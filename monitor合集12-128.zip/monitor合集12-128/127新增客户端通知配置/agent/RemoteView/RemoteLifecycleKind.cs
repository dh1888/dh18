namespace EnterpriseAgent.Agent.RemoteView;

/// <summary>
/// RemoteView lifecycle operation kinds. Detection stays outside; only execution is unified.
/// </summary>
internal enum RemoteLifecycleKind
{
    Recovery = 0,
    BootstrapRecovery = 1,
    QualityChange = 2,
    UserStart = 3,
    UserStop = 4,
}

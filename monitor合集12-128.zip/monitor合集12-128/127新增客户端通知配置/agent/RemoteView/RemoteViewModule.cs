using System.Diagnostics;
using System.Text;
using System.Text.Json;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.Lifecycle;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EnterpriseAgent.Agent.RemoteView;

public interface IRemoteViewPublisher
{
    bool IsPublishing { get; }
    string? ActiveSessionId { get; }
    RemoteViewStats GetStats();
    RemoteHealthStatus GetHealth();
    Task StartPublishAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default);
    Task StopPublishAsync(CancellationToken cancellationToken = default);
}

public sealed class RemoteViewConfig
{
    public bool Enabled { get; set; } = true;
    public int TargetWidth { get; set; } = 1280;
    public int TargetHeight { get; set; } = 720;
    public int TargetFps { get; set; } = 15;
    public int VideoBitrateKbps { get; set; } = 2000;
    /// <summary>Wait after stop / before RTMP connect so Ingress can accept a new publisher.</summary>
    public int IngressWarmupMs { get; set; } = 400;
    /// <summary>Settle after stopping ffmpeg before republishing the same ingress (quality switch).</summary>
    public int QualitySwitchSettleMs { get; set; } = 600;
    /// <summary>After SharedBridge recording first frame, wait before launching remote WHIP encode.</summary>
    public int SharedBridgeRecordingWarmMs { get; set; } = 500;
    /// <summary>First WHIP publish: max time to poll for slow-state before skipping recovery.</summary>
    public int SlowPublishHealthSampleMaxMs { get; set; } = 2000;
    /// <summary>Poll interval while sampling first WHIP publish health.</summary>
    public int SlowPublishHealthPollMs { get; set; } = 350;
    /// <summary>Delay before first slow-publish health sample after WHIP media ready.</summary>
    public int SlowPublishHealthInitialMs { get; set; } = 500;
    /// <summary>
    /// Mid-session FFmpeg speed watchdog: when publishing, recover sustained sub-realtime encode.
    /// Does not change CFR / pipe queue / QSV async_depth.
    /// </summary>
    public bool SpeedWatchdogEnabled { get; set; } = true;
    /// <summary>Treat speed below this as slow (FFmpeg -progress speed=).</summary>
    public double SpeedWatchdogThreshold { get; set; } = 0.5;
    /// <summary>Consecutive slow speed= samples required before recovery (≈0.5s each when CFR waits).</summary>
    public int SpeedWatchdogConsecutiveSlowSamples { get; set; } = 10;
    /// <summary>Ignore slow samples for this long after each (re)launch.</summary>
    public int SpeedWatchdogGraceMs { get; set; } = 15000;
    /// <summary>Same-parameter restarts before applying network degrade (weak).</summary>
    public int SpeedWatchdogSameParamMaxRestarts { get; set; } = 2;
    /// <summary>Hard cap on speed-watchdog recoveries per remote session.</summary>
    public int SpeedWatchdogMaxRestartsPerSession { get; set; } = 5;
    /// <summary>FFmpeg launch attempts when RTMP output fails to open.</summary>
    public int RtmpLaunchMaxAttempts { get; set; } = 3;
    /// <summary>Max automatic FFmpeg restarts per remote-view session before reporting failed.</summary>
    public int RtmpMaxRestartsPerSession { get; set; } = 5;
    /// <summary>auto | strong | weak — auto starts at full/policy quality and steps down after failures.</summary>
    public string NetworkProfile { get; set; } = "auto";
    public int WeakWidth { get; set; } = 854;
    public int WeakHeight { get; set; } = 480;
    public int WeakFps { get; set; } = 8;
    public int WeakVideoBitrateKbps { get; set; } = 600;
    /// <summary>Emergency only: WHIP without SharedBridge. Default false — SharedBridge is the architecture.</summary>
    public bool PreferDualGdigrabForWhip { get; set; } = false;
    /// <summary>FFmpeg -handshake_timeout for WHIP (ms). Local ICE gather + HTTPS POST need headroom.</summary>
    public int WhipHandshakeTimeoutMs { get; set; } = 20000;
    /// <summary>Wait for out_time_us/total_size after WHIP start before declaring ICE failure.</summary>
    public int WhipMediaReadyTimeoutMs { get; set; } = 20000;
    /// <summary>FFmpeg raw pipe -thread_queue_size (frames). 0 = omit (backup 63 default).</summary>
    public int RemotePipeThreadQueueSize { get; set; } = 0;
    /// <summary>WHIP VBV -bufsize as bitrate/divisor (4 → 500k at 2000kbps, ~250ms).</summary>
    public int WhipBufsizeDivisor { get; set; } = 4;
    /// <summary>WHIP GOP length as fps/divisor (2 → gop=7 at 15fps).</summary>
    public int WhipGopDivisor { get; set; } = 2;
    /// <summary>QSV -async_depth for remote WHIP. 1 = backup 63 low-latency profile.</summary>
    public int QsvAsyncDepth { get; set; } = 1;
    /// <summary>Emit [RemoteViewLifecycleDiag] logs (FFmpeg teardown / republish). Default off.</summary>
    public bool LifecycleDiagEnabled { get; set; }
}

public sealed class RemoteViewStartParams
{
    public string SessionId { get; init; } = "";
    public string RoomName { get; init; } = "";
    public string LiveKitUrl { get; init; } = "";
    /// <summary>rtmp | whip. Empty = infer from WhipUrl/RtmpUrl.</summary>
    public string PublishProtocol { get; init; } = "";
    public string RtmpUrl { get; init; } = "";
    public string WhipUrl { get; init; } = "";
    public int Width { get; init; } = 1920;
    public int Height { get; init; } = 1080;
    public int Fps { get; init; } = 15;
    /// <summary>Optional session override: auto | weak | strong. Empty = use RemoteViewConfig.NetworkProfile.</summary>
    public string NetworkProfile { get; init; } = "";
    /// <summary>Optional session bitrate override in kbps. 0 = use config default.</summary>
    public int VideoBitrateKbps { get; init; }
    /// <summary>Ingress stream key (WHIP Authorization Bearer). Empty = derive from publish URL.</summary>
    public string StreamKey { get; init; } = "";

    public string ResolvePublishProtocol()
    {
        var p = (PublishProtocol ?? "").Trim().ToLowerInvariant();
        if (p is "whip" or "rtmp")
            return p;
        if (!string.IsNullOrWhiteSpace(WhipUrl))
            return "whip";
        return "rtmp";
    }

    public string ResolvePublishUrl()
    {
        if (ResolvePublishProtocol() == "whip" && !string.IsNullOrWhiteSpace(WhipUrl))
            return WhipUrl.Trim();
        return (RtmpUrl ?? "").Trim();
    }

    public string ResolveStreamKey()
    {
        if (!string.IsNullOrWhiteSpace(StreamKey))
            return StreamKey.Trim();
        return ExtractStreamKeyFromUrl(ResolvePublishUrl());
    }

    public static string ExtractStreamKeyFromUrl(string url)
    {
        if (string.IsNullOrWhiteSpace(url))
            return "";
        var u = url.Trim().TrimEnd('/');
        var idx = u.LastIndexOf('/');
        if (idx < 0 || idx >= u.Length - 1)
            return "";
        return u[(idx + 1)..];
    }
}

public sealed class RemoteViewStats
{
    public int Fps { get; set; }
    public int BitrateKbps { get; set; }
    public string Encoder { get; set; } = "libx264";
    public bool IsPublishing { get; set; }
    public string? SessionId { get; set; }
}

/// <summary>
/// 远程查看：录屏与推流分离（双进程架构），经 LifecycleCoordinator 编排。
/// </summary>
public sealed class CompositeRemoteViewPublisher : IRemoteViewPublisher, IDisposable
{
    private readonly ILifecycleCoordinator _lifecycle;
    private readonly IRemoteViewService _remoteView;
    private readonly ILogger<CompositeRemoteViewPublisher> _logger;
    private bool _disposed;

    public event Func<string?, string, Task>? PublishFailed;

    public CompositeRemoteViewPublisher(
        ILifecycleCoordinator lifecycle,
        IRemoteViewService remoteView,
        ILogger<CompositeRemoteViewPublisher> logger)
    {
        _lifecycle = lifecycle;
        _remoteView = remoteView;
        _logger = logger;
        _lifecycle.RemoteViewPublishFailed += OnRecorderRemoteFailedAsync;
    }

    public bool IsPublishing => _lifecycle.IsRemoteActive;

    public string? ActiveSessionId => _remoteView.ActiveSessionId;

    public RemoteViewStats GetStats() => _remoteView.GetStats();

    public RemoteHealthStatus GetHealth() => _remoteView.GetHealth();

    public async Task StartPublishAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default)
    {
        // Same session already in remote mode: restart encode only — keep SharedBridge / recording.
        if (_lifecycle.IsRemoteActive &&
            (string.IsNullOrWhiteSpace(_remoteView.ActiveSessionId) ||
             string.Equals(_remoteView.ActiveSessionId, parameters.SessionId, StringComparison.OrdinalIgnoreCase)))
        {
            var diagnostics = _lifecycle.GetDiagnostics();
            if (diagnostics.SharedBridgeForRemote && !diagnostics.SharedCaptureActive)
            {
                _logger.LogWarning(
                    "SharedBridge inactive for session={SessionId}; full EnterRemoteView instead of in-place restart",
                    parameters.SessionId);
            }
            else
            {
                RemoteDiagLog.Event(
                    _logger,
                    "RemoteView",
                    parameters.SessionId,
                    "publishing",
                    "in-place encode restart (SharedBridge kept)");
                _logger.LogInformation(
                    "In-place remote encode restart session={SessionId} (SharedBridge kept)",
                    parameters.SessionId);
                await _remoteView.StartAsync(parameters, cancellationToken);
                if (string.Equals(
                        parameters.ResolvePublishProtocol(), "whip", StringComparison.OrdinalIgnoreCase))
                {
                    await _remoteView.WaitForPublishReadyAsync(cancellationToken);
                }

                return;
            }
        }

        RemoteDiagLog.Event(
            _logger,
            "RemoteView",
            parameters.SessionId,
            "starting",
            "EnterRemoteView via lifecycle");
        _logger.LogInformation(
            "Starting remote view via recorder lifecycle session={SessionId}",
            parameters.SessionId);

        var result = await _lifecycle.RequestAsync(
            RecorderCommand.EnterRemoteView,
            new RecorderRequestContext { RemoteView = parameters, Reason = "RemoteViewSession" },
            cancellationToken);

        if (!result.Success)
            throw new InvalidOperationException(result.Message ?? "EnterRemoteView failed");
    }

    public async Task StopPublishAsync(CancellationToken cancellationToken = default)
    {
        RemoteDiagLog.Event(
            _logger,
            "RemoteView",
            ActiveSessionId,
            IsPublishing ? "publishing" : "idle",
            "StopPublishAsync ExitRemoteView");
        await _lifecycle.RequestAsync(
            RecorderCommand.ExitRemoteView,
            new RecorderRequestContext { Reason = "RemoteViewSession stop" },
            cancellationToken);
    }

    private Task OnRecorderRemoteFailedAsync(string? sessionId, string detail)
    {
        PublishFailed?.Invoke(sessionId, detail);
        return Task.CompletedTask;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _lifecycle.RemoteViewPublishFailed -= OnRecorderRemoteFailedAsync;
        try
        {
            StopPublishAsync().Wait(TimeSpan.FromSeconds(5));
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Remote view stop during dispose timed out or failed");
        }
    }
}

public sealed class RemoteViewSessionController
{
    private readonly ILogger<RemoteViewSessionController> _logger;
    private readonly IRemoteViewPublisher _publisher;
    private readonly RemoteViewConfig _config;
    private readonly IServiceProvider _serviceProvider;
    private readonly SemaphoreSlim _sessionLock = new(1, 1);
    private readonly TimeSpan _statsInterval = TimeSpan.FromSeconds(5);
    private CancellationTokenSource? _enterCts;
    private CancellationTokenSource? _statsCts;
    private Task? _statsTask;
    private string? _lastPublishFingerprint;
    private string? _lastStartedSessionId;

    public RemoteViewSessionController(
        ILogger<RemoteViewSessionController> logger,
        IRemoteViewPublisher publisher,
        IOptions<RemoteViewConfig> options,
        IServiceProvider serviceProvider)
    {
        _logger = logger;
        _publisher = publisher;
        _config = options.Value;
        _serviceProvider = serviceProvider;

        if (publisher is CompositeRemoteViewPublisher compositePublisher)
        {
            compositePublisher.PublishFailed += OnPublishFailedAsync;
        }
    }

    public async Task HandleStartAsync(JsonElement paramsElement, CancellationToken cancellationToken = default)
    {
        if (!_config.Enabled)
        {
            _logger.LogInformation("Remote view is disabled by configuration");
            return;
        }

        RemoteViewStartParams startParams;
        CancellationToken linkedToken;

        await _sessionLock.WaitAsync(cancellationToken);
        try
        {
            startParams = ParseStartParams(paramsElement);
            if (string.IsNullOrWhiteSpace(startParams.ResolvePublishUrl()))
            {
                await SendEventAsync(startParams.SessionId, "failed", "publish URL is missing");
                return;
            }

            RemoteDiagLog.Event(
                _logger,
                "RemoteView",
                startParams.SessionId,
                _publisher.IsPublishing ? "publishing" : "idle",
                $"HandleStart begin protocol={startParams.ResolvePublishProtocol()}");

            if (_publisher.IsPublishing || _publisher.GetStats().IsPublishing)
            {
                var livePublishing = _publisher.GetStats().IsPublishing;
                var activeId = _publisher.ActiveSessionId;
                if (IsSameRemoteSession(activeId, startParams.SessionId))
                {
                    var fingerprint = BuildPublishFingerprint(startParams);
                    if (livePublishing &&
                        string.Equals(_lastPublishFingerprint, fingerprint, StringComparison.Ordinal) &&
                        IsPublisherMediaLive(_publisher))
                    {
                        _logger.LogInformation("Remote view already active for session {SessionId}", startParams.SessionId);
                        await SendEventAsync(startParams.SessionId, "published");
                        return;
                    }

                    // Quality / dead-ffmpeg restart: do NOT ExitRemoteView — StartPublishAsync
                    // will in-place restart encode and keep SharedBridge.
                    _logger.LogInformation(
                        "{Action} remote view session {SessionId} profile={Profile} size={Width}x{Height}@{Fps}",
                        livePublishing ? "Updating" : "Restarting dead",
                        startParams.SessionId,
                        string.IsNullOrWhiteSpace(startParams.NetworkProfile) ? "(config)" : startParams.NetworkProfile,
                        startParams.Width,
                        startParams.Height,
                        startParams.Fps);
                }
                else
                {
                    _logger.LogInformation(
                        "Replacing remote view session {Old} -> {New}",
                        activeId, startParams.SessionId);
                    await _publisher.StopPublishAsync(cancellationToken);
                    var cooldownMs = Math.Max(_config.QualitySwitchSettleMs, 300);
                    await Task.Delay(cooldownMs, cancellationToken);
                }
            }
            else if (_config.IngressWarmupMs > 0)
            {
                // Short settle only — backend already waited for Ingress create.
                var warmMs = Math.Min(_config.IngressWarmupMs, 250);
                if (warmMs > 0)
                    await Task.Delay(warmMs, cancellationToken);
            }

            // Do not cancel an in-flight start here — quality switches are serialized on
            // _sessionLock and cancelling mid-restart leaves SharedBridge without an encoder.
            _enterCts?.Dispose();
            _enterCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            linkedToken = _enterCts.Token;
        }
        finally
        {
            _sessionLock.Release();
        }

        try
        {
            await _publisher.StartPublishAsync(startParams, linkedToken);
        }
        catch (OperationCanceledException) when (linkedToken.IsCancellationRequested)
        {
            _logger.LogInformation("Remote view start cancelled for session {SessionId}", startParams.SessionId);
            await SendEventAsync(startParams.SessionId, "stopped");
            return;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to start remote view for session {SessionId}", startParams.SessionId);
            _lastPublishFingerprint = null;
            _lastStartedSessionId = null;
            try
            {
                await _publisher.StopPublishAsync(CancellationToken.None);
            }
            catch (Exception stopEx)
            {
                _logger.LogWarning(stopEx, "Cleanup stop failed after remote view start error");
            }

            if (string.Equals(startParams.ResolvePublishProtocol(), "whip", StringComparison.OrdinalIgnoreCase)
                && !string.IsNullOrWhiteSpace(startParams.RtmpUrl))
            {
                _logger.LogWarning(
                    "WHIP start failed; requesting RTMP fallback session={SessionId}: {Detail}",
                    startParams.SessionId, ex.Message);
                await SendEventAsync(startParams.SessionId, "whip_fallback_request", ex.Message);
                return;
            }

            if (string.Equals(startParams.ResolvePublishProtocol(), "whip", StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning(
                    "WHIP start failed (no RTMP URL / whip-only); session={SessionId}: {Detail}",
                    startParams.SessionId, ex.Message);
            }

            await SendEventAsync(startParams.SessionId, "failed", ex.Message);
            return;
        }

        await _sessionLock.WaitAsync(cancellationToken);
        try
        {
            _lastStartedSessionId = startParams.SessionId;
            _lastPublishFingerprint = BuildPublishFingerprint(startParams);
            await SendEventAsync(startParams.SessionId, "published");
            StartStatsLoop();
            RemoteDiagLog.Event(
                _logger,
                "RemoteView",
                startParams.SessionId,
                "published",
                "HandleStart complete");
            _logger.LogInformation("Remote view publishing started for session {SessionId}", startParams.SessionId);
        }
        finally
        {
            _sessionLock.Release();
        }
    }

    private static bool IsPublisherMediaLive(IRemoteViewPublisher publisher)
    {
        if (!publisher.GetStats().IsPublishing)
            return false;

        var health = publisher.GetHealth();
        return health.ProcessAlive && health.FrameRecent;
    }

    private bool IsSameRemoteSession(string? activeId, string? requestedId)
    {
        if (string.Equals(activeId, requestedId, StringComparison.OrdinalIgnoreCase))
            return true;

        if (string.IsNullOrWhiteSpace(activeId) && string.IsNullOrWhiteSpace(requestedId))
            return true;

        // Quality-switch in-place restart clears ActiveSessionId while SharedBridge stays up.
        if (string.IsNullOrWhiteSpace(activeId)
            && !string.IsNullOrWhiteSpace(requestedId)
            && _publisher.IsPublishing
            && string.Equals(_lastStartedSessionId, requestedId, StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        return false;
    }

    public async Task HandleStopAsync(JsonElement paramsElement = default, CancellationToken cancellationToken = default)
    {
        _enterCts?.Cancel();

        var stopWait = TimeSpan.FromMilliseconds(
            Math.Clamp(_config.WhipMediaReadyTimeoutMs + _config.QualitySwitchSettleMs + 8000, 15000, 60000));
        if (!await _sessionLock.WaitAsync(stopWait, cancellationToken))
        {
            _logger.LogWarning("Stop remote view: session busy, forcing lifecycle stop");
            try
            {
                await _publisher.StopPublishAsync(CancellationToken.None);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Forced remote view stop failed");
            }
            return;
        }

        try
        {
            await HandleStopCoreAsync(paramsElement, cancellationToken);
            var cooldownMs = Math.Max(_config.QualitySwitchSettleMs, 300);
            if (cooldownMs > 0)
                await Task.Delay(cooldownMs, cancellationToken);
        }
        finally
        {
            _sessionLock.Release();
        }
    }

    private async Task HandleStopCoreAsync(JsonElement paramsElement, CancellationToken cancellationToken)
    {
        string? requestedSessionId = null;
        if (paramsElement.ValueKind == JsonValueKind.Object &&
            paramsElement.TryGetProperty("sessionId", out var sidProp))
        {
            requestedSessionId = sidProp.GetString();
        }

        var activeSessionId = _publisher.ActiveSessionId;
        if (!string.IsNullOrWhiteSpace(requestedSessionId) &&
            !string.IsNullOrWhiteSpace(activeSessionId) &&
            !string.Equals(requestedSessionId, activeSessionId, StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogInformation(
                "Ignoring stop for session {Requested} (active {Active})",
                requestedSessionId, activeSessionId);
            return;
        }

        var sessionId = activeSessionId ?? requestedSessionId;
        RemoteLifecycleDiagLog.Event(
            _logger,
            "RemoteView",
            sessionId,
            "handle-stop-begin",
            requestedSessionId != null ? $"requested={requestedSessionId}" : "active-only");
        RemoteDiagLog.Event(
            _logger,
            "RemoteView",
            sessionId,
            "stopping",
            "HandleStop begin");
        StopStatsLoop();
        await _publisher.StopPublishAsync(cancellationToken);
        _lastPublishFingerprint = null;
        _lastStartedSessionId = null;
        await SendEventAsync(sessionId, "stopped");
        RemoteLifecycleDiagLog.Event(
            _logger,
            "RemoteView",
            sessionId,
            "handle-stop-complete",
            "HandleStop complete");
        RemoteDiagLog.Event(
            _logger,
            "RemoteView",
            sessionId,
            "stopped",
            "HandleStop complete");
        _logger.LogInformation("Remote view publishing stopped");
    }

    private async Task OnPublishFailedAsync(string? sessionId, string detail)
    {
        StopStatsLoop();
        _lastPublishFingerprint = null;
        _lastStartedSessionId = null;
        if (!string.IsNullOrWhiteSpace(detail) &&
            detail.StartsWith("WHIP_FALLBACK_REQUEST:", StringComparison.OrdinalIgnoreCase))
        {
            var reason = detail["WHIP_FALLBACK_REQUEST:".Length..].Trim();
            RemoteDiagLog.Event(
                _logger,
                "RemoteView",
                sessionId,
                "whip-fallback",
                RemoteDiagLog.Truncate(reason, 160));
            _logger.LogWarning(
                "WHIP publish exhausted; requesting RTMP fallback session={SessionId}: {Detail}",
                sessionId, reason);
            await SendEventAsync(sessionId, "whip_fallback_request", reason);
            return;
        }

        await SendEventAsync(sessionId, "failed", detail);
    }

    private static string BuildPublishFingerprint(RemoteViewStartParams p) =>
        $"{p.SessionId}|{p.ResolvePublishProtocol()}|{p.NetworkProfile}|{p.Width}x{p.Height}@{p.Fps}|{p.VideoBitrateKbps}|{p.ResolvePublishUrl()}";

    private RemoteViewStartParams ParseStartParams(JsonElement element)
    {
        string GetString(string name) =>
            element.TryGetProperty(name, out var prop) ? prop.GetString() ?? "" : "";

        int GetInt(string name, int fallback) =>
            element.TryGetProperty(name, out var prop) && prop.TryGetInt32(out var value) ? value : fallback;

        var networkProfile = GetString("networkProfile");
        if (string.IsNullOrWhiteSpace(networkProfile))
            networkProfile = GetString("quality");

        return new RemoteViewStartParams
        {
            SessionId = GetString("sessionId"),
            RoomName = GetString("roomName"),
            LiveKitUrl = GetString("livekitUrl"),
            PublishProtocol = GetString("publishProtocol"),
            RtmpUrl = GetString("rtmpUrl"),
            WhipUrl = GetString("whipUrl"),
            Width = GetInt("width", 1280),
            Height = GetInt("height", 720),
            Fps = GetInt("fps", 10),
            NetworkProfile = networkProfile,
            VideoBitrateKbps = GetInt("videoBitrateKbps", 0),
            StreamKey = GetString("streamKey"),
        };
    }

    private void StartStatsLoop()
    {
        StopStatsLoop();
        _statsCts = new CancellationTokenSource();
        var token = _statsCts.Token;
        _statsTask = Task.Run(async () =>
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    if (_publisher.IsPublishing)
                    {
                        var stats = _publisher.GetStats();
                        await SendStatsAsync(stats, token);
                    }
                    await Task.Delay(_statsInterval, token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogDebug(ex, "Remote view stats loop error");
                }
            }
        }, token);
    }

    private void StopStatsLoop()
    {
        try
        {
            _statsCts?.Cancel();
        }
        catch
        {
            // ignore
        }
        finally
        {
            _statsCts?.Dispose();
            _statsCts = null;
            _statsTask = null;
        }
    }

    private Task SendStatsAsync(RemoteViewStats stats, CancellationToken cancellationToken)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "remote_view_stats",
            sessionId = stats.SessionId,
            fps = stats.Fps,
            bitrateKbps = stats.BitrateKbps,
            encoder = stats.Encoder,
        });
        return GetWebSocketService().SendMessageAsync(payload, cancellationToken);
    }

    private Task SendEventAsync(string? sessionId, string eventName, string? detail = null)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "remote_view_event",
            sessionId,
            @event = eventName,
            detail,
        });
        return GetWebSocketService().SendMessageAsync(payload);
    }

    private Services.WebSocketService GetWebSocketService() =>
        _serviceProvider.GetRequiredService<Services.WebSocketService>();
}


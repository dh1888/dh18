namespace EnterpriseAgent.Agent.Health;

/// <summary>
/// Queues recovery requests. Recording recoveries are drained by HealthCoordinator;
/// remote publish recoveries should call <see cref="IRemoteViewService.RequestRecoveryAsync"/> directly
/// (sole remote executor).
/// </summary>
public interface IRecoveryRequestSink
{
    void RequestRecordingRecovery(string reason);
    bool TryTakePendingRecordingRecovery(out string reason);
}

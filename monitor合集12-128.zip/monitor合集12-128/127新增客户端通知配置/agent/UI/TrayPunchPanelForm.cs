using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Services;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.UI;

public sealed class TrayPunchActions
{
    public Func<bool>? GetIsConnected { get; init; }
    public Func<EmployeeTrayStatus>? GetEmployeeStatus { get; init; }
    public Func<bool>? GetTripleShiftEnabled { get; init; }
    public Func<string, Task<bool>>? OnCheckInShift { get; init; }
    public Func<Task<bool>>? OnCheckOut { get; init; }
    public Func<Task<bool>>? OnEmployeeLogin { get; init; }
    /// <summary>Logout then show login (switch account). Same as tray「退出登录」.</summary>
    public Func<Task<bool>>? OnEmployeeSwitchAccount { get; init; }
    public Func<Task<TgPunchDashboard?>>? LoadDashboardAsync { get; init; }
    public Func<TgPunchDashboard?>? GetCachedDashboard { get; init; }
    public Action<TgPunchRecord>? RememberLocalRecord { get; init; }
    public Action<TgOpenActivity?>? UpdateCachedOpenActivity { get; init; }
    public Func<string, Task<(bool Success, string Message, TgOpenActivity? OpenActivity)>>? OnStartActivityAsync { get; init; }
    public Func<string?, Task<(bool Success, string Message)>>? OnActivityBackAsync { get; init; }
    public AgentNotificationService? Notifications { get; init; }
    public ILocalizationService? Localization { get; init; }
    public ILogger? Logger { get; init; }
    public Action? OnStateChanged { get; init; }
}

/// <summary>
/// TG-synced punch panel on tray left-click.
/// </summary>
public sealed class TrayPunchPanelForm : Form
{
    private const int CornerRadius = 18;
    private const int AccentWidth = 4;
    /// <summary>Design size on normal screens — keep pixel-identical when work area allows.</summary>
    private const int ExpandedWidth = 480;
    private const int ExpandedHeight = 694;
    private const int RecordsAreaHeight = 188;
    private const int ContentWidth = 436;
    private const int ActivityButtonWidth = 134;
    private const int ActivityButtonHeight = 42;
    private const int ActivityRowSpacing = 8;
    private const int ActivityAreaHeight = ActivityButtonHeight * 2 + ActivityRowSpacing + 6;
    private const int HeaderIconButtonSize = 30;
    private const int HeaderTitleRowHeight = 36;
    private const int HeaderMetaRowHeight = 30;
    private const int HeaderVerticalPadding = 16;
    private const int HeaderPanelHeight = HeaderTitleRowHeight + HeaderMetaRowHeight + HeaderVerticalPadding;
    private const float PanelOpacity = 0.88f;
    private const int DockThickness = 24;
    private const int DockLength = 80;
    private const int EdgeSnapPx = 36;
    private const double SideDockZoneRatio = 0.33;
    /// <summary>Small-screen floors (still usable; never force wider/taller than work area).</summary>
    private const int MinExpandedWidth = 320;
    private const int MinExpandedHeight = 520;
    private const int MinContentWidth = 260;
    private const int MinActionButtonWidth = 56;
    private const int ScreenEdgeMargin = 10;
    private const int ActivityButtonsPerRow = 3;

    private static Rectangle? s_lastExpandedBounds;
    private static bool s_lightTheme;

    private PunchPanelPalette _palette = PunchPanelPalette.Dark;
    private readonly Panel _headerActionsRow;
    private readonly FlowLayoutPanel _headerTitleRow;
    private readonly Panel _employeeAvatarHost;
    private readonly Label _headerTitleLabel;
    private string? _employeeAvatarKey;
    private readonly Button _accountButton;
    private readonly Button _themeButton;
    private readonly Button _languageButton;
    private readonly ContextMenuStrip _languageMenu;

    private enum PanelDisplayMode { Expanded, DockCollapsed }

    private enum DockEdge { Left, Right, Bottom }

    private readonly TrayPunchActions _actions;
    private readonly Panel _accentPanel;
    private readonly Panel _bodyPanel;
    private readonly Panel _dockTabPanel;
    private readonly Panel _headerPanel;
    private readonly FlowLayoutPanel _metaRow;
    private readonly Label _empNoLabel;
    private readonly Label _metaDot1;
    private readonly Label _positionLabel;
    private readonly PillChipLabel _statusChip;
    private readonly PillChipLabel _workChip;
    private readonly PillChipLabel _openActivityChip;
    private readonly Button _closeButton;
    private readonly PunchStyledButton _checkInDayButton;
    private readonly PunchStyledButton _checkInMiddleButton;
    private readonly PunchStyledButton _checkInNightButton;
    private readonly PunchStyledButton _checkOutButton;
    private readonly PunchStyledButton _loginButton;
    private readonly Panel _shiftBlock;
    private readonly FlowLayoutPanel _shiftButtonRow;
    private readonly FlowLayoutPanel _activityButtonsHost;
    private readonly PunchStyledButton _backButton;
    private readonly List<PunchStyledButton> _activityButtons = new();
    private readonly Dictionary<PunchStyledButton, TgActivityTypeItem> _buttonActivityMap = new();
    private string _activityTypesSignature = string.Empty;
    private readonly PunchRecordsHost _recordsHost;
    private readonly Panel _recordsCard;
    private readonly Label _recordsTitle;
    private readonly Label _shiftSectionTitle;
    private readonly Label _activitySectionTitle;
    private readonly Label _activityCountdownLabel;
    private Panel _activitySectionPanel = null!;
    private FlowLayoutPanel _activitySectionHeaderRow = null!;
    private readonly TableLayoutPanel _contentLayout;
    private readonly System.Windows.Forms.Timer _activityCountdownTimer;

    private TgPunchDashboard? _dashboard;
    private bool _loading;
    private bool _reloadPending;
    private PanelDisplayMode _displayMode = PanelDisplayMode.Expanded;
    private DockEdge _dockEdge = DockEdge.Right;
    private int _dockAnchorCoord;
    private bool _dragging;
    private Point _dragMouseScreen;
    private Point _dragFormOrigin;
    private bool _uiReady;
    private bool _relayouting;
    private int _lastLaidOutContentWidth = -1;

    public TrayPunchPanelForm(TrayPunchActions actions)
    {
        _actions = actions;
        _palette = s_lightTheme ? PunchPanelPalette.Light : PunchPanelPalette.Dark;

        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        BackColor = _palette.Bg;
        ForeColor = _palette.TextPrimary;
        Font = new Font("Segoe UI", 9.5F);
        var initialSize = FitExpandedSize(Screen.PrimaryScreen?.WorkingArea
            ?? new Rectangle(0, 0, ExpandedWidth, ExpandedHeight));
        Width = initialSize.Width;
        Height = initialSize.Height;
        Opacity = PanelOpacity;
        DoubleBuffered = true;

        _accentPanel = new Panel { Dock = DockStyle.Left, Width = AccentWidth, BackColor = _palette.Accent };
        _accentPanel.Paint += (_, e) =>
        {
            var rect = _accentPanel.ClientRectangle;
            using var brush = new LinearGradientBrush(rect, _palette.Accent, _palette.AccentSoft, 90f);
            e.Graphics.FillRectangle(brush, rect);
        };

        _headerPanel = new Panel
        {
            Dock = DockStyle.Top,
            Height = HeaderPanelHeight,
            BackColor = _palette.HeaderBg,
            Padding = new Padding(0)
        };
        _headerPanel.Paint += PaintHeaderBackground;

        _themeButton = CreateHeaderIconButton(string.Empty);
        _themeButton.Click += (_, _) => ToggleTheme();
        HandleCreated += (_, _) =>
        {
            EnsureLanguageButtonGlyphVisible();
            EnsureThemeButtonGlyphVisible();
        };

        _closeButton = CreateHeaderIconButton("×");
        _closeButton.Font = new Font("Segoe UI", 14F, FontStyle.Regular);
        _closeButton.Padding = new Padding(0, 0, 0, 2);
        _closeButton.Click += (_, _) => CollapseToDockStrip();

        _languageMenu = new ContextMenuStrip();
        RefreshLanguageMenu();
        // Segoe UI often cannot glyph 🌐 — use emoji font + 文 fallback for visibility.
        _languageButton = CreateHeaderIconButton("文");
        _languageButton.Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold);
        _languageButton.Click += (_, e) =>
        {
            RefreshLanguageMenu();
            _languageMenu.Show(_languageButton, new Point(0, _languageButton.Height));
        };

        _headerActionsRow = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0),
            Height = HeaderTitleRowHeight,
            MinimumSize = new Size(HeaderIconButtonSize * 3 + 12, HeaderTitleRowHeight),
            MaximumSize = new Size(0, HeaderTitleRowHeight)
        };
        _headerActionsRow.Controls.Add(_closeButton);
        _headerActionsRow.Controls.Add(_themeButton);
        _headerActionsRow.Controls.Add(_languageButton);
        _headerActionsRow.Resize += (_, _) => LayoutHeaderActionButtons();

        _employeeAvatarHost = new Panel
        {
            Size = new Size(28, 28),
            Margin = new Padding(0, 4, 8, 0),
            BackColor = Color.Transparent,
            Visible = false,
            Cursor = Cursors.SizeAll
        };
        _employeeAvatarHost.Paint += PaintEmployeeAvatar;

        _headerTitleLabel = new Label
        {
            Text = L("TrayPunchOpenPanel", "打卡面板"),
            AutoSize = true,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI Semibold", 10.25F, FontStyle.Bold),
            ForeColor = _palette.MetaText,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 6, 8, 0),
            Padding = new Padding(0),
            Cursor = Cursors.SizeAll
        };

        _accountButton = CreateAccountActionButton();
        _accountButton.Click += async (_, _) => await RunAccountActionAsync();

        _headerTitleRow = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            AutoSize = false,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0),
            Height = HeaderTitleRowHeight
        };
        _headerTitleRow.Controls.Add(_employeeAvatarHost);
        _headerTitleRow.Controls.Add(_headerTitleLabel);
        _headerTitleRow.Controls.Add(_accountButton);

        _metaRow = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            Height = HeaderMetaRowHeight,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            AutoSize = false,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0, 2, 0, 0)
        };

        _empNoLabel = CreateMetaLabel(string.Empty);
        _metaDot1 = CreateMetaDot();
        _positionLabel = CreateMetaLabel(string.Empty);
        _statusChip = CreatePillChip(L("Disconnected", "未连接"), _palette.ChipIdle);
        _workChip = CreatePillChip(L("WorkStatusOffShift", "未上班"), _palette.ChipIdle);
        _openActivityChip = CreatePillChip(string.Empty, _palette.OpenActivityChip);
        _openActivityChip.Visible = false;
        _openActivityChip.ForeColor = _palette.OpenActivityText;

        _metaRow.Controls.AddRange(new Control[]
        {
            _empNoLabel, _metaDot1, _positionLabel, _statusChip, _workChip, _openActivityChip
        });

        var headerLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 2,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(16, 8, 10, 8),
            GrowStyle = TableLayoutPanelGrowStyle.FixedSize
        };
        headerLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        headerLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, HeaderIconButtonSize * 3 + 12));
        headerLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, HeaderTitleRowHeight));
        headerLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, HeaderMetaRowHeight));
        headerLayout.Controls.Add(_headerTitleRow, 0, 0);
        headerLayout.Controls.Add(_headerActionsRow, 1, 0);
        headerLayout.Controls.Add(_metaRow, 0, 1);
        headerLayout.SetColumnSpan(_metaRow, 2);
        LayoutHeaderActionButtons();

        _headerPanel.Controls.Add(headerLayout);
        WireHeaderDrag(_headerPanel);
        WireHeaderDrag(_headerTitleLabel);
        WireHeaderDrag(_headerTitleRow);
        WireHeaderDrag(_employeeAvatarHost);
        WireHeaderDrag(_headerActionsRow);
        WireHeaderDrag(_metaRow);
        foreach (Control child in _metaRow.Controls)
            WireHeaderDrag(child);

        _bodyPanel = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = false,
            BackColor = _palette.Bg,
            Padding = new Padding(16, 12, 16, 14)
        };

        _contentLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 7,
            BackColor = _palette.Bg,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        var layout = _contentLayout;
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, ActivityAreaHeight));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, RecordsAreaHeight));

        layout.Controls.Add(CreateSectionPanel(L("TrayPunchSectionShift", "上下班"), out _shiftSectionTitle), 0, 0);
        _shiftButtonRow = CreateButtonRow(withBottomSpacing: false);
        _checkInDayButton = CreateActionButton(L("CheckInDay", "白班上班"), PunchButtonStyle.Success);
        _checkInDayButton.Click += async (_, _) => await RunShiftAsync("day");
        _checkInMiddleButton = CreateActionButton(L("CheckInMiddle", "中班上班"), PunchButtonStyle.Success);
        _checkInMiddleButton.Click += async (_, _) => await RunShiftAsync("middle");
        _checkInNightButton = CreateActionButton(L("CheckInNight", "夜班上班"), PunchButtonStyle.Success);
        _checkInNightButton.Click += async (_, _) => await RunShiftAsync("night");
        _checkOutButton = CreateActionButton(L("CheckOut", "下班"), PunchButtonStyle.Primary);
        _checkOutButton.Click += async (_, _) => await RunCheckoutAsync();
        _shiftButtonRow.Controls.AddRange(new Control[] {
            _checkInDayButton, _checkInMiddleButton, _checkInNightButton, _checkOutButton
        });

        _loginButton = CreateActionButton(L("EmployeeLogin", "员工登录"), PunchButtonStyle.Primary, width: ContentWidth);
        _loginButton.Margin = new Padding(0, 0, 0, 10);
        _loginButton.Visible = false;
        _loginButton.Click += async (_, _) => await RunLoginAsync();

        _shiftBlock = new Panel
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Dock = DockStyle.Top,
            BackColor = _palette.Bg,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        _shiftBlock.Controls.Add(_shiftButtonRow);
        _shiftBlock.Controls.Add(_loginButton);
        _loginButton.Dock = DockStyle.Top;
        _shiftButtonRow.Dock = DockStyle.Top;

        layout.Controls.Add(_shiftBlock, 0, 1);

        layout.Controls.Add(CreateActivitySectionPanel(out _activitySectionTitle, out _activityCountdownLabel), 0, 2);
        _activityButtonsHost = new FlowLayoutPanel
        {
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoSize = false,
            Dock = DockStyle.Fill,
            Width = ContentWidth,
            Height = ActivityAreaHeight,
            // Width floor must stay flexible — a fixed ContentWidth MinimumSize clips on small screens.
            MinimumSize = new Size(0, ActivityAreaHeight),
            BackColor = _palette.Bg,
            Margin = new Padding(0),
            Padding = new Padding(0, 0, 0, 2)
        };
        layout.Controls.Add(_activityButtonsHost, 0, 3);

        _backButton = CreateActionButton(L("ActivityBack", "回座"), PunchButtonStyle.Warning, width: ContentWidth);
        _backButton.Margin = new Padding(0, 2, 0, 10);
        _backButton.Click += async (_, _) => await RunBackAsync();
        layout.Controls.Add(_backButton, 0, 4);

        layout.Controls.Add(CreateSectionPanel(L("TrayPunchRecords", "今日打卡记录"), out _recordsTitle), 0, 5);

        _recordsCard = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = _palette.CardBg,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        _recordsCard.Paint += (_, e) => PaintRoundedCard(e.Graphics, _recordsCard.ClientRectangle, 12);

        _recordsHost = new PunchRecordsHost
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(6, 4, 6, 6)
        };
        _recordsHost.SetHeaders(
            L("TrayPunchColTime", "时间"),
            L("TrayPunchColEvent", "事项"),
            L("TrayPunchColDetail", "详情"),
            L("TrayPunchColSource", "来源"));

        _recordsHost.ApplyTheme(_palette.Records);

        _recordsCard.Controls.Add(_recordsHost);
        layout.Controls.Add(_recordsCard, 0, 6);

        _bodyPanel.Controls.Add(layout);
        Controls.Add(_bodyPanel);
        Controls.Add(_headerPanel);
        Controls.Add(_accentPanel);

        _dockTabPanel = new Panel
        {
            Dock = DockStyle.Fill,
            Visible = false,
            Cursor = Cursors.Hand,
            BackColor = _palette.Accent
        };
        _dockTabPanel.Paint += PaintDockTab;
        _dockTabPanel.MouseClick += (_, e) =>
        {
            if (e.Button == MouseButtons.Left && _displayMode == PanelDisplayMode.DockCollapsed)
                ExpandFromDock();
        };
        Controls.Add(_dockTabPanel);
        _dockTabPanel.SendToBack();

        ApplyRoundedRegion();
        Paint += (_, e) =>
        {
            if (_displayMode != PanelDisplayMode.Expanded)
                return;

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, Width - 1, Height - 1);
            using var path = CreateRoundedPath(rect, CornerRadius);
            using (var fill = new SolidBrush(Color.FromArgb(180, _palette.Bg)))
                e.Graphics.FillPath(fill, path);
            using var glow = new Pen(Color.FromArgb(40, _palette.Accent), 1.5f);
            using var border = new Pen(Color.FromArgb(120, _palette.Border));
            e.Graphics.DrawPath(glow, path);
            e.Graphics.DrawPath(border, path);
        };

        RefreshHeader();
        ApplyThemeChrome();

        _activityCountdownTimer = new System.Windows.Forms.Timer { Interval = 1000 };
        _activityCountdownTimer.Tick += (_, _) => RefreshActivityCountdown();

        _uiReady = true;
        EnsureThemeButtonGlyphVisible();
        RelayoutContentToWidth(force: true);
    }

    protected override void OnVisibleChanged(EventArgs e)
    {
        base.OnVisibleChanged(e);
        SyncActivityCountdownTimer();
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        if (!_uiReady || _displayMode != PanelDisplayMode.Expanded)
            return;

        RelayoutContentToWidth();
        ApplyRoundedRegion();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
            _activityCountdownTimer.Dispose();

        base.Dispose(disposing);
    }

    private void ApplyThemeChrome()
    {
        _themeButton.FlatAppearance.BorderSize = 0;
        _languageButton.FlatAppearance.BorderSize = 0;
        _closeButton.FlatAppearance.BorderSize = 0;
        _accountButton.FlatAppearance.BorderSize = 0;
        _accountButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
        ApplyAccountButtonTheme();
    }

    public bool IsOpen => Visible && !IsDisposed && _displayMode == PanelDisplayMode.Expanded;

    public void HideToTray()
    {
        _dragging = false;
        _headerPanel.Capture = false;
        _activityCountdownTimer.Stop();
        Hide();
    }

    public void ShowNearTray()
    {
        if (_displayMode == PanelDisplayMode.DockCollapsed)
            ExpandFromDock(silent: true);

        _displayMode = PanelDisplayMode.Expanded;
        _dockTabPanel.Visible = false;
        SetExpandedChromeVisible(true);

        ApplyExpandedBounds(GetExpandedBoundsOrDefault());

        if (!Visible)
            Show();
        WindowState = FormWindowState.Normal;
        BringToFront();
        Activate();

        if (_dashboard == null)
            _dashboard = _actions.GetCachedDashboard?.Invoke();

        if (_dashboard != null)
        {
            RefreshHeader();
            UpdateButtons();
            RenderRecords();
        }
        else
        {
            RefreshHeader();
            UpdateButtons();
            RenderRecords();
        }

        _ = ReloadDashboardAsync();
    }

    public void EnsureExpandedVisible()
    {
        if (_displayMode == PanelDisplayMode.DockCollapsed)
            ExpandFromDock(silent: true);

        if (!Visible)
            ShowNearTray();
        else if (_displayMode == PanelDisplayMode.Expanded)
        {
            BringToFront();
            Activate();
        }
    }

    public void ApplyLocalization()
    {
        _headerTitleLabel.Text = L("TrayPunchOpenPanel", "打卡面板");
        _shiftSectionTitle.Text = L("TrayPunchSectionShift", "上下班");
        _checkInDayButton.Text = L("CheckInDay", "白班上班");
        _checkInMiddleButton.Text = L("CheckInMiddle", "中班上班");
        _checkInNightButton.Text = L("CheckInNight", "夜班上班");
        _checkOutButton.Text = L("CheckOut", "下班");
        _loginButton.Text = L("EmployeeLogin", "员工登录");
        _backButton.Text = L("ActivityBack", "回座");
        RefreshAccountButtonText();

        _recordsHost.SetHeaders(
            L("TrayPunchColTime", "时间"),
            L("TrayPunchColEvent", "事项"),
            L("TrayPunchColDetail", "详情"),
            L("TrayPunchColSource", "来源"));

        RefreshLanguageMenu();
        _activityTypesSignature = string.Empty;
        RebuildActivityButtons();
        RefreshHeader();
        UpdateButtons();
        RenderRecords();
        UpdateActivitySectionTitle();
    }

    private void RefreshLanguageMenu()
    {
        LanguageMenuBuilder.Populate(_languageMenu.Items, _actions.Localization, SelectLanguage);
    }

    private void SelectLanguage(string languageCode)
    {
        if (_actions.Localization == null)
            return;

        if (string.Equals(_actions.Localization.GetCurrentLanguage(), languageCode, StringComparison.OrdinalIgnoreCase))
            return;

        _actions.Localization.SetLanguage(languageCode);
    }

    public void RefreshState()
    {
        MergeCachedOpenActivity();

        if (_dashboard != null && !Visible)
        {
            _ = ReloadDashboardAsync();
            return;
        }

        if (!Visible)
            return;

        if (_dashboard != null)
        {
            RefreshHeader();
            UpdateButtons();
            RenderRecords();
        }
        else
        {
            // Cache may have just received OpenActivity via TG WS before first dashboard load.
            SyncActivityCountdownTimer();
        }

        _ = ReloadDashboardAsync();
    }

    private void MergeCachedOpenActivity()
    {
        var cached = _actions.GetCachedDashboard?.Invoke();
        if (cached == null)
            return;

        if (_dashboard == null)
        {
            _dashboard = cached;
            return;
        }

        _dashboard.OpenActivity = MergeOpenActivityStart(_dashboard.OpenActivity, cached.OpenActivity);
    }

    private static TgOpenActivity? MergeOpenActivityStart(TgOpenActivity? local, TgOpenActivity? server)
    {
        // Server/cache null means activity closed (e.g. TG 回座 activity_state_sync open=false).
        if (server == null)
            return null;
        if (local == null)
            return server;

        var sameSession = !string.IsNullOrWhiteSpace(local.SessionId)
            && !string.IsNullOrWhiteSpace(server.SessionId)
            && string.Equals(local.SessionId, server.SessionId, StringComparison.OrdinalIgnoreCase);
        var sameActivity = string.Equals(local.ActivityName, server.ActivityName, StringComparison.OrdinalIgnoreCase);
        if (!sameSession && !sameActivity)
            return server;

        return new TgOpenActivity
        {
            SessionId = string.IsNullOrWhiteSpace(server.SessionId) ? local.SessionId : server.SessionId,
            ActivityName = string.IsNullOrWhiteSpace(server.ActivityName) ? local.ActivityName : server.ActivityName,
            StartedAt = PickEarlierStartedAt(local.StartedAt, server.StartedAt),
            LimitSeconds = server.LimitSeconds > 0 ? server.LimitSeconds : local.LimitSeconds
        };
    }

    private static string? PickEarlierStartedAt(string? localStartedAt, string? serverStartedAt)
    {
        if (string.IsNullOrWhiteSpace(localStartedAt))
            return serverStartedAt;
        if (string.IsNullOrWhiteSpace(serverStartedAt))
            return localStartedAt;

        if (!DateTime.TryParse(localStartedAt, null, System.Globalization.DateTimeStyles.RoundtripKind, out var local))
            return serverStartedAt;
        if (!DateTime.TryParse(serverStartedAt, null, System.Globalization.DateTimeStyles.RoundtripKind, out var server))
            return localStartedAt;

        return local.ToUniversalTime() <= server.ToUniversalTime()
            ? localStartedAt
            : serverStartedAt;
    }

    private TgOpenActivity BuildOpenActivityForStart(
        string activityKey,
        TgOpenActivity? server,
        DateTime clickedUtc,
        TgActivityTypeItem? type)
    {
        var limitSeconds = server?.LimitSeconds ?? type?.TimeLimitSeconds ?? 0;
        var startedAt = PickEarlierStartedAt(clickedUtc.ToString("O"), server?.StartedAt);
        return new TgOpenActivity
        {
            SessionId = server?.SessionId ?? string.Empty,
            ActivityName = string.IsNullOrWhiteSpace(server?.ActivityName) ? activityKey : server.ActivityName,
            StartedAt = startedAt,
            LimitSeconds = limitSeconds
        };
    }

    private async Task ReloadDashboardAsync()
    {
        if (_loading)
        {
            _reloadPending = true;
            return;
        }

        if (_actions.LoadDashboardAsync == null)
        {
            if (_dashboard != null)
                RenderRecords();
            else
                RefreshHeader();
            UpdateButtons();
            return;
        }

        _loading = true;
        var previous = _dashboard ?? _actions.GetCachedDashboard?.Invoke();
        try
        {
            var loaded = await _actions.LoadDashboardAsync().ConfigureAwait(true);
            if (loaded != null)
            {
                loaded.OpenActivity = MergeOpenActivityStart(previous?.OpenActivity, loaded.OpenActivity);
                _dashboard = loaded;
            }
            else if (previous != null)
                _dashboard = previous;

            ApplyDashboardToUi();
        }
        catch (Exception ex)
        {
            _actions.Logger?.LogDebug(ex, "Failed to load TG punch dashboard");
            if (previous != null)
                _dashboard = previous;
            ApplyDashboardToUi();
        }
        finally
        {
            _loading = false;
            if (_reloadPending)
            {
                _reloadPending = false;
                _ = ReloadDashboardAsync();
            }
        }
    }

    private void ApplyDashboardToUi()
    {
        RebuildActivityButtons();
        RefreshHeader();
        UpdateButtons();
        RenderRecords();
    }

    private void RebuildActivityButtons()
    {
        var types = _dashboard?.ActivityTypes;
        if (types == null || types.Count == 0)
            types = GetDefaultActivityTypes();

        var signature = string.Join("|", types.Select(t =>
            $"{t.Code}:{t.Name}:{t.SortOrder}"));
        if (signature == _activityTypesSignature && _activityButtons.Count > 0)
            return;

        _activityTypesSignature = signature;
        foreach (var button in _activityButtons)
            button.Dispose();
        _activityButtons.Clear();
        _buttonActivityMap.Clear();
        _activityButtonsHost.Controls.Clear();

        const int buttonsPerRow = ActivityButtonsPerRow;
        var activityBtnWidth = ResolveActivityButtonWidth(ResolveContentWidth());
        for (var i = 0; i < types.Count; i += buttonsPerRow)
        {
            var row = CreateButtonRow();
            for (var j = i; j < Math.Min(i + buttonsPerRow, types.Count); j++)
            {
                var type = types[j];
                var activityKey = !string.IsNullOrWhiteSpace(type.Name) ? type.Name.Trim() : type.Code.Trim();
                if (string.IsNullOrWhiteSpace(activityKey))
                    continue;

                var button = CreateActionButton(FormatActivityButtonText(type), PunchButtonStyle.Neutral, activityBtnWidth);
                var capturedType = type;
                var capturedKey = activityKey;
                button.Click += async (_, _) =>
                {
                    var freshType = GetFreshActivityType(capturedType);
                    if (IsActivityAtLimit(freshType))
                    {
                        WarnActivityLimit(freshType);
                        return;
                    }

                    await RunActivityAsync(capturedKey);
                };
                row.Controls.Add(button);
                _activityButtons.Add(button);
                _buttonActivityMap[button] = type;
            }

            if (row.Controls.Count > 0)
                _activityButtonsHost.Controls.Add(row);
        }

        _activityButtonsHost.Height = ActivityAreaHeight;
        _activityButtonsHost.MinimumSize = new Size(0, ActivityAreaHeight);
        RelayoutContentToWidth(force: true);
    }

    private string FormatActivityButtonText(TgActivityTypeItem type)
    {
        var label = PunchDisplayLocalizer.LocalizeActivityType(type, _actions.Localization);
        var icon = GetDefaultActivityIcon(type.Code);
        if (!string.IsNullOrEmpty(icon))
            label = $"{icon} {label}";
        if (type.MaxTimesPerDay > 0)
            return $"{label} {type.TodayCount}/{type.MaxTimesPerDay}";
        return label;
    }

    private static string? GetDefaultActivityIcon(string? code) => (code ?? string.Empty).Trim() switch
    {
        "wc_small" => "🚽",
        "wc_large" => "🚾",
        "eat" => "🍱",
        "smoke" => "🚬",
        _ => null
    };

    private string GetActivitySectionTitleText()
    {
        var baseTitle = L("TrayPunchSectionActivity", "活动");
        var open = _dashboard?.OpenActivity;
        if (open == null || string.IsNullOrWhiteSpace(open.ActivityName))
            return baseTitle;

        var name = PunchDisplayLocalizer.LocalizeActivityName(
            open.ActivityName,
            _dashboard?.ActivityTypes,
            _actions.Localization);
        return $"{baseTitle} · {name}";
    }

    private void UpdateActivitySectionTitle()
    {
        _activitySectionTitle.Text = GetActivitySectionTitleText();

        var open = _dashboard?.OpenActivity;
        var timer = open != null ? GetOpenActivityTimerDisplay(open, _actions.Localization) : null;
        if (timer == null || string.IsNullOrWhiteSpace(timer.Text))
        {
            _activityCountdownLabel.Visible = false;
            _activityCountdownLabel.Text = string.Empty;
            return;
        }

        _activityCountdownLabel.Text = " " + timer.Text;
        _activityCountdownLabel.Visible = true;
        _activityCountdownLabel.ForeColor = timer.IsCountdown
            ? timer.RemainingSeconds <= 60
                ? _palette.TimerUrgent
                : _palette.TimerCountdown
            : _palette.TextMuted;
    }

    private sealed record ActivityTimerDisplay(string Text, int RemainingSeconds, bool IsCountdown);

    private static ActivityTimerDisplay? GetOpenActivityTimerDisplay(
        TgOpenActivity open,
        ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(open.StartedAt))
            return null;

        if (!DateTime.TryParse(
                open.StartedAt,
                null,
                System.Globalization.DateTimeStyles.RoundtripKind,
                out var started))
            return null;

        // Server clock ahead of this PC → treat as "just started" so remaining isn't frozen at full.
        var startedUtc = started.ToUniversalTime();
        var nowUtc = DateTime.UtcNow;
        if (startedUtc > nowUtc)
            startedUtc = nowUtc;

        var elapsed = (int)Math.Max(0, (nowUtc - startedUtc).TotalSeconds);
        if (open.LimitSeconds > 0)
        {
            var remaining = Math.Max(0, open.LimitSeconds - elapsed);
            return new ActivityTimerDisplay(
                DurationFormatter.FormatDuration(remaining, localization),
                remaining,
                true);
        }

        return new ActivityTimerDisplay(
            DurationFormatter.FormatDuration(elapsed, localization),
            -1,
            false);
    }

    private void RefreshActivityCountdown()
    {
        UpdateActivitySectionTitle();
        if (_dashboard?.OpenActivity == null)
            SyncActivityCountdownTimer();
    }

    private void SyncActivityCountdownTimer()
    {
        UpdateActivitySectionTitle();

        var shouldRun = Visible
            && !IsDisposed
            && _displayMode == PanelDisplayMode.Expanded
            && _dashboard?.OpenActivity != null
            && !string.IsNullOrWhiteSpace(_dashboard.OpenActivity.StartedAt);

        if (!shouldRun)
        {
            _activityCountdownTimer.Stop();
            return;
        }

        if (!_activityCountdownTimer.Enabled)
        {
            _activityCountdownTimer.Start();
            RefreshActivityCountdown();
            return;
        }

        RefreshActivityCountdown();
    }

    private static bool IsActivityAtLimit(TgActivityTypeItem type)
        => type.MaxTimesPerDay > 0 && type.TodayCount >= type.MaxTimesPerDay;

    private void WarnActivityLimit(TgActivityTypeItem type)
    {
        var name = string.IsNullOrWhiteSpace(type.Name) ? type.Code : type.Name.Trim();
        var message = string.Format(
            L("ActivityLimitReachedDetail", "今日「{0}」次数已达上限（{1}/{2}）"),
            name,
            type.TodayCount,
            type.MaxTimesPerDay);
        NotifyWarning(message);
    }

    private List<TgActivityTypeItem> GetDefaultActivityTypes() =>
    [
        new() { Code = "wc_small", Name = L("ActivityWcSmall", "小厕"), SortOrder = 1 },
        new() { Code = "wc_large", Name = L("ActivityWcLarge", "大厕"), SortOrder = 2 },
        new() { Code = "eat", Name = L("ActivityEat", "吃饭"), SortOrder = 3 },
        new() { Code = "smoke", Name = L("ActivitySmoke", "抽烟或休息"), SortOrder = 4 },
    ];

    private void RememberLocalRecord(TgPunchRecord record)
    {
        _actions.RememberLocalRecord?.Invoke(record);
        _dashboard ??= new TgPunchDashboard { LoggedIn = true, Records = new List<TgPunchRecord>() };
        _dashboard.Records ??= new List<TgPunchRecord>();
        _dashboard.Records.Insert(0, record);
        while (_dashboard.Records.Count > 30)
            _dashboard.Records.RemoveAt(_dashboard.Records.Count - 1);
        RenderRecords();
    }

    private static string NowTimeLabel() => DurationFormatter.FormatTimeOfDay(DateTime.Now);

    private void RefreshHeader()
    {
        var connected = _actions.GetIsConnected?.Invoke() ?? false;
        var employee = _actions.GetEmployeeStatus?.Invoke();
        var loggedIn = _dashboard?.LoggedIn ?? employee?.IsLoggedIn ?? false;

        if (loggedIn && employee != null)
        {
            var empNo = !string.IsNullOrWhiteSpace(employee.EmployeeNumber)
                ? $"{L("EmployeeNumber", "工号")} {employee.EmployeeNumber.Trim()}"
                : string.Empty;
            var position = employee.Position?.Trim() ?? string.Empty;

            _empNoLabel.Text = empNo;
            _empNoLabel.Visible = !string.IsNullOrWhiteSpace(empNo);
            _positionLabel.Text = position;
            _positionLabel.Visible = !string.IsNullOrWhiteSpace(position);
            _metaDot1.Visible = _empNoLabel.Visible && _positionLabel.Visible;

            var avatarKey = !string.IsNullOrWhiteSpace(employee.Username)
                ? employee.Username.Trim()
                : employee.Name?.Trim();
            _employeeAvatarKey = avatarKey;
            _employeeAvatarHost.Visible = !string.IsNullOrWhiteSpace(avatarKey);
            _employeeAvatarHost.Invalidate();
        }
        else
        {
            _empNoLabel.Text = L("TrayPunchNotLoggedInHint", "未登录");
            _empNoLabel.Visible = true;
            _positionLabel.Visible = false;
            _metaDot1.Visible = false;
            _employeeAvatarKey = null;
            _employeeAvatarHost.Visible = false;
        }

        SetPillChip(_statusChip,
            connected ? L("Connected", "已连接") : L("Disconnected", "未连接"),
            connected ? _palette.ChipConnected : _palette.ChipDisconnected);

        var workOpen = _dashboard?.WorkSessionOpen ?? false;
        SetPillChip(_workChip,
            workOpen ? L("WorkStatusOnShift", "上班中") : L("WorkStatusOffShift", "未上班"),
            workOpen ? _palette.ChipWork : _palette.ChipIdle);

        if (_dashboard?.OpenActivity != null && !string.IsNullOrWhiteSpace(_dashboard.OpenActivity.ActivityName))
        {
            _openActivityChip.Visible = true;
            _openActivityChip.Text =
                $"{PunchDisplayLocalizer.LocalizeActivityName(_dashboard.OpenActivity.ActivityName, _dashboard.ActivityTypes, _actions.Localization)} · {L("TrayPunchInProgress", "进行中")}";
        }
        else
        {
            _openActivityChip.Visible = false;
            _openActivityChip.Text = string.Empty;
        }

        if (_displayMode == PanelDisplayMode.DockCollapsed)
            _dockTabPanel.Invalidate();
    }

    private void CollapseToDockStrip()
    {
        if (_displayMode != PanelDisplayMode.Expanded)
            return;

        _dragging = false;
        _headerPanel.Capture = false;

        var bounds = Bounds;
        var workArea = Screen.FromRectangle(bounds).WorkingArea;
        RememberExpandedBounds(bounds);
        DockToEdge(ResolveDockEdgeByPanelPosition(bounds, workArea), bounds, workArea);
    }

    private void WireHeaderDrag(Control control)
    {
        control.MouseDown += Header_MouseDown;
        control.MouseMove += Header_MouseMove;
        control.MouseUp += Header_MouseUp;
    }

    private static bool IsHeaderChromeClick(Button closeButton, Button themeButton, Button languageButton, Button accountButton, Point screenPoint)
    {
        if (accountButton.Visible && accountButton.RectangleToScreen(accountButton.ClientRectangle).Contains(screenPoint))
            return true;

        if (!closeButton.Visible || !themeButton.Visible || !languageButton.Visible)
            return false;

        return closeButton.RectangleToScreen(closeButton.ClientRectangle).Contains(screenPoint)
            || themeButton.RectangleToScreen(themeButton.ClientRectangle).Contains(screenPoint)
            || languageButton.RectangleToScreen(languageButton.ClientRectangle).Contains(screenPoint);
    }

    private void Header_MouseDown(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left || _displayMode != PanelDisplayMode.Expanded)
            return;

        if (IsHeaderChromeClick(_closeButton, _themeButton, _languageButton, _accountButton, Control.MousePosition))
            return;

        _dragging = true;
        _dragMouseScreen = Control.MousePosition;
        _dragFormOrigin = Location;
        _headerPanel.Capture = true;
    }

    private void Header_MouseMove(object? sender, MouseEventArgs e)
    {
        if (!_dragging)
            return;

        var screen = Control.MousePosition;
        Location = new Point(
            _dragFormOrigin.X + (screen.X - _dragMouseScreen.X),
            _dragFormOrigin.Y + (screen.Y - _dragMouseScreen.Y));
    }

    private void Header_MouseUp(object? sender, MouseEventArgs e)
    {
        if (!_dragging || e.Button != MouseButtons.Left)
            return;

        _dragging = false;
        _headerPanel.Capture = false;

        if (_displayMode != PanelDisplayMode.Expanded)
            return;

        var bounds = Bounds;
        var workArea = Screen.FromRectangle(bounds).WorkingArea;
        if (TryDetectDockEdge(bounds, workArea, out var edge))
        {
            RememberExpandedBounds(bounds);
            DockToEdge(edge, bounds, workArea);
            return;
        }

        var clamped = ClampToWorkArea(
            new Rectangle(bounds.Location, FitExpandedSize(workArea)),
            workArea);
        RememberExpandedBounds(clamped);
        SetBounds(clamped.X, clamped.Y, clamped.Width, clamped.Height);
        RelayoutContentToWidth(force: true);
        ApplyRoundedRegion();
    }

    private void DockToEdge(DockEdge edge, Rectangle expandedBounds, Rectangle workArea)
    {
        _dockEdge = edge;
        _displayMode = PanelDisplayMode.DockCollapsed;
        SetExpandedChromeVisible(false);
        _dockTabPanel.Visible = true;
        _dockTabPanel.BringToFront();
        Region = null;

        switch (edge)
        {
            case DockEdge.Left:
                _dockAnchorCoord = Math.Clamp(
                    expandedBounds.Top + (expandedBounds.Height - DockLength) / 2,
                    workArea.Top,
                    Math.Max(workArea.Top, workArea.Bottom - DockLength));
                SetBounds(workArea.Left, _dockAnchorCoord, DockThickness, DockLength);
                break;
            case DockEdge.Right:
                _dockAnchorCoord = Math.Clamp(
                    expandedBounds.Top + (expandedBounds.Height - DockLength) / 2,
                    workArea.Top,
                    Math.Max(workArea.Top, workArea.Bottom - DockLength));
                SetBounds(workArea.Right - DockThickness, _dockAnchorCoord, DockThickness, DockLength);
                break;
            default:
                _dockAnchorCoord = Math.Clamp(
                    expandedBounds.Left + (expandedBounds.Width - DockLength) / 2,
                    workArea.Left,
                    Math.Max(workArea.Left, workArea.Right - DockLength));
                SetBounds(_dockAnchorCoord, workArea.Bottom - DockThickness, DockLength, DockThickness);
                break;
        }

        _dockTabPanel.Invalidate();
    }

    private void ExpandFromDock(bool silent = false)
    {
        if (_displayMode != PanelDisplayMode.DockCollapsed)
            return;

        _displayMode = PanelDisplayMode.Expanded;
        _dockTabPanel.Visible = false;
        SetExpandedChromeVisible(true);

        ApplyExpandedBounds(GetExpandedBoundsOrDefault());
        ApplyRoundedRegion();
        ApplyDashboardToUi();

        if (!silent)
        {
            BringToFront();
            Activate();
        }
    }

    private void ApplyExpandedBounds(Rectangle bounds)
    {
        var workArea = Screen.FromRectangle(bounds).WorkingArea;
        var size = FitExpandedSize(workArea);
        var fitted = ClampToWorkArea(new Rectangle(bounds.Location, size), workArea);
        SetBounds(fitted.X, fitted.Y, fitted.Width, fitted.Height);
        RememberExpandedBounds(fitted);
        RelayoutContentToWidth(force: true);
        ApplyRoundedRegion();
    }

    private Rectangle GetExpandedBoundsOrDefault()
    {
        if (s_lastExpandedBounds is { Width: >= MinExpandedWidth / 2, Height: >= MinExpandedHeight / 2 } saved)
        {
            var workArea = Screen.FromPoint(saved.Location).WorkingArea;
            var size = FitExpandedSize(workArea);
            return ClampToWorkArea(new Rectangle(saved.Location, size), workArea);
        }

        return GetDefaultExpandedBounds();
    }

    private Rectangle GetDefaultExpandedBounds()
    {
        var screen = Screen.PrimaryScreen;
        if (screen == null)
            return new Rectangle(100, 100, ExpandedWidth, ExpandedHeight);

        var area = screen.WorkingArea;
        var size = FitExpandedSize(area);
        return new Rectangle(
            area.Right - size.Width - ScreenEdgeMargin,
            area.Bottom - size.Height - ScreenEdgeMargin,
            size.Width,
            size.Height);
    }

    private static void RememberExpandedBounds(Rectangle bounds)
    {
        if (bounds.Width < MinExpandedWidth / 2 || bounds.Height < MinExpandedHeight / 2)
            return;

        // Persist location; size is always re-fitted to the current work area on restore.
        s_lastExpandedBounds = new Rectangle(bounds.Location, new Size(ExpandedWidth, ExpandedHeight));
    }

    /// <summary>
    /// Prefer the design 480×694 panel; only shrink when the work area cannot fit it.
    /// </summary>
    private static Size FitExpandedSize(Rectangle workArea)
    {
        var maxW = Math.Max(0, workArea.Width - ScreenEdgeMargin * 2);
        var maxH = Math.Max(0, workArea.Height - ScreenEdgeMargin * 2);

        var w = ExpandedWidth;
        var h = ExpandedHeight;

        if (maxW > 0 && w > maxW)
            w = Math.Max(MinExpandedWidth, maxW);
        if (maxH > 0 && h > maxH)
            h = Math.Max(MinExpandedHeight, maxH);

        // Never exceed the physical work area (even if below the preferred minimum).
        if (workArea.Width > 0)
            w = Math.Min(w, workArea.Width);
        if (workArea.Height > 0)
            h = Math.Min(h, workArea.Height);

        return new Size(Math.Max(1, w), Math.Max(1, h));
    }

    private static Rectangle ClampToWorkArea(Rectangle bounds, Rectangle workArea)
    {
        var x = Math.Clamp(bounds.X, workArea.Left, Math.Max(workArea.Left, workArea.Right - bounds.Width));
        var y = Math.Clamp(bounds.Y, workArea.Top, Math.Max(workArea.Top, workArea.Bottom - bounds.Height));
        return new Rectangle(x, y, bounds.Width, bounds.Height);
    }

    private static bool TryDetectDockEdge(Rectangle bounds, Rectangle workArea, out DockEdge edge)
    {
        var leftDist = Math.Abs(bounds.Left - workArea.Left);
        var rightDist = Math.Abs(workArea.Right - bounds.Right);
        var bottomDist = Math.Abs(workArea.Bottom - bounds.Bottom);

        var candidates = new List<(DockEdge Edge, int Distance)>();
        if (leftDist <= EdgeSnapPx)
            candidates.Add((DockEdge.Left, leftDist));
        if (rightDist <= EdgeSnapPx)
            candidates.Add((DockEdge.Right, rightDist));
        if (bottomDist <= EdgeSnapPx)
            candidates.Add((DockEdge.Bottom, bottomDist));

        if (candidates.Count == 0)
        {
            edge = DockEdge.Right;
            return false;
        }

        candidates.Sort((a, b) =>
        {
            var byDistance = a.Distance.CompareTo(b.Distance);
            if (byDistance != 0)
                return byDistance;

            var aVertical = a.Edge is DockEdge.Left or DockEdge.Right;
            var bVertical = b.Edge is DockEdge.Left or DockEdge.Right;
            if (aVertical && !bVertical)
                return -1;
            if (bVertical && !aVertical)
                return 1;
            return 0;
        });

        edge = candidates[0].Edge;
        return true;
    }

    /// <summary>
    /// Decide dock side from where the panel sits on screen (used by close-to-strip).
    /// </summary>
    private static DockEdge ResolveDockEdgeByPanelPosition(Rectangle bounds, Rectangle workArea)
    {
        var centerX = bounds.Left + bounds.Width / 2.0;
        var centerY = bounds.Top + bounds.Height / 2.0;
        var width = Math.Max(1, workArea.Width);
        var height = Math.Max(1, workArea.Height);

        var relX = (centerX - workArea.Left) / width;
        var relY = (centerY - workArea.Top) / height;

        if (relX <= SideDockZoneRatio)
            return DockEdge.Left;
        if (relX >= 1 - SideDockZoneRatio)
            return DockEdge.Right;
        if (relY >= 1 - SideDockZoneRatio)
            return DockEdge.Bottom;

        var toLeft = centerX - workArea.Left;
        var toRight = workArea.Right - centerX;
        var toBottom = workArea.Bottom - centerY;

        if (toLeft <= toRight && toLeft <= toBottom)
            return DockEdge.Left;
        if (toRight <= toLeft && toRight <= toBottom)
            return DockEdge.Right;
        return DockEdge.Bottom;
    }

    private void SetExpandedChromeVisible(bool visible)
    {
        _headerPanel.Visible = visible;
        _bodyPanel.Visible = visible;
        _accentPanel.Visible = visible;
        if (visible)
        {
            _dockTabPanel.SendToBack();
            _accentPanel.BringToFront();
            _headerPanel.BringToFront();
            _bodyPanel.BringToFront();
        }
    }

    private void PaintDockTab(object? sender, PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
        var bounds = _dockTabPanel.ClientRectangle;
        var hasActivity = _dashboard?.OpenActivity != null;
        var fill = hasActivity ? Color.FromArgb(245, 124, 0) : _palette.Accent;

        using (var brush = new SolidBrush(fill))
            g.FillRectangle(brush, bounds);

        using var textBrush = new SolidBrush(Color.White);
        using var font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold);
        var label = L("TrayPunchTitle", "打卡");

        if (_dockEdge == DockEdge.Bottom)
        {
            var size = g.MeasureString(label, font);
            g.DrawString(label, font, textBrush,
                (bounds.Width - size.Width) / 2f,
                (bounds.Height - size.Height) / 2f);
        }
        else
        {
            var chars = label.ToCharArray();
            var sizes = new SizeF[chars.Length];
            var lineGap = 1f;
            var totalH = 0f;
            for (var i = 0; i < chars.Length; i++)
            {
                sizes[i] = g.MeasureString(chars[i].ToString(), font);
                totalH += sizes[i].Height;
                if (i < chars.Length - 1)
                    totalH -= lineGap;
            }

            var y = Math.Max(4f, (bounds.Height - totalH) / 2f);
            for (var i = 0; i < chars.Length; i++)
            {
                var x = (bounds.Width - sizes[i].Width) / 2f;
                g.DrawString(chars[i].ToString(), font, textBrush, x, y);
                y += sizes[i].Height - lineGap;
            }
        }

        if (hasActivity)
        {
            using var dot = new SolidBrush(Color.FromArgb(255, 235, 120));
            var dotRect = _dockEdge == DockEdge.Bottom
                ? new Rectangle(bounds.Right - 12, 4, 7, 7)
                : new Rectangle(bounds.Right - 11, 5, 7, 7);
            g.FillEllipse(dot, dotRect);
        }
    }

    private void UpdateButtons()
    {
        var loggedIn = _dashboard?.LoggedIn ?? _actions.GetEmployeeStatus?.Invoke().IsLoggedIn ?? false;
        var workOpen = _dashboard?.WorkSessionOpen ?? false;
        var hasActivity = _dashboard?.OpenActivity != null;
        var dual = _dashboard?.DualShiftEnabled ?? true;
        // Prefer either live session config or dashboard config. An older cached
        // dashboard may not contain tripleShiftEnabled and must not hide Middle.
        var triple = _dashboard?.TripleShiftEnabled == true
            || _actions.GetTripleShiftEnabled?.Invoke() == true;
        dual = dual || triple;

        _checkInDayButton.Enabled = loggedIn && !workOpen;
        _checkInMiddleButton.Visible = triple;
        _checkInMiddleButton.Enabled = triple && loggedIn && !workOpen;
        _checkInNightButton.Enabled = loggedIn && !workOpen && dual;
        _checkOutButton.Enabled = loggedIn && workOpen;
        LayoutShiftButtons(triple);

        var canStartActivity = loggedIn && workOpen && !hasActivity;
        foreach (var button in _activityButtons)
        {
            if (_buttonActivityMap.TryGetValue(button, out var mapped))
            {
                var type = GetFreshActivityType(mapped);
                var atLimit = IsActivityAtLimit(type);
                button.Text = FormatActivityButtonText(type);
                button.ApplyStyle(atLimit ? PunchButtonStyle.Exhausted : PunchButtonStyle.Neutral);
                button.Enabled = canStartActivity;
            }
            else
            {
                button.Enabled = canStartActivity;
            }
        }
        _backButton.Enabled = loggedIn && hasActivity;

        var showLogin = !loggedIn && _actions.OnEmployeeLogin != null;
        _loginButton.Visible = showLogin;
        RefreshAccountButtonText();

        SyncActivityCountdownTimer();
    }

    private void LayoutShiftButtons(bool triple)
    {
        var count = triple ? 4 : 3;
        const int gap = 8;
        var width = Math.Max(MinActionButtonWidth, (ResolveContentWidth() - count * gap) / count);
        _checkInDayButton.Width = width;
        _checkInMiddleButton.Width = width;
        _checkInNightButton.Width = width;
        _checkOutButton.Width = width;
    }

    private int ResolveContentWidth()
    {
        if (_bodyPanel.IsHandleCreated)
        {
            var available = _bodyPanel.ClientSize.Width - _bodyPanel.Padding.Horizontal;
            if (available > 0)
            {
                // Prefer the design content width when it fits; shrink only when the client is tighter.
                if (available >= ContentWidth)
                    return ContentWidth;

                return Math.Max(MinContentWidth, available - 4);
            }
        }

        return ContentWidth;
    }

    private static int ResolveActivityButtonWidth(int contentWidth)
    {
        const int gap = 8;
        if (contentWidth >= ContentWidth)
            return ActivityButtonWidth;

        return Math.Max(MinActionButtonWidth, (contentWidth - ActivityButtonsPerRow * gap) / ActivityButtonsPerRow);
    }

    /// <summary>
    /// Recompute section/button widths for the current client size without changing chrome/styles.
    /// </summary>
    private void RelayoutContentToWidth(bool force = false)
    {
        if (!_uiReady || _relayouting || _displayMode != PanelDisplayMode.Expanded)
            return;

        var contentWidth = ResolveContentWidth();
        if (!force && contentWidth == _lastLaidOutContentWidth)
        {
            UpdateRecordsAreaForHeight();
            return;
        }

        _relayouting = true;
        try
        {
            _lastLaidOutContentWidth = contentWidth;
            var activityBtnWidth = ResolveActivityButtonWidth(contentWidth);

            ApplyFixedSectionWidth(_shiftSectionTitle.Parent as Panel, _shiftSectionTitle, contentWidth);
            if (_activitySectionPanel != null)
                _activitySectionPanel.Width = contentWidth;
            ApplyFixedSectionWidth(_recordsTitle.Parent as Panel, _recordsTitle, contentWidth);

            _shiftButtonRow.Width = contentWidth;
            _shiftButtonRow.MinimumSize = new Size(0, _shiftButtonRow.Height);

            // Dock.Top login stretches automatically; keep explicit width for consistency.
            _loginButton.Width = contentWidth;
            _backButton.Width = contentWidth;

            _activityButtonsHost.Width = contentWidth;
            _activityButtonsHost.MinimumSize = new Size(0, ActivityAreaHeight);
            foreach (Control rowCtrl in _activityButtonsHost.Controls)
            {
                if (rowCtrl is not FlowLayoutPanel row)
                    continue;

                row.Width = contentWidth;
                row.MinimumSize = new Size(0, row.Height);
                foreach (Control child in row.Controls)
                {
                    if (child is PunchStyledButton btn)
                        btn.Width = activityBtnWidth;
                }
            }

            LayoutShiftButtons(_checkInMiddleButton.Visible);
            UpdateRecordsAreaForHeight();
        }
        finally
        {
            _relayouting = false;
        }
    }

    private static void ApplyFixedSectionWidth(Panel? panel, Label title, int contentWidth)
    {
        if (panel == null)
            return;

        panel.Width = contentWidth;
        if (!title.AutoSize)
            title.Size = new Size(Math.Max(40, contentWidth - 14), title.Height);
    }

    private void UpdateRecordsAreaForHeight()
    {
        if (_contentLayout.RowCount < 7)
            return;

        int recordsHeight;
        if (Height >= ExpandedHeight - 2)
        {
            recordsHeight = RecordsAreaHeight;
            _bodyPanel.AutoScroll = false;
            _bodyPanel.AutoScrollMinSize = Size.Empty;
        }
        else
        {
            var deficit = ExpandedHeight - Height;
            recordsHeight = Math.Max(96, RecordsAreaHeight - deficit);
            // Only scroll when even a compressed records area cannot fit — keeps normal screens unchanged.
            _bodyPanel.AutoScroll = Height < MinExpandedHeight;
            if (!_bodyPanel.AutoScroll)
                _bodyPanel.AutoScrollMinSize = Size.Empty;
        }

        _contentLayout.RowStyles[6] = new RowStyle(SizeType.Absolute, recordsHeight);
    }

    private void RefreshAccountButtonText()
    {
        var loggedIn = _dashboard?.LoggedIn ?? _actions.GetEmployeeStatus?.Invoke().IsLoggedIn ?? false;
        if (loggedIn)
        {
            _accountButton.Text = L("SwitchAccount", "切换账号");
            _accountButton.Visible = _actions.OnEmployeeSwitchAccount != null || _actions.OnEmployeeLogin != null;
        }
        else
        {
            _accountButton.Text = L("Login", "登录");
            _accountButton.Visible = _actions.OnEmployeeLogin != null;
        }

        // Keep compact height after AutoSize text change.
        _accountButton.Height = 26;
        _accountButton.Invalidate();
    }

    private async Task RunAccountActionAsync()
    {
        var loggedIn = _dashboard?.LoggedIn ?? _actions.GetEmployeeStatus?.Invoke().IsLoggedIn ?? false;
        if (loggedIn)
        {
            if (_actions.OnEmployeeSwitchAccount != null)
            {
                try
                {
                    await _actions.OnEmployeeSwitchAccount().ConfigureAwait(true);
                    _actions.OnStateChanged?.Invoke();
                    await ReloadDashboardAsync().ConfigureAwait(true);
                    RefreshHeader();
                    UpdateButtons();
                }
                catch (Exception ex)
                {
                    _actions.Logger?.LogError(ex, "Switch account from punch panel failed");
                    NotifyWarning(L("ActionFailed", "操作失败，请查看日志"));
                }
                return;
            }
        }

        await RunLoginAsync();
    }

    private async Task RunLoginAsync()
    {
        if (_actions.OnEmployeeLogin == null)
            return;

        try
        {
            var ok = await _actions.OnEmployeeLogin().ConfigureAwait(true);
            if (!ok)
                return;

            _actions.OnStateChanged?.Invoke();
            await ReloadDashboardAsync().ConfigureAwait(true);
            RefreshHeader();
            UpdateButtons();
            RenderRecords();
        }
        catch (Exception ex)
        {
            _actions.Logger?.LogError(ex, "Employee login from punch panel failed");
            NotifyWarning(L("ActionFailed", "操作失败，请查看日志"));
        }
    }

    private void RenderRecords()
    {
        var rows = new List<PunchRecordDisplayRow>();
        if (_dashboard?.Records is { Count: > 0 } records)
        {
            foreach (var rec in records)
            {
                var detail = PunchDisplayLocalizer.LocalizeRecordDetail(rec.Detail, _actions.Localization);
                if (rec.FineAmount > 0)
                    detail += $" · ¥{rec.FineAmount:0.##}";
                var inProgress = L("TrayPunchInProgress", "进行中");
                if (rec.Status == "open"
                    && (string.IsNullOrWhiteSpace(detail)
                        || !detail.Contains(inProgress, StringComparison.Ordinal)))
                {
                    detail = string.IsNullOrWhiteSpace(detail) ? inProgress : detail;
                }

                rows.Add(new PunchRecordDisplayRow
                {
                    Time = rec.Time,
                    Event = PunchDisplayLocalizer.LocalizeRecordEvent(rec.Event, _dashboard?.ActivityTypes, _actions.Localization),
                    Detail = detail,
                    Source = PunchDisplayLocalizer.LocalizeRecordSource(rec.Source, _actions.Localization),
                    IsOpen = rec.Status == "open"
                });
            }
        }
        else
        {
            rows.Add(new PunchRecordDisplayRow
            {
                Time = "--",
                Event = L("TrayPunchNoRecords", "暂无记录"),
                Detail = string.Empty,
                Source = string.Empty
            });
        }

        _recordsHost.SetRows(rows);
        _recordsHost.RefreshScrollChrome();

        _recordsTitle.Text = _dashboard?.TodayFineTotal > 0
            ? $"{L("TrayPunchRecords", "今日打卡记录")}  ·  {L("TrayPunchFineTotal", "罚款")} ¥{_dashboard.TodayFineTotal:0.##}"
            : L("TrayPunchRecords", "今日打卡记录");
    }

    private async Task RunShiftAsync(string shift)
    {
        if (_actions.OnCheckInShift == null) return;
        try
        {
            var ok = await _actions.OnCheckInShift(shift).ConfigureAwait(true);
            if (ok)
            {
                var label = shift switch
                {
                    "middle" => L("CheckInMiddle", "中班上班"),
                    "night" => L("CheckInNight", "夜班上班"),
                    _ => L("CheckInDay", "白班上班")
                };
                RememberLocalRecord(new TgPunchRecord
                {
                    Time = NowTimeLabel(),
                    Event = label,
                    Detail = L("TrayPunchInProgress", "进行中"),
                    Status = "open",
                    Source = "PC"
                });
                _dashboard ??= new TgPunchDashboard();
                _dashboard.WorkSessionOpen = true;
                NotifySuccess(L("CheckInSuccess", "上班成功"), L("CheckInSuccess", "上班成功"), LocalNotifyKind.Attendance);
                _actions.OnStateChanged?.Invoke();
                await ReloadDashboardAsync();
            }
        }
        catch (Exception ex)
        {
            _actions.Logger?.LogError(ex, "Check-in from punch panel failed");
            NotifyWarning(L("ActionFailed", "操作失败，请查看日志"));
        }
    }

    private async Task RunCheckoutAsync()
    {
        if (_actions.OnCheckOut == null) return;
        try
        {
            var ok = await _actions.OnCheckOut().ConfigureAwait(true);
            if (ok)
            {
                RememberLocalRecord(new TgPunchRecord
                {
                    Time = NowTimeLabel(),
                    Event = L("CheckOut", "下班"),
                    Detail = L("TrayPunchCheckOutDetail", "下班打卡"),
                    Status = "checkout",
                    Source = "PC"
                });
                if (_dashboard != null)
                {
                    _dashboard.WorkSessionOpen = false;
                    _dashboard.OpenActivity = null;
                }
                NotifySuccess(L("CheckOutSuccess", "下班成功"), L("CheckOutSuccess", "下班成功"), LocalNotifyKind.Attendance);
                _actions.OnStateChanged?.Invoke();
                await ReloadDashboardAsync();
            }
        }
        catch (Exception ex)
        {
            _actions.Logger?.LogError(ex, "Check-out from punch panel failed");
            NotifyWarning(L("ActionFailed", "操作失败，请查看日志"));
        }
    }

    private async Task RunActivityAsync(string activity)
    {
        if (_actions.OnStartActivityAsync == null) return;

        var type = FindActivityType(activity);
        if (type != null && IsActivityAtLimit(type))
        {
            WarnActivityLimit(type);
            return;
        }

        try
        {
            var clickedUtc = DateTime.UtcNow;
            var (success, message, openActivity) = await _actions.OnStartActivityAsync(activity).ConfigureAwait(true);
            if (success)
            {
                var mergedActivity = BuildOpenActivityForStart(activity, openActivity, clickedUtc, type);
                RememberLocalRecord(new TgPunchRecord
                {
                    Time = NowTimeLabel(),
                    Event = activity,
                    Detail = L("TrayPunchInProgress", "进行中"),
                    Status = "open",
                    Source = "PC"
                });
                if (_dashboard != null)
                    _dashboard.OpenActivity = mergedActivity;
                _actions.UpdateCachedOpenActivity?.Invoke(mergedActivity);
                NotifySuccess(L("ActivityStartSuccess", "活动已开始"), message);
                UpdateButtons();
                _actions.OnStateChanged?.Invoke();
                await ReloadDashboardAsync();
            }
            else
            {
                var limitMsg = string.IsNullOrWhiteSpace(message)
                    ? L("ActivityLimitReached", "今日该活动次数已达上限")
                    : message;
                NotifyWarning(limitMsg);
            }
        }
        catch (Exception ex)
        {
            _actions.Logger?.LogError(ex, "Start activity from punch panel failed");
            NotifyWarning(L("ActionFailed", "操作失败，请查看日志"));
        }
    }

    private TgActivityTypeItem? FindActivityType(string activityKey)
    {
        if (_dashboard?.ActivityTypes is not { Count: > 0 } types)
            return null;

        var key = activityKey.Trim();
        return types.FirstOrDefault(t =>
            string.Equals(t.Name, key, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(t.Code, key, StringComparison.OrdinalIgnoreCase));
    }

    private TgActivityTypeItem GetFreshActivityType(TgActivityTypeItem mapped)
    {
        if (_dashboard?.ActivityTypes is not { Count: > 0 } types || string.IsNullOrWhiteSpace(mapped.Code))
            return mapped;

        return types.FirstOrDefault(t => string.Equals(t.Code, mapped.Code, StringComparison.OrdinalIgnoreCase)) ?? mapped;
    }

    private async Task RunBackAsync()
    {
        if (_actions.OnActivityBackAsync == null) return;
        var sessionId = _dashboard?.OpenActivity?.SessionId;
        try
        {
            var (success, message) = await _actions.OnActivityBackAsync(sessionId).ConfigureAwait(true);
            if (success)
            {
                var actName = _dashboard?.OpenActivity?.ActivityName ?? L("ActivityBack", "回座");
                RememberLocalRecord(new TgPunchRecord
                {
                    Time = NowTimeLabel(),
                    Event = actName,
                    Detail = L("TrayPunchActivityEnded", "已结束"),
                    Status = "closed",
                    Source = "PC"
                });
                if (_dashboard != null)
                    _dashboard.OpenActivity = null;
                NotifySuccess(L("ActivityBackSuccess", "回座成功"), message);
                UpdateButtons();
                _actions.OnStateChanged?.Invoke();
                await ReloadDashboardAsync();
            }
            else
            {
                NotifyWarning(message);
            }
        }
        catch (Exception ex)
        {
            _actions.Logger?.LogError(ex, "Activity back from punch panel failed");
            NotifyWarning(L("ActionFailed", "操作失败，请查看日志"));
        }
    }

    private void NotifySuccess(string title, string message, LocalNotifyKind kind = LocalNotifyKind.Always)
        => _actions.Notifications?.ShowLocal(title, message, "success", kind: kind);

    private void NotifyWarning(string message)
        => _actions.Notifications?.ShowLocal(L("Prompt", "提示"), message, "warning");

    private Panel CreateSectionPanel(string text, out Label titleLabel)
    {
        var panel = new Panel
        {
            Width = ContentWidth,
            Height = 32,
            Margin = new Padding(0, 8, 0, 4),
            BackColor = _palette.Bg
        };
        panel.Paint += (_, e) =>
        {
            using var accent = new LinearGradientBrush(new Rectangle(0, 12, 3, 16), _palette.Accent, _palette.AccentSoft, 90f);
            e.Graphics.FillRectangle(accent, 0, 12, 3, 16);
        };

        titleLabel = new Label
        {
            AutoSize = false,
            Location = new Point(12, 7),
            Size = new Size(ContentWidth - 14, 24),
            Text = text,
            ForeColor = _palette.TextMuted,
            Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold),
            BackColor = _palette.Bg
        };
        panel.Controls.Add(titleLabel);
        return panel;
    }

    private Panel CreateActivitySectionPanel(out Label titleLabel, out Label countdownLabel)
    {
        var panel = new Panel
        {
            Width = ContentWidth,
            Height = 32,
            Margin = new Padding(0, 8, 0, 4),
            BackColor = _palette.Bg
        };
        _activitySectionPanel = panel;
        panel.Paint += (_, e) =>
        {
            using var accent = new LinearGradientBrush(new Rectangle(0, 12, 3, 16), _palette.Accent, _palette.AccentSoft, 90f);
            e.Graphics.FillRectangle(accent, 0, 12, 3, 16);
        };

        var headerRow = new FlowLayoutPanel
        {
            Location = new Point(12, 7),
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = false,
            FlowDirection = FlowDirection.LeftToRight,
            BackColor = _palette.Bg,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        _activitySectionHeaderRow = headerRow;

        var sectionFont = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold);
        titleLabel = new Label
        {
            AutoSize = true,
            Text = L("TrayPunchSectionActivity", "活动"),
            ForeColor = _palette.TextMuted,
            Font = sectionFont,
            BackColor = _palette.Bg,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        countdownLabel = new Label
        {
            AutoSize = true,
            Visible = false,
            ForeColor = _palette.TimerCountdown,
            Font = sectionFont,
            BackColor = _palette.Bg,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };

        headerRow.Controls.Add(titleLabel);
        headerRow.Controls.Add(countdownLabel);
        panel.Controls.Add(headerRow);
        return panel;
    }

    private Panel CreateSectionPanel(string text)
        => CreateSectionPanel(text, out _);

    private FlowLayoutPanel CreateButtonRow(bool withBottomSpacing = true)
    {
        var rowHeight = withBottomSpacing
            ? ActivityButtonHeight + ActivityRowSpacing
            : ActivityButtonHeight;

        return new FlowLayoutPanel
        {
            AutoSize = false,
            Height = rowHeight,
            MinimumSize = new Size(0, rowHeight),
            WrapContents = false,
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Padding(0, 0, 0, withBottomSpacing ? ActivityRowSpacing : 0),
            BackColor = _palette.Bg,
            Width = ContentWidth
        };
    }

    private PunchStyledButton CreateActionButton(string text, PunchButtonStyle style = PunchButtonStyle.Neutral, int width = ActivityButtonWidth)
        => new(this, text, style, width);

    private void LayoutHeaderActionButtons()
    {
        if (_headerActionsRow.ClientSize.Width <= 0)
            return;

        const int gap = 6;
        var size = HeaderIconButtonSize;
        var y = Math.Max(0, (HeaderTitleRowHeight - size) / 2);
        var x = _headerActionsRow.ClientSize.Width - size;
        _closeButton.SetBounds(x, y, size, size);
        x -= size + gap;
        _themeButton.SetBounds(x, y, size, size);
        x -= size + gap;
        _languageButton.SetBounds(x, y, size, size);
    }

    private Button CreateHeaderIconButton(string text) => new()
    {
        Size = new Size(HeaderIconButtonSize, HeaderIconButtonSize),
        FlatStyle = FlatStyle.Flat,
        Text = text,
        TextAlign = ContentAlignment.MiddleCenter,
        Font = new Font("Segoe UI", 12F),
        ForeColor = _palette.TextMuted,
        BackColor = Color.Transparent,
        Cursor = Cursors.Hand,
        Margin = new Padding(0),
        Padding = new Padding(0, 0, 0, 1),
        UseCompatibleTextRendering = true
    };

    private Button CreateAccountActionButton()
    {
        var button = new RoundedAccountChipButton
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Height = 26,
            MinimumSize = new Size(52, 26),
            FlatStyle = FlatStyle.Flat,
            Text = L("Login", "登录"),
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
            ForeColor = _palette.Accent,
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand,
            Margin = new Padding(0),
            Padding = new Padding(10, 3, 10, 3),
            UseCompatibleTextRendering = true,
            GetIsLightTheme = () => _palette.IsLight,
            GetSurfaceColor = () => _palette.HeaderBg
        };
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = Color.Transparent;
        button.FlatAppearance.MouseDownBackColor = Color.Transparent;
        return button;
    }

    private void ApplyAccountButtonTheme()
    {
        _accountButton.ForeColor = _palette.IsLight
            ? Color.FromArgb(32, 120, 210)
            : _palette.Accent;
        _accountButton.BackColor = _palette.HeaderBg;
        _accountButton.FlatAppearance.BorderSize = 0;
        _accountButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
        _accountButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
        _accountButton.Invalidate();
    }

    /// <summary>Pill-shaped account chip with fully rounded blue outline (no square WinForms border).</summary>
    private sealed class RoundedAccountChipButton : Button
    {
        public Func<bool>? GetIsLightTheme { get; init; }
        public Func<Color>? GetSurfaceColor { get; init; }

        public RoundedAccountChipButton()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint
                     | ControlStyles.UserPaint
                     | ControlStyles.OptimizedDoubleBuffer
                     | ControlStyles.ResizeRedraw
                     | ControlStyles.SupportsTransparentBackColor, true);
            UpdateStyles();
            MouseEnter += (_, _) => Invalidate();
            MouseLeave += (_, _) => Invalidate();
            Resize += (_, _) => UpdateRoundedRegion();
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            UpdateRoundedRegion();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

            // Parent is often Transparent; Graphics.Clear(Transparent) paints black — use header surface.
            var surface = GetSurfaceColor?.Invoke()
                ?? (Parent?.BackColor.A == 255 ? Parent.BackColor : Color.FromArgb(246, 248, 252));
            using (var bg = new SolidBrush(surface))
                g.FillRectangle(bg, ClientRectangle);

            var rect = new Rectangle(1, 1, Width - 3, Height - 3);
            if (rect.Width <= 0 || rect.Height <= 0)
                return;

            var radius = Math.Max(10, rect.Height / 2); // stadium / pill corners
            var border = ForeColor;
            var hovered = ClientRectangle.Contains(PointToClient(Cursor.Position));
            var light = GetIsLightTheme?.Invoke() ?? true;

            using (var path = LoginUiChrome.CreateRoundedPath(rect, radius))
            {
                if (hovered)
                {
                    using var fill = new SolidBrush(Color.FromArgb(light ? 30 : 45, border));
                    g.FillPath(fill, path);
                }
                else if (light)
                {
                    using var fill = new SolidBrush(Color.FromArgb(18, border));
                    g.FillPath(fill, path);
                }

                using var pen = new Pen(Color.FromArgb(light ? 200 : 220, border), 1.35f);
                g.DrawPath(pen, path);
            }

            TextRenderer.DrawText(
                g,
                Text,
                Font,
                ClientRectangle,
                border,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }

        private void UpdateRoundedRegion()
        {
            if (Width <= 0 || Height <= 0)
                return;

            var radius = Math.Max(10, Height / 2);
            using var path = LoginUiChrome.CreateRoundedPath(new Rectangle(0, 0, Width, Height), radius);
            Region?.Dispose();
            Region = new Region(path);
        }
    }

    private static Font ResolveLanguageIconFont()
    {
        try
        {
            using var probe = new Font("Segoe UI Emoji", 11F);
            if (string.Equals(probe.Name, "Segoe UI Emoji", StringComparison.OrdinalIgnoreCase))
                return new Font("Segoe UI Emoji", 11F);
        }
        catch
        {
            // fall through
        }

        try
        {
            using var probe = new Font("Segoe UI Symbol", 11F);
            if (string.Equals(probe.Name, "Segoe UI Symbol", StringComparison.OrdinalIgnoreCase))
                return new Font("Segoe UI Symbol", 11F);
        }
        catch
        {
            // fall through
        }

        return new Font("Microsoft YaHei UI", 10F, FontStyle.Bold);
    }

    private void EnsureLanguageButtonGlyphVisible()
    {
        // Prefer globe emoji when the system can actually draw it; otherwise keep 文.
        try
        {
            var emojiFont = ResolveLanguageIconFont();
            using var g = CreateGraphics();
            var size = TextRenderer.MeasureText(g, "🌐", emojiFont);
            if (size.Width >= 14 && size.Height >= 12)
            {
                _languageButton.Font = emojiFont;
                _languageButton.Text = "🌐";
                return;
            }
        }
        catch
        {
            // ignore measure failures
        }

        _languageButton.Text = "文";
        _languageButton.Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold);
    }

    /// <summary>
    /// Theme toggle glyph: prefer Segoe MDL2 / Fluent Icons (reliable on Win10/11),
    /// then emoji font, then plain CJK fallbacks so the icon is never blank.
    /// Light theme shows moon (switch to dark); dark theme shows sun (switch to light).
    /// </summary>
    private void EnsureThemeButtonGlyphVisible()
    {
        var wantMoon = s_lightTheme;

        try
        {
            foreach (var family in new[] { "Segoe Fluent Icons", "Segoe MDL2 Assets" })
            {
                using var probe = new Font(family, 11F);
                if (!string.Equals(probe.Name, family, StringComparison.OrdinalIgnoreCase))
                    continue;

                _themeButton.Font = new Font(family, 11F);
                // QuietHours (moon) / WeatherSunny
                _themeButton.Text = wantMoon ? "\uEC46" : "\uE706";
                return;
            }
        }
        catch
        {
            // fall through
        }

        try
        {
            var emojiFont = ResolveLanguageIconFont();
            var glyph = wantMoon ? "🌙" : "☀";
            using var g = CreateGraphics();
            var size = TextRenderer.MeasureText(g, glyph, emojiFont);
            if (size.Width >= 12 && size.Height >= 12)
            {
                _themeButton.Font = emojiFont;
                _themeButton.Text = glyph;
                return;
            }
        }
        catch
        {
            // fall through
        }

        _themeButton.Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold);
        _themeButton.Text = wantMoon ? "夜" : "日";
    }

    private void ToggleTheme()
    {
        s_lightTheme = !s_lightTheme;
        _palette = s_lightTheme ? PunchPanelPalette.Light : PunchPanelPalette.Dark;
        ApplyTheme();
    }

    private void ApplyTheme()
    {
        BackColor = _palette.Bg;
        ForeColor = _palette.TextPrimary;
        _headerPanel.BackColor = _palette.HeaderBg;
        _bodyPanel.BackColor = _palette.Bg;
        _contentLayout.BackColor = _palette.Bg;
        _recordsCard.BackColor = _palette.CardBg;
        _accentPanel.BackColor = _palette.Accent;

        _themeButton.ForeColor = _palette.TextMuted;
        EnsureThemeButtonGlyphVisible();
        _languageButton.ForeColor = _palette.TextMuted;
        _languageButton.Font = ResolveLanguageIconFont();
        EnsureLanguageButtonGlyphVisible();
        _closeButton.ForeColor = _palette.TextMuted;
        _headerTitleLabel.ForeColor = _palette.MetaText;
        _employeeAvatarHost.Invalidate();
        ApplyThemeChrome();
        LayoutHeaderActionButtons();

        _empNoLabel.ForeColor = _palette.MetaText;
        _positionLabel.ForeColor = _palette.MetaText;
        _metaDot1.ForeColor = _palette.MetaDot;
        _recordsTitle.ForeColor = _palette.TextMuted;
        _recordsTitle.BackColor = _palette.Bg;
        _activitySectionTitle.ForeColor = _palette.TextMuted;
        _activitySectionTitle.BackColor = _palette.Bg;
        _activityCountdownLabel.BackColor = _palette.Bg;
        _activitySectionPanel.BackColor = _palette.Bg;
        _activitySectionHeaderRow.BackColor = _palette.Bg;

        _shiftBlock.BackColor = _palette.Bg;
        _shiftButtonRow.BackColor = _palette.Bg;

        _checkInDayButton.RefreshTheme(_palette);
        _checkInMiddleButton.RefreshTheme(_palette);
        _checkInNightButton.RefreshTheme(_palette);
        _checkOutButton.RefreshTheme(_palette);
        _loginButton.RefreshTheme(_palette);
        _backButton.RefreshTheme(_palette);
        foreach (var button in _activityButtons)
            button.RefreshTheme(_palette);

        _activityButtonsHost.BackColor = _palette.Bg;
        foreach (Control row in _activityButtonsHost.Controls)
            row.BackColor = _palette.Bg;

        foreach (Control control in _contentLayout.Controls)
        {
            control.BackColor = _palette.Bg;
            if (control is Panel sectionPanel)
                sectionPanel.Invalidate();

            foreach (Control child in control.Controls)
            {
                if (child is FlowLayoutPanel flow)
                    flow.BackColor = _palette.Bg;

                if (child is Label label && child != _empNoLabel && child != _positionLabel && child != _metaDot1)
                {
                    label.BackColor = _palette.Bg;
                    label.ForeColor = _palette.TextMuted;
                }
            }
        }

        _recordsHost.ApplyTheme(_palette.Records);
        _recordsCard.Invalidate();
        RefreshHeader();
        UpdateButtons();
        UpdateActivitySectionTitle();
        _headerPanel.Invalidate();
        Invalidate(true);
    }

    private Label CreateMetaLabel(string text) => new()
    {
        AutoSize = true,
        Text = text,
        ForeColor = _palette.MetaText,
        BackColor = Color.Transparent,
        Font = new Font("Segoe UI", 8.75F),
        Margin = new Padding(0, 4, 0, 0),
        Padding = new Padding(0)
    };

    private Label CreateMetaDot() => new()
    {
        AutoSize = true,
        Text = "·",
        ForeColor = _palette.MetaDot,
        BackColor = Color.Transparent,
        Font = new Font("Segoe UI", 8.75F),
        Margin = new Padding(4, 3, 4, 0),
        Padding = new Padding(0),
        Visible = false
    };

    private PillChipLabel CreatePillChip(string text, Color back)
    {
        var chip = new PillChipLabel
        {
            Text = text,
            ChipColor = back,
            Margin = new Padding(8, 3, 0, 0)
        };
        chip.UpdateChipSize();
        return chip;
    }

    private static void SetPillChip(PillChipLabel chip, string text, Color back)
    {
        chip.Text = text;
        chip.ChipColor = back;
        chip.UpdateChipSize();
    }

    private void PaintHeaderBackground(object? sender, PaintEventArgs e)
    {
        var rect = _headerPanel.ClientRectangle;
        using (var brush = new SolidBrush(Color.FromArgb(175, _palette.HeaderBg)))
            e.Graphics.FillRectangle(brush, rect);

        using var line = new Pen(Color.FromArgb(s_lightTheme ? 180 : 48, _palette.Border));
        e.Graphics.DrawLine(line, 0, rect.Height - 1, rect.Width, rect.Height - 1);
    }

    private void PaintEmployeeAvatar(object? sender, PaintEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_employeeAvatarKey))
            return;

        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;

        var rect = new Rectangle(1, 1, _employeeAvatarHost.Width - 3, _employeeAvatarHost.Height - 3);
        using (var path = LoginUiChrome.CreateRoundedPath(rect, rect.Width / 2))
        {
            g.SetClip(path);
            g.DrawImage(AccountAvatarGallery.GetAvatar(_employeeAvatarKey), rect);
            g.ResetClip();
        }

        if (!AccountAvatarGallery.UsesCustomImages)
        {
            var initial = AccountAvatarGallery.GetInitial(_employeeAvatarKey);
            using var font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold);
            using var brush = new SolidBrush(Color.FromArgb(235, Color.White));
            var size = g.MeasureString(initial, font);
            g.DrawString(
                initial,
                font,
                brush,
                ( _employeeAvatarHost.Width - size.Width) / 2f,
                (_employeeAvatarHost.Height - size.Height) / 2f + 0.5f);
        }

        using var ring = new Pen(Color.FromArgb(160, _palette.Border), 1.2f);
        g.DrawEllipse(ring, rect);
    }

    private void ApplyRoundedRegion()
    {
        var rect = new Rectangle(0, 0, Width, Height);
        Region = new Region(CreateRoundedPath(rect, CornerRadius));
    }

    private void PaintRoundedCard(Graphics g, Rectangle bounds, int radius = 10)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var rect = new Rectangle(0, 0, bounds.Width - 1, bounds.Height - 1);
        using var path = CreateRoundedPath(rect, radius);
        using var fill = new SolidBrush(Color.FromArgb(165, _palette.CardBg));
        using var inner = new Pen(Color.FromArgb(s_lightTheme ? 220 : 36, _palette.Border));
        using var pen = new Pen(Color.FromArgb(100, _palette.Border));
        g.FillPath(fill, path);
        g.DrawPath(inner, path);
        g.DrawPath(pen, path);
    }

    private static GraphicsPath CreateRoundedPath(Rectangle bounds, int radius)
    {
        var path = new GraphicsPath();
        var d = radius * 2;
        var arc = new Rectangle(bounds.Location, new Size(d, d));
        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - d;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - d;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.Left;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }

    private string L(string key, string fallback)
        => _actions.Localization?.GetString(key, fallback) ?? fallback;

    protected override CreateParams CreateParams
    {
        get
        {
            const int WS_EX_TOOLWINDOW = 0x00000080;
            var cp = base.CreateParams;
            cp.ExStyle |= WS_EX_TOOLWINDOW;
            return cp;
        }
    }

    private sealed class PunchStyledButton : Button
    {
        private const int WM_ERASEBKGND = 0x0014;

        private readonly TrayPunchPanelForm _owner;
        private PunchButtonStyle _style;
        private Color _normalBack;
        private Color _hoverBack;
        private Color _pressedBack;
        private Color _disabledBack;
        private Color _surfaceBack;
        private bool _hover;
        private bool _pressed;

        public PunchStyledButton(TrayPunchPanelForm owner, string text, PunchButtonStyle style, int width)
        {
            _owner = owner;
            _style = style;
            Text = text;
            Width = width;
            Height = ActivityButtonHeight;
            Margin = new Padding(0, 0, 8, 0);
            FlatStyle = FlatStyle.Flat;
            Cursor = Cursors.Hand;
            Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            FlatAppearance.BorderSize = 0;
            UseVisualStyleBackColor = false;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            UpdateStyles();
            RefreshTheme(owner._palette);
        }

        public void RefreshTheme(PunchPanelPalette palette)
        {
            _surfaceBack = palette.Bg;
            BackColor = _surfaceBack;
            UseVisualStyleBackColor = false;

            _disabledBack = palette.IsLight
                ? Color.FromArgb(214, 220, 230)
                : Color.FromArgb(52, 56, 66);

            if (!Enabled)
            {
                ForeColor = palette.IsLight
                    ? Color.FromArgb(156, 164, 176)
                    : Color.FromArgb(130, 136, 148);
                _normalBack = _disabledBack;
                _hoverBack = _disabledBack;
                _pressedBack = _disabledBack;
                Invalidate();
                return;
            }

            ForeColor = ResolveForeColor(palette, _style);
            _normalBack = palette.ResolveButton(_style);
            _hoverBack = Lighten(_normalBack, palette.IsLight ? 10 : 18);
            _pressedBack = Darken(_normalBack, palette.IsLight ? 8 : 12);
            Invalidate();
        }

        public void ApplyStyle(PunchButtonStyle style)
        {
            _style = style;
            RefreshTheme(_owner._palette);
        }

        protected override void OnPaintBackground(PaintEventArgs pevent)
        {
            using var brush = new SolidBrush(_surfaceBack);
            pevent.Graphics.FillRectangle(brush, pevent.ClipRectangle);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_ERASEBKGND)
            {
                m.Result = (IntPtr)1;
                return;
            }

            base.WndProc(ref m);
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            if (!Enabled)
                return;

            _hover = true;
            Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            _hover = false;
            _pressed = false;
            Invalidate();
        }

        protected override void OnMouseDown(MouseEventArgs mevent)
        {
            base.OnMouseDown(mevent);
            if (!Enabled || mevent.Button != MouseButtons.Left)
                return;

            _pressed = true;
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs mevent)
        {
            base.OnMouseUp(mevent);
            _pressed = false;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            var g = pevent.Graphics;
            // FillRectangle (not Clear): Clear can leave black AA fringes on rounded corners
            // when the control surface color was stale after a theme switch.
            using (var surface = new SolidBrush(_surfaceBack))
                g.FillRectangle(surface, ClientRectangle);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.CompositingQuality = CompositingQuality.HighQuality;

            var rect = new Rectangle(0, 0, Width, Height);
            rect.Inflate(-1, -1);
            using var path = CreateRoundedPath(rect, 10);
            var fill = !Enabled
                ? _disabledBack
                : _pressed ? _pressedBack : _hover ? _hoverBack : _normalBack;

            using (var brush = new SolidBrush(fill))
                g.FillPath(brush, path);

            var flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis;
            using var drawFont = ResolveFitFont(g, flags);
            TextRenderer.DrawText(g, Text, drawFont, ClientRectangle, ForeColor, flags);
        }

        /// <summary>
        /// Shrinks the font just enough for the current text to fit the button without being
        /// ellipsis-clipped (e.g. long localized labels like "抽烟或休息" once the panel/button
        /// has been resized down for a small screen). Button size, colors and layout are
        /// untouched; only the rendered font size adapts.
        /// </summary>
        private Font ResolveFitFont(Graphics g, TextFormatFlags flags)
        {
            var padding = 6; // matches the visual inset used by the rounded background path
            var available = new Size(Math.Max(1, Width - padding), Math.Max(1, Height - padding));

            if (string.IsNullOrEmpty(Text))
                return (Font)Font.Clone();

            var measured = TextRenderer.MeasureText(g, Text, Font, available, flags & ~TextFormatFlags.EndEllipsis);
            if (measured.Width <= available.Width && measured.Height <= available.Height)
                return (Font)Font.Clone();

            const float minSize = 7.5f;
            var size = Font.Size;
            while (size > minSize)
            {
                size -= 0.5f;
                using var candidate = new Font(Font.FontFamily, size, Font.Style);
                var candidateMeasured = TextRenderer.MeasureText(g, Text, candidate, available, flags & ~TextFormatFlags.EndEllipsis);
                if (candidateMeasured.Width <= available.Width)
                    return new Font(Font.FontFamily, size, Font.Style);
            }

            return new Font(Font.FontFamily, minSize, Font.Style);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            base.OnEnabledChanged(e);
            RefreshTheme(_owner._palette);
        }

        private static Color ResolveForeColor(PunchPanelPalette palette, PunchButtonStyle style)
        {
            if (style == PunchButtonStyle.Exhausted)
                return palette.IsLight ? Color.FromArgb(136, 72, 64) : Color.FromArgb(255, 205, 180);
            if (palette.IsLight && style == PunchButtonStyle.Neutral)
                return Color.FromArgb(52, 58, 68);
            return Color.White;
        }

        private static Color Lighten(Color c, int amount)
            => Color.FromArgb(Math.Min(255, c.R + amount), Math.Min(255, c.G + amount), Math.Min(255, c.B + amount));

        private static Color Darken(Color c, int amount)
            => Color.FromArgb(Math.Max(0, c.R - amount), Math.Max(0, c.G - amount), Math.Max(0, c.B - amount));

        private static GraphicsPath CreateRoundedPath(Rectangle bounds, int radius)
        {
            var path = new GraphicsPath();
            var d = radius * 2;
            var arc = new Rectangle(bounds.Location, new Size(d, d));
            path.AddArc(arc, 180, 90);
            arc.X = bounds.Right - d;
            path.AddArc(arc, 270, 90);
            arc.Y = bounds.Bottom - d;
            path.AddArc(arc, 0, 90);
            arc.X = bounds.Left;
            path.AddArc(arc, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    private sealed class PillChipLabel : Control
    {
        private static readonly Font ChipFont = new("Segoe UI", 8.25F, FontStyle.Bold);

        public Color ChipColor { get; set; } = Color.FromArgb(78, 84, 98);

        public PillChipLabel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            ForeColor = Color.White;
            BackColor = Color.Transparent;
            Size = new Size(56, 22);
            Cursor = Cursors.Default;
        }

        public void UpdateChipSize()
        {
            var text = string.IsNullOrWhiteSpace(Text) ? " " : Text;
            var size = TextRenderer.MeasureText(text, ChipFont, new Size(int.MaxValue, 22),
                TextFormatFlags.SingleLine | TextFormatFlags.NoPadding);
            Size = new Size(Math.Max(44, size.Width + 18), 22);
            Invalidate();
        }

        public override Size GetPreferredSize(Size proposedSize) => Size;

        protected override void OnTextChanged(EventArgs e)
        {
            base.OnTextChanged(e);
            UpdateChipSize();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, Width - 1, Height - 1);
            using var path = CreateRoundedPath(rect, 10);
            using var fill = new SolidBrush(ChipColor);
            e.Graphics.FillPath(fill, path);

            TextRenderer.DrawText(e.Graphics, Text, ChipFont, rect, ForeColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        }

        private static GraphicsPath CreateRoundedPath(Rectangle bounds, int radius)
        {
            var path = new GraphicsPath();
            var d = radius * 2;
            var arc = new Rectangle(bounds.Location, new Size(d, d));
            path.AddArc(arc, 180, 90);
            arc.X = bounds.Right - d;
            path.AddArc(arc, 270, 90);
            arc.Y = bounds.Bottom - d;
            path.AddArc(arc, 0, 90);
            arc.X = bounds.Left;
            path.AddArc(arc, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}

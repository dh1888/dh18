using System.Runtime.Versioning;
using System.Text.Json;
using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Health;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.RecordingServices;
using EnterpriseAgent.Agent.RemoteView;
using EnterpriseAgent.Agent.Services;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Win32;

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.Lifecycle;

[SupportedOSPlatform("windows")]
public sealed class LifecycleCoordinator : ILifecycleCoordinator, IHostedService, IDisposable
{
    private readonly ILogger<LifecycleCoordinator> _logger;
    private readonly IRecordingService _recording;
    private readonly IRemoteViewService _remoteView;
    private readonly IRecoveryRequestSink _recoverySink;
    private readonly ICaptureCoordinator _captureCoordinator;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IHostApplicationLifetime _lifetime;
    private readonly CaptureLifecycleTelemetry _telemetry;
    private readonly RestartPolicyRegistry _restartPolicies;
    private readonly RemoteViewConfig _remoteViewConfig;
    private readonly SemaphoreSlim _orchestrationLock = new(1, 1);
    private readonly CaptureIntentQueue _intentQueue;

    private AgentPolicy? _currentPolicy;
    private CaptureLifecycleState _captureState = CaptureLifecycleState.Idle;
    private RecorderState _recorderState = RecorderState.Idle;
    private bool _standaloneRemoteActive;
    private bool _sharedBridgeForRemote;
    private bool _pendingPolicyApply;
    private bool _workSessionActive;
    private DateTime _lastResumeUtc = DateTime.MinValue;
    private DateTime _lastEnterFailureUtc = DateTime.MinValue;
    private CaptureSnapshot? _enterSnapshot;
    private string? _lastCorrelationId;
    private string? _lastTransition;
    private DateTime? _lastTransitionUtc;
    private int _pendingRemoteReconnect;

    public LifecycleCoordinator(
        ILogger<LifecycleCoordinator> logger,
        IRecordingService recording,
        IRemoteViewService remoteView,
        IRecoveryRequestSink recoverySink,
        ICaptureCoordinator captureCoordinator,
        IServiceScopeFactory scopeFactory,
        IHostApplicationLifetime lifetime,
        CaptureLifecycleTelemetry telemetry,
        RestartPolicyRegistry restartPolicies,
        IOptions<RemoteViewConfig> remoteViewConfig)
    {
        _logger = logger;
        _recording = recording;
        _remoteView = remoteView;
        _recoverySink = recoverySink;
        _captureCoordinator = captureCoordinator;
        _scopeFactory = scopeFactory;
        _lifetime = lifetime;
        _telemetry = telemetry;
        _restartPolicies = restartPolicies;
        _remoteViewConfig = remoteViewConfig.Value;
        _intentQueue = new CaptureIntentQueue(ExecuteCommandInternalAsync, _telemetry);
        _remoteView.PublishFailed += OnRemoteViewPublishFailedAsync;
    }

    public event Func<string?, string, Task>? RemoteViewPublishFailed;

    public RecorderState State => _recorderState;
    public bool IsRemoteActive =>
        _captureState is CaptureLifecycleState.SharedBridgeRunning
        || (_captureState == CaptureLifecycleState.PreparingSharedBridge && _standaloneRemoteActive)
        || (_standaloneRemoteActive && _captureState != CaptureLifecycleState.Stopping);

    public bool WorkSessionActive => _workSessionActive;
    public DateTime LastResumeUtc => _lastResumeUtc;
    public DateTime LastEnterFailureUtc => _lastEnterFailureUtc;

    public CaptureLifecycleDiagnostics GetDiagnostics()
    {
        var recordingEnabled = _currentPolicy?.GetRecordingConfig()?.Enabled ?? false;
        var shouldRecordingBeActive = ShouldRecordingBeActive();
        var recordingSnapshot = _recording.GetHealthSnapshot(_recorderState, IsRemoteActive);
        var remoteHealth = _remoteView.GetHealth();

        var violations = CaptureLifecycleDiagnosticsAnalyzer.DetectInvariantViolations(
            _captureState,
            shouldRecordingBeActive,
            _recording.IsRunning,
            IsRemoteActive,
            remoteHealth.IsPublishing,
            _sharedBridgeForRemote,
            _captureCoordinator.IsSharedCaptureActive);

        return new CaptureLifecycleDiagnostics
        {
            CaptureState = _captureState,
            RecorderState = _recorderState,
            IsRemoteActive = IsRemoteActive,
            WorkSessionActive = _workSessionActive,
            SharedBridgeForRemote = _sharedBridgeForRemote,
            StandaloneRemoteActive = _standaloneRemoteActive,
            RecordingEnabledByPolicy = recordingEnabled,
            RecordingRunning = _recording.IsRunning,
            RemotePublishing = remoteHealth.IsPublishing,
            SharedCaptureActive = _captureCoordinator.IsSharedCaptureActive,
            PendingPolicyApply = _pendingPolicyApply,
            LastResumeUtc = _lastResumeUtc == DateTime.MinValue ? null : _lastResumeUtc,
            LastCorrelationId = _lastCorrelationId,
            LastTransition = _lastTransition,
            LastTransitionUtc = _lastTransitionUtc,
            RestartPolicies = _restartPolicies.GetDiagnostics(),
            RecordingHealth = new CaptureLifecycleRecordingHealth
            {
                ShouldBeRecording = recordingSnapshot.ShouldBeRecording,
                ProcessAlive = recordingSnapshot.ProcessAlive,
                EncoderAlive = recordingSnapshot.EncoderAlive,
                FileRecent = recordingSnapshot.FileRecent,
                IsHealthy = recordingSnapshot.IsHealthy,
                StallSeconds = recordingSnapshot.StallSeconds,
                CurrentEncoder = recordingSnapshot.CurrentEncoder,
            },
            InvariantViolations = violations,
        };
    }

    RecordingHealthSnapshot IRecorderLifecycle.GetHealthSnapshot() =>
        _recording.GetHealthSnapshot(_recorderState, IsRemoteActive);

    public void UpdatePolicy(AgentPolicy policy)
    {
        var previousConfig = _currentPolicy?.GetRecordingConfig();
        _currentPolicy = policy;
        _recording.UpdatePolicy(policy);

        var recordingConfig = policy.GetRecordingConfig();
        var recordingConfigChanged = HasRecordingConfigChanged(previousConfig, recordingConfig);

        _logger.LogInformation(
            "Lifecycle policy updated: Enabled={Enabled}, FPS={Fps}, GPU={Gpu}, SliceMinutes={SliceMinutes}, ConfigChanged={ConfigChanged}",
            recordingConfig.Enabled,
            recordingConfig.Fps,
            recordingConfig.EnableGpu,
            recordingConfig.SliceMinutes,
            recordingConfigChanged);

        if (!recordingConfig.Enabled)
        {
            _ = _intentQueue.EnqueueAsync(
                RecorderCommand.EmergencyStop,
                new RecorderRequestContext { Reason = "Policy disabled" });
            return;
        }

        if (_workSessionActive && (!_recording.IsRunning || recordingConfigChanged))
        {
            _ = _intentQueue.EnqueueAsync(
                RecorderCommand.ApplyPolicyChange,
                new RecorderRequestContext
                {
                    Reason = recordingConfigChanged ? "Policy config changed" : "Policy process dead",
                });
        }
    }

    private static bool HasRecordingConfigChanged(RecordingConfig? previous, RecordingConfig current)
    {
        if (previous == null)
            return true;

        return previous.Enabled != current.Enabled
            || previous.Fps != current.Fps
            || previous.IdleFps != current.IdleFps
            || previous.SliceMinutes != current.SliceMinutes
            || previous.EnableGpu != current.EnableGpu
            || previous.Quality != current.Quality
            || !string.Equals(previous.Resolution, current.Resolution, StringComparison.OrdinalIgnoreCase);
    }

    public void NotifySystemResume() => _lastResumeUtc = DateTime.UtcNow;

    public Task<RecorderResult> RequestAsync(
        RecorderCommand command,
        RecorderRequestContext? context = null,
        CancellationToken cancellationToken = default) =>
        _intentQueue.EnqueueAsync(command, context ?? new RecorderRequestContext(), cancellationToken);

    private async Task<RecorderResult> ExecuteCommandInternalAsync(
        RecorderCommand command,
        RecorderRequestContext context,
        CancellationToken cancellationToken)
    {
        if (!await _orchestrationLock.WaitAsync(TimeSpan.FromSeconds(60), cancellationToken))
            return RecorderResult.Failed(_recorderState, "Orchestration lock timeout");

        var correlationId = ExtractCorrelationId(context.Reason);
        _lastCorrelationId = correlationId;
        var previousCaptureState = _captureState;
        var previousRecorderState = _recorderState;
        _recorderState = RecorderState.Transitioning;

        try
        {
            _logger.LogInformation(
                "Lifecycle command: {Command} reason={Reason} captureState={CaptureState}",
                command,
                context.Reason,
                _captureState);

            var result = command switch
            {
                RecorderCommand.StartWorkSession => await ExecuteStartWorkSessionAsync(cancellationToken),
                RecorderCommand.StopWorkSession => await ExecuteStopWorkSessionAsync(cancellationToken),
                RecorderCommand.EnterRemoteView => await ExecuteEnterRemoteViewAsync(context, cancellationToken),
                RecorderCommand.ExitRemoteView => await ExecuteExitRemoteViewAsync(cancellationToken),
                RecorderCommand.ReconnectRemote => await ExecuteReconnectRemoteAsync(context, cancellationToken),
                RecorderCommand.RecoverCapture => await ExecuteRecoverCaptureAsync(context, cancellationToken),
                RecorderCommand.RecoverRecording => await ExecuteRecoverRecordingAsync(context, cancellationToken),
                RecorderCommand.ApplyPolicyChange => await ExecuteApplyPolicyChangeAsync(cancellationToken),
                RecorderCommand.RetryEncoder => await ExecuteRetryEncoderAsync(cancellationToken),
                RecorderCommand.EmergencyStop => await ExecuteEmergencyStopAsync(cancellationToken),
                RecorderCommand.SystemResume => await ExecuteSystemResumeAsync(cancellationToken),
                RecorderCommand.RecoverSharedBridge => await ExecuteRecoverSharedBridgeAsync(context, cancellationToken),
                _ => RecorderResult.Failed(MapRecorderState(), $"Unknown command: {command}"),
            };

            if (_recorderState == RecorderState.Transitioning)
                MapRecorderState();

            RecordTransition(correlationId, previousCaptureState, _captureState, command.ToString(), result.Success, result.Message);

            return new RecorderResult
            {
                Success = result.Success,
                State = _recorderState,
                Message = result.Message,
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Lifecycle command {Command} failed", command);
            MapRecorderState();
            RecordTransition(correlationId, previousCaptureState, _captureState, command.ToString(), false, ex.Message);
            return RecorderResult.Failed(_recorderState, ex.Message);
        }
        finally
        {
            if (_recorderState == RecorderState.Transitioning)
                MapRecorderState();
            _orchestrationLock.Release();
        }
    }

    private static string ExtractCorrelationId(string reason)
    {
        const string marker = "|cid=";
        var idx = reason.LastIndexOf(marker, StringComparison.Ordinal);
        return idx >= 0 ? reason[(idx + marker.Length)..] : reason;
    }

    private void RecordTransition(
        string correlationId,
        CaptureLifecycleState from,
        CaptureLifecycleState to,
        string trigger,
        bool success,
        string? detail)
    {
        _lastTransition = $"{from}->{to}";
        _lastTransitionUtc = DateTime.UtcNow;
        _telemetry.AuditTransition(correlationId, from, to, trigger, success, detail);
    }

    private void TransitionCaptureState(CaptureLifecycleState next)
    {
        if (_captureState == next)
            return;

        var from = _captureState;
        _captureState = next;
        RemoteDiagLog.Transition(
            _logger,
            "Lifecycle",
            _remoteView.ActiveSessionId,
            from.ToString(),
            next.ToString(),
            BuildLifecycleStateReason());
    }

    private string BuildLifecycleStateReason()
        => $"remoteActive={IsRemoteActive} sharedBridge={_sharedBridgeForRemote} standalone={_standaloneRemoteActive} publishing={_remoteView.IsPublishing}";

    private RecorderState MapRecorderState()
    {
        _recorderState = _captureState switch
        {
            CaptureLifecycleState.Idle or CaptureLifecycleState.Stopped => RecorderState.Idle,
            CaptureLifecycleState.Recording or CaptureLifecycleState.Recovering or CaptureLifecycleState.Rollback =>
                _standaloneRemoteActive ? RecorderState.RecordingAndRemote : RecorderState.Recording,
            CaptureLifecycleState.PreparingSharedBridge =>
                _standaloneRemoteActive ? RecorderState.RecordingAndRemote : RecorderState.Recording,
            CaptureLifecycleState.SharedBridgeRunning => RecorderState.RecordingAndRemote,
            CaptureLifecycleState.Stopping => RecorderState.Transitioning,
            _ => _standaloneRemoteActive
                ? (_recording.IsRunning ? RecorderState.RecordingAndRemote : RecorderState.StandaloneRemote)
                : (_recording.IsRunning ? RecorderState.Recording : RecorderState.Idle),
        };
        return _recorderState;
    }

    private Task OnRemoteViewPublishFailedAsync(string? sessionId, string detail)
    {
        RemoteViewPublishFailed?.Invoke(sessionId, detail);

        // WHIP→RTMP fallback: notify module/backend only; do not reconnect or tear down remote mode.
        if (!string.IsNullOrWhiteSpace(detail) &&
            detail.StartsWith("WHIP_FALLBACK_REQUEST:", StringComparison.OrdinalIgnoreCase))
        {
            Interlocked.Exchange(ref _pendingRemoteReconnect, 0);
            MapRecorderState();
            return Task.CompletedTask;
        }

        if (_captureState is CaptureLifecycleState.PreparingSharedBridge
            or CaptureLifecycleState.Rollback
            or CaptureLifecycleState.Recovering
            or CaptureLifecycleState.Stopping)
        {
            _logger.LogDebug(
                "Ignoring PublishFailed during capture transition state={State}: {Detail}",
                _captureState,
                detail);
            return Task.CompletedTask;
        }

        var userStop = _remoteView.TakeUserInitiatedStop();
        var pendingTransport = _remoteView.TakePendingTransportError();
        var enriched = detail;
        if (!string.IsNullOrWhiteSpace(pendingTransport) &&
            (string.IsNullOrWhiteSpace(enriched) ||
             !enriched.Contains(pendingTransport, StringComparison.OrdinalIgnoreCase)))
        {
            enriched = string.IsNullOrWhiteSpace(enriched)
                ? pendingTransport
                : $"{enriched} | {pendingTransport}";
        }

        var kind = RemoteFailureClassifier.Classify(enriched, userStop);

        RemoteDiagLog.Event(
            _logger,
            "Lifecycle",
            sessionId,
            _captureState.ToString(),
            $"PublishFailed kind={kind} detail={TruncateDiag(enriched, 160)}");

        _logger.LogWarning(
            "Remote publish failed kind={Kind} sharedBridge={SharedBridge} detail={Detail}",
            kind,
            _sharedBridgeForRemote || _captureCoordinator.IsSharedCaptureActive,
            enriched);

        if (kind == RemoteFailureKind.UserStop)
        {
            Interlocked.Exchange(ref _pendingRemoteReconnect, 0);
            _standaloneRemoteActive = false;
            MapRecorderState();
            return Task.CompletedTask;
        }

        // P1: recoverable RTMP/Ingress failures reconnect without tearing DualGdigrab / SharedBridge
        var reconnect = RemoteFailureClassifier.ShouldReconnectWithoutTeardown(kind, enriched);
        if (!reconnect)
        {
            Interlocked.Exchange(ref _pendingRemoteReconnect, 0);
            _standaloneRemoteActive = false;
        }

        var command = reconnect ? RecorderCommand.ReconnectRemote : RecorderCommand.ExitRemoteView;

        if (reconnect && Interlocked.Exchange(ref _pendingRemoteReconnect, 1) == 1)
        {
            _logger.LogDebug("Coalescing duplicate ReconnectRemote while one is pending");
            return Task.CompletedTask;
        }

        if (_sharedBridgeForRemote || _captureCoordinator.IsSharedCaptureActive || _standaloneRemoteActive
            || !string.IsNullOrWhiteSpace(_remoteView.ActiveSessionId)
            || command == RecorderCommand.ExitRemoteView)
        {
            _ = _intentQueue.EnqueueAsync(
                command,
                new RecorderRequestContext { Reason = $"Publish failed ({kind}): {enriched}" });
        }
        else
        {
            Interlocked.Exchange(ref _pendingRemoteReconnect, 0);
            MapRecorderState();
        }

        return Task.CompletedTask;
    }

    private bool ShouldRecordingBeActive() =>
        _workSessionActive && (_currentPolicy?.GetRecordingConfig()?.Enabled ?? false);

    private CaptureSnapshot CaptureEnterSnapshot(bool recordingWasRunning) => new()
    {
        Mode = _captureCoordinator.Mode,
        OutputPattern = _recording.OutputPattern,
        RecordingWasRunning = recordingWasRunning,
        CapturedUtc = DateTime.UtcNow,
    };

    private async Task<RecorderResult> ExecuteStartWorkSessionAsync(CancellationToken ct)
    {
        _workSessionActive = true;
        _recording.SetWorkSessionActive(true);

        if (IsRemoteActive)
        {
            MapRecorderState();
            return RecorderResult.Ok(_recorderState, "Work session on; remote already active");
        }

        TransitionCaptureState(CaptureLifecycleState.Recording);
        var started = await _recording.TryStartAsync(ct);
        if (!started)
        {
            TransitionCaptureState(CaptureLifecycleState.Idle);
            return RecorderResult.Failed(MapRecorderState(), "Recording failed to start for work session");
        }

        _remoteView.WarmupEncoderAsync(ct);

        return RecorderResult.Ok(MapRecorderState());
    }

    private async Task<RecorderResult> ExecuteStopWorkSessionAsync(CancellationToken ct)
    {
        TransitionCaptureState(CaptureLifecycleState.Stopping);
        _workSessionActive = false;
        _recording.SetWorkSessionActive(false);

        if (_standaloneRemoteActive)
            await ExecuteExitRemoteViewAsync(ct);

        await _recording.StopAsync(fullShutdown: true, cancellationToken: ct);
        TransitionCaptureState(CaptureLifecycleState.Stopped);
        return RecorderResult.Ok(MapRecorderState());
    }

    private async Task<RecorderResult> ExecuteEnterRemoteViewAsync(RecorderRequestContext context, CancellationToken ct)
    {
        var parameters = context.RemoteView
            ?? throw new InvalidOperationException("EnterRemoteView requires RemoteViewStartParams");

        RemoteDiagLog.Event(
            _logger,
            "Lifecycle",
            parameters.SessionId,
            _captureState.ToString(),
            $"EnterRemoteView begin protocol={parameters.ResolvePublishProtocol()} recording={ShouldRecordingBeActive()}");

        var recordingEnabled = ShouldRecordingBeActive();
        var recordingRunning = recordingEnabled && _recording.IsRunning;

        if (recordingRunning)
        {
            _enterSnapshot = CaptureEnterSnapshot(recordingWasRunning: true);
            TransitionCaptureState(CaptureLifecycleState.PreparingSharedBridge);

            _logger.LogInformation(
                "Enter SharedBridge: single capture, dual encoders (recording + remote concurrent) protocol={Protocol}",
                parameters.ResolvePublishProtocol());

            try
            {
                if (_lastEnterFailureUtc != DateTime.MinValue
                    && DateTime.UtcNow - _lastEnterFailureUtc < TimeSpan.FromSeconds(2))
                {
                    await Task.Delay(400, ct);
                }

                // P1: prepare pipes while gdigrab still recording (health defers during PreparingSharedBridge)
                await _captureCoordinator.PrepareSharedCaptureAsync(ct);
                _sharedBridgeForRemote = true;
                _captureCoordinator.SetSharedBridgeOrchestrated(true);

                var pipeHealth = _captureCoordinator.GetSharedBridgeHealth();
                if (pipeHealth.State < SharedBridgeState.PipesListening
                    || (pipeHealth.ReadyFlags & SharedBridgeReadyFlags.PipesListening) == 0)
                {
                    throw new InvalidOperationException(
                        $"SharedBridge pipes not listening after prepare (state={pipeHealth.State}, flags={pipeHealth.ReadyFlags})");
                }

                await _recording.StopAsync(fullShutdown: false, fastTransition: true, ct);
                // StopAsync already awaits full cleanup — extra quiescence polling caused lock races.

                var recordingStarted = await TryStartRecordingWithRetryAsync(ct);
                if (!recordingStarted || !_recording.IsRunning)
                {
                    MarkEnterFailure();
                    await RollbackSharedBridgeEnterAsync(_enterSnapshot, ct);
                    return RecorderResult.Failed(
                        MapRecorderState(),
                        "Recording pipe consumer did not start (SharedBridge enter failed)");
                }

                // P2 Enter plan B: bridge flowing first, then remote on a live hub stream.
                await _captureCoordinator.WaitSharedConsumersConnectedAsync(ct, requireRemote: false);
                await _captureCoordinator.StartSharedCaptureAsync(ct);
                await _captureCoordinator.WaitSharedBridgeFlowingAsync(
                    ct,
                    requireConsumerFirstFrames: true,
                    requireRemoteConsumer: false);

                var warmMs = _captureCoordinator.GetSharedFrameHubEnterRemoteWarmMs();
                if (warmMs > 0)
                {
                    _logger.LogInformation(
                        "[PipelineDiag] Seq SharedBridgeEnterWarm delayMs={DelayMs} session={SessionId}",
                        warmMs,
                        parameters.SessionId);
                    await Task.Delay(warmMs, ct);
                }

                _logger.LogInformation(
                    "[PipelineDiag] Seq SharedBridgeRemoteLaunchAfterFlow session={SessionId}",
                    parameters.SessionId);
                await _remoteView.StartAsync(parameters, ct);

                await _remoteView.WaitForPublishReadyAsync(ct);

                if (await _remoteView.RecoverSlowSharedBridgePublishIfNeededAsync(parameters, ct))
                    await _remoteView.WaitForPublishReadyAsync(ct);
            }
            catch (Exception ex)
            {
                MarkEnterFailure();
                await RollbackSharedBridgeEnterAsync(_enterSnapshot, CancellationToken.None);
                return RecorderResult.Failed(MapRecorderState(), ex.Message);
            }
            finally
            {
                _captureCoordinator.SetSharedBridgeOrchestrated(false);
                _enterSnapshot = null;
            }

            TransitionCaptureState(CaptureLifecycleState.SharedBridgeRunning);
        }
        else
        {
            _sharedBridgeForRemote = false;
            await _remoteView.StartAsync(parameters, ct);
            await _remoteView.WaitForPublishReadyAsync(ct);
        }

        _standaloneRemoteActive = true;

        RemoteDiagLog.Event(
            _logger,
            "Lifecycle",
            parameters.SessionId,
            _captureState.ToString(),
            $"EnterRemoteView complete sharedBridge={_sharedBridgeForRemote} publishing={_remoteView.IsPublishing}");

        _logger.LogInformation(
            "Remote view Running: session={SessionId}, sharedBridge={SharedBridge}, recording={Recording}, protocol={Protocol}",
            parameters.SessionId,
            _sharedBridgeForRemote,
            recordingEnabled && _recording.IsRunning,
            parameters.ResolvePublishProtocol());

        return RecorderResult.Ok(MapRecorderState());
    }

    private void MarkEnterFailure() => _lastEnterFailureUtc = DateTime.UtcNow;

    private async Task<bool> TryStartRecordingWithRetryAsync(CancellationToken ct, int maxAttempts = 5)
    {
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            if (await _recording.TryStartAsync(ct) && _recording.IsRunning)
                return true;

            _logger.LogWarning(
                "SharedBridge enter: recording start attempt {Attempt}/{MaxAttempts} failed",
                attempt,
                maxAttempts);

            if (attempt < maxAttempts)
                await Task.Delay(400 * attempt, ct);
        }

        return false;
    }

    private async Task RollbackSharedBridgeEnterAsync(CaptureSnapshot? snapshot, CancellationToken ct)
    {
        TransitionCaptureState(CaptureLifecycleState.Rollback);
        MarkEnterFailure();
        _logger.LogWarning("Rolling back SharedBridge enter (L1-L3)");

        // Stop bridge producer BEFORE consumers to avoid "Pipe is broken" write storms.
        if (_captureCoordinator.IsSharedCaptureActive)
        {
            try { await _captureCoordinator.StopSharedCaptureAsync(ct); }
            catch (Exception ex) { _logger.LogWarning(ex, "SharedBridge rollback: bridge stop failed"); }
        }

        try { await _remoteView.StopAsync(ct); }
        catch (Exception ex) { _logger.LogWarning(ex, "SharedBridge rollback: remote stop failed"); }

        if (_recording.IsRunning)
        {
            try
            {
                await _recording.StopAsync(fullShutdown: false, fastTransition: true, ct);
                await _captureCoordinator.NotifyConsumerStoppingAsync(CaptureConsumer.Recording, ct);
            }
            catch (Exception ex) { _logger.LogWarning(ex, "SharedBridge rollback: recording stop failed"); }
        }

        _sharedBridgeForRemote = false;
        _standaloneRemoteActive = false;
        _captureCoordinator.SetSharedBridgeOrchestrated(false);

        try { await _captureCoordinator.DisposeSharedCaptureAsync(ct); }
        catch (Exception ex) { _logger.LogWarning(ex, "SharedBridge rollback: shared capture dispose failed"); }

        // Named pipes can stay busy briefly after dispose; give the OS a moment.
        await Task.Delay(300, ct);
        await _recording.WaitUntilQuiescentAsync(ct);

        if (snapshot?.RecordingWasRunning == true && ShouldRecordingBeActive())
        {
            try
            {
                _logger.LogInformation("SharedBridge rollback L3: restoring snapshot output pattern");
                _recording.RestoreOutputPattern(snapshot.OutputPattern);
                var restored = await TryStartRecordingWithRetryAsync(ct, maxAttempts: 3);
                if (!restored)
                {
                    _logger.LogWarning("SharedBridge rollback L3 restore failed; attempting lifecycle restart");
                    await _recording.RestartAsync("SharedBridge enter rollback (L4)", ct);
                }
            }
            catch (Exception ex) { _logger.LogWarning(ex, "SharedBridge rollback: recording restore failed"); }
        }

        TransitionCaptureState(ShouldRecordingBeActive() && _recording.IsRunning
            ? CaptureLifecycleState.Recording
            : CaptureLifecycleState.Idle);
    }

    private async Task TeardownSharedBridgeAsync(CancellationToken ct, bool gracefulRecordingStop = false)
    {
        if (!_sharedBridgeForRemote && !_captureCoordinator.IsSharedCaptureActive)
            return;

        // P1: stop bridge producer before consumers (matches rollback order; avoids pipe write storms)
        if (_captureCoordinator.IsSharedCaptureActive)
        {
            try { await _captureCoordinator.StopSharedCaptureAsync(ct); }
            catch (Exception ex) { _logger.LogWarning(ex, "SharedBridge teardown: bridge stop failed"); }
        }

        // Always stop remote publisher so ActiveSessionId / params clear even if ffmpeg already died.
        try { await _remoteView.StopAsync(ct); }
        catch (Exception ex) { _logger.LogWarning(ex, "SharedBridge teardown: remote stop failed"); }

        if (_recording.IsRunning)
        {
            try
            {
                await _captureCoordinator.NotifyConsumerStoppingAsync(CaptureConsumer.Recording, ct);
                await _recording.StopAsync(fullShutdown: false, fastTransition: !gracefulRecordingStop, ct);
            }
            catch (Exception ex) { _logger.LogWarning(ex, "SharedBridge teardown: recording stop failed"); }
        }

        _sharedBridgeForRemote = false;
        _captureCoordinator.SetSharedBridgeOrchestrated(false);

        try { await _captureCoordinator.DisposeSharedCaptureAsync(ct); }
        catch (Exception ex) { _logger.LogWarning(ex, "SharedBridge teardown: shared capture dispose failed"); }
    }

    private async Task<RecorderResult> ExecuteExitRemoteViewAsync(CancellationToken ct)
    {
        Interlocked.Exchange(ref _pendingRemoteReconnect, 0);
        RemoteDiagLog.Event(
            _logger,
            "Lifecycle",
            _remoteView.ActiveSessionId,
            _captureState.ToString(),
            "ExitRemoteView begin");
        TransitionCaptureState(CaptureLifecycleState.Stopping);

        if (_standaloneRemoteActive && !_sharedBridgeForRemote)
        {
            await _remoteView.StopAsync(ct);
            _standaloneRemoteActive = false;
        }

        if (_sharedBridgeForRemote)
        {
            await TeardownSharedBridgeAsync(ct, gracefulRecordingStop: true);
            _standaloneRemoteActive = false;

            if (ShouldRecordingBeActive())
            {
                _logger.LogInformation("Restore DualGdigrab recording after remote view ended");
                var restored = await _recording.RestoreGdigrabCaptureAsync(ct);
                if (!restored)
                {
                    _logger.LogWarning("Fast gdigrab restore failed; falling back to RecoverForHealthAsync");
                    restored = await _recording.RecoverForHealthAsync("Restore gdigrab after remote view", ct);
                }

                TransitionCaptureState(_recording.IsRunning
                    ? CaptureLifecycleState.Recording
                    : CaptureLifecycleState.Idle);
            }
            else
            {
                TransitionCaptureState(CaptureLifecycleState.Idle);
            }
        }
        else if (_pendingPolicyApply)
        {
            _pendingPolicyApply = false;
            await _recording.RestartAsync("Deferred policy change", ct);
            TransitionCaptureState(CaptureLifecycleState.Recording);
        }
        else
        {
            TransitionCaptureState(ShouldRecordingBeActive() && _recording.IsRunning
                ? CaptureLifecycleState.Recording
                : CaptureLifecycleState.Idle);
        }

        RemoteDiagLog.Event(
            _logger,
            "Lifecycle",
            _remoteView.ActiveSessionId,
            _captureState.ToString(),
            "ExitRemoteView complete");

        return RecorderResult.Ok(MapRecorderState());
    }

    private async Task<RecorderResult> ExecuteReconnectRemoteAsync(RecorderRequestContext context, CancellationToken ct)
    {
        RemoteDiagLog.Event(
            _logger,
            "Lifecycle",
            _remoteView.ActiveSessionId,
            _captureState.ToString(),
            $"ReconnectRemote begin reason={context.Reason}");
        try
        {
            // SharedBridge path keeps _standaloneRemoteActive=false; still reconnect publish only.
            var remoteSessionActive = _sharedBridgeForRemote
                || _captureCoordinator.IsSharedCaptureActive
                || _standaloneRemoteActive
                || !string.IsNullOrWhiteSpace(_remoteView.ActiveSessionId);

            if (!remoteSessionActive)
                return await ExecuteRecoverCaptureAsync(context, ct);

            await _remoteView.RequestRecoveryAsync(context.Reason, ct);

            // Permanent RTMP failure clears ActiveSessionId; tear SharedBridge so tray / recording recover.
            if (!_remoteView.IsPublishing && string.IsNullOrWhiteSpace(_remoteView.ActiveSessionId))
            {
                _logger.LogWarning(
                    "Remote reconnect exhausted or cleared session; exiting remote view ({Reason})",
                    context.Reason);
                return await ExecuteExitRemoteViewAsync(ct);
            }

            _standaloneRemoteActive = _remoteView.IsPublishing
                || _sharedBridgeForRemote
                || !string.IsNullOrWhiteSpace(_remoteView.ActiveSessionId);

            RemoteDiagLog.Event(
                _logger,
                "Lifecycle",
                _remoteView.ActiveSessionId,
                _captureState.ToString(),
                $"ReconnectRemote complete publishing={_remoteView.IsPublishing}");

            return RecorderResult.Ok(MapRecorderState());
        }
        finally
        {
            Interlocked.Exchange(ref _pendingRemoteReconnect, 0);
        }
    }

    private Task<RecorderResult> ExecuteRecoverCaptureAsync(RecorderRequestContext context, CancellationToken ct)
    {
        var state = MapRecorderState();

        if (!RecorderStateMachine.AllowsFullEngineRestart(state))
        {
            if (!_recording.IsRunning && _workSessionActive)
                return ExecuteRecoverRecordingAsync(context, ct);

            return Task.FromResult(RecorderResult.Skipped(state, "Recover skipped for current state"));
        }

        _recoverySink.RequestRecordingRecovery(context.Reason);
        return Task.FromResult(RecorderResult.Ok(
            MapRecorderState(),
            "Recording recovery scheduled via HealthCoordinator"));
    }

    private async Task<RecorderResult> ExecuteRecoverRecordingAsync(RecorderRequestContext context, CancellationToken ct)
    {
        if (_captureState == CaptureLifecycleState.Recovering)
            return RecorderResult.Skipped(MapRecorderState(), "Recovery already in progress");

        if (_captureState is CaptureLifecycleState.PreparingSharedBridge or CaptureLifecycleState.Rollback)
            return RecorderResult.Skipped(MapRecorderState(), "Capture transition in progress");

        if (_sharedBridgeForRemote || _captureCoordinator.IsSharedCaptureActive)
        {
            var bridgeReason = MapRecordingRecoveryToSharedBridgeReason(context.Reason);
            _logger.LogWarning(
                "Recording recovery redirected to SharedBridge while remote active: {Reason} -> {BridgeReason}",
                context.Reason,
                bridgeReason);
            return await ExecuteRecoverSharedBridgeAsync(
                new RecorderRequestContext { Reason = bridgeReason },
                ct);
        }

        var previous = _captureState;
        TransitionCaptureState(CaptureLifecycleState.Recovering);

        try
        {
            _logger.LogWarning("Orchestrator recovering recording: {Reason}", context.Reason);
            var recovered = await _recording.RecoverForHealthAsync(context.Reason, ct);
            TransitionCaptureState(recovered && _recording.IsRunning
                ? CaptureLifecycleState.Recording
                : CaptureLifecycleState.Idle);

            return recovered
                ? RecorderResult.Ok(MapRecorderState(), context.Reason)
                : RecorderResult.Failed(MapRecorderState(), "Health recovery did not restart recording");
        }
        catch (Exception)
        {
            TransitionCaptureState(previous);
            throw;
        }
    }

    private async Task<RecorderResult> ExecuteApplyPolicyChangeAsync(CancellationToken ct)
    {
        var config = _currentPolicy?.GetRecordingConfig();
        if (config is not { Enabled: true })
        {
            await ExecuteEmergencyStopAsync(ct);
            return RecorderResult.Ok(MapRecorderState());
        }

        if (RecorderStateMachine.ShouldQueuePolicyChange(MapRecorderState()))
        {
            _pendingPolicyApply = true;
            _logger.LogInformation("Policy change queued until remote view ends");
            return RecorderResult.Skipped(_recorderState, "Policy change queued");
        }

        if (_workSessionActive && (!_recording.IsRunning || _pendingPolicyApply))
        {
            _pendingPolicyApply = false;
            await _recording.RestartAsync("Policy change", ct);
            TransitionCaptureState(CaptureLifecycleState.Recording);
        }

        return RecorderResult.Ok(MapRecorderState());
    }

    private Task<RecorderResult> ExecuteRetryEncoderAsync(CancellationToken ct) =>
        ExecuteRestartResultAsync("Retry encoder", ct);

    private async Task<RecorderResult> ExecuteRestartResultAsync(string reason, CancellationToken ct)
    {
        await _recording.RestartAsync(reason, ct);
        TransitionCaptureState(_recording.IsRunning ? CaptureLifecycleState.Recording : CaptureLifecycleState.Idle);
        return RecorderResult.Ok(MapRecorderState());
    }

    private async Task<RecorderResult> ExecuteRecoverSharedBridgeAsync(RecorderRequestContext context, CancellationToken ct)
    {
        RemoteDiagLog.Event(
            _logger,
            "Lifecycle",
            _remoteView.ActiveSessionId,
            _captureState.ToString(),
            $"RecoverSharedBridge begin reason={context.Reason}");

        if (!_captureCoordinator.IsSharedCaptureActive)
            return RecorderResult.Skipped(MapRecorderState(), "SharedBridge not active");

        if (IsRecordingConsumerRecoveryReason(context.Reason))
            return await ExecuteRecoverRecordingConsumerAsync(context, ct);

        if (string.Equals(context.Reason, "BRIDGE_PIPE_BROKEN", StringComparison.Ordinal))
        {
            // Split ownership:
            // - Recording consumer pipe → Capture lifecycle (unchanged)
            // - Remote consumer pipe + Remote FFmpeg → RemoteView Lifecycle Executor
            // Do not call ReconnectBrokenSharedBridgeConsumersAsync (it mutates Remote pipe
            // outside the RemoteView executor when a remote session is active).
            var health = _captureCoordinator.GetSharedBridgeHealth();
            if (!health.RecordingPipeConnected)
            {
                await _captureCoordinator.ReconnectSharedBridgeConsumerAsync(
                    CaptureConsumer.Recording, ct);
            }

            var remoteSessionActive = _standaloneRemoteActive
                || _remoteView.IsPublishing
                || !string.IsNullOrWhiteSpace(_remoteView.ActiveSessionId);

            if (!health.RemotePipeConnected)
            {
                if (remoteSessionActive)
                {
                    await _remoteView.RequestRecoveryAsync(context.Reason, ct);
                }
                else
                {
                    // Idle remote pipe (no publish session) stays Capture-owned.
                    await _captureCoordinator.ReconnectSharedBridgeConsumerAsync(
                        CaptureConsumer.RemoteView, ct);
                }
            }
            else if (remoteSessionActive && !_remoteView.IsPublishing)
            {
                await _remoteView.RequestRecoveryAsync(context.Reason, ct);
            }

            if (ShouldRecordingBeActive() && !_recording.IsRunning)
            {
                var started = await _recording.TryStartAsync(ct);
                if (!started)
                    return RecorderResult.Failed(MapRecorderState(), "Recording restart failed after pipe reconnect");
            }

            await _captureCoordinator.RestartSharedBridgeProducerAsync(ct);
        }
        else
        {
            await _captureCoordinator.RestartSharedBridgeProducerAsync(ct);
        }

        TransitionCaptureState(CaptureLifecycleState.SharedBridgeRunning);

        RemoteDiagLog.Event(
            _logger,
            "Lifecycle",
            _remoteView.ActiveSessionId,
            _captureState.ToString(),
            $"RecoverSharedBridge complete reason={context.Reason}");

        return RecorderResult.Ok(MapRecorderState(), context.Reason);
    }

    private static bool IsRecordingConsumerRecoveryReason(string? reason) =>
        string.Equals(reason, "RECORDING_CONSUMER_DEAD", StringComparison.Ordinal)
        || string.Equals(reason, "RECORDING_CONSUMER_STALL", StringComparison.Ordinal);

    private static string MapRecordingRecoveryToSharedBridgeReason(string? reason)
    {
        if (string.Equals(reason, "PROCESS_DEAD", StringComparison.Ordinal))
            return "RECORDING_CONSUMER_DEAD";

        if (reason is "NO_FILE_ACTIVITY" or "ENCODER_STALE" or "ENCODER_STALE_AND_NO_FILE_ACTIVITY")
            return "RECORDING_CONSUMER_STALL";

        return reason ?? "RECORDING_CONSUMER_STALL";
    }

    private async Task<RecorderResult> ExecuteRecoverRecordingConsumerAsync(
        RecorderRequestContext context,
        CancellationToken ct)
    {
        var bridge = _captureCoordinator.GetSharedBridgeHealth();
        _logger.LogWarning(
            "RecordingConsumerRecovery: reason={Reason} bridgeFlowing={BridgeFlowing} recPipe={RecPipe} remotePipe={RemotePipe} recordingRunning={RecordingRunning}",
            context.Reason,
            bridge.FrameFlowing,
            bridge.RecordingPipeConnected,
            bridge.RemotePipeConnected,
            _recording.IsRunning);

        if (ShouldRecordingBeActive())
        {
            if (!bridge.RecordingPipeConnected)
                await _captureCoordinator.ReconnectSharedBridgeConsumerAsync(CaptureConsumer.Recording, ct);

            var recovered = await _recording.RecoverForHealthAsync(context.Reason, ct);
            if (!recovered)
            {
                return RecorderResult.Failed(
                    MapRecorderState(),
                    "Recording consumer recovery did not restart recording");
            }
        }

        TransitionCaptureState(CaptureLifecycleState.SharedBridgeRunning);
        return RecorderResult.Ok(MapRecorderState(), context.Reason);
    }

    private async Task<RecorderResult> ExecuteEmergencyStopAsync(CancellationToken ct)
    {
        TransitionCaptureState(CaptureLifecycleState.Stopping);

        if (_standaloneRemoteActive)
        {
            await _remoteView.StopAsync(ct);
            _standaloneRemoteActive = false;
        }

        await TeardownSharedBridgeAsync(ct);
        await _recording.StopAsync(fullShutdown: true, cancellationToken: ct);
        TransitionCaptureState(CaptureLifecycleState.Stopped);
        return RecorderResult.Ok(MapRecorderState());
    }

    private async Task<RecorderResult> ExecuteSystemResumeAsync(CancellationToken ct)
    {
        _lastResumeUtc = DateTime.UtcNow;
        await Task.Delay(5000, ct);
        await _recording.StopAsync(fullShutdown: false, cancellationToken: ct);

        if (_workSessionActive)
        {
            await _recording.RestartAsync("System resume", ct);
            TransitionCaptureState(CaptureLifecycleState.Recording);
        }
        else
        {
            TransitionCaptureState(CaptureLifecycleState.Idle);
        }

        return RecorderResult.Ok(MapRecorderState());
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        SystemEvents.PowerModeChanged += OnPowerModeChanged;
        SystemEvents.SessionSwitch += OnSessionSwitch;
        _lifetime.ApplicationStopping.Register(OnApplicationStopping);

        if (TryGetSyncedPolicy() == null)
        {
            var defaultPolicy = new Policy
            {
                Version = 1,
                Config = JsonSerializer.Deserialize<JsonElement>(
                    @"{
                        ""recording"": {
                            ""enabled"": true,
                            ""fps"": 10,
                            ""enableGpu"": true,
                            ""quality"": 60,
                            ""sliceMinutes"": 1
                        }
                    }")!,
            };

            UpdatePolicy(defaultPolicy);
            _logger.LogWarning("Applied default recording policy (server sync not available)");
        }

        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        SystemEvents.PowerModeChanged -= OnPowerModeChanged;
        SystemEvents.SessionSwitch -= OnSessionSwitch;
        return Task.CompletedTask;
    }

    private Policy? TryGetSyncedPolicy()
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            return scope.ServiceProvider.GetService<PolicySyncService>()?.GetCurrentPolicy();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Policy sync service not available during startup");
            return null;
        }
    }

    private void OnApplicationStopping()
    {
        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(12));
            RequestAsync(
                RecorderCommand.EmergencyStop,
                new RecorderRequestContext { Reason = "Application shutdown" },
                cts.Token).GetAwaiter().GetResult();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Emergency stop during application shutdown failed");
        }
    }

    private void OnPowerModeChanged(object? sender, PowerModeChangedEventArgs e)
    {
        if (e.Mode == PowerModes.Suspend)
        {
            _logger.LogInformation("System entering sleep/suspend, requesting emergency stop");
            try
            {
                using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                RequestAsync(
                    RecorderCommand.EmergencyStop,
                    new RecorderRequestContext { Reason = "System suspend" }).WaitAsync(cts.Token).GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Emergency stop before sleep failed");
            }
        }
        else if (e.Mode == PowerModes.Resume)
        {
            _logger.LogInformation("System resumed from sleep, scheduling lifecycle recovery");
            _ = Task.Run(ResumeAfterSleepAsync);
        }
    }

    private async Task ResumeAfterSleepAsync()
    {
        try
        {
            await Task.Delay(5000);

            try
            {
                using var scope = _scopeFactory.CreateScope();
                var db = scope.ServiceProvider.GetService<SqliteDbContext>();
                db?.InvalidateConnection();

                var uploader = scope.ServiceProvider.GetService<FileUploadService>();
                uploader?.ResetHttpClient();

                var uploadRepo = scope.ServiceProvider.GetService<UploadQueueRepository>();
                if (uploadRepo != null)
                    await uploadRepo.ResetStuckUploadsAsync(TimeSpan.FromMinutes(30));
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Post-resume dependency refresh failed");
            }

            NotifySystemResume();
            await RequestAsync(
                RecorderCommand.SystemResume,
                new RecorderRequestContext { Reason = "System resume" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "System resume lifecycle recovery failed");
        }
    }

    private void OnSessionSwitch(object? sender, SessionSwitchEventArgs e)
    {
        if (e.Reason == SessionSwitchReason.SessionUnlock)
            _logger.LogDebug("Screen unlocked; recording health delegated to HealthCoordinator");
    }

    public void Dispose()
    {
        StopAsync(CancellationToken.None).GetAwaiter().GetResult();
        _intentQueue.DisposeAsync().AsTask().GetAwaiter().GetResult();
        _orchestrationLock.Dispose();
    }

    private static string TruncateDiag(string? value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "-";
        var trimmed = value.Trim();
        return trimmed.Length <= maxLength ? trimmed : trimmed[..maxLength] + "...";
    }
}

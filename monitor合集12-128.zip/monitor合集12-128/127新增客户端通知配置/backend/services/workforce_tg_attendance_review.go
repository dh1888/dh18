package services

import (
	"context"
	"database/sql"
	"fmt"
	"html"
	"strings"
	"time"

	"github.com/google/uuid"
)

const (
	perfReviewDefaultWorkHours  = 5 // 迟到阈值（小时）；JSON 字段仍为 workHours，兼容前端
	perfReviewDefaultEarlyHours = 5 // 早退提前阈值（小时）
	triggerEarlyCheckoutReview  = "early_checkout_review"
	triggerLateCheckinReview    = "late_checkin_review"
)

type AttendanceReviewSettings struct {
	WorkHours  int `json:"workHours"`  // 迟到超过该小时数 → 待确认
	EarlyHours int `json:"earlyHours"` // 早退提前超过该小时数 → 待确认
}

type AttendanceReviewTask struct {
	ID             uuid.UUID `json:"id"`
	EmployeeID     uuid.UUID `json:"employeeId"`
	EmployeeName   string    `json:"employeeName"`
	Position       string    `json:"position"`
	AttendanceDate string    `json:"attendanceDate"`
	ShiftType      string    `json:"shiftType"`
	ChatID         string    `json:"chatId"`
	TriggerType    string    `json:"triggerType"`
	WorkSeconds    int       `json:"workSeconds"`
	EarlyMinutes   int       `json:"earlyMinutes"` // 早退分钟；迟到场景复用为迟到分钟
	ProposedFine   float64   `json:"proposedFine"`
	Status         string    `json:"status"`
	CreatedAt      string    `json:"createdAt"`
}

func clampReviewHours(v int) int {
	if v < 1 {
		return 1
	}
	if v > 24 {
		return 24
	}
	return v
}

func (s *WorkforceTelegramService) GetAttendanceReviewSettings(ctx context.Context) AttendanceReviewSettings {
	out := AttendanceReviewSettings{
		WorkHours:  perfReviewDefaultWorkHours,
		EarlyHours: perfReviewDefaultEarlyHours,
	}
	var val sql.NullString
	if err := s.db.QueryRowContext(ctx, `SELECT value FROM system_settings WHERE key = 'tg_review_work_hours'`).Scan(&val); err == nil && val.Valid {
		if n, err := atoiSafe(strings.TrimSpace(val.String)); err == nil {
			out.WorkHours = clampReviewHours(n)
		}
	}
	val = sql.NullString{}
	if err := s.db.QueryRowContext(ctx, `SELECT value FROM system_settings WHERE key = 'tg_review_early_hours'`).Scan(&val); err == nil && val.Valid {
		if n, err := atoiSafe(strings.TrimSpace(val.String)); err == nil {
			out.EarlyHours = clampReviewHours(n)
		}
	}
	return out
}

func atoiSafe(v string) (int, error) {
	var n int
	_, err := fmt.Sscanf(v, "%d", &n)
	return n, err
}

func (s *WorkforceTelegramService) SaveAttendanceReviewSettings(ctx context.Context, in AttendanceReviewSettings) (AttendanceReviewSettings, error) {
	in.WorkHours = clampReviewHours(in.WorkHours)
	in.EarlyHours = clampReviewHours(in.EarlyHours)
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO system_settings (key, value, updated_at)
		VALUES ('tg_review_work_hours', $1, NOW())
		ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`, fmt.Sprintf("%d", in.WorkHours))
	if err != nil {
		return in, err
	}
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO system_settings (key, value, updated_at)
		VALUES ('tg_review_early_hours', $1, NOW())
		ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`, fmt.Sprintf("%d", in.EarlyHours))
	return in, err
}

func attendanceReviewKeyboard(taskID uuid.UUID) map[string]interface{} {
	id := taskID.String()
	return map[string]interface{}{
		"inline_keyboard": [][]map[string]interface{}{
			{
				{"text": "旷工", "callback_data": "rv:" + id + ":abs"},
				{"text": "半休", "callback_data": "rv:" + id + ":rest"},
				{"text": "半假", "callback_data": "rv:" + id + ":leave"},
			},
		},
	}
}

func (s *WorkforceTelegramService) resolveEmployeeChatID(ctx context.Context, empID uuid.UUID, fallback string) string {
	if strings.TrimSpace(fallback) != "" {
		return strings.TrimSpace(fallback)
	}
	var chatID sql.NullString
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(chat_id,'') FROM employee_telegram_bindings
		WHERE employee_id = $1 AND status = 1
		ORDER BY updated_at DESC NULLS LAST LIMIT 1`, empID).Scan(&chatID)
	return strings.TrimSpace(chatID.String)
}

func (s *WorkforceTelegramService) employeeNameByID(ctx context.Context, empID uuid.UUID) string {
	var name string
	_ = s.db.QueryRowContext(ctx, `SELECT COALESCE(name,'') FROM employees WHERE id = $1`, empID).Scan(&name)
	return name
}

// maybeCreateAttendanceReviewTask：早退提前超过阈值时进入【罚款详情】待确认，未确认前不记罚款。
func (s *WorkforceTelegramService) maybeCreateAttendanceReviewTask(
	ctx context.Context,
	empID uuid.UUID,
	shift, recordDate, chatID string,
	checkinAt, checkoutAt time.Time,
	earlyMin int,
	employeeName string,
) (bool, error) {
	cfg := s.GetAttendanceReviewSettings(ctx)
	workSec := int(checkoutAt.Sub(checkinAt).Seconds())
	if workSec < 0 {
		workSec = 0
	}
	// 仅按「提前下班 ≥ 阈值小时」进入待确认（与迟到阈值相互独立）
	if earlyMin < cfg.EarlyHours*60 {
		return false, nil
	}
	if len(recordDate) < 7 {
		return false, nil
	}
	yearMonth := recordDate[:7]
	chatID = s.resolveEmployeeChatID(ctx, empID, chatID)
	fineMap := s.loadWorkFineMap(ctx, "work_end")
	proposedFine := computeActivityOvertimeFine(fineMap, float64(earlyMin))

	var taskID uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO wf_tg_attendance_review_tasks (
			employee_id, attendance_date, year_month, shift_type, chat_id, trigger_type,
			work_seconds, early_minutes, overtime_threshold_hours, early_threshold_hours, proposed_fine, status, updated_at
		) VALUES ($1, $2::date, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'pending', NOW())
		ON CONFLICT (employee_id, attendance_date, shift_type, trigger_type) DO NOTHING
		RETURNING id`,
		empID, recordDate, yearMonth, shift, chatID, triggerEarlyCheckoutReview,
		workSec, earlyMin, cfg.WorkHours, cfg.EarlyHours, proposedFine,
	).Scan(&taskID)
	if err == sql.ErrNoRows {
		return false, nil
	}
	if err != nil {
		return false, err
	}

	if strings.TrimSpace(chatID) != "" {
		msg := fmt.Sprintf(
			"⚠️ <b>考勤待确认</b>（早退）\n👤 %s\n📅 %s（%s）\n⏱ 上班时长：%s\n🕐 提前下班：%d 分钟\n\n请管理员在【罚款详情】确认：旷工 / 半休 / 半假\n未确认前：不记罚款，不改考勤状态。",
			html.EscapeString(employeeName),
			recordDate, shiftLabel(shift),
			formatDurationZh(workSec), earlyMin,
		)
		msgID, sendErr := s.SendTelegramHTMLReplyReturnID(ctx, chatID, msg, 0, attendanceReviewKeyboard(taskID))
		if sendErr == nil && msgID > 0 {
			_, _ = s.db.ExecContext(ctx, `UPDATE wf_tg_attendance_review_tasks SET tg_message_id = $2, updated_at = NOW() WHERE id = $1`, taskID, msgID)
		}
	}
	NotifyAttendanceReviewPendingUsers(ctx, s.db, taskID, employeeName, recordDate, triggerEarlyCheckoutReview)
	return true, nil
}

// maybeCreateLateCheckinReviewTask：上班迟到超过阈值时进入【罚款详情】待确认，未确认前不记罚款、群消息不显示罚款金额。
func (s *WorkforceTelegramService) maybeCreateLateCheckinReviewTask(
	ctx context.Context,
	empID uuid.UUID,
	shift, recordDate, chatID string,
	lateMin int,
	employeeName string,
) (bool, error) {
	cfg := s.GetAttendanceReviewSettings(ctx)
	if lateMin < cfg.WorkHours*60 {
		return false, nil
	}
	if len(recordDate) < 7 {
		return false, nil
	}
	yearMonth := recordDate[:7]
	chatID = s.resolveEmployeeChatID(ctx, empID, chatID)
	fineMap := s.loadWorkFineMap(ctx, "work_start")
	proposedFine := computeActivityOvertimeFine(fineMap, float64(lateMin))

	var taskID uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO wf_tg_attendance_review_tasks (
			employee_id, attendance_date, year_month, shift_type, chat_id, trigger_type,
			work_seconds, early_minutes, overtime_threshold_hours, early_threshold_hours, proposed_fine, status, updated_at
		) VALUES ($1, $2::date, $3, $4, $5, $6, 0, $7, $8, $9, $10, 'pending', NOW())
		ON CONFLICT (employee_id, attendance_date, shift_type, trigger_type) DO NOTHING
		RETURNING id`,
		empID, recordDate, yearMonth, shift, chatID, triggerLateCheckinReview,
		lateMin, cfg.WorkHours, cfg.EarlyHours, proposedFine,
	).Scan(&taskID)
	if err == sql.ErrNoRows {
		return false, nil
	}
	if err != nil {
		return false, err
	}

	if strings.TrimSpace(chatID) != "" {
		msg := fmt.Sprintf(
			"⚠️ <b>考勤待确认</b>（迟到）\n👤 %s\n📅 %s（%s）\n🕐 迟到：%d 分钟（超过 %d 小时阈值）\n💰 预计旷工罚款：%s\n\n请管理员在【罚款详情】确认：旷工 / 半休 / 半假\n未确认前：不记罚款，不改考勤状态。",
			html.EscapeString(employeeName),
			recordDate, shiftLabel(shift),
			lateMin, cfg.WorkHours,
			FormatFineMoney(proposedFine, s.FineCurrencyCode(ctx)),
		)
		msgID, sendErr := s.SendTelegramHTMLReplyReturnID(ctx, chatID, msg, 0, attendanceReviewKeyboard(taskID))
		if sendErr == nil && msgID > 0 {
			_, _ = s.db.ExecContext(ctx, `UPDATE wf_tg_attendance_review_tasks SET tg_message_id = $2, updated_at = NOW() WHERE id = $1`, taskID, msgID)
		}
	}
	NotifyAttendanceReviewPendingUsers(ctx, s.db, taskID, employeeName, recordDate, triggerLateCheckinReview)
	return true, nil
}

func attendanceReviewPendingHint(kind string) string {
	switch kind {
	case "late":
		return "⚠️ 迟到超过阈值，已进入【罚款详情-待确认】，未确认前不记罚款。"
	case "early":
		return "⚠️ 早退超过阈值，已进入【罚款详情-待确认】，未确认前不记罚款。"
	default:
		return "⚠️ 已进入【罚款详情-待确认】，未确认前不记罚款。"
	}
}

func (s *WorkforceTelegramService) scanAndCreateAttendanceReviewTasks(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return
	}
	loc := tgLoadLocation(settings.Timezone)
	rows, err := s.db.QueryContext(ctx, `
		SELECT ws.employee_id, COALESCE(ws.shift_type,'day'), ws.attendance_date::text,
		       ws.checkin_time, ws.checkout_time, COALESCE(ws.source_chat_id,''), e.name
		FROM work_sessions ws
		JOIN employees e ON e.id = ws.employee_id
		WHERE ws.status = 'closed'
		  AND ws.source IN ('telegram','agent','web')
		  AND ws.checkout_time IS NOT NULL
		  AND ws.checkout_time >= NOW() - INTERVAL '12 hours'`)
	if err != nil {
		return
	}
	defer rows.Close()
	for rows.Next() {
		var empID uuid.UUID
		var shift, recordDate, chatID, empName string
		var checkinAt, checkoutAt time.Time
		if rows.Scan(&empID, &shift, &recordDate, &checkinAt, &checkoutAt, &chatID, &empName) != nil {
			continue
		}
		endClock := settings.DayEnd
		if shift == "night" {
			endClock = settings.NightEnd
		}
		expectedEnd := resolveWorkEndExpectedTime(checkoutAt.In(loc), recordDate, shift, endClock, loc)
		earlyMin := minutesEarlyFromExpected(checkoutAt.In(loc), expectedEnd, 0)
		_, _ = s.maybeCreateAttendanceReviewTask(ctx, empID, shift, recordDate, chatID, checkinAt.In(loc), checkoutAt.In(loc), earlyMin, empName)
	}
}

func (s *WorkforceTelegramService) ListAttendanceReviewTasks(ctx context.Context, month, search string) ([]AttendanceReviewTask, error) {
	month = strings.TrimSpace(month)
	if month == "" {
		month = time.Now().Format("2006-01")
	}
	search = strings.TrimSpace(search)
	args := []interface{}{month}
	where := "t.year_month = $1 AND t.status = 'pending'"
	if search != "" {
		args = append(args, "%"+search+"%")
		where += fmt.Sprintf(" AND e.name ILIKE $%d", len(args))
	}
	rows, err := s.db.QueryContext(ctx, fmt.Sprintf(`
		SELECT t.id, t.employee_id, e.name, COALESCE(e.position,''), t.attendance_date::text,
		       t.shift_type, t.chat_id, t.trigger_type, t.work_seconds, t.early_minutes,
		       COALESCE(t.proposed_fine,0), t.status, t.created_at
		FROM wf_tg_attendance_review_tasks t
		JOIN employees e ON e.id = t.employee_id
		WHERE %s
		ORDER BY t.created_at DESC`, where), args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]AttendanceReviewTask, 0)
	for rows.Next() {
		var item AttendanceReviewTask
		var createdAt time.Time
		if rows.Scan(&item.ID, &item.EmployeeID, &item.EmployeeName, &item.Position, &item.AttendanceDate,
			&item.ShiftType, &item.ChatID, &item.TriggerType, &item.WorkSeconds, &item.EarlyMinutes,
			&item.ProposedFine, &item.Status, &createdAt) != nil {
			continue
		}
		item.CreatedAt = createdAt.Format("2006-01-02 15:04:05")
		out = append(out, item)
	}
	return out, nil
}

func (s *WorkforceTelegramService) confirmAttendanceReviewTask(
	ctx context.Context,
	taskID uuid.UUID,
	decision, actor, source string,
) (string, error) {
	decision = strings.TrimSpace(strings.ToLower(decision))
	if decision != "absent" && decision != "rest_half" && decision != "leave" {
		return "", fmt.Errorf("invalid decision")
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return "", err
	}
	defer tx.Rollback()

	var empID uuid.UUID
	var dateStr, yearMonth, shift, status, triggerType string
	var proposedFine float64
	var reviewChatID string
	var reviewMessageID sql.NullInt64
	if err = tx.QueryRowContext(ctx, `
		SELECT employee_id, attendance_date::text, year_month, COALESCE(shift_type,'day'),
		       status, COALESCE(proposed_fine,0), COALESCE(trigger_type,''),
		       COALESCE(chat_id,''), tg_message_id
		FROM wf_tg_attendance_review_tasks
		WHERE id = $1
		FOR UPDATE`, taskID).Scan(
		&empID, &dateStr, &yearMonth, &shift, &status, &proposedFine, &triggerType,
		&reviewChatID, &reviewMessageID,
	); err != nil {
		return "", err
	}
	if status != "pending" {
		return "该待确认任务已处理", nil
	}
	targetStatus := "work"
	taskStatus := "confirmed"
	switch decision {
	case "absent":
		targetStatus = "absent"
		taskStatus = "confirmed_absent"
	case "rest_half":
		targetStatus = "rest_half"
		taskStatus = "confirmed_rest_half"
	case "leave":
		targetStatus = "leave"
		taskStatus = "confirmed_leave_half"
	}
	if _, err = tx.ExecContext(ctx, `
		UPDATE attendance_records
		SET status = $4, manually_edited = TRUE, updated_at = NOW()
		WHERE employee_id = $1 AND year_month = $2 AND date = $3::date`,
		empID, yearMonth, dateStr, targetStatus); err != nil {
		return "", err
	}
	if _, err = tx.ExecContext(ctx, `
		UPDATE wf_tg_attendance_review_tasks
		SET status = $2, confirmed_by = NULLIF($3,''), confirm_source = NULLIF($4,''),
			confirmed_at = NOW(), updated_at = NOW()
		WHERE id = $1`, taskID, taskStatus, actor, source); err != nil {
		return "", err
	}

	msg := "已确认"
	if decision == "absent" {
		var empName, position string
		_ = tx.QueryRowContext(ctx, `SELECT name, COALESCE(position,'') FROM employees WHERE id = $1`, empID).Scan(&empName, &position)
		reason := fmt.Sprintf("%s早退待确认，管理员确认为旷工", shiftLabel(shift))
		if triggerType == triggerLateCheckinReview {
			reason = fmt.Sprintf("%s上班迟到待确认，管理员确认为旷工", shiftLabel(shift))
		}
		if _, err = tx.ExecContext(ctx, `
			INSERT INTO penalty_records (id, employee_id, employee_name, position, amount, category, reason, penalty_date, created_by, created_at)
			VALUES ($1, $2, $3, $4, $5, 'TG考勤', $6, $7::date, 'telegram', NOW())`,
			uuid.NewString(), empID, empName, position, proposedFine, reason, dateStr); err != nil {
			return "", err
		}
		s.pushAutoPenaltyNotify(ctx, empID, proposedFine, "TG考勤", reason, dateStr)
		msg = fmt.Sprintf("已确认旷工，并记录罚款 %s", FormatFineMoney(proposedFine, s.FineCurrencyCode(ctx)))
	} else if decision == "rest_half" {
		msg = "已确认半休"
	} else if decision == "leave" {
		msg = "已确认半假"
	}
	if err = tx.Commit(); err != nil {
		return "", err
	}
	// Confirmation is already committed; Telegram cleanup is best-effort and
	// must not roll back attendance if the Bot API is temporarily unavailable.
	if reviewMessageID.Valid && reviewMessageID.Int64 > 0 && strings.TrimSpace(reviewChatID) != "" {
		_ = s.RemoveTelegramInlineKeyboard(ctx, reviewChatID, reviewMessageID.Int64)
	}
	return msg, nil
}

func (s *WorkforceTelegramService) ConfirmAttendanceReviewTaskByAdmin(ctx context.Context, taskID uuid.UUID, decision, adminName string) (string, error) {
	return s.confirmAttendanceReviewTask(ctx, taskID, decision, adminName, "admin")
}

func (s *WorkforceTelegramService) ConfirmAttendanceReviewTaskByTelegram(ctx context.Context, taskID uuid.UUID, decision string, telegramUserID int64) (string, error) {
	if telegramUserID <= 0 || !s.IsAdminTelegramUser(ctx, telegramUserID) {
		return "", fmt.Errorf("admin only")
	}
	actor := fmt.Sprintf("tg:%d", telegramUserID)
	return s.confirmAttendanceReviewTask(ctx, taskID, decision, actor, "telegram")
}

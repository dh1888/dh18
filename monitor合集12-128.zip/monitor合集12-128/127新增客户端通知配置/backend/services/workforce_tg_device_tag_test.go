package services

import (
	"testing"

	"github.com/google/uuid"
)

func TestSplitTgDeviceTag(t *testing.T) {
	base, hint := SplitTgDeviceTag("🚽 小厕 · A")
	if base != "🚽 小厕" || hint != "A" {
		t.Fatalf("got base=%q hint=%q", base, hint)
	}
	base, hint = SplitTgDeviceTag("白班上班")
	if base != "白班上班" || hint != "" {
		t.Fatalf("untagged got base=%q hint=%q", base, hint)
	}
}

func TestBuildWorkstationDeviceTagsShortLetters(t *testing.T) {
	id1 := uuid.MustParse("11111111-1111-1111-1111-111111111111")
	id2 := uuid.MustParse("22222222-2222-2222-2222-222222222222")
	tags := buildWorkstationDeviceTags([]workstationTGDevice{
		{ID: id2, Name: "DESKTOP-BBB"},
		{ID: id1, Name: "DESKTOP-AAA"},
	})
	if len(tags) != 2 || tags[0].Tag != "A" || tags[1].Tag != "B" {
		t.Fatalf("tags=%v", tags)
	}
	// Stable by UUID: smaller UUID is A
	if tags[0].Device.ID != id1 || tags[1].Device.ID != id2 {
		t.Fatalf("order by uuid failed: %#v", tags)
	}
	legend := FormatWorkstationDeviceTagLegend(tags)
	if legend != "设备标记：A=DESKTOP-AAA  B=DESKTOP-BBB" {
		t.Fatalf("legend=%q", legend)
	}
}

func TestMatchWorkstationDeviceByHint(t *testing.T) {
	id1 := uuid.MustParse("11111111-1111-1111-1111-111111111111")
	id2 := uuid.MustParse("22222222-2222-2222-2222-222222222222")
	devices := []workstationTGDevice{
		{ID: id1, Name: "DESKTOP-AAA"},
		{ID: id2, Name: "DESKTOP-BBB"},
	}
	got, err := matchWorkstationDeviceByHint(devices, "B")
	if err != nil || got.ID != id2 {
		t.Fatalf("match B failed: got=%v err=%v", got, err)
	}
	got, err = matchWorkstationDeviceByHint(devices, "DESKTOP-AAA")
	if err != nil || got.ID != id1 {
		t.Fatalf("hostname match failed: got=%v err=%v", got, err)
	}
}

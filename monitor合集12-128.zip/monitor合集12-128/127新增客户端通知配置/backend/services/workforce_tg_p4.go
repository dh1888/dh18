package services

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log"
	"math"
	"strings"
	"time"

	"github.com/google/uuid"
)

const defaultHandoverResetThresholdHours = 12.0

func handoverThreshold(cfg *TgHandoverConfigRow) float64 {
	if cfg == nil || cfg.HandoverResetThresholdHours <= 0 {
		return defaultHandoverResetThresholdHours
	}
	return cfg.HandoverResetThresholdHours
}

type TgHandoverConfigRow struct {
	ChatID                string
	HandoverEnabled       bool
	HandoverDay           int
	HandoverMonth         int
	HandoverDayStartTime  string
	NightStartTime        string
	DayStartTime          string
	HandoverNightHours    int
	HandoverDayHours      int
	NormalNightHours           int
	NormalDayHours             int
	HandoverResetThresholdHours float64
	UpdatedAt                  time.Time
}

type TgWorkFine struct {
	ID             uuid.UUID
	CheckinType    string
	SegmentMinutes int
	FineAmount     float64
}

type TgSharedWorkstationMember struct {
	DeviceID     uuid.UUID
	DeviceName   string
	EmployeeID   uuid.UUID
	EmployeeName string
	EmployeeCode string
}

type TgPeriodInfo struct {
	PeriodType   string
	BusinessDate string
	HandoverDate string
	IsHandover   bool
	Cycle        int
	TotalHours   float64
	HoursElapsed float64
}

type CheckInOutcome struct {
	Result         *CheckInResult
	WorkFine       float64
	HandoverHint   string
	GroupReplyHTML string
}

type CheckOutOutcome struct {
	Result         *CheckOutResult
	WorkFine       float64
	ShiftType      string
	HandoverHint   string
	ActivityWarn   string
	GroupReplyHTML string
}

func normalizeShiftType(shift string) (string, error) {
	raw := strings.TrimSpace(shift)
	shift = strings.ToLower(raw)
	switch shift {
	case "", "day", "白班", "白班上班":
		return "day", nil
	case "middle", "mid", "中班", "中班上班":
		return "middle", nil
	case "night", "夜班", "夜班上班":
		return "night", nil
	default:
		// Chinese labels are unchanged by ToLower; accept raw forms too.
		switch raw {
		case "白班", "白班上班":
			return "day", nil
		case "中班", "中班上班":
			return "middle", nil
		case "夜班", "夜班上班":
			return "night", nil
		}
		return "", fmt.Errorf("invalid shift: %s", shift)
	}
}

func (s *WorkforceTelegramService) loadExtendedSettings(ctx context.Context) (*TelegramSettings, bool, int, bool, error) {
	base, err := s.GetSettings(ctx)
	if err != nil {
		return nil, false, 0, false, err
	}
	var shiftWindowDisabled, requirePCLogin bool
	var workEndGrace int
	err = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_window_disabled, FALSE), COALESCE(work_end_grace_minutes, 5), COALESCE(require_pc_login, TRUE)
		FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).
		Scan(&shiftWindowDisabled, &workEndGrace, &requirePCLogin)
	return base, shiftWindowDisabled, workEndGrace, requirePCLogin, err
}

func (s *WorkforceTelegramService) defaultHandoverConfig(chatID string) *TgHandoverConfigRow {
	return &TgHandoverConfigRow{
		ChatID: chatID, HandoverEnabled: true, HandoverDay: 31, HandoverMonth: 0,
		HandoverDayStartTime: "15:00", NightStartTime: "21:00", DayStartTime: "09:00",
		HandoverNightHours: 18, HandoverDayHours: 18, NormalNightHours: 12, NormalDayHours: 12,
		HandoverResetThresholdHours: defaultHandoverResetThresholdHours,
	}
}

func (s *WorkforceTelegramService) GetHandoverConfig(ctx context.Context, chatID string) (*TgHandoverConfigRow, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return s.defaultHandoverConfig(""), nil
	}
	row := s.defaultHandoverConfig(chatID)
	err := s.db.QueryRowContext(ctx, `
		SELECT chat_id, handover_enabled, handover_day, handover_month,
			handover_day_start_time, night_start_time, day_start_time,
			handover_night_hours, handover_day_hours, normal_night_hours, normal_day_hours,
			handover_reset_threshold_hours, updated_at
		FROM wf_tg_handover_configs WHERE chat_id = $1`, chatID).
		Scan(&row.ChatID, &row.HandoverEnabled, &row.HandoverDay, &row.HandoverMonth,
			&row.HandoverDayStartTime, &row.NightStartTime, &row.DayStartTime,
			&row.HandoverNightHours, &row.HandoverDayHours, &row.NormalNightHours, &row.NormalDayHours,
			&row.HandoverResetThresholdHours, &row.UpdatedAt)
	if err == sql.ErrNoRows {
		_, _ = s.db.ExecContext(ctx, `
			INSERT INTO wf_tg_handover_configs (chat_id) VALUES ($1) ON CONFLICT (chat_id) DO NOTHING`, chatID)
		return s.defaultHandoverConfig(chatID), nil
	}
	if err != nil {
		return nil, err
	}
	return row, nil
}

func (s *WorkforceTelegramService) UpsertHandoverConfig(ctx context.Context, chatID string, in map[string]interface{}) (*TgHandoverConfigRow, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return nil, fmt.Errorf("chatId required")
	}
	current, err := s.GetHandoverConfig(ctx, chatID)
	if err != nil {
		return nil, err
	}
	if v, ok := in["handoverEnabled"].(bool); ok {
		current.HandoverEnabled = v
	}
	if v, ok := in["handoverDay"].(float64); ok {
		current.HandoverDay = int(v)
	}
	if v, ok := in["handoverMonth"].(float64); ok {
		current.HandoverMonth = int(v)
	}
	if v, ok := in["handoverDayStartTime"].(string); ok && strings.TrimSpace(v) != "" {
		current.HandoverDayStartTime = strings.TrimSpace(v)
	}
	if v, ok := in["nightStartTime"].(string); ok && strings.TrimSpace(v) != "" {
		current.NightStartTime = strings.TrimSpace(v)
	}
	if v, ok := in["dayStartTime"].(string); ok && strings.TrimSpace(v) != "" {
		current.DayStartTime = strings.TrimSpace(v)
	}
	for _, pair := range []struct {
		key string
		ptr *int
	}{
		{"handoverNightHours", &current.HandoverNightHours},
		{"handoverDayHours", &current.HandoverDayHours},
		{"normalNightHours", &current.NormalNightHours},
		{"normalDayHours", &current.NormalDayHours},
	} {
		if v, ok := in[pair.key].(float64); ok {
			*pair.ptr = int(v)
		}
	}
	if v, ok := in["handoverResetThresholdHours"].(float64); ok && v > 0 {
		current.HandoverResetThresholdHours = v
	}
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_handover_configs (
			chat_id, handover_enabled, handover_day, handover_month,
			handover_day_start_time, night_start_time, day_start_time,
			handover_night_hours, handover_day_hours, normal_night_hours, normal_day_hours,
			handover_reset_threshold_hours, updated_at
		) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,NOW())
		ON CONFLICT (chat_id) DO UPDATE SET
			handover_enabled = EXCLUDED.handover_enabled,
			handover_day = EXCLUDED.handover_day,
			handover_month = EXCLUDED.handover_month,
			handover_day_start_time = EXCLUDED.handover_day_start_time,
			night_start_time = EXCLUDED.night_start_time,
			day_start_time = EXCLUDED.day_start_time,
			handover_night_hours = EXCLUDED.handover_night_hours,
			handover_day_hours = EXCLUDED.handover_day_hours,
			normal_night_hours = EXCLUDED.normal_night_hours,
			normal_day_hours = EXCLUDED.normal_day_hours,
			handover_reset_threshold_hours = EXCLUDED.handover_reset_threshold_hours,
			updated_at = NOW()`,
		chatID, current.HandoverEnabled, current.HandoverDay, current.HandoverMonth,
		current.HandoverDayStartTime, current.NightStartTime, current.DayStartTime,
		current.HandoverNightHours, current.HandoverDayHours, current.NormalNightHours, current.NormalDayHours,
		current.HandoverResetThresholdHours)
	if err != nil {
		return nil, err
	}
	return s.GetHandoverConfig(ctx, chatID)
}

func isHandoverDate(d time.Time, handoverDay, handoverMonth int) bool {
	if handoverDay == 0 {
		firstOfNext := time.Date(d.Year(), d.Month()+1, 1, 0, 0, 0, 0, d.Location())
		lastDay := firstOfNext.AddDate(0, 0, -1).Day()
		return d.Day() == lastDay
	}
	if handoverMonth == 0 {
		return d.Day() == handoverDay
	}
	return int(d.Month()) == handoverMonth && d.Day() == handoverDay
}

func combineDateTime(d time.Time, clock string, loc *time.Location) time.Time {
	h, m, ok := parseClock(clock)
	if !ok {
		h, m = 0, 0
	}
	return time.Date(d.Year(), d.Month(), d.Day(), h, m, 0, 0, loc)
}

func (s *WorkforceTelegramService) DetermineCurrentPeriod(ctx context.Context, chatID string, now time.Time) (*TgPeriodInfo, error) {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return nil, err
	}
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	cfg, err := s.GetHandoverConfig(ctx, chatID)
	if err != nil {
		return nil, err
	}
	if !cfg.HandoverEnabled {
		return s.buildNormalPeriod(now, cfg, loc)
	}
	currentDate := now
	for _, offset := range []int{0, -1, 1} {
		checkDate := currentDate.AddDate(0, 0, offset)
		if !isHandoverDate(checkDate, cfg.HandoverDay, cfg.HandoverMonth) {
			continue
		}
		if p := s.resolveHandoverPeriodForDate(now, checkDate, cfg, loc); p != nil {
			return p, nil
		}
	}
	return s.buildNormalPeriod(now, cfg, loc)
}

func (s *WorkforceTelegramService) resolveHandoverPeriodForDate(now, handoverDate time.Time, cfg *TgHandoverConfigRow, loc *time.Location) *TgPeriodInfo {
	nightStart := combineDateTime(handoverDate.AddDate(0, 0, -1), cfg.NightStartTime, loc)
	nightEnd := combineDateTime(handoverDate, cfg.HandoverDayStartTime, loc)
	dayStart := nightEnd
	dayEnd := combineDateTime(handoverDate.AddDate(0, 0, 1), cfg.DayStartTime, loc)

	if !now.Before(nightStart) && now.Before(nightEnd) {
		return s.buildHandoverNightPeriod(now, nightStart, handoverDate, cfg)
	}
	if !now.Before(dayStart) && now.Before(dayEnd) {
		return s.buildHandoverDayPeriod(now, dayStart, handoverDate, cfg)
	}
	return nil
}

func (s *WorkforceTelegramService) buildHandoverNightPeriod(now, start time.Time, handoverDate time.Time, cfg *TgHandoverConfigRow) *TgPeriodInfo {
	elapsed := now.Sub(start).Hours()
	total := float64(cfg.HandoverNightHours)
	cycle := 1
	if elapsed >= handoverThreshold(cfg) {
		cycle = 2
	}
	return &TgPeriodInfo{
		PeriodType:   "handover_night",
		BusinessDate: handoverDate.AddDate(0, 0, -1).Format("2006-01-02"),
		HandoverDate: handoverDate.Format("2006-01-02"),
		IsHandover:   true,
		Cycle:        cycle,
		TotalHours:   total,
		HoursElapsed: elapsed,
	}
}

func (s *WorkforceTelegramService) buildHandoverDayPeriod(now, start time.Time, handoverDate time.Time, cfg *TgHandoverConfigRow) *TgPeriodInfo {
	elapsed := now.Sub(start).Hours()
	total := float64(cfg.HandoverDayHours)
	cycle := 1
	if elapsed >= handoverThreshold(cfg) {
		cycle = 2
	}
	return &TgPeriodInfo{
		PeriodType:   "handover_day",
		BusinessDate: handoverDate.Format("2006-01-02"),
		HandoverDate: handoverDate.Format("2006-01-02"),
		IsHandover:   true,
		Cycle:        cycle,
		TotalHours:   total,
		HoursElapsed: elapsed,
	}
}

func (s *WorkforceTelegramService) buildNormalPeriod(now time.Time, cfg *TgHandoverConfigRow, loc *time.Location) (*TgPeriodInfo, error) {
	dec := float64(now.Hour()) + float64(now.Minute())/60.0
	nh, nm, _ := parseClock(cfg.NightStartTime)
	dh, dm, _ := parseClock(cfg.DayStartTime)
	nightDec := float64(nh) + float64(nm)/60.0
	dayDec := float64(dh) + float64(dm)/60.0

	if dec >= nightDec || dec < dayDec {
		var start time.Time
		businessDate := now
		if dec >= nightDec {
			start = combineDateTime(now, cfg.NightStartTime, loc)
		} else {
			businessDate = now.AddDate(0, 0, -1)
			start = combineDateTime(businessDate, cfg.NightStartTime, loc)
		}
		elapsed := now.Sub(start).Hours()
		return &TgPeriodInfo{
			PeriodType:   "normal_night",
			BusinessDate: businessDate.Format("2006-01-02"),
			IsHandover:   false,
			Cycle:        1,
			TotalHours:   float64(cfg.NormalNightHours),
			HoursElapsed: elapsed,
		}, nil
	}
	start := combineDateTime(now, cfg.DayStartTime, loc)
	return &TgPeriodInfo{
		PeriodType:   "normal_day",
		BusinessDate: now.Format("2006-01-02"),
		IsHandover:   false,
		Cycle:        1,
		TotalHours:   float64(cfg.NormalDayHours),
		HoursElapsed: now.Sub(start).Hours(),
	}, nil
}

func (s *WorkforceTelegramService) telegramCheckInExplicit(ctx context.Context, empID uuid.UUID, telegramUserID int64, chatID, forcedShift string, actor *TelegramActor) (*CheckInOutcome, error) {
	settings, shiftWindowDisabled, _, requirePCLogin, err := s.loadExtendedSettings(ctx)
	if err != nil {
		return nil, err
	}
	grace, _ := s.GetGraceConfig(ctx, chatID)
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)

	if err := s.validatePCLoginForEmployee(ctx, empID, requirePCLogin, actor); err != nil {
		return nil, err
	}
	if _, err := s.closeExpiredWorkSessionsForEmployee(ctx, empID, chatID); err != nil {
		log.Printf("[Telegram] close expired shifts emp=%s: %v", empID, err)
	}

	period, err := s.DetermineCurrentPeriod(ctx, chatID, now)
	if err != nil {
		return nil, err
	}

	shift, shiftDetail, err := s.resolveShiftForCheckIn(settings, grace, shiftWindowDisabled, forcedShift, now)
	if err != nil {
		return nil, err
	}
	if err := s.validateRelayNightBlock(ctx, chatID, shift, now); err != nil {
		return nil, err
	}

	recordDate := resolveAttendanceDate(shift, shiftDetail, period, now, loc)

	if err := s.validateNoConflictingOpenWorkSession(ctx, empID, shift, shiftDetail, recordDate); err != nil {
		return nil, err
	}

	done, err := s.hasCompletedShiftOnDate(ctx, empID, recordDate, shift)
	if err != nil {
		return nil, err
	}
	if done {
		return nil, ErrShiftAlreadyCompleted
	}

	if err := s.autoEndActivityIfCrossShift(ctx, empID, shift, recordDate); err != nil {
		return nil, err
	}

	var startClock string
	if shift == "night" {
		startClock = settings.NightStart
		if period.IsHandover {
			cfg, _ := s.GetHandoverConfig(ctx, chatID)
			if cfg != nil {
				startClock = cfg.NightStartTime
			}
		}
	} else {
		startClock = settings.DayStart
		if period.IsHandover && strings.Contains(period.PeriodType, "handover_day") {
			cfg, _ := s.GetHandoverConfig(ctx, chatID)
			if cfg != nil {
				startClock = cfg.HandoverDayStartTime
			}
		}
	}
	lateMin := minutesLateFromExpected(now, resolveWorkStartExpectedTime(now, recordDate, shift, shiftDetail, startClock, loc), grace.LateTolerance)
	fineReason := fmt.Sprintf("%s上班迟到 %d 分钟", shiftLabel(shift)+shiftDetailLabel(shiftDetail), lateMin)

	result, err := s.workforce.CheckInForEmployee(ctx, empID, resolvePunchSource(actor, PunchSourceTelegram), nil, &CheckInOptions{
		ShiftType:   shift,
		RecordDate:  recordDate,
		ShiftDetail: shiftDetail,
	})
	if err != nil {
		return nil, err
	}

	workFine := 0.0
	empName := ""
	_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, empID).Scan(&empName)
	createdReview, _ := s.maybeCreateLateCheckinReviewTask(ctx, empID, shift, recordDate, chatID, lateMin, empName)
	if !createdReview {
		workFine, _ = s.applyWorkFine(ctx, empID, "work_start", lateMin, recordDate, fineReason)
	}
	if chatID != "" {
		_ = s.setGroupShiftState(ctx, chatID, empID, shift, recordDate)
	}
	result.ShiftType = shift
	s.syncAgentWorkInFromTelegram(ctx, empID, result.SessionID, actor)

	activitySec := s.sumTodayActivitySeconds(ctx, empID, recordDate, shift)

	hint := s.handoverStatusHint(ctx, chatID, period)
	hint += s.buildRelaySuccessorHintAfterCheckIn(ctx, empID, chatID, shift, recordDate, now)
	expected := resolveWorkStartExpectedTime(now, recordDate, shift, shiftDetail, startClock, loc)
	groupReply := buildWorkStartGroupReplyHTML(
		telegramUserID, empName, shift, shiftDetail, now, expected, lateMin, workFine, strings.TrimSpace(hint),
		s.FineCurrencyCode(ctx),
	)
	if createdReview {
		groupReply += "\n\n" + attendanceReviewPendingHint("late")
	}
	s.NotifyWorkExceptionPushHTML(ctx, chatID, empID, empName, shiftLabel(shift)+shiftDetailLabel(shiftDetail), "上班", workFine, lateMin, 0, activitySec, groupReply, "")
	return &CheckInOutcome{
		Result:         result,
		WorkFine:       workFine,
		HandoverHint:   strings.TrimSpace(hint),
		GroupReplyHTML: groupReply,
	}, nil
}

func (s *WorkforceTelegramService) validatePCLoginForEmployee(ctx context.Context, empID uuid.UUID, requirePCLogin bool, actor *TelegramActor) error {
	// Web-only mode: admin console punch must not require PC Agent login.
	if actor != nil && actor.PunchSource == PunchSourceWeb && s.IsWebPunchOnly(ctx) {
		return nil
	}
	if actor != nil && actor.Channel == TelegramChannelWorkstation {
		if actor.DeviceID == uuid.Nil {
			return ErrPCLoginRequired
		}
		loggedIn, err := s.resolveWorkstationLoggedInEmployee(ctx, actor.DeviceID)
		if err != nil {
			return err
		}
		if loggedIn != empID {
			return ErrPCLoginMismatch
		}
		return nil
	}
	needPC, err := s.employeeRequiresPCLogin(ctx, empID, requirePCLogin)
	if err != nil {
		return err
	}
	if !needPC {
		return nil
	}
	deviceID, err := s.findDeviceForEmployee(ctx, empID)
	if err != nil || deviceID == uuid.Nil {
		return ErrPCLoginRequired
	}
	var loggedIn uuid.UUID
	var sessionAt sql.NullTime
	err = s.db.QueryRowContext(ctx, `
		SELECT employee_uuid, employee_session_at FROM devices WHERE id = $1`, deviceID).
		Scan(&loggedIn, &sessionAt)
	if err != nil || !sessionAt.Valid || loggedIn == uuid.Nil {
		return ErrPCLoginRequired
	}
	if loggedIn != empID {
		return ErrPCLoginMismatch
	}
	return nil
}

func (s *WorkforceTelegramService) findDeviceForEmployee(ctx context.Context, empID uuid.UUID) (uuid.UUID, error) {
	var deviceID uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM devices
		WHERE employee_uuid = $1 AND LOWER(status) = 'approved' AND employee_session_at IS NOT NULL
		ORDER BY last_seen_at DESC NULLS LAST LIMIT 1`, empID).Scan(&deviceID)
	if err == nil && deviceID != uuid.Nil {
		return deviceID, nil
	}
	err = s.db.QueryRowContext(ctx, `
		SELECT m.device_id FROM wf_shared_workstation_members m
		JOIN devices d ON d.id = m.device_id AND LOWER(d.status) = 'approved'
		WHERE m.employee_id = $1
		ORDER BY d.last_seen_at DESC NULLS LAST LIMIT 1`, empID).Scan(&deviceID)
	if err == nil && deviceID != uuid.Nil {
		return deviceID, nil
	}
	err = s.db.QueryRowContext(ctx, `
		SELECT id FROM devices
		WHERE employee_uuid = $1 AND LOWER(status) = 'approved'
		ORDER BY last_seen_at DESC NULLS LAST LIMIT 1`, empID).Scan(&deviceID)
	if err == sql.ErrNoRows {
		return uuid.Nil, ErrWorkstationNotConfigured
	}
	return deviceID, err
}

func (s *WorkforceTelegramService) setGroupShiftState(ctx context.Context, chatID string, empID uuid.UUID, shift, recordDate string) error {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" || empID == uuid.Nil {
		return nil
	}
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_group_shift_state (chat_id, employee_id, shift_type, record_date, updated_at)
		VALUES ($1, $2, $3, $4::date, NOW())
		ON CONFLICT (chat_id, employee_id, shift_type) DO UPDATE SET
			record_date = EXCLUDED.record_date, updated_at = NOW()`,
		chatID, empID, shift, recordDate)
	return err
}

func (s *WorkforceTelegramService) clearGroupShiftState(ctx context.Context, chatID string, empID uuid.UUID, shift string) {
	if chatID == "" || empID == uuid.Nil {
		return
	}
	_, _ = s.db.ExecContext(ctx, `
		DELETE FROM wf_tg_group_shift_state WHERE chat_id = $1 AND employee_id = $2 AND shift_type = $3`,
		chatID, empID, shift)
}

func (s *WorkforceTelegramService) loadWorkFineMap(ctx context.Context, checkinType string) map[int]float64 {
	rows, err := s.db.QueryContext(ctx, `
		SELECT segment_minutes, fine_amount FROM wf_tg_work_fines WHERE checkin_type = $1 ORDER BY segment_minutes`, checkinType)
	if err != nil {
		return nil
	}
	defer rows.Close()
	out := make(map[int]float64)
	for rows.Next() {
		var seg int
		var amt float64
		if rows.Scan(&seg, &amt) == nil {
			out[seg] = amt
		}
	}
	return out
}

func minutesAfterScheduled(now time.Time, clock string, grace int, loc *time.Location) int {
	now = now.In(loc)
	start := combineDateTime(now, clock, loc)
	return minutesLateFromExpected(now, start, grace)
}

// truncateToClockMinute drops seconds/nanos so late/early matches displayed HH:mm clock difference.
func truncateToClockMinute(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), t.Minute(), 0, 0, t.Location())
}

func minutesLateFromExpected(now, expected time.Time, grace int) int {
	now = now.In(expected.Location())
	deadline := expected.Add(time.Duration(grace) * time.Minute)
	nowMin := truncateToClockMinute(now)
	deadlineMin := truncateToClockMinute(deadline)
	if !nowMin.After(deadlineMin) {
		return 0
	}
	late := int(nowMin.Sub(deadlineMin) / time.Minute)
	if late < 0 {
		return 0
	}
	return late
}

func minutesBeforeScheduled(now time.Time, clock string, grace int, loc *time.Location) int {
	now = now.In(loc)
	end := combineDateTime(now, clock, loc)
	return minutesEarlyFromExpected(now, end, grace)
}

func minutesEarlyFromExpected(now, expectedEnd time.Time, grace int) int {
	now = now.In(expectedEnd.Location())
	allowed := expectedEnd.Add(-time.Duration(grace) * time.Minute)
	nowMin := truncateToClockMinute(now)
	allowedMin := truncateToClockMinute(allowed)
	if !nowMin.Before(allowedMin) {
		return 0
	}
	early := int(allowedMin.Sub(nowMin) / time.Minute)
	if early < 0 {
		return 0
	}
	return early
}

func (s *WorkforceTelegramService) applyWorkFine(ctx context.Context, empID uuid.UUID, checkinType string, lateMinutes int, penaltyDate, reason string) (float64, error) {
	if lateMinutes <= 0 {
		return 0, nil
	}
	fineMap := s.loadWorkFineMap(ctx, checkinType)
	amount := computeActivityOvertimeFine(fineMap, float64(lateMinutes))
	if amount <= 0 {
		return 0, nil
	}
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO penalty_records (id, employee_id, employee_name, position, amount, category, reason, penalty_date, created_by, created_at)
		SELECT $1, e.id, e.name, COALESCE(e.position,''), $2, 'TG考勤', $3, $4::date, 'telegram', NOW()
		FROM employees e WHERE e.id = $5`,
		uuid.NewString(), amount, reason, penaltyDate, empID)
	if err != nil {
		return amount, err
	}
	s.pushAutoPenaltyNotify(ctx, empID, amount, "TG考勤", reason, penaltyDate)
	return amount, nil
}

func (s *WorkforceTelegramService) hasCompletedShiftOnDate(ctx context.Context, empID uuid.UUID, date, shift string) (bool, error) {
	var count int
	err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM work_sessions
		WHERE employee_id = $1 AND attendance_date = $2::date AND shift_type = $3 AND status = 'closed'`,
		empID, date, shift).Scan(&count)
	return count > 0, err
}

func (s *WorkforceTelegramService) getHandoverDayRelayHandoverDate(ctx context.Context, chatID string, now time.Time) string {
	period, err := s.DetermineCurrentPeriod(ctx, chatID, now)
	if err != nil || period == nil || period.PeriodType != "handover_day" || period.HandoverDate == "" {
		return ""
	}
	settings, _ := s.GetSettings(ctx)
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	if now.Format("2006-01-02") <= period.HandoverDate {
		return ""
	}
	return period.HandoverDate
}

func (s *WorkforceTelegramService) handoverStatusHint(ctx context.Context, chatID string, period *TgPeriodInfo) string {
	if period == nil || !period.IsHandover {
		return ""
	}
	cfg, _ := s.GetHandoverConfig(ctx, chatID)
	threshold := handoverThreshold(cfg)
	if period.Cycle == 1 {
		remaining := math.Max(0, threshold-period.HoursElapsed)
		return fmt.Sprintf("🔄 换班日（%.0f小时制）· 第1段 · 约 %.1fh 后活动次数重置", period.TotalHours, remaining)
	}
	return fmt.Sprintf("🔄 换班日（%.0f小时制）· 第2段 · 活动次数已重置", period.TotalHours)
}

func checkoutSourceForForce(sessionSource, finePrefix string) string {
	if strings.TrimSpace(finePrefix) != "" {
		return CheckoutSourceSystem
	}
	source := strings.TrimSpace(sessionSource)
	if source == "" {
		return CheckoutSourceSystem
	}
	return source
}

func (s *WorkforceTelegramService) forceCheckoutWorkSessionAt(ctx context.Context, sessionID uuid.UUID, chatID string, checkoutAt time.Time, finePrefix string) error {
	return s.forceCheckoutWorkSessionAtWithOptions(ctx, sessionID, chatID, checkoutAt, finePrefix, false)
}

// forceCheckoutWorkSessionAtWithOptions closes an open work session at checkoutAt.
// When skipFine is true (e.g. employee daily reset), no early-leave fine or review task is created.
func (s *WorkforceTelegramService) forceCheckoutWorkSessionAtWithOptions(ctx context.Context, sessionID uuid.UUID, chatID string, checkoutAt time.Time, finePrefix string, skipFine bool) error {
	var empID uuid.UUID
	var shift, recordDate, sessionSource string
	var checkin time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT employee_id, COALESCE(shift_type,'day'), attendance_date::text, checkin_time, COALESCE(source,'')
		FROM work_sessions WHERE id = $1 AND status = 'open'`, sessionID).
		Scan(&empID, &shift, &recordDate, &checkin, &sessionSource)
	if err == sql.ErrNoRows {
		return nil
	}
	if err != nil {
		return err
	}

	settings, _, _, _, err := s.loadExtendedSettings(ctx)
	if err != nil {
		return err
	}
	grace, _ := s.GetGraceConfig(ctx, chatID)
	loc := tgLoadLocation(settings.Timezone)
	checkoutAt = checkoutAt.In(loc)

	endClock := shiftEndClock(settings, shift)
	expectedEnd := resolveWorkEndExpectedTime(checkoutAt, recordDate, shift, endClock, loc)
	earlyMin := minutesEarlyFromExpected(checkoutAt, expectedEnd, grace.EarlyLeaveTolerance)
	fineReason := fmt.Sprintf("%s下班早退 %d 分钟", shiftLabel(shift), earlyMin)
	if p := strings.TrimSpace(finePrefix); p != "" {
		fineReason = p + " " + fineReason
	}

	yearMonth := recordDate[:7]
	if len(recordDate) < 7 {
		yearMonth = checkoutAt.Format("2006-01")
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	if _, err = tx.ExecContext(ctx, `
		UPDATE work_sessions SET status = 'closed', checkout_time = $2, updated_at = NOW()
		WHERE id = $1 AND status = 'open'`, sessionID, checkoutAt); err != nil {
		return err
	}
	if _, err = tx.ExecContext(ctx, `
		UPDATE attendance_records SET
			status = CASE
				WHEN manually_edited THEN status
				WHEN status IN ('leave','absent','rest_full','rest_half','off_post','resigned') THEN status
				ELSE 'work' END,
			checkout_time = CASE WHEN manually_edited THEN checkout_time ELSE $4 END,
			checkout_source = CASE
				WHEN manually_edited THEN checkout_source
				WHEN $5 != '' THEN $5
				ELSE checkout_source END,
			shift_type = CASE
				WHEN manually_edited THEN shift_type
				WHEN COALESCE(NULLIF(TRIM($6), ''), '') = '' THEN shift_type
				ELSE $6 END,
			activity_seconds = CASE
				WHEN manually_edited THEN activity_seconds
				ELSE COALESCE((
					SELECT SUM(a.elapsed_seconds)::int
					FROM wf_tg_activity_sessions a
					WHERE a.employee_id = $1 AND a.attendance_date = $3::date AND a.status = 'closed'
				), 0) END,
			updated_at = NOW()
		WHERE employee_id = $1 AND year_month = $2 AND date = $3`,
		empID, yearMonth, recordDate, checkoutAt, checkoutSourceForForce(sessionSource, finePrefix), shift); err != nil {
		return err
	}
	if err = tx.Commit(); err != nil {
		return err
	}

	workFine := 0.0
	if !skipFine {
		createdReview, _ := s.maybeCreateAttendanceReviewTask(ctx, empID, shift, recordDate, chatID, checkin.In(loc), checkoutAt, earlyMin, s.employeeNameByID(ctx, empID))
		if !createdReview {
			workFine, _ = s.applyWorkFine(ctx, empID, "work_end", earlyMin, recordDate, fineReason)
		}
	}
	s.SyncAgentCaptureStop(ctx, empID, sessionID)
	s.SyncAgentTelegramCheckOutNotify(ctx, empID, sessionID)
	s.SyncAgentWorkSessionState(ctx, empID, false, sessionID, sessionSource)
	if chatID != "" {
		s.clearGroupShiftState(ctx, chatID, empID, shift)
		s.maybeBroadcastShiftEnd(ctx, chatID, shift, recordDate)
	}
	if workFine > 0 {
		log.Printf("[Telegram] force checkout session=%s fine=%.2f", sessionID, workFine)
	}
	return nil
}

func (s *WorkforceTelegramService) telegramCheckOutFIFO(ctx context.Context, empID uuid.UUID, telegramUserID int64, chatID string, actor *TelegramActor) (*CheckOutOutcome, error) {
	settings, shiftWindowDisabled, _, _, err := s.loadExtendedSettings(ctx)
	if err != nil {
		return nil, err
	}
	grace, _ := s.GetGraceConfig(ctx, chatID)
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)

	openSID := s.openWorkSessionIDFIFO(ctx, empID)
	if openSID == uuid.Nil {
		return nil, ErrNoOpenSession
	}

	var shift, recordDate string
	var checkin time.Time
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day'), attendance_date::text, checkin_time FROM work_sessions WHERE id = $1`, openSID).
		Scan(&shift, &recordDate, &checkin)

	if err := s.validateCheckOutWindow(settings, grace, shiftWindowDisabled, shift, recordDate, now); err != nil {
		return nil, err
	}

	activityWarn := s.buildCrossShiftActivityWarn(ctx, empID, shift, recordDate)

	endClock := shiftEndClock(settings, shift)
	expectedEnd := resolveWorkEndExpectedTime(now, recordDate, shift, endClock, loc)
	earlyMin := minutesEarlyFromExpected(now, expectedEnd, grace.EarlyLeaveTolerance)
	fineReason := fmt.Sprintf("%s下班早退 %d 分钟", shiftLabel(shift), earlyMin)

	result, err := s.workforce.CheckOutForEmployee(ctx, empID, resolvePunchSource(actor, PunchSourceTelegram), nil, &openSID, &CheckOutOptions{ShiftType: shift})
	if err != nil {
		return nil, err
	}
	empName := s.employeeNameByID(ctx, empID)
	workFine := 0.0
	workSec := int(math.Max(0, now.Sub(checkin).Seconds()))
	createdReview, _ := s.maybeCreateAttendanceReviewTask(ctx, empID, shift, recordDate, chatID, checkin, now, earlyMin, empName)
	if !createdReview {
		workFine, _ = s.applyWorkFine(ctx, empID, "work_end", earlyMin, recordDate, fineReason)
	}

	s.syncAgentWorkOutFromTelegram(ctx, empID, openSID, actor, resolvePunchSource(actor, PunchSourceTelegram))
	if chatID != "" {
		s.clearGroupShiftState(ctx, chatID, empID, shift)
		s.maybeBroadcastShiftEnd(ctx, chatID, shift, recordDate)
	}
	if result != nil {
		result.ShiftType = shift
	}

	activitySec := s.sumTodayActivitySeconds(ctx, empID, recordDate, shift)
	if period, err := s.DetermineCurrentPeriod(ctx, chatID, now); err == nil {
		s.bumpHandoverCycleWork(ctx, chatID, empID, period, workSec)
	}
	handoverHint := s.buildRelayCheckoutHint(ctx, chatID, empID, shift, recordDate, now)
	groupReply := buildWorkEndGroupReplyHTML(
		telegramUserID, empName, shift, now, expectedEnd, earlyMin, workFine, handoverHint, activityWarn,
		s.FineCurrencyCode(ctx),
	)
	if createdReview {
		groupReply += "\n\n" + attendanceReviewPendingHint("early")
	}
	s.NotifyWorkExceptionPushHTML(ctx, chatID, empID, empName, shiftLabel(shift), "下班", workFine, earlyMin, workSec, activitySec, groupReply, "")
	return &CheckOutOutcome{
		Result:         result,
		WorkFine:       workFine,
		ShiftType:      shift,
		HandoverHint:   handoverHint,
		ActivityWarn:   activityWarn,
		GroupReplyHTML: groupReply,
	}, nil
}

func (s *WorkforceTelegramService) openTelegramWorkSessionIDFIFO(ctx context.Context, empID uuid.UUID) uuid.UUID {
	var sid uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM work_sessions WHERE employee_id = $1 AND status = 'open' AND source = 'telegram'
		ORDER BY checkin_time ASC LIMIT 1`, empID).Scan(&sid)
	if err != nil {
		return uuid.Nil
	}
	return sid
}

func (s *WorkforceTelegramService) openWorkSessionIDFIFO(ctx context.Context, empID uuid.UUID) uuid.UUID {
	var sid uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM work_sessions WHERE employee_id = $1 AND status = 'open'
		ORDER BY checkin_time ASC LIMIT 1`, empID).Scan(&sid)
	if err != nil {
		return uuid.Nil
	}
	return sid
}

func (s *WorkforceTelegramService) GetEmployeeOpenShifts(ctx context.Context, empID uuid.UUID) ([]string, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT shift_type FROM work_sessions WHERE employee_id = $1 AND status = 'open' ORDER BY shift_type`, empID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	shifts := make([]string, 0)
	for rows.Next() {
		var sh string
		if rows.Scan(&sh) == nil {
			shifts = append(shifts, sh)
		}
	}
	return shifts, nil
}

func (s *WorkforceTelegramService) ListWorkFines(ctx context.Context) ([]TgWorkFine, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, checkin_type, segment_minutes, fine_amount FROM wf_tg_work_fines ORDER BY checkin_type, segment_minutes`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TgWorkFine, 0)
	for rows.Next() {
		var row TgWorkFine
		if rows.Scan(&row.ID, &row.CheckinType, &row.SegmentMinutes, &row.FineAmount) == nil {
			items = append(items, row)
		}
	}
	return items, nil
}

func (s *WorkforceTelegramService) UpsertWorkFine(ctx context.Context, checkinType string, segmentMinutes int, fineAmount float64) (*TgWorkFine, error) {
	checkinType = strings.TrimSpace(checkinType)
	if checkinType == "" || segmentMinutes <= 0 {
		return nil, fmt.Errorf("invalid work fine rule")
	}
	var id uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO wf_tg_work_fines (checkin_type, segment_minutes, fine_amount)
		VALUES ($1, $2, $3)
		ON CONFLICT (checkin_type, segment_minutes) DO UPDATE SET fine_amount = EXCLUDED.fine_amount
		RETURNING id`, checkinType, segmentMinutes, fineAmount).Scan(&id)
	if err != nil {
		return nil, err
	}
	items, err := s.ListWorkFines(ctx)
	if err != nil {
		return nil, err
	}
	for _, f := range items {
		if f.ID == id {
			return &f, nil
		}
	}
	return nil, fmt.Errorf("work fine not found")
}

type TgWorkFineBatchItem struct {
	SegmentMinutes int
	FineAmount     float64
}

func (s *WorkforceTelegramService) BatchUpsertWorkFines(ctx context.Context, checkinTypes []string, items []TgWorkFineBatchItem) ([]TgWorkFine, error) {
	types := make([]string, 0, len(checkinTypes))
	seenType := map[string]struct{}{}
	for _, t := range checkinTypes {
		t = strings.TrimSpace(t)
		if t == "" {
			continue
		}
		if t != "work_start" && t != "work_end" {
			return nil, fmt.Errorf("invalid checkin type: %s", t)
		}
		if _, ok := seenType[t]; ok {
			continue
		}
		seenType[t] = struct{}{}
		types = append(types, t)
	}
	if len(types) == 0 {
		return nil, fmt.Errorf("checkin type required")
	}
	if len(items) == 0 {
		return nil, fmt.Errorf("at least one rule required")
	}

	seen := make(map[int]struct{}, len(items))
	for _, item := range items {
		if item.SegmentMinutes <= 0 {
			return nil, fmt.Errorf("segment minutes must be positive")
		}
		if _, dup := seen[item.SegmentMinutes]; dup {
			return nil, fmt.Errorf("duplicate segment minutes in batch: %d", item.SegmentMinutes)
		}
		seen[item.SegmentMinutes] = struct{}{}
	}

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	out := make([]TgWorkFine, 0, len(types)*len(items))
	for _, checkinType := range types {
		for _, item := range items {
			var id uuid.UUID
			err := tx.QueryRowContext(ctx, `
				INSERT INTO wf_tg_work_fines (checkin_type, segment_minutes, fine_amount)
				VALUES ($1, $2, $3)
				ON CONFLICT (checkin_type, segment_minutes) DO UPDATE SET fine_amount = EXCLUDED.fine_amount
				RETURNING id`, checkinType, item.SegmentMinutes, item.FineAmount).Scan(&id)
			if err != nil {
				return nil, err
			}
			out = append(out, TgWorkFine{
				ID: id, CheckinType: checkinType,
				SegmentMinutes: item.SegmentMinutes, FineAmount: item.FineAmount,
			})
		}
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return out, nil
}

func (s *WorkforceTelegramService) DeleteWorkFine(ctx context.Context, id uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM wf_tg_work_fines WHERE id = $1`, id)
	return err
}

func (s *WorkforceTelegramService) ListSharedWorkstationMembers(ctx context.Context, deviceID string) ([]TgSharedWorkstationMember, error) {
	query := `
		SELECT m.device_id, COALESCE(d.hostname, ''), m.employee_id, e.name, COALESCE(e.employee_id,'')
		FROM wf_shared_workstation_members m
		JOIN devices d ON d.id = m.device_id
		JOIN employees e ON e.id = m.employee_id`
	args := []interface{}{}
	if strings.TrimSpace(deviceID) != "" {
		query += ` WHERE m.device_id = $1::uuid`
		args = append(args, deviceID)
	}
	query += ` ORDER BY d.hostname, e.name`
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TgSharedWorkstationMember, 0)
	for rows.Next() {
		var row TgSharedWorkstationMember
		if rows.Scan(&row.DeviceID, &row.DeviceName, &row.EmployeeID, &row.EmployeeName, &row.EmployeeCode) == nil {
			items = append(items, row)
		}
	}
	return items, nil
}

func (s *WorkforceTelegramService) AddSharedWorkstationMember(ctx context.Context, deviceID, employeeID uuid.UUID) error {
	if deviceID == uuid.Nil || employeeID == uuid.Nil {
		return fmt.Errorf("device and employee required")
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	_, err = tx.ExecContext(ctx, `UPDATE devices SET is_shared_workstation = TRUE WHERE id = $1`, deviceID)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		INSERT INTO wf_shared_workstation_members (device_id, employee_id) VALUES ($1, $2)
		ON CONFLICT DO NOTHING`, deviceID, employeeID)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		UPDATE employees SET attendance_mode = $2, updated_at = NOW()
		WHERE id = $1 AND COALESCE(NULLIF(TRIM(attendance_mode), ''), 'pc_tg') <> $3`,
		employeeID, AttendanceModeSharedStation, AttendanceModeTGOnly)
	if err != nil {
		return err
	}
	return tx.Commit()
}

func (s *WorkforceTelegramService) RemoveSharedWorkstationMember(ctx context.Context, deviceID, employeeID uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `
		DELETE FROM wf_shared_workstation_members WHERE device_id = $1 AND employee_id = $2`, deviceID, employeeID)
	return err
}

func (s *WorkforceTelegramService) effectiveActivityCycle(ctx context.Context, chatID string, empID uuid.UUID, period *TgPeriodInfo) int {
	if period == nil || !period.IsHandover {
		return 1
	}
	if period.Cycle >= 2 {
		return 2
	}
	var totalSec int
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(total_work_seconds,0) FROM wf_tg_handover_cycles
		WHERE chat_id = $1 AND employee_id = $2 AND handover_date = $3::date
		  AND shift_type = $4 AND cycle_number = 1`,
		chatID, empID, period.HandoverDate, shiftFromPeriod(period.PeriodType)).Scan(&totalSec)
	cfg, _ := s.GetHandoverConfig(ctx, chatID)
	if totalSec >= int(handoverThreshold(cfg)*3600) {
		return 2
	}
	return 1
}

func shiftFromPeriod(periodType string) string {
	if strings.Contains(periodType, "night") {
		return "night"
	}
	return "day"
}

func (s *WorkforceTelegramService) bumpHandoverCycleWork(ctx context.Context, chatID string, empID uuid.UUID, period *TgPeriodInfo, elapsedSec int) {
	if period == nil || !period.IsHandover || elapsedSec <= 0 || chatID == "" {
		return
	}
	shift := shiftFromPeriod(period.PeriodType)
	cycle := s.effectiveActivityCycle(ctx, chatID, empID, period)
	_, _ = s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_handover_cycles (chat_id, employee_id, handover_date, shift_type, cycle_number, total_work_seconds)
		VALUES ($1,$2,$3::date,$4,$5,$6)
		ON CONFLICT (chat_id, employee_id, handover_date, shift_type, cycle_number)
		DO UPDATE SET total_work_seconds = wf_tg_handover_cycles.total_work_seconds + EXCLUDED.total_work_seconds, updated_at = NOW()`,
		chatID, empID, period.HandoverDate, shift, cycle, elapsedSec)
}

func (s *WorkforceTelegramService) getOpenWorkSessionAttendance(ctx context.Context, empID uuid.UUID) (shift, shiftDetail, recordDate string, ok bool) {
	err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day'), COALESCE(shift_detail,''), attendance_date::text
		FROM work_sessions
		WHERE employee_id = $1 AND status = 'open'
		ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&shift, &shiftDetail, &recordDate)
	if err != nil {
		return "", "", "", false
	}
	return shift, shiftDetail, recordDate, true
}

func (s *WorkforceTelegramService) validateNoConflictingOpenWorkSession(ctx context.Context, empID uuid.UUID, shift, shiftDetail, recordDate string) error {
	openShift, openDetail, openDate, hasOpen := s.getOpenWorkSessionAttendance(ctx, empID)
	if !hasOpen {
		return nil
	}
	if openShift == shift && openDate == recordDate {
		return nil
	}
	return fmt.Errorf("%w：请先下班当前%s%s（%s）", ErrOtherWorkSessionOpen, shiftLabel(openShift), shiftDetailLabel(openDetail), openDate)
}

func (s *WorkforceTelegramService) resolveActivityBusinessDate(ctx context.Context, chatID string, empID uuid.UUID, shift string) (string, *TgPeriodInfo, int, error) {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		settings = &TelegramSettings{Timezone: "Asia/Shanghai"}
	}
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)

	if successor := s.getRelaySuccessorDate(ctx, chatID, empID); successor != "" {
		period, perr := s.DetermineCurrentPeriod(ctx, chatID, now)
		cycle := 1
		if period != nil {
			cycle = s.effectiveActivityCycle(ctx, chatID, empID, period)
		}
		if perr != nil {
			return successor, period, cycle, perr
		}
		return successor, period, cycle, nil
	}

	if openShift, openDetail, openDate, hasOpen := s.getOpenWorkSessionAttendance(ctx, empID); hasOpen {
		period, _ := s.DetermineCurrentPeriod(ctx, chatID, now)
		cycle := 1
		if period != nil {
			cycle = s.effectiveActivityCycle(ctx, chatID, empID, period)
		}
		if strings.TrimSpace(shift) == "" {
			shift = openShift
		}
		_ = openDetail
		return openDate, period, cycle, nil
	}

	period, err := s.DetermineCurrentPeriod(ctx, chatID, now)
	if err != nil {
		return now.Format("2006-01-02"), nil, 1, err
	}
	if strings.TrimSpace(shift) == "" {
		shift = "day"
	}
	shiftDetail := ""
	if shift == "night" {
		shiftDetail = resolveNightShiftDetail(settings, now)
	}
	cycle := s.effectiveActivityCycle(ctx, chatID, empID, period)
	return resolveAttendanceDate(shift, shiftDetail, period, now, loc), period, cycle, nil
}

func (s *WorkforceTelegramService) countActivitiesOnDate(ctx context.Context, empID uuid.UUID, activityCode, date, shift string, cycle int) (int, error) {
	var count int
	query := `
		SELECT COUNT(*) FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND activity_code = $2 AND attendance_date = $3::date AND status = 'closed'`
	args := []interface{}{empID, activityCode, date}
	if shift != "" {
		query += ` AND shift_type = $4`
		args = append(args, shift)
	}
	err := s.db.QueryRowContext(ctx, query, args...).Scan(&count)
	if err != nil {
		return 0, err
	}
	if cycle >= 2 {
		return 0, nil
	}
	return count, nil
}

func (s *WorkforceTelegramService) getOpenWorkShift(ctx context.Context, empID uuid.UUID) (string, error) {
	var shift string
	err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day') FROM work_sessions
		WHERE employee_id = $1 AND status = 'open' ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&shift)
	if err == sql.ErrNoRows {
		return "", ErrNoOpenSession
	}
	return shift, err
}

func (s *WorkforceTelegramService) GetMyInfoForShift(ctx context.Context, telegramUserID int64, shiftFilter, chatID string) (*TgMyInfoSummary, error) {
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil {
		return nil, err
	}
	if strings.TrimSpace(chatID) == "" {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(chat_id,'') FROM employee_telegram_bindings WHERE employee_id = $1 AND status = 1`, empID).Scan(&chatID)
	}

	shiftFilter = strings.TrimSpace(strings.ToLower(shiftFilter))
	info, err := s.GetMyInfo(ctx, telegramUserID)
	if err != nil {
		return nil, err
	}
	if shiftFilter == "" {
		return info, nil
	}

	openShifts, _ := s.GetEmployeeOpenShifts(ctx, empID)
	info.WorkSessionOpen = false
	for _, sh := range openShifts {
		if sh == shiftFilter {
			info.WorkSessionOpen = true
			break
		}
	}

	businessDate, _, cycle, _ := s.resolveActivityBusinessDate(ctx, chatID, empID, shiftFilter)
	rows, err := s.db.QueryContext(ctx, `
		SELECT activity_name, COUNT(*), COALESCE(SUM(elapsed_seconds),0), COALESCE(SUM(fine_amount),0)
		FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND attendance_date = $2::date AND status = 'closed' AND shift_type = $3
		GROUP BY activity_name ORDER BY activity_name`, empID, businessDate, shiftFilter)
	if err == nil {
		defer rows.Close()
		info.TodayActivities = nil
		info.TodayFineTotal = 0
		for rows.Next() {
			var actName string
			var count, totalSec int
			var fineTotal float64
			if rows.Scan(&actName, &count, &totalSec, &fineTotal) == nil {
				if cycle >= 2 {
					count = 0
				}
				info.TodayActivities = append(info.TodayActivities, map[string]interface{}{
					"name": actName, "count": count, "totalSeconds": totalSec, "fineAmount": fineTotal,
					"shift": shiftFilter, "shiftLabel": shiftLabel(shiftFilter),
				})
				info.TodayFineTotal += fineTotal
			}
		}
	}
	info.ShiftFilter = shiftFilter
	info.ShiftLabel = shiftLabel(shiftFilter)
	return info, nil
}

func (s *WorkforceTelegramService) sumTodayActivitySeconds(ctx context.Context, empID uuid.UUID, recordDate, shift string) int {
	var total int
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(SUM(elapsed_seconds),0)::int FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND attendance_date = $2::date AND shift_type = $3 AND status = 'closed'`,
		empID, recordDate, shift).Scan(&total)
	return total
}

func (s *WorkforceTelegramService) buildCrossShiftActivityWarn(ctx context.Context, empID uuid.UUID, closingShift, recordDate string) string {
	sess, err := s.getOpenActivitySession(ctx, empID)
	if errors.Is(err, ErrActivityNotActive) {
		return ""
	}
	if err != nil {
		return ""
	}
	var actShift string
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day') FROM wf_tg_activity_sessions WHERE id = $1`, sess.ID).Scan(&actShift)
	if actShift == closingShift && sess.AttendanceDate == recordDate {
		return ""
	}
	return fmt.Sprintf("⚠️ 活动「%s」仍在进行（%s），请手动回座", sess.ActivityName, shiftLabel(actShift))
}

func (s *WorkforceTelegramService) maybeBroadcastShiftEnd(ctx context.Context, chatID, shift, recordDate string) {
	if chatID == "" {
		return
	}
	var remain int
	_ = s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM wf_tg_group_shift_state
		WHERE chat_id = $1 AND shift_type = $2 AND record_date = $3::date`, chatID, shift, recordDate).Scan(&remain)
	if remain > 0 {
		return
	}
	msg := fmt.Sprintf("📢 %s %s 全员已下班", recordDate, shiftLabel(shift))
	_ = s.SendTelegramText(ctx, chatID, msg, nil)
}

func (s *WorkforceTelegramService) ListRankingsForShift(ctx context.Context, date, metric, shift, chatID string, limit int) ([]TgRankingRow, error) {
	if limit <= 0 {
		limit = 20
	}
	if strings.TrimSpace(date) == "" {
		date = time.Now().Format("2006-01-02")
	}
	metric = strings.TrimSpace(metric)
	if metric == "" {
		metric = "fine"
	}
	orderBy := "fine_total DESC, activity_count DESC"
	switch metric {
	case "activity":
		orderBy = "activity_count DESC, fine_total DESC"
	case "overtime":
		orderBy = "overtime_seconds DESC, fine_total DESC"
	}
	where := "s.attendance_date = $1::date AND s.status = 'closed'"
	args := []interface{}{date}
	argN := 2
	if strings.TrimSpace(chatID) != "" {
		where += fmt.Sprintf(" AND COALESCE(s.source_chat_id,'') = $%d", argN)
		args = append(args, chatID)
		argN++
	}
	if strings.TrimSpace(shift) != "" {
		where += fmt.Sprintf(" AND s.shift_type = $%d", argN)
		args = append(args, shift)
		argN++
	}
	// Live ∪ archive：日切会把已关闭会话归档并删活表，历史日排行必须读归档。
	query := fmt.Sprintf(`
		SELECT e.id, e.name, COALESCE(e.employee_id,''),
			COUNT(s.id)::int AS activity_count,
			COALESCE(SUM(s.overtime_seconds),0)::int AS overtime_seconds,
			COALESCE(SUM(s.fine_amount),0) AS fine_total
		FROM (
			SELECT DISTINCT ON (id)
				id, employee_id, attendance_date, overtime_seconds, fine_amount, status,
				COALESCE(source_chat_id,'') AS source_chat_id, shift_type, is_live
			FROM (
				SELECT id, employee_id, attendance_date, overtime_seconds, fine_amount, status,
					source_chat_id, shift_type, TRUE AS is_live
				FROM wf_tg_activity_sessions
				UNION ALL
				SELECT id, employee_id, attendance_date, overtime_seconds, fine_amount, status,
					source_chat_id, shift_type, FALSE AS is_live
				FROM wf_tg_activity_sessions_archive
			) u
			ORDER BY id, is_live DESC
		) s
		JOIN employees e ON e.id = s.employee_id
		WHERE %s
		GROUP BY e.id, e.name, e.employee_id
		ORDER BY %s
		LIMIT %d`, where, orderBy, limit)
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TgRankingRow, 0)
	rank := 0
	for rows.Next() {
		var row TgRankingRow
		if rows.Scan(&row.EmployeeID, &row.EmployeeName, &row.EmployeeCode,
			&row.ActivityCount, &row.OvertimeSeconds, &row.FineTotal) != nil {
			continue
		}
		rank++
		row.Rank = rank
		items = append(items, row)
	}
	return items, nil
}

package services

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

var (
	pushDedupMu    sync.Mutex
	pushDedupCache = map[string]time.Time{}
)

type TgPushSettings struct {
	ChatID              string
	ChannelID           string
	NotificationGroupID string
	ExtraWorkGroupID    string
	EnableChannelPush   bool
	EnableGroupPush     bool
	EnableAdminPush     bool
	UpdatedAt           time.Time
}

func (s *WorkforceTelegramService) GetPushSettings(ctx context.Context, chatID string) (*TgPushSettings, error) {
	chatID = strings.TrimSpace(chatID)
	out := &TgPushSettings{ChatID: chatID, EnableChannelPush: true, EnableGroupPush: true}
	if chatID == "" {
		return out, nil
	}
	err := s.db.QueryRowContext(ctx, `
		SELECT chat_id, COALESCE(channel_id,''), COALESCE(notification_group_id,''), COALESCE(extra_work_group_id,''),
			enable_channel_push, enable_group_push, enable_admin_push, updated_at
		FROM wf_tg_push_settings WHERE chat_id = $1`, chatID).
		Scan(&out.ChatID, &out.ChannelID, &out.NotificationGroupID, &out.ExtraWorkGroupID,
			&out.EnableChannelPush, &out.EnableGroupPush, &out.EnableAdminPush, &out.UpdatedAt)
	if err == sql.ErrNoRows {
		return out, nil
	}
	return out, err
}

func (s *WorkforceTelegramService) UpsertPushSettings(ctx context.Context, chatID string, in map[string]interface{}) (*TgPushSettings, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return nil, fmt.Errorf("chatId required")
	}
	cur, _ := s.GetPushSettings(ctx, chatID)
	if v, ok := in["channelId"].(string); ok {
		cur.ChannelID = strings.TrimSpace(v)
	}
	if v, ok := in["notificationGroupId"].(string); ok {
		cur.NotificationGroupID = strings.TrimSpace(v)
	}
	if v, ok := in["extraWorkGroupId"].(string); ok {
		cur.ExtraWorkGroupID = strings.TrimSpace(v)
	}
	if v, ok := in["enableChannelPush"].(bool); ok {
		cur.EnableChannelPush = v
	}
	if v, ok := in["enableGroupPush"].(bool); ok {
		cur.EnableGroupPush = v
	}
	if v, ok := in["enableAdminPush"].(bool); ok {
		cur.EnableAdminPush = v
	}
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_push_settings (chat_id, channel_id, notification_group_id, extra_work_group_id,
			enable_channel_push, enable_group_push, enable_admin_push, updated_at)
		VALUES ($1,$2,$3,$4,$5,$6,$7,NOW())
		ON CONFLICT (chat_id) DO UPDATE SET
			channel_id = EXCLUDED.channel_id,
			notification_group_id = EXCLUDED.notification_group_id,
			extra_work_group_id = EXCLUDED.extra_work_group_id,
			enable_channel_push = EXCLUDED.enable_channel_push,
			enable_group_push = EXCLUDED.enable_group_push,
			enable_admin_push = EXCLUDED.enable_admin_push,
			updated_at = NOW()`,
		chatID, nullIfEmpty(cur.ChannelID), nullIfEmpty(cur.NotificationGroupID), nullIfEmpty(cur.ExtraWorkGroupID),
		cur.EnableChannelPush, cur.EnableGroupPush, cur.EnableAdminPush)
	if err != nil {
		return nil, err
	}
	return s.GetPushSettings(ctx, chatID)
}

func nullIfEmpty(s string) interface{} {
	if strings.TrimSpace(s) == "" {
		return nil
	}
	return s
}

func (s *WorkforceTelegramService) listAdminTelegramUserIDs(ctx context.Context) []int64 {
	ids := make([]int64, 0)
	var raw sql.NullString
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(admin_telegram_user_ids,'') FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).Scan(&raw)
	if raw.Valid {
		ids = append(ids, parseTelegramIDList(raw.String)...)
	}
	if env := strings.TrimSpace(os.Getenv("TELEGRAM_ADMIN_USER_IDS")); env != "" {
		ids = append(ids, parseTelegramIDList(env)...)
	}
	return dedupeInt64(ids)
}

func parseTelegramIDList(raw string) []int64 {
	out := make([]int64, 0)
	for _, part := range strings.Split(raw, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		if n, err := strconv.ParseInt(part, 10, 64); err == nil {
			out = append(out, n)
		}
	}
	return out
}

func dedupeInt64(items []int64) []int64 {
	seen := make(map[int64]struct{}, len(items))
	out := make([]int64, 0, len(items))
	for _, v := range items {
		if v == 0 {
			continue
		}
		if _, ok := seen[v]; ok {
			continue
		}
		seen[v] = struct{}{}
		out = append(out, v)
	}
	return out
}

type telegramSendMessageResult struct {
	MessageID int64 `json:"message_id"`
}

func (s *WorkforceTelegramService) telegramAPI(ctx context.Context, method string, payload map[string]interface{}) error {
	_, err := s.telegramAPIWithResult(ctx, method, payload)
	return err
}

func (s *WorkforceTelegramService) telegramAPIWithResult(ctx context.Context, method string, payload map[string]interface{}) (*telegramSendMessageResult, error) {
	token, err := s.GetBotToken(ctx)
	if err != nil || strings.TrimSpace(token) == "" {
		return nil, fmt.Errorf("bot token not configured")
	}
	body, _ := json.Marshal(payload)
	url := fmt.Sprintf("https://api.telegram.org/bot%s/%s", token, method)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK          bool                       `json:"ok"`
		Description string                     `json:"description"`
		Result      *telegramSendMessageResult `json:"result"`
	}
	_ = json.Unmarshal(raw, &parsed)
	if !parsed.OK {
		if parsed.Description == "" {
			parsed.Description = string(raw)
		}
		return nil, fmt.Errorf("telegram %s: %s", method, parsed.Description)
	}
	return parsed.Result, nil
}

func (s *WorkforceTelegramService) SendTelegramHTML(ctx context.Context, chatID, htmlText string, replyMarkup interface{}) error {
	return s.SendTelegramHTMLReply(ctx, chatID, htmlText, 0, replyMarkup)
}

func (s *WorkforceTelegramService) SendTelegramHTMLReply(ctx context.Context, chatID, htmlText string, replyTo int64, replyMarkup interface{}) error {
	_, err := s.SendTelegramHTMLReplyReturnID(ctx, chatID, htmlText, replyTo, replyMarkup)
	return err
}

func (s *WorkforceTelegramService) SendTelegramHTMLReplyReturnID(ctx context.Context, chatID, htmlText string, replyTo int64, replyMarkup interface{}) (int64, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" || strings.TrimSpace(htmlText) == "" {
		return 0, nil
	}
	payload := map[string]interface{}{
		"chat_id":    chatID,
		"text":       htmlText,
		"parse_mode": "HTML",
	}
	if replyTo > 0 {
		payload["reply_to_message_id"] = replyTo
	}
	if replyMarkup != nil {
		payload["reply_markup"] = replyMarkup
	}
	result, err := s.telegramAPIWithResult(ctx, "sendMessage", payload)
	if err != nil {
		return 0, err
	}
	if result == nil {
		return 0, nil
	}
	return result.MessageID, nil
}

// RemoveTelegramInlineKeyboard removes buttons from an existing Telegram
// message without changing its text.
func (s *WorkforceTelegramService) RemoveTelegramInlineKeyboard(
	ctx context.Context, chatID string, messageID int64,
) error {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" || messageID <= 0 {
		return nil
	}
	return s.telegramAPI(ctx, "editMessageReplyMarkup", map[string]interface{}{
		"chat_id":    chatID,
		"message_id": messageID,
		"reply_markup": map[string]interface{}{
			"inline_keyboard": [][]interface{}{},
		},
	})
}

func (s *WorkforceTelegramService) SendTelegramText(ctx context.Context, chatID string, text string, replyMarkup interface{}) error {
	return s.SendTelegramTextReply(ctx, chatID, text, 0, replyMarkup)
}

func (s *WorkforceTelegramService) SendTelegramTextReply(ctx context.Context, chatID string, text string, replyTo int64, replyMarkup interface{}) error {
	return s.sendTelegramTextDedup(ctx, chatID, text, replyTo, replyMarkup, "")
}

func (s *WorkforceTelegramService) sendTelegramTextDedup(ctx context.Context, chatID, text string, replyTo int64, replyMarkup interface{}, dedupKey string) error {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" || strings.TrimSpace(text) == "" {
		return nil
	}
	if dedupKey == "" {
		dedupKey = chatID + "|" + text
	}
	pushDedupMu.Lock()
	if exp, ok := pushDedupCache[dedupKey]; ok && exp.After(time.Now()) {
		pushDedupMu.Unlock()
		return nil
	}
	pushDedupCache[dedupKey] = time.Now().Add(60 * time.Second)
	pushDedupMu.Unlock()
	payload := map[string]interface{}{
		"chat_id": chatID,
		"text":    text,
	}
	if replyTo > 0 {
		payload["reply_to_message_id"] = replyTo
	}
	if replyMarkup != nil {
		payload["reply_markup"] = replyMarkup
	}
	return s.telegramAPI(ctx, "sendMessage", payload)
}

func (s *WorkforceTelegramService) EditTelegramMessage(ctx context.Context, chatID string, messageID int64, text string, replyMarkup interface{}) error {
	if messageID <= 0 || strings.TrimSpace(chatID) == "" {
		return nil
	}
	payload := map[string]interface{}{
		"chat_id":    chatID,
		"message_id": messageID,
		"text":       text,
	}
	if replyMarkup != nil {
		payload["reply_markup"] = replyMarkup
	}
	return s.telegramAPI(ctx, "editMessageText", payload)
}

func (s *WorkforceTelegramService) SendTelegramDocument(ctx context.Context, chatID, filename string, data []byte, caption string) error {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" || len(data) == 0 {
		return nil
	}
	token, err := s.GetBotToken(ctx)
	if err != nil || strings.TrimSpace(token) == "" {
		return fmt.Errorf("bot token not configured")
	}
	var body bytes.Buffer
	w := multipart.NewWriter(&body)
	_ = w.WriteField("chat_id", chatID)
	if strings.TrimSpace(caption) != "" {
		_ = w.WriteField("caption", caption)
	}
	part, err := w.CreateFormFile("document", filename)
	if err != nil {
		return err
	}
	if _, err = part.Write(data); err != nil {
		return err
	}
	_ = w.Close()

	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendDocument", token)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, &body)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", w.FormDataContentType())
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
	}
	_ = json.Unmarshal(raw, &parsed)
	if !parsed.OK {
		if parsed.Description == "" {
			parsed.Description = string(raw)
		}
		return fmt.Errorf("telegram sendDocument: %s", parsed.Description)
	}
	return nil
}

func (s *WorkforceTelegramService) pushWithAdminFallback(ctx context.Context, ps *TgPushSettings, sourceChatID string, send func(target string) error) {
	if ps == nil {
		return
	}
	sourceChatID = strings.TrimSpace(sourceChatID)
	shouldSkip := func(target string) bool {
		return sourceChatID != "" && strings.TrimSpace(target) == sourceChatID
	}
	sent := false
	if ps.EnableChannelPush && ps.ChannelID != "" && !shouldSkip(ps.ChannelID) {
		if err := send(ps.ChannelID); err == nil {
			sent = true
		} else {
			log.Printf("[TelegramPush] channel %s failed: %v", ps.ChannelID, err)
		}
	}
	if ps.EnableGroupPush && ps.NotificationGroupID != "" && !shouldSkip(ps.NotificationGroupID) {
		if err := send(ps.NotificationGroupID); err == nil {
			sent = true
		} else {
			log.Printf("[TelegramPush] notification group %s failed: %v", ps.NotificationGroupID, err)
		}
	}
	if !sent && ps.EnableAdminPush {
		for _, adminID := range s.listAdminTelegramUserIDs(ctx) {
			target := fmt.Sprintf("%d", adminID)
			if shouldSkip(target) {
				continue
			}
			if err := send(target); err == nil {
				break
			} else {
				log.Printf("[TelegramPush] admin %s failed: %v", target, err)
			}
		}
	}
}

func (s *WorkforceTelegramService) PushToChatTargets(ctx context.Context, chatID, text string, includeExtraWork bool) {
	if strings.TrimSpace(text) == "" {
		return
	}
	sourceChat := strings.TrimSpace(chatID)
	ps, err := s.GetPushSettings(ctx, sourceChat)
	if err != nil {
		return
	}
	s.pushWithAdminFallback(ctx, ps, sourceChat, func(target string) error {
		return s.SendTelegramText(ctx, target, text, nil)
	})
	if includeExtraWork && ps.ExtraWorkGroupID != "" && strings.TrimSpace(ps.ExtraWorkGroupID) != sourceChat {
		_ = s.SendTelegramText(ctx, ps.ExtraWorkGroupID, text, nil)
	}
}

func (s *WorkforceTelegramService) pushHTMLToChatTargets(ctx context.Context, chatID, htmlText string, includeExtraWork bool) {
	if strings.TrimSpace(htmlText) == "" {
		return
	}
	sourceChat := strings.TrimSpace(chatID)
	ps, err := s.GetPushSettings(ctx, sourceChat)
	if err != nil {
		return
	}
	s.pushWithAdminFallback(ctx, ps, sourceChat, func(target string) error {
		return s.SendTelegramHTML(ctx, target, htmlText, nil)
	})
	if includeExtraWork && ps.ExtraWorkGroupID != "" && strings.TrimSpace(ps.ExtraWorkGroupID) != sourceChat {
		_ = s.SendTelegramHTML(ctx, ps.ExtraWorkGroupID, htmlText, nil)
	}
}

func (s *WorkforceTelegramService) PushWorkEventToTargets(ctx context.Context, chatID, text string) {
	s.PushToChatTargets(ctx, chatID, text, false)
}

func (s *WorkforceTelegramService) PushDocumentToChatTargets(ctx context.Context, chatID, filename string, data []byte, caption string, includeExtraWork bool) {
	if len(data) == 0 {
		return
	}
	ps, err := s.GetPushSettings(ctx, chatID)
	if err != nil {
		return
	}
	s.pushWithAdminFallback(ctx, ps, chatID, func(target string) error {
		return s.SendTelegramDocument(ctx, target, filename, data, caption)
	})
	if includeExtraWork && ps.ExtraWorkGroupID != "" && strings.TrimSpace(ps.ExtraWorkGroupID) != strings.TrimSpace(chatID) {
		_ = s.SendTelegramDocument(ctx, ps.ExtraWorkGroupID, filename, data, caption)
	}
}

func (s *WorkforceTelegramService) NotifyWorkEvent(ctx context.Context, chatID string, empID uuid.UUID, employeeName, shift, event string, fine float64, workSeconds int) {
	s.NotifyWorkExceptionPush(ctx, chatID, empID, employeeName, shift, event, fine, 0, workSeconds, 0, "")
}

// NotifyWorkExceptionPushHTML sends late/early/fine alerts to channel & notification group
// using the same HTML template as the check-in group reply.
func (s *WorkforceTelegramService) NotifyWorkExceptionPushHTML(
	ctx context.Context, chatID string, empID uuid.UUID, employeeName, shiftLabel, event string,
	workFine float64, exceptionMinutes int,
	workSeconds, activitySeconds int,
	htmlBody, sourcePrefix string,
) {
	if chatID == "" || (workFine <= 0 && exceptionMinutes <= 0) {
		return
	}
	msg := strings.TrimSpace(htmlBody)
	if msg == "" {
		s.NotifyWorkExceptionPush(ctx, chatID, empID, employeeName, shiftLabel, event, workFine, exceptionMinutes, workSeconds, activitySeconds, "")
		return
	}
	if prefix := strings.TrimSpace(sourcePrefix); prefix != "" {
		msg = prefix + "\n" + msg
	}
	s.pushHTMLToChatTargets(ctx, chatID, msg, true)
	if s.agentNotify != nil {
		s.agentNotify.PushAttendanceException(empID, employeeName, shiftLabel, event, workFine, exceptionMinutes)
	}
}

// NotifyWorkExceptionPush sends late/early/fine alerts to channel & notification group.
// Normal on-time check-in/out is answered in the check-in group by the bot.
func (s *WorkforceTelegramService) NotifyWorkExceptionPush(
	ctx context.Context, chatID string, empID uuid.UUID, employeeName, shift, event string,
	workFine float64, exceptionMinutes int,
	workSeconds, activitySeconds int, shiftDetail string,
) {
	if chatID == "" || (workFine <= 0 && exceptionMinutes <= 0) {
		return
	}
	label := shiftLabel(shift) + shiftDetailLabel(shiftDetail)
	msg := fmt.Sprintf("🚨 %s %s · %s", employeeName, event, label)
	if exceptionMinutes > 0 {
		if event == "上班" {
			msg += fmt.Sprintf("\n⏰ 迟到 %d 分钟", exceptionMinutes)
		} else {
			msg += fmt.Sprintf("\n⏰ 早退 %d 分钟", exceptionMinutes)
		}
	}
	if workSeconds > 0 {
		msg += fmt.Sprintf("\n⏱ 在岗时长：%s", formatDurationZh(workSeconds))
		if activitySeconds > 0 {
			net := workSeconds - activitySeconds
			if net < 0 {
				net = 0
			}
			msg += fmt.Sprintf("\n📊 活动 %s · 净工时 %s", formatDurationZh(activitySeconds), formatDurationZh(net))
		}
	}
	if workFine > 0 {
		msg += fmt.Sprintf("\n⚠️ 罚款 %s", FormatFineMoney(workFine, s.FineCurrencyCode(ctx)))
	}
	s.PushToChatTargets(ctx, chatID, msg, true)
	if s.agentNotify != nil {
		s.agentNotify.PushAttendanceException(empID, employeeName, label, event, workFine, exceptionMinutes)
	}
}

func (s *WorkforceTelegramService) NotifyWorkEventRich(ctx context.Context, chatID string, empID uuid.UUID, employeeName, shift, event string, fine float64, workSeconds, activitySeconds int, shiftDetail string) {
	s.NotifyWorkExceptionPush(ctx, chatID, empID, employeeName, shift, event, fine, 0, workSeconds, activitySeconds, shiftDetail)
}

func (s *WorkforceTelegramService) NotifyActivityOvertimeBack(
	ctx context.Context, chatID string, empID uuid.UUID, employeeName, activity string, telegramUserID int64,
	overtimeSec int, fine float64, backAt time.Time,
) {
	if chatID == "" || overtimeSec <= 0 {
		return
	}
	cur := s.FineCurrencyCode(ctx)
	msg := buildActivityOvertimeBackPushHTML(s.getChatTitle(ctx, chatID), telegramUserID, employeeName, activity, backAt, overtimeSec, fine, cur)
	s.pushHTMLToChatTargets(ctx, chatID, msg, false)
	if s.agentNotify != nil {
		extra := fmt.Sprintf("超时时长：%s", formatDurationZh(overtimeSec))
		if fine > 0 {
			extra += fmt.Sprintf("\n罚款 %s", FormatFineMoney(fine, cur))
		}
		s.agentNotify.PushActivityEvent(empID, employeeName, activity, "超时回座", extra, uuid.Nil)
	}
}

func (s *WorkforceTelegramService) NotifyActivityEvent(ctx context.Context, chatID string, empID uuid.UUID, employeeName, activityName, event string, extra string) {
	if chatID == "" && empID == uuid.Nil {
		return
	}
	// 即将超时仅在打卡群/私信提醒，不推送到额外频道或通知群
	if event == "即将超时" {
		s.syncAgentActivityNotify(empID, employeeName, activityName, event, extra, uuid.Nil)
		return
	}
	switch event {
	case "强制回座", "超时自动结束":
	default:
		return
	}
	msg := fmt.Sprintf(
		"🚨 <b>活动超时通知</b>\n🏢 群组：<code>%s</code>\n%s\n👤 %s\n📝 活动：<code>%s</code>\n📌 %s",
		html.EscapeString(defaultChatTitle(s.getChatTitle(ctx, chatID))),
		tgReplyDashedLine(),
		html.EscapeString(employeeName),
		html.EscapeString(activityName),
		html.EscapeString(strings.TrimSpace(extra)),
	)
	s.pushHTMLToChatTargets(ctx, chatID, msg, false)
	if s.agentNotify != nil {
		s.agentNotify.PushActivityEvent(empID, employeeName, activityName, event, extra, uuid.Nil)
	}
}

// TestPushSettings sends a probe message to configured channel / notification targets.
func (s *WorkforceTelegramService) TestPushSettings(ctx context.Context, chatID string) error {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return fmt.Errorf("请先选择打卡群")
	}
	ps, err := s.GetPushSettings(ctx, chatID)
	if err != nil {
		return err
	}
	text := "🧪 <b>推送通道测试</b>\n\n若收到此消息，说明频道/通知群配置正确，迟到与活动超时告警将推送到此处。"
	var failures []string
	sent := 0
	try := func(label, target string, enabled bool) {
		target = strings.TrimSpace(target)
		if !enabled || target == "" {
			return
		}
		if err := s.SendTelegramHTML(ctx, target, text, nil); err != nil {
			failures = append(failures, fmt.Sprintf("%s(%s): %v", label, target, err))
		} else {
			sent++
		}
	}
	try("频道", ps.ChannelID, ps.EnableChannelPush)
	try("通知群", ps.NotificationGroupID, ps.EnableGroupPush)
	try("迟到/早退群", ps.ExtraWorkGroupID, ps.ExtraWorkGroupID != "")
	if sent == 0 {
		if len(failures) > 0 {
			return errors.New(strings.Join(failures, "；"))
		}
		return fmt.Errorf("请先填写频道 ID 或通知群 ID，并开启对应推送开关")
	}
	if len(failures) > 0 {
		return fmt.Errorf("部分目标发送失败：%s", strings.Join(failures, "；"))
	}
	return nil
}

func defaultChatTitle(title string) string {
	if strings.TrimSpace(title) == "" {
		return "打卡群"
	}
	return title
}

func inlineQuickBackKeyboard(sessionID string) map[string]interface{} {
	return map[string]interface{}{
		"inline_keyboard": [][]map[string]interface{}{
			{{
				"text":          "回座",
				"callback_data": "qb:" + sessionID,
				"style":         tgUIButtons["back"].Style,
			}},
		},
	}
}

const activityKeyboardCols = 3

func buildActivityRowsWithBack(mode TgLangMode, activityNames []string) [][]map[string]interface{} {
	backBtn := tgKeyboardBtn(tgButtonLabel(tgUIButtons["back"], mode), tgUIButtons["back"].Style)
	if len(activityNames) == 0 {
		return [][]map[string]interface{}{{backBtn}}
	}
	actBtns := make([]map[string]interface{}, 0, len(activityNames))
	for _, name := range activityNames {
		if strings.TrimSpace(name) != "" {
			actBtns = append(actBtns, map[string]interface{}{"text": name})
		}
	}
	if len(actBtns) == 0 {
		return [][]map[string]interface{}{{backBtn}}
	}
	if len(actBtns) <= 1 {
		return [][]map[string]interface{}{append(actBtns, backBtn)}
	}
	main := actBtns[:len(actBtns)-1]
	last := actBtns[len(actBtns)-1:]
	rows := make([][]map[string]interface{}, 0)
	for i := 0; i < len(main); i += activityKeyboardCols {
		end := i + activityKeyboardCols
		if end > len(main) {
			end = len(main)
		}
		rows = append(rows, main[i:end])
	}
	rows = append(rows, append(last, backBtn))
	return rows
}

func mainReplyKeyboard(dualShift bool, activityNames []string) map[string]interface{} {
	return localizedMainReplyKeyboard(TgLangBoth, dualShift, false, activityNames)
}

func (s *WorkforceTelegramService) ExportAttendanceCSV(ctx context.Context, dateFrom, dateTo, chatID string) ([]byte, string, error) {
	dateFrom = strings.TrimSpace(dateFrom)
	dateTo = strings.TrimSpace(dateTo)
	if dateFrom == "" {
		dateFrom = time.Now().Format("2006-01-02")
	}
	if dateTo == "" {
		dateTo = dateFrom
	}
	stats, activityNames, err := s.buildTelegramExportStats(ctx, dateFrom, dateTo, chatID)
	if err != nil {
		return nil, "", err
	}
	usePunchTimes := telegramExportUsePunchTimes(dateFrom, dateTo)
	startLabel, endLabel := telegramExportWorkColumnHeaders(usePunchTimes)

	headers := []string{"用户ID", "用户昵称", "班次", "工作天数", startLabel, endLabel, "工作时长"}
	for _, act := range activityNames {
		headers = append(headers, act+"次数", act+"总时长")
	}
	headers = append(headers,
		"活动次数总计", "活动用时总计", "超时次数", "超时时长",
		"早退次数", "迟到次数", "下班罚款", "上班罚款", "罚款总金额",
	)

	buf := &bytes.Buffer{}
	w := csv.NewWriter(buf)
	_ = w.Write(headers)
	for _, st := range stats {
		startVal, endVal := telegramExportWorkColumnValues(st, usePunchTimes)
		row := []string{
			strconv.FormatInt(st.UserID, 10),
			st.Nickname,
			formatShiftForExport(st.Shift),
			formatExportValue(st.WorkDays, false),
			startVal,
			endVal,
			formatExportValue(st.WorkHours, true),
		}
		for _, act := range activityNames {
			info := st.Activities[act]
			row = append(row,
				formatExportValue(info.Count, false),
				formatExportValue(info.Time, true),
			)
		}
		row = append(row,
			formatExportValue(st.TotalActivityCount, false),
			formatExportValue(st.TotalAccumulatedTime, true),
			formatExportValue(st.OvertimeCount, false),
			formatExportValue(st.TotalOvertimeTime, true),
			formatExportValue(st.EarlyCount, false),
			formatExportValue(st.LateCount, false),
			formatExportValue(st.WorkEndFines, false),
			formatExportValue(st.WorkStartFines, false),
			formatExportValue(st.TotalFines, false),
		)
		_ = w.Write(row)
	}
	w.Flush()
	filename := exportFilenameSuffix(chatID, dateFrom, dateTo) + ".csv"
	return buf.Bytes(), filename, w.Error()
}

package services

import (
	"fmt"
	"strings"
	"time"
)

func isWithinWindowAsymmetric(nowMin, startMin, endMin, graceBefore, graceAfter int) bool {
	startMin -= graceBefore
	endMin += graceAfter
	if startMin < 0 {
		startMin = 0
	}
	if endMin > 24*60-1 {
		endMin = 24*60 - 1
	}
	if startMin <= endMin {
		return nowMin >= startMin && nowMin <= endMin
	}
	return nowMin >= startMin || nowMin <= endMin
}

func resolveExpectedStartForWindow(now time.Time, startClock string, loc *time.Location) time.Time {
	expectedStart := combineDateTime(now, startClock, loc)
	if now.Before(expectedStart) {
		expectedStart = expectedStart.AddDate(0, 0, -1)
	}
	return expectedStart
}

func isWithinCheckInWindow(now, expectedStart time.Time, beforeMin, afterMin int) bool {
	earliest := expectedStart.Add(-time.Duration(beforeMin) * time.Minute)
	latest := expectedStart.Add(time.Duration(afterMin) * time.Minute)
	return !now.Before(earliest) && !now.After(latest)
}

func isWithinCheckOutWindow(now, expectedEnd time.Time, beforeMin, afterMin int) bool {
	earliest := expectedEnd.Add(-time.Duration(beforeMin) * time.Minute)
	latest := expectedEnd.Add(time.Duration(afterMin) * time.Minute)
	return !now.Before(earliest) && !now.After(latest)
}

func shiftStartClock(settings *TelegramSettings, shift string) string {
	switch shift {
	case "night":
		return settings.NightStart
	case "middle":
		if strings.TrimSpace(settings.MiddleStart) != "" {
			return settings.MiddleStart
		}
		return "13:00"
	default:
		return settings.DayStart
	}
}

func shiftEndClock(settings *TelegramSettings, shift string) string {
	switch shift {
	case "night":
		return settings.NightEnd
	case "middle":
		if strings.TrimSpace(settings.MiddleEnd) != "" {
			return settings.MiddleEnd
		}
		return "01:00"
	default:
		return settings.DayEnd
	}
}

func (s *WorkforceTelegramService) isCheckInWindowForShift(settings *TelegramSettings, grace TgGraceConfig, shift string, now time.Time) bool {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	startClock := shiftStartClock(settings, shift)
	expectedStart := resolveExpectedStartForWindow(now, startClock, loc)
	return isWithinCheckInWindow(now, expectedStart, grace.CheckInBefore, grace.CheckInAfter)
}

func (s *WorkforceTelegramService) validateCheckOutWindow(settings *TelegramSettings, grace TgGraceConfig, shiftWindowDisabled bool, shift, recordDate string, now time.Time) error {
	if shiftWindowDisabled {
		return nil
	}
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	endClock := shiftEndClock(settings, shift)
	expectedEnd := resolveWorkEndExpectedTime(now, recordDate, shift, endClock, loc)
	if isWithinCheckOutWindow(now, expectedEnd, grace.CheckOutBefore, grace.CheckOutAfter) {
		return nil
	}
	label := shiftLabel(shift)
	return fmt.Errorf("当前不在%s签退窗口，请在 %s 前后（含宽容）内打下班卡；%w", label, endClock, ErrOutsideWorkWindow)
}

func resolveNightShiftDetail(settings *TelegramSettings, now time.Time) string {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	nowMin := minutesOfDay(now)
	dayEndH, dayEndM, ok1 := parseClock(settings.DayEnd)
	nightStartH, nightStartM, ok2 := parseClock(settings.NightStart)
	if !ok1 || !ok2 {
		return "night_tonight"
	}
	dayEnd := clockToMinutes(dayEndH, dayEndM)
	nightStart := clockToMinutes(nightStartH, nightStartM)
	if nowMin >= nightStart {
		return "night_tonight"
	}
	if nowMin < dayEnd {
		return "night_last"
	}
	return "night_tonight"
}

func resolveMiddleShiftDetail(settings *TelegramSettings, now time.Time) string {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	nowMin := minutesOfDay(now)
	startH, startM, ok1 := parseClock(shiftStartClock(settings, "middle"))
	endH, endM, ok2 := parseClock(shiftEndClock(settings, "middle"))
	if !ok1 || !ok2 {
		return "middle_today"
	}
	startMin := clockToMinutes(startH, startM)
	endMin := clockToMinutes(endH, endM)
	// Overnight middle (e.g. 13:00–01:00): early-morning hours belong to previous business day.
	if startMin > endMin && nowMin <= endMin {
		return "middle_prev"
	}
	if nowMin >= startMin {
		return "middle_today"
	}
	return "middle_today"
}

func nightRecordDateForDetail(businessDate, detail string) string {
	_ = detail
	return businessDate
}

// resolveAttendanceDate 返回按班次解释的统一业务日（attendance_date）。
func resolveAttendanceDate(shift, shiftDetail string, period *TgPeriodInfo, now time.Time, loc *time.Location) string {
	now = now.In(loc)
	if shift == "day" {
		return now.Format("2006-01-02")
	}
	if shift == "middle" && shiftDetail == "middle_prev" {
		return now.AddDate(0, 0, -1).Format("2006-01-02")
	}
	bd := now.Format("2006-01-02")
	if period != nil && strings.TrimSpace(period.BusinessDate) != "" {
		bd = period.BusinessDate
	}
	return nightRecordDateForDetail(bd, shiftDetail)
}

func (s *WorkforceTelegramService) resolveCurrentShiftWithGrace(settings *TelegramSettings, grace TgGraceConfig, now time.Time) (shift, shiftDetail string, err error) {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)

	if !settings.MultiShiftEnabled() {
		if s.isCheckInWindowForShift(settings, grace, "day", now) {
			return "day", "", nil
		}
		return "", "", ErrOutsideWorkWindow
	}

	if s.isCheckInWindowForShift(settings, grace, "day", now) {
		return "day", "", nil
	}
	if settings.TripleShiftEnabled && s.isCheckInWindowForShift(settings, grace, "middle", now) {
		return "middle", resolveMiddleShiftDetail(settings, now), nil
	}
	if s.isCheckInWindowForShift(settings, grace, "night", now) {
		return "night", resolveNightShiftDetail(settings, now), nil
	}
	return "", "", ErrOutsideWorkWindow
}

func (s *WorkforceTelegramService) isForcedShiftAllowed(settings *TelegramSettings, grace TgGraceConfig, forcedShift string, now time.Time) bool {
	forced, _ := normalizeShiftType(forcedShift)
	return s.isCheckInWindowForShift(settings, grace, forced, now)
}

func shiftWindowHint(settings *TelegramSettings, forcedShift string) string {
	forced, _ := normalizeShiftType(forcedShift)
	start := shiftStartClock(settings, forced)
	return fmt.Sprintf("当前不在%s上班窗口，请在 %s 前后（含宽容）内打%s卡", shiftLabel(forced), start, shiftLabel(forced))
}

func shiftDetailForCheckIn(settings *TelegramSettings, shift string, now time.Time) string {
	switch shift {
	case "night":
		return resolveNightShiftDetail(settings, now)
	case "middle":
		return resolveMiddleShiftDetail(settings, now)
	default:
		return ""
	}
}

func (s *WorkforceTelegramService) resolveShiftForCheckIn(settings *TelegramSettings, grace TgGraceConfig, shiftWindowDisabled bool, forcedShift string, now time.Time) (shift, shiftDetail string, err error) {
	if forcedShift != "" {
		shift, err = normalizeShiftType(forcedShift)
		if err != nil {
			return "", "", err
		}
		if shift == "middle" && !settings.TripleShiftEnabled {
			return "", "", fmt.Errorf("三班模式未启用")
		}
		if shiftWindowDisabled {
			return shift, shiftDetailForCheckIn(settings, shift, now), nil
		}
		if !s.isForcedShiftAllowed(settings, grace, forcedShift, now) {
			return "", "", fmt.Errorf("%s；%w", shiftWindowHint(settings, forcedShift), ErrOutsideWorkWindow)
		}
		return shift, shiftDetailForCheckIn(settings, shift, now), nil
	}
	if shiftWindowDisabled {
		if settings.MultiShiftEnabled() {
			if shift, detail, err := s.resolveCurrentShiftWithGrace(settings, grace, now); err == nil {
				return shift, detail, nil
			}
		}
		return "day", "", nil
	}
	return s.resolveCurrentShiftWithGrace(settings, grace, now)
}

func shiftDetailLabel(detail string) string {
	switch strings.TrimSpace(detail) {
	case "night_last":
		return "（昨晚夜班）"
	case "night_tonight":
		return "（今晚夜班）"
	case "middle_prev":
		return "（昨日中班）"
	case "middle_today":
		return "（今日中班）"
	default:
		return ""
	}
}

package services

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"
)

type TgActivityRankEntry struct {
	Rank         int
	EmployeeName string
	TotalSeconds int
	TotalCount   int
	IsActive     bool
}

type TgActivityRankGroup struct {
	ActivityName string
	ActivityCode string
	Entries      []TgActivityRankEntry
}

func formatDurationZh(seconds int) string {
	return FormatDurationZh(seconds)
}

// FormatDurationZh 将秒数格式化为中文「时分秒」，供 handlers 等包外调用。
func FormatDurationZh(seconds int) string {
	if seconds <= 0 {
		return "0秒"
	}
	m, s := seconds/60, seconds%60
	h := m / 60
	m = m % 60
	if h > 0 {
		return fmt.Sprintf("%d小时%d分%d秒", h, m, s)
	}
	if m > 0 {
		return fmt.Sprintf("%d分%d秒", m, s)
	}
	return fmt.Sprintf("%d秒", s)
}

func (s *WorkforceTelegramService) resolveStatsQuery(ctx context.Context, chatID, shift string, now time.Time) (businessDate string, queryDate string, splitDual bool, nightDate, dayDate string, err error) {
	settings, _ := s.GetSettings(ctx)
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	period, err := s.DetermineCurrentPeriod(ctx, chatID, now)
	if err != nil {
		fallback := now.Format("2006-01-02")
		return fallback, fallback, false, "", "", err
	}
	cfg, _ := s.GetHandoverConfig(ctx, chatID)
	dec := float64(now.Hour()) + float64(now.Minute())/60.0
	nh, nm, _ := parseClock(cfg.NightStartTime)
	dh, dm, _ := parseClock(cfg.DayStartTime)
	nightDec := float64(nh) + float64(nm)/60.0
	dayDec := float64(dh) + float64(dm)/60.0
	isNight := dec >= nightDec || dec < dayDec

	if shift == "day" {
		businessDate = resolveAttendanceDate("day", "", period, now, loc)
		return businessDate, businessDate, false, "", "", nil
	}
	if shift == "night" {
		detail := resolveNightShiftDetail(settings, now)
		businessDate = resolveAttendanceDate("night", detail, period, now, loc)
		queryDate = businessDate
		if !isNight {
			t, _ := time.Parse("2006-01-02", businessDate)
			queryDate = t.AddDate(0, 0, -1).Format("2006-01-02")
		}
		return businessDate, queryDate, false, "", "", nil
	}
	if isNight {
		nightBD := resolveAttendanceDate("night", resolveNightShiftDetail(settings, now), period, now, loc)
		dayBD := resolveAttendanceDate("day", "", period, now, loc)
		if dayBD != nightBD {
			return nightBD, nightBD, true, nightBD, dayBD, nil
		}
		return nightBD, nightBD, false, "", "", nil
	}
	businessDate = resolveAttendanceDate("day", "", period, now, loc)
	return businessDate, businessDate, false, "", "", nil
}

func (s *WorkforceTelegramService) ListActivityRankGroups(ctx context.Context, chatID, shift string) ([]TgActivityRankGroup, string, error) {
	types, err := s.ListEnabledActivityTypesForWorker(ctx)
	if err != nil {
		return nil, "", err
	}
	now := time.Now()
	businessDate, _, _, nightDate, dayDate, err := s.resolveStatsQuery(ctx, chatID, shift, now)
	if err != nil {
		businessDate = now.Format("2006-01-02")
	}
	settings, _ := s.GetSettings(ctx)
	header := fmt.Sprintf("📅 统计周期：%s\n⏰ 重置：%s", businessDate, settings.DailyResetTime)

	groups := make([]TgActivityRankGroup, 0)
	for _, act := range types {
		dates := []string{businessDate}
		if shift == "" && nightDate != "" && dayDate != "" {
			dates = []string{dayDate, nightDate}
		} else if shift == "night" && nightDate != "" {
			dates = []string{nightDate}
		} else if shift == "day" && dayDate != "" {
			dates = []string{dayDate}
		}

		chatFilter := strings.TrimSpace(chatID)
		rows, err := s.db.QueryContext(ctx, `
			SELECT e.name,
				COALESCE(SUM(CASE WHEN s.status = 'closed' THEN s.elapsed_seconds ELSE EXTRACT(EPOCH FROM (NOW()-s.started_at))::int END),0)::int,
				COUNT(CASE WHEN s.status = 'closed' THEN 1 END)::int,
				BOOL_OR(s.status = 'open') AS is_active
			FROM wf_tg_activity_sessions s
			JOIN employees e ON e.id = s.employee_id
			WHERE s.activity_code = $1 AND s.attendance_date = ANY($2::date[])
			  AND ($3 = '' OR COALESCE(s.source_chat_id,'') = $3
			       OR e.id IN (SELECT employee_id FROM employee_telegram_bindings WHERE chat_id = $3 AND status = 1))
			GROUP BY e.id, e.name
			HAVING BOOL_OR(s.status = 'open') OR COUNT(CASE WHEN s.status = 'closed' THEN 1 END) > 0
			ORDER BY BOOL_OR(s.status = 'open') DESC, 2 DESC, 3 DESC
			LIMIT 15`, act.Code, pq.Array(dates), chatFilter)
		if err != nil {
			continue
		}
		entries := make([]TgActivityRankEntry, 0)
		rank := 0
		for rows.Next() {
			var name string
			var totalSec, count int
			var active bool
			if rows.Scan(&name, &totalSec, &count, &active) != nil {
				continue
			}
			rank++
			entries = append(entries, TgActivityRankEntry{
				Rank: rank, EmployeeName: name, TotalSeconds: totalSec, TotalCount: count, IsActive: active,
			})
		}
		rows.Close()
		if len(entries) > 0 {
			groups = append(groups, TgActivityRankGroup{ActivityName: act.Name, ActivityCode: act.Code, Entries: entries})
		}
	}
	return groups, header, nil
}

func (s *WorkforceTelegramService) FormatActivityRankingsText(groups []TgActivityRankGroup, header, shift string) string {
	if shift == "day" {
		header = "🏆 【白班】活动排行榜\n" + header
	} else if shift == "night" {
		header = "🏆 【夜班】活动排行榜\n" + header
	} else {
		header = "🏆 活动排行榜\n" + header
	}
	if len(groups) == 0 {
		return header + "\n\n暂无排行数据"
	}
	var b strings.Builder
	b.WriteString(header)
	b.WriteString("\n\n")
	for _, g := range groups {
		b.WriteString(fmt.Sprintf("📈 %s：\n", g.ActivityName))
		for _, e := range g.Entries {
			if e.IsActive && e.TotalSeconds == 0 {
				b.WriteString(fmt.Sprintf("  %d. 🟡 %s - 进行中\n", e.Rank, e.EmployeeName))
			} else if e.TotalSeconds > 0 {
				b.WriteString(fmt.Sprintf("  %d. 🟢 %s - %s (%d次)\n", e.Rank, e.EmployeeName, formatDurationZh(e.TotalSeconds), e.TotalCount))
			}
		}
		b.WriteString("\n")
	}
	return strings.TrimSpace(b.String())
}

func (s *WorkforceTelegramService) BuildRichMyInfo(ctx context.Context, telegramUserID int64, shiftFilter, chatID string) (string, error) {
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil {
		return "", err
	}
	var empName string
	if strings.TrimSpace(chatID) == "" {
		_ = s.db.QueryRowContext(ctx, `
			SELECT e.name, COALESCE(b.chat_id,'')
			FROM employees e
			LEFT JOIN employee_telegram_bindings b ON b.employee_id = e.id AND b.status = 1
			WHERE e.id = $1`, empID).Scan(&empName, &chatID)
	} else {
		_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, empID).Scan(&empName)
	}

	settings, _ := s.GetSettings(ctx)
	now := time.Now()
	businessDate, queryDate, splitDual, nightDate, dayDate, _ := s.resolveStatsQuery(ctx, chatID, shiftFilter, now)
	period, _ := s.DetermineCurrentPeriod(ctx, chatID, now)

	var b strings.Builder
	if shiftFilter == "day" {
		b.WriteString(fmt.Sprintf("👤 %s\n📊 【白班】记录统计\n", empName))
	} else if shiftFilter == "night" {
		b.WriteString(fmt.Sprintf("👤 %s\n📊 【夜班】记录统计\n", empName))
	} else {
		b.WriteString(fmt.Sprintf("👤 %s\n📊 当前周期记录\n", empName))
	}
	b.WriteString(fmt.Sprintf("📅 统计周期：%s\n⏰ 重置时间：%s\n", businessDate, settings.DailyResetTime))
	if period != nil && period.IsHandover {
		b.WriteString(s.handoverStatusHint(ctx, chatID, period) + "\n")
	}
	b.WriteString("\n")

	// work sessions
	wsQuery := `
		SELECT shift_type, checkin_time, checkout_time, status
		FROM work_sessions WHERE employee_id = $1 AND attendance_date = $2::date`
	wsArgs := []interface{}{empID, queryDate}
	if shiftFilter != "" {
		wsQuery += ` AND shift_type = $3`
		wsArgs = append(wsArgs, shiftFilter)
	}
	wsQuery += ` ORDER BY checkin_time ASC`
	wsRows, _ := s.db.QueryContext(ctx, wsQuery, wsArgs...)
	if wsRows != nil {
		defer wsRows.Close()
		hasWork := false
		for wsRows.Next() {
			var sh, st string
			var in time.Time
			var out sql.NullTime
			if wsRows.Scan(&sh, &in, &out, &st) != nil {
				continue
			}
			if !hasWork {
				b.WriteString("🕒 上下班记录\n")
				hasWork = true
			}
			outStr := "进行中"
			if out.Valid {
				outStr = out.Time.Format("15:04:05")
			}
			b.WriteString(fmt.Sprintf("• %s 上班 %s → %s\n", shiftLabel(sh), in.Format("15:04:05"), outStr))
		}
		if hasWork {
			b.WriteString("\n")
		}
	}

	types, _ := s.ListActivityTypes(ctx)
	cycle := 1
	if period != nil {
		cycle = s.effectiveActivityCycle(ctx, chatID, empID, period)
	}

	dates := []string{queryDate}
	if splitDual && shiftFilter == "" {
		dates = []string{dayDate, nightDate}
	}

	b.WriteString("📋 活动统计\n")
	for _, act := range types {
		if !act.Enabled {
			continue
		}
		for _, d := range dates {
			shifts := []string{shiftFilter}
			if shiftFilter == "" {
				shifts = []string{"day", "middle", "night"}
			}
			for _, sh := range shifts {
				if shiftFilter == "" && splitDual {
					if d == dayDate && sh == "night" {
						continue
					}
					if d == nightDate && sh == "day" {
						continue
					}
				}
				count, _ := s.countActivitiesOnDate(ctx, empID, act.Code, d, sh, cycle)
				var totalSec int
				_ = s.db.QueryRowContext(ctx, `
					SELECT COALESCE(SUM(elapsed_seconds),0) FROM wf_tg_activity_sessions
					WHERE employee_id = $1 AND activity_code = $2 AND attendance_date = $3::date AND shift_type = $4 AND status = 'closed'`,
					empID, act.Code, d, sh).Scan(&totalSec)
				limitStr := "不限"
				if act.MaxTimesPerDay > 0 {
					limitStr = fmt.Sprintf("%d", act.MaxTimesPerDay)
				}
				if count > 0 || totalSec > 0 {
					b.WriteString(fmt.Sprintf("• %s(%s) %d/%s 次 · %s\n",
						act.Name, shiftLabel(sh), count, limitStr, formatDurationZh(totalSec)))
				}
			}
		}
	}

	if sess, err := s.getOpenActivitySession(ctx, empID); err == nil {
		b.WriteString(fmt.Sprintf("\n🟡 进行中：%s（%s）\n", sess.ActivityName, formatDurationZh(int(time.Since(sess.StartedAt).Seconds()))))
	}

	var fineTotal float64
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(SUM(fine_amount),0) FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND attendance_date = ANY($2::date[]) AND status = 'closed'`,
		empID, pq.Array(dates)).Scan(&fineTotal)
	if fineTotal > 0 {
		b.WriteString(fmt.Sprintf("\n💰 今日活动罚款：%s", FormatFineMoney(fineTotal, s.FineCurrencyCode(ctx))))
	}
	out := strings.TrimSpace(b.String())
	if !strings.Contains(out, "•") && !strings.Contains(out, "🟡") && !strings.Contains(out, "🕒") {
		out += "\n\n暂无记录"
	}
	return out, nil
}

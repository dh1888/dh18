package services

import (
	"context"
	"database/sql"
	"fmt"
	"sort"
	"strings"

	"github.com/google/uuid"
)

// TgDeviceTagSep separates action label and short device tag on reply-keyboard buttons.
// Example: "🚽 小厕 · A"
const TgDeviceTagSep = " · "

type workstationDeviceTag struct {
	Device workstationTGDevice
	Tag    string
}

type TelegramPunchDeviceOption struct {
	DeviceID     uuid.UUID `json:"deviceId"`
	DeviceName   string    `json:"deviceName"`
	EmployeeID   uuid.UUID `json:"employeeId"`
	EmployeeName string    `json:"employeeName"`
}

// ListTelegramPunchDeviceOptions returns bound workstations that currently have
// an employee logged in. The bot uses this to ask for a device only when the
// action would otherwise be ambiguous.
func (s *WorkforceTelegramService) ListTelegramPunchDeviceOptions(
	ctx context.Context, telegramUserID int64,
) ([]TelegramPunchDeviceOption, error) {
	devices, err := s.listWorkstationDevicesForTelegram(ctx, telegramUserID)
	if err != nil {
		return nil, err
	}
	out := make([]TelegramPunchDeviceOption, 0, len(devices))
	for _, device := range devices {
		empID, loginErr := s.resolveWorkstationLoggedInEmployee(ctx, device.ID)
		if loginErr == ErrPCLoginRequired {
			continue
		}
		if loginErr != nil {
			return nil, loginErr
		}
		var employeeName string
		if err := s.db.QueryRowContext(ctx,
			`SELECT COALESCE(name, '') FROM employees WHERE id = $1`, empID,
		).Scan(&employeeName); err != nil && err != sql.ErrNoRows {
			return nil, err
		}
		out = append(out, TelegramPunchDeviceOption{
			DeviceID: device.ID, DeviceName: device.Name,
			EmployeeID: empID, EmployeeName: strings.TrimSpace(employeeName),
		})
	}
	return out, nil
}

// SplitTgDeviceTag splits "动作 · 标记" into base label and device hint.
func SplitTgDeviceTag(text string) (base, deviceHint string) {
	text = strings.TrimSpace(text)
	if text == "" {
		return "", ""
	}
	idx := strings.LastIndex(text, TgDeviceTagSep)
	if idx <= 0 {
		return text, ""
	}
	base = strings.TrimSpace(text[:idx])
	deviceHint = strings.TrimSpace(text[idx+len(TgDeviceTagSep):])
	if base == "" || deviceHint == "" {
		return text, ""
	}
	return base, deviceHint
}

func JoinTgDeviceTag(label, tag string) string {
	label = strings.TrimSpace(label)
	tag = strings.TrimSpace(tag)
	if label == "" {
		return tag
	}
	if tag == "" {
		return label
	}
	return label + TgDeviceTagSep + tag
}

// buildWorkstationDeviceTags assigns stable short tags A, B, C… (then A1, B1…).
// Order is by device UUID so the same PC keeps the same letter across refreshes.
func buildWorkstationDeviceTags(devices []workstationTGDevice) []workstationDeviceTag {
	sorted := append([]workstationTGDevice(nil), devices...)
	sort.Slice(sorted, func(i, j int) bool {
		return sorted[i].ID.String() < sorted[j].ID.String()
	})
	out := make([]workstationDeviceTag, 0, len(sorted))
	for i, d := range sorted {
		out = append(out, workstationDeviceTag{
			Device: d,
			Tag:    shortDeviceLetterTag(i),
		})
	}
	return out
}

func shortDeviceLetterTag(index int) string {
	if index < 0 {
		index = 0
	}
	if index < 26 {
		return string(rune('A' + index))
	}
	// 27th+ → A1, B1, … then A2…
	cycle := index / 26
	letter := index % 26
	return fmt.Sprintf("%c%d", 'A'+letter, cycle)
}

// FormatWorkstationDeviceTagLegend explains short tags, e.g. "A=DESKTOP-1  B=DESKTOP-2".
func FormatWorkstationDeviceTagLegend(tags []workstationDeviceTag) string {
	if len(tags) == 0 {
		return ""
	}
	parts := make([]string, 0, len(tags))
	for _, t := range tags {
		name := strings.TrimSpace(t.Device.Name)
		if name == "" {
			name = t.Device.ID.String()
			if len(name) > 8 {
				name = name[:8]
			}
		}
		parts = append(parts, t.Tag+"="+name)
	}
	return "设备标记：" + strings.Join(parts, "  ")
}

// allWorkstationDeviceTagsForTelegram returns stable A/B tags for every bound device
// when the TG has 2+ workstation bindings (for legends / matching).
func (s *WorkforceTelegramService) allWorkstationDeviceTagsForTelegram(ctx context.Context, telegramUserID int64) ([]workstationDeviceTag, error) {
	if telegramUserID <= 0 {
		return nil, nil
	}
	devices, err := s.listWorkstationDevicesForTelegram(ctx, telegramUserID)
	if err != nil {
		return nil, err
	}
	if len(devices) < 2 {
		return nil, nil
	}
	return buildWorkstationDeviceTags(devices), nil
}

// workstationDeviceTagsForTelegram returns tags to put on the reply keyboard.
// Only devices with an active PC employee login are shown. If 0–1 PCs are logged
// in, returns nil so the user gets a normal single-column keyboard (that one
// logged-in station is selected automatically on punch).
func (s *WorkforceTelegramService) workstationDeviceTagsForTelegram(ctx context.Context, telegramUserID int64) ([]workstationDeviceTag, error) {
	all, err := s.allWorkstationDeviceTagsForTelegram(ctx, telegramUserID)
	if err != nil || len(all) == 0 {
		return nil, err
	}
	loggedIn := make([]workstationDeviceTag, 0, len(all))
	for _, t := range all {
		if _, loginErr := s.resolveWorkstationLoggedInEmployee(ctx, t.Device.ID); loginErr == nil {
			loggedIn = append(loggedIn, t)
		}
	}
	if len(loggedIn) < 2 {
		return nil, nil
	}
	return loggedIn, nil
}

func matchWorkstationDeviceByHint(devices []workstationTGDevice, hint string) (workstationTGDevice, error) {
	hint = strings.TrimSpace(hint)
	if hint == "" {
		return workstationTGDevice{}, ErrWorkstationDeviceRequired
	}
	tags := buildWorkstationDeviceTags(devices)
	hintLower := strings.ToLower(hint)

	var exact []workstationTGDevice
	for _, t := range tags {
		if strings.EqualFold(t.Tag, hint) {
			exact = append(exact, t.Device)
		}
	}
	if len(exact) == 1 {
		return exact[0], nil
	}
	if len(exact) > 1 {
		return workstationTGDevice{}, fmt.Errorf("%w: ambiguous device tag", ErrWorkstationDeviceRequired)
	}

	if id, err := uuid.Parse(hint); err == nil {
		for _, d := range devices {
			if d.ID == id {
				return d, nil
			}
		}
	}
	// Hostname / UUID prefix when unique (legacy / manual input).
	var prefixHits []workstationTGDevice
	for _, d := range devices {
		idRaw := strings.ReplaceAll(d.ID.String(), "-", "")
		nameLower := strings.ToLower(strings.TrimSpace(d.Name))
		if strings.HasPrefix(strings.ToLower(idRaw), hintLower) ||
			(nameLower != "" && (nameLower == hintLower || strings.HasPrefix(nameLower, hintLower))) {
			prefixHits = append(prefixHits, d)
		}
	}
	if len(prefixHits) == 1 {
		return prefixHits[0], nil
	}
	return workstationTGDevice{}, ErrWorkstationDeviceNotBound
}

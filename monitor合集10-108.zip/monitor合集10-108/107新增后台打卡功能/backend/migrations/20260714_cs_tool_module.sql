-- 客服工具模块：权限种子
UPDATE roles
SET permissions = (
    SELECT COALESCE(jsonb_agg(DISTINCT val), '[]'::jsonb)
    FROM (
        SELECT jsonb_array_elements_text(permissions) AS val
        FROM roles
        WHERE name = '管理员'
        UNION ALL
        SELECT unnest(ARRAY[
            'cstool:view',
            'cstool:settings'
        ])
    ) t
),
updated_at = NOW()
WHERE name = '管理员';

UPDATE roles
SET permissions = (
    SELECT COALESCE(jsonb_agg(DISTINCT val), '[]'::jsonb)
    FROM (
        SELECT jsonb_array_elements_text(permissions) AS val
        FROM roles
        WHERE name = '操作员'
        UNION ALL
        SELECT unnest(ARRAY[
            'cstool:view',
            'cstool:settings'
        ])
    ) t
),
updated_at = NOW()
WHERE name = '操作员';

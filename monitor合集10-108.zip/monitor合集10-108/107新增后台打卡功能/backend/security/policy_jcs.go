package security

import (
	"encoding/json"
	"fmt"

	"webpki.org/jsoncanonicalizer"
)

// CanonicalizePolicyPayload JSON-marshals the normalized payload and applies RFC 8785 JCS.
func CanonicalizePolicyPayload(payload PolicySignPayload) ([]byte, error) {
	encoded, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("marshal policy sign payload: %w", err)
	}
	return CanonicalizeJSON(encoded)
}

// CanonicalizeJSON applies RFC 8785 JCS using the cyberphone reference implementation.
func CanonicalizeJSON(jsonBytes []byte) ([]byte, error) {
	canonical, err := jsoncanonicalizer.Transform(jsonBytes)
	if err != nil {
		return nil, fmt.Errorf("jcs transform: %w", err)
	}
	return canonical, nil
}

// CanonicalizePolicyFromContent parses, normalizes, and canonicalizes stored policy content.
func CanonicalizePolicyFromContent(content string) ([]byte, PolicySignPayload, error) {
	payload, err := NormalizePolicySignPayloadFromContent(content)
	if err != nil {
		return nil, PolicySignPayload{}, err
	}
	canonical, err := CanonicalizePolicyPayload(payload)
	if err != nil {
		return nil, PolicySignPayload{}, err
	}
	return canonical, payload, nil
}

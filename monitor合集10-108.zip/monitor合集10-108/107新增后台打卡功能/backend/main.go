package main

import (
	"context"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"

	"enterprise-agent/backend/config"
	"enterprise-agent/backend/handlers"
	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/models"
	"enterprise-agent/backend/routes"
	"enterprise-agent/backend/services"
	"enterprise-agent/backend/internal/domainmonitor"
	"enterprise-agent/backend/internal/callback"
)
func main() {
    // 加载环境变量
    if err := godotenv.Load(); err != nil {
        log.Println("Warning: .env file not found, using environment variables")
    }

    // 设置 Gin 为发布模式（生产环境）
    if os.Getenv("ENV") == "production" {
        gin.SetMode(gin.ReleaseMode)
        log.Println("Running in production mode (ReleaseMode)")
    }

    // 验证必要的环境变量
    if os.Getenv("JWT_SECRET") == "" {
        log.Fatal("FATAL: JWT_SECRET environment variable is required")
    }
    if os.Getenv("DB_PASSWORD") == "" {
        log.Fatal("FATAL: DB_PASSWORD environment variable is required")
    }
    log.Println("Environment validation passed")

    // 验证所有必需的配置
    if err := models.ValidateConfig(); err != nil {
        log.Fatalf("Configuration error: %v", err)
    }
    log.Println("Configuration validated successfully")

    // 初始化数据库
    db := services.NewDatabase()
    middleware.InitPermissionDB(db)
    middleware.InitEmployeeScopeDB(db)
    redis := services.NewRedis()
    if redis != nil {
        pingCtx, pingCancel := context.WithTimeout(context.Background(), 3*time.Second)
        if err := redis.Ping(pingCtx).Err(); err != nil {
            log.Printf("Warning: Redis ping failed at startup: %v (refresh token operations will fail until Redis is available)", err)
        } else {
            log.Println("Redis connection verified")
        }
        pingCancel()
    }
    minio := services.NewMinIO()

    startupCtx, startupCancel := context.WithTimeout(context.Background(), 10*time.Second)
    if err := services.ValidateDeploymentConsistency(startupCtx, redis, minio); err != nil {
        startupCancel()
        log.Fatalf("FATAL: deployment consistency check failed: %v", err)
    }
    startupCancel()
    log.Println("Deployment consistency check passed")

    sessionSvc := services.NewSessionService(db, redis)
    middleware.InitSessionService(sessionSvc)
    sessionMaintenanceCtx, sessionMaintenanceCancel := context.WithCancel(context.Background())
    services.StartSessionMaintenance(sessionMaintenanceCtx, sessionSvc)
    deploymentDriftCtx, deploymentDriftCancel := context.WithCancel(context.Background())
    services.StartDeploymentDriftMonitor(deploymentDriftCtx, redis, minio)
    log.Println("Session SSOT auth enabled (JWT sid-only, auth_sessions as source of truth)")
    log.Printf("Upload auth: DeviceAuth + HMAC required; WS ticket required: %v", services.WSTicketRequired())
    log.Printf("WS session guard interval: %v", services.WSSessionGuardInterval())

    // 创建 WebSocket Hub
    wsHub := services.NewWebSocketHubWithRedis(redis)
    wsHub.SetSessionService(sessionSvc)
    sessionSvc.SetRevokeHook(func(event services.SessionRevokeEvent) {
        services.GlobalMetrics.SessionRevokes.Add(1)
        wsHub.DisconnectAdminsBySession(event.SessionID, event.Reason)
        wsHub.DisconnectAgentsBySession(event.SessionID, event.Reason)
    })
    var sessionRevokeCancel context.CancelFunc
    if redis != nil {
        var revokeCtx context.Context
        revokeCtx, sessionRevokeCancel = context.WithCancel(context.Background())
        services.StartSessionRevokeListener(revokeCtx, redis, func(event services.SessionRevokeEvent) {
            services.GlobalMetrics.SessionRevokes.Add(1)
            wsHub.DisconnectAdminsBySession(event.SessionID, event.Reason)
            wsHub.DisconnectAgentsBySession(event.SessionID, event.Reason)
        })
    }

    // 初始化所有 Repository
    deviceRepo := services.NewDeviceRepository(db)
    policyRepo := services.NewPolicyRepository(db)
    recordingRepo := services.NewRecordingRepository(db, minio)
    taskRepo := services.NewTaskRepository(db)
    screenshotRepo := services.NewScreenshotRepository(db)
    activityRepo := services.NewActivityRepository(db)
    cleanupRepo := services.NewCleanupRepositoryWithAll(db, recordingRepo, screenshotRepo, activityRepo, minio)
    userRepo := services.NewUserRepository(db)
    workforceSvc := services.NewWorkforceService(db)
    systemSettingsSvc := services.NewSystemSettingsService(db)
    config.SetCorsOriginsProvider(systemSettingsSvc.GetEffectiveCorsOrigins)
    wsHub.SetActivityRepository(activityRepo)
    wsHub.SetDeviceRepository(deviceRepo)

    go cleanupRepo.StartAutoCleanup()

    taskMonitorCtx, taskMonitorCancel := context.WithCancel(context.Background())
    go taskRepo.StartStaleTaskMonitor(taskMonitorCtx)

    workforceCtx, workforceCancel := context.WithCancel(context.Background())
    services.StartAttendanceScheduler(workforceCtx, workforceSvc)
    _ = workforceCancel

    // ========== 磁盘监控服务 ==========
    uploadsDir := os.Getenv("UPLOADS_DIR")
    if uploadsDir == "" {
        uploadsDir = "./uploads"
    }

    // 转换为绝对路径
    uploadsDirAbs, err := filepath.Abs(uploadsDir)
    if err != nil {
        log.Fatalf("failed to resolve uploads directory: %v", err)
    }
    uploadsDir = uploadsDirAbs

    // 确保目录存在
    if err := os.MkdirAll(uploadsDir, 0755); err != nil {
        log.Fatalf("Failed to create uploads dir: %v", err)
    }

    // 创建数据目录（用于安全配置）
    dataDir, err := filepath.Abs(filepath.Join(".", "data"))
    if err != nil {
        log.Fatalf("failed to resolve data directory: %v", err)
    }
    if err := os.MkdirAll(dataDir, 0755); err != nil {
        log.Fatalf("failed to create data directory: %v", err)
    }

    // 创建磁盘监控器
    diskMonitor := services.NewDiskMonitor(cleanupRepo, uploadsDir)
    diskMonitor.SetInterval(10 * time.Minute)
    diskMonitor.SetThreshold(85)
    go diskMonitor.Start(context.Background())
    log.Printf("[Main] Disk monitor started: interval=10m, threshold=85%%")

    alertService := services.NewAlertService(deviceRepo, taskRepo, uploadsDir)
    alertMonitorCtx, alertMonitorCancel := context.WithCancel(context.Background())
    go alertService.StartMonitor(alertMonitorCtx)

    // 初始化截图安全配置
    handlers.InitScreenshotSecurity(uploadsDir, dataDir)
    log.Println("Screenshot security initialized")

    // 初始化 Handlers
    userHandler := handlers.NewUserHandler(userRepo, services.NewTOTPAuthService(redis), systemSettingsSvc, workforceSvc)
    screenshotHandler := handlers.NewScreenshotHandler(screenshotRepo, deviceRepo)
    activityHandler := handlers.NewActivityHandler(activityRepo, deviceRepo)
    authHandler := handlers.NewAuthHandler(db, redis, sessionSvc, wsHub, systemSettingsSvc, userRepo)
    clientProtectionSvc := services.NewClientProtectionService(db)
    clientProtectionSvc.SetWebSocketHub(wsHub)
    wsHub.SetClientProtectionService(clientProtectionSvc)

    deviceHandler := handlers.NewDeviceHandler(deviceRepo, wsHub, redis, workforceSvc, sessionSvc, clientProtectionSvc)
    policyHandler := handlers.NewPolicyHandler(policyRepo, wsHub, clientProtectionSvc)
    recordingHandler := handlers.NewRecordingHandler(recordingRepo, deviceRepo)
    uploadHandler := handlers.NewUploadHandler(recordingRepo, screenshotRepo, minio, taskRepo, deviceRepo)
    taskHandler := handlers.NewTaskHandler(taskRepo, wsHub, deviceRepo, alertService)
    cleanupHandler := handlers.NewCleanupHandler(cleanupRepo)
    agentNotifySvc := services.NewAgentNotificationService(db, wsHub)
    mailSvc := services.NewMailService()
    adminHandler := handlers.NewAdminHandler(db, workforceSvc, services.NewPerformancePushService(db), services.NewPenaltyPushService(db), agentNotifySvc, mailSvc, services.NewCsToolSettingsService(db))
    workforceTelegramSvc := services.NewWorkforceTelegramService(db, workforceSvc)
    workforceTelegramSvc.SetWebSocketHub(wsHub)
    workforceTelegramSvc.SetAgentNotificationService(agentNotifySvc)
    workforceHandler := handlers.NewWorkforceHandler(db, workforceSvc, workforceTelegramSvc, userRepo, deviceRepo, wsHub)
    workforceTelegramHandler := handlers.NewWorkforceTelegramHandler(db, workforceTelegramSvc, wsHub)
    tgResetCtx, tgResetCancel := context.WithCancel(context.Background())
    services.StartTelegramDailyResetScheduler(tgResetCtx, workforceTelegramSvc)
    services.StartTelegramActivityTimerScheduler(tgResetCtx, workforceTelegramSvc)
    services.StartTelegramMaintenanceScheduler(tgResetCtx, workforceTelegramSvc)
    go workforceTelegramSvc.RecoverMissedDailyResets(context.Background())
    go workforceTelegramSvc.RecoverExpiredActivities(context.Background())
    go workforceTelegramSvc.RecoverGroupShiftStates(context.Background())
    _ = tgResetCancel
    operationLogHandler := handlers.NewOperationLogHandler(db)
    settingsHandler := handlers.NewSettingsHandler(systemSettingsSvc, clientProtectionSvc)

    liveKitCfg := config.LoadLiveKitConfig()
    remoteViewRepo := services.NewRemoteViewRepository(db)
    remoteViewSvc := services.NewRemoteViewService(liveKitCfg, remoteViewRepo, deviceRepo, policyRepo, wsHub)
    wsHub.SetRemoteViewService(remoteViewSvc)

    diagnosticSvc := services.NewDiagnosticService(db, wsHub)
    diagnosticSvc.SetRemoteViewService(remoteViewSvc)
    diagnosticSvc.SetDeviceRepository(deviceRepo)
    wsHub.SetDiagnosticService(diagnosticSvc)
    diagnosticHandler := handlers.NewDiagnosticHandler(diagnosticSvc)

    sweepCtx, sweepCancel := context.WithTimeout(context.Background(), 30*time.Second)
    remoteViewSvc.SweepZombieSessions(sweepCtx)
    sweepCancel()
    remoteViewHandler := handlers.NewRemoteViewHandler(remoteViewSvc)

    mediaTokenSvc := services.NewMediaTokenService(redis, sessionSvc)
    mediaTokenHandler := handlers.NewMediaTokenHandler(mediaTokenSvc, recordingRepo, screenshotRepo)
    wsTicketHandler := handlers.NewWSTicketHandler(sessionSvc)
    notificationHandler := handlers.NewNotificationHandler(db)

    handlers.GlobalLogger = operationLogHandler

    handlers.InitUploadSessionStore(redis)
    chunkStore := services.NewUploadChunkStore(minio)
    handlers.InitUploadChunkStore(minio)
    handlers.InitUploadManifestStore(redis, chunkStore)
    handlers.InitUploadCompleteLock(redis)
    middleware.InitSignatureNonceStore(redis)

    healthHandler := handlers.NewHealthHandler(db, redis, uploadsDir)
    healthHandler.SetLiveKitPing(remoteViewSvc.PingLiveKit)

    // 创建 Gin 路由
    router := gin.New()
    router.Use(middleware.Logger())
    router.Use(middleware.Metrics())
    router.Use(middleware.Recovery())
    router.Use(middleware.SecurityHeaders())
    router.Use(middleware.CORS())
    // 媒体文件通过鉴权 API 访问（/recordings/:id/stream、/screenshots/:id/image），禁止静态公开目录
    router.Use(handlers.OperationLogMiddleware(db))

    // 健康检查：/health 公开；/ready 与 /metrics 生产环境需 OPS_TOKEN
    router.GET("/health", healthHandler.Live)
    ops := router.Group("")
    ops.Use(middleware.InternalOpsAuth())
    ops.GET("/ready", healthHandler.Ready)
    if os.Getenv("METRICS_ENABLED") == "true" || os.Getenv("METRICS_ENABLED") == "1" {
        ops.GET("/metrics", gin.WrapH(services.GlobalMetrics.Handler()))
        log.Println("Prometheus-style metrics enabled at GET /metrics (ops auth in production)")
    }

    downloadsDir := os.Getenv("CLIENT_DOWNLOAD_DIR")
    if downloadsDir == "" {
        downloadsDir = "./downloads"
    }
    if absDownloads, err := filepath.Abs(downloadsDir); err == nil {
        downloadsDir = absDownloads
    }
    if err := os.MkdirAll(downloadsDir, 0755); err != nil {
        log.Printf("Warning: failed to create downloads dir %s: %v", downloadsDir, err)
    } else {
        log.Printf("Client installer directory: %s (served via authenticated /api/v1/client-download/file)", downloadsDir)
    }

    // 路由配置
    routeHandlers := &routes.Handlers{
        Auth:         authHandler,
        Device:       deviceHandler,
        Policy:       policyHandler,
        Recording:    recordingHandler,
        Upload:       uploadHandler,
        Task:         taskHandler,
        Cleanup:      cleanupHandler,
        Activity:     activityHandler,
        Screenshot:   screenshotHandler,
        User:         userHandler,
        Admin:        adminHandler,
        Workforce:    workforceHandler,
        WorkforceTG:  workforceTelegramHandler,
        OperationLog: operationLogHandler,
        RemoteView:   remoteViewHandler,
        Diagnostic:   diagnosticHandler,
        MediaToken:   mediaTokenHandler,
        Meta:         handlers.NewMetaHandler(db),
        Settings:     settingsHandler,
        WSTicket:     wsTicketHandler,
        Notification: notificationHandler,
    }
    routes.SetupRoutesWithHub(router, routeHandlers, redis, wsHub, deviceRepo)

    domainmonitor.Bootstrap(router, db, redis)
    callback.Bootstrap(router, db, redis)

    port := os.Getenv("PORT")
    if port == "" {
        port = "8080"
    }

    tgBotCtx, tgBotCancel := context.WithCancel(context.Background())
    services.StartTelegramBotRunner(tgBotCtx, workforceTelegramSvc, port)

    listener, err := net.Listen("tcp4", ":"+port)
    if err != nil {
        log.Fatalf("Failed to create listener: %v", err)
    }

    srv := &http.Server{
        Handler:           router,
        ReadHeaderTimeout: 10 * time.Second,
        ReadTimeout:       120 * time.Second,
        WriteTimeout:      300 * time.Second,
        IdleTimeout:       120 * time.Second,
    }

    go func() {
        log.Printf("Server starting on port %s (IPv4)", port)
        if err := srv.Serve(listener); err != nil && err != http.ErrServerClosed {
            log.Fatalf("Failed to start server: %v", err)
        }
    }()

    // 等待退出信号
    quit := make(chan os.Signal, 1)
    signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
    <-quit

    log.Println("Shutting down server...")

    shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 30*time.Second)
    defer shutdownCancel()

    if err := srv.Shutdown(shutdownCtx); err != nil {
        log.Printf("HTTP server shutdown error: %v", err)
    }

    uploadHandler.Stop()
    if sessionRevokeCancel != nil {
        sessionRevokeCancel()
    }
    middleware.CloseSignatureNonceStore()
    taskMonitorCancel()
    sessionMaintenanceCancel()
    deploymentDriftCancel()
    tgBotCancel()
    alertMonitorCancel()
    wsHub.Stop()
    cleanupRepo.Stop()
    diskMonitor.Stop()
    domainmonitor.Stop()

    if db != nil {
        db.Close()
    }
    if redis != nil {
        if err := redis.Close(); err != nil {
            log.Printf("Error closing redis: %v", err)
        }
    }
    log.Println("Server stopped")
}
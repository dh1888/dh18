package domainmonitor

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"sort"
	"strconv"
	"strings"
	"time"
)

const (
	alertTypeMonitorReport   = "monitor_report"
	maxReportFailureItems    = 30
	maxReportFieldRunes      = 180
)

func (e *Engine) sendBatchMonitorReport(ctx context.Context, batch *checkBatch) {
	settings, err := e.repo.GetCheckSettings(ctx)
	if err != nil || !settings.TelegramReportEnabled {
		return
	}
	routes, err := e.repo.MatchRoutes(ctx, alertTypeMonitorReport, "INFO")
	if err != nil || len(routes) == 0 {
		return
	}
	text := buildMonitorReportText(settings, batch.status)
	for _, rt := range routes {
		if sm := strings.ToLower(strings.TrimSpace(rt.SendMode)); sm == "realtime" {
			continue
		}
		var grp DmTelegramGroup
		if err := e.repo.db.WithContext(ctx).First(&grp, "id = ?", rt.GroupID).Error; err != nil {
			continue
		}
		var bot DmTelegramBot
		if err := e.repo.db.WithContext(ctx).First(&bot, "id = ?", grp.BotID).Error; err != nil || !bot.Enabled {
			continue
		}
		token, err := decryptToken(e.cfg.SecretKey, bot.BotTokenEnc)
		if err != nil {
			continue
		}
		if err := telegramSendMessage(token, grp.ChatID, text); err != nil {
			log.Printf("[DomainMonitor] telegram report failed: %v", err)
		}
	}
}

func buildMonitorReportText(settings *CheckSettings, st CheckBatchStatus) string {
	title := strings.TrimSpace(settings.ReportTitle)
	if title == "" {
		title = "域名监控报告"
	}
	tz := strings.TrimSpace(settings.ReportTimezone)
	if tz == "" {
		tz = "UTC"
	}
	server := strings.TrimSpace(settings.ReportServerLabel)
	if server == "" {
		server = "Local Center"
	}
	checkedAt := time.Now().UTC()
	if st.FinishedAt != nil {
		checkedAt = *st.FinishedAt
	}
	loc := parseReportTimezone(tz)
	tzLabel := formatReportTimezoneLabel(tz, loc)
	normal := st.Normal
	if normal == 0 && st.Total > 0 {
		normal = st.Total - st.Failed
	}
	if normal < 0 {
		normal = 0
	}
	avail := 100.0
	if st.Total > 0 {
		avail = float64(normal) / float64(st.Total) * 100
	}

	var b strings.Builder
	b.WriteString("🐈 域名检测报告\n\n")
	b.WriteString(fmt.Sprintf("🕐 检测时间：%s (%s)\n", checkedAt.In(loc).Format("2006-01-02 15:04"), tzLabel))
	b.WriteString(fmt.Sprintf("🌐 服务器：%s\n", server))
	b.WriteString(fmt.Sprintf("🔗 %s\n", formatGlobalProxyLabel(settings.HttpProxyUrl)))
	b.WriteString("\n---\n\n")

	if st.Failed > 0 && len(st.Failures) > 0 {
		failures := append([]BatchFailureItem(nil), st.Failures...)
		sort.Slice(failures, func(i, j int) bool { return failures[i].Domain < failures[j].Domain })
		totalFailures := len(failures)
		if totalFailures > maxReportFailureItems {
			failures = failures[:maxReportFailureItems]
		}
		b.WriteString(fmt.Sprintf("⚠️ 异常域名（%d个）\n\n", totalFailures))
		for _, it := range failures {
			b.WriteString(fmt.Sprintf("• %s\n", truncateReportText(it.Domain, 120)))
			if path := strings.TrimSpace(it.CheckPath); path != "" {
				b.WriteString(fmt.Sprintf("  检测方式：%s\n", truncateReportText(path, maxReportFieldRunes)))
			}
			b.WriteString(fmt.Sprintf("  ❌ %s\n\n", truncateReportText(it.Reason, maxReportFieldRunes)))
		}
		if totalFailures > len(failures) {
			b.WriteString(fmt.Sprintf("… 还有 %d 个异常域名未列出，请登录控制台查看详情\n\n", totalFailures-len(failures)))
		}
		b.WriteString("---\n\n")
	}

	if normal > 0 {
		b.WriteString(fmt.Sprintf("✅ 其余 %d 个域名全部正常\n\n", normal))
	}
	b.WriteString(fmt.Sprintf("📊 总结： 总计 %d 个域名 | ✅ %d 正常 | ⚠️ %d 异常\n", st.Total, normal, st.Failed))
	b.WriteString(fmt.Sprintf("正常率 %.2f%% 🐈✨", avail))
	return b.String()
}

func truncateReportText(s string, maxRunes int) string {
	s = strings.TrimSpace(s)
	if maxRunes <= 0 || s == "" {
		return s
	}
	if len([]rune(s)) <= maxRunes {
		return s
	}
	runes := []rune(s)
	return string(runes[:maxRunes-1]) + "…"
}

func groupFailuresByReason(items []BatchFailureItem) map[string][]BatchFailureItem {
	out := make(map[string][]BatchFailureItem)
	for _, it := range items {
		key := primaryReasonKey(it.Reason)
		out[key] = append(out[key], it)
	}
	for k := range out {
		sort.Slice(out[k], func(i, j int) bool { return out[k][i].Domain < out[k][j].Domain })
	}
	return out
}

func primaryReasonKey(reason string) string {
	if idx := strings.Index(reason, "；"); idx > 0 {
		return reason[:idx]
	}
	return reason
}

func failureGroupHint(items []BatchFailureItem) string {
	if len(items) < 2 {
		return ""
	}
	prefix := commonDomainPrefix(items)
	if prefix != "" && len(prefix) >= 3 {
		return fmt.Sprintf("这 %d 个域名均属于 %s 系列，建议检查 DNS/Cloudflare 配置。", len(items), prefix)
	}
	return fmt.Sprintf("这 %d 个域名存在相同类型异常，建议批量排查。", len(items))
}

func commonDomainPrefix(items []BatchFailureItem) string {
	if len(items) == 0 {
		return ""
	}
	parts := strings.Split(items[0].Domain, ".")
	if len(parts) == 0 {
		return ""
	}
	host := parts[0]
	max := len(host)
	for _, it := range items[1:] {
		p := strings.Split(it.Domain, ".")
		if len(p) == 0 {
			return ""
		}
		h := p[0]
		n := 0
		for n < len(host) && n < len(h) && host[n] == h[n] {
			n++
		}
		max = n
		if max == 0 {
			return ""
		}
	}
	if max < 3 {
		return ""
	}
	return host[:max]
}

func parseReportTimezone(tz string) *time.Location {
	tz = strings.TrimSpace(tz)
	if tz == "" || strings.EqualFold(tz, "UTC") {
		return time.UTC
	}
	if l, err := time.LoadLocation(tz); err == nil {
		return l
	}
	upper := strings.ToUpper(tz)
	if strings.HasPrefix(upper, "UTC") {
		offsetStr := strings.TrimPrefix(upper, "UTC")
		if offsetStr == "" {
			return time.UTC
		}
		sign := 1
		if strings.HasPrefix(offsetStr, "+") {
			offsetStr = offsetStr[1:]
		} else if strings.HasPrefix(offsetStr, "-") {
			sign = -1
			offsetStr = offsetStr[1:]
		}
		if h, err := strconv.Atoi(offsetStr); err == nil {
			return time.FixedZone(tz, sign*h*3600)
		}
	}
	return time.UTC
}

func isCheckBad(st string) bool {
	return st == statusError || st == statusCritical
}

func dnsIssueText(res *DmCheckResult) string {
	var rec map[string]interface{}
	_ = json.Unmarshal([]byte(res.DNSRecords), &rec)
	if errMsg, ok := rec["lookupError"].(string); ok && errMsg != "" {
		if strings.Contains(strings.ToLower(errMsg), "no such host") ||
			strings.Contains(strings.ToLower(errMsg), "nxdomain") {
			return "DNS 解析失败"
		}
		return "DNS 异常"
	}
	return "DNS 检测异常"
}

func httpIssueText(res *DmCheckResult, st string) string {
	if res.HTTPStatus >= 400 {
		return fmt.Sprintf("HTTP %d 异常", res.HTTPStatus)
	}
	if st == statusCritical {
		return "HTTP 不可达"
	}
	return "HTTP 检测异常"
}

func sslIssueText(res *DmCheckResult) string {
	var info map[string]interface{}
	_ = json.Unmarshal([]byte(res.SSLInfo), &info)
	if days, ok := info["daysLeft"].(float64); ok {
		if days < 0 {
			return "SSL 证书已过期"
		}
		if days <= 30 {
			return fmt.Sprintf("SSL 剩余 %d 天", int(days))
		}
	}
	if match, ok := info["hostnameMatch"].(bool); ok && !match {
		return "SSL 证书域名不匹配"
	}
	if errMsg, ok := info["error"].(string); ok && errMsg != "" {
		return "SSL 证书异常"
	}
	return "SSL 检测异常"
}

func whoisIssueText(res *DmCheckResult) string {
	var info map[string]interface{}
	_ = json.Unmarshal([]byte(res.RawDetail), &info)
	if days, ok := info["daysLeft"].(float64); ok {
		if days < 0 {
			return "WHOIS 域名已过期"
		}
		return fmt.Sprintf("WHOIS 剩余 %d 天", int(days))
	}
	return "WHOIS 检测异常"
}

func contentIssueText(res *DmCheckResult) string {
	var info struct {
		MissingKeywords []string `json:"missingKeywords"`
		Changed         bool     `json:"changed"`
	}
	_ = json.Unmarshal([]byte(res.RawDetail), &info)
	if len(info.MissingKeywords) > 0 {
		return "页面缺少关键词"
	}
	if info.Changed {
		return "页面内容变更"
	}
	return "内容检测异常"
}

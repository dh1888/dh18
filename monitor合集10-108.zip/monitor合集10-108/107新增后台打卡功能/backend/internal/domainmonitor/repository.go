package domainmonitor

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"strconv"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository struct {
	db *gorm.DB
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

func (r *Repository) DB() *gorm.DB { return r.db }

// ---------- Groups ----------

func (r *Repository) ListGroups(ctx context.Context) ([]DmGroup, error) {
	var items []DmGroup
	err := r.db.WithContext(ctx).Order("sort_order asc, name asc").Find(&items).Error
	return items, err
}

func (r *Repository) CreateGroup(ctx context.Context, g *DmGroup) error {
	return r.db.WithContext(ctx).Create(g).Error
}

func (r *Repository) UpdateGroup(ctx context.Context, g *DmGroup) error {
	return r.db.WithContext(ctx).Save(g).Error
}

func (r *Repository) DeleteGroup(ctx context.Context, id uuid.UUID) error {
	return r.db.WithContext(ctx).Delete(&DmGroup{}, "id = ?", id).Error
}

func (r *Repository) GetGroupByName(ctx context.Context, name string) (*DmGroup, error) {
	var g DmGroup
	err := r.db.WithContext(ctx).Where("name = ?", name).First(&g).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &g, err
}

// ---------- Domains ----------

type DomainListFilter struct {
	GroupID   string
	Keyword   string
	Enabled   *bool
	Page      int
	PageSize  int
}

func (r *Repository) ListDomains(ctx context.Context, f DomainListFilter) ([]DmDomain, int64, error) {
	q := r.db.WithContext(ctx).Model(&DmDomain{}).Preload("Group")
	if f.GroupID != "" {
		q = q.Where("group_id = ?", f.GroupID)
	}
	if f.Keyword != "" {
		k := "%" + strings.TrimSpace(f.Keyword) + "%"
		q = q.Where("domain ILIKE ?", k)
	}
	if f.Enabled != nil {
		q = q.Where("enabled = ?", *f.Enabled)
	}
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	if f.Page < 1 {
		f.Page = 1
	}
	if f.PageSize < 1 || f.PageSize > 200 {
		f.PageSize = 20
	}
	offset := (f.Page - 1) * f.PageSize
	var items []DmDomain
	err := q.Order("domain asc").Offset(offset).Limit(f.PageSize).Find(&items).Error
	return items, total, err
}

func (r *Repository) GetDomain(ctx context.Context, id uuid.UUID) (*DmDomain, error) {
	var d DmDomain
	err := r.db.WithContext(ctx).Preload("Group").First(&d, "id = ?", id).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &d, err
}

func (r *Repository) GetDomainByName(ctx context.Context, domain string) (*DmDomain, error) {
	var d DmDomain
	err := r.db.WithContext(ctx).Where("domain = ?", strings.ToLower(strings.TrimSpace(domain))).First(&d).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &d, err
}

func (r *Repository) CreateDomain(ctx context.Context, d *DmDomain) error {
	d.Domain = normalizeDomain(d.Domain)
	if err := validateDomainName(d.Domain); err != nil {
		return err
	}
	return r.db.WithContext(ctx).Create(d).Error
}

func (r *Repository) UpdateDomain(ctx context.Context, d *DmDomain) error {
	d.Domain = normalizeDomain(d.Domain)
	if err := validateDomainName(d.Domain); err != nil {
		return err
	}
	return r.db.WithContext(ctx).Save(d).Error
}

func (r *Repository) DeleteDomain(ctx context.Context, id uuid.UUID) error {
	return r.db.WithContext(ctx).Delete(&DmDomain{}, "id = ?", id).Error
}

func (r *Repository) DomainsDueForCheck(ctx context.Context, limit int) ([]DmDomain, error) {
	if limit <= 0 {
		limit = 200
	}
	var items []DmDomain
	err := r.db.WithContext(ctx).
		Where("enabled = ?", true).
		Where("last_check_at IS NULL OR last_check_at + (check_interval * interval '1 second') <= NOW()").
		Order("last_check_at NULLS FIRST").
		Limit(limit).
		Find(&items).Error
	return items, err
}

func (r *Repository) UpdateDomainStatus(ctx context.Context, id uuid.UUID, dns, http, ssl, whois, content, screenshot string, httpDurationMs int, at time.Time) error {
	updates := map[string]interface{}{
		"last_dns_status":        dns,
		"last_http_status":       http,
		"last_ssl_status":        ssl,
		"last_whois_status":      whois,
		"last_content_status":    content,
		"last_screenshot_status": screenshot,
		"last_check_at":          at,
		"updated_at":             at,
	}
	if httpDurationMs > 0 {
		updates["last_http_duration_ms"] = httpDurationMs
	}
	return r.db.WithContext(ctx).Model(&DmDomain{}).Where("id = ?", id).Updates(updates).Error
}

func (r *Repository) UpdateContentBaseline(ctx context.Context, id uuid.UUID, hash string) error {
	return r.db.WithContext(ctx).Model(&DmDomain{}).Where("id = ?", id).Update("content_hash_baseline", hash).Error
}

func (r *Repository) UpdateWhoisExpireAt(ctx context.Context, id uuid.UUID, expireAt *time.Time) error {
	return r.db.WithContext(ctx).Model(&DmDomain{}).Where("id = ?", id).Update("whois_expire_at", expireAt).Error
}

func (r *Repository) ListAllDomains(ctx context.Context) ([]DmDomain, error) {
	var items []DmDomain
	err := r.db.WithContext(ctx).Preload("Group").Order("domain asc").Find(&items).Error
	return items, err
}

// ---------- Check results ----------

func (r *Repository) SaveCheckResult(ctx context.Context, res *DmCheckResult) error {
	res.RedirectChain = jsonbStringOrDefault(res.RedirectChain, "[]")
	res.DNSRecords = jsonbStringOrDefault(res.DNSRecords, "{}")
	res.SSLInfo = jsonbStringOrDefault(res.SSLInfo, "{}")
	res.RawDetail = jsonbStringOrDefault(res.RawDetail, "{}")
	return r.db.WithContext(ctx).Create(res).Error
}

func (r *Repository) ListCheckResults(ctx context.Context, domainID uuid.UUID, checkType, nodeID string, limit int) ([]DmCheckResult, error) {
	if limit <= 0 || limit > 500 {
		limit = 50
	}
	q := r.db.WithContext(ctx).Where("domain_id = ?", domainID).Order("checked_at desc").Limit(limit)
	if checkType != "" {
		q = q.Where("check_type = ?", checkType)
	}
	if nodeID != "" {
		if nodeID == "local" {
			q = q.Where("node_id = ?", nodeID)
		} else {
			q = q.Where("node_id = ?", nodeID)
		}
	}
	var items []DmCheckResult
	return items, q.Find(&items).Error
}

func (r *Repository) GetLastCheckResult(ctx context.Context, domainID uuid.UUID, checkType string) (*DmCheckResult, error) {
	var res DmCheckResult
	err := r.db.WithContext(ctx).
		Where("domain_id = ? AND check_type = ?", domainID, checkType).
		Order("checked_at desc").
		Limit(1).
		Find(&res).Error
	if err != nil {
		return nil, err
	}
	if res.ID == uuid.Nil {
		return nil, nil
	}
	return &res, nil
}

func (r *Repository) ListLatestProbeResultsByNode(ctx context.Context, domainID uuid.UUID, checkType string, since time.Time) ([]DmCheckResult, error) {
	var items []DmCheckResult
	err := r.db.WithContext(ctx).
		Where("domain_id = ? AND check_type = ? AND node_id <> ? AND checked_at >= ?", domainID, checkType, nodeID, since).
		Order("checked_at desc").
		Limit(200).
		Find(&items).Error
	if err != nil {
		return nil, err
	}
	seen := map[string]struct{}{}
	out := make([]DmCheckResult, 0)
	for _, it := range items {
		if _, ok := seen[it.NodeID]; ok {
			continue
		}
		seen[it.NodeID] = struct{}{}
		out = append(out, it)
	}
	return out, nil
}

func (r *Repository) UpdateDomainAggregation(ctx context.Context, id uuid.UUID, healthLevel string, reachability float64, summaryJSON string) error {
	if strings.TrimSpace(summaryJSON) == "" {
		summaryJSON = "{}"
	}
	now := time.Now().UTC()
	return r.db.WithContext(ctx).Model(&DmDomain{}).Where("id = ?", id).Updates(map[string]interface{}{
		"health_level":        healthLevel,
		"reachability_pct":    reachability,
		"probe_node_summary":  summaryJSON,
		"updated_at":          now,
	}).Error
}

func (r *Repository) UpdateDomainCDNProvider(ctx context.Context, id uuid.UUID, provider string) error {
	return r.db.WithContext(ctx).Model(&DmDomain{}).Where("id = ?", id).Update("last_cdn_provider", provider).Error
}

func (r *Repository) SaveCDNHistory(ctx context.Context, h *DmCDNHistory) error {
	if h.ID == uuid.Nil {
		h.ID = uuid.New()
	}
	return r.db.WithContext(ctx).Create(h).Error
}

func (r *Repository) ListCDNHistory(ctx context.Context, domainID uuid.UUID, limit int) ([]DmCDNHistory, error) {
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	var items []DmCDNHistory
	err := r.db.WithContext(ctx).Where("domain_id = ?", domainID).Order("detected_at desc").Limit(limit).Find(&items).Error
	return items, err
}

func (r *Repository) PurgeOldCheckResults(ctx context.Context, before time.Time) (int64, error) {
	tx := r.db.WithContext(ctx).Where("checked_at < ?", before).Delete(&DmCheckResult{})
	return tx.RowsAffected, tx.Error
}

// ---------- Alerts ----------

func (r *Repository) CreateAlert(ctx context.Context, a *DmAlert) error {
	now := time.Now().UTC()
	if a.FirstAt.IsZero() {
		a.FirstAt = now
	}
	a.LastAt = now
	return r.db.WithContext(ctx).Create(a).Error
}

func (r *Repository) UpsertOpenAlert(ctx context.Context, domainID uuid.UUID, alertType, severity, title, message string) (*DmAlert, error) {
	if domainID == uuid.Nil {
		return nil, fmtErr("invalid domain id")
	}
	var existing DmAlert
	tx := r.db.WithContext(ctx).
		Where("domain_id = ? AND alert_type = ? AND status = ?", domainID, alertType, "open").
		Limit(1).
		Find(&existing)
	if tx.Error != nil {
		return nil, tx.Error
	}
	now := time.Now().UTC()
	if existing.ID != uuid.Nil {
		existing.LastAt = now
		existing.Message = message
		existing.Severity = severity
		existing.Title = title
		if err := r.db.WithContext(ctx).Save(&existing).Error; err != nil {
			return nil, err
		}
		return &existing, nil
	}
	a := &DmAlert{
		DomainID:  &domainID,
		AlertType: alertType,
		Severity:  severity,
		Title:     title,
		Message:   message,
		Status:    "open",
		NodeID:    "local",
		FirstAt:   now,
		LastAt:    now,
	}
	if err := r.CreateAlert(ctx, a); err != nil {
		return nil, err
	}
	return a, nil
}

func (r *Repository) ResolveAlertsByType(ctx context.Context, domainID uuid.UUID, alertType string) error {
	now := time.Now().UTC()
	return r.db.WithContext(ctx).Model(&DmAlert{}).
		Where("domain_id = ? AND alert_type = ? AND status = ?", domainID, alertType, "open").
		Updates(map[string]interface{}{"status": "resolved", "resolved_at": now}).Error
}

type AlertListFilter struct {
	Status   string
	Severity string
	Page     int
	PageSize int
}

func (r *Repository) ListAlerts(ctx context.Context, f AlertListFilter) ([]DmAlert, int64, error) {
	q := r.db.WithContext(ctx).Model(&DmAlert{})
	if f.Status != "" {
		q = q.Where("status = ?", f.Status)
	}
	if f.Severity != "" {
		q = q.Where("severity = ?", f.Severity)
	}
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	if f.Page < 1 {
		f.Page = 1
	}
	if f.PageSize < 1 || f.PageSize > 200 {
		f.PageSize = 20
	}
	var items []DmAlert
	err := q.Order("last_at desc").Offset((f.Page - 1) * f.PageSize).Limit(f.PageSize).Find(&items).Error
	return items, total, err
}

func (r *Repository) UpdateAlertStatus(ctx context.Context, id uuid.UUID, status string) error {
	updates := map[string]interface{}{"status": status}
	if status == "resolved" {
		now := time.Now().UTC()
		updates["resolved_at"] = now
	}
	return r.db.WithContext(ctx).Model(&DmAlert{}).Where("id = ?", id).Updates(updates).Error
}

func (r *Repository) CountAlertsToday(ctx context.Context) (int64, error) {
	start := time.Now().UTC().Truncate(24 * time.Hour)
	var n int64
	err := r.db.WithContext(ctx).Model(&DmAlert{}).Where("first_at >= ?", start).Count(&n).Error
	return n, err
}

// ---------- Telegram ----------

func (r *Repository) ListBots(ctx context.Context) ([]DmTelegramBot, error) {
	var items []DmTelegramBot
	return items, r.db.WithContext(ctx).Order("created_at desc").Find(&items).Error
}

func (r *Repository) GetBot(ctx context.Context, id uuid.UUID) (*DmTelegramBot, error) {
	var b DmTelegramBot
	err := r.db.WithContext(ctx).First(&b, "id = ?", id).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &b, err
}

func (r *Repository) SaveBot(ctx context.Context, b *DmTelegramBot) error {
	if b.ID == uuid.Nil {
		return r.db.WithContext(ctx).Create(b).Error
	}
	return r.db.WithContext(ctx).Save(b).Error
}

func (r *Repository) DeleteBot(ctx context.Context, id uuid.UUID) error {
	return r.db.WithContext(ctx).Delete(&DmTelegramBot{}, "id = ?", id).Error
}

func (r *Repository) ListGroupsByBot(ctx context.Context, botID uuid.UUID) ([]DmTelegramGroup, error) {
	var items []DmTelegramGroup
	return items, r.db.WithContext(ctx).Where("bot_id = ?", botID).Order("created_at desc").Find(&items).Error
}

func (r *Repository) ListTelegramGroups(ctx context.Context, botID *uuid.UUID) ([]DmTelegramGroup, error) {
	var items []DmTelegramGroup
	q := r.db.WithContext(ctx).Order("created_at desc")
	if botID != nil {
		q = q.Where("bot_id = ?", *botID)
	}
	return items, q.Find(&items).Error
}

func (r *Repository) SaveTelegramGroup(ctx context.Context, g *DmTelegramGroup) error {
	return r.db.WithContext(ctx).Save(g).Error
}

func (r *Repository) UpsertTelegramGroup(ctx context.Context, g *DmTelegramGroup) error {
	var existing DmTelegramGroup
	err := r.db.WithContext(ctx).Where("bot_id = ? AND chat_id = ?", g.BotID, g.ChatID).First(&existing).Error
	if err == nil {
		existing.GroupName = g.GroupName
		existing.ChatType = g.ChatType
		existing.Enabled = g.Enabled
		return r.db.WithContext(ctx).Save(&existing).Error
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}
	return r.db.WithContext(ctx).Create(g).Error
}

func (r *Repository) DeleteTelegramGroup(ctx context.Context, id uuid.UUID) error {
	var routeCount int64
	if err := r.db.WithContext(ctx).Model(&DmAlertRoute{}).Where("group_id = ?", id).Count(&routeCount).Error; err != nil {
		return err
	}
	if routeCount > 0 {
		return fmt.Errorf("该群组仍被 %d 条告警路由引用，请先删除相关路由", routeCount)
	}
	return r.db.WithContext(ctx).Delete(&DmTelegramGroup{}, "id = ?", id).Error
}

func (r *Repository) ListRoutes(ctx context.Context) ([]DmAlertRoute, error) {
	var items []DmAlertRoute
	return items, r.db.WithContext(ctx).Order("created_at desc").Find(&items).Error
}

func (r *Repository) SaveRoute(ctx context.Context, route *DmAlertRoute) error {
	if route.ID == uuid.Nil {
		return r.db.WithContext(ctx).Create(route).Error
	}
	return r.db.WithContext(ctx).Save(route).Error
}

func (r *Repository) DeleteRoute(ctx context.Context, id uuid.UUID) error {
	return r.db.WithContext(ctx).Delete(&DmAlertRoute{}, "id = ?", id).Error
}

func (r *Repository) MatchRoutes(ctx context.Context, alertType, severity string) ([]DmAlertRoute, error) {
	routes, err := r.ListRoutes(ctx)
	if err != nil {
		return nil, err
	}
	var matched []DmAlertRoute
	for _, rt := range routes {
		if !rt.Enabled {
			continue
		}
		if routeMatches(rt.AlertTypes, alertType) && routeMatches(rt.Severities, severity) {
			matched = append(matched, rt)
		}
	}
	return matched, nil
}

func routeMatches(rawJSON, value string) bool {
	if rawJSON == "" || rawJSON == "[]" || rawJSON == "null" {
		return true
	}
	var arr []string
	if err := json.Unmarshal([]byte(rawJSON), &arr); err != nil {
		return false
	}
	if len(arr) == 0 {
		return true
	}
	for _, v := range arr {
		if strings.EqualFold(v, value) {
			return true
		}
	}
	return false
}

// ---------- Dashboard ----------

type DashboardStats struct {
	TotalDomains         int64   `json:"totalDomains"`
	NormalCount          int64   `json:"normalCount"`
	PartialCount         int64   `json:"partialCount"`
	AbnormalCount        int64   `json:"abnormalCount"`
	CriticalHealthCount  int64   `json:"criticalHealthCount"`
	CriticalCount        int64   `json:"criticalCount"`
	WhoisExpiring        int64   `json:"whoisExpiring"`
	ContentAbnormal      int64   `json:"contentAbnormal"`
	OnlineNodes          int64   `json:"onlineNodes"`
	Availability         float64 `json:"availability"`
	GlobalReachability   float64 `json:"globalReachability"`
	AlertsToday          int64   `json:"alertsToday"`
	OpenAlerts           int64   `json:"openAlerts"`
	DroppedCheckJobs     uint64  `json:"droppedCheckJobs"`
	DroppedPriorityJobs  uint64  `json:"droppedPriorityJobs"`
}

type TrendPoint struct {
	Date         string  `json:"date"`
	OkCount      int64   `json:"okCount"`
	FailCount    int64   `json:"failCount"`
	Availability float64 `json:"availability"`
}

type HttpCheckPoint struct {
	ID         uuid.UUID `json:"id"`
	DomainID   uuid.UUID `json:"domainId"`
	Domain     string    `json:"domain"`
	CheckedAt  time.Time `json:"checkedAt"`
	Status     string    `json:"status"`
	DurationMs int       `json:"durationMs"`
	HTTPStatus int       `json:"httpStatus"`
	NodeName   string    `json:"nodeName"`
}

func (r *Repository) ListRecentHttpChecks(ctx context.Context, days, limit int, domainID *uuid.UUID) ([]HttpCheckPoint, error) {
	if days < 1 || days > 90 {
		days = 7
	}
	if limit < 1 || limit > 2000 {
		limit = 500
	}
	since := time.Now().UTC().AddDate(0, 0, -days)
	q := r.db.WithContext(ctx).Table("dm_check_results cr").
		Select("cr.id, cr.domain_id, d.domain, cr.checked_at, cr.status, cr.duration_ms, cr.http_status, cr.node_name").
		Joins("JOIN dm_domains d ON d.id = cr.domain_id").
		Where("cr.check_type = ? AND cr.checked_at >= ?", "http", since).
		Order("cr.checked_at asc").
		Limit(limit)
	if domainID != nil && *domainID != uuid.Nil {
		q = q.Where("cr.domain_id = ?", *domainID)
	}
	var items []HttpCheckPoint
	return items, q.Scan(&items).Error
}

func (r *Repository) GetSetting(ctx context.Context, key, fallback string) string {
	var s DmSetting
	err := r.db.WithContext(ctx).First(&s, "key = ?", key).Error
	if err != nil || strings.TrimSpace(s.Value) == "" {
		return fallback
	}
	return strings.TrimSpace(s.Value)
}

func (r *Repository) SetSetting(ctx context.Context, key, value string) error {
	now := time.Now().UTC()
	var existing DmSetting
	err := r.db.WithContext(ctx).First(&existing, "key = ?", key).Error
	if err == nil {
		existing.Value = value
		existing.UpdatedAt = now
		return r.db.WithContext(ctx).Save(&existing).Error
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}
	return r.db.WithContext(ctx).Create(&DmSetting{Key: key, Value: value, UpdatedAt: now}).Error
}

func (r *Repository) GetCheckSettings(ctx context.Context) (*CheckSettings, error) {
	def, _ := strconv.Atoi(r.GetSetting(ctx, settingDefaultCheckInterval, "300"))
	tick, _ := strconv.Atoi(r.GetSetting(ctx, settingSchedulerTickSeconds, "60"))
	pool, _ := strconv.Atoi(r.GetSetting(ctx, settingWorkerPoolSize, "100"))
	httpTO, _ := strconv.Atoi(r.GetSetting(ctx, settingHttpTimeoutSeconds, "8"))
	domainTO, _ := strconv.Atoi(r.GetSetting(ctx, settingDomainCheckTimeoutSec, "25"))
	batchLimit, _ := strconv.Atoi(r.GetSetting(ctx, settingScheduleBatchLimit, "1000"))
	if def < 60 {
		def = 300
	}
	if tick < 10 {
		tick = 60
	}
	if pool < 10 {
		pool = 100
	}
	if httpTO < 3 {
		httpTO = 8
	}
	if domainTO < 5 {
		domainTO = 25
	}
	if batchLimit < 100 {
		batchLimit = 1000
	}
	return &CheckSettings{
		DefaultCheckInterval:      def,
		SchedulerTickSeconds:      tick,
		AutoCheckPriority:         parseBoolSetting(r.GetSetting(ctx, settingAutoCheckPriority, "true")),
		TelegramReportEnabled:     parseBoolSetting(r.GetSetting(ctx, settingTelegramReportEnabled, "false")),
		TelegramRealtimeEnabled:   parseBoolSetting(r.GetSetting(ctx, settingTelegramRealtimeEnabled, "false")),
		ReportServerLabel:         r.GetSetting(ctx, settingReportServerLabel, "Local Center"),
		ReportTimezone:            r.GetSetting(ctx, settingReportTimezone, "UTC"),
		ReportTitle:               r.GetSetting(ctx, settingReportTitle, "域名监控报告"),
		WorkerPoolSize:            pool,
		HttpTimeoutSeconds:        httpTO,
		DomainCheckTimeoutSeconds: domainTO,
		FastDnsCheck:              parseBoolSetting(r.GetSetting(ctx, settingFastDnsCheck, "true")),
		ScheduleBatchLimit:        batchLimit,
		ProbeOnBatchCheck:         parseBoolSetting(r.GetSetting(ctx, settingProbeOnBatchCheck, "false")),
		HttpProxyUrl:              r.GetSetting(ctx, settingHttpProxyUrl, ""),
		ProbeRegistrationToken:  r.GetSetting(ctx, settingProbeRegistrationToken, ""),
	}, nil
}

func parseBoolSetting(v string) bool {
	v = strings.TrimSpace(strings.ToLower(v))
	return v == "true" || v == "1" || v == "yes"
}

func (r *Repository) SaveCheckSettings(ctx context.Context, cfg *CheckSettings, applyToAll bool) error {
	oldCfg, _ := r.GetCheckSettings(ctx)
	oldInterval := 0
	if oldCfg != nil {
		oldInterval = oldCfg.DefaultCheckInterval
	}
	if cfg.DefaultCheckInterval < 60 {
		return fmtErr("defaultCheckInterval must be >= 60")
	}
	if cfg.SchedulerTickSeconds < 10 {
		return fmtErr("schedulerTickSeconds must be >= 10")
	}
	if cfg.WorkerPoolSize < 10 || cfg.WorkerPoolSize > 500 {
		return fmtErr("workerPoolSize must be between 10 and 500")
	}
	if cfg.HttpTimeoutSeconds < 3 || cfg.HttpTimeoutSeconds > 30 {
		return fmtErr("httpTimeoutSeconds must be between 3 and 30")
	}
	if cfg.DomainCheckTimeoutSeconds < 5 || cfg.DomainCheckTimeoutSeconds > 120 {
		return fmtErr("domainCheckTimeoutSeconds must be between 5 and 120")
	}
	if cfg.ScheduleBatchLimit < 100 || cfg.ScheduleBatchLimit > 5000 {
		return fmtErr("scheduleBatchLimit must be between 100 and 5000")
	}
	if strings.TrimSpace(cfg.HttpProxyUrl) != "" {
		normalized, err := normalizeSavedProxyURL(cfg.HttpProxyUrl)
		if err != nil {
			return err
		}
		cfg.HttpProxyUrl = normalized
	}
	pairs := map[string]string{
		settingDefaultCheckInterval:  strconv.Itoa(cfg.DefaultCheckInterval),
		settingSchedulerTickSeconds:  strconv.Itoa(cfg.SchedulerTickSeconds),
		settingAutoCheckPriority:     boolSetting(cfg.AutoCheckPriority),
		settingTelegramReportEnabled:   boolSetting(cfg.TelegramReportEnabled),
		settingTelegramRealtimeEnabled: boolSetting(cfg.TelegramRealtimeEnabled),
		settingReportServerLabel:     strings.TrimSpace(cfg.ReportServerLabel),
		settingReportTimezone:        strings.TrimSpace(cfg.ReportTimezone),
		settingReportTitle:           strings.TrimSpace(cfg.ReportTitle),
		settingWorkerPoolSize:        strconv.Itoa(cfg.WorkerPoolSize),
		settingHttpTimeoutSeconds:    strconv.Itoa(cfg.HttpTimeoutSeconds),
		settingDomainCheckTimeoutSec: strconv.Itoa(cfg.DomainCheckTimeoutSeconds),
		settingFastDnsCheck:          boolSetting(cfg.FastDnsCheck),
		settingScheduleBatchLimit:    strconv.Itoa(cfg.ScheduleBatchLimit),
		settingProbeOnBatchCheck:     boolSetting(cfg.ProbeOnBatchCheck),
		settingHttpProxyUrl:          cfg.HttpProxyUrl,
	}
	token := strings.TrimSpace(cfg.ProbeRegistrationToken)
	if token != "" {
		pairs[settingProbeRegistrationToken] = token
	}
	for k, v := range pairs {
		if err := r.SetSetting(ctx, k, v); err != nil {
			return err
		}
	}
	if applyToAll {
		_, err := r.SyncAllDomainCheckIntervals(ctx, cfg.DefaultCheckInterval)
		return err
	}
	if oldInterval > 0 && oldInterval != cfg.DefaultCheckInterval {
		_, err := r.SyncAllDomainCheckIntervals(ctx, cfg.DefaultCheckInterval)
		return err
	}
	return nil
}

func (r *Repository) SyncAllDomainCheckIntervals(ctx context.Context, interval int) (int64, error) {
	if interval < 60 {
		interval = 300
	}
	now := time.Now().UTC()
	res := r.db.WithContext(ctx).Model(&DmDomain{}).
		Where("check_interval <> ?", interval).
		Updates(map[string]interface{}{
			"check_interval": interval,
			"updated_at":     now,
		})
	return res.RowsAffected, res.Error
}

type DomainBatchPatch struct {
	UpdateGroup       bool
	GroupID           *uuid.UUID
	ClearGroup        bool
	Enabled           *bool
	CheckInterval     *int
	SyncCheckInterval bool
	EnableDNS         *bool
	EnableHTTP        *bool
	EnableSSL         *bool
	EnableWhois       *bool
	EnableContent     *bool
}

func (r *Repository) BatchUpdateDomains(ctx context.Context, ids []uuid.UUID, patch DomainBatchPatch) (int64, error) {
	if len(ids) == 0 {
		return 0, fmtErr("no domain ids")
	}
	updates := map[string]interface{}{
		"updated_at": time.Now().UTC(),
	}
	hasUpdate := false
	if patch.UpdateGroup {
		hasUpdate = true
		if patch.ClearGroup {
			updates["group_id"] = nil
		} else if patch.GroupID != nil {
			updates["group_id"] = *patch.GroupID
		}
	}
	if patch.Enabled != nil {
		hasUpdate = true
		updates["enabled"] = *patch.Enabled
	}
	if patch.SyncCheckInterval {
		hasUpdate = true
		updates["check_interval"] = r.DefaultCheckInterval(ctx)
	} else if patch.CheckInterval != nil {
		hasUpdate = true
		updates["check_interval"] = *patch.CheckInterval
	}
	if patch.EnableDNS != nil {
		hasUpdate = true
		updates["enable_dns"] = *patch.EnableDNS
	}
	if patch.EnableHTTP != nil {
		hasUpdate = true
		updates["enable_http"] = *patch.EnableHTTP
	}
	if patch.EnableSSL != nil {
		hasUpdate = true
		updates["enable_ssl"] = *patch.EnableSSL
	}
	if patch.EnableWhois != nil {
		hasUpdate = true
		updates["enable_whois"] = *patch.EnableWhois
	}
	if patch.EnableContent != nil {
		hasUpdate = true
		updates["enable_content"] = *patch.EnableContent
	}
	if !hasUpdate {
		return 0, fmtErr("no fields to update")
	}
	res := r.db.WithContext(ctx).Model(&DmDomain{}).Where("id IN ?", ids).Updates(updates)
	return res.RowsAffected, res.Error
}

// BatchUpdateProbeNodes 一次 SQL 仅更新 ProbeNodeScope / ProbeNodeIDs。
func (r *Repository) BatchUpdateProbeNodes(ctx context.Context, ids []uuid.UUID, scope string, nodeIDs []string) (int64, error) {
	if len(ids) == 0 {
		return 0, fmtErr("no domain ids")
	}
	scope = strings.ToLower(strings.TrimSpace(scope))
	if scope == "" {
		scope = "all"
	}
	if scope != "all" && scope != "selected" {
		return 0, fmtErr("invalid probe node scope")
	}
	idsJSON := "[]"
	if scope == "selected" {
		idsJSON = jsonStrings(nodeIDs)
	}
	now := time.Now().UTC()
	res := r.db.WithContext(ctx).Exec(`
		UPDATE dm_domains
		SET probe_node_scope = ?,
		    probe_node_ids = ?::jsonb,
		    updated_at = ?
		WHERE id IN ?`,
		scope, idsJSON, now, ids)
	return res.RowsAffected, res.Error
}

func boolSetting(v bool) string {
	if v {
		return "true"
	}
	return "false"
}

func (r *Repository) DefaultCheckInterval(ctx context.Context) int {
	cfg, err := r.GetCheckSettings(ctx)
	if err != nil || cfg.DefaultCheckInterval < 60 {
		return 300
	}
	return cfg.DefaultCheckInterval
}

func (r *Repository) DashboardStats(ctx context.Context) (*DashboardStats, error) {
	var total int64
	if err := r.db.WithContext(ctx).Model(&DmDomain{}).Where("enabled = ?", true).Count(&total).Error; err != nil {
		return nil, err
	}
	countHealth := func(level string) int64 {
		var n int64
		r.db.WithContext(ctx).Model(&DmDomain{}).Where("enabled = ? AND health_level = ?", true, level).Count(&n)
		return n
	}
	normal := countHealth(healthNormal)
	partial := countHealth(healthPartial)
	abnormal := countHealth(healthAbnormal)
	criticalHealth := countHealth(healthCritical)
	var whoisExpiring int64
	r.db.WithContext(ctx).Model(&DmDomain{}).Where("enabled = ? AND enable_whois = ? AND whois_expire_at IS NOT NULL AND whois_expire_at <= ?", true, true, time.Now().UTC().AddDate(0, 0, 30)).Count(&whoisExpiring)
	var contentAbnormal int64
	r.db.WithContext(ctx).Model(&DmDomain{}).Where("enabled = ? AND enable_content = ? AND last_content_status IN ('error','critical','warning')", true, true).Count(&contentAbnormal)
	var onlineNodes int64
	r.db.WithContext(ctx).Model(&DmNode{}).Where("enabled = ? AND last_seen_at >= ?", true, time.Now().UTC().Add(-5*time.Minute)).Count(&onlineNodes)
	var openCriticalAlerts int64
	r.db.WithContext(ctx).Model(&DmAlert{}).Where("status = ? AND severity = ?", "open", "CRITICAL").Count(&openCriticalAlerts)
	alertsToday, _ := r.CountAlertsToday(ctx)
	var openAlerts int64
	r.db.WithContext(ctx).Model(&DmAlert{}).Where("status = ?", "open").Count(&openAlerts)
	var avgReach struct{ Avg *float64 }
	r.db.WithContext(ctx).Model(&DmDomain{}).Where("enabled = ?", true).Select("AVG(reachability_pct) as avg").Scan(&avgReach)
	globalReach := 100.0
	if avgReach.Avg != nil {
		globalReach = *avgReach.Avg
	}
	avail := 100.0
	if total > 0 {
		avail = float64(normal) / float64(total) * 100
	}
	return &DashboardStats{
		TotalDomains:        total,
		NormalCount:         normal,
		PartialCount:        partial,
		AbnormalCount:       abnormal,
		CriticalHealthCount: criticalHealth,
		CriticalCount:       openCriticalAlerts,
		WhoisExpiring:       whoisExpiring,
		ContentAbnormal:     contentAbnormal,
		OnlineNodes:         onlineNodes,
		Availability:        avail,
		GlobalReachability:  globalReach,
		AlertsToday:         alertsToday,
		OpenAlerts:          openAlerts,
	}, nil
}

func (r *Repository) AvailabilityTrend(ctx context.Context, days int) ([]TrendPoint, error) {
	if days < 1 || days > 90 {
		days = 7
	}
	since := time.Now().UTC().AddDate(0, 0, -days)
	type row struct {
		Day       time.Time
		OkCount   int64
		FailCount int64
	}
	var rows []row
	err := r.db.WithContext(ctx).Raw(`
		SELECT date_trunc('day', checked_at AT TIME ZONE 'UTC') AS day,
			COUNT(*) FILTER (WHERE status = 'ok') AS ok_count,
			COUNT(*) FILTER (WHERE status <> 'ok') AS fail_count
		FROM dm_check_results
		WHERE check_type = 'http' AND checked_at >= ?
		GROUP BY 1
		ORDER BY 1
	`, since).Scan(&rows).Error
	if err != nil {
		return nil, err
	}
	out := make([]TrendPoint, 0, len(rows))
	for _, rw := range rows {
		total := rw.OkCount + rw.FailCount
		avail := 100.0
		if total > 0 {
			avail = float64(rw.OkCount) / float64(total) * 100
		}
		out = append(out, TrendPoint{
			Date:         rw.Day.Format("2006-01-02"),
			OkCount:      rw.OkCount,
			FailCount:    rw.FailCount,
			Availability: avail,
		})
	}
	return out, nil
}

// ---------- P2: Probe nodes ----------

func hashNodeKey(key string) string {
	sum := sha256.Sum256([]byte(strings.TrimSpace(key)))
	return hex.EncodeToString(sum[:])
}

func (r *Repository) ListNodes(ctx context.Context) ([]DmNode, error) {
	var items []DmNode
	return items, r.db.WithContext(ctx).Order("name asc").Find(&items).Error
}

func (r *Repository) GetNode(ctx context.Context, id uuid.UUID) (*DmNode, error) {
	var n DmNode
	err := r.db.WithContext(ctx).First(&n, "id = ?", id).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &n, err
}

func (r *Repository) GetNodeByAPIKey(ctx context.Context, apiKey string) (*DmNode, error) {
	if strings.TrimSpace(apiKey) == "" {
		return nil, nil
	}
	var n DmNode
	err := r.db.WithContext(ctx).Where("api_key_hash = ? AND enabled = ?", hashNodeKey(apiKey), true).First(&n).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &n, err
}

func (r *Repository) SaveNode(ctx context.Context, n *DmNode) error {
	if n.ID == uuid.Nil {
		return r.db.WithContext(ctx).Create(n).Error
	}
	return r.db.WithContext(ctx).Save(n).Error
}

func (r *Repository) DeleteNode(ctx context.Context, id uuid.UUID) error {
	return r.db.WithContext(ctx).Delete(&DmNode{}, "id = ?", id).Error
}

func (r *Repository) UpdateNodeHeartbeat(ctx context.Context, id uuid.UUID, publicIP, version string, cpu, mem float64) error {
	now := time.Now().UTC()
	return r.db.WithContext(ctx).Model(&DmNode{}).Where("id = ?", id).Updates(map[string]interface{}{
		"last_seen_at":    now,
		"public_ip":       strings.TrimSpace(publicIP),
		"version":         strings.TrimSpace(version),
		"cpu_percent":     cpu,
		"memory_percent":  mem,
		"updated_at":      now,
	}).Error
}

func (r *Repository) TouchNode(ctx context.Context, id uuid.UUID) error {
	return r.UpdateNodeHeartbeat(ctx, id, "", "", 0, 0)
}

func (r *Repository) ListOnlineNodes(ctx context.Context, within time.Duration) ([]DmNode, error) {
	since := time.Now().UTC().Add(-within)
	var items []DmNode
	err := r.db.WithContext(ctx).Where("enabled = ? AND last_seen_at >= ?", true, since).Find(&items).Error
	return items, err
}

func (r *Repository) CreateProbeTask(ctx context.Context, domainID, nodeID uuid.UUID, checkSpecs string) error {
	var existing DmProbeTask
	err := r.db.WithContext(ctx).
		Where("domain_id = ? AND node_id = ? AND status = ?", domainID, nodeID, "pending").
		First(&existing).Error
	if err == nil {
		return nil
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}
	if strings.TrimSpace(checkSpecs) == "" {
		checkSpecs = "[]"
	}
	return r.db.WithContext(ctx).Create(&DmProbeTask{
		DomainID:   domainID,
		NodeID:     nodeID,
		Status:     "pending",
		CheckSpecs: checkSpecs,
	}).Error
}

func (r *Repository) ListNodeProbeTasks(ctx context.Context, nodeID uuid.UUID, limit int) ([]DmProbeTask, error) {
	if limit <= 0 || limit > 100 {
		limit = 50
	}
	var items []DmProbeTask
	err := r.db.WithContext(ctx).
		Preload("Domain").
		Where("node_id = ?", nodeID).
		Order("created_at desc").
		Limit(limit).
		Find(&items).Error
	return items, err
}

func (r *Repository) ClaimProbeTasks(ctx context.Context, nodeID uuid.UUID, limit int) ([]DmProbeTask, error) {
	if limit <= 0 || limit > 20 {
		limit = 10
	}
	var items []DmProbeTask
	err := r.db.WithContext(ctx).
		Preload("Domain").
		Where("node_id = ? AND status = ?", nodeID, "pending").
		Order("created_at asc").
		Limit(limit).
		Find(&items).Error
	return items, err
}

func (r *Repository) CompleteProbeTask(ctx context.Context, taskID uuid.UUID) error {
	now := time.Now().UTC()
	return r.db.WithContext(ctx).Model(&DmProbeTask{}).Where("id = ?", taskID).Updates(map[string]interface{}{
		"status":       "done",
		"completed_at": now,
	}).Error
}

func (r *Repository) GetProbeTask(ctx context.Context, taskID, nodeID uuid.UUID) (*DmProbeTask, error) {
	var t DmProbeTask
	err := r.db.WithContext(ctx).Preload("Domain").Where("id = ? AND node_id = ?", taskID, nodeID).First(&t).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &t, err
}

// ---------- P2: Reports ----------

func (r *Repository) ListReports(ctx context.Context, limit int) ([]DmReport, error) {
	if limit <= 0 || limit > 100 {
		limit = 30
	}
	var items []DmReport
	return items, r.db.WithContext(ctx).Order("created_at desc").Limit(limit).Find(&items).Error
}

func (r *Repository) GetReport(ctx context.Context, id uuid.UUID) (*DmReport, error) {
	var rep DmReport
	err := r.db.WithContext(ctx).First(&rep, "id = ?", id).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &rep, err
}

func (r *Repository) SaveReport(ctx context.Context, rep *DmReport) error {
	rep.Summary = jsonbStringOrDefault(rep.Summary, "{}")
	return r.db.WithContext(ctx).Create(rep).Error
}

func (r *Repository) ReportExists(ctx context.Context, reportType string, periodStart time.Time) (bool, error) {
	var n int64
	err := r.db.WithContext(ctx).Model(&DmReport{}).
		Where("report_type = ? AND period_start = ?", reportType, periodStart).
		Count(&n).Error
	return n > 0, err
}

func mustJSON(v interface{}) string {
	b, err := json.Marshal(v)
	if err != nil {
		return "{}"
	}
	return string(b)
}

// jsonbStringOrDefault 避免空字符串写入 PostgreSQL jsonb（22P02）
func jsonbStringOrDefault(s, fallback string) string {
	if strings.TrimSpace(s) == "" {
		return fallback
	}
	return s
}

func jsonStrings(v []string) string {
	if v == nil {
		return "[]"
	}
	return mustJSON(v)
}

func parseUUID(s string) (uuid.UUID, error) {
	return uuid.Parse(strings.TrimSpace(s))
}

func fmtErr(format string, args ...interface{}) error {
	return fmt.Errorf(format, args...)
}

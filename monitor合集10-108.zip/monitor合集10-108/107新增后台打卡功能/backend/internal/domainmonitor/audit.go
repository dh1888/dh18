package domainmonitor

import (
	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/handlers"
)

const operationModuleDomainMonitor = "DOMAIN_MONITOR"

func auditDM(c *gin.Context, opType, desc, targetID, targetName string) {
	handlers.Log(c, opType, operationModuleDomainMonitor, desc, targetID, targetName)
}

package domainmonitor

import (
	"context"
	"database/sql"
	"log"
	"sync"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"enterprise-agent/backend/middleware"
)

var (
	globalEngine *Engine
	globalStop   context.CancelFunc
	stopOnce     sync.Once
)

// Bootstrap 模块唯一入口：注册路由并启动 Worker（需 DOMAIN_MONITOR_ENABLED=true）
func Bootstrap(router *gin.Engine, sqlDB *sql.DB, redisClient *redis.Client) {
	cfg := LoadConfig()
	if !cfg.Enabled {
		log.Println("[DomainMonitor] disabled (set DOMAIN_MONITOR_ENABLED=true to enable)")
		return
	}
	if len(cfg.SecretKey) != 32 {
		log.Println("[DomainMonitor] warning: DM_SECRET_KEY invalid length, module disabled")
		return
	}

	gdb, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Warn),
	})
	if err != nil {
		log.Printf("[DomainMonitor] gorm init failed: %v", err)
		return
	}
	if err := autoMigrate(gdb); err != nil {
		log.Printf("[DomainMonitor] migrate failed: %v", err)
		return
	}

	repo := NewRepository(gdb)
	engine := NewEngine(repo, cfg, redisClient)
	globalEngine = engine

	handler := NewHandler(repo, engine)
	api := router.Group("/api/v1")
	dm := api.Group("/domain-monitor")
	dm.Use(middleware.Auth(redisClient))
	handler.Register(dm)

	probe := api.Group("/domain-monitor/probe")
	handler.RegisterProbe(probe)

	ctx, cancel := context.WithCancel(context.Background())
	globalStop = cancel
	engine.Start(ctx)

	log.Println("[DomainMonitor] P2 module started at /api/v1/domain-monitor (+ /probe)")
}

// Stop 优雅停止 Worker
func Stop() {
	stopOnce.Do(func() {
		if globalStop != nil {
			globalStop()
		}
		if globalEngine != nil {
			globalEngine.Stop()
		}
		log.Println("[DomainMonitor] stopped")
	})
}

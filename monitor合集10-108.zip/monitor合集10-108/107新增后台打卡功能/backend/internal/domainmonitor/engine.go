package domainmonitor

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"unicode"
	"unicode/utf8"

	"github.com/google/uuid"
	"github.com/jung-kurt/gofpdf"
	"github.com/likexian/whois"
	"github.com/redis/go-redis/v9"

	"github.com/chromedp/chromedp"
)

const (
	nodeID   = "local"
	nodeName = "Local Center"
	country  = "CN"
	city     = "Center"

	statusOK       = "ok"
	statusWarning  = "warning"
	statusError    = "error"
	statusCritical = "critical"
)

type Config struct {
	Enabled            bool
	WorkerPool         int
	ScheduleEvery      time.Duration
	SecretKey          []byte
	HTTPTimeout        time.Duration
	UploadsDir         string
	ScreenshotEnabled  bool
	ChromePath         string
	ReportsEnabled     bool
}

func LoadConfig() Config {
	enabled := strings.EqualFold(os.Getenv("DOMAIN_MONITOR_ENABLED"), "true")
	pool := 50
	if v := os.Getenv("DM_WORKER_POOL_SIZE"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			pool = n
		}
	}
	secret := deriveSecretKey(os.Getenv("DM_SECRET_KEY"))
	if len(secret) == 0 {
		secret = deriveSecretKey(os.Getenv("JWT_SECRET"))
	}
	return Config{
		Enabled:           enabled,
		WorkerPool:        pool,
		ScheduleEvery:     time.Minute,
		SecretKey:         secret,
		HTTPTimeout:       8 * time.Second,
		UploadsDir:        uploadsDir(),
		ScreenshotEnabled: strings.EqualFold(os.Getenv("DM_SCREENSHOT_ENABLED"), "true"),
		ChromePath:        strings.TrimSpace(os.Getenv("DM_CHROME_PATH")),
		ReportsEnabled:    !strings.EqualFold(os.Getenv("DM_REPORTS_ENABLED"), "false"),
	}
}

func uploadsDir() string {
	dir := strings.TrimSpace(os.Getenv("UPLOADS_DIR"))
	if dir == "" {
		dir = "./uploads"
	}
	abs, err := filepath.Abs(dir)
	if err != nil {
		return dir
	}
	return abs
}

func deriveSecretKey(raw string) []byte {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	if b, err := base64.StdEncoding.DecodeString(raw); err == nil && len(b) >= 32 {
		return b[:32]
	}
	sum := sha256.Sum256([]byte(raw))
	return sum[:]
}

// ---------- Crypto ----------

func encryptToken(key []byte, plain string) (string, error) {
	if len(key) != 32 {
		return "", fmtErr("DM_SECRET_KEY must be 32 bytes")
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	ciphertext := gcm.Seal(nonce, nonce, []byte(plain), nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func decryptToken(key []byte, enc string) (string, error) {
	if len(key) != 32 {
		return "", fmtErr("DM_SECRET_KEY must be 32 bytes")
	}
	data, err := base64.StdEncoding.DecodeString(enc)
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	if len(data) < gcm.NonceSize() {
		return "", fmtErr("invalid ciphertext")
	}
	nonce, ciphertext := data[:gcm.NonceSize()], data[gcm.NonceSize():]
	plain, err := gcm.Open(nil, nonce, ciphertext, nil)
	return string(plain), err
}

func MaskToken(token string) string {
	token = strings.TrimSpace(token)
	if len(token) <= 10 {
		return "******"
	}
	return token[:6] + "******" + token[len(token)-4:]
}

// ---------- Engine ----------

type Engine struct {
	repo   *Repository
	cfg    Config
	client *http.Client
	redis  *redis.Client

	jobCh         chan uuid.UUID
	priorityJobCh chan uuid.UUID
	stop          chan struct{}
	wg            sync.WaitGroup

	workerMu    sync.Mutex
	workerCount int
	workerCtx   context.Context

	perfMu   sync.RWMutex
	perfSnap perfSnapshot

	notifyMu       sync.Mutex
	lastNotify     map[string]time.Time
	notifyCooldown time.Duration

	batchMu sync.RWMutex
	batches map[uuid.UUID]*checkBatch

	droppedJobs         atomic.Uint64
	droppedPriorityJobs atomic.Uint64
}

type checkBatch struct {
	status     CheckBatchStatus
	pending    map[uuid.UUID]struct{}
	sendReport bool
}

func NewEngine(repo *Repository, cfg Config, redisClient *redis.Client) *Engine {
	if cfg.HTTPTimeout <= 0 {
		cfg.HTTPTimeout = 8 * time.Second
	}
	return &Engine{
		repo: repo,
		cfg:  cfg,
		redis: redisClient,
		client: newMonitorHTTPClient(cfg.HTTPTimeout, ""),
		jobCh:          make(chan uuid.UUID, 8192),
		priorityJobCh:  make(chan uuid.UUID, 8192),
		stop:           make(chan struct{}),
		lastNotify:     make(map[string]time.Time),
		notifyCooldown: 15 * time.Minute,
		batches:        make(map[uuid.UUID]*checkBatch),
		perfSnap: perfSnapshot{
			domainCheckTimeout: 25 * time.Second,
			scheduleBatchLimit: 1000,
			fastDnsCheck:       true,
		},
	}
}

func (e *Engine) Start(ctx context.Context) {
	if !e.cfg.Enabled {
		return
	}
	e.workerCtx = ctx
	if settings, err := e.repo.GetCheckSettings(ctx); err == nil && settings.SchedulerTickSeconds >= 10 {
		e.cfg.ScheduleEvery = time.Duration(settings.SchedulerTickSeconds) * time.Second
	}
	e.applyPerformanceSettings(ctx)
	e.ensureWorkers(e.cfg.WorkerPool)
	e.wg.Add(1)
	go e.schedulerLoop(ctx)
	e.wg.Add(1)
	go e.retentionLoop(ctx)
	if e.cfg.ReportsEnabled {
		e.wg.Add(1)
		go e.reportLoop(ctx)
	}
	log.Printf("[DomainMonitor] worker pool=%d httpTimeout=%s fastDns=%v (screenshot=%v reports=%v)",
		e.cfg.WorkerPool, e.cfg.HTTPTimeout, e.perf().fastDnsCheck, e.cfg.ScreenshotEnabled, e.cfg.ReportsEnabled)
}

func (e *Engine) Stop() {
	close(e.stop)
	e.wg.Wait()
}

// QueueMetrics 返回自进程启动以来因队列满而丢弃的检测任务计数
func (e *Engine) QueueMetrics() (droppedNormal, droppedPriority uint64) {
	if e == nil {
		return 0, 0
	}
	return e.droppedJobs.Load(), e.droppedPriorityJobs.Load()
}

func (e *Engine) EnqueueDomain(id uuid.UUID) {
	select {
	case e.jobCh <- id:
	default:
		e.droppedJobs.Add(1)
		log.Printf("[DomainMonitor] job queue full, drop domain %s (check worker pool / schedule batch limit)", id)
	}
}

func (e *Engine) EnqueueDomainPriority(id uuid.UUID) {
	select {
	case e.priorityJobCh <- id:
	default:
		select {
		case e.jobCh <- id:
		default:
			e.droppedPriorityJobs.Add(1)
			log.Printf("[DomainMonitor] priority queue full, drop domain %s (check worker pool / schedule batch limit)", id)
		}
	}
}

func (e *Engine) EnqueueAllDomains(ctx context.Context) (uuid.UUID, int, error) {
	domains, err := e.repo.ListAllDomains(ctx)
	if err != nil {
		return uuid.Nil, 0, err
	}
	settings, _ := e.repo.GetCheckSettings(ctx)
	now := time.Now().UTC()
	batchID := uuid.New()
	batch := &checkBatch{
		sendReport: settings != nil && settings.TelegramReportEnabled,
		status: CheckBatchStatus{
			BatchID:   batchID,
			Total:     0,
			Completed: 0,
			Failed:    0,
			Normal:    0,
			Running:   false,
			Failures:  []BatchFailureItem{},
			StartedAt: now,
		},
		pending: make(map[uuid.UUID]struct{}),
	}
	for _, d := range domains {
		if !d.Enabled {
			continue
		}
		batch.pending[d.ID] = struct{}{}
		batch.status.Total++
		e.EnqueueDomain(d.ID)
		e.maybeEnqueueProbe(d.ID, true)
	}
	if batch.status.Total == 0 {
		return uuid.Nil, 0, nil
	}
	batch.status.Running = true
	e.batchMu.Lock()
	e.batches[batchID] = batch
	e.batchMu.Unlock()
	return batchID, batch.status.Total, nil
}

func (e *Engine) GetCheckBatchStatus(batchID uuid.UUID) *CheckBatchStatus {
	e.batchMu.RLock()
	defer e.batchMu.RUnlock()
	batch, ok := e.batches[batchID]
	if !ok {
		return nil
	}
	st := batch.status
	st.Running = len(batch.pending) > 0
	st.Failures = append([]BatchFailureItem(nil), batch.status.Failures...)
	return &st
}

func (e *Engine) markBatchProgress(domainID uuid.UUID, summary *DomainCheckSummary) {
	e.batchMu.Lock()
	var reportBatch *checkBatch
	for _, batch := range e.batches {
		if _, ok := batch.pending[domainID]; !ok {
			continue
		}
		delete(batch.pending, domainID)
		batch.status.Completed++
		if summary != nil && !summary.OK {
			batch.status.Failed++
			batch.status.Failures = append(batch.status.Failures, BatchFailureItem{
				Domain:    summary.Domain,
				Reason:    summary.Reason,
				Issues:    append([]string(nil), summary.Issues...),
				CheckPath: summary.CheckPath,
			})
		} else {
			batch.status.Normal++
		}
		if len(batch.pending) == 0 {
			batch.status.Running = false
			now := time.Now().UTC()
			batch.status.FinishedAt = &now
			if batch.sendReport {
				reportBatch = batch
			}
		}
		break
	}
	e.batchMu.Unlock()
	if reportBatch != nil {
		go e.sendBatchMonitorReport(context.Background(), reportBatch)
	}
}

func (e *Engine) startScheduledBatch(ctx context.Context, domains []DmDomain, settings *CheckSettings) {
	if len(domains) == 0 {
		return
	}
	now := time.Now().UTC()
	batchID := uuid.New()
	batch := &checkBatch{
		sendReport: settings.TelegramReportEnabled,
		status: CheckBatchStatus{
			BatchID:   batchID,
			Total:     len(domains),
			Completed: 0,
			Failed:    0,
			Normal:    0,
			Running:   true,
			Failures:  []BatchFailureItem{},
			StartedAt: now,
		},
		pending: make(map[uuid.UUID]struct{}, len(domains)),
	}
	for _, d := range domains {
		batch.pending[d.ID] = struct{}{}
		if settings.AutoCheckPriority {
			e.EnqueueDomainPriority(d.ID)
		} else {
			e.EnqueueDomain(d.ID)
		}
		e.maybeEnqueueProbe(d.ID, false)
	}
	e.batchMu.Lock()
	e.batches[batchID] = batch
	e.batchMu.Unlock()
}

func (e *Engine) schedulerLoop(ctx context.Context) {
	defer e.wg.Done()
	for {
		select {
		case <-e.stop:
			return
		case <-ctx.Done():
			return
		default:
		}
		domains, err := e.repo.DomainsDueForCheck(ctx, e.perf().scheduleBatchLimit)
		if err != nil {
			log.Printf("[DomainMonitor] schedule error: %v", err)
		} else if len(domains) > 0 {
			settings, sErr := e.repo.GetCheckSettings(ctx)
			if sErr != nil {
				settings = &CheckSettings{AutoCheckPriority: true}
			}
			e.startScheduledBatch(ctx, domains, settings)
		}
		interval := e.cfg.ScheduleEvery
		if settings, err := e.repo.GetCheckSettings(ctx); err == nil && settings.SchedulerTickSeconds >= 10 {
			interval = time.Duration(settings.SchedulerTickSeconds) * time.Second
		}
		select {
		case <-e.stop:
			return
		case <-ctx.Done():
			return
		case <-time.After(interval):
		}
	}
}

func (e *Engine) workerLoop(ctx context.Context, _ int) {
	defer e.wg.Done()
	for {
		select {
		case <-e.stop:
			return
		case <-ctx.Done():
			return
		default:
		}
		var id uuid.UUID
		select {
		case <-e.stop:
			return
		case <-ctx.Done():
			return
		case id = <-e.priorityJobCh:
		default:
			select {
			case <-e.stop:
				return
			case <-ctx.Done():
				return
			case id = <-e.priorityJobCh:
			case id = <-e.jobCh:
			}
		}
		if id == uuid.Nil {
			continue
		}
		summary, err := e.RunChecks(ctx, id)
		if err != nil {
			log.Printf("[DomainMonitor] check %s: %v", id, err)
		}
		if summary == nil {
			summary = &DomainCheckSummary{OK: false, Reason: "检测未完成", Issues: []string{"检测未完成"}}
		}
		e.markBatchProgress(id, summary)
	}
}

func (e *Engine) retentionLoop(ctx context.Context) {
	defer e.wg.Done()
	ticker := time.NewTicker(24 * time.Hour)
	defer ticker.Stop()
	for {
		select {
		case <-e.stop:
			return
		case <-ctx.Done():
			return
		case <-ticker.C:
			before := time.Now().UTC().AddDate(0, 0, -90)
			n, err := e.repo.PurgeOldCheckResults(ctx, before)
			if err != nil {
				log.Printf("[DomainMonitor] purge error: %v", err)
			} else if n > 0 {
				log.Printf("[DomainMonitor] purged %d old check results", n)
			}
		}
	}
}

func (e *Engine) RunChecks(ctx context.Context, domainID uuid.UUID) (*DomainCheckSummary, error) {
	if domainID == uuid.Nil {
		return nil, fmtErr("invalid domain id")
	}
	d, err := e.repo.GetDomain(ctx, domainID)
	if err != nil || d == nil || !d.Enabled {
		return nil, err
	}
	if !isValidDomainName(d.Domain) {
		return e.finishInvalidDomainCheck(ctx, d)
	}

	snap := e.perf()
	checkCtx := ctx
	if snap.domainCheckTimeout > 0 {
		var cancel context.CancelFunc
		checkCtx, cancel = context.WithTimeout(ctx, snap.domainCheckTimeout)
		defer cancel()
	}

	summary := &DomainCheckSummary{Domain: d.Domain, OK: true}
	var (
		mu             sync.Mutex
		issues         []string
		dnsSt          = statusOK
		httpSt         = statusOK
		sslSt          = statusOK
		whoisSt        = statusOK
		contentSt      = statusOK
		screenshotSt   = statusOK
		httpDurationMs int
		wg             sync.WaitGroup
	)
	skipHTTPSSL := false

	appendIssue := func(text string) {
		summary.OK = false
		issues = append(issues, text)
	}

	if d.EnableDNS && runOnCenter(d, "dns") {
		res, st := e.checkDNS(checkCtx, d, snap.fastDnsCheck)
		if prev, _ := e.repo.GetLastCheckResult(ctx, d.ID, "dns"); prev != nil {
			changeInfo := annotateDNSChanges(prev, res)
			if changeInfo.IPChanged {
				e.handleChangeAlert(ctx, d, "ip_change", changeInfo.ChangeSummary)
				if st == statusOK {
					st = statusWarning
				}
			} else {
				_ = e.repo.ResolveAlertsByType(ctx, d.ID, "ip_change")
			}
			if changeInfo.DNSChanged {
				e.handleChangeAlert(ctx, d, "dns_change", changeInfo.ChangeSummary)
				if st == statusOK {
					st = statusWarning
				}
			} else {
				_ = e.repo.ResolveAlertsByType(ctx, d.ID, "dns_change")
			}
			if changeInfo.IPChanged || changeInfo.DNSChanged {
				appendIssue(changeInfo.ChangeSummary)
			}
		}
		if d.EnableBlacklist && st != statusCritical && st != statusError {
			var rec map[string]interface{}
			_ = json.Unmarshal([]byte(res.DNSRecords), &rec)
			listed := checkIPsAgainstDNSBL(checkCtx, extractIPList(rec))
			if len(listed) > 0 {
				appendBlacklistToDNSRecords(res, listed)
				if st == statusOK {
					st = statusWarning
				}
				e.handleBlacklistAlert(ctx, d, listed)
				appendIssue("IP 被列入黑名单: " + strings.Join(listed, ", "))
			} else {
				_ = e.repo.ResolveAlertsByType(ctx, d.ID, "blacklist_hit")
			}
		}
		{
			var rec map[string]interface{}
			_ = json.Unmarshal([]byte(res.DNSRecords), &rec)
			if rec == nil {
				rec = map[string]interface{}{}
			}
			eval := evaluateDNSExpectations(checkCtx, d, rec)
			res.DNSRecords = mustJSON(rec)
			e.handleDNSIntelAlerts(ctx, d, res, eval)
			if len(eval.HijackIssues) > 0 {
				appendIssue(strings.Join(eval.HijackIssues, "；"))
			}
			if statusRank(res.Status) > statusRank(st) {
				st = res.Status
			}
		}
		_ = e.repo.SaveCheckResult(ctx, res)
		e.handleAlert(ctx, d, "dns_fail", st, res)
		dnsSt = st
		if isCheckBad(st) {
			appendIssue(dnsIssueText(res))
			if st == statusCritical {
				skipHTTPSSL = true
			}
		}
	}

	saveSkippedResult := func(checkType, reason string) *DmCheckResult {
		res := e.baseResult(d, checkType)
		res.Status = statusError
		res.RawDetail = mustJSON(map[string]string{"error": reason, "skipped": "true"})
		_ = e.repo.SaveCheckResult(ctx, res)
		return res
	}
	if skipHTTPSSL {
		if d.EnableHTTP {
			saveSkippedResult("http", "DNS 解析失败，已跳过 HTTP 检测")
			httpSt = statusError
			appendIssue("HTTP 不可达")
		}
		if d.EnableSSL {
			saveSkippedResult("ssl", "DNS 解析失败，已跳过 SSL 检测")
			sslSt = statusError
		}
	}

	run := func(enabled bool, fn func()) {
		if !enabled {
			return
		}
		wg.Add(1)
		go func() {
			defer wg.Done()
			fn()
		}()
	}

	run(d.EnableHTTP && !skipHTTPSSL && runOnCenter(d, "http"), func() {
		res, st := e.checkHTTP(checkCtx, d)
		var chain []string
		_ = json.Unmarshal([]byte(res.RedirectChain), &chain)
		redir := analyzeRedirect(d.Domain, res.FinalURL, chain)
		if redir.Anomaly {
			if st == statusOK {
				st = statusWarning
			}
			e.handleRedirectAlert(ctx, d, redir.Message)
			mu.Lock()
			appendIssue("HTTP 跳转异常: " + redir.Message)
			mu.Unlock()
		} else {
			_ = e.repo.ResolveAlertsByType(ctx, d.ID, "http_redirect")
		}
		mu.Lock()
		httpSt = st
		httpDurationMs = res.DurationMs
		if isCheckBad(st) {
			appendIssue(httpIssueText(res, st))
		}
		mu.Unlock()
		_ = e.repo.SaveCheckResult(ctx, res)
		e.handleAlert(ctx, d, "http_fail", st, res)
	})
	run(d.EnableSSL && !skipHTTPSSL && runOnCenter(d, "ssl"), func() {
		res, st := e.checkSSL(checkCtx, d)
		_ = e.repo.SaveCheckResult(ctx, res)
		e.handleSSLAlerts(ctx, d, res, st)
		mu.Lock()
		sslSt = st
		if st != statusOK {
			appendIssue(sslIssueText(res))
		}
		mu.Unlock()
	})
	run(d.EnableWhois && runOnCenter(d, "whois"), func() {
		res, st := e.checkWhois(checkCtx, d)
		_ = e.repo.SaveCheckResult(ctx, res)
		e.handleWhoisAlerts(ctx, d, res, st)
		mu.Lock()
		whoisSt = st
		if isCheckBad(st) {
			appendIssue(whoisIssueText(res))
		}
		mu.Unlock()
	})
	run(d.EnableContent && runOnCenter(d, "content"), func() {
		res, st := e.checkContent(checkCtx, d)
		_ = e.repo.SaveCheckResult(ctx, res)
		e.handleContentAlerts(ctx, d, res, st)
		mu.Lock()
		contentSt = st
		if isCheckBad(st) {
			appendIssue(contentIssueText(res))
		}
		mu.Unlock()
	})
	run(d.EnableScreenshot && runOnCenter(d, "screenshot"), func() {
		res, st := e.checkScreenshot(checkCtx, d)
		if res == nil {
			return
		}
		_ = e.repo.SaveCheckResult(ctx, res)
		e.handleScreenshotAlerts(ctx, d, res, st)
		mu.Lock()
		screenshotSt = st
		if isCheckBad(st) {
			appendIssue("页面截图失败")
		}
		mu.Unlock()
	})

	run(d.EnableUserSimulation && runOnCenter(d, "userSimulation"), func() {
		res, st := e.checkUserSimulation(checkCtx, d)
		_ = e.repo.SaveCheckResult(ctx, res)
		e.handleUserSimulationAlerts(ctx, d, res, st)
		mu.Lock()
		if isCheckBad(st) || st == statusWarning {
			appendIssue(userSimulationIssueText(res))
		}
		mu.Unlock()
	})

	waitGroupWithContext(&wg, checkCtx)

	if checkCtx.Err() != nil {
		mu.Lock()
		if checkCtx.Err() == context.DeadlineExceeded {
			appendIssue("检测超时")
		}
		mu.Unlock()
	}

	summary.Issues = issues
	if len(issues) > 0 {
		summary.Reason = strings.Join(issues, "；")
	}
	summary.CheckPath = describeDomainCheckPaths(d, snap.httpProxyUrl)
	now := time.Now().UTC()
	err = e.repo.UpdateDomainStatus(ctx, d.ID, dnsSt, httpSt, sslSt, whoisSt, contentSt, screenshotSt, httpDurationMs, now)
	if err == nil {
		_ = e.aggregateDomainHealth(ctx, d.ID)
	}
	return summary, err
}

func (e *Engine) finishInvalidDomainCheck(ctx context.Context, d *DmDomain) (*DomainCheckSummary, error) {
	reason := "域名无效或为空"
	if d.Domain == "" {
		reason = "域名为空"
	} else if msg := invalidDomainReason(d.Domain); msg != "" {
		reason = msg
	}
	summary := &DomainCheckSummary{
		Domain:    displayDomain(d.Domain),
		OK:        false,
		Reason:    reason,
		Issues:    []string{reason},
		CheckPath: describeDomainCheckPaths(d, e.perf().httpProxyUrl),
	}
	now := time.Now().UTC()
	res := e.baseResult(d, "dns")
	res.Status = statusCritical
	res.DurationMs = 0
	res.DNSRecords = mustJSON(map[string]string{"error": reason})
	res.RawDetail = res.DNSRecords
	_ = e.repo.SaveCheckResult(ctx, res)
	err := e.repo.UpdateDomainStatus(ctx, d.ID, statusCritical, statusError, statusOK, statusOK, statusOK, statusOK, 0, now)
	return summary, err
}

func displayDomain(domain string) string {
	if domain == "" {
		return "(空)"
	}
	return domain
}

func (e *Engine) baseResult(d *DmDomain, checkType string) *DmCheckResult {
	return &DmCheckResult{
		DomainID:  d.ID,
		NodeID:    nodeID,
		NodeName:  nodeName,
		Country:   country,
		City:      city,
		CheckType: checkType,
		CheckedAt: time.Now().UTC(),
	}
}

func (e *Engine) checkDNS(ctx context.Context, d *DmDomain, fast bool) (*DmCheckResult, string) {
	start := time.Now()
	res := e.baseResult(d, "dns")
	host := d.Domain
	rec := map[string]interface{}{}
	status := statusOK

	if ips, err := monitorDNSResolver.LookupHost(ctx, host); err == nil {
		rec["A_AAAA"] = ips
	} else {
		rec["lookupError"] = err.Error()
		status = classifyDNSError(err)
	}

	if !fast {
		var wg sync.WaitGroup
		var mu sync.Mutex
		merge := func(key string, val interface{}) {
			mu.Lock()
			rec[key] = val
			mu.Unlock()
		}
		runLookup := func(fn func() (interface{}, error), key string) {
			wg.Add(1)
			go func() {
				defer wg.Done()
				if ctx.Err() != nil {
					return
				}
				if v, err := fn(); err == nil {
					merge(key, v)
				}
			}()
		}
		wg.Add(1)
		go func() {
			defer wg.Done()
			if ctx.Err() != nil {
				return
			}
			if cname, err := monitorDNSResolver.LookupCNAME(ctx, host); err == nil && cname != "" {
				merge("CNAME", cname)
			}
		}()
		wg.Add(1)
		go func() {
			defer wg.Done()
			if ctx.Err() != nil {
				return
			}
			if ns, err := monitorDNSResolver.LookupNS(ctx, host); err == nil {
				names := make([]string, 0, len(ns))
				for _, n := range ns {
					names = append(names, n.Host)
				}
				merge("NS", names)
			}
		}()
		runLookup(func() (interface{}, error) {
			return monitorDNSResolver.LookupMX(ctx, host)
		}, "MX")
		runLookup(func() (interface{}, error) {
			return monitorDNSResolver.LookupTXT(ctx, host)
		}, "TXT")
		waitGroupWithContext(&wg, ctx)
	}

	res.DurationMs = int(time.Since(start).Milliseconds())
	res.DNSRecords = mustJSON(rec)
	res.Status = status
	res.RawDetail = res.DNSRecords
	return res, status
}

func classifyDNSError(err error) string {
	msg := strings.ToLower(err.Error())
	switch {
	case strings.Contains(msg, "no such host"), strings.Contains(msg, "nxdomain"):
		return statusCritical
	case strings.Contains(msg, "timeout"), strings.Contains(msg, "i/o timeout"):
		return statusError
	default:
		return statusError
	}
}

func (e *Engine) checkHTTP(ctx context.Context, d *DmDomain) (*DmCheckResult, string) {
	start := time.Now()
	res := e.baseResult(d, "http")
	status := statusOK
	chain := []string{}
	finalURL := ""
	code := 0
	var lastErr error

	tryURL := func(scheme, method string) (ok bool, retryGET bool) {
		if ctx.Err() != nil {
			return false, false
		}
		url := scheme + "://" + d.Domain
		req, err := http.NewRequestWithContext(ctx, method, url, nil)
		if err != nil {
			lastErr = err
			return false, false
		}
		req.Header.Set("User-Agent", "EnterpriseDomainMonitor/1.0")
		resp, err := e.client.Do(req)
		if err != nil {
			lastErr = err
			return false, false
		}
		defer resp.Body.Close()
		io.Copy(io.Discard, resp.Body)
		code = resp.StatusCode
		finalURL = resp.Request.URL.String()
		if resp.Request.URL.String() != url && len(chain) == 1 {
			chain = append(chain, finalURL)
		}
		if method == http.MethodHead && (code == http.StatusMethodNotAllowed || code == http.StatusNotImplemented) {
			return false, true
		}
		return true, false
	}

	attempt := func(scheme string) bool {
		if ctx.Err() != nil {
			return false
		}
		chain = []string{scheme + "://" + d.Domain}
		ok, retry := tryURL(scheme, http.MethodHead)
		if ok {
			return true
		}
		if retry {
			okGet, _ := tryURL(scheme, http.MethodGet)
			return okGet
		}
		okGet, _ := tryURL(scheme, http.MethodGet)
		return okGet
	}

	if !attempt("https") {
		if ctx.Err() != nil {
			res.Status = statusError
			res.RawDetail = mustJSON(map[string]string{"error": "http check timeout"})
			res.DurationMs = int(time.Since(start).Milliseconds())
			return res, statusError
		}
		if !attempt("http") {
			res.Status = statusError
			res.DurationMs = int(time.Since(start).Milliseconds())
			detail := checkErrorDetail(lastErr, "unreachable")
			if detail["summary"] == "检测失败" || detail["summary"] == "请求失败" {
				detail["summary"] = "HTTP/HTTPS 不可达"
			}
			res.RawDetail = mustJSON(detail)
			return res, statusError
		}
	}

	res.HTTPStatus = code
	res.FinalURL = finalURL
	res.RedirectChain = mustJSON(chain)
	redir := analyzeRedirect(d.Domain, finalURL, chain)
	rawDetail := map[string]interface{}{"statusCode": code, "finalUrl": finalURL}
	if redir.Hops > 0 || redir.Anomaly {
		rawDetail["redirectAnomaly"] = redir.Anomaly
		rawDetail["redirectMessage"] = redir.Message
		rawDetail["redirectHops"] = redir.Hops
	}
	switch {
	case code >= 200 && code < 400:
		status = statusOK
	case code == 403 || code == 404:
		status = statusWarning
	default:
		status = statusError
	}
	res.Status = status
	res.DurationMs = int(time.Since(start).Milliseconds())
	res.RawDetail = mustJSON(rawDetail)
	return res, status
}

func (e *Engine) checkSSL(ctx context.Context, d *DmDomain) (*DmCheckResult, string) {
	start := time.Now()
	res := e.baseResult(d, "ssl")
	status := statusOK
	addr := net.JoinHostPort(d.Domain, "443")
	dialer := &net.Dialer{Timeout: e.cfg.HTTPTimeout}
	rawConn, err := dialer.DialContext(ctx, "tcp", addr)
	if err != nil {
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.SSLInfo = mustJSON(sslErrorDetail(err))
		return res, statusError
	}
	conn := tls.Client(rawConn, &tls.Config{
		ServerName: d.Domain,
		MinVersion: tls.VersionTLS12,
	})
	if err := conn.HandshakeContext(ctx); err != nil {
		rawConn.Close()
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.SSLInfo = mustJSON(sslErrorDetail(err))
		return res, statusError
	}
	defer conn.Close()

	tlsState := conn.ConnectionState()
	certs := tlsState.PeerCertificates
	if len(certs) == 0 {
		res.Status = statusError
		res.SSLInfo = mustJSON(map[string]interface{}{
			"summary": "未获取到 SSL 证书",
			"error":   "no certificate",
		})
		return res, statusError
	}
	leaf := certs[0]
	daysLeft := int(time.Until(leaf.NotAfter).Hours() / 24)
	hostnameMatch := certMatchesDomain(d.Domain, leaf)
	adv := analyzeSSLAdvanced(tlsState, certs)
	info := map[string]interface{}{
		"issuer":         leaf.Issuer.String(),
		"subject":        leaf.Subject.String(),
		"notBefore":      leaf.NotBefore.UTC().Format(time.RFC3339),
		"notAfter":       leaf.NotAfter.UTC().Format(time.RFC3339),
		"daysLeft":       daysLeft,
		"san":            leaf.DNSNames,
		"serialNumber":   leaf.SerialNumber.String(),
		"hostnameMatch":  hostnameMatch,
		"commonName":     leaf.Subject.CommonName,
		"chainValid":     adv.ChainValid,
		"selfSigned":     adv.SelfSigned,
		"weakAlgorithm":  adv.WeakAlgorithm,
		"tlsVersion":     adv.TLSVersion,
		"sslIssues":      adv.Issues,
	}
	res.SSLInfo = mustJSON(info)
	res.DurationMs = int(time.Since(start).Milliseconds())

	switch {
	case daysLeft < 0:
		status = statusCritical
	case daysLeft <= 3:
		status = statusCritical
	case daysLeft <= 7:
		status = statusError
	case daysLeft <= 15:
		status = statusWarning
	case daysLeft <= 30:
		status = statusWarning
	case !hostnameMatch:
		status = statusWarning
	default:
		status = statusOK
	}
	status = sslStatusFromAdvanced(status, adv)
	res.Status = status
	e.handleSSLAdvancedAlerts(ctx, d, adv)
	return res, status
}

// ---------- P1: WHOIS ----------

func (e *Engine) checkWhois(ctx context.Context, d *DmDomain) (*DmCheckResult, string) {
	start := time.Now()
	res := e.baseResult(d, "whois")
	status := statusOK
	info := map[string]interface{}{}

	type whoisResult struct {
		raw string
		err error
	}
	ch := make(chan whoisResult, 1)
	go func() {
		raw, err := whois.Whois(d.Domain)
		ch <- whoisResult{raw: raw, err: err}
	}()

	var raw string
	var err error
	select {
	case <-ctx.Done():
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.RawDetail = mustJSON(map[string]string{"error": "whois 检测超时"})
		return res, statusError
	case r := <-ch:
		raw, err = r.raw, r.err
	}
	if err != nil {
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.RawDetail = mustJSON(map[string]string{"error": err.Error()})
		return res, statusError
	}

	expireAt, ok := parseWhoisExpiry(raw)
	registrar := parseWhoisField(raw, "Registrar")
	info["registrar"] = registrar
	info["rawExcerpt"] = truncateWhois(raw, 800)

	if ok {
		info["expireAt"] = expireAt.UTC().Format(time.RFC3339)
		daysLeft := int(time.Until(expireAt).Hours() / 24)
		info["daysLeft"] = daysLeft
		_ = e.repo.UpdateWhoisExpireAt(ctx, d.ID, &expireAt)
		switch {
		case daysLeft < 0:
			status = statusCritical
		case daysLeft <= 7:
			status = statusCritical
		case daysLeft <= 15:
			status = statusError
		case daysLeft <= 30:
			status = statusWarning
		default:
			status = statusOK
		}
	} else {
		status = statusWarning
		info["parseWarning"] = "expiry date not found"
	}

	res.RawDetail = mustJSON(info)
	res.DurationMs = int(time.Since(start).Milliseconds())
	res.Status = status
	return res, status
}

func parseWhoisField(raw, key string) string {
	re := regexp.MustCompile(`(?im)^` + regexp.QuoteMeta(key) + `:\s*(.+)$`)
	if m := re.FindStringSubmatch(raw); len(m) > 1 {
		return strings.TrimSpace(m[1])
	}
	return ""
}

func parseWhoisExpiry(raw string) (time.Time, bool) {
	patterns := []string{
		`(?i)(Registry Expiry Date|Registrar Registration Expiration Date|Expiration Date|Expiry Date|Exp Date|paid-till|Renewal Date)[^:\n]*:\s*([^\n]+)`,
	}
	for _, p := range patterns {
		re := regexp.MustCompile(p)
		if m := re.FindStringSubmatch(raw); len(m) > 2 {
			if t, ok := tryParseWhoisDate(strings.TrimSpace(m[2])); ok {
				return t, true
			}
		}
	}
	return time.Time{}, false
}

func tryParseWhoisDate(s string) (time.Time, bool) {
	s = strings.TrimSpace(s)
	formats := []string{
		time.RFC3339,
		"2006-01-02T15:04:05Z",
		"2006-01-02 15:04:05",
		"2006-01-02",
		"02-Jan-2006",
		"2006.01.02",
		"2006/01/02",
	}
	for _, f := range formats {
		if t, err := time.Parse(f, s); err == nil {
			return t, true
		}
	}
	if i := strings.IndexAny(s, " \t"); i > 0 {
		if t, ok := tryParseWhoisDate(s[:i]); ok {
			return t, true
		}
	}
	return time.Time{}, false
}

func truncateWhois(s string, max int) string {
	if len(s) <= max {
		return s
	}
	return s[:max] + "..."
}

func (e *Engine) handleWhoisAlerts(ctx context.Context, d *DmDomain, res *DmCheckResult, st string) {
	if st == statusOK {
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, "whois_expire")
		return
	}
	var info struct {
		DaysLeft int `json:"daysLeft"`
	}
	_ = json.Unmarshal([]byte(res.RawDetail), &info)
	severity := "WARNING"
	if st == statusCritical || st == statusError {
		severity = "CRITICAL"
	}
	title := fmt.Sprintf("[whois_expire] %s", d.Domain)
	msg := fmt.Sprintf("WHOIS 剩余 %d 天", info.DaysLeft)
	alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "whois_expire", severity, title, msg)
	if err != nil {
		return
	}
	e.dispatchTelegram(ctx, "whois_expire", severity, title, msg, alert)
}

// ---------- P1: Content hash ----------

const maxContentBytes = 1 << 20 // 1MB

func (e *Engine) checkContent(ctx context.Context, d *DmDomain) (*DmCheckResult, string) {
	start := time.Now()
	res := e.baseResult(d, "content")
	status := statusOK

	target := strings.TrimSpace(d.ContentURL)
	if target == "" {
		target = "https://" + d.Domain
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	if err != nil {
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.RawDetail = mustJSON(map[string]string{"error": err.Error()})
		return res, statusError
	}
	req.Header.Set("User-Agent", "EnterpriseDomainMonitor/1.0")
	resp, err := e.client.Do(req)
	if err != nil {
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.RawDetail = mustJSON(map[string]string{"error": err.Error(), "url": target})
		return res, statusError
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(io.LimitReader(resp.Body, maxContentBytes))
	if err != nil {
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.RawDetail = mustJSON(map[string]string{"error": err.Error()})
		return res, statusError
	}

	norm := normalizeContent(body)
	hash := sha256.Sum256(norm)
	hashHex := hex.EncodeToString(hash[:])

	keywords := parseContentKeywords(d.ContentKeywords)
	missing := []string{}
	for _, kw := range keywords {
		if kw == "" {
			continue
		}
		if !strings.Contains(strings.ToLower(string(body)), strings.ToLower(kw)) {
			missing = append(missing, kw)
		}
	}
	if len(missing) > 0 {
		status = statusError
	}

	baseline := strings.TrimSpace(d.ContentHashBaseline)
	changed := false
	if baseline == "" {
		_ = e.repo.UpdateContentBaseline(ctx, d.ID, hashHex)
		baseline = hashHex
	} else if hashHex != baseline {
		changed = true
		if status != statusError {
			status = statusCritical
		}
	}

	info := map[string]interface{}{
		"url":         target,
		"hash":        hashHex,
		"baseline":    baseline,
		"changed":     changed,
		"sizeBytes":   len(body),
		"httpStatus":  resp.StatusCode,
		"missingKeywords": missing,
	}
	res.HTTPStatus = resp.StatusCode
	res.RawDetail = mustJSON(info)
	res.DurationMs = int(time.Since(start).Milliseconds())
	res.Status = status
	return res, status
}

func normalizeContent(b []byte) []byte {
	var out strings.Builder
	out.Grow(len(b))
	lastSpace := false
	for _, r := range string(b) {
		if unicode.IsSpace(r) {
			if !lastSpace {
				out.WriteByte(' ')
				lastSpace = true
			}
			continue
		}
		lastSpace = false
		out.WriteRune(r)
	}
	return []byte(strings.TrimSpace(out.String()))
}

func parseContentKeywords(raw string) []string {
	if raw == "" || raw == "[]" {
		return nil
	}
	var arr []string
	if err := json.Unmarshal([]byte(raw), &arr); err != nil {
		return nil
	}
	return arr
}

func (e *Engine) handleContentAlerts(ctx context.Context, d *DmDomain, res *DmCheckResult, st string) {
	if st == statusOK {
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, "content_change")
		return
	}
	var info struct {
		Changed         bool     `json:"changed"`
		MissingKeywords []string `json:"missingKeywords"`
	}
	_ = json.Unmarshal([]byte(res.RawDetail), &info)
	severity := "ERROR"
	if st == statusCritical {
		severity = "CRITICAL"
	}
	title := fmt.Sprintf("[content_change] %s", d.Domain)
	msg := "页面内容哈希与基线不一致"
	if len(info.MissingKeywords) > 0 {
		msg = fmt.Sprintf("页面缺少关键词: %s", strings.Join(info.MissingKeywords, ", "))
	} else if info.Changed {
		msg = "页面内容哈希与基线不一致"
	}
	alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "content_change", severity, title, msg)
	if err != nil {
		return
	}
	e.dispatchTelegram(ctx, "content_change", severity, title, msg, alert)
}

func (e *Engine) handleAlert(ctx context.Context, d *DmDomain, alertType, st string, res *DmCheckResult) {
	if st == statusOK || st == statusWarning {
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, alertType)
		return
	}
	severity := "ERROR"
	if st == statusCritical {
		severity = "CRITICAL"
	}
	title := fmt.Sprintf("[%s] %s", alertType, d.Domain)
	msg := alertMessageForCheck(alertType, st, res)
	alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, alertType, severity, title, msg)
	if err != nil {
		return
	}
	e.dispatchTelegram(ctx, alertType, severity, title, msg, alert)
}

func (e *Engine) handleSSLAlerts(ctx context.Context, d *DmDomain, res *DmCheckResult, st string) {
	var info struct {
		DaysLeft      int  `json:"daysLeft"`
		HostnameMatch bool `json:"hostnameMatch"`
	}
	_ = json.Unmarshal([]byte(res.SSLInfo), &info)

	expireAlert := info.DaysLeft < 0 || info.DaysLeft <= 30
	if expireAlert {
		expireSeverity := "WARNING"
		if info.DaysLeft < 0 || info.DaysLeft <= 3 {
			expireSeverity = "CRITICAL"
		} else if info.DaysLeft <= 7 {
			expireSeverity = "CRITICAL"
		}
		title := fmt.Sprintf("[ssl_expire] %s", d.Domain)
		msg := fmt.Sprintf("SSL 剩余 %d 天", info.DaysLeft)
		alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "ssl_expire", expireSeverity, title, msg)
		if err == nil {
			e.dispatchTelegram(ctx, "ssl_expire", expireSeverity, title, msg, alert)
		}
	} else {
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, "ssl_expire")
	}
	if !info.HostnameMatch {
		title := fmt.Sprintf("[ssl_mismatch] %s", d.Domain)
		msg := fmt.Sprintf("SSL 证书 CN/SAN 与域名 %s 不匹配", d.Domain)
		alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "ssl_mismatch", "WARNING", title, msg)
		if err == nil {
			e.dispatchTelegram(ctx, "ssl_mismatch", "WARNING", title, msg, alert)
		}
	} else {
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, "ssl_mismatch")
	}
	_ = st
}

func (e *Engine) handleChangeAlert(ctx context.Context, d *DmDomain, alertType, msg string) {
	if msg == "" || msg == alertType {
		msg = defaultAlertDetail(alertType)
	}
	title := fmt.Sprintf("[%s] %s", alertType, d.Domain)
	alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, alertType, "WARNING", title, msg)
	if err != nil {
		return
	}
	e.dispatchTelegram(ctx, alertType, "WARNING", title, msg, alert)
}

func (e *Engine) handleRedirectAlert(ctx context.Context, d *DmDomain, msg string) {
	if msg == "" {
		msg = "HTTP 发生跨域跳转"
	}
	title := fmt.Sprintf("[http_redirect] %s", d.Domain)
	alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "http_redirect", "WARNING", title, msg)
	if err != nil {
		return
	}
	e.dispatchTelegram(ctx, "http_redirect", "WARNING", title, msg, alert)
}

func (e *Engine) handleBlacklistAlert(ctx context.Context, d *DmDomain, listed []string) {
	msg := strings.Join(listed, "; ")
	title := fmt.Sprintf("[blacklist_hit] %s", d.Domain)
	alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "blacklist_hit", "ERROR", title, msg)
	if err != nil {
		return
	}
	e.dispatchTelegram(ctx, "blacklist_hit", "ERROR", title, msg, alert)
}

func (e *Engine) dispatchTelegram(ctx context.Context, alertType, severity, title, msg string, alert *DmAlert) {
	if alert == nil {
		return
	}
	if !e.markTelegramCooldown(ctx, alert, alertType) {
		return
	}

	routes, err := e.repo.MatchRoutes(ctx, alertType, severity)
	if err != nil || len(routes) == 0 {
		return
	}
	settings, _ := e.repo.GetCheckSettings(ctx)
	if settings == nil || !settings.TelegramRealtimeEnabled {
		return
	}
	text := formatTelegramAlertText(settings, alertType, severity, title, msg)
	for _, rt := range routes {
		if strings.EqualFold(strings.TrimSpace(rt.SendMode), "batch") {
			continue
		}
		var grp DmTelegramGroup
		if err := e.repo.db.WithContext(ctx).First(&grp, "id = ?", rt.GroupID).Error; err != nil {
			continue
		}
		var bot DmTelegramBot
		if err := e.repo.db.WithContext(ctx).First(&bot, "id = ?", grp.BotID).Error; err != nil || !bot.Enabled {
			continue
		}
		token, err := decryptToken(e.cfg.SecretKey, bot.BotTokenEnc)
		if err != nil {
			continue
		}
		_ = telegramSendMessage(token, grp.ChatID, text)
	}
}

func (e *Engine) markTelegramCooldown(ctx context.Context, alert *DmAlert, alertType string) bool {
	key := fmt.Sprintf("dm:tg:cooldown:%s:%s", alert.DomainID.String(), alertType)
	if e.redis != nil {
		ok, err := e.redis.SetNX(ctx, key, "1", e.notifyCooldown).Result()
		if err == nil {
			return ok
		}
		log.Printf("[DomainMonitor] telegram cooldown redis error: %v", err)
	}

	memKey := alertType + ":" + alert.ID.String()
	e.notifyMu.Lock()
	defer e.notifyMu.Unlock()
	if t, ok := e.lastNotify[memKey]; ok && time.Since(t) < e.notifyCooldown {
		return false
	}
	e.lastNotify[memKey] = time.Now()
	return true
}

// ---------- Telegram API ----------

type tgMeResponse struct {
	OK     bool `json:"ok"`
	Result struct {
		ID        int64  `json:"id"`
		IsBot     bool   `json:"is_bot"`
		Username  string `json:"username"`
		FirstName string `json:"first_name"`
	} `json:"result"`
}

func telegramGetMe(token string) (*tgMeResponse, error) {
	url := fmt.Sprintf("https://api.telegram.org/bot%s/getMe", token)
	resp, err := http.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var out tgMeResponse
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return nil, err
	}
	if !out.OK {
		return nil, fmtErr("telegram getMe failed")
	}
	return &out, nil
}

func telegramSendMessage(token, chatID, text string) error {
	text = strings.TrimSpace(text)
	if text == "" {
		return fmtErr("telegram send failed: empty message")
	}
	const maxChunkRunes = 4000
	chunks := splitTelegramText(text, maxChunkRunes)
	if len(chunks) == 1 {
		return telegramSendMessageOnce(token, chatID, chunks[0])
	}
	for i, chunk := range chunks {
		payload := fmt.Sprintf("(%d/%d)\n%s", i+1, len(chunks), chunk)
		if err := telegramSendMessageOnce(token, chatID, payload); err != nil {
			return err
		}
	}
	return nil
}

func telegramSendMessageOnce(token, chatID, text string) error {
	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", token)
	body := map[string]string{"chat_id": chatID, "text": text}
	b, _ := json.Marshal(body)
	resp, err := http.Post(url, "application/json", strings.NewReader(string(b)))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 300 {
		desc := parseTelegramError(respBody)
		if desc != "" {
			return fmt.Errorf("telegram send failed: %d (%s)", resp.StatusCode, desc)
		}
		return fmtErr("telegram send failed: %d", resp.StatusCode)
	}
	return nil
}

func parseTelegramError(body []byte) string {
	var out struct {
		Description string `json:"description"`
	}
	if err := json.Unmarshal(body, &out); err != nil {
		return strings.TrimSpace(string(body))
	}
	return strings.TrimSpace(out.Description)
}

func splitTelegramText(text string, maxRunes int) []string {
	if maxRunes <= 0 {
		maxRunes = 4096
	}
	if utf8.RuneCountInString(text) <= maxRunes {
		return []string{text}
	}
	lines := strings.Split(text, "\n")
	var chunks []string
	var b strings.Builder
	for _, line := range lines {
		lineRunes := utf8.RuneCountInString(line)
		if lineRunes > maxRunes {
			if b.Len() > 0 {
				chunks = append(chunks, b.String())
				b.Reset()
			}
			for _, part := range splitLongLine(line, maxRunes) {
				chunks = append(chunks, part)
			}
			continue
		}
		sep := 0
		if b.Len() > 0 {
			sep = 1
		}
		if utf8.RuneCountInString(b.String())+sep+lineRunes > maxRunes {
			chunks = append(chunks, b.String())
			b.Reset()
		}
		if b.Len() > 0 {
			b.WriteByte('\n')
		}
		b.WriteString(line)
	}
	if b.Len() > 0 {
		chunks = append(chunks, b.String())
	}
	return chunks
}

func splitLongLine(line string, maxRunes int) []string {
	runes := []rune(line)
	var out []string
	for len(runes) > 0 {
		n := maxRunes
		if n > len(runes) {
			n = len(runes)
		}
		out = append(out, string(runes[:n]))
		runes = runes[n:]
	}
	return out
}

type tgUpdatesResponse struct {
	OK     bool `json:"ok"`
	Result []struct {
		Message *struct {
			Chat struct {
				ID    int64  `json:"id"`
				Title string `json:"title"`
				Type  string `json:"type"`
			} `json:"chat"`
		} `json:"message"`
		ChannelPost *struct {
			Chat struct {
				ID    int64  `json:"id"`
				Title string `json:"title"`
				Type  string `json:"type"`
			} `json:"chat"`
		} `json:"channel_post"`
		MyChatMember *struct {
			Chat struct {
				ID    int64  `json:"id"`
				Title string `json:"title"`
				Type  string `json:"type"`
			} `json:"chat"`
		} `json:"my_chat_member"`
	} `json:"result"`
}

func telegramGetRecentGroups(token string) ([]map[string]string, error) {
	url := fmt.Sprintf(
		"https://api.telegram.org/bot%s/getUpdates?limit=100&allowed_updates=%s",
		token,
		"%5B%22message%22%2C%22channel_post%22%2C%22my_chat_member%22%5D",
	)
	resp, err := http.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var out tgUpdatesResponse
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return nil, err
	}
	seen := map[string]map[string]string{}
	addChat := func(id int64, chatType, title string) {
		if chatType != "group" && chatType != "supergroup" && chatType != "channel" {
			return
		}
		key := strconv.FormatInt(id, 10)
		if _, ok := seen[key]; ok {
			return
		}
		name := title
		if name == "" {
			name = key
		}
		seen[key] = map[string]string{
			"chatId":    key,
			"groupName": name,
			"chatType":  chatType,
		}
	}
	for _, u := range out.Result {
		if u.Message != nil {
			c := u.Message.Chat
			addChat(c.ID, c.Type, c.Title)
		}
		if u.ChannelPost != nil {
			c := u.ChannelPost.Chat
			addChat(c.ID, c.Type, c.Title)
		}
		if u.MyChatMember != nil {
			c := u.MyChatMember.Chat
			addChat(c.ID, c.Type, c.Title)
		}
	}
	list := make([]map[string]string, 0, len(seen))
	for _, v := range seen {
		list = append(list, v)
	}
	return list, nil
}

func (e *Engine) VerifyBot(ctx context.Context, bot *DmTelegramBot) error {
	token, err := decryptToken(e.cfg.SecretKey, bot.BotTokenEnc)
	if err != nil {
		return err
	}
	me, err := telegramGetMe(token)
	if err != nil {
		return err
	}
	now := time.Now().UTC()
	bot.BotID = me.Result.ID
	bot.BotUsername = me.Result.Username
	if bot.BotName == "" {
		bot.BotName = me.Result.FirstName
	}
	bot.VerifiedAt = &now
	return e.repo.SaveBot(ctx, bot)
}

func (e *Engine) EncryptBotToken(plain string) (string, error) {
	return encryptToken(e.cfg.SecretKey, plain)
}

func (e *Engine) DecryptBotToken(enc string) (string, error) {
	return decryptToken(e.cfg.SecretKey, enc)
}

// ---------- P2: Screenshot (Headless Chrome / chromedp) ----------

func (e *Engine) checkScreenshot(ctx context.Context, d *DmDomain) (*DmCheckResult, string) {
	if !e.cfg.ScreenshotEnabled {
		return nil, statusOK
	}
	url := strings.TrimSpace(d.ScreenshotURL)
	if url == "" {
		url = "https://" + d.Domain
	}
	start := time.Now()
	res := e.baseResult(d, "screenshot")
	status := statusOK

	dir := filepath.Join(e.cfg.UploadsDir, "domain-monitor", "screenshots", d.ID.String())
	if err := os.MkdirAll(dir, 0755); err != nil {
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.RawDetail = mustJSON(map[string]string{"error": err.Error()})
		return res, statusError
	}
	fname := time.Now().UTC().Format("20060102-150405") + ".png"
	fullPath := filepath.Join(dir, fname)

	opts := append(chromedp.DefaultExecAllocatorOptions[:],
		chromedp.Flag("headless", true),
		chromedp.Flag("disable-gpu", true),
		chromedp.Flag("no-sandbox", true),
		chromedp.Flag("disable-dev-shm-usage", true),
	)
	if e.cfg.ChromePath != "" {
		opts = append(opts, chromedp.ExecPath(e.cfg.ChromePath))
	}
	allocCtx, cancel := chromedp.NewExecAllocator(ctx, opts...)
	defer cancel()
	cctx, cancel2 := chromedp.NewContext(allocCtx)
	defer cancel2()

	var buf []byte
	err := chromedp.Run(cctx,
		chromedp.Navigate(url),
		chromedp.FullScreenshot(&buf, 90),
	)
	if err != nil {
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.RawDetail = mustJSON(map[string]string{"error": err.Error(), "url": url})
		return res, statusError
	}
	if err := os.WriteFile(fullPath, buf, 0644); err != nil {
		res.Status = statusError
		res.DurationMs = int(time.Since(start).Milliseconds())
		res.RawDetail = mustJSON(map[string]string{"error": err.Error()})
		return res, statusError
	}
	rel := filepath.ToSlash(filepath.Join("domain-monitor", "screenshots", d.ID.String(), fname))
	res.ScreenshotPath = rel
	res.DurationMs = int(time.Since(start).Milliseconds())
	res.RawDetail = mustJSON(map[string]interface{}{"url": url, "screenshotPath": rel, "bytes": len(buf)})
	res.Status = status
	return res, status
}

func (e *Engine) handleScreenshotAlerts(ctx context.Context, d *DmDomain, res *DmCheckResult, st string) {
	if st == statusOK {
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, "screenshot_fail")
		return
	}
	severity := "ERROR"
	if st == statusCritical {
		severity = "CRITICAL"
	}
	title := fmt.Sprintf("[screenshot_fail] %s", d.Domain)
	msg := "页面截图失败"
	alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "screenshot_fail", severity, title, msg)
	if err != nil {
		return
	}
	e.dispatchTelegram(ctx, "screenshot_fail", severity, title, msg, alert)
}

func (e *Engine) SaveScreenshotFile(domainID uuid.UUID, data []byte) (string, error) {
	dir := filepath.Join(e.cfg.UploadsDir, "domain-monitor", "screenshots", domainID.String())
	if err := os.MkdirAll(dir, 0755); err != nil {
		return "", err
	}
	fname := time.Now().UTC().Format("20060102-150405") + ".png"
	fullPath := filepath.Join(dir, fname)
	if err := os.WriteFile(fullPath, data, 0644); err != nil {
		return "", err
	}
	return filepath.ToSlash(filepath.Join("domain-monitor", "screenshots", domainID.String(), fname)), nil
}

// ---------- P2: Probe tasks ----------

func (e *Engine) enqueueProbeTasks(ctx context.Context, domainID uuid.UUID) {
	d, err := e.repo.GetDomain(ctx, domainID)
	if err != nil || d == nil || !d.Enabled {
		return
	}
	nodes, err := e.repo.ListOnlineNodes(ctx, 5*time.Minute)
	if err != nil || len(nodes) == 0 {
		return
	}
	snap := e.perf()
	specs := buildProbeChecks(d, snap.httpProxyUrl, snap.fastDnsCheck)
	legacy := !d.EnableProbeDetection && len(specs) == 0
	if legacy {
		specs = []ProbeCheckSpec{{Type: "http", URL: probeTargetURL(d, "http")}}
	}
	if len(specs) == 0 {
		return
	}
	specsJSON := mustJSON(specs)
	for _, n := range nodes {
		if !probeNodeSelected(d, n.ID.String()) {
			continue
		}
		_ = e.repo.CreateProbeTask(ctx, domainID, n.ID, specsJSON)
	}
}

type ProbeResultIn struct {
	CheckType      string `json:"checkType"`
	Status         string `json:"status"`
	DurationMs     int    `json:"durationMs"`
	HTTPStatus     int    `json:"httpStatus"`
	FinalURL       string `json:"finalUrl"`
	DNSRecords     string `json:"dnsRecords"`
	SSLInfo        string `json:"sslInfo"`
	RedirectChain  string `json:"redirectChain"`
	RawDetail      string `json:"rawDetail"`
	ScreenshotPath string `json:"screenshotPath"`
}

func (e *Engine) IngestProbeResults(ctx context.Context, node *DmNode, taskID uuid.UUID, results []ProbeResultIn, screenshot []byte) error {
	task, err := e.repo.GetProbeTask(ctx, taskID, node.ID)
	if err != nil || task == nil || task.Domain == nil {
		return fmtErr("invalid probe task")
	}
	d := task.Domain
	for _, in := range results {
		res := &DmCheckResult{
			DomainID:      d.ID,
			NodeID:        node.ID.String(),
			NodeName:      node.Name,
			Country:       node.Country,
			City:          node.City,
			CheckType:     in.CheckType,
			Status:        in.Status,
			DurationMs:    in.DurationMs,
			HTTPStatus:    in.HTTPStatus,
			FinalURL:      in.FinalURL,
			DNSRecords:    in.DNSRecords,
			SSLInfo:       in.SSLInfo,
			RedirectChain: in.RedirectChain,
			RawDetail:     in.RawDetail,
			CheckedAt:     time.Now().UTC(),
		}
		if in.CheckType == "screenshot" && len(screenshot) > 0 {
			path, err := e.SaveScreenshotFile(d.ID, screenshot)
			if err == nil {
				res.ScreenshotPath = path
			}
		} else if in.ScreenshotPath != "" {
			res.ScreenshotPath = in.ScreenshotPath
		}
		_ = e.repo.SaveCheckResult(ctx, res)
		if in.Status != statusOK && in.Status != statusWarning {
			alertType := in.CheckType + "_fail"
			switch in.CheckType {
			case "http":
				alertType = "http_fail"
			case "userSimulation":
				alertType = "user_sim_fail"
			case "screenshot":
				alertType = "screenshot_fail"
			}
			e.handleAlert(ctx, d, alertType, in.Status, res)
		}
		if in.CheckType == "userSimulation" && in.Status == statusWarning {
			e.handleUserSimulationAlerts(ctx, d, res, in.Status)
		}
	}
	if err := e.repo.CompleteProbeTask(ctx, taskID); err != nil {
		return err
	}
	return e.aggregateDomainHealth(ctx, d.ID)
}

// ---------- P2: PDF reports ----------

func (e *Engine) reportLoop(ctx context.Context) {
	defer e.wg.Done()
	ticker := time.NewTicker(time.Hour)
	defer ticker.Stop()
	for {
		select {
		case <-e.stop:
			return
		case <-ctx.Done():
			return
		case <-ticker.C:
			e.maybeGenerateReports(ctx)
		}
	}
}

func (e *Engine) maybeGenerateReports(ctx context.Context) {
	now := time.Now().UTC()
	if now.Hour() == 1 {
		start := now.AddDate(0, 0, -1).Truncate(24 * time.Hour)
		end := start.Add(24 * time.Hour)
		exists, _ := e.repo.ReportExists(ctx, "daily", start)
		if !exists {
			_ = e.GenerateReport(ctx, "daily", start, end)
		}
	}
	if now.Weekday() == time.Monday && now.Hour() == 2 {
		start := now.AddDate(0, 0, -7).Truncate(24 * time.Hour)
		end := start.AddDate(0, 0, 7)
		exists, _ := e.repo.ReportExists(ctx, "weekly", start)
		if !exists {
			_ = e.GenerateReport(ctx, "weekly", start, end)
		}
	}
}

func (e *Engine) GenerateReport(ctx context.Context, reportType string, start, end time.Time) error {
	stats, err := e.repo.DashboardStats(ctx)
	if err != nil {
		return err
	}
	trends, _ := e.repo.AvailabilityTrend(ctx, 7)
	dir := filepath.Join(e.cfg.UploadsDir, "domain-monitor", "reports")
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	fname := fmt.Sprintf("%s_%s.pdf", reportType, start.Format("20060102"))
	fullPath := filepath.Join(dir, fname)

	pdf := gofpdf.New("P", "mm", "A4", "")
	pdf.AddPage()
	pdf.SetFont("Arial", "B", 16)
	title := "Domain Monitor Report"
	if reportType == "weekly" {
		title = "Weekly " + title
	} else {
		title = "Daily " + title
	}
	pdf.Cell(190, 10, title)
	pdf.Ln(12)
	pdf.SetFont("Arial", "", 11)
	pdf.Cell(190, 8, fmt.Sprintf("Period: %s ~ %s", start.Format("2006-01-02"), end.Format("2006-01-02")))
	pdf.Ln(10)
	pdf.Cell(190, 7, fmt.Sprintf("Total domains: %d  Normal: %d  Abnormal: %d", stats.TotalDomains, stats.NormalCount, stats.AbnormalCount))
	pdf.Ln(7)
	pdf.Cell(190, 7, fmt.Sprintf("Availability: %.1f%%  Open alerts: %d  Online nodes: %d", stats.Availability, stats.OpenAlerts, stats.OnlineNodes))
	pdf.Ln(10)
	pdf.SetFont("Arial", "B", 12)
	pdf.Cell(190, 8, "7-day HTTP trend")
	pdf.Ln(8)
	pdf.SetFont("Arial", "", 10)
	for _, t := range trends {
		pdf.Cell(190, 6, fmt.Sprintf("%s  ok=%d fail=%d avail=%.1f%%", t.Date, t.OkCount, t.FailCount, t.Availability))
		pdf.Ln(6)
	}
	if err := pdf.OutputFileAndClose(fullPath); err != nil {
		return err
	}
	rel := filepath.ToSlash(filepath.Join("domain-monitor", "reports", fname))
	summary := mustJSON(map[string]interface{}{
		"totalDomains": stats.TotalDomains,
		"abnormal":     stats.AbnormalCount,
		"availability": stats.Availability,
		"openAlerts":   stats.OpenAlerts,
	})
	rep := &DmReport{
		ReportType:  reportType,
		PeriodStart: start,
		PeriodEnd:   end,
		FilePath:    rel,
		Summary:     summary,
	}
	return e.repo.SaveReport(ctx, rep)
}

func GenerateNodeAPIKey() (string, error) {
	b := make([]byte, 24)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}

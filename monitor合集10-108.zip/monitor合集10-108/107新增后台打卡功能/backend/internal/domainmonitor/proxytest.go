package domainmonitor

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"enterprise-agent/backend/internal/proxytransport"
	"enterprise-agent/backend/internal/ssrfguard"
)

const (
	defaultProxyTestHTTPURL  = "http://example.com"
	defaultProxyTestHTTPSURL = "https://example.com"
	defaultProxyIPCheckURL   = "https://api.ipify.org?format=text"
)

type ProxyTestStep struct {
	Name       string `json:"name"`
	OK         bool   `json:"ok"`
	TestURL    string `json:"testUrl,omitempty"`
	HTTPStatus int    `json:"httpStatus,omitempty"`
	DurationMs int64  `json:"durationMs,omitempty"`
	Summary    string `json:"summary,omitempty"`
	Hint       string `json:"hint,omitempty"`
	Error      string `json:"error,omitempty"`
}

type ProxyTestResult struct {
	OK           bool            `json:"ok"`
	Mode         string          `json:"mode"`
	ProxyDisplay string          `json:"proxyDisplay,omitempty"`
	TestURL      string          `json:"testUrl"`
	HTTPStatus   int             `json:"httpStatus,omitempty"`
	DurationMs   int64           `json:"durationMs,omitempty"`
	ExitIP       string          `json:"exitIp,omitempty"`
	DirectExitIP string          `json:"directExitIp,omitempty"`
	Message      string          `json:"message"`
	Summary      string          `json:"summary,omitempty"`
	Hint         string          `json:"hint,omitempty"`
	Error        string          `json:"error,omitempty"`
	Steps        []ProxyTestStep `json:"steps,omitempty"`
}

func testHTTPProxy(ctx context.Context, proxyURL, testURL string, timeout time.Duration) ProxyTestResult {
	proxyURL = strings.TrimSpace(proxyURL)
	testURL = strings.TrimSpace(testURL)
	if timeout <= 0 {
		timeout = 15 * time.Second
	}

	mode := "direct"
	display := ""
	if proxyURL != "" {
		mode = "proxy"
		normalized, normErr := proxytransport.NormalizeProxyURL(proxyURL)
		if normErr != nil {
			return failProxyTest(mode, display, testURL, "代理地址无效", normErr.Error(), nil)
		}
		proxyURL = normalized
		display = proxytransport.MaskProxyURL(proxyURL)
		if hint := validateHTTPProxyScheme(proxyURL); hint != "" {
			return failProxyTest(mode, display, testURL, "代理地址格式不支持", hint, nil)
		}
		if hint := validateHTTPProxyURL(proxyURL); hint != "" {
			return failProxyTest(mode, display, testURL, "代理地址可能不正确", hint, nil)
		}
		if scheme := proxytransport.ProxyScheme(proxyURL); proxytransport.IsSOCKS(scheme) {
			mode = "socks5"
		}
	}

	client := newMonitorHTTPClient(timeout, proxyURL)
	steps := make([]ProxyTestStep, 0, 3)

	if mode == "proxy" {
		steps = append(steps, runProxyTestStep(ctx, client, "HTTP 经代理", defaultProxyTestHTTPURL))
	}

	targetHTTPS := testURL
	if targetHTTPS == "" {
		targetHTTPS = defaultProxyTestHTTPSURL
	} else if err := ssrfguard.ValidateOutboundURL(targetHTTPS); err != nil {
		return failProxyTest(mode, display, targetHTTPS, "测试 URL 不允许", err.Error(), nil)
	}
	httpsStep := runProxyTestStep(ctx, client, stepLabel(mode, "HTTPS"), targetHTTPS)
	steps = append(steps, httpsStep)
	if !httpsStep.OK {
		hint := httpsStep.Hint
		if extra := httpsConnectFailureHint(steps, httpsStep); extra != "" {
			if hint != "" {
				hint = extra + "\n\n" + hint
			} else {
				hint = extra
			}
		}
		httpsStep.Hint = hint
		return failProxyTestFromStep(mode, display, targetHTTPS, httpsStep, steps)
	}

	exitIP, _ := proxyTestFetchText(ctx, client, defaultProxyIPCheckURL)
	directIP := ""
	if mode == "proxy" {
		directClient := newMonitorHTTPClient(timeout, "")
		directIP, _ = proxyTestFetchText(ctx, directClient, defaultProxyIPCheckURL)
	}

	msg := "HTTPS 请求成功，代理可用"
	if mode == "direct" {
		msg = "本机直连 HTTPS 请求成功（当前未配置代理）"
	}
	if exitIP != "" {
		msg += "，出口 IP：" + exitIP
	}

	return ProxyTestResult{
		OK:           true,
		Mode:         mode,
		ProxyDisplay: display,
		TestURL:      targetHTTPS,
		HTTPStatus:   httpsStep.HTTPStatus,
		DurationMs:   httpsStep.DurationMs,
		ExitIP:       exitIP,
		DirectExitIP: directIP,
		Message:      msg,
		Hint:         proxyEffectiveHint(mode, directIP, exitIP),
		Steps:        steps,
	}
}

func stepLabel(mode, kind string) string {
	if mode == "proxy" {
		return kind + " 经代理"
	}
	return kind + " 直连"
}

func runProxyTestStep(ctx context.Context, client *http.Client, name, target string) ProxyTestStep {
	start := time.Now()
	code, err := proxyTestFetch(ctx, client, target)
	step := ProxyTestStep{
		Name:       name,
		TestURL:    target,
		DurationMs: time.Since(start).Milliseconds(),
	}
	if err != nil {
		detail := checkErrorDetail(err, "proxy_test_failed")
		step.Summary = strField(detail, "summary", "请求失败")
		step.Hint = strField(detail, "hint", "")
		step.Error = strField(detail, "error", err.Error())
		if extra := proxyStepExtraHint(err); extra != "" {
			if step.Hint != "" {
				step.Hint = extra + " " + step.Hint
			} else {
				step.Hint = extra
			}
		}
		return step
	}
	step.OK = true
	step.HTTPStatus = code
	step.Summary = "成功"
	return step
}

func failProxyTestFromStep(mode, display, testURL string, step ProxyTestStep, steps []ProxyTestStep) ProxyTestResult {
	return ProxyTestResult{
		OK:           false,
		Mode:         mode,
		ProxyDisplay: display,
		TestURL:      testURL,
		DurationMs:   step.DurationMs,
		Message:      step.Summary,
		Summary:      step.Summary,
		Hint:         step.Hint,
		Error:        step.Error,
		Steps:        steps,
	}
}

func failProxyTest(mode, display, testURL, summary, hint string, steps []ProxyTestStep) ProxyTestResult {
	if testURL == "" {
		testURL = defaultProxyTestHTTPSURL
	}
	return ProxyTestResult{
		OK:           false,
		Mode:         mode,
		ProxyDisplay: display,
		TestURL:      testURL,
		Message:      summary,
		Summary:      summary,
		Hint:         hint,
		Steps:        steps,
	}
}

func proxyEffectiveHint(mode, directIP, exitIP string) string {
	if mode == "proxy" && directIP != "" && exitIP != "" && directIP == exitIP {
		return "出口 IP 与直连相同，代理可能未生效或为目标局域网地址，请核对代理端口与协议（需 HTTP 代理，非 SOCKS）。"
	}
	return ""
}

func proxyStepExtraHint(err error) string {
	if err == nil {
		return ""
	}
	if strings.Contains(err.Error(), "Bad Request") {
		return "代理返回 400 Bad Request：多为端口/协议错误，或该代理不支持 HTTPS CONNECT。"
	}
	return ""
}

func httpsConnectFailureHint(steps []ProxyTestStep, httpsStep ProxyTestStep) string {
	if len(steps) < 2 || !steps[0].OK || httpsStep.OK {
		return ""
	}
	if !strings.Contains(httpsStep.Error, "Bad Request") &&
		!strings.Contains(httpsStep.Summary, "Bad Request") {
		return ""
	}
	httpStep := steps[0]
	msg := "HTTP 经代理已通，但 HTTPS CONNECT 被拒绝：该代理只转发 HTTP，不支持 HTTPS 隧道。"
	if httpStep.HTTPStatus == 403 || httpStep.HTTPStatus == 407 {
		msg += fmt.Sprintf("（HTTP 步骤返回 %d，仅表示代理能连通，不代表可用于监控。）", httpStep.HTTPStatus)
	}
	msg += "免费 HTTP 代理列表（如 free-proxy-list）里绝大多数不支持 HTTPS CONNECT，无法用于检测 https:// 域名。"
	msg += "请改用本地 Clash/V2Ray 的 http-port（如 http://127.0.0.1:7890），或确认代理明确支持 CONNECT。"
	return msg
}

func validateHTTPProxyScheme(raw string) string {
	normalized, err := proxytransport.NormalizeProxyURL(raw)
	if err != nil {
		return err.Error()
	}
	if normalized == "" {
		return "请填写完整代理 URL"
	}
	return ""
}

func validateHTTPProxyURL(raw string) string {
	normalized, err := proxytransport.NormalizeProxyURL(raw)
	if err != nil {
		return err.Error()
	}
	u, err := url.Parse(normalized)
	if err != nil || u.Host == "" {
		return "代理地址无效，示例：http://127.0.0.1:7890 或 socks5://user:pass@host:port"
	}
	if proxytransport.IsSOCKS(u.Scheme) {
		return ""
	}
	if strings.ToLower(u.Scheme) == "https" && (u.Hostname() == "127.0.0.1" || u.Hostname() == "localhost") {
		return "本地代理一般应使用 http://127.0.0.1:端口，不要用 https://（除非代理软件明确提供 HTTPS 代理入口）。"
	}
	return ""
}

func proxyTestFetch(ctx context.Context, client *http.Client, target string) (int, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	if err != nil {
		return 0, err
	}
	req.Header.Set("User-Agent", "EnterpriseDomainMonitor-ProxyTest/1.0")
	resp, err := client.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	return resp.StatusCode, nil
}

func proxyTestFetchText(ctx context.Context, client *http.Client, target string) (string, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("User-Agent", "EnterpriseDomainMonitor-ProxyTest/1.0")
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 64))
	if err != nil {
		return "", err
	}
	if resp.StatusCode >= 400 {
		return "", fmtErr("ip check status %d", resp.StatusCode)
	}
	return strings.TrimSpace(string(body)), nil
}

func strField(m map[string]interface{}, key, fallback string) string {
	if v, ok := m[key].(string); ok && strings.TrimSpace(v) != "" {
		return v
	}
	return fallback
}

package callback

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"

	"enterprise-agent/backend/internal/ssrfguard"
)

const (
	maxResponseBodyLog = 4096
	defaultHTTPTimeout = 60 * time.Second
)

type Client struct {
	repo       *Repository
	crypto     *Crypto
	httpClient *http.Client
}

func NewClient(repo *Repository, crypto *Crypto) *Client {
	return &Client{
		repo:   repo,
		crypto: crypto,
		httpClient: &http.Client{
			Timeout: defaultHTTPTimeout,
		},
	}
}

type FetchRequest struct {
	Platform   *CallbackPlatform
	Endpoint   *ParsedEndpoint
	TaskID     *uuid.UUID
	DateFrom   time.Time
	DateTo     time.Time
	TokenPlain string
}

func (c *Client) FetchMembers(ctx context.Context, req FetchRequest) ([]MappedMember, error) {
	if req.Platform == nil || req.Endpoint == nil {
		return nil, fmt.Errorf("platform and endpoint are required")
	}
	if strings.TrimSpace(req.TokenPlain) == "" {
		return nil, fmt.Errorf("platform token is required")
	}

	p := req.Endpoint.Pagination
	if !p.Enabled {
		body, status, dur, err := c.doRequest(ctx, req, req.Endpoint.ParamsTemplate, 0, 0)
		c.writeLog(ctx, req, status, dur, req.Endpoint.ParamsTemplate, body, err)
		if err != nil {
			return nil, err
		}
		return c.parseMembers(body, req.Endpoint.Mapping)
	}

	pageSize := p.PageSize
	if pageSize <= 0 {
		pageSize = 99
	}
	startPage := p.StartPage
	if startPage <= 0 {
		startPage = 1
	}

	var all []MappedMember
	page := startPage
	for {
		params := cloneParams(req.Endpoint.ParamsTemplate)
		params = applyPaginationFields(params, p, page, pageSize)
		body, status, dur, err := c.doRequest(ctx, req, params, page, pageSize)
		c.writeLog(ctx, req, status, dur, params, body, err)
		if err != nil {
			return nil, err
		}
		members, err := c.parseMembers(body, req.Endpoint.Mapping)
		if err != nil {
			return nil, err
		}
		if len(members) == 0 && p.StopWhenEmpty {
			break
		}
		all = append(all, members...)
		if len(members) == 0 {
			break
		}
		page++
	}
	return dedupeMembers(all), nil
}

// ConnectionTestResult 平台连通性探测结果（不写任务、不拉全量）
type ConnectionTestResult struct {
	Success      bool   `json:"success"`
	StatusCode   int    `json:"statusCode"`
	DurationMs   int    `json:"durationMs"`
	Message      string `json:"message"`
	EndpointCode string `json:"endpointCode"`
	SampleCount  int    `json:"sampleCount"`
}

// TestConnection 探测平台与第三方接口连通性（仅首屏请求）
func (c *Client) TestConnection(ctx context.Context, req FetchRequest) (*ConnectionTestResult, error) {
	if req.Platform == nil || req.Endpoint == nil {
		return nil, fmt.Errorf("platform and endpoint are required")
	}
	if strings.TrimSpace(req.TokenPlain) == "" {
		return nil, fmt.Errorf("platform token is required")
	}

	code := req.Endpoint.Row.Code
	params := cloneParams(req.Endpoint.ParamsTemplate)
	page, pageSize := 1, 99
	p := req.Endpoint.Pagination
	if p.Enabled {
		if p.StartPage > 0 {
			page = p.StartPage
		}
		if p.PageSize > 0 {
			pageSize = p.PageSize
		}
		params = applyPaginationFields(params, p, page, pageSize)
	}

	body, status, dur, err := c.doRequest(ctx, req, params, page, pageSize)
	c.writeLog(ctx, req, status, dur, params, body, err)

	out := &ConnectionTestResult{
		Success:      err == nil && status >= 200 && status < 300,
		StatusCode:   status,
		DurationMs:   dur,
		EndpointCode: code,
	}
	if err != nil {
		out.Message = err.Error()
		return out, nil
	}
	out.Message = "connection ok"
	if members, parseErr := c.parseMembers(body, req.Endpoint.Mapping); parseErr == nil {
		out.SampleCount = len(members)
	}
	return out, nil
}

func enrichDateRangeParams(
	out map[string]interface{},
	template map[string]interface{},
	dateFrom, dateTo time.Time,
) {
	if dateFrom.IsZero() || dateTo.IsZero() {
		return
	}
	df := dateFrom.Format("2006-01-02")
	dt := dateTo.Format("2006-01-02")

	hasDatePlaceholder := false
	for k, v := range template {
		s, ok := v.(string)
		if !ok {
			continue
		}
		switch s {
		case "{{dateFrom}}":
			out[k] = df
			hasDatePlaceholder = true
		case "{{dateTo}}":
			out[k] = dt
			hasDatePlaceholder = true
		}
	}

	if hasDatePlaceholder {
		return
	}

	setParamIfAbsent(out, "dateFrom", df)
	setParamIfAbsent(out, "dateTo", dt)
	setParamIfAbsent(out, "startDate", df)
	setParamIfAbsent(out, "endDate", dt)
}

func setParamIfAbsent(params map[string]interface{}, key, value string) {
	if params == nil {
		return
	}
	if _, exists := params[key]; !exists {
		params[key] = value
	}
}

func (c *Client) doRequest(ctx context.Context, req FetchRequest, params map[string]interface{}, page, pageSize int) ([]byte, int, int, error) {
	fullURL, err := buildRequestURL(req.Platform.BaseURL, req.Endpoint.Row.Path, req.Endpoint.Row.HTTPMethod, params)
	if err != nil {
		return nil, 0, 0, err
	}
	if err := ssrfguard.ValidateOutboundURL(fullURL); err != nil {
		return nil, 0, 0, fmt.Errorf("blocked outbound url: %w", err)
	}

	vars := map[string]string{
		"tenantId": req.Platform.TenantID,
		"page":     strconv.Itoa(page),
		"pageSize": strconv.Itoa(pageSize),
		"dateFrom": req.DateFrom.Format("2006-01-02"),
		"dateTo":   req.DateTo.Format("2006-01-02"),
	}
	resolvedParams := replacePlaceholdersMap(params, vars)
	enrichDateRangeParams(resolvedParams, req.Endpoint.ParamsTemplate, req.DateFrom, req.DateTo)

	method := strings.ToUpper(strings.TrimSpace(req.Endpoint.Row.HTTPMethod))
	if method == "" {
		method = http.MethodGet
	}

	var httpReq *http.Request
	if method == http.MethodGet {
		u, err := url.Parse(fullURL)
		if err != nil {
			return nil, 0, 0, err
		}
		q := u.Query()
		for k, v := range resolvedParams {
			q.Set(k, fmt.Sprint(v))
		}
		u.RawQuery = q.Encode()
		httpReq, err = http.NewRequestWithContext(ctx, method, u.String(), nil)
		if err != nil {
			return nil, 0, 0, err
		}
		fullURL = u.String()
	} else {
		bodyBytes, err := json.Marshal(resolvedParams)
		if err != nil {
			return nil, 0, 0, err
		}
		httpReq, err = http.NewRequestWithContext(ctx, method, fullURL, bytes.NewReader(bodyBytes))
		if err != nil {
			return nil, 0, 0, err
		}
		httpReq.Header.Set("Content-Type", "application/json")
	}

	httpReq.Header.Set("Authorization", "Bearer "+req.TokenPlain)

	start := time.Now()
	resp, err := c.httpClient.Do(httpReq)
	durationMs := int(time.Since(start).Milliseconds())
	if err != nil {
		return nil, 0, durationMs, err
	}
	defer resp.Body.Close()

	body, readErr := io.ReadAll(io.LimitReader(resp.Body, 8<<20))
	if readErr != nil {
		return body, resp.StatusCode, durationMs, readErr
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return body, resp.StatusCode, durationMs, fmt.Errorf("HTTP %d: %s", resp.StatusCode, truncateString(string(body), 256))
	}
	return body, resp.StatusCode, durationMs, nil
}

func (c *Client) writeLog(ctx context.Context, req FetchRequest, status, durationMs int, params map[string]interface{}, body []byte, reqErr error) {
	paramsJSON, _ := json.Marshal(params)
	logRow := &CallbackRequestLog{
		PlatformID:    &req.Platform.ID,
		TaskID:        req.TaskID,
		EndpointCode:  req.Endpoint.Row.Code,
		RequestURL:    buildSafeLogURL(req.Platform.BaseURL, req.Endpoint.Row.Path),
		RequestParams: string(paramsJSON),
		DurationMs:    durationMs,
	}
	if status > 0 {
		logRow.ResponseStatus = &status
	}
	if len(body) > 0 {
		logRow.ResponseBody = truncateString(string(body), maxResponseBodyLog)
	}
	if reqErr != nil {
		logRow.ErrorMessage = reqErr.Error()
	}
	_ = c.repo.CreateRequestLog(ctx, logRow)
}

func buildSafeLogURL(baseURL, path string) string {
	base := strings.TrimRight(strings.TrimSpace(baseURL), "/")
	p := strings.TrimSpace(path)
	if p == "" {
		return base
	}
	if !strings.HasPrefix(p, "/") {
		p = "/" + p
	}
	return base + p
}

func buildRequestURL(baseURL, path, method string, _ map[string]interface{}) (string, error) {
	base := strings.TrimRight(strings.TrimSpace(baseURL), "/")
	p := strings.TrimSpace(path)
	if base == "" || p == "" {
		return "", fmt.Errorf("base_url and path are required")
	}
	if !strings.HasPrefix(p, "/") {
		p = "/" + p
	}
	return base + p, nil
}

func (c *Client) parseMembers(body []byte, mapping ResponseMapping) ([]MappedMember, error) {
	var root interface{}
	if err := json.Unmarshal(body, &root); err != nil {
		return nil, fmt.Errorf("invalid JSON response: %w", err)
	}
	listVal, ok := getByPath(root, mapping.ListPath)
	if !ok {
		return nil, fmt.Errorf("list path %q not found", mapping.ListPath)
	}
	items, ok := listVal.([]interface{})
	if !ok {
		return nil, fmt.Errorf("list path %q is not an array", mapping.ListPath)
	}
	out := make([]MappedMember, 0, len(items))
	for _, item := range items {
		member, err := mapResponseItem(item, mapping.Fields)
		if err != nil {
			continue
		}
		if member.UserID == 0 {
			continue
		}
		out = append(out, member)
	}
	return out, nil
}

func mapResponseItem(item interface{}, fields map[string]string) (MappedMember, error) {
	m := MappedMember{Raw: toRawMap(item)}
	for internalKey, jsonPath := range fields {
		val, ok := getByPath(item, jsonPath)
		if !ok {
			continue
		}
		switch internalKey {
		case InternalFieldUserID:
			m.UserID = toInt64(val)
		case InternalFieldPhoneNumber:
			m.PhoneNumber = toString(val)
		case InternalFieldVIPLevel:
			m.VIPLevel = int(toInt64(val))
		case InternalFieldHistoricalPay:
			m.HistoricalPay = toFloat64(val)
		case InternalFieldHistoryWithdrawals:
			m.HistoryWithdrawals = toFloat64(val)
		case InternalFieldHistoricalReward:
			m.HistoricalReward = toFloat64(val)
		}
	}
	return m, nil
}

func getByPath(data interface{}, path string) (interface{}, bool) {
	path = strings.TrimSpace(path)
	if path == "" {
		return nil, false
	}
	cur := data
	for _, part := range strings.Split(path, ".") {
		if part == "" {
			return nil, false
		}
		switch node := cur.(type) {
		case map[string]interface{}:
			next, ok := node[part]
			if !ok {
				return nil, false
			}
			cur = next
		case []interface{}:
			idx, err := strconv.Atoi(part)
			if err != nil || idx < 0 || idx >= len(node) {
				return nil, false
			}
			cur = node[idx]
		default:
			return nil, false
		}
	}
	return cur, true
}

func replacePlaceholdersMap(src map[string]interface{}, vars map[string]string) map[string]interface{} {
	out := make(map[string]interface{}, len(src))
	for k, v := range src {
		out[k] = replacePlaceholdersValue(v, vars)
	}
	return out
}

func replacePlaceholdersValue(v interface{}, vars map[string]string) interface{} {
	switch t := v.(type) {
	case string:
		s := t
		for key, val := range vars {
			s = strings.ReplaceAll(s, "{{"+key+"}}", val)
		}
		return s
	case map[string]interface{}:
		out := make(map[string]interface{}, len(t))
		for k, vv := range t {
			out[k] = replacePlaceholdersValue(vv, vars)
		}
		return out
	case []interface{}:
		out := make([]interface{}, len(t))
		for i, vv := range t {
			out[i] = replacePlaceholdersValue(vv, vars)
		}
		return out
	default:
		return v
	}
}

func applyPaginationFields(params map[string]interface{}, p PaginationConfig, page, pageSize int) map[string]interface{} {
	out := cloneParams(params)
	if p.PageField != "" {
		out[p.PageField] = page
	}
	if p.PageSizeField != "" {
		out[p.PageSizeField] = pageSize
	}
	return out
}

func cloneParams(src map[string]interface{}) map[string]interface{} {
	if src == nil {
		return map[string]interface{}{}
	}
	b, _ := json.Marshal(src)
	var out map[string]interface{}
	_ = json.Unmarshal(b, &out)
	if out == nil {
		out = map[string]interface{}{}
	}
	return out
}

func dedupeMembers(items []MappedMember) []MappedMember {
	seen := make(map[int64]MappedMember, len(items))
	for _, m := range items {
		seen[m.UserID] = m
	}
	out := make([]MappedMember, 0, len(seen))
	for _, m := range seen {
		out = append(out, m)
	}
	return out
}

func toRawMap(v interface{}) map[string]interface{} {
	if m, ok := v.(map[string]interface{}); ok {
		return m
	}
	return map[string]interface{}{}
}

func toString(v interface{}) string {
	switch t := v.(type) {
	case string:
		return t
	case float64:
		return strconv.FormatInt(int64(t), 10)
	case json.Number:
		return t.String()
	default:
		return fmt.Sprint(v)
	}
}

func toInt64(v interface{}) int64 {
	switch t := v.(type) {
	case float64:
		return int64(t)
	case int:
		return int64(t)
	case int64:
		return t
	case json.Number:
		n, _ := t.Int64()
		return n
	case string:
		n, _ := strconv.ParseInt(strings.TrimSpace(t), 10, 64)
		return n
	default:
		return 0
	}
}

func toFloat64(v interface{}) float64 {
	switch t := v.(type) {
	case float64:
		return t
	case int:
		return float64(t)
	case int64:
		return float64(t)
	case json.Number:
		f, _ := t.Float64()
		return f
	case string:
		f, _ := strconv.ParseFloat(strings.TrimSpace(t), 64)
		return f
	default:
		return 0
	}
}

func truncateString(s string, max int) string {
	if len(s) <= max {
		return s
	}
	return s[:max]
}

package tgbot

import "strings"

// tgAlertPrefix adds a warning icon to user-facing alert text when missing.
func tgAlertPrefix(text string) string {
	text = strings.TrimSpace(text)
	if text == "" {
		return "⚠️ 操作失败"
	}
	for _, p := range []string{"⚠️", "⚠", "❌", "🚨", "✅", "👍", "😅", "🏃", "⏰"} {
		if strings.HasPrefix(text, p) {
			return text
		}
	}
	if strings.Contains(text, "失败") {
		return "❌ " + text
	}
	return "⚠️ " + text
}

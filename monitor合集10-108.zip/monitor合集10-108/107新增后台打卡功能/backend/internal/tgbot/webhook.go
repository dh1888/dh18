package tgbot

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"time"
)

func (cfg config) useWebhook() bool {
	return strings.ToLower(strings.TrimSpace(cfg.BotMode)) == "webhook" && strings.TrimSpace(cfg.WebhookURL) != ""
}

func runPollingCtx(ctx context.Context, cfg config) error {
	if err := deleteWebhook(cfg); err != nil {
		log.Printf("delete webhook: %v", err)
	}
	offset := int64(0)
	lastRefresh := time.Now()
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}
		if time.Since(lastRefresh) > 5*time.Minute {
			refreshRuntimeConfig(&cfg, "")
			setActiveConfig(cfg)
			lastRefresh = time.Now()
		}
		updates, err := pollUpdates(cfg, offset)
		if err != nil {
			log.Printf("poll error: %v", err)
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(3 * time.Second):
			}
			continue
		}
		for _, u := range updates {
			if u.UpdateID >= offset {
				offset = u.UpdateID + 1
			}
			ProcessUpdate(cfg, u)
		}
	}
}

func runEmbeddedWebhook(ctx context.Context, cfg config) error {
	if err := setWebhook(cfg); err != nil {
		return err
	}
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
			refreshRuntimeConfig(&cfg, "")
			setActiveConfig(cfg)
		}
	}
}

func runPolling(cfg config) {
	_ = runPollingCtx(context.Background(), cfg)
}

func runWebhook(cfg config) {
	if err := setWebhook(cfg); err != nil {
		log.Fatalf("set webhook: %v", err)
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	path := cfg.WebhookPath
	if path == "" {
		path = "/telegram/webhook"
	}
	mux.HandleFunc(path, func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.NotFound(w, r)
			return
		}
		if secret := strings.TrimSpace(cfg.WebhookSecret); secret != "" {
			if r.Header.Get("X-Telegram-Bot-Api-Secret-Token") != secret {
				http.Error(w, "forbidden", http.StatusForbidden)
				return
			}
		}
		body, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "bad request", http.StatusBadRequest)
			return
		}
		var update tgUpdate
		if err := json.Unmarshal(body, &update); err != nil {
			http.Error(w, "bad request", http.StatusBadRequest)
			return
		}
		go ProcessUpdate(cfg, update)
		w.WriteHeader(http.StatusOK)
	})
	go func() {
		localCfg := cfg
		for {
			time.Sleep(5 * time.Minute)
			refreshRuntimeConfig(&localCfg, "")
		}
	}()
	addr := cfg.WebhookListen
	if addr == "" {
		addr = ":8081"
	}
	log.Printf("telegram-worker webhook mode listening on %s%s (public URL=%s)", addr, path, cfg.WebhookURL)
	log.Fatal(http.ListenAndServe(addr, mux))
}

// ProcessUpdate handles a single Telegram update.
func ProcessUpdate(cfg config, u tgUpdate) {
	if u.MyChatMember != nil {
		handleMyChatMember(cfg, u)
		return
	}
	if u.CallbackQuery != nil {
		handleCallback(cfg, u)
		return
	}
	if u.ChannelPost != nil {
		handleChannelPost(cfg, u)
		return
	}
	if u.Message == nil {
		return
	}
	if text := strings.TrimSpace(u.Message.Text); text != "" {
		log.Printf("[tgbot] update=%d chat=%d user=%d text=%q", u.UpdateID, u.Message.Chat.ID, u.Message.From.ID, text)
	}
	handleMessage(cfg, u)
}

func deleteWebhook(cfg config) error {
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/deleteWebhook?drop_pending_updates=true", cfg.BotToken)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader([]byte("{}")))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
	}
	if err := json.Unmarshal(body, &parsed); err != nil {
		return err
	}
	if !parsed.OK {
		if parsed.Description != "" {
			return fmt.Errorf(parsed.Description)
		}
		return fmt.Errorf("deleteWebhook failed")
	}
	return nil
}

func setWebhook(cfg config) error {
	payload := map[string]interface{}{
		"url":              strings.TrimSpace(cfg.WebhookURL),
		"allowed_updates":  []string{"message", "callback_query", "my_chat_member"},
		"drop_pending_updates": true,
	}
	if secret := strings.TrimSpace(cfg.WebhookSecret); secret != "" {
		payload["secret_token"] = secret
	}
	body, _ := json.Marshal(payload)
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/setWebhook", cfg.BotToken)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader(body))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
	}
	if err := json.Unmarshal(raw, &parsed); err != nil {
		return err
	}
	if !parsed.OK {
		if parsed.Description != "" {
			return fmt.Errorf(parsed.Description)
		}
		return fmt.Errorf("setWebhook failed: %s", string(raw))
	}
	log.Printf("webhook registered: %s", cfg.WebhookURL)
	return nil
}

// HandleWebhookBody validates optional secret and processes a webhook payload.
func HandleWebhookBody(cfg config, secretHeader string, body []byte) error {
	if secret := strings.TrimSpace(cfg.WebhookSecret); secret != "" && secretHeader != secret {
		return fmt.Errorf("forbidden")
	}
	var update tgUpdate
	if err := json.Unmarshal(body, &update); err != nil {
		return err
	}
	go ProcessUpdate(cfg, update)
	return nil
}

package tgbot

import (
	"fmt"
	"strings"
)

func currentLangMode() string {
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	if cachedLangMode == "" {
		return "both"
	}
	return cachedLangMode
}

// Built-in labels so button presses still work before /config is loaded.
var builtinButtonLookup = map[string]string{
	"上班": "checkin", "Đi làm": "checkin", "上班 / Đi làm": "checkin",
	"下班": "work_end", "Tan ca": "work_end", "下班 / Tan ca": "work_end", "🔴 下班": "work_end",
	"白班上班": "work_start_day", "Ca ngày Đi làm": "work_start_day",
	"夜班上班": "work_start_night", "Ca đêm Đi làm": "work_start_night",
	"回座": "back", "Trở lại chỗ ngồi": "back", "✅ 回座": "back",
	"我的记录": "my_record", "Lịch sử của tôi": "my_record", "我的信息": "my_record",
	"排行榜": "rank", "Bảng xếp hạng": "rank", "排名": "rank",
	"状态": "status", "Trạng thái": "status",
	"交接班": "handover", "Giao ca": "handover", "换班": "handover",
	"帮助": "help", "Trợ giúp": "help",
	"chatid": "chatid",
	"导出数据": "export_data", "Xuất dữ liệu": "export_data",
	"🚽 小厕": "小厕", "🚾 大厕": "大厕", "🍱 吃饭": "吃饭", "🚬 抽烟": "抽烟", "🚬 抽烟或休息": "抽烟或休息",
}

func resolveButton(text string) string {
	text = strings.TrimSpace(text)
	if text == "" {
		return ""
	}
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	if canonical, ok := cachedButtonLookup[text]; ok {
		return canonical
	}
	if canonical, ok := builtinButtonLookup[text]; ok {
		return canonical
	}
	return text
}

func resolveActivityName(text string) string {
	canonical := resolveButton(text)
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	for _, name := range cachedActivities {
		if canonical == name {
			return name
		}
	}
	return ""
}

func isActivityInput(text string) bool {
	return resolveActivityName(text) != ""
}

func tRateLimited() string {
	switch currentLangMode() {
	case "vi":
		return "Thao tác quá nhanh, vui lòng thử lại sau."
	case "zh":
		return "操作过于频繁，请稍后再试。"
	default:
		return "操作过于频繁，请稍后再试。 / Thao tác quá nhanh, vui lòng thử lại sau."
	}
}

func helpText() string {
	activitiesMu.RLock()
	acts := strings.Join(cachedActivities, "、")
	mode := cachedLangMode
	activitiesMu.RUnlock()
	if mode == "" {
		mode = "both"
	}
	switch mode {
	case "vi":
		return fmt.Sprintf(`Bot chấm công Telegram

Ca ngày / Ca đêm (chế độ hai ca)
Đi làm: gửi nút tương ứng
Tan ca: gửi nút Tan ca
Hoạt động: gửi tên hoạt động (%s)
Trở lại: gửi nút Trở lại chỗ ngồi
Giao ca: gửi Giao ca
Trạng thái / Lịch sử / Bảng xếp hạng: dùng nút bàn phím`, acts)
	case "zh":
		return fmt.Sprintf(`Telegram 考勤 Bot

绑定个人 TG（无需客户端）：/bind 邀请码 账号
绑定工位共用 TG：/bind_workstation 邀请码（打卡需 PC 登录）
客户端：登录后托盘「绑定 Telegram」获取链接
群内键盘按钮无反应：请在 @BotFather 对该 Bot 执行 /setprivacy → Disable
或在群内使用命令：/checkin /checkout
白班上班 / 夜班上班（双班模式）
上班：发送「上班」或 /checkin
下班：发送「下班」或 /checkout
活动：发送活动名称开始（%s）
结束活动：发送「回座」或 /at
交接班：发送「交接班」
状态 / 我的记录 / 排行榜：使用键盘按钮
查询本群/频道 ID：/chatid（或 /groupid、/channelid）`, acts)
	default:
		return fmt.Sprintf(`Telegram 考勤 Bot / Bot chấm công

绑定个人 /bind 邀请码 账号 | 工位 /bind_workstation 邀请码
白班上班 / 夜班上班 | Ca ngày / Ca đêm
上班 / 下班 | Đi làm / Tan ca
活动 (%s) | Hoạt động
回座 / 状态 / 我的记录 / 排行榜
Trở lại / Trạng thái / Lịch sử / Bảng xếp hạng
/chatid 查询群或频道 ID`, acts)
	}
}

func tGroupWelcome(chatType, title string, chatID int64) string {
	name := title
	if name == "" {
		name = "本群"
	}
	mode := currentLangMode()
	if chatType == "channel" {
		switch mode {
		case "vi":
			return fmt.Sprintf("🤖 Bot đã tham gia kênh\n\n📢 %s\n🆔 ID: %d\n\nThêm ID này trong trang quản trị monitorWin.", name, chatID)
		case "zh":
			return fmt.Sprintf("🤖 机器人已加入频道\n\n📢 %s\n🆔 频道 ID：%d\n\n请在后台「Telegram 考勤 → 推送配置」绑定此 ID。", name, chatID)
		default:
			return fmt.Sprintf("🤖 机器人已加入频道 / Bot đã tham gia kênh\n\n📢 %s\n🆔 ID：%d\n\n后台绑定此 ID。", name, chatID)
		}
	}
	switch mode {
	case "vi":
		return fmt.Sprintf("🤖 Bot đã tham gia nhóm\n\n💬 %s\n🆔 ID: %d\n\nThêm Chat ID trong trang quản trị hoặc gửi /chatid.", name, chatID)
	case "zh":
		return fmt.Sprintf("🤖 机器人已加入群组\n\n💬 %s\n🆔 群组 ID：%d\n\n请在后台「群组绑定」添加此 Chat ID；也可发送 /chatid 查看。", name, chatID)
	default:
		return fmt.Sprintf("🤖 机器人已加入群组 / Bot đã tham gia nhóm\n\n💬 %s\n🆔 ID：%d\n\n后台「群组绑定」或 /chatid", name, chatID)
	}
}

func tChatIDHint(chatType, title string, chatID int64) string {
	name := title
	if name == "" {
		name = fmt.Sprintf("%d", chatID)
	}
	mode := currentLangMode()
	switch mode {
	case "vi":
		return fmt.Sprintf("📋 %s\n🆔 %s: %d", name, chatIDLabel(chatType), chatID)
	case "zh":
		return fmt.Sprintf("📋 %s\n🆔 %s：%d", name, chatIDLabel(chatType), chatID)
	default:
		return fmt.Sprintf("📋 %s\n🆔 %s：%d", name, chatIDLabel(chatType), chatID)
	}
}

func chatIDLabel(chatType string) string {
	mode := currentLangMode()
	if chatType == "channel" {
		switch mode {
		case "vi":
			return "ID kênh"
		case "zh":
			return "频道 ID"
		default:
			return "频道 ID / ID kênh"
		}
	}
	switch mode {
	case "vi":
		return "Chat ID"
	case "zh":
		return "群组 ID"
	default:
		return "群组 ID / Chat ID"
	}
}

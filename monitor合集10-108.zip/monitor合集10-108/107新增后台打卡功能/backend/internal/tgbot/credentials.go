package tgbot

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const workerCredentialsFile = ".worker-credentials.json"

type workerCredentials struct {
	WorkerSecret string `json:"workerSecret"`
	BackendURL   string `json:"backendUrl"`
}

func loadWorkerCredentials() *workerCredentials {
	raw, err := os.ReadFile(workerCredentialsFile)
	if err != nil {
		return nil
	}
	var creds workerCredentials
	if err := json.Unmarshal(raw, &creds); err != nil {
		return nil
	}
	creds.WorkerSecret = strings.TrimSpace(creds.WorkerSecret)
	creds.BackendURL = strings.TrimRight(strings.TrimSpace(creds.BackendURL), "/")
	if creds.WorkerSecret == "" || creds.BackendURL == "" {
		return nil
	}
	return &creds
}

func saveWorkerCredentials(creds workerCredentials) error {
	creds.BackendURL = strings.TrimRight(strings.TrimSpace(creds.BackendURL), "/")
	creds.WorkerSecret = strings.TrimSpace(creds.WorkerSecret)
	body, err := json.MarshalIndent(creds, "", "  ")
	if err != nil {
		return err
	}
	dir := filepath.Dir(workerCredentialsFile)
	if dir != "." && dir != "" {
		if err := os.MkdirAll(dir, 0o755); err != nil {
			return err
		}
	}
	return os.WriteFile(workerCredentialsFile, body, 0o600)
}

func pairWorker(cfg *config, pairingCode string) error {
	payload := map[string]string{"pairingCode": strings.TrimSpace(pairingCode)}
	body, _ := json.Marshal(payload)
	resp, err := http.Post(cfg.BackendURL+"/telegram/worker/pair", "application/json", bytes.NewReader(body))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var result struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
		Data    struct {
			WorkerSecret string `json:"workerSecret"`
			BotToken     string `json:"botToken"`
		} `json:"data"`
	}
	if err := json.Unmarshal(raw, &result); err != nil {
		return fmt.Errorf("pair failed: %s", string(raw))
	}
	if result.Code != 0 || strings.TrimSpace(result.Data.WorkerSecret) == "" {
		if result.Message != "" {
			return fmt.Errorf("%s", result.Message)
		}
		return fmt.Errorf("pair failed: %s", string(raw))
	}
	cfg.WorkerSecret = strings.TrimSpace(result.Data.WorkerSecret)
	if token := strings.TrimSpace(result.Data.BotToken); token != "" {
		cfg.BotToken = token
	}
	return saveWorkerCredentials(workerCredentials{
		WorkerSecret: cfg.WorkerSecret,
		BackendURL:   cfg.BackendURL,
	})
}

func startWorkerHeartbeat(cfg config) {
	sendHeartbeat := func() {
		var result apiResult
		_ = backendPost(cfg, "/telegram/worker/heartbeat", map[string]interface{}{}, &result)
	}
	sendHeartbeat()
	go func() {
		ticker := time.NewTicker(60 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			sendHeartbeat()
		}
	}()
}

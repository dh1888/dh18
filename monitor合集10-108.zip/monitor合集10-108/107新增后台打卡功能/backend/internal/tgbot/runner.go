// Telegram 考勤 Bot：长轮询 Telegram，调用 monitorWin 后端 API。
package tgbot

import (
	"bytes"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type config struct {
	BotToken       string
	BackendURL     string
	WorkerSecret   string
	PollTimeout    int
	BotMode        string
	WebhookURL     string
	WebhookSecret  string
	WebhookPath    string
	WebhookListen  string
}

type tgMessage struct {
	MessageID int64 `json:"message_id"`
	Chat      struct {
		ID    int64  `json:"id"`
		Type  string `json:"type"`
		Title string `json:"title"`
	} `json:"chat"`
	From struct {
		ID        int64  `json:"id"`
		Username  string `json:"username"`
		FirstName string `json:"first_name"`
	} `json:"from"`
	Text string `json:"text"`
}

type tgCallbackQuery struct {
	ID   string `json:"id"`
	From struct {
		ID int64 `json:"id"`
	} `json:"from"`
	Message *tgMessage `json:"message"`
	Data    string     `json:"data"`
}

type tgUpdate struct {
	UpdateID      int64            `json:"update_id"`
	CallbackQuery *tgCallbackQuery `json:"callback_query"`
	MyChatMember *struct {
		Chat struct {
			ID    int64  `json:"id"`
			Type  string `json:"type"`
			Title string `json:"title"`
		} `json:"chat"`
		OldChatMember struct {
			Status string `json:"status"`
		} `json:"old_chat_member"`
		NewChatMember struct {
			Status string `json:"status"`
			User   struct {
				IsBot bool `json:"is_bot"`
			} `json:"user"`
		} `json:"new_chat_member"`
	} `json:"my_chat_member"`
	Message     *tgMessage `json:"message"`
	ChannelPost *tgMessage `json:"channel_post"`
}

type workerActivity struct {
	Code string `json:"code"`
	Name string `json:"name"`
}

var (
	cachedActivities     = []string{"小厕", "大厕", "抽烟", "吃饭"}
	cachedReplyKeyboard  map[string]interface{}
	cachedButtonLookup   = map[string]string{}
	cachedLangMode       = "both"
	activitiesMu         sync.RWMutex
	rateMu               sync.Mutex
	userRateCalls        = map[int64][]time.Time{}
)

const (
	userRateLimitCount = 10
	userRateLimitWindow = time.Minute
)

func allowUserRate(userID int64) bool {
	rateMu.Lock()
	defer rateMu.Unlock()
	now := time.Now()
	cutoff := now.Add(-userRateLimitWindow)
	calls := userRateCalls[userID]
	filtered := calls[:0]
	for _, t := range calls {
		if t.After(cutoff) {
			filtered = append(filtered, t)
		}
	}
	if len(filtered) >= userRateLimitCount {
		userRateCalls[userID] = filtered
		return false
	}
	userRateCalls[userID] = append(filtered, now)
	return true
}

func refreshRuntimeConfig(cfg *config, chatID string) {
	path := "/telegram/worker/config"
	if chatID = strings.TrimSpace(chatID); chatID != "" {
		path += "?chatId=" + url.QueryEscape(chatID)
	}
	var result struct {
		Code int `json:"code"`
		Data struct {
			BotMode              string                   `json:"botMode"`
			BotToken             string                   `json:"botToken"`
			WebhookURL           string                   `json:"webhookUrl"`
			WebhookSecret        string                   `json:"webhookSecret"`
			WebhookPath          string                   `json:"webhookPath"`
			LangMode             string                   `json:"langMode"`
			ButtonLookup         map[string]string        `json:"buttonLookup"`
			BotCommands          []map[string]interface{} `json:"botCommands"`
			AdminTelegramUserIds string                   `json:"adminTelegramUserIds"`
			Activities           []workerActivity         `json:"activities"`
			ReplyKeyboard        map[string]interface{}   `json:"replyKeyboard"`
		} `json:"data"`
	}
	if err := backendGet(*cfg, path, &result); err != nil || result.Code != 0 {
		return
	}
	names := make([]string, 0, len(result.Data.Activities))
	for _, a := range result.Data.Activities {
		if strings.TrimSpace(a.Name) != "" {
			names = append(names, a.Name)
		}
	}
	activitiesMu.Lock()
	if len(names) > 0 {
		cachedActivities = names
	}
	if result.Data.ReplyKeyboard != nil {
		cachedReplyKeyboard = result.Data.ReplyKeyboard
	}
	if len(result.Data.ButtonLookup) > 0 {
		cachedButtonLookup = result.Data.ButtonLookup
	}
	if strings.TrimSpace(result.Data.LangMode) != "" {
		cachedLangMode = strings.TrimSpace(result.Data.LangMode)
	}
	parseAdminIDs(result.Data.AdminTelegramUserIds)
	if len(result.Data.BotCommands) > 0 {
		syncBotCommands(*cfg, result.Data.BotCommands)
	}
	if token := strings.TrimSpace(result.Data.BotToken); token != "" {
		cfg.BotToken = token
	}
	activitiesMu.Unlock()
	if v := strings.TrimSpace(os.Getenv("TELEGRAM_BOT_MODE")); v != "" {
		cfg.BotMode = v
	} else if m := strings.TrimSpace(result.Data.BotMode); m != "" {
		cfg.BotMode = m
	}
	if v := strings.TrimSpace(os.Getenv("TELEGRAM_WEBHOOK_URL")); v != "" {
		cfg.WebhookURL = v
	} else if u := strings.TrimSpace(result.Data.WebhookURL); u != "" {
		cfg.WebhookURL = u
	}
	if v := strings.TrimSpace(os.Getenv("TELEGRAM_WEBHOOK_SECRET")); v != "" {
		cfg.WebhookSecret = v
	} else if s := strings.TrimSpace(result.Data.WebhookSecret); s != "" {
		cfg.WebhookSecret = s
	}
	if p := strings.TrimSpace(result.Data.WebhookPath); p != "" {
		cfg.WebhookPath = p
	}
}

func refreshActivities(cfg config) {
	refreshRuntimeConfig(&cfg, "")
}

func recordChatSeen(cfg config, chatID int64, chatType, title string) bool {
	chatType = strings.TrimSpace(chatType)
	if chatType != "group" && chatType != "supergroup" && chatType != "channel" {
		return false
	}
	var result apiResult
	err := backendPost(cfg, "/telegram/worker/chat/seen", map[string]interface{}{
		"chatId":    strconv.FormatInt(chatID, 10),
		"chatTitle": title,
		"chatType":  chatType,
	}, &result)
	if err != nil || result.Code != 0 {
		return false
	}
	if v, ok := result.Data["firstSeen"].(bool); ok {
		return v
	}
	return false
}

func pollUpdates(cfg config, offset int64) ([]tgUpdate, error) {
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/getUpdates?timeout=%d&offset=%d&allowed_updates=%s",
		cfg.BotToken, cfg.PollTimeout, offset, url.QueryEscape(`["message","callback_query","my_chat_member","channel_post"]`))
	resp, err := http.Get(apiURL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK     bool       `json:"ok"`
		Result []tgUpdate `json:"result"`
	}
	if err := json.Unmarshal(body, &parsed); err != nil {
		return nil, err
	}
	if !parsed.OK {
		return nil, fmt.Errorf("getUpdates failed: %s", string(body))
	}
	return parsed.Result, nil
}

func handleCallback(cfg config, u tgUpdate) {
	cb := u.CallbackQuery
	if cb == nil {
		return
	}
	data := strings.TrimSpace(cb.Data)
	if strings.HasPrefix(data, "rv:") {
		handleAttendanceReviewCallback(cfg, cb, data)
		return
	}
	if !strings.HasPrefix(data, "qb:") {
		return
	}
	sessionID := strings.TrimPrefix(data, "qb:")
	userID := cb.From.ID
	var result apiResult
	result.Data = map[string]interface{}{}
	err := backendPost(cfg, "/telegram/worker/activity/callback-back", map[string]interface{}{
		"sessionId":      sessionID,
		"telegramUserId": userID,
	}, &result)
	chatID := strconv.FormatInt(userID, 10)
	replyTo := int64(0)
	if cb.Message != nil {
		chatID = strconv.FormatInt(cb.Message.Chat.ID, 10)
		replyTo = cb.Message.MessageID
	}
	if err == nil && result.Code == 0 {
		if groupReplySent(result.Data) {
			answerCallback(cfg, cb.ID, "")
			return
		}
		if groupHTML, ok := result.Data["groupReplyHtml"].(string); ok && strings.TrimSpace(groupHTML) != "" {
			replyWorkHTMLInChat(cfg, chatID, groupHTML, activityAnchorReplyTo(result.Data, replyTo))
			answerCallback(cfg, cb.ID, "")
			return
		}
		text := "回座完成"
		if msg, ok := result.Data["messageText"].(string); ok && msg != "" {
			text = msg
		}
		replyWorkHTMLError(cfg, chatID, text, replyTo)
	} else {
		text := "回座失败"
		if err != nil {
			text = err.Error()
		} else if result.Message != "" {
			text = result.Message
		}
		if result.Code == 1006 {
			answerCallbackAlert(cfg, cb.ID, text)
			return
		}
		replyWorkHTMLError(cfg, chatID, text, replyTo)
	}
	answerCallback(cfg, cb.ID, "")
}

func handleAttendanceReviewCallback(cfg config, cb *tgCallbackQuery, data string) {
	parts := strings.Split(data, ":")
	if len(parts) != 3 {
		answerCallbackAlert(cfg, cb.ID, "无效操作")
		return
	}
	taskID := strings.TrimSpace(parts[1])
	choice := strings.TrimSpace(parts[2])
	decision := ""
	switch choice {
	case "abs":
		decision = "absent"
	case "rest":
		decision = "rest_half"
	case "leave":
		decision = "leave"
	default:
		answerCallbackAlert(cfg, cb.ID, "无效操作")
		return
	}
	var result apiResult
	result.Data = map[string]interface{}{}
	err := backendPost(cfg, "/telegram/worker/attendance-review/callback", map[string]interface{}{
		"taskId":         taskID,
		"decision":       decision,
		"telegramUserId": cb.From.ID,
	}, &result)
	if err != nil {
		answerCallbackAlert(cfg, cb.ID, err.Error())
		return
	}
	if result.Code != 0 {
		text := result.Message
		if strings.TrimSpace(text) == "" {
			text = "处理失败"
		}
		if result.Code == 1003 {
			answerCallbackAlert(cfg, cb.ID, text)
			return
		}
		answerCallback(cfg, cb.ID, text)
		return
	}
	text := "已确认"
	if m, ok := result.Data["messageText"].(string); ok && strings.TrimSpace(m) != "" {
		text = m
	}
	answerCallback(cfg, cb.ID, text)
}

func currentReplyKeyboard() map[string]interface{} {
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	return cachedReplyKeyboard
}

func replyKeyboardForChat(cfg config, chatID string) map[string]interface{} {
	if kb := currentReplyKeyboard(); kb != nil {
		return kb
	}
	refreshRuntimeConfig(&cfg, chatID)
	return currentReplyKeyboard()
}

func answerCallback(cfg config, callbackID, text string) {
	answerCallbackQuery(cfg, callbackID, text, false)
}

func answerCallbackAlert(cfg config, callbackID, text string) {
	answerCallbackQuery(cfg, callbackID, text, true)
}

func answerCallbackQuery(cfg config, callbackID, text string, showAlert bool) {
	payload := map[string]interface{}{"callback_query_id": callbackID}
	if text != "" {
		payload["text"] = text
	}
	if showAlert {
		payload["show_alert"] = true
	}
	body, _ := json.Marshal(payload)
	url := fmt.Sprintf("https://api.telegram.org/bot%s/answerCallbackQuery", cfg.BotToken)
	resp, err := http.Post(url, "application/json", bytes.NewReader(body))
	if err == nil {
		resp.Body.Close()
	}
}

func handleChannelPost(cfg config, u tgUpdate) {
	msg := u.ChannelPost
	if msg == nil || isDuplicateUpdate(u.UpdateID) {
		return
	}
	recordChatSeen(cfg, msg.Chat.ID, msg.Chat.Type, msg.Chat.Title)
	text := strings.TrimSpace(msg.Text)
	if text == "" || !strings.HasPrefix(text, "/") {
		return
	}
	if handleChatIDSlash(cfg, msg) {
		return
	}
}

func handleChatIDSlash(cfg config, msg *tgMessage) bool {
	if msg == nil {
		return false
	}
	text := strings.TrimSpace(msg.Text)
	if !strings.HasPrefix(text, "/") {
		return false
	}
	parts := strings.Fields(text)
	cmd := strings.TrimPrefix(strings.ToLower(parts[0]), "/")
	if i := strings.Index(cmd, "@"); i > 0 {
		cmd = cmd[:i]
	}
	if !isChatIDCommand(cmd) {
		return false
	}
	replyChatID(cfg, msg.Chat.ID, msg.Chat.Type, msg.Chat.Title, msg.MessageID)
	return true
}

func isChatIDCommand(cmd string) bool {
	switch cmd {
	case "chatid", "groupid", "channelid", "id", "群id", "频道id":
		return true
	default:
		return false
	}
}

func handleMessage(cfg config, u tgUpdate) {
	msg := u.Message
	if isDuplicateUpdate(u.UpdateID) {
		return
	}
	if msg.From.ID == 0 {
		return
	}
	chatID := strconv.FormatInt(msg.Chat.ID, 10)
	activitiesMu.RLock()
	lookupEmpty := len(cachedButtonLookup) == 0
	activitiesMu.RUnlock()
	if lookupEmpty {
		refreshRuntimeConfig(&cfg, chatID)
	}
	recordChatSeen(cfg, msg.Chat.ID, msg.Chat.Type, msg.Chat.Title)
	text := strings.TrimSpace(msg.Text)
	userID := msg.From.ID

	if strings.HasPrefix(text, "/") {
		if handleSlashCommand(cfg, msg) {
			return
		}
	}

	if !allowUserRate(userID) {
		_ = sendTelegramByUser(cfg, userID, tRateLimited())
		return
	}

	action := resolveButton(text)
	switch action {
	case "chatid":
		replyChatID(cfg, msg.Chat.ID, msg.Chat.Type, msg.Chat.Title, msg.MessageID)
	case "work_start_day":
		replyCheckIn(cfg, userID, chatID, "day", msg.MessageID)
	case "work_start_night":
		replyCheckIn(cfg, userID, chatID, "night", msg.MessageID)
	case "checkin":
		replyCheckIn(cfg, userID, chatID, "", msg.MessageID)
	case "work_end":
		replyCheckOut(cfg, userID, chatID, msg.MessageID)
	case "status":
		replyStatus(cfg, userID)
	case "my_record":
		replyMyInfo(cfg, userID, chatID, "", msg.MessageID)
	case "my_record_day":
		replyMyInfo(cfg, userID, chatID, "day", msg.MessageID)
	case "my_record_night":
		replyMyInfo(cfg, userID, chatID, "night", msg.MessageID)
	case "rank":
		replyRankings(cfg, userID, chatID, "", msg.MessageID)
	case "rank_day":
		replyRankings(cfg, userID, chatID, "day", msg.MessageID)
	case "rank_night":
		replyRankings(cfg, userID, chatID, "night", msg.MessageID)
	case "export_data":
		exportMsg := *msg
		exportMsg.Text = "/export"
		handleSlashCommand(cfg, &exportMsg)
	case "handover":
		replyHandover(cfg, userID, "")
	case "back":
		replyEndActivity(cfg, userID, chatID, msg.MessageID)
	case "help":
		_ = sendTelegramWithMarkup(cfg, msg.Chat.ID, helpText(), currentReplyKeyboard())
	default:
		if strings.HasPrefix(text, "交接班 ") {
			replyHandover(cfg, userID, strings.TrimSpace(strings.TrimPrefix(text, "交接班")))
			return
		}
		if strings.HasPrefix(text, "绑定工位 ") || strings.HasPrefix(text, "绑定工位") {
			code := strings.TrimSpace(strings.TrimPrefix(strings.TrimPrefix(text, "绑定工位 "), "绑定工位"))
			if code != "" {
				replyBindWorkstation(cfg, userID, msg.From.Username, chatID, code, msg.Chat.ID, msg.MessageID)
				return
			}
		}
		if strings.HasPrefix(text, "绑定 ") || strings.HasPrefix(text, "绑定") {
			code := strings.TrimSpace(strings.TrimPrefix(strings.TrimPrefix(text, "绑定 "), "绑定"))
			if code != "" {
				replyBind(cfg, userID, msg.From.Username, chatID, code, msg.Chat.ID, msg.MessageID)
				return
			}
		}
		if looksLikeInviteCode(text) {
			replyBind(cfg, userID, msg.From.Username, chatID, text, msg.Chat.ID, msg.MessageID)
			return
		}
		if act := resolveActivityName(text); act != "" {
			replyStartActivity(cfg, userID, chatID, act, msg.MessageID)
			return
		}
		if strings.HasPrefix(text, "/") {
			return
		}
		if text != "" && (msg.Chat.Type == "group" || msg.Chat.Type == "supergroup") {
			_ = sendTelegramHTMLReply(cfg, msg.Chat.ID,
				"未识别操作。群内键盘无反应时请在 @BotFather 关闭 Privacy Mode，或使用 /checkin /checkout /bind 邀请码",
				msg.MessageID, replyKeyboardForChat(cfg, chatID))
		}
	}
}

func replyInUserAndGroup(cfg config, userID int64, chatIDStr, userMsg, groupMsg string, replyTo int64) {
	_ = sendTelegramByUser(cfg, userID, userMsg)
	if groupChatID, err := strconv.ParseInt(chatIDStr, 10, 64); err == nil && groupChatID != userID {
		msg := groupMsg
		if msg == "" {
			msg = userMsg
		}
		_ = sendTelegramChatReply(cfg, groupChatID, msg, replyTo)
	}
}

func handleMyChatMember(cfg config, u tgUpdate) {
	m := u.MyChatMember
	if m == nil || !m.NewChatMember.User.IsBot {
		return
	}
	oldStatus := m.OldChatMember.Status
	newStatus := m.NewChatMember.Status
	if !isBotJoinTransition(oldStatus, newStatus) {
		return
	}
	recordChatSeen(cfg, m.Chat.ID, m.Chat.Type, m.Chat.Title)
	chatID := strconv.FormatInt(m.Chat.ID, 10)
	text := buildGroupWelcome(m.Chat.Type, m.Chat.Title, m.Chat.ID)
	_ = sendTelegramWithMarkup(cfg, m.Chat.ID, text, replyKeyboardForChat(cfg, chatID))
}

func isBotJoinTransition(oldStatus, newStatus string) bool {
	if !isActiveMemberStatus(newStatus) {
		return false
	}
	return isInactiveMemberStatus(oldStatus)
}

func buildGroupWelcome(chatType, title string, chatID int64) string {
	return tGroupWelcome(chatType, title, chatID)
}

func isInactiveMemberStatus(status string) bool {
	switch status {
	case "left", "kicked", "":
		return true
	default:
		return false
	}
}

func isActiveMemberStatus(status string) bool {
	switch status {
	case "member", "administrator", "creator", "restricted":
		return true
	default:
		return false
	}
}

func replyChatID(cfg config, chatID int64, chatType, title string, replyTo int64) {
	text := tChatIDHint(chatType, title, chatID)
	if chatType == "channel" {
		switch currentLangMode() {
		case "vi":
			text += "\n\nThêm ID kênh trong cấu hình push."
		case "zh":
			text += "\n\n在后台推送配置中绑定此频道 ID。"
		default:
			text += "\n\n后台推送配置绑定 / Cấu hình push"
		}
	} else if chatType == "group" || chatType == "supergroup" {
		switch currentLangMode() {
		case "vi":
			text += "\n\nThêm Chat ID trong trang quản trị."
		case "zh":
			text += "\n\n在后台「群组绑定」中添加此 Chat ID。"
		default:
			text += "\n\n后台「群组绑定」/ Trang quản trị"
		}
	}
	payload := map[string]interface{}{
		"chat_id": chatID,
		"text":    text,
	}
	if replyTo > 0 {
		payload["reply_to_message_id"] = replyTo
	}
	kb := currentReplyKeyboard()
	if kb != nil {
		payload["reply_markup"] = kb
	}
	body, _ := json.Marshal(payload)
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", cfg.BotToken)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader(body))
	if err == nil {
		resp.Body.Close()
	}
}

func looksLikeInviteCode(text string) bool {
	text = strings.ToUpper(strings.TrimSpace(text))
	if !strings.Contains(text, "-") {
		return false
	}
	parts := strings.Split(text, "-")
	if len(parts) != 2 {
		return false
	}
	if len(parts[0]) < 4 || len(parts[1]) < 4 {
		return false
	}
	for _, p := range parts {
		for _, ch := range p {
			if (ch < '0' || ch > '9') && (ch < 'A' || ch > 'F') {
				return false
			}
		}
	}
	return true
}

func replyBind(cfg config, userID int64, username, chatID, codeOrToken string, sourceChatID int64, replyTo int64) {
	codeOrToken = strings.TrimSpace(codeOrToken)
	if codeOrToken == "" {
		hint := "个人 TG 绑定（无需客户端）：\n/bind 邀请码 账号\n\n客户端绑定：点击托盘「绑定 Telegram」链接\n\n工位共用 TG：\n/bind_workstation 邀请码"
		_ = sendTelegramByUser(cfg, userID, hint)
		if sourceChatID != userID {
			_ = sendTelegramChatReply(cfg, sourceChatID, "请私聊机器人发送绑定命令。", replyTo)
		}
		return
	}
	payload := map[string]interface{}{
		"telegramUserId":   userID,
		"telegramUsername": strings.TrimPrefix(strings.TrimSpace(username), "@"),
		"chatId":           chatID,
	}
	parts := strings.Fields(codeOrToken)
	if len(parts) >= 2 && looksLikeInviteCode(parts[0]) {
		payload["inviteCode"] = strings.ToUpper(parts[0])
		payload["username"] = parts[1]
		if len(parts) >= 3 {
			payload["password"] = strings.Join(parts[2:], " ")
		}
	} else if len(parts) == 1 && !strings.Contains(parts[0], "-") {
		payload["bindToken"] = parts[0]
	} else {
		_ = sendTelegramByUser(cfg, userID, tgAlertPrefix("用法：/bind 邀请码 账号\n例如：/bind ABCD-1234 zhangsan"))
		return
	}
	var result apiResult
	result.Data = map[string]interface{}{}
	err := backendPost(cfg, "/telegram/worker/bind", payload, &result)
	if err != nil {
		_ = sendTelegramByUser(cfg, userID, tgAlertPrefix("绑定失败："+err.Error()))
		if sourceChatID != userID {
			_ = sendTelegramChatReply(cfg, sourceChatID, "绑定失败，详细原因已私聊发送。", replyTo)
		}
		return
	}
	if result.Code != 0 {
		_ = sendTelegramByUser(cfg, userID, tgAlertPrefix(result.Message))
		if sourceChatID != userID {
			_ = sendTelegramChatReply(cfg, sourceChatID, "绑定失败，详细原因已私聊发送。", replyTo)
		}
		return
	}
	name, _ := result.Data["employeeName"].(string)
	if name == "" {
		name = "员工"
	}
	successMsg := fmt.Sprintf("✅ 已绑定员工：%s（个人 TG，无需客户端）\n现在可以在考勤群打卡。", name)
	_ = sendTelegramByUser(cfg, userID, successMsg)
	if sourceChatID != userID {
		_ = sendTelegramChatReply(cfg, sourceChatID, fmt.Sprintf("✅ %s 已绑定个人 Telegram，可以打卡了。", name), replyTo)
	}
}

func replyBindWorkstation(cfg config, userID int64, username, chatID, inviteCode string, sourceChatID int64, replyTo int64) {
	inviteCode = strings.TrimSpace(strings.ToUpper(strings.Fields(inviteCode)[0]))
	if inviteCode == "" || !looksLikeInviteCode(inviteCode) {
		hint := "工位共用 TG 绑定：\n/bind_workstation 邀请码\n\n绑定后打卡需先在 PC 上员工登录。"
		_ = sendTelegramByUser(cfg, userID, hint)
		if sourceChatID != userID {
			_ = sendTelegramChatReply(cfg, sourceChatID, "请私聊机器人发送 /bind_workstation 邀请码。", replyTo)
		}
		return
	}
	payload := map[string]interface{}{
		"telegramUserId":   userID,
		"telegramUsername": strings.TrimPrefix(strings.TrimSpace(username), "@"),
		"inviteCode":       inviteCode,
		"chatId":           chatID,
	}
	var result apiResult
	result.Data = map[string]interface{}{}
	err := backendPost(cfg, "/telegram/worker/bind-workstation", payload, &result)
	if err != nil {
		_ = sendTelegramByUser(cfg, userID, tgAlertPrefix("绑定失败："+err.Error()))
		if sourceChatID != userID {
			_ = sendTelegramChatReply(cfg, sourceChatID, "绑定失败，详细原因已私聊发送。", replyTo)
		}
		return
	}
	if result.Code != 0 {
		_ = sendTelegramByUser(cfg, userID, tgAlertPrefix(result.Message))
		if sourceChatID != userID {
			_ = sendTelegramChatReply(cfg, sourceChatID, "绑定失败，详细原因已私聊发送。", replyTo)
		}
		return
	}
	deviceName, _ := result.Data["deviceName"].(string)
	if deviceName == "" {
		deviceName = "共享工位"
	}
	successMsg := fmt.Sprintf("✅ 工位 TG 已绑定设备：%s\n只需绑定一次；打卡前请先在 PC Agent 员工登录。", deviceName)
	_ = sendTelegramByUser(cfg, userID, successMsg)
	if sourceChatID != userID {
		_ = sendTelegramChatReply(cfg, sourceChatID, fmt.Sprintf("✅ 工位 Telegram 已绑定 %s。", deviceName), replyTo)
	}
}

func replyCheckIn(cfg config, userID int64, chatID, shift string, replyTo int64) {
	var result apiResult
	result.Data = map[string]interface{}{}
	payload := map[string]interface{}{
		"telegramUserId": userID,
		"chatId":         chatID,
	}
	if shift != "" {
		payload["shift"] = shift
	}
	err := backendPost(cfg, "/telegram/worker/checkin", payload, &result)
	if err != nil {
		replyWorkHTMLError(cfg, chatID, "打卡失败："+err.Error(), replyTo)
		return
	}
	if result.Code != 0 {
		failMsg := result.Message
		if strings.Contains(failMsg, "未绑定") {
			failMsg += "\n\n个人 TG：/bind 邀请码 账号\n工位 TG：/bind_workstation 邀请码"
		}
		replyWorkHTMLError(cfg, chatID, failMsg, replyTo)
		return
	}
	if groupHTML, ok := result.Data["groupReplyHtml"].(string); ok && strings.TrimSpace(groupHTML) != "" {
		replyWorkHTMLInChat(cfg, chatID, groupHTML, replyTo)
		return
	}
	name, _ := result.Data["employeeName"].(string)
	date, _ := result.Data["date"].(string)
	shiftLabel, _ := result.Data["shiftLabel"].(string)
	if name == "" {
		name = "员工"
	}
	msg := fmt.Sprintf("✅ %s 已上班（%s）", name, date)
	if shiftLabel != "" {
		msg += fmt.Sprintf(" · %s", shiftLabel)
	}
	if fine, ok := result.Data["workFine"].(float64); ok && fine > 0 {
		msg += fmt.Sprintf("\n⚠️ 迟到罚款 ¥%.2f", fine)
	}
	if hint, ok := result.Data["handoverHint"].(string); ok && hint != "" {
		msg += "\n" + hint
	}
	replyWorkHTMLError(cfg, chatID, msg, replyTo)
}

func replyCheckOut(cfg config, userID int64, chatID string, replyTo int64) {
	var result apiResult
	result.Data = map[string]interface{}{}
	err := backendPost(cfg, "/telegram/worker/checkout", map[string]interface{}{
		"telegramUserId": userID,
		"chatId":         chatID,
	}, &result)
	if err != nil {
		replyWorkHTMLError(cfg, chatID, "签退失败："+err.Error(), replyTo)
		return
	}
	if result.Code != 0 {
		replyWorkHTMLError(cfg, chatID, result.Message, replyTo)
		return
	}
	if groupHTML, ok := result.Data["groupReplyHtml"].(string); ok && strings.TrimSpace(groupHTML) != "" {
		replyWorkHTMLInChat(cfg, chatID, groupHTML, replyTo)
		return
	}
	name, _ := result.Data["employeeName"].(string)
	if name == "" {
		name = "员工"
	}
	msg := fmt.Sprintf("✅ %s 已下班", name)
	if shiftLabel, ok := result.Data["shiftLabel"].(string); ok && shiftLabel != "" {
		msg += fmt.Sprintf("（%s）", shiftLabel)
	}
	replyWorkHTMLError(cfg, chatID, msg, replyTo)
}

func replyWorkHTMLError(cfg config, chatID, text string, replyTo int64) {
	replyWorkHTMLInChat(cfg, chatID, html.EscapeString(tgAlertPrefix(text)), replyTo)
}

func replyWorkHTMLInChat(cfg config, chatID, htmlText string, replyTo int64) {
	groupChatID, err := strconv.ParseInt(strings.TrimSpace(chatID), 10, 64)
	if err != nil {
		return
	}
	kb := replyKeyboardForChat(cfg, chatID)
	if err := sendTelegramHTMLReply(cfg, groupChatID, htmlText, replyTo, kb); err != nil {
		_ = sendTelegramHTMLReply(cfg, groupChatID, htmlText, 0, kb)
	}
}

func replyStatus(cfg config, userID int64) {
	var result struct {
		Code int `json:"code"`
		Data struct {
			Bound             bool     `json:"bound"`
			EmployeeName      string   `json:"employeeName"`
			EmployeeCode      string   `json:"employeeCode"`
			WorkSessionOpen   bool     `json:"workSessionOpen"`
			CurrentActivity   string   `json:"currentActivity"`
			ActivityStartedAt string   `json:"activityStartedAt"`
			ShiftLabel        string   `json:"shiftLabel"`
			ShiftType         string   `json:"shiftType"`
			OpenShifts        []string `json:"openShifts"`
		} `json:"data"`
	}
	err := backendGet(cfg, fmt.Sprintf("/telegram/worker/status?telegramUserId=%d", userID), &result)
	if err != nil {
		_ = sendTelegramByUser(cfg, userID, tgAlertPrefix("查询失败："+err.Error()))
		return
	}
	if result.Code != 0 || !result.Data.Bound {
		_ = sendTelegramByUser(cfg, userID, tgAlertPrefix("尚未绑定员工账号，请联系管理员在后台绑定。"))
		return
	}
	status := "未上班"
	if result.Data.WorkSessionOpen {
		status = "上班中"
	}
	msg := fmt.Sprintf("%s", result.Data.EmployeeName)
	if result.Data.EmployeeCode != "" {
		msg += fmt.Sprintf("（%s）", result.Data.EmployeeCode)
	}
	msg += " · " + status
	if result.Data.ShiftLabel != "" && result.Data.WorkSessionOpen {
		msg += fmt.Sprintf("（%s）", result.Data.ShiftLabel)
	}
	if len(result.Data.OpenShifts) > 1 {
		msg += fmt.Sprintf("\n进行中班次：%s", strings.Join(result.Data.OpenShifts, "、"))
	}
	if result.Data.CurrentActivity != "" {
		msg += fmt.Sprintf("\n进行中活动：%s", result.Data.CurrentActivity)
		if result.Data.ActivityStartedAt != "" {
			msg += fmt.Sprintf("（自 %s）", result.Data.ActivityStartedAt)
		}
	}
	_ = sendTelegramByUser(cfg, userID, msg)
}

func replyStartActivity(cfg config, userID int64, chatID, activity string, replyTo int64) {
	var result apiResult
	result.Data = map[string]interface{}{}
	err := backendPost(cfg, "/telegram/worker/activity/start", map[string]interface{}{
		"telegramUserId":   userID,
		"chatId":           chatID,
		"activity":         activity,
		"replyToMessageId": replyTo,
	}, &result)
	if err != nil {
		replyWorkHTMLError(cfg, chatID, "开始活动失败："+err.Error(), replyTo)
		return
	}
	if result.Code != 0 {
		replyWorkHTMLError(cfg, chatID, result.Message, replyTo)
		return
	}
	if groupReplySent(result.Data) {
		return
	}
	groupHTML, _ := result.Data["groupReplyHtml"].(string)
	if strings.TrimSpace(groupHTML) == "" {
		msg, _ := result.Data["messageText"].(string)
		if msg == "" {
			name, _ := result.Data["activityName"].(string)
			limit, _ := result.Data["limitSeconds"].(float64)
			msg = fmt.Sprintf("⏱ 已开始「%s」，时限 %d 秒", name, int(limit))
		}
		groupHTML = html.EscapeString(msg)
	}
	inline, _ := result.Data["inlineKeyboard"].(map[string]interface{})
	sessionID, _ := result.Data["sessionId"].(string)
	groupChatID, parseErr := strconv.ParseInt(strings.TrimSpace(chatID), 10, 64)
	if parseErr == nil && groupChatID < 0 {
		kb := replyKeyboardForChat(cfg, chatID)
		msgID, sendErr := sendTelegramHTMLReplyReturnID(cfg, groupChatID, groupHTML, replyTo, kb)
		if sendErr != nil {
			_ = sendTelegramHTMLReply(cfg, groupChatID, groupHTML, 0, kb)
		} else if sessionID != "" && msgID > 0 {
			_ = backendPost(cfg, "/telegram/worker/activity/message-id", map[string]interface{}{
				"sessionId": sessionID, "messageId": msgID,
			}, &apiResult{})
		}
		return
	}
	msgID, err := sendTelegramWithMarkupReturnID(cfg, userID, groupHTML, inline)
	if err != nil {
		plain, _ := result.Data["messageText"].(string)
		if plain == "" {
			plain = "活动已开始"
		}
		_ = sendTelegramByUser(cfg, userID, plain)
	} else if sessionID != "" && msgID > 0 {
		_ = backendPost(cfg, "/telegram/worker/activity/message-id", map[string]interface{}{
			"sessionId": sessionID, "messageId": msgID,
		}, &apiResult{})
	}
}

func replyEndActivity(cfg config, userID int64, chatID string, replyTo int64) {
	var result apiResult
	result.Data = map[string]interface{}{}
	err := backendPost(cfg, "/telegram/worker/activity/end", map[string]interface{}{
		"telegramUserId": userID,
	}, &result)
	if err != nil {
		replyWorkHTMLError(cfg, chatID, "结束活动失败："+err.Error(), replyTo)
		return
	}
	if result.Code != 0 {
		replyWorkHTMLError(cfg, chatID, result.Message, replyTo)
		return
	}
	if groupReplySent(result.Data) {
		return
	}
	if groupHTML, ok := result.Data["groupReplyHtml"].(string); ok && strings.TrimSpace(groupHTML) != "" {
		replyWorkHTMLInChat(cfg, chatID, groupHTML, activityAnchorReplyTo(result.Data, replyTo))
		return
	}
	name, _ := result.Data["activityName"].(string)
	elapsed, _ := result.Data["elapsedSeconds"].(float64)
	fine, _ := result.Data["fineAmount"].(float64)
	msg := fmt.Sprintf("✅ 「%s」已结束，用时 %s", name, formatDurationZh(int(elapsed)))
	if fine > 0 {
		msg += fmt.Sprintf("\n⚠️ 超时罚款 ¥%.2f（已写入罚款明细）", fine)
	}
	replyWorkHTMLError(cfg, chatID, msg, activityAnchorReplyTo(result.Data, replyTo))
}

func groupReplySent(data map[string]interface{}) bool {
	if data == nil {
		return false
	}
	switch v := data["groupReplySent"].(type) {
	case bool:
		return v
	case string:
		return v == "true" || v == "1"
	}
	return false
}

func activityAnchorReplyTo(data map[string]interface{}, fallback int64) int64 {
	if data == nil {
		return fallback
	}
	switch v := data["activityAnchorMessageId"].(type) {
	case float64:
		if int64(v) > 0 {
			return int64(v)
		}
	case int64:
		if v > 0 {
			return v
		}
	case int:
		if int64(v) > 0 {
			return int64(v)
		}
	}
	return fallback
}

func replyMyInfo(cfg config, userID int64, chatID, shift string, replyTo int64) {
	path := fmt.Sprintf("/telegram/worker/myinfo?telegramUserId=%d", userID)
	if strings.TrimSpace(chatID) != "" {
		path += "&chatId=" + url.QueryEscape(chatID)
	}
	if shift != "" {
		path += "&shift=" + url.QueryEscape(shift)
	}
	var result struct {
		Code int `json:"code"`
		Data struct {
			Bound       bool   `json:"bound"`
			DisplayText string `json:"displayText"`
		} `json:"data"`
	}
	err := backendGet(cfg, path, &result)
	if err != nil {
		replyStatsPlain(cfg, userID, chatID, tgAlertPrefix("查询失败："+err.Error()), replyTo)
		return
	}
	if result.Code != 0 || !result.Data.Bound {
		replyStatsPlain(cfg, userID, chatID, tgAlertPrefix("尚未绑定员工账号。"), replyTo)
		return
	}
	text := result.Data.DisplayText
	if text == "" {
		text = "暂无记录"
	}
	replyStatsPlain(cfg, userID, chatID, text, replyTo)
}

func replyRankings(cfg config, userID int64, chatID, shift string, replyTo int64) {
	path := fmt.Sprintf("/telegram/worker/rankings?telegramUserId=%d", userID)
	if strings.TrimSpace(chatID) != "" {
		path += "&chatId=" + url.QueryEscape(chatID)
	}
	if shift != "" {
		path += "&shift=" + url.QueryEscape(shift)
	}
	var result struct {
		Code int `json:"code"`
		Data struct {
			DisplayText string `json:"displayText"`
		} `json:"data"`
	}
	err := backendGet(cfg, path, &result)
	if err != nil {
		replyStatsPlain(cfg, userID, chatID, tgAlertPrefix("查询排行榜失败："+err.Error()), replyTo)
		return
	}
	text := result.Data.DisplayText
	if result.Code != 0 || text == "" {
		text = "今日暂无排行数据"
	}
	replyStatsPlain(cfg, userID, chatID, text, replyTo)
}

func replyStatsPlain(cfg config, userID int64, chatID, text string, replyTo int64) {
	if groupChatID, err := strconv.ParseInt(strings.TrimSpace(chatID), 10, 64); err == nil && groupChatID < 0 {
		kb := replyKeyboardForChat(cfg, chatID)
		_ = sendTelegramPlainReply(cfg, groupChatID, text, replyTo, kb)
		return
	}
	_ = sendTelegramByUser(cfg, userID, text)
}

func sendTelegramPlainReply(cfg config, chatID int64, text string, replyTo int64, replyMarkup map[string]interface{}) error {
	payload := map[string]interface{}{
		"chat_id": chatID,
		"text":    text,
	}
	if replyTo > 0 {
		payload["reply_to_message_id"] = replyTo
	}
	if replyMarkup != nil {
		payload["reply_markup"] = replyMarkup
	}
	body, _ := json.Marshal(payload)
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", cfg.BotToken)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader(body))
	if err != nil {
		return err
	}
	resp.Body.Close()
	return nil
}

func replyHandover(cfg config, userID int64, note string) {
	var result apiResult
	result.Data = map[string]interface{}{}
	payload := map[string]interface{}{"telegramUserId": userID}
	if note != "" {
		payload["note"] = note
	}
	err := backendPost(cfg, "/telegram/worker/handover", payload, &result)
	if err != nil {
		_ = sendTelegramByUser(cfg, userID, tgAlertPrefix("交接班失败："+err.Error()))
		return
	}
	if result.Code != 0 {
		_ = sendTelegramByUser(cfg, userID, tgAlertPrefix(result.Message))
		return
	}
	shiftLabel, _ := result.Data["shiftLabel"].(string)
	_ = sendTelegramByUser(cfg, userID, fmt.Sprintf("✅ 交接班完成，当前班次：%s", shiftLabel))
}

type apiResult struct {
	Code    int                    `json:"code"`
	Message string                 `json:"message"`
	Data    map[string]interface{} `json:"data"`
}

func backendPost(cfg config, path string, payload interface{}, out interface{}) error {
	body, _ := json.Marshal(payload)
	req, err := http.NewRequest(http.MethodPost, cfg.BackendURL+path, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Telegram-Worker-Secret", cfg.WorkerSecret)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	if err := json.Unmarshal(raw, out); err != nil {
		return fmt.Errorf("%s", string(raw))
	}
	return nil
}

func backendGet(cfg config, path string, out interface{}) error {
	req, err := http.NewRequest(http.MethodGet, cfg.BackendURL+path, nil)
	if err != nil {
		return err
	}
	req.Header.Set("X-Telegram-Worker-Secret", cfg.WorkerSecret)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	return json.Unmarshal(raw, out)
}

func sendTelegramByUser(cfg config, userID int64, text string) error {
	return sendTelegramWithMarkup(cfg, userID, text, replyKeyboardForChat(cfg, strconv.FormatInt(userID, 10)))
}

func sendTelegramChatReply(cfg config, chatID int64, text string, replyTo int64) error {
	return sendTelegramHTMLReply(cfg, chatID, text, replyTo, nil)
}

func sendTelegramHTMLReply(cfg config, chatID int64, text string, replyTo int64, replyMarkup map[string]interface{}) error {
	_, err := sendTelegramHTMLReplyReturnID(cfg, chatID, text, replyTo, replyMarkup)
	return err
}

func sendTelegramHTMLReplyReturnID(cfg config, chatID int64, text string, replyTo int64, replyMarkup map[string]interface{}) (int64, error) {
	payload := map[string]interface{}{
		"chat_id":    chatID,
		"text":       text,
		"parse_mode": "HTML",
	}
	if replyTo > 0 {
		payload["reply_to_message_id"] = replyTo
	}
	if replyMarkup != nil {
		payload["reply_markup"] = replyMarkup
	}
	body, _ := json.Marshal(payload)
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", cfg.BotToken)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader(body))
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK     bool `json:"ok"`
		Result struct {
			MessageID int64 `json:"message_id"`
		} `json:"result"`
	}
	_ = json.Unmarshal(raw, &parsed)
	if !parsed.OK {
		return 0, fmt.Errorf("telegram send failed")
	}
	return parsed.Result.MessageID, nil
}

func sendTelegramWithMarkupReturnID(cfg config, chatID int64, text string, replyMarkup map[string]interface{}) (int64, error) {
	payload := map[string]interface{}{
		"chat_id": chatID,
		"text":    text,
	}
	if replyMarkup != nil {
		payload["reply_markup"] = replyMarkup
	}
	body, _ := json.Marshal(payload)
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", cfg.BotToken)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader(body))
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK     bool `json:"ok"`
		Result struct {
			MessageID int64 `json:"message_id"`
		} `json:"result"`
	}
	if json.Unmarshal(raw, &parsed) != nil || !parsed.OK {
		return 0, fmt.Errorf("sendMessage failed")
	}
	return parsed.Result.MessageID, nil
}

func sendTelegramWithMarkup(cfg config, chatID int64, text string, replyMarkup map[string]interface{}) error {
	payload := map[string]interface{}{
		"chat_id": chatID,
		"text":    text,
	}
	if replyMarkup != nil {
		payload["reply_markup"] = replyMarkup
	}
	body, _ := json.Marshal(payload)
	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", cfg.BotToken)
	resp, err := http.Post(url, "application/json", bytes.NewReader(body))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return nil
}

func sendTelegram(cfg config, chatID int64, text string) error {
	return sendTelegramWithMarkup(cfg, chatID, text, nil)
}

func formatDurationZh(seconds int) string {
	if seconds <= 0 {
		return "0秒"
	}
	m, s := seconds/60, seconds%60
	h := m / 60
	m = m % 60
	if h > 0 {
		return fmt.Sprintf("%d小时%d分%d秒", h, m, s)
	}
	if m > 0 {
		return fmt.Sprintf("%d分%d秒", m, s)
	}
	return fmt.Sprintf("%d秒", s)
}

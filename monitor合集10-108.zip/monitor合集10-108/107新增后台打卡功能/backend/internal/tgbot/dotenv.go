package tgbot

import "github.com/joho/godotenv"

func loadDotEnv() error {
	return godotenv.Load()
}

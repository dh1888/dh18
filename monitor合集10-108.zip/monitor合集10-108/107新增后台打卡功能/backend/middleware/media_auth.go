package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// MediaAccessAuth 支持 Bearer JWT 或短期 mediaToken（用于 video 流等无法带 Header 的场景）
func MediaAccessAuth(redisClient *redis.Client, resourceType, action, permission string) gin.HandlerFunc {
	return mediaAccessAuth(redisClient, resourceType, action, []string{permission})
}

// MediaAccessAnyAuth 允许 JWT 用户持有任意一个指定权限
func MediaAccessAnyAuth(redisClient *redis.Client, resourceType, action string, permissions ...string) gin.HandlerFunc {
	return mediaAccessAuth(redisClient, resourceType, action, permissions)
}

func mediaAccessAuth(redisClient *redis.Client, resourceType, action string, permissions []string) gin.HandlerFunc {
	svc := services.NewMediaTokenService(redisClient, GetSessionService())

	return func(c *gin.Context) {
		resourceID := strings.TrimSpace(c.Param("id"))
		if mediaToken := strings.TrimSpace(c.Query("mediaToken")); mediaToken != "" {
			grant, err := svc.Validate(c.Request.Context(), mediaToken, resourceType, resourceID, action)
			if err != nil {
				if err == services.ErrMediaTokenExpired {
					models.SendError(c, 401, 1002, "Media token expired")
				} else {
					models.SendError(c, 401, 1002, "Invalid media token")
				}
				c.Abort()
				return
			}
			applyMediaGrantToContext(c, grant)
			c.Next()
			return
		}

		Auth(redisClient)(c)
		if c.IsAborted() {
			return
		}
		if len(permissions) == 1 {
			RequirePermission(permissions[0])(c)
		} else {
			RequireAnyPermission(permissions...)(c)
		}
	}
}

func applyMediaGrantToContext(c *gin.Context, grant *services.MediaAccessGrant) {
	if grant.SessionID != "" {
		c.Set("sessionID", grant.SessionID)
	}
	c.Set("userID", grant.UserID)
	c.Set("username", grant.Username)
	if grant.Role != "" {
		c.Set("role", grant.Role)
	}
	if len(grant.AllowedDeviceIDs) > 0 {
		c.Set("mediaScopedDeviceIDs", grant.AllowedDeviceIDs)
	}
}

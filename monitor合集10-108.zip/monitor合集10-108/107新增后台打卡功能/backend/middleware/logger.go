package middleware

import (
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/config"
	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services/logx"
)

func Logger() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		requestID := uuid.New().String()
		c.Set("requestID", requestID)
		c.Header("X-Request-ID", requestID)

		c.Next()

		duration := time.Since(start)
		sessionID := strings.TrimSpace(c.GetString("sessionID"))
		uploadID := strings.TrimSpace(c.GetString("uploadId"))
		deviceID := strings.TrimSpace(c.GetString("deviceID"))
		if deviceID == "" {
			deviceID = strings.TrimSpace(c.GetString("deviceId"))
		}
		userID := strings.TrimSpace(c.GetString("userID"))

		fields := fmt.Sprintf("session_id=%s", sessionID)
		if uploadID != "" {
			fields += fmt.Sprintf(" upload_id=%s", uploadID)
		}
		if deviceID != "" {
			fields += fmt.Sprintf(" device_id=%s", deviceID)
		}
		if userID != "" {
			fields += fmt.Sprintf(" user_id=%s", userID)
		}

		if !logx.ShouldLogHTTPAccess(c.Writer.Status(), c.Request.URL.Path, duration) {
			return
		}

		log.Printf("[%s] %s %s - %d (%v) %s",
			requestID,
			c.Request.Method,
			c.Request.URL.Path,
			c.Writer.Status(),
			duration,
			fields,
		)
	}
}

func Recovery() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if err := recover(); err != nil {
				log.Printf("Panic recovered: %v", err)
				models.SendError(c, 500, 5000, "Internal server error")
				c.Abort()
			}
		}()
		c.Next()
	}
}

func CORS() gin.HandlerFunc {
	return func(c *gin.Context) {
		origin := c.GetHeader("Origin")
		if config.IsOriginAllowed(origin) {
			if origin != "" {
				c.Header("Access-Control-Allow-Origin", origin)
				c.Header("Vary", "Origin")
				c.Header("Access-Control-Allow-Credentials", "true")
			}
		}

		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Authorization, Content-Type, X-Device-Id, X-Timestamp, X-Nonce, X-Signature, X-Signature-Version, X-Upload-Id, X-File-Name, X-File-Type, X-File-Id, X-Chunk-Index, X-Total-Chunks, X-Chunk-Checksum, X-Upload-Nonce")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	}
}

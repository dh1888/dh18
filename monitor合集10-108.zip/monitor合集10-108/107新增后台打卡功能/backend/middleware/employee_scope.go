package middleware

import (
	"database/sql"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

var employeeScopeDB *sql.DB

func InitEmployeeScopeDB(db *sql.DB) {
	employeeScopeDB = db
}

// ResolveScopedEmployeeID loads employees.id for portal user.
func ResolveScopedEmployeeID(c *gin.Context) (uuid.UUID, bool) {
	if employeeScopeDB == nil {
		return uuid.Nil, false
	}
	userID, err := uuid.Parse(c.GetString("userID"))
	if err != nil {
		return uuid.Nil, false
	}
	var empID uuid.UUID
	err = employeeScopeDB.QueryRowContext(c.Request.Context(),
		`SELECT id FROM employees WHERE user_id = $1 AND status = 1`, userID).Scan(&empID)
	if err != nil {
		return uuid.Nil, false
	}
	return empID, true
}

// RequireEmployeePortal ensures linked employee record or admin.
func RequireEmployeePortal() gin.HandlerFunc {
	return func(c *gin.Context) {
		role := c.GetString("role")
		if role == "admin" {
			c.Next()
			return
		}
		if empID, ok := ResolveScopedEmployeeID(c); ok {
			c.Set("scopedEmployeeID", empID.String())
			c.Next()
			return
		}
		models.SendError(c, 403, 1003, "Employee portal access denied")
		c.Abort()
	}
}

// IsEmployeeRole returns true when the portal user is an employee-role account with a linked workforce record.
// Admin/operator/auditor/viewer accounts are never scoped to a single bound device, even if employees.user_id links them.
func IsEmployeeRole(c *gin.Context) bool {
	if normalizeRoleName(c.GetString("role")) != "employee" {
		return false
	}
	_, ok := ResolveScopedEmployeeID(c)
	return ok
}

// IsAdminRole reports whether the authenticated user is an administrator.
func IsAdminRole(c *gin.Context) bool {
	return normalizeRoleName(c.GetString("role")) == "admin"
}

// ResolveEmployeeDeviceIDs returns device IDs bound to the scoped employee.
func ResolveEmployeeDeviceIDs(c *gin.Context) ([]uuid.UUID, bool) {
	if employeeScopeDB == nil {
		return nil, false
	}
	empID, ok := ResolveScopedEmployeeID(c)
	if !ok {
		return nil, false
	}
	rows, err := employeeScopeDB.QueryContext(c.Request.Context(),
		`SELECT id FROM devices WHERE employee_uuid = $1 AND status != 'rejected'`, empID)
	if err != nil {
		return nil, false
	}
	defer rows.Close()

	var ids []uuid.UUID
	for rows.Next() {
		var id uuid.UUID
		if err := rows.Scan(&id); err == nil {
			ids = append(ids, id)
		}
	}
	return ids, len(ids) > 0
}

// EmployeeCanAccessDevice checks whether an employee user may access a device.
func EmployeeCanAccessDevice(c *gin.Context, deviceID uuid.UUID) bool {
	if !IsEmployeeRole(c) {
		return true
	}
	if raw, ok := c.Get("mediaScopedDeviceIDs"); ok {
		if ids, ok := raw.([]string); ok {
			for _, s := range ids {
				if id, err := uuid.Parse(s); err == nil && id == deviceID {
					return true
				}
			}
			return false
		}
	}
	ids, ok := ResolveEmployeeDeviceIDs(c)
	if !ok {
		return false
	}
	for _, id := range ids {
		if id == deviceID {
			return true
		}
	}
	return false
}

// EnforceEmployeeDeviceScope aborts with 403 when employee accesses another device.
func EnforceEmployeeDeviceScope(c *gin.Context, deviceID uuid.UUID) bool {
	if !IsEmployeeRole(c) {
		return true
	}
	if EmployeeCanAccessDevice(c, deviceID) {
		return true
	}
	models.SendError(c, 403, 1003, "Access denied: recording belongs to another employee")
	c.Abort()
	return false
}

// ResolveEmployeeListDeviceFilter returns the device filter for employee-scoped list queries.
func ResolveEmployeeListDeviceFilter(c *gin.Context, requested string) (string, bool) {
	if !IsEmployeeRole(c) {
		return requested, true
	}
	ids, ok := ResolveEmployeeDeviceIDs(c)
	if !ok {
		models.SendError(c, 403, 1003, "No device bound to your account")
		c.Abort()
		return "", false
	}
	if requested != "" {
		reqID, err := uuid.Parse(requested)
		if err != nil || !EmployeeCanAccessDevice(c, reqID) {
			models.SendError(c, 403, 1003, "Access denied")
			c.Abort()
			return "", false
		}
		return requested, true
	}
	return ids[0].String(), true
}

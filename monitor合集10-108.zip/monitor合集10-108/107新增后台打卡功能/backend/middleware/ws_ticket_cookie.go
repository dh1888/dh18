package middleware

import (
	"log"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

const wsTicketCookieName = "ws_ticket"

const wsTicketContextKey = "wsTicket"

// extractWSTicketCandidates prefers Cookie (latest POST /ws-ticket) over query.
func extractWSTicketCandidates(c *gin.Context) []string {
	seen := make(map[string]struct{}, 2)
	out := make([]string, 0, 2)
	add := func(raw string) {
		ticket := strings.TrimSpace(raw)
		if ticket == "" {
			return
		}
		if _, ok := seen[ticket]; ok {
			return
		}
		seen[ticket] = struct{}{}
		out = append(out, ticket)
	}
	if ticket, err := c.Cookie(wsTicketCookieName); err == nil {
		add(ticket)
	}
	add(c.Query("ticket"))
	return out
}

func SetWSTicketCookie(c *gin.Context, ticket string, ttl time.Duration) {
	if ticket == "" || ttl <= 0 {
		return
	}
	secure := requestIsHTTPS(c)
	maxAge := int(ttl.Seconds())
	if maxAge < 1 {
		maxAge = 1
	}
	c.SetSameSite(http.SameSiteLaxMode)
	c.SetCookie(wsTicketCookieName, ticket, maxAge, "/", "", secure, true)
}

func ClearWSTicketCookie(c *gin.Context) {
	secure := requestIsHTTPS(c)
	c.SetSameSite(http.SameSiteLaxMode)
	c.SetCookie(wsTicketCookieName, "", -1, "/", "", secure, true)
}

func requestIsHTTPS(c *gin.Context) bool {
	if c.Request.TLS != nil {
		return true
	}
	return strings.EqualFold(strings.TrimSpace(c.GetHeader("X-Forwarded-Proto")), "https")
}

func logWSAuthFailure(c *gin.Context, reason string, triedTickets []string) {
	hasQuery := strings.TrimSpace(c.Query("ticket")) != ""
	hasCookie := false
	cookieTicket := ""
	if ticket, err := c.Cookie(wsTicketCookieName); err == nil {
		hasCookie = true
		cookieTicket = strings.TrimSpace(ticket)
	}
	queryTicket := strings.TrimSpace(c.Query("ticket"))
	mismatch := hasQuery && hasCookie && queryTicket != "" && cookieTicket != "" && queryTicket != cookieTicket
	log.Printf(
		"[WS Auth] %s path=%s hasQueryTicket=%v hasCookieTicket=%v ticketMismatch=%v tried=%d origin=%q",
		reason,
		c.Request.URL.Path,
		hasQuery,
		hasCookie,
		mismatch,
		len(triedTickets),
		c.GetHeader("Origin"),
	)
}

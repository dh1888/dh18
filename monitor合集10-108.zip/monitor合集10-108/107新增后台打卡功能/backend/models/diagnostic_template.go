package models

import "time"

// DiagnosticTemplate 诊断模板：集中定义场景所需模块级别，新增模块时只需改此处。
type DiagnosticTemplate struct {
	ID                     string                     `json:"id"`
	Name                   string                     `json:"name"`
	Description            string                     `json:"description"`
	GlobalLevel            DiagnosticLevel            `json:"globalLevel"`
	ModuleLevels           map[string]DiagnosticLevel `json:"moduleLevels"`
	DefaultDurationMinutes int                        `json:"defaultDurationMinutes"`
}

var diagnosticTemplateOrder = []string{
	"remote-view",
	"login",
	"upload",
	"recording",
	"full",
}

var diagnosticTemplates = map[string]DiagnosticTemplate{
	"remote-view": {
		ID:          "remote-view",
		Name:        "RemoteView",
		Description: "远程桌面推流、编码、媒体与链路生命周期",
		GlobalLevel: DiagnosticLevelOff,
		ModuleLevels: map[string]DiagnosticLevel{
			"RemoteView": DiagnosticLevelInfo,
			"FFmpeg":     DiagnosticLevelInfo,
			"LiveKit":    DiagnosticLevelInfo,
			"WebSocket":  DiagnosticLevelInfo,
			"Capture":    DiagnosticLevelInfo,
			"Lifecycle":  DiagnosticLevelInfo,
			"Health":     DiagnosticLevelWarn,
			"Backend":    DiagnosticLevelWarn,
		},
		DefaultDurationMinutes: 60,
	},
	"login": {
		ID:          "login",
		Name:        "登录异常",
		Description: "Agent 注册、WebSocket 连接与鉴权问题",
		GlobalLevel: DiagnosticLevelOff,
		ModuleLevels: map[string]DiagnosticLevel{
			"WebSocket": DiagnosticLevelInfo,
			"Lifecycle": DiagnosticLevelInfo,
			"Health":    DiagnosticLevelInfo,
			"Backend":   DiagnosticLevelInfo,
			"Policy":    DiagnosticLevelWarn,
		},
		DefaultDurationMinutes: 30,
	},
	"upload": {
		ID:          "upload",
		Name:        "上传异常",
		Description: "录制/截图上传队列与网络传输",
		GlobalLevel: DiagnosticLevelOff,
		ModuleLevels: map[string]DiagnosticLevel{
			"Upload":    DiagnosticLevelInfo,
			"Recording": DiagnosticLevelInfo,
			"WebSocket": DiagnosticLevelInfo,
			"Health":    DiagnosticLevelWarn,
			"Backend":   DiagnosticLevelWarn,
		},
		DefaultDurationMinutes: 60,
	},
	"recording": {
		ID:          "recording",
		Name:        "录屏异常",
		Description: "本地录屏、采集与编码链路",
		GlobalLevel: DiagnosticLevelOff,
		ModuleLevels: map[string]DiagnosticLevel{
			"Recording": DiagnosticLevelInfo,
			"Capture":   DiagnosticLevelInfo,
			"FFmpeg":    DiagnosticLevelInfo,
			"Lifecycle": DiagnosticLevelInfo,
			"Health":    DiagnosticLevelWarn,
		},
		DefaultDurationMinutes: 60,
	},
	"full": {
		ID:          "full",
		Name:        "全部诊断",
		Description: "所有模块开启 DEBUG，仅短时排查使用",
		GlobalLevel: DiagnosticLevelDebug,
		ModuleLevels: map[string]DiagnosticLevel{
			"RemoteView": DiagnosticLevelDebug,
			"Recording":  DiagnosticLevelDebug,
			"Upload":     DiagnosticLevelDebug,
			"WebSocket":  DiagnosticLevelDebug,
			"LiveKit":    DiagnosticLevelDebug,
			"FFmpeg":     DiagnosticLevelDebug,
			"Policy":     DiagnosticLevelInfo,
			"Capture":    DiagnosticLevelDebug,
			"Lifecycle":  DiagnosticLevelDebug,
			"Health":     DiagnosticLevelInfo,
			"Backend":    DiagnosticLevelInfo,
		},
		DefaultDurationMinutes: 30,
	},
}

func ListDiagnosticTemplates() []DiagnosticTemplate {
	out := make([]DiagnosticTemplate, 0, len(diagnosticTemplateOrder))
	for _, id := range diagnosticTemplateOrder {
		if tmpl, ok := diagnosticTemplates[id]; ok {
			out = append(out, tmpl)
		}
	}
	return out
}

func GetDiagnosticTemplate(id string) (DiagnosticTemplate, bool) {
	tmpl, ok := diagnosticTemplates[id]
	return tmpl, ok
}

func ApplyDiagnosticTemplate(base DiagnosticCenterConfig, tmpl DiagnosticTemplate, durationMinutes int) DiagnosticCenterConfig {
	if durationMinutes <= 0 {
		durationMinutes = tmpl.DefaultDurationMinutes
	}
	exp := UTCNow().Add(time.Duration(durationMinutes) * time.Minute)

	cfg := DefaultDiagnosticCenterConfig()
	cfg.Enabled = true
	cfg.GlobalLevel = NormalizeDiagnosticLevel(string(tmpl.GlobalLevel))
	cfg.ExpiresAt = &exp
	cfg.AppliedTemplateID = tmpl.ID
	cfg.RetentionHours = base.RetentionHours
	cfg.AgentUploadEnabled = base.AgentUploadEnabled
	cfg.FrontendUploadEnabled = base.FrontendUploadEnabled

	for _, module := range DiagnosticModules {
		level := cfg.GlobalLevel
		if moduleLevel, ok := tmpl.ModuleLevels[module]; ok {
			level = NormalizeDiagnosticLevel(string(moduleLevel))
		}
		cfg.ModuleLevels[module] = level
	}
	return cfg
}

func RestoreDefaultDiagnosticCenterConfig(current DiagnosticCenterConfig) DiagnosticCenterConfig {
	cfg := DefaultDiagnosticCenterConfig()
	cfg.RetentionHours = current.RetentionHours
	cfg.AgentUploadEnabled = current.AgentUploadEnabled
	cfg.FrontendUploadEnabled = current.FrontendUploadEnabled
	return cfg
}

package models

import "time"

type DiagnosticSnapshot struct {
	GeneratedAt time.Time              `json:"generatedAt"`
	Runtime     DiagnosticRuntimeConfig `json:"runtime"`
	WebSocket   DiagnosticWSSnapshot    `json:"websocket"`
	Events      DiagnosticEventStats    `json:"events"`
	RemoteView  DiagnosticRVSnapshot    `json:"remoteView"`
	Agents      []DiagnosticAgentSummary `json:"agents"`
	Health      DiagnosticHealthScore   `json:"health"`
	StatsToday  DiagnosticDailyStats    `json:"statsToday"`
}

type DiagnosticHealthScore struct {
	Score  int                     `json:"score"`
	Layers []DiagnosticHealthLayer `json:"layers"`
}

type DiagnosticHealthLayer struct {
	ID     string `json:"id"`
	Label  string `json:"label"`
	Status string `json:"status"`
	Detail string `json:"detail,omitempty"`
}

type DiagnosticDailyStats struct {
	RemoteViewStarts   int     `json:"remoteViewStarts"`
	RemoteViewSuccess  int     `json:"remoteViewSuccess"`
	RemoteViewFailures int     `json:"remoteViewFailures"`
	SuccessRate        float64 `json:"successRate"`
}

type DiagnosticWSSnapshot struct {
	AgentsOnline      int `json:"agentsOnline"`
	AdminConnections  int `json:"adminConnections"`
	TotalConnections  int `json:"totalConnections"`
}

type DiagnosticEventStats struct {
	TotalStored int            `json:"totalStored"`
	Last5Min    map[string]int `json:"last5Min"`
	Last1Hour   map[string]int `json:"last1Hour"`
	ByModule5m  map[string]int `json:"byModule5m"`
}

type DiagnosticRVSnapshot struct {
	ActiveSessions   int                              `json:"activeSessions"`
	PublishingFresh  int                              `json:"publishingFresh"`
	Sessions         []DiagnosticRemoteSessionSummary `json:"sessions"`
}

type DiagnosticRemoteSessionSummary struct {
	SessionID    string                  `json:"sessionId"`
	DeviceID     string                  `json:"deviceId"`
	Hostname     string                  `json:"hostname,omitempty"`
	Status       string                  `json:"status"`
	ViewerCount  int                     `json:"viewerCount"`
	AgentOnline  bool                    `json:"agentOnline"`
	StatsFresh   bool                    `json:"statsFresh"`
	IngressID    string                  `json:"ingressId,omitempty"`
	StartedAt    string                  `json:"startedAt,omitempty"`
	Stats        *RemoteViewStatsPayload `json:"stats,omitempty"`
}

type DiagnosticAgentSummary struct {
	DeviceID    string `json:"deviceId"`
	Hostname    string `json:"hostname,omitempty"`
	Online      bool   `json:"online"`
	StatsFresh  bool   `json:"statsFresh"`
	Publishing  bool   `json:"publishing"`
	SessionID   string `json:"sessionId,omitempty"`
	SessionStatus string `json:"sessionStatus,omitempty"`
}

type DiagnosticPipeline struct {
	DeviceID      string                   `json:"deviceId"`
	Hostname      string                   `json:"hostname,omitempty"`
	SessionID     string                   `json:"sessionId,omitempty"`
	GeneratedAt   time.Time                `json:"generatedAt"`
	OverallStatus string                   `json:"overallStatus"`
	Nodes         []DiagnosticPipelineNode `json:"nodes"`
	Edges         []DiagnosticPipelineEdge `json:"edges"`
}

type DiagnosticPipelineNode struct {
	ID         string                      `json:"id"`
	Label      string                      `json:"label"`
	Layer      string                      `json:"layer"`
	Status     string                      `json:"status"`
	Detail     string                      `json:"detail"`
	Metrics    map[string]interface{}      `json:"metrics,omitempty"`
	RecentLogs []DiagnosticEventBrief      `json:"recentLogs,omitempty"`
	RecentErrors []DiagnosticEventBrief    `json:"recentErrors,omitempty"`
}

type DiagnosticEventBrief struct {
	CreatedAt string `json:"createdAt"`
	Level     string `json:"level"`
	Message   string `json:"message"`
	Module    string `json:"module,omitempty"`
}

type DiagnosticPipelineEdge struct {
	From string `json:"from"`
	To   string `json:"to"`
}

type DiagnosticFinding struct {
	Severity        string   `json:"severity"`
	Code            string   `json:"code"`
	Title           string   `json:"title"`
	Detail          string   `json:"detail"`
	Module          string   `json:"module,omitempty"`
	DeviceID        string   `json:"deviceId,omitempty"`
	Evidence        []string `json:"evidence,omitempty"`
	SuggestedAction string   `json:"suggestedAction,omitempty"`
}

type DiagnosticAnalysis struct {
	GeneratedAt   time.Time              `json:"generatedAt"`
	WindowMinutes int                    `json:"windowMinutes"`
	Summary       string                 `json:"summary"`
	Findings      []DiagnosticFinding    `json:"findings"`
	Counts        map[string]int         `json:"counts"`
	Conclusion    *DiagnosticConclusion  `json:"conclusion,omitempty"`
}

type DiagnosticConclusion struct {
	Title         string                    `json:"title"`
	ProbableCause string                    `json:"probableCause"`
	Confidence    int                       `json:"confidence"`
	Checks        []DiagnosticConclusionCheck `json:"checks"`
}

type DiagnosticConclusionCheck struct {
	Label string `json:"label"`
	OK    bool   `json:"ok"`
}

type DiagnosticSessionGroup struct {
	SessionID   string                `json:"sessionId"`
	DeviceID    string                `json:"deviceId,omitempty"`
	Hostname    string                `json:"hostname,omitempty"`
	StartedAt   string                `json:"startedAt,omitempty"`
	EndedAt     string                `json:"endedAt,omitempty"`
	DurationSec int                   `json:"durationSec"`
	Status      string                `json:"status"`
	Reason      string                `json:"reason,omitempty"`
	EventCount  int                   `json:"eventCount"`
	Events      []DiagnosticEventBrief `json:"events,omitempty"`
}

type DiagnosticReproduceRequest struct {
	TemplateID      string   `json:"templateId"`
	DeviceIDs       []string `json:"deviceIds"`
	DurationMinutes int      `json:"durationMinutes"`
	AutoCapture     bool     `json:"autoCapture"`
}

type DiagnosticReproduceStatus struct {
	JobID           string    `json:"jobId"`
	Active          bool      `json:"active"`
	TemplateID      string    `json:"templateId"`
	DeviceIDs       []string  `json:"deviceIds"`
	StartedAt       time.Time `json:"startedAt"`
	ExpiresAt       time.Time `json:"expiresAt"`
	AutoCapture     bool      `json:"autoCapture"`
	CaptureReady    bool      `json:"captureReady"`
	CaptureID       string    `json:"captureId,omitempty"`
	Message         string    `json:"message,omitempty"`
}

type DiagnosticCaptureRequest struct {
	DeviceIDs       []string `json:"deviceIds"`
	WindowMinutes   int      `json:"windowMinutes"`
	IncludeAgents   bool     `json:"includeAgents"`
	IncludeAnalysis bool     `json:"includeAnalysis"`
}

type DiagnosticCaptureResult struct {
	CaptureID   string                 `json:"captureId"`
	GeneratedAt time.Time              `json:"generatedAt"`
	Snapshot    DiagnosticSnapshot     `json:"snapshot"`
	Analysis    *DiagnosticAnalysis    `json:"analysis,omitempty"`
	Pipelines   []DiagnosticPipeline   `json:"pipelines,omitempty"`
	AgentSnaps  map[string]interface{} `json:"agentSnapshots,omitempty"`
	EventCount  int                    `json:"eventCount"`
}

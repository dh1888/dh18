package handlers

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

const (
	NotificationTypeSalaryPaid    = "salary_paid"
	NotificationTypeAnnouncement  = "announcement"
)

type NotificationHandler struct {
	db *sql.DB
}

func NewNotificationHandler(db *sql.DB) *NotificationHandler {
	return &NotificationHandler{db: db}
}

func formatSalaryMonthLabel(yearMonth string) string {
	parts := strings.Split(yearMonth, "-")
	if len(parts) != 2 {
		return yearMonth
	}
	m, err := strconv.Atoi(parts[1])
	if err != nil {
		return yearMonth
	}
	return fmt.Sprintf("%s年%d月", parts[0], m)
}

func formatSalaryMoney(amount float64) string {
	return fmt.Sprintf("%.2f", amount)
}

// CreateSalaryPaidNotification notifies the employee portal user that salary was paid.
func CreateSalaryPaidNotification(ctx context.Context, db *sql.DB, employeeUUID, yearMonth, employeeName string, totalSalary float64) error {
	if db == nil || strings.TrimSpace(employeeUUID) == "" || strings.TrimSpace(yearMonth) == "" {
		return nil
	}
	var userID sql.NullString
	err := db.QueryRowContext(ctx, `
		SELECT user_id::text FROM employees WHERE id = $1 AND status = 1
	`, employeeUUID).Scan(&userID)
	if err != nil || !userID.Valid || strings.TrimSpace(userID.String) == "" {
		return nil
	}

	monthLabel := formatSalaryMonthLabel(yearMonth)
	title := "工资已发放"
	content := fmt.Sprintf("%s，您 %s 的工资已确认发放，实发 ¥%s，请查收。",
		employeeName, monthLabel, formatSalaryMoney(totalSalary))
	payload, _ := json.Marshal(map[string]interface{}{
		"type":         NotificationTypeSalaryPaid,
		"yearMonth":    yearMonth,
		"monthLabel":   monthLabel,
		"totalSalary":  totalSalary,
		"employeeName": employeeName,
	})

	_, err = db.ExecContext(ctx, `
		INSERT INTO user_notifications (id, user_id, type, title, content, payload, is_read, show_popup)
		VALUES ($1, $2, $3, $4, $5, $6, FALSE, TRUE)
	`, uuid.NewString(), userID.String, NotificationTypeSalaryPaid, title, content, payload)
	return err
}

func scanNotification(row interface{ Scan(dest ...interface{}) error }) (map[string]interface{}, error) {
	var id, nType, title, content string
	var payload []byte
	var isRead, showPopup bool
	var createdAt time.Time
	if err := row.Scan(&id, &nType, &title, &content, &payload, &isRead, &showPopup, &createdAt); err != nil {
		return nil, err
	}
	item := map[string]interface{}{
		"id":         id,
		"type":       nType,
		"title":      title,
		"content":    content,
		"isRead":     isRead,
		"showPopup":  showPopup,
		"createdAt":  models.FormatUTC(createdAt),
	}
	if len(payload) > 0 {
		var data map[string]interface{}
		if json.Unmarshal(payload, &data) == nil {
			item["payload"] = data
		}
	}
	return item, nil
}

// ListNotifications returns notifications for the current user.
func (h *NotificationHandler) ListNotifications(c *gin.Context) {
	userID := strings.TrimSpace(c.GetString("userID"))
	if userID == "" {
		models.SendError(c, 401, 1002, "Unauthorized")
		return
	}
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "30"))
	if limit <= 0 {
		limit = 30
	}
	if limit > 100 {
		limit = 100
	}

	rows, err := h.db.QueryContext(c.Request.Context(), `
		SELECT id::text, type, title, content, payload, is_read, show_popup, created_at
		FROM user_notifications
		WHERE user_id = $1
		ORDER BY created_at DESC
		LIMIT $2
	`, userID, limit)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	defer rows.Close()

	items := make([]map[string]interface{}, 0)
	for rows.Next() {
		item, err := scanNotification(rows)
		if err != nil {
			continue
		}
		items = append(items, item)
	}

	var unread int
	_ = h.db.QueryRowContext(c.Request.Context(), `
		SELECT COUNT(*) FROM user_notifications WHERE user_id = $1 AND is_read = FALSE
	`, userID).Scan(&unread)

	models.Send(c, 200, 0, "success", map[string]interface{}{
		"items":        items,
		"unreadCount":  unread,
	})
}

// GetUnreadCount returns unread notification count.
func (h *NotificationHandler) GetUnreadCount(c *gin.Context) {
	userID := strings.TrimSpace(c.GetString("userID"))
	if userID == "" {
		models.SendError(c, 401, 1002, "Unauthorized")
		return
	}
	var unread int
	if err := h.db.QueryRowContext(c.Request.Context(), `
		SELECT COUNT(*) FROM user_notifications WHERE user_id = $1 AND is_read = FALSE
	`, userID).Scan(&unread); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", map[string]interface{}{"unreadCount": unread})
}

// ListPopupNotifications returns notifications that should show as popup.
func (h *NotificationHandler) ListPopupNotifications(c *gin.Context) {
	userID := strings.TrimSpace(c.GetString("userID"))
	if userID == "" {
		models.SendError(c, 401, 1002, "Unauthorized")
		return
	}

	rows, err := h.db.QueryContext(c.Request.Context(), `
		SELECT id::text, type, title, content, payload, is_read, show_popup, created_at
		FROM user_notifications
		WHERE user_id = $1 AND show_popup = TRUE AND is_read = FALSE
		ORDER BY created_at ASC
		LIMIT 10
	`, userID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	defer rows.Close()

	items := make([]map[string]interface{}, 0)
	for rows.Next() {
		item, err := scanNotification(rows)
		if err != nil {
			continue
		}
		items = append(items, item)
	}
	models.Send(c, 200, 0, "success", items)
}

// MarkNotificationRead marks a notification as read.
func (h *NotificationHandler) MarkNotificationRead(c *gin.Context) {
	userID := strings.TrimSpace(c.GetString("userID"))
	id := strings.TrimSpace(c.Param("id"))
	if userID == "" || id == "" {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	_, err := h.db.ExecContext(c.Request.Context(), `
		UPDATE user_notifications SET is_read = TRUE, show_popup = FALSE
		WHERE id = $1 AND user_id = $2
	`, id, userID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

// MarkAllNotificationsRead marks all notifications as read for current user.
func (h *NotificationHandler) MarkAllNotificationsRead(c *gin.Context) {
	userID := strings.TrimSpace(c.GetString("userID"))
	if userID == "" {
		models.SendError(c, 401, 1002, "Unauthorized")
		return
	}
	_, err := h.db.ExecContext(c.Request.Context(), `
		UPDATE user_notifications SET is_read = TRUE, show_popup = FALSE WHERE user_id = $1
	`, userID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

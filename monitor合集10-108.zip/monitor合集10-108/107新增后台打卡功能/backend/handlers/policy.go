package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/security"
	"enterprise-agent/backend/services"
)

type PolicyHandler struct {
	repo             *services.PolicyRepository
	wsHub            *services.WebSocketHub
	clientProtection *services.ClientProtectionService
}

func NewPolicyHandler(repo *services.PolicyRepository, wsHub *services.WebSocketHub, clientProtection *services.ClientProtectionService) *PolicyHandler {
	return &PolicyHandler{repo: repo, wsHub: wsHub, clientProtection: clientProtection}
}

func (h *PolicyHandler) applyClientProtectionFromPolicy(c *gin.Context, policy *models.Policy) {
	if h.clientProtection == nil || policy == nil {
		return
	}
	if err := h.clientProtection.SyncSystemDefaultsFromPolicyContent(c.Request.Context(), policy.Content); err != nil {
		Log(c, "UPDATE", "POLICY", "同步客户端防护默认失败: "+err.Error(), policy.ID.String(), policy.Name)
	}
}

// PolicyCurrentAgentResponse is the Agent-facing current policy payload (V2.1).
type PolicyCurrentAgentResponse struct {
	ID               uuid.UUID       `json:"id"`
	Name             string          `json:"name"`
	Version          int             `json:"version"`
	Status           int             `json:"status"`
	IsCurrent        bool            `json:"isCurrent"`
	Policy           json.RawMessage `json:"policy"`
	Content          string          `json:"content,omitempty"`
	Signature        string          `json:"signature"`
	SignatureAlg     string          `json:"signatureAlg"`
	SignatureVersion int             `json:"signatureVersion"`
	KeyID            string          `json:"keyId"`
	CreatedAt        time.Time       `json:"createdAt"`
	UpdatedAt        time.Time       `json:"updatedAt"`
}

func (h *PolicyHandler) List(c *gin.Context) {
	policies, err := h.repo.List(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", policies)
}

func (h *PolicyHandler) GetCurrent(c *gin.Context) {
	policy, err := h.repo.GetCurrent(c.Request.Context())
	if err != nil {
		models.SendError(c, 404, 2001, "No policy found")
		return
	}

	response, err := h.buildSignedAgentResponse(policy)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", response)
}

func (h *PolicyHandler) Create(c *gin.Context) {
	var req struct {
		Name    string          `json:"name"`
		Content json.RawMessage `json:"content"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if len(req.Content) == 0 {
		models.SendError(c, 400, 1001, "Policy content is required")
		return
	}

	payload, err := security.NormalizePolicySignPayloadFromJSON(req.Content)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	policy := &models.Policy{
		ID:        uuid.New(),
		Name:      req.Name,
		Version:   payload.Version,
		Content:   string(req.Content),
		Signature: "",
		Status:    0,
		CreatedAt: models.UTCNow(),
	}
	if err := h.repo.Create(c.Request.Context(), policy); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "CREATE", "POLICY", fmt.Sprintf("创建监控策略：%s", policy.Name), policy.ID.String(), policy.Name)
	models.Send(c, 200, 0, "Policy created", policy)
}

func (h *PolicyHandler) Publish(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid policy ID")
		return
	}

	policy, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "Policy not found")
		return
	}

	if err := h.repo.SetCurrent(c.Request.Context(), policy); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	policy, err = h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	h.applyClientProtectionFromPolicy(c, policy)
	h.broadcastPolicyUpdate(policy)
	Log(c, "UPDATE", "POLICY", fmt.Sprintf("发布监控策略：%s", policy.Name), policy.ID.String(), policy.Name)
	models.Send(c, 200, 0, "Policy published", nil)
}

func (h *PolicyHandler) Rollback(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid policy ID")
		return
	}

	policy, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "Policy not found")
		return
	}

	if err := h.repo.SetCurrent(c.Request.Context(), policy); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	h.applyClientProtectionFromPolicy(c, policy)
	h.broadcastPolicyUpdate(policy)
	Log(c, "UPDATE", "POLICY", fmt.Sprintf("回滚监控策略：%s", policy.Name), policy.ID.String(), policy.Name)
	models.Send(c, 200, 0, "Policy rolled back", nil)
}

func (h *PolicyHandler) buildSignedAgentResponse(policy *models.Policy) (*PolicyCurrentAgentResponse, error) {
	if policy == nil {
		return nil, fmt.Errorf("policy is nil")
	}

	signed, err := security.SignPolicyContent(policy.Content)
	if err != nil {
		return nil, err
	}

	policyJSON, err := signed.Policy.MarshalPolicyObject()
	if err != nil {
		return nil, err
	}

	return &PolicyCurrentAgentResponse{
		ID:               policy.ID,
		Name:             policy.Name,
		Version:          policy.Version,
		Status:           policy.Status,
		IsCurrent:        policy.IsCurrent,
		Policy:           policyJSON,
		Content:          policy.Content,
		Signature:        signed.Signature,
		SignatureAlg:     signed.SignatureAlg,
		SignatureVersion: signed.SignatureVersion,
		KeyID:            signed.KeyID,
		CreatedAt:        policy.CreatedAt,
		UpdatedAt:        policy.UpdatedAt,
	}, nil
}

func (h *PolicyHandler) broadcastPolicyUpdate(policy *models.Policy) {
	if h.wsHub == nil || policy == nil {
		return
	}

	signed, err := security.SignPolicyContent(policy.Content)
	if err != nil {
		return
	}

	policyJSON, err := signed.Policy.MarshalPolicyObject()
	if err != nil {
		return
	}

	h.wsHub.SendCriticalToAllAgents(gin.H{
		"type":             "policy_update",
		"version":          policy.Version,
		"policy":           json.RawMessage(policyJSON),
		"content":          policy.Content,
		"signature":        signed.Signature,
		"signatureAlg":     signed.SignatureAlg,
		"signatureVersion": signed.SignatureVersion,
		"keyId":            signed.KeyID,
	})
}

func (h *PolicyHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid policy ID")
		return
	}

	policy, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "Policy not found")
		return
	}

	models.Send(c, http.StatusOK, 0, "success", policy)
}

func (h *PolicyHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid policy ID")
		return
	}

	policy, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "Policy not found")
		return
	}

	var req struct {
		Name    string          `json:"name"`
		Content json.RawMessage `json:"content"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if len(req.Content) == 0 {
		models.SendError(c, 400, 1001, "Policy content is required")
		return
	}

	payload, err := security.NormalizePolicySignPayloadFromJSON(req.Content)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	policy.Name = req.Name
	policy.Version = payload.Version
	policy.Content = string(req.Content)
	policy.Signature = ""
	policy.UpdatedAt = models.UTCNow()

	wasCurrent := policy.IsCurrent

	if err := h.repo.Update(c.Request.Context(), policy); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	if wasCurrent {
		policy.IsCurrent = true
		h.applyClientProtectionFromPolicy(c, policy)
		h.broadcastPolicyUpdate(policy)
	}

	Log(c, "UPDATE", "POLICY", fmt.Sprintf("修改监控策略：%s", policy.Name), policy.ID.String(), policy.Name)
	models.Send(c, 200, 0, "Policy updated", policy)
}

func (h *PolicyHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid policy ID")
		return
	}

	if err := h.repo.Delete(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "DELETE", "POLICY", fmt.Sprintf("删除监控策略：%s", id.String()), id.String(), id.String())
	models.Send(c, 200, 0, "Policy deleted", nil)
}

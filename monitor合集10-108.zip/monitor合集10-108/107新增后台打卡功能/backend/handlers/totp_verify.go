package handlers

import (
	"database/sql"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/services"
)

// VerifyCurrentUserTotp validates the Google Authenticator code for the logged-in user.
func VerifyCurrentUserTotp(c *gin.Context, db *sql.DB, totpCode string) error {
	totpCode = strings.TrimSpace(totpCode)
	if totpCode == "" {
		return errTotpRequired
	}

	userID := strings.TrimSpace(c.GetString("userID"))
	id, err := uuid.Parse(userID)
	if err != nil {
		return errInvalidUser
	}

	var totpEnabled bool
	var totpSecretEnc sql.NullString
	err = db.QueryRowContext(c.Request.Context(), `
		SELECT COALESCE(totp_enabled, FALSE), totp_secret
		FROM users WHERE id = $1
	`, id).Scan(&totpEnabled, &totpSecretEnc)
	if err == sql.ErrNoRows {
		return errInvalidUser
	}
	if err != nil {
		return err
	}
	if !totpEnabled || !totpSecretEnc.Valid || strings.TrimSpace(totpSecretEnc.String) == "" {
		return errTotpNotBound
	}

	secret, err := services.DecryptTotpSecret(totpSecretEnc.String)
	if err != nil {
		return err
	}
	if !services.ValidateTotpCode(secret, totpCode) {
		return errInvalidTotpCode
	}
	return nil
}

package handlers

import (
	"database/sql"
	"os"
	"strings"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type MetaHandler struct {
	db *sql.DB
}

func NewMetaHandler(db *sql.DB) *MetaHandler {
	return &MetaHandler{db: db}
}

// Capabilities exposes client-facing runtime flags (no auth required).
func (h *MetaHandler) Capabilities(c *gin.Context) {
	models.Send(c, 200, 0, "success", gin.H{
		"wsTicketRequired": services.WSTicketRequired(),
	})
}

// ClientRelease exposes installer/update metadata for agents (no auth required).
func (h *MetaHandler) ClientRelease(c *gin.Context) {
	release := services.ClientReleaseFromEnv()
	downloadURL := release.DownloadURL
	updateURL := release.UpdatePackageURL
	if downloadURL != "" && !strings.HasPrefix(downloadURL, "http") {
		downloadURL = absolutePublicURL(c, downloadURL)
	}
	if updateURL != "" && !strings.HasPrefix(updateURL, "http") {
		updateURL = absolutePublicURL(c, updateURL)
	}
	models.Send(c, 200, 0, "success", gin.H{
		"version":          release.Version,
		"fileName":           release.FileName,
		"downloadUrl":        downloadURL,
		"updatePackageUrl":   updateURL,
		"sha256":             release.Sha256,
		"updateSha256":       release.UpdateSha256,
		"available":          release.Available,
		"mode":               release.Mode,
	})
}

func (h *MetaHandler) DownloadUpdatePackage(c *gin.Context) {
	localPath, fileName := services.ResolveClientUpdatePackage()
	if _, err := os.Stat(localPath); err != nil {
		models.SendError(c, 404, 3001, "Client update package not found")
		return
	}
	c.Header("Content-Disposition", "attachment; filename="+fileName)
	c.Header("Content-Type", "application/octet-stream")
	c.File(localPath)
}

func absolutePublicURL(c *gin.Context, path string) string {
	if strings.HasPrefix(path, "http://") || strings.HasPrefix(path, "https://") {
		return path
	}
	scheme := "https"
	if c.Request.TLS == nil {
		scheme = "http"
	}
	if fwd := c.GetHeader("X-Forwarded-Proto"); fwd != "" {
		scheme = strings.TrimSpace(strings.Split(fwd, ",")[0])
	}
	return scheme + "://" + c.Request.Host + path
}

func (h *MetaHandler) Modules(c *gin.Context) {
	dmEnabled := strings.EqualFold(strings.TrimSpace(os.Getenv("DOMAIN_MONITOR_ENABLED")), "true")
	cbEnv := strings.ToLower(strings.TrimSpace(os.Getenv("CALLBACK_ENABLED")))
	callbackEnabled := cbEnv != "false" && cbEnv != "0"
	models.Send(c, 200, 0, "success", gin.H{
		"domainMonitor":            dmEnabled,
		"callback":                 callbackEnabled,
		"telegramAttendance":       services.TelegramAttendanceEnabled(),
		"captureLinkedToCheckin":   services.CaptureLinkedToCheckin(c.Request.Context(), h.db),
		"telegramAgentCapture":     services.CaptureLinkedToCheckin(c.Request.Context(), h.db), // legacy alias
		"wsTicketRequired":         services.WSTicketRequired(),
	})
}

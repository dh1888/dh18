package handlers

import (
	"strings"
	"testing"

	"github.com/google/uuid"
)

func TestUploadSessionCheckOwner(t *testing.T) {
	t.Parallel()

	sess := &uploadSession{DeviceID: "device-owner-abc"}

	if err := sess.checkOwner("device-owner-abc"); err != nil {
		t.Fatalf("expected same device to pass: %v", err)
	}
	if err := sess.checkOwner("DEVICE-OWNER-ABC"); err != nil {
		t.Fatalf("expected case-insensitive match: %v", err)
	}
	if err := sess.checkOwner("other-device"); err == nil {
		t.Fatal("expected mismatch error")
	} else if !strings.Contains(err.Error(), "mismatch") {
		t.Fatalf("unexpected error: %v", err)
	}
	if err := sess.checkOwner(""); err == nil {
		t.Fatal("expected empty owner to fail")
	}

	unbound := &uploadSession{}
	if err := unbound.checkOwner("device-a"); err == nil {
		t.Fatal("expected unbound session to fail")
	} else if !strings.Contains(err.Error(), "no owner") {
		t.Fatalf("unexpected error: %v", err)
	}
}

func TestGetOrCreateBindsDeviceAndRejectsHijack(t *testing.T) {
	t.Parallel()

	mgr := &uploadSessionManager{sessions: make(map[string]*uploadSession)}
	uploadID := "test-" + uuid.NewString()
	req := &chunkUpload{
		UploadID:    uploadID,
		FileName:    "clip.mp4",
		FileType:    "recording",
		FileID:      "file-1",
		TotalChunks: 2,
	}
	owner := "device-owner-111"
	hijacker := "device-hijacker-222"

	created, err := mgr.getOrCreate(req, owner)
	if err != nil {
		t.Fatalf("create session: %v", err)
	}
	if created.DeviceID != owner {
		t.Fatalf("expected DeviceID %q, got %q", owner, created.DeviceID)
	}

	reused, err := mgr.getOrCreate(req, owner)
	if err != nil {
		t.Fatalf("reuse session: %v", err)
	}
	if reused != created {
		t.Fatal("expected same session instance for same owner")
	}

	if _, err := mgr.getOrCreate(req, hijacker); err == nil {
		t.Fatal("expected hijacker to be rejected")
	} else if !strings.Contains(err.Error(), "mismatch") {
		t.Fatalf("unexpected error: %v", err)
	}
}

func TestGetOrCreateRequiresAuthenticatedDevice(t *testing.T) {
	t.Parallel()

	mgr := &uploadSessionManager{sessions: make(map[string]*uploadSession)}
	req := &chunkUpload{UploadID: "test-" + uuid.NewString(), TotalChunks: 1}

	if _, err := mgr.getOrCreate(req, ""); err == nil {
		t.Fatal("expected empty device ID to fail")
	} else if !strings.Contains(err.Error(), "not authenticated") {
		t.Fatalf("unexpected error: %v", err)
	}
}

package handlers

import (
	"fmt"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

const maxEmployeeAccountImportRows = 2000

type employeeAccountImportRow struct {
	Name        string
	AccountName string
}

func isEmployeeAccountHeaderRow(name, account string) bool {
	nameNorm := normalizeSiteStatsHeader(name)
	accountNorm := normalizeSiteStatsHeader(account)
	if nameNorm == "" && accountNorm == "" {
		return false
	}

	nameHeaders := []string{"员工姓名", "姓名", "name", "员工名", "名字"}
	accountHeaders := []string{"员工账号", "后台账号", "账号", "account", "accountname", "account_name", "登录账号"}

	for _, key := range nameHeaders {
		if nameNorm == normalizeSiteStatsHeader(key) || strings.Contains(nameNorm, normalizeSiteStatsHeader(key)) {
			return true
		}
	}
	for _, key := range accountHeaders {
		if accountNorm == normalizeSiteStatsHeader(key) || strings.Contains(accountNorm, normalizeSiteStatsHeader(key)) {
			return true
		}
	}
	return false
}

func parseEmployeeAccountImportRows(rows [][]string) ([]employeeAccountImportRow, error) {
	items := make([]employeeAccountImportRow, 0, len(rows))
	seenAccounts := make(map[string]struct{})

	for rowIdx, row := range rows {
		name := ""
		accountName := ""
		if len(row) > 0 {
			name = strings.TrimSpace(row[0])
		}
		if len(row) > 1 {
			accountName = strings.TrimSpace(row[1])
		}

		if name == "" && accountName == "" {
			continue
		}
		if rowIdx == 0 && isEmployeeAccountHeaderRow(name, accountName) {
			continue
		}
		if name == "" {
			return nil, fmt.Errorf("第 %d 行缺少员工姓名（A列）", rowIdx+1)
		}
		if accountName == "" {
			return nil, fmt.Errorf("第 %d 行缺少员工账号（B列）", rowIdx+1)
		}

		accountKey := strings.ToLower(accountName)
		if _, exists := seenAccounts[accountKey]; exists {
			return nil, fmt.Errorf("第 %d 行账号 %s 在文件中重复", rowIdx+1, accountName)
		}
		seenAccounts[accountKey] = struct{}{}

		items = append(items, employeeAccountImportRow{
			Name:        name,
			AccountName: accountName,
		})
		if len(items) > maxEmployeeAccountImportRows {
			return nil, fmt.Errorf("单次最多导入 %d 条记录", maxEmployeeAccountImportRows)
		}
	}

	if len(items) == 0 {
		return nil, fmt.Errorf("未读取到有效数据，请确认 A 列为员工姓名、B 列为员工账号")
	}
	return items, nil
}

// ImportEmployeeAccounts 批量导入出款站点员工账号（A列姓名，B列账号）
func (h *AdminHandler) ImportEmployeeAccounts(c *gin.Context) {
	siteID := strings.TrimSpace(c.PostForm("site_id"))
	shift := strings.TrimSpace(c.PostForm("shift"))

	if siteID == "" {
		models.SendError(c, 400, 1001, "site_id 不能为空")
		return
	}
	if shift == "" {
		models.SendError(c, 400, 1001, "shift 不能为空")
		return
	}
	if shift != "day" && shift != "night" {
		models.SendError(c, 400, 1001, "shift 无效")
		return
	}

	siteUUID, err := uuid.Parse(siteID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid site_id")
		return
	}

	var siteCode, siteName string
	if err := h.db.QueryRow(`SELECT code, name FROM sites WHERE id=$1`, siteUUID).Scan(&siteCode, &siteName); err != nil {
		models.SendError(c, 400, 1001, "站点不存在")
		return
	}

	file, err := c.FormFile("file")
	if err != nil {
		models.SendError(c, 400, 1001, "请上传文件")
		return
	}

	rows, err := readSiteStatsRowsFromFileHeader(file)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	items, err := parseEmployeeAccountImportRows(rows)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	createdCount := 0
	updatedCount := 0

	for _, item := range items {
		var existingID string
		err := h.db.QueryRow(
			`SELECT id::text FROM employee_accounts WHERE site_id = $1 AND account_name = $2`,
			siteUUID, item.AccountName,
		).Scan(&existingID)

		if err == nil && existingID != "" {
			_, err = h.db.Exec(`
				UPDATE employee_accounts
				SET name = $1, shift = $2, is_active = true, updated_at = NOW()
				WHERE id = $3
			`, item.Name, shift, existingID)
			if err != nil {
				models.SendError(c, 500, 5000, fmt.Sprintf("更新账号 %s 失败: %v", item.AccountName, err))
				return
			}
			updatedCount++
			continue
		}

		id := uuid.New()
		_, err = h.db.Exec(`
			INSERT INTO employee_accounts (id, site_id, name, account_name, shift, is_active, created_at)
			VALUES ($1, $2, $3, $4, $5, true, NOW())
		`, id, siteUUID, item.Name, item.AccountName, shift)
		if err != nil {
			models.SendError(c, 500, 5000, fmt.Sprintf("导入账号 %s 失败: %v", item.AccountName, err))
			return
		}
		createdCount++
	}

	shiftLabel := shift
	if shift == "day" {
		shiftLabel = "A班"
	} else if shift == "night" {
		shiftLabel = "B班"
	}
	Log(c, "CREATE", "SITE_STATS",
		fmt.Sprintf("导入出款员工账号：站点 %s，%s，新增 %d 条，更新 %d 条", siteCode, shiftLabel, createdCount, updatedCount),
		siteID, siteName)

	models.Send(c, 200, 0, "Import completed", gin.H{
		"created": createdCount,
		"updated": updatedCount,
		"total":   len(items),
	})
}

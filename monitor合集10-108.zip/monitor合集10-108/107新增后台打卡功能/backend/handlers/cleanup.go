package handlers

import (
	"context"
	"errors"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type CleanupHandler struct {
	repo *services.CleanupRepository
}

func NewCleanupHandler(repo *services.CleanupRepository) *CleanupHandler {
	return &CleanupHandler{repo: repo}
}

func (h *CleanupHandler) GetCleanupPolicy(c *gin.Context) {
	policy, err := h.repo.GetPolicy(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", policy)
}

func (h *CleanupHandler) UpdateCleanupPolicy(c *gin.Context) {
	var policy models.CleanupPolicy
	if err := c.ShouldBindJSON(&policy); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if err := validateCleanupPolicy(policy); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if err := h.repo.UpdatePolicy(c.Request.Context(), &policy); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	updated, err := h.repo.GetPolicy(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "POLICY", "修改存储清理策略", "", "")
	models.Send(c, 200, 0, "Cleanup policy updated", updated)
}

func (h *CleanupHandler) GetStorageStats(c *gin.Context) {
	stats, err := h.repo.GetStorageStats(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", stats)
}

func (h *CleanupHandler) ManualCleanup(c *gin.Context) {
	logEntry, err := h.repo.ManualCleanup(c.Request.Context(), "manual")
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "CREATE", "POLICY",
		fmt.Sprintf("手动执行存储清理（删除录屏 %d、截图 %d、日志/历史 %d、业务 %d）",
			logEntry.DeletedRecordings, logEntry.DeletedScreenshots, logEntry.DeletedLogs, logEntry.DeletedBusinessRecords),
		"", "存储清理")
	models.Send(c, 200, 0, "Manual cleanup completed", logEntry)
}

func (h *CleanupHandler) GetCleanupLogs(c *gin.Context) {
	// 获取分页参数
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "20"))
	
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 20
	}
	if pageSize > 100 {
		pageSize = 100
	}
	
	logs, total, err := h.repo.GetLogsWithPagination(c.Request.Context(), page, pageSize)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	
	models.Send(c, 200, 0, "success", gin.H{
		"items":    logs,
		"total":    total,
		"page":     page,
		"pageSize": pageSize,
	})
}

func validateCleanupPolicy(policy models.CleanupPolicy) error {
	if policy.RecordingRetentionDays < 0 || policy.ScreenshotRetentionDays < 0 || policy.LogRetentionDays < 0 {
		return errors.New("retention days must be non-negative")
	}
	if policy.AttendanceRetentionMonths < 0 || policy.PerformanceRetentionMonths < 0 ||
		policy.PenaltyRetentionMonths < 0 || policy.SalaryRetentionMonths < 0 ||
		policy.SiteStatsRetentionMonths < 0 {
		return errors.New("business retention months must be non-negative")
	}
	if policy.DiskUsageThresholdPercent < 1 || policy.DiskUsageThresholdPercent > 100 {
		return errors.New("disk usage threshold must be between 1 and 100")
	}
	if policy.CleanupIntervalMinutes < 1 {
		return errors.New("cleanup interval must be at least 1 minute")
	}
	return nil
}

var _ = context.Background

package handlers

import (
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type RemoteViewHandler struct {
	svc *services.RemoteViewService
}

func NewRemoteViewHandler(svc *services.RemoteViewService) *RemoteViewHandler {
	return &RemoteViewHandler{svc: svc}
}

func (h *RemoteViewHandler) Start(c *gin.Context) {
	deviceID := c.Param("id")
	if deviceID == "" {
		models.SendError(c, 400, 1001, "Device ID is required")
		return
	}
	if _, err := uuid.Parse(deviceID); err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID format")
		return
	}

	userID := c.GetString("userID")
	username := c.GetString("username")
	if userID == "" {
		models.SendError(c, 401, 1002, "Unauthorized")
		return
	}

	var body struct {
		Quality        string `json:"quality"`
		NetworkProfile string `json:"networkProfile"`
		FreshStart     bool   `json:"freshStart"`
	}
	_ = c.ShouldBindJSON(&body)
	quality := body.NetworkProfile
	if quality == "" {
		quality = body.Quality
	}

	resp, err := h.svc.StartSession(c.Request.Context(), deviceID, userID, username, c.ClientIP(), quality, body.FreshStart)
	if err != nil {
		msg := err.Error()
		switch msg {
		case "device is not connected":
			models.SendError(c, 400, 2002, msg)
		case "livekit is not configured":
			models.SendError(c, 503, 5001, msg)
		default:
			if strings.Contains(msg, "ingress not connected") || strings.Contains(msg, "redis required") {
				models.SendError(c, 503, 5002, "LiveKit Ingress 未就绪：需要 Redis + ingress 服务，见 docs/livekit-docker-compose.yml")
				return
			}
			if strings.Contains(msg, "permissions denied") || strings.Contains(msg, "unauthenticated") {
				models.SendError(c, 503, 5001, "LiveKit API 认证失败，请检查 LIVEKIT_API_KEY/SECRET")
				return
			}
			models.SendError(c, 500, 5000, msg)
		}
		return
	}

	Log(c, "VIEW", "REMOTE_VIEW", "发起远程查看", deviceID, deviceID)
	models.Send(c, 200, 0, "success", resp)
}

func (h *RemoteViewHandler) UpdateQuality(c *gin.Context) {
	deviceID := c.Param("id")
	if deviceID == "" {
		models.SendError(c, 400, 1001, "Device ID is required")
		return
	}
	if _, err := uuid.Parse(deviceID); err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID format")
		return
	}

	var body struct {
		SessionID      string `json:"sessionId"`
		Quality        string `json:"quality"`
		NetworkProfile string `json:"networkProfile"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		models.SendError(c, 400, 1001, "Invalid request body")
		return
	}
	quality := body.NetworkProfile
	if quality == "" {
		quality = body.Quality
	}
	if quality == "" {
		models.SendError(c, 400, 1001, "quality or networkProfile is required")
		return
	}

	userID := c.GetString("userID")
	username := c.GetString("username")

	profile, err := h.svc.UpdateQuality(
		c.Request.Context(),
		deviceID,
		body.SessionID,
		quality,
		userID,
		username,
		c.ClientIP(),
	)
	if err != nil {
		switch err.Error() {
		case "no active remote view session":
			models.SendError(c, 404, 2003, err.Error())
		case "session does not belong to device":
			models.SendError(c, 403, 2004, err.Error())
		case "session not found":
			models.SendError(c, 404, 2003, err.Error())
		case "device is not connected":
			models.SendError(c, 400, 2002, err.Error())
		case "livekit is not configured":
			models.SendError(c, 503, 5001, err.Error())
		default:
			models.SendError(c, 500, 5000, err.Error())
		}
		return
	}

	Log(c, "UPDATE", "REMOTE_VIEW", "调整远程查看画质："+quality, deviceID, deviceID)
	models.Send(c, 200, 0, "success", gin.H{
		"deviceId":       deviceID,
		"networkProfile": profile,
		"updated":        true,
	})
}

func (h *RemoteViewHandler) Stop(c *gin.Context) {
	deviceID := c.Param("id")
	if deviceID == "" {
		models.SendError(c, 400, 1001, "Device ID is required")
		return
	}

	var body struct {
		SessionID string `json:"sessionId"`
		Hard      bool   `json:"hard"`
	}
	_ = c.ShouldBindJSON(&body)

	userID := c.GetString("userID")
	username := c.GetString("username")

	publisherStopped, err := h.svc.StopSession(
		c.Request.Context(),
		deviceID,
		userID,
		username,
		body.SessionID,
		c.ClientIP(),
		body.Hard,
	)
	if err != nil {
		switch err.Error() {
		case "session does not belong to device":
			models.SendError(c, 403, 2004, err.Error())
		case "session not found":
			models.SendError(c, 404, 2003, err.Error())
		default:
			models.SendError(c, 404, 2003, err.Error())
		}
		return
	}

	Log(c, "VIEW", "REMOTE_VIEW", "结束远程查看", deviceID, deviceID)
	models.Send(c, 200, 0, "success", gin.H{
		"deviceId":         deviceID,
		"stopped":          true,
		"publisherStopped": publisherStopped,
	})
}

func (h *RemoteViewHandler) Status(c *gin.Context) {
	deviceID := c.Param("id")
	if deviceID == "" {
		models.SendError(c, 400, 1001, "Device ID is required")
		return
	}

	resp, err := h.svc.GetStatus(c.Request.Context(), deviceID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", resp)
}

func (h *RemoteViewHandler) AuditLogs(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "20"))

	var deviceID *uuid.UUID
	if id := c.Query("deviceId"); id != "" {
		parsed, err := uuid.Parse(id)
		if err != nil {
			models.SendError(c, 400, 1001, "Invalid device ID format")
			return
		}
		deviceID = &parsed
	}

	logs, total, err := h.svc.ListAuditLogs(c.Request.Context(), deviceID, page, pageSize)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	for i := range logs {
		logs[i].Action = NormalizeRemoteViewAuditAction(logs[i].Action)
		logs[i].Detail = FormatRemoteViewAuditDetail(logs[i].Detail)
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items":    logs,
		"total":    total,
		"page":     page,
		"pageSize": pageSize,
	})
}

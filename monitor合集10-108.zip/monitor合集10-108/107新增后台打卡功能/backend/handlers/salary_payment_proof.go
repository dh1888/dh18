package handlers

import (
	"database/sql"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/models"
)

var allowedPaymentProofExts = map[string]string{
	".jpg":  "image/jpeg",
	".jpeg": "image/jpeg",
	".png":  "image/png",
	".gif":  "image/gif",
	".webp": "image/webp",
	".bmp":  "image/bmp",
}

func salaryUploadsDir() string {
	dir := strings.TrimSpace(os.Getenv("UPLOADS_DIR"))
	if dir == "" {
		dir = "./uploads"
	}
	abs, err := filepath.Abs(dir)
	if err != nil {
		return dir
	}
	return abs
}

func validatePaymentProofFile(filename string, size int64) (ext, contentType string, err error) {
	if size <= 0 {
		return "", "", fmt.Errorf("文件为空")
	}
	if size > 10*1024*1024 {
		return "", "", fmt.Errorf("文件不能超过 10MB")
	}
	ext = strings.ToLower(filepath.Ext(filename))
	contentType, ok := allowedPaymentProofExts[ext]
	if !ok {
		return "", "", fmt.Errorf("仅支持 JPG、PNG、GIF、WEBP、BMP 图片")
	}
	return ext, contentType, nil
}

func (h *AdminHandler) ensureSalaryPaymentProofAccess(c *gin.Context, proofEmployeeID string) bool {
	if middleware.UserHasPermission(c, "salary:upload") {
		return true
	}
	proofEmployeeID = strings.TrimSpace(proofEmployeeID)
	empID, err := h.resolveEmployeeIDForCurrentUser(c)
	if err != nil {
		if err == errEmployeeNotFound {
			models.SendError(c, 404, 2001, "未找到员工信息")
		} else {
			models.SendInternalError(c, err)
		}
		return false
	}
	if proofEmployeeID != empID {
		models.SendError(c, 403, 1003, "无权查看该打款截图")
		return false
	}
	return true
}

// UploadSalaryPaymentProof 上传工资打款截图
func (h *AdminHandler) UploadSalaryPaymentProof(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		models.SendError(c, 400, 1001, "请选择打款截图")
		return
	}
	employeeID := strings.TrimSpace(c.PostForm("employeeId"))
	yearMonth := strings.TrimSpace(c.PostForm("yearMonth"))
	if employeeID == "" || yearMonth == "" {
		models.SendError(c, 400, 1001, "请提供员工与工资月份")
		return
	}
	if _, err := uuid.Parse(employeeID); err != nil {
		models.SendError(c, 400, 1001, "员工 ID 无效")
		return
	}

	ext, contentType, err := validatePaymentProofFile(file.Filename, file.Size)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	var employeeName string
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT name FROM employees WHERE id = $1 AND status = 1
	`, employeeID).Scan(&employeeName)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "员工不存在")
		return
	}
	if err != nil {
		models.SendInternalError(c, err)
		return
	}

	uploadsDir := salaryUploadsDir()
	relDir := filepath.Join("salary-proofs", employeeID, yearMonth)
	absDir := filepath.Join(uploadsDir, relDir)
	if err := os.MkdirAll(absDir, 0o755); err != nil {
		models.SendInternalError(c, err)
		return
	}

	proofID := uuid.NewString()
	fileName := proofID + ext
	relPath := filepath.ToSlash(filepath.Join(relDir, fileName))
	absPath := filepath.Join(uploadsDir, relPath)

	src, err := file.Open()
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	defer src.Close()

	dst, err := os.Create(absPath)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if _, err := io.Copy(dst, src); err != nil {
		dst.Close()
		os.Remove(absPath)
		models.SendInternalError(c, err)
		return
	}
	dst.Close()

	uploaderID := strings.TrimSpace(c.GetString("userID"))
	var oldRelPath sql.NullString
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT file_path FROM salary_payment_proofs
		WHERE employee_id = $1 AND year_month = $2
	`, employeeID, yearMonth).Scan(&oldRelPath)

	if err == sql.ErrNoRows {
		_, err = h.db.ExecContext(c.Request.Context(), `
			INSERT INTO salary_payment_proofs (
				id, employee_id, year_month, file_path, file_name, content_type, uploaded_by
			) VALUES ($1, $2, $3, $4, $5, $6, NULLIF($7, '')::uuid)
		`, proofID, employeeID, yearMonth, relPath, file.Filename, contentType, uploaderID)
	} else if err == nil {
		_, err = h.db.ExecContext(c.Request.Context(), `
			UPDATE salary_payment_proofs SET
				id = $1, file_path = $2, file_name = $3, content_type = $4,
				uploaded_by = NULLIF($5, '')::uuid, uploaded_at = NOW()
			WHERE employee_id = $6 AND year_month = $7
		`, proofID, relPath, file.Filename, contentType, uploaderID, employeeID, yearMonth)
		if oldRelPath.Valid {
			oldAbs := filepath.Join(uploadsDir, filepath.FromSlash(oldRelPath.String))
			_ = os.Remove(oldAbs)
		}
	}
	if err != nil {
		os.Remove(absPath)
		models.SendInternalError(c, err)
		return
	}

	Log(c, models.OperationTypeUpload, models.OperationModuleSalary,
		fmt.Sprintf("上传打款截图：%s %s", employeeName, yearMonth),
		proofID, employeeName)

	models.Send(c, 200, 0, "上传成功", map[string]interface{}{
		"id":         proofID,
		"employeeId": employeeID,
		"yearMonth":  yearMonth,
		"fileName":   file.Filename,
	})
}

// GetSalaryPaymentProof 查询指定员工月份的打款截图
func (h *AdminHandler) GetSalaryPaymentProof(c *gin.Context) {
	employeeID := strings.TrimSpace(c.Query("employeeId"))
	yearMonth := strings.TrimSpace(c.Query("yearMonth"))
	if employeeID == "" || yearMonth == "" {
		models.SendError(c, 400, 1001, "请提供 employeeId 与 yearMonth")
		return
	}
	if !middleware.UserHasPermission(c, "salary:upload") {
		if !h.ensureSalaryPaymentProofAccess(c, employeeID) {
			return
		}
	}

	var id, fileName, contentType string
	var uploadedAt time.Time
	var uploadedBy sql.NullString
	err := h.db.QueryRowContext(c.Request.Context(), `
		SELECT id::text, file_name, content_type, uploaded_at, uploaded_by::text
		FROM salary_payment_proofs
		WHERE employee_id = $1 AND year_month = $2
	`, employeeID, yearMonth).Scan(&id, &fileName, &contentType, &uploadedAt, &uploadedBy)
	if err == sql.ErrNoRows {
		models.Send(c, 200, 0, "success", nil)
		return
	}
	if err != nil {
		models.SendInternalError(c, err)
		return
	}

	item := map[string]interface{}{
		"id":          id,
		"employeeId":  employeeID,
		"yearMonth":   yearMonth,
		"fileName":    fileName,
		"contentType": contentType,
		"uploadedAt":  models.FormatUTC(uploadedAt),
	}
	if uploadedBy.Valid {
		item["uploadedBy"] = uploadedBy.String
	}
	models.Send(c, 200, 0, "success", item)
}

// GetSalaryPaymentProofFile 返回打款截图文件（inline 预览）
func (h *AdminHandler) GetSalaryPaymentProofFile(c *gin.Context) {
	id := strings.TrimSpace(c.Param("id"))
	if _, err := uuid.Parse(id); err != nil {
		models.SendError(c, 400, 1001, "Invalid proof ID")
		return
	}

	var relPath, contentType, employeeID string
	err := h.db.QueryRowContext(c.Request.Context(), `
		SELECT file_path, content_type, employee_id::text FROM salary_payment_proofs WHERE id = $1
	`, id).Scan(&relPath, &contentType, &employeeID)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "打款截图不存在")
		return
	}
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if !h.ensureSalaryPaymentProofAccess(c, employeeID) {
		return
	}

	absPath := filepath.Join(salaryUploadsDir(), filepath.FromSlash(relPath))
	if _, err := os.Stat(absPath); err != nil {
		models.SendError(c, 404, 2001, "文件不存在")
		return
	}

	if contentType == "" {
		contentType = "application/octet-stream"
	}
	c.Header("Cache-Control", "private, max-age=3600")
	c.Header("Content-Type", contentType)
	c.Header("Content-Disposition", "inline")
	http.ServeFile(c.Writer, c.Request, absPath)
}

package handlers

import (
	"database/sql"
	"errors"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

func (h *SettingsHandler) GetClientProtectionDefaults(c *gin.Context) {
	if h.clientProtection == nil {
		models.SendError(c, 500, 5000, "client protection not configured")
		return
	}
	cfg, err := h.clientProtection.GetSystemDefaults(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", cfg)
}

func (h *SettingsHandler) UpdateClientProtectionDefaults(c *gin.Context) {
	if h.clientProtection == nil {
		models.SendError(c, 500, 5000, "client protection not configured")
		return
	}
	var req struct {
		AllowUserExit                 bool `json:"allowUserExit"`
		AllowAutoStartToggle          bool `json:"allowAutoStartToggle"`
		RestartOnKill                 bool `json:"restartOnKill"`
		UnlockCodeUnusedExpireMinutes int  `json:"unlockCodeUnusedExpireMinutes"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	cfg, err := h.clientProtection.SaveSystemDefaults(
		c.Request.Context(),
		req.AllowUserExit,
		req.AllowAutoStartToggle,
		req.RestartOnKill,
		req.UnlockCodeUnusedExpireMinutes,
	)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "SYSTEM", "更新客户端防护默认策略", "", "")
	h.clientProtection.PushAllOnlineAgents(c.Request.Context())
	models.Send(c, 200, 0, "success", cfg)
}

func (h *DeviceHandler) GetDeviceClientProtection(c *gin.Context) {
	if h.clientProtection == nil {
		models.SendError(c, 500, 5000, "client protection not configured")
		return
	}
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}
	override, err := h.clientProtection.GetDeviceOverride(c.Request.Context(), id)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			models.SendError(c, 404, 2001, "Device not found")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	effective, err := h.clientProtection.ResolveEffective(c.Request.Context(), id.String())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	hasActive, unlockExpires, _ := h.clientProtection.GetDeviceUnlockCodeStatus(c.Request.Context(), id)
	models.Send(c, 200, 0, "success", gin.H{
		"override":  override,
		"effective": effective,
		"unlockCode": gin.H{
			"hasActive": hasActive,
			"expiresAt": unlockExpires,
		},
	})
}

func (h *DeviceHandler) IssueDeviceExitUnlockCode(c *gin.Context) {
	if h.clientProtection == nil {
		models.SendError(c, 500, 5000, "client protection not configured")
		return
	}
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}
	var createdBy *uuid.UUID
	if uid := strings.TrimSpace(c.GetString("userID")); uid != "" {
		if parsed, err := uuid.Parse(uid); err == nil {
			createdBy = &parsed
		}
	}
	issue, err := h.clientProtection.IssueDeviceExitUnlockCode(c.Request.Context(), id, createdBy)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "CREATE", "DEVICE", "生成设备退出解锁码", id.String(), id.String())
	models.Send(c, 200, 0, "success", issue)
}

func (h *DeviceHandler) UpdateDeviceClientProtection(c *gin.Context) {
	if h.clientProtection == nil {
		models.SendError(c, 500, 5000, "client protection not configured")
		return
	}
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}
	var req services.ClientProtectionDeviceOverride
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if err := h.clientProtection.SaveDeviceOverride(c.Request.Context(), id, req); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	h.clientProtection.PushConfigToDevice(c.Request.Context(), id.String())
	Log(c, "UPDATE", "DEVICE", "更新设备客户端防护覆盖", id.String(), id.String())
	models.Send(c, 200, 0, "success", nil)
}

func (h *DeviceHandler) GrantDeviceTemporaryExit(c *gin.Context) {
	if h.clientProtection == nil {
		models.SendError(c, 500, 5000, "client protection not configured")
		return
	}
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}
	var req struct {
		Minutes int `json:"minutes"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	minutes := req.Minutes
	if minutes <= 0 {
		minutes = 15
	}
	until, err := h.clientProtection.GrantTemporaryExit(c.Request.Context(), id, minutes)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "DEVICE", "授予设备临时允许退出", id.String(), strconv.Itoa(minutes)+"min")
	models.Send(c, 200, 0, "success", gin.H{"temporaryExitUntil": until})
}

func (h *DeviceHandler) GetAgentClientProtection(c *gin.Context) {
	if h.clientProtection == nil {
		models.SendError(c, 500, 5000, "client protection not configured")
		return
	}
	deviceID := strings.TrimSpace(c.GetString("deviceID"))
	if deviceID == "" {
		models.SendError(c, 401, 1002, "Unauthorized")
		return
	}
	eff, err := h.clientProtection.ResolveEffective(c.Request.Context(), deviceID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", eff)
}

func (h *DeviceHandler) VerifyAgentExitUnlock(c *gin.Context) {
	if h.clientProtection == nil {
		models.SendError(c, 500, 5000, "client protection not configured")
		return
	}
	deviceID := strings.TrimSpace(c.GetString("deviceID"))
	if deviceID == "" {
		models.SendError(c, 401, 1002, "Unauthorized")
		return
	}
	var req struct {
		Code string `json:"code"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	ok, err := h.clientProtection.VerifyUnlockCode(c.Request.Context(), deviceID, req.Code)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if !ok {
		models.SendError(c, 400, 1001, "解锁码不正确、已使用或已过期")
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"allowExitOnce": true})
}

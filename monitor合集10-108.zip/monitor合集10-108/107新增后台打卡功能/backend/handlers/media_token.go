package handlers

import (
	"database/sql"
	"errors"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type MediaTokenHandler struct {
	svc            *services.MediaTokenService
	recordingRepo  *services.RecordingRepository
	screenshotRepo *services.ScreenshotRepository
}

func NewMediaTokenHandler(
	svc *services.MediaTokenService,
	recordingRepo *services.RecordingRepository,
	screenshotRepo *services.ScreenshotRepository,
) *MediaTokenHandler {
	return &MediaTokenHandler{
		svc:            svc,
		recordingRepo:  recordingRepo,
		screenshotRepo: screenshotRepo,
	}
}

func (h *MediaTokenHandler) Issue(c *gin.Context) {
	var req struct {
		ResourceType string `json:"resourceType" binding:"required"`
		ResourceID   string `json:"resourceId" binding:"required"`
		Action       string `json:"action" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	resourceType := strings.ToLower(strings.TrimSpace(req.ResourceType))
	action := strings.ToLower(strings.TrimSpace(req.Action))
	resourceID := strings.TrimSpace(req.ResourceID)

	if _, err := uuid.Parse(resourceID); err != nil {
		models.SendError(c, 400, 1001, "Invalid resource ID")
		return
	}

	userID := c.GetString("userID")
	if userID == "" {
		models.SendError(c, 401, 1002, "User not authenticated")
		return
	}
	sessionID := c.GetString("sessionID")
	if sessionID == "" {
		models.SendError(c, 401, 1002, "Missing session")
		return
	}

	if err := h.verifyMediaIssueAccess(c, resourceType, action, resourceID); err != nil {
		if errors.Is(err, errMediaAccessDenied) {
			models.SendError(c, 403, 1003, "Permission denied")
			return
		}
		if errors.Is(err, sql.ErrNoRows) {
			models.SendError(c, 404, 2001, "Resource not found")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	grant := services.MediaAccessGrant{
		SessionID:    c.GetString("sessionID"),
		UserID:       userID,
		Username:     c.GetString("username"),
		Role:         c.GetString("role"),
		ResourceType: resourceType,
		ResourceID:   resourceID,
		Action:       action,
	}
	if middleware.IsEmployeeRole(c) {
		if ids, ok := middleware.ResolveEmployeeDeviceIDs(c); ok {
			for _, id := range ids {
				grant.AllowedDeviceIDs = append(grant.AllowedDeviceIDs, id.String())
			}
		}
	}

	token, ttl, err := h.svc.Issue(c.Request.Context(), grant)
	if err != nil {
		models.SendError(c, 503, 5003, "Media token service unavailable")
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"mediaToken": token,
		"expiresIn":  int(ttl.Seconds()),
	})
}

var errMediaAccessDenied = errors.New("media access denied")

func (h *MediaTokenHandler) verifyMediaIssueAccess(c *gin.Context, resourceType, action, resourceID string) error {
	switch resourceType {
	case "recording":
		switch action {
		case "stream":
			if !hasAnyContextPermission(c, models.PermRecordingPlay, "employee:recording:view_own") {
				return errMediaAccessDenied
			}
		case "download":
			if !hasAnyContextPermission(c, models.PermRecordingExport, "employee:recording:view_own") {
				return errMediaAccessDenied
			}
		default:
			return errInvalidMediaAction
		}
		if h.recordingRepo == nil {
			return errMediaAccessDenied
		}
		recID, err := uuid.Parse(resourceID)
		if err != nil {
			return err
		}
		recording, err := h.recordingRepo.GetByID(c.Request.Context(), recID)
		if err != nil {
			return err
		}
		if middleware.IsEmployeeRole(c) && !middleware.EmployeeCanAccessDevice(c, recording.DeviceID) {
			return errMediaAccessDenied
		}
		return nil
	case "screenshot":
		if action != "view" {
			return errInvalidMediaAction
		}
		if !hasContextPermission(c, models.PermScreenshotView) {
			return errMediaAccessDenied
		}
		if h.screenshotRepo == nil {
			return errMediaAccessDenied
		}
		screenshot, err := h.screenshotRepo.GetByID(c.Request.Context(), resourceID)
		if err != nil {
			return err
		}
		if middleware.IsEmployeeRole(c) {
			deviceID, err := uuid.Parse(screenshot.DeviceID)
			if err != nil || !middleware.EmployeeCanAccessDevice(c, deviceID) {
				return errMediaAccessDenied
			}
		}
		return nil
	default:
		return errInvalidMediaResource
	}
}

func hasAnyContextPermission(c *gin.Context, permissions ...string) bool {
	for _, p := range permissions {
		if hasContextPermission(c, p) {
			return true
		}
	}
	return false
}

var (
	errInvalidMediaAction   = &mediaRequestError{"unsupported media action"}
	errInvalidMediaResource = &mediaRequestError{"unsupported resource type"}
)

type mediaRequestError struct {
	msg string
}

func (e *mediaRequestError) Error() string { return e.msg }

func hasContextPermission(c *gin.Context, permission string) bool {
	return middleware.UserHasPermission(c, permission)
}

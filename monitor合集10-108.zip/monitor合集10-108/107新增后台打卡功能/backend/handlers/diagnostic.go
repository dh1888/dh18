package handlers

import (
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type DiagnosticHandler struct {
	svc *services.DiagnosticService
}

func NewDiagnosticHandler(svc *services.DiagnosticService) *DiagnosticHandler {
	return &DiagnosticHandler{svc: svc}
}

func (h *DiagnosticHandler) GetConfig(c *gin.Context) {
	cfg, err := h.svc.GetConfig(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	runtime := h.svc.GetRuntimeConfig()
	models.Send(c, 200, 0, "success", gin.H{
		"config":  cfg,
		"runtime": runtime,
		"modules": models.DiagnosticModules,
		"levels": []string{
			string(models.DiagnosticLevelOff),
			string(models.DiagnosticLevelError),
			string(models.DiagnosticLevelWarn),
			string(models.DiagnosticLevelInfo),
			string(models.DiagnosticLevelDebug),
			string(models.DiagnosticLevelTrace),
		},
	})
}

func (h *DiagnosticHandler) UpdateConfig(c *gin.Context) {
	var req struct {
		Enabled               bool                           `json:"enabled"`
		ExpiresAt             *time.Time                     `json:"expiresAt"`
		DurationMinutes       *int                           `json:"durationMinutes"`
		GlobalLevel           string                         `json:"globalLevel"`
		ModuleLevels          map[string]string              `json:"moduleLevels"`
		AgentUploadEnabled    bool                           `json:"agentUploadEnabled"`
		FrontendUploadEnabled bool                           `json:"frontendUploadEnabled"`
		RetentionHours        int                            `json:"retentionHours"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	cfg := models.DefaultDiagnosticCenterConfig()
	cfg.Enabled = req.Enabled
	cfg.GlobalLevel = models.NormalizeDiagnosticLevel(req.GlobalLevel)
	cfg.AgentUploadEnabled = req.AgentUploadEnabled
	cfg.FrontendUploadEnabled = req.FrontendUploadEnabled
	cfg.RetentionHours = req.RetentionHours

	if req.DurationMinutes != nil && *req.DurationMinutes > 0 {
		exp := models.UTCNow().Add(time.Duration(*req.DurationMinutes) * time.Minute)
		cfg.ExpiresAt = &exp
	} else {
		cfg.ExpiresAt = req.ExpiresAt
	}

	cfg.ModuleLevels = make(map[string]models.DiagnosticLevel, len(models.DiagnosticModules))
	for _, module := range models.DiagnosticModules {
		level := cfg.GlobalLevel
		if req.ModuleLevels != nil {
			if raw, ok := req.ModuleLevels[module]; ok {
				level = models.NormalizeDiagnosticLevel(raw)
			}
		}
		cfg.ModuleLevels[module] = level
	}

	updatedBy := c.GetString("username")
	if updatedBy == "" {
		updatedBy = c.GetString("userID")
	}
	saved, err := h.svc.SaveConfig(c.Request.Context(), cfg, updatedBy)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	Log(c, "UPDATE", "DIAGNOSTIC", "更新诊断中心配置", "", "")
	models.Send(c, 200, 0, "success", gin.H{
		"config":  saved,
		"runtime": h.svc.GetRuntimeConfig(),
	})
}

func (h *DiagnosticHandler) ListTemplates(c *gin.Context) {
	models.Send(c, 200, 0, "success", gin.H{
		"items": h.svc.ListTemplates(),
	})
}

func (h *DiagnosticHandler) ApplyTemplate(c *gin.Context) {
	var req struct {
		TemplateID      string `json:"templateId"`
		DurationMinutes int    `json:"durationMinutes"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	req.TemplateID = strings.TrimSpace(req.TemplateID)
	if req.TemplateID == "" {
		models.SendError(c, 400, 1001, "templateId is required")
		return
	}

	updatedBy := c.GetString("username")
	if updatedBy == "" {
		updatedBy = c.GetString("userID")
	}
	saved, err := h.svc.ApplyTemplate(c.Request.Context(), req.TemplateID, req.DurationMinutes, updatedBy)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "DIAGNOSTIC", "应用诊断模板", req.TemplateID, saved.AppliedTemplateID)
	models.Send(c, 200, 0, "success", gin.H{
		"config":  saved,
		"runtime": h.svc.GetRuntimeConfig(),
	})
}

func (h *DiagnosticHandler) GetRuntime(c *gin.Context) {
	models.Send(c, 200, 0, "success", h.svc.GetRuntimeConfig())
}

func (h *DiagnosticHandler) ListEvents(c *gin.Context) {
	q := parseDiagnosticEventQuery(c)
	events, total, err := h.svc.ListEvents(c.Request.Context(), q)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"items":    events,
		"total":    total,
		"page":     q.Page,
		"pageSize": q.PageSize,
	})
}

func (h *DiagnosticHandler) IngestFrontend(c *gin.Context) {
	var payload map[string]interface{}
	if err := c.ShouldBindJSON(&payload); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	h.svc.IngestFrontendLog(c.GetString("userID"), payload)
	models.Send(c, 200, 0, "success", gin.H{"accepted": true})
}

func (h *DiagnosticHandler) Export(c *gin.Context) {
	q := parseDiagnosticEventQuery(c)
	q.Page = 1
	q.PageSize = 5000
	data, filename, err := h.svc.ExportBundle(c.Request.Context(), q)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "EXPORT", "DIAGNOSTIC", "导出诊断包", "", filename)
	c.Header("Content-Disposition", "attachment; filename="+filename)
	c.Data(http.StatusOK, "application/zip", data)
}

func (h *DiagnosticHandler) GetSnapshot(c *gin.Context) {
	snap, err := h.svc.BuildSnapshot(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", snap)
}

func (h *DiagnosticHandler) Analyze(c *gin.Context) {
	window, _ := strconv.Atoi(c.DefaultQuery("windowMinutes", "30"))
	deviceID := strings.TrimSpace(c.Query("deviceId"))
	analysis, err := h.svc.Analyze(c.Request.Context(), deviceID, window)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", analysis)
}

func (h *DiagnosticHandler) GetPipeline(c *gin.Context) {
	deviceID := strings.TrimSpace(c.Query("deviceId"))
	if deviceID == "" {
		models.SendError(c, 400, 1001, "deviceId is required")
		return
	}
	pipeline, err := h.svc.BuildPipeline(c.Request.Context(), deviceID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", pipeline)
}

func (h *DiagnosticHandler) GetPipelineNode(c *gin.Context) {
	deviceID := strings.TrimSpace(c.Query("deviceId"))
	nodeID := strings.TrimSpace(c.Query("nodeId"))
	if deviceID == "" || nodeID == "" {
		models.SendError(c, 400, 1001, "deviceId and nodeId are required")
		return
	}
	node, err := h.svc.GetPipelineNodeDetail(c.Request.Context(), deviceID, nodeID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", node)
}

func (h *DiagnosticHandler) ListSessions(c *gin.Context) {
	deviceID := strings.TrimSpace(c.Query("deviceId"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "30"))
	items, err := h.svc.ListSessionGroups(c.Request.Context(), deviceID, limit)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items})
}

func (h *DiagnosticHandler) GetSession(c *gin.Context) {
	sessionID := strings.TrimSpace(c.Param("sessionId"))
	group, err := h.svc.GetSessionGroup(c.Request.Context(), sessionID)
	if err != nil {
		models.SendError(c, 404, 1004, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", group)
}

func (h *DiagnosticHandler) StartReproduce(c *gin.Context) {
	var req models.DiagnosticReproduceRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if len(req.DeviceIDs) == 0 {
		models.SendError(c, 400, 1001, "deviceIds is required")
		return
	}
	updatedBy := c.GetString("username")
	if updatedBy == "" {
		updatedBy = c.GetString("userID")
	}
	job, err := h.svc.StartReproduce(c.Request.Context(), req, updatedBy)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "DIAGNOSTIC", "启动复现模式", req.TemplateID, job.JobID)
	models.Send(c, 200, 0, "success", job)
}

func (h *DiagnosticHandler) GetReproduceStatus(c *gin.Context) {
	jobID := strings.TrimSpace(c.Param("jobId"))
	job, err := h.svc.GetReproduceStatus(jobID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if job == nil {
		models.SendError(c, 404, 1004, "job not found")
		return
	}
	models.Send(c, 200, 0, "success", job)
}

func (h *DiagnosticHandler) Capture(c *gin.Context) {
	var req models.DiagnosticCaptureRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	result, err := h.svc.Capture(c.Request.Context(), req)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "EXPORT", "DIAGNOSTIC", "一键抓取诊断", "", strings.Join(req.DeviceIDs, ","))
	models.Send(c, 200, 0, "success", result)
}

func (h *DiagnosticHandler) CaptureExport(c *gin.Context) {
	var req models.DiagnosticCaptureRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	data, filename, err := h.svc.ExportCaptureBundle(c.Request.Context(), req)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "EXPORT", "DIAGNOSTIC", "导出抓取诊断包", "", filename)
	c.Header("Content-Disposition", "attachment; filename="+filename)
	c.Data(http.StatusOK, "application/zip", data)
}

func parseDiagnosticEventQuery(c *gin.Context) services.DiagnosticEventQuery {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "50"))
	q := services.DiagnosticEventQuery{
		Source:   strings.TrimSpace(c.Query("source")),
		Module:   strings.TrimSpace(c.Query("module")),
		Level:    strings.TrimSpace(c.Query("level")),
		DeviceID: strings.TrimSpace(c.Query("deviceId")),
		Page:     page,
		PageSize: pageSize,
	}
	if from := strings.TrimSpace(c.Query("from")); from != "" {
		if t, err := time.Parse(time.RFC3339, from); err == nil {
			q.From = &t
		}
	}
	if to := strings.TrimSpace(c.Query("to")); to != "" {
		if t, err := time.Parse(time.RFC3339, to); err == nil {
			q.To = &t
		}
	}
	return q
}

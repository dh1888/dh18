package handlers

import (
	"fmt"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

func (h *AdminHandler) GetAgentNotificationSettings(c *gin.Context) {
	if h.agentNotify == nil {
		models.SendError(c, 500, 5000, "agent notification service unavailable")
		return
	}
	settings, err := h.agentNotify.GetSettings(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", settings)
}

func (h *AdminHandler) SaveAgentNotificationSettings(c *gin.Context) {
	if h.agentNotify == nil {
		models.SendError(c, 500, 5000, "agent notification service unavailable")
		return
	}
	var req services.AgentNotificationSettings
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	settings, err := h.agentNotify.SaveSettings(c.Request.Context(), req)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "AGENT_NOTIFY", "保存客户端通知推送设置", "",
		fmt.Sprintf("enabled=%v duration=%ds", settings.Enabled, settings.DefaultDurationSec))
	models.Send(c, 200, 0, "已保存", settings)
}

package handlers

import (
	"database/sql"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

func (h *UserHandler) requireTotpService(c *gin.Context) *services.TOTPAuthService {
	if h.totp == nil {
		models.SendError(c, 503, 5003, "TOTP service unavailable")
		return nil
	}
	return h.totp
}

func (h *UserHandler) isLoginTotpEnabled(c *gin.Context) bool {
	if h.settings == nil {
		return false
	}
	cfg, err := h.settings.GetAuthSecurityConfig(c.Request.Context())
	return err == nil && cfg != nil && cfg.LoginTotpEnabled
}

// InitiateTotpEnroll 管理员为用户生成绑定二维码
func (h *UserHandler) InitiateTotpEnroll(c *gin.Context) {
	totpSvc := h.requireTotpService(c)
	if totpSvc == nil {
		return
	}
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}
	user, err := h.repo.Get(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "User not found")
		return
	}
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if user.TotpEnabled {
		models.SendError(c, 400, 1001, "User already bound Google Authenticator")
		return
	}

	challengeID, uri, err := totpSvc.StartBindChallenge(c.Request.Context(), id.String(), user.Username)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", models.TotpEnrollResponse{
		SetupChallenge:      challengeID,
		TotpProvisioningURI: uri,
	})
}

// ConfirmTotpEnroll 管理员确认用户 TOTP 绑定
func (h *UserHandler) ConfirmTotpEnroll(c *gin.Context) {
	totpSvc := h.requireTotpService(c)
	if totpSvc == nil {
		return
	}
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}
	var req struct {
		SetupChallenge string `json:"setupChallenge"`
		TotpCode       string `json:"totpCode"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	user, err := h.repo.Get(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "User not found")
		return
	}
	if err != nil {
		models.SendInternalError(c, err)
		return
	}

	secret, err := totpSvc.ConfirmBindChallenge(c.Request.Context(), req.SetupChallenge, req.TotpCode, id)
	if err != nil {
		msg := err.Error()
		if strings.Contains(msg, "invalid totp") {
			models.SendError(c, 401, 1002, "Invalid Google Authenticator code")
			return
		}
		models.SendError(c, 401, 1002, "Setup expired, please scan QR code again")
		return
	}
	enc, err := services.EncryptTotpSecret(secret)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if err := h.repo.EnableUserTOTP(c.Request.Context(), id, enc); err != nil {
		models.SendInternalError(c, err)
		return
	}
	Log(c, "UPDATE", "USER",
		"绑定谷歌验证：用户 "+userLogDisplayName(user.Username, user.RealName),
		id.String(), userLogDisplayName(user.Username, user.RealName))
	models.Send(c, 200, 0, "Google Authenticator bound", nil)
}

// GetOwnTotpStatus 当前用户 TOTP 状态
func (h *UserHandler) GetOwnTotpStatus(c *gin.Context) {
	userID := c.GetString("userID")
	id, err := uuid.Parse(userID)
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid user")
		return
	}
	user, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "User not found")
		return
	}
	models.Send(c, 200, 0, "success", models.TotpStatusResponse{
		TotpEnabled:      user.TotpEnabled,
		LoginTotpEnabled: h.isLoginTotpEnabled(c),
	})
}

// InitiateOwnTotpEnroll 用户自助发起绑定（需验证密码）
func (h *UserHandler) InitiateOwnTotpEnroll(c *gin.Context) {
	totpSvc := h.requireTotpService(c)
	if totpSvc == nil {
		return
	}
	if !h.isLoginTotpEnabled(c) {
		models.SendError(c, 400, 1001, "Google Authenticator login is disabled")
		return
	}
	userID := c.GetString("userID")
	id, err := uuid.Parse(userID)
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid user")
		return
	}
	var req struct {
		Password string `json:"password"`
	}
	if err := c.ShouldBindJSON(&req); err != nil || strings.TrimSpace(req.Password) == "" {
		models.SendError(c, 400, 1001, "Password is required")
		return
	}

	userWithPwd, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	authUser, err := h.repo.GetLoginUserByUsername(c.Request.Context(), userWithPwd.Username)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(authUser.PasswordHash), []byte(req.Password)) != nil {
		models.SendError(c, 401, 1002, "Invalid password")
		return
	}
	if authUser.TotpEnabled {
		models.SendError(c, 400, 1001, "Google Authenticator already bound")
		return
	}

	challengeID, uri, err := totpSvc.StartBindChallenge(c.Request.Context(), id.String(), authUser.Username)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", models.TotpEnrollResponse{
		SetupChallenge:      challengeID,
		TotpProvisioningURI: uri,
	})
}

// ConfirmOwnTotpEnroll 用户自助确认绑定
func (h *UserHandler) ConfirmOwnTotpEnroll(c *gin.Context) {
	totpSvc := h.requireTotpService(c)
	if totpSvc == nil {
		return
	}
	if !h.isLoginTotpEnabled(c) {
		models.SendError(c, 400, 1001, "Google Authenticator login is disabled")
		return
	}
	userID := c.GetString("userID")
	id, err := uuid.Parse(userID)
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid user")
		return
	}
	var req struct {
		SetupChallenge string `json:"setupChallenge"`
		TotpCode       string `json:"totpCode"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	secret, err := totpSvc.ConfirmBindChallenge(c.Request.Context(), req.SetupChallenge, req.TotpCode, id)
	if err != nil {
		msg := err.Error()
		if strings.Contains(msg, "invalid totp") {
			models.SendError(c, 401, 1002, "Invalid Google Authenticator code")
			return
		}
		models.SendError(c, 401, 1002, "Setup expired, please scan QR code again")
		return
	}
	enc, err := services.EncryptTotpSecret(secret)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if err := h.repo.EnableUserTOTP(c.Request.Context(), id, enc); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "Google Authenticator bound", nil)
}

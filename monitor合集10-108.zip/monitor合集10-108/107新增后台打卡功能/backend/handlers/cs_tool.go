package handlers

import (
	"errors"
	"fmt"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

func (h *AdminHandler) GetCsToolSettings(c *gin.Context) {
	if h.csTool == nil {
		models.SendError(c, 500, 5000, "cs tool settings service unavailable")
		return
	}
	settings, err := h.csTool.GetSettings(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", settings)
}

func (h *AdminHandler) SaveCsToolSettings(c *gin.Context) {
	if h.csTool == nil {
		models.SendError(c, 500, 5000, "cs tool settings service unavailable")
		return
	}
	var req services.CsToolSettings
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	settings, err := h.csTool.SaveSettings(c.Request.Context(), req)
	if err != nil {
		if errors.Is(err, services.ErrInvalidCsToolURL) {
			models.SendError(c, 400, 1001, err.Error())
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "CS_TOOL", "保存客服工具跳转地址", "",
		fmt.Sprintf("tool=%s script=%s", settings.ToolUrl, settings.ScriptUrl))
	models.Send(c, 200, 0, "已保存", settings)
}

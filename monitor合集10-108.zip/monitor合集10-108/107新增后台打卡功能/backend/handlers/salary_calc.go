package handlers

import (
	"fmt"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

func (h *AdminHandler) salaryConfigSvc() *services.SalaryConfigService {
	return services.NewSalaryConfigService(h.db)
}

func (h *AdminHandler) salaryCalculator() *services.SalaryCalculator {
	return services.NewSalaryCalculator(h.db)
}

func (h *AdminHandler) GetSalaryConfigs(c *gin.Context) {
	items, err := h.salaryConfigSvc().ListConfigs(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items})
}

func (h *AdminHandler) CreateSalaryConfig(c *gin.Context) {
	var req struct {
		ConfigName string `json:"configName" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	row, err := h.salaryConfigSvc().CreateConfig(c.Request.Context(), req.ConfigName)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "CREATE", "SALARY", fmt.Sprintf("新增工资配置：%s", row.ConfigName), row.ConfigKey, row.ConfigName)
	models.Send(c, 200, 0, "success", row)
}

func (h *AdminHandler) UpsertSalaryConfig(c *gin.Context) {
	var req services.SalaryWorkConfig
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	row, err := h.salaryConfigSvc().UpsertConfig(c.Request.Context(), req)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	label := row.ConfigName
	if label == "" {
		label = row.ConfigKey
	}
	Log(c, "UPDATE", "SALARY", fmt.Sprintf("更新工资配置：%s", label), row.ConfigKey, label)
	models.Send(c, 200, 0, "success", row)
}

func (h *AdminHandler) DeleteSalaryConfig(c *gin.Context) {
	configKey := c.Param("configKey")
	if err := h.salaryConfigSvc().DeleteConfig(c.Request.Context(), configKey); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "DELETE", "SALARY", fmt.Sprintf("删除工资配置：%s", configKey), configKey, configKey)
	models.Send(c, 200, 0, "success", gin.H{"deleted": configKey})
}

func (h *AdminHandler) GetSalaryCalculateDraft(c *gin.Context) {
	yearMonth := c.Query("yearMonth")
	rows, configs, err := h.salaryCalculator().BuildDraftRows(c.Request.Context(), yearMonth)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	configItems := make([]services.SalaryWorkConfig, 0, len(configs))
	for _, cfg := range configs {
		configItems = append(configItems, cfg)
	}
	models.Send(c, 200, 0, "success", gin.H{
		"yearMonth": yearMonth,
		"items":     rows,
		"configs":   configItems,
	})
}

func (h *AdminHandler) RecalculateSalaryRows(c *gin.Context) {
	var req struct {
		YearMonth string                        `json:"yearMonth" binding:"required"`
		Items     []services.SalaryCalculateRow `json:"items" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	configs, err := h.salaryConfigSvc().ListConfigs(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	configMap := services.BuildSalaryConfigMap(configs)
	rows, err := h.salaryCalculator().RecalculateRows(c.Request.Context(), req.YearMonth, req.Items, configMap)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"items": rows})
}

func (h *AdminHandler) SaveSalaryCalculateRows(c *gin.Context) {
	var req struct {
		YearMonth string                        `json:"yearMonth" binding:"required"`
		Items     []services.SalaryCalculateRow `json:"items" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	configs, err := h.salaryConfigSvc().ListConfigs(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	configMap := services.BuildSalaryConfigMap(configs)
	rows, err := h.salaryCalculator().RecalculateRows(c.Request.Context(), req.YearMonth, req.Items, configMap)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	count, err := h.salaryCalculator().SaveRows(c.Request.Context(), req.YearMonth, rows)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "CREATE", "SALARY",
		fmt.Sprintf("保存计算工资：%s，共 %d 条", req.YearMonth, count),
		req.YearMonth, req.YearMonth)
	models.Send(c, 200, 0, "success", gin.H{"saved": count})
}

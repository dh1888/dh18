package services

import (
	"crypto/sha256"
	"encoding/hex"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

var (
	fileHashCacheMu sync.RWMutex
	fileHashCache   = map[string]cachedFileHash{}
)

type cachedFileHash struct {
	modTime int64
	size    int64
	hash    string
}

// ClientRelease describes installer/update artifacts exposed to agents and the employee portal.
type ClientRelease struct {
	Version           string
	FileName          string
	DownloadURL       string
	UpdatePackageURL  string
	Sha256            string
	UpdateSha256      string
	Available         bool
	Mode              string
}

func ClientReleaseFromEnv() ClientRelease {
	localPath, externalURL, fileName := ResolveClientInstaller()
	version := strings.TrimSpace(os.Getenv("CLIENT_VERSION"))
	updateFile := strings.TrimSpace(os.Getenv("CLIENT_UPDATE_FILE"))
	if updateFile == "" {
		updateFile = "MonitorAgent-update.zip"
	}

	out := ClientRelease{
		Version:  version,
		FileName: fileName,
		Mode:     "api",
	}

	if externalURL != "" {
		out.Mode = "external"
		out.DownloadURL = externalURL
		out.Available = version != ""
		return out
	}

	dir := ClientDownloadDir()
	if _, err := os.Stat(localPath); err == nil {
		out.Available = true
		out.DownloadURL = "/api/v1/employee/client-download/file"
		out.Sha256 = FileSha256HexCached(localPath)
	}

	updatePath := filepath.Join(dir, updateFile)
	if _, err := os.Stat(updatePath); err == nil {
		out.UpdatePackageURL = "/api/v1/meta/client-release/update-package"
		out.UpdateSha256 = FileSha256HexCached(updatePath)
		if version != "" {
			out.Available = true
		}
	}

	return out
}

func ResolveClientInstaller() (localPath, externalURL, fileName string) {
	fileName = strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_FILE"))
	if fileName == "" {
		fileName = "MonitorAgentSetup.exe"
	}

	configured := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_URL"))
	if configured != "" {
		if strings.HasPrefix(configured, "http://") || strings.HasPrefix(configured, "https://") {
			return "", configured, fileName
		}
		dir := ClientDownloadDir()
		if strings.HasPrefix(configured, "/") {
			rel := strings.TrimPrefix(configured, "/downloads/")
			if rel == configured {
				rel = filepath.Base(configured)
			}
			return filepath.Join(dir, rel), "", filepath.Base(rel)
		}
		return filepath.Join(configured), "", filepath.Base(configured)
	}

	return filepath.Join(ClientDownloadDir(), fileName), "", fileName
}

func ClientDownloadDir() string {
	dir := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_DIR"))
	if dir == "" {
		dir = "./downloads"
	}
	return dir
}

func ResolveClientUpdatePackage() (localPath, fileName string) {
	fileName = strings.TrimSpace(os.Getenv("CLIENT_UPDATE_FILE"))
	if fileName == "" {
		fileName = "MonitorAgent-update.zip"
	}
	return filepath.Join(ClientDownloadDir(), fileName), fileName
}

func FileSha256HexCached(path string) string {
	info, err := os.Stat(path)
	if err != nil {
		return ""
	}

	fileHashCacheMu.RLock()
	if cached, ok := fileHashCache[path]; ok && cached.modTime == info.ModTime().UnixNano() && cached.size == info.Size() {
		fileHashCacheMu.RUnlock()
		return cached.hash
	}
	fileHashCacheMu.RUnlock()

	hash := fileSha256Hex(path)
	if hash == "" {
		return ""
	}

	fileHashCacheMu.Lock()
	fileHashCache[path] = cachedFileHash{
		modTime: info.ModTime().UnixNano(),
		size:    info.Size(),
		hash:    hash,
	}
	fileHashCacheMu.Unlock()
	return hash
}

func fileSha256Hex(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}
	return hex.EncodeToString(h.Sum(nil))
}

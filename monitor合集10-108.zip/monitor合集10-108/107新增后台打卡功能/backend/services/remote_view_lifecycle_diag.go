package services

import (
	"log"
	"time"
)

func (s *RemoteViewService) lifecycleDiag(phase, sessionID, detail string) {
	if s == nil || !s.cfg.LifecycleDiagEnabled {
		return
	}
	log.Printf(
		"[RemoteViewLifecycleDiag] ts=%s phase=%s session=%s detail=%s",
		time.Now().UTC().Format(time.RFC3339Nano),
		phase,
		normalizeLifecycleDiagSession(sessionID),
		detail,
	)
}

func normalizeLifecycleDiagSession(sessionID string) string {
	if sessionID == "" {
		return "-"
	}
	return sessionID
}

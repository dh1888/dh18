package services

import (
	"image"
	"image/color"
	"image/png"
	"os"
	"path/filepath"
	"testing"
)

func TestEnsureScreenshotThumbnail(t *testing.T) {
	dir := t.TempDir()
	srcPath := filepath.Join(dir, "shot.png")

	img := image.NewRGBA(image.Rect(0, 0, 800, 600))
	for y := 0; y < 600; y++ {
		for x := 0; x < 800; x++ {
			img.Set(x, y, color.RGBA{R: uint8(x % 255), G: uint8(y % 255), B: 40, A: 255})
		}
	}
	f, err := os.Create(srcPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := png.Encode(f, img); err != nil {
		f.Close()
		t.Fatal(err)
	}
	f.Close()

	thumbPath, err := EnsureScreenshotThumbnail(srcPath)
	if err != nil {
		t.Fatalf("EnsureScreenshotThumbnail: %v", err)
	}
	info, err := os.Stat(thumbPath)
	if err != nil {
		t.Fatalf("thumb missing: %v", err)
	}
	if info.Size() <= 0 {
		t.Fatal("thumb empty")
	}
	srcInfo, _ := os.Stat(srcPath)
	if info.Size() >= srcInfo.Size() {
		t.Fatalf("thumb should be smaller than source: thumb=%d src=%d", info.Size(), srcInfo.Size())
	}

	// second call should reuse cache
	again, err := EnsureScreenshotThumbnail(srcPath)
	if err != nil || again != thumbPath {
		t.Fatalf("cache reuse failed: %v path=%s", err, again)
	}

	RemoveScreenshotThumbnail(srcPath)
	if _, err := os.Stat(thumbPath); !os.IsNotExist(err) {
		t.Fatalf("thumb should be removed, err=%v", err)
	}
}

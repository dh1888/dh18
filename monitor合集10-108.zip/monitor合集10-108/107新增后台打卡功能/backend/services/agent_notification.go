package services

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

const (
	AgentNotifyCategorySalaryPaid  = "salary_paid"
	AgentNotifyCategoryPenalty     = "penalty"
	AgentNotifyCategoryPerformance = "performance"
	AgentNotifyCategoryAttendance  = "attendance"
	AgentNotifyCategoryActivity    = "activity"
)

const (
	AgentNotifyLevelInfo    = "info"
	AgentNotifyLevelWarning = "warning"
	AgentNotifyLevelSuccess = "success"
)

type AgentNotificationSettings struct {
	Enabled            bool   `json:"enabled"`
	SalaryPaidEnabled  bool   `json:"salaryPaidEnabled"`
	PenaltyEnabled     bool   `json:"penaltyEnabled"`
	PerformanceEnabled bool   `json:"performanceEnabled"`
	AttendanceEnabled  bool   `json:"attendanceEnabled"`
	ActivityEnabled    bool   `json:"activityEnabled"`
	DefaultDurationSec int    `json:"defaultDurationSec"`
	UpdatedAt          string `json:"updatedAt,omitempty"`
}

type AgentNotificationService struct {
	db    *sql.DB
	wsHub *WebSocketHub
}

func NewAgentNotificationService(db *sql.DB, wsHub *WebSocketHub) *AgentNotificationService {
	return &AgentNotificationService{db: db, wsHub: wsHub}
}

func (s *AgentNotificationService) GetSettings(ctx context.Context) (*AgentNotificationSettings, error) {
	out := &AgentNotificationSettings{DefaultDurationSec: 60}
	var updatedAt time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT enabled, salary_paid_enabled, penalty_enabled, performance_enabled,
		       attendance_enabled, activity_enabled, default_duration_sec, updated_at
		FROM agent_notification_settings WHERE id = 1`).
		Scan(&out.Enabled, &out.SalaryPaidEnabled, &out.PenaltyEnabled, &out.PerformanceEnabled,
			&out.AttendanceEnabled, &out.ActivityEnabled, &out.DefaultDurationSec, &updatedAt)
	if err == sql.ErrNoRows {
		out.Enabled = true
		out.SalaryPaidEnabled = true
		out.PenaltyEnabled = true
		out.PerformanceEnabled = true
		out.AttendanceEnabled = true
		out.ActivityEnabled = true
		return out, nil
	}
	if err != nil {
		return nil, err
	}
	out.UpdatedAt = updatedAt.UTC().Format(time.RFC3339)
	return out, nil
}

func (s *AgentNotificationService) SaveSettings(ctx context.Context, in AgentNotificationSettings) (*AgentNotificationSettings, error) {
	dur := in.DefaultDurationSec
	if dur < 30 {
		dur = 30
	}
	if dur > 600 {
		dur = 600
	}
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO agent_notification_settings (
			id, enabled, salary_paid_enabled, penalty_enabled, performance_enabled,
			attendance_enabled, activity_enabled, default_duration_sec, updated_at
		) VALUES (1, $1, $2, $3, $4, $5, $6, $7, NOW())
		ON CONFLICT (id) DO UPDATE SET
			enabled = EXCLUDED.enabled,
			salary_paid_enabled = EXCLUDED.salary_paid_enabled,
			penalty_enabled = EXCLUDED.penalty_enabled,
			performance_enabled = EXCLUDED.performance_enabled,
			attendance_enabled = EXCLUDED.attendance_enabled,
			activity_enabled = EXCLUDED.activity_enabled,
			default_duration_sec = EXCLUDED.default_duration_sec,
			updated_at = NOW()`,
		in.Enabled, in.SalaryPaidEnabled, in.PenaltyEnabled, in.PerformanceEnabled,
		in.AttendanceEnabled, in.ActivityEnabled, dur)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *AgentNotificationService) categoryEnabled(settings *AgentNotificationSettings, category string) bool {
	if settings == nil || !settings.Enabled {
		return false
	}
	switch category {
	case AgentNotifyCategorySalaryPaid:
		return settings.SalaryPaidEnabled
	case AgentNotifyCategoryPenalty:
		return settings.PenaltyEnabled
	case AgentNotifyCategoryPerformance:
		return settings.PerformanceEnabled
	case AgentNotifyCategoryAttendance:
		return settings.AttendanceEnabled
	case AgentNotifyCategoryActivity:
		return settings.ActivityEnabled
	default:
		return false
	}
}

func (s *AgentNotificationService) PushToEmployee(
	ctx context.Context,
	empID uuid.UUID,
	category, title, message, level string,
	durationSec int,
) bool {
	return s.pushToEmployee(ctx, empID, category, title, message, level, durationSec, nil)
}

type AgentNotifyExtras struct {
	SessionID uuid.UUID
	Action    string
}

func (s *AgentNotificationService) applyAgentNotifyExtras(params gin.H, extras *AgentNotifyExtras) {
	if extras == nil {
		return
	}
	if extras.SessionID != uuid.Nil {
		params["sessionId"] = extras.SessionID.String()
	}
	if action := strings.TrimSpace(extras.Action); action != "" {
		params["action"] = action
	}
}

func (s *AgentNotificationService) PushToEmployeeAsync(
	empID uuid.UUID,
	category, title, message, level string,
	durationSec int,
	extras ...*AgentNotifyExtras,
) {
	if s == nil || empID == uuid.Nil {
		return
	}
	var opt *AgentNotifyExtras
	if len(extras) > 0 {
		opt = extras[0]
	}
	go func() {
		ok := s.pushToEmployee(context.Background(), empID, category, title, message, level, durationSec, opt)
		if ok {
			log.Printf("[AgentNotify] pushed category=%s emp=%s", category, empID)
		}
	}()
}

func (s *AgentNotificationService) pushToEmployee(
	ctx context.Context,
	empID uuid.UUID,
	category, title, message, level string,
	durationSec int,
	extras *AgentNotifyExtras,
) bool {
	if s == nil || s.wsHub == nil || empID == uuid.Nil {
		return false
	}
	settings, err := s.GetSettings(ctx)
	if err != nil || !s.categoryEnabled(settings, category) {
		return false
	}
	title = strings.TrimSpace(title)
	message = strings.TrimSpace(message)
	if title == "" && message == "" {
		return false
	}
	if title == "" {
		title = "通知"
	}
	level = normalizeAgentNotifyLevel(level)
	if durationSec <= 0 {
		durationSec = settings.DefaultDurationSec
	}
	if durationSec < 30 {
		durationSec = 30
	}
	if durationSec > 600 {
		durationSec = 600
	}

	deviceID, online, err := s.findOnlineDeviceForEmployee(ctx, empID)
	if err != nil || deviceID == uuid.Nil || !online {
		return false
	}
	params := gin.H{
		"title":       title,
		"message":     message,
		"type":        category,
		"level":       level,
		"durationSec": durationSec,
	}
	s.applyAgentNotifyExtras(params, extras)
	s.wsHub.SendCommandToDevice(deviceID.String(), "agent_notification", params)
	return true
}

func (s *AgentNotificationService) ResolveEmployeeID(ctx context.Context, empID uuid.UUID, employeeName string) uuid.UUID {
	if empID != uuid.Nil {
		return empID
	}
	name := strings.TrimSpace(employeeName)
	if name == "" || s == nil || s.db == nil {
		return uuid.Nil
	}
	var id uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM employees WHERE name = $1
		ORDER BY updated_at DESC NULLS LAST LIMIT 1`, name).Scan(&id)
	if err != nil {
		return uuid.Nil
	}
	return id
}

func (s *AgentNotificationService) PushSalaryPaid(
	ctx context.Context,
	empID uuid.UUID,
	yearMonth, employeeName string,
	totalSalary float64,
) {
	monthLabel := agentNotifySalaryMonthLabel(yearMonth)
	title := "工资已发放"
	message := fmt.Sprintf("%s，您 %s 的工资已确认发放，实发 ¥%s，请查收。",
		employeeName, monthLabel, agentNotifyFormatMoney(totalSalary))
	s.PushToEmployeeAsync(empID, AgentNotifyCategorySalaryPaid, title, message, AgentNotifyLevelSuccess, 0)
}

func (s *AgentNotificationService) PushPenalty(
	empID uuid.UUID,
	amount float64,
	category, reason, penaltyDate string,
	employeeName string,
) {
	if amount <= 0 {
		return
	}
	empID = s.ResolveEmployeeID(context.Background(), empID, employeeName)
	if empID == uuid.Nil {
		return
	}
	title := "罚款通知"
	date := strings.TrimSpace(penaltyDate)
	msg := fmt.Sprintf("您有一笔 ¥%.2f 的罚款", amount)
	if cat := strings.TrimSpace(category); cat != "" {
		msg += "（" + cat + "）"
	}
	if r := strings.TrimSpace(reason); r != "" {
		msg += "\n原因：" + r
	}
	if date != "" {
		msg += "\n日期：" + date
	}
	s.PushToEmployeeAsync(empID, AgentNotifyCategoryPenalty, title, msg, AgentNotifyLevelWarning, 0)
}

func (s *AgentNotificationService) PushPerformance(
	empID uuid.UUID,
	rec PerformancePushRecord,
) {
	empID = s.ResolveEmployeeID(context.Background(), empID, rec.EmployeeName)
	if empID == uuid.Nil {
		return
	}
	changeType := "加分"
	level := AgentNotifyLevelSuccess
	scoreText := fmt.Sprintf("+%d分", rec.Score)
	if rec.Score < 0 {
		changeType = "扣分"
		level = AgentNotifyLevelWarning
		scoreText = fmt.Sprintf("%d分", rec.Score)
	}
	title := "绩效变动"
	reason := strings.TrimSpace(rec.Reason)
	if reason == "" {
		reason = "-"
	}
	message := fmt.Sprintf("%s %s（%s）\n原因：%s", strings.TrimSpace(rec.Date), scoreText, changeType, reason)
	s.PushToEmployeeAsync(empID, AgentNotifyCategoryPerformance, title, message, level, 0)
}

func (s *AgentNotificationService) PushAttendanceException(
	empID uuid.UUID,
	employeeName, shift, event string,
	workFine float64,
	exceptionMinutes int,
) {
	if workFine <= 0 && exceptionMinutes <= 0 {
		return
	}
	empID = s.ResolveEmployeeID(context.Background(), empID, employeeName)
	if empID == uuid.Nil {
		return
	}
	label := strings.TrimSpace(shift)
	if label == "" {
		label = "班次"
	}
	title := "考勤异常"
	message := fmt.Sprintf("%s · %s", event, label)
	if exceptionMinutes > 0 {
		sec := exceptionMinutes * 60
		if event == "上班" {
			message += fmt.Sprintf("\n迟到 %s", formatDurationZh(sec))
		} else {
			message += fmt.Sprintf("\n早退 %s", formatDurationZh(sec))
		}
	}
	if workFine > 0 {
		message += fmt.Sprintf("\n罚款 ¥%.2f", workFine)
	}
	level := AgentNotifyLevelWarning
	s.PushToEmployeeAsync(empID, AgentNotifyCategoryAttendance, title, message, level, 0)
}

func (s *AgentNotificationService) PushActivityEvent(
	empID uuid.UUID,
	employeeName, activityName, event, extra string,
	sessionID uuid.UUID,
) {
	empID = s.ResolveEmployeeID(context.Background(), empID, employeeName)
	if empID == uuid.Nil {
		return
	}
	title, message, level := formatActivityAgentNotify(activityName, event, extra)
	var notifyExtras *AgentNotifyExtras
	if sessionID != uuid.Nil && activityAgentNotifySupportsBack(event) {
		notifyExtras = &AgentNotifyExtras{
			SessionID: sessionID,
			Action:    "activity_back",
		}
	}
	s.PushToEmployeeAsync(empID, AgentNotifyCategoryActivity, title, message, level, 0, notifyExtras)
}

func activityAgentNotifySupportsBack(event string) bool {
	switch strings.TrimSpace(event) {
	case "即将超时", "超时警告":
		return true
	default:
		return false
	}
}

func formatActivityAgentNotify(activityName, event, extra string) (title, message, level string) {
	act := strings.TrimSpace(activityName)
	if act == "" {
		act = "活动"
	}
	level = AgentNotifyLevelWarning
	extra = strings.TrimSpace(extra)
	switch strings.TrimSpace(event) {
	case "即将超时":
		title = "即将超时"
		message = fmt.Sprintf("活动：%s\n剩余约 1 分钟，请及时回座", act)
		if extra != "" {
			message += "\n" + extra
		}
	case "超时警告":
		title = "活动超时"
		message = fmt.Sprintf("活动：%s", act)
		if extra != "" {
			message += "\n" + extra
		} else {
			message += "\n已超时，请立即回座"
		}
	case "自动安全回座":
		title = "自动安全回座"
		message = fmt.Sprintf("活动：%s", act)
		if extra != "" {
			message += "\n" + extra
		}
	case "强制回座":
		title = "强制回座"
		message = fmt.Sprintf("活动：%s", act)
		if extra != "" {
			message += "\n" + extra
		}
	case "超时自动结束":
		title = "活动超时结束"
		message = fmt.Sprintf("活动：%s\n超时自动结束", act)
		if extra != "" {
			message += "\n" + extra
		}
	case "超时回座":
		title = "超时回座"
		message = fmt.Sprintf("活动：%s", act)
		if extra != "" {
			message += "\n" + extra
		}
	default:
		title = "活动通知"
		message = fmt.Sprintf("活动：%s\n%s", act, strings.TrimSpace(event))
		if extra != "" {
			message += "\n" + extra
		}
	}
	return title, message, level
}

func (s *AgentNotificationService) findOnlineDeviceForEmployee(ctx context.Context, empID uuid.UUID) (uuid.UUID, bool, error) {
	if s == nil || s.db == nil {
		return uuid.Nil, false, nil
	}
	var deviceID uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM devices
		WHERE employee_uuid = $1 AND LOWER(status) = 'approved' AND employee_session_at IS NOT NULL
		ORDER BY last_seen_at DESC NULLS LAST LIMIT 1`, empID).Scan(&deviceID)
	if err != nil && err != sql.ErrNoRows {
		return uuid.Nil, false, err
	}
	if deviceID == uuid.Nil {
		err = s.db.QueryRowContext(ctx, `
			SELECT m.device_id FROM wf_shared_workstation_members m
			JOIN devices d ON d.id = m.device_id AND LOWER(d.status) = 'approved'
			WHERE m.employee_id = $1
			ORDER BY d.last_seen_at DESC NULLS LAST LIMIT 1`, empID).Scan(&deviceID)
		if err != nil && err != sql.ErrNoRows {
			return uuid.Nil, false, err
		}
	}
	if deviceID == uuid.Nil {
		return uuid.Nil, false, nil
	}
	online := s.wsHub != nil && s.wsHub.IsAgentOnline(deviceID.String())
	return deviceID, online, nil
}

func normalizeAgentNotifyLevel(level string) string {
	switch strings.ToLower(strings.TrimSpace(level)) {
	case AgentNotifyLevelWarning, AgentNotifyLevelSuccess:
		return strings.ToLower(strings.TrimSpace(level))
	default:
		return AgentNotifyLevelInfo
	}
}

func agentNotifySalaryMonthLabel(yearMonth string) string {
	parts := strings.Split(yearMonth, "-")
	if len(parts) != 2 {
		return yearMonth
	}
	m, err := strconv.Atoi(parts[1])
	if err != nil {
		return yearMonth
	}
	return fmt.Sprintf("%s年%d月", parts[0], m)
}

func agentNotifyFormatMoney(amount float64) string {
	return fmt.Sprintf("%.2f", amount)
}

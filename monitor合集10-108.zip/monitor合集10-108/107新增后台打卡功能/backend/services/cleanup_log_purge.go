package services

import (
	"context"
	"database/sql"
	"errors"
	"log"
	"strings"
	"time"

	"github.com/lib/pq"
)

type expiredLogPurgeJob struct {
	name       string
	deleteSQL  string
	batchSize  int
}

func defaultLogPurgeJobs() []expiredLogPurgeJob {
	return []expiredLogPurgeJob{
		{
			name: "remote_view_audit_logs",
			deleteSQL: `DELETE FROM remote_view_audit_logs WHERE id IN (
				SELECT id FROM remote_view_audit_logs WHERE created_at < $1 LIMIT $2)`,
		},
		{
			name: "remote_view_sessions",
			deleteSQL: `DELETE FROM remote_view_sessions WHERE id IN (
				SELECT id FROM remote_view_sessions
				WHERE status IN ('stopped', 'failed')
				  AND COALESCE(ended_at, updated_at, started_at) < $1
				LIMIT $2)`,
		},
		{
			name: "operation_logs",
			deleteSQL: `DELETE FROM operation_logs WHERE id IN (
				SELECT id FROM operation_logs WHERE created_at < $1 LIMIT $2)`,
		},
		{
			name: "activity_logs",
			deleteSQL: `DELETE FROM activity_logs WHERE id IN (
				SELECT id FROM activity_logs WHERE started_at < $1 LIMIT $2)`,
		},
		{
			name: "upload_tasks",
			deleteSQL: `DELETE FROM upload_tasks WHERE id IN (
				SELECT id FROM upload_tasks
				WHERE status IN ('completed', 'failed', 'cancelled')
				  AND COALESCE(completed_at, created_at) < $1
				LIMIT $2)`,
		},
		{
			name: "auth_sessions",
			deleteSQL: `DELETE FROM auth_sessions WHERE id IN (
				SELECT id FROM auth_sessions
				WHERE expires_at < $1 OR (revoked_at IS NOT NULL AND revoked_at < $1)
				LIMIT $2)`,
		},
		{
			name: "work_sessions",
			deleteSQL: `DELETE FROM work_sessions WHERE id IN (
				SELECT id FROM work_sessions
				WHERE status <> 'open'
				  AND COALESCE(checkout_time, updated_at, created_at) < $1
				LIMIT $2)`,
		},
		{
			name: "wf_tg_activity_sessions",
			deleteSQL: `DELETE FROM wf_tg_activity_sessions WHERE id IN (
				SELECT id FROM wf_tg_activity_sessions
				WHERE status <> 'open'
				  AND COALESCE(ended_at, created_at) < $1
				LIMIT $2)`,
		},
		{
			name: "wf_tg_daily_reset_log",
			deleteSQL: `DELETE FROM wf_tg_daily_reset_log WHERE id IN (
				SELECT id FROM wf_tg_daily_reset_log WHERE run_at < $1 LIMIT $2)`,
		},
		{
			name: "wf_tg_group_reset_log",
			deleteSQL: `DELETE FROM wf_tg_group_reset_log WHERE ctid IN (
				SELECT ctid FROM wf_tg_group_reset_log WHERE run_at < $1 LIMIT $2)`,
		},
		{
			name: "wf_tg_reset_export_log",
			deleteSQL: `DELETE FROM wf_tg_reset_export_log WHERE id IN (
				SELECT id FROM wf_tg_reset_export_log WHERE run_at < $1 LIMIT $2)`,
		},
		{
			name: "wf_tg_handovers",
			deleteSQL: `DELETE FROM wf_tg_handovers WHERE id IN (
				SELECT id FROM wf_tg_handovers WHERE handover_at < $1 LIMIT $2)`,
		},
		{
			name: "wf_tg_bind_tokens",
			deleteSQL: `DELETE FROM wf_tg_bind_tokens WHERE id IN (
				SELECT id FROM wf_tg_bind_tokens WHERE expires_at < $1 LIMIT $2)`,
		},
		{
			name: "user_notifications",
			deleteSQL: `DELETE FROM user_notifications WHERE id IN (
				SELECT id FROM user_notifications
				WHERE is_read = TRUE AND created_at < $1
				LIMIT $2)`,
		},
		{
			name: "dm_check_results",
			deleteSQL: `DELETE FROM dm_check_results WHERE id IN (
				SELECT id FROM dm_check_results WHERE checked_at < $1 LIMIT $2)`,
		},
		{
			name: "cleanup_logs",
			deleteSQL: `DELETE FROM cleanup_logs WHERE id IN (
				SELECT id FROM cleanup_logs WHERE started_at < $1 LIMIT $2)`,
		},
	}
}

func isMissingRelationErr(err error) bool {
	if err == nil {
		return false
	}
	var pqErr *pq.Error
	if errors.As(err, &pqErr) {
		return pqErr.Code == "42P01"
	}
	msg := strings.ToLower(err.Error())
	return strings.Contains(msg, "does not exist") || strings.Contains(msg, "不存在")
}

func (r *CleanupRepository) purgeExpiredLogTables(ctx context.Context, cutoff time.Time, batchSize int) (int, error) {
	if r.db == nil {
		return 0, nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	totalDeleted := 0
	for _, job := range defaultLogPurgeJobs() {
		n, err := r.purgeExpiredLogJob(ctx, job, cutoff, batchSize)
		if err != nil {
			if isMissingRelationErr(err) {
				continue
			}
			return totalDeleted, err
		}
		totalDeleted += n
	}
	return totalDeleted, nil
}

func (r *CleanupRepository) purgeExpiredLogJob(
	ctx context.Context,
	job expiredLogPurgeJob,
	cutoff time.Time,
	batchSize int,
) (int, error) {
	deleted := 0
	batchNum := 0
	limit := batchSize
	if job.batchSize > 0 {
		limit = job.batchSize
	}

	for {
		batchNum++
		result, err := r.db.ExecContext(ctx, job.deleteSQL, cutoff, limit)
		if err != nil {
			if isMissingRelationErr(err) {
				return 0, nil
			}
			return deleted, err
		}
		rowsAffected, _ := result.RowsAffected()
		if rowsAffected == 0 {
			break
		}
		deleted += int(rowsAffected)
		log.Printf("[Cleanup] %s batch %d: deleted %d rows", job.name, batchNum, rowsAffected)
		if rowsAffected < int64(limit) {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if deleted > 0 {
		log.Printf("[Cleanup] %s: deleted %d rows total", job.name, deleted)
	}
	return deleted, nil
}

func (r *CleanupRepository) countAllLogRows(ctx context.Context) int {
	if r.db == nil {
		return 0
	}
	tables := []string{
		"activity_logs",
		"operation_logs",
		"remote_view_audit_logs",
		"remote_view_sessions",
		"upload_tasks",
		"auth_sessions",
		"work_sessions",
		"wf_tg_activity_sessions",
		"wf_tg_daily_reset_log",
		"wf_tg_group_reset_log",
		"wf_tg_reset_export_log",
		"wf_tg_handovers",
		"wf_tg_bind_tokens",
		"user_notifications",
		"dm_check_results",
		"cleanup_logs",
	}
	total := 0
	for _, table := range tables {
		var n int
		err := r.db.QueryRowContext(ctx, `SELECT COALESCE(COUNT(*), 0) FROM `+table).Scan(&n)
		if err == nil {
			total += n
			continue
		}
		if isMissingRelationErr(err) {
			continue
		}
	}
	return total
}

func countTableRows(ctx context.Context, db *sql.DB, table string) int {
	if db == nil {
		return 0
	}
	var n int
	if err := db.QueryRowContext(ctx, `SELECT COALESCE(COUNT(*), 0) FROM `+table).Scan(&n); err != nil {
		return 0
	}
	return n
}

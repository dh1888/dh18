package services

import "testing"

func TestIPMatchesAllowlist(t *testing.T) {
	allowlist := []string{"203.0.113.10", "192.168.1.0/24", "::1"}

	cases := []struct {
		ip    string
		match bool
	}{
		{"203.0.113.10", true},
		{"192.168.1.55", true},
		{"10.0.0.1", false},
		{"::1", true},
	}
	for _, tc := range cases {
		got := IPMatchesAllowlist(tc.ip, allowlist)
		if got != tc.match {
			t.Fatalf("IPMatchesAllowlist(%q) = %v, want %v", tc.ip, got, tc.match)
		}
	}
}

func TestValidateIPAllowlistEntry(t *testing.T) {
	if err := ValidateIPAllowlistEntry("192.168.0.0/24"); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if err := ValidateIPAllowlistEntry("not-an-ip"); err == nil {
		t.Fatal("expected error for invalid ip")
	}
}

package services

import (
	"bytes"
	"context"
	"io"
	"os"
	"testing"
	"time"

	"github.com/redis/go-redis/v9"
)

func testRedisClient(t *testing.T) *redis.Client {
	t.Helper()
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "127.0.0.1:6379"
	}
	client := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: os.Getenv("REDIS_PASSWORD"),
		DB:       15,
	})
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		t.Skipf("redis unavailable at %s: %v", addr, err)
	}
	return client
}

func TestUploadManifestInitDeviceMismatch(t *testing.T) {
	client := testRedisClient(t)
	defer client.Close()

	store := NewUploadManifestStore(client, nil)
	ctx := context.Background()
	uploadID := "manifest-init-" + time.Now().UTC().Format("150405.000")

	t.Cleanup(func() {
		_ = store.Delete(context.Background(), uploadID)
	})

	if err := store.Init(ctx, UploadManifest{
		UploadID: uploadID, DeviceID: "device-a", FileName: "a.mp4", FileType: "recording", TotalChunks: 1,
	}); err != nil {
		t.Fatalf("first init: %v", err)
	}
	if err := store.Init(ctx, UploadManifest{
		UploadID: uploadID, DeviceID: "device-b", FileName: "b.mp4", FileType: "recording", TotalChunks: 1,
	}); err == nil {
		t.Fatal("expected device mismatch on second init")
	}
}

func TestUploadManifestRecordAndVerify(t *testing.T) {
	client := testRedisClient(t)
	defer client.Close()

	root := t.TempDir()
	minio := &MinIOClient{bucket: "test", enabled: true, rootDir: root}
	chunks := NewUploadChunkStore(minio)
	store := NewUploadManifestStore(client, chunks)
	ctx := context.Background()

	uploadID := "manifest-test-" + time.Now().UTC().Format("150405.000")
	deviceID := "device-abc"

	t.Cleanup(func() {
		_ = store.Delete(context.Background(), uploadID)
	})

	if err := store.Init(ctx, UploadManifest{
		UploadID:    uploadID,
		DeviceID:    deviceID,
		FileName:    "clip.mp4",
		FileType:    "recording",
		TotalChunks: 2,
	}); err != nil {
		t.Fatalf("init manifest: %v", err)
	}

	if _, err := store.RecordChunk(ctx, uploadID, 0, 5, "abc"); err != nil {
		t.Fatalf("record chunk 0: %v", err)
	}
	if _, err := store.RecordChunk(ctx, uploadID, 1, 7, "def"); err != nil {
		t.Fatalf("record chunk 1: %v", err)
	}

	manifest, err := store.Verify(ctx, uploadID, deviceID, 2, map[int]string{0: "abc", 1: "def"})
	if err != nil {
		t.Fatalf("verify: %v", err)
	}
	if manifest.TotalChunks != 2 {
		t.Fatalf("expected 2 chunks, got %d", manifest.TotalChunks)
	}

	if _, err := store.Verify(ctx, uploadID, "other-device", 2, nil); err == nil {
		t.Fatal("expected device mismatch error")
	}
}

func TestUploadPipelineE2E(t *testing.T) {
	client := testRedisClient(t)
	defer client.Close()

	root := t.TempDir()
	minio := &MinIOClient{bucket: "test", enabled: true, rootDir: root}
	chunks := NewUploadChunkStore(minio)
	manifest := NewUploadManifestStore(client, chunks)
	ctx := context.Background()

	uploadID := "pipeline-e2e-" + time.Now().UTC().Format("150405.000")
	deviceID := "device-e2e"

	t.Cleanup(func() {
		_ = manifest.Delete(context.Background(), uploadID)
		_ = chunks.DeleteAll(context.Background(), uploadID)
	})

	if err := manifest.Init(ctx, UploadManifest{
		UploadID:    uploadID,
		DeviceID:    deviceID,
		FileName:    "test.bin",
		FileType:    "screenshot",
		TotalChunks: 2,
	}); err != nil {
		t.Fatalf("init: %v", err)
	}

	part0 := []byte("hello-")
	part1 := []byte("world")
	if err := chunks.Save(ctx, uploadID, 0, part0); err != nil {
		t.Fatalf("save chunk 0: %v", err)
	}
	if err := chunks.Save(ctx, uploadID, 1, part1); err != nil {
		t.Fatalf("save chunk 1: %v", err)
	}
	if _, err := manifest.RecordChunk(ctx, uploadID, 0, int64(len(part0)), "c0"); err != nil {
		t.Fatalf("manifest chunk 0: %v", err)
	}
	if _, err := manifest.RecordChunk(ctx, uploadID, 1, int64(len(part1)), "c1"); err != nil {
		t.Fatalf("manifest chunk 1: %v", err)
	}

	if _, err := manifest.Verify(ctx, uploadID, deviceID, 2, map[int]string{0: "c0", 1: "c1"}); err != nil {
		t.Fatalf("verify manifest: %v", err)
	}
	if count, err := chunks.CountChunks(ctx, uploadID, 2); err != nil || count != 2 {
		t.Fatalf("count chunks: count=%d err=%v", count, err)
	}

	merge := chunks.MergeReader(ctx, uploadID, 2)
	defer merge.Close()
	var buf bytes.Buffer
	if _, err := io.Copy(&buf, merge); err != nil {
		t.Fatalf("merge read: %v", err)
	}
	if buf.String() != "hello-world" {
		t.Fatalf("merged payload = %q", buf.String())
	}
}

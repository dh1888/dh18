package services

import (
	"context"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

// UploadSharedStorageEnabled indicates UPLOADS_DIR is mounted shared across app instances.
func UploadSharedStorageEnabled() bool {
	v := strings.TrimSpace(os.Getenv("UPLOAD_SHARED_STORAGE"))
	return v == "true" || v == "1"
}

// ValidateDeploymentConsistency enforces production dependencies for session/upload/WS coherence.
func ValidateDeploymentConsistency(ctx context.Context, redisClient *redis.Client, minio *MinIOClient) error {
	if !IsProductionEnv() {
		return nil
	}
	if redisClient == nil {
		return fmt.Errorf("REDIS_ADDR is required in production (session SSOT, upload manifest, WS revoke bus)")
	}
	pingCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	if err := redisClient.Ping(pingCtx).Err(); err != nil {
		return fmt.Errorf("redis ping failed at startup: %w", err)
	}

	chunkStore := NewUploadChunkStore(minio)
	if chunkStore != nil && chunkStore.SharedAcrossInstances() {
		return verifyRemoteObjectStore(pingCtx, minio)
	}
	if UploadSharedStorageEnabled() {
		return nil
	}
	return fmt.Errorf("production requires shared upload storage: set MINIO_ENDPOINT or UPLOAD_SHARED_STORAGE=true")
}

func verifyRemoteObjectStore(ctx context.Context, minio *MinIOClient) error {
	if minio == nil || !minio.UsesRemote() {
		return fmt.Errorf("MINIO_ENDPOINT is required for remote upload chunk storage")
	}
	probe := []byte("startup-probe")
	key := "upload-chunks/.startup-probe"
	if err := minio.Save(ctx, key, probe); err != nil {
		return fmt.Errorf("minio write probe failed: %w", err)
	}
	rc, err := minio.Open(ctx, key)
	if err != nil {
		return fmt.Errorf("minio read probe failed: %w", err)
	}
	_ = rc.Close()
	_ = minio.RemoveObject(ctx, key)
	return nil
}

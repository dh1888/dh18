package services

import (
	"context"
	"fmt"
	"strings"

	"github.com/google/uuid"
)

const archiveActivitySessionsInsertSQL = `
		INSERT INTO wf_tg_activity_sessions_archive (
			id, employee_id, activity_code, activity_name, attendance_date,
			started_at, ended_at, elapsed_seconds, overtime_seconds, fine_amount,
			status, source, end_source, shift_type, source_chat_id, archived_at
		)
		SELECT
			s.id, s.employee_id, s.activity_code, s.activity_name, s.attendance_date,
			s.started_at, s.ended_at, s.elapsed_seconds, s.overtime_seconds, s.fine_amount,
			s.status, s.source, s.end_source, COALESCE(s.shift_type,'day'), s.source_chat_id, NOW()
		FROM wf_tg_activity_sessions s
		WHERE %s
		ON CONFLICT (id) DO NOTHING`

func (s *WorkforceTelegramService) archiveClosedActivitySessionsByGroupDate(ctx context.Context, tx execContext, chatID, exportDate string) error {
	chatID = strings.TrimSpace(chatID)
	exportDate = strings.TrimSpace(exportDate)
	if chatID == "" || exportDate == "" {
		return nil
	}
	where := `s.status = 'closed' AND s.attendance_date = $2::date AND COALESCE(s.source_chat_id,'') = $1`
	_, err := tx.ExecContext(ctx, fmt.Sprintf(archiveActivitySessionsInsertSQL, where), chatID, exportDate)
	return err
}

func (s *WorkforceTelegramService) archiveActivitySessionsByEmployeeDate(ctx context.Context, tx execContext, employeeID uuid.UUID, attendanceDate string) error {
	if employeeID == uuid.Nil || strings.TrimSpace(attendanceDate) == "" {
		return nil
	}
	where := `s.attendance_date = $2::date AND s.employee_id = $1`
	_, err := tx.ExecContext(ctx, fmt.Sprintf(archiveActivitySessionsInsertSQL, where), employeeID, attendanceDate)
	return err
}

func (s *WorkforceTelegramService) mergeActivityStatsIntoMonthlyForEmployeeDateTx(ctx context.Context, tx execContext, employeeID uuid.UUID, exportDate string) error {
	if employeeID == uuid.Nil {
		return nil
	}
	exportDate = strings.TrimSpace(exportDate)
	if exportDate == "" || len(exportDate) < 7 {
		return nil
	}
	yearMonth := exportDate[:7]
	_, err := tx.ExecContext(ctx, `
		INSERT INTO wf_tg_monthly_activity_stats (
			year_month, chat_id, employee_id, shift_type, activity_code, activity_name,
			activity_count, total_seconds, fine_total, archived_at
		)
		SELECT $1, COALESCE(s.source_chat_id,''), s.employee_id, COALESCE(s.shift_type,'day'),
			s.activity_code, s.activity_name,
			COUNT(*)::int, COALESCE(SUM(s.elapsed_seconds),0)::int, COALESCE(SUM(s.fine_amount),0), NOW()
		FROM wf_tg_activity_sessions s
		WHERE s.status = 'closed' AND s.attendance_date = $2::date AND s.employee_id = $3
		GROUP BY COALESCE(s.source_chat_id,''), s.employee_id, COALESCE(s.shift_type,'day'),
			s.activity_code, s.activity_name
		ON CONFLICT (year_month, chat_id, employee_id, shift_type, activity_code) DO UPDATE SET
			activity_name = EXCLUDED.activity_name,
			activity_count = wf_tg_monthly_activity_stats.activity_count + EXCLUDED.activity_count,
			total_seconds = wf_tg_monthly_activity_stats.total_seconds + EXCLUDED.total_seconds,
			fine_total = wf_tg_monthly_activity_stats.fine_total + EXCLUDED.fine_total,
			archived_at = NOW()`, yearMonth, exportDate, employeeID)
	return err
}

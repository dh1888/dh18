package services

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/pquerna/otp"
	"github.com/pquerna/otp/totp"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
)

const (
	loginChallengePrefix = "login:challenge:"
	loginChallengeTTL    = 5 * time.Minute
	totpIssuer           = "DHPG"
)

type LoginChallengePurpose string

const (
	LoginChallengeVerify LoginChallengePurpose = "verify"
	LoginChallengeSetup  LoginChallengePurpose = "setup"
	LoginChallengeBind   LoginChallengePurpose = "bind"
)

type LoginChallengePayload struct {
	UserID            string                `json:"userId"`
	Username          string                `json:"username"`
	Purpose           LoginChallengePurpose `json:"purpose"`
	PendingTotpSecret string                `json:"pendingTotpSecret,omitempty"`
}

type TOTPAuthService struct {
	redis *redis.Client
}

func NewTOTPAuthService(redisClient *redis.Client) *TOTPAuthService {
	return &TOTPAuthService{redis: redisClient}
}

func totpEncryptionKey() []byte {
	secret := strings.TrimSpace(os.Getenv("TOTP_ENCRYPTION_KEY"))
	if secret == "" {
		secret = string(models.JWTSecret())
	}
	sum := sha256.Sum256([]byte(secret))
	return sum[:]
}

func EncryptTotpSecret(plain string) (string, error) {
	if plain == "" {
		return "", nil
	}
	block, err := aes.NewCipher(totpEncryptionKey())
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	ciphertext := gcm.Seal(nonce, nonce, []byte(plain), nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func DecryptTotpSecret(encoded string) (string, error) {
	if encoded == "" {
		return "", nil
	}
	raw, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher(totpEncryptionKey())
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	if len(raw) < gcm.NonceSize() {
	 return "", errors.New("invalid totp secret payload")
	}
	nonce, ciphertext := raw[:gcm.NonceSize()], raw[gcm.NonceSize():]
	plain, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}
	return string(plain), nil
}

func GenerateTotpKey(username string) (*otp.Key, error) {
	return totp.Generate(totp.GenerateOpts{
		Issuer:      totpIssuer,
		AccountName: username,
		SecretSize:  20,
	})
}

func ValidateTotpCode(secret, code string) bool {
	code = strings.TrimSpace(code)
	secret = strings.TrimSpace(secret)
	if secret == "" || code == "" {
		return false
	}
	return totp.Validate(code, secret)
}

func (s *TOTPAuthService) CreateChallenge(ctx context.Context, payload LoginChallengePayload) (string, error) {
	if s.redis == nil {
		return "", fmt.Errorf("login challenge store unavailable")
	}
	id := uuid.NewString()
	data, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}
	if err := s.redis.Set(ctx, loginChallengePrefix+id, data, loginChallengeTTL).Err(); err != nil {
		return "", err
	}
	return id, nil
}

func (s *TOTPAuthService) LoadChallenge(ctx context.Context, id string) (*LoginChallengePayload, error) {
	if s.redis == nil {
		return nil, fmt.Errorf("login challenge store unavailable")
	}
	raw, err := s.redis.Get(ctx, loginChallengePrefix+strings.TrimSpace(id)).Bytes()
	if err != nil {
		if err == redis.Nil {
			return nil, errors.New("login challenge expired or invalid")
		}
		return nil, err
	}
	var payload LoginChallengePayload
	if err := json.Unmarshal(raw, &payload); err != nil {
		return nil, err
	}
	return &payload, nil
}

func (s *TOTPAuthService) DeleteChallenge(ctx context.Context, id string) error {
	if s.redis == nil {
		return fmt.Errorf("login challenge store unavailable")
	}
	return s.redis.Del(ctx, loginChallengePrefix+strings.TrimSpace(id)).Err()
}

// ConsumeChallenge removes the challenge after a successful read (legacy).
func (s *TOTPAuthService) StartBindChallenge(ctx context.Context, userID, username string) (challengeID, provisioningURI string, err error) {
	key, err := GenerateTotpKey(username)
	if err != nil {
		return "", "", err
	}
	challengeID, err = s.CreateChallenge(ctx, LoginChallengePayload{
		UserID:            userID,
		Username:          username,
		Purpose:           LoginChallengeBind,
		PendingTotpSecret: key.Secret(),
	})
	if err != nil {
		return "", "", err
	}
	return challengeID, key.URL(), nil
}

func (s *TOTPAuthService) ConfirmBindChallenge(ctx context.Context, challengeID, code string, userID uuid.UUID) (plainSecret string, err error) {
	payload, err := s.LoadChallenge(ctx, challengeID)
	if err != nil {
		return "", err
	}
	if payload.Purpose != LoginChallengeBind {
		return "", errors.New("invalid bind challenge")
	}
	if payload.UserID != userID.String() {
		return "", errors.New("bind challenge user mismatch")
	}
	if !ValidateTotpCode(payload.PendingTotpSecret, code) {
		return "", errors.New("invalid totp code")
	}
	if err := s.DeleteChallenge(ctx, challengeID); err != nil {
		return "", err
	}
	return payload.PendingTotpSecret, nil
}

func (s *TOTPAuthService) ConsumeChallenge(ctx context.Context, id string) (*LoginChallengePayload, error) {
	payload, err := s.LoadChallenge(ctx, id)
	if err != nil {
		return nil, err
	}
	if err := s.DeleteChallenge(ctx, id); err != nil {
		return nil, err
	}
	return payload, nil
}

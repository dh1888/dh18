package services

import (
	"context"
	"os"
	"sync"
	"testing"
	"time"

	"github.com/redis/go-redis/v9"
)

func testUploadRedis(t *testing.T) *redis.Client {
	t.Helper()
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "127.0.0.1:6379"
	}
	client := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: os.Getenv("REDIS_PASSWORD"),
		DB:       12,
	})
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		t.Skipf("redis unavailable at %s: %v", addr, err)
	}
	return client
}

func TestUploadCompleteLockExclusive(t *testing.T) {
	client := testUploadRedis(t)
	defer client.Close()

	lock := NewUploadCompleteLock(client)
	ctx := context.Background()
	uploadID := "lock-test-" + time.Now().Format("150405.000000")

	release1, ok1, err := lock.Acquire(ctx, uploadID)
	if err != nil || !ok1 {
		t.Fatalf("first acquire: ok=%v err=%v", ok1, err)
	}
	defer release1()

	_, ok2, err := lock.Acquire(ctx, uploadID)
	if err != nil {
		t.Fatalf("second acquire err: %v", err)
	}
	if ok2 {
		t.Fatal("expected second acquire to fail")
	}

	release1()
	time.Sleep(50 * time.Millisecond)

	release3, ok3, err := lock.Acquire(ctx, uploadID)
	if err != nil || !ok3 {
		t.Fatalf("third acquire after release: ok=%v err=%v", ok3, err)
	}
	release3()
}

func TestUploadCompleteLockConcurrentAcquire(t *testing.T) {
	client := testUploadRedis(t)
	defer client.Close()

	lock := NewUploadCompleteLock(client)
	ctx := context.Background()
	uploadID := "lock-race-" + time.Now().Format("150405.000000")

	var wg sync.WaitGroup
	var winners int32
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			release, ok, err := lock.Acquire(ctx, uploadID)
			if err != nil {
				return
			}
			if ok {
				winners++
				time.Sleep(20 * time.Millisecond)
				release()
			}
		}()
	}
	wg.Wait()
	if winners == 0 {
		t.Fatal("expected at least one winner")
	}
}

func TestUploadManifestVerifyMissingIndex(t *testing.T) {
	client := testUploadRedis(t)
	defer client.Close()

	store := NewUploadManifestStore(client, nil)
	ctx := context.Background()
	uploadID := "verify-gap-" + time.Now().Format("150405.000000")
	deviceID := "device-verify"

	t.Cleanup(func() {
		_ = store.Delete(context.Background(), uploadID)
	})

	if err := store.Init(ctx, UploadManifest{
		UploadID: uploadID, DeviceID: deviceID, FileName: "f.bin",
		FileType: "screenshot", TotalChunks: 3,
	}); err != nil {
		t.Fatalf("init: %v", err)
	}
	if _, err := store.RecordChunk(ctx, uploadID, 0, 1, "a"); err != nil {
		t.Fatalf("chunk 0: %v", err)
	}
	if _, err := store.RecordChunk(ctx, uploadID, 2, 1, "c"); err != nil {
		t.Fatalf("chunk 2: %v", err)
	}

	if _, err := store.Verify(ctx, uploadID, deviceID, 3, nil); err == nil {
		t.Fatal("expected missing index 1 to fail verify")
	}
}

func TestUploadManifestVerifyChecksumMismatch(t *testing.T) {
	client := testUploadRedis(t)
	defer client.Close()

	store := NewUploadManifestStore(client, nil)
	ctx := context.Background()
	uploadID := "verify-chk-" + time.Now().Format("150405.000000")

	t.Cleanup(func() {
		_ = store.Delete(context.Background(), uploadID)
	})

	if err := store.Init(ctx, UploadManifest{
		UploadID: uploadID, DeviceID: "dev", FileName: "f.bin",
		FileType: "screenshot", TotalChunks: 1,
	}); err != nil {
		t.Fatalf("init: %v", err)
	}
	if _, err := store.RecordChunk(ctx, uploadID, 0, 4, "real-checksum"); err != nil {
		t.Fatalf("record: %v", err)
	}
	if _, err := store.Verify(ctx, uploadID, "dev", 1, map[int]string{0: "wrong"}); err == nil {
		t.Fatal("expected checksum mismatch")
	}
}

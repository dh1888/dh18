package services

import (
	"context"
	"database/sql"
	"os"
	"strings"
)

// CaptureLinkedToCheckinEnvOverride returns (enabled, explicit) when TELEGRAM_AGENT_CAPTURE_ENABLED is set.
func CaptureLinkedToCheckinEnvOverride() (bool, bool) {
	v := strings.TrimSpace(os.Getenv("TELEGRAM_AGENT_CAPTURE_ENABLED"))
	if v == "" {
		return false, false
	}
	lower := strings.ToLower(v)
	return lower == "true" || lower == "1" || lower == "yes", true
}

// CaptureLinkedToCheckin reports whether check-in (client or Telegram) should start/stop capture.
// Default false: follow policy auto capture. Env var overrides DB when explicitly set.
func CaptureLinkedToCheckin(ctx context.Context, db *sql.DB) bool {
	if enabled, explicit := CaptureLinkedToCheckinEnvOverride(); explicit {
		return enabled
	}
	if db == nil {
		return false
	}
	var linked bool
	err := db.QueryRowContext(ctx, `
		SELECT COALESCE(capture_linked_to_checkin, FALSE)
		FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).Scan(&linked)
	if err != nil {
		return false
	}
	return linked
}

// backend/services/screenshot_repository.go
// 完整修复版本 - 删除重复方法、统一辅助函数、修复命名一致性

package services

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

// ScreenshotRepository 截图仓库
// 主存储：PostgreSQL，内存作为一级缓存
type ScreenshotRepository struct {
	db          *sql.DB
	mu          sync.RWMutex
	screenshots map[string]*models.Screenshot // 缓存，key 为 ID
}

// NewScreenshotRepository 创建截图仓库
func NewScreenshotRepository(db *sql.DB) *ScreenshotRepository {
	repo := &ScreenshotRepository{
		db:          db,
		screenshots: make(map[string]*models.Screenshot),
	}
	if db != nil {
		repo.ensureTable()
		repo.loadScreenshots()
	}
	return repo
}

// ensureTable 确保表存在且结构正确 - device_id 使用 UUID 外键
func (r *ScreenshotRepository) ensureTable() {
	createTableSQL := `
		CREATE TABLE IF NOT EXISTS screenshots (
			id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
			device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
			captured_at TIMESTAMP WITH TIME ZONE NOT NULL,
			file_path TEXT NOT NULL,
			file_size BIGINT NOT NULL DEFAULT 0,
			uploaded BOOLEAN NOT NULL DEFAULT FALSE,
			created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
		)
	`

	indexes := []string{
		`CREATE INDEX IF NOT EXISTS idx_screenshots_device_id ON screenshots(device_id)`,
		`CREATE INDEX IF NOT EXISTS idx_screenshots_captured_at ON screenshots(captured_at)`,
		`CREATE INDEX IF NOT EXISTS idx_screenshots_device_captured ON screenshots(device_id, captured_at DESC)`,
		`CREATE INDEX IF NOT EXISTS idx_screenshots_uploaded ON screenshots(uploaded)`,
	}

	if _, err := r.db.Exec(createTableSQL); err != nil {
		if strings.Contains(err.Error(), "already exists") {
			r.migrateTable()
		}
	}

	for _, idx := range indexes {
		_, _ = r.db.Exec(idx)
	}
}

// migrateTable 迁移旧表结构（将 device_id 从 VARCHAR 转为 UUID）
func (r *ScreenshotRepository) migrateTable() {
	var columnType string
	err := r.db.QueryRow(`
		SELECT data_type 
		FROM information_schema.columns 
		WHERE table_name = 'screenshots' AND column_name = 'device_id'
	`).Scan(&columnType)

	if err != nil {
		_, _ = r.db.Exec(`ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS device_id UUID`)
		return
	}

	if strings.ToLower(columnType) == "character varying" || columnType == "varchar" {
		_, _ = r.db.Exec(`ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS device_id_temp UUID`)

		_, _ = r.db.Exec(`
			UPDATE screenshots 
			SET device_id_temp = d.id 
			FROM devices d 
			WHERE screenshots.device_id::text = d.device_fingerprint
		`)

		_, _ = r.db.Exec(`ALTER TABLE screenshots DROP COLUMN IF EXISTS device_id`)
		_, _ = r.db.Exec(`ALTER TABLE screenshots RENAME COLUMN device_id_temp TO device_id`)
		_, _ = r.db.Exec(`ALTER TABLE screenshots ALTER COLUMN device_id SET NOT NULL`)

		_, _ = r.db.Exec(`
			ALTER TABLE screenshots 
			ADD CONSTRAINT fk_screenshots_device 
			FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
		`)

		_, _ = r.db.Exec(`CREATE INDEX IF NOT EXISTS idx_screenshots_device_id ON screenshots(device_id)`)
		_, _ = r.db.Exec(`CREATE INDEX IF NOT EXISTS idx_screenshots_device_captured ON screenshots(device_id, captured_at DESC)`)
	}
}

// loadScreenshots 从数据库加载最近的截图到内存缓存
func (r *ScreenshotRepository) loadScreenshots() {
	rows, err := r.db.Query(`
		SELECT id, device_id, captured_at, file_path, file_size, uploaded, created_at
		FROM screenshots
		ORDER BY captured_at DESC
		LIMIT 5000
	`)
	if err != nil {
		return
	}
	defer rows.Close()

	r.mu.Lock()
	defer r.mu.Unlock()

	for rows.Next() {
		var s models.Screenshot
		var id uuid.UUID
		var deviceUUID uuid.UUID
		var capturedAt, createdAt time.Time

		if err := rows.Scan(&id, &deviceUUID, &capturedAt, &s.FilePath, &s.FileSize, &s.Uploaded, &createdAt); err != nil {
			continue
		}
		s.ID = id.String()
		s.DeviceID = deviceUUID.String()
		s.CapturedAt = capturedAt
		s.CreatedAt = createdAt
		r.screenshots[s.ID] = &s
	}
}

// resolveDeviceUUID 将设备标识（UUID字符串或fingerprint）转换为UUID
func (r *ScreenshotRepository) resolveDeviceUUID(ctx context.Context, deviceID string) (uuid.UUID, error) {
	// 先尝试直接解析为 UUID
	if deviceUUID, err := uuid.Parse(deviceID); err == nil {
		return deviceUUID, nil
	}

	// 解析失败，尝试通过 device_fingerprint 查找
	var deviceUUID uuid.UUID
	err := r.db.QueryRowContext(ctx, `SELECT id FROM devices WHERE device_fingerprint = $1`, deviceID).Scan(&deviceUUID)
	if err != nil {
		return uuid.Nil, fmt.Errorf("device not found: %s", deviceID)
	}
	return deviceUUID, nil
}

// List 获取截图列表（分页）- 支持日期和时间筛选
func (r *ScreenshotRepository) List(ctx context.Context, deviceID, employeeUUID, startDate, endDate, startTime, endTime string, page, pageSize int) ([]models.Screenshot, int, error) {
    offset := (page - 1) * pageSize
    args := []interface{}{}
    where := []string{"1=1"}
    argIdx := 1

    // 1. 设备ID筛选
    if deviceID != "" {
        deviceUUID, err := r.resolveDeviceUUID(ctx, deviceID)
        if err != nil {
            return nil, 0, fmt.Errorf("resolve device UUID failed: %w", err)
        }
        where = append(where, fmt.Sprintf("s.device_id = $%d", argIdx))
        args = append(args, deviceUUID)
        argIdx++
    }

    // 1b. 共享工位：按截图所属员工筛选
    if employeeUUID != "" {
        empID, err := uuid.Parse(strings.TrimSpace(employeeUUID))
        if err != nil {
            return nil, 0, fmt.Errorf("invalid employeeUuid: %w", err)
        }
        where = append(where, fmt.Sprintf(`(
            s.employee_uuid = $%d
            OR (s.employee_uuid IS NULL AND d.employee_uuid = $%d)
        )`, argIdx, argIdx))
        args = append(args, empID)
        argIdx++
    }

    // 2. 日期范围筛选（统一使用 UTC 时间）
    if startDate != "" && endDate != "" {
        // 解析开始日期
        startTimeUTC, err := time.Parse(time.RFC3339, startDate)
        if err != nil {
            return nil, 0, fmt.Errorf("invalid startDate format: %s, error: %w", startDate, err)
        }
        
        // 解析结束日期
        endTimeUTC, err := time.Parse(time.RFC3339, endDate)
        if err != nil {
            return nil, 0, fmt.Errorf("invalid endDate format: %s, error: %w", endDate, err)
        }
        
        where = append(where, fmt.Sprintf("s.captured_at >= $%d AND s.captured_at <= $%d", argIdx, argIdx+1))
        args = append(args, startTimeUTC, endTimeUTC)
        argIdx += 2
    } else if startDate != "" {
        // 只有开始日期
        startTimeUTC, err := time.Parse(time.RFC3339, startDate)
        if err != nil {
            return nil, 0, fmt.Errorf("invalid startDate format: %s, error: %w", startDate, err)
        }
        where = append(where, fmt.Sprintf("s.captured_at >= $%d", argIdx))
        args = append(args, startTimeUTC)
        argIdx++
    } else if endDate != "" {
        // 只有结束日期
        endTimeUTC, err := time.Parse(time.RFC3339, endDate)
        if err != nil {
            return nil, 0, fmt.Errorf("invalid endDate format: %s, error: %w", endDate, err)
        }
        where = append(where, fmt.Sprintf("s.captured_at <= $%d", argIdx))
        args = append(args, endTimeUTC)
        argIdx++
    }

    // 3. 小时范围筛选（支持跨天）
    if startTime != "" && endTime != "" {
        startHour, err := parseHour(startTime)
        if err != nil {
            return nil, 0, fmt.Errorf("invalid startTime format: %s, error: %w", startTime, err)
        }
        endHour, err := parseHour(endTime)
        if err != nil {
            return nil, 0, fmt.Errorf("invalid endTime format: %s, error: %w", endTime, err)
        }
        
        // 处理跨天情况（例如：22:00 到 06:00）
        if startHour <= endHour {
            where = append(where, fmt.Sprintf("EXTRACT(HOUR FROM s.captured_at) BETWEEN $%d AND $%d", argIdx, argIdx+1))
        } else {
            where = append(where, fmt.Sprintf("(EXTRACT(HOUR FROM s.captured_at) >= $%d OR EXTRACT(HOUR FROM s.captured_at) <= $%d)", argIdx, argIdx+1))
        }
        args = append(args, startHour, endHour)
        argIdx += 2
    }

    whereClause := strings.Join(where, " AND ")

    // 4. 查询总数
    countQuery := `SELECT COUNT(*) FROM screenshots s LEFT JOIN devices d ON d.id = s.device_id WHERE ` + whereClause
    var total int
    if err := r.db.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
        return nil, 0, fmt.Errorf("count query failed: %w", err)
    }

    // 5. 查询数据
    dataQuery := fmt.Sprintf(`
        SELECT s.id, s.device_id, s.captured_at, s.file_path, s.file_size, s.uploaded, s.created_at,
               COALESCE(NULLIF(s.employee_name, ''), d.employee_name, '') AS employee_name,
               COALESCE(NULLIF(s.employee_number, ''), d.employee_number, '') AS employee_number,
               COALESCE(s.employee_uuid::text, d.employee_uuid::text, '') AS employee_uuid
        FROM screenshots s
        LEFT JOIN devices d ON d.id = s.device_id
        WHERE %s
        ORDER BY s.captured_at DESC
        LIMIT $%d OFFSET $%d
    `, whereClause, argIdx, argIdx+1)

    args = append(args, pageSize, offset)

    rows, err := r.db.QueryContext(ctx, dataQuery, args...)
    if err != nil {
        return nil, 0, fmt.Errorf("data query failed: %w", err)
    }
    defer rows.Close()

    var screenshots []models.Screenshot
    for rows.Next() {
        var s models.Screenshot
        var id uuid.UUID
        var deviceUUID uuid.UUID
        var capturedAt, createdAt time.Time
        var employeeName, employeeNumber, employeeUUID sql.NullString

        if err := rows.Scan(&id, &deviceUUID, &capturedAt, &s.FilePath, &s.FileSize, &s.Uploaded, &createdAt,
            &employeeName, &employeeNumber, &employeeUUID); err != nil {
            return nil, 0, fmt.Errorf("scan row failed: %w", err)
        }
        s.ID = id.String()
        s.DeviceID = deviceUUID.String()
        s.CapturedAt = capturedAt
        s.CreatedAt = createdAt
        if employeeName.Valid {
            s.EmployeeName = employeeName.String
        }
        if employeeNumber.Valid {
            s.EmployeeNumber = employeeNumber.String
        }
        if employeeUUID.Valid {
            s.EmployeeUUID = employeeUUID.String
        }
        screenshots = append(screenshots, s)
    }

    return screenshots, total, nil
}

// GetByID 根据ID获取截图
func (r *ScreenshotRepository) GetByID(ctx context.Context, id string) (*models.Screenshot, error) {
	// 先查缓存
	r.mu.RLock()
	if s, ok := r.screenshots[id]; ok {
		sCopy := *s
		r.mu.RUnlock()
		return &sCopy, nil
	}
	r.mu.RUnlock()

	// 缓存未命中，查询数据库
	var s models.Screenshot
	var uid uuid.UUID
	var deviceUUID uuid.UUID
	var capturedAt, createdAt time.Time

	query := `
		SELECT s.id, s.device_id, s.captured_at, s.file_path, s.file_size, s.uploaded, s.created_at,
		       COALESCE(NULLIF(s.employee_name, ''), d.employee_name, '') AS employee_name,
		       COALESCE(NULLIF(s.employee_number, ''), d.employee_number, '') AS employee_number,
		       COALESCE(s.employee_uuid::text, d.employee_uuid::text, '') AS employee_uuid
		FROM screenshots s
		LEFT JOIN devices d ON d.id = s.device_id
		WHERE s.id = $1
	`
	var employeeName, employeeNumber, employeeUUID sql.NullString
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&uid, &deviceUUID, &capturedAt, &s.FilePath, &s.FileSize, &s.Uploaded, &createdAt,
		&employeeName, &employeeNumber, &employeeUUID)
	if err == sql.ErrNoRows {
		return nil, err
	}
	if err != nil {
		return nil, err
	}

	s.ID = uid.String()
	s.DeviceID = deviceUUID.String()
	s.CapturedAt = capturedAt
	s.CreatedAt = createdAt
	if employeeName.Valid {
		s.EmployeeName = employeeName.String
	}
	if employeeNumber.Valid {
		s.EmployeeNumber = employeeNumber.String
	}
	if employeeUUID.Valid {
		s.EmployeeUUID = employeeUUID.String
	}

	// 更新缓存
	r.mu.Lock()
	r.screenshots[s.ID] = &s
	r.mu.Unlock()

	return &s, nil
}

// Add 添加截图
func (r *ScreenshotRepository) Add(ctx context.Context, screenshot *models.Screenshot) error {
	if screenshot.ID == "" {
		screenshot.ID = uuid.New().String()
	}
	if screenshot.CreatedAt.IsZero() {
		screenshot.CreatedAt = time.Now().UTC()
	}

	// 转换 DeviceID 为 UUID
	deviceUUID, err := r.resolveDeviceUUID(ctx, screenshot.DeviceID)
	if err != nil {
		return err
	}

	id, err := uuid.Parse(screenshot.ID)
	if err != nil {
		return fmt.Errorf("invalid screenshot ID: %w", err)
	}

	query := `
		INSERT INTO screenshots (id, device_id, captured_at, file_path, file_size, uploaded, created_at, employee_uuid, employee_name, employee_number)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
		ON CONFLICT (id) DO UPDATE SET
			device_id = EXCLUDED.device_id,
			captured_at = EXCLUDED.captured_at,
			file_path = EXCLUDED.file_path,
			file_size = EXCLUDED.file_size,
			uploaded = EXCLUDED.uploaded,
			employee_uuid = COALESCE(EXCLUDED.employee_uuid, screenshots.employee_uuid),
			employee_name = COALESCE(NULLIF(EXCLUDED.employee_name, ''), screenshots.employee_name),
			employee_number = COALESCE(NULLIF(EXCLUDED.employee_number, ''), screenshots.employee_number)
	`
	var empUUID interface{}
	if screenshot.EmployeeUUID != "" {
		if parsed, parseErr := uuid.Parse(screenshot.EmployeeUUID); parseErr == nil {
			empUUID = parsed
		}
	}
	_, err = r.db.ExecContext(ctx, query,
		id, deviceUUID, screenshot.CapturedAt,
		screenshot.FilePath, screenshot.FileSize, screenshot.Uploaded, screenshot.CreatedAt,
		empUUID, nullString(screenshot.EmployeeName), nullString(screenshot.EmployeeNumber))
	if err != nil {
		return err
	}

	// 更新缓存
	r.mu.Lock()
	r.screenshots[screenshot.ID] = screenshot
	r.mu.Unlock()

	return nil
}

// ExistsByFilePathPattern 检查是否已有以 uploadId 为文件名的存储记录
func (r *ScreenshotRepository) ExistsByFilePathPattern(ctx context.Context, pattern string) (bool, error) {
	var exists bool
	err := r.db.QueryRowContext(ctx,
		`SELECT EXISTS(SELECT 1 FROM screenshots WHERE file_path LIKE $1)`,
		pattern).Scan(&exists)
	return exists, err
}

// BatchAdd 批量添加截图
func (r *ScreenshotRepository) BatchAdd(ctx context.Context, screenshots []models.Screenshot) error {
	if len(screenshots) == 0 {
		return nil
	}

	// 准备所有ID
	for i := range screenshots {
		if screenshots[i].ID == "" {
			screenshots[i].ID = uuid.New().String()
		}
		if screenshots[i].CreatedAt.IsZero() {
			screenshots[i].CreatedAt = time.Now().UTC()
		}
	}

	// 使用事务批量插入
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	stmt, err := tx.PrepareContext(ctx, `
		INSERT INTO screenshots (id, device_id, captured_at, file_path, file_size, uploaded, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7)
		ON CONFLICT (id) DO UPDATE SET
			device_id = EXCLUDED.device_id,
			captured_at = EXCLUDED.captured_at,
			file_path = EXCLUDED.file_path,
			file_size = EXCLUDED.file_size,
			uploaded = EXCLUDED.uploaded
	`)
	if err != nil {
		return err
	}
	defer stmt.Close()

	for _, s := range screenshots {
		deviceUUID, err := r.resolveDeviceUUID(ctx, s.DeviceID)
		if err != nil {
			return err
		}

		id, err := uuid.Parse(s.ID)
		if err != nil {
			return fmt.Errorf("invalid screenshot ID: %w", err)
		}

		_, err = stmt.ExecContext(ctx,
			id, deviceUUID, s.CapturedAt, s.FilePath, s.FileSize, s.Uploaded, s.CreatedAt)
		if err != nil {
			return err
		}
	}

	if err := tx.Commit(); err != nil {
		return err
	}

	// 更新缓存
	r.mu.Lock()
	for i := range screenshots {
		r.screenshots[screenshots[i].ID] = &screenshots[i]
	}
	r.mu.Unlock()

	return nil
}

// Delete 删除单张截图
func (r *ScreenshotRepository) Delete(ctx context.Context, id string) error {
	result, err := r.db.ExecContext(ctx, `DELETE FROM screenshots WHERE id = $1`, id)
	if err != nil {
		return err
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		return sql.ErrNoRows
	}

	// 从缓存中删除
	r.mu.Lock()
	delete(r.screenshots, id)
	r.mu.Unlock()

	return nil
}

// DeleteBatch 批量删除截图
func (r *ScreenshotRepository) DeleteBatch(ctx context.Context, ids []string) error {
	if len(ids) == 0 {
		return nil
	}

	placeholders := make([]string, len(ids))
	args := make([]interface{}, len(ids))
	for i, id := range ids {
		placeholders[i] = formatPlaceholder(i + 1)
		args[i] = id
	}
	placeholderStr := strings.Join(placeholders, ",")

	query := `DELETE FROM screenshots WHERE id IN (` + placeholderStr + `)`
	_, err := r.db.ExecContext(ctx, query, args...)
	if err != nil {
		return err
	}

	// 从缓存中删除
	r.mu.Lock()
	for _, id := range ids {
		delete(r.screenshots, id)
	}
	r.mu.Unlock()

	return nil
}

// DeleteByDeviceID 删除指定设备的所有截图
func (r *ScreenshotRepository) DeleteByDeviceID(ctx context.Context, deviceID string) (int64, error) {
	deviceUUID, err := r.resolveDeviceUUID(ctx, deviceID)
	if err != nil {
		return 0, err
	}

	result, err := r.db.ExecContext(ctx, `DELETE FROM screenshots WHERE device_id = $1`, deviceUUID)
	if err != nil {
		return 0, err
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected > 0 {
		r.mu.Lock()
		for id, s := range r.screenshots {
			if s.DeviceID == deviceUUID.String() {
				delete(r.screenshots, id)
			}
		}
		r.mu.Unlock()
	}

	return rowsAffected, nil
}

// DeleteOlderThan 删除指定时间之前的截图
func (r *ScreenshotRepository) DeleteOlderThan(ctx context.Context, cutoff time.Time) (int64, error) {
	result, err := r.db.ExecContext(ctx, `DELETE FROM screenshots WHERE captured_at < $1`, cutoff)
	if err != nil {
		return 0, err
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected > 0 {
		r.mu.Lock()
		for id, s := range r.screenshots {
			if s.CapturedAt.Before(cutoff) {
				delete(r.screenshots, id)
			}
		}
		r.mu.Unlock()
	}

	return rowsAffected, nil
}

// UpdateUploadStatus 更新截图上传状态
func (r *ScreenshotRepository) UpdateUploadStatus(ctx context.Context, id string, uploaded bool) error {
	_, err := r.db.ExecContext(ctx, `UPDATE screenshots SET uploaded = $1 WHERE id = $2`, uploaded, id)
	if err != nil {
		return err
	}

	// 更新缓存
	r.mu.Lock()
	if s, ok := r.screenshots[id]; ok {
		s.Uploaded = uploaded
	}
	r.mu.Unlock()

	return nil
}

// GetUnuploaded 获取未上传的截图
func (r *ScreenshotRepository) GetUnuploaded(ctx context.Context, limit int) ([]models.Screenshot, error) {
	query := `
		SELECT id, device_id, captured_at, file_path, file_size, uploaded, created_at
		FROM screenshots
		WHERE uploaded = false
		ORDER BY captured_at ASC
		LIMIT $1
	`
	rows, err := r.db.QueryContext(ctx, query, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var screenshots []models.Screenshot
	for rows.Next() {
		var s models.Screenshot
		var id uuid.UUID
		var deviceUUID uuid.UUID
		var capturedAt, createdAt time.Time

		if err := rows.Scan(&id, &deviceUUID, &capturedAt, &s.FilePath, &s.FileSize, &s.Uploaded, &createdAt); err != nil {
			return nil, err
		}
		s.ID = id.String()
		s.DeviceID = deviceUUID.String()
		s.CapturedAt = capturedAt
		s.CreatedAt = createdAt
		screenshots = append(screenshots, s)
	}
	return screenshots, nil
}

// CountTodayByDevice 统计指定设备今日的截图数量
func (r *ScreenshotRepository) CountTodayByDevice(ctx context.Context, deviceID string) (int, error) {
	today := time.Now().UTC().Truncate(24 * time.Hour)

	deviceUUID, err := r.resolveDeviceUUID(ctx, deviceID)
	if err != nil {
		return 0, err
	}

	var count int
	query := `SELECT COUNT(*) FROM screenshots WHERE device_id = $1 AND captured_at >= $2`
	err = r.db.QueryRowContext(ctx, query, deviceUUID, today).Scan(&count)
	return count, err
}

// CountByDevice 统计指定设备的截图数量
func (r *ScreenshotRepository) CountByDevice(ctx context.Context, deviceID string) (int, error) {
	deviceUUID, err := r.resolveDeviceUUID(ctx, deviceID)
	if err != nil {
		return 0, err
	}

	var count int
	query := `SELECT COUNT(*) FROM screenshots WHERE device_id = $1`
	err = r.db.QueryRowContext(ctx, query, deviceUUID).Scan(&count)
	return count, err
}

// DeviceScreenshotStats 设备截图统计
type DeviceScreenshotStats struct {
	TodayCount int `json:"todayCount"`
	TotalCount int `json:"totalCount"`
}

// CountStatsByDevices 批量统计多个设备的截图数量（单次查询）
func (r *ScreenshotRepository) CountStatsByDevices(ctx context.Context, deviceIDs []string) (map[string]DeviceScreenshotStats, error) {
	out := make(map[string]DeviceScreenshotStats)
	if len(deviceIDs) == 0 {
		return out, nil
	}

	uuids := make([]uuid.UUID, 0, len(deviceIDs))
	idByUUID := make(map[string]string, len(deviceIDs))
	for _, raw := range deviceIDs {
		raw = strings.TrimSpace(raw)
		if raw == "" {
			continue
		}
		parsed, err := uuid.Parse(raw)
		if err != nil {
			resolved, resolveErr := r.resolveDeviceUUID(ctx, raw)
			if resolveErr != nil {
				continue
			}
			parsed = resolved
		}
		key := parsed.String()
		if _, ok := idByUUID[key]; ok {
			continue
		}
		idByUUID[key] = raw
		uuids = append(uuids, parsed)
	}
	if len(uuids) == 0 {
		return out, nil
	}

	today := time.Now().UTC().Truncate(24 * time.Hour)
	rows, err := r.db.QueryContext(ctx, `
		SELECT device_id::text,
			COUNT(*) FILTER (WHERE captured_at >= $2)::int AS today_count,
			COUNT(*)::int AS total_count
		FROM screenshots
		WHERE device_id = ANY($1)
		GROUP BY device_id`, uuids, today)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var deviceUUID string
		var stats DeviceScreenshotStats
		if err := rows.Scan(&deviceUUID, &stats.TodayCount, &stats.TotalCount); err != nil {
			continue
		}
		key := deviceUUID
		if mapped, ok := idByUUID[deviceUUID]; ok {
			key = mapped
		}
		out[key] = stats
	}
	return out, rows.Err()
}

// CountByDateRange 统计指定日期范围内的截图数量
func (r *ScreenshotRepository) CountByDateRange(ctx context.Context, deviceID string, startDate, endDate time.Time) (int, error) {
	deviceUUID, err := r.resolveDeviceUUID(ctx, deviceID)
	if err != nil {
		return 0, err
	}

	query := `SELECT COUNT(*) FROM screenshots WHERE device_id = $1 AND captured_at BETWEEN $2 AND $3`
	var count int
	err = r.db.QueryRowContext(ctx, query, deviceUUID, startDate, endDate).Scan(&count)
	return count, err
}

// GetStats 获取截图统计信息
func (r *ScreenshotRepository) GetStats(ctx context.Context, deviceID string) (map[string]interface{}, error) {
	stats := make(map[string]interface{})

	args := []interface{}{}
	where := "1=1"
	argIdx := 1

	if deviceID != "" {
		deviceUUID, err := r.resolveDeviceUUID(ctx, deviceID)
		if err != nil {
			return nil, err
		}
		where = fmt.Sprintf("device_id = $%d", argIdx)
		args = append(args, deviceUUID)
		argIdx++
	}

	// 总数量
	var totalCount int
	err := r.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM screenshots WHERE `+where, args...).Scan(&totalCount)
	if err != nil {
		return nil, err
	}
	stats["total_count"] = totalCount

	// 总大小
	var totalSize int64
	err = r.db.QueryRowContext(ctx, `SELECT COALESCE(SUM(file_size), 0) FROM screenshots WHERE `+where, args...).Scan(&totalSize)
	if err != nil {
		return nil, err
	}
	stats["total_size"] = totalSize

	// 今日新增
	today := time.Now().UTC().Truncate(24 * time.Hour)
	var todayCount int
	err = r.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM screenshots WHERE `+where+` AND captured_at >= $`+formatPlaceholder(argIdx), append(args, today)...).Scan(&todayCount)
	if err != nil {
		return nil, err
	}
	stats["today_count"] = todayCount

	return stats, nil
}

// ListByDevice 获取指定设备的所有截图（用于导出）
func (r *ScreenshotRepository) ListByDevice(ctx context.Context, deviceID, startDate, endDate string, limit int) ([]models.Screenshot, error) {
    deviceUUID, err := r.resolveDeviceUUID(ctx, deviceID)
    if err != nil {
        return nil, fmt.Errorf("resolve device UUID failed: %w", err)
    }

    args := []interface{}{deviceUUID}
    where := "device_id = $1"
    argIdx := 2

    // 日期范围筛选（统一使用 UTC 时间）
    if startDate != "" && endDate != "" {
        startTimeUTC, err := time.Parse(time.RFC3339, startDate)
        if err != nil {
            return nil, fmt.Errorf("invalid startDate format: %s, error: %w", startDate, err)
        }
        endTimeUTC, err := time.Parse(time.RFC3339, endDate)
        if err != nil {
            return nil, fmt.Errorf("invalid endDate format: %s, error: %w", endDate, err)
        }
        where += fmt.Sprintf(" AND captured_at >= $%d AND captured_at < $%d", argIdx, argIdx+1)
        args = append(args, startTimeUTC, endTimeUTC)
        argIdx += 2
    } else if startDate != "" {
        startTimeUTC, err := time.Parse(time.RFC3339, startDate)
        if err != nil {
            return nil, fmt.Errorf("invalid startDate format: %s, error: %w", startDate, err)
        }
        where += fmt.Sprintf(" AND captured_at >= $%d", argIdx)
        args = append(args, startTimeUTC)
        argIdx++
    } else if endDate != "" {
        endTimeUTC, err := time.Parse(time.RFC3339, endDate)
        if err != nil {
            return nil, fmt.Errorf("invalid endDate format: %s, error: %w", endDate, err)
        }
        where += fmt.Sprintf(" AND captured_at < $%d", argIdx)
        args = append(args, endTimeUTC)
        argIdx++
    }

    query := `SELECT id, device_id, captured_at, file_path, file_size, uploaded, created_at
              FROM screenshots WHERE ` + where + `
              ORDER BY captured_at DESC LIMIT $` + formatPlaceholder(argIdx)
    args = append(args, limit)

    rows, err := r.db.QueryContext(ctx, query, args...)
    if err != nil {
        return nil, fmt.Errorf("query failed: %w", err)
    }
    defer rows.Close()

    var screenshots []models.Screenshot
    for rows.Next() {
        var s models.Screenshot
        var id uuid.UUID
        var devUUID uuid.UUID
        var capturedAt, createdAt time.Time

        if err := rows.Scan(&id, &devUUID, &capturedAt, &s.FilePath, &s.FileSize, &s.Uploaded, &createdAt); err != nil {
            return nil, fmt.Errorf("scan row failed: %w", err)
        }
        s.ID = id.String()
        s.DeviceID = devUUID.String()
        s.CapturedAt = capturedAt
        s.CreatedAt = createdAt
        screenshots = append(screenshots, s)
    }
    return screenshots, nil
}

// buildScreenshotCapturedAtFilters builds captured_at filters for screenshot queries.
func buildScreenshotCapturedAtFilters(startDate, endDate, startTime, endTime, tableAlias string, argIdx int) ([]string, []interface{}, int, error) {
	col := "captured_at"
	if tableAlias != "" {
		col = tableAlias + ".captured_at"
	}

	where := []string{}
	args := []interface{}{}

	if startDate != "" && endDate != "" {
		startTimeUTC, err := time.Parse(time.RFC3339, startDate)
		if err != nil {
			return nil, nil, argIdx, fmt.Errorf("invalid startDate format: %s, error: %w", startDate, err)
		}
		endTimeUTC, err := time.Parse(time.RFC3339, endDate)
		if err != nil {
			return nil, nil, argIdx, fmt.Errorf("invalid endDate format: %s, error: %w", endDate, err)
		}
		where = append(where, fmt.Sprintf("%s >= $%d AND %s <= $%d", col, argIdx, col, argIdx+1))
		args = append(args, startTimeUTC, endTimeUTC)
		argIdx += 2
	} else if startDate != "" {
		startTimeUTC, err := time.Parse(time.RFC3339, startDate)
		if err != nil {
			return nil, nil, argIdx, fmt.Errorf("invalid startDate format: %s, error: %w", startDate, err)
		}
		where = append(where, fmt.Sprintf("%s >= $%d", col, argIdx))
		args = append(args, startTimeUTC)
		argIdx++
	} else if endDate != "" {
		endTimeUTC, err := time.Parse(time.RFC3339, endDate)
		if err != nil {
			return nil, nil, argIdx, fmt.Errorf("invalid endDate format: %s, error: %w", endDate, err)
		}
		where = append(where, fmt.Sprintf("%s <= $%d", col, argIdx))
		args = append(args, endTimeUTC)
		argIdx++
	}

	if startTime != "" && endTime != "" {
		startHour, err := parseHour(startTime)
		if err != nil {
			return nil, nil, argIdx, fmt.Errorf("invalid startTime format: %s, error: %w", startTime, err)
		}
		endHour, err := parseHour(endTime)
		if err != nil {
			return nil, nil, argIdx, fmt.Errorf("invalid endTime format: %s, error: %w", endTime, err)
		}
		hourCol := "EXTRACT(HOUR FROM " + col + ")"
		if startHour <= endHour {
			where = append(where, fmt.Sprintf("%s BETWEEN $%d AND $%d", hourCol, argIdx, argIdx+1))
		} else {
			where = append(where, fmt.Sprintf("(%s >= $%d OR %s <= $%d)", hourCol, argIdx, hourCol, argIdx+1))
		}
		args = append(args, startHour, endHour)
		argIdx += 2
	}

	return where, args, argIdx, nil
}

// ListOverview returns recent screenshots grouped by employee/device.
func (r *ScreenshotRepository) ListOverview(ctx context.Context, perDeviceLimit int, deviceFilter []uuid.UUID, startDate, endDate, startTime, endTime string) ([]models.ScreenshotOverviewItem, error) {
	if perDeviceLimit < 1 {
		perDeviceLimit = 10
	}
	if perDeviceLimit > 30 {
		perDeviceLimit = 30
	}

	args := []interface{}{}
	deviceWhere := "d.status != 'rejected'"
	if len(deviceFilter) > 0 {
		placeholders := make([]string, len(deviceFilter))
		for i, id := range deviceFilter {
			placeholders[i] = fmt.Sprintf("$%d", i+1)
			args = append(args, id)
		}
		deviceWhere += " AND d.id IN (" + strings.Join(placeholders, ",") + ")"
	}

	countFilterIdx := len(args) + 1
	countFilterParts, countFilterArgs, _, err := buildScreenshotCapturedAtFilters(startDate, endDate, startTime, endTime, "s", countFilterIdx)
	if err != nil {
		return nil, err
	}
	countFilterSQL := ""
	if len(countFilterParts) > 0 {
		countFilterSQL = " AND " + strings.Join(countFilterParts, " AND ")
	}

	overviewEmployeeRowsCTE := `
WITH overview_employee_rows AS (
  SELECT
    d.id AS device_id,
    e.id AS employee_uuid,
    COALESCE(e.name, '') AS employee_name,
    COALESCE(e.employee_id, '') AS employee_number,
    COALESCE(d.hostname, '') AS hostname,
    TRUE AS is_shared_workstation
  FROM devices d
  INNER JOIN wf_shared_workstation_members m ON m.device_id = d.id
  INNER JOIN employees e ON e.id = m.employee_id
  WHERE d.status != 'rejected'

  UNION ALL

  SELECT
    d.id,
    d.employee_uuid,
    COALESCE(d.employee_name, ''),
    COALESCE(d.employee_number, ''),
    COALESCE(d.hostname, ''),
    FALSE
  FROM devices d
  WHERE d.status != 'rejected'
    AND NOT EXISTS (SELECT 1 FROM wf_shared_workstation_members m WHERE m.device_id = d.id)
)`

	deviceQuery := overviewEmployeeRowsCTE + fmt.Sprintf(`
		SELECT oer.device_id, oer.employee_uuid, oer.employee_name, oer.employee_number, oer.hostname,
		       oer.is_shared_workstation,
		       COALESCE(sc.cnt, 0),
		       CASE WHEN oer.is_shared_workstation THEN (
		         SELECT COALESCE(string_agg(e2.name, '、' ORDER BY e2.name), '')
		         FROM wf_shared_workstation_members m2
		         JOIN employees e2 ON e2.id = m2.employee_id
		         WHERE m2.device_id = oer.device_id
		           AND m2.employee_id IS DISTINCT FROM oer.employee_uuid
		       ) ELSE '' END AS shared_with_names
		FROM overview_employee_rows oer
		INNER JOIN devices d ON d.id = oer.device_id
		LEFT JOIN (
			SELECT s.device_id,
			       COALESCE(s.employee_uuid, d2.employee_uuid) AS employee_uuid,
			       COUNT(*)::int AS cnt
			FROM screenshots s
			INNER JOIN devices d2 ON d2.id = s.device_id
			WHERE 1=1%s
			GROUP BY s.device_id, COALESCE(s.employee_uuid, d2.employee_uuid)
		) sc ON sc.device_id = oer.device_id
		    AND sc.employee_uuid IS NOT DISTINCT FROM oer.employee_uuid
		WHERE %s
		ORDER BY oer.employee_name, oer.hostname, oer.device_id`, countFilterSQL, deviceWhere)

	deviceQueryArgs := append(args, countFilterArgs...)

	rows, err := r.db.QueryContext(ctx, deviceQuery, deviceQueryArgs...)
	if err != nil {
		return nil, fmt.Errorf("overview devices query failed: %w", err)
	}
	defer rows.Close()

	items := make([]models.ScreenshotOverviewItem, 0)
	indexByKey := make(map[string]int)

	for rows.Next() {
		var devID uuid.UUID
		var empUUID uuid.NullUUID
		var item models.ScreenshotOverviewItem
		if err := rows.Scan(&devID, &empUUID, &item.EmployeeName, &item.EmployeeNumber, &item.Hostname,
			&item.IsSharedWorkstation, &item.TotalCount, &item.SharedWithNames); err != nil {
			return nil, fmt.Errorf("overview device scan failed: %w", err)
		}
		item.DeviceID = devID.String()
		if empUUID.Valid {
			item.EmployeeUUID = empUUID.UUID.String()
		}
		item.Screenshots = []models.Screenshot{}
		key := overviewItemKey(item.DeviceID, empUUID)
		indexByKey[key] = len(items)
		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	if len(items) == 0 {
		return items, nil
	}

	deviceIDs := make([]uuid.UUID, 0, len(items))
	seenDevices := make(map[uuid.UUID]struct{})
	for _, item := range items {
		if devID, parseErr := uuid.Parse(item.DeviceID); parseErr == nil {
			if _, ok := seenDevices[devID]; !ok {
				seenDevices[devID] = struct{}{}
				deviceIDs = append(deviceIDs, devID)
			}
		}
	}

	shotPlaceholders := make([]string, len(deviceIDs))
	shotArgs := make([]interface{}, 0, len(deviceIDs)+8)
	for i, id := range deviceIDs {
		shotPlaceholders[i] = fmt.Sprintf("$%d", i+1)
		shotArgs = append(shotArgs, id)
	}
	shotFilterIdx := len(deviceIDs) + 1
	shotFilterParts, shotFilterArgs, nextIdx, err := buildScreenshotCapturedAtFilters(startDate, endDate, startTime, endTime, "s", shotFilterIdx)
	if err != nil {
		return nil, err
	}
	shotFilterSQL := ""
	if len(shotFilterParts) > 0 {
		shotFilterSQL = " AND " + strings.Join(shotFilterParts, " AND ")
	}
	shotArgs = append(shotArgs, shotFilterArgs...)
	limitIdx := nextIdx
	shotArgs = append(shotArgs, perDeviceLimit)

	shotQuery := fmt.Sprintf(`
		SELECT id, device_id, resolved_employee_uuid, captured_at, file_path, file_size, uploaded, created_at,
		       employee_name, employee_number, employee_uuid
		FROM (
			SELECT s.id, s.device_id, s.captured_at, s.file_path, s.file_size, s.uploaded, s.created_at,
			       COALESCE(s.employee_uuid, d.employee_uuid) AS resolved_employee_uuid,
			       COALESCE(NULLIF(s.employee_name, ''), d.employee_name, '') AS employee_name,
			       COALESCE(NULLIF(s.employee_number, ''), d.employee_number, '') AS employee_number,
			       COALESCE(s.employee_uuid::text, d.employee_uuid::text, '') AS employee_uuid,
			       ROW_NUMBER() OVER (
			         PARTITION BY s.device_id, COALESCE(s.employee_uuid, d.employee_uuid)
			         ORDER BY s.captured_at DESC
			       ) AS rn
			FROM screenshots s
			INNER JOIN devices d ON d.id = s.device_id
			WHERE s.device_id IN (%s)%s
		) ranked
		WHERE rn <= $%d
		ORDER BY device_id, captured_at DESC`, strings.Join(shotPlaceholders, ","), shotFilterSQL, limitIdx)

	shotRows, err := r.db.QueryContext(ctx, shotQuery, shotArgs...)
	if err != nil {
		return nil, fmt.Errorf("overview screenshots query failed: %w", err)
	}
	defer shotRows.Close()

	for shotRows.Next() {
		var s models.Screenshot
		var id uuid.UUID
		var deviceUUID uuid.UUID
		var resolvedEmpUUID uuid.NullUUID
		var capturedAt, createdAt time.Time
		var employeeName, employeeNumber, employeeUUID sql.NullString
		if err := shotRows.Scan(&id, &deviceUUID, &resolvedEmpUUID, &capturedAt, &s.FilePath, &s.FileSize, &s.Uploaded, &createdAt,
			&employeeName, &employeeNumber, &employeeUUID); err != nil {
			return nil, fmt.Errorf("overview screenshot scan failed: %w", err)
		}
		s.ID = id.String()
		s.DeviceID = deviceUUID.String()
		s.CapturedAt = capturedAt
		s.CreatedAt = createdAt
		if employeeName.Valid {
			s.EmployeeName = employeeName.String
		}
		if employeeNumber.Valid {
			s.EmployeeNumber = employeeNumber.String
		}
		if employeeUUID.Valid {
			s.EmployeeUUID = employeeUUID.String
		}
		key := overviewItemKey(deviceUUID.String(), resolvedEmpUUID)
		if idx, ok := indexByKey[key]; ok {
			items[idx].Screenshots = append(items[idx].Screenshots, s)
		}
	}
	return items, shotRows.Err()
}

func overviewItemKey(deviceID string, employeeUUID uuid.NullUUID) string {
	if employeeUUID.Valid && employeeUUID.UUID != uuid.Nil {
		return deviceID + ":" + employeeUUID.UUID.String()
	}
	return deviceID + ":"
}

const screenshotPurgeBatchSize = 500

// FetchBatchForPurge returns the next batch of screenshots eligible for purge.
// When deviceIDs is non-empty, results are limited to those devices.
// When start/end are provided, captured_at must fall within [start, end].
func (r *ScreenshotRepository) FetchBatchForPurge(
	ctx context.Context,
	deviceIDs []uuid.UUID,
	start, end *time.Time,
	limit int,
) ([]models.Screenshot, error) {
	if limit <= 0 {
		limit = screenshotPurgeBatchSize
	}

	where := []string{"1=1"}
	args := []interface{}{}
	argIdx := 1

	if len(deviceIDs) > 0 {
		placeholders := make([]string, len(deviceIDs))
		for i, id := range deviceIDs {
			placeholders[i] = formatPlaceholder(argIdx)
			args = append(args, id)
			argIdx++
		}
		where = append(where, fmt.Sprintf("device_id IN (%s)", strings.Join(placeholders, ",")))
	}
	if start != nil {
		where = append(where, fmt.Sprintf("captured_at >= $%d", argIdx))
		args = append(args, *start)
		argIdx++
	}
	if end != nil {
		where = append(where, fmt.Sprintf("captured_at <= $%d", argIdx))
		args = append(args, *end)
		argIdx++
	}

	query := fmt.Sprintf(`
		SELECT id, device_id, captured_at, file_path, file_size, uploaded, created_at
		FROM screenshots
		WHERE %s
		ORDER BY captured_at ASC
		LIMIT $%d
	`, strings.Join(where, " AND "), argIdx)
	args = append(args, limit)

	rows, err := r.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("fetch purge batch failed: %w", err)
	}
	defer rows.Close()

	items := make([]models.Screenshot, 0)
	for rows.Next() {
		var s models.Screenshot
		var id uuid.UUID
		var deviceUUID uuid.UUID
		var capturedAt, createdAt time.Time
		if err := rows.Scan(&id, &deviceUUID, &capturedAt, &s.FilePath, &s.FileSize, &s.Uploaded, &createdAt); err != nil {
			return nil, fmt.Errorf("scan purge batch failed: %w", err)
		}
		s.ID = id.String()
		s.DeviceID = deviceUUID.String()
		s.CapturedAt = capturedAt
		s.CreatedAt = createdAt
		items = append(items, s)
	}
	return items, rows.Err()
}

// InvalidateCache 清除指定截图的缓存
func (r *ScreenshotRepository) InvalidateCache(id string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	delete(r.screenshots, id)
}

// InvalidateCacheByDevice 清除指定设备的所有缓存
func (r *ScreenshotRepository) InvalidateCacheByDevice(deviceID string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for id, s := range r.screenshots {
		if s.DeviceID == deviceID {
			delete(r.screenshots, id)
		}
	}
}

// ClearCache 清除所有缓存
func (r *ScreenshotRepository) ClearCache() {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.screenshots = make(map[string]*models.Screenshot)
}

// RefreshCache 刷新缓存
func (r *ScreenshotRepository) RefreshCache(ctx context.Context) error {
	r.mu.Lock()
	r.screenshots = make(map[string]*models.Screenshot)
	r.mu.Unlock()
	r.loadScreenshots()
	return nil
}

// ========== 辅助函数 ==========

// parseHour 解析时间字符串中的小时
func parseHour(timeStr string) (int, error) {
    if timeStr == "" {
        return 0, fmt.Errorf("empty time string")
    }
    
    var hour int
    // 支持 "14" 或 "14:00:00" 格式
    if strings.Contains(timeStr, ":") {
        _, err := fmt.Sscanf(timeStr, "%d", &hour)
        if err != nil {
            return 0, fmt.Errorf("failed to parse hour from '%s': %w", timeStr, err)
        }
    } else {
        _, err := fmt.Sscanf(timeStr, "%d", &hour)
        if err != nil {
            return 0, fmt.Errorf("failed to parse hour from '%s': %w", timeStr, err)
        }
    }
    
    if hour < 0 || hour > 23 {
        return 0, fmt.Errorf("invalid hour value: %d, must be between 0 and 23", hour)
    }
    return hour, nil
}

// formatPlaceholder 格式化 PostgreSQL 参数占位符
func formatPlaceholder(n int) string {
	return fmt.Sprintf("$%d", n)
}
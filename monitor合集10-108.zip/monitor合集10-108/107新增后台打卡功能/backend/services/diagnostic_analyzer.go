package services

import (
	"context"
	"fmt"
	"strings"
	"time"

	"enterprise-agent/backend/models"
)

func (s *DiagnosticService) Analyze(ctx context.Context, deviceID string, windowMinutes int) (*models.DiagnosticAnalysis, error) {
	if windowMinutes <= 0 {
		windowMinutes = 30
	}
	if windowMinutes > 24*60 {
		windowMinutes = 24 * 60
	}
	since := models.UTCNow().Add(-time.Duration(windowMinutes) * time.Minute)

	q := DiagnosticEventQuery{Page: 1, PageSize: 500, DeviceID: deviceID}
	q.From = &since
	events, _, err := s.ListEvents(ctx, q)
	if err != nil {
		return nil, err
	}

	counts := map[string]int{"ERROR": 0, "WARN": 0, "INFO": 0, "DEBUG": 0, "TRACE": 0}
	findings := []models.DiagnosticFinding{}

	for _, ev := range events {
		counts[string(ev.Level)]++
	}

	// Rule: high error rate
	if counts["ERROR"] >= 3 {
		findings = append(findings, models.DiagnosticFinding{
			Severity:        "critical",
			Code:            "HIGH_ERROR_RATE",
			Title:           "错误事件集中出现",
			Detail:          fmt.Sprintf("近 %d 分钟内 ERROR 事件 %d 条", windowMinutes, counts["ERROR"]),
			SuggestedAction: "查看 Timeline / Logs 中 ERROR 详情，优先检查 FFmpeg / WHIP / Ingress",
		})
	}

	// Rule: dead frame / srcObject
	for _, ev := range events {
		msg := strings.ToLower(ev.Message)
		if ev.Module == "RemoteView" && (strings.Contains(msg, "dead frame") || strings.Contains(msg, "srcobject")) {
			findings = append(findings, models.DiagnosticFinding{
				Severity:        "warning",
				Code:            "REMOTE_VIEW_DEAD_FRAME",
				Title:           "前端可能存在 dead frame",
				Detail:          ev.Message,
				Module:          ev.Module,
				DeviceID:        deviceIDFromEvent(ev),
				SuggestedAction: "检查 trackSid 是否变化、LiveKit reconnect 是否成功",
				Evidence:        []string{ev.Message},
			})
			break
		}
	}

	// Rule: ingress lifecycle
	ingressDeletes := 0
	for _, ev := range events {
		if strings.Contains(strings.ToLower(ev.Message), "ingress") {
			ingressDeletes++
		}
	}
	if ingressDeletes >= 2 {
		findings = append(findings, models.DiagnosticFinding{
			Severity:        "info",
			Code:            "INGRESS_CHURN",
			Title:           "Ingress 生命周期频繁变化",
			Detail:          fmt.Sprintf("近 %d 分钟内 ingress 相关事件 %d 条", windowMinutes, ingressDeletes),
			SuggestedAction: "确认 stop/start 间隔是否小于 15s DeleteIngress 延迟",
		})
	}

	// Rule: ffmpeg teardown
	for _, ev := range events {
		if ev.Module == "FFmpeg" && strings.Contains(ev.Message, "killed=true") {
			findings = append(findings, models.DiagnosticFinding{
				Severity:        "warning",
				Code:            "FFMPEG_FORCE_KILL",
				Title:           "FFmpeg 被强制 Kill",
				Detail:          ev.Message,
				Module:          "FFmpeg",
				DeviceID:        deviceIDFromEvent(ev),
				SuggestedAction: "检查 WHIP 退出是否超时，或 quality switch 是否重叠",
			})
			break
		}
	}

	// Rule: stale remote stats from snapshot comparison
	if s.remoteView != nil && deviceID != "" {
		if st, err := s.remoteView.GetStatus(ctx, deviceID); err == nil && st != nil && st.IsActive && !st.StatsFresh {
			findings = append(findings, models.DiagnosticFinding{
				Severity:        "warning",
				Code:            "STALE_PUBLISHER_STATS",
				Title:           "Agent 推流 stats 过期",
				Detail:          fmt.Sprintf("session=%s status=%s statsFresh=false", st.SessionID, st.Status),
				Module:          "RemoteView",
				DeviceID:        deviceID,
				SuggestedAction: "Agent 可能已停推或 WS stats 上报中断",
			})
		}
	}

	summary := fmt.Sprintf("分析窗口 %d 分钟，共 %d 条事件", windowMinutes, len(events))
	if len(findings) == 0 {
		summary += "；未发现明显异常"
	} else {
		summary += fmt.Sprintf("；发现 %d 条提示", len(findings))
	}

	analysis := &models.DiagnosticAnalysis{
		GeneratedAt:   models.UTCNow(),
		WindowMinutes: windowMinutes,
		Summary:       summary,
		Findings:      findings,
		Counts:        counts,
	}
	analysis.Conclusion = s.buildConclusion(ctx, deviceID, findings)
	return analysis, nil
}

func (s *DiagnosticService) buildConclusion(ctx context.Context, deviceID string, findings []models.DiagnosticFinding) *models.DiagnosticConclusion {
	checks := []models.DiagnosticConclusionCheck{
		{Label: "Agent 在线", OK: true},
		{Label: "Capture 正常", OK: true},
		{Label: "FFmpeg 正常", OK: true},
		{Label: "WHIP 正常", OK: true},
		{Label: "Backend 正常", OK: true},
		{Label: "Browser Track 正常", OK: true},
	}

	probableCause := "未发现明显异常，链路整体正常"
	confidence := 75
	title := "诊断结论"

	if deviceID != "" && s.remoteView != nil {
		if pipe, err := s.BuildPipeline(ctx, deviceID); err == nil && pipe != nil {
			for i := range checks {
				for _, node := range pipe.Nodes {
					switch checks[i].Label {
					case "Agent 在线":
						if node.ID == "agent" {
							checks[i].OK = node.Status == statusHealthy
						}
					case "Capture 正常":
						if node.ID == "capture" {
							checks[i].OK = node.Status == statusHealthy
						}
					case "FFmpeg 正常":
						if node.ID == "ffmpeg" {
							checks[i].OK = node.Status == statusHealthy
						}
					case "WHIP 正常":
						if node.ID == "whip" {
							checks[i].OK = node.Status == statusHealthy
						}
					case "Backend 正常":
						if node.ID == "ingress" || node.ID == "livekit" {
							if node.Status != statusHealthy {
								checks[i].OK = false
							}
						}
					case "Browser Track 正常":
						if node.ID == "frontend" {
							checks[i].OK = node.Status == statusHealthy
						}
					}
				}
			}
		}
	}

	for _, f := range findings {
		switch f.Code {
		case "REMOTE_VIEW_DEAD_FRAME":
			checks[5].OK = false
			probableCause = "LiveKit Track 未更新或 Browser srcObject 未切换"
			confidence = 91
			title = "前端播放层异常"
		case "FFMPEG_FORCE_KILL":
			checks[2].OK = false
			probableCause = "FFmpeg 被强制终止，推流链路中断"
			confidence = 88
			title = "编码进程异常"
		case "STALE_PUBLISHER_STATS":
			checks[0].OK = false
			checks[2].OK = false
			probableCause = "Agent 推流 stats 过期，可能已停推或 WS 上报中断"
			confidence = 86
			title = "Agent 推流异常"
		case "INGRESS_CHURN":
			checks[4].OK = false
			if confidence < 80 {
				probableCause = "Ingress 生命周期频繁变化，可能存在 stop/start 竞态"
				confidence = 82
				title = "Ingress 不稳定"
			}
		case "HIGH_ERROR_RATE":
			confidence = 70
			title = "错误事件集中"
			probableCause = "近窗口内 ERROR 事件偏多，建议查看 Session Timeline"
		}
	}

	if len(findings) == 0 {
		okCount := 0
		for _, c := range checks {
			if c.OK {
				okCount++
			}
		}
		confidence = 60 + okCount*5
		if confidence > 95 {
			confidence = 95
		}
	}

	return &models.DiagnosticConclusion{
		Title:         title,
		ProbableCause: probableCause,
		Confidence:    confidence,
		Checks:        checks,
	}
}

func deviceIDFromEvent(ev models.DiagnosticEvent) string {
	if ev.DeviceID == nil {
		return ""
	}
	return ev.DeviceID.String()
}

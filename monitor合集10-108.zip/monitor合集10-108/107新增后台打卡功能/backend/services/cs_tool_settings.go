package services

import (
	"context"
	"database/sql"
	"net/url"
	"strings"
	"time"
)

const (
	DefaultCsToolUrl   = "https://dh1888.github.io/168/"
	DefaultCsScriptUrl = "https://dh1888.github.io/render/"
)

type CsToolSettings struct {
	ToolUrl   string `json:"toolUrl"`
	ScriptUrl string `json:"scriptUrl"`
	UpdatedAt string `json:"updatedAt,omitempty"`
}

type CsToolSettingsService struct {
	db *sql.DB
}

func NewCsToolSettingsService(db *sql.DB) *CsToolSettingsService {
	return &CsToolSettingsService{db: db}
}

func (s *CsToolSettingsService) GetSettings(ctx context.Context) (*CsToolSettings, error) {
	out := &CsToolSettings{
		ToolUrl:   DefaultCsToolUrl,
		ScriptUrl: DefaultCsScriptUrl,
	}
	var updatedAt time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT tool_url, script_url, updated_at
		FROM cs_tool_settings WHERE id = 1`).
		Scan(&out.ToolUrl, &out.ScriptUrl, &updatedAt)
	if err == sql.ErrNoRows {
		return out, nil
	}
	if err != nil {
		return nil, err
	}
	out.ToolUrl = normalizeCsToolURL(out.ToolUrl, DefaultCsToolUrl)
	out.ScriptUrl = normalizeCsToolURL(out.ScriptUrl, DefaultCsScriptUrl)
	out.UpdatedAt = updatedAt.UTC().Format(time.RFC3339)
	return out, nil
}

func (s *CsToolSettingsService) SaveSettings(ctx context.Context, in CsToolSettings) (*CsToolSettings, error) {
	toolURL, err := validateCsToolURL(in.ToolUrl, DefaultCsToolUrl)
	if err != nil {
		return nil, err
	}
	scriptURL, err := validateCsToolURL(in.ScriptUrl, DefaultCsScriptUrl)
	if err != nil {
		return nil, err
	}

	_, err = s.db.ExecContext(ctx, `
		INSERT INTO cs_tool_settings (id, tool_url, script_url, updated_at)
		VALUES (1, $1, $2, NOW())
		ON CONFLICT (id) DO UPDATE SET
			tool_url = EXCLUDED.tool_url,
			script_url = EXCLUDED.script_url,
			updated_at = NOW()`,
		toolURL, scriptURL)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func validateCsToolURL(raw, fallback string) (string, error) {
	v := strings.TrimSpace(raw)
	if v == "" {
		return fallback, nil
	}
	u, err := url.Parse(v)
	if err != nil || u.Scheme == "" || u.Host == "" {
		return "", ErrInvalidCsToolURL
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return "", ErrInvalidCsToolURL
	}
	return u.String(), nil
}

func normalizeCsToolURL(raw, fallback string) string {
	v, err := validateCsToolURL(raw, fallback)
	if err != nil || v == "" {
		return fallback
	}
	return v
}

var ErrInvalidCsToolURL = &csToolURLError{}

type csToolURLError struct{}

func (e *csToolURLError) Error() string { return "跳转地址必须是有效的 http 或 https URL" }

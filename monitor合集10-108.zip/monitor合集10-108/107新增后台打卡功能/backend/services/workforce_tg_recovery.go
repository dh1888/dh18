package services

import (
	"context"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

const defaultForceBackOvertimeMinutes = 120

var userOperationLocks sync.Map

func tryAcquireUserLock(empID uuid.UUID, ttl time.Duration) bool {
	now := time.Now()
	if v, ok := userOperationLocks.Load(empID); ok {
		if expiry, ok := v.(time.Time); ok && expiry.After(now) {
			return false
		}
	}
	userOperationLocks.Store(empID, now.Add(ttl))
	return true
}

func releaseUserLock(empID uuid.UUID) {
	userOperationLocks.Delete(empID)
}

func (s *WorkforceTelegramService) tryAcquireBackLock(empID uuid.UUID) bool {
	return tryAcquireUserLock(empID, 30*time.Second)
}

func telegramForceBackOvertimeSeconds() int {
	if v := strings.TrimSpace(os.Getenv("TELEGRAM_FORCE_BACK_OVERTIME_MINUTES")); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			return n * 60
		}
	}
	return defaultForceBackOvertimeMinutes * 60
}

func (s *WorkforceTelegramService) RecoverExpiredActivities(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	forceBackSec := telegramForceBackOvertimeSeconds()
	rows, err := s.db.QueryContext(ctx, `
		SELECT s.id, s.employee_id, s.activity_name, s.started_at, s.limit_seconds,
			COALESCE(s.source_chat_id,''), e.name
		FROM wf_tg_activity_sessions s
		JOIN employees e ON e.id = s.employee_id
		WHERE s.status = 'open' AND s.limit_seconds > 0`)
	if err != nil {
		return
	}
	defer rows.Close()
	for rows.Next() {
		var sid, empID uuid.UUID
		var actName, chatID, empName string
		var started time.Time
		var limitSec int
		if rows.Scan(&sid, &empID, &actName, &started, &limitSec, &chatID, &empName) != nil {
			continue
		}
		elapsed := int(time.Since(started).Seconds())
		if elapsed-limitSec < forceBackSec {
			continue
		}
		sess, err := s.closeActivitySession(ctx, sid, true, "system")
		if err != nil {
			log.Printf("[Telegram] recover expired activity %s: %v", sid, err)
			continue
		}
		msg := fmt.Sprintf("🚨 %s「%s」超时超过 %d 分钟，系统已强制回座", empName, actName, forceBackSec/60)
		if sess.FineAmount > 0 {
			msg += fmt.Sprintf("\n⚠️ 罚款 ¥%.2f", sess.FineAmount)
		}
		_ = s.SendTelegramText(ctx, chatID, msg, nil)
		s.NotifyActivityEvent(ctx, chatID, empID, empName, actName, "强制回座", fmt.Sprintf("超时 %d 分钟", forceBackSec/60))
		log.Printf("[Telegram] recovered expired activity %s for employee %s", sid, empID)
	}
}

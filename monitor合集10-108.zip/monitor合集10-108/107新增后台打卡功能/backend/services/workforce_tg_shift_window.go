package services

import (
	"fmt"
	"strings"
	"time"
)

func isWithinWindowAsymmetric(nowMin, startMin, endMin, graceBefore, graceAfter int) bool {
	startMin -= graceBefore
	endMin += graceAfter
	if startMin < 0 {
		startMin = 0
	}
	if endMin > 24*60-1 {
		endMin = 24*60 - 1
	}
	if startMin <= endMin {
		return nowMin >= startMin && nowMin <= endMin
	}
	return nowMin >= startMin || nowMin <= endMin
}

func resolveExpectedStartForWindow(now time.Time, startClock string, loc *time.Location) time.Time {
	expectedStart := combineDateTime(now, startClock, loc)
	if now.Before(expectedStart) {
		expectedStart = expectedStart.AddDate(0, 0, -1)
	}
	return expectedStart
}

func isWithinCheckInWindow(now, expectedStart time.Time, beforeMin, afterMin int) bool {
	earliest := expectedStart.Add(-time.Duration(beforeMin) * time.Minute)
	latest := expectedStart.Add(time.Duration(afterMin) * time.Minute)
	return !now.Before(earliest) && !now.After(latest)
}

func isWithinCheckOutWindow(now, expectedEnd time.Time, beforeMin, afterMin int) bool {
	earliest := expectedEnd.Add(-time.Duration(beforeMin) * time.Minute)
	latest := expectedEnd.Add(time.Duration(afterMin) * time.Minute)
	return !now.Before(earliest) && !now.After(latest)
}

func (s *WorkforceTelegramService) isCheckInWindowForShift(settings *TelegramSettings, grace TgGraceConfig, shift string, now time.Time) bool {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	startClock := settings.DayStart
	if shift == "night" {
		startClock = settings.NightStart
	}
	expectedStart := resolveExpectedStartForWindow(now, startClock, loc)
	return isWithinCheckInWindow(now, expectedStart, grace.CheckInBefore, grace.CheckInAfter)
}

func (s *WorkforceTelegramService) validateCheckOutWindow(settings *TelegramSettings, grace TgGraceConfig, shiftWindowDisabled bool, shift, recordDate string, now time.Time) error {
	if shiftWindowDisabled {
		return nil
	}
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	endClock := settings.DayEnd
	if shift == "night" {
		endClock = settings.NightEnd
	}
	expectedEnd := resolveWorkEndExpectedTime(now, recordDate, shift, endClock, loc)
	if isWithinCheckOutWindow(now, expectedEnd, grace.CheckOutBefore, grace.CheckOutAfter) {
		return nil
	}
	if shift == "night" {
		return fmt.Errorf("当前不在夜班签退窗口，请在 %s 前后（含宽容）内打下班卡；%w", endClock, ErrOutsideWorkWindow)
	}
	return fmt.Errorf("当前不在白班签退窗口，请在 %s 前后（含宽容）内打下班卡；%w", endClock, ErrOutsideWorkWindow)
}

func resolveNightShiftDetail(settings *TelegramSettings, now time.Time) string {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	nowMin := minutesOfDay(now)
	dayEndH, dayEndM, ok1 := parseClock(settings.DayEnd)
	nightStartH, nightStartM, ok2 := parseClock(settings.NightStart)
	if !ok1 || !ok2 {
		return "night_tonight"
	}
	dayEnd := clockToMinutes(dayEndH, dayEndM)
	nightStart := clockToMinutes(nightStartH, nightStartM)
	if nowMin >= nightStart {
		return "night_tonight"
	}
	if nowMin < dayEnd {
		return "night_last"
	}
	return "night_tonight"
}

func nightRecordDateForDetail(businessDate, detail string) string {
	_ = detail
	return businessDate
}

// resolveAttendanceDate 返回按班次解释的统一业务日（attendance_date）。
func resolveAttendanceDate(shift, shiftDetail string, period *TgPeriodInfo, now time.Time, loc *time.Location) string {
	now = now.In(loc)
	if shift == "day" {
		return now.Format("2006-01-02")
	}
	bd := now.Format("2006-01-02")
	if period != nil && strings.TrimSpace(period.BusinessDate) != "" {
		bd = period.BusinessDate
	}
	return nightRecordDateForDetail(bd, shiftDetail)
}

func (s *WorkforceTelegramService) resolveCurrentShiftWithGrace(settings *TelegramSettings, grace TgGraceConfig, now time.Time) (shift, shiftDetail string, err error) {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)

	if !settings.DualShiftEnabled {
		if s.isCheckInWindowForShift(settings, grace, "day", now) {
			return "day", "", nil
		}
		return "", "", ErrOutsideWorkWindow
	}

	if s.isCheckInWindowForShift(settings, grace, "day", now) {
		return "day", "", nil
	}
	if s.isCheckInWindowForShift(settings, grace, "night", now) {
		return "night", resolveNightShiftDetail(settings, now), nil
	}
	return "", "", ErrOutsideWorkWindow
}

func (s *WorkforceTelegramService) isForcedShiftAllowed(settings *TelegramSettings, grace TgGraceConfig, forcedShift string, now time.Time) bool {
	forced, _ := normalizeShiftType(forcedShift)
	return s.isCheckInWindowForShift(settings, grace, forced, now)
}

func shiftWindowHint(settings *TelegramSettings, forcedShift string) string {
	forced, _ := normalizeShiftType(forcedShift)
	if forced == "night" {
		return fmt.Sprintf("当前不在夜班上班窗口，请在 %s 前后（含宽容）内打夜班卡", settings.NightStart)
	}
	return fmt.Sprintf("当前不在白班上班窗口，请在 %s 前后（含宽容）内打白班卡", settings.DayStart)
}

func (s *WorkforceTelegramService) resolveShiftForCheckIn(settings *TelegramSettings, grace TgGraceConfig, shiftWindowDisabled bool, forcedShift string, now time.Time) (shift, shiftDetail string, err error) {
	if forcedShift != "" {
		shift, err = normalizeShiftType(forcedShift)
		if err != nil {
			return "", "", err
		}
		if shiftWindowDisabled {
			detail := ""
			if shift == "night" {
				detail = resolveNightShiftDetail(settings, now)
			}
			return shift, detail, nil
		}
		if !s.isForcedShiftAllowed(settings, grace, forcedShift, now) {
			return "", "", fmt.Errorf("%s；%w", shiftWindowHint(settings, forcedShift), ErrOutsideWorkWindow)
		}
		detail := ""
		if shift == "night" {
			detail = resolveNightShiftDetail(settings, now)
		}
		return shift, detail, nil
	}
	if shiftWindowDisabled {
		if settings.DualShiftEnabled {
			if shift, detail, err := s.resolveCurrentShiftWithGrace(settings, grace, now); err == nil {
				return shift, detail, nil
			}
		}
		return "day", "", nil
	}
	return s.resolveCurrentShiftWithGrace(settings, grace, now)
}

func shiftDetailLabel(detail string) string {
	switch strings.TrimSpace(detail) {
	case "night_last":
		return "（昨晚夜班）"
	case "night_tonight":
		return "（今晚夜班）"
	default:
		return ""
	}
}

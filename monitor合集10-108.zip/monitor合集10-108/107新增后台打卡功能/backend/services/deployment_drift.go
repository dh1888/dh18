package services

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"time"

	"github.com/redis/go-redis/v9"
)

const (
	deploymentRegistryKey   = "deploy:registry"
	deploymentDriftInterval = time.Minute
	deploymentInstanceTTL   = 3 * time.Minute
)

var deploymentInstanceID = fmt.Sprintf("%s:%d", hostname(), os.Getpid())

func hostname() string {
	h, err := os.Hostname()
	if err != nil || h == "" {
		return "unknown"
	}
	return h
}

// DeploymentConfigSnapshot captures deployment-relevant settings for drift detection.
type DeploymentConfigSnapshot struct {
	InstanceID          string `json:"instanceId"`
	MinIORemote         bool   `json:"minioRemote"`
	UploadSharedStorage bool   `json:"uploadSharedStorage"`
	WSTicketRequired    bool   `json:"wsTicketRequired"`
	RedisConfigured     bool   `json:"redisConfigured"`
	Env                 string `json:"env"`
	Hash                string `json:"hash"`
	UpdatedAt           time.Time `json:"updatedAt"`
}

// ComputeDeploymentFingerprint builds a canonical snapshot of runtime deployment config.
func ComputeDeploymentFingerprint(minio *MinIOClient) DeploymentConfigSnapshot {
	chunks := NewUploadChunkStore(minio)
	snap := DeploymentConfigSnapshot{
		InstanceID:          deploymentInstanceID,
		MinIORemote:         chunks != nil && chunks.SharedAcrossInstances(),
		UploadSharedStorage: UploadSharedStorageEnabled(),
		WSTicketRequired:    WSTicketRequired(),
		RedisConfigured:     os.Getenv("REDIS_ADDR") != "",
		Env:                 os.Getenv("ENV"),
		UpdatedAt:           time.Now().UTC(),
	}
	snap.Hash = snap.canonicalHash()
	return snap
}

func (s DeploymentConfigSnapshot) canonicalHash() string {
	body := fmt.Sprintf(
		"env=%s|minio_remote=%t|upload_shared=%t|ws_ticket=%t|redis=%t",
		s.Env, s.MinIORemote, s.UploadSharedStorage, s.WSTicketRequired, s.RedisConfigured,
	)
	sum := sha256.Sum256([]byte(body))
	return hex.EncodeToString(sum[:8])
}

// StartDeploymentDriftMonitor registers instance fingerprints and detects cluster config drift.
func StartDeploymentDriftMonitor(ctx context.Context, redisClient *redis.Client, minio *MinIOClient) {
	if redisClient == nil {
		return
	}
	go func() {
		ticker := time.NewTicker(deploymentDriftInterval)
		defer ticker.Stop()
		log.Printf("[DeploymentDrift] monitor started instance=%s", deploymentInstanceID)
		publish := func() {
			snap := ComputeDeploymentFingerprint(minio)
			payload, err := json.Marshal(snap)
			if err != nil {
				return
			}
			pubCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
			defer cancel()
			if err := redisClient.HSet(pubCtx, deploymentRegistryKey, snap.InstanceID, payload).Err(); err != nil {
				log.Printf("[DeploymentDrift] registry update failed: %v", err)
				return
			}
			checkDeploymentDrift(pubCtx, redisClient)
		}
		publish()
		for {
			select {
			case <-ctx.Done():
				log.Printf("[DeploymentDrift] monitor stopped")
				return
			case <-ticker.C:
				publish()
			}
		}
	}()
}

func checkDeploymentDrift(ctx context.Context, redisClient *redis.Client) {
	raw, err := redisClient.HGetAll(ctx, deploymentRegistryKey).Result()
	if err != nil || len(raw) < 2 {
		return
	}
	now := time.Now().UTC()
	active := make(map[string]DeploymentConfigSnapshot)
	for id, payload := range raw {
		var snap DeploymentConfigSnapshot
		if err := json.Unmarshal([]byte(payload), &snap); err != nil {
			continue
		}
		if snap.UpdatedAt.IsZero() || now.Sub(snap.UpdatedAt) > deploymentInstanceTTL {
			_, _ = redisClient.HDel(ctx, deploymentRegistryKey, id).Result()
			continue
		}
		active[id] = snap
	}
	if len(active) < 2 {
		return
	}
	hashes := make(map[string][]string)
	for id, snap := range active {
		hashes[snap.Hash] = append(hashes[snap.Hash], id)
	}
	if len(hashes) <= 1 {
		GlobalMetrics.DeploymentDriftDetected.Store(0)
		return
	}
	GlobalMetrics.DeploymentDriftDetected.Store(1)
	for hash, ids := range hashes {
		log.Printf("[DeploymentDrift] ALERT config mismatch hash=%s instances=%v", hash, ids)
	}
}

// DeploymentInstanceID returns this process deployment registry id.
func DeploymentInstanceID() string {
	return deploymentInstanceID
}

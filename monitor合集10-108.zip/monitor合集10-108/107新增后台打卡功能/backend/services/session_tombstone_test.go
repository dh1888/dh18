package services

import (
	"context"
	"encoding/json"
	"os"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
)

func testTombstoneRedis(t *testing.T) *redis.Client {
	t.Helper()
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "127.0.0.1:6379"
	}
	client := redis.NewClient(&redis.Options{Addr: addr, Password: os.Getenv("REDIS_PASSWORD"), DB: 10})
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		t.Skipf("redis unavailable: %v", err)
	}
	return client
}

func TestSessionTombstoneBlocksActiveCache(t *testing.T) {
	client := testTombstoneRedis(t)
	defer client.Close()

	svc := &SessionService{redis: client}
	ctx := context.Background()
	sessionID := uuid.NewString()

	t.Cleanup(func() {
		_ = client.Del(context.Background(), sessionCacheKey(sessionID), sessionTombstoneKey(sessionID)).Err()
	})

	activePayload := sessionCachePayload{
		Status:      SessionStatusActive,
		Version:     1,
		ExpiresAt:   time.Now().UTC().Add(time.Hour),
		SubjectType: SessionSubjectUser,
		SubjectID:   uuid.NewString(),
	}
	raw, err := json.Marshal(activePayload)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if err := client.Set(ctx, sessionCacheKey(sessionID), raw, time.Hour).Err(); err != nil {
		t.Fatalf("seed cache: %v", err)
	}
	svc.writeSessionTombstone(ctx, sessionID, SessionStatusRevoked, "test_revoke")

	sess, err := svc.GetSession(ctx, sessionID)
	if err != nil {
		t.Fatalf("get session: %v", err)
	}
	if sess.Status != SessionStatusRevoked {
		t.Fatalf("expected revoked via tombstone, got %q", sess.Status)
	}
}

func TestComputeDeploymentFingerprintStable(t *testing.T) {
	t.Setenv("ENV", "production")
	t.Setenv("UPLOAD_SHARED_STORAGE", "false")
	t.Setenv("WS_TICKET_REQUIRED", "true")

	minio := NewLocalMinIOForTests(t.TempDir())
	a := ComputeDeploymentFingerprint(minio)
	b := ComputeDeploymentFingerprint(minio)
	if a.Hash != b.Hash {
		t.Fatalf("fingerprint unstable: %q vs %q", a.Hash, b.Hash)
	}
	if a.Hash == "" {
		t.Fatal("expected non-empty fingerprint hash")
	}
}

func TestMetricsUploadSuccessRate(t *testing.T) {
	m := &AppMetrics{}
	m.UploadCompletes.Store(8)
	m.UploadFailures.Store(2)
	if got := m.uploadSuccessRatePercent(); got != 80 {
		t.Fatalf("expected 80%% got %d", got)
	}
}

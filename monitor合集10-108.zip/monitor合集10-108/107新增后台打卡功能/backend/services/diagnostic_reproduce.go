package services

import (
	"context"
	"time"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

func (s *DiagnosticService) StartReproduce(ctx context.Context, req models.DiagnosticReproduceRequest, updatedBy string) (*models.DiagnosticReproduceStatus, error) {
	if req.TemplateID == "" {
		req.TemplateID = "remote-view"
	}
	if req.DurationMinutes <= 0 {
		req.DurationMinutes = 30
	}
	if _, err := s.ApplyTemplate(ctx, req.TemplateID, req.DurationMinutes, updatedBy); err != nil {
		return nil, err
	}

	now := models.UTCNow()
	job := &models.DiagnosticReproduceStatus{
		JobID:       uuid.New().String(),
		Active:      true,
		TemplateID:  req.TemplateID,
		DeviceIDs:   req.DeviceIDs,
		StartedAt:   now,
		ExpiresAt:   now.Add(time.Duration(req.DurationMinutes) * time.Minute),
		AutoCapture: req.AutoCapture,
		Message:     "复现模式已启动，诊断模板已自动应用",
	}

	s.reproduceMu.Lock()
	s.reproduceJobs[job.JobID] = job
	s.reproduceMu.Unlock()

	if req.AutoCapture {
		go s.runReproduceCapture(job.JobID)
	}
	return job, nil
}

func (s *DiagnosticService) GetReproduceStatus(jobID string) (*models.DiagnosticReproduceStatus, error) {
	s.reproduceMu.RLock()
	defer s.reproduceMu.RUnlock()
	job, ok := s.reproduceJobs[jobID]
	if !ok {
		return nil, nil
	}
	copy := *job
	return &copy, nil
}

func (s *DiagnosticService) GetReproduceCapture(jobID string) (*models.DiagnosticCaptureResult, bool) {
	s.reproduceMu.RLock()
	defer s.reproduceMu.RUnlock()
	cap, ok := s.reproduceCap[jobID]
	return cap, ok
}

func (s *DiagnosticService) runReproduceCapture(jobID string) {
	s.reproduceMu.RLock()
	job, ok := s.reproduceJobs[jobID]
	s.reproduceMu.RUnlock()
	if !ok || job == nil {
		return
	}

	wait := time.Until(job.ExpiresAt)
	if wait > 0 {
		time.Sleep(wait)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()

	result, err := s.Capture(ctx, models.DiagnosticCaptureRequest{
		DeviceIDs:       job.DeviceIDs,
		WindowMinutes:   30,
		IncludeAgents:   true,
		IncludeAnalysis: true,
	})

	s.reproduceMu.Lock()
	defer s.reproduceMu.Unlock()
	if j, ok := s.reproduceJobs[jobID]; ok {
		j.Active = false
		j.CaptureReady = err == nil
		if err != nil {
			j.Message = "自动抓取失败: " + err.Error()
		} else {
			j.CaptureID = result.CaptureID
			j.Message = "复现模式完成，诊断包已自动抓取"
			s.reproduceCap[jobID] = result
		}
	}
}

package services

import (
	"context"
	"database/sql"
	"strings"
)

type TgLangMode string

const (
	TgLangBoth TgLangMode = "both"
	TgLangZh   TgLangMode = "zh"
	TgLangVi   TgLangMode = "vi"
)

var tgActivityVI = map[string]string{
	"吃饭":     "Đi ăn",
	"大厕":     "Nhà vệ sinh lớn",
	"小厕":     "Nhà vệ sinh nhỏ",
	"抽烟或休息": "Nghỉ hoặc hút thuốc",
}

// tgDefaultActivityIcons maps canonical activity names to keyboard display icons.
// DB name / API resolution stay unchanged; icons are display-only on buttons.
var tgDefaultActivityIcons = map[string]string{
	"小厕":     "🚽",
	"大厕":     "🚾",
	"吃饭":     "🍱",
	"抽烟":     "🚬",
	"抽烟或休息": "🚬",
}

type tgButtonMeta struct {
	Zh     string
	Vi     string
	Style  string
	Legacy []string
}

var tgWorkButtons = map[string]tgButtonMeta{
	"work_start_day":   {Zh: "白班上班", Vi: "Ca ngày Đi làm", Style: "success"},
	"work_start_night": {Zh: "夜班上班", Vi: "Ca đêm Đi làm", Style: "primary"},
	"work_end":         {Zh: "下班", Vi: "Tan ca", Style: "danger", Legacy: []string{"🔴 下班"}},
}

var tgUIButtons = map[string]tgButtonMeta{
	"back":       {Zh: "回座", Vi: "Trở lại chỗ ngồi", Style: "success", Legacy: []string{"✅ 回座", "回来", "结束活动", "结束", "回座"}},
	"my_record":  {Zh: "我的记录", Vi: "Lịch sử của tôi", Legacy: []string{"我的信息", "我的记录"}},
	"rank":        {Zh: "排行榜", Vi: "Bảng xếp hạng", Legacy: []string{"排名"}},
	"export_data": {Zh: "导出数据", Vi: "Xuất dữ liệu", Legacy: []string{"/export"}},
	"checkin":    {Zh: "上班", Vi: "Đi làm", Style: "success"},
	"status":     {Zh: "状态", Vi: "Trạng thái"},
	"handover":   {Zh: "交接班", Vi: "Giao ca", Legacy: []string{"换班"}},
	"help":       {Zh: "帮助", Vi: "Trợ giúp"},
	"chatid":     {Zh: "chatid", Vi: "chatid"},
}

func normalizeTgLangMode(mode string) TgLangMode {
	switch strings.ToLower(strings.TrimSpace(mode)) {
	case "zh":
		return TgLangZh
	case "vi":
		return TgLangVi
	default:
		return TgLangBoth
	}
}

func (s *WorkforceTelegramService) GetLangMode(ctx context.Context, chatID string) TgLangMode {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return TgLangBoth
	}
	mode := normalizeTgLangMode(settings.BotUILang)
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return mode
	}
	var groupLang sql.NullString
	if s.db.QueryRowContext(ctx, `
		SELECT bot_ui_lang FROM wf_telegram_groups WHERE chat_id = $1`, chatID).
		Scan(&groupLang) == nil && groupLang.Valid && strings.TrimSpace(groupLang.String) != "" {
		return normalizeTgLangMode(groupLang.String)
	}
	return mode
}

func tgFormatLabel(zh, vi string, mode TgLangMode) string {
	switch mode {
	case TgLangZh:
		return zh
	case TgLangVi:
		if vi != "" {
			return vi
		}
		return zh
	default:
		if vi != "" && vi != zh {
			return zh + " / " + vi
		}
		return zh
	}
}

func tgActivityLabel(activity string, mode TgLangMode) string {
	return tgFormatLabel(activity, tgActivityVI[activity], mode)
}

func tgDefaultActivityIcon(name string) string {
	return tgDefaultActivityIcons[strings.TrimSpace(name)]
}

func tgActivityKeyboardLabel(activity string, mode TgLangMode) string {
	base := tgActivityLabel(activity, mode)
	if icon := tgDefaultActivityIcon(activity); icon != "" {
		return icon + " " + base
	}
	return base
}

// stripActivityKeyboardPrefix removes a leading default activity icon from button text.
func stripActivityKeyboardPrefix(text string) string {
	text = strings.TrimSpace(text)
	if text == "" {
		return text
	}
	seen := make(map[string]struct{}, len(tgDefaultActivityIcons))
	for _, icon := range tgDefaultActivityIcons {
		if icon == "" {
			continue
		}
		if _, ok := seen[icon]; ok {
			continue
		}
		seen[icon] = struct{}{}
		if strings.HasPrefix(text, icon+" ") {
			return strings.TrimSpace(text[len(icon)+1:])
		}
	}
	return text
}

func tgButtonLabel(meta tgButtonMeta, mode TgLangMode) string {
	return tgFormatLabel(meta.Zh, meta.Vi, mode)
}

func tgKeyboardBtn(label, style string) map[string]interface{} {
	btn := map[string]interface{}{"text": label}
	if strings.TrimSpace(style) != "" {
		btn["style"] = style
	}
	return btn
}

func tgCollectStyledLabels(meta tgButtonMeta) []string {
	labels := []string{
		strings.TrimSpace(meta.Zh),
		strings.TrimSpace(meta.Vi),
		strings.TrimSpace(tgFormatLabel(meta.Zh, meta.Vi, TgLangBoth)),
		strings.TrimSpace(tgFormatLabel(meta.Zh, meta.Vi, TgLangZh)),
		strings.TrimSpace(tgFormatLabel(meta.Zh, meta.Vi, TgLangVi)),
	}
	for _, legacy := range meta.Legacy {
		if legacy = strings.TrimSpace(legacy); legacy != "" {
			labels = append(labels, legacy)
		}
	}
	return labels
}

func buildStyledButtonTextLookup() map[string]string {
	lookup := map[string]string{}
	addMeta := func(meta tgButtonMeta) {
		style := strings.TrimSpace(meta.Style)
		if style == "" {
			return
		}
		for _, label := range tgCollectStyledLabels(meta) {
			if label != "" {
				lookup[label] = style
			}
		}
	}
	for _, meta := range tgWorkButtons {
		addMeta(meta)
	}
	for _, meta := range tgUIButtons {
		addMeta(meta)
	}
	return lookup
}

func enrichReplyKeyboardButton(btn map[string]interface{}, lookup map[string]string) {
	text, _ := btn["text"].(string)
	text = strings.TrimSpace(text)
	if text == "" {
		return
	}
	if style, ok := lookup[text]; ok {
		btn["style"] = style
	}
}

func enrichReplyKeyboardStyles(kb map[string]interface{}) map[string]interface{} {
	if kb == nil {
		return nil
	}
	lookup := buildStyledButtonTextLookup()
	rawRows, ok := kb["keyboard"]
	if !ok || rawRows == nil {
		return kb
	}
	switch rows := rawRows.(type) {
	case [][]map[string]interface{}:
		for i := range rows {
			for j := range rows[i] {
				enrichReplyKeyboardButton(rows[i][j], lookup)
			}
		}
		kb["keyboard"] = rows
	case []interface{}:
		for _, row := range rows {
			btnRow, ok := row.([]interface{})
			if !ok {
				continue
			}
			for i, btn := range btnRow {
				switch b := btn.(type) {
				case string:
					if style, ok := lookup[strings.TrimSpace(b)]; ok {
						btnRow[i] = map[string]interface{}{"text": b, "style": style}
					}
				case map[string]interface{}:
					enrichReplyKeyboardButton(b, lookup)
				}
			}
		}
	}
	return kb
}

func tgRegisterLookup(lookup map[string]string, canonical, text string) {
	if text = strings.TrimSpace(text); text != "" {
		lookup[text] = canonical
	}
}

func tgRegisterMeta(lookup map[string]string, key string, meta tgButtonMeta, mode TgLangMode) {
	tgRegisterLookup(lookup, key, meta.Zh)
	tgRegisterLookup(lookup, key, meta.Vi)
	tgRegisterLookup(lookup, key, tgButtonLabel(meta, TgLangBoth))
	for _, legacy := range meta.Legacy {
		tgRegisterLookup(lookup, key, legacy)
	}
}

func (s *WorkforceTelegramService) BuildButtonLookup(ctx context.Context, activityNames []string) map[string]string {
	settings, _ := s.GetSettings(ctx)
	mode := normalizeTgLangMode("")
	if settings != nil {
		mode = normalizeTgLangMode(settings.BotUILang)
	}
	lookup := map[string]string{}
	for key, meta := range tgWorkButtons {
		tgRegisterMeta(lookup, key, meta, mode)
	}
	for key, meta := range tgUIButtons {
		tgRegisterMeta(lookup, key, meta, mode)
	}
	for _, act := range activityNames {
		name := strings.TrimSpace(act)
		if name == "" {
			continue
		}
		tgRegisterLookup(lookup, name, name)
		tgRegisterLookup(lookup, name, tgActivityLabel(name, TgLangZh))
		tgRegisterLookup(lookup, name, tgActivityLabel(name, TgLangVi))
		tgRegisterLookup(lookup, name, tgActivityLabel(name, TgLangBoth))
		tgRegisterLookup(lookup, name, tgActivityKeyboardLabel(name, TgLangZh))
		tgRegisterLookup(lookup, name, tgActivityKeyboardLabel(name, TgLangVi))
		tgRegisterLookup(lookup, name, tgActivityKeyboardLabel(name, TgLangBoth))
	}
	// Legacy slash commands
	tgRegisterLookup(lookup, "back", "/at")
	tgRegisterLookup(lookup, "checkin", "/checkin")
	tgRegisterLookup(lookup, "work_end", "/checkout")
	tgRegisterLookup(lookup, "status", "/status")
	tgRegisterLookup(lookup, "my_record", "/myinfo")
	tgRegisterLookup(lookup, "rank", "/rankings")
	tgRegisterLookup(lookup, "handover", "/handover")
	tgRegisterLookup(lookup, "help", "/start")
	tgRegisterLookup(lookup, "help", "/help")
	tgRegisterLookup(lookup, "my_record_day", "/myinfoday")
	tgRegisterLookup(lookup, "my_record_day", "白班信息")
	tgRegisterLookup(lookup, "my_record_night", "/myinfonight")
	tgRegisterLookup(lookup, "my_record_night", "夜班信息")
	tgRegisterLookup(lookup, "rank_day", "/rankingsday")
	tgRegisterLookup(lookup, "rank_day", "白班排行")
	tgRegisterLookup(lookup, "rank_night", "/rankingsnight")
	tgRegisterLookup(lookup, "rank_night", "夜班排行")
	tgRegisterLookup(lookup, "work_start_day", "白班")
	tgRegisterLookup(lookup, "work_start_night", "夜班")
	tgRegisterLookup(lookup, "export_data", "/export")
	tgRegisterLookup(lookup, "export_data", "/exportmonthly")
	tgRegisterLookup(lookup, "export_data", "导出数据")
	tgRegisterLookup(lookup, "actstatus", "/actstatus")
	tgRegisterLookup(lookup, "showsettings", "/showsettings")
	return lookup
}

func localizedMainReplyKeyboard(mode TgLangMode, dualShift bool, activityNames []string) map[string]interface{} {
	var rows [][]map[string]interface{}
	if dualShift {
		rows = append(rows, []map[string]interface{}{
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_start_day"], mode), tgWorkButtons["work_start_day"].Style),
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_start_night"], mode), tgWorkButtons["work_start_night"].Style),
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_end"], mode), tgWorkButtons["work_end"].Style),
		})
	} else {
		rows = append(rows, []map[string]interface{}{
			tgKeyboardBtn(tgButtonLabel(tgUIButtons["checkin"], mode), tgUIButtons["checkin"].Style),
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_end"], mode), tgWorkButtons["work_end"].Style),
		})
	}
	displayNames := make([]string, 0, len(activityNames))
	for _, name := range activityNames {
		displayNames = append(displayNames, tgActivityKeyboardLabel(strings.TrimSpace(name), mode))
	}
	rows = append(rows, buildActivityRowsWithBack(mode, displayNames)...)
	rows = append(rows, []map[string]interface{}{
		tgKeyboardBtn(tgButtonLabel(tgUIButtons["my_record"], mode), ""),
		tgKeyboardBtn(tgButtonLabel(tgUIButtons["rank"], mode), ""),
		tgKeyboardBtn(tgButtonLabel(tgUIButtons["export_data"], mode), ""),
	})
	return enrichReplyKeyboardStyles(map[string]interface{}{
		"keyboard":          rows,
		"resize_keyboard":   true,
		"one_time_keyboard": false,
	})
}

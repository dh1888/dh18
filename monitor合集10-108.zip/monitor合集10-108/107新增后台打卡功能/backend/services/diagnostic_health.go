package services

import (
	"context"
	"strings"
	"time"

	"enterprise-agent/backend/models"
)

func (s *DiagnosticService) enrichSnapshot(ctx context.Context, snap *models.DiagnosticSnapshot) {
	if snap == nil {
		return
	}
	snap.StatsToday = s.buildDailyStats(ctx)
	snap.Health = s.buildSystemHealth(ctx, snap)
}

func (s *DiagnosticService) buildDailyStats(ctx context.Context) models.DiagnosticDailyStats {
	stats := models.DiagnosticDailyStats{}
	startOfDay := models.UTCNow().Truncate(24 * time.Hour)
	rows, err := s.db.QueryContext(ctx, `
		SELECT action, COUNT(*)
		FROM remote_view_audit_logs
		WHERE created_at >= $1
		GROUP BY action
	`, startOfDay)
	if err != nil {
		return stats
	}
	defer rows.Close()
	for rows.Next() {
		var action string
		var count int
		if err := rows.Scan(&action, &count); err != nil {
			continue
		}
		lower := strings.ToLower(action)
		switch {
		case strings.Contains(lower, "start") || strings.Contains(action, "启动") || strings.Contains(action, "开始"):
			stats.RemoteViewStarts += count
		case strings.Contains(lower, "success") || strings.Contains(action, "成功"):
			stats.RemoteViewSuccess += count
		case strings.Contains(lower, "fail") || strings.Contains(lower, "error") ||
			strings.Contains(action, "失败") || strings.Contains(action, "断开"):
			stats.RemoteViewFailures += count
		}
	}
	if stats.RemoteViewStarts == 0 {
		stats.RemoteViewStarts = stats.RemoteViewSuccess + stats.RemoteViewFailures
	}
	if stats.RemoteViewStarts > 0 {
		success := stats.RemoteViewStarts - stats.RemoteViewFailures
		if success < 0 {
			success = stats.RemoteViewSuccess
		}
		stats.RemoteViewSuccess = success
		stats.SuccessRate = float64(success) / float64(stats.RemoteViewStarts) * 100
	}
	return stats
}

func (s *DiagnosticService) buildSystemHealth(ctx context.Context, snap *models.DiagnosticSnapshot) models.DiagnosticHealthScore {
	layers := []models.DiagnosticHealthLayer{}
	score := 100

	wsStatus := statusHealthy
	wsDetail := "连接正常"
	if snap.WebSocket.AgentsOnline == 0 {
		wsStatus = statusDegraded
		wsDetail = "无在线 Agent"
		score -= 15
	}
	layers = append(layers, models.DiagnosticHealthLayer{ID: "websocket", Label: "WebSocket", Status: wsStatus, Detail: wsDetail})

	agentStatus := statusUnknown
	agentDetail := "无 Agent"
	if len(snap.Agents) > 0 {
		online := 0
		for _, a := range snap.Agents {
			if a.Online {
				online++
			}
		}
		switch {
		case online == len(snap.Agents):
			agentStatus = statusHealthy
			agentDetail = "全部在线"
		case online > 0:
			agentStatus = statusDegraded
			agentDetail = "部分离线"
			score -= 10
		default:
			agentStatus = statusDown
			agentDetail = "全部离线"
			score -= 25
		}
	}
	layers = append(layers, models.DiagnosticHealthLayer{ID: "agent", Label: "Agent", Status: agentStatus, Detail: agentDetail})

	pipelineLayers := []string{"capture", "ffmpeg", "whip", "ingress", "livekit", "frontend"}
	pipelineLabels := map[string]string{
		"capture": "Capture", "ffmpeg": "FFmpeg", "whip": "WHIP",
		"ingress": "Ingress", "livekit": "LiveKit", "frontend": "Browser",
	}

	if snap.RemoteView.ActiveSessions > 0 && len(snap.RemoteView.Sessions) > 0 {
		session := snap.RemoteView.Sessions[0]
		if pipe, err := s.BuildPipeline(ctx, session.DeviceID); err == nil && pipe != nil {
			for _, nodeID := range pipelineLayers {
				for _, node := range pipe.Nodes {
					if node.ID != nodeID {
						continue
					}
					layers = append(layers, models.DiagnosticHealthLayer{
						ID: node.ID, Label: pipelineLabels[nodeID], Status: node.Status, Detail: node.Detail,
					})
					switch node.Status {
					case statusDegraded:
						score -= 8
					case statusDown:
						score -= 20
					case statusUnknown:
						score -= 3
					}
				}
			}
		}
	} else {
		for _, nodeID := range pipelineLayers {
			layers = append(layers, models.DiagnosticHealthLayer{
				ID: nodeID, Label: pipelineLabels[nodeID], Status: statusUnknown, Detail: "无活跃 RemoteView 会话",
			})
			score -= 2
		}
	}

	errCount := snap.Events.Last5Min["ERROR"]
	if errCount >= 3 {
		score -= 15
	} else if errCount >= 1 {
		score -= 5
	}
	if score < 0 {
		score = 0
	}
	if score > 100 {
		score = 100
	}
	return models.DiagnosticHealthScore{Score: score, Layers: layers}
}

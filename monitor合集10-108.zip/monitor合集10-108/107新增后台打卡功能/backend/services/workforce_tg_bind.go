package services

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
)

func (s *WorkforceTelegramService) telegramUserBoundEmployee(ctx context.Context, telegramUserID int64) (uuid.UUID, error) {
	var empID uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT employee_id FROM employee_telegram_bindings
		WHERE telegram_user_id = $1 AND status = 1`, telegramUserID).Scan(&empID)
	if err == sql.ErrNoRows {
		return uuid.Nil, nil
	}
	return empID, err
}

func (s *WorkforceTelegramService) employeeTelegramBound(ctx context.Context, employeeID uuid.UUID) (int64, error) {
	var tgUID int64
	err := s.db.QueryRowContext(ctx, `
		SELECT telegram_user_id FROM employee_telegram_bindings
		WHERE employee_id = $1 AND status = 1`, employeeID).Scan(&tgUID)
	if err == sql.ErrNoRows {
		return 0, nil
	}
	return tgUID, err
}

// BindTelegramByInviteCode binds via invite + username (legacy alias).
func (s *WorkforceTelegramService) BindTelegramByInviteCode(ctx context.Context, telegramUserID int64, telegramUsername, inviteCode, chatID string) (*TelegramBindingRow, error) {
	return nil, fmt.Errorf("用法：/bind 邀请码 账号")
}

// BindTelegramByInviteAndCredentials binds personal TG with invite + username (password optional).
func (s *WorkforceTelegramService) BindTelegramByInviteAndCredentials(ctx context.Context, telegramUserID int64, telegramUsername, inviteCode, username, password, chatID string) (*TelegramBindingRow, error) {
	if telegramUserID <= 0 {
		return nil, fmt.Errorf("invalid telegram user id")
	}
	if s.workforce == nil {
		return nil, fmt.Errorf("workforce service unavailable")
	}
	inviteCode = strings.TrimSpace(inviteCode)
	if inviteCode == "" {
		return nil, fmt.Errorf("invite code required")
	}
	username = strings.TrimSpace(username)
	password = strings.TrimSpace(password)
	if username == "" {
		return nil, fmt.Errorf("账号不能为空，用法：/bind 邀请码 账号")
	}
	if err := s.ensureTelegramNotCrossBound(ctx, telegramUserID, TelegramChannelPersonal); err != nil {
		return nil, err
	}
	invite, err := s.workforce.ResolveInviteCodeEmployee(ctx, inviteCode)
	if err != nil {
		return nil, err
	}
	if password != "" {
		if err := s.workforce.ValidateEmployeeCredentials(ctx, username, password, invite.EmployeeID); err != nil {
			return nil, err
		}
	} else if err := s.workforce.ValidateEmployeeUsername(ctx, username, invite.EmployeeID); err != nil {
		return nil, err
	}
	if boundEmp, err := s.telegramUserBoundEmployee(ctx, telegramUserID); err != nil {
		return nil, err
	} else if boundEmp != uuid.Nil && boundEmp != invite.EmployeeID {
		return nil, ErrTelegramAlreadyBound
	}
	if otherTG, err := s.employeeTelegramBound(ctx, invite.EmployeeID); err != nil {
		return nil, err
	} else if otherTG > 0 && otherTG != telegramUserID {
		return nil, fmt.Errorf("该员工已绑定其他 Telegram 账号")
	}
	row, err := s.CreateBinding(ctx, invite.EmployeeID, telegramUserID, telegramUsername, chatID)
	if err != nil {
		return nil, err
	}
	_ = s.setEmployeeAttendanceMode(ctx, invite.EmployeeID, AttendanceModeTGOnly)
	return row, nil
}

// BindWorkstationTelegramByInviteCode binds a shared workstation TG account to a device.
func (s *WorkforceTelegramService) BindWorkstationTelegramByInviteCode(ctx context.Context, telegramUserID int64, telegramUsername, inviteCode, chatID string) (*DeviceTelegramBindingRow, error) {
	if telegramUserID <= 0 {
		return nil, fmt.Errorf("invalid telegram user id")
	}
	if s.workforce == nil {
		return nil, fmt.Errorf("workforce service unavailable")
	}
	inviteCode = strings.TrimSpace(inviteCode)
	if inviteCode == "" {
		return nil, fmt.Errorf("invite code required")
	}
	if err := s.ensureTelegramNotCrossBound(ctx, telegramUserID, TelegramChannelWorkstation); err != nil {
		return nil, err
	}
	invite, err := s.workforce.ResolveInviteCodeEmployee(ctx, inviteCode)
	if err != nil {
		return nil, err
	}
	deviceID, err := s.findSharedWorkstationDeviceForEmployee(ctx, invite.EmployeeID)
	if err != nil {
		return nil, err
	}
	ok, err := s.deviceIsSharedWorkstation(ctx, deviceID)
	if err != nil {
		return nil, err
	}
	if !ok {
		return nil, ErrWorkstationNotConfigured
	}
	var existingDevice uuid.UUID
	err = s.db.QueryRowContext(ctx, `
		SELECT device_id FROM device_telegram_bindings
		WHERE telegram_user_id = $1 AND status = 1`, telegramUserID).Scan(&existingDevice)
	if err == nil && existingDevice != uuid.Nil && existingDevice != deviceID {
		return nil, ErrTelegramAlreadyBound
	}
	var otherTG int64
	err = s.db.QueryRowContext(ctx, `
		SELECT telegram_user_id FROM device_telegram_bindings
		WHERE device_id = $1 AND status = 1`, deviceID).Scan(&otherTG)
	if err == nil && otherTG > 0 && otherTG != telegramUserID {
		return nil, ErrDeviceTelegramAlreadyBound
	}
	var id uuid.UUID
	err = s.db.QueryRowContext(ctx, `
		INSERT INTO device_telegram_bindings (device_id, telegram_user_id, telegram_username, chat_id, status)
		VALUES ($1, $2, $3, $4, 1)
		ON CONFLICT (device_id) DO UPDATE SET
			telegram_user_id = EXCLUDED.telegram_user_id,
			telegram_username = EXCLUDED.telegram_username,
			chat_id = CASE
				WHEN COALESCE(NULLIF(TRIM(EXCLUDED.chat_id), ''), '') <> '' THEN EXCLUDED.chat_id
				ELSE device_telegram_bindings.chat_id
			END,
			status = 1,
			bound_at = NOW()
		RETURNING id`, deviceID, telegramUserID, nullString(strings.TrimSpace(telegramUsername)), nullString(strings.TrimSpace(chatID))).Scan(&id)
	if err != nil {
		return nil, err
	}
	_, _ = s.db.ExecContext(ctx, `UPDATE devices SET is_shared_workstation = TRUE WHERE id = $1`, deviceID)
	items, err := s.ListDeviceTelegramBindings(ctx, "")
	if err != nil {
		return nil, err
	}
	for _, item := range items {
		if item.ID == id {
			return &item, nil
		}
	}
	return nil, fmt.Errorf("workstation binding not found after create")
}

func generateTelegramBindTokenString() (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

type TelegramBindTokenResult struct {
	Token        string
	ExpiresAt    time.Time
	BotUsername  string
	DeepLink     string
	EmployeeID   uuid.UUID
	EmployeeName string
}

// CreateTelegramBindToken issues a short-lived deep-link token for logged-in agent employees.
func (s *WorkforceTelegramService) CreateTelegramBindToken(ctx context.Context, deviceID, employeeID uuid.UUID) (*TelegramBindTokenResult, error) {
	if employeeID == uuid.Nil {
		return nil, ErrEmployeeNotFound
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return nil, err
	}
	if !settings.HasBotToken || strings.TrimSpace(settings.BotUsername) == "" {
		return nil, fmt.Errorf("telegram bot not configured")
	}
	token, err := generateTelegramBindTokenString()
	if err != nil {
		return nil, err
	}
	expires := time.Now().Add(15 * time.Minute)
	var dev interface{}
	if deviceID != uuid.Nil {
		dev = deviceID
	}
	if _, err := s.db.ExecContext(ctx, `
		UPDATE wf_tg_bind_tokens SET used_at = NOW()
		WHERE employee_id = $1 AND used_at IS NULL AND expires_at > NOW()`, employeeID); err != nil {
		return nil, err
	}
	if _, err := s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_bind_tokens (token, employee_id, device_id, expires_at)
		VALUES ($1, $2, $3, $4)`, token, employeeID, dev, expires); err != nil {
		return nil, err
	}
	var name string
	_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, employeeID).Scan(&name)
	deepLink := fmt.Sprintf("https://t.me/%s?start=bind_%s", strings.TrimPrefix(settings.BotUsername, "@"), token)
	return &TelegramBindTokenResult{
		Token:        token,
		ExpiresAt:    expires,
		BotUsername:  settings.BotUsername,
		DeepLink:     deepLink,
		EmployeeID:   employeeID,
		EmployeeName: name,
	}, nil
}

// BindTelegramByToken consumes a deep-link bind token.
func (s *WorkforceTelegramService) BindTelegramByToken(ctx context.Context, telegramUserID int64, telegramUsername, token, chatID string) (*TelegramBindingRow, error) {
	token = strings.TrimSpace(strings.TrimPrefix(token, "bind_"))
	if token == "" || telegramUserID <= 0 {
		return nil, fmt.Errorf("invalid bind token")
	}
	if err := s.ensureTelegramNotCrossBound(ctx, telegramUserID, TelegramChannelPersonal); err != nil {
		return nil, err
	}
	var employeeID uuid.UUID
	var expiresAt time.Time
	var usedAt sql.NullTime
	err := s.db.QueryRowContext(ctx, `
		SELECT employee_id, expires_at, used_at FROM wf_tg_bind_tokens
		WHERE token = $1`, token).Scan(&employeeID, &expiresAt, &usedAt)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("绑定链接无效或已过期")
	}
	if err != nil {
		return nil, err
	}
	if usedAt.Valid {
		return nil, fmt.Errorf("绑定链接已使用")
	}
	if time.Now().After(expiresAt) {
		return nil, fmt.Errorf("绑定链接已过期，请在客户端重新获取")
	}
	if boundEmp, err := s.telegramUserBoundEmployee(ctx, telegramUserID); err != nil {
		return nil, err
	} else if boundEmp != uuid.Nil && boundEmp != employeeID {
		return nil, ErrTelegramAlreadyBound
	}
	if otherTG, err := s.employeeTelegramBound(ctx, employeeID); err != nil {
		return nil, err
	} else if otherTG > 0 && otherTG != telegramUserID {
		return nil, fmt.Errorf("该员工已绑定其他 Telegram 账号")
	}
	row, err := s.CreateBinding(ctx, employeeID, telegramUserID, telegramUsername, chatID)
	if err != nil {
		return nil, err
	}
	res, execErr := s.db.ExecContext(ctx, `
		UPDATE wf_tg_bind_tokens SET used_at = NOW(), used_by_telegram_user_id = $2
		WHERE token = $1 AND used_at IS NULL`, token, telegramUserID)
	if execErr != nil {
		return row, execErr
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return nil, errors.New("bind token already used")
	}
	return row, nil
}

// BindTelegramSelf accepts invite code (+ credentials) or bind token from worker API.
func (s *WorkforceTelegramService) BindTelegramSelf(ctx context.Context, telegramUserID int64, telegramUsername, inviteCode, bindToken, username, password, chatID string) (*TelegramBindingRow, error) {
	inviteCode = strings.TrimSpace(inviteCode)
	bindToken = strings.TrimSpace(bindToken)
	switch {
	case bindToken != "":
		return s.BindTelegramByToken(ctx, telegramUserID, telegramUsername, bindToken, chatID)
	case inviteCode != "":
		return s.BindTelegramByInviteAndCredentials(ctx, telegramUserID, telegramUsername, inviteCode, username, password, chatID)
	default:
		return nil, fmt.Errorf("invite code or bind token required")
	}
}

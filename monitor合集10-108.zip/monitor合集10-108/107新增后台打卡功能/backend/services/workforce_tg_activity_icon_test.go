package services

import "testing"

func TestActivityKeyboardIconLabels(t *testing.T) {
	label := tgActivityKeyboardLabel("小厕", TgLangZh)
	if label != "🚽 小厕" {
		t.Fatalf("expected icon label, got %q", label)
	}
	lookup := map[string]string{}
	tgRegisterLookup(lookup, "小厕", tgActivityKeyboardLabel("小厕", TgLangZh))
	if lookup["🚽 小厕"] != "小厕" {
		t.Fatalf("lookup mismatch: %v", lookup)
	}
}

func TestStripActivityKeyboardPrefix(t *testing.T) {
	if got := stripActivityKeyboardPrefix("🚽 小厕"); got != "小厕" {
		t.Fatalf("strip icon prefix failed: %q", got)
	}
	if got := stripActivityKeyboardPrefix("小厕"); got != "小厕" {
		t.Fatalf("plain name changed: %q", got)
	}
}

func TestResolveActivityTypeByIconLabel(t *testing.T) {
	// Ensures API/agent paths still resolve when only icon+name text is used.
	if got := canonicalActivityTypeCode("🍱 吃饭"); got != "eat" {
		t.Fatalf("expected eat, got %q", got)
	}
}

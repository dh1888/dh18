package services

import (
	"archive/zip"
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

const systemSettingDiagnosticCenter = "diagnostic_center_config"

type DiagnosticService struct {
	db          *sql.DB
	wsHub       *WebSocketHub
	remoteView  *RemoteViewService
	deviceRepo  *DeviceRepository

	mu     sync.RWMutex
	config models.DiagnosticCenterConfig
	loaded bool

	agentSnapMu sync.RWMutex
	agentSnaps  map[string]agentSnapshotEntry

	reproduceMu   sync.RWMutex
	reproduceJobs map[string]*models.DiagnosticReproduceStatus
	reproduceCap  map[string]*models.DiagnosticCaptureResult
}

type agentSnapshotEntry struct {
	payload   map[string]interface{}
	received  time.Time
}

func (s *DiagnosticService) SetRemoteViewService(rv *RemoteViewService) {
	s.remoteView = rv
}

func (s *DiagnosticService) SetDeviceRepository(repo *DeviceRepository) {
	s.deviceRepo = repo
}

func NewDiagnosticService(db *sql.DB, wsHub *WebSocketHub) *DiagnosticService {
	svc := &DiagnosticService{
		db:            db,
		wsHub:         wsHub,
		agentSnaps:    make(map[string]agentSnapshotEntry),
		reproduceJobs: make(map[string]*models.DiagnosticReproduceStatus),
		reproduceCap:  make(map[string]*models.DiagnosticCaptureResult),
	}
	svc.reloadConfig(context.Background())
	go svc.runExpiryWatcher()
	return svc
}

func (s *DiagnosticService) reloadConfig(ctx context.Context) {
	cfg := models.DefaultDiagnosticCenterConfig()
	var raw sql.NullString
	err := s.db.QueryRowContext(ctx,
		`SELECT value FROM system_settings WHERE key = $1`, systemSettingDiagnosticCenter).Scan(&raw)
	if err == nil && raw.Valid && strings.TrimSpace(raw.String) != "" {
		if unmarshalErr := json.Unmarshal([]byte(raw.String), &cfg); unmarshalErr != nil {
			log.Printf("[DiagnosticCenter] invalid config JSON: %v", unmarshalErr)
		}
	}
	if cfg.ModuleLevels == nil {
		cfg.ModuleLevels = models.DefaultDiagnosticCenterConfig().ModuleLevels
	}
	if cfg.RetentionHours <= 0 {
		cfg.RetentionHours = 72
	}
	s.mu.Lock()
	s.config = cfg
	s.loaded = true
	s.mu.Unlock()
}

func (s *DiagnosticService) GetConfig(ctx context.Context) (models.DiagnosticCenterConfig, error) {
	s.reloadConfig(ctx)
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.config, nil
}

func (s *DiagnosticService) GetRuntimeConfig() models.DiagnosticRuntimeConfig {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.config.Effective(time.Now().UTC())
}

func (s *DiagnosticService) ApplyTemplate(
	ctx context.Context,
	templateID string,
	durationMinutes int,
	updatedBy string,
) (models.DiagnosticCenterConfig, error) {
	tmpl, ok := models.GetDiagnosticTemplate(templateID)
	if !ok {
		return models.DiagnosticCenterConfig{}, fmt.Errorf("unknown diagnostic template: %s", templateID)
	}
	current, err := s.GetConfig(ctx)
	if err != nil {
		return models.DiagnosticCenterConfig{}, err
	}
	cfg := models.ApplyDiagnosticTemplate(current, tmpl, durationMinutes)
	return s.SaveConfig(ctx, cfg, updatedBy)
}

func (s *DiagnosticService) ListTemplates() []models.DiagnosticTemplate {
	return models.ListDiagnosticTemplates()
}

func (s *DiagnosticService) SaveConfig(
	ctx context.Context,
	cfg models.DiagnosticCenterConfig,
	updatedBy string,
) (models.DiagnosticCenterConfig, error) {
	cfg.GlobalLevel = models.NormalizeDiagnosticLevel(string(cfg.GlobalLevel))
	if cfg.ModuleLevels == nil {
		cfg.ModuleLevels = map[string]models.DiagnosticLevel{}
	}
	normalized := make(map[string]models.DiagnosticLevel, len(models.DiagnosticModules))
	for _, module := range models.DiagnosticModules {
		level := cfg.GlobalLevel
		if v, ok := cfg.ModuleLevels[module]; ok {
			level = models.NormalizeDiagnosticLevel(string(v))
		}
		normalized[module] = level
	}
	cfg.ModuleLevels = normalized
	if cfg.RetentionHours <= 0 {
		cfg.RetentionHours = 72
	}
	cfg.UpdatedAt = models.UTCNow()
	cfg.UpdatedBy = updatedBy

	body, err := json.Marshal(cfg)
	if err != nil {
		return models.DiagnosticCenterConfig{}, err
	}
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO system_settings (key, value, updated_at)
		VALUES ($1, $2, NOW())
		ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
	`, systemSettingDiagnosticCenter, string(body))
	if err != nil {
		return models.DiagnosticCenterConfig{}, err
	}

	s.mu.Lock()
	s.config = cfg
	s.loaded = true
	s.mu.Unlock()

	s.BroadcastConfig()
	return cfg, nil
}

func (s *DiagnosticService) BroadcastConfig() {
	if s.wsHub == nil {
		return
	}
	runtime := s.GetRuntimeConfig()
	payload := gin.H{
		"type":   "diagnostic_config_update",
		"config": runtime,
	}
	s.wsHub.SendCriticalToAllAgents(payload)
	s.wsHub.BroadcastToAdmin(gin.H{
		"type":   "diagnostic_config_update",
		"config": runtime,
	})
}

func (s *DiagnosticService) PushConfigToDevice(deviceID string) {
	if s.wsHub == nil || deviceID == "" {
		return
	}
	runtime := s.GetRuntimeConfig()
	s.wsHub.SendCriticalToAgent(deviceID, gin.H{
		"type":   "diagnostic_config_update",
		"config": runtime,
	})
}

func (s *DiagnosticService) Allows(source, module string, level models.DiagnosticLevel) bool {
	runtime := s.GetRuntimeConfig()
	if !runtime.Active {
		return false
	}
	if source == "frontend" && !runtime.FrontendUploadEnabled {
		return false
	}
	if source == "agent" && !runtime.AgentUploadEnabled {
		return false
	}
	return runtime.Allows(module, level)
}

func (s *DiagnosticService) Record(
	ctx context.Context,
	source, module string,
	level models.DiagnosticLevel,
	message string,
	deviceID *uuid.UUID,
	contextData map[string]interface{},
	correlationID string,
) error {
	if !s.Allows(source, module, level) {
		return nil
	}
	if strings.TrimSpace(message) == "" {
		return nil
	}

	retention := time.Duration(72) * time.Hour
	s.mu.RLock()
	if s.config.RetentionHours > 0 {
		retention = time.Duration(s.config.RetentionHours) * time.Hour
	}
	s.mu.RUnlock()

	var ctxJSON []byte
	if len(contextData) > 0 {
		ctxJSON, _ = json.Marshal(contextData)
	}
	id := uuid.New()
	now := models.UTCNow()
	expiresAt := now.Add(retention)

	_, err := s.db.ExecContext(ctx, `
		INSERT INTO diagnostic_events (
			id, source, device_id, module, level, message, context, correlation_id, created_at, expires_at
		) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
	`, id, source, deviceID, module, string(level), message, diagNullJSON(ctxJSON), diagNullString(correlationID), now, expiresAt)
	if err != nil {
		return err
	}

	if s.wsHub != nil && models.DiagnosticLevelRank(level) <= models.DiagnosticLevelRank(models.DiagnosticLevelWarn) {
		s.wsHub.BroadcastToAdmin(gin.H{
			"type":          "diagnostic_event",
			"id":            id.String(),
			"source":        source,
			"deviceId":      nullableUUIDString(deviceID),
			"module":        module,
			"level":         level,
			"message":       message,
			"context":       contextData,
			"correlationId": correlationID,
			"createdAt":     now,
		})
	}
	return nil
}

func (s *DiagnosticService) IngestAgentLog(deviceID string, payload map[string]interface{}) {
	module, _ := payload["module"].(string)
	levelRaw, _ := payload["level"].(string)
	message, _ := payload["message"].(string)
	correlationID, _ := payload["correlationId"].(string)
	level := models.NormalizeDiagnosticLevel(levelRaw)
	if module == "" {
		module = "Backend"
	}

	var contextData map[string]interface{}
	if ctxRaw, ok := payload["context"].(map[string]interface{}); ok {
		contextData = ctxRaw
	}

	var deviceUUID *uuid.UUID
	if parsed, err := uuid.Parse(deviceID); err == nil {
		deviceUUID = &parsed
	}

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if err := s.Record(ctx, "agent", module, level, message, deviceUUID, contextData, correlationID); err != nil {
		log.Printf("[DiagnosticCenter] ingest agent log failed: %v", err)
	}
}

func (s *DiagnosticService) IngestFrontendLog(
	userID string,
	payload map[string]interface{},
) {
	module, _ := payload["module"].(string)
	levelRaw, _ := payload["level"].(string)
	message, _ := payload["message"].(string)
	correlationID, _ := payload["correlationId"].(string)
	level := models.NormalizeDiagnosticLevel(levelRaw)
	if module == "" {
		module = "RemoteView"
	}

	var contextData map[string]interface{}
	if ctxRaw, ok := payload["context"].(map[string]interface{}); ok {
		contextData = ctxRaw
	} else {
		contextData = map[string]interface{}{}
	}
	if userID != "" {
		contextData["userId"] = userID
	}

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if err := s.Record(ctx, "frontend", module, level, message, nil, contextData, correlationID); err != nil {
		log.Printf("[DiagnosticCenter] ingest frontend log failed: %v", err)
	}
}

type DiagnosticEventQuery struct {
	Source    string
	Module    string
	Level     string
	DeviceID  string
	From      *time.Time
	To        *time.Time
	Page      int
	PageSize  int
}

func (s *DiagnosticService) ListEvents(ctx context.Context, q DiagnosticEventQuery) ([]models.DiagnosticEvent, int, error) {
	if q.Page < 1 {
		q.Page = 1
	}
	if q.PageSize < 1 {
		q.PageSize = 50
	}
	if q.PageSize > 200 {
		q.PageSize = 200
	}

	where := "1=1"
	args := []interface{}{}
	idx := 1

	if q.Source != "" {
		where += fmt.Sprintf(" AND source = $%d", idx)
		args = append(args, q.Source)
		idx++
	}
	if q.Module != "" {
		where += fmt.Sprintf(" AND module = $%d", idx)
		args = append(args, q.Module)
		idx++
	}
	if q.Level != "" {
		where += fmt.Sprintf(" AND level = $%d", idx)
		args = append(args, strings.ToUpper(q.Level))
		idx++
	}
	if q.DeviceID != "" {
		where += fmt.Sprintf(" AND device_id = $%d", idx)
		args = append(args, q.DeviceID)
		idx++
	}
	if q.From != nil {
		where += fmt.Sprintf(" AND created_at >= $%d", idx)
		args = append(args, *q.From)
		idx++
	}
	if q.To != nil {
		where += fmt.Sprintf(" AND created_at <= $%d", idx)
		args = append(args, *q.To)
		idx++
	}

	var total int
	countSQL := "SELECT COUNT(*) FROM diagnostic_events WHERE " + where
	if err := s.db.QueryRowContext(ctx, countSQL, args...).Scan(&total); err != nil {
		return nil, 0, err
	}

	offset := (q.Page - 1) * q.PageSize
	listSQL := fmt.Sprintf(`
		SELECT id, source, device_id, module, level, message, context, correlation_id, created_at
		FROM diagnostic_events
		WHERE %s
		ORDER BY created_at DESC
		LIMIT $%d OFFSET $%d
	`, where, idx, idx+1)
	args = append(args, q.PageSize, offset)

	rows, err := s.db.QueryContext(ctx, listSQL, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	out := make([]models.DiagnosticEvent, 0, q.PageSize)
	for rows.Next() {
		var ev models.DiagnosticEvent
		var deviceID sql.NullString
		var ctxRaw sql.NullString
		var corr sql.NullString
		if err := rows.Scan(
			&ev.ID, &ev.Source, &deviceID, &ev.Module, &ev.Level, &ev.Message, &ctxRaw, &corr, &ev.CreatedAt,
		); err != nil {
			return nil, 0, err
		}
		if deviceID.Valid {
			if parsed, err := uuid.Parse(deviceID.String); err == nil {
				ev.DeviceID = &parsed
			}
		}
		if ctxRaw.Valid && strings.TrimSpace(ctxRaw.String) != "" {
			ev.Context = json.RawMessage(ctxRaw.String)
		}
		if corr.Valid {
			ev.CorrelationID = corr.String
		}
		out = append(out, ev)
	}
	return out, total, rows.Err()
}

func (s *DiagnosticService) ExportBundle(ctx context.Context, q DiagnosticEventQuery) ([]byte, string, error) {
	return s.exportBundleWithCapture(ctx, q, nil)
}

func (s *DiagnosticService) exportBundleWithCapture(
	ctx context.Context,
	q DiagnosticEventQuery,
	capture *models.DiagnosticCaptureResult,
) ([]byte, string, error) {
	events, _, err := s.ListEvents(ctx, DiagnosticEventQuery{
		Source:   q.Source,
		Module:   q.Module,
		Level:    q.Level,
		DeviceID: q.DeviceID,
		From:     q.From,
		To:       q.To,
		Page:     1,
		PageSize: 5000,
	})
	if err != nil {
		return nil, "", err
	}

	cfg, _ := s.GetConfig(ctx)
	runtime := s.GetRuntimeConfig()
	snapshot, _ := s.BuildSnapshot(ctx)

	buf := &bytes.Buffer{}
	zw := zip.NewWriter(buf)

	manifest := map[string]interface{}{
		"exportedAt": models.UTCNow(),
		"filters":    q,
		"eventCount": len(events),
		"env":        os.Getenv("ENV"),
	}
	if capture != nil {
		manifest["captureId"] = capture.CaptureID
	}
	writeZipJSON(zw, "manifest.json", manifest)
	writeZipJSON(zw, "diagnostic_config.json", cfg)
	writeZipJSON(zw, "diagnostic_runtime.json", runtime)
	if snapshot != nil {
		writeZipJSON(zw, "snapshot.json", snapshot)
	}
	if capture != nil {
		writeZipJSON(zw, "capture.json", capture)
		if capture.Analysis != nil {
			writeZipJSON(zw, "analysis.json", capture.Analysis)
		}
		for i, pipe := range capture.Pipelines {
			writeZipJSON(zw, fmt.Sprintf("pipeline_%d_%s.json", i, pipe.DeviceID), pipe)
		}
		if len(capture.AgentSnaps) > 0 {
			writeZipJSON(zw, "agent_snapshots.json", capture.AgentSnaps)
		}
	}

	var eventLines bytes.Buffer
	for _, ev := range events {
		line, _ := json.Marshal(ev)
		eventLines.Write(line)
		eventLines.WriteByte('\n')
	}
	writeZipBytes(zw, "events.jsonl", eventLines.Bytes())

	if err := zw.Close(); err != nil {
		return nil, "", err
	}

	filename := fmt.Sprintf("diagnostic-bundle-%s.zip", time.Now().UTC().Format("20060102-150405"))
	return buf.Bytes(), filename, nil
}

func (s *DiagnosticService) runExpiryWatcher() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()
	for range ticker.C {
		s.checkAutoDisable()
		s.purgeExpiredEvents()
	}
}

func (s *DiagnosticService) checkAutoDisable() {
	s.mu.RLock()
	cfg := s.config
	s.mu.RUnlock()
	if !cfg.Enabled || cfg.ExpiresAt == nil {
		return
	}
	if cfg.ExpiresAt.After(time.Now().UTC()) {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	cfg.Enabled = false
	if cfg.AppliedTemplateID != "" {
		cfg = models.RestoreDefaultDiagnosticCenterConfig(cfg)
		if _, err := s.SaveConfig(ctx, cfg, "system:template-expire"); err != nil {
			log.Printf("[DiagnosticCenter] template restore failed: %v", err)
			return
		}
		log.Printf("[DiagnosticCenter] restored default config after template expiry")
		return
	}
	if _, err := s.SaveConfig(ctx, cfg, "system:auto-expire"); err != nil {
		log.Printf("[DiagnosticCenter] auto-disable failed: %v", err)
		return
	}
	log.Printf("[DiagnosticCenter] auto-disabled after expiry %s", cfg.ExpiresAt.Format(time.RFC3339))
}

func (s *DiagnosticService) purgeExpiredEvents() {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if _, err := s.db.ExecContext(ctx, `DELETE FROM diagnostic_events WHERE expires_at < NOW()`); err != nil {
		log.Printf("[DiagnosticCenter] purge expired events failed: %v", err)
	}
}

func writeZipJSON(zw *zip.Writer, name string, v interface{}) {
	body, _ := json.MarshalIndent(v, "", "  ")
	writeZipBytes(zw, name, body)
}

func writeZipBytes(zw *zip.Writer, name string, body []byte) {
	w, err := zw.Create(name)
	if err != nil {
		return
	}
	_, _ = w.Write(body)
}

func diagNullJSON(raw []byte) interface{} {
	if len(raw) == 0 {
		return nil
	}
	return string(raw)
}

func diagNullString(v string) interface{} {
	if strings.TrimSpace(v) == "" {
		return nil
	}
	return v
}

func nullableUUIDString(id *uuid.UUID) string {
	if id == nil {
		return ""
	}
	return id.String()
}

package services

import (
	"os"
	"strconv"
	"strings"
	"time"
)

func envInt(key string, defaultVal int) int {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return defaultVal
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return defaultVal
	}
	return n
}

// WSTicketTTL returns WS ticket lifetime (5–30s).
func WSTicketTTL() time.Duration {
	seconds := envInt("WS_TICKET_TTL_SECONDS", 15)
	if seconds < 5 {
		seconds = 5
	}
	if seconds > 30 {
		seconds = 30
	}
	return time.Duration(seconds) * time.Second
}

// SessionMaintenanceInterval returns background session expiry sweep interval.
func SessionMaintenanceInterval() time.Duration {
	minutes := envInt("SESSION_MAINTENANCE_INTERVAL_MINUTES", 60)
	if minutes < 5 {
		minutes = 5
	}
	return time.Duration(minutes) * time.Minute
}

// IsProductionEnv returns true when ENV is production or prod.
func IsProductionEnv() bool {
	env := strings.ToLower(strings.TrimSpace(os.Getenv("ENV")))
	return env == "production" || env == "prod"
}

// WSTicketRequired when true, WebSocket handshakes must use ticket (no JWT fallback).
// Defaults to true when ENV=production|prod.
func WSTicketRequired() bool {
	v := strings.TrimSpace(os.Getenv("WS_TICKET_REQUIRED"))
	if v != "" {
		return v == "true" || v == "1"
	}
	return IsProductionEnv()
}

// WSSessionGuardInterval returns how often WS connections revalidate session state.
func WSSessionGuardInterval() time.Duration {
	seconds := envInt("WS_SESSION_GUARD_INTERVAL_SECONDS", 10)
	if seconds < 3 {
		seconds = 3
	}
	if seconds > 120 {
		seconds = 120
	}
	return time.Duration(seconds) * time.Second
}

// WSMaxConnections returns process-wide WebSocket connection cap (0 = unlimited).
func WSMaxConnections() int {
	return envInt("WS_MAX_CONNECTIONS", 2000)
}

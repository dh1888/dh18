package services

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"
)

func deriveAppSecretKey() []byte {
	raw := strings.TrimSpace(os.Getenv("TELEGRAM_TOKEN_SECRET"))
	if raw == "" {
		raw = strings.TrimSpace(os.Getenv("JWT_SECRET"))
	}
	if raw == "" {
		raw = strings.TrimSpace(os.Getenv("DM_SECRET_KEY"))
	}
	if raw == "" {
		return nil
	}
	if b, err := base64.StdEncoding.DecodeString(raw); err == nil && len(b) >= 32 {
		return b[:32]
	}
	sum := sha256.Sum256([]byte(raw))
	return sum[:]
}

func EncryptSecret(plain string) (string, error) {
	key := deriveAppSecretKey()
	if len(key) != 32 {
		return "", errors.New("secret key not configured (set JWT_SECRET or TELEGRAM_TOKEN_SECRET)")
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	ciphertext := gcm.Seal(nonce, nonce, []byte(plain), nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func DecryptSecret(enc string) (string, error) {
	key := deriveAppSecretKey()
	if len(key) != 32 {
		return "", errors.New("secret key not configured")
	}
	data, err := base64.StdEncoding.DecodeString(enc)
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	if len(data) < gcm.NonceSize() {
		return "", fmt.Errorf("invalid ciphertext")
	}
	nonce, ciphertext := data[:gcm.NonceSize()], data[gcm.NonceSize():]
	plain, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}
	return string(plain), nil
}

func TelegramAttendanceEnabled() bool {
	v := strings.ToLower(strings.TrimSpace(os.Getenv("TELEGRAM_ATTENDANCE_ENABLED")))
	if v == "false" || v == "0" || v == "no" {
		return false
	}
	return true
}

// TelegramAgentCaptureEnabled is deprecated; use CaptureLinkedToCheckin with DB settings.
// Kept for callers that only check env without DB context.
func TelegramAgentCaptureEnabled() bool {
	if !TelegramAttendanceEnabled() {
		return false
	}
	v := strings.ToLower(strings.TrimSpace(os.Getenv("TELEGRAM_AGENT_CAPTURE_ENABLED")))
	return v == "true" || v == "1" || v == "yes"
}

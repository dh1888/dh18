package services

import (
	"encoding/json"
	"testing"
)

func TestLocalizedMainReplyKeyboardIncludesButtonStyles(t *testing.T) {
	kb := localizedMainReplyKeyboard(TgLangBoth, false, []string{"小厕", "大厕", "吃饭"})
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(raw, `"style":"success"`, `"style":"danger"`) {
		t.Fatalf("expected success and danger styles in keyboard JSON, got: %s", raw)
	}

	var wrapped struct {
		Code int `json:"code"`
		Data struct {
			ReplyKeyboard map[string]interface{} `json:"replyKeyboard"`
		} `json:"data"`
	}
	wrapped.Code = 0
	wrapped.Data.ReplyKeyboard = kb
	roundTrip, err := json.Marshal(wrapped)
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(roundTrip, &wrapped); err != nil {
		t.Fatal(err)
	}
	telegramPayload := map[string]interface{}{
		"chat_id":      123,
		"text":         "hello",
		"reply_markup": wrapped.Data.ReplyKeyboard,
	}
	final, err := json.Marshal(telegramPayload)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(final, `"style":"success"`, `"style":"danger"`) {
		t.Fatalf("styles lost after round-trip, got: %s", final)
	}
}

func TestLocalizedMainReplyKeyboardDualShiftStyles(t *testing.T) {
	kb := localizedMainReplyKeyboard(TgLangBoth, true, []string{"小厕"})
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(raw, `"style":"success"`, `"style":"primary"`, `"style":"danger"`) {
		t.Fatalf("expected success, primary and danger styles, got: %s", raw)
	}
}

func TestLocalizedMainReplyKeyboardBackButtonStyle(t *testing.T) {
	kb := localizedMainReplyKeyboard(TgLangBoth, false, []string{"小厕", "大厕", "抽烟或休息", "吃饭"})
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	successCount := countSubstring(string(raw), `"style":"success"`)
	if successCount < 2 {
		t.Fatalf("expected at least 2 success styles (checkin + back), got %d in: %s", successCount, raw)
	}
}

func TestEnrichReplyKeyboardStylesAfterRoundTrip(t *testing.T) {
	kb := localizedMainReplyKeyboard(TgLangBoth, false, []string{"小厕", "大厕", "吃饭"})
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	var roundTrip map[string]interface{}
	if err := json.Unmarshal(raw, &roundTrip); err != nil {
		t.Fatal(err)
	}
	if rows, ok := roundTrip["keyboard"].([]interface{}); ok && len(rows) > 0 {
		if firstRow, ok := rows[0].([]interface{}); ok && len(firstRow) > 0 {
			if btn, ok := firstRow[0].(map[string]interface{}); ok {
				delete(btn, "style")
			}
		}
	}
	enriched := enrichReplyKeyboardStyles(roundTrip)
	final, err := json.Marshal(enriched)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(final, `"style":"success"`, `"style":"danger"`) {
		t.Fatalf("enrichReplyKeyboardStyles failed, got: %s", final)
	}
}

func jsonContainsAll(raw []byte, parts ...string) bool {
	s := string(raw)
	for _, part := range parts {
		if !contains(s, part) {
			return false
		}
	}
	return true
}

func countSubstring(s, sub string) int {
	n := 0
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			n++
			i += len(sub) - 1
		}
	}
	return n
}

func contains(s, sub string) bool {
	return len(s) >= len(sub) && (s == sub || len(sub) == 0 || indexOf(s, sub) >= 0)
}

func indexOf(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}

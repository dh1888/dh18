package services

import (
	"context"
	"database/sql"
	"fmt"
	"net"
	"os"
	"strings"
	"sync"
	"time"
)

const (
	systemSettingCorsOrigins            = "cors_allowed_origins"
	systemSettingLoginCaptcha           = "login_captcha_enabled"
	systemSettingLoginTotp              = "login_totp_enabled"
	systemSettingLoginIPWhitelistEnabled = "login_ip_whitelist_enabled"
	systemSettingLoginIPWhitelist       = "login_ip_whitelist"
)

// SystemSettingsService stores runtime system configuration (overrides env when set).
type SystemSettingsService struct {
	db *sql.DB

	mu            sync.RWMutex
	corsFromDB    []string
	corsDBLoaded  bool
	corsDBHasValue bool

	loginIPWhitelistEnabled bool
	loginIPWhitelistIPs     []string
	loginIPWhitelistLoaded  bool
}

func NewSystemSettingsService(db *sql.DB) *SystemSettingsService {
	svc := &SystemSettingsService{db: db}
	svc.reloadCorsOrigins(context.Background())
	svc.reloadLoginIPWhitelist(context.Background())
	return svc
}

func parseOriginList(raw string) []string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	parts := strings.Split(raw, ",")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		if o := strings.TrimSpace(part); o != "" {
			out = append(out, o)
		}
	}
	return out
}

func joinOriginList(origins []string) string {
	clean := make([]string, 0, len(origins))
	for _, origin := range origins {
		if o := strings.TrimSpace(origin); o != "" {
			clean = append(clean, o)
		}
	}
	return strings.Join(clean, ",")
}

func defaultDevOrigins() []string {
	return []string{
		"http://localhost:5173",
		"http://localhost:3000",
		"http://127.0.0.1:5173",
		"http://127.0.0.1:3000",
	}
}

func envOrigins() []string {
	return parseOriginList(os.Getenv("CORS_ALLOWED_ORIGINS"))
}

func (s *SystemSettingsService) reloadCorsOrigins(ctx context.Context) {
	origins, hasValue, err := s.loadCorsOriginsFromDB(ctx)
	s.mu.Lock()
	defer s.mu.Unlock()
	s.corsDBLoaded = err == nil
	s.corsDBHasValue = hasValue
	if hasValue {
		s.corsFromDB = origins
	} else {
		s.corsFromDB = nil
	}
}

func (s *SystemSettingsService) loadCorsOriginsFromDB(ctx context.Context) ([]string, bool, error) {
	var value sql.NullString
	err := s.db.QueryRowContext(ctx,
		`SELECT value FROM system_settings WHERE key = $1`, systemSettingCorsOrigins).Scan(&value)
	if err == sql.ErrNoRows {
		return nil, false, nil
	}
	if err != nil {
		return nil, false, err
	}
	if !value.Valid || strings.TrimSpace(value.String) == "" {
		return nil, false, nil
	}
	return parseOriginList(value.String), true, nil
}

// GetEffectiveCorsOrigins returns origins used by CORS / WebSocket checks.
func (s *SystemSettingsService) GetEffectiveCorsOrigins() []string {
	s.mu.RLock()
	defer s.mu.RUnlock()

	if s.corsDBHasValue && len(s.corsFromDB) > 0 {
		return append([]string(nil), s.corsFromDB...)
	}

	if env := envOrigins(); len(env) > 0 {
		return env
	}

	if os.Getenv("ENV") != "production" {
		return defaultDevOrigins()
	}
	return nil
}

type CorsOriginsConfig struct {
	Origins          []string `json:"origins"`
	EffectiveOrigins []string `json:"effectiveOrigins"`
	Source           string   `json:"source"`
	UpdatedAt        string   `json:"updatedAt,omitempty"`
}

func (s *SystemSettingsService) GetCorsOriginsConfig(ctx context.Context) (*CorsOriginsConfig, error) {
	s.reloadCorsOrigins(ctx)

	s.mu.RLock()
	dbHas := s.corsDBHasValue
	dbOrigins := append([]string(nil), s.corsFromDB...)
	s.mu.RUnlock()

	cfg := &CorsOriginsConfig{
		EffectiveOrigins: s.GetEffectiveCorsOrigins(),
	}

	switch {
	case dbHas:
		cfg.Origins = dbOrigins
		cfg.Source = "database"
	case len(envOrigins()) > 0:
		cfg.Origins = envOrigins()
		cfg.Source = "environment"
	default:
		cfg.Origins = []string{}
		if os.Getenv("ENV") != "production" {
			cfg.Source = "default"
		} else {
			cfg.Source = "none"
		}
	}

	var updatedAt sql.NullTime
	_ = s.db.QueryRowContext(ctx,
		`SELECT updated_at FROM system_settings WHERE key = $1`, systemSettingCorsOrigins).Scan(&updatedAt)
	if updatedAt.Valid {
		cfg.UpdatedAt = updatedAt.Time.UTC().Format("2006-01-02T15:04:05Z")
	}
	return cfg, nil
}

func (s *SystemSettingsService) SaveCorsOrigins(ctx context.Context, origins []string) (*CorsOriginsConfig, error) {
	value := joinOriginList(origins)
	if value == "" {
		if _, err := s.db.ExecContext(ctx,
			`DELETE FROM system_settings WHERE key = $1`, systemSettingCorsOrigins); err != nil {
			return nil, err
		}
		s.reloadCorsOrigins(ctx)
		return s.GetCorsOriginsConfig(ctx)
	}

	_, err := s.db.ExecContext(ctx, `
		INSERT INTO system_settings (key, value, updated_at)
		VALUES ($1, $2, NOW())
		ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
		systemSettingCorsOrigins, value)
	if err != nil {
		return nil, err
	}
	s.reloadCorsOrigins(ctx)
	return s.GetCorsOriginsConfig(ctx)
}

// AuthSecurityConfig controls login captcha and Google Authenticator (TOTP).
type AuthSecurityConfig struct {
	LoginCaptchaEnabled bool   `json:"loginCaptchaEnabled"`
	LoginTotpEnabled    bool   `json:"loginTotpEnabled"`
	UpdatedAt           string `json:"updatedAt,omitempty"`
}

func parseBoolSetting(value sql.NullString, defaultVal bool) bool {
	if !value.Valid {
		return defaultVal
	}
	v := strings.TrimSpace(strings.ToLower(value.String))
	if v == "true" || v == "1" {
		return true
	}
	if v == "false" || v == "0" {
		return false
	}
	return defaultVal
}

func (s *SystemSettingsService) GetAuthSecurityConfig(ctx context.Context) (*AuthSecurityConfig, error) {
	cfg := &AuthSecurityConfig{
		LoginCaptchaEnabled: true,
		LoginTotpEnabled:    false,
	}
	if s.db == nil {
		return cfg, nil
	}
	var captchaVal, totpVal sql.NullString
	_ = s.db.QueryRowContext(ctx, `SELECT value FROM system_settings WHERE key = $1`, systemSettingLoginCaptcha).Scan(&captchaVal)
	_ = s.db.QueryRowContext(ctx, `SELECT value FROM system_settings WHERE key = $1`, systemSettingLoginTotp).Scan(&totpVal)
	cfg.LoginCaptchaEnabled = parseBoolSetting(captchaVal, true)
	cfg.LoginTotpEnabled = parseBoolSetting(totpVal, false)

	var updatedAt sql.NullTime
	_ = s.db.QueryRowContext(ctx, `
		SELECT MAX(updated_at) FROM system_settings
		WHERE key IN ($1, $2)`, systemSettingLoginCaptcha, systemSettingLoginTotp).Scan(&updatedAt)
	if updatedAt.Valid {
		cfg.UpdatedAt = updatedAt.Time.UTC().Format(time.RFC3339)
	}
	return cfg, nil
}

func (s *SystemSettingsService) SaveAuthSecurityConfig(ctx context.Context, captchaEnabled, totpEnabled bool) (*AuthSecurityConfig, error) {
	if s.db == nil {
		return nil, fmt.Errorf("settings store unavailable")
	}
	pairs := []struct {
		key   string
		value string
	}{
		{systemSettingLoginCaptcha, boolString(captchaEnabled)},
		{systemSettingLoginTotp, boolString(totpEnabled)},
	}
	for _, pair := range pairs {
		_, err := s.db.ExecContext(ctx, `
			INSERT INTO system_settings (key, value, updated_at)
			VALUES ($1, $2, NOW())
			ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
			pair.key, pair.value)
		if err != nil {
			return nil, err
		}
	}
	return s.GetAuthSecurityConfig(ctx)
}

func boolString(v bool) string {
	if v {
		return "true"
	}
	return "false"
}

// LoginIPWhitelistConfig controls admin login IP allowlist.
type LoginIPWhitelistConfig struct {
	Enabled   bool     `json:"enabled"`
	IPs       []string `json:"ips"`
	UpdatedAt string   `json:"updatedAt,omitempty"`
}

func parseIPList(raw string) []string {
	return parseOriginList(raw)
}

func joinIPList(ips []string) string {
	return joinOriginList(ips)
}

func (s *SystemSettingsService) reloadLoginIPWhitelist(ctx context.Context) {
	enabled, ips, loaded, err := s.loadLoginIPWhitelistFromDB(ctx)
	s.mu.Lock()
	defer s.mu.Unlock()
	s.loginIPWhitelistLoaded = err == nil && loaded
	if s.loginIPWhitelistLoaded {
		s.loginIPWhitelistEnabled = enabled
		s.loginIPWhitelistIPs = ips
	} else {
		s.loginIPWhitelistEnabled = false
		s.loginIPWhitelistIPs = nil
	}
}

func (s *SystemSettingsService) loadLoginIPWhitelistFromDB(ctx context.Context) (enabled bool, ips []string, loaded bool, err error) {
	if s.db == nil {
		return false, nil, false, nil
	}
	var enabledVal, ipsVal sql.NullString
	err = s.db.QueryRowContext(ctx, `
		SELECT
			(SELECT value FROM system_settings WHERE key = $1),
			(SELECT value FROM system_settings WHERE key = $2)`,
		systemSettingLoginIPWhitelistEnabled, systemSettingLoginIPWhitelist).Scan(&enabledVal, &ipsVal)
	if err != nil {
		return false, nil, false, err
	}
	loaded = true
	enabled = parseBoolSetting(enabledVal, false)
	if ipsVal.Valid {
		ips = parseIPList(ipsVal.String)
	}
	return enabled, ips, loaded, nil
}

func (s *SystemSettingsService) GetLoginIPWhitelistConfig(ctx context.Context) (*LoginIPWhitelistConfig, error) {
	s.reloadLoginIPWhitelist(ctx)
	s.mu.RLock()
	cfg := &LoginIPWhitelistConfig{
		Enabled: s.loginIPWhitelistEnabled,
		IPs:     append([]string(nil), s.loginIPWhitelistIPs...),
	}
	s.mu.RUnlock()

	var updatedAt sql.NullTime
	_ = s.db.QueryRowContext(ctx, `
		SELECT MAX(updated_at) FROM system_settings
		WHERE key IN ($1, $2)`, systemSettingLoginIPWhitelistEnabled, systemSettingLoginIPWhitelist).Scan(&updatedAt)
	if updatedAt.Valid {
		cfg.UpdatedAt = updatedAt.Time.UTC().Format(time.RFC3339)
	}
	return cfg, nil
}

func (s *SystemSettingsService) SaveLoginIPWhitelistConfig(ctx context.Context, enabled bool, ips []string) (*LoginIPWhitelistConfig, error) {
	if s.db == nil {
		return nil, fmt.Errorf("settings store unavailable")
	}
	pairs := []struct {
		key   string
		value string
	}{
		{systemSettingLoginIPWhitelistEnabled, boolString(enabled)},
		{systemSettingLoginIPWhitelist, joinIPList(ips)},
	}
	for _, pair := range pairs {
		_, err := s.db.ExecContext(ctx, `
			INSERT INTO system_settings (key, value, updated_at)
			VALUES ($1, $2, NOW())
			ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
			pair.key, pair.value)
		if err != nil {
			return nil, err
		}
	}
	s.reloadLoginIPWhitelist(ctx)
	return s.GetLoginIPWhitelistConfig(ctx)
}

// IsLoginIPAllowed returns true when IP whitelist is disabled/empty or client IP matches.
func (s *SystemSettingsService) IsLoginIPAllowed(ctx context.Context, clientIP string) (bool, error) {
	s.reloadLoginIPWhitelist(ctx)
	s.mu.RLock()
	enabled := s.loginIPWhitelistEnabled
	ips := append([]string(nil), s.loginIPWhitelistIPs...)
	s.mu.RUnlock()

	if !enabled || len(ips) == 0 {
		return true, nil
	}
	return IPMatchesAllowlist(clientIP, ips), nil
}

// IPMatchesAllowlist checks whether clientIP matches any single IP or CIDR entry.
func IPMatchesAllowlist(clientIP string, allowlist []string) bool {
	ip := parseClientIP(clientIP)
	if ip == nil {
		return false
	}
	for _, entry := range allowlist {
		if ipMatchesEntry(ip, entry) {
			return true
		}
	}
	return false
}

func parseClientIP(raw string) net.IP {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	if host, _, err := net.SplitHostPort(raw); err == nil {
		raw = host
	}
	raw = strings.Trim(raw, "[]")
	return net.ParseIP(raw)
}

func ipMatchesEntry(ip net.IP, entry string) bool {
	entry = strings.TrimSpace(entry)
	if entry == "" {
		return false
	}
	if strings.Contains(entry, "/") {
		_, network, err := net.ParseCIDR(entry)
		return err == nil && network.Contains(ip)
	}
	if host, _, err := net.SplitHostPort(entry); err == nil {
		entry = host
	}
	allowed := net.ParseIP(strings.Trim(entry, "[]"))
	return allowed != nil && allowed.Equal(ip)
}

// ValidateIPAllowlistEntry returns an error when entry is not a valid IP or CIDR.
func ValidateIPAllowlistEntry(entry string) error {
	entry = strings.TrimSpace(entry)
	if entry == "" {
		return fmt.Errorf("empty IP entry")
	}
	if strings.Contains(entry, "/") {
		if _, _, err := net.ParseCIDR(entry); err != nil {
			return fmt.Errorf("invalid CIDR: %s", entry)
		}
		return nil
	}
	if host, _, err := net.SplitHostPort(entry); err == nil {
		entry = host
	}
	if net.ParseIP(strings.Trim(entry, "[]")) == nil {
		return fmt.Errorf("invalid IP: %s", entry)
	}
	return nil
}

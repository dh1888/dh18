package services

import "testing"

func TestNormalizeSessionClientIP(t *testing.T) {
	tests := []struct {
		in   string
		want bool
	}{
		{"127.0.0.1", true},
		{"127.0.0.1:5173", true},
		{"::1", true},
		{"[::1]:8080", true},
		{"", false},
		{"unknown", false},
	}
	for _, tc := range tests {
		got := normalizeSessionClientIP(tc.in)
		if tc.want && got == nil {
			t.Fatalf("expected IP for %q", tc.in)
		}
		if !tc.want && got != nil {
			t.Fatalf("expected nil for %q, got %v", tc.in, got)
		}
	}
}

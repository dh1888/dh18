package services

import (
	"context"
	"fmt"
	"strings"
	"time"

	"enterprise-agent/backend/models"
)

var pipelineNodeModules = map[string][]string{
	"agent":     {"WebSocket", "Health"},
	"capture":   {"Capture", "Lifecycle"},
	"ffmpeg":    {"FFmpeg", "RemoteView"},
	"whip":      {"RemoteView", "FFmpeg"},
	"ingress":   {"Backend", "RemoteView"},
	"livekit":   {"LiveKit", "Backend"},
	"frontend":  {"RemoteView", "LiveKit"},
}

func (s *DiagnosticService) attachPipelineNodeLogs(ctx context.Context, deviceID string, nodes []models.DiagnosticPipelineNode) []models.DiagnosticPipelineNode {
	since := models.UTCNow().Add(-30 * time.Minute)
	for i := range nodes {
		modules := pipelineNodeModules[nodes[i].ID]
		if len(modules) == 0 {
			continue
		}
		logs, errors := s.fetchNodeEvents(ctx, deviceID, modules, since, 8)
		nodes[i].RecentLogs = logs
		nodes[i].RecentErrors = errors
	}
	return nodes
}

func (s *DiagnosticService) fetchNodeEvents(
	ctx context.Context,
	deviceID string,
	modules []string,
	since time.Time,
	limit int,
) ([]models.DiagnosticEventBrief, []models.DiagnosticEventBrief) {
	if len(modules) == 0 {
		return nil, nil
	}
	placeholders := make([]string, len(modules))
	args := []interface{}{since}
	for i, m := range modules {
		placeholders[i] = fmt.Sprintf("$%d", i+2)
		args = append(args, m)
	}
	deviceClause := ""
	if deviceID != "" {
		deviceClause = fmt.Sprintf(" AND device_id = $%d", len(args)+1)
		args = append(args, deviceID)
	}
	query := fmt.Sprintf(`
		SELECT created_at, level, module, message
		FROM diagnostic_events
		WHERE created_at >= $1 AND module IN (%s)%s
		ORDER BY created_at DESC
		LIMIT %d
	`, strings.Join(placeholders, ","), deviceClause, limit)

	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, nil
	}
	defer rows.Close()

	logs := []models.DiagnosticEventBrief{}
	errors := []models.DiagnosticEventBrief{}
	for rows.Next() {
		var createdAt time.Time
		var level, module, message string
		if err := rows.Scan(&createdAt, &level, &module, &message); err != nil {
			continue
		}
		item := models.DiagnosticEventBrief{
			CreatedAt: models.FormatUTC(createdAt),
			Level:     level,
			Module:    module,
			Message:   message,
		}
		logs = append(logs, item)
		if level == "ERROR" || level == "WARN" {
			errors = append(errors, item)
		}
	}
	return logs, errors
}

func (s *DiagnosticService) GetPipelineNodeDetail(ctx context.Context, deviceID, nodeID string) (*models.DiagnosticPipelineNode, error) {
	pipe, err := s.BuildPipeline(ctx, deviceID)
	if err != nil {
		return nil, err
	}
	for _, node := range pipe.Nodes {
		if node.ID == nodeID {
			copy := node
			return &copy, nil
		}
	}
	return nil, fmt.Errorf("node not found: %s", nodeID)
}

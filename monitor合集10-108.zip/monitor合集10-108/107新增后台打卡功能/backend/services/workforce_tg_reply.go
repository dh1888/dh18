package services

import (
	"fmt"
	"html"
	"strings"
	"time"
)

func formatTelegramUserLink(telegramUserID int64, displayName string) string {
	name := strings.TrimSpace(displayName)
	if name == "" {
		name = fmt.Sprintf("用户%d", telegramUserID)
	}
	return fmt.Sprintf(`<a href="tg://user?id=%d">%s</a>`, telegramUserID, html.EscapeString(name))
}

func resolveWorkStartExpectedTime(now time.Time, recordDate, shift, shiftDetail, startClock string, loc *time.Location) time.Time {
	rd, err := time.ParseInLocation("2006-01-02", recordDate, loc)
	if err != nil {
		rd = now.In(loc)
	}
	_ = shift
	_ = shiftDetail
	// 夜班业务日 = 开班日（含跨午夜）；统一用 recordDate + 上班时刻。
	return combineDateTime(rd, startClock, loc)
}

func resolveWorkEndExpectedTime(now time.Time, recordDate, shift, endClock string, loc *time.Location) time.Time {
	rd, err := time.ParseInLocation("2006-01-02", recordDate, loc)
	if err != nil {
		rd = now.In(loc)
	}
	if shift == "night" {
		eh, em, ok := parseClock(endClock)
		// 跨午夜夜班：下班钟点在上午（如 09:00）→ 落在业务日次日
		if ok && clockToMinutes(eh, em) <= 12*60 {
			rd = rd.AddDate(0, 0, 1)
		}
	}
	return combineDateTime(rd, endClock, loc)
}

func buildWorkStartGroupReplyHTML(
	telegramUserID int64,
	employeeName, shift, shiftDetail string,
	now, expected time.Time,
	lateMin int,
	workFine float64,
	handoverHint string,
) string {
	// 群组「上班完成」只显示白班/夜班，不附带（昨晚夜班）/（今晚夜班）后缀。
	shiftText := shiftLabel(shift)
	actionText := "上班"
	emoji := "👍"
	status := "✅ 准时"

	diffSec := int(now.Sub(expected).Seconds())
	if lateMin > 0 {
		emoji = "😅"
		status = fmt.Sprintf("🚨 迟到 %s", formatDurationZh(lateMin*60))
		if workFine > 0 {
			status += fmt.Sprintf("\n💰罚款金额: %.0f 元", workFine)
		}
	} else if diffSec < 0 {
		status = fmt.Sprintf("✅ 早到 %s", formatDurationZh(-diffSec))
	}

	msg := fmt.Sprintf(
		"%s <b>%s%s完成</b>\n"+
			"👤 用户：%s\n"+
			"⏰ 打卡时间：<code>%s</code>\n"+
			"📅 %s时间：<code>%s</code>\n"+
			"📊 状态：%s",
		emoji, shiftText, actionText,
		formatTelegramUserLink(telegramUserID, employeeName),
		now.Format("15:04"),
		actionText, expected.Format("01/02 15:04"),
		status,
	)
	if hint := strings.TrimSpace(handoverHint); hint != "" {
		msg += "\n\n" + hint
	}
	return msg
}

func buildWorkEndGroupReplyHTML(
	telegramUserID int64,
	employeeName, shift string,
	now, expected time.Time,
	earlyMin int,
	workFine float64,
	handoverHint, activityWarn string,
) string {
	shiftText := shiftLabel(shift)
	actionText := "下班"
	emoji := "👍"
	status := "✅ 准时"

	diffSec := int(now.Sub(expected).Seconds())
	if earlyMin > 0 {
		emoji = "🏃"
		sec := earlyMin * 60
		if diffSec < 0 {
			sec = -diffSec
		}
		status = fmt.Sprintf("🚨 早退 %s", formatDurationZh(sec))
		if workFine > 0 {
			status += fmt.Sprintf("\n💰罚款金额: %.0f 元", workFine)
		}
	} else if diffSec > 60 {
		emoji = "⏰"
		status = fmt.Sprintf("✅ 加班 %s", formatDurationZh(diffSec))
	}

	msg := fmt.Sprintf(
		"%s <b>%s%s完成</b>\n"+
			"👤 用户：%s\n"+
			"⏰ 打卡时间：<code>%s</code>\n"+
			"📅 %s时间：<code>%s</code>\n"+
			"📊 状态：%s",
		emoji, shiftText, actionText,
		formatTelegramUserLink(telegramUserID, employeeName),
		now.Format("15:04"),
		actionText, expected.Format("01/02 15:04"),
		status,
	)
	if hint := strings.TrimSpace(handoverHint); hint != "" {
		msg += "\n\n" + hint
	}
	if warn := strings.TrimSpace(activityWarn); warn != "" {
		msg += "\n\n🔄 " + html.EscapeString(warn)
	}
	return msg
}

func tgReplyDashedLine() string {
	return "────────────────"
}

func buildActivityStartGroupReplyHTML(
	telegramUserID int64,
	employeeName, activity, timeStr, shiftText string,
	count, maxTimes, timeLimitMin int,
) string {
	maxStr := "不限"
	if maxTimes > 0 {
		maxStr = fmt.Sprintf("%d", maxTimes)
	}
	actEsc := html.EscapeString(activity)
	msg := fmt.Sprintf(
		"👤 用户：%s\n"+
			"✅ 打卡成功：<code>%s</code> - <code>%s</code>\n",
		formatTelegramUserLink(telegramUserID, employeeName),
		actEsc, html.EscapeString(timeStr),
	)
	if shiftText != "" {
		msg += fmt.Sprintf("📊 班次：<code>%s</code>\n", html.EscapeString(shiftText))
	}
	msg += fmt.Sprintf(
		"▫️ 本次活动类型：<code>%s</code>\n"+
			"⏰ 单次时长限制：<code>%d</code>分钟 \n"+
			"📈 今日<code>%s</code>次数：第 <code>%d</code> 次（上限 <code>%s</code> 次）\n",
		actEsc, timeLimitMin, actEsc, count, html.EscapeString(maxStr),
	)
	if maxTimes > 0 && count >= maxTimes {
		msg += fmt.Sprintf("🚨 警告：本次结束后，您今日的<code>%s</code>次数将达到上限，请留意！\n", actEsc)
	}
	msg += fmt.Sprintf(
		"%s\n"+
			"💡 操作提示\n"+
			"活动结束后请点击下方「回座」按钮，或使用 /at。",
		tgReplyDashedLine(),
	)
	return msg
}

func buildActivityEndGroupReplyHTML(
	telegramUserID int64,
	employeeName, activity, timeStr string,
	elapsedSec, todayActivityCount, totalActivitySec, totalDailySec, totalDailyCount int,
	activityCounts map[string]int,
	isOvertime bool,
	overtimeSec int,
	fine float64,
) string {
	actEsc := html.EscapeString(activity)
	msg := fmt.Sprintf(
		"👤 用户：%s\n"+
			"✅ 回座打卡：<code>%s</code>\n"+
			"%s\n"+
			"📍 活动记录\n"+
			"▫️ 活动类型：<code>%s</code>\n"+
			"▫️ 本次耗时：<code>%s</code> ⏰\n"+
			"▫️ 累计时长：<code>%s</code>\n"+
			"▫️ 今日次数：<code>%d</code>次\n",
		formatTelegramUserLink(telegramUserID, employeeName),
		html.EscapeString(timeStr),
		tgReplyDashedLine(),
		actEsc,
		formatDurationZh(elapsedSec),
		formatDurationZh(totalActivitySec),
		todayActivityCount,
	)
	if isOvertime && overtimeSec > 0 {
		msg += "\n⚠️ 超时提醒\n"
		msg += fmt.Sprintf("▫️ 超时时长：<code>%s</code> 🚨\n", formatDurationZh(overtimeSec))
		if fine > 0 {
			msg += fmt.Sprintf("▫️ 罚款金额：<code>%.0f</code> 元 💸\n", fine)
		}
	}
	msg += tgReplyDashedLine() + "\n"
	msg += "📊 今日总计\n▫️ 活动详情\n"
	for name, count := range activityCounts {
		if count <= 0 {
			continue
		}
		msg += fmt.Sprintf("   ➤ <code>%s</code>：<code>%d</code> 次 📝\n", html.EscapeString(name), count)
	}
	msg += fmt.Sprintf("▫️ 总活动次数：<code>%d</code>次\n", totalDailyCount)
	msg += fmt.Sprintf("▫️ 总活动时长：<code>%s</code>", formatDurationZh(totalDailySec))
	return msg
}

func buildActivitySoonTimeoutHTML(telegramUserID int64, employeeName, activity, shiftText string) string {
	return fmt.Sprintf(
		"⏳ <b>即将超时警告</b>\n"+
			"👤 %s\n"+
			"📊 班次：<code>%s</code>\n"+
			"🕓 本次 <code>%s</code> 还有 <code>1</code> 分钟！\n"+
			"💡 请及时回座，避免超时罚款",
		formatTelegramUserLink(telegramUserID, employeeName),
		html.EscapeString(shiftText),
		html.EscapeString(activity),
	)
}

func buildActivityOvertimeWarnHTML(telegramUserID int64, employeeName, activity, shiftText string, overtimeMin, variant int) string {
	actEsc := html.EscapeString(activity)
	shiftEsc := html.EscapeString(shiftText)
	user := formatTelegramUserLink(telegramUserID, employeeName)
	switch variant {
	case 0:
		return fmt.Sprintf(
			"⚠️ <b>超时警告</b>\n👤 %s\n📊 班次：<code>%s</code>\n🕓 本次 <code>%s</code> 已超时\n🏃‍♂️ 请立即回座，避免产生更多罚款！",
			user, shiftEsc, actEsc)
	case 5:
		return fmt.Sprintf(
			"🔔 <b>超时警告</b>\n👤 %s\n📊 班次：<code>%s</code>\n🕓 本次 <code>%s</code> 已超时 <code>%d</code> 分钟！\n😤 罚款正在累积，请立即回座！",
			user, shiftEsc, actEsc, overtimeMin)
	default:
		return fmt.Sprintf(
			"🚨 <b>超时警告</b>\n👤 %s\n📊 班次：<code>%s</code>\n🕓 本次 <code>%s</code> 已超时 <code>%d</code> 分钟！\n💢 请立刻回座，避免产生更多罚款！",
			user, shiftEsc, actEsc, overtimeMin)
	}
}

func buildActivitySoonTimeoutPushHTML(chatTitle, employeeName, activity string) string {
	title := html.EscapeString(strings.TrimSpace(chatTitle))
	if title == "" {
		title = "打卡群"
	}
	return fmt.Sprintf(
		"⏳ <b>即将超时提醒</b>\n🏢 群组：<code>%s</code>\n%s\n👤 %s\n📝 活动：<code>%s</code>\n💡 剩余约 1 分钟",
		title, tgReplyDashedLine(), html.EscapeString(employeeName), html.EscapeString(activity),
	)
}

func buildActivityOvertimeBackPushHTML(chatTitle string, telegramUserID int64, employeeName, activity string, backAt time.Time, overtimeSec int, fine float64) string {
	title := html.EscapeString(strings.TrimSpace(chatTitle))
	if title == "" {
		title = "打卡群"
	}
	msg := fmt.Sprintf(
		"🚨 <b>超时回座通知</b>\n🏢 群组：<code>%s</code>\n%s\n"+
			"👤 用户：%s\n📝 活动：<code>%s</code>\n⏰ 回座时间：<code>%s</code>\n⏱️ 超时时长：<code>%s</code>\n",
		title, tgReplyDashedLine(),
		formatTelegramUserLink(telegramUserID, employeeName),
		html.EscapeString(activity),
		backAt.Format("01/02 15:04:05"),
		formatDurationZh(overtimeSec),
	)
	if fine > 0 {
		msg += fmt.Sprintf("💰 罚款金额：<code>%.0f</code> 元", fine)
	}
	return msg
}

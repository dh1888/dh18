package services

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"enterprise-agent/backend/internal/tgbot"
)

func envTelegramBotEmbedded() bool {
	v := strings.ToLower(strings.TrimSpace(os.Getenv("TELEGRAM_BOT_EMBEDDED")))
	if v == "false" || v == "0" || v == "no" {
		return false
	}
	return true
}

// TelegramBotEmbedded reports whether the bot runs inside the backend process.
func TelegramBotEmbedded() bool {
	return envTelegramBotEmbedded()
}

// StartTelegramBotRunner runs the Telegram bot inside the backend process (default).
func StartTelegramBotRunner(parentCtx context.Context, svc *WorkforceTelegramService, listenPort string) {
	if !TelegramAttendanceEnabled() {
		return
	}
	if !envTelegramBotEmbedded() {
		log.Println("[TelegramBot] external worker mode (TELEGRAM_BOT_EMBEDDED=false)")
		return
	}
	log.Println("[TelegramBot] embedded in backend — no separate telegram-worker process needed")
	go touchWorkerHeartbeatLoop(parentCtx, svc)
	go func() {
		waitForHealth(listenPort, 30*time.Second)
		for {
			if parentCtx.Err() != nil {
				return
			}
			if err := runEmbeddedTelegramBotOnce(parentCtx, svc, listenPort); err != nil {
				if parentCtx.Err() != nil {
					return
				}
				log.Printf("[TelegramBot] runner error: %v (retry in 10s)", err)
				time.Sleep(10 * time.Second)
			}
		}
	}()
}

func waitForHealth(port string, timeout time.Duration) {
	deadline := time.Now().Add(timeout)
	url := fmt.Sprintf("http://127.0.0.1:%s/health", port)
	for time.Now().Before(deadline) {
		resp, err := http.Get(url)
		if err == nil {
			resp.Body.Close()
			return
		}
		time.Sleep(time.Second)
	}
}

func isUsableWebhookURL(raw string) bool {
	u := strings.ToLower(strings.TrimSpace(raw))
	if u == "" {
		return false
	}
	if strings.Contains(u, "localhost") || strings.Contains(u, "127.0.0.1") {
		return false
	}
	return strings.HasPrefix(u, "https://")
}

func resolveTelegramBotTransport(settings *TelegramSettings) (botMode, webhookURL string) {
	botMode = strings.TrimSpace(settings.BotMode)
	webhookURL = strings.TrimSpace(settings.WebhookURL)
	if strings.ToLower(botMode) != "webhook" {
		return botMode, webhookURL
	}
	if isUsableWebhookURL(webhookURL) {
		return botMode, webhookURL
	}
	log.Printf("[TelegramBot] webhook URL %q is not publicly reachable — falling back to polling", webhookURL)
	return "polling", ""
}

func runEmbeddedTelegramBotOnce(ctx context.Context, svc *WorkforceTelegramService, listenPort string) error {
	active, err := svc.IsActive(ctx)
	if err != nil || !active {
		time.Sleep(30 * time.Second)
		return nil
	}
	secret, err := svc.EnsureWorkerSecret(ctx)
	if err != nil {
		return err
	}
	settings, err := svc.GetSettings(ctx)
	if err != nil {
		return err
	}
	token, err := svc.GetBotTokenForWorker(ctx)
	if err != nil {
		time.Sleep(30 * time.Second)
		return nil
	}
	webhookSecret, _ := svc.GetWebhookSecret(ctx)
	botMode, webhookURL := resolveTelegramBotTransport(settings)
	opts := tgbot.Options{
		BackendURL:    fmt.Sprintf("http://127.0.0.1:%s/api/v1", listenPort),
		WorkerSecret:  secret,
		BotToken:      token,
		BotMode:       botMode,
		WebhookURL:    webhookURL,
		WebhookSecret: webhookSecret,
		Embedded:      true,
	}
	return tgbot.Run(ctx, opts)
}

func touchWorkerHeartbeatLoop(ctx context.Context, svc *WorkforceTelegramService) {
	ticker := time.NewTicker(60 * time.Second)
	defer ticker.Stop()
	_ = svc.TouchWorkerHeartbeat(ctx)
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			_ = svc.TouchWorkerHeartbeat(ctx)
		}
	}
}

// BuildTelegramBotOptions builds runtime options from current DB settings.
func (s *WorkforceTelegramService) BuildTelegramBotOptions(listenPort string) (tgbot.Options, error) {
	secret, err := s.EnsureWorkerSecret(context.Background())
	if err != nil {
		return tgbot.Options{}, err
	}
	settings, err := s.GetSettings(context.Background())
	if err != nil {
		return tgbot.Options{}, err
	}
	token, err := s.GetBotTokenForWorker(context.Background())
	if err != nil {
		return tgbot.Options{}, err
	}
	webhookSecret, _ := s.GetWebhookSecret(context.Background())
	return tgbot.Options{
		BackendURL:    fmt.Sprintf("http://127.0.0.1:%s/api/v1", listenPort),
		WorkerSecret:  secret,
		BotToken:      token,
		BotMode:       settings.BotMode,
		WebhookURL:    settings.WebhookURL,
		WebhookSecret: webhookSecret,
		Embedded:      true,
	}, nil
}

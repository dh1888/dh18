package logx

import (
	"log"
	"os"
	"strings"
	"sync"
	"time"
)

var (
	debugOnce    sync.Once
	debugEnabled bool
)

// DebugEnabled is true when LOG_LEVEL=debug, or ENV is not production.
func DebugEnabled() bool {
	debugOnce.Do(func() {
		level := strings.ToLower(strings.TrimSpace(os.Getenv("LOG_LEVEL")))
		if level == "debug" {
			debugEnabled = true
			return
		}
		env := strings.ToLower(strings.TrimSpace(os.Getenv("ENV")))
		debugEnabled = env != "production"
	})
	return debugEnabled
}

// Debug writes a debug line when DebugEnabled() is true.
func Debug(format string, v ...any) {
	if DebugEnabled() {
		log.Printf("[DEBUG] "+format, v...)
	}
}

// quietSuccessPaths — production 下 2xx 成功时不打 access log，避免刷屏。
var quietSuccessPaths = []string{
	"/api/v1/upload/chunk",
	"/api/v1/upload/complete",
	"/api/v1/activities/report",
}

// ShouldLogHTTPAccess decides whether the HTTP access middleware should log a request.
// Errors, slow requests, and debug mode always log.
func ShouldLogHTTPAccess(status int, path string, duration time.Duration) bool {
	if status >= 400 || duration > 2*time.Second {
		return true
	}
	if DebugEnabled() {
		return true
	}
	for _, prefix := range quietSuccessPaths {
		if path == prefix {
			return false
		}
	}
	return true
}

package services

import (
	"strings"
	"testing"

	"github.com/google/uuid"
)

func TestTgGroupEmployeeBelongsToChatSQLIncludesSharedWorkstation(t *testing.T) {
	sql := tgGroupEmployeeBelongsToChatSQL("ws.employee_id", "$1")
	if !strings.Contains(sql, "wf_shared_workstation_members") {
		t.Fatal("group employee match must include shared workstation")
	}
	if !strings.Contains(sql, "device_telegram_bindings") {
		t.Fatal("group employee match must include device telegram bindings")
	}
}

func TestTgExportChatFilterIncludesPCSessionChat(t *testing.T) {
	filter, arg := tgExportChatFilter("-100123")
	if arg != "-100123" {
		t.Fatalf("chat arg = %q", arg)
	}
	if !strings.Contains(filter, "source_chat_id") {
		t.Fatal("export chat filter must match session source_chat_id")
	}
	if !strings.Contains(filter, "wf_shared_workstation_members") {
		t.Fatal("export chat filter must include shared workstation")
	}
	if !strings.Contains(filter, "wf_tg_activity_sessions_archive") {
		t.Fatal("export chat filter must also match activity archive for empty binding chat")
	}
}

func TestTgExportAttendanceChatFilter(t *testing.T) {
	if got := tgExportAttendanceChatFilter(""); got != "" {
		t.Fatalf("empty chat filter = %q", got)
	}
	got := tgExportAttendanceChatFilter("-1001")
	if !strings.Contains(got, "ar.employee_id") {
		t.Fatal("attendance chat filter must scope ar.employee_id")
	}
	if !strings.Contains(got, "$3") {
		t.Fatal("attendance chat filter must use $3 chat placeholder")
	}
}

func TestExportStatKeySeparatesSharedTelegramEmployees(t *testing.T) {
	tgUID := int64(987654321)
	empA := uuid.MustParse("11111111-1111-1111-1111-111111111111")
	empB := uuid.MustParse("22222222-2222-2222-2222-222222222222")

	keyA := exportStatKey(empA, tgUID, "day")
	keyB := exportStatKey(empB, tgUID, "day")
	if keyA == keyB {
		t.Fatalf("shared TG employees must not share export stat key: %q", keyA)
	}
	if exportUserKey(empA, tgUID) != exportUserKey(empA, 0) {
		t.Fatal("export user key should not depend on telegram user id")
	}
}

func TestTelegramExportUsePunchTimes(t *testing.T) {
	if !telegramExportUsePunchTimes("2026-07-25", "2026-07-25") {
		t.Fatal("single day export should use punch times")
	}
	if telegramExportUsePunchTimes("2026-07-01", "2026-07-31") {
		t.Fatal("month span export should use aggregate counts")
	}
}

func TestExportDisplayUserIDStillUsesTelegramWhenPresent(t *testing.T) {
	tgUID := int64(12345)
	empID := uuid.New()
	if got := exportDisplayUserID(tgUID, empID); got != tgUID {
		t.Fatalf("display user id = %d, want %d", got, tgUID)
	}
}

package services

import (
	"context"
	"time"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

func (s *DiagnosticService) BuildSnapshot(ctx context.Context) (*models.DiagnosticSnapshot, error) {
	now := models.UTCNow()
	snap := &models.DiagnosticSnapshot{
		GeneratedAt: now,
		Runtime:     s.GetRuntimeConfig(),
		Events: models.DiagnosticEventStats{
			Last5Min:   map[string]int{},
			Last1Hour:  map[string]int{},
			ByModule5m: map[string]int{},
		},
		RemoteView: models.DiagnosticRVSnapshot{Sessions: []models.DiagnosticRemoteSessionSummary{}},
		Agents:     []models.DiagnosticAgentSummary{},
	}

	if s.wsHub != nil {
		adminCount, agentCount := s.wsHub.GetConnectionCounts()
		snap.WebSocket = models.DiagnosticWSSnapshot{
			AgentsOnline:     agentCount,
			AdminConnections: adminCount,
			TotalConnections: adminCount + agentCount,
		}
		online := s.wsHub.GetOnlineDevices()
		for _, deviceID := range online {
			agent := models.DiagnosticAgentSummary{DeviceID: deviceID, Online: true}
			if s.remoteView != nil {
				agent.StatsFresh = s.remoteView.hasFreshRemoteStats(deviceID)
				if st, err := s.remoteView.GetStatus(ctx, deviceID); err == nil && st != nil && st.IsActive {
					agent.SessionID = st.SessionID
					agent.SessionStatus = st.Status
					agent.Publishing = st.StatsFresh && st.Status == models.RemoteViewStatusActive
				}
			}
			if s.deviceRepo != nil {
				if id, err := uuid.Parse(deviceID); err == nil {
					if dev, err := s.deviceRepo.Get(ctx, id); err == nil && dev != nil {
						agent.Hostname = dev.Hostname
					}
				}
			}
			snap.Agents = append(snap.Agents, agent)
		}
	}

	_ = s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM diagnostic_events`).Scan(&snap.Events.TotalStored)
	s.fillEventStats(ctx, now.Add(-5*time.Minute), snap.Events.Last5Min, snap.Events.ByModule5m)
	s.fillEventStats(ctx, now.Add(-1*time.Hour), snap.Events.Last1Hour, nil)

	if s.remoteView != nil {
		sessions, err := s.remoteView.ListActivePublisherSessions(ctx)
		if err == nil {
			snap.RemoteView.ActiveSessions = len(sessions)
			for _, session := range sessions {
				if session == nil {
					continue
				}
				deviceID := session.DeviceID.String()
				item := models.DiagnosticRemoteSessionSummary{
					SessionID:   session.ID.String(),
					DeviceID:    deviceID,
					Status:      session.Status,
					ViewerCount: session.ViewerCount,
					IngressID:   session.IngressID,
					AgentOnline: s.wsHub != nil && s.wsHub.IsAgentOnline(deviceID),
					StatsFresh:  s.remoteView.hasFreshRemoteStats(deviceID),
					StartedAt:   models.FormatUTC(session.StartedAt),
					Stats:       s.remoteView.GetDeviceStats(deviceID),
				}
				if item.StatsFresh {
					snap.RemoteView.PublishingFresh++
				}
				if s.deviceRepo != nil {
					if dev, err := s.deviceRepo.Get(ctx, session.DeviceID); err == nil && dev != nil {
						item.Hostname = dev.Hostname
					}
				}
				snap.RemoteView.Sessions = append(snap.RemoteView.Sessions, item)
			}
		}
	}

	s.enrichSnapshot(ctx, snap)
	return snap, nil
}

func (s *DiagnosticService) fillEventStats(
	ctx context.Context,
	since time.Time,
	levelCounts map[string]int,
	moduleCounts map[string]int,
) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT level, module, COUNT(*)
		FROM diagnostic_events
		WHERE created_at >= $1
		GROUP BY level, module
	`, since)
	if err != nil {
		return
	}
	defer rows.Close()
	for rows.Next() {
		var level, module string
		var count int
		if err := rows.Scan(&level, &module, &count); err != nil {
			continue
		}
		levelCounts[level] += count
		if moduleCounts != nil {
			moduleCounts[module] += count
		}
	}
}

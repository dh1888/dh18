package services

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/json"
	"math/big"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"

	"enterprise-agent/backend/models"
)

const (
	systemSettingClientProtectionDefaults = "client_protection_defaults"
	defaultUnlockCodeUnusedExpireMinutes  = 30
	minUnlockCodeUnusedExpireMinutes      = 5
	maxUnlockCodeUnusedExpireMinutes      = 1440
)

// ClientProtectionDefaults is the system-wide default (stored in system_settings).
type ClientProtectionDefaults struct {
	AllowUserExit                  bool   `json:"allowUserExit"`
	AllowAutoStartToggle           bool   `json:"allowAutoStartToggle"`
	RestartOnKill                  bool   `json:"restartOnKill"`
	UnlockCodeUnusedExpireMinutes  int    `json:"unlockCodeUnusedExpireMinutes"`
	UpdatedAt                      string `json:"updatedAt,omitempty"`
}

type clientProtectionDefaultsStored struct {
	AllowUserExit                 bool   `json:"allowUserExit"`
	AllowAutoStartToggle          bool   `json:"allowAutoStartToggle"`
	RestartOnKill                 bool   `json:"restartOnKill"`
	UnlockCodeUnusedExpireMinutes int    `json:"unlockCodeUnusedExpireMinutes"`
	UnlockCodeHash                string `json:"unlockCodeHash,omitempty"` // legacy, ignored
}

// ClientProtectionDeviceOverride per-device settings when useDefault is false.
type ClientProtectionDeviceOverride struct {
	UseDefault           bool  `json:"useDefault"`
	AllowUserExit        *bool `json:"allowUserExit,omitempty"`
	AllowAutoStartToggle *bool `json:"allowAutoStartToggle,omitempty"`
	RestartOnKill        *bool `json:"restartOnKill,omitempty"`
}

// ClientProtectionEffective is sent to agents (no secrets).
type ClientProtectionEffective struct {
	AllowUserExit        bool       `json:"allowUserExit"`
	AllowAutoStartToggle bool       `json:"allowAutoStartToggle"`
	RestartOnKill        bool       `json:"restartOnKill"`
	UnlockCodeConfigured bool       `json:"unlockCodeConfigured"` // true when device has unused, unexpired code
	TemporaryExitUntil   *time.Time `json:"temporaryExitUntil,omitempty"`
}

type DeviceExitUnlockCodeIssue struct {
	Code      string    `json:"code"`
	ExpiresAt time.Time `json:"expiresAt"`
}

type ClientProtectionService struct {
	db  *sql.DB
	hub *WebSocketHub
}

func NewClientProtectionService(db *sql.DB) *ClientProtectionService {
	return &ClientProtectionService{db: db}
}

func (s *ClientProtectionService) SetWebSocketHub(hub *WebSocketHub) {
	s.hub = hub
}

func defaultClientProtectionStored() clientProtectionDefaultsStored {
	return clientProtectionDefaultsStored{
		AllowUserExit:                 true,
		AllowAutoStartToggle:          true,
		RestartOnKill:                 false,
		UnlockCodeUnusedExpireMinutes: defaultUnlockCodeUnusedExpireMinutes,
	}
}

func normalizeUnlockCodeExpireMinutes(minutes int) int {
	if minutes < minUnlockCodeUnusedExpireMinutes {
		return defaultUnlockCodeUnusedExpireMinutes
	}
	if minutes > maxUnlockCodeUnusedExpireMinutes {
		return maxUnlockCodeUnusedExpireMinutes
	}
	return minutes
}

func (s *ClientProtectionService) unlockCodeExpireMinutes(ctx context.Context) (int, error) {
	stored, _, err := s.loadStoredDefaults(ctx)
	if err != nil {
		return defaultUnlockCodeUnusedExpireMinutes, err
	}
	return normalizeUnlockCodeExpireMinutes(stored.UnlockCodeUnusedExpireMinutes), nil
}

func (s *ClientProtectionService) loadStoredDefaults(ctx context.Context) (clientProtectionDefaultsStored, *time.Time, error) {
	stored := defaultClientProtectionStored()
	var raw sql.NullString
	var updatedAt sql.NullTime
	err := s.db.QueryRowContext(ctx,
		`SELECT value, updated_at FROM system_settings WHERE key = $1`, systemSettingClientProtectionDefaults,
	).Scan(&raw, &updatedAt)
	if err == sql.ErrNoRows {
		return stored, nil, nil
	}
	if err != nil {
		return stored, nil, err
	}
	if raw.Valid && strings.TrimSpace(raw.String) != "" {
		_ = json.Unmarshal([]byte(raw.String), &stored)
	}
	if stored.UnlockCodeUnusedExpireMinutes <= 0 {
		stored.UnlockCodeUnusedExpireMinutes = defaultUnlockCodeUnusedExpireMinutes
	}
	var updated *time.Time
	if updatedAt.Valid {
		t := updatedAt.Time.UTC()
		updated = &t
	}
	return stored, updated, nil
}

func (s *ClientProtectionService) GetSystemDefaults(ctx context.Context) (*ClientProtectionDefaults, error) {
	stored, updated, err := s.loadStoredDefaults(ctx)
	if err != nil {
		return nil, err
	}
	out := &ClientProtectionDefaults{
		AllowUserExit:                 stored.AllowUserExit,
		AllowAutoStartToggle:          stored.AllowAutoStartToggle,
		RestartOnKill:                 stored.RestartOnKill,
		UnlockCodeUnusedExpireMinutes: normalizeUnlockCodeExpireMinutes(stored.UnlockCodeUnusedExpireMinutes),
	}
	if updated != nil {
		out.UpdatedAt = updated.Format(time.RFC3339)
	}
	return out, nil
}

func (s *ClientProtectionService) SaveSystemDefaults(
	ctx context.Context,
	allowUserExit, allowAutoStartToggle, restartOnKill bool,
	unlockCodeUnusedExpireMinutes int,
) (*ClientProtectionDefaults, error) {
	stored, _, err := s.loadStoredDefaults(ctx)
	if err != nil {
		return nil, err
	}
	stored.AllowUserExit = allowUserExit
	stored.AllowAutoStartToggle = allowAutoStartToggle
	stored.RestartOnKill = restartOnKill
	stored.UnlockCodeUnusedExpireMinutes = normalizeUnlockCodeExpireMinutes(unlockCodeUnusedExpireMinutes)
	stored.UnlockCodeHash = ""

	payload, err := json.Marshal(stored)
	if err != nil {
		return nil, err
	}
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO system_settings (key, value, updated_at)
		VALUES ($1, $2, NOW())
		ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
	`, systemSettingClientProtectionDefaults, string(payload))
	if err != nil {
		return nil, err
	}
	return s.GetSystemDefaults(ctx)
}

// SyncSystemDefaultsFromPolicyContent copies config.clientProtection from a policy into system_settings when present.
func (s *ClientProtectionService) SyncSystemDefaultsFromPolicyContent(ctx context.Context, policyContent string) error {
	cp, ok := models.ParseClientProtectionFromPolicyContent(policyContent)
	if !ok || cp == nil {
		return nil
	}
	_, err := s.SaveSystemDefaults(
		ctx,
		cp.AllowUserExit,
		cp.AllowAutoStartToggle,
		cp.RestartOnKill,
		cp.UnlockCodeUnusedExpireMinutes,
	)
	if err != nil {
		return err
	}
	s.PushAllOnlineAgents(ctx)
	return nil
}

func (s *ClientProtectionService) deviceHasActiveUnlockCode(ctx context.Context, deviceID uuid.UUID) bool {
	var id uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM device_exit_unlock_codes
		WHERE device_id = $1 AND used_at IS NULL AND expires_at > NOW()
		ORDER BY created_at DESC
		LIMIT 1
	`, deviceID).Scan(&id)
	return err == nil
}

func (s *ClientProtectionService) GetDeviceOverride(ctx context.Context, deviceID uuid.UUID) (*ClientProtectionDeviceOverride, error) {
	var useDefault bool
	var allowExit, allowAuto, restart sql.NullBool
	err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(client_protection_use_default, TRUE),
		       client_protection_allow_user_exit,
		       client_protection_allow_auto_start_toggle,
		       client_protection_restart_on_kill
		FROM devices WHERE id = $1
	`, deviceID).Scan(&useDefault, &allowExit, &allowAuto, &restart)
	if err == sql.ErrNoRows {
		return nil, err
	}
	if err != nil {
		return nil, err
	}
	out := &ClientProtectionDeviceOverride{UseDefault: useDefault}
	if allowExit.Valid {
		v := allowExit.Bool
		out.AllowUserExit = &v
	}
	if allowAuto.Valid {
		v := allowAuto.Bool
		out.AllowAutoStartToggle = &v
	}
	if restart.Valid {
		v := restart.Bool
		out.RestartOnKill = &v
	}
	return out, nil
}

func (s *ClientProtectionService) SaveDeviceOverride(ctx context.Context, deviceID uuid.UUID, req ClientProtectionDeviceOverride) error {
	if req.UseDefault {
		_, err := s.db.ExecContext(ctx, `
			UPDATE devices SET
				client_protection_use_default = TRUE,
				client_protection_allow_user_exit = NULL,
				client_protection_allow_auto_start_toggle = NULL,
				client_protection_restart_on_kill = NULL,
				updated_at = NOW()
			WHERE id = $1
		`, deviceID)
		return err
	}

	_, err := s.db.ExecContext(ctx, `
		UPDATE devices SET
			client_protection_use_default = FALSE,
			client_protection_allow_user_exit = $2,
			client_protection_allow_auto_start_toggle = $3,
			client_protection_restart_on_kill = $4,
			updated_at = NOW()
		WHERE id = $1
	`, deviceID, nullBool(req.AllowUserExit), nullBool(req.AllowAutoStartToggle), nullBool(req.RestartOnKill))
	return err
}

func nullBool(p *bool) interface{} {
	if p == nil {
		return nil
	}
	return *p
}

func (s *ClientProtectionService) ResolveEffective(ctx context.Context, deviceID string) (*ClientProtectionEffective, error) {
	id, err := uuid.Parse(strings.TrimSpace(deviceID))
	if err != nil {
		return nil, err
	}
	stored, _, err := s.loadStoredDefaults(ctx)
	if err != nil {
		return nil, err
	}
	eff := &ClientProtectionEffective{
		AllowUserExit:        stored.AllowUserExit,
		AllowAutoStartToggle: stored.AllowAutoStartToggle,
		RestartOnKill:        stored.RestartOnKill,
		UnlockCodeConfigured: s.deviceHasActiveUnlockCode(ctx, id),
	}

	var useDefault bool
	var allowExit, allowAuto, restart sql.NullBool
	var tempUntil sql.NullTime
	err = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(client_protection_use_default, TRUE),
		       client_protection_allow_user_exit,
		       client_protection_allow_auto_start_toggle,
		       client_protection_restart_on_kill,
		       client_protection_temp_exit_until
		FROM devices WHERE id = $1
	`, id).Scan(&useDefault, &allowExit, &allowAuto, &restart, &tempUntil)
	if err != nil && err != sql.ErrNoRows {
		return nil, err
	}
	if err == nil && !useDefault {
		if allowExit.Valid {
			eff.AllowUserExit = allowExit.Bool
		}
		if allowAuto.Valid {
			eff.AllowAutoStartToggle = allowAuto.Bool
		}
		if restart.Valid {
			eff.RestartOnKill = restart.Bool
		}
	}
	if tempUntil.Valid {
		t := tempUntil.Time.UTC()
		if t.After(time.Now().UTC()) {
			eff.TemporaryExitUntil = &t
		} else {
			_, _ = s.db.ExecContext(ctx, `
				UPDATE devices SET client_protection_temp_exit_until = NULL, updated_at = NOW()
				WHERE id = $1 AND client_protection_temp_exit_until IS NOT NULL
			`, id)
		}
	}
	eff.UnlockCodeConfigured = s.deviceHasActiveUnlockCode(ctx, id)
	return eff, nil
}

func generateExitUnlockPlaintext() (string, error) {
	const digits = "0123456789"
	var b strings.Builder
	for i := 0; i < 8; i++ {
		n, err := rand.Int(rand.Reader, big.NewInt(int64(len(digits))))
		if err != nil {
			return "", err
		}
		b.WriteByte(digits[n.Int64()])
	}
	return b.String(), nil
}

// IssueDeviceExitUnlockCode creates a one-time code for the device; revokes other unused codes on that device.
func (s *ClientProtectionService) IssueDeviceExitUnlockCode(ctx context.Context, deviceID uuid.UUID, createdBy *uuid.UUID) (*DeviceExitUnlockCodeIssue, error) {
	minutes, err := s.unlockCodeExpireMinutes(ctx)
	if err != nil {
		return nil, err
	}
	plain, err := generateExitUnlockPlaintext()
	if err != nil {
		return nil, err
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(plain), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}
	expiresAt := time.Now().UTC().Add(time.Duration(minutes) * time.Minute)

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	_, err = tx.ExecContext(ctx, `
		UPDATE device_exit_unlock_codes
		SET used_at = NOW()
		WHERE device_id = $1 AND used_at IS NULL
	`, deviceID)
	if err != nil {
		return nil, err
	}

	var createdByArg interface{}
	if createdBy != nil {
		createdByArg = *createdBy
	}
	_, err = tx.ExecContext(ctx, `
		INSERT INTO device_exit_unlock_codes (device_id, code_hash, expires_at, created_by)
		VALUES ($1, $2, $3, $4)
	`, deviceID, string(hash), expiresAt, createdByArg)
	if err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}

	s.PushConfigToDevice(ctx, deviceID.String())
	return &DeviceExitUnlockCodeIssue{Code: plain, ExpiresAt: expiresAt}, nil
}

func (s *ClientProtectionService) VerifyUnlockCode(ctx context.Context, deviceID, code string) (bool, error) {
	id, err := uuid.Parse(strings.TrimSpace(deviceID))
	if err != nil {
		return false, err
	}
	code = strings.TrimSpace(code)
	if code == "" {
		return false, nil
	}

	rows, err := s.db.QueryContext(ctx, `
		SELECT id, code_hash FROM device_exit_unlock_codes
		WHERE device_id = $1 AND used_at IS NULL AND expires_at > NOW()
		ORDER BY created_at DESC
	`, id)
	if err != nil {
		return false, err
	}
	defer rows.Close()

	for rows.Next() {
		var rowID uuid.UUID
		var hash string
		if err := rows.Scan(&rowID, &hash); err != nil {
			continue
		}
		if bcrypt.CompareHashAndPassword([]byte(hash), []byte(code)) != nil {
			continue
		}
		res, err := s.db.ExecContext(ctx, `
			UPDATE device_exit_unlock_codes
			SET used_at = NOW()
			WHERE id = $1 AND used_at IS NULL AND expires_at > NOW()
		`, rowID)
		if err != nil {
			return false, err
		}
		if n, _ := res.RowsAffected(); n == 0 {
			return false, nil
		}
		s.PushConfigToDevice(ctx, deviceID)
		return true, nil
	}
	return false, nil
}

func (s *ClientProtectionService) GrantTemporaryExit(ctx context.Context, deviceID uuid.UUID, minutes int) (*time.Time, error) {
	if minutes < 1 {
		minutes = 1
	}
	if minutes > 240 {
		minutes = 240
	}
	until := time.Now().UTC().Add(time.Duration(minutes) * time.Minute)
	_, err := s.db.ExecContext(ctx, `
		UPDATE devices SET client_protection_temp_exit_until = $2, updated_at = NOW() WHERE id = $1
	`, deviceID, until)
	if err != nil {
		return nil, err
	}
	s.PushConfigToDevice(ctx, deviceID.String())
	deviceIDCopy := deviceID
	untilCopy := until
	go func() {
		delay := time.Until(untilCopy) + 2*time.Second
		if delay < time.Second {
			delay = time.Second
		}
		time.Sleep(delay)
		s.PushConfigToDevice(context.Background(), deviceIDCopy.String())
	}()
	return &until, nil
}

func (s *ClientProtectionService) PushConfigToDevice(ctx context.Context, deviceID string) {
	if s.hub == nil {
		return
	}
	eff, err := s.ResolveEffective(ctx, deviceID)
	if err != nil {
		return
	}
	s.hub.BroadcastToAgent(deviceID, gin.H{
		"type":      "client_protection_update",
		"messageId": uuid.NewString(),
		"config":    eff,
	})
}

func (s *ClientProtectionService) PushAllOnlineAgents(ctx context.Context) {
	if s.hub == nil {
		return
	}
	for _, deviceID := range s.hub.GetOnlineDevices() {
		s.PushConfigToDevice(ctx, deviceID)
	}
}

func (s *ClientProtectionService) OnAgentRegistered(deviceID string) {
	if s.hub == nil {
		return
	}
	go s.PushConfigToDevice(context.Background(), deviceID)
}

// RevokeExpiredUnlockCodes removes old rows (housekeeping).
func (s *ClientProtectionService) RevokeExpiredUnlockCodes(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, `
		DELETE FROM device_exit_unlock_codes
		WHERE expires_at < NOW() - INTERVAL '7 days'
		   OR (used_at IS NOT NULL AND used_at < NOW() - INTERVAL '7 days')
	`)
	return err
}

func (s *ClientProtectionService) activeUnlockSummary(ctx context.Context, deviceID uuid.UUID) (expiresAt *time.Time, err error) {
	var t sql.NullTime
	err = s.db.QueryRowContext(ctx, `
		SELECT expires_at FROM device_exit_unlock_codes
		WHERE device_id = $1 AND used_at IS NULL AND expires_at > NOW()
		ORDER BY created_at DESC LIMIT 1
	`, deviceID).Scan(&t)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if t.Valid {
		u := t.Time.UTC()
		return &u, nil
	}
	return nil, nil
}

func (s *ClientProtectionService) GetDeviceUnlockCodeStatus(ctx context.Context, deviceID uuid.UUID) (hasActive bool, expiresAt *time.Time, err error) {
	hasActive = s.deviceHasActiveUnlockCode(ctx, deviceID)
	if !hasActive {
		return false, nil, nil
	}
	expiresAt, err = s.activeUnlockSummary(ctx, deviceID)
	return hasActive, expiresAt, err
}
package services

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/google/uuid"
)

const (
	telegramDailyRetentionDays = 30
)

func StartTelegramMaintenanceScheduler(ctx context.Context, svc *WorkforceTelegramService) {
	if svc == nil {
		return
	}
	go func() {
		hourly := time.NewTicker(time.Hour)
		daily := time.NewTicker(24 * time.Hour)
		defer hourly.Stop()
		defer daily.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-hourly.C:
				svc.RecoverMissedDailyResets(context.Background())
				svc.RecoverExpiredActivities(context.Background())
				svc.CloseExpiredWorkSessionsGlobal(context.Background())
				svc.MaybePushMonthlyArchive(context.Background())
			case <-daily.C:
				if err := svc.CleanupTelegramRetention(context.Background()); err != nil {
					log.Printf("[Telegram] retention cleanup: %v", err)
				}
			}
		}
	}()
}

func (s *WorkforceTelegramService) CleanupTelegramRetention(ctx context.Context) error {
	if !TelegramAttendanceEnabled() {
		return nil
	}
	// Live detail rows are normally archived then deleted by daily reset.
	// Only remove orphan live closed activities that are already archived,
	// so export completeness is preserved. Archive / monthly table retention
	// is owned by System Settings → attendanceRetentionMonths.
	cutoff := time.Now().AddDate(0, 0, -telegramDailyRetentionDays).Format("2006-01-02")
	res, err := s.db.ExecContext(ctx, `
		DELETE FROM wf_tg_activity_sessions s
		WHERE s.status = 'closed'
		  AND s.attendance_date < $1::date
		  AND EXISTS (
			SELECT 1 FROM wf_tg_activity_sessions_archive a WHERE a.id = s.id
		  )`, cutoff)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n > 0 {
		log.Printf("[Telegram] retention cleanup: removed %d already-archived live activities before %s", n, cutoff)
	}
	return nil
}

func (s *WorkforceTelegramService) MaybePushMonthlyArchive(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return
	}
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)
	// 次月 1 日 17:00 起推送上月月表；前 3 天内可补推，避免服务宕机漏掉。
	if now.Day() > 3 {
		return
	}
	if now.Day() == 1 && now.Hour() < 17 {
		return
	}
	prevMonth := now.AddDate(0, -1, 0)
	yearMonth := prevMonth.Format("2006-01")
	dateFrom := time.Date(prevMonth.Year(), prevMonth.Month(), 1, 0, 0, 0, 0, loc).Format("2006-01-02")
	dateTo := time.Date(prevMonth.Year(), prevMonth.Month()+1, 0, 0, 0, 0, 0, loc).Format("2006-01-02")

	groups, err := s.ListGroups(ctx)
	if err != nil {
		return
	}
	caption := fmt.Sprintf("📊 月度考勤报表\n📅 统计月份：%s\n📆 区间：%s ~ %s\n⏰ 导出时间：%s",
		yearMonth, dateFrom, dateTo, now.Format("2006-01-02 15:04:05"))
	for _, g := range groups {
		if !g.Enabled || strings.TrimSpace(g.ChatID) == "" {
			continue
		}
		chatID := strings.TrimSpace(g.ChatID)
		var exists int
		_ = s.db.QueryRowContext(ctx, `
			SELECT COUNT(*) FROM wf_tg_monthly_export_log
			WHERE year_month = $1 AND chat_id = $2`, yearMonth, chatID).Scan(&exists)
		if exists > 0 {
			continue
		}
		data, filename, err := s.ExportAttendanceXLSX(ctx, dateFrom, dateTo, chatID)
		if err != nil || len(data) == 0 {
			log.Printf("[Telegram] monthly archive export %s chat=%s: %v", yearMonth, chatID, err)
			continue
		}
		s.PushDocumentToChatTargets(ctx, chatID, filename, data, caption, false)
		_, _ = s.db.ExecContext(ctx, `
			INSERT INTO wf_tg_monthly_export_log (year_month, chat_id, export_path, pushed_at)
			VALUES ($1, $2, $3, NOW())
			ON CONFLICT (year_month, chat_id) DO NOTHING`, yearMonth, chatID, filename)
		log.Printf("[Telegram] monthly archive pushed %s -> %s", yearMonth, chatID)
	}
}

func (s *WorkforceTelegramService) ExportMonthlyArchiveXLSX(ctx context.Context, yearMonth string) ([]byte, string, error) {
	t, err := time.Parse("2006-01", yearMonth)
	if err != nil {
		return nil, "", err
	}
	dateFrom := t.Format("2006-01-02")
	dateTo := t.AddDate(0, 1, -1).Format("2006-01-02")
	return s.ExportAttendanceXLSX(ctx, dateFrom, dateTo, "")
}

func (s *WorkforceTelegramService) SetActivityTelegramMessageID(ctx context.Context, sessionID uuid.UUID, messageID int64) {
	if sessionID == uuid.Nil || messageID <= 0 {
		return
	}
	_, _ = s.db.ExecContext(ctx, `
		UPDATE wf_tg_activity_sessions SET telegram_message_id = $2 WHERE id = $1`, sessionID, messageID)
}

func (s *WorkforceTelegramService) GetActivitySessionTelegramMessageID(ctx context.Context, sessionID uuid.UUID) int64 {
	return s.activitySessionTelegramMessageID(ctx, sessionID)
}

func (s *WorkforceTelegramService) getEmployeeLastGroupBotMessageID(ctx context.Context, chatID string, empID uuid.UUID) int64 {
	if empID == uuid.Nil || strings.TrimSpace(chatID) == "" {
		return 0
	}
	var msgID sql.NullInt64
	_ = s.db.QueryRowContext(ctx, `
		SELECT last_group_bot_message_id FROM employee_telegram_bindings
		WHERE employee_id = $1 AND status = 1 AND COALESCE(chat_id,'') = $2`,
		empID, strings.TrimSpace(chatID)).Scan(&msgID)
	if msgID.Valid && msgID.Int64 > 0 {
		return msgID.Int64
	}
	return 0
}

func (s *WorkforceTelegramService) setEmployeeLastGroupBotMessageID(ctx context.Context, chatID string, empID uuid.UUID, messageID int64) {
	if empID == uuid.Nil || messageID <= 0 || strings.TrimSpace(chatID) == "" {
		return
	}
	_, _ = s.db.ExecContext(ctx, `
		UPDATE employee_telegram_bindings
		SET last_group_bot_message_id = $3
		WHERE employee_id = $1 AND status = 1 AND COALESCE(chat_id,'') = $2`,
		empID, strings.TrimSpace(chatID), messageID)
}

func (s *WorkforceTelegramService) hasOpenNightContinuation(ctx context.Context, empID uuid.UUID, recordDate string) bool {
	t, err := time.Parse("2006-01-02", recordDate)
	if err != nil {
		return false
	}
	next := t.AddDate(0, 0, 1).Format("2006-01-02")
	var count int
	_ = s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM work_sessions
		WHERE employee_id = $1 AND shift_type = 'night' AND status = 'open'
		  AND attendance_date IN ($2::date, $3::date)`, empID, recordDate, next).Scan(&count)
	return count > 0 && time.Now().Hour() < 12
}

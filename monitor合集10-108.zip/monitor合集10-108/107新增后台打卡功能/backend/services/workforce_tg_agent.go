package services

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"math"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type AgentCaptureSyncResult struct {
	DeviceID uuid.UUID
	Synced   bool
	Online   bool
}

func (s *WorkforceTelegramService) findApprovedDeviceForEmployee(ctx context.Context, empID uuid.UUID) (uuid.UUID, bool, error) {
	return s.resolveAgentSyncTarget(ctx, empID, uuid.Nil)
}

func (s *WorkforceTelegramService) resolveAgentSyncTarget(ctx context.Context, empID, preferredDeviceID uuid.UUID) (uuid.UUID, bool, error) {
	if preferredDeviceID != uuid.Nil {
		var status string
		err := s.db.QueryRowContext(ctx, `
			SELECT LOWER(COALESCE(status,'')) FROM devices WHERE id = $1`, preferredDeviceID).Scan(&status)
		if err == nil && status == "approved" {
			online := s.wsHub != nil && s.wsHub.IsAgentOnline(preferredDeviceID.String())
			return preferredDeviceID, online, nil
		}
	}
	deviceID, err := s.findDeviceForEmployee(ctx, empID)
	if err != nil || deviceID == uuid.Nil {
		return uuid.Nil, false, err
	}
	online := s.wsHub != nil && s.wsHub.IsAgentOnline(deviceID.String())
	return deviceID, online, nil
}

func (s *WorkforceTelegramService) syncAgentWorkInFromTelegram(ctx context.Context, empID, sessionID uuid.UUID, actor *TelegramActor) {
	pref := preferredDeviceFromActor(actor)
	s.syncAgentCaptureStart(ctx, empID, sessionID, pref)
	s.syncAgentTelegramCheckInNotify(ctx, empID, sessionID, pref)
	s.syncAgentWorkSessionState(ctx, empID, true, sessionID, resolvePunchSource(actor, PunchSourceTelegram), pref)
}

func (s *WorkforceTelegramService) syncAgentWorkOutFromTelegram(ctx context.Context, empID, sessionID uuid.UUID, actor *TelegramActor, source string) {
	pref := preferredDeviceFromActor(actor)
	s.syncAgentCaptureStop(ctx, empID, sessionID, pref)
	s.syncAgentTelegramCheckOutNotify(ctx, empID, sessionID, pref)
	src := strings.TrimSpace(source)
	if src == "" {
		src = "telegram"
	}
	s.syncAgentWorkSessionState(ctx, empID, false, sessionID, src, pref)
}

func (s *WorkforceTelegramService) linkSessionToDevice(ctx context.Context, sessionID, deviceID uuid.UUID) {
	_, _ = s.db.ExecContext(ctx, `
		UPDATE work_sessions SET device_id = $1, updated_at = NOW()
		WHERE id = $2 AND device_id IS NULL`, deviceID, sessionID)
}

func (s *WorkforceTelegramService) SyncAgentCaptureStart(ctx context.Context, empID, sessionID uuid.UUID) AgentCaptureSyncResult {
	return s.syncAgentCaptureStart(ctx, empID, sessionID, uuid.Nil)
}

func (s *WorkforceTelegramService) syncAgentCaptureStart(ctx context.Context, empID, sessionID, preferredDeviceID uuid.UUID) AgentCaptureSyncResult {
	out := AgentCaptureSyncResult{}
	if !CaptureLinkedToCheckin(ctx, s.db) || s.wsHub == nil {
		return out
	}
	deviceID, online, err := s.resolveAgentSyncTarget(ctx, empID, preferredDeviceID)
	if err != nil || deviceID == uuid.Nil {
		return out
	}
	out.DeviceID = deviceID
	out.Online = online
	s.linkSessionToDevice(ctx, sessionID, deviceID)
	if !online {
		log.Printf("[Telegram] agent capture start skipped: device %s offline (employee %s)", deviceID, empID)
		return out
	}
	s.wsHub.SendCommandToDevice(deviceID.String(), "start_work_capture", gin.H{
		"sessionId": sessionID.String(),
		"source":    "telegram",
	})
	out.Synced = true
	return out
}

func (s *WorkforceTelegramService) SyncAgentCaptureStop(ctx context.Context, empID, sessionID uuid.UUID) AgentCaptureSyncResult {
	return s.syncAgentCaptureStop(ctx, empID, sessionID, uuid.Nil)
}

func (s *WorkforceTelegramService) syncAgentCaptureStop(ctx context.Context, empID, sessionID, preferredDeviceID uuid.UUID) AgentCaptureSyncResult {
	out := AgentCaptureSyncResult{}
	if !CaptureLinkedToCheckin(ctx, s.db) || s.wsHub == nil {
		return out
	}
	deviceID, online, err := s.resolveAgentSyncTarget(ctx, empID, preferredDeviceID)
	if err != nil || deviceID == uuid.Nil {
		return out
	}
	out.DeviceID = deviceID
	out.Online = online
	if !online {
		return out
	}
	params := gin.H{"source": "telegram"}
	if sessionID != uuid.Nil {
		params["sessionId"] = sessionID.String()
	}
	s.wsHub.SendCommandToDevice(deviceID.String(), "stop_work_capture", params)
	out.Synced = true
	return out
}

func (s *WorkforceTelegramService) SyncAgentTelegramCheckInNotify(ctx context.Context, empID, sessionID uuid.UUID) {
	s.syncAgentTelegramCheckInNotify(ctx, empID, sessionID, uuid.Nil)
}

func (s *WorkforceTelegramService) syncAgentTelegramCheckInNotify(ctx context.Context, empID, sessionID, preferredDeviceID uuid.UUID) {
	if s.wsHub == nil {
		return
	}
	deviceID, online, err := s.resolveAgentSyncTarget(ctx, empID, preferredDeviceID)
	if err != nil || deviceID == uuid.Nil || !online {
		return
	}
	s.wsHub.SendCommandToDevice(deviceID.String(), "telegram_checkin_notify", gin.H{
		"sessionId": sessionID.String(),
	})
}

func (s *WorkforceTelegramService) SyncAgentTelegramCheckOutNotify(ctx context.Context, empID, sessionID uuid.UUID) {
	s.syncAgentTelegramCheckOutNotify(ctx, empID, sessionID, uuid.Nil)
}

func (s *WorkforceTelegramService) syncAgentTelegramCheckOutNotify(ctx context.Context, empID, sessionID, preferredDeviceID uuid.UUID) {
	if s.wsHub == nil {
		return
	}
	deviceID, online, err := s.resolveAgentSyncTarget(ctx, empID, preferredDeviceID)
	if err != nil || deviceID == uuid.Nil || !online {
		return
	}
	params := gin.H{}
	if sessionID != uuid.Nil {
		params["sessionId"] = sessionID.String()
	}
	s.wsHub.SendCommandToDevice(deviceID.String(), "telegram_checkout_notify", params)
}

// SyncAgentWorkSessionState pushes tray work-session state without requiring capture-linked check-in.
func (s *WorkforceTelegramService) SyncAgentWorkSessionState(ctx context.Context, empID uuid.UUID, open bool, sessionID uuid.UUID, source string) {
	s.syncAgentWorkSessionState(ctx, empID, open, sessionID, source, uuid.Nil)
}

func (s *WorkforceTelegramService) syncAgentWorkSessionState(ctx context.Context, empID uuid.UUID, open bool, sessionID uuid.UUID, source string, preferredDeviceID uuid.UUID) {
	if s.wsHub == nil {
		return
	}
	deviceID, online, err := s.resolveAgentSyncTarget(ctx, empID, preferredDeviceID)
	if err != nil || deviceID == uuid.Nil || !online {
		return
	}
	params := gin.H{"open": open}
	if sessionID != uuid.Nil {
		params["sessionId"] = sessionID.String()
	}
	if strings.TrimSpace(source) != "" {
		params["source"] = strings.TrimSpace(source)
	}
	s.wsHub.SendCommandToDevice(deviceID.String(), "work_session_state_sync", params)
}

// SyncAgentActivityState pushes TG/PC activity (活动/回座) changes to the online agent punch panel.
func (s *WorkforceTelegramService) SyncAgentActivityState(
	ctx context.Context,
	empID uuid.UUID,
	open bool,
	session *TgActivitySession,
	source string,
) {
	if s.wsHub == nil {
		return
	}
	deviceID, online, err := s.resolveAgentSyncTarget(ctx, empID, uuid.Nil)
	if err != nil || deviceID == uuid.Nil || !online {
		return
	}
	params := gin.H{"open": open}
	if strings.TrimSpace(source) != "" {
		params["source"] = strings.TrimSpace(source)
	}
	if session != nil {
		if session.ID != uuid.Nil {
			params["sessionId"] = session.ID.String()
		}
		if strings.TrimSpace(session.ActivityName) != "" {
			params["activityName"] = strings.TrimSpace(session.ActivityName)
		}
		if strings.TrimSpace(session.ActivityCode) != "" {
			params["activityCode"] = strings.TrimSpace(session.ActivityCode)
		}
		if session.LimitSeconds > 0 {
			params["limitSeconds"] = session.LimitSeconds
		}
		if !session.StartedAt.IsZero() {
			params["startedAt"] = session.StartedAt.UTC().Format(time.RFC3339)
		}
	}
	s.wsHub.SendCommandToDevice(deviceID.String(), "activity_state_sync", params)
}

func (s *WorkforceTelegramService) syncAgentActivityStateForDevice(ctx context.Context, empID, preferredDeviceID uuid.UUID, open bool, session *TgActivitySession, source string) {
	if s.wsHub == nil {
		return
	}
	deviceID, online, err := s.resolveAgentSyncTarget(ctx, empID, preferredDeviceID)
	if err != nil || deviceID == uuid.Nil || !online {
		return
	}
	params := gin.H{"open": open}
	if strings.TrimSpace(source) != "" {
		params["source"] = strings.TrimSpace(source)
	}
	if session != nil {
		if session.ID != uuid.Nil {
			params["sessionId"] = session.ID.String()
		}
		if strings.TrimSpace(session.ActivityName) != "" {
			params["activityName"] = strings.TrimSpace(session.ActivityName)
		}
		if strings.TrimSpace(session.ActivityCode) != "" {
			params["activityCode"] = strings.TrimSpace(session.ActivityCode)
		}
		if session.LimitSeconds > 0 {
			params["limitSeconds"] = session.LimitSeconds
		}
		if !session.StartedAt.IsZero() {
			params["startedAt"] = session.StartedAt.UTC().Format(time.RFC3339)
		}
	}
	s.wsHub.SendCommandToDevice(deviceID.String(), "activity_state_sync", params)
}

func (s *WorkforceTelegramService) openWorkSessionID(ctx context.Context, empID uuid.UUID) uuid.UUID {
	var sid uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM work_sessions WHERE employee_id = $1 AND status = 'open'
		ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&sid)
	if err != nil {
		return uuid.Nil
	}
	return sid
}

// NotifyAgentWorkEvent posts PC client check-in/out to the bound Telegram check-in group
// using the same HTML templates as in-group TG check-in. Exception alerts go to push targets.
func (s *WorkforceTelegramService) NotifyAgentWorkEvent(ctx context.Context, empID, deviceID uuid.UUID, shift, event string, sessionID uuid.UUID) {
	if empID == uuid.Nil || sessionID == uuid.Nil {
		return
	}
	active, err := s.IsActive(ctx)
	if err != nil || !active {
		return
	}
	var empName string
	var tgUID int64
	err = s.db.QueryRowContext(ctx, `SELECT COALESCE(name,'') FROM employees WHERE id = $1`, empID).Scan(&empName)
	if err != nil {
		return
	}
	chatID := s.resolveNotifyChatID(ctx, empID, deviceID)
	if strings.TrimSpace(chatID) == "" {
		log.Printf("[Telegram] agent work event skipped: no notify chat emp=%s device=%s event=%s", empID, deviceID, event)
		return
	}
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(telegram_user_id,0) FROM employee_telegram_bindings
		WHERE employee_id = $1 AND status = 1 ORDER BY updated_at DESC NULLS LAST LIMIT 1`, empID).Scan(&tgUID)
	if tgUID == 0 && deviceID != uuid.Nil {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(telegram_user_id,0) FROM device_telegram_bindings
			WHERE device_id = $1 AND status = 1`, deviceID).Scan(&tgUID)
	}
	settings, _, _, _, err := s.loadExtendedSettings(ctx)
	if err != nil {
		return
	}
	grace, _ := s.GetGraceConfig(ctx, chatID)
	loc := tgLoadLocation(settings.Timezone)

	switch event {
	case "上班":
		s.notifyAgentCheckInGroup(ctx, empID, tgUID, chatID, empName, sessionID, shift, settings, grace, loc)
	case "下班":
		s.notifyAgentCheckOutGroup(ctx, empID, tgUID, chatID, empName, sessionID, shift, settings, grace, loc)
	}
}

func (s *WorkforceTelegramService) resolveWorkStartClock(ctx context.Context, chatID string, settings *TelegramSettings, period *TgPeriodInfo, shift string) string {
	if shift == "night" {
		startClock := settings.NightStart
		if period != nil && period.IsHandover {
			if cfg, _ := s.GetHandoverConfig(ctx, chatID); cfg != nil {
				startClock = cfg.NightStartTime
			}
		}
		return startClock
	}
	startClock := settings.DayStart
	if period != nil && period.IsHandover && strings.Contains(period.PeriodType, "handover_day") {
		if cfg, _ := s.GetHandoverConfig(ctx, chatID); cfg != nil {
			startClock = cfg.HandoverDayStartTime
		}
	}
	return startClock
}

func (s *WorkforceTelegramService) notifyAgentCheckInGroup(
	ctx context.Context, empID uuid.UUID, tgUID int64, chatID, empName string, sessionID uuid.UUID,
	shift string, settings *TelegramSettings, grace TgGraceConfig, loc *time.Location,
) {
	var shiftType, shiftDetail, recordDate string
	var checkin time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day'), COALESCE(shift_detail,''), attendance_date::text, checkin_time
		FROM work_sessions WHERE id = $1`, sessionID).
		Scan(&shiftType, &shiftDetail, &recordDate, &checkin)
	if err != nil {
		return
	}
	if strings.TrimSpace(shift) == "" {
		shift = shiftType
	}
	checkin = checkin.In(loc)
	period, _ := s.DetermineCurrentPeriod(ctx, chatID, checkin)
	recordDate = resolveAttendanceDate(shiftType, shiftDetail, period, checkin, loc)
	startClock := s.resolveWorkStartClock(ctx, chatID, settings, period, shiftType)
	expectedStart := resolveWorkStartExpectedTime(checkin, recordDate, shiftType, shiftDetail, startClock, loc)
	lateMin := minutesLateFromExpected(checkin, expectedStart, grace.LateTolerance)
	fineReason := fmt.Sprintf("%s上班迟到 %d 分钟（PC客户端）", shiftLabel(shiftType)+shiftDetailLabel(shiftDetail), lateMin)
	workFine, _ := s.applyWorkFine(ctx, empID, "work_start", lateMin, recordDate, fineReason)

	if chatID != "" {
		_ = s.setGroupShiftState(ctx, chatID, empID, shiftType, recordDate)
	}

	hint := ""
	if period != nil {
		hint = s.handoverStatusHint(ctx, chatID, period)
		hint += s.buildRelaySuccessorHintAfterCheckIn(ctx, empID, chatID, shiftType, recordDate, checkin)
	}
	bodyHTML := buildWorkStartGroupReplyHTML(
		tgUID, empName, shiftType, shiftDetail, checkin, expectedStart, lateMin, workFine, strings.TrimSpace(hint),
	)
	pcPrefix := "💻 <b>PC客户端打卡</b>"
	groupHTML := pcPrefix + "\n" + bodyHTML
	kb := s.BuildWorkerReplyKeyboard(ctx, chatID)
	replyTo := s.getEmployeeLastGroupBotMessageID(ctx, chatID, empID)
	if msgID, err := s.SendTelegramHTMLReplyReturnID(ctx, chatID, groupHTML, replyTo, kb); err != nil {
		log.Printf("[Telegram] agent check-in group notify failed chat=%s emp=%s: %v", chatID, empID, err)
	} else {
		s.setEmployeeLastGroupBotMessageID(ctx, chatID, empID, msgID)
	}
	activitySec := s.sumTodayActivitySeconds(ctx, empID, recordDate, shiftType)
	s.NotifyWorkExceptionPushHTML(ctx, chatID, empID, empName, shiftLabel(shiftType)+shiftDetailLabel(shiftDetail), "上班", workFine, lateMin, 0, activitySec, bodyHTML, pcPrefix)
}

func (s *WorkforceTelegramService) notifyAgentCheckOutGroup(
	ctx context.Context, empID uuid.UUID, tgUID int64, chatID, empName string, sessionID uuid.UUID,
	shift string, settings *TelegramSettings, grace TgGraceConfig, loc *time.Location,
) {
	var shiftType, shiftDetail, recordDate string
	var checkin, checkout time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day'), COALESCE(shift_detail,''), attendance_date::text, checkin_time, checkout_time
		FROM work_sessions WHERE id = $1 AND status = 'closed'`, sessionID).
		Scan(&shiftType, &shiftDetail, &recordDate, &checkin, &checkout)
	if err != nil {
		return
	}
	if strings.TrimSpace(shift) == "" {
		shift = shiftType
	}
	checkin = checkin.In(loc)
	checkout = checkout.In(loc)
	now := checkout

	period, _ := s.DetermineCurrentPeriod(ctx, chatID, checkin)
	recordDate = resolveAttendanceDate(shiftType, shiftDetail, period, checkin, loc)

	var endClock string
	if shiftType == "night" {
		endClock = settings.NightEnd
	} else {
		endClock = settings.DayEnd
	}
	expectedEnd := resolveWorkEndExpectedTime(now, recordDate, shiftType, endClock, loc)
	earlyMin := minutesEarlyFromExpected(now, expectedEnd, grace.EarlyLeaveTolerance)
	fineReason := fmt.Sprintf("%s下班早退 %d 分钟（PC客户端）", shiftLabel(shiftType), earlyMin)
	workFine, _ := s.applyWorkFine(ctx, empID, "work_end", earlyMin, recordDate, fineReason)

	activityWarn := s.buildCrossShiftActivityWarn(ctx, empID, shiftType, recordDate)
	if chatID != "" {
		s.clearGroupShiftState(ctx, chatID, empID, shiftType)
		s.maybeBroadcastShiftEnd(ctx, chatID, shiftType, recordDate)
	}

	workSec := int(math.Max(0, now.Sub(checkin).Seconds()))
	activitySec := s.sumTodayActivitySeconds(ctx, empID, recordDate, shiftType)
	handoverHint := s.buildRelayCheckoutHint(ctx, chatID, empID, shiftType, recordDate, now)
	bodyHTML := buildWorkEndGroupReplyHTML(
		tgUID, empName, shiftType, now, expectedEnd, earlyMin, workFine, handoverHint, activityWarn,
	)
	pcPrefix := "💻 <b>PC客户端打卡</b>"
	groupHTML := pcPrefix + "\n" + bodyHTML
	kb := s.BuildWorkerReplyKeyboard(ctx, chatID)
	replyTo := s.getEmployeeLastGroupBotMessageID(ctx, chatID, empID)
	if msgID, err := s.SendTelegramHTMLReplyReturnID(ctx, chatID, groupHTML, replyTo, kb); err != nil {
		log.Printf("[Telegram] agent check-out group notify failed chat=%s emp=%s: %v", chatID, empID, err)
	} else {
		s.setEmployeeLastGroupBotMessageID(ctx, chatID, empID, msgID)
	}
	s.NotifyWorkExceptionPushHTML(ctx, chatID, empID, empName, shiftLabel(shiftType), "下班", workFine, earlyMin, workSec, activitySec, bodyHTML, pcPrefix)
}

func (s *WorkforceTelegramService) latestClosedWorkSeconds(ctx context.Context, empID uuid.UUID) int {
	var sec sql.NullFloat64
	_ = s.db.QueryRowContext(ctx, `
		SELECT EXTRACT(EPOCH FROM (checkout_time - checkin_time))
		FROM work_sessions
		WHERE employee_id = $1 AND status = 'closed'
		ORDER BY checkout_time DESC LIMIT 1`, empID).Scan(&sec)
	if sec.Valid && sec.Float64 > 0 {
		return int(sec.Float64)
	}
	return 0
}

// AgentCheckIn handles PC client check-in with optional forced shift (day/night).
// When dual-shift is off, always records day shift (legacy single button).
func (s *WorkforceTelegramService) AgentCheckIn(ctx context.Context, deviceID uuid.UUID, forcedShift string) (*CheckInResult, error) {
	if err := s.rejectIfWebPunchOnly(ctx); err != nil {
		return nil, err
	}
	if _, err := s.workforce.ExpireEmployeeSessionIfNeeded(ctx, deviceID); err != nil {
		return nil, err
	}

	empID, err := s.workforce.ResolveEmployeeByDeviceID(ctx, deviceID)
	if err != nil {
		return nil, err
	}
	var sessionAt sql.NullTime
	if err = s.db.QueryRowContext(ctx, `SELECT employee_session_at FROM devices WHERE id = $1`, deviceID).Scan(&sessionAt); err != nil {
		return nil, err
	}
	if !sessionAt.Valid {
		return nil, ErrEmployeeLoginRequired
	}

	settings, shiftWindowDisabled, _, requirePCLogin, err := s.loadExtendedSettings(ctx)
	if err != nil {
		return nil, err
	}
	_ = requirePCLogin

	var chatID string
	chatID = s.resolveNotifyChatID(ctx, empID, deviceID)

	if !settings.DualShiftEnabled {
		loc := tgLoadLocation(settings.Timezone)
		now := time.Now().In(loc)
		period, _ := s.DetermineCurrentPeriod(ctx, chatID, now)
		recordDate := resolveAttendanceDate("day", "", period, now, loc)
		if err := s.validateNoConflictingOpenWorkSession(ctx, empID, "day", "", recordDate); err != nil {
			return nil, err
		}
		return s.workforce.CheckInForEmployee(ctx, empID, "agent", &deviceID, &CheckInOptions{
			ShiftType:  "day",
			RecordDate: recordDate,
		})
	}

	forcedShift = strings.TrimSpace(forcedShift)
	if forcedShift == "" {
		forcedShift = "day"
	}
	shift, err := normalizeShiftType(forcedShift)
	if err != nil {
		return nil, err
	}

	grace, _ := s.GetGraceConfig(ctx, chatID)
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)

	shift, shiftDetail, err := s.resolveShiftForCheckIn(settings, grace, shiftWindowDisabled, shift, now)
	if err != nil {
		return nil, err
	}
	if err := s.validateRelayNightBlock(ctx, chatID, shift, now); err != nil {
		return nil, err
	}

	period, _ := s.DetermineCurrentPeriod(ctx, chatID, now)
	recordDate := resolveAttendanceDate(shift, shiftDetail, period, now, loc)

	if err := s.validateNoConflictingOpenWorkSession(ctx, empID, shift, shiftDetail, recordDate); err != nil {
		return nil, err
	}

	done, err := s.hasCompletedShiftOnDate(ctx, empID, recordDate, shift)
	if err != nil {
		return nil, err
	}
	if done {
		return nil, ErrShiftAlreadyCompleted
	}

	return s.workforce.CheckInForEmployee(ctx, empID, "agent", &deviceID, &CheckInOptions{
		ShiftType:   shift,
		RecordDate:  recordDate,
		ShiftDetail: shiftDetail,
	})
}

// DualShiftEnabledForAgent reports whether the agent should show day/night check-in.
func (s *WorkforceTelegramService) DualShiftEnabledForAgent(ctx context.Context) bool {
	settings, err := s.GetSettings(ctx)
	return err == nil && settings != nil && settings.DualShiftEnabled
}

type AgentTgRecord struct {
	Time       string  `json:"time"`
	Event      string  `json:"event"`
	Detail     string  `json:"detail"`
	Status     string  `json:"status"`
	Source     string  `json:"source,omitempty"`
	SessionID  string  `json:"sessionId,omitempty"`
	OccurredAt string  `json:"occurredAt,omitempty"`
	FineAmount float64 `json:"fineAmount,omitempty"`
}

type AgentTgActivityType struct {
	Code             string `json:"code"`
	Name             string `json:"name"`
	TimeLimitSeconds int    `json:"timeLimitSeconds,omitempty"`
	MaxTimesPerDay   int    `json:"maxTimesPerDay,omitempty"`
	TodayCount       int    `json:"todayCount,omitempty"`
	SortOrder        int    `json:"sortOrder,omitempty"`
}

type AgentTgDashboard struct {
	WorkSessionOpen  bool                 `json:"workSessionOpen"`
	WorkShiftType    string               `json:"workShiftType,omitempty"`
	DualShiftEnabled bool                 `json:"dualShiftEnabled"`
	OpenActivity     *TgActivitySession     `json:"openActivity,omitempty"`
	ActivityTypes    []AgentTgActivityType  `json:"activityTypes,omitempty"`
	Records          []AgentTgRecord        `json:"records"`
	TodayFineTotal   float64              `json:"todayFineTotal"`
}

func (s *WorkforceTelegramService) GetAgentTgDashboard(ctx context.Context, empID uuid.UUID) (*AgentTgDashboard, error) {
	if empID == uuid.Nil {
		return nil, ErrEmployeeNotFound
	}
	out := &AgentTgDashboard{
		DualShiftEnabled: s.DualShiftEnabledForAgent(ctx),
		Records:          make([]AgentTgRecord, 0),
	}
	openWork, _, _ := s.GetEmployeeSessionStatus(ctx, empID)
	out.WorkSessionOpen = openWork
	var shiftType string
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day') FROM work_sessions
		WHERE employee_id = $1 AND status = 'open'
		ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&shiftType)
	out.WorkShiftType = shiftType

	if sess, err := s.getOpenActivitySession(ctx, empID); err == nil {
		out.OpenActivity = sess
	}

	settings, _ := s.GetSettings(ctx)
	tz := "Asia/Shanghai"
	if settings != nil && strings.TrimSpace(settings.Timezone) != "" {
		tz = strings.TrimSpace(settings.Timezone)
	}
	loc := tgLoadLocation(tz)
	calendarToday := time.Now().In(loc).Format("2006-01-02")
	businessDate := s.resolveAgentDashboardDate(ctx, empID, calendarToday)

	type sortableRecord struct {
		at     time.Time
		record AgentTgRecord
	}
	merged := make([]sortableRecord, 0, 32)

	wsRows, err := s.db.QueryContext(ctx, `
		SELECT shift_type, checkin_time, checkout_time, status, COALESCE(source,''), attendance_date::text
		FROM work_sessions
		WHERE employee_id = $1
		  AND (attendance_date = $2::date OR attendance_date = $3::date
		       OR (checkin_time AT TIME ZONE $4)::date = $2::date
		       OR (checkin_time AT TIME ZONE $4)::date = $3::date)
		ORDER BY checkin_time DESC
		LIMIT 30`, empID, businessDate, calendarToday, tz)
	if err != nil {
		log.Printf("[AgentDashboard] work sessions query emp=%s: %v", empID, err)
	} else {
		defer wsRows.Close()
		for wsRows.Next() {
			var shiftType, source, attDate string
			var checkin time.Time
			var checkout sql.NullTime
			var status string
			if wsRows.Scan(&shiftType, &checkin, &checkout, &status, &source, &attDate) != nil {
				continue
			}
			checkin = checkin.In(loc)
			label := shiftLabel(shiftType) + "上班"
			src := formatAgentRecordSource(source)
			rec := AgentTgRecord{
				Time:       checkin.Format("15:04:05"),
				Event:      label,
				Detail:     "上班打卡",
				Status:     "checkin",
				Source:     src,
				OccurredAt: checkin.UTC().Format(time.RFC3339),
			}
			if !checkout.Valid && status == "open" {
				rec.Detail = "上班中"
				rec.Status = "open"
			}
			merged = append(merged, sortableRecord{at: checkin, record: rec})
			if checkout.Valid {
				co := checkout.Time.In(loc)
				outRec := AgentTgRecord{
					Time:       co.Format("15:04:05"),
					Event:      shiftLabel(shiftType) + "下班",
					Detail:     "下班打卡",
					Status:     "checkout",
					Source:     src,
					OccurredAt: co.UTC().Format(time.RFC3339),
				}
				merged = append(merged, sortableRecord{at: co, record: outRec})
			}
		}
	}

	actRows, err := s.db.QueryContext(ctx, `
		SELECT id, activity_name, started_at, ended_at, status, elapsed_seconds, fine_amount, COALESCE(source,'')
		FROM wf_tg_activity_sessions
		WHERE employee_id = $1
		  AND (attendance_date = $2::date OR attendance_date = $3::date
		       OR ((started_at AT TIME ZONE $4)::date = $2::date)
		       OR ((started_at AT TIME ZONE $4)::date = $3::date)
		       OR status = 'open')
		ORDER BY started_at DESC
		LIMIT 50`, empID, businessDate, calendarToday, tz)
	if err != nil {
		log.Printf("[AgentDashboard] activity sessions query emp=%s: %v", empID, err)
	} else {
		defer actRows.Close()
		for actRows.Next() {
			var id uuid.UUID
			var actName, source string
			var started time.Time
			var ended sql.NullTime
			var status string
			var elapsed int
			var fine float64
			if actRows.Scan(&id, &actName, &started, &ended, &status, &elapsed, &fine, &source) != nil {
				continue
			}
			started = started.In(loc)
			src := formatAgentRecordSource(source)
			rec := AgentTgRecord{
				Time:       started.Format("15:04:05"),
				Event:      actName,
				Detail:     "开始",
				Status:     "open",
				Source:     src,
				SessionID:  id.String(),
				OccurredAt: started.UTC().Format(time.RFC3339),
			}
			if status == "closed" {
				rec.Status = "closed"
				if elapsed > 0 {
					rec.Detail = formatDurationZh(elapsed)
				} else if ended.Valid {
					rec.Detail = formatDurationZh(int(ended.Time.Sub(started).Seconds()))
				} else {
					rec.Detail = "已结束"
				}
				rec.FineAmount = fine
				out.TodayFineTotal += fine
				endAt := started
				if ended.Valid {
					endAt = ended.Time.In(loc)
				}
				merged = append(merged, sortableRecord{at: endAt, record: rec})
			} else {
				rec.Detail = "进行中"
				merged = append(merged, sortableRecord{at: started, record: rec})
			}
		}
	}

	for i := 0; i < len(merged); i++ {
		for j := i + 1; j < len(merged); j++ {
			if merged[j].at.After(merged[i].at) {
				merged[i], merged[j] = merged[j], merged[i]
			}
		}
	}
	limit := 25
	if len(merged) < limit {
		limit = len(merged)
	}
	for i := 0; i < limit; i++ {
		out.Records = append(out.Records, merged[i].record)
	}

	if types, err := s.ListEnabledActivityTypesForWorker(ctx); err == nil {
		var effectiveChat string
		effectiveChat = s.getChatIDForEmployee(ctx, empID)
		countDate, _, countCycle, countErr := s.resolveActivityBusinessDate(ctx, effectiveChat, empID, shiftType)
		if countErr != nil || strings.TrimSpace(countDate) == "" {
			countDate = businessDate
			countCycle = 1
		}
		out.ActivityTypes = make([]AgentTgActivityType, 0, len(types))
		for _, t := range types {
			item := AgentTgActivityType{
				Code:             t.Code,
				Name:             t.Name,
				TimeLimitSeconds: t.TimeLimitSeconds,
				MaxTimesPerDay:   t.MaxTimesPerDay,
				SortOrder:        t.SortOrder,
			}
			if count, err := s.countActivitiesOnDate(ctx, empID, t.Code, countDate, shiftType, countCycle); err == nil {
				item.TodayCount = count
			}
			out.ActivityTypes = append(out.ActivityTypes, item)
		}
	}

	return out, nil
}

func (s *WorkforceTelegramService) resolveAgentDashboardDate(ctx context.Context, empID uuid.UUID, calendarToday string) string {
	var openDate sql.NullString
	_ = s.db.QueryRowContext(ctx, `
		SELECT attendance_date::text FROM work_sessions
		WHERE employee_id = $1 AND status = 'open'
		ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&openDate)
	if openDate.Valid && strings.TrimSpace(openDate.String) != "" {
		return strings.TrimSpace(openDate.String)
	}
	return calendarToday
}

func formatAgentRecordSource(source string) string {
	switch strings.TrimSpace(strings.ToLower(source)) {
	case "telegram":
		return "TG"
	case "agent":
		return "PC"
	default:
		if strings.TrimSpace(source) == "" {
			return "-"
		}
		return strings.TrimSpace(source)
	}
}

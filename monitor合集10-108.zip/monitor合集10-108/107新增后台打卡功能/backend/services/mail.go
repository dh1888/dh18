package services

import (
	"context"
	"crypto/tls"
	"database/sql"
	"encoding/base64"
	"fmt"
	"log"
	"net"
	"net/smtp"
	"os"
	"strconv"
	"strings"
)

type MailService struct {
	enabled  bool
	host     string
	port     int
	user     string
	password string
	from     string
	fromName string
}

func NewMailService() *MailService {
	enabled := strings.EqualFold(strings.TrimSpace(os.Getenv("SMTP_ENABLED")), "true")
	port, _ := strconv.Atoi(strings.TrimSpace(os.Getenv("SMTP_PORT")))
	if port == 0 {
		port = 587
	}
	from := strings.TrimSpace(os.Getenv("SMTP_FROM"))
	fromName := strings.TrimSpace(os.Getenv("SMTP_FROM_NAME"))
	if fromName == "" {
		fromName = "工资通知"
	}
	host := strings.TrimSpace(os.Getenv("SMTP_HOST"))
	return &MailService{
		enabled:  enabled && host != "" && from != "",
		host:     host,
		port:     port,
		user:     strings.TrimSpace(os.Getenv("SMTP_USER")),
		password: os.Getenv("SMTP_PASSWORD"),
		from:     from,
		fromName: fromName,
	}
}

func (m *MailService) Enabled() bool {
	return m != nil && m.enabled
}

func (m *MailService) Send(_ context.Context, to, subject, body string) error {
	if m == nil || !m.enabled {
		return nil
	}
	to = strings.TrimSpace(to)
	if to == "" || !strings.Contains(to, "@") {
		return nil
	}

	fromHeader := m.from
	if m.fromName != "" {
		fromHeader = fmt.Sprintf("%s <%s>", encodeRFC2047(m.fromName), m.from)
	}

	msg := strings.Join([]string{
		fmt.Sprintf("From: %s", fromHeader),
		fmt.Sprintf("To: %s", to),
		fmt.Sprintf("Subject: %s", encodeRFC2047(subject)),
		"MIME-Version: 1.0",
		"Content-Type: text/plain; charset=UTF-8",
		"Content-Transfer-Encoding: 8bit",
		"",
		body,
	}, "\r\n")

	addr := net.JoinHostPort(m.host, strconv.Itoa(m.port))
	auth := smtp.PlainAuth("", m.user, m.password, m.host)

	if m.port == 465 {
		return m.sendTLS(addr, to, []byte(msg), auth)
	}
	return smtp.SendMail(addr, auth, m.from, []string{to}, []byte(msg))
}

func (m *MailService) sendTLS(addr, to string, msg []byte, auth smtp.Auth) error {
	conn, err := tls.Dial("tcp", addr, &tls.Config{
		ServerName: m.host,
		MinVersion: tls.VersionTLS12,
	})
	if err != nil {
		return err
	}
	defer conn.Close()

	client, err := smtp.NewClient(conn, m.host)
	if err != nil {
		return err
	}
	defer client.Close()

	if auth != nil && m.user != "" {
		if err := client.Auth(auth); err != nil {
			return err
		}
	}
	if err := client.Mail(m.from); err != nil {
		return err
	}
	if err := client.Rcpt(to); err != nil {
		return err
	}
	w, err := client.Data()
	if err != nil {
		return err
	}
	if _, err := w.Write(msg); err != nil {
		_ = w.Close()
		return err
	}
	if err := w.Close(); err != nil {
		return err
	}
	return client.Quit()
}

func (m *MailService) SendSalaryPaidNotification(
	ctx context.Context,
	db *sql.DB,
	employeeUUID, yearMonth, employeeName string,
	totalSalary float64,
) {
	if m == nil || !m.enabled || db == nil {
		return
	}
	to := ResolveEmployeeNotificationEmail(ctx, db, employeeUUID)
	if to == "" {
		return
	}
	monthLabel := formatSalaryMailMonthLabel(yearMonth)
	subject := fmt.Sprintf("工资已发放 - %s", monthLabel)
	body := fmt.Sprintf("%s，您好：\n\n您 %s 的工资已确认发放，实发 ¥%s，请查收。\n\n如有疑问请联系财务或管理员。",
		employeeName, monthLabel, formatSalaryMailMoney(totalSalary))
	if err := m.Send(ctx, to, subject, body); err != nil {
		log.Printf("[Mail] salary paid notification failed emp=%s to=%s: %v", employeeUUID, to, err)
	}
}

func ResolveEmployeeNotificationEmail(ctx context.Context, db *sql.DB, employeeUUID string) string {
	if db == nil || strings.TrimSpace(employeeUUID) == "" {
		return ""
	}
	var notificationEmail, userEmail sql.NullString
	err := db.QueryRowContext(ctx, `
		SELECT COALESCE(NULLIF(TRIM(pa.notification_email), ''), ''),
		       COALESCE(NULLIF(TRIM(u.email), ''), '')
		FROM employees e
		LEFT JOIN employee_payment_accounts pa ON pa.employee_id = e.id
		LEFT JOIN users u ON u.id = e.user_id
		WHERE e.id = $1 AND e.status = 1
	`, employeeUUID).Scan(&notificationEmail, &userEmail)
	if err != nil {
		return ""
	}
	if notificationEmail.Valid && strings.TrimSpace(notificationEmail.String) != "" {
		return strings.TrimSpace(notificationEmail.String)
	}
	if userEmail.Valid && strings.TrimSpace(userEmail.String) != "" {
		return strings.TrimSpace(userEmail.String)
	}
	return ""
}

func encodeRFC2047(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return ""
	}
	for _, r := range value {
		if r > 127 {
			return fmt.Sprintf("=?UTF-8?B?%s?=", base64.StdEncoding.EncodeToString([]byte(value)))
		}
	}
	return value
}

func formatSalaryMailMonthLabel(yearMonth string) string {
	parts := strings.Split(strings.TrimSpace(yearMonth), "-")
	if len(parts) != 2 {
		return yearMonth
	}
	month, err := strconv.Atoi(parts[1])
	if err != nil {
		return yearMonth
	}
	return fmt.Sprintf("%s年%d月", parts[0], month)
}

func formatSalaryMailMoney(amount float64) string {
	return strings.TrimRight(strings.TrimRight(fmt.Sprintf("%.2f", amount), "0"), ".")
}

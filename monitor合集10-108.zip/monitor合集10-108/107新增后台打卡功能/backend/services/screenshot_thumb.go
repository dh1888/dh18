package services

import (
	"fmt"
	"image"
	"image/jpeg"
	_ "image/gif"
	_ "image/png"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"golang.org/x/image/draw"
	_ "golang.org/x/image/webp"
)

const (
	// 略大于网格展示尺寸，避免卡片发糊；体积仍远小于整屏原图
	screenshotThumbMaxEdge = 720
	screenshotThumbQuality = 78
)

var thumbGenLocks sync.Map // string -> *sync.Mutex

// ScreenshotThumbPath returns the on-disk cache path for a screenshot thumbnail.
func ScreenshotThumbPath(originalPath string) string {
	ext := filepath.Ext(originalPath)
	// 文件名带边长，便于日后调参后自动换新缓存，避免沿用旧小图
	return strings.TrimSuffix(originalPath, ext) + "_thumb720.jpg"
}

// EnsureScreenshotThumbnail builds (or reuses) a small JPEG next to the original image.
// Safe for concurrent callers; returns the thumbnail path.
func EnsureScreenshotThumbnail(originalPath string) (string, error) {
	if strings.TrimSpace(originalPath) == "" {
		return "", fmt.Errorf("empty image path")
	}
	thumbPath := ScreenshotThumbPath(originalPath)

	srcInfo, err := os.Stat(originalPath)
	if err != nil {
		return "", err
	}
	if thumbInfo, err := os.Stat(thumbPath); err == nil && !thumbInfo.ModTime().Before(srcInfo.ModTime()) && thumbInfo.Size() > 0 {
		return thumbPath, nil
	}

	lockIface, _ := thumbGenLocks.LoadOrStore(originalPath, &sync.Mutex{})
	lock := lockIface.(*sync.Mutex)
	lock.Lock()
	defer lock.Unlock()

	if thumbInfo, err := os.Stat(thumbPath); err == nil && !thumbInfo.ModTime().Before(srcInfo.ModTime()) && thumbInfo.Size() > 0 {
		return thumbPath, nil
	}

	if err := writeScreenshotThumbnail(originalPath, thumbPath); err != nil {
		return "", err
	}
	return thumbPath, nil
}

// RemoveScreenshotThumbnail deletes the cached thumbnail if present.
func RemoveScreenshotThumbnail(originalPath string) {
	if strings.TrimSpace(originalPath) == "" {
		return
	}
	_ = os.Remove(ScreenshotThumbPath(originalPath))
	// 兼容清理旧版缓存文件名
	ext := filepath.Ext(originalPath)
	_ = os.Remove(strings.TrimSuffix(originalPath, ext) + "_thumb.jpg")
}

func writeScreenshotThumbnail(srcPath, thumbPath string) error {
	f, err := os.Open(srcPath)
	if err != nil {
		return err
	}
	defer f.Close()

	img, _, err := image.Decode(f)
	if err != nil {
		return fmt.Errorf("decode screenshot: %w", err)
	}

	resized := resizeToMaxEdge(img, screenshotThumbMaxEdge)

	tmpPath := thumbPath + ".tmp"
	out, err := os.Create(tmpPath)
	if err != nil {
		return err
	}

	encodeErr := jpeg.Encode(out, resized, &jpeg.Options{Quality: screenshotThumbQuality})
	closeErr := out.Close()
	if encodeErr != nil {
		_ = os.Remove(tmpPath)
		return encodeErr
	}
	if closeErr != nil {
		_ = os.Remove(tmpPath)
		return closeErr
	}

	if err := os.Rename(tmpPath, thumbPath); err != nil {
		_ = os.Remove(tmpPath)
		return err
	}
	return nil
}

func resizeToMaxEdge(src image.Image, maxEdge int) image.Image {
	b := src.Bounds()
	w, h := b.Dx(), b.Dy()
	if w <= 0 || h <= 0 {
		return src
	}
	if w <= maxEdge && h <= maxEdge {
		return src
	}

	var nw, nh int
	if w >= h {
		nw = maxEdge
		nh = max(1, h*maxEdge/w)
	} else {
		nh = maxEdge
		nw = max(1, w*maxEdge/h)
	}

	dst := image.NewRGBA(image.Rect(0, 0, nw, nh))
	draw.CatmullRom.Scale(dst, dst.Bounds(), src, b, draw.Over, nil)
	return dst
}

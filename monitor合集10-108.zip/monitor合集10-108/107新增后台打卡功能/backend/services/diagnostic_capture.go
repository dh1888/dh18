package services

import (
	"context"
	"time"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

func (s *DiagnosticService) StoreAgentSnapshot(deviceID string, payload map[string]interface{}) {
	if deviceID == "" || payload == nil {
		return
	}
	s.agentSnapMu.Lock()
	s.agentSnaps[deviceID] = agentSnapshotEntry{payload: payload, received: time.Now()}
	s.agentSnapMu.Unlock()
}

func (s *DiagnosticService) GetAgentSnapshots(deviceIDs []string) map[string]interface{} {
	out := map[string]interface{}{}
	cutoff := time.Now().Add(-2 * time.Minute)
	s.agentSnapMu.RLock()
	defer s.agentSnapMu.RUnlock()
	if len(deviceIDs) == 0 {
		for id, entry := range s.agentSnaps {
			if entry.received.After(cutoff) {
				out[id] = entry.payload
			}
		}
		return out
	}
	for _, id := range deviceIDs {
		if entry, ok := s.agentSnaps[id]; ok && entry.received.After(cutoff) {
			out[id] = entry.payload
		}
	}
	return out
}

func (s *DiagnosticService) RequestAgentSnapshots(deviceIDs []string) {
	if s.wsHub == nil {
		return
	}
	for _, deviceID := range deviceIDs {
		if !s.wsHub.IsAgentOnline(deviceID) {
			continue
		}
		s.wsHub.SendCommandToDevice(deviceID, "collect_diagnostics", nil)
	}
}

func (s *DiagnosticService) Capture(ctx context.Context, req models.DiagnosticCaptureRequest) (*models.DiagnosticCaptureResult, error) {
	window := req.WindowMinutes
	if window <= 0 {
		window = 60
	}

	snapshot, err := s.BuildSnapshot(ctx)
	if err != nil {
		return nil, err
	}

	if req.IncludeAgents && len(req.DeviceIDs) > 0 {
		s.RequestAgentSnapshots(req.DeviceIDs)
		time.Sleep(1200 * time.Millisecond)
	}

	result := &models.DiagnosticCaptureResult{
		CaptureID:   uuid.New().String(),
		GeneratedAt: models.UTCNow(),
		Snapshot:    *snapshot,
		AgentSnaps:  s.GetAgentSnapshots(req.DeviceIDs),
		Pipelines:   []models.DiagnosticPipeline{},
	}

	if req.IncludeAnalysis {
		analysis, err := s.Analyze(ctx, "", window)
		if err == nil {
			result.Analysis = analysis
		}
		for _, deviceID := range req.DeviceIDs {
			if pipe, err := s.BuildPipeline(ctx, deviceID); err == nil {
				result.Pipelines = append(result.Pipelines, *pipe)
			}
		}
	}

	q := DiagnosticEventQuery{Page: 1, PageSize: 5000}
	since := models.UTCNow().Add(-time.Duration(window) * time.Minute)
	q.From = &since
	if len(req.DeviceIDs) == 1 {
		q.DeviceID = req.DeviceIDs[0]
	}
	events, _, _ := s.ListEvents(ctx, q)
	result.EventCount = len(events)

	return result, nil
}

func (s *DiagnosticService) ExportCaptureBundle(ctx context.Context, req models.DiagnosticCaptureRequest) ([]byte, string, error) {
	capture, err := s.Capture(ctx, req)
	if err != nil {
		return nil, "", err
	}

	q := DiagnosticEventQuery{Page: 1, PageSize: 5000}
	if window := req.WindowMinutes; window > 0 {
		since := models.UTCNow().Add(-time.Duration(window) * time.Minute)
		q.From = &since
	}
	if len(req.DeviceIDs) == 1 {
		q.DeviceID = req.DeviceIDs[0]
	}

	return s.exportBundleWithCapture(ctx, q, capture)
}

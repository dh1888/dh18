package services

import (
	"context"
	"encoding/json"
	"log"
	"time"

	"github.com/google/uuid"
)

const sessionTombstoneTTL = 24 * time.Hour

type sessionTombstonePayload struct {
	Status string `json:"status"`
	Reason string `json:"reason,omitempty"`
}

func sessionTombstoneKey(id string) string { return "sess:tomb:" + id }

func (s *SessionService) writeSessionTombstone(ctx context.Context, sessionID, status, reason string) {
	if s == nil || s.redis == nil || sessionID == "" {
		return
	}
	payload, err := json.Marshal(sessionTombstonePayload{
		Status: status,
		Reason: reason,
	})
	if err != nil {
		return
	}
	tombCtx, cancel := context.WithTimeout(ctx, 3*time.Second)
	defer cancel()
	if err := s.redis.Set(tombCtx, sessionTombstoneKey(sessionID), payload, sessionTombstoneTTL).Err(); err != nil {
		log.Printf("[Session] tombstone write failed session=%s: %v", sessionID, err)
	}
}

func (s *SessionService) loadSessionTombstone(ctx context.Context, sessionID string) (*AuthSession, bool) {
	if s == nil || s.redis == nil || sessionID == "" {
		return nil, false
	}
	raw, err := s.redis.Get(ctx, sessionTombstoneKey(sessionID)).Bytes()
	if err != nil {
		return nil, false
	}
	var payload sessionTombstonePayload
	if err := json.Unmarshal(raw, &payload); err != nil {
		return nil, false
	}
	parsedID, err := uuid.Parse(sessionID)
	if err != nil {
		return nil, false
	}
	switch payload.Status {
	case SessionStatusRevoked, SessionStatusExpired:
		return &AuthSession{
			ID:           parsedID,
			Status:       payload.Status,
			RevokeReason: payload.Reason,
		}, true
	default:
		return nil, false
	}
}

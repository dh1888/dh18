package services

import (
	"context"
	"fmt"
	"strings"

	"github.com/google/uuid"
)

const archiveWorkSessionsInsertSQL = `
		INSERT INTO work_sessions_archive (
			id, employee_id, attendance_date, device_id,
			checkin_time, checkout_time, status, recording_id,
			source, shift_type, shift_detail, source_chat_id,
			created_at, updated_at, archived_at
		)
		SELECT
			ws.id, ws.employee_id, ws.attendance_date, ws.device_id,
			ws.checkin_time, ws.checkout_time, ws.status, ws.recording_id,
			ws.source, COALESCE(ws.shift_type,'day'), ws.shift_detail, ws.source_chat_id,
			ws.created_at, ws.updated_at, NOW()
		FROM work_sessions ws
		WHERE %s
		ON CONFLICT (id) DO NOTHING`

func (s *WorkforceTelegramService) archiveClosedWorkSessionsByGroupDate(ctx context.Context, tx execContext, chatID, exportDate string) error {
	chatID = strings.TrimSpace(chatID)
	exportDate = strings.TrimSpace(exportDate)
	if chatID == "" || exportDate == "" {
		return nil
	}
	where := `ws.source IN ('telegram','agent','web') AND ws.status = 'closed'
		AND ws.attendance_date = $2::date
		AND (` + tgGroupEmployeeBelongsToChatSQL("ws.employee_id", "$1") + ` OR COALESCE(ws.source_chat_id,'') = $1)`
	_, err := tx.ExecContext(ctx, fmt.Sprintf(archiveWorkSessionsInsertSQL, where), chatID, exportDate)
	return err
}

func (s *WorkforceTelegramService) archiveWorkSessionsByEmployeeDate(ctx context.Context, tx execContext, employeeID uuid.UUID, attendanceDate string) error {
	if employeeID == uuid.Nil || strings.TrimSpace(attendanceDate) == "" {
		return nil
	}
	where := `ws.attendance_date = $2::date AND ws.employee_id = $1`
	_, err := tx.ExecContext(ctx, fmt.Sprintf(archiveWorkSessionsInsertSQL, where), employeeID, attendanceDate)
	return err
}

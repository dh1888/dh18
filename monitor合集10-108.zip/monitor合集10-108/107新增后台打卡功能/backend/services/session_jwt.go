package services

import (
	"errors"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"enterprise-agent/backend/models"
)

const userAccessTokenTTL = 24 * time.Hour
const deviceAccessTokenTTL = 7 * 24 * time.Hour
const refreshTokenTTL = 7 * 24 * time.Hour

func UserAccessTokenTTL() time.Duration  { return userAccessTokenTTL }
func DeviceAccessTokenTTL() time.Duration { return deviceAccessTokenTTL }
func RefreshTokenTTL() time.Duration     { return refreshTokenTTL }

var (
	ErrInvalidSessionJWT = errors.New("invalid session jwt")
	ErrMissingSessionID  = errors.New("missing session id in jwt")
)

// SignSessionJWT issues a JWT containing only sid (session_id).
func SignSessionJWT(sessionID string, expiresAt time.Time) (string, error) {
	if sessionID == "" {
		return "", ErrMissingSessionID
	}
	claims := &models.SessionJWTClaims{
		SID: sessionID,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expiresAt),
			IssuedAt:  jwt.NewNumericDate(models.UTCNow()),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	secret := models.JWTSecret()
	if len(secret) == 0 {
		return "", jwt.ErrInvalidKey
	}
	return token.SignedString(secret)
}

// ParseSessionJWT validates signature/expiry and returns sid.
func ParseSessionJWT(tokenString string) (string, error) {
	secret := models.JWTSecret()
	if len(secret) == 0 {
		return "", jwt.ErrInvalidKey
	}
	claims := &models.SessionJWTClaims{}
	token, err := jwt.ParseWithClaims(tokenString, claims, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, jwt.ErrSignatureInvalid
		}
		return secret, nil
	}, jwt.WithValidMethods([]string{jwt.SigningMethodHS256.Name}))
	if err != nil {
		return "", err
	}
	if !token.Valid || claims.SID == "" {
		return "", ErrInvalidSessionJWT
	}
	return claims.SID, nil
}

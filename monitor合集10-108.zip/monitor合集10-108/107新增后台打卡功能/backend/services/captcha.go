package services

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"image"
	"image/color"
	"image/png"
	"bytes"
	"math/big"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
)

const captchaRedisPrefix = "login:captcha:"
const captchaTTL = 5 * time.Minute

type CaptchaService struct {
	redis *redis.Client
	mem   sync.Map // id -> captchaEntry
}

type captchaEntry struct {
	code   string
	expiry time.Time
}

func NewCaptchaService(redisClient *redis.Client) *CaptchaService {
	return &CaptchaService{redis: redisClient}
}

func (s *CaptchaService) Issue(ctx context.Context) (id, imageBase64 string, err error) {
	code, err := randomCaptchaCode(4)
	if err != nil {
		return "", "", err
	}
	id = uuid.NewString()
	if s.redis != nil {
		if err := s.redis.Set(ctx, captchaRedisPrefix+id, strings.ToLower(code), captchaTTL).Err(); err != nil {
			return "", "", err
		}
	} else {
		s.mem.Store(id, captchaEntry{code: strings.ToLower(code), expiry: time.Now().Add(captchaTTL)})
	}
	img, err := renderCaptchaPNG(code)
	if err != nil {
		return "", "", err
	}
	return id, base64.StdEncoding.EncodeToString(img), nil
}

func (s *CaptchaService) Verify(ctx context.Context, id, code string) bool {
	id = strings.TrimSpace(id)
	code = strings.TrimSpace(strings.ToLower(code))
	if id == "" || code == "" {
		return false
	}
	if s.redis != nil {
		key := captchaRedisPrefix + id
		val, err := s.redis.Get(ctx, key).Result()
		if err != nil {
			return false
		}
		if strings.ToLower(val) != code {
			return false
		}
		_ = s.redis.Del(ctx, key).Err()
		return true
	}
	raw, ok := s.mem.Load(id)
	if !ok {
		return false
	}
	entry := raw.(captchaEntry)
	if time.Now().After(entry.expiry) {
		s.mem.Delete(id)
		return false
	}
	if entry.code != code {
		return false
	}
	s.mem.Delete(id)
	return true
}

func randomCaptchaCode(length int) (string, error) {
	// 仅数字：每种字符在图片中有独立字形，避免字母共用同一方块导致无法辨认
	const chars = "23456789"
	out := make([]byte, length)
	for i := range out {
		n, err := rand.Int(rand.Reader, big.NewInt(int64(len(chars))))
		if err != nil {
			return "", err
		}
		out[i] = chars[n.Int64()]
	}
	return string(out), nil
}

func renderCaptchaPNG(code string) ([]byte, error) {
	const w, h = 120, 42
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			img.Set(x, y, color.RGBA{245, 247, 250, 255})
		}
	}
	n := len(code)
	if n == 0 {
		n = 1
	}
	slotW := w / n
	for i, ch := range code {
		x0 := i*slotW + (slotW-16)/2
		if x0 < 4 {
			x0 = 4
		}
		drawCharBlock(img, x0, 10, byte(ch))
	}
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func drawCharBlock(img *image.RGBA, x0, y0 int, ch byte) {
	pattern := charPattern(ch)
	for row, line := range pattern {
		for col, bit := range line {
			if bit == '1' {
				for dx := 0; dx < 2; dx++ {
					for dy := 0; dy < 2; dy++ {
						img.Set(x0+col*2+dx, y0+row*2+dy, color.RGBA{40, 60, 120, 255})
					}
				}
			}
		}
	}
}

func charPattern(ch byte) []string {
	digits := map[byte][]string{
		'2': {"0110", "1001", "0010", "0100", "1111"},
		'3': {"1110", "0010", "0110", "0010", "1110"},
		'4': {"1001", "1001", "1111", "0010", "0010"},
		'5': {"1111", "1000", "1110", "0001", "1110"},
		'6': {"0110", "1000", "1110", "1001", "0110"},
		'7': {"1111", "0010", "0100", "0100", "0100"},
		'8': {"0110", "1001", "0110", "1001", "0110"},
		'9': {"0110", "1001", "0111", "0001", "0110"},
	}
	if p, ok := digits[ch]; ok {
		return p
	}
	if ch >= 'A' && ch <= 'Z' {
		return []string{"0110", "1001", "1001", "1001", "0110"}
	}
	return []string{"1111", "1001", "1001", "1001", "1111"}
}

func (s *CaptchaService) PingRedis(ctx context.Context) error {
	if s.redis == nil {
		return fmt.Errorf("redis unavailable")
	}
	return s.redis.Ping(ctx).Err()
}

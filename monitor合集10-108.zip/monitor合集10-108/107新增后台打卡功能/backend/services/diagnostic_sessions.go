package services

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"enterprise-agent/backend/models"
)

func (s *DiagnosticService) ListSessionGroups(ctx context.Context, deviceID string, limit int) ([]models.DiagnosticSessionGroup, error) {
	if limit <= 0 || limit > 100 {
		limit = 30
	}
	since := models.UTCNow().Add(-24 * time.Hour)
	args := []interface{}{since}
	deviceClause := ""
	if strings.TrimSpace(deviceID) != "" {
		deviceClause = " AND device_id = $2"
		args = append(args, deviceID)
	}
	query := fmt.Sprintf(`
		SELECT COALESCE(NULLIF(correlation_id, ''), id::text) AS session_key,
		       MIN(created_at) AS started_at,
		       MAX(created_at) AS ended_at,
		       COUNT(*) AS event_count,
		       MAX(device_id::text) AS device_id,
		       MAX(CASE WHEN level = 'ERROR' THEN message ELSE '' END) AS err_msg
		FROM diagnostic_events
		WHERE created_at >= $1%s
		GROUP BY session_key
		ORDER BY ended_at DESC
		LIMIT %d
	`, deviceClause, limit)

	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	groups := []models.DiagnosticSessionGroup{}
	for rows.Next() {
		var sessionKey string
		var startedAt, endedAt time.Time
		var eventCount int
		var devID sql.NullString
		var errMsg string
		if err := rows.Scan(&sessionKey, &startedAt, &endedAt, &eventCount, &devID, &errMsg); err != nil {
			continue
		}
		group := models.DiagnosticSessionGroup{
			SessionID:   sessionKey,
			DeviceID:    devID.String,
			StartedAt:   models.FormatUTC(startedAt),
			EndedAt:     models.FormatUTC(endedAt),
			DurationSec: int(endedAt.Sub(startedAt).Seconds()),
			EventCount:  eventCount,
			Status:      "success",
		}
		if errMsg != "" {
			group.Status = "failed"
			group.Reason = errMsg
		}
		groups = append(groups, group)
	}
	return groups, nil
}

func (s *DiagnosticService) GetSessionGroup(ctx context.Context, sessionID string) (*models.DiagnosticSessionGroup, error) {
	sessionID = strings.TrimSpace(sessionID)
	if sessionID == "" {
		return nil, fmt.Errorf("sessionId is required")
	}

	rows, err := s.db.QueryContext(ctx, `
		SELECT created_at, level, module, message, device_id::text
		FROM diagnostic_events
		WHERE correlation_id = $1 OR id::text = $1
		ORDER BY created_at ASC
		LIMIT 500
	`, sessionID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	group := &models.DiagnosticSessionGroup{SessionID: sessionID, Status: "success"}
	var startedAt, endedAt time.Time
	for rows.Next() {
		var createdAt time.Time
		var level, module, message string
		var devID sql.NullString
		if err := rows.Scan(&createdAt, &level, &module, &message, &devID); err != nil {
			continue
		}
		if group.StartedAt == "" {
			startedAt = createdAt
			group.StartedAt = models.FormatUTC(createdAt)
		}
		endedAt = createdAt
		group.EndedAt = models.FormatUTC(createdAt)
		if devID.Valid && group.DeviceID == "" {
			group.DeviceID = devID.String
		}
		group.Events = append(group.Events, models.DiagnosticEventBrief{
			CreatedAt: models.FormatUTC(createdAt),
			Level:     level,
			Module:    module,
			Message:   message,
		})
		if level == "ERROR" {
			group.Status = "failed"
			group.Reason = message
		}
	}
	if len(group.Events) == 0 {
		return nil, fmt.Errorf("session not found")
	}
	group.EventCount = len(group.Events)
	group.DurationSec = int(endedAt.Sub(startedAt).Seconds())
	return group, nil
}

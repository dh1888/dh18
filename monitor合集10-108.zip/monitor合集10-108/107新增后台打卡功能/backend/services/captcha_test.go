package services

import (
	"context"
	"testing"
)

func TestCaptchaVerifyWrongCodeKeepsTicket(t *testing.T) {
	svc := NewCaptchaService(nil)
	ctx := context.Background()

	id, _, err := svc.Issue(ctx)
	if err != nil {
		t.Fatalf("issue: %v", err)
	}
	code := readMemCode(t, svc, id)
	if svc.Verify(ctx, id, "0000") {
		t.Fatal("wrong code should not verify")
	}
	if !svc.Verify(ctx, id, code) {
		t.Fatal("correct code should verify after a wrong attempt")
	}
}

func readMemCode(t *testing.T, svc *CaptchaService, id string) string {
	t.Helper()
	raw, ok := svc.mem.Load(id)
	if !ok {
		t.Fatal("captcha entry missing")
	}
	return raw.(captchaEntry).code
}

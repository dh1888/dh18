package main

import (
	"encoding/json"
	"fmt"
	"os"

	"enterprise-agent/backend/security"
)

// Quick local check: POLICY_SIGNING_* env must be set.
// Usage (from backend/):
//
//	set POLICY_SIGNING_KEY_ID=2026-07
//	set POLICY_SIGNING_PRIVATE_KEY_PATH=./secrets/policy-ed25519.pem
//	go run ./cmd/verifyproductionpolicy
func main() {
	content := `{"version":1,"config":{"recording":{"enabled":true,"fps":5}}}`
	if len(os.Args) > 1 {
		content = os.Args[1]
	}

	signed, err := security.SignPolicyContent(content)
	if err != nil {
		fmt.Fprintf(os.Stderr, "sign failed: %v\n", err)
		os.Exit(1)
	}

	out, _ := json.MarshalIndent(map[string]any{
		"signatureAlg":     signed.SignatureAlg,
		"signatureVersion": signed.SignatureVersion,
		"keyId":            signed.KeyID,
		"signaturePrefix":  truncate(signed.Signature, 32),
		"policy":           signed.Policy,
	}, "", "  ")
	fmt.Println(string(out))
	fmt.Println("OK: local Backend signer produces V2.1 Ed25519 envelope")
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

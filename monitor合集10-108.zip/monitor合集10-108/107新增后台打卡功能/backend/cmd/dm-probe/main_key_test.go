package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestSaveLoadNodeKey(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "dm-node.key")
	want := "test-api-key-abc"

	if err := saveNodeKey(path, want); err != nil {
		t.Fatalf("saveNodeKey: %v", err)
	}
	got, err := loadNodeKey(path)
	if err != nil {
		t.Fatalf("loadNodeKey: %v", err)
	}
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}

	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode().Perm()&0o077 != 0 {
		// Windows may not honor 0600; only assert on Unix-like
		if filepath.Separator == '/' && info.Mode().Perm() != 0o600 {
			t.Fatalf("perm=%v want 0600", info.Mode().Perm())
		}
	}
}

using System.Net;

namespace EnterpriseAgent.Agent.Infrastructure;

/// <summary>
/// 控制 Agent 出站是否跟随系统代理 / VPN 客户端注入的 HTTP 代理。
/// TUN 型全局 VPN 需在 VPN 软件中对监控服务器做分流或排除进程，本开关无法单独绕过 IP 层隧道。
/// </summary>
public sealed class AgentNetworkSettings
{
    /// <summary>
    /// true：HTTP/WS 不使用系统代理，尽量直连 ServerUrl（适合「电脑开 VPN，监控仍走本地宽带访问公网服务器」）。
    /// false：跟随 Windows 系统代理与 .NET 默认行为（与 VPN 全局代理一致时走 VPN）。
    /// </summary>
    public bool ForceDirectConnection { get; set; }

    public static AgentNetworkSettings From(bool forceDirect) => new() { ForceDirectConnection = forceDirect };

    /// <summary>IWebProxy：对所有目标返回直连。</summary>
    public static IWebProxy DirectProxy { get; } = new DirectConnectionProxy();

    private sealed class DirectConnectionProxy : IWebProxy
    {
        public ICredentials? Credentials { get; set; }

        public Uri? GetProxy(Uri destination) => destination;

        public bool IsBypassed(Uri host) => true;
    }
}

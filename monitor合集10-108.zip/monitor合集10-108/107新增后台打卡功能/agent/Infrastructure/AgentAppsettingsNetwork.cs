using System.Text.Json;
using System.Text.Json.Nodes;

namespace EnterpriseAgent.Agent.Infrastructure;

/// <summary>
/// 读写 exe 同目录 appsettings.json 中的 Network.ForceDirectConnection。
/// </summary>
public static class AgentAppsettingsNetwork
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    public static string GetAppsettingsPath()
        => Path.Combine(AppContext.BaseDirectory, "appsettings.json");

    public static bool TryReadForceDirectConnection(out bool forceDirect)
    {
        forceDirect = true;
        var path = GetAppsettingsPath();
        if (!File.Exists(path))
            return false;

        try
        {
            var root = JsonNode.Parse(File.ReadAllText(path)) as JsonObject;
            if (root?["Network"] is not JsonObject network)
                return false;
            if (network["ForceDirectConnection"] is JsonValue value && value.TryGetValue<bool>(out var parsed))
            {
                forceDirect = parsed;
                return true;
            }
            return false;
        }
        catch
        {
            return false;
        }
    }

    public static bool TryWriteForceDirectConnection(bool forceDirect, out string? error)
    {
        error = null;
        var path = GetAppsettingsPath();
        try
        {
            JsonObject root;
            if (File.Exists(path))
            {
                root = JsonNode.Parse(File.ReadAllText(path)) as JsonObject ?? new JsonObject();
            }
            else
            {
                root = new JsonObject();
            }

            if (root["Network"] is not JsonObject network)
            {
                network = new JsonObject();
                root["Network"] = network;
            }

            network["ForceDirectConnection"] = forceDirect;
            root.Remove("_说明");
            if (network["_说明"] != null)
            {
                // 保留 Network 段说明若已有
            }

            File.WriteAllText(path, root.ToJsonString(JsonOptions));
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }
}

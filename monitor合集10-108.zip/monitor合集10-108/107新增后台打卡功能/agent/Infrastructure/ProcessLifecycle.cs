using System.Diagnostics;
using System.Management;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 统一应用数据目录（与 Program 中 Serilog 日志路径一致）
/// </summary>
public static class AppPaths
{
    private const string AppDataFolder = "EnterpriseAgent";

    public static string GetAppDataPath()
    {
        var path = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            AppDataFolder);
        Directory.CreateDirectory(path);
        return path;
    }

    public static string GetLogsPath()
    {
        var path = Path.Combine(GetAppDataPath(), "logs");
        Directory.CreateDirectory(path);
        return path;
    }
}

/// <summary>
/// 用户从托盘主动退出时写入标记；守护进程检测到主进程已退出后自行停止。
/// 用户手动双击 DHPG.exe 启动时会清除标记。
/// </summary>
internal static class VoluntaryShutdownMarker
{
    private static string MarkerPath
        => Path.Combine(AppPaths.GetAppDataPath(), "voluntary_exit.marker");

    public static void Mark()
    {
        try
        {
            File.WriteAllText(MarkerPath, DateTime.UtcNow.ToString("O"));
        }
        catch
        {
            // 标记失败不阻断退出
        }
    }

    public static void Clear()
    {
        try
        {
            if (File.Exists(MarkerPath))
                File.Delete(MarkerPath);
        }
        catch
        {
            // ignore
        }
    }

    public static bool IsActive()
    {
        try
        {
            if (!File.Exists(MarkerPath))
                return false;

            // 主动退出仅对「本次开机会话」有效；重启/关机后再开机不应继续阻止登录自启。
            var markerUtc = File.GetLastWriteTimeUtc(MarkerPath);
            var bootUtc = DateTime.UtcNow - TimeSpan.FromMilliseconds(Environment.TickCount64);
            if (markerUtc < bootUtc)
            {
                Clear();
                return false;
            }

            return true;
        }
        catch
        {
            return false;
        }
    }
}

/// <summary>
/// Captures how the UI process was launched so startup notifications can be shown selectively.
/// </summary>
internal static class LaunchContext
{
    public static bool ReopenAfterVoluntaryExit { get; private set; }
    public static bool UserInitiated { get; private set; }
    public static bool StartupNotifyRequested { get; private set; }

    public static bool ShouldShowStartupToast =>
        ReopenAfterVoluntaryExit || UserInitiated || StartupNotifyRequested;

    public static void CaptureFromCurrentProcess(IReadOnlyList<string>? args = null, bool directUserLaunch = false)
    {
        ReopenAfterVoluntaryExit = VoluntaryShutdownMarker.IsActive();
        UserInitiated = directUserLaunch || ProcessLaunchDetector.IsUserInitiatedLaunch();
        StartupNotifyRequested = args != null
                                 && args.Contains(
                                     HiddenLauncherFiles.StartupNotifyArgument,
                                     StringComparer.OrdinalIgnoreCase);
    }

    public static void Reset()
    {
        ReopenAfterVoluntaryExit = false;
        UserInitiated = false;
        StartupNotifyRequested = false;
    }
}

internal static class ProcessLaunchDetector
{
    public static bool IsUserInitiatedLaunch()
    {
        try
        {
            using var current = Process.GetCurrentProcess();
            var parentId = TryGetParentProcessId(current.Id);
            if (parentId <= 0)
                return false;

            using var parent = Process.GetProcessById(parentId);
            var name = parent.ProcessName;
            return name.Equals("explorer", StringComparison.OrdinalIgnoreCase)
                   || name.Equals("cmd", StringComparison.OrdinalIgnoreCase)
                   || name.Equals("powershell", StringComparison.OrdinalIgnoreCase)
                   || name.Equals("pwsh", StringComparison.OrdinalIgnoreCase)
                   || name.Equals("WindowsTerminal", StringComparison.OrdinalIgnoreCase)
                   || name.Equals("SearchHost", StringComparison.OrdinalIgnoreCase)
                   || name.Equals("StartMenuExperienceHost", StringComparison.OrdinalIgnoreCase)
                   || name.Equals("ShellExperienceHost", StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    private static int TryGetParentProcessId(int processId)
    {
        try
        {
            using var searcher = new ManagementObjectSearcher(
                $"SELECT ParentProcessId FROM Win32_Process WHERE ProcessId = {processId}");
            foreach (ManagementObject obj in searcher.Get())
                return Convert.ToInt32(obj["ParentProcessId"]);
        }
        catch
        {
            // WMI unavailable
        }

        return 0;
    }
}

/// <summary>
/// 尽早隐藏/脱离控制台，避免 WinExe 启动或从终端拉起时出现黑窗一闪。
/// </summary>
internal static class ConsoleWindowSuppressor
{
    private const int SwHide = 0;
    private const int AttachParentProcess = -1;

    [DllImport("kernel32.dll")]
    private static extern IntPtr GetConsoleWindow();

    [DllImport("kernel32.dll")]
    private static extern bool FreeConsole();

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool AttachConsole(int dwProcessId);

    [DllImport("user32.dll")]
    private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [ModuleInitializer]
    internal static void Initialize()
    {
        Suppress();
    }

    internal static void Suppress()
    {
        try
        {
            AttachConsole(AttachParentProcess);
        }
        catch
        {
            // 无父控制台时忽略
        }

        var handle = GetConsoleWindow();
        if (handle != IntPtr.Zero)
            ShowWindow(handle, SwHide);
        FreeConsole();
    }
}

/// <summary>
/// 通过 wscript + VBS 无窗口启动 DHPG（主进程 / 看门狗），避免计划任务与进程拉起时黑屏一闪。
/// </summary>
internal static class HiddenLauncherFiles
{
    public const string StartVbsFileName = "dhpg-start.vbs";
    public const string GuardianVbsFileName = "dhpg-guardian.vbs";
    public const string WatchdogVbsFileName = "dhpg-watchdog.vbs";

    /// <summary>由 VBS 无窗口拉起主界面进程时携带，区分用户直接双击 exe 的引导进程。</summary>
    public const string UiLaunchArgument = "--ui";

    /// <summary>守护进程首次拉起主界面时携带，用于显示登录自启动提示。</summary>
    public const string StartupNotifyArgument = "--startup-notify";

    /// <summary>用户会话内常驻守护进程，监控并静默拉起主界面。</summary>
    public const string GuardianLaunchArgument = "--guardian";

    public static string GetStartVbsPath(string exePath)
        => GetVbsPath(exePath, StartVbsFileName);

    public static string GetGuardianVbsPath(string exePath)
        => GetVbsPath(exePath, GuardianVbsFileName);

    public static string GetWatchdogVbsPath(string exePath)
        => GetVbsPath(exePath, WatchdogVbsFileName);

    public static void EnsureStartVbs(string exePath)
        => EnsureVbsScript(exePath, StartVbsFileName, UiLaunchArgument);

    public static void EnsureGuardianVbs(string exePath)
    {
        var vbsPath = GetVbsPath(exePath, GuardianVbsFileName);
        var markerPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "EnterpriseAgent",
            "voluntary_exit.marker");
        var escapedExe = exePath.Replace("\"", "\"\"");
        var escapedMarker = markerPath.Replace("\"", "\"\"");
        var content =
            $"' DHPG hidden launcher (auto-generated){Environment.NewLine}" +
            $"Set fso = CreateObject(\"Scripting.FileSystemObject\"){Environment.NewLine}" +
            $"marker = \"{escapedMarker}\"{Environment.NewLine}" +
            $"If fso.FileExists(marker) Then fso.DeleteFile marker, True{Environment.NewLine}" +
            $"exe = \"{escapedExe}\"{Environment.NewLine}" +
            $"CreateObject(\"Wscript.Shell\").Run Chr(34) & exe & Chr(34) & \" {GuardianLaunchArgument}\", 0, False{Environment.NewLine}";
        File.WriteAllText(vbsPath, content);
    }

    public static void EnsureWatchdogVbs(string exePath)
        => EnsureVbsScript(exePath, WatchdogVbsFileName, AgentProcessLauncher.EnsureRunningArgument);

    public static void LaunchMainAgentHidden(string exePath, bool showStartupNotify = false)
    {
        // 守护/自愈拉起主界面：最小化启动（勿用 WindowStyle.Hidden，否则托盘可能无法初始化）
        var arguments = UiLaunchArgument;
        if (showStartupNotify)
            arguments += " " + StartupNotifyArgument;

        Process.Start(new ProcessStartInfo
        {
            FileName = exePath,
            Arguments = arguments,
            UseShellExecute = true,
            WindowStyle = ProcessWindowStyle.Minimized,
        });
    }

    public static void LaunchGuardianHidden(string exePath)
    {
        EnsureGuardianVbs(exePath);
        LaunchVbsHidden(GetGuardianVbsPath(exePath));
    }

    public static string GetWscriptPath()
        => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "wscript.exe");

    public static string BuildWscriptArguments(string vbsPath)
        => $"//B //Nologo \"{vbsPath}\"";

    private static string GetVbsPath(string exePath, string fileName)
    {
        // Do not place generated launchers beside the executable.  The agent may
        // be installed under Program Files, where a normal user cannot update
        // files even though HKCU Run and a per-user scheduled task are allowed.
        // LocalAppData remains writable for the account that owns the auto-start
        // entry and survives executable updates/moves.
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "EnterpriseAgent",
            "launchers");
        Directory.CreateDirectory(dir);
        return Path.Combine(dir, fileName);
    }

    private static void EnsureVbsScript(string exePath, string fileName, string? arguments, int windowStyle = 0)
    {
        var vbsPath = GetVbsPath(exePath, fileName);
        // VBScript strings use double quotes; single quote (') starts a line comment.
        var escapedExe = exePath.Replace("\"", "\"\"");
        var argSuffix = string.IsNullOrWhiteSpace(arguments) ? "" : " " + arguments;
        var content =
            $"' DHPG hidden launcher (auto-generated){Environment.NewLine}" +
            $"exe = \"{escapedExe}\"{Environment.NewLine}" +
            $"CreateObject(\"Wscript.Shell\").Run Chr(34) & exe & Chr(34) & \"{argSuffix}\", {windowStyle}, False{Environment.NewLine}";

        File.WriteAllText(vbsPath, content);
    }

    private static void LaunchVbsHidden(string vbsPath)
    {
        Process.Start(new ProcessStartInfo
        {
            FileName = GetWscriptPath(),
            Arguments = BuildWscriptArguments(vbsPath),
            UseShellExecute = false,
            CreateNoWindow = true,
            WindowStyle = ProcessWindowStyle.Hidden
        });
    }
}

/// <summary>
/// 计划任务公共操作（查询 / 创建 / 删除），供开机自启与看门狗复用。
/// </summary>
internal static class ScheduledTaskHelper
{
    public static string? LastOperationError { get; private set; }
    public static string GetCurrentTaskUserId()
    {
        try
        {
            using var identity = WindowsIdentity.GetCurrent();
            if (!string.IsNullOrWhiteSpace(identity.Name))
                return identity.Name;
        }
        catch
        {
            // ignore
        }

        return Environment.UserName;
    }

    public static string BuildPrincipalXml()
    {
        var userId = EscapeXml(GetCurrentTaskUserId());
        return $"""
                  <Principal id="Author">
                    <UserId>{userId}</UserId>
                    <LogonType>InteractiveToken</LogonType>
                    <RunLevel>LeastPrivilege</RunLevel>
                  </Principal>
            """;
    }

    public static bool TaskMatches(string taskName, string exePath, string? expectedArguments, ILogger? logger = null)
    {
        var output = QueryTaskOutput(taskName);
        if (output == null)
            return false;

        if (!ReferencesExecutable(output, exePath))
            return false;

        if (expectedArguments != null && !output.Contains(expectedArguments, StringComparison.OrdinalIgnoreCase))
            return false;

        return true;
    }

    public static string? QueryTaskOutput(string taskName)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = "schtasks.exe",
                Arguments = $"/Query /TN \"{taskName}\" /FO LIST /V",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                // schtasks writes localized text using the Windows ANSI code
                // page.  UTF-8 corrupts Chinese task names/paths and makes the
                // task status parser fail on Chinese Windows installations.
                StandardOutputEncoding = Encoding.Default,
                StandardErrorEncoding = Encoding.Default
            };

            using var process = Process.Start(psi);
            if (process == null)
                return null;

            var output = process.StandardOutput.ReadToEnd();
            process.WaitForExit(5000);
            return process.ExitCode == 0 ? output : null;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>计划任务存在且处于可运行状态（非 Disabled）。</summary>
    public static bool IsTaskRunnable(string taskName)
    {
        var output = QueryTaskOutput(taskName);
        if (output == null)
            return false;

        // The state text emitted by schtasks is localized (for example, "Ready"
        // on English Windows and "就绪" on Simplified Chinese Windows).  The
        // prior Ready/Running-only test therefore treated healthy non-English
        // tasks as broken and repeatedly recreated them.  A successfully queried
        // matching task is runnable unless its state explicitly says disabled.
        if (output.Contains("Disabled", StringComparison.OrdinalIgnoreCase)
            || output.Contains("禁用", StringComparison.OrdinalIgnoreCase)
            || output.Contains("停用", StringComparison.OrdinalIgnoreCase))
            return false;

        return true;
    }

    public static bool TryEnableTask(string taskName, ILogger? logger = null)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = "schtasks.exe",
                Arguments = $"/Change /TN \"{taskName}\" /ENABLE",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using var process = Process.Start(psi);
            if (process == null)
                return false;

            var stderr = process.StandardError.ReadToEnd();
            process.WaitForExit(10000);

            if (process.ExitCode != 0)
            {
                logger?.LogWarning("schtasks /Change /ENABLE failed for {Task} ({Code}): {Error}",
                    taskName, process.ExitCode, stderr.Trim());
                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "Failed to enable scheduled task {Task}", taskName);
            return false;
        }
    }

    public static bool TryCreateTask(string taskName, string xmlContent, ILogger? logger)
    {
        LastOperationError = null;
        var xmlPath = Path.Combine(Path.GetTempPath(), $"{taskName}-{Guid.NewGuid():N}.xml");
        try
        {
            File.WriteAllText(xmlPath, xmlContent, Encoding.Unicode);

            var psi = new ProcessStartInfo
            {
                FileName = "schtasks.exe",
                Arguments = $"/Create /TN \"{taskName}\" /XML \"{xmlPath}\" /F",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using var process = Process.Start(psi);
            if (process == null)
                return false;

            var stderr = process.StandardError.ReadToEnd();
            process.WaitForExit(15000);

            if (process.ExitCode != 0)
            {
                LastOperationError = stderr.Trim();
                logger?.LogWarning("schtasks /Create failed for {Task} ({Code}): {Error}",
                    taskName, process.ExitCode, LastOperationError);
                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            LastOperationError = ex.Message;
            logger?.LogWarning(ex, "Failed to create scheduled task {Task}", taskName);
            return false;
        }
        finally
        {
            try { File.Delete(xmlPath); } catch { /* ignore */ }
        }
    }

    /// <summary>
    /// 使用 schtasks 命令行创建当前用户登录触发任务（无需管理员，作为 XML 导入的备选）。
    /// </summary>
    public static bool TryCreateLogonTask(
        string taskName,
        string exePath,
        string arguments,
        TimeSpan? delay = null,
        ILogger? logger = null)
    {
        LastOperationError = null;
        try
        {
            var taskRun = $"\"{exePath}\" {arguments}";
            var args = $"/Create /TN \"{taskName}\" /TR \"{taskRun}\" /SC ONLOGON /RL LIMITED /F";
            if (delay is { } d && d > TimeSpan.Zero)
            {
                var totalMinutes = (int)Math.Min(d.TotalMinutes, 9999);
                var seconds = d.Seconds;
                args += $" /DELAY {totalMinutes:D4}:{seconds:D2}";
            }

            var psi = new ProcessStartInfo
            {
                FileName = "schtasks.exe",
                Arguments = args,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using var process = Process.Start(psi);
            if (process == null)
                return false;

            var stderr = process.StandardError.ReadToEnd();
            process.WaitForExit(15000);

            if (process.ExitCode != 0)
            {
                LastOperationError = stderr.Trim();
                logger?.LogWarning("schtasks logon create failed for {Task} ({Code}): {Error}",
                    taskName, process.ExitCode, LastOperationError);
                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            LastOperationError = ex.Message;
            logger?.LogWarning(ex, "Failed to create logon task {Task}", taskName);
            return false;
        }
    }

    public static void TryDeleteTask(string taskName, ILogger? logger)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = "schtasks.exe",
                Arguments = $"/Delete /TN \"{taskName}\" /F",
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using var process = Process.Start(psi);
            process?.WaitForExit(10000);
        }
        catch (Exception ex)
        {
            logger?.LogDebug(ex, "Scheduled task delete skipped: {Task}", taskName);
        }
    }

    public static bool ReferencesExecutable(string value, string currentExe)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;

        var normalizedValue = Normalize(value);
        var normalizedExe = Normalize(currentExe);
        var exeName = Path.GetFileName(normalizedExe);

        return normalizedValue.Contains(normalizedExe, StringComparison.OrdinalIgnoreCase)
               || normalizedValue.Contains(exeName, StringComparison.OrdinalIgnoreCase);
    }

    public static string EscapeXml(string value)
        => value
            .Replace("&", "&amp;", StringComparison.Ordinal)
            .Replace("<", "&lt;", StringComparison.Ordinal)
            .Replace(">", "&gt;", StringComparison.Ordinal)
            .Replace("\"", "&quot;", StringComparison.Ordinal);

    private static string Normalize(string value)
        => value.Replace("\"", "", StringComparison.Ordinal).Trim();
}

/// <summary>
/// 保证全局只运行一个进程；再次启动时通知已运行实例。
/// </summary>
public static class SingleInstanceManager
{
    private const string MutexName = @"Global\DHPG_EnterpriseAgent_SingleInstance";
    private const string ActivateEventName = @"Global\DHPG_EnterpriseAgent_Activate";

    private static Mutex? _mutex;
    private static EventWaitHandle? _activateEvent;
    private static CancellationTokenSource? _listenerCts;
    private static Action? _onActivate;

    public static bool TryAcquire()
    {
        _mutex = new Mutex(true, MutexName, out var isFirstInstance);
        if (!isFirstInstance)
        {
            SignalExistingInstance();
            return false;
        }

        try
        {
            _activateEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ActivateEventName);
        }
        catch (WaitHandleCannotBeOpenedException)
        {
            _activateEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ActivateEventName);
        }

        StartActivateListener();
        return true;
    }

    /// <summary>
    /// 检测是否已有 Agent 实例在运行（不获取互斥锁）。
    /// </summary>
    public static bool IsAnotherInstanceRunning()
    {
        try
        {
            using var mutex = Mutex.OpenExisting(MutexName);
            return true;
        }
        catch (WaitHandleCannotBeOpenedException)
        {
            return false;
        }
        catch (UnauthorizedAccessException)
        {
            return true;
        }
    }

    public static void SetActivateHandler(Action? onSecondInstanceLaunch)
    {
        _onActivate = onSecondInstanceLaunch;
    }

    public static void Release()
    {
        try
        {
            _listenerCts?.Cancel();
            _listenerCts?.Dispose();
            _listenerCts = null;
        }
        catch { /* ignore */ }

        try
        {
            _activateEvent?.Dispose();
            _activateEvent = null;
        }
        catch { /* ignore */ }

        try
        {
            _mutex?.ReleaseMutex();
            _mutex?.Dispose();
            _mutex = null;
        }
        catch { /* ignore */ }

        _onActivate = null;
    }

    private static void SignalExistingInstance()
    {
        try
        {
            using var existing = EventWaitHandle.OpenExisting(ActivateEventName);
            existing.Set();
        }
        catch (WaitHandleCannotBeOpenedException)
        {
            // 首个实例尚未创建事件，忽略
        }
        catch (UnauthorizedAccessException)
        {
            // 权限不足时无法通知，但仍阻止多开
        }
    }

    private static void StartActivateListener()
    {
        if (_activateEvent == null)
            return;

        _listenerCts = new CancellationTokenSource();
        var token = _listenerCts.Token;

        Task.Run(() =>
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    if (!_activateEvent.WaitOne(500))
                        continue;

                    _onActivate?.Invoke();
                }
                catch (ObjectDisposedException)
                {
                    break;
                }
                catch (AbandonedMutexException)
                {
                    break;
                }
            }
        }, token);
    }
}

/// <summary>
/// 统一进程启动入口。所有外部拉起（看门狗、开机自启计划任务）必须经此模块，
/// 避免多路并发 Process.Start 引发启动风暴。
/// </summary>
public static class AgentProcessLauncher
{
    /// <summary>轻量检测模式参数，经 Program 进入后调用 <see cref="EnsureRunning"/>。</summary>
    public const string EnsureRunningArgument = "--watchdog";

    private static readonly TimeSpan DebounceInterval = TimeSpan.FromSeconds(30);
    private static readonly object Gate = new();

    public enum LaunchResult
    {
        AlreadyRunning,
        Debounced,
        Started,
        ExecutableNotFound,
        Failed,
        SkippedVoluntaryExit
    }

    /// <summary>
    /// 确保主进程在运行：已运行 / 防抖窗口内则跳过，否则启动主进程（无额外参数）。
    /// </summary>
    public static LaunchResult EnsureRunning(string reason, ILogger? logger = null, bool showStartupNotify = false)
        => TryStart(reason, logger, showStartupNotify);

    public static LaunchResult TryStart(string reason, ILogger? logger = null, bool showStartupNotify = false)
    {
        if (VoluntaryShutdownMarker.IsActive())
        {
            logger?.LogDebug("Launch skipped (user voluntarily exited): {Reason}", reason);
            return LaunchResult.SkippedVoluntaryExit;
        }

        if (SingleInstanceManager.IsAnotherInstanceRunning())
        {
            logger?.LogDebug("Launch skipped (already running): {Reason}", reason);
            return LaunchResult.AlreadyRunning;
        }

        lock (Gate)
        {
            if (SingleInstanceManager.IsAnotherInstanceRunning())
            {
                logger?.LogDebug("Launch skipped (already running after lock): {Reason}", reason);
                return LaunchResult.AlreadyRunning;
            }

            if (IsWithinDebounceWindow())
            {
                logger?.LogDebug("Launch skipped (debounced {Seconds}s): {Reason}",
                    DebounceInterval.TotalSeconds, reason);
                return LaunchResult.Debounced;
            }

            var exePath = AutoStartManager.GetExecutablePath();
            if (!File.Exists(exePath))
            {
                logger?.LogWarning("Launch failed, executable not found: {Path} ({Reason})", exePath, reason);
                return LaunchResult.ExecutableNotFound;
            }

            try
            {
                HiddenLauncherFiles.LaunchMainAgentHidden(exePath, showStartupNotify);

                RecordLaunchAttempt();
                logger?.LogInformation("Agent launched ({Reason}) from {Path}", reason, exePath);
                return LaunchResult.Started;
            }
            catch (Exception ex)
            {
                logger?.LogError(ex, "Launch failed ({Reason})", reason);
                return LaunchResult.Failed;
            }
        }
    }

    private static string DebounceFilePath
        => Path.Combine(AppPaths.GetAppDataPath(), "last_launch_attempt.txt");

    private static bool IsWithinDebounceWindow()
    {
        try
        {
            if (!File.Exists(DebounceFilePath))
                return false;

            var text = File.ReadAllText(DebounceFilePath).Trim();
            if (!DateTime.TryParse(text, null, System.Globalization.DateTimeStyles.RoundtripKind, out var last))
                return false;

            return DateTime.UtcNow - last.ToUniversalTime() < DebounceInterval;
        }
        catch
        {
            return false;
        }
    }

    private static void RecordLaunchAttempt()
    {
        try
        {
            File.WriteAllText(DebounceFilePath, DateTime.UtcNow.ToString("O"));
        }
        catch
        {
            // 防抖记录失败不阻断启动
        }
    }
}

/// <summary>
/// 用户会话内常驻守护进程：无窗口轮询主进程，崩溃后静默拉起；主动退出时自行停止。
/// 不依赖计划任务，避免每 5 分钟黑屏一闪；与录屏/托盘等同会话，优于 Session 0 服务。
/// </summary>
public static class AgentGuardianManager
{
    private const string GuardianMutexName = @"Global\DHPG_EnterpriseAgent_Guardian";

    public static readonly TimeSpan CheckInterval = TimeSpan.FromSeconds(15);

    private static Mutex? _guardianMutex;
    private static int _sessionStartupNotifySent;

    public static bool IsRunning()
    {
        try
        {
            using var mutex = Mutex.OpenExisting(GuardianMutexName);
            return true;
        }
        catch (WaitHandleCannotBeOpenedException)
        {
            return false;
        }
        catch (UnauthorizedAccessException)
        {
            return true;
        }
    }

    public static bool TryAcquire()
    {
        _guardianMutex = new Mutex(true, GuardianMutexName, out var isFirst);
        return isFirst;
    }

    public static void Release()
    {
        try
        {
            _guardianMutex?.ReleaseMutex();
            _guardianMutex?.Dispose();
            _guardianMutex = null;
        }
        catch
        {
            // ignore
        }
    }

    /// <summary>
    /// 确保守护进程在运行（已运行则跳过）。
    /// </summary>
    public static void EnsureRunning(ILogger? logger = null)
    {
        if (IsRunning())
        {
            logger?.LogDebug("Guardian already running");
            return;
        }

        try
        {
            var exePath = AutoStartManager.GetExecutablePath();
            HiddenLauncherFiles.LaunchGuardianHidden(exePath);
            logger?.LogInformation("Guardian launched (hidden)");
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "Failed to launch guardian");
        }
    }

    public static async Task RunAsync(ILogger logger, CancellationToken ct)
    {
        logger.LogInformation("Guardian started (interval={Seconds}s)", CheckInterval.TotalSeconds);

        if (!PerformCheck(logger))
            return;

        while (!ct.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(CheckInterval, ct);
            }
            catch (OperationCanceledException)
            {
                break;
            }

            if (!PerformCheck(logger))
                break;
        }

        logger.LogInformation("Guardian stopped");
    }

    private static bool PerformCheck(ILogger logger)
    {
        var uiRunning = UiPresence.IsMainUiRunning();

        if (VoluntaryShutdownMarker.IsActive())
        {
            if (!uiRunning)
            {
                logger.LogInformation("Voluntary exit confirmed, guardian stopping");
                return false;
            }

            logger.LogDebug("Voluntary exit marker set, waiting for UI to stop");
            return true;
        }

        if (UiPresence.TryGetHungUiPid(out var hungPid))
        {
            logger.LogWarning(
                "UI appears hung (heartbeat stale > {Seconds}s, pid={Pid}), attempting recovery",
                UiPresence.HungThreshold.TotalSeconds,
                hungPid);
            UiPresence.TryTerminateHungProcess(hungPid, logger);
            uiRunning = UiPresence.IsMainUiRunning();
        }

        if (!uiRunning)
        {
            if (!ClientProtectionStateFile.ShouldGuardianRestartUi())
            {
                logger.LogDebug("Guardian skip UI restart (client protection: no restart-on-kill)");
                return true;
            }

            var showStartupNotify = _sessionStartupNotifySent == 0;
            var result = AgentProcessLauncher.EnsureRunning("guardian", logger, showStartupNotify);
            if (result == AgentProcessLauncher.LaunchResult.Started)
            {
                if (showStartupNotify)
                    _sessionStartupNotifySent = 1;
                logger.LogInformation("Guardian restarted main UI: {Result}", result);
            }
            else
            {
                logger.LogDebug("Guardian ensure UI: {Result}", result);
            }
        }

        return true;
    }
}

/// <summary>
/// 进程看门狗（已弃用计划任务模式）。
/// 崩溃恢复改由 <see cref="AgentGuardianManager"/> 用户会话守护进程负责；
/// 运行中由 <see cref="SelfHealingService"/> 在进程内每 60 秒自愈。
/// </summary>
public static class AgentWatchdogManager
{
    public const string WatchdogTaskName = "DHPG-Agent-Watchdog";

    /// <summary>
    /// --watchdog 模式入口：委托统一启动器，检测后按需启动主进程。
    /// </summary>
    public static void RunWatchdogCheck(ILogger? logger = null)
    {
        var result = AgentProcessLauncher.EnsureRunning("watchdog-scheduled", logger);

        if (result == AgentProcessLauncher.LaunchResult.Debounced)
            logger?.LogDebug("Watchdog: launch debounced, another channel may have started agent recently");
    }

    /// <summary>
    /// 用户主动退出时移除看门狗计划任务，避免退出后仍被自动拉起。
    /// </summary>
    public static void DisableWatchdogTask(ILogger? logger = null)
    {
        ScheduledTaskHelper.TryDeleteTask(WatchdogTaskName, logger);
        logger?.LogInformation("Watchdog task disabled: {Task}", WatchdogTaskName);
    }

    /// <summary>
    /// 启动时移除旧版 5 分钟计划任务，避免周期性黑屏一闪。
    /// </summary>
    public static void RemoveLegacyWatchdogTask(ILogger? logger = null)
        => DisableWatchdogTask(logger);

    /// <summary>
    /// 已弃用：不再创建计划任务，改由进程内自愈。
    /// </summary>
    public static bool EnsureWatchdogTask(ILogger? logger = null)
    {
        RemoveLegacyWatchdogTask(logger);
        logger?.LogDebug("Scheduled watchdog disabled; using in-process self-healing");
        return false;
    }
}

/// <summary>
/// 开机自启动：优先计划任务（用户级），失败时回退 HKCU Run 注册表。
/// 均通过 wscript + VBS 无窗口启动守护进程（守护进程再拉起主界面）。
/// </summary>
public static partial class AutoStartManager
{
    public const string RegistryValueName = "DHPG";
    public const string TaskName = "DHPG-Agent";

    private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";

    public static string GetExecutablePath()
    {
        var path = Environment.ProcessPath;
        if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
            return Path.GetFullPath(path);

        path = Application.ExecutablePath;
        if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
            return Path.GetFullPath(path);

        var baseDir = AppDomain.CurrentDomain.BaseDirectory;
        var candidate = Path.Combine(baseDir, "DHPG.exe");
        if (File.Exists(candidate))
            return Path.GetFullPath(candidate);

        return Path.GetFullPath(path ?? candidate);
    }

    public static bool IsEnabled()
    {
        var exePath = GetExecutablePath();
        return TaskSchedulerMatches(exePath) || RegistryAutoStartMatches(exePath);
    }

    public static bool Enable(ILogger? logger = null)
    {
        ClearEnableNotice();
        LastTaskCreationFailure = null;

        var exePath = GetExecutablePath();
        HiddenLauncherFiles.EnsureGuardianVbs(exePath);
        ScheduledTaskHelper.TryDeleteTask(TaskName, logger);

        if (TryEnableTaskScheduler(exePath, logger))
        {
            TryDisableRegistry(logger);
            return true;
        }

        logger?.LogWarning(
            "Scheduled task auto-start failed, falling back to registry Run key: {Detail}",
            LastTaskCreationFailure ?? "unknown");
        if (!string.IsNullOrWhiteSpace(LastTaskCreationFailure))
        {
            SetEnableNotice("AutoStartTaskFallbackNotice", LastTaskCreationFailure);
        }

        return TryEnableRegistry(exePath, logger);
    }

    public static void Disable(ILogger? logger = null)
    {
        TryDisableRegistry(logger);
        ScheduledTaskHelper.TryDeleteTask(TaskName, logger);
        logger?.LogInformation("Auto-start disabled");
    }

    /// <summary>
    /// 确保开机自启已配置；已正确配置时跳过重建。
    /// </summary>
    public static bool EnsureEnabled(ILogger? logger = null)
    {
        try
        {
            var exePath = GetExecutablePath();
            HiddenLauncherFiles.EnsureGuardianVbs(exePath);
            RepairRegistryWhenVbsMissing(exePath, logger);

            if (TaskSchedulerMatches(exePath))
            {
                if (!ScheduledTaskHelper.IsTaskRunnable(TaskName))
                {
                    logger?.LogWarning("Auto-start task exists but is disabled, attempting repair");
                    if (ScheduledTaskHelper.TryEnableTask(TaskName, logger)
                        && ScheduledTaskHelper.IsTaskRunnable(TaskName))
                    {
                        TryDisableRegistry(logger);
                        logger?.LogInformation("Auto-start task re-enabled");
                        return true;
                    }

                    logger?.LogWarning("Auto-start task disabled and could not be enabled, recreating");
                    ScheduledTaskHelper.TryDeleteTask(TaskName, logger);
                }
                else
                {
                    TryDisableRegistry(logger);
                    logger?.LogDebug("Auto-start task already configured");
                    return true;
                }
            }

            if (RegistryAutoStartMatches(exePath))
            {
                SetStartupApprovedRun(RegistryValueName, true, logger);
                TryEnableStartupFolderShortcut(exePath, logger);
                logger?.LogDebug("Auto-start registry already configured");
                return true;
            }

            return Enable(logger);
        }
        catch (Exception ex)
        {
            logger?.LogError(ex, "Failed to ensure auto-start");
            return false;
        }
    }

    private static bool TaskSchedulerMatches(string currentExe)
    {
        var output = ScheduledTaskHelper.QueryTaskOutput(TaskName);
        return AutoStartEntryMatches(output, currentExe);
    }

    private static bool RegistryAutoStartMatches(string currentExe)
    {
        try
        {
            return AutoStartEntryMatches(ReadRegistryAutoStartValue(), currentExe);
        }
        catch
        {
            return false;
        }
    }

    private static bool TryEnableTaskScheduler(string exePath, ILogger? logger)
    {
        LastTaskCreationFailure = null;

        try
        {
            var workDir = Path.GetDirectoryName(exePath)
                ?? AppDomain.CurrentDomain.BaseDirectory;
            var vbsPath = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
            var failures = new List<string>();

            if (File.Exists(vbsPath))
            {
                if (ScheduledTaskHelper.TryCreateTask(TaskName, BuildTaskXml(vbsPath, workDir), logger))
                {
                    logger?.LogInformation("Auto-start task created (VBS/XML): {Task}", TaskName);
                    return true;
                }

                failures.Add($"VBS/XML: {ScheduledTaskHelper.LastOperationError ?? "failed"}");

                if (ScheduledTaskHelper.TryCreateLogonTask(
                        TaskName,
                        HiddenLauncherFiles.GetWscriptPath(),
                        HiddenLauncherFiles.BuildWscriptArguments(vbsPath),
                        TimeSpan.FromSeconds(15),
                        logger))
                {
                    logger?.LogInformation("Auto-start task created (VBS/ONLOGON): {Task}", TaskName);
                    return true;
                }

                failures.Add($"VBS/ONLOGON: {ScheduledTaskHelper.LastOperationError ?? "failed"}");
            }
            else
            {
                failures.Add("VBS missing");
                logger?.LogWarning("Guardian VBS missing; trying direct exe scheduled task");
            }

            if (ScheduledTaskHelper.TryCreateTask(TaskName, BuildTaskXmlDirectExe(exePath, workDir), logger))
            {
                logger?.LogInformation("Auto-start task created (direct exe/XML): {Task}", TaskName);
                return true;
            }

            failures.Add($"Direct/XML: {ScheduledTaskHelper.LastOperationError ?? "failed"}");

            if (ScheduledTaskHelper.TryCreateLogonTask(
                    TaskName,
                    exePath,
                    HiddenLauncherFiles.GuardianLaunchArgument,
                    TimeSpan.FromSeconds(15),
                    logger))
            {
                logger?.LogInformation("Auto-start task created (direct exe/ONLOGON): {Task}", TaskName);
                return true;
            }

            failures.Add($"Direct/ONLOGON: {ScheduledTaskHelper.LastOperationError ?? "failed"}");
            LastTaskCreationFailure = string.Join(" | ", failures);
            logger?.LogWarning(
                "All scheduled task strategies failed for {Task}: {Detail}",
                TaskName,
                LastTaskCreationFailure);
            return false;
        }
        catch (Exception ex)
        {
            LastTaskCreationFailure = ex.Message;
            logger?.LogWarning(ex, "Failed to create auto-start task");
            return false;
        }
    }

    private static bool TryEnableRegistry(string exePath, ILogger? logger)
    {
        try
        {
            using var key = Registry.CurrentUser.CreateSubKey(RunKeyPath);
            if (key == null)
                return false;

            var command = BuildRegistryCommand(exePath, logger, out var mode);
            key.SetValue(RegistryValueName, command);
            SetStartupApprovedRun(RegistryValueName, true, logger);
            TryEnableStartupFolderShortcut(exePath, logger);
            logger?.LogInformation(
                "Auto-start enabled via registry Run key ({Mode}): {Command}",
                mode,
                command);
            if (mode == AutoStartLaunchMode.DirectGuardianExe)
            {
                SetEnableNotice("AutoStartRegistryDirectExeNotice");
            }

            return true;
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "Failed to enable registry auto-start");
            return false;
        }
    }

    private static void TryDisableRegistry(ILogger? logger)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath, true);
            key?.DeleteValue(RegistryValueName, false);
            SetStartupApprovedRun(RegistryValueName, false, logger);
            TryDisableStartupFolderShortcut(logger);
            logger?.LogDebug("Registry auto-start removed (if any)");
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "Failed to remove registry auto-start");
        }
    }

    private static string BuildTaskXml(string vbsPath, string workDir)
    {
        var wscript = HiddenLauncherFiles.GetWscriptPath();
        var arguments = HiddenLauncherFiles.BuildWscriptArguments(vbsPath);
        return BuildTaskXmlCore(wscript, arguments, workDir, "guardian hidden launcher (VBS)");
    }

    private static string BuildTaskXmlDirectExe(string exePath, string workDir)
        => BuildTaskXmlCore(
            exePath,
            HiddenLauncherFiles.GuardianLaunchArgument,
            workDir,
            "guardian direct exe fallback");

    private static string BuildTaskXmlCore(
        string command,
        string arguments,
        string workDir,
        string descriptionSuffix)
    {
        var principal = ScheduledTaskHelper.BuildPrincipalXml();
        return $"""
            <?xml version="1.0" encoding="UTF-16"?>
            <Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
              <RegistrationInfo>
                <Description>DHPG Enterprise Agent auto-start at user logon ({descriptionSuffix})</Description>
              </RegistrationInfo>
              <Triggers>
                <LogonTrigger>
                  <Enabled>true</Enabled>
                  <Delay>PT15S</Delay>
                </LogonTrigger>
              </Triggers>
              <Principals>
            {principal}
              </Principals>
              <Settings>
                <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
                <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
                <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
                <AllowHardTerminate>true</AllowHardTerminate>
                <StartWhenAvailable>true</StartWhenAvailable>
                <Enabled>true</Enabled>
                <Hidden>true</Hidden>
                <WakeToRun>false</WakeToRun>
                <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
              </Settings>
              <Actions Context="Author">
                <Exec>
                  <Command>{ScheduledTaskHelper.EscapeXml(command)}</Command>
                  <Arguments>{ScheduledTaskHelper.EscapeXml(arguments)}</Arguments>
                  <WorkingDirectory>{ScheduledTaskHelper.EscapeXml(workDir)}</WorkingDirectory>
                </Exec>
              </Actions>
            </Task>
            """;
    }
}

using System.Reflection;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// Runtime version from assembly metadata (matches csproj &lt;Version&gt;).
/// </summary>
public static class AppVersion
{
    public static string Current { get; } = Resolve();

    private static string Resolve()
    {
        var assembly = typeof(AppVersion).Assembly;
        var informational = assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion;
        if (!string.IsNullOrWhiteSpace(informational))
        {
            var plus = informational.IndexOf('+');
            return plus >= 0 ? informational[..plus] : informational;
        }

        var version = assembly.GetName().Version;
        if (version != null)
            return version.ToString(3);

        return Models.Constants.DefaultAgentVersion;
    }
}

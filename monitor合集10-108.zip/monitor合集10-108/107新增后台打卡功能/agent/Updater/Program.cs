using System.Diagnostics;
using System.IO.Compression;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;

namespace EnterpriseAgent.Updater;

internal static class Program
{
    private const string AppDataFolder = "EnterpriseAgent";
    private const string VoluntaryExitFile = "voluntary_exit.marker";
    private const int StopTimeoutSeconds = 45;

    public static async Task<int> Main(string[] args)
    {
        try
        {
            var options = UpdateOptions.Parse(args);
            if (options.ShowHelp)
            {
                PrintHelp();
                return 0;
            }

            if (string.IsNullOrWhiteSpace(options.InstallDirectory))
            {
                Console.Error.WriteLine("Missing --install-dir");
                return 2;
            }

            options.InstallDirectory = Path.GetFullPath(options.InstallDirectory);
            var logPath = Path.Combine(GetAppDataPath(), "logs", "updater.log");
            Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
            await using var log = new StreamWriter(logPath, append: true, Encoding.UTF8);
            void Log(string message)
            {
                var line = $"{DateTime.UtcNow:O} {message}";
                log.WriteLine(line);
                log.Flush();
                Console.WriteLine(message);
            }

            Log($"Updater started: installDir={options.InstallDirectory}");

            var packagePath = options.PackagePath;
            if (!string.IsNullOrWhiteSpace(options.DownloadUrl))
            {
                var tempZip = Path.Combine(Path.GetTempPath(), $"dhpg-update-{Guid.NewGuid():N}.zip");
                Log($"Downloading {options.DownloadUrl}");
                await DownloadAsync(options.DownloadUrl, tempZip);
                packagePath = tempZip;
            }

            if (string.IsNullOrWhiteSpace(packagePath) || !File.Exists(packagePath))
            {
                Log("Update package not found.");
                return 3;
            }

            if (!string.IsNullOrWhiteSpace(options.ExpectedSha256))
            {
                var hash = await ComputeSha256HexAsync(packagePath);
                if (!hash.Equals(options.ExpectedSha256, StringComparison.OrdinalIgnoreCase))
                {
                    Log($"SHA256 mismatch: expected={options.ExpectedSha256}, actual={hash}");
                    return 4;
                }
                Log("SHA256 verified.");
            }

            MarkVoluntaryExit(Log);
            await StopAgentProcessesAsync(options.InstallDirectory, Log);

            var stagingDir = Path.Combine(GetAppDataPath(), "update", "staging");
            var backupDir = Path.Combine(GetAppDataPath(), "update", $"backup-{DateTime.UtcNow:yyyyMMddHHmmss}");
            PrepareDirectory(stagingDir);
            PrepareDirectory(backupDir);

            Log($"Extracting {packagePath} -> {stagingDir}");
            ZipFile.ExtractToDirectory(packagePath, stagingDir, overwriteFiles: true);

            var mainExe = Path.Combine(stagingDir, "DHPG.exe");
            if (!File.Exists(mainExe))
            {
                Log("Package missing DHPG.exe");
                return 5;
            }

            Log($"Backing up {options.InstallDirectory} -> {backupDir}");
            MirrorDirectory(options.InstallDirectory, backupDir, Log);

            Log($"Applying update to {options.InstallDirectory}");
            MirrorDirectory(stagingDir, options.InstallDirectory, Log);

            try
            {
                Directory.Delete(stagingDir, recursive: true);
            }
            catch
            {
                // non-fatal
            }

            if (options.Restart)
            {
                var exe = Path.Combine(options.InstallDirectory, "DHPG.exe");
                Log($"Restarting {exe}");
                Process.Start(new ProcessStartInfo
                {
                    FileName = exe,
                    Arguments = "--ui",
                    UseShellExecute = true,
                    WorkingDirectory = options.InstallDirectory,
                });
            }

            Log("Update completed.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex);
            return 1;
        }
    }

    private static void PrintHelp()
    {
        Console.WriteLine("""
            DHPGUpdater — Enterprise Agent in-place updater

            Usage:
              DHPGUpdater --install-dir <path> --package <zip> [--restart]
              DHPGUpdater --install-dir <path> --download <url> [--sha256 <hex>] [--restart]
            """);
    }

    private static string GetAppDataPath()
    {
        var path = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            AppDataFolder);
        Directory.CreateDirectory(path);
        return path;
    }

    private static void MarkVoluntaryExit(Action<string> log)
    {
        try
        {
            var marker = Path.Combine(GetAppDataPath(), VoluntaryExitFile);
            File.WriteAllText(marker, DateTime.UtcNow.ToString("O"));
            log("Voluntary exit marker set.");
        }
        catch (Exception ex)
        {
            log($"Failed to set voluntary exit marker: {ex.Message}");
        }
    }

    private static async Task StopAgentProcessesAsync(string installDirectory, Action<string> log)
    {
        var installFfmpeg = Path.GetFullPath(Path.Combine(installDirectory, "ffmpeg.exe"));
        var deadline = DateTime.UtcNow.AddSeconds(StopTimeoutSeconds);

        foreach (var name in new[] { "DHPG", "ffmpeg" })
        {
            foreach (var process in Process.GetProcessesByName(name))
            {
                try
                {
                    if (process.Id == Environment.ProcessId)
                        continue;

                    if (name.Equals("ffmpeg", StringComparison.OrdinalIgnoreCase))
                    {
                        var path = TryGetProcessPath(process);
                        if (path != null && !path.Equals(installFfmpeg, StringComparison.OrdinalIgnoreCase))
                            continue;
                    }

                    log($"Stopping {name} pid={process.Id}");
                    if (!process.HasExited)
                        process.CloseMainWindow();
                }
                catch
                {
                    // ignore per-process errors
                }
                finally
                {
                    process.Dispose();
                }
            }
        }

        while (DateTime.UtcNow < deadline)
        {
            if (!Process.GetProcessesByName("DHPG").Any(p => p.Id != Environment.ProcessId))
                break;
            await Task.Delay(500);
        }

        foreach (var process in Process.GetProcessesByName("DHPG"))
        {
            try
            {
                if (process.Id == Environment.ProcessId)
                    continue;
                log($"Killing DHPG pid={process.Id}");
                if (!process.HasExited)
                    process.Kill(entireProcessTree: true);
            }
            catch (Exception ex)
            {
                log($"Kill failed pid={process.Id}: {ex.Message}");
            }
            finally
            {
                process.Dispose();
            }
        }

        foreach (var process in Process.GetProcessesByName("ffmpeg"))
        {
            try
            {
                var path = TryGetProcessPath(process);
                if (path != null && !path.Equals(installFfmpeg, StringComparison.OrdinalIgnoreCase))
                    continue;
                if (!process.HasExited)
                    process.Kill(entireProcessTree: true);
            }
            catch
            {
                // ignore
            }
            finally
            {
                process.Dispose();
            }
        }
    }

    private static string? TryGetProcessPath(Process process)
    {
        try
        {
            return process.MainModule?.FileName;
        }
        catch
        {
            return null;
        }
    }

    private static void PrepareDirectory(string path)
    {
        if (Directory.Exists(path))
            Directory.Delete(path, recursive: true);
        Directory.CreateDirectory(path);
    }

    private static void MirrorDirectory(string source, string destination, Action<string> log)
    {
        Directory.CreateDirectory(destination);
        foreach (var dir in Directory.EnumerateDirectories(source, "*", SearchOption.AllDirectories))
        {
            var relative = Path.GetRelativePath(source, dir);
            Directory.CreateDirectory(Path.Combine(destination, relative));
        }

        foreach (var file in Directory.EnumerateFiles(source, "*", SearchOption.AllDirectories))
        {
            var relative = Path.GetRelativePath(source, file);
            var target = Path.Combine(destination, relative);
            var fullSource = Path.GetFullPath(file);
            var currentExe = Path.GetFullPath(Environment.ProcessPath ?? "");
            if (!string.IsNullOrEmpty(currentExe)
                && fullSource.Equals(currentExe, StringComparison.OrdinalIgnoreCase))
            {
                log($"Skipping running updater binary: {relative}");
                continue;
            }

            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            for (var attempt = 0; attempt < 5; attempt++)
            {
                try
                {
                    File.Copy(file, target, overwrite: true);
                    break;
                }
                catch (IOException) when (attempt < 4)
                {
                    log($"Retry copy {relative} ({attempt + 1}/5)");
                    Thread.Sleep(1000);
                }
            }
        }
    }

    private static async Task DownloadAsync(string url, string destination)
    {
        using var client = new HttpClient { Timeout = TimeSpan.FromMinutes(30) };
        await using var stream = await client.GetStreamAsync(url);
        await using var file = File.Create(destination);
        await stream.CopyToAsync(file);
    }

    private static async Task<string> ComputeSha256HexAsync(string path)
    {
        await using var stream = File.OpenRead(path);
        var hash = await SHA256.HashDataAsync(stream);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private sealed class UpdateOptions
    {
        public string InstallDirectory { get; set; } = "";
        public string? PackagePath { get; set; }
        public string? DownloadUrl { get; set; }
        public string? ExpectedSha256 { get; set; }
        public bool Restart { get; set; }
        public bool ShowHelp { get; set; }

        public static UpdateOptions Parse(string[] args)
        {
            var options = new UpdateOptions();
            for (var i = 0; i < args.Length; i++)
            {
                var arg = args[i];
                switch (arg.ToLowerInvariant())
                {
                    case "--help":
                    case "-h":
                    case "/?":
                        options.ShowHelp = true;
                        break;
                    case "--install-dir":
                        options.InstallDirectory = ReadValue(args, ref i);
                        break;
                    case "--package":
                        options.PackagePath = ReadValue(args, ref i);
                        break;
                    case "--download":
                        options.DownloadUrl = ReadValue(args, ref i);
                        break;
                    case "--sha256":
                        options.ExpectedSha256 = ReadValue(args, ref i);
                        break;
                    case "--restart":
                        options.Restart = true;
                        break;
                }
            }

            return options;
        }

        private static string ReadValue(string[] args, ref int index)
        {
            if (index + 1 >= args.Length)
                return "";
            index++;
            return args[index];
        }
    }
}

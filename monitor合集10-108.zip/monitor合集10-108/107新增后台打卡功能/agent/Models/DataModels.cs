using System.Text.Json.Serialization;

namespace EnterpriseAgent.Agent.Models;

public abstract class BaseEntity
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    private DateTime _createdAt;
    
    public DateTime CreatedAt 
    { 
        get => _createdAt;
        set => _createdAt = value.Kind == DateTimeKind.Utc ? value : value.ToUniversalTime();
    }
    
    private DateTime? _updatedAt;
    
    public DateTime? UpdatedAt 
    { 
        get => _updatedAt;
        set => _updatedAt = value.HasValue 
            ? (value.Value.Kind == DateTimeKind.Utc ? value.Value : value.Value.ToUniversalTime())
            : null;
    }
    
    protected BaseEntity()
    {
        _createdAt = DateTime.UtcNow;
    }
    
    /// <summary>
    /// 更新时间戳
    /// </summary>
    public void Touch()
    {
        UpdatedAt = DateTime.UtcNow;
    }
}

public class Recording : BaseEntity
{
    public string DeviceId { get; set; } = "";
    
    private DateTime _startTime;
    public DateTime StartTime 
    { 
        get => _startTime;
        set => _startTime = value.Kind == DateTimeKind.Utc ? value : value.ToUniversalTime();
    }
    
    private DateTime _endTime;
    public DateTime EndTime 
    { 
        get => _endTime;
        set => _endTime = value.Kind == DateTimeKind.Utc ? value : value.ToUniversalTime();
    }
    
    public string FilePath { get; set; } = "";
    public long FileSize { get; set; }
    public string Sha256 { get; set; } = "";
    public bool Uploaded { get; set; }
    public int RetryCount { get; set; }
    public string TaskId { get; set; } = "";
    public string UploadId { get; set; } = "";
    
    /// <summary>
    /// ✅ 计算录屏时长（秒）
    /// </summary>
    public int DurationSeconds => (int)(EndTime - StartTime).TotalSeconds;
    
    /// <summary>
    /// 检查文件是否有效
    /// </summary>
    public bool IsFileValid => File.Exists(FilePath) && FileSize > 0;
}

public class Screenshot : BaseEntity
{
    public string DeviceId { get; set; } = "";
    
    private DateTime _capturedAt;
    public DateTime CapturedAt 
    { 
        get => _capturedAt;
        set => _capturedAt = value.Kind == DateTimeKind.Utc ? value : value.ToUniversalTime();
    }
    
    public string FilePath { get; set; } = "";
    public long FileSize { get; set; }
    public bool Uploaded { get; set; }
    public bool Encrypted { get; set; }
    public string UploadId { get; set; } = "";
    
    /// <summary>
    /// ✅ 添加：图片宽度和高度
    /// </summary>
    public int Width { get; set; }
    public int Height { get; set; }
    
    /// <summary>
    /// ✅ 添加：文件格式
    /// </summary>
    public string Format { get; set; } = "jpg";
    
    /// <summary>
    /// ✅ 添加：上传时间
    /// </summary>
    private DateTime? _uploadedAt;
    public DateTime? UploadedAt
    {
        get => _uploadedAt;
        set => _uploadedAt = value.HasValue 
            ? (value.Value.Kind == DateTimeKind.Utc ? value.Value : value.Value.ToUniversalTime())
            : null;
    }
    
    /// <summary>
    /// 检查文件是否有效
    /// </summary>
    public bool IsFileValid => File.Exists(FilePath) && FileSize > 0;
}

public class ActivityLog : BaseEntity
{
    public string DeviceId { get; set; } = "";
    public string ProcessName { get; set; } = "";
    public string WindowTitle { get; set; } = "";
    public string BrowserTitle { get; set; } = "";
    
    private DateTime _startedAt;
    public DateTime StartedAt 
    { 
        get => _startedAt;
        set => _startedAt = value.Kind == DateTimeKind.Utc ? value : value.ToUniversalTime();
    }
    
    private DateTime? _endedAt;
    public DateTime? EndedAt 
    { 
        get => _endedAt;
        set => _endedAt = value.HasValue 
            ? (value.Value.Kind == DateTimeKind.Utc ? value.Value : value.Value.ToUniversalTime())
            : null;
    }
    
    public bool IsIdle { get; set; }
    public int DurationSeconds { get; set; }
    
    /// <summary>
    /// ✅ 添加：报告追踪字段
    /// </summary>
    public bool Reported { get; set; }
    private DateTime? _reportedAt;
    public DateTime? ReportedAt
    {
        get => _reportedAt;
        set => _reportedAt = value.HasValue 
            ? (value.Value.Kind == DateTimeKind.Utc ? value.Value : value.Value.ToUniversalTime())
            : null;
    }
    
    public int RetryCount { get; set; }
    public string ErrorMessage { get; set; } = "";
    
    /// <summary>
    /// 结束活动并计算时长
    /// </summary>
    public void End()
    {
        EndedAt = DateTime.UtcNow;
        DurationSeconds = (int)(EndedAt.Value - StartedAt).TotalSeconds;
    }
    
    /// <summary>
    /// 是否正在活动中
    /// </summary>
    public bool IsActive => EndedAt == null;
}

public class UploadQueue : BaseEntity
{
    public string FilePath { get; set; } = "";
    public string FileType { get; set; } = "";
    public string FileId { get; set; } = "";
    public string Status { get; set; } = "pending";
    public long Offset { get; set; }
    public int RetryCount { get; set; }
    public string ErrorMessage { get; set; } = "";
    public DateTime? LastRetryAt { get; set; }
    public string UploadId { get; set; } = "";

    public DateTime? RecordStartTime { get; set; }
    public DateTime? RecordEndTime { get; set; }
    public DateTime? LastUploadActivity { get; set; }
    
    /// <summary>
    /// 是否可以重试
    /// </summary>
    public bool CanRetry => RetryCount < Constants.MaxRetryCount;
    
    /// <summary>
    /// 增加重试计数
    /// </summary>
    public void IncrementRetry()
    {
        RetryCount++;
        LastRetryAt = DateTime.UtcNow;
    }
    
    /// <summary>
    /// 标记为失败
    /// </summary>
    public void MarkFailed(string error)
    {
        Status = "failed";
        ErrorMessage = error;
        UpdatedAt = DateTime.UtcNow;
    }
    
    /// <summary>
    /// 标记为完成
    /// </summary>
    public void MarkComplete()
    {
        Status = "completed";
        UpdatedAt = DateTime.UtcNow;
    }
    
    /// <summary>
    /// 重置为待处理
    /// </summary>
    public void ResetToPending()
    {
        Status = "pending";
        Offset = 0;
        ErrorMessage = "";
        UpdatedAt = DateTime.UtcNow;
    }
}

public class DeviceInfo
{
    public string DeviceId { get; set; } = "";
    public string Hostname { get; set; } = "";
    public string OsVersion { get; set; } = "";
    public string AgentVersion { get; set; } = Constants.DefaultAgentVersion;
    public string Fingerprint { get; set; } = "";
    public double FingerprintScore { get; set; }
    public string BoundEmployeeId { get; set; } = "";
    public DateTime? BoundAt { get; set; }
    public string Status { get; set; } = "pending";
    
    private DateTime _lastSeenAt;
    public DateTime LastSeenAt 
    { 
        get => _lastSeenAt;
        set => _lastSeenAt = value.Kind == DateTimeKind.Utc ? value : value.ToUniversalTime();
    }
    
    /// <summary>
    /// 更新最后在线时间
    /// </summary>
    public void UpdateLastSeen()
    {
        LastSeenAt = DateTime.UtcNow;
    }
    
    /// <summary>
    /// 检查设备是否在线（5分钟内）
    /// </summary>
    public bool IsOnline => DateTime.UtcNow - LastSeenAt < TimeSpan.FromMinutes(5);
}
/// <summary>
/// 打包时放在 exe 同目录的 deployment.json（发布前由厂商填写，终端用户不可见）
/// </summary>
public class DeploymentBundle
{
    /// <summary>策略 Ed25519 公钥（keyId → Base64 公钥）</summary>
    [JsonPropertyName("policyPublicKeys")]
    public Dictionary<string, string> PolicyPublicKeys { get; set; } = new();

    /// <summary>与后端 DEVICE_REGISTRATION_SECRET 一致（可选，启用后注册须携带 X-Registration-Secret）</summary>
    [JsonPropertyName("registrationSecret")]
    public string RegistrationSecret { get; set; } = "";

    /// <summary>本地 HTTP 调试时设为 true；生产环境应为 false</summary>
    [JsonPropertyName("allowInsecureTransport")]
    public bool AllowInsecureTransport { get; set; }

    /// <summary>厂商预置服务器地址；填写后客户首次向导不可修改</summary>
    [JsonPropertyName("serverUrl")]
    public string ServerUrl { get; set; } = "";

    /// <summary>
    /// 可选：强制 WebSocket 使用 ticket 模式（与后端 WS_TICKET_REQUIRED 一致）。
    /// 未设置时 Agent 启动后会向 /api/v1/meta/capabilities 自动探测。
    /// </summary>
    [JsonPropertyName("wsTicketRequired")]
    public bool? WsTicketRequired { get; set; }

    /// <summary>与 serverUrl 相同（兼容旧字段名）</summary>
    [JsonPropertyName("defaultServerUrl")]
    public string DefaultServerUrl { get; set; } = "";

    /// <summary>解析有效的预置服务器地址</summary>
    public string ResolveServerUrl()
    {
        if (!string.IsNullOrWhiteSpace(ServerUrl))
            return ServerUrl.Trim();
        return DefaultServerUrl.Trim();
    }
}

#region DateTime Extensions

/// <summary>
/// 统一时间处理扩展方法 - 解决时间格式混用问题
/// 所有时间统一使用 UTC + ISO 8601 格式
/// </summary>
public static class DateTimeExtensions
{
    /// <summary>
    /// ISO 8601 格式常量（带毫秒，推荐）
    /// </summary>
    public const string Iso8601Format = "yyyy-MM-ddTHH:mm:ss.fffZ";
    
    /// <summary>
    /// ISO 8601 格式常量（不带毫秒，用于 SQLite 兼容）
    /// </summary>
    public const string Iso8601FormatBasic = "yyyy-MM-ddTHH:mm:ssZ";
    
    /// <summary>
    /// 日期格式
    /// </summary>
    public const string DateFormat = "yyyy-MM-dd";
    
    /// <summary>
    /// 时间格式（用于文件名）
    /// </summary>
    public const string TimeFormatForFile = "HH-mm-ss";
    
    /// <summary>
    /// 完整时间格式（用于文件名）
    /// </summary>
    public const string DateTimeFormatForFile = "yyyy-MM-dd_HH-mm-ss";

    /// <summary>
    /// 转换为 ISO 8601 字符串（UTC，带毫秒）
    /// </summary>
    public static string ToIso8601String(this DateTime dateTime)
    {
        if (dateTime == default)
            return "";
            
        if (dateTime.Kind == DateTimeKind.Unspecified)
        {
            dateTime = DateTime.SpecifyKind(dateTime, DateTimeKind.Utc);
        }
        return dateTime.ToUniversalTime().ToString(Iso8601Format);
    }
    
    /// <summary>
    /// 转换为 ISO 8601 字符串（UTC，不带毫秒，SQLite 兼容）
    /// </summary>
    public static string ToIso8601StringBasic(this DateTime dateTime)
    {
        if (dateTime == default)
            return "";
            
        if (dateTime.Kind == DateTimeKind.Unspecified)
        {
            dateTime = DateTime.SpecifyKind(dateTime, DateTimeKind.Utc);
        }
        return dateTime.ToUniversalTime().ToString(Iso8601FormatBasic);
    }
    
    /// <summary>
    /// 从 ISO 8601 字符串解析（返回 UTC）
    /// </summary>
    public static DateTime FromIso8601String(string isoString)
    {
        if (string.IsNullOrEmpty(isoString))
            return DateTime.UtcNow;
        
        if (DateTime.TryParseExact(isoString, Iso8601Format, 
            System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.RoundtripKind, 
            out var result))
        {
            return result.ToUniversalTime();
        }
        
        if (DateTime.TryParseExact(isoString, Iso8601FormatBasic,
            System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.RoundtripKind,
            out result))
        {
            return result.ToUniversalTime();
        }
        
        return DateTime.Parse(isoString).ToUniversalTime();
    }
    
    /// <summary>
    /// 获取当前 UTC 时间的开始（00:00:00）
    /// </summary>
    public static DateTime UtcTodayStart()
    {
        var now = DateTime.UtcNow;
        return new DateTime(now.Year, now.Month, now.Day, 0, 0, 0, DateTimeKind.Utc);
    }
    
    /// <summary>
    /// 获取当前 UTC 时间的结束（23:59:59.999）
    /// </summary>
    public static DateTime UtcTodayEnd()
    {
        var now = DateTime.UtcNow;
        return new DateTime(now.Year, now.Month, now.Day, 23, 59, 59, 999, DateTimeKind.Utc);
    }
    
    // ========== 新增辅助方法 ==========
    
    /// <summary>
    /// 获取 UTC 现在时间（带毫秒的 ISO 字符串）
    /// </summary>
    public static string UtcNowIsoString() => DateTime.UtcNow.ToIso8601String();
    
    /// <summary>
    /// 获取 UTC 现在时间（不带毫秒的 ISO 字符串，SQLite 兼容）
    /// </summary>
    public static string UtcNowIsoStringBasic() => DateTime.UtcNow.ToIso8601StringBasic();
    
    /// <summary>
    /// 计算两个 UTC 时间之间的秒数差
    /// </summary>
    public static int SecondsDifference(this DateTime start, DateTime end)
    {
        return (int)(end.ToUniversalTime() - start.ToUniversalTime()).TotalSeconds;
    }
    
    /// <summary>
    /// 检查时间是否已过期
    /// </summary>
    public static bool IsExpired(this DateTime dateTime, TimeSpan? maxAge = null)
    {
        if (dateTime == default) return true;
        if (maxAge.HasValue)
            return DateTime.UtcNow - dateTime.ToUniversalTime() > maxAge.Value;
        return dateTime.ToUniversalTime() < DateTime.UtcNow;
    }
    
    /// <summary>
    /// 安全地转换 DateTime? 为 ISO 字符串
    /// </summary>
    public static string ToIso8601String(this DateTime? dateTime)
    {
        return dateTime.HasValue ? dateTime.Value.ToIso8601String() : "";
    }
    
    /// <summary>
    /// 安全地转换 DateTime? 为基础 ISO 字符串
    /// </summary>
    public static string ToIso8601StringBasic(this DateTime? dateTime)
    {
        return dateTime.HasValue ? dateTime.Value.ToIso8601StringBasic() : "";
    }
    
    /// <summary>
    /// 获取用于文件名的 UTC 时间字符串
    /// </summary>
    public static string ToFileTimeString(this DateTime dateTime)
    {
        return dateTime.ToUniversalTime().ToString(DateTimeFormatForFile);
    }
    
    /// <summary>
    /// 获取日期目录路径（yyyy-MM-dd，UTC，供服务端对齐）
    /// </summary>
    public static string ToDateDirectory(this DateTime dateTime)
    {
        return dateTime.ToUniversalTime().ToString(DateFormat);
    }

    /// <summary>
    /// 获取本地日期目录路径（yyyy-MM-dd，与员工电脑日历一致）
    /// </summary>
    public static string ToLocalDateDirectory(this DateTime dateTime)
    {
        return dateTime.ToLocalTime().ToString(DateFormat);
    }
}

#endregion

#region Metrics Models

/// <summary>
/// 指标快照
/// </summary>
public class MetricsSnapshot
{
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public Dictionary<string, long> Counters { get; set; } = new();
    public Dictionary<string, double> Gauges { get; set; } = new();
    public Dictionary<string, long> Histograms { get; set; } = new();
}

/// <summary>
/// 健康报告
/// </summary>
public class HealthReport
{
    public string Status { get; set; } = "Unknown";  // Healthy, Degraded, Unhealthy
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public List<HealthCheck> Checks { get; set; } = new();
    public string? Details { get; set; }
    public Lifecycle.CaptureLifecycleDiagnostics? CaptureLifecycle { get; set; }
}

/// <summary>
/// 健康检查项
/// </summary>
public class HealthCheck
{
    public string Name { get; set; } = "";
    public bool Healthy { get; set; }
    public string? Message { get; set; }
    public DateTime CheckedAt { get; set; } = DateTime.UtcNow;
    public TimeSpan Duration { get; set; }
}

/// <summary>
/// 队列统计
/// </summary>
public class QueueStats{
    public int PendingCount { get; set; }
    public int UploadingCount { get; set; }
    public int CompletedCount { get; set; }
    public int FailedCount { get; set; }
    public long TotalSizeBytes { get; set; }
    public int TotalUploads { get; set; }
    public int FailedUploads { get; set; }
    public DateTime? LastUploadTime { get; set; }
    
    public string TotalSizeMB => $"{TotalSizeBytes / 1024.0 / 1024.0:F2} MB";
}

/// <summary>
/// 系统指标
/// </summary>
public class SystemMetrics
{
    public double CpuUsagePercent { get; set; }
    public double MemoryUsagePercent { get; set; }
    public long MemoryUsedBytes { get; set; }
    public long DiskFreeBytes { get; set; }
    public long DiskTotalBytes { get; set; }
    public int ThreadCount { get; set; }
    public int HandleCount { get; set; }
    public TimeSpan Uptime { get; set; }
}

/// <summary>
/// 录屏指标
/// </summary>
public class RecordingMetrics
{
    public bool IsRunning { get; set; }
    public double CurrentFps { get; set; }
    public DateTime? LastFrameTime { get; set; }
    public long CurrentFileSize { get; set; }
    public int RestartCount { get; set; }
    public int ConsecutiveFailures { get; set; }
    public string? CurrentEncoder { get; set; }
}

/// <summary>
/// 告警规则
/// </summary>
public class AlertRule
{
    public string Name { get; set; } = "";
    public string Condition { get; set; } = "";
    public string Severity { get; set; } = "warning";  // info, warning, critical
    public string Action { get; set; } = "log";
    public TimeSpan Duration { get; set; } = TimeSpan.Zero;
    public bool Enabled { get; set; } = true;
}

/// <summary>
/// 告警事件
/// </summary>
public class AlertEvent
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; } = "";
    public string Severity { get; set; } = "";
    public string Message { get; set; } = "";
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public Dictionary<string, object>? Metadata { get; set; }
}

#endregion

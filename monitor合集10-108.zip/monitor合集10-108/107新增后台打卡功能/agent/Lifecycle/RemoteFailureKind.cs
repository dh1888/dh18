namespace EnterpriseAgent.Agent.Lifecycle;

public enum RemoteFailureKind
{
    Unknown,
    UserStop,
    TransportError,
    FfmpegCrash,
    ServerKick,
    Timeout,
}

public static class RemoteFailureClassifier
{
    public static RemoteFailureKind Classify(string? detail, bool intentionalUserStop)
    {
        if (intentionalUserStop)
            return RemoteFailureKind.UserStop;

        if (string.IsNullOrWhiteSpace(detail))
            return RemoteFailureKind.Unknown;

        if (detail.Contains("Timed out waiting", StringComparison.OrdinalIgnoreCase))
            return RemoteFailureKind.Timeout;

            // Server / Ingress rejects must win over generic "ffmpeg exited"
        if (detail.Contains("Publish failed", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("Server error", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("Operation not permitted", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("not_found", StringComparison.OrdinalIgnoreCase))
            return RemoteFailureKind.ServerKick;

        if (IsTransportHint(detail))
            return RemoteFailureKind.TransportError;

        if (detail.Contains("exit code -1", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("exited with code -1", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("ffmpeg exited", StringComparison.OrdinalIgnoreCase))
            return RemoteFailureKind.FfmpegCrash;

        return RemoteFailureKind.Unknown;
    }

    /// <summary>Recoverable publish failures: retry without tearing SharedBridge / DualGdigrab.</summary>
    public static bool ShouldReconnectWithoutTeardown(RemoteFailureKind kind, string? detail)
    {
        if (IsPermanentPublishFailure(detail))
            return false;

        if (kind is RemoteFailureKind.TransportError or RemoteFailureKind.Timeout or RemoteFailureKind.ServerKick)
            return true;

        // FFmpeg often exits -1 when RTMP open fails; stderr may already be folded into detail
        if (kind == RemoteFailureKind.FfmpegCrash &&
            (IsTransportHint(detail) || LooksLikeServerReject(detail)))
            return true;

        return false;
    }

    public static bool IsPermanentPublishFailure(string? detail)
    {
        if (string.IsNullOrWhiteSpace(detail))
            return false;

        return detail.Contains("RTMP unstable after", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("WHIP unstable after", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("WHIP_FALLBACK_REQUEST", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("WHIP media path failed", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("exceeded max restarts", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("permanent remote failure", StringComparison.OrdinalIgnoreCase);
    }

    public static bool IsTransportHint(string? detail)
    {
        if (string.IsNullOrWhiteSpace(detail))
            return false;

        // FFmpeg WHIP info lines look like:
        //   [WHIP muxer @ ...] Muxer state=10, ... ice:115.79,dtls:298.87,srtp:0.06
        // Matching bare "DTLS"/"WHIP" here falsely aborts a healthy session.
        if (IsWhipMuxerStatusInfo(detail))
            return false;

        if (detail.Contains("-10053", StringComparison.Ordinal) ||
            detail.Contains("-10054", StringComparison.Ordinal))
            return true;
        if (detail.Contains("Error submitting a packet", StringComparison.OrdinalIgnoreCase))
            return true;
        if (detail.Contains("RTMP transport error", StringComparison.OrdinalIgnoreCase))
            return true;
        if (detail.Contains("Error opening output", StringComparison.OrdinalIgnoreCase))
            return true;
        if (detail.Contains("Error muxing a packet", StringComparison.OrdinalIgnoreCase))
            return true;
        if (detail.Contains("I/O error", StringComparison.OrdinalIgnoreCase) &&
            (detail.Contains("rtmp", StringComparison.OrdinalIgnoreCase) ||
             detail.Contains("whip", StringComparison.OrdinalIgnoreCase)))
            return true;
        if (detail.Contains("WHIP", StringComparison.OrdinalIgnoreCase) &&
            (detail.Contains("failed", StringComparison.OrdinalIgnoreCase) ||
             detail.Contains("error", StringComparison.OrdinalIgnoreCase) ||
             detail.Contains("timeout", StringComparison.OrdinalIgnoreCase)))
            return true;
        if (detail.Contains("DTLS handshake timeout", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("DTLS failed", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("ICE failed", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("no candidate", StringComparison.OrdinalIgnoreCase))
            return true;

        return false;
    }

    /// <summary>Healthy WHIP muxer progress / teardown info — not a transport failure.</summary>
    public static bool IsWhipMuxerStatusInfo(string? detail)
    {
        if (string.IsNullOrWhiteSpace(detail))
            return false;

        if (!detail.Contains("WHIP muxer", StringComparison.OrdinalIgnoreCase) &&
            !detail.Contains("out#0/whip", StringComparison.OrdinalIgnoreCase))
            return false;

        // Timing dump after ICE/DTLS/SRTP success
        if (detail.Contains("Muxer state=", StringComparison.OrdinalIgnoreCase))
            return true;
        if (detail.Contains("Dispose resource", StringComparison.OrdinalIgnoreCase))
            return true;
        if (detail.Contains("muxing overhead", StringComparison.OrdinalIgnoreCase))
            return true;

        return false;
    }

    public static bool LooksLikeServerReject(string? detail)
    {
        if (string.IsNullOrWhiteSpace(detail))
            return false;

        return detail.Contains("Publish failed", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("Server error", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("Operation not permitted", StringComparison.OrdinalIgnoreCase);
    }
}

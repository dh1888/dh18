using System.Threading.Channels;
using EnterpriseAgent.Agent.Recorder;

namespace EnterpriseAgent.Agent.Lifecycle;

/// <summary>
/// Serializes lifecycle intents — no fire-and-forget RequestAsync.
/// Caller cancellation aborts the in-flight executor (linked with queue lifetime).
/// </summary>
public sealed class CaptureIntentQueue : IAsyncDisposable
{
    private readonly Func<RecorderCommand, RecorderRequestContext, CancellationToken, Task<RecorderResult>> _executor;
    private readonly CaptureLifecycleTelemetry _telemetry;
    private readonly Channel<(
        RecorderCommand Command,
        RecorderRequestContext Context,
        TaskCompletionSource<RecorderResult> Completion,
        CancellationTokenSource CommandCts)> _channel;
    private readonly Task _processor;
    private readonly CancellationTokenSource _cts = new();

    public CaptureIntentQueue(
        Func<RecorderCommand, RecorderRequestContext, CancellationToken, Task<RecorderResult>> executor,
        CaptureLifecycleTelemetry telemetry)
    {
        _executor = executor;
        _telemetry = telemetry;
        _channel = Channel.CreateUnbounded<(RecorderCommand, RecorderRequestContext, TaskCompletionSource<RecorderResult>, CancellationTokenSource)>(
            new UnboundedChannelOptions { SingleReader = true, SingleWriter = false });
        _processor = Task.Run(ProcessAsync);
    }

    public async Task<RecorderResult> EnqueueAsync(
        RecorderCommand command,
        RecorderRequestContext context,
        CancellationToken cancellationToken = default)
    {
        var correlationId = _telemetry.NewCorrelationId();
        context = new RecorderRequestContext
        {
            RemoteView = context.RemoteView,
            Reason = string.IsNullOrWhiteSpace(context.Reason)
                ? correlationId
                : $"{context.Reason}|cid={correlationId}",
            PolicyRecordingEnabled = context.PolicyRecordingEnabled,
        };

        _telemetry.AuditIntent(correlationId, command.ToString(), context.Reason);

        var tcs = new TaskCompletionSource<RecorderResult>(TaskCreationOptions.RunContinuationsAsynchronously);
        var commandCts = CancellationTokenSource.CreateLinkedTokenSource(_cts.Token, cancellationToken);
        if (!_channel.Writer.TryWrite((command, context, tcs, commandCts)))
        {
            commandCts.Dispose();
            tcs.SetResult(RecorderResult.Failed(RecorderState.Transitioning, "Lifecycle intent queue unavailable"));
            return await tcs.Task;
        }

        try
        {
            return await tcs.Task.WaitAsync(cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // Abort the worker so Exit/EmergencyStop are not stuck behind a cancelled Enter.
            try { commandCts.Cancel(); } catch (ObjectDisposedException) { }
            throw;
        }
    }

    private async Task ProcessAsync()
    {
        await foreach (var (command, context, completion, commandCts) in _channel.Reader.ReadAllAsync(_cts.Token))
        {
            try
            {
                var result = await _executor(command, context, commandCts.Token);
                completion.TrySetResult(result);
            }
            catch (OperationCanceledException)
            {
                completion.TrySetCanceled(commandCts.Token);
            }
            catch (Exception ex)
            {
                completion.TrySetResult(RecorderResult.Failed(RecorderState.Transitioning, ex.Message));
            }
            finally
            {
                commandCts.Dispose();
            }
        }
    }

    public async ValueTask DisposeAsync()
    {
        _channel.Writer.TryComplete();
        _cts.Cancel();
        try { await _processor.ConfigureAwait(false); }
        catch (OperationCanceledException) { }
        _cts.Dispose();
    }
}

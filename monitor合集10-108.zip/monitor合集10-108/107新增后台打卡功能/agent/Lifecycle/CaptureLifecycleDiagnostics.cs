using EnterpriseAgent.Agent.Recorder;

namespace EnterpriseAgent.Agent.Lifecycle;

/// <summary>
/// Read-only diagnostics for capture lifecycle (P2).
/// </summary>
public sealed class CaptureLifecycleDiagnostics
{
    public CaptureLifecycleState CaptureState { get; init; }
    public RecorderState RecorderState { get; init; }
    public bool IsRemoteActive { get; init; }
    public bool WorkSessionActive { get; init; }
    public bool SharedBridgeForRemote { get; init; }
    public bool StandaloneRemoteActive { get; init; }
    public bool RecordingEnabledByPolicy { get; init; }
    public bool RecordingRunning { get; init; }
    public bool RemotePublishing { get; init; }
    public bool SharedCaptureActive { get; init; }
    public bool PendingPolicyApply { get; init; }
    public DateTime? LastResumeUtc { get; init; }
    public string? LastCorrelationId { get; init; }
    public string? LastTransition { get; init; }
    public DateTime? LastTransitionUtc { get; init; }
    public RestartPolicyDiagnostics RestartPolicies { get; init; } = new();
    public CaptureLifecycleRecordingHealth RecordingHealth { get; init; } = new();
    public IReadOnlyList<string> InvariantViolations { get; init; } = Array.Empty<string>();
    public bool IsHealthy => InvariantViolations.Count == 0;
}

public sealed class CaptureLifecycleRecordingHealth
{
    public bool ShouldBeRecording { get; init; }
    public bool ProcessAlive { get; init; }
    public bool EncoderAlive { get; init; }
    public bool FileRecent { get; init; }
    public bool IsHealthy { get; init; }
    public double StallSeconds { get; init; }
    public string CurrentEncoder { get; init; } = "";
}

public sealed class RestartPolicyDiagnostics
{
    public int LifecycleTransitionsLast5Min { get; init; }
    public int HealthRecoveriesLastHour { get; init; }
    public int EncoderRetriesLast5Min { get; init; }
    public int UserInitiatedLastHour { get; init; }
    public DateTime? LastHealthRecoveryUtc { get; init; }
    public DateTime? LastEncoderRetryUtc { get; init; }
    public DateTime? LastUserInitiatedUtc { get; init; }
}

/// <summary>
/// Pure invariant checks for diagnostics and tests.
/// </summary>
public static class CaptureLifecycleDiagnosticsAnalyzer
{
    public static IReadOnlyList<string> DetectInvariantViolations(
        CaptureLifecycleState captureState,
        bool shouldRecordingBeActive,
        bool recordingRunning,
        bool remoteActive,
        bool remotePublishing,
        bool sharedBridgeForRemote,
        bool sharedCaptureActive)
    {
        var violations = new List<string>();

        if (shouldRecordingBeActive && sharedBridgeForRemote && (remoteActive || remotePublishing) && !recordingRunning)
            violations.Add("recording=false,remote=true");

        if (captureState == CaptureLifecycleState.SharedBridgeRunning && !sharedCaptureActive)
            violations.Add("shared_bridge_running_without_active_bridge");

        if (shouldRecordingBeActive
            && captureState is CaptureLifecycleState.Recording or CaptureLifecycleState.SharedBridgeRunning
            && !recordingRunning)
        {
            violations.Add("recording_expected_but_process_not_running");
        }

        if (remotePublishing && !remoteActive && captureState != CaptureLifecycleState.Stopping)
            violations.Add("remote_publishing_without_lifecycle_remote_active");

        if (sharedBridgeForRemote && remoteActive && !sharedCaptureActive
            && captureState is CaptureLifecycleState.PreparingSharedBridge or CaptureLifecycleState.SharedBridgeRunning)
        {
            violations.Add("shared_bridge_remote_without_bridge");
        }

        return violations;
    }
}

using EnterpriseAgent.Agent.Recorder;

namespace EnterpriseAgent.Agent.Lifecycle;

public interface ILifecycleCoordinator : IRecorderLifecycle
{
    bool WorkSessionActive { get; }
    DateTime LastResumeUtc { get; }
    DateTime LastEnterFailureUtc { get; }
    CaptureLifecycleDiagnostics GetDiagnostics();
    event Func<string?, string, Task>? RemoteViewPublishFailed;
    void UpdatePolicy(Models.Policy policy);
    void NotifySystemResume();
}

using System.Collections.Concurrent;
using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Diagnostics;

public enum DiagnosticLevel
{
    Off = 0,
    Error = 1,
    Warn = 2,
    Info = 3,
    Debug = 4,
    Trace = 5,
}

public sealed class DiagnosticRuntimeConfig
{
    public bool Active { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public DiagnosticLevel GlobalLevel { get; set; } = DiagnosticLevel.Off;
    public Dictionary<string, DiagnosticLevel> ModuleLevels { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public bool AgentUploadEnabled { get; set; } = true;
    public bool FrontendUploadEnabled { get; set; } = true;
}

/// <summary>
/// Unified diagnostic center for Agent modules. Config is pushed from backend via WebSocket.
/// </summary>
public sealed class DiagnosticCenter
{
    private readonly ILogger<DiagnosticCenter> _logger;
    private readonly ConcurrentDictionary<string, DiagnosticLevel> _moduleLevels = new(StringComparer.OrdinalIgnoreCase);
    private volatile DiagnosticRuntimeConfig _runtime = new();
    private Func<string, CancellationToken, Task>? _uploadAsync;

    public DiagnosticCenter(ILogger<DiagnosticCenter> logger)
    {
        _logger = logger;
    }

    public void SetUploader(Func<string, CancellationToken, Task> uploadAsync)
        => _uploadAsync = uploadAsync;

    public DiagnosticRuntimeConfig Current => _runtime;

    public void ApplyRuntimeConfig(DiagnosticRuntimeConfig runtime)
    {
        _runtime = runtime ?? new DiagnosticRuntimeConfig();
        _moduleLevels.Clear();
        foreach (var pair in _runtime.ModuleLevels)
            _moduleLevels[pair.Key] = pair.Value;
    }

    public bool Allows(string module, DiagnosticLevel level)
    {
        var runtime = _runtime;
        if (!runtime.Active || !runtime.AgentUploadEnabled)
            return false;
        if (runtime.ExpiresAt is { } expires && expires <= DateTime.UtcNow)
            return false;

        var moduleLevel = runtime.GlobalLevel;
        if (_moduleLevels.TryGetValue(module, out var configured))
            moduleLevel = configured;
        if (moduleLevel == DiagnosticLevel.Off)
            return false;
        return (int)level <= (int)moduleLevel;
    }

    public void Log(
        ILogger logger,
        string module,
        DiagnosticLevel level,
        string? sessionId,
        string phase,
        string detail)
    {
        if (!Allows(module, level))
            return;

        logger.LogInformation(
            "[DiagnosticCenter] ts={Timestamp:O} module={Module} session={SessionId} phase={Phase} level={Level} detail={Detail}",
            DateTime.UtcNow,
            module,
            string.IsNullOrWhiteSpace(sessionId) ? "-" : sessionId.Trim(),
            phase,
            level,
            detail);

        Upload(module, level, phase, detail, sessionId);
    }

    private void Upload(string module, DiagnosticLevel level, string phase, string detail, string? sessionId)
    {
        if (_uploadAsync == null)
            return;

        var payload = JsonSerializer.Serialize(new
        {
            type = "log",
            module,
            level = level.ToString().ToUpperInvariant(),
            message = $"{phase}: {detail}",
            correlationId = sessionId,
            context = new { phase, sessionId },
        });

        _ = Task.Run(async () =>
        {
            try
            {
                await _uploadAsync(payload, CancellationToken.None);
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Diagnostic upload failed module={Module}", module);
            }
        });
    }

    public static DiagnosticLevel ParseLevel(string? raw)
    {
        return raw?.Trim().ToUpperInvariant() switch
        {
            "ERROR" => DiagnosticLevel.Error,
            "WARN" or "WARNING" => DiagnosticLevel.Warn,
            "INFO" => DiagnosticLevel.Info,
            "DEBUG" => DiagnosticLevel.Debug,
            "TRACE" => DiagnosticLevel.Trace,
            _ => DiagnosticLevel.Off,
        };
    }

    public static DiagnosticRuntimeConfig ParseRuntime(JsonElement root)
    {
        var runtime = new DiagnosticRuntimeConfig
        {
            Active = root.TryGetProperty("active", out var active) && active.GetBoolean(),
            AgentUploadEnabled = !root.TryGetProperty("agentUploadEnabled", out var upload) || upload.GetBoolean(),
            FrontendUploadEnabled = !root.TryGetProperty("frontendUploadEnabled", out var feUpload) || feUpload.GetBoolean(),
            GlobalLevel = root.TryGetProperty("globalLevel", out var global)
                ? ParseLevel(global.GetString())
                : DiagnosticLevel.Off,
        };

        if (root.TryGetProperty("expiresAt", out var expiresEl) &&
            expiresEl.ValueKind == JsonValueKind.String &&
            DateTime.TryParse(expiresEl.GetString(), out var expires))
        {
            runtime.ExpiresAt = DateTime.SpecifyKind(expires, DateTimeKind.Utc);
        }

        if (root.TryGetProperty("moduleLevels", out var modules) && modules.ValueKind == JsonValueKind.Object)
        {
            var levels = new Dictionary<string, DiagnosticLevel>(StringComparer.OrdinalIgnoreCase);
            foreach (var prop in modules.EnumerateObject())
                levels[prop.Name] = ParseLevel(prop.Value.GetString());
            runtime.ModuleLevels = levels;
        }

        return runtime;
    }
}

using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Diagnostics;

internal static class DiagnosticCenterLog
{
    public static void Event(
        ILogger logger,
        DiagnosticCenter center,
        string module,
        DiagnosticLevel level,
        string? sessionId,
        string phase,
        string detail)
        => center.Log(logger, module, level, sessionId, phase, detail);
}

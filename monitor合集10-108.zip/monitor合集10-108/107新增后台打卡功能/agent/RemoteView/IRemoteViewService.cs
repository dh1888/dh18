namespace EnterpriseAgent.Agent.RemoteView;

public sealed class RemoteHealthStatus
{
    public bool IsPublishing { get; init; }
    public bool ProcessAlive { get; init; }
    public bool FrameRecent { get; init; }
    public double FrameAgeSeconds { get; init; }
    public int RestartCount { get; init; }
    public string? SessionId { get; init; }
    public string? LastError { get; init; }
}

public interface IRemoteViewService
{
    bool IsPublishing { get; }
    /// <summary>True while in-place remote encode restart is rebuilding the SharedBridge remote pipe.</summary>
    bool IsRemotePipeRestartInProgress { get; }
    string? ActiveSessionId { get; }
    RemoteViewStats GetStats();
    RemoteHealthStatus GetHealth();
    Task StartAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default);
    /// <summary>
    /// After SharedBridge producer is flowing: wait until WHIP has real media (or fail).
    /// No-op for RTMP / non-WHIP / already flowing.
    /// </summary>
    Task WaitForPublishReadyAsync(CancellationToken cancellationToken = default);
    /// <summary>
    /// After first SharedBridge WHIP publish: sample pipeline health and in-place restart if stuck in ~2fps slow state.
    /// Returns true when a recovery restart was performed.
    /// </summary>
    Task<bool> RecoverSlowSharedBridgePublishIfNeededAsync(
        RemoteViewStartParams parameters,
        CancellationToken cancellationToken = default);
    Task StopAsync(CancellationToken cancellationToken = default);
    /// <summary>Background encoder probe after work session starts (non-blocking).</summary>
    void WarmupEncoderAsync(CancellationToken cancellationToken = default);
    Task ReconnectAsync(string reason, CancellationToken cancellationToken = default);
    string? TakePendingTransportError();
    /// <summary>Consumes and clears the user-initiated stop flag (used to suppress PublishFailed storms).</summary>
    bool TakeUserInitiatedStop();

    event Func<string?, string, Task>? PublishFailed;
}

using EnterpriseAgent.Agent.Diagnostics;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.RemoteView;

/// <summary>
/// Optional remote-view lifecycle diagnostics. Prefer server-pushed DiagnosticCenter config;
/// falls back to RemoteView:LifecycleDiagEnabled in appsettings when center is inactive.
/// </summary>
internal static class RemoteLifecycleDiagLog
{
    private static DiagnosticCenter? _center;
    private static volatile bool _legacyEnabled;

    public static void Bind(DiagnosticCenter center) => _center = center;

    public static void Configure(bool enabled) => _legacyEnabled = enabled;

    public static void Event(
        ILogger logger,
        string module,
        string? sessionId,
        string phase,
        string detail)
    {
        if (_center != null && _center.Current.Active)
        {
            DiagnosticCenterLog.Event(
                logger,
                _center,
                "RemoteView",
                DiagnosticLevel.Info,
                sessionId,
                phase,
                detail);
            return;
        }

        if (!_legacyEnabled || !logger.IsEnabled(LogLevel.Information))
            return;

        logger.LogInformation(
            "[RemoteViewLifecycleDiag] ts={Timestamp:O} module={Module} session={SessionId} phase={Phase} detail={Detail}",
            DateTime.UtcNow,
            module,
            NormalizeSessionId(sessionId),
            phase,
            detail);
    }

    private static string NormalizeSessionId(string? sessionId)
        => string.IsNullOrWhiteSpace(sessionId) ? "-" : sessionId.Trim();
}

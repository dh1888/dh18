// Storage/RecordingRepository.cs - 优化版（支持批量操作）

using EnterpriseAgent.Agent.Models;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Storage;

public class RecordingRepository
{
    private readonly SqliteDbContext _db;
    private readonly ILogger<RecordingRepository> _log;

    public RecordingRepository(SqliteDbContext db, ILogger<RecordingRepository> log)
    {
        _db = db;
        _log = log;
    }

    /// <summary>
    /// 添加录屏记录
    /// </summary>
    public async Task AddAsync(Recording r)
    {
        const int maxRetries = 3;
        int retryCount = 0;

        while (true)
        {
            try
            {
                using var conn = _db.GetConnection();

                using var cmd = new SqliteCommand(@"
                INSERT INTO recordings (id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, retry_count, task_id, upload_id, created_at, updated_at)
                VALUES (@id, @did, @st, @et, @fp, @fs, @sh, @up, @rc, @tid, @uid, @created, @updated)", conn);

                cmd.Parameters.AddWithValue("@id", r.Id);
                cmd.Parameters.AddWithValue("@did", r.DeviceId);
                cmd.Parameters.AddWithValue("@st", r.StartTime.ToIso8601StringBasic());
                cmd.Parameters.AddWithValue("@et", r.EndTime.ToIso8601StringBasic());
                cmd.Parameters.AddWithValue("@fp", r.FilePath);
                cmd.Parameters.AddWithValue("@fs", r.FileSize);
                cmd.Parameters.AddWithValue("@sh", r.Sha256 ?? "");
                cmd.Parameters.AddWithValue("@up", r.Uploaded ? 1 : 0);
                cmd.Parameters.AddWithValue("@rc", r.RetryCount);
                cmd.Parameters.AddWithValue("@tid", r.TaskId ?? "");
                cmd.Parameters.AddWithValue("@uid", r.UploadId ?? "");
                cmd.Parameters.AddWithValue("@created", DateTime.UtcNow.ToIso8601StringBasic());
                cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());

                await cmd.ExecuteNonQueryAsync();
                return; // 成功
            }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 5 || ex.SqliteErrorCode == 6) // BUSY 或 LOCKED
            {
                retryCount++;

                if (retryCount >= maxRetries)
                {
                    _log.LogError(ex, "Failed to insert recording {Id} after {Retries} retries", r.Id, maxRetries);
                    throw;
                }

                var delay = 50 * retryCount;

                _log.LogDebug(
                    ex,
                    "Database busy (error {ErrorCode}), retry {Retry}/{Max} in {Delay}ms",
                    ex.SqliteErrorCode,
                    retryCount,
                    maxRetries,
                    delay);

                await Task.Delay(delay);
            }
            catch (ObjectDisposedException ex)
            {
                retryCount++;

                if (retryCount >= maxRetries)
                {
                    _log.LogError(ex, "Connection disposed for recording {Id} after {Retries} retries", r.Id, maxRetries);
                    throw;
                }

                await Task.Delay(100 * retryCount);

                _log.LogDebug(
                    "Connection disposed, retrying with new connection {Retry}/{Max}",
                    retryCount,
                    maxRetries);

                _db.InvalidateConnection();
            }
            // 可选：添加超时重试
            catch (TimeoutException ex)
            {
                retryCount++;

                if (retryCount >= maxRetries)
                {
                    throw;
                }

                await Task.Delay(50 * retryCount);

                _log.LogDebug(ex, "Timeout, retrying");
            }
        }
    }

    /// <summary>
    /// 批量添加录屏记录
    /// </summary>
    public async Task AddBatchAsync(IEnumerable<Recording> recordings)
    {
        foreach (var recording in recordings)
        {
            await _db.AddBatchOperationAsync(conn =>
            {
                using var cmd = new SqliteCommand(@"
                    INSERT OR REPLACE INTO recordings (id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, retry_count, task_id, upload_id, updated_at)
                    VALUES (@id, @did, @st, @et, @fp, @fs, @sh, @up, @rc, @tid, @uid, @updated)", conn);
                
                cmd.Parameters.AddWithValue("@id", recording.Id);
                cmd.Parameters.AddWithValue("@did", recording.DeviceId);
                cmd.Parameters.AddWithValue("@st", recording.StartTime.ToIso8601StringBasic());
                cmd.Parameters.AddWithValue("@et", recording.EndTime.ToIso8601StringBasic());
                cmd.Parameters.AddWithValue("@fp", recording.FilePath);
                cmd.Parameters.AddWithValue("@fs", recording.FileSize);
                cmd.Parameters.AddWithValue("@sh", recording.Sha256 ?? "");
                cmd.Parameters.AddWithValue("@up", recording.Uploaded ? 1 : 0);
                cmd.Parameters.AddWithValue("@rc", recording.RetryCount);
                cmd.Parameters.AddWithValue("@tid", recording.TaskId ?? "");
                cmd.Parameters.AddWithValue("@uid", recording.UploadId ?? "");
                cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
                
                cmd.ExecuteNonQuery();
            });
        }
    }

    /// <summary>
    /// 更新上传状态
    /// </summary>
    public async Task UpdateUploadStatusAsync(string id, bool uploaded)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE recordings 
            SET uploaded = @up, updated_at = @updated 
            WHERE id = @id", conn);
        
        cmd.Parameters.AddWithValue("@up", uploaded ? 1 : 0);
        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 按本地文件路径标记录屏已上传（FileId 缺失或无效时的兜底）。
    /// </summary>
    public async Task<int> MarkUploadedByFilePathAsync(string filePath)
    {
        if (string.IsNullOrWhiteSpace(filePath))
            return 0;

        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE recordings
            SET uploaded = 1, updated_at = @updated
            WHERE file_path = @fp AND uploaded = 0", conn);

        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@fp", filePath);
        return await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 更新上传 ID
    /// </summary>
    public async Task UpdateUploadIdAsync(string id, string uploadId)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE recordings 
            SET upload_id = @uid, updated_at = @updated 
            WHERE id = @id", conn);
        
        cmd.Parameters.AddWithValue("@uid", uploadId);
        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 获取未上传的录屏记录
    /// </summary>
    public async Task<List<Recording>> GetUnuploadedAsync(DateTime start, DateTime end)
    {
        var result = new List<Recording>();
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, retry_count, task_id, upload_id 
            FROM recordings 
            WHERE start_time <= @et AND end_time >= @st AND uploaded = 0
            ORDER BY start_time ASC", conn);
        
        cmd.Parameters.AddWithValue("@st", start.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@et", end.ToIso8601StringBasic());
        
        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new Recording
            {
                Id = reader.GetString(0),
                DeviceId = reader.GetString(1),
                StartTime = DateTimeExtensions.FromIso8601String(reader.GetString(2)),
                EndTime = DateTimeExtensions.FromIso8601String(reader.GetString(3)),
                FilePath = reader.GetString(4),
                FileSize = reader.GetInt64(5),
                Sha256 = reader.IsDBNull(6) ? "" : reader.GetString(6),
                Uploaded = reader.GetInt32(7) == 1,
                RetryCount = reader.GetInt32(8),
                TaskId = reader.IsDBNull(9) ? "" : reader.GetString(9),
                UploadId = reader.IsDBNull(10) ? "" : reader.GetString(10)
            });
        }
        return result;
    }

    /// <summary>
    /// 获取最近的录屏记录
    /// </summary>
    public async Task<Recording?> GetLatestAsync(string deviceId)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, retry_count, task_id, upload_id 
            FROM recordings 
            WHERE device_id = @did
            ORDER BY end_time DESC 
            LIMIT 1", conn);
        
        cmd.Parameters.AddWithValue("@did", deviceId);
        
        using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            return new Recording
            {
                Id = reader.GetString(0),
                DeviceId = reader.GetString(1),
                StartTime = DateTimeExtensions.FromIso8601String(reader.GetString(2)),
                EndTime = DateTimeExtensions.FromIso8601String(reader.GetString(3)),
                FilePath = reader.GetString(4),
                FileSize = reader.GetInt64(5),
                Sha256 = reader.IsDBNull(6) ? "" : reader.GetString(6),
                Uploaded = reader.GetInt32(7) == 1,
                RetryCount = reader.GetInt32(8),
                TaskId = reader.IsDBNull(9) ? "" : reader.GetString(9),
                UploadId = reader.IsDBNull(10) ? "" : reader.GetString(10)
            };
        }
        return null;
    }

    /// <summary>
    /// 删除指定日期前的录屏记录（仅已上传的）
    /// </summary>
    public async Task<int> DeleteOlderThanAsync(DateTime cutoff)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            DELETE FROM recordings 
            WHERE end_time < @cut AND uploaded = 1", conn);
        cmd.Parameters.AddWithValue("@cut", cutoff.ToIso8601StringBasic());
        var deleted = await cmd.ExecuteNonQueryAsync();
        
        if (deleted > 0)
        {
            _log.LogDebug("Deleted {Count} old recording records older than {Cutoff}", 
                deleted, cutoff.ToIso8601StringBasic());
        }
        
        return deleted;
    }

    /// <summary>
    /// 获取统计信息
    /// </summary>
    public async Task<(int total, int uploaded, int pending)> GetStatsAsync(string deviceId)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN uploaded = 1 THEN 1 ELSE 0 END) as uploaded,
                SUM(CASE WHEN uploaded = 0 THEN 1 ELSE 0 END) as pending
            FROM recordings 
            WHERE device_id = @did", conn);
        
        cmd.Parameters.AddWithValue("@did", deviceId);
        
        using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            return (
                reader.GetInt32(0),
                reader.GetInt32(1),
                reader.GetInt32(2)
            );
        }
        return (0, 0, 0);
    }

    /// <summary>
    /// 检查指定文件路径的录屏记录是否已存在
    /// </summary>
    public async Task<bool> ExistsByFilePathAsync(string filePath)
    {
        return await GetByFilePathAsync(filePath) != null;
    }

    /// <summary>
    /// 按文件路径获取录屏记录
    /// </summary>
    public async Task<Recording?> GetByFilePathAsync(string filePath)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, retry_count, task_id, upload_id
            FROM recordings WHERE file_path = @fp LIMIT 1", conn);
        cmd.Parameters.AddWithValue("@fp", filePath);

        using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync())
            return null;

        return new Recording
        {
            Id = reader.GetString(0),
            DeviceId = reader.GetString(1),
            StartTime = DateTime.Parse(reader.GetString(2)).ToUniversalTime(),
            EndTime = DateTime.Parse(reader.GetString(3)).ToUniversalTime(),
            FilePath = reader.GetString(4),
            FileSize = reader.GetInt64(5),
            Sha256 = reader.IsDBNull(6) ? "" : reader.GetString(6),
            Uploaded = reader.GetInt64(7) == 1,
            RetryCount = reader.GetInt32(8),
            TaskId = reader.IsDBNull(9) ? "" : reader.GetString(9),
            UploadId = reader.IsDBNull(10) ? "" : reader.GetString(10),
        };
    }

    /// <summary>
    /// 更新录屏文件元数据（用于索引阶段文件长大后补全）
    /// </summary>
    public async Task UpdateMetadataAsync(string id, long fileSize, string sha256, DateTime startTime, DateTime endTime)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE recordings
            SET file_size = @fs, sha256 = @sh, start_time = @st, end_time = @et, updated_at = @updated
            WHERE id = @id", conn);

        cmd.Parameters.AddWithValue("@fs", fileSize);
        cmd.Parameters.AddWithValue("@sh", sha256 ?? "");
        cmd.Parameters.AddWithValue("@st", startTime.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@et", endTime.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }
}
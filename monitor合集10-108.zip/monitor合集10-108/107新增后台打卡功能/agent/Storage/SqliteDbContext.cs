// Storage/SqliteDbContext.cs - 完整修复版（已添加 AddBatchOperation 方法）

using System.Threading;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Logging;
using EnterpriseAgent.Agent.Models;
using System.Text.Json;

namespace EnterpriseAgent.Agent.Storage;

/// <summary>
/// SQLite 数据库上下文 - 每次操作使用独立连接（线程安全）
/// </summary>
public class SqliteDbContext : IDisposable
{
    private readonly string _connectionString;
    private readonly ILogger<SqliteDbContext> _logger;
    private bool _disposed;

    private readonly object _poolLock = new();
    private DateTime _lastClearPoolTime = DateTime.MinValue;
    private readonly TimeSpan _clearPoolCooldown = TimeSpan.FromSeconds(30);

    // ✅ 批量操作缓冲区
    private const int MaxPendingBatchOperations = 10000;
    private readonly List<Action<SqliteConnection>> _pendingBatchOperations = new();
    private readonly SemaphoreSlim _batchLock = new(1, 1);
    private System.Threading.Timer? _batchFlushTimer;
    private bool _isBatching;
    private int _flushRunning;

    public SqliteDbContext(string dbPath, ILogger<SqliteDbContext> logger)
    {
        _logger = logger;
        var dir = Path.GetDirectoryName(dbPath);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
        {
            Directory.CreateDirectory(dir);
        }
        
        _connectionString = $"Data Source={dbPath};Pooling=true;";
        Initialize();
        
        // 启动批量写入定时器（异步触发，避免 Timer 线程阻塞）
        _batchFlushTimer = new System.Threading.Timer(
            _ => _ = TriggerFlushAsync(),
            null,
            TimeSpan.FromSeconds(Constants.BatchWriteIntervalSeconds),
            TimeSpan.FromSeconds(Constants.BatchWriteIntervalSeconds));
    }

    private async Task TriggerFlushAsync()
    {
        if (Interlocked.CompareExchange(ref _flushRunning, 1, 0) != 0)
            return;

        try
        {
            await FlushBatchAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Scheduled batch flush failed");
        }
        finally
        {
            Interlocked.Exchange(ref _flushRunning, 0);
        }
    }

    private void EnqueueBatchOperation(Action<SqliteConnection> operation)
    {
        if (_pendingBatchOperations.Count >= MaxPendingBatchOperations)
        {
            _logger.LogWarning(
                "Batch queue at capacity ({Max}), dropping oldest operation",
                MaxPendingBatchOperations);
            _pendingBatchOperations.RemoveAt(0);
        }

        _pendingBatchOperations.Add(operation);
    }

    private void Initialize()
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        
        // 启用 WAL 模式（Write-Ahead Logging）提高并发性能
        using var walCmd = new SqliteCommand("PRAGMA journal_mode=WAL;", conn);
        walCmd.ExecuteNonQuery();
        
        // 设置忙等待超时
        using var busyCmd = new SqliteCommand("PRAGMA busy_timeout=5000;", conn);
        busyCmd.ExecuteNonQuery();
        
        // 设置同步模式（NORMAL 是性能和安全的平衡）
        using var syncCmd = new SqliteCommand("PRAGMA synchronous=NORMAL;", conn);
        syncCmd.ExecuteNonQuery();
        
        // 设置缓存大小（默认2000页，约2MB）
        using var cacheCmd = new SqliteCommand("PRAGMA cache_size=2000;", conn);
        cacheCmd.ExecuteNonQuery();
        
        var sql = @"
            -- ========== 录屏表 ==========
            CREATE TABLE IF NOT EXISTS recordings (
                id TEXT PRIMARY KEY,
                device_id TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                file_path TEXT NOT NULL,
                file_size INTEGER,
                sha256 TEXT,
                uploaded INTEGER DEFAULT 0,
                retry_count INTEGER DEFAULT 0,
                task_id TEXT,
                upload_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            -- ========== 截图表 ==========
            CREATE TABLE IF NOT EXISTS screenshots (
                id TEXT PRIMARY KEY,
                device_id TEXT NOT NULL,
                captured_at TEXT NOT NULL,
                file_path TEXT NOT NULL,
                file_size INTEGER,
                uploaded INTEGER DEFAULT 0,
                encrypted INTEGER DEFAULT 0,
                upload_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            -- ========== 活动日志表 ==========
            CREATE TABLE IF NOT EXISTS activity_logs (
                id TEXT PRIMARY KEY,
                device_id TEXT NOT NULL,
                process_name TEXT,
                window_title TEXT,
                browser_title TEXT,
                started_at TEXT NOT NULL,
                ended_at TEXT,
                is_idle INTEGER DEFAULT 0,
                duration_seconds INTEGER DEFAULT 0,
                reported INTEGER DEFAULT 0,
                reported_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            -- ========== 上传队列表 ==========
            CREATE TABLE IF NOT EXISTS upload_queue (
                id TEXT PRIMARY KEY,
                file_path TEXT NOT NULL,
                file_type TEXT NOT NULL,
                file_id TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                offset INTEGER DEFAULT 0,
                retry_count INTEGER DEFAULT 0,
                error_message TEXT,
                last_retry_at TEXT,
                last_upload_activity TEXT,
                upload_id TEXT,
                record_start_time TEXT,
                record_end_time TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            -- ========== 清理日志表 ==========
            CREATE TABLE IF NOT EXISTS cleanup_logs (
                id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                message TEXT NOT NULL,
                recording_file_deletes INTEGER DEFAULT 0,
                screenshot_file_deletes INTEGER DEFAULT 0,
                screenshot_row_deletes INTEGER DEFAULT 0,
                activity_log_deletes INTEGER DEFAULT 0,
                failed_upload_queue_deletes INTEGER DEFAULT 0,
                created_at TEXT NOT NULL
            );

            -- ========== 设备信息表 ==========
            CREATE TABLE IF NOT EXISTS device_info (
                id TEXT PRIMARY KEY,
                device_id TEXT UNIQUE NOT NULL,
                hostname TEXT,
                os_version TEXT,
                agent_version TEXT,
                fingerprint TEXT,
                fingerprint_score REAL,
                bound_employee_id TEXT,
                bound_at TEXT,
                status TEXT,
                last_seen_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            -- ========== 策略缓存表 ==========
            CREATE TABLE IF NOT EXISTS policy_cache (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                version INTEGER NOT NULL,
                content TEXT NOT NULL,
                signature TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            -- ========== 健康检查日志表（新增）==========
            CREATE TABLE IF NOT EXISTS health_logs (
                id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                message TEXT,
                details TEXT,
                created_at TEXT NOT NULL
            );

            -- ========== 索引 ==========
            CREATE INDEX IF NOT EXISTS idx_recordings_device_id ON recordings(device_id);
            CREATE INDEX IF NOT EXISTS idx_recordings_start_time ON recordings(start_time);
            CREATE INDEX IF NOT EXISTS idx_recordings_file_path ON recordings(file_path);
            CREATE INDEX IF NOT EXISTS idx_recordings_uploaded ON recordings(uploaded);
            
            CREATE INDEX IF NOT EXISTS idx_screenshots_device_id ON screenshots(device_id);
            CREATE INDEX IF NOT EXISTS idx_screenshots_captured_at ON screenshots(captured_at);
            CREATE INDEX IF NOT EXISTS idx_screenshots_uploaded ON screenshots(uploaded);
            
            CREATE INDEX IF NOT EXISTS idx_activity_logs_device_id ON activity_logs(device_id);
            CREATE INDEX IF NOT EXISTS idx_activity_logs_started_at ON activity_logs(started_at);
            CREATE INDEX IF NOT EXISTS idx_activity_logs_process_name ON activity_logs(process_name);
            
            CREATE INDEX IF NOT EXISTS idx_upload_queue_status ON upload_queue(status);
            CREATE INDEX IF NOT EXISTS idx_upload_queue_file_id ON upload_queue(file_id);
            CREATE INDEX IF NOT EXISTS idx_upload_queue_file_type ON upload_queue(file_type);
            CREATE INDEX IF NOT EXISTS idx_upload_queue_file_path ON upload_queue(file_path);
            
            CREATE INDEX IF NOT EXISTS idx_cleanup_logs_created_at ON cleanup_logs(created_at);
            
            CREATE INDEX IF NOT EXISTS idx_device_info_device_id ON device_info(device_id);
            CREATE INDEX IF NOT EXISTS idx_device_info_status ON device_info(status);
            
            CREATE INDEX IF NOT EXISTS idx_health_logs_created_at ON health_logs(created_at);
        ";
        
        using var cmd = new SqliteCommand(sql, conn);
        cmd.ExecuteNonQuery();

        // ✅ 在这里定义 addColumnsMigrations 数组
        var addColumnsMigrations = new[]
        {
            "ALTER TABLE activity_logs ADD COLUMN reported INTEGER DEFAULT 0",
            "ALTER TABLE activity_logs ADD COLUMN reported_at TEXT",
            "ALTER TABLE activity_logs ADD COLUMN retry_count INTEGER DEFAULT 0",
            "ALTER TABLE activity_logs ADD COLUMN error_message TEXT DEFAULT ''" 
        };

        foreach (var migration in addColumnsMigrations)
        {
            try
            {
                using var addCmd = new SqliteCommand(migration, conn);
                addCmd.ExecuteNonQuery();
                _logger.LogDebug("Migration executed: {Migration}", migration);
            }
            catch (SqliteException ex) when (ex.Message.Contains("duplicate column name"))
            {
                // 列已存在，忽略
                _logger.LogDebug("Column already exists: {Migration}", migration);
            }
            catch (Exception ex)
            {
                // 其他错误也忽略，继续执行
                _logger.LogDebug(ex, "Migration skipped: {Migration}", migration);
            }
        }
        
        _logger.LogInformation("Database initialized with all tables and indexes");
    }

    /// <summary>
    /// 创建并打开新的数据库连接（调用方负责 Dispose）
    /// </summary>
    public SqliteConnection CreateConnection()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(SqliteDbContext));

        var conn = new SqliteConnection(_connectionString);
        conn.Open();
        ApplyConnectionPragmas(conn);
        return conn;
    }

    /// <summary>
    /// 创建并打开新的数据库连接（调用方负责 Dispose）
    /// </summary>
    public async Task<SqliteConnection> CreateConnectionAsync(CancellationToken ct = default)
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(SqliteDbContext));

        var conn = new SqliteConnection(_connectionString);
        await conn.OpenAsync(ct);
        await ApplyConnectionPragmasAsync(conn, ct);
        return conn;
    }

    /// <summary>
    /// 获取数据库连接（每次返回独立连接，须 using 释放）
    /// </summary>
    public Task<SqliteConnection> GetConnectionAsync(CancellationToken ct = default)
        => CreateConnectionAsync(ct);

    /// <summary>
    /// 获取数据库连接（每次返回独立连接，须 using 释放）
    /// </summary>
    public SqliteConnection GetConnection()
        => CreateConnection();

    private static void ApplyConnectionPragmas(SqliteConnection conn)
    {
        using var busyCmd = new SqliteCommand("PRAGMA busy_timeout=5000;", conn);
        busyCmd.ExecuteNonQuery();
    }

    private static async Task ApplyConnectionPragmasAsync(SqliteConnection conn, CancellationToken ct = default)
    {
        using var busyCmd = new SqliteCommand("PRAGMA busy_timeout=5000;", conn);
        await busyCmd.ExecuteNonQueryAsync(ct);
    }

    /// <summary>
    /// 在独立连接上执行数据库操作
    /// </summary>
    public async Task<T> ExecuteAsync<T>(Func<SqliteConnection, Task<T>> action, CancellationToken ct = default)
    {
        await using var conn = await CreateConnectionAsync(ct);
        return await action(conn);
    }

    /// <summary>
    /// 在独立连接上执行数据库操作
    /// </summary>
    public async Task ExecuteAsync(Func<SqliteConnection, Task> action, CancellationToken ct = default)
    {
        await using var conn = await CreateConnectionAsync(ct);
        await action(conn);
    }

    /// <summary>
    /// 添加批量操作（异步版本）
    /// </summary>
    public async Task AddBatchOperationAsync(Action<SqliteConnection> operation)
    {
        if (_disposed) return;
        
        await _batchLock.WaitAsync();
        try
        {
            EnqueueBatchOperation(operation);
            
            if (_pendingBatchOperations.Count >= Constants.BatchWriteThreshold && !_isBatching)
            {
                _ = TriggerFlushAsync();
            }
        }
        finally
        {
            _batchLock.Release();
        }
    }

    /// <summary>
    /// 添加批量操作（同步版本）- 用于 Repository 中的同步调用
    /// </summary>
    public void AddBatchOperation(Action<SqliteConnection> operation)
    {
        if (_disposed) return;
        
        _batchLock.Wait();
        try
        {
            EnqueueBatchOperation(operation);
            
            if (_pendingBatchOperations.Count >= Constants.BatchWriteThreshold && !_isBatching)
            {
                _ = TriggerFlushAsync();
            }
        }
        finally
        {
            _batchLock.Release();
        }
    }
    
    /// <summary>
    /// 批量写入
    /// </summary>
    private async Task FlushBatchAsync()
    {
        if (_disposed)
            return;

        List<Action<SqliteConnection>> batch;
        
        await _batchLock.WaitAsync();
        try
        {
            if (_isBatching || _pendingBatchOperations.Count == 0)
                return;
            
            _isBatching = true;
            batch = new List<Action<SqliteConnection>>(_pendingBatchOperations);
            _pendingBatchOperations.Clear();
        }
        finally
        {
            _batchLock.Release();
        }
        
        try
        {
            // 使用独立连接和事务进行批量写入，避免与长期持有的全局连接冲突
            using var conn = new SqliteConnection(_connectionString);
            await conn.OpenAsync();

            using var transaction = conn.BeginTransaction();

            try
            {
                foreach (var operation in batch)
                {
                    try
                    {
                        operation(conn);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Batch operation failed, continuing with next");
                    }
                }

                transaction.Commit();
                _logger.LogDebug("Flushed {Count} batch operations", batch.Count);
            }
            catch
            {
                try { transaction.Rollback(); } catch { }
                throw;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to flush batch operations");
            // 重新加入队列并应用简单退避
            await _batchLock.WaitAsync();
            try
            {
                var remaining = MaxPendingBatchOperations - _pendingBatchOperations.Count;
                if (remaining <= 0)
                {
                    _logger.LogWarning("Batch queue full, cannot requeue failed batch of {Count}", batch.Count);
                }
                else if (batch.Count > remaining)
                {
                    _pendingBatchOperations.InsertRange(0, batch.GetRange(0, remaining));
                    _logger.LogWarning(
                        "Requeued {Requeued}/{Total} failed batch operations (queue cap)",
                        remaining,
                        batch.Count);
                }
                else
                {
                    _pendingBatchOperations.InsertRange(0, batch);
                }
            }
            finally
            {
                _batchLock.Release();
            }

            // 等待一小段时间再重试下一次 Flush，避免紧急循环
            await Task.Delay(TimeSpan.FromSeconds(2));
        }
        finally
        {
            _isBatching = false;
        }
    }

    /// <summary>
    /// 执行数据库迁移
    /// </summary>
    public async Task MigrateAsync()
    {
        await using var conn = await CreateConnectionAsync();
        
        var migrations = new List<string>
        {
            "CREATE INDEX IF NOT EXISTS idx_recordings_device_id ON recordings(device_id)",
            "CREATE INDEX IF NOT EXISTS idx_recordings_start_time ON recordings(start_time)",
            "CREATE INDEX IF NOT EXISTS idx_recordings_file_path ON recordings(file_path)",
            "CREATE INDEX IF NOT EXISTS idx_screenshots_device_id ON screenshots(device_id)",
            "CREATE INDEX IF NOT EXISTS idx_screenshots_captured_at ON screenshots(captured_at)",
            "CREATE INDEX IF NOT EXISTS idx_screenshots_uploaded ON screenshots(uploaded)",
            "CREATE INDEX IF NOT EXISTS idx_activity_logs_device_id ON activity_logs(device_id)",
            "CREATE INDEX IF NOT EXISTS idx_activity_logs_process_name ON activity_logs(process_name)",
            "CREATE INDEX IF NOT EXISTS idx_upload_queue_file_id ON upload_queue(file_id)",
            "CREATE INDEX IF NOT EXISTS idx_upload_queue_file_type ON upload_queue(file_type)",
            "CREATE INDEX IF NOT EXISTS idx_upload_queue_file_path ON upload_queue(file_path)",
            "CREATE INDEX IF NOT EXISTS idx_device_info_device_id ON device_info(device_id)",
            
            // ✅ 新增列迁移
            "ALTER TABLE recordings ADD COLUMN upload_id TEXT DEFAULT ''",
            "ALTER TABLE screenshots ADD COLUMN encrypted INTEGER DEFAULT 0",
            "ALTER TABLE screenshots ADD COLUMN upload_id TEXT DEFAULT ''",
            "ALTER TABLE upload_queue ADD COLUMN record_start_time TEXT",
            "ALTER TABLE upload_queue ADD COLUMN record_end_time TEXT",
            // 新增字段：上次上传活动时间（用于判断上传是否卡住）
            "ALTER TABLE upload_queue ADD COLUMN last_upload_activity TEXT"
        };
        
        foreach (var migration in migrations)
        {
            try
            {
                using var cmd = new SqliteCommand(migration, conn);
                await cmd.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                // 列可能已存在，忽略错误
                _logger.LogDebug(ex, "Migration skipped: {Migration}", migration);
            }
        }
        
        _logger.LogInformation("Database migration completed");
    }

    /// <summary>
    /// 获取数据库大小（字节）
    /// </summary>
    public async Task<long> GetDatabaseSizeAsync()
    {
        await using var conn = await CreateConnectionAsync();
        using var cmd = new SqliteCommand("SELECT page_count * page_size FROM pragma_page_count(), pragma_page_size();", conn);
        var result = await cmd.ExecuteScalarAsync();
        return result != null ? Convert.ToInt64(result) : 0;
    }

    /// <summary>
    /// 执行 VACUUM 压缩数据库
    /// </summary>
    public async Task VacuumAsync()
    {
        await using var conn = await CreateConnectionAsync();
        using var cmd = new SqliteCommand("VACUUM;", conn);
        await cmd.ExecuteNonQueryAsync();
        _logger.LogInformation("Database vacuum completed");
    }

    /// <summary>
    /// 检查数据库完整性
    /// </summary>
    public async Task<bool> IntegrityCheckAsync()
    {
        await using var conn = await CreateConnectionAsync();
        using var cmd = new SqliteCommand("PRAGMA integrity_check;", conn);
        var result = await cmd.ExecuteScalarAsync();
        var isOk = result?.ToString() == "ok";
        
        if (!isOk)
        {
            _logger.LogError("Database integrity check failed: {Result}", result);
        }
        
        return isOk;
    }

    /// <summary>
    /// 刷新待处理的批量操作并关闭
    /// </summary>
    public async Task FlushAndShutdownAsync()
    {
        _logger.LogInformation("Flushing pending batch operations...");

        var maxWait = TimeSpan.FromSeconds(10);
        var startTime = DateTime.UtcNow;

        while (_pendingBatchOperations.Count > 0 &&
               DateTime.UtcNow - startTime < maxWait)
        {
            await FlushBatchAsync();
            await Task.Delay(100);
        }

        if (_pendingBatchOperations.Count > 0)
        {
            _logger.LogWarning(
                "Still have {Count} pending operations after shutdown timeout",
                _pendingBatchOperations.Count);
        }

        _logger.LogInformation("Batch flush completed");
    }

    /// <summary>
    /// 清空连接池（在持续 database locked 时调用）
    /// </summary>
    public void InvalidateConnection()
    {
        lock (_poolLock)
        {
            if (DateTime.UtcNow - _lastClearPoolTime <= _clearPoolCooldown)
                return;

            SqliteConnection.ClearPool(new SqliteConnection(_connectionString));
            _lastClearPoolTime = DateTime.UtcNow;
            _logger.LogDebug("Connection pool cleared");
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        
        TriggerFlushAsync().Wait(TimeSpan.FromSeconds(5));
        
        _batchFlushTimer?.Dispose();
        _batchLock.Dispose();
        
        _logger.LogInformation("Database context disposed");
    }
}


/// <summary>
/// 本地缓存的策略及其签名原文
/// </summary>
public sealed class CachedPolicy
{
    public Policy Policy { get; }
    public string SignedContentJson { get; }
    public string SignatureAlg { get; }
    public int SignatureVersion { get; }
    public string KeyId { get; }

    public CachedPolicy(
        Policy policy,
        string signedContentJson,
        string signatureAlg,
        int signatureVersion,
        string keyId)
    {
        Policy = policy;
        SignedContentJson = signedContentJson;
        SignatureAlg = signatureAlg;
        SignatureVersion = signatureVersion;
        KeyId = keyId;
    }
}

/// <summary>
/// 策略仓储 - 管理本地缓存的策略
/// </summary>
public class PolicyRepository
{
    private readonly SqliteDbContext _db;

    public PolicyRepository(SqliteDbContext db)
    {
        _db = db;
    }

    /// <summary>
    /// 缓存策略（content 为与后端签名一致的原始 JSON）
    /// </summary>
    public async Task CacheAsync(
        Policy policy,
        string signedContentJson,
        string signatureAlg,
        int signatureVersion,
        string keyId)
    {
        using var conn = _db.GetConnection();
        
        using var createCmd = new SqliteCommand(@"
            CREATE TABLE IF NOT EXISTS policy_cache (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                version INTEGER NOT NULL,
                content TEXT NOT NULL,
                signature TEXT NOT NULL,
                signature_alg TEXT,
                signature_version INTEGER,
                key_id TEXT,
                updated_at TEXT NOT NULL
            )", conn);
        await createCmd.ExecuteNonQueryAsync();

        await EnsurePolicyCacheColumnsAsync(conn);
        
        using var cmd = new SqliteCommand(@"
            INSERT OR REPLACE INTO policy_cache (
                id, version, content, signature, signature_alg, signature_version, key_id, updated_at)
            VALUES (1, @version, @content, @signature, @signatureAlg, @signatureVersion, @keyId, @updated)", conn);
        
        cmd.Parameters.AddWithValue("@version", policy.Version);
        cmd.Parameters.AddWithValue("@content", signedContentJson);
        cmd.Parameters.AddWithValue("@signature", policy.Signature ?? "");
        cmd.Parameters.AddWithValue("@signatureAlg", signatureAlg);
        cmd.Parameters.AddWithValue("@signatureVersion", signatureVersion);
        cmd.Parameters.AddWithValue("@keyId", keyId);
        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601String());
        
        await cmd.ExecuteNonQueryAsync();
    }

    private static async Task EnsurePolicyCacheColumnsAsync(SqliteConnection conn)
    {
        var existing = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using (var pragma = new SqliteCommand("PRAGMA table_info(policy_cache)", conn))
        using (var reader = await pragma.ExecuteReaderAsync())
        {
            while (await reader.ReadAsync())
                existing.Add(reader.GetString(1));
        }

        async Task AddColumnIfMissing(string name, string ddl)
        {
            if (existing.Contains(name))
                return;
            using var alter = new SqliteCommand($"ALTER TABLE policy_cache ADD COLUMN {ddl}", conn);
            await alter.ExecuteNonQueryAsync();
        }

        await AddColumnIfMissing("signature_alg", "signature_alg TEXT");
        await AddColumnIfMissing("signature_version", "signature_version INTEGER");
        await AddColumnIfMissing("key_id", "key_id TEXT");
    }

    /// <summary>
    /// 获取缓存的策略
    /// </summary>
    public async Task<CachedPolicy?> GetCachedAsync()
    {
        using var conn = _db.GetConnection();
        
        using var cmd = new SqliteCommand(@"
            SELECT content, signature, version, updated_at, signature_alg, signature_version, key_id
            FROM policy_cache 
            WHERE id = 1", conn);
        
        using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            var content = reader.GetString(0);
            var signature = reader.GetString(1);
            var version = reader.GetInt32(2);
            var signatureAlg = reader.IsDBNull(4) ? "" : reader.GetString(4);
            var signatureVersion = reader.IsDBNull(5) ? 0 : reader.GetInt32(5);
            var keyId = reader.IsDBNull(6) ? "" : reader.GetString(6);
            
            var policy = JsonSerializer.Deserialize<Policy>(content);
            if (policy != null)
            {
                policy.Signature = signature;
                policy.Version = version;
                return new CachedPolicy(
                    policy,
                    content,
                    signatureAlg,
                    signatureVersion,
                    keyId);
            }
        }
        
        return null;
    }

    /// <summary>
    /// 清除策略缓存
    /// </summary>
    public async Task ClearAsync()
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand("DELETE FROM policy_cache WHERE id = 1", conn);
        await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 获取缓存的策略版本
    /// </summary>
    public async Task<int> GetCachedVersionAsync()
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand("SELECT version FROM policy_cache WHERE id = 1", conn);
        var result = await cmd.ExecuteScalarAsync();
        return result != null ? Convert.ToInt32(result) : 0;
    }
}
// Services/TaskSchedulerService.cs - 优化版（移除冗余）

using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using EnterpriseAgent.Agent.Extensions;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

// 任务状态枚举
public enum TaskStatus
{
    Pending,
    Running,
    Completed,
    Failed,
    Cancelled
}

// 任务进度信息
public class TaskProgress
{
    public string TaskId { get; set; } = "";
    public int Progress { get; set; }
    public string Status { get; set; } = "";
    public string? Message { get; set; }
    public int ProcessedCount { get; set; }
    public int TotalCount { get; set; }
    public long UploadedBytes { get; set; }
    public long TotalBytes { get; set; }
}

public sealed class TaskSchedulerService : BackgroundService
{
    private readonly ILogger<TaskSchedulerService> _logger;
    private readonly IHttpClientFactory _httpFactory;
    private readonly AgentConfig _config;
    private readonly WebSocketService _wsService;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IAuthTokenProvider _authTokenProvider;
    private readonly CleanupService _cleanupService;

    private readonly List<ScheduledTask> _pendingTasks = new();
    private readonly SemaphoreSlim _taskLock = new(1, 1);
    private readonly SemaphoreSlim _syncLock = new(1, 1);

    // 智能轮询配置
    private readonly TimeSpan _webSocketPollingInterval = TimeSpan.FromSeconds(30);
    private readonly TimeSpan _fallbackPollingInterval = TimeSpan.FromSeconds(10);
    private readonly TimeSpan _initialDelay = TimeSpan.FromSeconds(5);
    
    private bool _isStopping;
    private bool _disposed;
    private DateTime _lastWebSocketMessageTime = DateTime.UtcNow;

    public TaskSchedulerService(
        ILogger<TaskSchedulerService> logger,
        IHttpClientFactory httpFactory,
        AgentConfig config,
        WebSocketService wsService,
        IServiceScopeFactory scopeFactory,
        IAuthTokenProvider authTokenProvider,
        CleanupService cleanupService)
    {
        _logger = logger;
        _httpFactory = httpFactory;
        _config = config;
        _scopeFactory = scopeFactory;
        _authTokenProvider = authTokenProvider;
        _wsService = wsService;
        _cleanupService = cleanupService;

        _logger.LogInformation("=== TaskSchedulerService Initialized ===");
        _logger.LogInformation("DeviceId from config: {DeviceId}", _config.DeviceId ?? "null");
        _logger.LogInformation("Is valid UUID: {IsValid}", Guid.TryParse(_config.DeviceId ?? "", out _));
        _logger.LogInformation("Token available: {HasToken}", !string.IsNullOrEmpty(_config.Auth.Token));

        _wsService.OnMessage += OnWebSocketMessage;
    }

    #region ========== Token 管理 ==========

    /// <summary>
    /// ✅ 获取当前 DeviceId（从 Provider）
    /// </summary>
    private string GetCurrentDeviceId()
    {
        return _authTokenProvider.GetSnapshot().DeviceId;
    }

    /// <summary>
    /// ✅ 检查是否已认证
    /// </summary>
    private bool IsAuthenticated()
    {
        return _authTokenProvider.GetSnapshot().IsAuthenticated;
    }

    private bool IsApproved()
    {
        return _authTokenProvider.GetSnapshot().IsApproved;
    }

    private static bool IsDeviceApprovalForbidden(HttpStatusCode statusCode)
        => statusCode == HttpStatusCode.Forbidden;

    #endregion

    #region ========== 主循环 ==========

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Task scheduler started");
        
        // 等待设备注册完成
        while (!stoppingToken.IsCancellationRequested && !IsAuthenticated())
        {
            _logger.LogDebug("Waiting for device registration...");
            await Task.Delay(2000, stoppingToken);
        }
        
        if (stoppingToken.IsCancellationRequested) return;
        
        _logger.LogInformation("Device registered: {DeviceId}", 
            SensitiveDataFilter.SafeDeviceId(GetCurrentDeviceId()));

        if (!IsApproved())
        {
            _logger.LogInformation(
                "Device is pending admin approval (status={Status}); task sync will resume after approval",
                _authTokenProvider.GetSnapshot().DeviceStatus);
        }
        
        await Task.Delay(_initialDelay, stoppingToken);
        
        if (IsApproved())
            await SyncPendingTasksWithRetryAsync(stoppingToken);
        
        while (!stoppingToken.IsCancellationRequested && !_isStopping)
        {
            try
            {
                if (!IsApproved())
                {
                    var status = _authTokenProvider.GetSnapshot().DeviceStatus;
                    if (string.Equals(status, "rejected", StringComparison.OrdinalIgnoreCase))
                        _logger.LogWarning("Device registration rejected; task processing remains paused");
                    else
                        _logger.LogDebug("Device pending admin approval; task processing paused");

                    await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
                    continue;
                }

                var pollingInterval = GetCurrentPollingInterval();
                
                await ProcessTasksAsync(stoppingToken);
                
                await Task.Delay(pollingInterval, stoppingToken);
                
                if (DateTime.UtcNow.Minute == 0)
                {
                    await SyncPendingTasksAsync(stoppingToken);
                }
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Task processing failed");
                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }
        
        _logger.LogInformation("Task scheduler stopped");
    }
    
    private TimeSpan GetCurrentPollingInterval()
    {
        if (_wsService.IsConnected)
        {
            var timeSinceLastMessage = DateTime.UtcNow - _lastWebSocketMessageTime;
            if (timeSinceLastMessage < TimeSpan.FromMinutes(2))
            {
                return _webSocketPollingInterval;
            }
        }
        
        return _fallbackPollingInterval;
    }

    #endregion

    #region ========== 任务同步 ==========

    private async Task SyncPendingTasksWithRetryAsync(CancellationToken ct)
    {
        for (int i = 0; i < Constants.MaxRetryCount; i++)
        {
            try
            {
                await SyncPendingTasksAsync(ct);
                return;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Initial task sync attempt {Attempt}/{MaxRetries} failed", 
                    i + 1, Constants.MaxRetryCount);
                if (i < Constants.MaxRetryCount - 1)
                    await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, i)), ct);
            }
        }
    }

    private async Task SyncPendingTasksAsync(CancellationToken ct)
    {
        var effectiveDeviceId = GetCurrentDeviceId();
        
        if (string.IsNullOrEmpty(effectiveDeviceId))
        {
            _logger.LogWarning("Cannot sync tasks: DeviceId is empty");
            return;
        }
        
        if (!Guid.TryParse(effectiveDeviceId, out _))
        {
            _logger.LogWarning("Cannot sync tasks: Invalid Device ID format: {DeviceId}", effectiveDeviceId);
            return;
        }
        
        if (!await _syncLock.WaitAsync(0, ct))
        {
            _logger.LogDebug("Task sync already in progress");
            return;
        }

        try
        {
            var url = $"{_config.ServerUrl}/api/v1/tasks/pending?deviceId={Uri.EscapeDataString(effectiveDeviceId)}";

            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            
            if (!HttpAuthExtensions.TryApplyBearerToken(request, _authTokenProvider))
            {
                _logger.LogWarning("No token available for task sync");
                return;
            }

            using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
            
            if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
            {
                var error = await response.Content.ReadAsStringAsync(ct);
                _logger.LogWarning("Bad request when syncing tasks: {Error}", error);
                return;
            }

            if (response.IsSuccessStatusCode)
            {
                var tasks = await ParseTasksResponseAsync(response, ct);

                if (tasks.Count > 0)
                {
                    await _taskLock.WaitAsync(ct);
                    try
                    {
                        foreach (var task in tasks)
                        {
                            if (!_pendingTasks.Any(t => t.Id == task.Id))
                                _pendingTasks.Add(task);
                        }
                    }
                    finally
                    {
                        _taskLock.Release();
                    }

                    _logger.LogInformation("Synced {Count} pending tasks for device {DeviceId}", 
                        tasks.Count, SensitiveDataFilter.SafeDeviceId(effectiveDeviceId));
                }
            }
            else if (IsDeviceApprovalForbidden(response.StatusCode))
            {
                var error = await response.Content.ReadAsStringAsync(ct);
                _authTokenProvider.UpdateDeviceStatus("pending");
                _logger.LogWarning(
                    "Task sync blocked until admin approval (403): {Error}",
                    SensitiveDataFilter.FilterStatic(error));
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                _logger.LogWarning("Unauthorized when syncing tasks, attempting token refresh");
                var refreshed = await _authTokenProvider.RefreshTokenAsync(ct);
                if (refreshed != null)
                {
                    using var retryRequest = new HttpRequestMessage(HttpMethod.Get, url);
                    if (HttpAuthExtensions.TryApplyBearerToken(retryRequest, _authTokenProvider))
                    {
                        using var retryResponse = await _httpFactory.CreateClient("AgentClient")
                            .SendAsync(retryRequest, ct);
                        if (retryResponse.IsSuccessStatusCode)
                        {
                            var tasks = await ParseTasksResponseAsync(retryResponse, ct);
                            if (tasks.Count > 0)
                            {
                                await _taskLock.WaitAsync(ct);
                                try
                                {
                                    foreach (var task in tasks)
                                    {
                                        if (!_pendingTasks.Any(t => t.Id == task.Id))
                                            _pendingTasks.Add(task);
                                    }
                                }
                                finally
                                {
                                    _taskLock.Release();
                                }

                                _logger.LogInformation(
                                    "Synced {Count} pending tasks after token refresh",
                                    tasks.Count);
                            }
                        }
                    }
                }
            }
        }
        catch (HttpRequestException ex)
        {
            _logger.LogWarning(ex, "HTTP request failed during task sync");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to sync pending tasks");
        }
        finally
        {
            _syncLock.Release();
        }
    }
    
    private async Task<List<ScheduledTask>> ParseTasksResponseAsync(
        HttpResponseMessage response,
        CancellationToken ct)
    {
        var responseBody = await response.Content.ReadAsStringAsync(ct);
        var tasks = new List<ScheduledTask>();

        try
        {
            using var doc = JsonDocument.Parse(responseBody);
            var root = doc.RootElement;

            if (root.TryGetProperty("data", out var dataElement) &&
                dataElement.TryGetProperty("items", out var itemsElement))
            {
                tasks = JsonSerializer.Deserialize<List<ScheduledTask>>(
                    itemsElement.GetRawText(),
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new List<ScheduledTask>();
            }
            else if (root.ValueKind == JsonValueKind.Array)
            {
                tasks = JsonSerializer.Deserialize<List<ScheduledTask>>(
                    responseBody,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new List<ScheduledTask>();
            }
            else if (root.TryGetProperty("items", out var itemsElement2))
            {
                tasks = JsonSerializer.Deserialize<List<ScheduledTask>>(
                    itemsElement2.GetRawText(),
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new List<ScheduledTask>();
            }

            NormalizeHttpTasks(tasks);
        }
        catch (JsonException ex)
        {
            _logger.LogWarning(ex, "Failed to parse tasks response: {Response}", 
                responseBody.Length > 200 ? responseBody[..200] : responseBody);
        }

        return tasks;
    }

    /// <summary>
    /// 将 HTTP 轮询返回的 UploadTask 形态规范为可执行的 ScheduledTask
    /// </summary>
    private static void NormalizeHttpTasks(List<ScheduledTask> tasks)
    {
        foreach (var task in tasks)
        {
            if (string.IsNullOrWhiteSpace(task.Type))
                task.Type = "upload_recordings";

            if (task.ScheduledTime == default)
                task.ScheduledTime = DateTime.UtcNow;

            if (task.Parameters.HasValue && task.Parameters.Value.ValueKind != JsonValueKind.Null)
                continue;

            var paramDict = new Dictionary<string, string?>();
            if (task.StartTime.HasValue)
                paramDict["startTime"] = task.StartTime.Value.ToUniversalTime().ToString("O");
            if (task.EndTime.HasValue)
                paramDict["endTime"] = task.EndTime.Value.ToUniversalTime().ToString("O");

            if (paramDict.Count == 0)
                continue;

            var json = JsonSerializer.Serialize(paramDict);
            task.Parameters = JsonSerializer.Deserialize<JsonElement>(json);
            task.CacheParameters();
        }
    }

    #endregion

    #region ========== 任务处理 ==========

    private async Task ProcessTasksAsync(CancellationToken ct)
    {
        List<ScheduledTask> tasksToProcess;
        
        await _taskLock.WaitAsync(ct);
        try
        {
            tasksToProcess = _pendingTasks
                .Where(t => t.Status == "pending" && t.ScheduledTime <= DateTime.UtcNow)
                .ToList();
        }
        finally
        {
            _taskLock.Release();
        }
        
        foreach (var task in tasksToProcess)
        {
            if (ct.IsCancellationRequested) break;
            
            try
            {
                _logger.LogInformation("Executing task: {TaskId} - {TaskType}", task.Id, task.Type);
                await ExecuteTaskAsync(task, ct);
                
                task.Status = "completed";
                task.CompletedAt = DateTime.UtcNow;
                await UpdateTaskStatusAsync(task);
                
                await _taskLock.WaitAsync(ct);
                try { _pendingTasks.Remove(task); }
                finally { _taskLock.Release(); }
                
                _logger.LogInformation("Task {TaskId} completed", task.Id);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Task {TaskId} failed", task.Id);
                
                task.RetryCount++;
                if (task.RetryCount >= task.MaxRetries)
                {
                    task.Status = "failed";
                    task.Result = ex.Message;
                    await UpdateTaskStatusAsync(task);
                    
                    await _taskLock.WaitAsync(ct);
                    try { _pendingTasks.Remove(task); }
                    finally { _taskLock.Release(); }
                }
                else
                {
                    task.ScheduledTime = DateTime.UtcNow.AddSeconds(Math.Pow(2, task.RetryCount));
                    _logger.LogInformation("Task {TaskId} will retry at {ScheduledTime}", 
                        task.Id, task.ScheduledTime);
                }
            }
        }
    }

    private async Task ExecuteTaskAsync(ScheduledTask task, CancellationToken ct)
    {
        switch (task.Type?.ToLower())
        {
            case "upload_recordings":
                await UploadRecordingsTask(task, ct);
                break;
            case "upload_screenshots":
                await UploadScreenshotsTask(task, ct);
                break;
            case "cleanup":
                await CleanupTask(task, ct);
                break;
            case "restart_recording":
                await RestartRecordingTask(task, ct);
                break;
            case "execute_command":
                if (!_config.Resilience.AllowRemoteCommands)
                {
                    task.Status = "skipped";
                    task.Result = "Remote command execution is disabled (Resilience.AllowRemoteCommands=false)";
                    _logger.LogWarning("Skipped execute_command task {TaskId}: remote commands are disabled", task.Id);
                    return;
                }
                await ExecuteCommandTask(task, ct);
                break;
            case "collect_info":
                await CollectInfoTask(task, ct);
                break;
            case "sync_policy":
                await SyncPolicyTask(task, ct);
                break;
            default:
                throw new ArgumentException($"Unknown task type: {task.Type}");
        }
    }

    #endregion

    #region ========== 具体任务实现 ==========

    private async Task UploadRecordingsTask(ScheduledTask task, CancellationToken ct)
    {
        var queuedCount = 0;
        var failedCount = 0;
        var totalBytes = 0L;
        
        string? startTimeStr = null;
        string? endTimeStr = null;
        
        if (task.TryGetParameter("startTime", out var startParam))
            startTimeStr = startParam.GetString();
        if (task.TryGetParameter("endTime", out var endParam))
            endTimeStr = endParam.GetString();
        
        DateTime? startTime = null;
        DateTime? endTime = null;
        
        if (!string.IsNullOrEmpty(startTimeStr))
        {
            if (TryParseUtcTime(startTimeStr, out var parsed))
                startTime = parsed;
            else
                _logger.LogWarning("Failed to parse startTime: {StartTime}", startTimeStr);
        }
        
        if (!string.IsNullOrEmpty(endTimeStr))
        {
            if (TryParseUtcTime(endTimeStr, out var parsed))
                endTime = parsed;
            else
                _logger.LogWarning("Failed to parse endTime: {EndTime}", endTimeStr);
        }
        
        _logger.LogInformation("Upload task - Time range (UTC): {StartTime} to {EndTime}",
            startTime?.ToString("yyyy-MM-dd HH:mm:ss") ?? "any", 
            endTime?.ToString("yyyy-MM-dd HH:mm:ss") ?? "any");
        _logger.LogInformation("Upload task - Time range (Beijing): {StartTime} to {EndTime}",
            FormatBeijingTime(startTime) ?? "any",
            FormatBeijingTime(endTime) ?? "any");
        
        var recordingConfig = GetRecordingConfig();
        var sliceSeconds = recordingConfig.GetSliceSeconds();
        
        var recordingsPath = Path.Combine(_config.GetEffectiveStoragePath(), "recordings");
        
        if (!Directory.Exists(recordingsPath))
        {
            task.Status = "failed";
            task.Result = $"Recordings directory not found: {recordingsPath}";
            await UpdateTaskStatusAsync(task);
            return;
        }

        var scanResult = await RecordingUploadCandidateResolver.ResolveAsync(
            recordingsPath,
            startTime,
            endTime,
            sliceSeconds,
            _scopeFactory,
            _logger,
            ct);
        var filesToUpload = scanResult.Files;
        foreach (var entry in filesToUpload)
            totalBytes += entry.File.Length;

        _logger.LogInformation(
            "Found {Count} recording files to upload (Total: {Size:F2} MB, source={Source}, scan={ScanMs:F0}ms, parse_cache={CacheEntries})",
            filesToUpload.Count,
            totalBytes / 1024.0 / 1024.0,
            scanResult.Source,
            scanResult.ScanMs,
            scanResult.ParseCacheEntries);
        
        if (filesToUpload.Count == 0)
        {
            task.Status = "completed";
            task.Result = $"指定时间范围内未找到本地录屏（{FormatBeijingTime(startTime) ?? "任意"} ~ {FormatBeijingTime(endTime) ?? "任意"} 北京时间）";
            task.Progress = 100;
            await UpdateTaskStatusAsync(task);
            return;
        }
        
        task.Status = "running";
        task.Progress = 0;
        task.TotalCount = filesToUpload.Count;
        task.TotalBytes = totalBytes;
        task.Result = $"正在扫描并入队，共 {filesToUpload.Count} 个录屏";
        await UpdateTaskStatusAsync(task);

        var queueItems = new List<UploadQueue>(filesToUpload.Count);
        var trackedQueueIds = new List<string>();

        foreach (var entry in filesToUpload)
        {
            if (ct.IsCancellationRequested)
            {
                task.Status = "cancelled";
                task.Result = "上传任务已取消";
                await UpdateTaskStatusAsync(task);
                return;
            }

            var file = entry.File;
            try
            {
                if (string.IsNullOrWhiteSpace(entry.RecordingId))
                {
                    _logger.LogWarning(
                        "Recording upload candidate has no SQLite id; will rely on file-path mark after upload: {File}",
                        file.Name);
                }

                queueItems.Add(new UploadQueue
                {
                    Id = Guid.NewGuid().ToString(),
                    FilePath = file.FullName,
                    FileType = "recording",
                    FileId = entry.RecordingId ?? string.Empty,
                    Status = "pending",
                    Offset = 0,
                    RetryCount = 0,
                    CreatedAt = DateTime.UtcNow,
                    RecordStartTime = entry.RecordStart,
                    RecordEndTime = entry.RecordEnd
                });
            }
            catch (Exception ex)
            {
                failedCount++;
                _logger.LogError(ex, "Failed to prepare recording for queue: {File}", file.Name);
            }
        }

        try
        {
            using var scope = _scopeFactory.CreateScope();
            var uploader = scope.ServiceProvider.GetRequiredService<FileUploadService>();
            trackedQueueIds = await uploader.QueueManyWithTimeAsync(queueItems);
            queuedCount = trackedQueueIds.Count;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Bulk queue failed, falling back is not attempted");
            task.Status = "failed";
            task.Progress = 100;
            task.Result = $"批量入队失败: {ex.Message}";
            task.CompletedAt = DateTime.UtcNow;
            await UpdateTaskStatusAsync(task);
            return;
        }

        task.Progress = 14;
        task.Result = $"已入队 {queuedCount}/{filesToUpload.Count}，等待实际上传...";
        await UpdateTaskStatusAsync(task);

        if (trackedQueueIds.Count == 0)
        {
            task.Status = failedCount > 0 ? "failed" : "completed";
            task.Progress = 100;
            task.Result = failedCount > 0
                ? $"入队失败 {failedCount} 个，未能开始上传"
                : "没有可上传的录屏文件";
            task.CompletedAt = DateTime.UtcNow;
            await UpdateTaskStatusAsync(task);
            return;
        }

        await WaitForRecordingUploadsAsync(task, trackedQueueIds, queuedCount, failedCount, totalBytes, ct);
    }

    private async Task WaitForRecordingUploadsAsync(
        ScheduledTask task,
        List<string> queueIds,
        int queuedCount,
        int queueFailedCount,
        long totalBytes,
        CancellationToken ct)
    {
        var total = queueIds.Count;
        var timeout = CalculateUploadWaitTimeout(total, totalBytes);
        var startedAt = DateTime.UtcNow;
        var lastProgress = -1;
        var pollInterval = TimeSpan.FromSeconds(3);

        task.Progress = 15;
        task.Result = $"正在上传 0/{total}（共 {totalBytes / 1024.0 / 1024.0:F2} MB）";
        await UpdateTaskStatusAsync(task);

        while (!ct.IsCancellationRequested)
        {
            var statuses = await GetUploadQueueStatusesAsync(queueIds);
            var completed = queueIds.Count(id => statuses.TryGetValue(id, out var s) && s == "completed");
            var failed = queueIds.Count(id => statuses.TryGetValue(id, out var s) && s == "failed");
            var pending = queueIds.Count(id =>
                !statuses.TryGetValue(id, out var s) || s is "pending" or "uploading");

            var finished = completed + failed;
            var progress = 15 + (int)(finished * 85.0 / total);
            progress = Math.Clamp(progress, 15, 99);

            if (progress != lastProgress)
            {
                task.Progress = progress;
                task.Result = $"正在上传 {completed}/{total}（失败 {failed}，剩余 {pending}）";
                await UpdateTaskStatusAsync(task);
                lastProgress = progress;
            }

            if (pending == 0)
            {
                task.Progress = 100;
                task.CompletedAt = DateTime.UtcNow;

                if (completed == total)
                {
                    task.Status = "completed";
                    task.Result = queueFailedCount > 0
                        ? $"上传完成：成功 {completed}/{total}，入队失败 {queueFailedCount} 个"
                        : $"上传完成：成功 {completed}/{total}，共 {totalBytes / 1024.0 / 1024.0:F2} MB";
                }
                else if (completed > 0)
                {
                    task.Status = "completed";
                    task.Result = $"部分完成：成功 {completed}/{total}，失败 {failed} 个";
                }
                else
                {
                    task.Status = "failed";
                    task.Result = $"上传失败：0/{total} 成功，失败 {failed} 个";
                }

                await UpdateTaskStatusAsync(task);
                _logger.LogInformation(
                    "Upload recordings task finished: completed={Completed}, failed={Failed}, queueFailed={QueueFailed}",
                    completed, failed, queueFailedCount);
                return;
            }

            if (DateTime.UtcNow - startedAt > timeout)
            {
                task.Status = "failed";
                task.Progress = progress;
                task.CompletedAt = DateTime.UtcNow;
                task.Result =
                    $"上传超时：成功 {completed}/{total}，失败 {failed}，仍在进行 {pending}（已等待 {timeout.TotalMinutes:F0} 分钟）";
                await UpdateTaskStatusAsync(task);
                _logger.LogWarning(
                    "Upload recordings task timed out after {Minutes}m: completed={Completed}, failed={Failed}, pending={Pending}",
                    timeout.TotalMinutes, completed, failed, pending);
                return;
            }

            await Task.Delay(pollInterval, ct);
        }

        task.Status = "cancelled";
        task.Result = "上传任务已取消";
        task.CompletedAt = DateTime.UtcNow;
        await UpdateTaskStatusAsync(task);
    }

    private static TimeSpan CalculateUploadWaitTimeout(int fileCount, long totalBytes)
    {
        // 按文件数：每文件约 45s（含 complete）；按体积：假设 512KB/s 有效吞吐
        var byCount = TimeSpan.FromSeconds(Math.Max(fileCount * 45, 300));
        var bySize = TimeSpan.FromSeconds(Math.Max(totalBytes / (512 * 1024), 300));
        var timeout = byCount > bySize ? byCount : bySize;

        // 大批量任务允许更长等待：最多 6 小时（原 60 分钟易超时）
        var maxTimeout = fileCount >= 100
            ? TimeSpan.FromHours(6)
            : TimeSpan.FromMinutes(90);

        return timeout > maxTimeout ? maxTimeout : timeout;
    }

    #endregion

    #region ========== 辅助方法 ==========

    private DateTime? ParseRecordingTimeFromPath(string filePath)
    {
        var recordingConfig = GetRecordingConfig();
        if (RecordingTimeParser.TryParse(filePath, recordingConfig.GetSliceSeconds(), out var startUtc, out _))
            return startUtc;
        return null;
    }
    
    private RecordingConfig GetRecordingConfig()
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var policySync = scope.ServiceProvider.GetRequiredService<PolicySyncService>();
            var policy = policySync.GetCurrentPolicy();

            if (policy != null)
            {
                var config = policy.GetRecordingConfig();
                _logger.LogDebug(
                    "Using policy recording config: SliceMinutes={SliceMinutes}, Fps={Fps}, Quality={Quality}",
                    config.SliceMinutes, config.Fps, config.Quality);
                return config;
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to get recording config from policy, using defaults");
        }

        return new RecordingConfig
        {
            SliceMinutes = 1,
            Fps = 10,
            Quality = 60
        };
    }
    
    private async Task<bool> UploadQueueExistsAsync(string filePath)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        return await repo.ExistsPendingAsync(filePath);
    }

    private async Task<UploadQueue?> GetActiveUploadQueueItemAsync(string filePath)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        return await repo.GetActiveByFilePathAsync(filePath);
    }

    private async Task<Dictionary<string, string>> GetUploadQueueStatusesAsync(IEnumerable<string> queueIds)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        return await repo.GetStatusesByIdsAsync(queueIds);
    }
    
    private async Task QueueFileUploadWithTimeAsync(UploadQueue queueItem)
    {
        using var scope = _scopeFactory.CreateScope();
        var uploader = scope.ServiceProvider.GetRequiredService<FileUploadService>();
        await uploader.QueueFileWithTimeAsync(queueItem);
    }

    private async Task UploadScreenshotsTask(ScheduledTask task, CancellationToken ct)
    {
        var screenshots = await GetUnuploadedScreenshotsAsync(1000);
        var queuedCount = 0;
        
        foreach (var screenshot in screenshots)
        {
            if (ct.IsCancellationRequested) break;
            if (File.Exists(screenshot.FilePath))
            {
                await QueueFileUploadAsync(screenshot.FilePath, "screenshot", screenshot.Id);
                queuedCount++;
            }
        }
        
        task.Result = $"Queued {queuedCount} screenshots for upload";
    }

    private async Task CleanupTask(ScheduledTask task, CancellationToken ct)
    {
        var daysToKeep = task.Parameters?.TryGetProperty("daysToKeep", out var daysProp) == true
            ? daysProp.GetInt32()
            : (int?)null;

        var policy = _cleanupService.GetEffectivePolicy();
        var effectiveDays = daysToKeep ?? policy.RecordingDays;

        var result = await _cleanupService.RunRetentionCleanupAsync(
            CleanupTrigger.RemoteTask,
            ct,
            recordingDaysOverride: effectiveDays,
            screenshotDaysOverride: effectiveDays,
            logDaysOverride: policy.LogDays);

        task.Result =
            $"Deleted {result.DeletedRecordingFiles} recording files, {result.DeletedScreenshotFiles} screenshot files, {result.DeletedActivityRows} activity logs";
    }

    private async Task RestartRecordingTask(ScheduledTask task, CancellationToken ct)
    {
        using var scope = _scopeFactory.CreateScope();
        var lifecycle = scope.ServiceProvider.GetRequiredService<IRecorderLifecycle>();

        if (lifecycle.IsRemoteActive)
        {
            task.Result = "Recording restart skipped: remote view active";
            return;
        }

        var result = await lifecycle.RequestAsync(
            RecorderCommand.RecoverCapture,
            new RecorderRequestContext { Reason = "scheduled_restart_task" },
            ct);

        task.Result = result.Success
            ? "Recording recover completed"
            : $"Recording recover failed: {result.Message}";
    }

    private async Task ExecuteCommandTask(ScheduledTask task, CancellationToken ct)
    {
        var command = task.Parameters?.TryGetProperty("command", out var cmdProp) == true 
            ? cmdProp.GetString() : null;
        var args = task.Parameters?.TryGetProperty("arguments", out var argsProp) == true 
            ? argsProp.GetString() : "";
        var timeoutSeconds = task.Parameters?.TryGetProperty("timeout", out var timeoutProp) == true 
            ? timeoutProp.GetInt32() : 60;
        
        if (string.IsNullOrEmpty(command))
            throw new ArgumentException("No command specified");
        
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(TimeSpan.FromSeconds(timeoutSeconds));
        
        using var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = command,
                Arguments = args,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            }
        };
        
        process.Start();
        
        var outputTask = process.StandardOutput.ReadToEndAsync();
        var errorTask = process.StandardError.ReadToEndAsync();
        
        await process.WaitForExitAsync(cts.Token);
        
        string output, error;
        bool timedOut = cts.Token.IsCancellationRequested;
        
        if (timedOut)
        {
            try { process.Kill(); } catch { }
            await process.WaitForExitAsync();
        }
        
        output = await outputTask;
        error = await errorTask;
        
        task.Result = JsonSerializer.Serialize(new { output, error, exitCode = process.ExitCode, timedOut });
    }

    private async Task CollectInfoTask(ScheduledTask task, CancellationToken ct)
    {
        var info = new
        {
            deviceId = SensitiveDataFilter.SafeDeviceId(_config.DeviceId),
            hostname = Environment.MachineName,
            osVersion = Environment.OSVersion.ToString(),
            processorCount = Environment.ProcessorCount,
            timestamp = DateTime.UtcNow,
            agentVersion = _config.AgentVersion
        };
        
        task.Result = JsonSerializer.Serialize(info);
        
        var url = $"{_config.ServerUrl}/api/v1/devices/info";
        var content = new StringContent(JsonSerializer.Serialize(info), Encoding.UTF8, "application/json");

        using var request = new HttpRequestMessage(HttpMethod.Post, url) { Content = content };
        if (!HttpAuthExtensions.TryApplyBearerToken(request, _authTokenProvider))
        {
            _logger.LogWarning("No token available for collect info");
            return;
        }

        await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
    }

    private async Task SyncPolicyTask(ScheduledTask task, CancellationToken ct)
    {
        task.Result = "Policy sync triggered";
        await Task.CompletedTask;
    }

    private async Task UpdateTaskStatusAsync(ScheduledTask task)
    {
        try
        {
            var url = $"{_config.ServerUrl}/api/v1/tasks/{task.Id}/status";

            var update = new
            {
                status = task.Status,
                progress = task.Progress,
                result = task.Result ?? "",
                completedAt = task.CompletedAt?.ToString("o")
            };

            using var request = new HttpRequestMessage(HttpMethod.Put, url);
            if (!HttpAuthExtensions.TryApplyBearerToken(request, _authTokenProvider))
            {
                _logger.LogWarning("Cannot update task status: Token is empty");
                return;
            }

            request.Content = new StringContent(JsonSerializer.Serialize(update), Encoding.UTF8, "application/json");

            using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request);

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                _logger.LogWarning("Unauthorized when updating task {TaskId}, attempting token refresh", task.Id);
                var refreshed = await _authTokenProvider.RefreshTokenAsync();
                if (refreshed != null)
                {
                    using var retryRequest = new HttpRequestMessage(HttpMethod.Put, url);
                    if (HttpAuthExtensions.TryApplyBearerToken(retryRequest, _authTokenProvider))
                    {
                        retryRequest.Content = new StringContent(
                            JsonSerializer.Serialize(update), Encoding.UTF8, "application/json");
                        using var retryResponse = await _httpFactory.CreateClient("AgentClient")
                            .SendAsync(retryRequest);
                        if (retryResponse.IsSuccessStatusCode)
                        {
                            _logger.LogDebug(
                                "Task {TaskId} updated after token refresh: Status={Status}, Progress={Progress}%",
                                task.Id, task.Status, task.Progress);
                            return;
                        }

                        var retryError = await retryResponse.Content.ReadAsStringAsync();
                        _logger.LogWarning(
                            "Failed to update task {TaskId} after refresh: {StatusCode} - {Error}",
                            task.Id, retryResponse.StatusCode, retryError);
                        return;
                    }
                }
            }
            else if (IsDeviceApprovalForbidden(response.StatusCode))
            {
                _authTokenProvider.UpdateDeviceStatus("pending");
                _logger.LogWarning(
                    "Task status update blocked until admin approval for task {TaskId}",
                    task.Id);
                return;
            }

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                _logger.LogWarning("Failed to update task {TaskId}: {StatusCode} - {Error}", 
                    task.Id, response.StatusCode, error);
            }
            else
            {
                _logger.LogDebug("Task {TaskId} updated: Status={Status}, Progress={Progress}%", 
                    task.Id, task.Status, task.Progress);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to update task {TaskId}", task.Id);
        }
    }

    private async Task OnWebSocketMessage(string type, JsonElement data)
    {
        _lastWebSocketMessageTime = DateTime.UtcNow;

        if (type == "device_approved")
        {
            _authTokenProvider.ClearSessionRevoke();
            _authTokenProvider.UpdateDeviceStatus("approved");
            _logger.LogInformation("Device approved by administrator; resuming task sync");
            if (string.IsNullOrWhiteSpace(_authTokenProvider.GetSnapshot().DeviceId))
            {
                using var scope = _scopeFactory.CreateScope();
                var registrationService = scope.ServiceProvider.GetRequiredService<DeviceRegistrationService>();
                await registrationService.ForceReRegisterAsync();
            }
            _ = SyncPendingTasksAsync(CancellationToken.None);
            return;
        }

        if (type == "device_rejected")
        {
            _authTokenProvider.UpdateDeviceStatus("rejected");
            _logger.LogWarning("Device registration rejected by administrator");
            return;
        }
        
        if (type == "task")
        {
            _logger.LogInformation("Received task via WebSocket: {Data}", data.ToString());
            
            try
            {
                if (data.TryGetProperty("taskId", out var taskIdElement) &&
                    data.TryGetProperty("task", out var taskTypeElement))
                {
                    var task = new ScheduledTask
                    {
                        Id = taskIdElement.GetString() ?? Guid.NewGuid().ToString(),
                        Type = taskTypeElement.GetString() ?? "",
                        Status = "pending",
                        ScheduledTime = DateTime.UtcNow,
                        MaxRetries = Constants.MaxRetryCount
                    };
                    
                    if (data.TryGetProperty("params", out var paramsElement))
                    {
                        task.Parameters = paramsElement;
                    }
                    
                    task.CacheParameters();
                    
                    await _taskLock.WaitAsync();
                    try
                    {
                        if (!_pendingTasks.Any(t => t.Id == task.Id))
                        {
                            _pendingTasks.Add(task);
                            _logger.LogInformation("Task {TaskId} added from WebSocket", task.Id);
                        }
                    }
                    finally
                    {
                        _taskLock.Release();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to process WebSocket task message");
            }
        }
    }
    
    private async Task<int> CleanupDirectoryAsync(string path, DateTime cutoff, params string[] patterns)
    {
        var deleted = 0;
        if (!Directory.Exists(path)) return deleted;
        
        foreach (var pattern in patterns)
        {
            var files = Directory.GetFiles(path, pattern, SearchOption.AllDirectories);
            foreach (var file in files)
            {
                try
                {
                    if (File.GetLastWriteTimeUtc(file) < cutoff)
                    {
                        File.Delete(file);
                        deleted++;
                    }
                }
                catch { }
            }
        }
        return deleted;
    }

    public async Task OnTaskReceivedAsync(string taskId, string taskType, JsonElement data)
    {
        if (string.IsNullOrWhiteSpace(taskId) || string.IsNullOrWhiteSpace(taskType))
        {
            _logger.LogWarning("Received task with missing taskId or taskType");
            return;
        }
        
        var task = new ScheduledTask
        {
            Id = taskId,
            Type = taskType,
            Status = "pending",
            Parameters = data.TryGetProperty("params", out var paramsProp) ? paramsProp : null,
            ScheduledTime = DateTime.UtcNow,
            MaxRetries = Constants.MaxRetryCount
        };
        
        task.CacheParameters();
        
        await _taskLock.WaitAsync();
        try
        {
            _pendingTasks.Add(task);
            _logger.LogInformation("Task received: {TaskId} - {TaskType}", taskId, taskType);
        }
        finally
        {
            _taskLock.Release();
        }
    }

    private async Task<List<Screenshot>> GetUnuploadedScreenshotsAsync(int max)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<ScreenshotRepository>();
        return await repo.GetUnuploadedAsync(max);
    }

    private async Task QueueFileUploadAsync(string path, string type, string id)
    {
        using var scope = _scopeFactory.CreateScope();
        var uploader = scope.ServiceProvider.GetRequiredService<FileUploadService>();
        await uploader.QueueFileAsync(path, type, id);
    }

    #endregion

    #region ========== 生命周期 ==========

    public override void Dispose()
    {
        if (!_disposed)
        {
            try
            {
                _wsService.OnMessage -= OnWebSocketMessage;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error unsubscribing from WebSocket events");
            }
            
            try { _taskLock?.Dispose(); } catch { }
            try { _syncLock?.Dispose(); } catch { }
            
            _disposed = true;
        }
        base.Dispose();
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Stopping task scheduler...");
        _isStopping = true;

        _wsService.OnMessage -= OnWebSocketMessage;
        
        try
        {
            if (_taskLock.CurrentCount == 0)
            {
                using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                cts.CancelAfter(TimeSpan.FromSeconds(3));
                try
                {
                    await _taskLock.WaitAsync(cts.Token);
                }
                catch (OperationCanceledException)
                {
                    _logger.LogWarning("Timeout waiting for task lock during stop");
                }
                _taskLock.Release();
            }
            
            if (_syncLock.CurrentCount == 0)
            {
                using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                cts.CancelAfter(TimeSpan.FromSeconds(3));
                try
                {
                    await _syncLock.WaitAsync(cts.Token);
                }
                catch (OperationCanceledException)
                {
                    _logger.LogWarning("Timeout waiting for sync lock during stop");
                }
                _syncLock.Release();
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error acquiring locks during stop");
        }
        
        try
        {
            await base.StopAsync(cancellationToken);
        }
        catch (OperationCanceledException)
        {
            // 正常退出，忽略
        }
    }

    private static bool TryParseUtcTime(string? timeStr, out DateTime utc)
    {
        utc = default;
        if (string.IsNullOrWhiteSpace(timeStr))
            return false;

        if (DateTimeOffset.TryParse(
                timeStr,
                CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind,
                out var parsed))
        {
            utc = parsed.UtcDateTime;
            return true;
        }

        return false;
    }

    private static string? FormatBeijingTime(DateTime? utcTime)
    {
        if (!utcTime.HasValue)
            return null;

        foreach (var id in new[] { "China Standard Time", "Asia/Shanghai" })
        {
            try
            {
                var zone = TimeZoneInfo.FindSystemTimeZoneById(id);
                var local = TimeZoneInfo.ConvertTimeFromUtc(utcTime.Value, zone);
                return local.ToString("yyyy-MM-dd HH:mm");
            }
            catch (TimeZoneNotFoundException)
            {
            }
            catch (InvalidTimeZoneException)
            {
            }
        }

        return utcTime.Value.AddHours(8).ToString("yyyy-MM-dd HH:mm");
    }

    #endregion
}

public class ScheduledTask
{
    public string Id { get; set; } = "";
    public string Type { get; set; } = "";
    public string Status { get; set; } = "pending";
    public JsonElement? Parameters { get; set; }
    public DateTime ScheduledTime { get; set; }
    public DateTime? CompletedAt { get; set; }
    public int RetryCount { get; set; }
    public int MaxRetries { get; set; } = Constants.MaxRetryCount;
    public string Result { get; set; } = "";

    [JsonPropertyName("startTime")]
    public DateTime? StartTime { get; set; }

    [JsonPropertyName("endTime")]
    public DateTime? EndTime { get; set; }
    
    public int Progress { get; set; }
    public int ProcessedCount { get; set; }
    public int TotalCount { get; set; }
    public long UploadedBytes { get; set; }
    public long TotalBytes { get; set; }   
    private Dictionary<string, JsonElement>? _parametersCache;  

    public void CacheParameters()
    {
        if (Parameters.HasValue)
        {
            _parametersCache = new Dictionary<string, JsonElement>();
            foreach (var property in Parameters.Value.EnumerateObject())
            {
                _parametersCache[property.Name] = JsonSerializer.Deserialize<JsonElement>(
                    property.Value.GetRawText());
            }
        }
    }
    
    public bool TryGetParameter(string key, out JsonElement value)
    {
        value = default;
        if (_parametersCache != null && _parametersCache.TryGetValue(key, out var cachedValue))
        {
            value = cachedValue;
            return true;
        }
        return false;
    }
}
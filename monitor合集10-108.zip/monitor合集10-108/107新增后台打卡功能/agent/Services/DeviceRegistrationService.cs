// Services/DeviceRegistrationService.cs - 完整修复版（保留所有功能）

using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using EnterpriseAgent.Agent.Extensions;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;

namespace EnterpriseAgent.Agent.Services;

public sealed class DeviceRegistrationService : BackgroundService
{
    private static readonly TimeSpan VerifyInterval = TimeSpan.FromHours(24);
    private static readonly TimeSpan RetryDelay = TimeSpan.FromMinutes(5);

    private readonly ILogger<DeviceRegistrationService> _logger;
    private readonly DeviceFingerprinter _fingerprinter;
    private readonly IHttpClientFactory _httpFactory;
    private readonly AgentConfig _config;
    private readonly EncryptedConfigService _encryptedConfigService;

    private readonly IAuthTokenProvider _authTokenProvider;

    private IDisposable? _authSubscription;
    private long _lastSavedAuthVersion = -1;
    private readonly SemaphoreSlim _persistLock = new(1, 1);
    private readonly SemaphoreSlim _registrationLock = new(1, 1);
    private long _pendingPersistVersion = -1;
    private int _persistScheduled;

    public DeviceRegistrationService(
        ILogger<DeviceRegistrationService> logger,
        DeviceFingerprinter fingerprinter,
        IHttpClientFactory httpFactory,
        AgentConfig config,
        EncryptedConfigService encryptedConfigService,
        IAuthTokenProvider authTokenProvider)
    {
        _logger = logger;
        _fingerprinter = fingerprinter;
        _httpFactory = httpFactory;
        _config = config;
        _encryptedConfigService = encryptedConfigService;
        _authTokenProvider = authTokenProvider;  // ✅ 保存引用

        _authSubscription = _authTokenProvider.Subscribe(OnAuthSnapshotChanged);
    }

    private void OnAuthSnapshotChanged(AuthSnapshot snapshot)
    {
        if (snapshot.Version <= _lastSavedAuthVersion)
            return;

        Interlocked.Exchange(ref _pendingPersistVersion, snapshot.Version);
        if (Interlocked.CompareExchange(ref _persistScheduled, 1, 0) == 0)
        {
            _ = PersistAuthSnapshotWorkerAsync();
        }
    }

    private async Task PersistAuthSnapshotWorkerAsync()
    {
        try
        {
            await _persistLock.WaitAsync();
            try
            {
                while (true)
                {
                    var targetVersion = Interlocked.Read(ref _pendingPersistVersion);
                    if (targetVersion <= _lastSavedAuthVersion)
                        break;

                    var snapshot = _authTokenProvider.GetSnapshot();
                    if (snapshot.Version < targetVersion)
                    {
                        await Task.Delay(50);
                        continue;
                    }

                    await SaveConfigurationAsync();
                    _lastSavedAuthVersion = snapshot.Version;

                    if (Interlocked.Read(ref _pendingPersistVersion) <= snapshot.Version)
                        break;
                }
            }
            finally
            {
                _persistLock.Release();
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to persist auth snapshot");
        }
        finally
        {
            Interlocked.Exchange(ref _persistScheduled, 0);
            if (Interlocked.Read(ref _pendingPersistVersion) > _lastSavedAuthVersion
                && Interlocked.CompareExchange(ref _persistScheduled, 1, 0) == 0)
            {
                _ = PersistAuthSnapshotWorkerAsync();
            }
        }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Device registration service started");

        // ✅ 添加：启动时验证配置格式
        _logger.LogInformation("Initial config - DeviceId: {DeviceId}, HasToken: {HasToken}", 
            SensitiveDataFilter.SafeDeviceId(_config.DeviceId),
            !string.IsNullOrEmpty(_config.Auth.Token));
        
        // 如果已经有 DeviceId，验证格式是否正确
        if (!string.IsNullOrEmpty(_config.DeviceId))
        {
            var isValid = Guid.TryParse(_config.DeviceId, out var guid);
            _logger.LogInformation("Existing DeviceId is valid UUID: {IsValid}, Value: {Guid}", 
                isValid, isValid ? guid.ToString() : "invalid");
            
            if (!isValid)
            {
                _logger.LogWarning("DeviceId format is invalid, will re-register on next cycle");
                // 不清除，让验证流程自然失败并重新注册
            }
        }

        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await ProcessAsync(stoppingToken);

                var delay = _authTokenProvider.GetSnapshot().IsAuthenticated
                    ? VerifyInterval
                    : RetryDelay;

                try
                {
                    await Task.Delay(delay, stoppingToken);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("Device registration service stopped");
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Fatal error in DeviceRegistrationService");
        }
    }

    private async Task ProcessAsync(CancellationToken ct)
    {
        if (_authTokenProvider.IsSessionRevoked)
        {
            _logger.LogWarning("Device session revoked by administrator; waiting for re-approval");
            return;
        }

        var hasToken = _authTokenProvider.GetSnapshot().IsAuthenticated;
        var hasInvite = !string.IsNullOrWhiteSpace(_config.Employee?.InviteCode);

        // 无 deviceId，或尚未拿到 token 但已填写邀请码时，主动走注册（含邀请码绑定）
        if (string.IsNullOrWhiteSpace(_config.DeviceId) || (!hasToken && hasInvite))
        {
            await RegisterDeviceAsync(ct);
        }
        else
        {
            await VerifyDeviceAsync(ct);
        }
    }

    private bool _lastRegistrationInvalidInvite;

    /// <summary>上次注册是否因邀请码无效/过期/已使用而失败。</summary>
    public bool LastRegistrationInvalidInvite => _lastRegistrationInvalidInvite;

    private async Task RegisterDeviceAsync(CancellationToken ct)
    {
        await _registrationLock.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            await RegisterDeviceCoreAsync(ct).ConfigureAwait(false);
        }
        finally
        {
            _registrationLock.Release();
        }
    }

    private async Task RegisterDeviceCoreAsync(CancellationToken ct)
    {
        try
        {
            _lastRegistrationInvalidInvite = false;
            _logger.LogInformation("Registering device with server...");

            var fingerprint = _fingerprinter.Collect();
            var deviceId = _fingerprinter.GenerateDeviceId(fingerprint);

            _logger.LogInformation("Generated local deviceId: {DeviceId}", deviceId);

            var registrationData = new
            {
                deviceId,
                hostname = Environment.MachineName,
                osVersion = Environment.OSVersion.ToString(),
                agentVersion = _config.AgentVersion,
                fingerprint,
                publicKey = _config.Auth.EncryptionKey,
                inviteCode = _config.Employee?.InviteCode ?? string.Empty,
                employee = new
                {
                    name = _config.Employee?.Name ?? string.Empty,
                    employeeNumber = _config.Employee?.EmployeeNumber ?? string.Empty
                }
            };

            var requestJson = JsonSerializer.Serialize(registrationData);
            _logger.LogDebug("Registration request prepared for device {DeviceId}", deviceId);

            using var request = new HttpRequestMessage(
                HttpMethod.Post,
                $"{_config.ServerUrl}/api/v1/devices/register");

            request.Content = new StringContent(requestJson, Encoding.UTF8, "application/json");

            if (!string.IsNullOrWhiteSpace(_config.Auth?.RegistrationSecret))
            {
                request.Headers.TryAddWithoutValidation(
                    "X-Registration-Secret",
                    _config.Auth.RegistrationSecret);
            }

            using var response = await _httpFactory.CreateClient("AgentClient")
                .SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);

            var responseBody = await response.Content.ReadAsStringAsync(ct);

            if (!response.IsSuccessStatusCode)
            {
                _lastRegistrationInvalidInvite = response.StatusCode == HttpStatusCode.BadRequest
                    && responseBody.Contains("invite", StringComparison.OrdinalIgnoreCase);
                _logger.LogWarning(
                    "Registration failed with status {StatusCode}, response length={Length}, invalidInvite={InvalidInvite}",
                    response.StatusCode,
                    responseBody.Length,
                    _lastRegistrationInvalidInvite);
                await HandleRegistrationErrorAsync(response, ct);
                return;
            }

            string? deviceIdFromResponse = null;
            string? token = null;
            string? refreshToken = null;
            string? deviceSecret = null;
            string? expiresAtRaw = null;
            string? deviceStatus = null;

            using var doc = JsonDocument.Parse(responseBody);
            var root = doc.RootElement;

            if (root.TryGetProperty("data", out var dataElement))
            {
                if (dataElement.TryGetProperty("deviceId", out var deviceIdElement))
                    deviceIdFromResponse = deviceIdElement.GetString();
                if (dataElement.TryGetProperty("token", out var tokenElement))
                    token = tokenElement.GetString();
                if (dataElement.TryGetProperty("refreshToken", out var refreshTokenElement))
                    refreshToken = refreshTokenElement.GetString();
                if (dataElement.TryGetProperty("deviceSecret", out var secretElement))
                    deviceSecret = secretElement.GetString();
                if (dataElement.TryGetProperty("expiresAt", out var expiresElement))
                    expiresAtRaw = expiresElement.GetString();
                if (dataElement.TryGetProperty("status", out var statusElement))
                    deviceStatus = statusElement.GetString();
            }

            if (string.IsNullOrEmpty(token))
            {
                _logger.LogError("Token is empty in registration response!");
                return;
            }

            var resolvedDeviceId = deviceIdFromResponse ?? deviceId;
            var resolvedDeviceSecret = !string.IsNullOrEmpty(deviceSecret)
                ? deviceSecret
                : _config.Auth?.DeviceSecret ?? "";

            _authTokenProvider.UpdateAuth(
                deviceId: resolvedDeviceId,
                token: token,
                refreshToken: refreshToken,
                deviceSecret: resolvedDeviceSecret,
                deviceStatus: deviceStatus
            );

            if (_authTokenProvider is AuthTokenProvider provider && !string.IsNullOrEmpty(expiresAtRaw)
                && DateTime.TryParse(expiresAtRaw, null, System.Globalization.DateTimeStyles.RoundtripKind, out var expiresAt))
            {
                provider.ApplyTokenExpiresAt(expiresAt.ToUniversalTime());
            }

            _logger.LogInformation("Registration parsed - DeviceId: {DeviceId}, Status: {Status}, Token length: {TokenLength}",
                resolvedDeviceId,
                string.IsNullOrWhiteSpace(deviceStatus) ? "unknown" : deviceStatus,
                token.Length);

            await SaveConfigurationAsync();

            _logger.LogInformation("Device registered successfully: {DeviceId}", 
                SensitiveDataFilter.SafeDeviceId(_config.DeviceId));
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Device registration failed");
            await SafeDelayAsync(RetryDelay, ct);
        }
    }

    private async Task VerifyDeviceAsync(CancellationToken ct)
    {
        try
        {
            // ✅ 修复3：验证 DeviceId 格式后再发送请求
            if (!Guid.TryParse(_config.DeviceId, out _))
            {
                _logger.LogWarning("DeviceId format is invalid: {DeviceId}, will re-register", 
                    SensitiveDataFilter.SafeDeviceId(_config.DeviceId));
                await RegisterDeviceAsync(ct);
                return;
            }

            using var request = new HttpRequestMessage(
                HttpMethod.Get,
                $"{_config.ServerUrl}/api/v1/devices/{_config.DeviceId}/verify");

            var snapshot = _authTokenProvider.GetSnapshot();
            if (!snapshot.IsAuthenticated)
            {
                _logger.LogWarning("Device verification skipped: no token available");
                return;
            }

            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

            using var response = await _httpFactory.CreateClient("AgentClient")
                .SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);

            if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            {
                _logger.LogWarning("Device token expired or invalid, attempting refresh...");
                await RefreshTokenAsync(ct);
                return;
            }

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("Device verification failed: {StatusCode}", response.StatusCode);
                return;
            }

            var body = await response.Content.ReadAsStringAsync(ct);
            TryApplyDeviceStatusFromResponse(body);

            _logger.LogDebug("Device verification successful");
            await ReportDeviceInfoAsync(ct);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Device verification failed");
        }
    }

    private async Task ReportDeviceInfoAsync(CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(_config.DeviceId))
            return;

        try
        {
            var payload = new
            {
                deviceId = _config.DeviceId,
                hostname = Environment.MachineName,
                osVersion = Environment.OSVersion.ToString(),
                agentVersion = _config.AgentVersion,
                processorCount = Environment.ProcessorCount
            };

            using var request = new HttpRequestMessage(
                HttpMethod.Post,
                $"{_config.ServerUrl}/api/v1/devices/info");

            request.Content = new StringContent(
                JsonSerializer.Serialize(payload),
                Encoding.UTF8,
                "application/json");

            if (!HttpAuthExtensions.TryApplyBearerToken(request, _authTokenProvider))
            {
                _logger.LogDebug("Device info report skipped: no token");
                return;
            }

            using var response = await _httpFactory.CreateClient("AgentClient")
                .SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);

            if (response.IsSuccessStatusCode)
                _logger.LogInformation("Reported agent version {Version} to server", _config.AgentVersion);
            else
                _logger.LogWarning("Device info report failed: {StatusCode}", response.StatusCode);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to report device info");
        }
    }

    private async Task RefreshTokenAsync(CancellationToken ct)
    {
        try
        {
            var snapshot = _authTokenProvider.GetSnapshot();
            if (string.IsNullOrEmpty(snapshot.RefreshToken))
            {
                _logger.LogWarning("Refresh token is empty, will re-register device");
                await RegisterDeviceAsync(ct);
                return;
            }

            var newToken = await _authTokenProvider.RefreshTokenAsync(ct);
            if (!string.IsNullOrEmpty(newToken))
            {
                await SaveConfigurationAsync();
                _logger.LogInformation("Token refreshed successfully via AuthTokenProvider");
                return;
            }

            _logger.LogWarning("Token refresh failed, will re-register device");
            await RegisterDeviceAsync(ct);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Token refresh failed, will re-register device");
            await RegisterDeviceAsync(ct);
        }
    }

    private void TryApplyDeviceStatusFromResponse(string responseBody)
    {
        if (string.IsNullOrWhiteSpace(responseBody))
            return;

        try
        {
            using var doc = JsonDocument.Parse(responseBody);
            var root = doc.RootElement;
            if (root.TryGetProperty("data", out var data) &&
                data.TryGetProperty("status", out var statusElement))
            {
                var status = statusElement.GetString();
                if (!string.IsNullOrWhiteSpace(status))
                    _authTokenProvider.UpdateDeviceStatus(status);
            }
        }
        catch (JsonException ex)
        {
            _logger.LogDebug(ex, "Failed to parse device status from response");
        }
    }

    private async Task HandleRegistrationErrorAsync(HttpResponseMessage response, CancellationToken ct)
    {
        var error = await response.Content.ReadAsStringAsync(ct);
        _logger.LogError("Registration failed: {StatusCode} - {Error}", response.StatusCode, 
            SensitiveDataFilter.FilterStatic(error));
        await SafeDelayAsync(RetryDelay, ct);
    }

    private async Task SaveConfigurationAsync() 
    {
        // ✅ 修复5：添加保存日志
        _logger.LogDebug("Saving configuration - DeviceId: {DeviceId}, Token exists: {HasToken}", 
            SensitiveDataFilter.SafeDeviceId(_config.DeviceId),
            !string.IsNullOrEmpty(_config.Auth.Token));
        
        await _encryptedConfigService.SaveConfigAsync("config.json", _config);
        
        _logger.LogDebug("Configuration saved successfully");
    }

    private async Task ClearAuthStateAndSaveAsync()
    {
        _config.DeviceId = string.Empty;
        _config.Auth.Clear();
        await SaveConfigurationAsync();
        _logger.LogWarning("Authentication state cleared due to refresh failure");
    }

    private static async Task SafeDelayAsync(TimeSpan delay, CancellationToken ct)
    {
        try { await Task.Delay(delay, ct); }
        catch (OperationCanceledException) { }
    }

    // ========== ✅ 新增：供其他服务使用的公共方法 ==========
    
    /// <summary>
    /// 验证 DeviceId 格式是否正确
    /// </summary>
    public bool IsValidDeviceId()
    {
        return !string.IsNullOrEmpty(_config.DeviceId) && Guid.TryParse(_config.DeviceId, out _);
    }
    
    /// <summary>
    /// 获取真实的 DeviceId（UUID格式）
    /// </summary>
    public string GetDeviceId()
    {
        return _config.DeviceId ?? "";
    }
    
    /// <summary>
    /// 获取认证 Token
    /// </summary>
    public string GetToken()
    {
        return _authTokenProvider.GetSnapshot().Token;
    }
    
    /// <summary>
    /// 强制重新注册设备
    /// </summary>
    public async Task ForceReRegisterAsync()
    {
        if (_authTokenProvider.IsSessionRevoked)
        {
            _logger.LogWarning("Skipping forced re-registration while session is revoked");
            return;
        }

        _logger.LogInformation("Forcing device re-registration...");
        _authTokenProvider.ClearAuth();
        await SaveConfigurationAsync();

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        await RegisterDeviceAsync(cts.Token);
    }
    
    /// <summary>
    /// 获取当前注册状态
    /// </summary>
    public RegistrationStatus GetRegistrationStatus()
    {
        return new RegistrationStatus
        {
            IsRegistered = !string.IsNullOrEmpty(_config.DeviceId) && !string.IsNullOrEmpty(_config.Auth.Token),
            DeviceId = _config.DeviceId,
            IsValidUuid = IsValidDeviceId(),
            HasToken = !string.IsNullOrEmpty(_config.Auth.Token),
            ApprovalStatus = _authTokenProvider.GetSnapshot().DeviceStatus
        };
    }

    /// <summary>
    /// 使用邀请码绑定已有设备（重新调用注册接口，服务端会关联员工）。
    /// </summary>
    public async Task<InviteBindResult> BindWithInviteCodeAsync(string inviteCode, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(inviteCode))
            return InviteBindResult.Failed;

        _config.Employee ??= new EmployeeInfo();
        _config.Employee.InviteCode = inviteCode.Trim();
        _config.Employee.PreferSharedLogin = false;

        try
        {
            await RegisterDeviceAsync(ct).ConfigureAwait(false);
            await SaveConfigurationAsync().ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Invite bind registration timed out or cancelled");
            return InviteBindResult.Failed;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Invite bind registration failed");
            return InviteBindResult.Failed;
        }

        if (_lastRegistrationInvalidInvite)
            return InviteBindResult.InvalidInvite;

        return !string.IsNullOrEmpty(_authTokenProvider.GetSnapshot().Token)
            ? InviteBindResult.Success
            : InviteBindResult.Failed;
    }

    /// <summary>
    /// 等待设备完成注册并通过审核（最多等待指定秒数）。
    /// </summary>
    public async Task<bool> WaitForApprovedRegistrationAsync(int timeoutSeconds = 60, CancellationToken ct = default)
    {
        for (var i = 0; i < timeoutSeconds && !ct.IsCancellationRequested; i++)
        {
            var status = GetRegistrationStatus();
            if (status.IsRegistered &&
                string.Equals(status.ApprovalStatus, "approved", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            await Task.Delay(TimeSpan.FromSeconds(1), ct);
        }

        return GetRegistrationStatus().IsRegistered;
    }
}

/// <summary>
/// 注册状态信息
/// </summary>
public class RegistrationStatus
{
    public bool IsRegistered { get; set; }
    public string DeviceId { get; set; } = "";
    public bool IsValidUuid { get; set; }
    public bool HasToken { get; set; }
    public string ApprovalStatus { get; set; } = "";
}

public enum InviteBindResult
{
    Success,
    InvalidInvite,
    Failed
}

internal sealed class RegistrationResult
{
    [JsonPropertyName("deviceId")] public string DeviceId { get; set; } = "";
    [JsonPropertyName("token")] public string AccessToken { get; set; } = "";
    [JsonPropertyName("refreshToken")] public string RefreshToken { get; set; } = "";
    [JsonPropertyName("expiresAt")] public string ExpiresAt { get; set; } = "";
}

internal sealed class TokenRefreshResult
{
    [JsonPropertyName("accessToken")] public string AccessToken { get; set; } = "";
    [JsonPropertyName("refreshToken")] public string RefreshToken { get; set; } = "";
    [JsonPropertyName("expiresIn")] public int ExpiresIn { get; set; }
}
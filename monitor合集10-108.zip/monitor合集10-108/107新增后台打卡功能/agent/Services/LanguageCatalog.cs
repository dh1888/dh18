namespace EnterpriseAgent.Agent.Services;

public static class LanguageCatalog
{
    public static readonly string[] SupportedCodes = ["zh-CN", "en-US", "zh-TW", "vi-VN"];

    public static bool IsSupported(string? languageCode)
    {
        if (string.IsNullOrWhiteSpace(languageCode))
            return false;

        return SupportedCodes.Contains(languageCode, StringComparer.OrdinalIgnoreCase);
    }

    public static string GetDisplayName(string languageCode, ILocalizationService? localization)
    {
        var key = languageCode.ToUpperInvariant() switch
        {
            "ZH-CN" => "LanguageZhCn",
            "EN-US" => "LanguageEnUs",
            "ZH-TW" => "LanguageZhTw",
            "VI-VN" => "LanguageViVn",
            _ => null
        };

        if (key == null)
            return languageCode;

        return languageCode.ToUpperInvariant() switch
        {
            "ZH-CN" => localization?.GetString(key, "简体中文") ?? "简体中文",
            "EN-US" => localization?.GetString(key, "English") ?? "English",
            "ZH-TW" => localization?.GetString(key, "繁體中文") ?? "繁體中文",
            "VI-VN" => localization?.GetString(key, "Tiếng Việt") ?? "Tiếng Việt",
            _ => languageCode
        };
    }
}

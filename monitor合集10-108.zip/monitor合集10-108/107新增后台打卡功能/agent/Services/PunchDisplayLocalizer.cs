using System.Globalization;
using System.Text.RegularExpressions;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 将 TG/服务端返回的中文活动名、记录文案映射为当前 UI 语言。
/// </summary>
public static class PunchDisplayLocalizer
{
    private static readonly Dictionary<string, string> ActivityNameToCode = new(StringComparer.Ordinal)
    {
        ["小厕"] = "wc_small",
        ["大厕"] = "wc_large",
        ["吃饭"] = "eat",
        ["抽烟或休息"] = "smoke",
        ["抽烟"] = "smoke",
    };

    private static readonly Regex ChineseDurationRegex = new(
        @"^(?:(?<h>\d+)时)?(?:(?<m>\d+)分)?(?:(?<s>\d+)秒)?$",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);

    public static string LocalizeActivityName(
        string? name,
        IEnumerable<TgActivityTypeItem>? activityTypes,
        ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(name))
            return string.Empty;

        var trimmed = name.Trim();
        var code = ResolveActivityCode(trimmed, activityTypes);
        var localized = LocalizeActivityByCode(code, localization);
        return localized ?? trimmed;
    }

    public static string LocalizeActivityType(TgActivityTypeItem type, ILocalizationService? localization)
    {
        var localized = LocalizeActivityByCode(type.Code, localization);
        if (!string.IsNullOrWhiteSpace(localized))
            return localized;

        return LocalizeActivityName(type.Name, null, localization);
    }

    public static string? LocalizeActivityByCode(string? code, ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(code))
            return null;

        return code.Trim().ToLowerInvariant() switch
        {
            "wc_small" => localization?.GetString("ActivityWcSmall", "小厕") ?? "小厕",
            "wc_large" => localization?.GetString("ActivityWcLarge", "大厕") ?? "大厕",
            "eat" => localization?.GetString("ActivityEat", "吃饭") ?? "吃饭",
            "smoke" => localization?.GetString("ActivitySmoke", "抽烟或休息") ?? "抽烟或休息",
            _ => null
        };
    }

    public static string LocalizeRecordEvent(
        string? eventText,
        IEnumerable<TgActivityTypeItem>? activityTypes,
        ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(eventText))
            return string.Empty;

        var value = eventText.Trim();
        var mapped = value switch
        {
            "白班上班" => localization?.GetString("CheckInDay", "白班上班") ?? "白班上班",
            "夜班上班" => localization?.GetString("CheckInNight", "夜班上班") ?? "夜班上班",
            "白班下班" => localization?.GetString("TrayPunchEventDayCheckOut", "白班下班") ?? "白班下班",
            "夜班下班" => localization?.GetString("TrayPunchEventNightCheckOut", "夜班下班") ?? "夜班下班",
            "下班" => localization?.GetString("CheckOut", "下班") ?? "下班",
            "上班" => localization?.GetString("CheckIn", "上班") ?? "上班",
            _ => null
        };

        if (!string.IsNullOrWhiteSpace(mapped))
            return mapped;

        return LocalizeActivityName(value, activityTypes, localization);
    }

    public static string LocalizeRecordDetail(string? detail, ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(detail))
            return string.Empty;

        var value = detail.Trim();
        var mapped = value switch
        {
            "上班打卡" => localization?.GetString("TrayPunchCheckInDetail", "上班打卡") ?? "上班打卡",
            "上班中" => localization?.GetString("TrayPunchWorkInProgress", "上班中") ?? "上班中",
            "下班打卡" => localization?.GetString("TrayPunchCheckOutDetail", "下班打卡") ?? "下班打卡",
            "开始" => localization?.GetString("TrayPunchActivityStarted", "开始") ?? "开始",
            "进行中" => localization?.GetString("TrayPunchInProgress", "进行中") ?? "进行中",
            "已结束" => localization?.GetString("TrayPunchActivityEnded", "已结束") ?? "已结束",
            _ => null
        };

        if (!string.IsNullOrWhiteSpace(mapped))
            return mapped;

        if (TryParseChineseDuration(value, out var seconds))
            return DurationFormatter.FormatDuration(seconds, localization);

        return value;
    }

    public static string LocalizeRecordSource(string? source, ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(source) || source == "-")
            return "-";

        return source.Trim().ToUpperInvariant() switch
        {
            "PC" => localization?.GetString("TrayPunchSourcePc", "PC") ?? "PC",
            "TG" => localization?.GetString("TrayPunchSourceTg", "TG") ?? "TG",
            "TELEGRAM" => localization?.GetString("TrayPunchSourceTg", "TG") ?? "TG",
            "AGENT" => localization?.GetString("TrayPunchSourcePc", "PC") ?? "PC",
            _ => source.Trim()
        };
    }

    private static string? ResolveActivityCode(string name, IEnumerable<TgActivityTypeItem>? activityTypes)
    {
        if (activityTypes != null)
        {
            foreach (var type in activityTypes)
            {
                if (string.Equals(type.Name, name, StringComparison.OrdinalIgnoreCase)
                    && !string.IsNullOrWhiteSpace(type.Code))
                {
                    return type.Code;
                }
            }
        }

        return ActivityNameToCode.TryGetValue(name, out var code) ? code : null;
    }

    private static bool TryParseChineseDuration(string text, out int totalSeconds)
    {
        totalSeconds = 0;
        var match = ChineseDurationRegex.Match(text.Trim());
        if (!match.Success)
            return false;

        var hasPart = false;
        if (match.Groups["h"].Success && int.TryParse(match.Groups["h"].Value, NumberStyles.None, CultureInfo.InvariantCulture, out var hours))
        {
            totalSeconds += hours * 3600;
            hasPart = true;
        }

        if (match.Groups["m"].Success && int.TryParse(match.Groups["m"].Value, NumberStyles.None, CultureInfo.InvariantCulture, out var minutes))
        {
            totalSeconds += minutes * 60;
            hasPart = true;
        }

        if (match.Groups["s"].Success && int.TryParse(match.Groups["s"].Value, NumberStyles.None, CultureInfo.InvariantCulture, out var seconds))
        {
            totalSeconds += seconds;
            hasPart = true;
        }

        return hasPart;
    }
}

using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 退出时清理本客户端拉起的 ffmpeg，避免录制文件被孤儿进程占用。
/// </summary>
internal static class FfmpegProcessCleanup
{
    internal static void KillAgentFfmpegProcesses(ILogger? logger = null)
    {
        var expectedPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "ffmpeg.exe")),
            Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "bin", "ffmpeg.exe")),
        };

        foreach (var process in Process.GetProcessesByName("ffmpeg"))
        {
            try
            {
                if (!IsAgentFfmpeg(process, expectedPaths))
                    continue;

                logger?.LogInformation("Killing residual ffmpeg (pid={Pid})", process.Id);
                if (!process.HasExited)
                    process.Kill(entireProcessTree: true);
                process.WaitForExit(5000);
            }
            catch (Exception ex)
            {
                logger?.LogDebug(ex, "Failed to kill ffmpeg pid={Pid}", TryGetPid(process));
            }
            finally
            {
                process.Dispose();
            }
        }
    }

    private static bool IsAgentFfmpeg(Process process, HashSet<string> expectedPaths)
    {
        try
        {
            var modulePath = process.MainModule?.FileName;
            if (string.IsNullOrWhiteSpace(modulePath))
                return false;

            return expectedPaths.Contains(Path.GetFullPath(modulePath));
        }
        catch
        {
            // 无法读取模块路径时不误杀其它 ffmpeg
            return false;
        }
    }

    private static int TryGetPid(Process? process)
    {
        try
        {
            return process?.Id ?? -1;
        }
        catch
        {
            return -1;
        }
    }
}

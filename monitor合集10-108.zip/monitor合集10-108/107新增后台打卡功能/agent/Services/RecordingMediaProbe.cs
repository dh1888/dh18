using System.Diagnostics;
using System.Globalization;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 读取 MP4 真实媒体播放时长（秒），不参与 timeline 计算。
/// </summary>
internal static class RecordingMediaProbe
{
    private const int ProbeTimeoutMs = 3000;

    public static bool TryGetDurationSeconds(string filePath, out int durationSeconds)
    {
        durationSeconds = 0;

        if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
            return false;

        FileInfo fileInfo;
        try
        {
            fileInfo = new FileInfo(filePath);
        }
        catch
        {
            return false;
        }

        if (fileInfo.Length <= 0)
            return false;

        var ffprobe = FindFfprobe();
        if (string.IsNullOrWhiteSpace(ffprobe))
            return false;

        try
        {
            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffprobe,
                    Arguments =
                        $"-v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 \"{filePath}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                },
            };

            if (!process.Start())
                return false;

            if (!process.WaitForExit(ProbeTimeoutMs))
            {
                try
                {
                    process.Kill(entireProcessTree: true);
                }
                catch
                {
                    // ignore kill failures on timeout
                }

                return false;
            }

            if (process.ExitCode != 0)
                return false;

            var output = process.StandardOutput.ReadToEnd().Trim();
            if (!double.TryParse(output, NumberStyles.Float, CultureInfo.InvariantCulture, out var seconds) ||
                seconds <= 0 ||
                !double.IsFinite(seconds))
            {
                return false;
            }

            durationSeconds = (int)Math.Floor(seconds);
            return durationSeconds > 0;
        }
        catch
        {
            return false;
        }
    }

    private static string? FindFfprobe()
    {
        foreach (var ffmpegPath in GetFfmpegSearchPaths())
        {
            try
            {
                if (!File.Exists(ffmpegPath))
                    continue;

                var ffprobePath = Path.Combine(Path.GetDirectoryName(ffmpegPath) ?? "", "ffprobe.exe");
                if (File.Exists(ffprobePath))
                    return ffprobePath;
            }
            catch
            {
                // ignore invalid paths
            }
        }

        return null;
    }

    private static IEnumerable<string> GetFfmpegSearchPaths()
    {
        var baseDir = AppDomain.CurrentDomain.BaseDirectory;
        yield return Path.Combine(baseDir, "ffmpeg.exe");
        yield return Path.Combine(baseDir, "bin", "ffmpeg.exe");

        var projectDir = Path.GetFullPath(Path.Combine(baseDir, "..", "..", ".."));
        yield return Path.Combine(projectDir, "ffmpeg.exe");

        yield return @"C:\ffmpeg\bin\ffmpeg.exe";
        yield return @"C:\Program Files\ffmpeg\bin\ffmpeg.exe";

        var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (var dir in pathEnv.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            yield return Path.Combine(dir, "ffmpeg.exe");
        }
    }
}

using System.Net.Http.Headers;
using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

public sealed class TelegramBindService
{
    private readonly ILogger<TelegramBindService> _logger;
    private readonly IHttpClientFactory _httpFactory;
    private readonly IAuthTokenProvider _authTokenProvider;

    public TelegramBindService(
        ILogger<TelegramBindService> logger,
        IHttpClientFactory httpFactory,
        IAuthTokenProvider authTokenProvider)
    {
        _logger = logger;
        _httpFactory = httpFactory;
        _authTokenProvider = authTokenProvider;
    }

    private Func<string>? _serverUrlResolver;
    public void SetServerUrlResolver(Func<string> resolver) => _serverUrlResolver = resolver;

    public async Task<TelegramBindTokenResult?> CreateBindTokenAsync(CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return null;

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/telegram-bind-token");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning("Create telegram bind token failed: {Status} {Body}", response.StatusCode, body);
            return null;
        }

        try
        {
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return null;
            return new TelegramBindTokenResult
            {
                DeepLink = data.TryGetProperty("deepLink", out var link) ? link.GetString() ?? "" : "",
                BotUsername = data.TryGetProperty("botUsername", out var bot) ? bot.GetString() ?? "" : "",
                EmployeeName = data.TryGetProperty("employeeName", out var name) ? name.GetString() ?? "" : "",
                ExpiresAt = data.TryGetProperty("expiresAt", out var exp) ? exp.GetString() ?? "" : "",
            };
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to parse telegram bind token response");
            return null;
        }
    }

    public async Task<bool> IsTelegramBoundAsync(CancellationToken ct = default)
    {
        var status = await GetBindStatusAsync(ct);
        return status.Bound;
    }

    public async Task<TelegramBindStatus> GetBindStatusAsync(CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return TelegramBindStatus.NotBound;

        using var request = new HttpRequestMessage(HttpMethod.Get, $"{GetServerUrl()}/api/v1/agent/telegram-bind-status");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        if (!response.IsSuccessStatusCode)
            return TelegramBindStatus.NotBound;

        var body = await response.Content.ReadAsStringAsync(ct);
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return TelegramBindStatus.NotBound;

            var bound = data.TryGetProperty("bound", out var boundEl) && boundEl.GetBoolean();
            if (!bound)
                return TelegramBindStatus.NotBound;

            var username = data.TryGetProperty("telegramUsername", out var userEl)
                ? userEl.GetString() ?? ""
                : "";
            var channel = data.TryGetProperty("channel", out var channelEl)
                ? channelEl.GetString() ?? ""
                : "";
            return new TelegramBindStatus
            {
                Bound = true,
                Channel = channel.Trim(),
                TelegramUsername = username.Trim().TrimStart('@'),
            };
        }
        catch
        {
            return TelegramBindStatus.NotBound;
        }
    }

    private string GetServerUrl() => _serverUrlResolver?.Invoke() ?? "http://localhost:8080";
}

public sealed class TelegramBindTokenResult
{
    public string DeepLink { get; set; } = "";
    public string BotUsername { get; set; } = "";
    public string EmployeeName { get; set; } = "";
    public string ExpiresAt { get; set; } = "";
}

public sealed class TelegramBindStatus
{
    public static TelegramBindStatus NotBound { get; } = new();

    public bool Bound { get; init; }
    public string Channel { get; init; } = "";
    public string TelegramUsername { get; init; } = "";

    public bool IsWorkstationChannel =>
        string.Equals(Channel, "workstation", StringComparison.OrdinalIgnoreCase);

    public string DisplayLabel
    {
        get
        {
            if (!Bound)
                return "";
            if (IsWorkstationChannel)
                return string.IsNullOrWhiteSpace(TelegramUsername)
                    ? "工位 TG"
                    : "工位 TG @" + TelegramUsername.TrimStart('@');
            if (string.IsNullOrWhiteSpace(TelegramUsername))
                return "已绑定";
            return "@" + TelegramUsername.TrimStart('@');
        }
    }
}

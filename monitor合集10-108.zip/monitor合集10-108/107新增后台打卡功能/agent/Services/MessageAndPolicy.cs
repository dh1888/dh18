// Services/MessageAndPolicy.cs - 完整修改版（集成 AuthTokenProvider）

using System.Net.Http.Json;
using System.Text;
using System.Collections.Concurrent;
using System.Text.Json;
using EnterpriseAgent.Agent.Extensions;
using EnterpriseAgent.Agent.Lifecycle;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Storage; 
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;


namespace EnterpriseAgent.Agent.Services;

#region 消息总线

/// <summary>
/// 消息总线接口，用于解耦 WebSocket 与业务逻辑
/// </summary>
public interface IMessageBus
{
    /// <summary>
    /// 订阅特定类型的消息
    /// </summary>
    /// <param name="messageType">消息类型</param>
    /// <param name="handler">消息处理程序</param>
    void Subscribe(string messageType, Func<JsonElement, Task> handler);

    /// <summary>
    /// 取消订阅消息
    /// </summary>
    /// <param name="messageType">消息类型</param>
    /// <param name="handler">消息处理程序</param>
    void Unsubscribe(string messageType, Func<JsonElement, Task> handler);

    /// <summary>
    /// 发布消息
    /// </summary>
    /// <param name="messageType">消息类型</param>
    /// <param name="payload">消息负载</param>
    Task PublishAsync(string messageType, JsonElement payload);

    /// <summary>
    /// 订阅所有消息
    /// </summary>
    /// <param name="handler">消息处理程序，参数为 (messageType, payload)</param>
    void SubscribeAll(Func<string, JsonElement, Task> handler);

    /// <summary>
    /// 取消订阅所有消息
    /// </summary>
    void UnsubscribeAll(Func<string, JsonElement, Task> handler);
}

/// <summary>
/// 消息总线实现，支持发布-订阅模式
/// </summary>
public class MessageBus : IMessageBus
{
    private readonly ILogger<MessageBus> _logger;
    private readonly Dictionary<string, List<Func<JsonElement, Task>>> _subscribers = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<Func<string, JsonElement, Task>> _allSubscribers = new();
    private readonly object _lock = new();

    public MessageBus(ILogger<MessageBus> logger)
    {
        _logger = logger;
    }

    public void Subscribe(string messageType, Func<JsonElement, Task> handler)
    {
        if (string.IsNullOrWhiteSpace(messageType))
            throw new ArgumentNullException(nameof(messageType));
        if (handler == null)
            throw new ArgumentNullException(nameof(handler));

        lock (_lock)
        {
            if (!_subscribers.ContainsKey(messageType))
                _subscribers[messageType] = new List<Func<JsonElement, Task>>();

            _subscribers[messageType].Add(handler);
            _logger.LogDebug("Subscribed to message type: {MessageType}", messageType);
        }
    }

    public void Unsubscribe(string messageType, Func<JsonElement, Task> handler)
    {
        if (string.IsNullOrWhiteSpace(messageType) || handler == null)
            return;

        lock (_lock)
        {
            if (_subscribers.TryGetValue(messageType, out var handlers))
            {
                handlers.Remove(handler);
                if (handlers.Count == 0)
                    _subscribers.Remove(messageType);
                
                _logger.LogDebug("Unsubscribed from message type: {MessageType}", messageType);
            }
        }
    }

    public async Task PublishAsync(string messageType, JsonElement payload)
    {
        if (string.IsNullOrWhiteSpace(messageType))
            throw new ArgumentNullException(nameof(messageType));

        List<Func<JsonElement, Task>>? handlers = null;
        List<Func<string, JsonElement, Task>>? allHandlers = null;

        lock (_lock)
        {
            if (_subscribers.TryGetValue(messageType, out var subs))
                handlers = new List<Func<JsonElement, Task>>(subs);

            allHandlers = new List<Func<string, JsonElement, Task>>(_allSubscribers);
        }

        if (handlers != null)
        {
            foreach (var handler in handlers)
            {
                try
                {
                    await handler(payload);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error handling message of type {MessageType}", messageType);
                }
            }
        }

        if (allHandlers != null)
        {
            foreach (var handler in allHandlers)
            {
                try
                {
                    await handler(messageType, payload);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error in all-message handler for type {MessageType}", messageType);
                }
            }
        }

        _logger.LogDebug("Published message of type: {MessageType}", messageType);
    }

    public void SubscribeAll(Func<string, JsonElement, Task> handler)
    {
        if (handler == null)
            throw new ArgumentNullException(nameof(handler));

        lock (_lock)
        {
            _allSubscribers.Add(handler);
            _logger.LogDebug("Subscribed to all messages");
        }
    }

    public void UnsubscribeAll(Func<string, JsonElement, Task> handler)
    {
        if (handler == null)
            return;

        lock (_lock)
        {
            _allSubscribers.Remove(handler);
            _logger.LogDebug("Unsubscribed from all messages");
        }
    }
}

#endregion

#region 策略同步服务

public class PolicySyncService : BackgroundService
{
    private readonly ILogger<PolicySyncService> _logger;
    private readonly IMessageBus _messageBus;
    private readonly IHttpClientFactory _httpFactory;
    private readonly AgentConfig _config;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILifecycleCoordinator _lifecycleCoordinator;
    private readonly FileUploadService _uploader;
    private readonly ScreenshotService _screenshotService;
    private readonly CleanupService _cleanup;
    private readonly ActivityMonitorService _activityMonitor;
    private readonly IAuthTokenProvider _authTokenProvider;
    private readonly PolicySignatureVerifier _policySignatureVerifier;
    
    private Policy? _currentPolicy;
    private readonly SemaphoreSlim _syncLock = new(1, 1);
    private DateTime _lastSyncTime;
    private bool _isStopping;

    public PolicySyncService(
        ILogger<PolicySyncService> logger,
        IMessageBus messageBus,
        IHttpClientFactory httpFactory,
        AgentConfig config,
        IServiceScopeFactory scopeFactory,
        ILifecycleCoordinator lifecycleCoordinator,
        FileUploadService uploader,
        ScreenshotService screenshotService,
        CleanupService cleanup,
        ActivityMonitorService activityMonitor,
        IAuthTokenProvider authTokenProvider)  // ✅ 新增参数
    {
        _logger = logger;
        _messageBus = messageBus ?? throw new ArgumentNullException(nameof(messageBus));
        _httpFactory = httpFactory;
        _config = config;
        _scopeFactory = scopeFactory;
        _lifecycleCoordinator = lifecycleCoordinator ?? throw new ArgumentNullException(nameof(lifecycleCoordinator));
        _uploader = uploader ?? throw new ArgumentNullException(nameof(uploader));
        _screenshotService = screenshotService ?? throw new ArgumentNullException(nameof(screenshotService));
        _cleanup = cleanup ?? throw new ArgumentNullException(nameof(cleanup));
        _activityMonitor = activityMonitor ?? throw new ArgumentNullException(nameof(activityMonitor));
        _authTokenProvider = authTokenProvider;

        _policySignatureVerifier = new PolicySignatureVerifier(_config.Auth?.PolicyPublicKeys ?? new Dictionary<string, string>());

        // ========== WebSocket 策略更新订阅 ==========
        // 订阅后端推送的策略更新消息 (type: "policy_update")
        _messageBus.Subscribe("policy_update", async payload =>
        {
            await HandleWebSocketPolicyUpdateAsync(payload);
        });
        
        // 可选：订阅策略同步请求（后端可通过此消息要求客户端立即同步）
        _messageBus.Subscribe("policy.sync", async _ =>
        {
            _logger.LogInformation("收到策略同步请求，立即同步");
            await ForceSyncAsync();
        });
    }

    private async Task HandleWebSocketPolicyUpdateAsync(JsonElement payload)
    {
        _logger.LogInformation("📡 收到策略更新 WebSocket 推送");

        try
        {
            if (!payload.TryGetProperty("policy", out var policyElement))
            {
                _logger.LogWarning("策略更新消息缺少 policy 字段");
                return;
            }

            if (!TryReadPolicySignatureEnvelope(payload, policyElement, out var envelope, out var parseError))
            {
                _logger.LogWarning("策略更新消息无效: {Error}", parseError);
                return;
            }

            await ApplyPolicyIfNewerAsync(envelope, "websocket", publishEvent: false);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "处理 WebSocket 策略更新失败");
        }
    }

    private sealed class PolicySignatureEnvelope
    {
        public required JsonElement PolicyElement { get; init; }
        public required Policy Policy { get; init; }
        public required string Signature { get; init; }
        public required string SignatureAlg { get; init; }
        public required int SignatureVersion { get; init; }
        public required string KeyId { get; init; }
    }

    /// <summary>
    /// 统一策略应用入口：版本比较 + 签名校验 + 缓存 + 应用（HTTP / WebSocket 共用）
    /// </summary>
    private async Task<bool> ApplyPolicyIfNewerAsync(
        PolicySignatureEnvelope envelope,
        string source,
        bool publishEvent,
        CancellationToken ct = default)
    {
        await _syncLock.WaitAsync(ct);
        try
        {
            var policy = envelope.Policy;
            var currentVersion = _currentPolicy?.Version ?? 0;
            if (policy.Version <= currentVersion)
            {
                _logger.LogDebug(
                    "忽略来自 {Source} 的策略: v{Version} 不高于当前 v{CurrentVersion}",
                    source,
                    policy.Version,
                    currentVersion);
                return false;
            }

            if (!_policySignatureVerifier.TryVerifyPolicy(
                    envelope.PolicyElement,
                    envelope.Signature,
                    envelope.SignatureAlg,
                    envelope.SignatureVersion,
                    envelope.KeyId,
                    out var verifyError))
            {
                _logger.LogError(
                    "来自 {Source} 的策略签名校验失败，拒绝 v{Version}: {Reason}",
                    source,
                    policy.Version,
                    verifyError);
                return false;
            }

            policy.Signature = envelope.Signature;

            _logger.LogInformation(
                "应用来自 {Source} 的策略: v{OldVersion} -> v{NewVersion}",
                source,
                currentVersion,
                policy.Version);

            using var scope = _scopeFactory.CreateScope();
            var policyRepo = scope.ServiceProvider.GetRequiredService<PolicyRepository>();
            await policyRepo.CacheAsync(
                policy,
                envelope.PolicyElement.GetRawText(),
                envelope.SignatureAlg,
                envelope.SignatureVersion,
                envelope.KeyId);

            _currentPolicy = policy;
            ApplyPolicy(policy);
            _lastSyncTime = DateTime.UtcNow;

            if (publishEvent)
            {
                await _messageBus.PublishAsync("policy.updated", JsonSerializer.SerializeToElement(policy));
            }

            _logger.LogInformation("策略已从 {Source} 更新到版本 {Version}", source, policy.Version);
            return true;
        }
        finally
        {
            _syncLock.Release();
        }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Policy sync service started");
        
        await LoadCachedPolicyAsync();
        await SyncPolicyWithRetryAsync(stoppingToken);
        
        while (!stoppingToken.IsCancellationRequested && !_isStopping)
        {
            try
            {
                await SyncPolicyAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Policy sync failed");
            }
            
            await Task.Delay(
                TimeSpan.FromSeconds(Math.Max(_config.Policy.SyncIntervalSeconds, 60)),
                stoppingToken);
        }
        
        _logger.LogInformation("Policy sync service stopped");
    }

    private async Task LoadCachedPolicyAsync()
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var policyRepo = scope.ServiceProvider.GetRequiredService<PolicyRepository>();
            
            var cached = await policyRepo.GetCachedAsync();
            if (cached != null)
            {
                if (TryBuildEnvelopeFromCache(cached, out var envelope, out var cacheError))
                {
                    await ApplyPolicyIfNewerAsync(envelope, "cache", publishEvent: false);
                    _logger.LogInformation("Loaded cached policy version {Version}", cached.Policy.Version);
                }
                else
                {
                    _logger.LogWarning("Skip cached policy: {Reason}", cacheError);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to load cached policy");
        }
    }

    private async Task SyncPolicyWithRetryAsync(CancellationToken ct)
    {
        for (int i = 0; i < Constants.MaxRetryCount; i++)
        {
            try
            {
                await SyncPolicyAsync(ct);
                return;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Initial policy sync attempt {Attempt}/{MaxRetries} failed", i + 1, Constants.MaxRetryCount);
                if (i < Constants.MaxRetryCount - 1)
                    await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, i)), ct);
            }
        }
    }

    private async Task SyncPolicyAsync(CancellationToken ct)
    {
        try
        {
            var success = await TrySyncPolicyOnceAsync(ct);
            if (!success)
            {
                // 401 后 refresh 已在 TrySyncPolicyOnceAsync 内完成，重试一次
                await TrySyncPolicyOnceAsync(ct);
            }

            using var scope = _scopeFactory.CreateScope();
            var workSession = scope.ServiceProvider.GetService<WorkSessionService>();
            if (workSession != null)
            {
                await workSession.SyncCaptureSettingsAsync(ct);
                workSession.ApplyAutoCaptureFromPolicy(_currentPolicy);
            }
        }
        catch (HttpRequestException ex)
        {
            _logger.LogWarning(ex, "HTTP request failed during policy sync");
            throw;
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("Policy sync cancelled");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during policy sync");
            throw;
        }
    }

    private async Task<bool> TrySyncPolicyOnceAsync(CancellationToken ct)
    {
        try
        {
            var url = $"{_config.ServerUrl}/api/v1/policies/current";

            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            if (!HttpAuthExtensions.TryApplyBearerToken(request, _authTokenProvider))
            {
                _logger.LogWarning("Token is empty, skipping policy sync");
                return false;
            }

            using var http = _httpFactory.CreateClient("AgentClient");
            using var response = await http.SendAsync(request, ct);

            if (response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync(ct);
                if (TryParsePolicyFromApiResponse(body, out var envelope))
                {
                    await ApplyPolicyIfNewerAsync(envelope, "http", publishEvent: true, ct);
                }
                else
                {
                    _logger.LogWarning("Policy API response format invalid or signature missing");
                }
                return true;
            }

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                _logger.LogWarning("Unauthorized to fetch policy, attempting token refresh");
                await _authTokenProvider.RefreshTokenAsync(ct);
                return false;
            }

            _logger.LogWarning("Policy sync failed with status {StatusCode}", (int)response.StatusCode);
            return false;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
    }

    private static bool TryParsePolicyFromApiResponse(
        string json,
        out PolicySignatureEnvelope envelope)
    {
        envelope = null!;

        try
        {
            using var doc = JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return false;

            if (!data.TryGetProperty("policy", out var policyElement))
                return false;

            return TryReadPolicySignatureEnvelope(data, policyElement, out envelope, out _);
        }
        catch
        {
            return false;
        }
    }

    private static bool TryReadPolicySignatureEnvelope(
        JsonElement container,
        JsonElement policyElement,
        out PolicySignatureEnvelope envelope,
        out string error)
    {
        envelope = null!;
        error = "";

        if (!container.TryGetProperty("signature", out var signatureProp))
        {
            error = "signature is missing";
            return false;
        }

        var signature = signatureProp.GetString() ?? "";
        if (string.IsNullOrWhiteSpace(signature))
        {
            error = "signature is empty";
            return false;
        }

        if (!container.TryGetProperty("signatureAlg", out var algProp))
        {
            error = "signatureAlg is missing";
            return false;
        }

        var signatureAlg = algProp.GetString() ?? "";
        if (string.IsNullOrWhiteSpace(signatureAlg))
        {
            error = "signatureAlg is empty";
            return false;
        }

        if (!container.TryGetProperty("signatureVersion", out var versionProp) ||
            !versionProp.TryGetInt32(out var signatureVersion))
        {
            error = "signatureVersion is missing";
            return false;
        }

        if (!container.TryGetProperty("keyId", out var keyIdProp))
        {
            error = "keyId is missing";
            return false;
        }

        var keyId = keyIdProp.GetString() ?? "";
        if (string.IsNullOrWhiteSpace(keyId))
        {
            error = "keyId is empty";
            return false;
        }

        var policy = JsonSerializer.Deserialize<Policy>(policyElement.GetRawText(), new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });
        if (policy == null)
        {
            error = "policy parse failed";
            return false;
        }

        if (container.TryGetProperty("version", out var envelopeVersionProp) &&
            envelopeVersionProp.TryGetInt32(out var envelopeVersion) &&
            envelopeVersion > 0 &&
            policy.Version != envelopeVersion)
        {
            policy.Version = envelopeVersion;
        }

        policy.Signature = signature;

        envelope = new PolicySignatureEnvelope
        {
            PolicyElement = policyElement.Clone(),
            Policy = policy,
            Signature = signature,
            SignatureAlg = signatureAlg,
            SignatureVersion = signatureVersion,
            KeyId = keyId,
        };
        return true;
    }

    private bool TryBuildEnvelopeFromCache(CachedPolicy cached, out PolicySignatureEnvelope envelope, out string error)
    {
        envelope = null!;
        error = "";

        if (string.IsNullOrWhiteSpace(cached.SignatureAlg) ||
            string.IsNullOrWhiteSpace(cached.KeyId) ||
            cached.SignatureVersion <= 0)
        {
            error = "cached signature metadata is incomplete";
            return false;
        }

        try
        {
            using var doc = JsonDocument.Parse(cached.SignedContentJson);
            var policyElement = doc.RootElement.Clone();
            envelope = new PolicySignatureEnvelope
            {
                PolicyElement = policyElement,
                Policy = cached.Policy,
                Signature = cached.Policy.Signature ?? "",
                SignatureAlg = cached.SignatureAlg,
                SignatureVersion = cached.SignatureVersion,
                KeyId = cached.KeyId,
            };
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    private void ApplyPolicy(Policy policy)
    {
        try
        {
            _logger.LogInformation("Applying policy version {Version}", policy.Version);
            
            _lifecycleCoordinator.UpdatePolicy(policy);
            _uploader?.UpdatePolicy(policy);
            _screenshotService?.UpdatePolicy(policy);
            _activityMonitor.UpdatePolicy(policy);
            
            var cleanupConfig = policy.GetCleanupConfig();
            _cleanup?.UpdatePolicy(cleanupConfig);

            var securityConfig = policy.GetSecurityConfig();
            _logger.LogInformation(
                "Security policy applied: EnableEncryption={EnableEncryption}, EnableVPN={EnableVPN}",
                securityConfig.EnableEncryption,
                securityConfig.EnableVPN);
            if (securityConfig.EnableVPN)
            {
                _logger.LogWarning(
                    "Policy requires VPN but Windows agent does not enforce VPN routing yet");
            }
            if (!securityConfig.EnableEncryption)
            {
                _logger.LogWarning(
                    "Policy disabled encryption flag; agent still uses HTTPS and DPAPI for secrets");
            }

            using var scope = _scopeFactory.CreateScope();
            var workSession = scope.ServiceProvider.GetService<WorkSessionService>();
            workSession?.ApplyAutoCaptureFromPolicy(policy);
            
            _logger.LogInformation("Policy applied successfully");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to apply policy");
        }
    }

    public async Task ForceSyncAsync()
    {
        _logger.LogInformation("Forcing policy sync");
        await SyncPolicyAsync(CancellationToken.None);
    }

    public Policy? GetCurrentPolicy() => _currentPolicy;

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Stopping policy sync service...");
        _isStopping = true;
        
        if (_syncLock.CurrentCount == 0)
        {
            await _syncLock.WaitAsync(TimeSpan.FromSeconds(10), cancellationToken);
            _syncLock.Release();
        }
        
        await base.StopAsync(cancellationToken);
    }
}

#endregion

#region 活动日志实时上报服务

/// <summary>
/// 活动日志实时上报服务 - 监听消息总线并转发到 WebSocket
/// </summary>
public class ActivityRealTimeReporter : BackgroundService
{
    private const int MaxBufferedActivities = 500;

    private readonly ILogger<ActivityRealTimeReporter> _logger;
    private readonly IMessageBus _messageBus;
    private readonly WebSocketService _webSocketService;
    private readonly AgentConfig _config;

    private readonly ConcurrentQueue<string> _offlineBuffer = new();
    private int _bufferedCount;

    private Func<JsonElement, Task>? _handler;
    private Func<JsonElement, Task>? _connectedHandler;

    public ActivityRealTimeReporter(
        ILogger<ActivityRealTimeReporter> logger,
        IMessageBus messageBus,
        WebSocketService webSocketService,
        AgentConfig config)
    {
        _logger = logger;
        _messageBus = messageBus;
        _webSocketService = webSocketService;
        _config = config;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Activity real-time reporter started (with offline buffer)");

        _handler = async payload =>
        {
            try
            {
                await ForwardActivityToWebSocket(payload, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                // 正常取消
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to forward activity to WebSocket");
            }
        };

        _connectedHandler = async _ =>
        {
            try
            {
                await FlushOfflineBufferAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                // 正常取消
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to flush offline activity buffer on reconnect");
            }
        };

        _messageBus.Subscribe("activity.real_time", _handler);
        _messageBus.Subscribe("websocket.connected", _connectedHandler);

        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                if (_webSocketService.IsConnected && !_offlineBuffer.IsEmpty)
                    await FlushOfflineBufferAsync(stoppingToken);

                await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
            }
        }
        catch (OperationCanceledException)
        {
            // 正常停止
        }
    }

    private async Task ForwardActivityToWebSocket(JsonElement payload, CancellationToken ct)
    {
        if (!_webSocketService.IsConnected)
        {
            BufferActivity(payload);
            return;
        }

        await SendActivityAsync(payload, ct);
    }

    private void BufferActivity(JsonElement payload)
    {
        var json = JsonSerializer.Serialize(payload);
        _offlineBuffer.Enqueue(json);

        var count = Interlocked.Increment(ref _bufferedCount);
        while (count > MaxBufferedActivities && _offlineBuffer.TryDequeue(out _))
            count = Interlocked.Decrement(ref _bufferedCount);

        if (count == 1 || count % 50 == 0)
            _logger.LogDebug("Buffered real-time activity (offline), queue size ~{Count}", count);
    }

    private async Task FlushOfflineBufferAsync(CancellationToken ct)
    {
        if (!_webSocketService.IsConnected || _offlineBuffer.IsEmpty)
            return;

        var flushed = 0;
        while (_offlineBuffer.TryDequeue(out var json))
        {
            Interlocked.Decrement(ref _bufferedCount);

            try
            {
                var payload = JsonSerializer.Deserialize<JsonElement>(json);
                await SendActivityAsync(payload, ct);
                flushed++;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to flush buffered activity");
            }
        }

        if (flushed > 0)
            _logger.LogInformation("Flushed {Count} buffered real-time activities after reconnect", flushed);
    }

    private async Task SendActivityAsync(JsonElement payload, CancellationToken ct)
    {
        var message = new WebSocketMessage
        {
            Type = "activity.real_time",
            Data = payload,
            Timestamp = DateTime.UtcNow,
            DeviceId = _config.DeviceId
        };

        var json = JsonSerializer.Serialize(message);
        await _webSocketService.SendMessageAsync(json, ct);
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Stopping activity real-time reporter...");
        if (_handler != null)
        {
            _messageBus.Unsubscribe("activity.real_time", _handler);
            _handler = null;
        }
        if (_connectedHandler != null)
        {
            _messageBus.Unsubscribe("websocket.connected", _connectedHandler);
            _connectedHandler = null;
        }
        await base.StopAsync(cancellationToken);
    }
}

/// <summary>
/// WebSocket 消息结构
/// </summary>
public class WebSocketMessage
{
    public string Type { get; set; } = "";
    public JsonElement Data { get; set; }
    public DateTime Timestamp { get; set; }
    public string DeviceId { get; set; } = "";
}

#endregion
namespace EnterpriseAgent.Agent.Services;

public sealed class EmployeeTrayStatus
{
    public bool IsLoggedIn { get; init; }
    public string? Name { get; init; }
    public string? Username { get; init; }
    public string? EmployeeNumber { get; init; }
    public string? Position { get; init; }

    public string DisplayLabel
    {
        get
        {
            if (!IsLoggedIn)
                return "未登录";

            if (!string.IsNullOrWhiteSpace(Name) && !string.IsNullOrWhiteSpace(Username))
                return $"{Name} ({Username})";

            return Name ?? Username ?? "已登录";
        }
    }

    public string DetailLabel
    {
        get
        {
            if (!IsLoggedIn)
                return "请点击「员工登录」";

            var parts = new List<string>();
            if (!string.IsNullOrWhiteSpace(EmployeeNumber))
                parts.Add($"工号 {EmployeeNumber}");
            if (!string.IsNullOrWhiteSpace(Position))
                parts.Add(Position);
            return parts.Count > 0 ? string.Join(" · ", parts) : DisplayLabel;
        }
    }
}

using System.Net.Http.Headers;

using System.Text;

using System.Text.Json;

using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Recorder;

using Microsoft.Extensions.Logging;



namespace EnterpriseAgent.Agent.Services;



/// <summary>

/// 上下班 Session：调用后端 checkin/checkout，并协调录屏/截图启停。

/// </summary>

public sealed class WorkSessionService

{

    private readonly ILogger<WorkSessionService> _logger;

    private readonly IHttpClientFactory _httpFactory;

    private readonly IAuthTokenProvider _authTokenProvider;

    private readonly IRecorderLifecycle _recorderLifecycle;

    private readonly ScreenshotService _screenshot;



    private string? _openSessionId;

    private volatile bool _captureLinkedToCheckin;
    private volatile bool _dualShiftEnabled;

    private readonly object _lock = new();

    private string? _lastTelegramNotifiedSessionId;
    private string? _lastTelegramCheckoutNotifiedSessionId;

    /// <summary>Last check-in failure message from the server (for UI).</summary>
    public string? LastCheckInError { get; private set; }

    /// <summary>本地上班会话 ID 或 open 状态变化时触发。</summary>
    public event EventHandler<WorkSessionSyncEventArgs>? SessionSyncChanged;

    /// <summary>后台双班配置变化时触发（托盘切换白班/夜班菜单）。</summary>
    public event EventHandler? DualShiftConfigChanged;



    public WorkSessionService(

        ILogger<WorkSessionService> logger,

        IHttpClientFactory httpFactory,

        IAuthTokenProvider authTokenProvider,

        IRecorderLifecycle recorderLifecycle,

        ScreenshotService screenshot)

    {

        _logger = logger;

        _httpFactory = httpFactory;

        _authTokenProvider = authTokenProvider;

        _recorderLifecycle = recorderLifecycle;

        _screenshot = screenshot;

    }



    public bool HasOpenSession

    {

        get { lock (_lock) return !string.IsNullOrEmpty(_openSessionId); }

    }



    public bool CaptureLinkedToCheckin => _captureLinkedToCheckin;

    public bool DualShiftEnabled => _dualShiftEnabled;

    private void UpdateDualShiftEnabled(bool enabled)
    {
        if (_dualShiftEnabled == enabled)
            return;
        _dualShiftEnabled = enabled;
        _logger.LogInformation("Dual shift enabled: {Enabled}", enabled);
        DualShiftConfigChanged?.Invoke(this, EventArgs.Empty);
    }

    public void UpdateCaptureLinkedToCheckin(bool linked)

    {

        if (_captureLinkedToCheckin == linked)

            return;



        _captureLinkedToCheckin = linked;

        _logger.LogInformation("Capture mode updated: linkedToCheckin={Linked}", linked);



        if (linked)

        {

            lock (_lock)

            {

                if (string.IsNullOrEmpty(_openSessionId))

                    StopWorkCapture();

            }

        }

    }



    public void ApplyAutoCaptureFromPolicy(Policy? policy)

    {

        if (_captureLinkedToCheckin)

            return;



        var recordingEnabled = policy?.GetRecordingConfig()?.Enabled == true;

        var screenshotEnabled = policy?.GetScreenshotConfig()?.Enabled == true;



        if (recordingEnabled || screenshotEnabled)

        {

            StartWorkCapture();

            _logger.LogInformation("Auto capture enabled from policy (recording={Recording}, screenshot={Screenshot})",

                recordingEnabled, screenshotEnabled);

        }

        else

        {

            StopWorkCapture();

            _logger.LogInformation("Auto capture disabled: recording and screenshot are off in policy");

        }

    }



    public Task<bool> CheckInAsync(CancellationToken ct = default)
        => CheckInAsync(shift: null, ct);

    public async Task<bool> CheckInAsync(string? shift, CancellationToken ct = default)
    {
        LastCheckInError = null;

        var snapshot = _authTokenProvider.GetSnapshot();
        if (!snapshot.IsApproved || string.IsNullOrEmpty(snapshot.Token))
        {
            _logger.LogWarning("Check-in rejected: device not approved or missing token");
            LastCheckInError = "设备未授权或未登录";
            return false;
        }

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/checkin");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
        if (!string.IsNullOrWhiteSpace(shift))
        {
            var payload = JsonSerializer.Serialize(new { shift });
            request.Content = new StringContent(payload, Encoding.UTF8, "application/json");
        }

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            LastCheckInError = NormalizeCheckInErrorMessage(ParseApiErrorMessage(body));
            _logger.LogWarning("Check-in failed: {Status} {Body}", response.StatusCode, body);
            return false;
        }

        var sessionId = ParseSessionId(body);
        lock (_lock) { _openSessionId = sessionId; }

        if (_captureLinkedToCheckin)
            StartWorkCapture();

        _logger.LogInformation("Check-in OK, session={SessionId}, shift={Shift}, captureLinked={Linked}",
            sessionId, shift ?? "(default)", _captureLinkedToCheckin);
        return true;
    }

    private static string? ParseApiErrorMessage(string? body)
    {
        if (string.IsNullOrWhiteSpace(body))
            return null;
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("message", out var msg) &&
                msg.ValueKind == JsonValueKind.String)
            {
                var text = msg.GetString();
                return string.IsNullOrWhiteSpace(text) ? null : text.Trim();
            }
        }
        catch
        {
            // ignore parse errors
        }
        return null;
    }

    /// <summary>Map server shift-completed errors to a clearer employee-facing hint.</summary>
    private static string NormalizeCheckInErrorMessage(string? serverMessage)
    {
        if (string.IsNullOrWhiteSpace(serverMessage))
            return "上班失败，请确认已登录且网络正常";

        if (serverMessage.Contains("已打过卡", StringComparison.Ordinal)
            || serverMessage.Contains("无法重复上班", StringComparison.Ordinal)
            || serverMessage.Contains("already completed", StringComparison.OrdinalIgnoreCase))
        {
            return "今天该班次已下班，请明天再上班";
        }

        return serverMessage;
    }



    public async Task<bool> CheckOutAsync(CancellationToken ct = default)

    {

        var snapshot = _authTokenProvider.GetSnapshot();

        if (string.IsNullOrEmpty(snapshot.Token))

            return false;



        string? sessionId;

        lock (_lock) { sessionId = _openSessionId; }



        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/checkout");

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        if (!string.IsNullOrEmpty(sessionId))

        {

            var payload = JsonSerializer.Serialize(new { sessionId });

            request.Content = new StringContent(payload, Encoding.UTF8, "application/json");

        }



        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);

        var body = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)

        {

            _logger.LogWarning("Check-out failed: {Status} {Body}", response.StatusCode, body);

            return false;

        }



        lock (_lock) { _openSessionId = null; }



        if (_captureLinkedToCheckin)

            StopWorkCapture();



        _logger.LogInformation("Check-out OK");

        return true;

    }



    /// <summary>
    /// 启动时从服务端恢复未关闭的上班会话（崩溃/重启后续录）。
    /// </summary>
    public Task TryRestoreOpenSessionAsync(CancellationToken ct = default)
        => SyncOpenSessionFromServerAsync(ct, notifyTelegramCheckIn: false);

    /// <summary>
    /// 从服务端同步 open 会话与 capture 设置；不依赖「打卡联动录屏」也会更新托盘上班状态。
    /// </summary>
    public async Task<bool> SyncOpenSessionFromServerAsync(CancellationToken ct = default, bool notifyTelegramCheckIn = true)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return false;

        using var request = new HttpRequestMessage(HttpMethod.Get, $"{GetServerUrl()}/api/v1/agent/session");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        if (!response.IsSuccessStatusCode)
            return false;

        var body = await response.Content.ReadAsStringAsync(ct);
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return false;

            if (data.TryGetProperty("captureLinkedToCheckin", out var linkedProp) &&
                (linkedProp.ValueKind == JsonValueKind.True || linkedProp.ValueKind == JsonValueKind.False))
            {
                UpdateCaptureLinkedToCheckin(linkedProp.GetBoolean());
            }

            if (data.TryGetProperty("dualShiftEnabled", out var dualProp) &&
                (dualProp.ValueKind == JsonValueKind.True || dualProp.ValueKind == JsonValueKind.False))
            {
                UpdateDualShiftEnabled(dualProp.GetBoolean());
            }

            var open = data.TryGetProperty("workSessionOpen", out var wso) && wso.GetBoolean();
            string? sessionId = null;
            if (data.TryGetProperty("workSessionId", out var wsid))
                sessionId = wsid.GetString();

            var source = data.TryGetProperty("workSessionSource", out var srcProp)
                ? srcProp.GetString()
                : null;

            return ApplyServerSessionState(open, sessionId, source, notifyTelegramCheckIn);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to sync open work session from server");
            return false;
        }
    }



    public Task SyncCaptureSettingsAsync(CancellationToken ct = default)
        => SyncOpenSessionFromServerAsync(ct, notifyTelegramCheckIn: false);



    public void HandleTelegramCheckInNotify(string sessionId)
    {
        if (string.IsNullOrWhiteSpace(sessionId))
            return;

        ApplyServerSessionState(open: true, sessionId, source: "telegram", notifyTelegramCheckIn: true);
    }

    public void HandleTelegramCheckOutNotify(string? sessionId)
    {
        var checkoutNotified = TryNotifyTelegramCheckOut(sessionId);
        StopExternalWorkSession(sessionId);

        if (checkoutNotified)
        {
            SessionSyncChanged?.Invoke(this, new WorkSessionSyncEventArgs
            {
                TelegramCheckOutNotified = true,
            });
        }

        ScheduleSessionSyncFromServer();
    }

    /// <summary>服务端推送的上下班状态同步（不依赖录屏联动）。</summary>
    public void HandleWorkSessionStateSync(bool open, string? sessionId, string? source)
    {
        ApplyServerSessionState(open, sessionId, source, notifyTelegramCheckIn: false);
        ScheduleSessionSyncFromServer();
    }

    /// <summary>后台拉取服务端 open 会话，用于 WS 重连或 sessionId 不一致时以服务端为准。</summary>
    public void ScheduleSessionSyncFromServer()
    {
        _ = Task.Run(async () =>
        {
            try
            {
                await SyncOpenSessionFromServerAsync(notifyTelegramCheckIn: false).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Background work session sync failed");
            }
        });
    }



    private bool ApplyServerSessionState(bool open, string? sessionId, string? source, bool notifyTelegramCheckIn)
    {
        var wasOpen = HasOpenSession;
        string? previousSessionId;
        lock (_lock)
        {
            previousSessionId = _openSessionId;
        }

        var sessionChanged = false;
        var telegramNotified = false;

        if (open && !string.IsNullOrWhiteSpace(sessionId))
        {
            var isNewSession = !wasOpen || !string.Equals(previousSessionId, sessionId, StringComparison.Ordinal);
            lock (_lock)
            {
                sessionChanged = _openSessionId != sessionId;
                _openSessionId = sessionId;
            }

            if (_captureLinkedToCheckin && isNewSession && !_screenshot.WorkSessionActive)
            {
                StartWorkCapture();
                _logger.LogInformation("Work session synced from server, capture started (session={SessionId})", sessionId);
            }
            else if (isNewSession)
            {
                _logger.LogInformation("Work session synced from server (session={SessionId}, source={Source})", sessionId, source);
            }

            if (notifyTelegramCheckIn && isNewSession)
                telegramNotified = TryNotifyTelegramCheckIn(sessionId, source);
        }
        else
        {
            lock (_lock)
            {
                sessionChanged = !string.IsNullOrEmpty(_openSessionId);
                _openSessionId = null;
            }

            if (_captureLinkedToCheckin && wasOpen)
                StopWorkCapture();
        }

        if (sessionChanged || telegramNotified)
        {
            SessionSyncChanged?.Invoke(this, new WorkSessionSyncEventArgs
            {
                SessionStateChanged = sessionChanged,
                TelegramCheckInNotified = telegramNotified
            });
        }

        return sessionChanged;
    }



    private bool TryNotifyTelegramCheckIn(string sessionId, string? source)
    {
        if (!string.Equals(source, "telegram", StringComparison.OrdinalIgnoreCase))
            return false;

        lock (_lock)
        {
            if (string.Equals(_lastTelegramNotifiedSessionId, sessionId, StringComparison.Ordinal))
                return false;
            _lastTelegramNotifiedSessionId = sessionId;
        }

        return true;
    }

    private bool TryNotifyTelegramCheckOut(string? sessionId)
    {
        var key = string.IsNullOrWhiteSpace(sessionId) ? "*" : sessionId.Trim();
        lock (_lock)
        {
            if (string.Equals(_lastTelegramCheckoutNotifiedSessionId, key, StringComparison.Ordinal))
                return false;
            _lastTelegramCheckoutNotifiedSessionId = key;
        }

        return true;
    }



	public void StartExternalWorkSession(string sessionId, string source = "telegram")
	{
        ApplyServerSessionState(open: true, sessionId, source, notifyTelegramCheckIn: true);
	}



	public void StopExternalWorkSession(string? sessionId = null)
	{
        string? localId;
        lock (_lock)
        {
            localId = _openSessionId;
        }

        if (!string.IsNullOrEmpty(sessionId) && !string.IsNullOrEmpty(localId) &&
            !string.Equals(localId, sessionId, StringComparison.Ordinal))
        {
            _logger.LogWarning(
                "Checkout session mismatch local={LocalSession} remote={RemoteSession}, syncing from server",
                localId, sessionId);
            ScheduleSessionSyncFromServer();
            return;
        }

        ApplyServerSessionState(open: false, sessionId: null, source: null, notifyTelegramCheckIn: false);
	}



	private void StartWorkCapture()

    {

        _screenshot.StartCapture();

        _ = _recorderLifecycle.RequestAsync(
            RecorderCommand.StartWorkSession,
            new RecorderRequestContext { Reason = "WorkSession checkin" });

    }



    private void StopWorkCapture()

    {

        _ = _recorderLifecycle.RequestAsync(
            RecorderCommand.StopWorkSession,
            new RecorderRequestContext { Reason = "WorkSession checkout" });

        _screenshot.StopCapture();

    }



    private string GetServerUrl() => _serverUrlResolver?.Invoke() ?? "http://localhost:8080";



    private Func<string>? _serverUrlResolver;

    public void SetServerUrlResolver(Func<string> resolver) => _serverUrlResolver = resolver;



    private static string? ParseSessionId(string json)

    {

        try

        {

            using var doc = JsonDocument.Parse(json);

            if (doc.RootElement.TryGetProperty("data", out var data)

                && data.TryGetProperty("sessionId", out var sid))

            {

                return sid.GetString();

            }

        }

        catch { /* ignore */ }



        return null;

    }

    public async Task<(bool Success, string Message)> ActivityBackAsync(string sessionId, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(sessionId))
            return (false, "活动会话无效");

        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return (false, "请先登录员工账号");

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/activity/back");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
        var payload = JsonSerializer.Serialize(new { sessionId });
        request.Content = new StringContent(payload, Encoding.UTF8, "application/json");

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        try
        {
            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            var message = root.TryGetProperty("message", out var msgProp)
                ? msgProp.GetString() ?? string.Empty
                : string.Empty;
            if (!response.IsSuccessStatusCode)
            {
                if (string.IsNullOrWhiteSpace(message) && root.TryGetProperty("data", out var errData) &&
                    errData.ValueKind == JsonValueKind.String)
                {
                    message = errData.GetString() ?? string.Empty;
                }
                return (false, string.IsNullOrWhiteSpace(message) ? "回座失败" : message);
            }

            if (root.TryGetProperty("data", out var data))
            {
                if (data.TryGetProperty("messageText", out var textProp))
                {
                    var text = DurationFormatter.NormalizeMessageDurations(textProp.GetString());
                    if (!string.IsNullOrWhiteSpace(text))
                        return (true, text);
                }
                if (data.TryGetProperty("activityName", out var actProp))
                {
                    var act = actProp.GetString();
                    if (!string.IsNullOrWhiteSpace(act))
                        return (true, $"「{act}」已结束");
                }
            }

            return (true, string.IsNullOrWhiteSpace(message) ? "回座完成" : DurationFormatter.NormalizeMessageDurations(message));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to parse activity back response");
            return response.IsSuccessStatusCode
                ? (true, "回座完成")
                : (false, "回座失败");
        }
    }

}



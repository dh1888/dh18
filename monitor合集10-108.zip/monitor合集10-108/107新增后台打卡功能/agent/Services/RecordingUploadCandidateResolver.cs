using System.Diagnostics;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

internal enum RecordingUploadScanSource
{
    Sqlite,
    FilesystemDateDir,
    FilesystemFull,
}

internal sealed class RecordingUploadScanResult
{
    public required List<RecordingUploadCandidate> Files { get; init; }
    public RecordingUploadScanSource Source { get; init; }
    public double ScanMs { get; init; }
    public int ParseCacheEntries { get; init; }
}

/// <summary>
/// 文件系统扫描超时后抛出。区别于 OperationCanceledException（代表服务真正在停止），
/// 这个异常代表"这次扫描没在预算时间内做完，但任务本身还应该重试"，
/// 会被 TaskSchedulerService.ProcessTasksAsync 现有的通用 catch(Exception) 分支接住，
/// 走既有的 RetryCount++ / 指数退避重新调度逻辑——而不是被当成"未找到文件"直接标记 completed。
/// </summary>
internal sealed class RecordingScanTimeoutException : Exception
{
    public RecordingScanTimeoutException(string message) : base(message)
    {
    }
}

/// <summary>
/// Resolves local recording files for upload tasks: SQLite index first, filesystem scan as fallback.
/// </summary>
internal static class RecordingUploadCandidateResolver
{
    private const int DefaultLookbackDays = 30;
    private const int MaxLookbackDays = 90;

    /// <summary>
    /// 文件系统兜底扫描的硬超时。必须明显小于外部健康检查/看门狗判定"进程无响应"的阈值，
    /// 否则超时保护还没触发，进程就已经被外部机制杀掉重启了——等于白加。
    /// </summary>
    private static readonly TimeSpan FilesystemScanTimeout = TimeSpan.FromSeconds(45);

    public static async Task<RecordingUploadScanResult> ResolveAsync(
        string recordingsPath,
        DateTime? startTime,
        DateTime? endTime,
        int sliceSeconds,
        IServiceScopeFactory scopeFactory,
        ILogger logger,
        CancellationToken ct = default)
    {
        var scanStarted = Stopwatch.GetTimestamp();
        var sliceDuration = TimeSpan.FromSeconds(sliceSeconds);
        var sliceCache = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        var (queryStart, queryEnd) = ResolveSqliteQueryRange(startTime, endTime);
        var sqliteCandidates = await TryResolveFromSqliteAsync(
            scopeFactory,
            queryStart,
            queryEnd,
            startTime,
            endTime,
            sliceDuration,
            logger,
            ct);

        if (sqliteCandidates.Count > 0)
        {
            return new RecordingUploadScanResult
            {
                Files = sqliteCandidates,
                Source = RecordingUploadScanSource.Sqlite,
                ScanMs = Stopwatch.GetElapsedTime(scanStarted).TotalMilliseconds,
                ParseCacheEntries = 0,
            };
        }

        logger.LogInformation(
            "Upload scan: SQLite returned no valid candidates for [{Start} .. {End}] UTC; falling back to filesystem scan",
            FormatUtc(startTime),
            FormatUtc(endTime));

        var (filePaths, source) = await ScanFilesystemWithTimeoutAsync(
            recordingsPath, startTime, endTime, logger, ct);

        var filesystemCandidates = await BuildCandidatesFromPathsAsync(
            scopeFactory,
            filePaths,
            sliceSeconds,
            sliceDuration,
            sliceCache,
            startTime,
            endTime,
            ct);

        return new RecordingUploadScanResult
        {
            Files = filesystemCandidates,
            Source = source,
            ScanMs = Stopwatch.GetElapsedTime(scanStarted).TotalMilliseconds,
            ParseCacheEntries = sliceCache.Count,
        };
    }

    /// <summary>
    /// 在独立线程上执行文件系统枚举，并施加硬超时。
    /// 枚举本身（RecordingScanHelper）内部已经是流式 + 逐项检查取消令牌，
    /// 所以这里的超时能在"文件遍历过程中"随时打断，而不必等整个目录扫完。
    ///
    /// 残留限制：如果枚举卡在单次系统调用内部（例如网络盘无响应），
    /// 取消令牌要等那次调用返回才生效，Task.Run 里的后台线程届时才会真正退出——
    /// 期间这次 await 会一直等到超时触发、异常被抛出为止，不会无限期挂起调用方，
    /// 但底层线程本身可能继续占用到那次系统调用超时/返回为止。这是可接受的折中，
    /// 并在超时日志中如实说明，方便后续排查是否命中了这种更底层的卡死。
    /// </summary>
    private static async Task<(IReadOnlyList<string> Files, RecordingUploadScanSource Source)> ScanFilesystemWithTimeoutAsync(
        string recordingsPath,
        DateTime? startTime,
        DateTime? endTime,
        ILogger logger,
        CancellationToken ct)
    {
        using var timeoutCts = new CancellationTokenSource(FilesystemScanTimeout);
        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(ct, timeoutCts.Token);

        try
        {
            if (startTime.HasValue || endTime.HasValue)
            {
                var (files, usedFallback) = await Task.Run(
                    () => RecordingScanHelper.EnumerateMp4Files(recordingsPath, startTime, endTime, logger, linkedCts.Token),
                    linkedCts.Token);

                var source = usedFallback
                    ? RecordingUploadScanSource.FilesystemFull
                    : RecordingUploadScanSource.FilesystemDateDir;

                return (files, source);
            }
            else
            {
                var files = await Task.Run(
                    () => RecordingScanHelper.EnumerateAllMp4FilesRecursive(recordingsPath, logger, linkedCts.Token),
                    linkedCts.Token);

                return (files, RecordingUploadScanSource.FilesystemFull);
            }
        }
        catch (OperationCanceledException) when (timeoutCts.IsCancellationRequested && !ct.IsCancellationRequested)
        {
            // 走到这里说明是我们自己的超时触发的取消，不是外部服务停止（ct 未被取消）。
            // 不能在此吞掉异常返回空结果——那会被 UploadRecordingsTask 当成"未找到文件"
            // 直接标记任务 completed，导致这个时间窗口的录屏永久不再被扫描/上传。
            // 转换成专门异常抛出去，交给 ProcessTasksAsync 现有的失败重试/退避逻辑处理。
            logger.LogWarning(
                "Upload scan: filesystem scan timed out after {TimeoutSeconds:F0}s under {Root} for [{Start} .. {End}] UTC; " +
                "will be retried, not treated as \"no files found\"",
                FilesystemScanTimeout.TotalSeconds,
                recordingsPath,
                FormatUtc(startTime),
                FormatUtc(endTime));

            throw new RecordingScanTimeoutException(
                $"Filesystem upload scan timed out after {FilesystemScanTimeout.TotalSeconds:F0}s under {recordingsPath}");
        }
        // 若是外部 ct 被取消（服务真正停止），则以 OperationCanceledException 原样向上传播，
        // 让 ProcessTasksAsync 的 catch (OperationCanceledException) 分支按"整体停止"处理，
        // 不会被误判为超时重试。
    }

    private static async Task<List<RecordingUploadCandidate>> TryResolveFromSqliteAsync(
        IServiceScopeFactory scopeFactory,
        DateTime queryStart,
        DateTime queryEnd,
        DateTime? taskStart,
        DateTime? taskEnd,
        TimeSpan sliceDuration,
        ILogger logger,
        CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();
        var indexed = await repo.GetUnuploadedAsync(queryStart, queryEnd);

        logger.LogInformation(
            "Upload scan: SQLite index returned {Count} unuploaded row(s) for [{Start} .. {End}] UTC",
            indexed.Count,
            queryStart.ToString("yyyy-MM-dd HH:mm:ss"),
            queryEnd.ToString("yyyy-MM-dd HH:mm:ss"));

        var candidates = new List<RecordingUploadCandidate>();
        var missing = 0;
        var tooSmall = 0;
        var filteredOut = 0;

        foreach (var recording in indexed)
        {
            ct.ThrowIfCancellationRequested();

            if (string.IsNullOrWhiteSpace(recording.FilePath))
            {
                missing++;
                continue;
            }

            if (!File.Exists(recording.FilePath))
            {
                missing++;
                continue;
            }

            var fileInfo = new FileInfo(recording.FilePath);
            if (fileInfo.Length <= Constants.MinRecordingFileBytes)
            {
                tooSmall++;
                continue;
            }

            var recordStart = recording.StartTime.ToUniversalTime();
            var recordEnd = recording.EndTime.ToUniversalTime();
            RecordingTimeParser.FinalizeRecordingTimes(
                fileInfo.FullName,
                (int)sliceDuration.TotalSeconds,
                ref recordStart,
                ref recordEnd);

            if (taskStart.HasValue && recordEnd < taskStart.Value)
            {
                filteredOut++;
                continue;
            }

            if (taskEnd.HasValue && recordStart > taskEnd.Value)
            {
                filteredOut++;
                continue;
            }

            candidates.Add(new RecordingUploadCandidate
            {
                File = fileInfo,
                RecordStart = recordStart,
                RecordEnd = recordEnd,
                RecordingId = recording.Id,
            });
        }

        if (indexed.Count > 0)
        {
            logger.LogInformation(
                "Upload scan: SQLite validated {Valid} file(s) (missing={Missing}, tooSmall={TooSmall}, filtered={Filtered})",
                candidates.Count,
                missing,
                tooSmall,
                filteredOut);
        }

        return candidates;
    }

    private static async Task<List<RecordingUploadCandidate>> BuildCandidatesFromPathsAsync(
        IServiceScopeFactory scopeFactory,
        IReadOnlyList<string> filePaths,
        int sliceSeconds,
        TimeSpan sliceDuration,
        Dictionary<string, int> sliceCache,
        DateTime? startTime,
        DateTime? endTime,
        CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();

        var filesToUpload = new List<RecordingUploadCandidate>();

        foreach (var file in filePaths)
        {
            ct.ThrowIfCancellationRequested();

            var fileInfo = new FileInfo(file);
            DateTime recordStart;
            DateTime recordEnd;
            if (RecordingTimeParser.TryParse(file, sliceSeconds, out recordStart, out recordEnd, sliceCache))
            {
                // parsed
            }
            else
            {
                recordStart = fileInfo.LastWriteTimeUtc;
                recordEnd = recordStart.Add(sliceDuration);
            }

            RecordingTimeParser.FinalizeRecordingTimes(
                fileInfo.FullName,
                sliceSeconds,
                ref recordStart,
                ref recordEnd);

            if (startTime.HasValue && recordEnd < startTime.Value)
                continue;
            if (endTime.HasValue && recordStart > endTime.Value)
                continue;

            if (fileInfo.Length <= Constants.MinRecordingFileBytes)
                continue;

            var existing = await repo.GetByFilePathAsync(fileInfo.FullName);

            filesToUpload.Add(new RecordingUploadCandidate
            {
                File = fileInfo,
                RecordStart = recordStart,
                RecordEnd = recordEnd,
                RecordingId = existing?.Id,
            });
        }

        return filesToUpload;
    }

    private static (DateTime Start, DateTime End) ResolveSqliteQueryRange(DateTime? startTime, DateTime? endTime)
    {
        if (startTime.HasValue && endTime.HasValue)
            return (startTime.Value.ToUniversalTime(), endTime.Value.ToUniversalTime());

        if (startTime.HasValue)
            return (startTime.Value.ToUniversalTime(), DateTime.UtcNow);

        if (endTime.HasValue)
        {
            var endUtc = endTime.Value.ToUniversalTime();
            return (endUtc.AddDays(-MaxLookbackDays), endUtc);
        }

        var now = DateTime.UtcNow;
        return (now.AddDays(-DefaultLookbackDays), now);
    }

    private static string FormatUtc(DateTime? value) =>
        value?.ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss") ?? "any";
}
using System.Collections.Generic;
using System.Windows.Forms;
using EnterpriseAgent.Agent.UI;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// Unified agent desktop notification service with stackable bottom-right toasts.
/// </summary>
public sealed class AgentNotificationService
{
    private readonly ILogger<AgentNotificationService> _logger;
    private readonly object _lock = new();
    private readonly List<NotificationToastForm> _activeToasts = new();
    private SynchronizationContext? _uiSync;

    private const int ToastWidth = 400;
    private const int ToastMargin = 16;
    private const int ToastGap = 10;
    private const int MaxVisibleToasts = 3;
    private const int DefaultDurationSec = 60;
    public const int LocalDurationSec = 60;

    public static AgentNotificationService? Current { get; private set; }

    public AgentNotificationService(ILogger<AgentNotificationService> logger)
    {
        _logger = logger;
        Current = this;
    }

    public void BindUiThread(SynchronizationContext sync)
    {
        _uiSync = sync;
    }

    public void ShowLocal(string title, string message, string level = "info", int durationSec = LocalDurationSec)
        => Show(title, message, level, durationSec);

    public void Show(string title, string message, string level, int durationSec)
        => Show(title, message, level, durationSec, null, null, null);

    public void Show(
        string title,
        string message,
        string level,
        int durationSec,
        string? actionLabel,
        string? sessionId,
        Func<string, Task<(bool Success, string Message)>>? onActionAsync)
    {
        if (string.IsNullOrWhiteSpace(title) && string.IsNullOrWhiteSpace(message))
            return;

        message = DurationFormatter.NormalizeMessageDurations(message);

        if (durationSec <= 0)
            durationSec = DefaultDurationSec;
        if (durationSec < 30)
            durationSec = 30;
        if (durationSec > 600)
            durationSec = 600;

        void Dispatch() => ShowOnUiThread(title, message, level, durationSec, actionLabel, sessionId, onActionAsync);

        if (_uiSync != null)
        {
            _uiSync.Post(_ => Dispatch(), null);
            return;
        }

        if (Application.MessageLoop)
        {
            Dispatch();
            return;
        }

        _logger.LogWarning("Skipped agent notification because UI thread is not ready");
    }

    private void ShowOnUiThread(
        string title,
        string message,
        string level,
        int durationSec,
        string? actionLabel,
        string? sessionId,
        Func<string, Task<(bool Success, string Message)>>? onActionAsync)
    {
        Func<Task>? toastAction = null;
        NotificationToastForm? toastRef = null;
        if (!string.IsNullOrWhiteSpace(actionLabel) &&
            !string.IsNullOrWhiteSpace(sessionId) &&
            onActionAsync != null)
        {
            var sid = sessionId.Trim();
            toastAction = async () =>
            {
                var (success, resultMessage) = await onActionAsync(sid);
                if (success)
                    toastRef?.ForceClose();
                ShowLocal(success ? "回座成功" : "回座失败", resultMessage, success ? "success" : "warning", LocalDurationSec);
            };
        }

        lock (_lock)
        {
            while (_activeToasts.Count >= MaxVisibleToasts)
            {
                _activeToasts[0].ForceClose();
                _activeToasts.RemoveAt(0);
            }

            var toast = new NotificationToastForm(
                title,
                message,
                level,
                durationSec,
                toastAction != null ? actionLabel : null,
                toastAction);
            toastRef = toast;
            toast.FormClosed += (_, _) =>
            {
                lock (_lock)
                {
                    _activeToasts.Remove(toast);
                    RepositionToasts();
                }
            };
            _activeToasts.Add(toast);
            RepositionToasts();
            toast.Show();
        }

        _logger.LogInformation("Agent notification shown: {Title}", title);
    }

    private void RepositionToasts()
    {
        var screen = Screen.PrimaryScreen;
        if (screen == null)
            return;

        var workArea = screen.WorkingArea;
        var bottom = workArea.Bottom - ToastMargin;

        for (var i = _activeToasts.Count - 1; i >= 0; i--)
        {
            var toast = _activeToasts[i];
            bottom -= toast.Height;
            toast.SetStackPosition(workArea.Right - ToastWidth - ToastMargin, bottom);
            bottom -= ToastGap;
        }
    }
}

using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 按日期目录扫描录屏文件；无时间范围或日期目录不存在时回退全盘递归扫描。
/// 有时间范围时目录扫描会在任务日历范围两侧各扩 1 天，以覆盖跨天未切目录的片段；实际上传仍按解析出的录制时间过滤。
///
/// 所有文件枚举均使用 Directory.EnumerateFiles（流式）而非 Directory.GetFiles（一次性加载全部结果），
/// 并在每取到一个文件时检查取消令牌。这样上层给的超时令牌才能在合理粒度内（单次系统调用之间）真正打断扫描，
/// 而不是卡在"整个目录扫完才返回"的一次性调用里出不来。
///
/// 局限：如果某一次底层文件系统调用本身长时间不返回（例如断连的网络盘），
/// 取消令牌要等到那次调用返回后才能生效——这是 .NET 同步 I/O 无法被强制中断的固有限制，
/// 这里的改造能解决的是"文件多、遍历总耗时长"，解决不了"单次系统调用本身挂死"。
/// </summary>
internal static class RecordingScanHelper
{
    private const int DirectoryScanPaddingDays = 1;

    /// <summary>
    /// 枚举待检查的 mp4 路径。录屏目录结构为 recordings/yyyy-MM-dd/*.mp4（本地日历日）。
    /// 返回值中的 UsedFullFallback 用于让调用方准确标记 Source（日期目录命中 vs 全盘兜底），便于日志/指标区分。
    /// </summary>
    public static (IReadOnlyList<string> Files, bool UsedFullFallback) EnumerateMp4Files(
        string recordingsRoot,
        DateTime? startUtc,
        DateTime? endUtc,
        ILogger logger,
        CancellationToken ct)
    {
        if (!startUtc.HasValue && !endUtc.HasValue)
        {
            var all = EnumerateAllMp4FilesRecursive(recordingsRoot, logger, ct);
            return (all, true);
        }

        var dates = GetLocalDateRange(startUtc, endUtc, DirectoryScanPaddingDays).ToList();
        var files = new List<string>();
        var dirsFound = 0;

        foreach (var date in dates)
        {
            ct.ThrowIfCancellationRequested();

            var dateDir = Path.Combine(recordingsRoot, date);
            if (!Directory.Exists(dateDir))
                continue;

            dirsFound++;
            try
            {
                foreach (var file in Directory.EnumerateFiles(dateDir, "*.mp4", SearchOption.AllDirectories))
                {
                    ct.ThrowIfCancellationRequested();
                    files.Add(file);
                }
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Upload scan: failed reading date directory {DateDir}", dateDir);
            }
        }

        logger.LogInformation(
            "Upload scan: date-dir mode (±{PaddingDays}d), {DayCount} calendar day(s), {DirCount} dir(s) found, {FileCount} mp4 file(s)",
            DirectoryScanPaddingDays,
            dates.Count,
            dirsFound,
            files.Count);

        if (dirsFound == 0)
        {
            logger.LogWarning(
                "Upload scan: no date directories in range [{Start} .. {End}], falling back to full recursive search",
                dates.FirstOrDefault() ?? "-",
                dates.LastOrDefault() ?? "-");
            var fallback = EnumerateAllMp4FilesRecursive(recordingsRoot, logger, ct);
            return (fallback, true);
        }

        return (files, false);
    }

    /// <summary>
    /// 递归扫描 recordings 下全部 mp4（SQLite 兜底路径，确保不因目录名漏文件）。
    /// 使用流式枚举 + 逐项检查取消令牌，配合上层的超时保护。
    /// </summary>
    public static IReadOnlyList<string> EnumerateAllMp4FilesRecursive(
        string recordingsRoot,
        ILogger logger,
        CancellationToken ct)
    {
        logger.LogInformation("Upload scan: full recursive search under {Root}", recordingsRoot);

        var files = new List<string>();
        foreach (var file in Directory.EnumerateFiles(recordingsRoot, "*.mp4", SearchOption.AllDirectories))
        {
            ct.ThrowIfCancellationRequested();
            files.Add(file);
        }

        return files;
    }

    internal static IEnumerable<string> GetLocalDateRange(
        DateTime? startUtc,
        DateTime? endUtc,
        int directoryPaddingDays = 0)
    {
        var anchorStart = startUtc ?? endUtc ?? DateTime.UtcNow;
        var anchorEnd = endUtc ?? startUtc ?? DateTime.UtcNow;

        var startLocal = anchorStart.ToLocalTime().Date;
        var endLocal = anchorEnd.ToLocalTime().Date;
        if (endLocal < startLocal)
            (startLocal, endLocal) = (endLocal, startLocal);

        if (directoryPaddingDays > 0)
        {
            startLocal = startLocal.AddDays(-directoryPaddingDays);
            endLocal = endLocal.AddDays(directoryPaddingDays);
        }

        for (var day = startLocal; day <= endLocal; day = day.AddDays(1))
            yield return day.ToString("yyyy-MM-dd");
    }
}
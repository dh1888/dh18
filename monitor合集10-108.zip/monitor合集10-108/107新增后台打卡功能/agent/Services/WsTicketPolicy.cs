using System.Text.Json;
using EnterpriseAgent.Agent.Models;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// Resolves whether WebSocket handshakes must use a short-lived ticket (aligned with backend WS_TICKET_REQUIRED).
/// Priority: env override → deployment.json → server /meta/capabilities → HTTPS heuristic.
/// </summary>
public sealed class WsTicketPolicy
{
    private readonly AgentConfig _config;
    private readonly IHttpClientFactory _httpFactory;
    private readonly ILogger<WsTicketPolicy> _logger;

    private bool? _cachedRequired;
    private DateTime _cacheExpiresAt = DateTime.MinValue;
    private readonly SemaphoreSlim _resolveLock = new(1, 1);

    public WsTicketPolicy(
        AgentConfig config,
        IHttpClientFactory httpFactory,
        ILogger<WsTicketPolicy> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _httpFactory = httpFactory ?? throw new ArgumentNullException(nameof(httpFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<bool> IsRequiredAsync(CancellationToken ct = default)
    {
        if (TryGetEnvOverride(out var envValue))
            return envValue;

        if (TryGetDeploymentOverride(out var deploymentValue))
            return deploymentValue;

        if (_cachedRequired.HasValue && DateTime.UtcNow < _cacheExpiresAt)
            return _cachedRequired.Value;

        await _resolveLock.WaitAsync(ct);
        try
        {
            if (_cachedRequired.HasValue && DateTime.UtcNow < _cacheExpiresAt)
                return _cachedRequired.Value;

            var fromServer = await FetchFromServerAsync(ct);
            if (fromServer.HasValue)
            {
                _cachedRequired = fromServer.Value;
                _cacheExpiresAt = DateTime.UtcNow.AddMinutes(5);
                _logger.LogInformation("Server WS ticket policy: required={Required}", fromServer.Value);
                return fromServer.Value;
            }

            var fallback = InferFromTransport();
            _cachedRequired = fallback;
            _cacheExpiresAt = DateTime.UtcNow.AddMinutes(1);
            _logger.LogWarning(
                "Could not fetch WS ticket policy from server, using transport heuristic: required={Required}",
                fallback);
            return fallback;
        }
        finally
        {
            _resolveLock.Release();
        }
    }

    public void InvalidateCache()
    {
        _cachedRequired = null;
        _cacheExpiresAt = DateTime.MinValue;
    }

    private static bool TryGetEnvOverride(out bool required)
    {
        var raw = Environment.GetEnvironmentVariable("WS_TICKET_REQUIRED");
        if (string.IsNullOrWhiteSpace(raw))
        {
            required = false;
            return false;
        }

        required = string.Equals(raw, "true", StringComparison.OrdinalIgnoreCase)
                   || string.Equals(raw, "1", StringComparison.Ordinal);
        return true;
    }

    private static bool TryGetDeploymentOverride(out bool required)
    {
        var bundle = DeploymentConfigLoader.TryLoad();
        if (bundle?.WsTicketRequired is bool value)
        {
            required = value;
            return true;
        }

        required = false;
        return false;
    }

    private async Task<bool?> FetchFromServerAsync(CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(_config.ServerUrl))
            return null;

        try
        {
            using var client = _httpFactory.CreateClient("AgentClient");
            var url = $"{_config.ServerUrl.TrimEnd('/')}/api/v1/meta/capabilities";
            using var response = await client.GetAsync(url, ct);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogDebug("WS capabilities request failed: {StatusCode}", response.StatusCode);
                return null;
            }

            var body = await response.Content.ReadAsStringAsync(ct);
            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            var data = root.TryGetProperty("data", out var d) ? d : root;
            if (data.TryGetProperty("wsTicketRequired", out var flag))
            {
                return flag.GetBoolean();
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "WS capabilities fetch failed");
        }

        return null;
    }

    private bool InferFromTransport()
    {
        if (_config.AllowInsecureTransport)
            return false;

        if (!Uri.TryCreate(_config.ServerUrl, UriKind.Absolute, out var uri))
            return false;

        if (!string.Equals(uri.Scheme, "https", StringComparison.OrdinalIgnoreCase))
            return false;

        var host = uri.Host;
        return !host.Equals("localhost", StringComparison.OrdinalIgnoreCase)
               && !host.Equals("127.0.0.1", StringComparison.OrdinalIgnoreCase);
    }
}

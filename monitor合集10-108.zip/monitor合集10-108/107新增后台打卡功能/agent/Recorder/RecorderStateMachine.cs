namespace EnterpriseAgent.Agent.Recorder;

public static class RecorderStateMachine
{
    public static RecorderState Derive(
        bool workSessionActive,
        bool recordingEnabled,
        bool unifiedRemoteActive,
        bool remoteOnly,
        bool standaloneRemoteActive)
    {
        _ = unifiedRemoteActive;
        _ = remoteOnly;

        if (standaloneRemoteActive)
        {
            if (workSessionActive && recordingEnabled)
                return RecorderState.RecordingAndRemote;
            return RecorderState.StandaloneRemote;
        }

        if (workSessionActive && recordingEnabled)
            return RecorderState.Recording;

        return RecorderState.Idle;
    }

    public static RecorderCommand ResolveRecoverCommand(RecorderState state) =>
        state is RecorderState.StandaloneRemote or RecorderState.RecordingAndRemote
            ? RecorderCommand.ReconnectRemote
            : RecorderCommand.RecoverCapture;

    public static bool ShouldQueuePolicyChange(RecorderState state) =>
        state is RecorderState.RecordingAndRemote
            or RecorderState.StandaloneRemote
            or RecorderState.Transitioning;

    public static bool AllowsFullEngineRestart(RecorderState state) =>
        state is RecorderState.Idle or RecorderState.Recording;
}

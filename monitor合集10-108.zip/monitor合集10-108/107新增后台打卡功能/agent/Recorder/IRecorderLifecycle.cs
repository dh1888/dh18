using EnterpriseAgent.Agent.RemoteView;

namespace EnterpriseAgent.Agent.Recorder;

public enum RecorderState
{
    Idle,
    Recording,
    RecordingAndRemote,
    StandaloneRemote,
    Transitioning,
}

public enum RecorderCommand
{
    StartWorkSession,
    StopWorkSession,
    EnterRemoteView,
    ExitRemoteView,
    ReconnectRemote,
    RecoverCapture,
    ApplyPolicyChange,
    RetryEncoder,
    EmergencyStop,
    SystemResume,
    RecoverSharedBridge,
    RecoverRecording,
}

public sealed class RecorderRequestContext
{
    public RemoteViewStartParams? RemoteView { get; init; }
    public string Reason { get; init; } = "";
    public bool PolicyRecordingEnabled { get; init; } = true;
}

public sealed class RecorderResult
{
    public bool Success { get; init; }
    public RecorderState State { get; init; }
    public string? Message { get; init; }

    public static RecorderResult Ok(RecorderState state, string? message = null) =>
        new() { Success = true, State = state, Message = message };

    public static RecorderResult Skipped(RecorderState state, string message) =>
        new() { Success = true, State = state, Message = message };

    public static RecorderResult Failed(RecorderState state, string message) =>
        new() { Success = false, State = state, Message = message };
}

/// <summary>
/// Recorder 生命周期唯一对外接口。所有 Start/Stop/Restart/Remote 变更经此入口。
/// </summary>
public interface IRecorderLifecycle
{
    RecorderState State { get; }
    bool IsRemoteActive { get; }

    RecordingHealthSnapshot GetHealthSnapshot();

    Task<RecorderResult> RequestAsync(
        RecorderCommand command,
        RecorderRequestContext? context = null,
        CancellationToken cancellationToken = default);
}

/// <summary>
/// 供 SelfHealing / Health 使用的健康快照。
/// </summary>
public sealed class RecordingHealthSnapshot
{
    public bool RecordingEnabled { get; init; }
    public bool ShouldBeRecording { get; init; }
    public bool ProcessAlive { get; init; }
    public bool IsHealthy { get; init; }
    public bool RemoteViewActive { get; init; }
    public bool EncoderAlive { get; init; }
    public bool FileRecent { get; init; }
    public bool FileGrowing { get; init; }
    public double StallSeconds { get; init; }
    public double EncoderHeartbeatAgeSeconds { get; init; }
    public string CurrentEncoder { get; init; } = "";
    public RecorderState RecorderState { get; init; }
}

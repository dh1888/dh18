using System.Diagnostics;
using System.IO.Pipes;
using EnterpriseAgent.Agent.RemoteView;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Capture;

public readonly record struct PipeFrameWriteResult(bool RecordingWritten, bool RemoteWritten);

/// <summary>
/// Owns Windows named pipe servers for recording and remote encoder consumers.
/// Server writes raw BGR24 frames; FFmpeg consumers connect as clients and read.
/// </summary>
public sealed class SharedCapturePipeHost : IAsyncDisposable
{
    public const string RecordingPipeName = "agent_capture_rec";
    public const string RemotePipeName = "agent_capture_rv";

    private const int PipeCreateMaxAttempts = 8;
    private static readonly TimeSpan PipeCreateRetryBaseDelay = TimeSpan.FromMilliseconds(50);

    private readonly ILogger<SharedCapturePipeHost> _logger;
    private readonly object _gate = new();
    private readonly SemaphoreSlim _reconnectGate = new(1, 1);
    private readonly Dictionary<NamedPipeServerStream, int> _pipeIds = new();

    private NamedPipeServerStream? _recordingPipe;
    private NamedPipeServerStream? _remotePipe;
    private TaskCompletionSource _recordingConnectedTcs = CreateConnectionTcs();
    private TaskCompletionSource _remoteConnectedTcs = CreateConnectionTcs();
    private CancellationTokenSource? _listenCts;

    private int _width;
    private int _height;
    private int _fps;
    private int _frameBytes;
    private long _framesWritten;
    private int _nextPipeId;
    private bool _disposed;
    private bool _sessionActive;

    // [PipelineDiag] temporary: WriteAsync+FlushAsync per-frame timing (bridge → pipe consumers)
    private long _diagWriteSamples;
    private long _diagWriteTotalMs;
    private long _diagWriteMaxMs;
    private DateTime _diagWriteLogUtc = DateTime.MinValue;
    private long _diagRemoteSamples;
    private long _diagRemoteTotalMs;
    private long _diagRemoteMaxMs;
    private long _diagRemoteWriteTotalMs;
    private long _diagRemoteFlushTotalMs;
    private long _diagRecordingSamples;
    private long _diagRecordingTotalMs;
    private long _diagRecordingMaxMs;
    private long _diagRecordingWriteTotalMs;
    private long _diagRecordingFlushTotalMs;
    private int _diagRemoteSkipped;
    private int _diagRecordingSkipped;

    public SharedCapturePipeHost(ILogger<SharedCapturePipeHost> logger) => _logger = logger;

    public bool RecordingConnected => IsPipeLive(_recordingPipe);
    public bool RemoteConnected => IsPipeLive(_remotePipe);

    /// <summary>True when the remote pipe server exists (listening or connected). False after invalidate.</summary>
    public bool RemotePipeServerActive
    {
        get
        {
            lock (_gate)
                return _remotePipe != null;
        }
    }
    public long FramesWritten => Interlocked.Read(ref _framesWritten);
    public int FrameBytes => _frameBytes;
    public bool SessionActive => _sessionActive;

    public static string RecordingPipePath => $@"\\.\pipe\{RecordingPipeName}";
    public static string RemotePipePath => $@"\\.\pipe\{RemotePipeName}";

    public static string BuildRecordingInputArgs(int width, int height, int fps) =>
        $"-f rawvideo -pix_fmt bgr24 -video_size {width}x{height} -framerate {fps} -i \"{RecordingPipePath}\"";

    public static string BuildRemoteInputArgs(int width, int height, int fps, int threadQueueSize = 0)
    {
        var size = Math.Clamp(threadQueueSize, 0, 512);
        var queue = size > 0 ? $"-thread_queue_size {size} " : "";
        return $"{queue}-f rawvideo -pix_fmt bgr24 -video_size {width}x{height} -framerate {fps} -i \"{RemotePipePath}\"";
    }

    public async Task PrepareAsync(int width, int height, int fps, CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        await _reconnectGate.WaitAsync(cancellationToken);
        try
        {
            await StopSessionPipesCoreAsync(cancellationToken);

            _width = width;
            _height = height;
            _fps = fps;
            _frameBytes = width * height * 3;
            Interlocked.Exchange(ref _framesWritten, 0);
            ResetPipelineDiagWriteStats();
            _recordingConnectedTcs = CreateConnectionTcs();
            _remoteConnectedTcs = CreateConnectionTcs();

            _listenCts?.Dispose();
            _listenCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            _sessionActive = true;

            _recordingPipe = await CreateServerStreamWithRetryAsync(
                RecordingPipeName, CaptureConsumer.Recording, cancellationToken);
            _remotePipe = await CreateServerStreamWithRetryAsync(
                RemotePipeName, CaptureConsumer.RemoteView, cancellationToken);

            _logger.LogInformation(
                "Pipe Listening: recording={RecordingPipe}, remote={RemotePipe}, {Width}x{Height}@{Fps}, frameBytes={FrameBytes}",
                RecordingPipePath,
                RemotePipePath,
                width,
                height,
                fps,
                _frameBytes);

            _ = WaitForClientAsync(_recordingPipe, _recordingConnectedTcs, CaptureConsumer.Recording, _listenCts.Token);
            _ = WaitForClientAsync(_remotePipe, _remoteConnectedTcs, CaptureConsumer.RemoteView, _listenCts.Token);

            await Task.Yield();
        }
        finally
        {
            _reconnectGate.Release();
        }
    }

    public async Task WaitConsumersConnectedAsync(TimeSpan timeout, CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(timeout);

        try
        {
            await Task.WhenAll(_recordingConnectedTcs.Task, _remoteConnectedTcs.Task)
                .WaitAsync(timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException(
                $"Timed out waiting for SharedBridge consumers to connect (recording={RecordingConnected}, remote={RemoteConnected})");
        }

        if (!RecordingConnected || !RemoteConnected)
        {
            throw new InvalidOperationException(
                $"SharedBridge consumer pipes not live after connect wait (recording={RecordingConnected}, remote={RemoteConnected})");
        }
    }

    public async Task WaitConsumerConnectedAsync(
        CaptureConsumer consumer,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        var tcs = consumer == CaptureConsumer.Recording ? _recordingConnectedTcs : _remoteConnectedTcs;
        var label = consumer == CaptureConsumer.Recording ? "recording" : "remote";

        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(timeout);

        try
        {
            await tcs.Task.WaitAsync(timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException(
                $"Timed out waiting for SharedBridge {label} consumer to connect (recording={RecordingConnected}, remote={RemoteConnected})");
        }

        var live = consumer == CaptureConsumer.Recording ? RecordingConnected : RemoteConnected;
        if (!live)
        {
            throw new InvalidOperationException(
                $"SharedBridge {label} pipe not live after connect wait (recording={RecordingConnected}, remote={RemoteConnected})");
        }
    }

    public async Task ReconnectPipeAsync(
        CaptureConsumer consumer,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (!_sessionActive)
            throw new InvalidOperationException("Cannot reconnect pipe: SharedCapture session is not active");

        await _reconnectGate.WaitAsync(cancellationToken);
        try
        {
            LogPipeLifecycle("Recover", consumer, null, "ReconnectPipe begin");
            if (consumer == CaptureConsumer.Recording)
                await RecreateRecordingPipeAsync(cancellationToken);
            else
                await RecreateRemotePipeAsync(cancellationToken);

            var tcs = consumer == CaptureConsumer.Recording ? _recordingConnectedTcs : _remoteConnectedTcs;
            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeoutCts.CancelAfter(timeout);

            try
            {
                await tcs.Task.WaitAsync(timeoutCts.Token);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                throw new TimeoutException($"Timed out waiting for {consumer} pipe reconnect");
            }

            var live = consumer == CaptureConsumer.Recording ? RecordingConnected : RemoteConnected;
            if (!live)
                throw new InvalidOperationException($"{consumer} pipe reconnect completed but pipe is not live");

            LogPipeLifecycle("Recover", consumer, GetPipeRef(consumer), "ReconnectPipe complete");
        }
        finally
        {
            _reconnectGate.Release();
        }
    }

    /// <summary>
    /// Recreate the server pipe and start WaitForConnection without blocking on the client.
    /// Used for quality-switch: recreate → launch ffmpeg → client connects.
    /// </summary>
    public async Task RecreatePipeListeningAsync(
        CaptureConsumer consumer,
        CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (!_sessionActive)
            throw new InvalidOperationException("Cannot recreate pipe: SharedCapture session is not active");

        await _reconnectGate.WaitAsync(cancellationToken);
        try
        {
            LogPipeLifecycle("Recover", consumer, null, "Recreate listen begin");
            if (consumer == CaptureConsumer.Recording)
                await RecreateRecordingPipeAsync(cancellationToken);
            else
                await RecreateRemotePipeAsync(cancellationToken);
        }
        finally
        {
            _reconnectGate.Release();
        }
    }

    public async Task<PipeFrameWriteResult> WriteFrameAsync(ReadOnlyMemory<byte> frame, CancellationToken cancellationToken)
    {
        var remoteWritten = await WriteConsumerFrameAsync(CaptureConsumer.RemoteView, frame, cancellationToken);
        var recordingWritten = await WriteConsumerFrameAsync(CaptureConsumer.Recording, frame, cancellationToken);

        if (!recordingWritten && !remoteWritten)
            throw new IOException("SharedBridge frame write failed: no consumer pipes are live");

        return new PipeFrameWriteResult(recordingWritten, remoteWritten);
    }

    public async Task<bool> WriteConsumerFrameAsync(
        CaptureConsumer consumer,
        ReadOnlyMemory<byte> frame,
        CancellationToken cancellationToken)
    {
        var result = await WriteConsumerFrameAsync(consumer, frame, cancellationToken, writeTimeout: null);
        return result.Written;
    }

    public async Task<PipeConsumerWriteResult> WriteConsumerFrameAsync(
        CaptureConsumer consumer,
        ReadOnlyMemory<byte> frame,
        CancellationToken cancellationToken,
        TimeSpan? writeTimeout)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (frame.Length != _frameBytes)
            throw new InvalidOperationException($"Frame size mismatch: expected {_frameBytes}, got {frame.Length}");

        NamedPipeServerStream? pipe;
        lock (_gate)
        {
            pipe = consumer == CaptureConsumer.Recording ? _recordingPipe : _remotePipe;
        }

        if (pipe == null || !IsPipeLive(pipe))
        {
            if (consumer == CaptureConsumer.Recording)
                _diagRecordingSkipped++;
            else
                _diagRemoteSkipped++;
            return new PipeConsumerWriteResult(Written: false, TimedOut: false);
        }

        CancellationToken writeToken = cancellationToken;
        CancellationTokenSource? timeoutCts = null;
        if (writeTimeout is { } timeout && timeout > TimeSpan.Zero)
        {
            timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeoutCts.CancelAfter(timeout);
            writeToken = timeoutCts.Token;
        }

        long writeMs = 0;
        long flushMs = 0;
        try
        {
            var sw = Stopwatch.StartNew();
            await pipe.WriteAsync(frame, writeToken);
            writeMs = sw.ElapsedMilliseconds;
            sw.Restart();
            await pipe.FlushAsync(writeToken);
            flushMs = sw.ElapsedMilliseconds;
        }
        catch (OperationCanceledException) when (timeoutCts != null && timeoutCts.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
        {
            return new PipeConsumerWriteResult(Written: false, TimedOut: true);
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or ObjectDisposedException)
        {
            _logger.LogWarning(ex, "{Consumer} pipe write failed; marking pipe broken", consumer);
            await InvalidatePipeAsync(consumer, pipe, "write failed");
            return new PipeConsumerWriteResult(Written: false, TimedOut: false);
        }
        finally
        {
            timeoutCts?.Dispose();
        }

        var totalMs = writeMs + flushMs;
        if (consumer == CaptureConsumer.Recording)
        {
            RecordPipelineDiagWriteMs(
                remoteMs: 0,
                remoteWriteMs: 0,
                remoteFlushMs: 0,
                recordingMs: totalMs,
                recordingWriteMs: writeMs,
                recordingFlushMs: flushMs,
                remoteWritten: false,
                recordingWritten: true);
        }
        else
        {
            RecordPipelineDiagWriteMs(
                remoteMs: totalMs,
                remoteWriteMs: writeMs,
                remoteFlushMs: flushMs,
                recordingMs: 0,
                recordingWriteMs: 0,
                recordingFlushMs: 0,
                remoteWritten: true,
                recordingWritten: false);
        }

        Interlocked.Increment(ref _framesWritten);
        return new PipeConsumerWriteResult(Written: true, TimedOut: false);
    }

    /// <summary>[PipelineDiag] temporary — accumulate per-frame pipe write+flush duration.</summary>
    private void RecordPipelineDiagWriteMs(
        long remoteMs,
        long remoteWriteMs,
        long remoteFlushMs,
        long recordingMs,
        long recordingWriteMs,
        long recordingFlushMs,
        bool remoteWritten,
        bool recordingWritten)
    {
        var totalMs = (remoteWritten ? remoteMs : 0) + (recordingWritten ? recordingMs : 0);
        _diagWriteSamples++;
        _diagWriteTotalMs += totalMs;
        if (totalMs > _diagWriteMaxMs)
            _diagWriteMaxMs = totalMs;

        if (remoteWritten)
        {
            _diagRemoteSamples++;
            _diagRemoteTotalMs += remoteMs;
            _diagRemoteWriteTotalMs += remoteWriteMs;
            _diagRemoteFlushTotalMs += remoteFlushMs;
            if (remoteMs > _diagRemoteMaxMs)
                _diagRemoteMaxMs = remoteMs;
        }

        if (recordingWritten)
        {
            _diagRecordingSamples++;
            _diagRecordingTotalMs += recordingMs;
            _diagRecordingWriteTotalMs += recordingWriteMs;
            _diagRecordingFlushTotalMs += recordingFlushMs;
            if (recordingMs > _diagRecordingMaxMs)
                _diagRecordingMaxMs = recordingMs;
        }

        MaybeLogPipelineDiagWriteStats();
    }

    private void ResetPipelineDiagWriteStats()
    {
        _diagWriteSamples = 0;
        _diagWriteTotalMs = 0;
        _diagWriteMaxMs = 0;
        _diagWriteLogUtc = DateTime.UtcNow;
        _diagRemoteSamples = 0;
        _diagRemoteTotalMs = 0;
        _diagRemoteMaxMs = 0;
        _diagRemoteWriteTotalMs = 0;
        _diagRemoteFlushTotalMs = 0;
        _diagRecordingSamples = 0;
        _diagRecordingTotalMs = 0;
        _diagRecordingMaxMs = 0;
        _diagRecordingWriteTotalMs = 0;
        _diagRecordingFlushTotalMs = 0;
        _diagRemoteSkipped = 0;
        _diagRecordingSkipped = 0;
    }

    /// <summary>[PipelineDiag] temporary — log avg/max pipe write ms once per second.</summary>
    private void MaybeLogPipelineDiagWriteStats()
    {
        var now = DateTime.UtcNow;
        if (_diagWriteLogUtc != DateTime.MinValue && now - _diagWriteLogUtc < TimeSpan.FromSeconds(1))
            return;

        var samples = _diagWriteSamples;
        if (samples == 0)
        {
            _diagWriteLogUtc = now;
            return;
        }

        var totalMs = _diagWriteTotalMs;
        var maxMs = _diagWriteMaxMs;
        var remoteSamples = _diagRemoteSamples;
        var remoteTotalMs = _diagRemoteTotalMs;
        var remoteMaxMs = _diagRemoteMaxMs;
        var remoteWriteTotalMs = _diagRemoteWriteTotalMs;
        var remoteFlushTotalMs = _diagRemoteFlushTotalMs;
        var recordingSamples = _diagRecordingSamples;
        var recordingTotalMs = _diagRecordingTotalMs;
        var recordingMaxMs = _diagRecordingMaxMs;
        var recordingWriteTotalMs = _diagRecordingWriteTotalMs;
        var recordingFlushTotalMs = _diagRecordingFlushTotalMs;
        var remoteSkipped = _diagRemoteSkipped;
        var recordingSkipped = _diagRecordingSkipped;

        _diagWriteSamples = 0;
        _diagWriteTotalMs = 0;
        _diagWriteMaxMs = 0;
        _diagRemoteSamples = 0;
        _diagRemoteTotalMs = 0;
        _diagRemoteMaxMs = 0;
        _diagRemoteWriteTotalMs = 0;
        _diagRemoteFlushTotalMs = 0;
        _diagRecordingSamples = 0;
        _diagRecordingTotalMs = 0;
        _diagRecordingMaxMs = 0;
        _diagRecordingWriteTotalMs = 0;
        _diagRecordingFlushTotalMs = 0;
        _diagRemoteSkipped = 0;
        _diagRecordingSkipped = 0;
        _diagWriteLogUtc = now;

        var remoteAvgMs = remoteSamples > 0 ? remoteTotalMs / (double)remoteSamples : 0;
        var recordingAvgMs = recordingSamples > 0 ? recordingTotalMs / (double)recordingSamples : 0;
        var blockHint = remoteAvgMs >= recordingAvgMs * 1.5 && remoteAvgMs > 5
            ? "remote-pipe"
            : recordingAvgMs > remoteAvgMs * 1.5 && recordingAvgMs > 5
                ? "recording-pipe"
                : remoteAvgMs > 5 || recordingAvgMs > 5
                    ? "both-pipes"
                    : "none";

        _logger.LogInformation(
            "[PipelineDiag] PipeTiming frames={Frames} totalAvgMs={TotalAvg:F1} totalMaxMs={TotalMax} remoteAvgMs={RemoteAvg:F1} remoteMaxMs={RemoteMax} remoteWriteAvgMs={RemoteWriteAvg:F1} remoteFlushAvgMs={RemoteFlushAvg:F1} recAvgMs={RecAvg:F1} recMaxMs={RecMax} recWriteAvgMs={RecWriteAvg:F1} recFlushAvgMs={RecFlushAvg:F1} remoteSkip={RemoteSkip} recSkip={RecSkip} blockHint={Hint}",
            samples,
            totalMs / (double)samples,
            maxMs,
            remoteAvgMs,
            remoteMaxMs,
            remoteSamples > 0 ? remoteWriteTotalMs / (double)remoteSamples : 0,
            remoteSamples > 0 ? remoteFlushTotalMs / (double)remoteSamples : 0,
            recordingAvgMs,
            recordingMaxMs,
            recordingSamples > 0 ? recordingWriteTotalMs / (double)recordingSamples : 0,
            recordingSamples > 0 ? recordingFlushTotalMs / (double)recordingSamples : 0,
            remoteSkipped,
            recordingSkipped,
            blockHint);
    }

    public async Task StopAsync()
    {
        _listenCts?.Cancel();

        await _reconnectGate.WaitAsync(CancellationToken.None);
        try
        {
            await StopSessionPipesCoreAsync(CancellationToken.None);
            _sessionActive = false;
            _logger.LogInformation("Pipe Closed");
        }
        finally
        {
            _reconnectGate.Release();
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed) return;
        _disposed = true;
        await StopAsync();
        _listenCts?.Dispose();
        _listenCts = null;
        _reconnectGate.Dispose();
    }

    private async Task RecreateRecordingPipeAsync(CancellationToken cancellationToken)
    {
        NamedPipeServerStream? previous;
        lock (_gate)
        {
            previous = _recordingPipe;
            _recordingPipe = null;
            _recordingConnectedTcs = CreateConnectionTcs();
        }

        LogPipeLifecycle("Recreate", CaptureConsumer.Recording, previous, "dispose-before-create");
        await DisposePipeInternalAsync(previous, CaptureConsumer.Recording, cancellationToken);

        var created = await CreateServerStreamWithRetryAsync(
            RecordingPipeName, CaptureConsumer.Recording, cancellationToken);
        lock (_gate)
        {
            _recordingPipe = created;
        }

        await StartListeningAsync(_recordingPipe, _recordingConnectedTcs, CaptureConsumer.Recording, cancellationToken);
    }

    private async Task RecreateRemotePipeAsync(CancellationToken cancellationToken)
    {
        NamedPipeServerStream? previous;
        lock (_gate)
        {
            previous = _remotePipe;
            _remotePipe = null;
            _remoteConnectedTcs = CreateConnectionTcs();
        }

        LogPipeLifecycle("Recreate", CaptureConsumer.RemoteView, previous, "dispose-before-create");
        await DisposePipeInternalAsync(previous, CaptureConsumer.RemoteView, cancellationToken);

        var created = await CreateServerStreamWithRetryAsync(
            RemotePipeName, CaptureConsumer.RemoteView, cancellationToken);
        lock (_gate)
        {
            _remotePipe = created;
        }

        await StartListeningAsync(_remotePipe, _remoteConnectedTcs, CaptureConsumer.RemoteView, cancellationToken);
    }

    private Task StartListeningAsync(
        NamedPipeServerStream? pipe,
        TaskCompletionSource connectedTcs,
        CaptureConsumer consumer,
        CancellationToken cancellationToken)
    {
        if (_listenCts == null || _listenCts.IsCancellationRequested)
            throw new InvalidOperationException("Pipe host listener is not active");
        if (pipe == null)
            throw new InvalidOperationException($"{consumer} pipe was not recreated");

        LogPipeLifecycle("Listen", consumer, pipe, "WaitForConnection scheduled");
        _ = WaitForClientAsync(pipe, connectedTcs, consumer, _listenCts.Token);
        return Task.CompletedTask;
    }

    private async Task InvalidatePipeAsync(
        CaptureConsumer consumer,
        NamedPipeServerStream? expectedPipe,
        string reason)
    {
        await _reconnectGate.WaitAsync(CancellationToken.None);
        try
        {
            NamedPipeServerStream? pipe;
            lock (_gate)
            {
                if (consumer == CaptureConsumer.Recording)
                {
                    if (_recordingPipe != expectedPipe)
                        return;
                    pipe = _recordingPipe;
                    _recordingPipe = null;
                }
                else
                {
                    if (_remotePipe != expectedPipe)
                        return;
                    pipe = _remotePipe;
                    _remotePipe = null;
                }
            }

            if (pipe == null)
                return;

            LogPipeLifecycle("Invalidate", consumer, pipe, reason);
            await DisposePipeInternalAsync(pipe, consumer, CancellationToken.None);
        }
        finally
        {
            _reconnectGate.Release();
        }
    }

    private async Task WaitForClientAsync(
        NamedPipeServerStream pipe,
        TaskCompletionSource tcs,
        CaptureConsumer consumer,
        CancellationToken cancellationToken)
    {
        var label = consumer == CaptureConsumer.Recording ? "Recording" : "Remote";
        try
        {
            await pipe.WaitForConnectionAsync(cancellationToken);
            if (!IsPipeLive(pipe))
            {
                tcs.TrySetException(new InvalidOperationException($"{label} pipe disconnected immediately after connect"));
                return;
            }

            LogPipeLifecycle("Connect", consumer, pipe, $"{label} Connected");
            _logger.LogInformation("{Label} Connected", label);
            tcs.TrySetResult();
        }
        catch (OperationCanceledException)
        {
            tcs.TrySetCanceled(cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "{Label} pipe connection failed", label);
            tcs.TrySetException(ex);
        }
    }

    private static bool IsPipeLive(NamedPipeServerStream? pipe)
    {
        if (pipe == null)
            return false;

        try
        {
            return pipe.IsConnected;
        }
        catch (ObjectDisposedException)
        {
            return false;
        }
    }

    private static NamedPipeServerStream CreateServerStream(string pipeName) =>
        new(
            pipeName,
            PipeDirection.Out,
            maxNumberOfServerInstances: 1,
            PipeTransmissionMode.Byte,
            PipeOptions.Asynchronous);

    private async Task<NamedPipeServerStream> CreateServerStreamWithRetryAsync(
        string pipeName,
        CaptureConsumer consumer,
        CancellationToken cancellationToken)
    {
        Exception? lastError = null;
        for (var attempt = 1; attempt <= PipeCreateMaxAttempts; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            try
            {
                var pipe = CreateServerStream(pipeName);
                RegisterPipe(pipe);
                LogPipeLifecycle("Create", consumer, pipe, $"attempt={attempt} name={pipeName}");
                return pipe;
            }
            catch (Exception ex) when (attempt < PipeCreateMaxAttempts && IsPipeBusyError(ex))
            {
                lastError = ex;
                LogPipeLifecycle(
                    "CreateRetry",
                    consumer,
                    null,
                    $"attempt={attempt}/{PipeCreateMaxAttempts} name={pipeName} error={ex.Message}");
                await Task.Delay(PipeCreateRetryBaseDelay * attempt, cancellationToken);
            }
        }

        throw new IOException(
            $"Failed to create named pipe '{pipeName}' after {PipeCreateMaxAttempts} attempts",
            lastError);
    }

    private async Task StopSessionPipesCoreAsync(CancellationToken cancellationToken)
    {
        NamedPipeServerStream? recording;
        NamedPipeServerStream? remote;
        lock (_gate)
        {
            recording = _recordingPipe;
            remote = _remotePipe;
            _recordingPipe = null;
            _remotePipe = null;
        }

        LogPipeLifecycle("StopSession", CaptureConsumer.Recording, recording, "session pipes stopping");
        LogPipeLifecycle("StopSession", CaptureConsumer.RemoteView, remote, "session pipes stopping");
        await DisposePipeInternalAsync(recording, CaptureConsumer.Recording, cancellationToken);
        await DisposePipeInternalAsync(remote, CaptureConsumer.RemoteView, cancellationToken);
    }

    private async Task DisposePipeInternalAsync(
        NamedPipeServerStream? pipe,
        CaptureConsumer consumer,
        CancellationToken cancellationToken)
    {
        if (pipe == null)
            return;

        LogPipeLifecycle("Dispose", consumer, pipe, "begin");
        try
        {
            if (pipe.IsConnected)
                pipe.Disconnect();
        }
        catch (Exception ex)
        {
            LogPipeLifecycle("Dispose", consumer, pipe, $"disconnect ignored: {ex.Message}");
        }

        await pipe.DisposeAsync();
        UnregisterPipe(pipe);
        LogPipeLifecycle("Dispose", consumer, pipe, "complete");
        cancellationToken.ThrowIfCancellationRequested();
    }

    private void RegisterPipe(NamedPipeServerStream pipe)
    {
        lock (_gate)
        {
            _pipeIds[pipe] = Interlocked.Increment(ref _nextPipeId);
        }
    }

    private void UnregisterPipe(NamedPipeServerStream pipe)
    {
        lock (_gate)
        {
            _pipeIds.Remove(pipe);
        }
    }

    private int? GetPipeId(NamedPipeServerStream? pipe)
    {
        if (pipe == null)
            return null;

        lock (_gate)
            return _pipeIds.TryGetValue(pipe, out var id) ? id : null;
    }

    private NamedPipeServerStream? GetPipeRef(CaptureConsumer consumer)
    {
        lock (_gate)
            return consumer == CaptureConsumer.Recording ? _recordingPipe : _remotePipe;
    }

    private void LogPipeLifecycle(
        string action,
        CaptureConsumer consumer,
        NamedPipeServerStream? pipe,
        string detail)
    {
        var pipeId = pipe == null ? "-" : (GetPipeId(pipe)?.ToString() ?? pipe.GetHashCode().ToString("x8"));
        var state = action switch
        {
            "Connect" => "connected",
            "Invalidate" => "disconnected",
            "Create" or "CreateRetry" => "creating",
            "Listen" => "listening",
            "Recreate" or "Recover" => "recreating",
            "StopSession" => "stopped",
            _ => action.ToLowerInvariant(),
        };

        RemoteDiagLog.Event(
            _logger,
            "Pipe",
            null,
            $"{consumer}:{state}",
            $"pipeId={pipeId} {detail}");
    }

    private static bool IsPipeBusyError(Exception ex)
    {
        if (ex is IOException ioEx)
        {
            const int errorPipeBusy = unchecked((int)0x800700E7);
            if (ioEx.HResult == errorPipeBusy)
                return true;
        }

        var message = ex.Message;
        return message.Contains("PIPE_BUSY", StringComparison.OrdinalIgnoreCase)
            || message.Contains("所有的管道范例都在使用中", StringComparison.Ordinal)
            || message.Contains("pipe instance", StringComparison.OrdinalIgnoreCase);
    }

    private static TaskCompletionSource CreateConnectionTcs() =>
        new(TaskCreationOptions.RunContinuationsAsynchronously);
}

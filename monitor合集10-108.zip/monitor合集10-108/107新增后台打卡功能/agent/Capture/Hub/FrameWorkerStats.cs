namespace EnterpriseAgent.Agent.Capture.Hub;

public sealed class FrameWorkerStats
{
    private long _framesWritten;
    private long _framesSkipped;
    private long _writeTimeouts;
    private long _pipeUnavailable;
    private long _hubRingDrops;

    public long FramesWritten => Interlocked.Read(ref _framesWritten);
    public long FramesSkipped => Interlocked.Read(ref _framesSkipped);
    public long WriteTimeouts => Interlocked.Read(ref _writeTimeouts);
    public long PipeUnavailable => Interlocked.Read(ref _pipeUnavailable);
    public long HubRingDrops => Interlocked.Read(ref _hubRingDrops);

    public void RecordWritten() => Interlocked.Increment(ref _framesWritten);

    public void RecordSkipped(int count)
    {
        if (count > 0)
            Interlocked.Add(ref _framesSkipped, count);
    }

    public void RecordWriteTimeout() => Interlocked.Increment(ref _writeTimeouts);

    public void RecordPipeUnavailable() => Interlocked.Increment(ref _pipeUnavailable);

    public void RecordHubRingDrops(long delta)
    {
        if (delta > 0)
            Interlocked.Add(ref _hubRingDrops, delta);
    }
}

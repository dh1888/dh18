namespace EnterpriseAgent.Agent.Capture.Hub;

public enum FrameHubReadPolicy
{
    Sequential,
    LatestOnly,
}

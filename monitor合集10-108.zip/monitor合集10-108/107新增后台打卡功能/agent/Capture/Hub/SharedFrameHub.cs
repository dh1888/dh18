namespace EnterpriseAgent.Agent.Capture.Hub;

/// <summary>
/// Shared frame center: Capture publishes BGR24 frames; workers read with Sequential or LatestOnly policy.
/// </summary>
public sealed class SharedFrameHub : IDisposable
{
    private readonly object _gate = new();
    private byte[][] _buffers = Array.Empty<byte[]>();
    private int[] _refCounts = Array.Empty<int>();
    private long[] _slotSequence = Array.Empty<long>();
    private int _frameBytes;
    private int _slotCount;
    private long _generation;
    private int _latestSlot = -1;
    private int _writeCursor;
    private long _droppedOverwrites;
    private volatile bool _active;

    private readonly ManualResetEventSlim _frameSignal = new(false);

    public bool IsActive => _active;
    public long LatestGeneration => Interlocked.Read(ref _generation);
    public long PublishedFrames { get; private set; }
    public long DroppedOverwrites => Interlocked.Read(ref _droppedOverwrites);

    public void StartSession(int frameBytes, int slotCount)
    {
        if (frameBytes <= 0)
            throw new ArgumentOutOfRangeException(nameof(frameBytes));
        slotCount = Math.Clamp(slotCount, 2, 16);

        lock (_gate)
        {
            _frameBytes = frameBytes;
            _slotCount = slotCount;
            _buffers = new byte[slotCount][];
            _refCounts = new int[slotCount];
            _slotSequence = new long[slotCount];
            for (var i = 0; i < slotCount; i++)
            {
                _buffers[i] = new byte[frameBytes];
                _slotSequence[i] = 0;
            }

            _generation = 0;
            _latestSlot = -1;
            _writeCursor = 0;
            _droppedOverwrites = 0;
            PublishedFrames = 0;
            _active = true;
        }

        _frameSignal.Reset();
    }

    public void StopSession()
    {
        _active = false;
        _frameSignal.Set();
        lock (_gate)
        {
            _buffers = Array.Empty<byte[]>();
            _refCounts = Array.Empty<int>();
            _slotSequence = Array.Empty<long>();
            _latestSlot = -1;
            _frameBytes = 0;
            _slotCount = 0;
        }
    }

    public void Publish(ReadOnlySpan<byte> frame)
    {
        if (!_active)
            return;
        if (frame.Length != _frameBytes)
            throw new InvalidOperationException($"Frame size mismatch: expected {_frameBytes}, got {frame.Length}");

        lock (_gate)
        {
            var slot = AcquireWritableSlotLocked();
            frame.CopyTo(_buffers[slot]);
            _generation++;
            _slotSequence[slot] = _generation;
            _latestSlot = slot;
            PublishedFrames++;
        }

        _frameSignal.Set();
    }

    public bool WaitForFrame(ref long lastGeneration, TimeSpan timeout, CancellationToken cancellationToken)
    {
        if (!_active)
            return false;

        while (!cancellationToken.IsCancellationRequested)
        {
            lock (_gate)
            {
                if (!_active)
                    return false;

                if (_generation > lastGeneration)
                    return true;
            }

            if (timeout <= TimeSpan.Zero)
            {
                if (!_frameSignal.Wait(0, cancellationToken))
                    return false;
            }
            else if (!_frameSignal.Wait(timeout, cancellationToken))
            {
                return false;
            }
        }

        return false;
    }

    public bool TryAcquireSequential(ref long lastGeneration, out FrameHubLease lease)
    {
        lease = FrameHubLease.Empty;
        lock (_gate)
        {
            if (!_active || _generation <= lastGeneration)
                return false;

            var target = lastGeneration + 1;
            if (!TryFindSlotLocked(target, out var slot))
            {
                // Ring overwrote this generation — skip forward until found or caught up.
                while (target <= _generation && !TryFindSlotLocked(target, out slot))
                    target++;

                if (target > _generation)
                    return false;
            }

            lastGeneration = target;
            AddRefLocked(slot);
            lease = new FrameHubLease(lastGeneration, _buffers[slot], slot, this);
            return true;
        }
    }

    public bool TryAcquireLatest(ref long lastGeneration, out FrameHubLease lease, out int skipped)
    {
        lease = FrameHubLease.Empty;
        skipped = 0;
        lock (_gate)
        {
            if (!_active || _generation <= lastGeneration || _latestSlot < 0)
                return false;

            skipped = (int)Math.Min(_generation - lastGeneration - 1, int.MaxValue);
            lastGeneration = _generation;
            var slot = _latestSlot;
            AddRefLocked(slot);
            lease = new FrameHubLease(lastGeneration, _buffers[slot], slot, this);
            return true;
        }
    }

    internal void ReleaseSlot(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= _refCounts.Length)
            return;

        Interlocked.Decrement(ref _refCounts[slotIndex]);
    }

    private bool TryFindSlotLocked(long sequence, out int slotIndex)
    {
        for (var i = 0; i < _slotCount; i++)
        {
            if (_slotSequence[i] == sequence)
            {
                slotIndex = i;
                return true;
            }
        }

        slotIndex = -1;
        return false;
    }

    private int AcquireWritableSlotLocked()
    {
        for (var i = 0; i < _slotCount; i++)
        {
            var idx = (_writeCursor + i) % _slotCount;
            if (_refCounts[idx] == 0)
            {
                _writeCursor = (idx + 1) % _slotCount;
                return idx;
            }
        }

        var overwrite = _writeCursor;
        _writeCursor = (_writeCursor + 1) % _slotCount;
        Interlocked.Increment(ref _droppedOverwrites);
        _refCounts[overwrite] = 0;
        return overwrite;
    }

    private void AddRefLocked(int slotIndex) => _refCounts[slotIndex]++;

    public void Dispose() => _frameSignal.Dispose();
}

public readonly struct FrameHubLease
{
    public static FrameHubLease Empty => default;

    private readonly SharedFrameHub? _hub;

    public FrameHubLease(long generation, byte[] buffer, int slotIndex, SharedFrameHub hub)
    {
        Generation = generation;
        Buffer = buffer;
        SlotIndex = slotIndex;
        _hub = hub;
    }

    public long Generation { get; }
    public byte[] Buffer { get; }
    public int SlotIndex { get; }
    public bool IsValid => _hub != null;

    public ReadOnlyMemory<byte> Memory => Buffer;

    public void Release() => _hub?.ReleaseSlot(SlotIndex);
}

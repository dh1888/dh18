namespace EnterpriseAgent.Agent.Capture;

/// <summary>[PipelineDiag] temporary — bridge-side pipe metrics for FFmpeg loop correlation.</summary>
public sealed class PipelineDiagBridgeSnapshot
{
    public long RemotePipeFramesWritten { get; init; }
    public long RemotePipeWriteTimeouts { get; init; }
    public long RemotePipeFramesSkipped { get; init; }
    public DateTime LastRemotePipeWriteUtc { get; init; }
}

namespace EnterpriseAgent.Agent.Capture;

public interface ISharedCaptureBridge
{
    SharedBridgeState State { get; }
    SharedBridgeReadyFlags ReadyFlags { get; }
    bool IsActive { get; }

    Task PrepareAsync(int width, int height, int fps, CancellationToken cancellationToken = default);
    Task WaitConsumersConnectedAsync(CancellationToken cancellationToken = default, bool requireRemote = true);
    Task StartBridgeAsync(CancellationToken cancellationToken = default);
    Task WaitFlowingAsync(
        CancellationToken cancellationToken = default,
        bool requireConsumerFirstFrames = true,
        bool requireRemoteConsumer = true);
    Task StopAsync(CancellationToken cancellationToken = default);
    Task RestartProducerAsync(CancellationToken cancellationToken = default);
    Task ReconnectConsumerAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default);
    /// <summary>Recreate consumer pipe and listen; does not wait for the client to connect.</summary>
    Task RecreateConsumerPipeAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default);
    /// <summary>Reset hub reader cursor after pipe/encoder epoch change (e.g. Remote in-place restart).</summary>
    void ResetConsumerFrameReader(CaptureConsumer consumer, bool snapToLatest = true);
    Task ResetSessionAsync(CancellationToken cancellationToken = default);
    Task DisposeAsync(CancellationToken cancellationToken = default);

    void NotifyConsumerFirstFrame(CaptureConsumer consumer);
    bool NeedsConsumerFirstFrame(CaptureConsumer consumer);
    SharedBridgeHealthSnapshot GetHealthSnapshot();
    PipelineDiagBridgeSnapshot GetPipelineDiagSnapshot();
}

public sealed class SharedBridgeHealthSnapshot
{
    public SharedBridgeState State { get; init; }
    public SharedBridgeReadyFlags ReadyFlags { get; init; }
    public bool BridgeProcessAlive { get; init; }
    public bool RecordingPipeConnected { get; init; }
    public bool RemotePipeConnected { get; init; }
    public bool RemotePipeServerActive { get; init; }
    public bool FrameFlowing { get; init; }
    public long FramesWritten { get; init; }
    public long FramesSinceUtc { get; init; }
    public DateTime LastFrameUtc { get; init; }
    public string? LastError { get; init; }
}

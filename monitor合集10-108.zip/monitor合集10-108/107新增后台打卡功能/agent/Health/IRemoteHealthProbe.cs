namespace EnterpriseAgent.Agent.Health;

public interface IRemoteHealthProbe
{
    RemoteHealthSnapshot Sample();
}

namespace EnterpriseAgent.Agent.Health;

public sealed class RemoteHealthSnapshot
{
    public bool IsPublishing { get; init; }
    public bool ProcessAlive { get; init; }
    public bool FrameRecent { get; init; }
    public double FrameAgeSeconds { get; init; }
    public int RestartCount { get; init; }
    public string? SessionId { get; init; }
    public bool RemoteActive { get; init; }
    public bool IsHealthy { get; init; }
    public bool SuppressBridgePipeRecovery { get; init; }
    public string? PendingTransportError { get; init; }
}

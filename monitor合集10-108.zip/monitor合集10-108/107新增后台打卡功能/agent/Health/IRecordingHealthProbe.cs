using EnterpriseAgent.Agent.Recorder;

namespace EnterpriseAgent.Agent.Health;

public interface IRecordingHealthProbe
{
    RecordingHealthSnapshot Sample();
}

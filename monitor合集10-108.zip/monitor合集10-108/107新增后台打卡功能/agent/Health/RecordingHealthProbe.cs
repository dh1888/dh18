using EnterpriseAgent.Agent.Lifecycle;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.RecordingServices;

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.Health;

public sealed class RecordingHealthProbe : IRecordingHealthProbe
{
    private readonly IRecordingService _recording;
    private readonly ILifecycleCoordinator _lifecycle;

    public RecordingHealthProbe(IRecordingService recording, ILifecycleCoordinator lifecycle)
    {
        _recording = recording;
        _lifecycle = lifecycle;
    }

    public RecordingHealthSnapshot Sample() =>
        _recording.GetHealthSnapshot(_lifecycle.State, _lifecycle.IsRemoteActive);
}

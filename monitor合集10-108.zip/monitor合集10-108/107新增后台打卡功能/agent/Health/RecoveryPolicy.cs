using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.RemoteView;
using Microsoft.Extensions.Options;

namespace EnterpriseAgent.Agent.Health;

public sealed class RecoveryPolicy
{
    private readonly RemoteViewConfig _remoteConfig;

    public RecoveryPolicy(IOptions<RemoteViewConfig> remoteOptions)
    {
        _remoteConfig = remoteOptions.Value;
    }

    public RecoveryDecision Evaluate(
        RecordingHealthSnapshot recording,
        RemoteHealthSnapshot remote,
        SharedBridgeHealthSnapshot? bridge,
        bool sharedCaptureActive,
        DateTime lastResumeUtc,
        DateTime nowUtc)
    {
        if ((nowUtc - lastResumeUtc).TotalSeconds < 30)
            return None("System resuming");

        if (sharedCaptureActive && bridge != null)
        {
            if (bridge.State == SharedBridgeState.Flowing && !bridge.FrameFlowing)
            {
                if (remote.SuppressBridgePipeRecovery && !bridge.RemotePipeConnected)
                    return None("Remote pipe restart in progress");

                if (bridge.BridgeProcessAlive)
                    return new RecoveryDecision { Action = RecoveryAction.RecoverSharedBridge, Reason = "BRIDGE_FRAME_STALL" };

                return new RecoveryDecision { Action = RecoveryAction.RecoverSharedBridge, Reason = "BRIDGE_PROCESS_DEAD" };
            }

            if (!bridge.BridgeProcessAlive &&
                bridge.State is SharedBridgeState.BridgeStarting or SharedBridgeState.Flowing)
            {
                return new RecoveryDecision { Action = RecoveryAction.RecoverSharedBridge, Reason = "BRIDGE_PROCESS_DEAD" };
            }

            if (bridge.State == SharedBridgeState.Flowing &&
                (!bridge.RecordingPipeConnected || !bridge.RemotePipeConnected))
            {
                if (remote.SuppressBridgePipeRecovery)
                    return None("Remote pipe restart in progress");

                return new RecoveryDecision { Action = RecoveryAction.RecoverSharedBridge, Reason = "BRIDGE_PIPE_BROKEN" };
            }

            if (recording.ShouldBeRecording && IsBridgeHealthyForRecordingConsumer(bridge))
            {
                if (!recording.ProcessAlive)
                {
                    return new RecoveryDecision
                    {
                        Action = RecoveryAction.RecoverSharedBridge,
                        Reason = "RECORDING_CONSUMER_DEAD",
                    };
                }

                if (!recording.FileRecent && !recording.FileGrowing)
                {
                    return new RecoveryDecision
                    {
                        Action = RecoveryAction.RecoverSharedBridge,
                        Reason = "RECORDING_CONSUMER_STALL",
                    };
                }
            }
        }

        if (remote.RemoteActive && !sharedCaptureActive && recording.ShouldBeRecording && !recording.ProcessAlive)
        {
            return new RecoveryDecision
            {
                Action = RecoveryAction.ExitRemoteFailed,
                Reason = "REMOTE_WITHOUT_BRIDGE",
            };
        }

        if (remote.RemoteActive)
        {
            var maxRestarts = Math.Max(1, _remoteConfig.RtmpMaxRestartsPerSession);

            if (!remote.IsPublishing && !string.IsNullOrWhiteSpace(remote.SessionId))
            {
                if (remote.RestartCount >= maxRestarts)
                    return new RecoveryDecision { Action = RecoveryAction.ExitRemoteFailed, Reason = "REMOTE_MAX_RESTARTS" };

                return new RecoveryDecision { Action = RecoveryAction.ReconnectRemote, Reason = "REMOTE_PROCESS_DEAD" };
            }

            if (remote.IsPublishing && !remote.FrameRecent)
                return new RecoveryDecision { Action = RecoveryAction.ReconnectRemote, Reason = "REMOTE_FRAME_STALE" };

            if (!string.IsNullOrWhiteSpace(remote.PendingTransportError))
                return new RecoveryDecision { Action = RecoveryAction.ReconnectRemote, Reason = remote.PendingTransportError };
        }

        // SharedBridge 模式下录屏走 bridge/pipe，禁止独立的 gdigrab 级 RecoverRecording（会导致远程黑屏/跳动）
        if (sharedCaptureActive)
            return None("SharedBridge active; recording recovery via bridge only");

        if (!recording.ShouldBeRecording)
            return None("Recording not expected");

        if (!recording.ProcessAlive)
            return new RecoveryDecision { Action = RecoveryAction.RecoverRecording, Reason = "PROCESS_DEAD" };

        if (recording.IsHealthy)
            return None("Recording healthy");

        if (recording.StallSeconds >= Constants.RecordingStallTimeoutSeconds)
        {
            return new RecoveryDecision
            {
                Action = RecoveryAction.RecoverRecording,
                Reason = recording.EncoderAlive ? "NO_FILE_ACTIVITY" : "ENCODER_STALE",
            };
        }

        if (!recording.EncoderAlive && !recording.FileRecent && !recording.FileGrowing)
        {
            return new RecoveryDecision
            {
                Action = RecoveryAction.RecoverRecording,
                Reason = "ENCODER_STALE_AND_NO_FILE_ACTIVITY",
            };
        }

        return None("Recording within tolerance");
    }

    private static bool IsBridgeHealthyForRecordingConsumer(SharedBridgeHealthSnapshot bridge) =>
        bridge.State == SharedBridgeState.Flowing
        && bridge.FrameFlowing
        && bridge.BridgeProcessAlive
        && bridge.RemotePipeConnected;

    private static RecoveryDecision None(string reason) =>
        new() { Action = RecoveryAction.None, Reason = reason };
}

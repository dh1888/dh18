using EnterpriseAgent.Agent.Capture;

namespace EnterpriseAgent.Agent.Health;

public interface ISharedBridgeHealthProbe
{
    SharedBridgeHealthSnapshot Sample();
}

public sealed class SharedBridgeHealthProbe : ISharedBridgeHealthProbe
{
    private readonly ICaptureCoordinator _captureCoordinator;

    public SharedBridgeHealthProbe(ICaptureCoordinator captureCoordinator) =>
        _captureCoordinator = captureCoordinator;

    public SharedBridgeHealthSnapshot Sample() =>
        _captureCoordinator.GetSharedBridgeHealth();
}

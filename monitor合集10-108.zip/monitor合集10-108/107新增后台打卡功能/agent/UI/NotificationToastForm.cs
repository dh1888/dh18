using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace EnterpriseAgent.Agent.UI;

/// <summary>
/// Bottom-right toast notification with close button and auto-dismiss timer.
/// </summary>
public sealed class NotificationToastForm : Form
{
    private const int CornerRadius = 12;
    private const int CloseButtonSize = 28;

    private readonly System.Windows.Forms.Timer _closeTimer;
    private readonly System.Windows.Forms.Timer _progressTimer;
    private readonly Label _titleLabel;
    private readonly Label _messageLabel;
    private readonly Panel _accentBar;
    private readonly Button _closeButton;
    private readonly Panel _progressTrack;
    private readonly Panel _progressFill;
    private readonly Panel _levelBadge;
    private readonly Button? _actionButton;
    private readonly int _durationMs;
    private readonly Color _accentColor;
    private int _elapsedMs;
    private bool _forceClosing;
    private bool _actionInProgress;

    public NotificationToastForm(string title, string message, string level, int durationSec, string? actionLabel = null, Func<Task>? onActionAsync = null)
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        BackColor = Color.FromArgb(28, 30, 36);
        ForeColor = Color.White;
        Font = new Font("Segoe UI", 9.5F);
        Width = 400;
        Padding = new Padding(0);
        DoubleBuffered = true;

        _durationMs = Math.Max(30, durationSec) * 1000;
        _accentColor = ResolveAccentColor(level);

        _accentBar = new Panel
        {
            Dock = DockStyle.Left,
            Width = 4,
            BackColor = _accentColor
        };

        _levelBadge = new Panel
        {
            Size = new Size(28, 28),
            Location = new Point(14, 14),
            BackColor = _accentColor
        };
        _levelBadge.Paint += (_, e) => PaintLevelBadge(e.Graphics, _levelBadge.ClientRectangle, ResolveLevelGlyph(level), _accentColor);

        _closeButton = new Button
        {
            Size = new Size(CloseButtonSize, CloseButtonSize),
            FlatStyle = FlatStyle.Flat,
            Text = "×",
            Font = new Font("Segoe UI", 13F, FontStyle.Regular),
            ForeColor = Color.FromArgb(180, 185, 195),
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand,
            TabStop = false,
            Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        _closeButton.FlatAppearance.BorderSize = 0;
        _closeButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(55, 58, 68);
        _closeButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 74, 86);
        _closeButton.Click += (_, _) => ForceClose();

        _titleLabel = new Label
        {
            AutoSize = false,
            Location = new Point(50, 14),
            Height = 24,
            Font = new Font("Segoe UI Semibold", 10.5F, FontStyle.Bold),
            ForeColor = Color.FromArgb(245, 246, 250),
            Text = string.IsNullOrWhiteSpace(title) ? "通知" : title.Trim()
        };

        _messageLabel = new Label
        {
            AutoSize = false,
            Location = new Point(14, 48),
            ForeColor = Color.FromArgb(196, 200, 210),
            Font = new Font("Segoe UI", 9.5F),
            Text = message?.Trim() ?? string.Empty
        };

        _progressTrack = new Panel
        {
            Height = 3,
            BackColor = Color.FromArgb(48, 52, 62),
            Dock = DockStyle.Bottom
        };
        _progressFill = new Panel
        {
            Height = 3,
            Width = Width,
            BackColor = _accentColor,
            Dock = DockStyle.Left
        };
        _progressTrack.Controls.Add(_progressFill);

        if (!string.IsNullOrWhiteSpace(actionLabel) && onActionAsync != null)
        {
            _actionButton = new Button
            {
                Text = actionLabel.Trim(),
                AutoSize = true,
                Height = 30,
                MinimumSize = new Size(72, 30),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = _accentColor,
                Cursor = Cursors.Hand,
                TabStop = false,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            _actionButton.FlatAppearance.BorderSize = 0;
            _actionButton.FlatAppearance.MouseOverBackColor = Lighten(_accentColor, 24);
            _actionButton.FlatAppearance.MouseDownBackColor = Darken(_accentColor, 16);
            _actionButton.Click += async (_, _) => await HandleActionClickAsync(onActionAsync);
        }

        var body = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = BackColor,
            Padding = new Padding(0, 0, 0, 0)
        };
        body.Controls.Add(_progressTrack);
        body.Controls.Add(_messageLabel);
        if (_actionButton != null)
            body.Controls.Add(_actionButton);
        body.Controls.Add(_closeButton);
        body.Controls.Add(_titleLabel);
        body.Controls.Add(_levelBadge);
        body.Resize += (_, _) => LayoutBody(body);

        Controls.Add(body);
        Controls.Add(_accentBar);

        AdjustHeight();
        LayoutBody(body);
        ApplyRoundedForm();

        _closeTimer = new System.Windows.Forms.Timer { Interval = _durationMs };
        _closeTimer.Tick += (_, _) => ForceClose();
        _closeTimer.Start();

        _progressTimer = new System.Windows.Forms.Timer { Interval = 200 };
        _progressTimer.Tick += (_, _) => UpdateProgress();
        _progressTimer.Start();

        Paint += (_, e) =>
        {
            using var pen = new Pen(Color.FromArgb(58, 62, 74), 1);
            var rect = new Rectangle(0, 0, Width - 1, Height - 1);
            using var path = CreateRoundedPath(rect, CornerRadius);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.DrawPath(pen, path);
        };
    }

    public void SetStackPosition(int x, int y)
    {
        Location = new Point(x, y);
    }

    public void ForceClose()
    {
        if (_forceClosing)
            return;
        _forceClosing = true;
        _closeTimer.Stop();
        _progressTimer.Stop();
        try
        {
            Close();
        }
        catch
        {
            // ignore race during shutdown
        }
        Dispose();
    }

    protected override CreateParams CreateParams
    {
        get
        {
            const int WS_EX_NOACTIVATE = 0x08000000;
            const int WS_EX_TOOLWINDOW = 0x00000080;
            var cp = base.CreateParams;
            cp.ExStyle |= WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW;
            return cp;
        }
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _closeTimer.Stop();
        _progressTimer.Stop();
        _closeTimer.Dispose();
        _progressTimer.Dispose();
        base.OnFormClosed(e);
    }

    private void LayoutBody(Panel body)
    {
        var rightPadding = 12;
        _closeButton.Location = new Point(body.ClientSize.Width - CloseButtonSize - 8, 10);

        var titleWidth = Math.Max(120, body.ClientSize.Width - 62 - CloseButtonSize - rightPadding);
        _titleLabel.Width = titleWidth;

        var messageWidth = body.ClientSize.Width - 28;
        _messageLabel.Width = messageWidth;
        var messageHeight = TextRenderer.MeasureText(
            _messageLabel.Text,
            _messageLabel.Font,
            new Size(messageWidth, int.MaxValue),
            TextFormatFlags.WordBreak).Height;
        _messageLabel.Height = Math.Max(20, messageHeight);

        if (_actionButton != null)
        {
            _actionButton.Location = new Point(
                body.ClientSize.Width - _actionButton.Width - 14,
                Math.Max(48, _messageLabel.Bottom + 10));
        }
    }

    private async Task HandleActionClickAsync(Func<Task> onActionAsync)
    {
        if (_actionInProgress || _actionButton == null)
            return;
        _actionInProgress = true;
        _actionButton.Enabled = false;
        var originalText = _actionButton.Text;
        _actionButton.Text = "...";
        try
        {
            await onActionAsync();
        }
        finally
        {
            if (!_forceClosing && _actionButton != null && !_actionButton.IsDisposed)
            {
                _actionButton.Text = originalText;
                _actionButton.Enabled = true;
            }
            _actionInProgress = false;
        }
    }

    private void AdjustHeight()
    {
        var messageWidth = Width - _accentBar.Width - 28;
        var messageHeight = TextRenderer.MeasureText(
            _messageLabel.Text,
            _messageLabel.Font,
            new Size(messageWidth, int.MaxValue),
            TextFormatFlags.WordBreak).Height;
        var actionExtra = _actionButton != null ? 44 : 0;
        Height = Math.Clamp(48 + messageHeight + 18 + actionExtra, 96, 280);
    }

    private static Color Lighten(Color color, int amount)
        => Color.FromArgb(
            Math.Min(255, color.R + amount),
            Math.Min(255, color.G + amount),
            Math.Min(255, color.B + amount));

    private static Color Darken(Color color, int amount)
        => Color.FromArgb(
            Math.Max(0, color.R - amount),
            Math.Max(0, color.G - amount),
            Math.Max(0, color.B - amount));

    private void UpdateProgress()
    {
        _elapsedMs += 200;
        if (_durationMs <= 0)
            return;
        var remainingRatio = Math.Max(0f, 1f - _elapsedMs / (float)_durationMs);
        var trackWidth = Math.Max(40, _progressTrack.ClientSize.Width);
        _progressFill.Width = (int)(trackWidth * remainingRatio);
    }

    private void ApplyRoundedForm()
    {
        var rect = new Rectangle(0, 0, Width, Height);
        Region = new Region(CreateRoundedPath(rect, CornerRadius));
    }

    private static void PaintLevelBadge(Graphics graphics, Rectangle bounds, string glyph, Color color)
    {
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using var brush = new SolidBrush(color);
        using var path = CreateRoundedPath(new Rectangle(0, 0, bounds.Width - 1, bounds.Height - 1), 8);
        graphics.FillPath(brush, path);
        TextRenderer.DrawText(
            graphics,
            glyph,
            new Font("Segoe UI", 11F, FontStyle.Bold),
            bounds,
            Color.White,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
    }

    private static GraphicsPath CreateRoundedPath(Rectangle bounds, int radius)
    {
        var path = new GraphicsPath();
        var diameter = radius * 2;
        var arc = new Rectangle(bounds.Location, new Size(diameter, diameter));
        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - diameter;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - diameter;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.Left;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }

    private static Color ResolveAccentColor(string level)
    {
        return level?.Trim().ToLowerInvariant() switch
        {
            "success" => Color.FromArgb(67, 160, 71),
            "warning" => Color.FromArgb(251, 140, 0),
            _ => Color.FromArgb(30, 136, 229)
        };
    }

    private static string ResolveLevelGlyph(string level)
    {
        return level?.Trim().ToLowerInvariant() switch
        {
            "success" => "✓",
            "warning" => "!",
            _ => "i"
        };
    }
}

using System.Drawing;

namespace EnterpriseAgent.Agent.UI;

internal sealed class PunchPanelPalette
{
    public Color Bg { get; init; }
    public Color HeaderBg { get; init; }
    public Color CardBg { get; init; }
    public Color Border { get; init; }
    public Color TextPrimary { get; init; }
    public Color TextMuted { get; init; }
    public Color MetaText { get; init; }
    public Color MetaDot { get; init; }
    public Color Accent { get; init; }
    public Color AccentSoft { get; init; }
    public Color CloseHover { get; init; }
    public Color ButtonNeutral { get; init; }
    public Color ButtonPrimary { get; init; }
    public Color ButtonSuccess { get; init; }
    public Color ButtonWarning { get; init; }
    public Color ButtonExhausted { get; init; }
    public Color ChipIdle { get; init; }
    public Color ChipConnected { get; init; }
    public Color ChipWork { get; init; }
    public Color ChipDisconnected { get; init; }
    public Color OpenActivityChip { get; init; }
    public Color OpenActivityText { get; init; }
    public Color TimerCountdown { get; init; }
    public Color TimerUrgent { get; init; }
    public PunchRecordsPalette Records { get; init; } = PunchRecordsPalette.Dark;

    public bool IsLight { get; init; }

    public static PunchPanelPalette Dark => new()
    {
        IsLight = false,
        Bg = Color.FromArgb(14, 16, 22),
        HeaderBg = Color.FromArgb(14, 16, 22),
        CardBg = Color.FromArgb(24, 28, 38),
        Border = Color.FromArgb(56, 64, 80),
        TextPrimary = Color.FromArgb(250, 252, 255),
        TextMuted = Color.FromArgb(142, 150, 166),
        MetaText = Color.FromArgb(214, 220, 230),
        MetaDot = Color.FromArgb(110, 118, 132),
        Accent = Color.FromArgb(72, 162, 255),
        AccentSoft = Color.FromArgb(44, 118, 210),
        CloseHover = Color.FromArgb(48, 54, 68),
        ButtonNeutral = Color.FromArgb(50, 56, 70),
        ButtonPrimary = Color.FromArgb(38, 146, 236),
        ButtonSuccess = Color.FromArgb(52, 164, 78),
        ButtonWarning = Color.FromArgb(250, 138, 28),
        ButtonExhausted = Color.FromArgb(96, 48, 44),
        ChipIdle = Color.FromArgb(78, 84, 98),
        ChipConnected = Color.FromArgb(42, 154, 82),
        ChipDisconnected = Color.FromArgb(88, 94, 108),
        ChipWork = Color.FromArgb(38, 146, 236),
        OpenActivityChip = Color.FromArgb(92, 58, 28),
        OpenActivityText = Color.FromArgb(255, 210, 130),
        TimerCountdown = Color.FromArgb(52, 164, 78),
        TimerUrgent = Color.FromArgb(255, 96, 96),
        Records = PunchRecordsPalette.Dark
    };

    public static PunchPanelPalette Light => new()
    {
        IsLight = true,
        Bg = Color.FromArgb(246, 248, 252),
        HeaderBg = Color.FromArgb(246, 248, 252),
        CardBg = Color.FromArgb(255, 255, 255),
        Border = Color.FromArgb(206, 214, 226),
        TextPrimary = Color.FromArgb(28, 32, 40),
        TextMuted = Color.FromArgb(104, 112, 126),
        MetaText = Color.FromArgb(52, 58, 68),
        MetaDot = Color.FromArgb(148, 156, 168),
        Accent = Color.FromArgb(37, 128, 228),
        AccentSoft = Color.FromArgb(24, 108, 200),
        CloseHover = Color.FromArgb(220, 226, 236),
        ButtonNeutral = Color.FromArgb(224, 230, 240),
        ButtonPrimary = Color.FromArgb(37, 128, 228),
        ButtonSuccess = Color.FromArgb(42, 148, 72),
        ButtonWarning = Color.FromArgb(240, 128, 24),
        ButtonExhausted = Color.FromArgb(214, 168, 160),
        ChipIdle = Color.FromArgb(176, 184, 198),
        ChipConnected = Color.FromArgb(34, 142, 72),
        ChipDisconnected = Color.FromArgb(156, 164, 178),
        ChipWork = Color.FromArgb(34, 128, 220),
        OpenActivityChip = Color.FromArgb(255, 228, 188),
        OpenActivityText = Color.FromArgb(176, 98, 24),
        TimerCountdown = Color.FromArgb(42, 148, 72),
        TimerUrgent = Color.FromArgb(210, 48, 48),
        Records = PunchRecordsPalette.Light
    };

    public Color ResolveButton(PunchButtonStyle style) => style switch
    {
        PunchButtonStyle.Primary => ButtonPrimary,
        PunchButtonStyle.Success => ButtonSuccess,
        PunchButtonStyle.Warning => ButtonWarning,
        PunchButtonStyle.Exhausted => ButtonExhausted,
        _ => ButtonNeutral
    };
}

internal sealed class PunchRecordsPalette
{
    public Color HeaderBg { get; init; }
    public Color RowEven { get; init; }
    public Color RowOdd { get; init; }
    public Color RowHover { get; init; }
    public Color TextPrimary { get; init; }
    public Color TextMuted { get; init; }
    public Color AccentOpen { get; init; }
    public Color TrackColor { get; init; }
    public Color TrackHoverColor { get; init; }
    public Color ThumbColor { get; init; }
    public Color ThumbHoverColor { get; init; }

    public static PunchRecordsPalette Dark => new()
    {
        HeaderBg = Color.FromArgb(20, 24, 32),
        RowEven = Color.FromArgb(18, 22, 30),
        RowOdd = Color.FromArgb(14, 18, 26),
        RowHover = Color.FromArgb(34, 44, 60),
        TextPrimary = Color.FromArgb(232, 236, 244),
        TextMuted = Color.FromArgb(128, 136, 152),
        AccentOpen = Color.FromArgb(255, 188, 92),
        TrackColor = Color.FromArgb(16, 40, 48, 60),
        TrackHoverColor = Color.FromArgb(40, 56, 66, 82),
        ThumbColor = Color.FromArgb(68, 104, 118, 142),
        ThumbHoverColor = Color.FromArgb(112, 126, 148, 176)
    };

    public static PunchRecordsPalette Light => new()
    {
        HeaderBg = Color.FromArgb(236, 240, 246),
        RowEven = Color.FromArgb(252, 253, 255),
        RowOdd = Color.FromArgb(244, 247, 252),
        RowHover = Color.FromArgb(228, 236, 248),
        TextPrimary = Color.FromArgb(36, 40, 48),
        TextMuted = Color.FromArgb(120, 128, 142),
        AccentOpen = Color.FromArgb(214, 128, 32),
        TrackColor = Color.FromArgb(18, 180, 188, 204),
        TrackHoverColor = Color.FromArgb(42, 160, 172, 192),
        ThumbColor = Color.FromArgb(72, 148, 164, 188),
        ThumbHoverColor = Color.FromArgb(110, 128, 148, 172)
    };
}

internal enum PunchButtonStyle { Neutral, Primary, Success, Warning, Exhausted }

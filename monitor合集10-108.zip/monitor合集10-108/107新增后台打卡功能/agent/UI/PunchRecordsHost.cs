using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace EnterpriseAgent.Agent.UI;

internal sealed class PunchRecordDisplayRow
{
    public string Time { get; init; } = string.Empty;
    public string Event { get; init; } = string.Empty;
    public string Detail { get; init; } = string.Empty;
    public string Source { get; init; } = string.Empty;
    public bool IsOpen { get; init; }
}

/// <summary>
/// Custom-painted records table without native ListView scrollbars.
/// </summary>
internal sealed class PunchRecordsHost : Panel
{
    private const int ScrollBarWidth = 4;
    private const int RowHeight = 24;
    private const int HeaderHeight = 24;
    private const int MaxVisibleRows = 6;
    private const int ContentPadding = 8;

    private PunchRecordsPalette _palette = PunchRecordsPalette.Dark;

    private readonly DoubleBufferedPanel _viewport;
    private readonly Panel _scrollTrack;
    private readonly Panel _scrollThumb;
    private readonly Font _headerFont = new("Segoe UI Semibold", 8.25F, FontStyle.Bold);
    private readonly Font _rowFont = new("Segoe UI", 8.75F);
    private readonly List<PunchRecordDisplayRow> _rows = new();
    private readonly string[] _headers = ["时间", "事项", "详情", "来源"];

    private int _scrollOffset;
    private int _hoverIndex = -1;
    private bool _hoveringChrome;
    private bool _draggingThumb;
    private int _dragOffsetY;

    private const int TimeColumnWidth = 78;
    private const int SourceColumnWidth = 46;
    private const int EventColumnWidth = 140;
    private const int MinDetailColumnWidth = 56;
    private const int MinEventColumnWidth = 64;

    public int PreferredHeight => HeaderHeight + MaxVisibleRows * RowHeight + ContentPadding * 2;

    public PunchRecordsHost()
    {
        DoubleBuffered = true;
        BackColor = Color.Transparent;
        Padding = new Padding(0);

        _viewport = new DoubleBufferedPanel
        {
            Dock = DockStyle.Fill,
            BackColor = _palette.RowEven,
            Margin = new Padding(0)
        };
        _viewport.Paint += PaintViewport;
        _viewport.MouseMove += Viewport_MouseMove;
        _viewport.MouseLeave += (_, _) =>
        {
            _hoverIndex = -1;
            _viewport.Invalidate();
        };
        _viewport.MouseWheel += (_, e) => ScrollByLines(-e.Delta / 120);

        _scrollTrack = new Panel
        {
            Width = ScrollBarWidth,
            Dock = DockStyle.Right,
            BackColor = Color.Transparent
        };
        _scrollTrack.Paint += PaintScrollTrack;

        _scrollThumb = new Panel
        {
            Width = ScrollBarWidth,
            Height = 18,
            BackColor = Color.Transparent,
            Visible = false
        };
        _scrollThumb.Paint += PaintScrollThumb;
        _scrollThumb.MouseDown += ScrollThumb_MouseDown;
        _scrollThumb.MouseMove += ScrollThumb_MouseMove;
        _scrollThumb.MouseUp += ScrollThumb_MouseUp;

        _scrollTrack.Controls.Add(_scrollThumb);
        Controls.Add(_viewport);
        Controls.Add(_scrollTrack);

        MouseWheel += (_, e) => ScrollByLines(-e.Delta / 120);
        MouseEnter += (_, _) => { _hoveringChrome = true; _scrollTrack.Invalidate(); _scrollThumb.Invalidate(); };
        MouseLeave += (_, _) =>
        {
            if (_draggingThumb)
                return;
            _hoveringChrome = false;
            _scrollTrack.Invalidate();
            _scrollThumb.Invalidate();
        };
    }

    public void SetHeaders(string time, string eventName, string detail, string source)
    {
        _headers[0] = time;
        _headers[1] = eventName;
        _headers[2] = detail;
        _headers[3] = source;
        _viewport.Invalidate();
    }

    public void SetRows(IReadOnlyList<PunchRecordDisplayRow> rows)
    {
        _rows.Clear();
        _rows.AddRange(rows);
        _scrollOffset = 0;
        _hoverIndex = -1;
        UpdateScrollMetrics();
        _viewport.Invalidate();
    }

    public void ApplyTheme(PunchRecordsPalette palette)
    {
        _palette = palette;
        _viewport.BackColor = palette.RowEven;
        _viewport.Invalidate();
        _scrollTrack.Invalidate();
        _scrollThumb.Invalidate();
    }

    public void RefreshScrollChrome() => UpdateScrollMetrics();

    private int VisibleRowCapacity
        => Math.Max(1, (_viewport.ClientSize.Height - HeaderHeight) / RowHeight);

    private int MaxScrollOffset
        => Math.Max(0, _rows.Count - VisibleRowCapacity);

    private void UpdateScrollMetrics()
    {
        _scrollOffset = Math.Clamp(_scrollOffset, 0, MaxScrollOffset);
        var needsScroll = MaxScrollOffset > 0;
        _scrollTrack.Visible = needsScroll;
        _scrollThumb.Visible = needsScroll;
        if (!needsScroll)
            return;

        var trackHeight = Math.Max(20, _scrollTrack.ClientSize.Height);
        var thumbHeight = Math.Max(14, (int)(trackHeight * (VisibleRowCapacity / (double)Math.Max(_rows.Count, 1))));
        _scrollThumb.Height = Math.Min(trackHeight, thumbHeight);

        var travel = Math.Max(1, trackHeight - _scrollThumb.Height);
        var ratio = MaxScrollOffset == 0 ? 0 : _scrollOffset / (double)MaxScrollOffset;
        _scrollThumb.Top = (int)(ratio * travel);
    }

    private void ScrollByLines(int lines)
    {
        if (lines == 0)
            return;

        _scrollOffset = Math.Clamp(_scrollOffset + lines, 0, MaxScrollOffset);
        UpdateScrollMetrics();
        _viewport.Invalidate();
    }

    private void Viewport_MouseMove(object? sender, MouseEventArgs e)
    {
        var next = ResolveRowIndex(e.Y);
        if (next == _hoverIndex)
            return;

        _hoverIndex = next;
        _viewport.Invalidate();
    }

    private int ResolveRowIndex(int y)
    {
        if (y < HeaderHeight)
            return -1;

        var index = _scrollOffset + (y - HeaderHeight) / RowHeight;
        return index >= 0 && index < _rows.Count ? index : -1;
    }

    private void ScrollThumb_MouseDown(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left)
            return;

        _draggingThumb = true;
        _dragOffsetY = e.Y;
        _scrollThumb.Capture = true;
    }

    private void ScrollThumb_MouseMove(object? sender, MouseEventArgs e)
    {
        if (!_draggingThumb)
            return;

        var trackHeight = _scrollTrack.ClientSize.Height;
        var travel = Math.Max(1, trackHeight - _scrollThumb.Height);
        var newTop = Math.Clamp(_scrollThumb.Top + e.Y - _dragOffsetY, 0, travel);
        _scrollThumb.Top = newTop;

        var ratio = newTop / (double)travel;
        _scrollOffset = (int)Math.Round(ratio * MaxScrollOffset);
        UpdateScrollMetrics();
        _viewport.Invalidate();
    }

    private void ScrollThumb_MouseUp(object? sender, MouseEventArgs e)
    {
        _draggingThumb = false;
        _scrollThumb.Capture = false;
        UpdateScrollMetrics();
    }

    private void PaintViewport(object? sender, PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        var bounds = _viewport.ClientRectangle;
        using (var bg = new SolidBrush(_palette.RowEven))
            g.FillRectangle(bg, bounds);

        var columns = BuildColumns();
        PaintHeader(g, columns);

        if (_rows.Count == 0)
        {
            var emptyRect = new Rectangle(0, HeaderHeight, bounds.Width, RowHeight);
            TextRenderer.DrawText(g, "--", _rowFont, emptyRect, _palette.TextMuted,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
            return;
        }

        var first = _scrollOffset;
        var last = Math.Min(_rows.Count, first + VisibleRowCapacity);
        for (var i = first; i < last; i++)
            PaintRow(g, columns, i, HeaderHeight + (i - first) * RowHeight);
    }

    private void PaintHeader(Graphics g, ColumnLayout columns)
    {
        using (var bg = new SolidBrush(_palette.HeaderBg))
            g.FillRectangle(bg, 0, 0, _viewport.ClientSize.Width, HeaderHeight);

        using var line = new Pen(Color.FromArgb(_palette.TextMuted.A / 3, _palette.TextMuted));
        g.DrawLine(line, 0, HeaderHeight - 1, _viewport.ClientSize.Width, HeaderHeight - 1);

        DrawCellText(g, _headers[0], columns.Time, 0, HeaderHeight, _headerFont, _palette.TextMuted, 6);
        DrawCellText(g, _headers[1], columns.Event, 0, HeaderHeight, _headerFont, _palette.TextMuted, 4);
        DrawCellText(g, _headers[2], columns.Detail, 0, HeaderHeight, _headerFont, _palette.TextMuted, 4);
        DrawCellText(g, _headers[3], columns.Source, 0, HeaderHeight, _headerFont, _palette.TextMuted, 4);
    }

    private void PaintRow(Graphics g, ColumnLayout columns, int rowIndex, int y)
    {
        var row = _rows[rowIndex];
        var rowRect = new Rectangle(0, y, _viewport.ClientSize.Width, RowHeight);
        var bgColor = rowIndex == _hoverIndex
            ? _palette.RowHover
            : rowIndex % 2 == 0 ? _palette.RowEven : _palette.RowOdd;

        using (var bg = new SolidBrush(bgColor))
            g.FillRectangle(bg, rowRect);

        var textColor = row.IsOpen ? _palette.AccentOpen : _palette.TextPrimary;
        DrawCellText(g, row.Time, columns.Time, y, RowHeight, _rowFont, textColor, 8);
        DrawCellText(g, row.Event, columns.Event, y, RowHeight, _rowFont, textColor, 4);
        DrawCellText(g, row.Detail, columns.Detail, y, RowHeight, _rowFont, row.IsOpen ? _palette.AccentOpen : _palette.TextPrimary, 4);
        DrawCellText(g, row.Source, columns.Source, y, RowHeight, _rowFont, _palette.TextMuted, 4);

        if (row.IsOpen)
        {
            using var dot = new SolidBrush(_palette.AccentOpen);
            g.FillEllipse(dot, new Rectangle(2, y + RowHeight / 2 - 2, 4, 4));
        }
    }

    private static void DrawCellText(
        Graphics g,
        string text,
        Rectangle column,
        int y,
        int height,
        Font font,
        Color color,
        int leftPad)
    {
        var rect = new Rectangle(column.Left + leftPad, y, column.Width - leftPad - 4, height);
        TextRenderer.DrawText(g, text, font, rect, color,
            TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
    }

    private ColumnLayout BuildColumns()
    {
        var width = Math.Max(0, _viewport.ClientSize.Width - (_scrollTrack.Visible ? ScrollBarWidth + 2 : 0));
        var eventWidth = EventColumnWidth;
        var detailWidth = width - TimeColumnWidth - SourceColumnWidth - eventWidth;

        if (detailWidth < MinDetailColumnWidth)
        {
            eventWidth = Math.Max(MinEventColumnWidth, width - TimeColumnWidth - SourceColumnWidth - MinDetailColumnWidth);
            detailWidth = Math.Max(0, width - TimeColumnWidth - SourceColumnWidth - eventWidth);
        }

        return new ColumnLayout
        {
            Time = new Rectangle(0, 0, TimeColumnWidth, HeaderHeight),
            Event = new Rectangle(TimeColumnWidth, 0, eventWidth, HeaderHeight),
            Detail = new Rectangle(TimeColumnWidth + eventWidth, 0, detailWidth, HeaderHeight),
            Source = new Rectangle(TimeColumnWidth + eventWidth + detailWidth, 0, SourceColumnWidth, HeaderHeight)
        };
    }

    private void PaintScrollTrack(object? sender, PaintEventArgs e)
    {
        var color = _hoveringChrome || _draggingThumb ? _palette.TrackHoverColor : _palette.TrackColor;
        using var brush = new SolidBrush(color);
        var rect = new Rectangle(1, 4, ScrollBarWidth - 1, _scrollTrack.Height - 8);
        using var path = CreateRoundedPath(rect, 2);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.FillPath(brush, path);
    }

    private void PaintScrollThumb(object? sender, PaintEventArgs e)
    {
        var color = _hoveringChrome || _draggingThumb ? _palette.ThumbHoverColor : _palette.ThumbColor;
        using var brush = new SolidBrush(color);
        var rect = new Rectangle(0, 0, _scrollThumb.Width - 1, _scrollThumb.Height - 1);
        using var path = CreateRoundedPath(rect, 2);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.FillPath(brush, path);
    }

    protected override void OnResize(EventArgs eventargs)
    {
        base.OnResize(eventargs);
        UpdateScrollMetrics();
        _viewport.Invalidate();
    }

    private static GraphicsPath CreateRoundedPath(Rectangle bounds, int radius)
    {
        var path = new GraphicsPath();
        var d = radius * 2;
        var arc = new Rectangle(bounds.Location, new Size(d, d));
        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - d;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - d;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.Left;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }

    private readonly struct ColumnLayout
    {
        public Rectangle Time { get; init; }
        public Rectangle Event { get; init; }
        public Rectangle Detail { get; init; }
        public Rectangle Source { get; init; }
    }

    private sealed class DoubleBufferedPanel : Panel
    {
        public DoubleBufferedPanel()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
        }
    }
}

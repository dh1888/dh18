using System.Drawing;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Services;

namespace EnterpriseAgent.Agent.UI;

/// <summary>
/// Username entry with remembered-account dropdown (per-row remove) and remember checkbox.
/// </summary>
public sealed class RememberedAccountPicker : UserControl
{
    private const int DropdownButtonWidth = 28;

    private readonly TextBox _usernameBox;
    private readonly Button _dropdownButton;
    private readonly CheckBox _rememberCheck;
    private ILocalizationService? _localization;
    private Func<string> _serverKeyProvider = () => RememberedAccountStore.NormalizeServerKey(null);
    private AccountHistoryPopup? _popup;

    public RememberedAccountPicker()
    {
        Height = 52;
        Width = 298;

        _usernameBox = new TextBox
        {
            Location = new Point(0, 0),
            Size = new Size(Width - DropdownButtonWidth, 27)
        };

        _dropdownButton = new Button
        {
            Text = "▾",
            Location = new Point(Width - DropdownButtonWidth, 0),
            Size = new Size(DropdownButtonWidth, 27),
            FlatStyle = FlatStyle.Flat,
            TabStop = false,
            Cursor = Cursors.Hand
        };
        _dropdownButton.FlatAppearance.BorderSize = 1;
        _dropdownButton.Click += (_, _) => ShowAccountHistoryPopup();

        _rememberCheck = new CheckBox
        {
            Location = new Point(0, 30),
            AutoSize = true,
            Checked = true
        };

        Controls.Add(_usernameBox);
        Controls.Add(_dropdownButton);
        Controls.Add(_rememberCheck);

        Resize += (_, _) => LayoutUsernameRow();
    }

    public string Username => _usernameBox.Text.Trim();

    public bool RememberAccount => _rememberCheck.Checked;

    public void SetServerKeyProvider(Func<string> provider)
    {
        _serverKeyProvider = provider ?? (() => RememberedAccountStore.NormalizeServerKey(null));
        RefreshAccounts();
    }

    public void SetServerKey(string? serverUrl)
        => SetServerKeyProvider(() => RememberedAccountStore.NormalizeServerKey(serverUrl));

    public void ApplyLocalization(ILocalizationService? localization)
    {
        _localization = localization;
        _rememberCheck.Text = L("RememberAccount", "记住账号");
        _popup?.ApplyLocalization(localization);
    }

    public void RefreshAccounts()
    {
        var lastUsed = RememberedAccountStore.GetLastUsed(_serverKeyProvider());
        if (!string.IsNullOrWhiteSpace(lastUsed))
            _usernameBox.Text = lastUsed;
    }

    public void FocusUsername()
    {
        _usernameBox.Focus();
        _usernameBox.SelectAll();
    }

    private void LayoutUsernameRow()
    {
        _dropdownButton.Location = new Point(Width - DropdownButtonWidth, 0);
        _usernameBox.Width = Math.Max(80, Width - DropdownButtonWidth);
    }

    private void ShowAccountHistoryPopup()
    {
        var accounts = RememberedAccountStore.GetAccounts(_serverKeyProvider());
        if (accounts.Count == 0)
            return;

        _popup ??= new AccountHistoryPopup();
        _popup.ApplyLocalization(_localization);
        var serverKey = _serverKeyProvider();
        _popup.ShowNear(
            this,
            serverKey,
            accounts,
            username =>
            {
                _usernameBox.Text = username;
                RestoreOwnerFocus();
                _usernameBox.Focus();
                _usernameBox.SelectAll();
            },
            username =>
            {
                RememberedAccountStore.Remove(serverKey, username);
                if (string.Equals(_usernameBox.Text.Trim(), username, StringComparison.OrdinalIgnoreCase))
                    _usernameBox.Text = string.Empty;
            });
    }

    private void RestoreOwnerFocus()
    {
        var owner = FindForm();
        if (owner == null || owner.IsDisposed)
            return;

        owner.Activate();
        owner.BringToFront();
    }

    private string L(string key, string fallback)
        => _localization?.GetString(key, fallback) ?? fallback;

    private sealed class AccountHistoryPopup : Form
    {
        private readonly Panel _host;
        private ILocalizationService? _localization;
        private Control? _activeAnchor;
        private string _activeServerKey = string.Empty;
        private Action<string>? _onSelect;
        private Action<string>? _onRemove;
        private bool _suppressDeactivate;

        public AccountHistoryPopup()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            BackColor = SystemColors.Window;
            Padding = new Padding(1);

            _host = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                BackColor = SystemColors.Window
            };
            Controls.Add(_host);
        }

        public void ApplyLocalization(ILocalizationService? localization)
            => _localization = localization;

        public void ShowNear(
            Control anchor,
            string serverKey,
            IReadOnlyList<string> accounts,
            Action<string> onSelect,
            Action<string> onRemove)
        {
            _activeAnchor = anchor;
            _activeServerKey = serverKey;
            _onSelect = onSelect;
            _onRemove = onRemove;
            RenderRows(accounts);
        }

        private void RenderRows(IReadOnlyList<string> accounts)
        {
            _host.Controls.Clear();
            if (_activeAnchor == null || _onSelect == null || _onRemove == null)
                return;

            const int rowHeight = 30;
            const int removeWidth = 34;
            var contentWidth = Math.Max(_activeAnchor.Width, 220);
            var height = Math.Min(accounts.Count * rowHeight + 2, rowHeight * 8 + 2);

            Width = contentWidth + 2;
            Height = height + 2;

            Location = _activeAnchor.PointToScreen(new Point(0, _activeAnchor.Height));

            for (var i = 0; i < accounts.Count; i++)
            {
                var username = accounts[i];
                var row = new Panel
                {
                    Width = contentWidth,
                    Height = rowHeight,
                    Location = new Point(0, i * rowHeight),
                    BackColor = SystemColors.Window
                };

                var selectButton = new Button
                {
                    Text = username,
                    FlatStyle = FlatStyle.Flat,
                    TextAlign = ContentAlignment.MiddleLeft,
                    Location = new Point(0, 0),
                    Size = new Size(contentWidth - removeWidth, rowHeight),
                    Cursor = Cursors.Hand,
                    TabStop = false
                };
                selectButton.FlatAppearance.BorderSize = 0;
                selectButton.MouseDown += (_, e) =>
                {
                    if (e.Button != MouseButtons.Left)
                        return;

                    _suppressDeactivate = true;
                    _onSelect?.Invoke(username);
                    HidePopup();
                };

                var removeButton = new Button
                {
                    Text = "×",
                    FlatStyle = FlatStyle.Flat,
                    Location = new Point(contentWidth - removeWidth, 0),
                    Size = new Size(removeWidth, rowHeight),
                    Cursor = Cursors.Hand,
                    TabStop = false,
                    ForeColor = Color.FromArgb(180, 60, 60),
                    Font = new Font(Font.FontFamily, 11F, FontStyle.Bold)
                };
                removeButton.FlatAppearance.BorderSize = 0;
                var removeTip = L("RemoveRememberedAccount", "清除此账号");
                var toolTip = new ToolTip();
                toolTip.SetToolTip(removeButton, removeTip);
                removeButton.MouseDown += (_, e) =>
                {
                    if (e.Button != MouseButtons.Left)
                        return;

                    _suppressDeactivate = true;
                    _onRemove?.Invoke(username);
                    var refreshed = RememberedAccountStore.GetAccounts(_activeServerKey);
                    if (refreshed.Count == 0)
                    {
                        HidePopup();
                        return;
                    }

                    _suppressDeactivate = false;
                    RenderRows(refreshed);
                };

                row.Controls.Add(selectButton);
                row.Controls.Add(removeButton);
                _host.Controls.Add(row);
            }

            var owner = _activeAnchor.FindForm();
            if (!Visible && owner != null)
                Show(owner);
            else
                BringToFront();

            Activate();
            Deactivate -= OnPopupDeactivate;
            Deactivate += OnPopupDeactivate;
        }

        private void HidePopup()
        {
            Hide();
            RestoreOwnerFocus();
            _suppressDeactivate = false;
        }

        private void RestoreOwnerFocus()
        {
            var owner = Owner ?? _activeAnchor?.FindForm();
            if (owner == null || owner.IsDisposed)
                return;

            owner.Activate();
            owner.BringToFront();
        }

        private void OnPopupDeactivate(object? sender, EventArgs e)
        {
            if (_suppressDeactivate)
                return;

            BeginInvoke(HidePopupIfInactive);
        }

        private void HidePopupIfInactive()
        {
            if (IsDisposed || !IsHandleCreated || !Visible)
                return;

            if (ContainsFocus)
                return;

            var cursorPos = PointToClient(Cursor.Position);
            if (ClientRectangle.Contains(cursorPos))
                return;

            HidePopup();
        }

        private string L(string key, string fallback)
            => _localization?.GetString(key, fallback) ?? fallback;

        protected override CreateParams CreateParams
        {
            get
            {
                const int wsExToolWindow = 0x00000080;
                var cp = base.CreateParams;
                cp.ExStyle |= wsExToolWindow;
                return cp;
            }
        }
    }
}

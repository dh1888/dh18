using System.Windows.Forms;
using EnterpriseAgent.Agent.Services;

namespace EnterpriseAgent.Agent.UI;

internal static class LanguageMenuBuilder
{
    public static ToolStripMenuItem CreateLanguageSubmenu(
        ILocalizationService? localization,
        Action<string> onLanguageSelected)
    {
        var menuText = localization?.GetString("LanguageMenu", "语言") ?? "语言";
        var menu = new ToolStripMenuItem(menuText);

        Populate(menu.DropDownItems, localization, onLanguageSelected);
        return menu;
    }

    public static void Populate(
        ToolStripItemCollection items,
        ILocalizationService? localization,
        Action<string> onLanguageSelected)
    {
        items.Clear();
        var current = localization?.GetCurrentLanguage() ?? "zh-CN";

        foreach (var code in LanguageCatalog.SupportedCodes)
        {
            var captured = code;
            var item = new ToolStripMenuItem(LanguageCatalog.GetDisplayName(code, localization))
            {
                Tag = code,
                Checked = string.Equals(code, current, StringComparison.OrdinalIgnoreCase)
            };
            item.Click += (_, _) => onLanguageSelected(captured);
            items.Add(item);
        }
    }
}

// frontend/store/user.ts
import { defineStore } from "pinia";
import { ref, computed } from "vue";
import { authApi, userApi } from "@api/index";
import { runCoordinatedRefresh } from "@api/authRefresh";
import { registerSessionTokenApplier } from "@api/sessionTokenSync";
import {
  connectRegisteredWebSocket,
  disconnectRegisteredWebSocket,
} from "@store/wsActions";
import type { AuthUserInfo, LoginRequest, LoginResponse } from "@api/types";

const SESSION_VALIDATE_INTERVAL_MS = 10_000;

const isWebSocketRole = (roleName: string): boolean =>
  roleName === "admin" ||
  roleName === "operator" ||
  roleName === "auditor" ||
  roleName === "viewer";

export const useUserStore = defineStore(
  "user",
  () => {
    const token = ref<string>("");
    const refreshToken = ref<string>("");
    const expiresAt = ref<string>("");
    const username = ref<string>("");
    const role = ref<string>("auditor");
    const permissions = ref<string[]>([]);
    let lastSessionValidatedAt = 0;
    let sessionValidatePromise: Promise<boolean> | null = null;

    const normalizeRoleName = (roleName: string): string => {
      const normalized = roleName.trim().toLowerCase();
      switch (normalized) {
        case "管理员":
        case "administrator":
        case "superadmin":
        case "admin":
          return "admin";
        case "审计员":
        case "auditor":
          return "auditor";
        case "操作员":
        case "operator":
        case "ops":
          return "operator";
        case "查看员":
        case "viewer":
          return "viewer";
        case "员工":
        case "employee":
          return "employee";
        default:
          return "auditor";
      }
    };

    const applyUserInfo = (user?: AuthUserInfo | null, fallbackUsername?: string) => {
      if (!user) return;
      if (user.username) {
        username.value = user.username;
      } else if (fallbackUsername) {
        username.value = fallbackUsername;
      }
      role.value = normalizeRoleName(user.role || "auditor");
      permissions.value = user.permissions || [];
      sessionStorage.setItem("username", username.value);
      sessionStorage.setItem("role", role.value);
      sessionStorage.setItem("permissions", JSON.stringify(permissions.value));
    };

    const isAuthenticated = computed(() => {
      if (!token.value) return false;
      if (!expiresAt.value) return true;
      try {
        const expiryDate = new Date(expiresAt.value);
        if (isNaN(expiryDate.getTime())) return true;
        return expiryDate > new Date();
      } catch {
        return true;
      }
    });

    const connectWebSocket = async (authToken: string) => {
      if (!authToken) return;

      const roleName = role.value;
      if (!isWebSocketRole(roleName)) {
        return;
      }
      // Admin WS requires device:view on the backend; skip to avoid 403 reconnect storms.
      if (roleName !== "admin" && !permissions.value.includes("device:view")) {
        return;
      }

      try {
        connectRegisteredWebSocket(authToken);
      } catch (wsError) {
        const errorMsg =
          wsError instanceof Error ? wsError.message : String(wsError);
        console.error("WebSocket连接失败:", errorMsg);
      }
    };

    const applyLoginResponse = async (data: LoginResponse, fallbackUsername?: string) => {
      if (!data.token || !data.refreshToken || !data.expiresAt) {
        throw new Error("Incomplete login response");
      }
      token.value = data.token;
      refreshToken.value = data.refreshToken;
      expiresAt.value = data.expiresAt;
      applyUserInfo(data.user, fallbackUsername);

      sessionStorage.setItem("token", data.token);
      sessionStorage.setItem("refreshToken", data.refreshToken);
      sessionStorage.setItem("expiresAt", data.expiresAt);

      await connectWebSocket(data.token);
    };

    const login = async (payload: LoginRequest) => {
      const { data, message } = await authApi.login(payload);
      if (data.requiresTotp || data.requiresTotpSetup) {
        return { pending: true as const, data, message };
      }
      await applyLoginResponse(data, payload.username);
      return { pending: false as const, data };
    };

    const hydrateFromSessionStorage = () => {
      refreshToken.value = sessionStorage.getItem("refreshToken") || "";
      token.value = sessionStorage.getItem("token") || "";
      expiresAt.value = sessionStorage.getItem("expiresAt") || "";
      username.value = sessionStorage.getItem("username") || "";
      role.value = sessionStorage.getItem("role") || "auditor";
      const storedPermissions = sessionStorage.getItem("permissions");
      if (storedPermissions) {
        try {
          permissions.value = JSON.parse(storedPermissions);
        } catch {
          permissions.value = [];
        }
      }
    };

    const restoreSession = () => {
      const storedToken = sessionStorage.getItem("token");
      const storedRefreshToken = sessionStorage.getItem("refreshToken");
      const storedExpiresAt = sessionStorage.getItem("expiresAt");

      if (!storedRefreshToken && !storedToken) {
        return false;
      }

      hydrateFromSessionStorage();

      if (storedToken && storedExpiresAt) {
        const expiryDate = new Date(storedExpiresAt);
        if (expiryDate > new Date()) {
          return true;
        }
      }

      return !!storedRefreshToken;
    };

    const reconnectWebSocket = async () => {
      const roleName = role.value;
      if (!isWebSocketRole(roleName)) {
        return;
      }
      const authToken = token.value || sessionStorage.getItem("token") || "";
      if (!authToken) {
        return;
      }
      await connectWebSocket(authToken);
    };

    const ensureSession = async (): Promise<boolean> => validateSession(false);

    const validateSession = async (force = false): Promise<boolean> => {
      hydrateFromSessionStorage();
      if (!refreshToken.value && !token.value) {
        return false;
      }

      const now = Date.now();
      if (
        !force &&
        lastSessionValidatedAt > 0 &&
        now - lastSessionValidatedAt < SESSION_VALIDATE_INTERVAL_MS &&
        isAuthenticated.value
      ) {
        return true;
      }

      if (sessionValidatePromise) {
        return sessionValidatePromise;
      }

      sessionValidatePromise = (async () => {
        if (!isAuthenticated.value) {
          const refreshed = await refresh(false);
          if (refreshed) {
            lastSessionValidatedAt = Date.now();
          }
          return refreshed;
        }

        try {
          await userApi.getProfile();
          lastSessionValidatedAt = Date.now();
          return true;
        } catch {
          const refreshed = await refresh(false);
          if (refreshed) {
            lastSessionValidatedAt = Date.now();
            return true;
          }
          await logout();
          return false;
        }
      })();

      try {
        return await sessionValidatePromise;
      } finally {
        sessionValidatePromise = null;
      }
    };

    const logout = async () => {
      const rt = refreshToken.value || sessionStorage.getItem("refreshToken") || "";
      try {
        await authApi.logout(rt || undefined);
      } catch {
        // 忽略错误
      }
      token.value = "";
      refreshToken.value = "";
      expiresAt.value = "";
      username.value = "";
      role.value = "auditor";
      permissions.value = [];
      sessionStorage.clear();
      lastSessionValidatedAt = 0;

      try {
        disconnectRegisteredWebSocket();
      } catch {
        // 忽略断开失败
      }
    };

    const refresh = async (reconnectWebSocket = true) => {
      if (!refreshToken.value) {
        refreshToken.value = sessionStorage.getItem("refreshToken") || "";
      }
      if (!refreshToken.value) {
        await logout();
        return false;
      }

      try {
        const payload = await runCoordinatedRefresh(async () => {
          const { data } = await authApi.refresh(refreshToken.value);
          if (!data.token || !data.refreshToken) {
            return null;
          }
          return {
            token: data.token,
            refreshToken: data.refreshToken,
            expiresAt: data.expiresAt,
            user: data.user,
          };
        });

        if (!payload) {
          await logout();
          return false;
        }

        applySessionTokens(
          payload.token,
          payload.expiresAt,
          payload.refreshToken,
        );
        if (payload.user) {
          applyUserInfo(payload.user);
        } else if (payload.role) {
          role.value = normalizeRoleName(payload.role);
          sessionStorage.setItem("role", role.value);
        }
        if (payload.permissions) {
          permissions.value = payload.permissions;
          sessionStorage.setItem("permissions", JSON.stringify(payload.permissions));
        }

        if (reconnectWebSocket) {
          await connectWebSocket(payload.token);
        }

        return true;
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        console.error("刷新失败:", errorMsg);
        await logout();
        return false;
      }
    };

    const applySessionTokens = (
      newToken: string,
      newExpiresAt: string,
      newRefreshToken?: string,
    ) => {
      token.value = newToken;
      expiresAt.value = newExpiresAt;
      if (newRefreshToken) {
        refreshToken.value = newRefreshToken;
      }
      sessionStorage.setItem("token", newToken);
      sessionStorage.setItem("expiresAt", newExpiresAt);
      if (newRefreshToken) {
        sessionStorage.setItem("refreshToken", newRefreshToken);
      }
    };

    registerSessionTokenApplier(applySessionTokens);

    const hasPermission = (permission: string): boolean => {
      if (role.value === "admin") {
        return true;
      }
      return permissions.value.includes(permission);
    };

    const isEmployee = computed(() => role.value === "employee");

    return {
      token,
      refreshToken,
      expiresAt,
      username,
      role,
      permissions,
      isAuthenticated,
      login,
      applyLoginResponse,
      logout,
      refresh,
      restoreSession,
      ensureSession,
      validateSession,
      reconnectWebSocket,
      applySessionTokens,
      hasPermission,
      isEmployee,
    };
  },
  {
    persist: false,
  },
);

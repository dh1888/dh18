export function getLastMonth() {
  const now = new Date();
  const d = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function formatMonthLabel(yearMonth: string) {
  if (!yearMonth) return "-";
  const [year, m] = yearMonth.split("-");
  return `${year}年${parseInt(m, 10)}月`;
}

export function formatSalaryAmount(value: number) {
  if (value === undefined || value === null) return "0";
  return Number(value).toLocaleString("zh-CN", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
}

export function salaryStatusTagType(status: string) {
  if (status === "paid") return "success";
  if (status === "pending") return "warning";
  return "info";
}

export interface SalaryEmployeeContext {
  employeeId: string;
  employeeName: string;
  lastMonthYearMonth: string;
  lastMonthSalaryId?: string;
  lastMonthStatus?: string;
}

export function normalizeSalaryEmployee(row: any): SalaryEmployeeContext | null {
  if (!row) return null;
  const employeeId = row.employeeId || row.employeeUuid;
  if (!employeeId) return null;
  const lastMonth = getLastMonth();
  return {
    employeeId,
    employeeName: row.employeeName || "",
    lastMonthYearMonth: row.lastMonthYearMonth || lastMonth,
    lastMonthSalaryId: row.lastMonthSalaryId,
    lastMonthStatus:
      row.lastMonthStatus ??
      (row.yearMonth === lastMonth ? row.paidStatus : undefined),
  };
}

export function findSalaryMonthItem(months: any[], yearMonth: string) {
  return months.find((item) => item.yearMonth === yearMonth) || null;
}

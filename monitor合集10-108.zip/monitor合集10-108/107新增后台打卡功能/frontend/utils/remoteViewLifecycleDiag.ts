export {
  remoteViewLifecycleDiag,
  mediaStreamTrackIds,
  diagnosticAllows,
  diagnosticLog,
  fetchDiagnosticRuntime,
  startDiagnosticRuntimePolling,
  applyDiagnosticRuntime,
  getDiagnosticRuntime,
} from "@/utils/diagnosticCenter";

export type { DiagnosticLevel, DiagnosticRuntimeConfig } from "@/utils/diagnosticCenter";

export interface SalaryColumnPreviewItem {
  index: number;
  letter: string;
  header: string;
}

export interface SalaryColumnFieldDef {
  key: string;
  label: string;
  defaultIndex: number;
  defaultLetter: string;
}

export const SALARY_COLUMN_FIELDS: { key: string; label: string }[] = [
  { key: "name", label: "姓名/用户名" },
  { key: "position", label: "职务" },
  { key: "hireDateDept", label: "入职日期-部门" },
  { key: "monthsEmployed", label: "在职月数" },
  { key: "lastMonthBase", label: "上月底薪" },
  { key: "totalIncrease", label: "递增总额" },
  { key: "baseSalary", label: "底薪(RMB)" },
  { key: "attendanceDays", label: "出勤" },
  { key: "actualBaseSalary", label: "实际底薪" },
  { key: "attendanceAdjustment", label: "调勤" },
  { key: "halfYearUnpaidLeave", label: "半年未休" },
  { key: "exchangeRate", label: "汇率" },
  { key: "performanceScore", label: "绩效分数" },
  { key: "performanceBonusB", label: "绩效奖励B" },
  { key: "reward", label: "奖励" },
  { key: "penalty", label: "罚款" },
  { key: "advance", label: "预支15-15" },
  { key: "otherDeduction", label: "其他扣款" },
  { key: "protectionReturn", label: "保护费返还" },
  { key: "protectionFee", label: "保护费" },
  { key: "totalSalary", label: "实发合计" },
  { key: "remark", label: "备注" },
];

export function indexToColumnLetter(index: number): string {
  if (index < 0) return "";
  let n = index + 1;
  let s = "";
  while (n > 0) {
    n--;
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26);
  }
  return s;
}

export function columnOptionLabel(col: SalaryColumnPreviewItem): string {
  const header = col.header?.trim();
  if (header) {
    return `${col.letter}列 · ${header}`;
  }
  return `${col.letter}列`;
}

export function buildSalaryColumnMappingFromDefaults(): Record<string, number> {
  return {
    position: 0,
    name: 1,
    hireDateDept: 2,
    monthsEmployed: 3,
    lastMonthBase: 4,
    totalIncrease: 5,
    baseSalary: 6,
    attendanceDays: 7,
    actualBaseSalary: 8,
    attendanceAdjustment: 9,
    halfYearUnpaidLeave: 10,
    exchangeRate: 11,
    performanceScore: 12,
    performanceBonusB: 13,
    reward: 14,
    penalty: 15,
    advance: 16,
    otherDeduction: 17,
    protectionReturn: 18,
    protectionFee: 19,
    totalSalary: 20,
    remark: 21,
  };
}

export interface DynamicSheetColumn {
  header: string;
  index: number;
}

/** 判断 Excel 表头是否为实发合计/合计类列 */
export function isSheetTotalHeader(header: string): boolean {
  const h = header.trim();
  if (!h) return false;
  if (h.includes("实发") && h.includes("合计")) return true;
  if (h === "合计" || h === "总计" || h === "实发工资" || h === "实发合计") return true;
  if (h.endsWith("合计") && h.length <= 8 && !h.includes("递增")) return true;
  return false;
}

export function isSheetDateHeader(header: string): boolean {
  const h = header.trim();
  if (!h) return false;
  if (h.includes("入职日期") || h.includes("入职时间")) return true;
  if (h.includes("日期-部门") || (h.includes("入职") && h.includes("部门"))) return true;
  return false;
}

function tryFormatExcelSerial(text: string): string {
  const trimmed = text.trim();
  if (!trimmed) return "";
  const numStr = trimmed.replace(/,/g, "");
  if (/^\d+(\.\d+)?$/.test(numStr)) {
    const n = Number(numStr);
    if (n > 20000 && n < 80000) {
      const epoch = new Date(Date.UTC(1899, 11, 30));
      const date = new Date(epoch.getTime() + n * 86400000);
      if (!Number.isNaN(date.getTime())) {
        const y = date.getUTCFullYear();
        const m = String(date.getUTCMonth() + 1).padStart(2, "0");
        const d = String(date.getUTCDate()).padStart(2, "0");
        return `${y}-${m}-${d}`;
      }
    }
  }
  return "";
}

function tryFormatDateString(text: string): string {
  const trimmed = text.trim();
  const normalized = trimmed
    .replace(/\./g, "-")
    .replace(/\//g, "-")
    .replace(/年/g, "-")
    .replace(/月/g, "-")
    .replace(/日/g, "");
  const match = normalized.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (match) {
    const y = match[1];
    const m = String(Number(match[2])).padStart(2, "0");
    const d = String(Number(match[3])).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return "";
}

export function formatHireDateDisplay(raw: unknown): string {
  const text = raw === undefined || raw === null ? "" : String(raw).trim();
  if (!text || text === "(空)") return "-";

  const serial = tryFormatExcelSerial(text);
  if (serial) return serial;

  const direct = tryFormatDateString(text);
  if (direct) return direct;

  const dashIdx = text.indexOf("-");
  if (dashIdx > 0) {
    const head = text.slice(0, dashIdx);
    const tail = text.slice(dashIdx + 1);
    const headSerial = tryFormatExcelSerial(head);
    if (headSerial) return tail ? `${headSerial}-${tail}` : headSerial;
    const headDate = tryFormatDateString(head);
    if (headDate) return tail ? `${headDate}-${tail}` : headDate;
  }

  if (text.length >= 10) {
    const prefix = tryFormatDateString(text.slice(0, 10));
    if (prefix) {
      const rest = text.slice(10).replace(/^[-—/]/, "").trim();
      return rest ? `${prefix}-${rest}` : prefix;
    }
  }

  return text;
}

export function formatSheetDisplayCell(header: string, value: unknown): string {
  if (value === undefined || value === null || value === "") return "-";
  const text = String(value).trim();
  if (!text) return "-";
  if (isSheetDateHeader(header)) {
    return formatHireDateDisplay(text);
  }
  const serial = tryFormatExcelSerial(text);
  if (serial) return serial;
  return text;
}

import request from "@api/request";

export type DiagnosticLevel =
  | "OFF"
  | "ERROR"
  | "WARN"
  | "INFO"
  | "DEBUG"
  | "TRACE";

export type DiagnosticRuntimeConfig = {
  active: boolean;
  expiresAt?: string | null;
  globalLevel: DiagnosticLevel;
  moduleLevels: Record<string, DiagnosticLevel>;
  agentUploadEnabled: boolean;
  frontendUploadEnabled: boolean;
};

export type DiagnosticCenterConfig = DiagnosticRuntimeConfig & {
  enabled: boolean;
  retentionHours: number;
  updatedAt?: string;
  updatedBy?: string;
};

const LEVEL_RANK: Record<DiagnosticLevel, number> = {
  OFF: 0,
  ERROR: 1,
  WARN: 2,
  INFO: 3,
  DEBUG: 4,
  TRACE: 5,
};

let runtime: DiagnosticRuntimeConfig = {
  active: false,
  globalLevel: "OFF",
  moduleLevels: {},
  agentUploadEnabled: true,
  frontendUploadEnabled: true,
};

let pollTimer: number | null = null;

const normalizeLevel = (raw?: string): DiagnosticLevel => {
  const upper = (raw ?? "OFF").toUpperCase() as DiagnosticLevel;
  return LEVEL_RANK[upper] !== undefined ? upper : "OFF";
};

export const applyDiagnosticRuntime = (config: DiagnosticRuntimeConfig) => {
  runtime = {
    active: !!config.active,
    expiresAt: config.expiresAt ?? null,
    globalLevel: normalizeLevel(config.globalLevel),
    moduleLevels: { ...(config.moduleLevels ?? {}) },
    agentUploadEnabled: config.agentUploadEnabled !== false,
    frontendUploadEnabled: config.frontendUploadEnabled !== false,
  };
};

export const fetchDiagnosticRuntime = async () => {
  const { data } = await request.get<DiagnosticRuntimeConfig>("/diagnostics/runtime");
  applyDiagnosticRuntime(data);
  return data;
};

export const startDiagnosticRuntimePolling = (intervalMs = 30_000) => {
  if (pollTimer != null) return;
  void fetchDiagnosticRuntime().catch(() => {});
  pollTimer = window.setInterval(() => {
    void fetchDiagnosticRuntime().catch(() => {});
  }, intervalMs);
};

export const stopDiagnosticRuntimePolling = () => {
  if (pollTimer != null) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
};

const isExpired = () => {
  if (!runtime.expiresAt) return false;
  return new Date(runtime.expiresAt).getTime() <= Date.now();
};

export const diagnosticAllows = (
  module: string,
  level: DiagnosticLevel,
): boolean => {
  if (!runtime.active || isExpired() || !runtime.frontendUploadEnabled) {
    return false;
  }
  const moduleLevel = normalizeLevel(
    runtime.moduleLevels?.[module] ?? runtime.globalLevel,
  );
  if (moduleLevel === "OFF") return false;
  return LEVEL_RANK[level] <= LEVEL_RANK[moduleLevel];
};

export const diagnosticLog = (
  module: string,
  level: DiagnosticLevel,
  phase: string,
  detail: Record<string, unknown> = {},
) => {
  if (!diagnosticAllows(module, level)) return;

  const payload = {
    ts: new Date().toISOString(),
    module,
    level,
    phase,
    ...detail,
  };
  console.info("[DiagnosticCenter]", payload);

  void request
    .post("/diagnostics/ingest", {
      module,
      level,
      message: `${phase}${detail.message ? `: ${detail.message}` : ""}`,
      correlationId: detail.sessionId,
      context: payload,
    })
    .catch(() => {});
};

export const getDiagnosticRuntime = () => runtime;

/** 模块标识 → 中文展示名（配置/API 仍用英文 key） */
export const DIAGNOSTIC_MODULE_LABELS: Record<string, string> = {
  RemoteView: "远程桌面",
  Recording: "屏幕录制",
  Upload: "文件上传",
  WebSocket: "WebSocket 连接",
  LiveKit: "LiveKit 媒体",
  FFmpeg: "FFmpeg 编码",
  Policy: "策略同步",
  Capture: "屏幕采集",
  Lifecycle: "生命周期",
  Health: "健康检查",
  Backend: "后端服务",
};

export const diagnosticModuleLabel = (module: string) =>
  DIAGNOSTIC_MODULE_LABELS[module] ?? module;

// Backward-compatible helpers for RemoteView lifecycle logging.
export const remoteViewLifecycleDiag = (
  phase: string,
  detail: Record<string, unknown>,
) => diagnosticLog("RemoteView", "INFO", phase, detail);

export const mediaStreamTrackIds = (
  srcObject: MediaProvider | null | undefined,
): string[] => {
  if (!(srcObject instanceof MediaStream)) return [];
  return srcObject.getVideoTracks().map((track) => track.id);
};

if (typeof window !== "undefined") {
  window.addEventListener("diagnostic-config-update", (event) => {
    const detail = (event as CustomEvent).detail as { config?: DiagnosticRuntimeConfig };
    if (detail?.config) applyDiagnosticRuntime(detail.config);
  });
}

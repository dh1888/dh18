import { deviceApi } from "@api/index";
import type { Device } from "@api/types";

let prefetchPromise: Promise<Device[]> | null = null;
let cachedDevices: Device[] | null = null;
let cachedAt = 0;
const CACHE_TTL_MS = 30_000;

export function prefetchRemoteDevices(): void {
  if (prefetchPromise) return;

  prefetchPromise = deviceApi
    .listAll()
    .then(({ data }) => {
      const items = data.items || [];
      cachedDevices = items;
      cachedAt = Date.now();
      return items;
    })
    .catch(() => {
      cachedDevices = [];
      cachedAt = Date.now();
      return [] as Device[];
    })
    .finally(() => {
      prefetchPromise = null;
    });
}

export async function loadRemoteDevices(force = false): Promise<Device[]> {
  if (
    !force &&
    cachedDevices &&
    Date.now() - cachedAt < CACHE_TTL_MS
  ) {
    return cachedDevices;
  }

  if (prefetchPromise) {
    return prefetchPromise;
  }

  const { data } = await deviceApi.listAll();
  const items = data.items || [];
  cachedDevices = items;
  cachedAt = Date.now();
  return items;
}

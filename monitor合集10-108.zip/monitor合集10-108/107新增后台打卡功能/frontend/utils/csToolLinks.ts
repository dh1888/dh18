import csToolApi, { type CsToolSettings } from "@/api/cs_tool_api";
import { ElMessage } from "element-plus";

const DEFAULT_URLS: CsToolSettings = {
  toolUrl: "https://dh1888.github.io/168/",
  scriptUrl: "https://dh1888.github.io/render/",
};

let cachedUrls: CsToolSettings = { ...DEFAULT_URLS };
let loadingPromise: Promise<CsToolSettings> | null = null;

export function getCsToolUrls() {
  return cachedUrls;
}

export async function preloadCsToolUrls(force = false): Promise<CsToolSettings> {
  if (!force && loadingPromise) return loadingPromise;
  loadingPromise = csToolApi
    .getSettings()
    .then((res) => {
      const data = res.data;
      cachedUrls = {
        toolUrl: data?.toolUrl || DEFAULT_URLS.toolUrl,
        scriptUrl: data?.scriptUrl || DEFAULT_URLS.scriptUrl,
        updatedAt: data?.updatedAt,
      };
      return cachedUrls;
    })
    .catch(() => cachedUrls)
    .finally(() => {
      loadingPromise = null;
    });
  return loadingPromise;
}

export function openCsToolLink(key: keyof Pick<CsToolSettings, "toolUrl" | "scriptUrl">) {
  const url = cachedUrls[key] || DEFAULT_URLS[key];
  if (!url) {
    ElMessage.warning("请先在地址配置中设置跳转地址");
    return;
  }
  window.open(url, "_blank", "noopener");
}

export function setCsToolUrls(next: CsToolSettings) {
  cachedUrls = {
    toolUrl: next.toolUrl || DEFAULT_URLS.toolUrl,
    scriptUrl: next.scriptUrl || DEFAULT_URLS.scriptUrl,
    updatedAt: next.updatedAt,
  };
}

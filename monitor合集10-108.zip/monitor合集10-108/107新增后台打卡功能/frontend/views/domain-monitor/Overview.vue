<template>
  <div class="dm-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
    </div>

    <el-row :gutter="20" class="stats-row" v-loading="loading">
      <el-col :xs="12" :sm="8" :md="6" v-for="card in statCards" :key="card.label">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-inner">
            <div class="stat-icon" :style="{ background: card.color }">
              <el-icon :size="26"><component :is="card.icon" /></el-icon>
            </div>
            <div>
              <div class="stat-value">{{ card.value }}</div>
              <div class="stat-label">{{ card.label }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-alert
      v-if="queueDropWarning"
      type="warning"
      :closable="false"
      show-icon
      class="queue-drop-alert"
      :title="queueDropWarning"
    />

    <el-row :gutter="20" class="chart-row">
      <el-col :span="24">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span>近 7 天 HTTP 可用率趋势</span>
              <el-button size="small" @click="loadAvailabilityTrend" :loading="availTrendLoading">
                <el-icon><Refresh /></el-icon> 刷新
              </el-button>
            </div>
          </template>
          <div ref="availChartRef" class="trend-chart trend-chart-sm" v-loading="availTrendLoading"></div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="chart-row">
      <el-col :span="24">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span>近 7 天 HTTP 检测记录</span>
              <div class="header-actions">
                <el-select
                  v-model="chartDomainId"
                  placeholder="全部域名"
                  clearable
                  filterable
                  style="width: 180px"
                  @change="loadHttpChecks"
                >
                  <el-option
                    v-for="d in domainOptions"
                    :key="d.id"
                    :label="d.domain"
                    :value="d.id"
                  />
                </el-select>
                <el-button size="small" @click="loadHttpChecks" :loading="trendLoading">
                  <el-icon><Refresh /></el-icon> 刷新
                </el-button>
              </div>
            </div>
          </template>
          <div ref="trendChartRef" class="trend-chart" v-loading="trendLoading"></div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20">
      <el-col :span="24">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span>快捷入口</span>
              <el-button size="small" @click="loadStats" :loading="loading">
                <el-icon><Refresh /></el-icon> 刷新
              </el-button>
            </div>
          </template>
          <div class="quick-links">
            <el-button type="primary" @click="$router.push('/domain-monitor/domains')">
              域名管理
            </el-button>
            <el-button
              type="warning"
              v-permission="'domain_monitor:manage'"
              :loading="checkAllLoading"
              @click="checkAllDomains"
            >
              一键检测全部
            </el-button>
            <el-button @click="$router.push('/domain-monitor/alerts')">
              告警中心
            </el-button>
            <el-button
              v-permission="'domain_monitor:settings'"
              @click="$router.push('/domain-monitor/check-config')"
            >
              检测配置
            </el-button>
            <el-button
              v-permission="'domain_monitor:settings'"
              @click="$router.push('/domain-monitor/settings')"
            >
              通知配置
            </el-button>
          </div>
          <el-alert
            v-if="stats && stats.openAlerts > 0"
            type="warning"
            :closable="false"
            show-icon
            class="alert-tip"
            :title="`当前有 ${stats.openAlerts} 条未处理告警`"
          />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, nextTick } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import * as echarts from "echarts";
import {
  Monitor,
  CircleCheck,
  Warning,
  Bell,
  Refresh,
  DataLine,
  Calendar,
  Document,
  Connection,
} from "@element-plus/icons-vue";
import domainMonitorApi, {
  type DmDashboardStats,
  type DmHttpCheckPoint,
  type DmDomain,
  type DmTrendPoint,
} from "@api/domain_monitor_api";
import { statusLabel, formatDurationMs, pollCheckBatch } from "./helpers";

const loading = ref(false);
const checkAllLoading = ref(false);
const pollingAbort = new AbortController();
const trendLoading = ref(false);
const availTrendLoading = ref(false);
const stats = ref<DmDashboardStats | null>(null);
const availabilityTrend = ref<DmTrendPoint[]>([]);
const chartDomainId = ref("");
const domainOptions = ref<DmDomain[]>([]);
const httpChecks = ref<DmHttpCheckPoint[]>([]);
const trendChartRef = ref<HTMLElement | null>(null);
const availChartRef = ref<HTMLElement | null>(null);
let trendChart: echarts.ECharts | null = null;
let availChart: echarts.ECharts | null = null;

const statCards = computed(() => {
  const s = stats.value;
  return [
    {
      label: "监控域名",
      value: s?.totalDomains ?? "-",
      icon: Monitor,
      color: "linear-gradient(135deg,#667eea,#764ba2)",
    },
    {
      label: "正常",
      value: s?.normalCount ?? "-",
      icon: CircleCheck,
      color: "linear-gradient(135deg,#11998e,#38ef7d)",
    },
    {
      label: "部分地区异常",
      value: s?.partialCount ?? "-",
      icon: Warning,
      color: "linear-gradient(135deg,#f6d365,#fda085)",
    },
    {
      label: "异常",
      value: s?.abnormalCount ?? "-",
      icon: Warning,
      color: "linear-gradient(135deg,#f093fb,#f5576c)",
    },
    {
      label: "高危",
      value: s?.criticalHealthCount ?? "-",
      icon: Bell,
      color: "linear-gradient(135deg,#cb2d3e,#ef473a)",
    },
    {
      label: "全球可达率",
      value: s?.globalReachability != null ? `${s.globalReachability.toFixed(0)}%` : "-",
      icon: DataLine,
      color: "linear-gradient(135deg,#4facfe,#00f2fe)",
    },
    {
      label: "在线 Probe",
      value: s?.onlineNodes ?? "-",
      icon: Connection,
      color: "linear-gradient(135deg,#a8edea,#fed6e3)",
    },
    {
      label: "WHOIS 30天内到期",
      value: s?.whoisExpiring ?? "-",
      icon: Calendar,
      color: "linear-gradient(135deg,#fbc2eb,#a6c1ee)",
    },
    {
      label: "今日告警",
      value: s?.alertsToday ?? "-",
      icon: Bell,
      color: "linear-gradient(135deg,#fa709a,#fee140)",
    },
    {
      label: "未处理告警",
      value: s?.openAlerts ?? "-",
      icon: Bell,
      color: "linear-gradient(135deg,#ff9a9e,#fecfef)",
    },
  ];
});

const queueDropWarning = computed(() => {
  const s = stats.value;
  if (!s) return "";
  const normal = s.droppedCheckJobs ?? 0;
  const priority = s.droppedPriorityJobs ?? 0;
  const total = normal + priority;
  if (total <= 0) return "";
  return `检测队列已满，已丢弃 ${total} 个任务（普通 ${normal} / 优先 ${priority}）。请增大 Worker 池或调度批量上限。`;
});

function renderAvailabilityChart(points: DmTrendPoint[]) {
  if (!availChartRef.value) return;
  if (!availChart) {
    availChart = echarts.init(availChartRef.value);
  }
  availChart.setOption({
    tooltip: {
      trigger: "axis",
      formatter(params: any) {
        const p = Array.isArray(params) ? params[0] : params;
        const row = points[p?.dataIndex];
        if (!row) return "";
        return [
          `<b>${row.date}</b>`,
          `可用率：${row.availability.toFixed(1)}%`,
          `成功：${row.okCount}`,
          `失败：${row.failCount}`,
        ].join("<br/>");
      },
    },
    grid: { left: 48, right: 24, bottom: 32, top: 24 },
    xAxis: {
      type: "category",
      data: points.map((p) => p.date),
      axisLabel: { rotate: points.length > 10 ? 30 : 0 },
    },
    yAxis: {
      type: "value",
      min: 0,
      max: 100,
      axisLabel: { formatter: "{value}%" },
    },
    series: [
      {
        name: "可用率",
        type: "line",
        smooth: true,
        data: points.map((p) => Number(p.availability.toFixed(1))),
        areaStyle: { opacity: 0.08 },
      },
    ],
  });
}

function renderHttpCheckChart(points: DmHttpCheckPoint[]) {
  if (!trendChartRef.value) return;
  if (!trendChart) {
    trendChart = echarts.init(trendChartRef.value);
  }
  trendChart.setOption({
    tooltip: {
      trigger: "item",
      formatter(params: any) {
        const p = params.data?.meta as DmHttpCheckPoint | undefined;
        if (!p) return "";
        return [
          `<b>${p.domain}</b>`,
          `时间：${formatDateTime(p.checkedAt)}`,
          `状态：${statusLabel(p.status)}`,
          `HTTP：${p.httpStatus || "-"}`,
          `响应：${formatDurationMs(p.durationMs)}`,
          `节点：${p.nodeName || "-"}`,
        ].join("<br/>");
      },
    },
    grid: { left: 56, right: 24, bottom: 48, top: 24 },
    xAxis: { type: "time", name: "检测时间" },
    yAxis: { type: "value", name: "响应时间 (ms)", min: 0 },
    dataZoom: [{ type: "inside" }, { type: "slider", height: 18, bottom: 8 }],
    series: [
      {
        name: "HTTP 检测",
        type: "scatter",
        symbolSize: 10,
        data: points.map((p) => ({
          value: [p.checkedAt, p.durationMs || 0],
          itemStyle: {
            color:
              (p.status || "").toLowerCase() === "ok" ? "#67c23a" : "#f56c6c",
          },
          meta: p,
        })),
      },
    ],
  });
}

function formatDateTime(value: string): string {
  return new Date(value).toLocaleString("zh-CN");
}

async function loadDomainOptions() {
  try {
    const { data } = await domainMonitorApi.listDomains({
      page: 1,
      pageSize: 200,
      enabled: true,
    });
    domainOptions.value = data?.items || [];
  } catch {
    domainOptions.value = [];
  }
}

async function loadAvailabilityTrend() {
  availTrendLoading.value = true;
  try {
    const { data } = await domainMonitorApi.getTrends(7);
    availabilityTrend.value = data || [];
    await nextTick();
    renderAvailabilityChart(availabilityTrend.value);
  } catch (e: any) {
    ElMessage.error(e.message || "加载可用率趋势失败");
  } finally {
    availTrendLoading.value = false;
  }
}

async function loadHttpChecks() {
  trendLoading.value = true;
  try {
    const { data } = await domainMonitorApi.getHttpChecks({
      days: 7,
      limit: 1000,
      domainId: chartDomainId.value || undefined,
    });
    httpChecks.value = data || [];
    await nextTick();
    renderHttpCheckChart(httpChecks.value);
  } catch (e: any) {
    ElMessage.error(e.message || "加载检测记录失败");
  } finally {
    trendLoading.value = false;
  }
}

async function loadStats() {
  loading.value = true;
  try {
    const { data } = await domainMonitorApi.getOverview();
    stats.value = data;
    await Promise.all([loadAvailabilityTrend(), loadHttpChecks()]);
  } catch (e: any) {
    ElMessage.error(e.message || "加载概览失败");
  } finally {
    loading.value = false;
  }
}

async function checkAllDomains() {
  try {
    await ElMessageBox.confirm(
      "将对所有已启用的域名发起立即检测（含探针节点任务），是否继续？",
      "一键检测全部",
      { type: "warning" },
    );
    checkAllLoading.value = true;
    const { data } = await domainMonitorApi.checkAllDomains();
    const total = data?.total ?? data?.queued ?? 0;
    if (!data?.batchId || total === 0) {
      ElMessage.warning("没有可检测的已启用域名");
      return;
    }
    const finalStatus = await pollCheckBatch(data.batchId, () => {}, 1000, pollingAbort.signal);
    if (!finalStatus) return;
    ElMessage.success(`检测完成：${total} 个域名`);
    await loadStats();
    await loadHttpChecks();
  } catch (e: any) {
    if (e !== "cancel") {
      ElMessage.error(e.message || "操作失败");
    }
  } finally {
    checkAllLoading.value = false;
  }
}

onMounted(async () => {
  await loadDomainOptions();
  await loadStats();
});
onUnmounted(() => {
  trendChart?.dispose();
  trendChart = null;
  availChart?.dispose();
  availChart = null;
  pollingAbort.abort();
});
</script>

<style scoped>
.dm-page {
  position: relative;
  padding: 4px;
}
.bg-decoration {
  position: absolute;
  inset: 0;
  overflow: hidden;
  pointer-events: none;
  z-index: 0;
}
.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(60px);
  opacity: 0.35;
}
.blob-1 {
  width: 280px;
  height: 280px;
  background: #667eea;
  top: -80px;
  right: -40px;
}
.blob-2 {
  width: 220px;
  height: 220px;
  background: #38ef7d;
  bottom: 0;
  left: -60px;
}
.stats-row,
.el-row {
  position: relative;
  z-index: 1;
}
.queue-drop-alert {
  margin-bottom: 16px;
  position: relative;
  z-index: 1;
}
.stat-card {
  margin-bottom: 16px;
  border-radius: 12px;
}
.stat-inner {
  display: flex;
  align-items: center;
  gap: 14px;
}
.stat-icon {
  width: 52px;
  height: 52px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
}
.stat-value {
  font-size: 24px;
  font-weight: 700;
  line-height: 1.2;
}
.stat-label {
  color: #909399;
  font-size: 13px;
  margin-top: 4px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: 600;
}
.header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}
.quick-links {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}
.alert-tip {
  margin-top: 16px;
}
.chart-row {
  margin-bottom: 16px;
}
.trend-chart {
  height: 320px;
  width: 100%;
}
.trend-chart-sm {
  height: 240px;
  width: 100%;
}
</style>

<template>
  <div class="dm-page">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <el-card shadow="hover" class="main-card" v-loading="loading">
      <!-- ===== 卡片头部 ===== -->
      <template #header>
        <div class="card-header-custom">
          <div class="header-left">
            <div class="header-icon-wrapper">
              <el-icon class="header-icon"><Setting /></el-icon>
            </div>
            <div class="header-info">
              <span class="header-title">自动检测配置</span>
              <span class="header-subtitle">管理域名监控的全局检测参数</span>
            </div>
          </div>
          <div class="header-right">
            <el-tag type="info" effect="plain" size="large" class="status-tag">
              <el-icon><Clock /></el-icon>
              运行中
            </el-tag>
          </div>
        </div>
      </template>

      <!-- ===== 提示信息 ===== -->
      <el-alert
        type="info"
        :closable="false"
        show-icon
        class="tip-alert"
        title="默认检测间隔用于新建/导入域名；修改默认间隔后会自动同步全部域名的检测间隔。"
      />

      <!-- ===== 配置表单 ===== -->
      <el-form :model="form" label-width="180px" class="config-form" @submit.prevent="save">
        <!-- ===== 基础配置 ===== -->
        <div class="form-section">
          <div class="section-header">
            <span class="section-icon">⚙️</span>
            <span class="section-title">基础配置</span>
          </div>

          <el-form-item label="默认检测间隔">
            <div class="input-group">
              <el-input-number
                v-model="form.defaultCheckInterval"
                :min="60"
                :step="60"
                size="large"
                controls-position="right"
                class="modern-input-number"
              />
              <span class="hint">{{ formatInterval(form.defaultCheckInterval) }}</span>
            </div>
          </el-form-item>

          <el-form-item label="调度扫描间隔">
            <div class="input-group">
              <el-input-number
                v-model="form.schedulerTickSeconds"
                :min="10"
                :step="10"
                size="large"
                controls-position="right"
                class="modern-input-number"
              />
              <span class="hint">秒（后台扫描到期域名的频率）</span>
            </div>
          </el-form-item>

          <el-form-item label="自动检测优先级">
            <div class="input-group">
              <el-switch v-model="form.autoCheckPriority" size="large" />
              <span class="hint">开启后，定时自动检测任务优先于手动/批量检测</span>
            </div>
          </el-form-item>
        </div>

        <!-- ===== Telegram 通知 ===== -->
        <div class="form-section">
          <div class="section-header">
            <span class="section-icon">📨</span>
            <span class="section-title">Telegram 通知</span>
          </div>

          <el-form-item label="Telegram 报告">
            <div class="input-group">
              <el-switch v-model="form.telegramReportEnabled" size="large" />
              <span class="hint">每次检测周期完成后推送一条汇总报告（需配置 monitor_report 路由）</span>
            </div>
          </el-form-item>

          <el-form-item label="实时告警推送">
            <div class="input-group">
              <el-switch v-model="form.telegramRealtimeEnabled" size="large" />
              <span class="hint">开启后每条异常单独推送；关闭且已开启汇总报告时，仅发送一条汇总</span>
            </div>
          </el-form-item>

          <el-form-item label="报告标题">
            <div class="input-group">
              <el-input
                v-model="form.reportTitle"
                placeholder="域名监控报告"
                size="large"
                class="modern-input"
                clearable
              />
            </div>
          </el-form-item>

          <el-form-item label="服务器标识">
            <div class="input-group">
              <el-input
                v-model="form.reportServerLabel"
                placeholder="216.238.122.242 | Osasco, BR"
                size="large"
                class="modern-input"
                clearable
              />
            </div>
          </el-form-item>

          <el-form-item label="通知时区">
            <div class="input-group">
              <el-select
                v-model="form.reportTimezone"
                filterable
                placeholder="选择通知时区"
                size="large"
                class="modern-select"
              >
                <el-option
                  v-for="item in timezoneOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
              <span class="hint block-hint">Telegram 告警与汇总报告将按此时区显示时间</span>
            </div>
          </el-form-item>
        </div>

        <!-- ===== 代理检测 ===== -->
        <div class="form-section">
          <div class="section-header">
            <span class="section-icon">🔌</span>
            <span class="section-title">代理检测（全局）</span>
          </div>

          <el-form-item label="HTTP/SOCKS 代理">
            <div class="input-group proxy-group">
              <el-input
                v-model="form.httpProxyUrl"
                placeholder="http://127.0.0.1:7890 或 socks5://user:pass@host:port"
                clearable
                size="large"
                class="modern-input proxy-input"
              />
              <el-button :loading="proxyTesting" @click="testProxy" class="test-proxy-btn" size="large">
                <el-icon><Connection /></el-icon>
                测试代理
              </el-button>
            </div>
            <span class="hint block-hint">
              支持 HTTP/HTTPS 与 SOCKS5（含 socks5://host:port:user:pass 写法）。留空则本机直连。测试无需先保存。
            </span>

            <!-- 代理测试结果 -->
            <el-alert
              v-if="proxyTestResult"
              class="proxy-result"
              :type="proxyTestResult.ok ? (proxyTestResult.hint ? 'warning' : 'success') : 'error'"
              :closable="true"
              show-icon
              @close="proxyTestResult = null"
            >
              <template #title>
                <span class="result-title">{{ proxyTestResult.message }}</span>
              </template>
              <div v-if="proxyTestResult.ok" class="proxy-detail">
                <div class="detail-row" v-if="proxyTestResult.mode">
                  <span class="detail-label">模式</span>
                  <el-tag :type="proxyTestResult.mode === 'socks5' ? 'warning' : 'primary'" size="small">
                    {{ proxyTestResult.mode === "socks5" ? "SOCKS5 代理" : proxyTestResult.mode === "proxy" ? "HTTP 代理" : "本机直连" }}
                  </el-tag>
                </div>
                <div class="detail-row" v-if="proxyTestResult.proxyDisplay">
                  <span class="detail-label">代理</span>
                  <span class="detail-value">{{ proxyTestResult.proxyDisplay }}</span>
                </div>
                <div class="detail-row" v-if="proxyTestResult.httpStatus">
                  <span class="detail-label">HTTP 状态</span>
                  <el-tag :type="proxyTestResult.httpStatus >= 200 && proxyTestResult.httpStatus < 300 ? 'success' : 'danger'" size="small">
                    {{ proxyTestResult.httpStatus }}
                  </el-tag>
                </div>
                <div class="detail-row" v-if="proxyTestResult.durationMs != null">
                  <span class="detail-label">耗时</span>
                  <span class="detail-value" :class="getDurationClass(proxyTestResult.durationMs)">
                    {{ proxyTestResult.durationMs }} ms
                  </span>
                </div>
                <div class="detail-row" v-if="proxyTestResult.exitIp">
                  <span class="detail-label">出口 IP</span>
                  <el-tag type="success" size="small">{{ proxyTestResult.exitIp }}</el-tag>
                </div>
                <div class="detail-row" v-if="proxyTestResult.directExitIp">
                  <span class="detail-label">直连 IP</span>
                  <el-tag type="info" size="small">{{ proxyTestResult.directExitIp }}</el-tag>
                </div>
              </div>
              <div v-else class="proxy-detail">
                <div v-if="proxyTestResult.hint" class="proxy-hint">{{ proxyTestResult.hint }}</div>
                <div v-if="proxyTestResult.steps?.length" class="proxy-steps-wrapper">
                  <div class="steps-title">检测步骤</div>
                  <ul class="proxy-steps">
                    <li v-for="(step, idx) in proxyTestResult.steps" :key="idx">
                      <span class="step-name">{{ step.name }}</span>
                      <span :class="step.ok ? 'step-ok' : 'step-fail'">
                        {{ step.ok ? `✅ 成功 (${step.httpStatus})` : `❌ ${step.summary}` }}
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
              <div v-if="proxyTestResult.ok && proxyTestResult.hint" class="proxy-detail warn">
                <el-icon><WarningFilled /></el-icon>
                {{ proxyTestResult.hint }}
              </div>
            </el-alert>
          </el-form-item>
        </div>

        <!-- ===== 性能优化 ===== -->
        <div class="form-section">
          <div class="section-header">
            <span class="section-icon">🚀</span>
            <span class="section-title">性能优化</span>
          </div>

          <el-form-item label="并发 Worker 数">
            <div class="input-group">
              <el-input-number
                v-model="form.workerPoolSize"
                :min="10"
                :max="500"
                :step="10"
                size="large"
                controls-position="right"
                class="modern-input-number"
              />
              <span class="hint">同时检测的域名数量，建议 100~200（大规模可提高到 300+）</span>
            </div>
          </el-form-item>

          <el-form-item label="HTTP 超时">
            <div class="input-group">
              <el-input-number
                v-model="form.httpTimeoutSeconds"
                :min="3"
                :max="30"
                size="large"
                controls-position="right"
                class="modern-input-number"
              />
              <span class="hint">秒，默认 8 秒，过短可能误判慢站点</span>
            </div>
          </el-form-item>

          <el-form-item label="单域名总超时">
            <div class="input-group">
              <el-input-number
                v-model="form.domainCheckTimeoutSeconds"
                :min="5"
                :max="120"
                size="large"
                controls-position="right"
                class="modern-input-number"
              />
              <span class="hint">秒，DNS/HTTP/SSL 等并行检测的上限</span>
            </div>
          </el-form-item>

          <el-form-item label="快速 DNS 模式">
            <div class="input-group">
              <el-switch v-model="form.fastDnsCheck" size="large" />
              <span class="hint">仅查 A/AAAA 记录，跳过 MX/TXT/NS，大幅加速</span>
            </div>
          </el-form-item>

          <el-form-item label="调度批次上限">
            <div class="input-group">
              <el-input-number
                v-model="form.scheduleBatchLimit"
                :min="100"
                :max="5000"
                :step="100"
                size="large"
                controls-position="right"
                class="modern-input-number"
              />
              <span class="hint">每轮自动调度最多检测的域名数</span>
            </div>
          </el-form-item>
        </div>

        <!-- ===== Probe 注册 ===== -->
        <div class="form-section">
          <div class="section-header">
            <span class="section-icon">🖥️</span>
            <span class="section-title">Probe 注册</span>
          </div>

          <el-form-item label="注册令牌">
            <div class="input-group">
              <el-input
                v-model="form.probeRegistrationToken"
                :placeholder="
                  form.probeRegistrationTokenConfigured
                    ? '已配置，留空则不修改'
                    : '探针自动注册时使用的密钥'
                "
                clearable
                show-password
                size="large"
                class="modern-input"
              />
              <span class="hint block-hint">设置后探针可通过 DM_REGISTER_TOKEN 自动注册，无需手动创建节点</span>
            </div>
          </el-form-item>
        </div>

        <!-- ===== Probe 任务 ===== -->
        <div class="form-section">
          <div class="section-header">
            <span class="section-icon">📋</span>
            <span class="section-title">Probe 任务</span>
          </div>

          <el-form-item label="批量检测探针">
            <div class="input-group">
              <el-switch v-model="form.probeOnBatchCheck" size="large" />
              <span class="hint">一键检测时同步下发探针任务（关闭可显著加速）</span>
            </div>
          </el-form-item>
        </div>

        <!-- ===== 操作按钮 ===== -->
        <div class="form-actions">
          <div class="actions-left">
            <el-form-item label="批量应用" class="batch-apply-item">
              <el-checkbox v-model="form.applyToAllDomains" size="large">
                保存时同步到全部已启用域名
              </el-checkbox>
            </el-form-item>
          </div>
          <div class="actions-right">
            <el-button type="primary" size="large" :loading="saving" @click="save" class="save-btn">
              <el-icon v-if="!saving"><Check /></el-icon>
              <span>{{ saving ? '保存中...' : '保存配置' }}</span>
            </el-button>
            <el-button size="large" @click="load" :loading="loading" class="reset-btn">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
          </div>
        </div>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted, computed } from "vue";
import { ElMessage } from "element-plus";
import {
  Setting,
  Clock,
  Connection,
  WarningFilled,
  Check,
  Refresh,
} from "@element-plus/icons-vue";
import domainMonitorApi, { type DmProxyTestResult } from "@api/domain_monitor_api";
import { formatInterval } from "./helpers";
import { buildTimezoneOptions } from "./timezones";

const loading = ref(false);
const saving = ref(false);
const proxyTesting = ref(false);
const proxyTestResult = ref<DmProxyTestResult | null>(null);
const form = reactive({
  defaultCheckInterval: 300,
  schedulerTickSeconds: 60,
  autoCheckPriority: true,
  telegramReportEnabled: false,
  telegramRealtimeEnabled: false,
  reportServerLabel: "Local Center",
  reportTimezone: "UTC",
  reportTitle: "域名监控报告",
  workerPoolSize: 100,
  httpTimeoutSeconds: 8,
  domainCheckTimeoutSeconds: 25,
  fastDnsCheck: true,
  scheduleBatchLimit: 1000,
  probeOnBatchCheck: false,
  httpProxyUrl: "",
  probeRegistrationToken: "",
  probeRegistrationTokenConfigured: false,
  applyToAllDomains: false,
});

const timezoneOptions = computed(() => buildTimezoneOptions(form.reportTimezone));

function getDurationClass(ms: number): string {
  if (ms < 500) return "fast";
  if (ms < 2000) return "medium";
  return "slow";
}

async function load() {
  loading.value = true;
  try {
    const { data } = await domainMonitorApi.getCheckSettings();
    if (data) {
      form.defaultCheckInterval = data.defaultCheckInterval;
      form.schedulerTickSeconds = data.schedulerTickSeconds;
      form.autoCheckPriority = data.autoCheckPriority ?? true;
      form.telegramReportEnabled = data.telegramReportEnabled ?? false;
      form.telegramRealtimeEnabled = data.telegramRealtimeEnabled ?? false;
      form.reportServerLabel = data.reportServerLabel || "Local Center";
      form.reportTimezone = data.reportTimezone || "UTC";
      form.reportTitle = data.reportTitle || "域名监控报告";
      form.workerPoolSize = data.workerPoolSize ?? 100;
      form.httpTimeoutSeconds = data.httpTimeoutSeconds ?? 8;
      form.domainCheckTimeoutSeconds = data.domainCheckTimeoutSeconds ?? 25;
      form.fastDnsCheck = data.fastDnsCheck ?? true;
      form.scheduleBatchLimit = data.scheduleBatchLimit ?? 1000;
      form.probeOnBatchCheck = data.probeOnBatchCheck ?? false;
      form.httpProxyUrl = data.httpProxyUrl || "";
      form.probeRegistrationToken = "";
      form.probeRegistrationTokenConfigured =
        data.probeRegistrationTokenConfigured ?? false;
    }
  } catch (e: any) {
    ElMessage.error(e.message || "加载配置失败");
  } finally {
    loading.value = false;
  }
}

async function testProxy() {
  proxyTesting.value = true;
  proxyTestResult.value = null;
  try {
    const { data } = await domainMonitorApi.testHttpProxy({
      httpProxyUrl: form.httpProxyUrl.trim(),
    });
    if (!data) {
      throw new Error("无测试结果");
    }
    proxyTestResult.value = data;
    if (data.ok) {
      ElMessage.success(data.message);
    } else {
      ElMessage.error(data.message || "代理测试失败");
    }
  } catch (e: any) {
    ElMessage.error(e.message || "代理测试失败");
  } finally {
    proxyTesting.value = false;
  }
}

async function save() {
  saving.value = true;
  try {
    await domainMonitorApi.saveCheckSettings({
      defaultCheckInterval: form.defaultCheckInterval,
      schedulerTickSeconds: form.schedulerTickSeconds,
      autoCheckPriority: form.autoCheckPriority,
      telegramReportEnabled: form.telegramReportEnabled,
      telegramRealtimeEnabled: form.telegramRealtimeEnabled,
      reportServerLabel: form.reportServerLabel,
      reportTimezone: form.reportTimezone,
      reportTitle: form.reportTitle,
      workerPoolSize: form.workerPoolSize,
      httpTimeoutSeconds: form.httpTimeoutSeconds,
      domainCheckTimeoutSeconds: form.domainCheckTimeoutSeconds,
      fastDnsCheck: form.fastDnsCheck,
      scheduleBatchLimit: form.scheduleBatchLimit,
      probeOnBatchCheck: form.probeOnBatchCheck,
      httpProxyUrl: form.httpProxyUrl.trim(),
      probeRegistrationToken: form.probeRegistrationToken.trim(),
      applyToAllDomains: form.applyToAllDomains,
    });
    ElMessage.success(
      form.applyToAllDomains
        ? "已保存，并已更新全部域名的检测间隔"
        : "配置已保存（修改默认检测间隔时已自动同步全部域名）",
    );
    form.applyToAllDomains = false;
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    saving.value = false;
  }
}

onMounted(load);
</script>

<style scoped>
/* ========== 页面背景 ========== */
.dm-page {
  position: relative;
  padding: 4px;
  min-height: 100vh;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.3;
  animation: floatBlob 25s ease-in-out infinite;
}

.blob-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -150px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -200px;
  left: -150px;
  animation-delay: -8s;
}

.blob-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 20%;
  animation-delay: -16s;
}

@keyframes floatBlob {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(40px, -40px) scale(1.05); }
  66% { transform: translate(-30px, 30px) scale(0.95); }
}

/* ========== 主卡片 ========== */
.main-card {
  position: relative;
  z-index: 1;
  border-radius: 20px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.08);
  overflow: hidden;
}

.main-card :deep(.el-card__header) {
  padding: 20px 24px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  background: transparent;
}

.main-card :deep(.el-card__body) {
  padding: 24px;
}

/* ========== 卡片头部 ========== */
.card-header-custom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  flex-wrap: wrap;
  gap: 12px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.header-icon-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  border-radius: 12px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.header-icon {
  font-size: 22px;
}

.header-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.header-title {
  font-size: 20px;
  font-weight: 700;
  color: #1a1a2e;
  letter-spacing: 0.5px;
}

.header-subtitle {
  font-size: 13px;
  color: #909399;
}

.header-right {
  display: flex;
  align-items: center;
}

.status-tag {
  font-size: 13px;
  padding: 6px 16px;
  border-radius: 20px;
  background: #f0f9f0;
  border-color: #b7eb8f;
  color: #52c41a;
}

.status-tag .el-icon {
  margin-right: 6px;
  animation: pulse-dot 2s infinite;
}

@keyframes pulse-dot {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}

/* ========== 提示 ========== */
.tip-alert {
  margin-bottom: 20px;
  border-radius: 12px;
}

.tip-alert :deep(.el-alert__title) {
  font-weight: 600;
}

/* ========== 配置表单 ========== */
.config-form {
  max-width: 100%;
}

/* 表单区块 */
.form-section {
  margin-bottom: 24px;
  padding: 20px 24px;
  background: linear-gradient(135deg, #f8fafc 0%, #f1f4f9 100%);
  border-radius: 12px;
  border: 1px solid #e8ecf1;
  transition: all 0.2s ease;
}

.form-section:hover {
  border-color: #d0d5dd;
}

.section-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 16px;
}

.section-icon {
  font-size: 20px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #1a1a2e;
}

/* ========== 表单输入 ========== */
.input-group {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px 12px;
  width: 100%;
}

.modern-input-number {
  width: 180px;
}

.modern-input-number :deep(.el-input__wrapper) {
  border-radius: 10px;
  padding: 2px 12px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
}

.modern-input-number :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #667eea;
}

.modern-input-number :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

.modern-input {
  flex: 1;
  min-width: 200px;
}

.modern-input :deep(.el-input__wrapper) {
  border-radius: 10px;
  padding: 2px 14px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
}

.modern-input :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #667eea;
}

.modern-input :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

.modern-select {
  width: 100%;
  max-width: 400px;
}

.modern-select :deep(.el-input__wrapper) {
  border-radius: 10px;
  padding: 2px 12px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
}

.modern-select :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #667eea;
}

.modern-select :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

.hint {
  color: #909399;
  font-size: 13px;
  line-height: 1.4;
}

.block-hint {
  display: block;
  margin-top: 6px;
  margin-left: 0;
  font-size: 12px;
}

/* ========== 代理配置 ========== */
.proxy-group {
  flex-wrap: wrap;
}

.proxy-input {
  flex: 1;
  min-width: 300px;
}

.test-proxy-btn {
  border-radius: 10px;
  padding: 8px 20px;
  font-weight: 500;
  transition: all 0.2s ease;
  border-color: #667eea;
  color: #667eea;
}

.test-proxy-btn:hover {
  background: rgba(102, 126, 234, 0.08);
  transform: translateY(-2px);
}

.test-proxy-btn .el-icon {
  margin-right: 4px;
}

/* ========== 代理测试结果 ========== */
.proxy-result {
  margin-top: 12px;
  border-radius: 10px;
}

.proxy-result :deep(.el-alert__title) {
  font-weight: 600;
}

.result-title {
  font-weight: 600;
}

.proxy-detail {
  margin-top: 8px;
  font-size: 13px;
  line-height: 1.8;
}

.detail-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 4px 0;
}

.detail-label {
  color: #909399;
  min-width: 80px;
  font-size: 12px;
}

.detail-value {
  font-weight: 500;
  color: #1a1a2e;
}

.detail-value.fast {
  color: #67c23a;
}

.detail-value.medium {
  color: #e6a23c;
}

.detail-value.slow {
  color: #f56c6c;
}

.proxy-detail.warn {
  color: #e6a23c;
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 4px;
}

.proxy-hint {
  white-space: pre-line;
  line-height: 1.6;
  color: #606266;
}

.proxy-steps-wrapper {
  margin-top: 8px;
}

.steps-title {
  font-weight: 500;
  color: #606266;
  margin-bottom: 4px;
  font-size: 12px;
}

.proxy-steps {
  margin: 4px 0 0;
  padding-left: 18px;
  list-style: none;
}

.proxy-steps li {
  padding: 2px 0;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
}

.step-name {
  color: #909399;
  min-width: 60px;
}

.step-ok {
  color: #67c23a;
}

.step-fail {
  color: #f56c6c;
}

/* ========== 操作按钮 ========== */
.form-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 16px;
  margin-top: 8px;
  padding-top: 20px;
  border-top: 1px solid #e8ecf1;
}

.actions-left {
  display: flex;
  align-items: center;
}

.actions-right {
  display: flex;
  gap: 12px;
}

.batch-apply-item {
  margin-bottom: 0;
}

.batch-apply-item :deep(.el-form-item__label) {
  display: none;
}

.batch-apply-item :deep(.el-checkbox) {
  font-weight: 500;
  color: #606266;
}

.save-btn {
  padding: 12px 36px;
  border-radius: 10px;
  font-size: 16px;
  font-weight: 600;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.25);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.save-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 24px rgba(102, 126, 234, 0.35);
}

.save-btn .el-icon {
  margin-right: 8px;
  font-size: 18px;
}

.reset-btn {
  padding: 12px 28px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 500;
  transition: all 0.3s ease;
  border: 1px solid #e8ecf1;
}

.reset-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
  border-color: #c0c4cc;
}

.reset-btn .el-icon {
  margin-right: 6px;
}

/* ========== 响应式 ========== */
@media (max-width: 1024px) {
  .form-actions {
    flex-direction: column;
    align-items: stretch;
  }

  .actions-left {
    justify-content: center;
  }

  .actions-right {
    justify-content: center;
  }
}

@media (max-width: 768px) {
  .main-card :deep(.el-card__header) {
    padding: 16px;
  }

  .main-card :deep(.el-card__body) {
    padding: 16px;
  }

  .card-header-custom {
    flex-direction: column;
    align-items: flex-start;
  }

  .header-left {
    width: 100%;
  }

  .header-title {
    font-size: 17px;
  }

  .header-right {
    width: 100%;
  }

  .status-tag {
    width: 100%;
    justify-content: center;
  }

  .form-section {
    padding: 16px;
  }

  .input-group {
    flex-direction: column;
    align-items: stretch;
  }

  .modern-input-number {
    width: 100%;
  }

  .modern-input {
    min-width: auto;
  }

  .proxy-input {
    min-width: auto;
  }

  .modern-select {
    max-width: 100%;
  }

  .test-proxy-btn {
    width: 100%;
    justify-content: center;
  }

  .form-actions {
    flex-direction: column;
    align-items: stretch;
  }

  .save-btn,
  .reset-btn {
    width: 100%;
    justify-content: center;
  }

  .batch-apply-item {
    text-align: center;
  }

  .proxy-steps li {
    flex-wrap: wrap;
  }
}

@media (max-width: 480px) {
  .header-icon-wrapper {
    width: 36px;
    height: 36px;
  }

  .header-icon {
    font-size: 18px;
  }

  .header-title {
    font-size: 15px;
  }

  .header-subtitle {
    font-size: 12px;
  }

  .form-section {
    padding: 12px;
  }

  .section-title {
    font-size: 14px;
  }

  .detail-row {
    flex-wrap: wrap;
    gap: 4px;
  }

  .detail-label {
    min-width: 60px;
  }
}
</style>
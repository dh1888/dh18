<!-- frontend/views/DiagnosticCenter.vue -->
<template>
  <div class="diagnostic-center-page">
    <el-card shadow="never" class="hero-card">
      <div class="page-header">
        <div>
          <div class="title-row">
            <h2>诊断中心</h2>
            <el-button
              link
              type="primary"
              class="guide-trigger"
              title="使用说明"
              @click="guideDialogVisible = true"
            >
              <el-icon><QuestionFilled /></el-icon>
            </el-button>
          </div>
          <p>统一查看 RemoteView 链路状态、实时事件、日志与一键抓取，并管理模块诊断级别。</p>
        </div>
        <div class="header-actions">
          <el-tag v-if="runtime.active" type="success" effect="dark">
            诊断已开启 · {{ runtime.globalLevel }}{{ runtimeExpiresLabel }}
          </el-tag>
          <el-tag v-else type="info">诊断关闭</el-tag>
          <el-button :loading="loading" @click="refreshActiveTab">刷新</el-button>
        </div>
      </div>
    </el-card>

    <el-tabs v-model="activeTab" class="main-tabs" @tab-change="onTabChange">
      <!-- 实时状态 Snapshot -->
      <el-tab-pane label="实时状态" name="snapshot">
        <div v-loading="snapshotLoading" class="tab-body">
          <div class="metric-grid">
            <el-card shadow="hover" class="metric-card">
              <div class="metric-label">WebSocket</div>
              <div class="metric-value">{{ snapshot?.websocket.totalConnections ?? "-" }}</div>
              <div class="metric-sub">
                Agent {{ snapshot?.websocket.agentsOnline ?? 0 }} · Admin
                {{ snapshot?.websocket.adminConnections ?? 0 }}
              </div>
            </el-card>
            <el-card shadow="hover" class="metric-card">
              <div class="metric-label">RemoteView 会话</div>
              <div class="metric-value">{{ snapshot?.remoteView.activeSessions ?? 0 }}</div>
              <div class="metric-sub">
                推流 fresh {{ snapshot?.remoteView.publishingFresh ?? 0 }}
              </div>
            </el-card>
            <el-card shadow="hover" class="metric-card">
              <div class="metric-label">在线 Agent</div>
              <div class="metric-value">{{ snapshot?.agents.length ?? 0 }}</div>
              <div class="metric-sub">
                事件总量 {{ snapshot?.events.totalStored ?? 0 }}
              </div>
            </el-card>
            <el-card shadow="hover" class="metric-card">
              <div class="metric-label">近 5 分钟事件</div>
              <div class="metric-value">{{ eventCount5m }}</div>
              <div class="metric-sub">ERROR {{ snapshot?.events.last5Min?.ERROR ?? 0 }}</div>
            </el-card>
          </div>

          <el-row :gutter="16" class="health-row">
            <el-col :xs="24" :lg="10">
              <el-card shadow="never" header="健康评分">
                <div class="health-score-wrap">
                  <div class="health-score" :class="healthScoreClass(snapshot?.health.score)">
                    {{ snapshot?.health.score ?? "-" }}
                    <span class="health-score-unit">分</span>
                  </div>
                  <div class="health-layers">
                    <div
                      v-for="layer in snapshot?.health.layers ?? []"
                      :key="layer.id"
                      class="health-layer"
                    >
                      <span class="health-dot" :class="`dot-${layer.status}`" />
                      <span>{{ layer.label }}</span>
                    </div>
                  </div>
                </div>
              </el-card>
            </el-col>
            <el-col :xs="24" :lg="14">
              <el-card shadow="never" header="RemoteView 今日统计">
                <div class="stats-today-grid">
                  <div class="stats-today-item">
                    <div class="stats-today-label">启动</div>
                    <div class="stats-today-value">{{ snapshot?.statsToday.remoteViewStarts ?? 0 }}</div>
                  </div>
                  <div class="stats-today-item">
                    <div class="stats-today-label">成功</div>
                    <div class="stats-today-value success">{{ snapshot?.statsToday.remoteViewSuccess ?? 0 }}</div>
                  </div>
                  <div class="stats-today-item">
                    <div class="stats-today-label">失败</div>
                    <div class="stats-today-value danger">{{ snapshot?.statsToday.remoteViewFailures ?? 0 }}</div>
                  </div>
                  <div class="stats-today-item">
                    <div class="stats-today-label">成功率</div>
                    <div class="stats-today-value">{{ formatPercent(snapshot?.statsToday.successRate ?? 0) }}</div>
                  </div>
                </div>
              </el-card>
            </el-col>
          </el-row>

          <el-row :gutter="16">
            <el-col :xs="24" :lg="12">
              <el-card shadow="never" header="活跃 RemoteView 会话">
                <el-table :data="snapshot?.remoteView.sessions ?? []" size="small" stripe>
                  <el-table-column prop="hostname" label="主机" min-width="100" />
                  <el-table-column prop="status" label="状态" width="90" />
                  <el-table-column label="Agent" width="70">
                    <template #default="{ row }">
                      <el-tag :type="row.agentOnline ? 'success' : 'danger'" size="small">
                        {{ row.agentOnline ? "在线" : "离线" }}
                      </el-tag>
                    </template>
                  </el-table-column>
                  <el-table-column label="Stats" width="70">
                    <template #default="{ row }">
                      <el-tag :type="row.statsFresh ? 'success' : 'warning'" size="small">
                        {{ row.statsFresh ? "fresh" : "stale" }}
                      </el-tag>
                    </template>
                  </el-table-column>
                  <el-table-column prop="viewerCount" label="观看" width="60" />
                </el-table>
              </el-card>
            </el-col>
            <el-col :xs="24" :lg="12">
              <el-card shadow="never" header="在线 Agent">
                <el-table :data="snapshot?.agents ?? []" size="small" stripe>
                  <el-table-column prop="hostname" label="主机" min-width="100" />
                  <el-table-column label="推流" width="70">
                    <template #default="{ row }">
                      <el-tag :type="row.publishing ? 'success' : 'info'" size="small">
                        {{ row.publishing ? "是" : "否" }}
                      </el-tag>
                    </template>
                  </el-table-column>
                  <el-table-column prop="sessionStatus" label="会话" width="90" />
                  <el-table-column label="Stats" width="70">
                    <template #default="{ row }">
                      <el-tag :type="row.statsFresh ? 'success' : 'warning'" size="small">
                        {{ row.statsFresh ? "fresh" : "stale" }}
                      </el-tag>
                    </template>
                  </el-table-column>
                </el-table>
              </el-card>
            </el-col>
          </el-row>
          <div v-if="snapshot?.generatedAt" class="generated-at">
            快照时间 {{ formatTime(snapshot.generatedAt) }} · 每 10s 自动刷新
          </div>
        </div>
      </el-tab-pane>

      <!-- 实时事件流 Timeline -->
      <el-tab-pane label="实时事件流" name="timeline">
        <div class="tab-body">
          <div class="toolbar">
            <el-switch v-model="timelinePaused" active-text="暂停" inactive-text="实时" />
            <el-button size="small" @click="clearTimeline">清空</el-button>
            <el-select v-model="timelineFilter.level" clearable placeholder="级别" size="small" style="width: 110px">
              <el-option v-for="level in levels" :key="`tl-${level}`" :label="level" :value="level" />
            </el-select>
            <el-select v-model="timelineFilter.module" clearable placeholder="模块" size="small" style="width: 130px">
              <el-option
                v-for="module in modules"
                :key="`tlm-${module}`"
                :label="diagnosticModuleLabel(module)"
                :value="module"
              />
            </el-select>
          </div>
          <div class="timeline-list">
            <div
              v-for="item in filteredTimeline"
              :key="item.id"
              class="timeline-item"
              :class="`level-${item.level.toLowerCase()}`"
            >
              <span class="timeline-time">{{ formatTime(item.createdAt) }}</span>
              <el-tag size="small" effect="plain">{{ item.source }}</el-tag>
              <el-tag size="small" type="info">{{ diagnosticModuleLabel(item.module) }}</el-tag>
              <el-tag size="small" :type="levelTagType(item.level)">{{ item.level }}</el-tag>
              <span class="timeline-msg">{{ item.message }}</span>
              <span v-if="item.deviceId" class="timeline-device">{{ shortId(item.deviceId) }}</span>
            </div>
            <el-empty v-if="filteredTimeline.length === 0" description="暂无事件，开启诊断后将实时推送" />
          </div>
        </div>
      </el-tab-pane>

      <!-- 日志中心 Logs -->
      <el-tab-pane label="日志中心" name="logs">
        <div class="tab-body">
          <div class="toolbar">
            <el-select v-model="filters.source" clearable placeholder="来源" size="small" style="width: 110px">
              <el-option label="agent" value="agent" />
              <el-option label="frontend" value="frontend" />
              <el-option label="backend" value="backend" />
            </el-select>
            <el-select v-model="filters.module" clearable placeholder="模块" size="small" style="width: 130px">
              <el-option
                v-for="module in modules"
                :key="`f-${module}`"
                :label="diagnosticModuleLabel(module)"
                :value="module"
              />
            </el-select>
            <el-select v-model="filters.level" clearable placeholder="级别" size="small" style="width: 110px">
              <el-option v-for="level in levels" :key="`f-${level}`" :label="level" :value="level" />
            </el-select>
            <el-input
              v-model="filters.deviceId"
              clearable
              placeholder="设备 ID"
              size="small"
              style="width: 220px"
            />
            <el-button size="small" @click="loadEvents">查询</el-button>
            <el-button
              size="small"
              v-permission="'diagnostic:export'"
              :loading="exporting"
              @click="exportBundle"
            >
              导出 ZIP
            </el-button>
          </div>
          <el-table :data="events" v-loading="eventsLoading" stripe size="small">
            <el-table-column prop="createdAt" label="时间" width="170">
              <template #default="{ row }">{{ formatTime(row.createdAt) }}</template>
            </el-table-column>
            <el-table-column prop="source" label="来源" width="80" />
            <el-table-column prop="module" label="模块" width="130">
              <template #default="{ row }">{{ diagnosticModuleLabel(row.module) }}</template>
            </el-table-column>
            <el-table-column prop="level" label="级别" width="80">
              <template #default="{ row }">
                <el-tag size="small" :type="levelTagType(row.level)">{{ row.level }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="message" label="消息" min-width="260" show-overflow-tooltip />
            <el-table-column prop="deviceId" label="设备" width="180" show-overflow-tooltip />
          </el-table>
          <div class="pager">
            <el-pagination
              background
              layout="total, prev, pager, next"
              :total="eventTotal"
              :page-size="pageSize"
              :current-page="page"
              @current-change="onPageChange"
            />
          </div>
        </div>
      </el-tab-pane>

      <!-- Session 聚合 -->
      <el-tab-pane label="Session 聚合" name="sessions">
        <div class="tab-body">
          <div class="toolbar">
            <el-select
              v-model="sessionDeviceFilter"
              clearable
              filterable
              placeholder="全部设备"
              size="small"
              style="width: 280px"
            >
              <el-option
                v-for="device in deviceOptions"
                :key="`s-${device.id}`"
                :label="formatDeviceOptionLabel(device)"
                :value="device.id"
              />
            </el-select>
            <el-button size="small" :loading="sessionsLoading" @click="loadSessions">刷新</el-button>
          </div>
          <el-table :data="sessionGroups" v-loading="sessionsLoading" size="small" stripe @row-click="openSession">
            <el-table-column prop="startedAt" label="开始" width="170">
              <template #default="{ row }">{{ formatTime(row.startedAt) }}</template>
            </el-table-column>
            <el-table-column prop="endedAt" label="结束" width="170">
              <template #default="{ row }">{{ formatTime(row.endedAt) }}</template>
            </el-table-column>
            <el-table-column label="持续" width="80">
              <template #default="{ row }">{{ formatDurationSec(row.durationSec) }}</template>
            </el-table-column>
            <el-table-column prop="status" label="状态" width="90">
              <template #default="{ row }">
                <el-tag :type="row.status === 'failed' ? 'danger' : 'success'" size="small">
                  {{ row.status === "failed" ? "失败" : "成功" }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="reason" label="原因" min-width="180" show-overflow-tooltip />
            <el-table-column prop="eventCount" label="事件" width="70" />
          </el-table>
        </div>
      </el-tab-pane>

      <!-- 一键抓取 Diagnostic Bundle -->
      <el-tab-pane label="一键抓取" name="capture">
        <div class="tab-body capture-panel">
          <el-card shadow="never" class="reproduce-card">
            <template #header>一键复现模式</template>
            <p class="template-desc">开始诊断 → 自动应用模板 → 等待异常 → 到期自动抓取，测试人员无需记步骤。</p>
            <div class="template-actions">
              <el-select
                v-model="reproduceDeviceIds"
                multiple
                filterable
                collapse-tags
                placeholder="选择设备"
                style="width: 100%; max-width: 420px"
              >
                <el-option
                  v-for="device in deviceOptions"
                  :key="`r-${device.id}`"
                  :label="formatDeviceOptionLabel(device)"
                  :value="device.id"
                />
              </el-select>
              <el-input-number v-model="reproduceDuration" :min="5" :max="120" />
              <span class="hint">分钟</span>
              <el-button
                type="warning"
                v-permission="'diagnostic:manage'"
                :loading="reproduceStarting"
                @click="startReproduce"
              >
                开始复现
              </el-button>
            </div>
            <el-alert
              v-if="reproduceJob"
              :title="reproduceJob.message || '复现模式进行中'"
              :type="reproduceJob.active ? 'warning' : 'success'"
              show-icon
              :closable="false"
              class="reproduce-status"
            />
          </el-card>

          <el-form label-width="120px" v-loading="captureLoading">
            <el-form-item label="目标设备">
              <el-select
                v-model="captureForm.deviceIds"
                multiple
                filterable
                collapse-tags
                collapse-tags-tooltip
                placeholder="选择设备（可多选）"
                style="width: 100%; max-width: 520px"
              >
                <el-option
                  v-for="device in deviceOptions"
                  :key="device.id"
                  :label="formatDeviceOptionLabel(device)"
                  :value="device.id"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="事件窗口">
              <el-input-number v-model="captureForm.windowMinutes" :min="5" :max="1440" />
              <span class="hint">分钟</span>
            </el-form-item>
            <el-form-item label="包含内容">
              <el-checkbox v-model="captureForm.includeAgents">Agent 快照</el-checkbox>
              <el-checkbox v-model="captureForm.includeAnalysis">自动分析</el-checkbox>
            </el-form-item>
            <el-form-item>
              <el-button
                type="primary"
                v-permission="'diagnostic:export'"
                :loading="captureLoading"
                @click="runCapture"
              >
                执行抓取
              </el-button>
              <el-button
                v-permission="'diagnostic:export'"
                :loading="captureExporting"
                @click="exportCapture"
              >
                抓取并导出 ZIP
              </el-button>
            </el-form-item>
          </el-form>

          <el-card v-if="captureResult" shadow="never" class="capture-result">
            <template #header>抓取结果 · {{ captureResult.captureId }}</template>
            <el-descriptions :column="3" size="small" border>
              <el-descriptions-item label="时间">
                {{ formatTime(captureResult.generatedAt) }}
              </el-descriptions-item>
              <el-descriptions-item label="事件数">{{ captureResult.eventCount }}</el-descriptions-item>
              <el-descriptions-item label="拓扑数">
                {{ captureResult.pipelines?.length ?? 0 }}
              </el-descriptions-item>
              <el-descriptions-item label="Agent 快照">
                {{ Object.keys(captureResult.agentSnapshots ?? {}).length }}
              </el-descriptions-item>
              <el-descriptions-item label="分析">
                {{ captureResult.analysis?.findings.length ?? 0 }} 条发现
              </el-descriptions-item>
            </el-descriptions>
          </el-card>
        </div>
      </el-tab-pane>

      <!-- 自动分析 Analyzer -->
      <el-tab-pane label="自动分析" name="analyzer">
        <div class="tab-body">
          <div class="toolbar">
            <el-input-number v-model="analyzeWindow" :min="5" :max="1440" size="small" />
            <span class="hint">分钟窗口</span>
            <el-select
              v-model="analyzeDeviceId"
              clearable
              filterable
              placeholder="全部设备"
              size="small"
              style="width: 240px"
            >
              <el-option
                v-for="device in deviceOptions"
                :key="`a-${device.id}`"
                :label="formatDeviceOptionLabel(device)"
                :value="device.id"
              />
            </el-select>
            <el-button size="small" :loading="analyzeLoading" @click="runAnalyze">分析</el-button>
          </div>

          <el-card v-if="analysis?.conclusion" shadow="never" class="conclusion-card">
            <template #header>诊断结论</template>
            <div class="conclusion-title">{{ analysis.conclusion.title }}</div>
            <p><strong>可能原因：</strong>{{ analysis.conclusion.probableCause }}</p>
            <p><strong>可信度：</strong>{{ analysis.conclusion.confidence }}%</p>
            <div class="conclusion-checks">
              <div v-for="(check, idx) in analysis.conclusion.checks" :key="idx" class="conclusion-check">
                <span>{{ check.ok ? "✓" : "✗" }}</span>
                <span>{{ check.label }}</span>
              </div>
            </div>
          </el-card>

          <el-alert
            v-if="analysis"
            :title="analysis.summary"
            type="info"
            show-icon
            :closable="false"
            class="analysis-summary"
          />

          <div v-if="analysis?.findings.length" class="findings-list">
            <el-card
              v-for="(finding, idx) in analysis.findings"
              :key="`${finding.code}-${idx}`"
              shadow="hover"
              class="finding-card"
            >
              <div class="finding-header">
                <el-tag :type="severityTagType(finding.severity)" size="small">
                  {{ finding.severity }}
                </el-tag>
                <strong>{{ finding.title }}</strong>
                <span class="finding-code">{{ finding.code }}</span>
              </div>
              <p>{{ finding.detail }}</p>
              <p v-if="finding.suggestedAction" class="finding-action">
                建议：{{ finding.suggestedAction }}
              </p>
              <div v-if="finding.evidence?.length" class="finding-evidence">
                <span v-for="(ev, i) in finding.evidence" :key="i">{{ ev }}</span>
              </div>
            </el-card>
          </div>
          <el-empty v-else-if="analysis && !analyzeLoading" description="未发现明显异常" />
        </div>
      </el-tab-pane>

      <!-- 配置中心 Log Level -->
      <el-tab-pane label="配置中心" name="config">
        <div class="tab-body">
          <el-card shadow="never" class="template-card">
            <template #header>
              <div class="template-card-header">
                <span>诊断模板</span>
                <el-tag v-if="appliedTemplateId" type="warning" size="small">
                  已应用 · {{ activeTemplateName }}
                </el-tag>
              </div>
            </template>
            <p class="template-desc">
              一键启用场景所需模块，有效期结束后自动恢复默认关闭配置，无需手动逐项设置。
            </p>
            <div class="template-radio-grid">
              <el-radio-group v-model="selectedTemplateId" :disabled="!canManage">
                <el-radio
                  v-for="template in templates"
                  :key="template.id"
                  :label="template.id"
                  class="template-radio"
                >
                  <div class="template-radio-content">
                    <strong>{{ template.name }}</strong>
                    <span>{{ template.description }}</span>
                  </div>
                </el-radio>
              </el-radio-group>
            </div>
            <div class="template-actions">
              <el-input-number
                v-model="templateDurationMinutes"
                :min="5"
                :max="1440"
                :disabled="!canManage"
              />
              <span class="hint">分钟</span>
              <el-button
                type="primary"
                :loading="applyingTemplate"
                v-permission="'diagnostic:manage'"
                :disabled="!selectedTemplateId"
                @click="applyTemplate"
              >
                应用模板
              </el-button>
            </div>
          </el-card>

          <el-form label-width="120px" v-loading="loading" class="config-form">
            <el-form-item label="总开关">
              <el-switch v-model="form.enabled" :disabled="!canManage" />
            </el-form-item>
            <el-form-item label="有效期">
              <el-radio-group v-model="durationPreset" :disabled="!canManage">
                <el-radio-button label="manual">手动关闭</el-radio-button>
                <el-radio-button label="30">30 分钟</el-radio-button>
                <el-radio-button label="60">1 小时</el-radio-button>
                <el-radio-button label="240">4 小时</el-radio-button>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="全局级别">
              <el-select v-model="form.globalLevel" :disabled="!canManage" style="width: 160px">
                <el-option v-for="level in levels" :key="level" :label="level" :value="level" />
              </el-select>
            </el-form-item>
            <el-form-item label="上报开关">
              <el-checkbox v-model="form.agentUploadEnabled" :disabled="!canManage">Agent 上报</el-checkbox>
              <el-checkbox v-model="form.frontendUploadEnabled" :disabled="!canManage">Frontend 上报</el-checkbox>
            </el-form-item>
            <el-form-item label="保留时长">
              <el-input-number v-model="form.retentionHours" :min="1" :max="720" :disabled="!canManage" />
              <span class="hint">小时</span>
            </el-form-item>
            <el-divider>模块级别</el-divider>
            <div class="module-grid">
              <div v-for="module in modules" :key="module" class="module-row">
                <div class="module-name-wrap">
                  <span class="module-name">{{ diagnosticModuleLabel(module) }}</span>
                  <span class="module-key">{{ module }}</span>
                </div>
                <el-select
                  v-model="form.moduleLevels[module]"
                  :disabled="!canManage"
                  size="small"
                  style="width: 140px"
                >
                  <el-option v-for="level in levels" :key="`${module}-${level}`" :label="level" :value="level" />
                </el-select>
              </div>
            </div>
            <el-form-item class="config-actions">
              <el-button
                type="primary"
                :loading="saving"
                v-permission="'diagnostic:manage'"
                @click="saveConfig"
              >
                保存并下发
              </el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-tab-pane>

      <!-- 状态拓扑 Pipeline -->
      <el-tab-pane label="状态拓扑" name="pipeline">
        <div class="tab-body">
          <div class="toolbar">
            <el-select
              v-model="pipelineDeviceId"
              filterable
              placeholder="选择设备"
              size="small"
              style="width: 280px"
            >
              <el-option
                v-for="device in deviceOptions"
                :key="`p-${device.id}`"
                :label="formatDeviceOptionLabel(device)"
                :value="device.id"
              />
            </el-select>
            <el-button size="small" :loading="pipelineLoading" @click="loadPipeline">加载拓扑</el-button>
          </div>

          <div v-if="pipeline" v-loading="pipelineLoading" class="pipeline-wrap">
            <div class="pipeline-meta">
              <el-tag :type="pipelineStatusTag(pipeline.overallStatus)">
                {{ pipeline.overallStatus }}
              </el-tag>
              <span>{{ formatDeviceOptionLabel(selectedPipelineDevice ?? { id: pipeline.deviceId, hostname: pipeline.hostname }) }}</span>
              <span v-if="pipeline.sessionId">session {{ shortId(pipeline.sessionId) }}</span>
            </div>
            <div class="pipeline-flow">
              <template v-for="(node, index) in pipeline.nodes" :key="node.id">
                <div class="pipeline-node clickable" :class="`status-${node.status}`" @click="openPipelineNode(node)">
                  <div class="node-label">{{ node.label }}</div>
                  <div class="node-status">{{ node.status }}</div>
                  <div class="node-detail">{{ node.detail }}</div>
                </div>
                <div v-if="index < pipeline.nodes.length - 1" class="pipeline-arrow">→</div>
              </template>
            </div>
          </div>
          <el-empty v-else description="选择设备后加载 RemoteView 链路拓扑" />
        </div>
      </el-tab-pane>
    </el-tabs>

    <el-dialog
      v-model="guideDialogVisible"
      title="诊断中心使用说明"
      width="680px"
      class="diagnostic-guide-dialog"
    >
      <div class="guide-content">
        <el-alert
          type="info"
          show-icon
          :closable="false"
          title="诊断中心默认关闭。需在「配置中心」打开总开关、设置级别并保存下发后，Agent 与 Frontend 才会开始上报诊断日志。"
        />

        <section class="guide-section">
          <h4>功能模块</h4>
          <ul class="guide-list">
            <li>
              <strong>实时状态：</strong>每 10 秒刷新系统快照，查看 WebSocket 连接、RemoteView 会话、在线 Agent 与近 5 分钟事件统计。
            </li>
            <li>
              <strong>实时事件流：</strong>通过 WebSocket 实时推送 WARN / ERROR 事件（可暂停、过滤、清空）；INFO 及以上级别请至「日志中心」查询。
            </li>
            <li>
              <strong>日志中心：</strong>分页检索历史诊断事件，支持按来源、模块、级别、设备筛选，并可导出 ZIP 诊断包。
            </li>
            <li>
              <strong>一键抓取：</strong>选择在线设备，批量采集快照、事件、拓扑与 Agent 侧状态，支持直接导出 ZIP（需 <code>diagnostic:export</code> 权限）。
            </li>
            <li>
              <strong>自动分析：</strong>基于规则分析近 N 分钟事件，识别 dead frame、Ingress 频繁变更、FFmpeg 强制 Kill、stats 过期等异常。
            </li>
            <li>
              <strong>配置中心：</strong>支持「诊断模板」一键启用场景模块，或手动管理总开关、有效期与模块日志级别，保存后经 WebSocket 下发。
            </li>
            <li>
              <strong>状态拓扑：</strong>选择设备后展示 Agent → Capture → FFmpeg → WHIP → Ingress → LiveKit → Frontend 链路各节点健康状态。
            </li>
          </ul>
        </section>

        <section class="guide-section">
          <h4>配置说明</h4>
          <ul class="guide-list">
            <li>推荐使用「RemoteView 诊断模板」排查远程桌面问题，系统会自动启用所需模块。</li>
            <li>模板有效期结束后，系统自动恢复默认关闭配置，无需手动还原。</li>
            <li>新增诊断模块时，模板定义在后端集中维护，无需修改使用说明。</li>
          </ul>
        </section>

        <section class="guide-section">
          <h4>权限要求</h4>
          <ul class="guide-list">
            <li><code>diagnostic:view</code> — 查看诊断中心、快照、分析、拓扑</li>
            <li><code>diagnostic:manage</code> — 修改配置并下发</li>
            <li><code>diagnostic:export</code> — 导出诊断包 / 一键抓取</li>
          </ul>
        </section>

        <section class="guide-section">
          <h4>使用建议</h4>
          <ul class="guide-list">
            <li>
              排查 RemoteView 问题时，推荐直接使用「RemoteView 诊断模板」。系统会自动启用所需模块并在有效期结束后自动恢复默认配置，无需手动逐项设置。
            </li>
            <li>设备下拉显示「员工姓名 · 主机名」，仅列出当前在线设备。</li>
            <li>生产环境建议按需短时开启，问题定位完成后及时关闭或等待有效期到期。</li>
          </ul>
        </section>
      </div>
      <template #footer>
        <el-button type="primary" @click="guideDialogVisible = false">知道了</el-button>
      </template>
    </el-dialog>

    <el-drawer v-model="pipelineNodeDrawer" :title="selectedPipelineNode?.label || '节点详情'" size="420px">
      <div v-if="selectedPipelineNode">
        <el-tag :type="pipelineStatusTag(selectedPipelineNode.status)">{{ selectedPipelineNode.status }}</el-tag>
        <p class="node-drawer-detail">{{ selectedPipelineNode.detail }}</p>
        <el-descriptions v-if="selectedPipelineNode.metrics" :column="1" size="small" border class="node-metrics">
          <el-descriptions-item
            v-for="(value, key) in selectedPipelineNode.metrics"
            :key="String(key)"
            :label="String(key)"
          >
            {{ value }}
          </el-descriptions-item>
        </el-descriptions>
        <h4>最近日志</h4>
        <div v-for="(log, idx) in selectedPipelineNode.recentLogs ?? []" :key="`l-${idx}`" class="node-log-item">
          <span class="timeline-time">{{ formatTime(log.createdAt) }}</span>
          <el-tag size="small">{{ log.level }}</el-tag>
          <span>{{ log.message }}</span>
        </div>
        <h4 v-if="selectedPipelineNode.recentErrors?.length">最近错误</h4>
        <div v-for="(log, idx) in selectedPipelineNode.recentErrors ?? []" :key="`e-${idx}`" class="node-log-item error">
          <span class="timeline-time">{{ formatTime(log.createdAt) }}</span>
          <span>{{ log.message }}</span>
        </div>
      </div>
    </el-drawer>

    <el-drawer v-model="sessionDrawer" title="Session Timeline" size="520px">
      <div v-if="activeSession">
        <el-descriptions :column="1" size="small" border>
          <el-descriptions-item label="Session">{{ activeSession.sessionId }}</el-descriptions-item>
          <el-descriptions-item label="开始">{{ formatTime(activeSession.startedAt) }}</el-descriptions-item>
          <el-descriptions-item label="结束">{{ formatTime(activeSession.endedAt) }}</el-descriptions-item>
          <el-descriptions-item label="持续">{{ formatDurationSec(activeSession.durationSec) }}</el-descriptions-item>
          <el-descriptions-item label="状态">{{ activeSession.status }}</el-descriptions-item>
          <el-descriptions-item v-if="activeSession.reason" label="原因">{{ activeSession.reason }}</el-descriptions-item>
        </el-descriptions>
        <div class="timeline-list session-timeline">
          <div v-for="item in activeSession.events ?? []" :key="`${item.createdAt}-${item.message}`" class="timeline-item">
            <span class="timeline-time">{{ formatTime(item.createdAt) }}</span>
            <el-tag size="small">{{ item.level }}</el-tag>
            <span class="timeline-msg">{{ item.message }}</span>
          </div>
        </div>
      </div>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, reactive, ref, watch } from "vue";
import { ElMessage } from "element-plus";
import { QuestionFilled } from "@element-plus/icons-vue";
import {
  deviceApi,
  diagnosticApi,
  type DiagnosticAnalysis,
  type DiagnosticCaptureResult,
  type DiagnosticLevelName,
  type DiagnosticPipeline,
  type DiagnosticPipelineNode,
  type DiagnosticReproduceStatus,
  type DiagnosticSessionGroup,
  type DiagnosticSnapshot,
} from "@api/index";
import { useUserStore } from "@store/user";
import { applyDiagnosticRuntime, diagnosticModuleLabel } from "@/utils/diagnosticCenter";
import { useDiagnosticTimeline } from "@/composables/useDiagnosticTimeline";

const userStore = useUserStore();
const canManage = computed(() => userStore.hasPermission("diagnostic:manage"));

const activeTab = ref("snapshot");
const guideDialogVisible = ref(false);
const loading = ref(false);
const saving = ref(false);
const exporting = ref(false);
const eventsLoading = ref(false);
const snapshotLoading = ref(false);
const analyzeLoading = ref(false);
const pipelineLoading = ref(false);
const captureLoading = ref(false);
const captureExporting = ref(false);
const applyingTemplate = ref(false);
const sessionsLoading = ref(false);
const reproduceStarting = ref(false);

const templates = ref<
  Array<{
    id: string;
    name: string;
    description: string;
    defaultDurationMinutes: number;
  }>
>([]);
const selectedTemplateId = ref("remote-view");
const templateDurationMinutes = ref(60);
const appliedTemplateId = ref("");

const sessionGroups = ref<DiagnosticSessionGroup[]>([]);
const sessionDeviceFilter = ref("");
const sessionDrawer = ref(false);
const activeSession = ref<DiagnosticSessionGroup | null>(null);

const pipelineNodeDrawer = ref(false);
const selectedPipelineNode = ref<DiagnosticPipelineNode | null>(null);

const reproduceDeviceIds = ref<string[]>([]);
const reproduceDuration = ref(30);
const reproduceJob = ref<DiagnosticReproduceStatus | null>(null);
let reproducePollTimer: number | null = null;

const modules = ref<string[]>([]);
const levels = ref<DiagnosticLevelName[]>(["OFF", "ERROR", "WARN", "INFO", "DEBUG", "TRACE"]);

const runtime = reactive({
  active: false,
  globalLevel: "OFF" as DiagnosticLevelName,
  expiresAt: null as string | null,
});

const durationPreset = ref("manual");
const form = reactive({
  enabled: false,
  globalLevel: "INFO" as DiagnosticLevelName,
  moduleLevels: {} as Record<string, DiagnosticLevelName>,
  agentUploadEnabled: true,
  frontendUploadEnabled: true,
  retentionHours: 72,
});

const filters = reactive({
  source: "",
  module: "",
  level: "",
  deviceId: "",
});

const events = ref<
  Array<{
    id: string;
    source: string;
    deviceId?: string;
    module: string;
    level: string;
    message: string;
    createdAt: string;
  }>
>([]);
const eventTotal = ref(0);
const page = ref(1);
const pageSize = 20;

const snapshot = ref<DiagnosticSnapshot | null>(null);
const analysis = ref<DiagnosticAnalysis | null>(null);
const pipeline = ref<DiagnosticPipeline | null>(null);
const captureResult = ref<DiagnosticCaptureResult | null>(null);

const analyzeWindow = ref(30);
const analyzeDeviceId = ref("");
const pipelineDeviceId = ref("");

const deviceOptions = ref<
  Array<{
    id: string;
    hostname?: string;
    status?: string;
    employeeName?: string;
    employeeNumber?: string;
  }>
>([]);

const formatDeviceOptionLabel = (device: (typeof deviceOptions.value)[number]) => {
  const host = device.hostname || device.id;
  const statusSuffix = device.status ? ` (${device.status})` : "";
  const name = device.employeeName?.trim();
  if (name) {
    const number = device.employeeNumber?.trim();
    const person = number ? `${name}（${number}）` : name;
    return `${person} · ${host}${statusSuffix}`;
  }
  return `${host}${statusSuffix}`;
};

const selectedPipelineDevice = computed(() =>
  deviceOptions.value.find((d) => d.id === pipelineDeviceId.value),
);

const captureForm = reactive({
  deviceIds: [] as string[],
  windowMinutes: 30,
  includeAgents: true,
  includeAnalysis: true,
});

const { liveEvents, paused: timelinePaused, mergeEvents, clearEvents } = useDiagnosticTimeline();

const timelineFilter = reactive({
  level: "",
  module: "",
});

let snapshotTimer: number | null = null;

const runtimeExpiresLabel = computed(() => {
  if (!runtime.expiresAt) return "";
  return ` · 到期 ${formatTime(runtime.expiresAt)}`;
});

const eventCount5m = computed(() => {
  const map = snapshot.value?.events.last5Min ?? {};
  return Object.values(map).reduce((sum, n) => sum + n, 0);
});

const activeTemplateName = computed(() => {
  const tmpl = templates.value.find((t) => t.id === appliedTemplateId.value);
  return tmpl?.name ?? appliedTemplateId.value;
});

const filteredTimeline = computed(() => {
  return liveEvents.value.filter((item) => {
    if (timelineFilter.level && item.level !== timelineFilter.level) return false;
    if (timelineFilter.module && item.module !== timelineFilter.module) return false;
    return true;
  });
});

const formatTime = (value?: string | null) => {
  if (!value) return "-";
  return new Date(value).toLocaleString();
};

const formatPercent = (value: number) => `${value.toFixed(1)}%`;

const formatDurationSec = (sec?: number) => {
  if (!sec || sec <= 0) return "-";
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return m > 0 ? `${m}分${s}秒` : `${s}秒`;
};

const healthScoreClass = (score?: number) => {
  if (score == null) return "";
  if (score >= 90) return "score-good";
  if (score >= 70) return "score-warn";
  return "score-bad";
};

const shortId = (value: string) => (value.length > 12 ? `${value.slice(0, 8)}…` : value);

const levelTagType = (level: string) => {
  if (level === "ERROR") return "danger";
  if (level === "WARN") return "warning";
  if (level === "DEBUG" || level === "TRACE") return "info";
  return "success";
};

const severityTagType = (severity: string) => {
  if (severity === "critical") return "danger";
  if (severity === "warning") return "warning";
  return "info";
};

const pipelineStatusTag = (status: string) => {
  if (status === "healthy") return "success";
  if (status === "degraded") return "warning";
  if (status === "down") return "danger";
  return "info";
};

const loadConfig = async () => {
  const { data } = await diagnosticApi.getConfig();
  modules.value = data.modules;
  levels.value = data.levels;
  form.enabled = data.config.enabled;
  form.globalLevel = data.config.globalLevel;
  form.agentUploadEnabled = data.config.agentUploadEnabled;
  form.frontendUploadEnabled = data.config.frontendUploadEnabled;
  form.retentionHours = data.config.retentionHours;
  form.moduleLevels = { ...data.config.moduleLevels };
  for (const module of data.modules) {
    if (!form.moduleLevels[module]) form.moduleLevels[module] = data.config.globalLevel;
  }
  runtime.active = data.runtime.active;
  runtime.globalLevel = data.runtime.globalLevel;
  runtime.expiresAt = data.runtime.expiresAt ?? null;
  appliedTemplateId.value = data.config.appliedTemplateId ?? "";
  applyDiagnosticRuntime(data.runtime);
};

const loadTemplates = async () => {
  try {
    const { data } = await diagnosticApi.listTemplates();
    templates.value = data.items ?? [];
    if (!selectedTemplateId.value && templates.value.length) {
      selectedTemplateId.value = templates.value[0].id;
    }
    const selected = templates.value.find((t) => t.id === selectedTemplateId.value);
    if (selected) {
      templateDurationMinutes.value = selected.defaultDurationMinutes;
    }
  } catch {
    templates.value = [];
  }
};

const applyTemplate = async () => {
  if (!selectedTemplateId.value || !canManage.value) return;
  applyingTemplate.value = true;
  try {
    const { data } = await diagnosticApi.applyTemplate({
      templateId: selectedTemplateId.value,
      durationMinutes: templateDurationMinutes.value,
    });
    form.enabled = data.config.enabled;
    form.globalLevel = data.config.globalLevel;
    form.moduleLevels = { ...data.config.moduleLevels };
    appliedTemplateId.value = data.config.appliedTemplateId ?? "";
    runtime.active = data.runtime.active;
    runtime.globalLevel = data.runtime.globalLevel;
    runtime.expiresAt = data.runtime.expiresAt ?? null;
    durationPreset.value = "manual";
    applyDiagnosticRuntime(data.runtime);
    ElMessage.success(`已应用「${activeTemplateName.value}」模板`);
    await loadEvents();
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "应用模板失败");
  } finally {
    applyingTemplate.value = false;
  }
};

const loadEvents = async () => {
  eventsLoading.value = true;
  try {
    const { data } = await diagnosticApi.listEvents({
      page: page.value,
      pageSize,
      source: filters.source || undefined,
      module: filters.module || undefined,
      level: filters.level || undefined,
      deviceId: filters.deviceId || undefined,
    });
    events.value = data.items;
    eventTotal.value = data.total;
  } finally {
    eventsLoading.value = false;
  }
};

const loadSnapshot = async () => {
  snapshotLoading.value = true;
  try {
    const { data } = await diagnosticApi.getSnapshot();
    snapshot.value = data;
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "快照加载失败");
  } finally {
    snapshotLoading.value = false;
  }
};

const loadTimelineSeed = async () => {
  try {
    const { data } = await diagnosticApi.listEvents({ page: 1, pageSize: 80 });
    mergeEvents(data.items);
  } catch {
    // ignore seed errors
  }
};

const loadDevices = async () => {
  try {
    const { data } = await deviceApi.listAll({ deviceStatus: "online" });
    deviceOptions.value = (data.items ?? []).map((d) => ({
      id: d.id,
      hostname: d.hostname,
      status: d.status,
      employeeName: d.employeeName,
      employeeNumber: d.employeeNumber,
    }));
    if (!pipelineDeviceId.value && deviceOptions.value.length) {
      pipelineDeviceId.value = deviceOptions.value[0].id;
    }
  } catch {
    deviceOptions.value = [];
  }
};

const runAnalyze = async () => {
  analyzeLoading.value = true;
  try {
    const { data } = await diagnosticApi.analyze({
      windowMinutes: analyzeWindow.value,
      deviceId: analyzeDeviceId.value || undefined,
    });
    analysis.value = data;
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "分析失败");
  } finally {
    analyzeLoading.value = false;
  }
};

const loadPipeline = async () => {
  if (!pipelineDeviceId.value) {
    ElMessage.warning("请先选择设备");
    return;
  }
  pipelineLoading.value = true;
  try {
    const { data } = await diagnosticApi.getPipeline(pipelineDeviceId.value);
    pipeline.value = data;
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "拓扑加载失败");
  } finally {
    pipelineLoading.value = false;
  }
};

const openPipelineNode = async (node: DiagnosticPipelineNode) => {
  if (!pipelineDeviceId.value) return;
  try {
    const { data } = await diagnosticApi.getPipelineNode(pipelineDeviceId.value, node.id);
    selectedPipelineNode.value = data;
    pipelineNodeDrawer.value = true;
  } catch {
    selectedPipelineNode.value = node;
    pipelineNodeDrawer.value = true;
  }
};

const loadSessions = async () => {
  sessionsLoading.value = true;
  try {
    const { data } = await diagnosticApi.listSessions({
      deviceId: sessionDeviceFilter.value || undefined,
    });
    sessionGroups.value = data.items ?? [];
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "Session 加载失败");
  } finally {
    sessionsLoading.value = false;
  }
};

const openSession = async (row: DiagnosticSessionGroup) => {
  try {
    const { data } = await diagnosticApi.getSession(row.sessionId);
    activeSession.value = data;
    sessionDrawer.value = true;
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "Session 详情加载失败");
  }
};

const startReproduce = async () => {
  if (!reproduceDeviceIds.value.length) {
    ElMessage.warning("请选择设备");
    return;
  }
  reproduceStarting.value = true;
  try {
    const { data } = await diagnosticApi.startReproduce({
      templateId: selectedTemplateId.value || "remote-view",
      deviceIds: reproduceDeviceIds.value,
      durationMinutes: reproduceDuration.value,
      autoCapture: true,
    });
    reproduceJob.value = data;
    appliedTemplateId.value = data.templateId;
    runtime.active = true;
    ElMessage.success("复现模式已启动");
    startReproducePolling(data.jobId);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "启动复现失败");
  } finally {
    reproduceStarting.value = false;
  }
};

const startReproducePolling = (jobId: string) => {
  stopReproducePolling();
  reproducePollTimer = window.setInterval(async () => {
    try {
      const { data } = await diagnosticApi.getReproduceStatus(jobId);
      reproduceJob.value = data;
      if (!data.active) {
        stopReproducePolling();
        if (data.captureReady) ElMessage.success("自动抓取已完成");
      }
    } catch {
      stopReproducePolling();
    }
  }, 5000);
};

const stopReproducePolling = () => {
  if (reproducePollTimer != null) {
    clearInterval(reproducePollTimer);
    reproducePollTimer = null;
  }
};

const runCapture = async () => {
  if (!captureForm.deviceIds.length) {
    ElMessage.warning("请至少选择一个设备");
    return;
  }
  captureLoading.value = true;
  try {
    const { data } = await diagnosticApi.capture({
      deviceIds: captureForm.deviceIds,
      windowMinutes: captureForm.windowMinutes,
      includeAgents: captureForm.includeAgents,
      includeAnalysis: captureForm.includeAnalysis,
    });
    captureResult.value = data;
    ElMessage.success("抓取完成");
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "抓取失败");
  } finally {
    captureLoading.value = false;
  }
};

const exportCapture = async () => {
  if (!captureForm.deviceIds.length) {
    ElMessage.warning("请至少选择一个设备");
    return;
  }
  captureExporting.value = true;
  try {
    const { data } = await diagnosticApi.captureExport({
      deviceIds: captureForm.deviceIds,
      windowMinutes: captureForm.windowMinutes,
      includeAgents: captureForm.includeAgents,
      includeAnalysis: captureForm.includeAnalysis,
    });
    downloadBlob(data, `diagnostic-capture-${Date.now()}.zip`);
    ElMessage.success("抓取包已开始下载");
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "导出失败");
  } finally {
    captureExporting.value = false;
  }
};

const downloadBlob = (data: Blob | unknown, filename: string) => {
  const blob = data instanceof Blob ? data : new Blob([data as BlobPart]);
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
};

const loadAll = async () => {
  loading.value = true;
  try {
    await Promise.all([loadConfig(), loadEvents(), loadDevices(), loadTemplates()]);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "加载失败");
  } finally {
    loading.value = false;
  }
};

const saveConfig = async () => {
  if (!canManage.value) return;
  saving.value = true;
  try {
    const payload: Parameters<typeof diagnosticApi.updateConfig>[0] = {
      enabled: form.enabled,
      globalLevel: form.globalLevel,
      moduleLevels: form.moduleLevels,
      agentUploadEnabled: form.agentUploadEnabled,
      frontendUploadEnabled: form.frontendUploadEnabled,
      retentionHours: form.retentionHours,
    };
    if (durationPreset.value !== "manual") {
      payload.durationMinutes = Number(durationPreset.value);
    }
    const { data } = await diagnosticApi.updateConfig(payload);
    runtime.active = data.runtime.active;
    runtime.globalLevel = data.runtime.globalLevel;
    runtime.expiresAt = data.runtime.expiresAt ?? null;
    applyDiagnosticRuntime(data.runtime);
    ElMessage.success("诊断配置已保存并下发");
    await loadEvents();
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "保存失败");
  } finally {
    saving.value = false;
  }
};

const exportBundle = async () => {
  exporting.value = true;
  try {
    const { data } = await diagnosticApi.exportBundle({
      source: filters.source || undefined,
      module: filters.module || undefined,
      level: filters.level || undefined,
      deviceId: filters.deviceId || undefined,
    });
    downloadBlob(data, `diagnostic-bundle-${Date.now()}.zip`);
    ElMessage.success("诊断包已开始下载");
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : "导出失败");
  } finally {
    exporting.value = false;
  }
};

const onPageChange = (next: number) => {
  page.value = next;
  void loadEvents();
};

const clearTimeline = () => clearEvents();

const refreshActiveTab = async () => {
  if (activeTab.value === "snapshot") await loadSnapshot();
  else if (activeTab.value === "timeline") await loadTimelineSeed();
  else if (activeTab.value === "logs") await loadEvents();
  else if (activeTab.value === "analyzer") await runAnalyze();
  else if (activeTab.value === "pipeline") await loadPipeline();
  else if (activeTab.value === "sessions") await loadSessions();
  else if (activeTab.value === "config") await loadConfig();
  else await loadAll();
};

const onTabChange = (name: string | number) => {
  if (name === "snapshot") void loadSnapshot();
  if (name === "timeline") void loadTimelineSeed();
  if (name === "analyzer" && !analysis.value) void runAnalyze();
  if (name === "pipeline" && pipelineDeviceId.value && !pipeline.value) void loadPipeline();
  if (name === "sessions") void loadSessions();
};

const startSnapshotPolling = () => {
  if (snapshotTimer != null) return;
  snapshotTimer = window.setInterval(() => {
    if (activeTab.value === "snapshot") void loadSnapshot();
  }, 10_000);
};

const stopSnapshotPolling = () => {
  if (snapshotTimer != null) {
    clearInterval(snapshotTimer);
    snapshotTimer = null;
  }
};

watch(selectedTemplateId, (id) => {
  const selected = templates.value.find((t) => t.id === id);
  if (selected) templateDurationMinutes.value = selected.defaultDurationMinutes;
});

watch(activeTab, (tab) => {
  if (tab === "snapshot") {
    void loadSnapshot();
    startSnapshotPolling();
  } else {
    stopSnapshotPolling();
  }
});

onMounted(() => {
  void loadAll();
  void loadSnapshot();
  void loadTimelineSeed();
  startSnapshotPolling();
});

onUnmounted(() => {
  stopSnapshotPolling();
  stopReproducePolling();
});
</script>

<style scoped>
.diagnostic-center-page {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.hero-card :deep(.el-card__body) {
  padding: 16px 20px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  align-items: flex-start;
}

.page-header h2 {
  margin: 0;
}

.title-row {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-bottom: 6px;
}

.guide-trigger {
  padding: 0 4px;
  font-size: 18px;
}

.guide-content {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.guide-section h4 {
  margin: 0 0 8px;
  font-size: 14px;
  color: var(--el-text-color-primary);
}

.guide-list {
  margin: 0;
  padding-left: 20px;
  line-height: 1.75;
  color: var(--el-text-color-regular);
}

.guide-list li + li {
  margin-top: 6px;
}

.guide-list code {
  padding: 1px 5px;
  border-radius: 4px;
  background: var(--el-fill-color-light);
  font-size: 12px;
}

.page-header p {
  margin: 0;
  color: var(--el-text-color-secondary);
  font-size: 13px;
}

.header-actions {
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
}

.main-tabs :deep(.el-tabs__content) {
  padding-top: 8px;
}

.tab-body {
  min-height: 360px;
}

.toolbar {
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
  margin-bottom: 12px;
}

.metric-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 12px;
  margin-bottom: 16px;
}

.metric-card :deep(.el-card__body) {
  padding: 14px 16px;
}

.metric-label {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.metric-value {
  font-size: 28px;
  font-weight: 600;
  line-height: 1.2;
  margin: 4px 0;
}

.metric-sub {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.generated-at {
  margin-top: 12px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.timeline-list {
  max-height: 520px;
  overflow: auto;
  border: 1px solid var(--el-border-color-light);
  border-radius: 8px;
}

.timeline-item {
  display: flex;
  gap: 8px;
  align-items: center;
  padding: 8px 12px;
  border-bottom: 1px solid var(--el-border-color-lighter);
  font-size: 13px;
}

.timeline-item.level-error {
  background: color-mix(in srgb, var(--el-color-danger) 8%, transparent);
}

.timeline-item.level-warn {
  background: color-mix(in srgb, var(--el-color-warning) 8%, transparent);
}

.timeline-time {
  color: var(--el-text-color-secondary);
  white-space: nowrap;
  font-size: 12px;
}

.timeline-msg {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.timeline-device {
  font-size: 11px;
  color: var(--el-text-color-secondary);
}

.pager {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}

.module-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 12px;
}

.module-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  border: 1px solid var(--el-border-color-light);
  border-radius: 8px;
}

.module-name-wrap {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.module-name {
  font-weight: 500;
}

.module-key {
  font-size: 11px;
  color: var(--el-text-color-secondary);
  font-family: ui-monospace, monospace;
}

.hint {
  margin-left: 8px;
  color: var(--el-text-color-secondary);
}

.config-form {
  margin-top: 16px;
}

.template-radio-grid {
  margin-bottom: 12px;
}

.template-radio {
  display: flex;
  align-items: flex-start;
  margin-right: 0;
  margin-bottom: 8px;
  width: 100%;
  height: auto;
  white-space: normal;
}

.template-radio-content {
  display: flex;
  flex-direction: column;
  gap: 2px;
  line-height: 1.4;
}

.template-radio-content span {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.health-row {
  margin-bottom: 16px;
}

.health-score-wrap {
  display: flex;
  gap: 16px;
  align-items: center;
}

.health-score {
  font-size: 42px;
  font-weight: 700;
  line-height: 1;
}

.health-score-unit {
  font-size: 16px;
  font-weight: 500;
}

.score-good {
  color: var(--el-color-success);
}

.score-warn {
  color: var(--el-color-warning);
}

.score-bad {
  color: var(--el-color-danger);
}

.health-layers {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 12px;
}

.health-layer {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
}

.health-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--el-text-color-secondary);
}

.health-dot.dot-healthy {
  background: var(--el-color-success);
}

.health-dot.dot-degraded {
  background: var(--el-color-warning);
}

.health-dot.dot-down {
  background: var(--el-color-danger);
}

.stats-today-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
}

.stats-today-item {
  text-align: center;
}

.stats-today-label {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.stats-today-value {
  font-size: 24px;
  font-weight: 600;
}

.stats-today-value.success {
  color: var(--el-color-success);
}

.stats-today-value.danger {
  color: var(--el-color-danger);
}

.conclusion-card {
  margin-bottom: 12px;
}

.conclusion-title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 8px;
}

.conclusion-checks {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 6px;
  margin-top: 10px;
}

.conclusion-check {
  display: flex;
  gap: 6px;
  font-size: 13px;
}

.reproduce-card {
  margin-bottom: 16px;
}

.reproduce-status {
  margin-top: 12px;
}

.pipeline-node.clickable {
  cursor: pointer;
}

.pipeline-node.clickable:hover {
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
}

.node-drawer-detail {
  margin: 10px 0;
}

.node-metrics {
  margin-bottom: 12px;
}

.node-log-item {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  padding: 6px 0;
  border-bottom: 1px solid var(--el-border-color-lighter);
  font-size: 12px;
}

.node-log-item.error {
  color: var(--el-color-danger);
}

.session-timeline {
  margin-top: 12px;
  max-height: 420px;
}

.template-card {
  margin-bottom: 4px;
}

.template-card-header {
  display: flex;
  align-items: center;
  gap: 8px;
}

.template-desc {
  margin: 0 0 12px;
  color: var(--el-text-color-secondary);
  font-size: 13px;
}

.template-actions {
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
}

.template-option {
  display: flex;
  flex-direction: column;
  line-height: 1.4;
}

.template-option-desc {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.config-actions {
  margin-top: 16px;
}

.capture-panel {
  max-width: 640px;
}

.capture-result {
  margin-top: 16px;
}

.analysis-summary {
  margin-bottom: 12px;
}

.findings-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.finding-card :deep(.el-card__body) {
  padding: 12px 16px;
}

.finding-header {
  display: flex;
  gap: 8px;
  align-items: center;
  margin-bottom: 6px;
}

.finding-code {
  margin-left: auto;
  font-size: 11px;
  color: var(--el-text-color-secondary);
}

.finding-action {
  margin: 6px 0 0;
  font-size: 13px;
  color: var(--el-color-primary);
}

.finding-evidence {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-top: 6px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.pipeline-wrap {
  margin-top: 8px;
}

.pipeline-meta {
  display: flex;
  gap: 12px;
  align-items: center;
  margin-bottom: 16px;
  font-size: 13px;
}

.pipeline-flow {
  display: flex;
  align-items: stretch;
  gap: 6px;
  overflow-x: auto;
  padding-bottom: 8px;
}

.pipeline-node {
  min-width: 120px;
  max-width: 160px;
  padding: 12px;
  border-radius: 10px;
  border: 2px solid var(--el-border-color);
  background: var(--el-fill-color-blank);
}

.pipeline-node.status-healthy {
  border-color: var(--el-color-success);
}

.pipeline-node.status-degraded {
  border-color: var(--el-color-warning);
}

.pipeline-node.status-down {
  border-color: var(--el-color-danger);
}

.pipeline-node.status-unknown {
  border-color: var(--el-border-color);
}

.node-label {
  font-weight: 600;
  margin-bottom: 4px;
}

.node-status {
  font-size: 11px;
  text-transform: uppercase;
  color: var(--el-text-color-secondary);
}

.node-detail {
  margin-top: 6px;
  font-size: 12px;
  line-height: 1.4;
  color: var(--el-text-color-regular);
}

.pipeline-arrow {
  align-self: center;
  color: var(--el-text-color-secondary);
  font-size: 18px;
}
</style>

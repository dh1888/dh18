<template>
  <div class="cs-tool-settings-page" v-loading="loading">
    <section class="hero-card">
      <div class="hero-left">
        <div class="hero-icon">
          <el-icon><Service /></el-icon>
        </div>
        <div>
          <h1>客服工具地址配置</h1>
          <p>配置「客服工具」「客服话术」菜单在浏览器新标签页中打开的跳转地址。</p>
          <div class="hero-meta" v-if="updatedAt">
            <el-icon><Clock /></el-icon>
            <span>最后更新：{{ formatUpdatedAt(updatedAt) }}</span>
          </div>
        </div>
      </div>
      <div class="hero-actions">
        <el-button @click="loadSettings" :loading="loading">
          <el-icon><Refresh /></el-icon>
          刷新
        </el-button>
        <el-button
          v-permission="'cstool:settings'"
          type="primary"
          :loading="saving"
          @click="saveSettings"
        >
          <el-icon><Check /></el-icon>
          保存设置
        </el-button>
      </div>
    </section>

    <el-card class="panel-card" shadow="never">
      <template #header>
        <div class="panel-header">
          <span class="panel-title">跳转地址</span>
          <el-tag size="small" type="info" effect="plain">浏览器新标签打开</el-tag>
        </div>
      </template>

      <el-form label-position="top" class="url-form">
        <el-form-item label="客服工具">
          <el-input
            v-model="form.toolUrl"
            placeholder="https://dh1888.github.io/168/"
            :disabled="!canEdit"
          />
          <p class="field-hint">对应侧边栏「客服工具」菜单，点击后在系统浏览器新标签页打开。</p>
        </el-form-item>

        <el-form-item label="客服话术">
          <el-input
            v-model="form.scriptUrl"
            placeholder="https://dh1888.github.io/render/"
            :disabled="!canEdit"
          />
          <p class="field-hint">对应侧边栏「客服话术」菜单，点击后在系统浏览器新标签页打开。</p>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { ElMessage } from "element-plus";
import { Check, Clock, Refresh, Service } from "@element-plus/icons-vue";
import csToolApi, { type CsToolSettings } from "@/api/cs_tool_api";
import { useUserStore } from "@store/user";
import { setCsToolUrls } from "@/utils/csToolLinks";

const userStore = useUserStore();
const loading = ref(false);
const saving = ref(false);
const updatedAt = ref("");

const form = ref<CsToolSettings>({
  toolUrl: "https://dh1888.github.io/168/",
  scriptUrl: "https://dh1888.github.io/render/",
});

const canEdit = computed(() => userStore.hasPermission("cstool:settings"));

function formatUpdatedAt(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
}

async function loadSettings() {
  loading.value = true;
  try {
    const res = await csToolApi.getSettings();
    const data = res.data;
    form.value = {
      toolUrl: data?.toolUrl || form.value.toolUrl,
      scriptUrl: data?.scriptUrl || form.value.scriptUrl,
    };
    updatedAt.value = data?.updatedAt || "";
    setCsToolUrls(form.value);
  } catch (error: any) {
    ElMessage.error(error.message || "加载配置失败");
  } finally {
    loading.value = false;
  }
}

async function saveSettings() {
  if (!canEdit.value) return;
  saving.value = true;
  try {
    const res = await csToolApi.saveSettings({
      toolUrl: form.value.toolUrl.trim(),
      scriptUrl: form.value.scriptUrl.trim(),
    });
    const data = res.data;
    form.value = {
      toolUrl: data.toolUrl,
      scriptUrl: data.scriptUrl,
    };
    updatedAt.value = data.updatedAt || "";
    setCsToolUrls(form.value);
    ElMessage.success("已保存");
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    saving.value = false;
  }
}

onMounted(() => {
  loadSettings();
});
</script>

<style scoped>
.cs-tool-settings-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.hero-card {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  padding: 24px;
  border-radius: 16px;
  background: linear-gradient(135deg, rgba(56, 189, 248, 0.12), rgba(59, 130, 246, 0.08));
  border: 1px solid rgba(59, 130, 246, 0.16);
}

.hero-left {
  display: flex;
  gap: 16px;
}

.hero-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  background: linear-gradient(135deg, #38bdf8, #2563eb);
  font-size: 24px;
}

.hero-card h1 {
  margin: 0 0 8px;
  font-size: 22px;
  color: #1f2937;
}

.hero-card p {
  margin: 0;
  color: #64748b;
  line-height: 1.6;
}

.hero-meta {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 10px;
  color: #94a3b8;
  font-size: 13px;
}

.hero-actions {
  display: flex;
  gap: 10px;
  flex-shrink: 0;
}

.panel-card {
  border-radius: 16px;
}

.panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.panel-title {
  font-weight: 700;
  color: #1f2937;
}

.url-form {
  max-width: 760px;
}

.field-hint {
  margin: 8px 0 0;
  color: #94a3b8;
  font-size: 13px;
  line-height: 1.5;
}

@media (max-width: 900px) {
  .hero-card {
    flex-direction: column;
  }
}
</style>

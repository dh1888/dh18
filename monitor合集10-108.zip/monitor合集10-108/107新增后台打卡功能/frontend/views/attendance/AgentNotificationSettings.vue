<template>
  <div class="attendance-management agent-notify-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <div class="page-shell" v-loading="loading">
      <section class="hero-card">
        <div class="hero-left">
          <div class="hero-icon">
            <el-icon><Bell /></el-icon>
          </div>
          <div>
            <div class="hero-title-row">
              <h1>客户端通知</h1>
              <el-tag :type="form.enabled ? 'success' : 'info'" effect="dark" round>
                {{ form.enabled ? "已启用" : "已关闭" }}
              </el-tag>
            </div>
            <p class="hero-desc">
              配置服务器推送至 PC 客户端的 Toast 通知；本机上班、下班、登录成功、邀请码绑定成功也统一使用同一套右下角通知样式。
            </p>
            <div class="hero-meta" v-if="updatedAt">
              <el-icon><Clock /></el-icon>
              <span>最后更新：{{ formatUpdatedAt(updatedAt) }}</span>
            </div>
          </div>
        </div>
        <div class="hero-actions">
          <el-button @click="loadSettings" :loading="loading">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
          <el-button
            v-permission="'attendance:edit'"
            type="primary"
            :loading="saving"
            @click="saveSettings"
          >
            <el-icon><Check /></el-icon>
            保存设置
          </el-button>
        </div>
      </section>

      <el-row :gutter="20" class="content-row">
        <el-col :xs="24" :lg="15">
          <el-card class="panel-card master-card" shadow="never">
            <template #header>
              <div class="panel-header">
                <span class="panel-title">总开关与显示时长</span>
                <el-tag size="small" effect="plain">{{ enabledCategoryCount }}/5 类已开启</el-tag>
              </div>
            </template>

            <div class="master-toggle" :class="{ disabled: !form.enabled }">
              <div class="master-toggle-text">
                <strong>启用客户端通知</strong>
                <span>关闭后服务器推送的分类通知不会送达 PC 客户端</span>
              </div>
              <el-switch
                v-model="form.enabled"
                size="large"
                :disabled="!canEdit"
                inline-prompt
                active-text="开"
                inactive-text="关"
              />
            </div>

            <div class="duration-block">
              <div class="duration-head">
                <div>
                  <strong>默认显示时长</strong>
                  <p>通知在客户端右下角停留的时间，员工也可点击关闭按钮提前关闭</p>
                </div>
                <div class="duration-value">
                  <span class="duration-number">{{ durationMinutes }}</span>
                  <span class="duration-unit">分钟</span>
                </div>
              </div>
              <el-slider
                v-model="form.defaultDurationSec"
                :min="30"
                :max="600"
                :step="30"
                :disabled="!canEdit"
                :format-tooltip="formatDurationTooltip"
                show-stops
              />
              <div class="duration-scale">
                <span>30 秒</span>
                <span>5 分钟</span>
                <span>10 分钟</span>
              </div>
            </div>
          </el-card>

          <el-card class="panel-card category-card" shadow="never">
            <template #header>
              <div class="panel-header">
                <span class="panel-title">分类推送开关</span>
                <span class="panel-subtitle">总开关关闭时，以下分类不会生效</span>
              </div>
            </template>

            <div class="category-grid">
              <div
                v-for="item in categoryItems"
                :key="item.key"
                class="category-item"
                :class="[item.tone, { active: form[item.key] && form.enabled, inactive: !form.enabled }]"
              >
                <div class="category-icon">
                  <el-icon><component :is="item.icon" /></el-icon>
                </div>
                <div class="category-body">
                  <div class="category-title-row">
                    <strong>{{ item.title }}</strong>
                    <el-switch
                      v-model="form[item.key]"
                      :disabled="!canEdit || !form.enabled"
                    />
                  </div>
                  <p>{{ item.desc }}</p>
                  <el-tag
                    size="small"
                    :type="form[item.key] && form.enabled ? item.tagType : 'info'"
                    effect="light"
                  >
                    {{ form[item.key] && form.enabled ? "将推送" : "不推送" }}
                  </el-tag>
                </div>
              </div>
            </div>
          </el-card>

          <el-card class="panel-card local-card" shadow="never">
            <template #header>
              <div class="panel-header">
                <span class="panel-title">客户端本地通知</span>
                <el-tag size="small" type="success" effect="plain">始终启用</el-tag>
              </div>
            </template>
            <p class="local-intro">
              以下操作在客户端本机触发，不经过服务器推送，统一使用右下角 Toast（默认约 2 分钟，可点 × 关闭）。
            </p>
            <div class="local-grid">
              <div v-for="item in localEventItems" :key="item.title" class="local-item">
                <div class="local-icon" :class="item.tone">
                  <el-icon><component :is="item.icon" /></el-icon>
                </div>
                <div>
                  <strong>{{ item.title }}</strong>
                  <p>{{ item.desc }}</p>
                </div>
              </div>
            </div>
          </el-card>
        </el-col>

        <el-col :xs="24" :lg="9">
          <el-card class="panel-card preview-card" shadow="never">
            <template #header>
              <div class="panel-header">
                <span class="panel-title">客户端预览</span>
                <el-tag size="small" type="info" effect="plain">右下角 Toast</el-tag>
              </div>
            </template>

            <div class="preview-stage">
              <div class="preview-desktop">
                <div class="preview-taskbar"></div>
                <div
                  class="preview-toast"
                  :class="previewToast.level"
                >
                  <div class="preview-accent"></div>
                  <div class="preview-content">
                    <div class="preview-top">
                      <div class="preview-badge">{{ previewToast.glyph }}</div>
                      <strong>{{ previewToast.title }}</strong>
                      <button class="preview-close" type="button" aria-label="关闭">×</button>
                    </div>
                    <p>{{ previewToast.message }}</p>
                    <div class="preview-progress">
                      <span :style="{ width: previewProgressWidth }"></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="preview-notes">
              <div class="note-item">
                <el-icon><Monitor /></el-icon>
                <span>员工已登录 PC 客户端</span>
              </div>
              <div class="note-item">
                <el-icon><Connection /></el-icon>
                <span>设备已审批且 WebSocket 在线</span>
              </div>
              <div class="note-item">
                <el-icon><Close /></el-icon>
                <span>支持右上角关闭按钮，也可等待自动消失</span>
              </div>
            </div>
          </el-card>

          <el-card class="panel-card tips-card" shadow="never">
            <template #header>
              <div class="panel-header">
                <span class="panel-title">使用说明</span>
              </div>
            </template>
            <ul class="tips-list">
              <li>上方分类开关仅控制<strong>服务器推送</strong>事件（工资、罚款、绩效等）。</li>
              <li>本机上班、下班、登录、绑定成功通知始终使用同一 Toast 组件，不受总开关影响。</li>
              <li>客户端通知不会替代 Telegram 频道推送，两者可同时开启。</li>
              <li>仅查看权限的用户可浏览本页，修改需 <code>attendance:edit</code> 权限。</li>
            </ul>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { ElMessage } from "element-plus";
import {
  Bell,
  Calendar,
  Check,
  Clock,
  Close,
  Connection,
  Monitor,
  Money,
  Refresh,
  Star,
  Timer,
  User,
  Warning,
} from "@element-plus/icons-vue";
import adminApi, { type AgentNotificationSettings } from "@api/admin_api";
import { useUserStore } from "@store/user";

type CategoryKey =
  | "salaryPaidEnabled"
  | "penaltyEnabled"
  | "performanceEnabled"
  | "attendanceEnabled"
  | "activityEnabled";

const userStore = useUserStore();
const loading = ref(false);
const saving = ref(false);
const updatedAt = ref("");

const defaultForm = (): AgentNotificationSettings => ({
  enabled: true,
  salaryPaidEnabled: true,
  penaltyEnabled: true,
  performanceEnabled: true,
  attendanceEnabled: true,
  activityEnabled: true,
  defaultDurationSec: 300,
});

const form = ref<AgentNotificationSettings>(defaultForm());

const categoryItems: Array<{
  key: CategoryKey;
  title: string;
  desc: string;
  icon: any;
  tone: string;
  tagType: "success" | "warning" | "danger" | "primary";
}> = [
  {
    key: "salaryPaidEnabled",
    title: "工资已发",
    desc: "标记工资已发时通知员工 PC 客户端",
    icon: Money,
    tone: "tone-success",
    tagType: "success",
  },
  {
    key: "penaltyEnabled",
    title: "罚款通知",
    desc: "TG 自动罚款及手动罚款推送时同步通知",
    icon: Warning,
    tone: "tone-warning",
    tagType: "warning",
  },
  {
    key: "performanceEnabled",
    title: "绩效变动",
    desc: "绩效推送到 Telegram 时同步通知客户端",
    icon: Star,
    tone: "tone-primary",
    tagType: "primary",
  },
  {
    key: "attendanceEnabled",
    title: "考勤异常",
    desc: "迟到、早退及考勤罚款时通知客户端",
    icon: Calendar,
    tone: "tone-danger",
    tagType: "danger",
  },
  {
    key: "activityEnabled",
    title: "活动超时",
    desc: "即将超时、超时警告等通知带「回座」按钮，与 TG 同步结束活动；强制回座、超时结束等为结果通知",
    icon: Timer,
    tone: "tone-info",
    tagType: "primary",
  },
];

const localEventItems = [
  {
    title: "上班 / 下班",
    desc: "托盘手动打卡、Telegram 同步上下班时提示",
    icon: Calendar,
    tone: "tone-primary",
  },
  {
    title: "登录成功",
    desc: "首次登录、托盘员工登录成功后欢迎提示",
    icon: User,
    tone: "tone-success",
  },
  {
    title: "邀请码绑定成功",
    desc: "首次绑定或托盘补绑邀请码成功后提示",
    icon: Check,
    tone: "tone-info",
  },
];

const canEdit = computed(() => userStore.hasPermission("attendance:edit"));

const enabledCategoryCount = computed(() => {
  if (!form.value.enabled) return 0;
  return categoryItems.filter((item) => form.value[item.key]).length;
});

const durationMinutes = computed(() => (form.value.defaultDurationSec / 60).toFixed(1));

const previewToast = computed(() => {
  if (!form.value.enabled) {
    return {
      level: "info",
      glyph: "i",
      title: "通知已关闭",
      message: "开启总开关后，客户端将收到对应类型的 Toast 通知。",
    };
  }
  if (form.value.salaryPaidEnabled) {
    return {
      level: "success",
      glyph: "✓",
      title: "工资已发放",
      message: "张三，您 2026年7月 的工资已确认发放，实发 ¥8500.00，请查收。",
    };
  }
  if (form.value.penaltyEnabled) {
    return {
      level: "warning",
      glyph: "!",
      title: "罚款通知",
      message: "您有一笔 ¥30.00 的罚款（TG考勤）\n原因：上班迟到 15 分钟",
    };
  }
  if (form.value.performanceEnabled) {
    return {
      level: "success",
      glyph: "✓",
      title: "绩效变动",
      message: "2026-07-13 +5分（加分）\n原因：主动协助同事完成工单",
    };
  }
  if (form.value.attendanceEnabled) {
    return {
      level: "warning",
      glyph: "!",
      title: "考勤异常",
      message: "上班 · 白班\n迟到 8 分钟\n罚款 ¥10.00",
    };
  }
  if (form.value.activityEnabled) {
    return {
      level: "warning",
      glyph: "!",
      title: "即将超时",
      message: "活动：抽烟\n班次：白班\n剩余约 1 分钟，请及时回座",
    };
  }
  return {
    level: "info",
    glyph: "i",
    title: "暂无启用分类",
    message: "请至少开启一个分类开关，客户端才会收到对应通知。",
  };
});

const previewProgressWidth = computed(() => {
  const ratio = form.value.defaultDurationSec / 600;
  return `${Math.max(18, Math.round(ratio * 100))}%`;
});

const applyFromApi = (data: Partial<AgentNotificationSettings> | undefined) => {
  form.value = {
    ...defaultForm(),
    ...data,
    defaultDurationSec: data?.defaultDurationSec ?? 300,
  };
  updatedAt.value = data?.updatedAt || "";
};

const formatDurationTooltip = (value: number) => {
  if (value < 60) return `${value} 秒`;
  const minutes = value / 60;
  return Number.isInteger(minutes) ? `${minutes} 分钟` : `${minutes.toFixed(1)} 分钟`;
};

const loadSettings = async () => {
  loading.value = true;
  try {
    const res = await adminApi.getAgentNotificationSettings();
    applyFromApi(res.data);
  } catch (e: any) {
    ElMessage.error(e.message || "加载客户端通知设置失败");
  } finally {
    loading.value = false;
  }
};

const saveSettings = async () => {
  if (!canEdit.value) return;
  saving.value = true;
  try {
    const res = await adminApi.saveAgentNotificationSettings(form.value);
    applyFromApi(res.data);
    ElMessage.success("客户端通知设置已保存");
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    saving.value = false;
  }
};

const formatUpdatedAt = (value: string) => {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString("zh-CN", { hour12: false });
};

onMounted(() => {
  loadSettings();
});
</script>

<style scoped>
@import "./attendance.css";

.agent-notify-page .page-shell {
  position: relative;
  z-index: 1;
  padding: 20px;
}

.hero-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  flex-wrap: wrap;
  padding: 24px 28px;
  margin-bottom: 20px;
  border-radius: 18px;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.14), rgba(118, 75, 162, 0.1));
  border: 1px solid rgba(102, 126, 234, 0.18);
  box-shadow: 0 10px 30px rgba(102, 126, 234, 0.08);
}

.hero-left {
  display: flex;
  align-items: flex-start;
  gap: 18px;
  min-width: 0;
}

.hero-icon {
  width: 56px;
  height: 56px;
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 26px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  box-shadow: 0 8px 20px rgba(102, 126, 234, 0.35);
  flex-shrink: 0;
}

.hero-title-row {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.hero-title-row h1 {
  margin: 0;
  font-size: 24px;
  font-weight: 700;
  color: #1f2937;
}

.hero-desc {
  margin: 8px 0 0;
  color: #64748b;
  line-height: 1.6;
  max-width: 720px;
}

.hero-meta {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 10px;
  color: #94a3b8;
  font-size: 13px;
}

.hero-actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.content-row {
  align-items: stretch;
}

.panel-card {
  border-radius: 16px;
  border: 1px solid rgba(148, 163, 184, 0.18);
  margin-bottom: 20px;
  overflow: hidden;
}

.panel-card :deep(.el-card__header) {
  padding: 16px 20px;
  border-bottom: 1px solid rgba(148, 163, 184, 0.14);
  background: rgba(255, 255, 255, 0.72);
}

.panel-card :deep(.el-card__body) {
  padding: 20px;
}

.panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}

.panel-title {
  font-size: 16px;
  font-weight: 600;
  color: #1f2937;
}

.panel-subtitle {
  color: #94a3b8;
  font-size: 13px;
}

.master-toggle {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 18px 20px;
  border-radius: 14px;
  background: linear-gradient(135deg, rgba(34, 197, 94, 0.08), rgba(16, 185, 129, 0.04));
  border: 1px solid rgba(34, 197, 94, 0.18);
}

.master-toggle.disabled {
  background: linear-gradient(135deg, rgba(148, 163, 184, 0.08), rgba(148, 163, 184, 0.04));
  border-color: rgba(148, 163, 184, 0.18);
}

.master-toggle-text {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.master-toggle-text strong {
  font-size: 16px;
  color: #111827;
}

.master-toggle-text span {
  color: #64748b;
  font-size: 13px;
}

.duration-block {
  margin-top: 22px;
  padding: 18px 20px;
  border-radius: 14px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
}

.duration-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 12px;
}

.duration-head strong {
  display: block;
  font-size: 15px;
  color: #111827;
}

.duration-head p {
  margin: 6px 0 0;
  color: #64748b;
  font-size: 13px;
  line-height: 1.5;
}

.duration-value {
  text-align: right;
  flex-shrink: 0;
}

.duration-number {
  font-size: 28px;
  font-weight: 700;
  color: #4f46e5;
  line-height: 1;
}

.duration-unit {
  display: block;
  margin-top: 4px;
  color: #94a3b8;
  font-size: 12px;
}

.duration-scale {
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
  color: #94a3b8;
  font-size: 12px;
}

.category-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
}

.category-item {
  display: flex;
  gap: 14px;
  padding: 16px;
  border-radius: 14px;
  border: 1px solid #e2e8f0;
  background: #fff;
  transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
}

.category-item.active {
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
  transform: translateY(-1px);
}

.category-item.inactive {
  opacity: 0.72;
}

.category-icon {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
}

.category-body {
  flex: 1;
  min-width: 0;
}

.category-title-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.category-title-row strong {
  color: #111827;
}

.category-body p {
  margin: 8px 0 10px;
  color: #64748b;
  font-size: 13px;
  line-height: 1.5;
}

.tone-success .category-icon {
  color: #16a34a;
  background: rgba(34, 197, 94, 0.12);
}

.tone-warning .category-icon {
  color: #d97706;
  background: rgba(251, 146, 60, 0.14);
}

.tone-primary .category-icon {
  color: #4f46e5;
  background: rgba(99, 102, 241, 0.12);
}

.tone-danger .category-icon {
  color: #dc2626;
  background: rgba(248, 113, 113, 0.14);
}

.tone-info .category-icon {
  color: #0284c7;
  background: rgba(56, 189, 248, 0.14);
}

.local-intro {
  margin: 0 0 16px;
  color: #64748b;
  font-size: 13px;
  line-height: 1.6;
}

.local-grid {
  display: grid;
  gap: 12px;
}

.local-item {
  display: flex;
  gap: 12px;
  padding: 14px 16px;
  border-radius: 12px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
}

.local-icon {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  font-size: 18px;
}

.local-item strong {
  display: block;
  color: #111827;
  margin-bottom: 4px;
}

.local-item p {
  margin: 0;
  color: #64748b;
  font-size: 13px;
  line-height: 1.5;
}

.local-icon.tone-primary {
  color: #4f46e5;
  background: rgba(99, 102, 241, 0.12);
}

.local-icon.tone-success {
  color: #16a34a;
  background: rgba(34, 197, 94, 0.12);
}

.local-icon.tone-info {
  color: #0284c7;
  background: rgba(56, 189, 248, 0.14);
}

.preview-stage {
  padding: 8px 0 4px;
}

.preview-desktop {
  position: relative;
  height: 260px;
  border-radius: 16px;
  overflow: hidden;
  background: linear-gradient(180deg, #dbeafe 0%, #eff6ff 42%, #e2e8f0 100%);
  border: 1px solid #cbd5e1;
}

.preview-taskbar {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 34px;
  background: rgba(15, 23, 42, 0.88);
}

.preview-toast {
  position: absolute;
  right: 16px;
  bottom: 48px;
  width: 290px;
  display: flex;
  border-radius: 12px;
  overflow: hidden;
  background: #1c1e24;
  color: #fff;
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.28);
  border: 1px solid rgba(148, 163, 184, 0.18);
}

.preview-accent {
  width: 4px;
  flex-shrink: 0;
  background: #1e88e5;
}

.preview-toast.success .preview-accent {
  background: #43a047;
}

.preview-toast.warning .preview-accent {
  background: #fb8c00;
}

.preview-content {
  flex: 1;
  padding: 12px 12px 10px;
}

.preview-top {
  display: flex;
  align-items: center;
  gap: 8px;
}

.preview-badge {
  width: 24px;
  height: 24px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 700;
  background: #1e88e5;
  flex-shrink: 0;
}

.preview-toast.success .preview-badge {
  background: #43a047;
}

.preview-toast.warning .preview-badge {
  background: #fb8c00;
}

.preview-top strong {
  flex: 1;
  font-size: 13px;
}

.preview-close {
  width: 24px;
  height: 24px;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: #b0b7c3;
  font-size: 18px;
  line-height: 1;
  cursor: default;
}

.preview-content p {
  margin: 8px 0 10px;
  color: #c4c9d4;
  font-size: 12px;
  line-height: 1.5;
  white-space: pre-line;
}

.preview-progress {
  height: 3px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.08);
  overflow: hidden;
}

.preview-progress span {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: currentColor;
  color: inherit;
}

.preview-toast.success .preview-progress span {
  background: #43a047;
}

.preview-toast.warning .preview-progress span {
  background: #fb8c00;
}

.preview-toast.info .preview-progress span {
  background: #1e88e5;
}

.preview-notes {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 16px;
}

.note-item {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #64748b;
  font-size: 13px;
}

.tips-list {
  margin: 0;
  padding-left: 18px;
  color: #64748b;
  line-height: 1.8;
  font-size: 13px;
}

.tips-list code {
  padding: 1px 6px;
  border-radius: 6px;
  background: #f1f5f9;
  color: #475569;
}

@media (max-width: 992px) {
  .category-grid {
    grid-template-columns: 1fr;
  }
}
</style>

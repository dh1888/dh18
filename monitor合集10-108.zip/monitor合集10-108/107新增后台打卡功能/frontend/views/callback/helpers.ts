export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export function taskStatusLabel(status: string): string {
  const map: Record<string, string> = {
    pending: "待处理",
    running: "执行中",
    completed: "已完成",
    failed: "失败",
  };
  return map[status] || status;
}

export function taskStatusTagType(
  status: string,
): "success" | "warning" | "danger" | "info" {
  if (status === "completed") return "success";
  if (status === "running") return "warning";
  if (status === "failed") return "danger";
  return "info";
}

export function healthLevelLabel(level?: string | null): string {
  const map: Record<string, string> = {
    low: "偏低",
    normal: "正常",
    high: "偏高",
  };
  if (!level) return "-";
  return map[level] || level;
}

export function healthLevelTagType(
  level?: string | null,
): "success" | "warning" | "danger" | "info" {
  if (level === "low") return "danger";
  if (level === "high") return "warning";
  if (level === "normal") return "success";
  return "info";
}

export function formatMoney(v: number | undefined | null): string {
  if (v == null || Number.isNaN(v)) return "0.00";
  return Number(v).toFixed(2);
}

export function defaultDateRange(days: number): [string, string] {
  const end = new Date();
  const start = new Date();
  start.setDate(end.getDate() - (days > 0 ? days - 1 : 6));
  const fmt = (d: Date) => d.toISOString().slice(0, 10);
  return [fmt(start), fmt(end)];
}

export interface ActivitySnapshot {
  days: number;
  rate: number;
  divisor: number;
  minBonus: number;
  maxBonus: number;
  excludeRewarded: boolean;
  healthMin: number;
  healthMax: number;
}

export interface ActivityLike extends Partial<ActivitySnapshot> {
  days?: number;
  rate?: number;
  divisor?: number;
  minBonus?: number;
  maxBonus?: number;
  excludeRewarded?: boolean;
  healthMin?: number;
  healthMax?: number;
  periodWageringMultiplier?: number;
  periodAppRemark?: string;
  periodBackendRemark?: string;
  callbackMinBonus?: number;
  callbackRate?: number;
  callbackDivisor?: number;
  callbackWageringMultiplier?: number;
  callbackAppRemark?: string;
  callbackBackendRemark?: string;
}

export function parseActivitySnapshot(raw?: string | null): ActivitySnapshot | null {
  if (!raw?.trim()) return null;
  try {
    const data = JSON.parse(raw) as ActivitySnapshot;
    if (typeof data.days !== "number") return null;
    return data;
  } catch {
    return null;
  }
}

export function formatActivitySummary(a: ActivityLike): string {
  const days = a.days ?? 7;
  const rate = a.rate ?? 0;
  const divisor = a.divisor ?? 1;
  const minBonus = a.minBonus ?? 0;
  const maxBonus = a.maxBonus ?? 0;
  return `统计 ${days} 天 · 比例 ${(rate * 100).toFixed(2)}% ÷ ${divisor} · 彩金 ${minBonus}~${maxBonus}`;
}

export function calcBonusPreview(profit: number, a: ActivityLike): number {
  const rate = a.rate ?? 0;
  const divisor = Math.max(1, a.divisor ?? 1);
  const minBonus = a.minBonus ?? 0;
  const maxBonus = a.maxBonus ?? 0;
  let bonus = Math.abs(profit) * rate / divisor;
  if (bonus < minBonus) bonus = minBonus;
  if (bonus > maxBonus) bonus = maxBonus;
  return Math.round(bonus * 100) / 100;
}

export function calcCallbackBonusPreview(profit: number, a: ActivityLike): number {
  const rate = a.callbackRate ?? 0.02;
  const divisor = Math.max(1, a.callbackDivisor ?? 2);
  const minBonus = a.callbackMinBonus ?? 0;
  if (profit < 0) return Math.round(minBonus * 100) / 100;
  let bonus = profit * rate / divisor;
  if (bonus < minBonus) bonus = minBonus;
  return Math.round(bonus * 100) / 100;
}

export function validateActivityForm(a: ActivityLike): string | null {
  if (!a.days || a.days < 1 || a.days > 365) return "统计天数需在 1~365 之间";
  if (a.rate == null || a.rate < 0 || a.rate > 1) return "彩金比例需在 0~1 之间";
  if (!a.divisor || a.divisor < 1) return "除数需 >= 1";
  if (a.minBonus == null || a.minBonus < 0) return "最低彩金不能为负";
  if (a.maxBonus == null || a.maxBonus < 0) return "最高彩金不能为负";
  if ((a.minBonus ?? 0) > (a.maxBonus ?? 0)) return "最低彩金不能大于最高彩金";
  if (a.callbackRate != null && (a.callbackRate < 0 || a.callbackRate > 1)) return "回访彩金比例需在 0~1 之间";
  if (a.callbackDivisor != null && a.callbackDivisor < 1) return "回访除数需 >= 1";
  if (a.periodWageringMultiplier != null && a.periodWageringMultiplier < 0) return "时段打码倍数不能为负";
  if (a.callbackWageringMultiplier != null && a.callbackWageringMultiplier < 0) return "回访打码倍数不能为负";
  if (a.callbackMinBonus != null && a.callbackMinBonus < 0) return "回访最低彩金不能为负";
  if (a.healthMin == null || a.healthMin < 0 || a.healthMin > 100) return "健康度下限需在 0~100 之间";
  if (a.healthMax == null || a.healthMax < 0 || a.healthMax > 100) return "健康度上限需在 0~100 之间";
  if ((a.healthMin ?? 0) > (a.healthMax ?? 0)) return "健康度下限不能大于上限";
  return null;
}

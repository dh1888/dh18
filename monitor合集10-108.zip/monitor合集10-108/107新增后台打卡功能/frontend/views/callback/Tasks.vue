<template>
  <div class="callback-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
    </div>
    <el-card shadow="hover" class="main-card">
      <template #header>历史任务</template>
      <div class="toolbar">
        <el-select
          v-model="filter.platformId"
          placeholder="全部平台"
          clearable
          filterable
          style="width: 220px"
          @change="loadTasks"
        >
          <el-option
            v-for="p in platforms"
            :key="p.id"
            :label="p.name"
            :value="p.id"
          />
        </el-select>
        <el-select
          v-model="filter.status"
          placeholder="全部状态"
          clearable
          style="width: 140px"
          @change="loadTasks"
        >
          <el-option label="已完成" value="completed" />
          <el-option label="失败" value="failed" />
          <el-option label="执行中" value="running" />
        </el-select>
        <el-button @click="loadTasks" :loading="loading">
          <el-icon><Refresh /></el-icon>
        </el-button>
      </div>
      <el-table :data="tasks" v-loading="loading" stripe>
        <el-table-column prop="createdAt" label="创建时间" width="170" />
        <el-table-column label="平台" width="140">
          <template #default="{ row }">{{ platformName(row.platformId) }}</template>
        </el-table-column>
        <el-table-column label="日期范围" width="200">
          <template #default="{ row }">{{ row.dateFrom }} ~ {{ row.dateTo }}</template>
        </el-table-column>
        <el-table-column prop="memberCount" label="人数" width="80" />
        <el-table-column label="总彩金" width="100">
          <template #default="{ row }">{{ formatMoney(row.totalBonus) }}</template>
        </el-table-column>
        <el-table-column label="健康值" width="90">
          <template #default="{ row }">
            <el-tag size="small" :type="healthLevelTagType(row.healthLevel)">
              {{ healthLevelLabel(row.healthLevel) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag size="small" :type="taskStatusTagType(row.status)">
              {{ taskStatusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openDetail(row)">明细</el-button>
            <el-button link @click="exportTask(row.id)">导出</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        class="pager"
        v-model:current-page="page"
        v-model:page-size="pageSize"
        :total="total"
        layout="total, prev, pager, next, sizes"
        @current-change="loadTasks"
        @size-change="loadTasks"
      />
    </el-card>

    <el-drawer v-model="detailVisible" title="任务明细" size="70%">
      <template v-if="detailTask">
        <el-descriptions :column="2" border class="task-meta" size="small">
          <el-descriptions-item label="平台">{{ platformName(detailTask.platformId) }}</el-descriptions-item>
          <el-descriptions-item label="日期">{{ detailTask.dateFrom }} ~ {{ detailTask.dateTo }}</el-descriptions-item>
          <el-descriptions-item label="人数">{{ detailTask.memberCount }}</el-descriptions-item>
          <el-descriptions-item label="总彩金">{{ formatMoney(detailTask.totalBonus) }}</el-descriptions-item>
          <el-descriptions-item label="健康值" :span="2">
            <el-tag size="small" :type="healthLevelTagType(detailTask.healthLevel)">
              {{ healthLevelLabel(detailTask.healthLevel) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item v-if="taskActivitySnapshot" label="活动规则" :span="2">
            {{ formatActivitySummary(taskActivitySnapshot) }}
          </el-descriptions-item>
        </el-descriptions>
      </template>
      <el-table :data="results" v-loading="detailLoading" stripe max-height="520" class="detail-table">
        <el-table-column prop="userId" label="用户ID" width="100" />
        <el-table-column prop="phoneNumber" label="手机号" width="130" />
        <el-table-column prop="vipLevel" label="VIP" width="70" />
        <el-table-column label="充值" width="100">
          <template #default="{ row }">{{ formatMoney(row.historicalPay) }}</template>
        </el-table-column>
        <el-table-column label="提现" width="100">
          <template #default="{ row }">{{ formatMoney(row.historyWithdrawals) }}</template>
        </el-table-column>
        <el-table-column label="优惠" width="100">
          <template #default="{ row }">{{ formatMoney(row.historicalReward) }}</template>
        </el-table-column>
        <el-table-column label="盈亏" width="100">
          <template #default="{ row }">{{ formatMoney(row.profit) }}</template>
        </el-table-column>
        <el-table-column label="彩金" width="100">
          <template #default="{ row }">{{ formatMoney(row.bonus) }}</template>
        </el-table-column>
      </el-table>
      <el-pagination
        class="pager"
        v-model:current-page="detailPage"
        v-model:page-size="detailPageSize"
        :total="detailTotal"
        layout="total, prev, pager, next"
        @current-change="loadResults"
      />
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from "vue";
import { ElMessage } from "element-plus";
import { Refresh } from "@element-plus/icons-vue";
import callbackApi, { type CallbackResult, type CallbackTask } from "@api/callback_api";
import {
  downloadBlob,
  formatActivitySummary,
  formatMoney,
  healthLevelLabel,
  healthLevelTagType,
  parseActivitySnapshot,
  taskStatusLabel,
  taskStatusTagType,
} from "./helpers";
import { useCallbackPlatforms } from "./useCallbackPlatforms";
import "./styles.css";

const { platforms, loadAll, platformName } = useCallbackPlatforms();

const tasks = ref<CallbackTask[]>([]);
const loading = ref(false);
const page = ref(1);
const pageSize = ref(20);
const total = ref(0);
const filter = reactive({ platformId: "", status: "" });

const detailVisible = ref(false);
const detailTask = ref<CallbackTask | null>(null);
const results = ref<CallbackResult[]>([]);
const detailLoading = ref(false);
const detailPage = ref(1);
const detailPageSize = ref(20);
const detailTotal = ref(0);

const taskActivitySnapshot = computed(() =>
  parseActivitySnapshot(detailTask.value?.activitySnapshot),
);

async function loadTasks() {
  loading.value = true;
  try {
    const { data } = await callbackApi.listTasks({
      platformId: filter.platformId || undefined,
      status: filter.status || undefined,
      page: page.value,
      pageSize: pageSize.value,
    });
    tasks.value = data.items || [];
    total.value = data.total || 0;
  } catch (e: any) {
    ElMessage.error(e.message || "加载失败");
  } finally {
    loading.value = false;
  }
}

function openDetail(task: CallbackTask) {
  detailTask.value = task;
  detailPage.value = 1;
  detailVisible.value = true;
  loadResults();
}

async function loadResults() {
  if (!detailTask.value) return;
  detailLoading.value = true;
  try {
    const { data } = await callbackApi.listTaskResults(detailTask.value.id, {
      page: detailPage.value,
      pageSize: detailPageSize.value,
    });
    results.value = data.items || [];
    detailTotal.value = data.total || 0;
  } catch (e: any) {
    ElMessage.error(e.message || "加载明细失败");
  } finally {
    detailLoading.value = false;
  }
}

async function exportTask(taskId: string) {
  try {
    const res = await callbackApi.exportTask(taskId);
    downloadBlob(res.data as Blob, `callback_${taskId}.xlsx`);
  } catch (e: any) {
    ElMessage.error(e.message || "导出失败");
  }
}

onMounted(async () => {
  await loadAll();
  loadTasks();
});
</script>

<style scoped>
.task-meta {
  margin-bottom: 16px;
}
.detail-table {
  margin-top: 8px;
}
</style>

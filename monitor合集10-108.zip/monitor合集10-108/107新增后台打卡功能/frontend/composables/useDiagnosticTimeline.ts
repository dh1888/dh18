import { onMounted, onUnmounted, ref } from "vue";
import type { DiagnosticEventItem } from "@api/index";

const MAX_EVENTS = 300;

export const useDiagnosticTimeline = () => {
  const liveEvents = ref<DiagnosticEventItem[]>([]);
  const paused = ref(false);

  const pushEvent = (raw: Partial<DiagnosticEventItem> & { message?: string }) => {
    if (paused.value) return;
    const item: DiagnosticEventItem = {
      id: raw.id ?? `live-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      source: raw.source ?? "unknown",
      deviceId: raw.deviceId,
      module: raw.module ?? "",
      level: raw.level ?? "INFO",
      message: raw.message ?? "",
      context: raw.context,
      correlationId: raw.correlationId,
      createdAt: raw.createdAt ?? new Date().toISOString(),
    };
    liveEvents.value = [item, ...liveEvents.value].slice(0, MAX_EVENTS);
  };

  const mergeEvents = (items: DiagnosticEventItem[]) => {
    const seen = new Set(liveEvents.value.map((e) => e.id));
    const merged = [...items.filter((e) => !seen.has(e.id)), ...liveEvents.value];
    merged.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
    liveEvents.value = merged.slice(0, MAX_EVENTS);
  };

  const clearEvents = () => {
    liveEvents.value = [];
  };

  const onDiagnosticEvent = (event: Event) => {
    const detail = (event as CustomEvent).detail as Partial<DiagnosticEventItem> & {
      event?: Partial<DiagnosticEventItem>;
    };
    const payload = detail?.event ?? detail;
    if (payload?.message || payload?.module) pushEvent(payload);
  };

  onMounted(() => {
    window.addEventListener("diagnostic-event", onDiagnosticEvent);
  });

  onUnmounted(() => {
    window.removeEventListener("diagnostic-event", onDiagnosticEvent);
  });

  return {
    liveEvents,
    paused,
    pushEvent,
    mergeEvents,
    clearEvents,
  };
};

<template>
  <el-dialog
    v-model="visible"
    :title="title"
    width="440px"
    destroy-on-close
    @closed="resetState"
  >
    <div v-if="requirePassword && !enrollStarted" class="totp-bind-body">
      <p class="hint">请输入当前登录密码以生成绑定二维码</p>
      <el-input
        v-model="password"
        type="password"
        show-password
        placeholder="当前密码"
        @keyup.enter="handleStart"
      />
    </div>

    <div v-else v-loading="loading" class="totp-bind-body">
      <p v-if="username" class="hint">用户：{{ username }}</p>
      <p class="hint">使用 Google Authenticator 等 App 扫描下方二维码</p>
      <div v-if="qrSrc" class="qr-wrap">
        <img :src="qrSrc" alt="TOTP QR" class="qr-img" />
      </div>
      <el-input
        v-model="totpCode"
        placeholder="输入验证器中的 6 位动态码"
        maxlength="6"
        inputmode="numeric"
        @keyup.enter="handleConfirm"
      />
    </div>

    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button
        v-if="requirePassword && !enrollStarted"
        type="primary"
        :loading="loading"
        @click="handleStart"
      >
        生成二维码
      </el-button>
      <template v-else>
        <el-button :loading="loading" @click="handleStart">刷新二维码</el-button>
        <el-button type="primary" :loading="confirmLoading" @click="handleConfirm">
          确认绑定
        </el-button>
      </template>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { computed, ref, watch } from "vue";
import { ElMessage } from "element-plus";

const props = withDefaults(
  defineProps<{
    modelValue: boolean;
    title?: string;
    username?: string;
    requirePassword?: boolean;
    onStart: (password?: string) => Promise<{
      setupChallenge: string;
      totpProvisioningUri: string;
    }>;
    onConfirm: (setupChallenge: string, totpCode: string) => Promise<void>;
  }>(),
  {
    title: "绑定 Google Authenticator",
    requirePassword: false,
  },
);

const emit = defineEmits<{
  "update:modelValue": [boolean];
  success: [];
}>();

const visible = computed({
  get: () => props.modelValue,
  set: (v) => emit("update:modelValue", v),
});

const loading = ref(false);
const confirmLoading = ref(false);
const enrollStarted = ref(false);
const setupChallenge = ref("");
const provisioningUri = ref("");
const totpCode = ref("");
const password = ref("");

const qrSrc = computed(() => {
  if (!provisioningUri.value) return "";
  return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(provisioningUri.value)}`;
});

const resetState = () => {
  loading.value = false;
  confirmLoading.value = false;
  enrollStarted.value = false;
  setupChallenge.value = "";
  provisioningUri.value = "";
  totpCode.value = "";
  password.value = "";
};

watch(
  () => props.modelValue,
  (open) => {
    if (open && !props.requirePassword) {
      void handleStart();
    }
  },
);

const handleStart = async () => {
  if (props.requirePassword && !password.value.trim()) {
    ElMessage.warning("请输入密码");
    return;
  }
  loading.value = true;
  try {
    const data = await props.onStart(
      props.requirePassword ? password.value : undefined,
    );
    setupChallenge.value = data.setupChallenge;
    provisioningUri.value = data.totpProvisioningUri;
    enrollStarted.value = true;
    totpCode.value = "";
  } catch (error: any) {
    ElMessage.error(error.message || "生成二维码失败");
  } finally {
    loading.value = false;
  }
};

const handleConfirm = async () => {
  const code = totpCode.value.trim();
  if (!/^\d{6}$/.test(code)) {
    ElMessage.warning("请输入 6 位验证码");
    return;
  }
  if (!setupChallenge.value) {
    ElMessage.warning("请先生成二维码");
    return;
  }
  confirmLoading.value = true;
  try {
    await props.onConfirm(setupChallenge.value, code);
    ElMessage.success("谷歌验证绑定成功");
    emit("success");
    visible.value = false;
  } catch (error: any) {
    ElMessage.error(error.message || "绑定失败");
  } finally {
    confirmLoading.value = false;
  }
};
</script>

<style scoped>
.totp-bind-body {
  min-height: 120px;
}

.hint {
  margin: 0 0 12px;
  font-size: 13px;
  color: #606266;
  line-height: 1.5;
}

.qr-wrap {
  display: flex;
  justify-content: center;
  margin: 12px 0 16px;
}

.qr-img {
  width: 200px;
  height: 200px;
  border-radius: 8px;
  border: 1px solid #ebeef5;
}
</style>

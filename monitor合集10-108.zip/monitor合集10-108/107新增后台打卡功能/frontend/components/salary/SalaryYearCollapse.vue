<template>
  <div class="salary-year-section">
    <div class="salary-year-header" @click="toggleExpanded">
      <div class="header-left">
        <el-icon class="expand-icon">
          <ArrowDown v-if="!expanded" />
          <ArrowUp v-else />
        </el-icon>
        <h4 class="section-heading">{{ expanded ? `${salaryYear}年 工资状态` : collapsedTitle }}</h4>
      </div>
      <el-select
        v-if="expanded"
        :model-value="salaryYear"
        size="small"
        style="width: 100px"
        @click.stop
        @change="handleYearChange"
      >
        <el-option v-for="y in yearOptions" :key="y" :label="`${y}年`" :value="y" />
      </el-select>
    </div>

    <div v-if="!expanded" v-loading="loading" class="salary-month-summary-collapsed">
      <div
        v-if="lastMonthItem"
        class="salary-month-item"
        :class="lastMonthItem.status"
      >
        <div class="month-label">{{ lastMonthItem.monthLabel || formatMonthLabel(lastMonthYearMonth) }}</div>
        <div class="month-amount" v-if="lastMonthItem.amount != null">
          ¥{{ formatSalaryAmount(lastMonthItem.amount) }}
        </div>
        <div class="month-amount empty" v-else>-</div>
        <el-tag size="small" :type="salaryStatusTagType(lastMonthItem.status)">
          {{ lastMonthItem.statusLabel }}
        </el-tag>
      </div>
      <el-empty v-else description="暂无上月工资数据" :image-size="48" />
      <div class="expand-hint">点击展开查看全年明细</div>
    </div>

    <div v-else v-loading="loading" class="salary-month-grid">
      <div
        v-for="item in salaryMonths"
        :key="item.yearMonth"
        class="salary-month-item"
        :class="item.status"
      >
        <div class="month-label">{{ item.monthLabel }}</div>
        <div class="month-amount" v-if="item.amount != null">¥{{ formatSalaryAmount(item.amount) }}</div>
        <div class="month-amount empty" v-else>-</div>
        <el-tag size="small" :type="salaryStatusTagType(item.status)">{{ item.statusLabel }}</el-tag>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from "vue";
import { ArrowDown, ArrowUp } from "@element-plus/icons-vue";
import {
  findSalaryMonthItem,
  formatMonthLabel,
  formatSalaryAmount,
  getLastMonth,
  salaryStatusTagType,
} from "@/utils/salaryHelpers";

const props = withDefaults(
  defineProps<{
    salaryMonths: any[];
    salaryYear: number;
    loading?: boolean;
    yearOptions?: number[];
    lastMonthYearMonth?: string;
  }>(),
  {
    loading: false,
    lastMonthYearMonth: () => getLastMonth(),
  },
);

const emit = defineEmits<{
  "update:salaryYear": [value: number];
  yearChange: [value: number];
}>();

const expanded = ref(false);

const lastMonthItem = computed(() =>
  findSalaryMonthItem(props.salaryMonths, props.lastMonthYearMonth),
);

const collapsedTitle = computed(() => {
  const label = formatMonthLabel(props.lastMonthYearMonth);
  if (!lastMonthItem.value) return `${label} 工资状态`;
  const amount =
    lastMonthItem.value.amount != null
      ? ` · ¥${formatSalaryAmount(lastMonthItem.value.amount)}`
      : "";
  return `${label} 工资状态${amount}`;
});

function toggleExpanded() {
  expanded.value = !expanded.value;
}

function handleYearChange(value: number) {
  emit("update:salaryYear", value);
  emit("yearChange", value);
}

function collapse() {
  expanded.value = false;
}

defineExpose({ collapse });
</script>

<style scoped>
.salary-year-section {
  margin-bottom: 24px;
  padding-bottom: 20px;
  border-bottom: 1px solid #ebeef5;
}

.salary-year-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
  cursor: pointer;
  user-select: none;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}

.expand-icon {
  color: #909399;
  flex-shrink: 0;
}

.section-heading {
  margin: 0;
  font-size: 15px;
  color: #606266;
  font-weight: 600;
}

.salary-month-summary-collapsed {
  min-height: 48px;
}

.salary-month-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  min-height: 48px;
}

.salary-month-item {
  padding: 10px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  background: #fafafa;
  text-align: center;
}

.salary-month-summary-collapsed .salary-month-item {
  max-width: 220px;
}

.salary-month-item.paid {
  border-color: #b3e19d;
  background: #fafdf8;
}

.salary-month-item.pending {
  border-color: #f3d19e;
  background: #fdfaf3;
}

.salary-month-item .month-label {
  font-size: 13px;
  color: #909399;
  margin-bottom: 4px;
}

.salary-month-item .month-amount {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 6px;
  word-break: break-all;
}

.salary-month-item .month-amount.empty {
  color: #c0c4cc;
  font-weight: 400;
}

.expand-hint {
  margin-top: 8px;
  font-size: 12px;
  color: #909399;
}
</style>

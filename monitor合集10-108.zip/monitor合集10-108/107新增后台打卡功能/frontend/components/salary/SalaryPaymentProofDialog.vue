<template>
  <el-dialog
    :model-value="visible"
    title="上传打款截图"
    width="520px"
    destroy-on-close
    @update:model-value="$emit('update:visible', $event)"
    @closed="$emit('closed')"
  >
    <el-alert
      v-if="target"
      type="info"
      :closable="false"
      show-icon
      :title="`员工：${target.employeeName}${yearMonth ? ' · ' + formatMonthLabel(yearMonth) : ''}`"
      style="margin-bottom: 16px"
    />
    <el-form label-width="90px">
      <el-form-item label="工资月份" required>
        <el-date-picker
          :model-value="yearMonth"
          type="month"
          placeholder="选择月份"
          format="YYYY年MM月"
          value-format="YYYY-MM"
          style="width: 100%"
          @update:model-value="$emit('update:yearMonth', $event)"
        />
      </el-form-item>
      <el-form-item label="打款截图" required>
        <el-upload
          ref="uploadRef"
          :auto-upload="false"
          :limit="1"
          accept="image/jpeg,image/png,image/gif,image/webp,image/bmp,.jpg,.jpeg,.png,.gif,.webp,.bmp"
          :on-change="(file: any) => $emit('fileChange', file)"
          list-type="picture-card"
        >
          <el-icon><Plus /></el-icon>
        </el-upload>
        <div class="el-upload__tip">支持 JPG、PNG、GIF、WEBP、BMP，最大 10MB</div>
      </el-form-item>
      <el-form-item v-if="previewUrl" label="当前截图">
        <img :src="previewUrl" alt="打款截图" class="proof-preview-img" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="$emit('update:visible', false)">取消</el-button>
      <el-button type="primary" :loading="uploading" @click="$emit('submit')">上传</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { Plus } from "@element-plus/icons-vue";
import { formatMonthLabel, type SalaryEmployeeContext } from "@/utils/salaryHelpers";

defineProps<{
  visible: boolean;
  uploading: boolean;
  target: SalaryEmployeeContext | null;
  yearMonth: string;
  previewUrl: string;
}>();

defineEmits<{
  "update:visible": [value: boolean];
  "update:yearMonth": [value: string];
  fileChange: [file: any];
  submit: [];
  closed: [];
}>();
</script>

<style scoped>
.proof-preview-img {
  max-width: 100%;
  max-height: 240px;
  border-radius: 8px;
  border: 1px solid #ebeef5;
}
</style>

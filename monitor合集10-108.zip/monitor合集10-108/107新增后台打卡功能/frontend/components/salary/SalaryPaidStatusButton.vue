<template>
  <el-button
    :link="link"
    :text="!link"
    :size="size"
    :disabled="disabled"
    class="salary-paid-status-btn"
    :class="status === 'paid' ? 'is-paid' : 'is-pending'"
    v-bind="$attrs"
    @click="$emit('click', $event)"
  >
    {{ status === "paid" ? "已发" : "待发" }}
  </el-button>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    status?: string;
    disabled?: boolean;
    link?: boolean;
    size?: "small" | "default" | "large";
  }>(),
  {
    status: "pending",
    disabled: false,
    link: true,
    size: "small",
  },
);

defineEmits<{
  click: [event: MouseEvent];
}>();
</script>

<style scoped>
.salary-paid-status-btn.is-pending {
  --el-button-text-color: #e6a23c;
  color: #e6a23c !important;
}

.salary-paid-status-btn.is-pending:hover:not(:disabled),
.salary-paid-status-btn.is-pending:focus:not(:disabled) {
  color: #cf9236 !important;
}

.salary-paid-status-btn.is-paid {
  --el-button-text-color: #67c23a;
  color: #67c23a !important;
}

.salary-paid-status-btn.is-paid:disabled {
  color: #67c23a !important;
  opacity: 1;
  cursor: default;
}

.salary-paid-status-btn.is-pending:disabled {
  color: #e6a23c !important;
  opacity: 0.55;
}
</style>

<template>
  <div class="drawer-footer-actions">
    <el-button
      type="primary"
      v-permission="['salary:upload', 'salary:payment_address:view']"
      @click="$emit('upload')"
    >
      上传图片
    </el-button>
    <SalaryPaidStatusButton
      :link="false"
      size="default"
      :status="paidStatus"
      :disabled="markPaidDisabled"
      v-permission="'salary:upload'"
      @click="$emit('markPaid')"
    />
  </div>
</template>

<script setup lang="ts">
import SalaryPaidStatusButton from "@/components/salary/SalaryPaidStatusButton.vue";

defineProps<{
  paidStatus?: string;
  markPaidDisabled?: boolean;
}>();

defineEmits<{
  upload: [];
  markPaid: [];
}>();
</script>

<style scoped>
.drawer-footer-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  width: 100%;
}
</style>

<template>
  <div
    class="editable-cell"
    :class="{ editable, editing, penalty: penalty && !editing, 'is-text': text }"
    @click="editable && !editing && emit('edit')"
  >
    <el-input
      v-if="editing && text"
      v-model="draftText"
      size="small"
      @keyup.enter="commit"
      @blur="commit"
      ref="inputRef"
    />
    <el-input-number
      v-else-if="editing"
      v-model="draftNumber"
      size="small"
      :precision="2"
      controls-position="right"
      @keyup.enter="commit"
      @blur="commit"
      ref="numRef"
    />
    <template v-else>
      <span class="cell-text">{{ displayText }}</span>
      <el-icon v-if="editable" class="edit-hint"><EditPen /></el-icon>
    </template>
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, ref, watch } from "vue";
import { EditPen } from "@element-plus/icons-vue";

const props = withDefaults(
  defineProps<{
    editing: boolean;
    value?: number | string;
    text?: boolean;
    editable?: boolean;
    penalty?: boolean;
  }>(),
  { text: false, editable: false, penalty: false },
);

const emit = defineEmits<{
  save: [number | string];
  close: [];
  edit: [];
}>();

const inputRef = ref();
const numRef = ref();
const draftNumber = ref(0);
const draftText = ref("");

watch(
  () => props.editing,
  async (v) => {
    if (!v) return;
    draftText.value = String(props.value ?? "");
    draftNumber.value = Number(props.value) || 0;
    await nextTick();
    if (props.text) inputRef.value?.focus?.();
    else numRef.value?.focus?.();
  },
);

const displayText = computed(() => {
  if (props.text) return props.value || "-";
  const n = Number(props.value);
  return Number.isFinite(n) ? n.toFixed(2) : "-";
});

const commit = () => {
  emit("save", props.text ? draftText.value : draftNumber.value);
  emit("close");
};
</script>

<style scoped>
.editable-cell {
  position: relative;
  min-height: 28px;
  display: flex;
  align-items: center;
  border-radius: 6px;
  padding: 2px 0;
  transition: background 0.2s ease;
}

.editable-cell.editable {
  cursor: pointer;
}

.editable-cell.editable:hover {
  background: rgba(64, 158, 255, 0.1);
  outline: 1px dashed rgba(64, 158, 255, 0.35);
}

.editable-cell.editing {
  background: #fff;
  outline: 2px solid rgba(64, 158, 255, 0.45);
}

.editable-cell.penalty .cell-text {
  color: #f56c6c;
  font-weight: 500;
}

.cell-text {
  display: block;
  width: 100%;
  font-variant-numeric: tabular-nums;
  text-align: right;
}

.editable-cell.is-text .cell-text {
  text-align: left;
}

.edit-hint {
  position: absolute;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  font-size: 12px;
  color: #c0c4cc;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.2s;
}

.editable-cell.editable:hover .edit-hint {
  opacity: 1;
}

.editable-cell :deep(.el-input-number) {
  width: 100%;
}
</style>

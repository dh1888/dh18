<template>
  <span
    v-if="displayText"
    class="copyable-text"
    :class="{ mono }"
    title="点击复制"
    @click.stop="handleCopy"
  >
    {{ displayText }}
  </span>
  <span v-else class="copyable-empty">{{ emptyText }}</span>
</template>

<script setup lang="ts">
import { computed } from "vue";
import { ElMessage } from "element-plus";

const props = withDefaults(
  defineProps<{
    text?: string | null;
    label?: string;
    mono?: boolean;
    emptyText?: string;
  }>(),
  {
    mono: true,
    emptyText: "-",
  },
);

const displayText = computed(() => {
  const value = props.text?.trim();
  return value || "";
});

async function handleCopy() {
  const value = displayText.value;
  if (!value) return;
  try {
    await navigator.clipboard.writeText(value);
    ElMessage.success(props.label ? `${props.label}已复制` : "已复制");
  } catch {
    ElMessage.error("复制失败，请手动复制");
  }
}
</script>

<style scoped>
.copyable-text {
  cursor: pointer;
  color: #409eff;
  word-break: break-all;
}

.copyable-text:hover {
  text-decoration: underline;
}

.copyable-text.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.copyable-empty {
  color: #c0c4cc;
}
</style>

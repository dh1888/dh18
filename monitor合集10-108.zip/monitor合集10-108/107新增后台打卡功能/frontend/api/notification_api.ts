import request from "./request";

export interface UserNotification {
  id: string;
  type: string;
  title: string;
  content: string;
  isRead: boolean;
  showPopup: boolean;
  createdAt: string;
  payload?: Record<string, unknown>;
}

const notificationApi = {
  list: (params?: { limit?: number }) =>
    request.get<{ items: UserNotification[]; unreadCount: number }>(
      "/notifications",
      { params },
    ),

  unreadCount: () =>
    request.get<{ unreadCount: number }>("/notifications/unread-count"),

  popups: () => request.get<UserNotification[]>("/notifications/popups"),

  markRead: (id: string) => request.post(`/notifications/${id}/read`),

  markAllRead: () => request.post("/notifications/read-all"),
};

export default notificationApi;

import request from "./request";

export interface CsToolSettings {
  toolUrl: string;
  scriptUrl: string;
  updatedAt?: string;
}

const csToolApi = {
  getSettings: () => request.get<CsToolSettings>("/admin/cs-tool/settings"),
  saveSettings: (data: CsToolSettings) => request.put<CsToolSettings>("/admin/cs-tool/settings", data),
};

export default csToolApi;

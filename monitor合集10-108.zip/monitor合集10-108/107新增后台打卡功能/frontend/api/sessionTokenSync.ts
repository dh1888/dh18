/** Sync refreshed tokens into the Pinia user store without circular imports. */

type SessionTokenApplier = (
  token: string,
  expiresAt: string,
  refreshToken?: string,
) => void;

let applier: SessionTokenApplier | null = null;

export function registerSessionTokenApplier(fn: SessionTokenApplier) {
  applier = fn;
}

export function applyRefreshedSessionTokens(
  token: string,
  expiresAt: string,
  refreshToken?: string,
) {
  try {
    applier?.(token, expiresAt, refreshToken);
  } catch {
    // Pinia 未初始化时仅依赖 sessionStorage
  }
}

/** Cross-tab refresh coordination to avoid single-use refresh token rotation races. */

const REFRESH_LOCK_KEY = "auth_refresh_lock";
const REFRESH_RESULT_KEY = "auth_refresh_result";
const LOCK_TTL_MS = 15000;
const CHANNEL_NAME = "auth-token-refreshed";

import type { AuthUserInfo } from "@api/types";

export type RefreshResultPayload = {
  token: string;
  refreshToken: string;
  expiresAt: string;
  user?: AuthUserInfo;
  permissions?: string[];
  role?: string;
};

function getChannel(): BroadcastChannel | null {
  if (typeof BroadcastChannel === "undefined") return null;
  return new BroadcastChannel(CHANNEL_NAME);
}

function readLockAge(): number | null {
  const raw = localStorage.getItem(REFRESH_LOCK_KEY);
  if (!raw) return null;
  const ts = parseInt(raw, 10);
  return Number.isFinite(ts) ? Date.now() - ts : null;
}

function tryAcquireLock(): boolean {
  const age = readLockAge();
  if (age !== null && age < LOCK_TTL_MS) return false;
  localStorage.setItem(REFRESH_LOCK_KEY, String(Date.now()));
  return true;
}

function releaseLock() {
  localStorage.removeItem(REFRESH_LOCK_KEY);
}

function publishResult(payload: RefreshResultPayload) {
  localStorage.setItem(REFRESH_RESULT_KEY, JSON.stringify(payload));
  getChannel()?.postMessage(payload);
  releaseLock();
}

function waitForPeerRefresh(timeoutMs = 12000): Promise<RefreshResultPayload | null> {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (payload: RefreshResultPayload | null) => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(payload);
    };

    const onStorage = (event: StorageEvent) => {
      if (event.key !== REFRESH_RESULT_KEY || !event.newValue) return;
      try {
        finish(JSON.parse(event.newValue) as RefreshResultPayload);
      } catch {
        finish(null);
      }
    };

    const channel = getChannel();
    const onMessage = (event: MessageEvent) => {
      finish(event.data as RefreshResultPayload);
    };

    const timer = window.setTimeout(() => finish(null), timeoutMs);

    const cleanup = () => {
      window.clearTimeout(timer);
      window.removeEventListener("storage", onStorage);
      channel?.removeEventListener("message", onMessage);
      channel?.close();
    };

    window.addEventListener("storage", onStorage);
    channel?.addEventListener("message", onMessage);

    const cached = localStorage.getItem(REFRESH_RESULT_KEY);
    if (cached) {
      try {
        finish(JSON.parse(cached) as RefreshResultPayload);
        return;
      } catch {
        // ignore
      }
    }
  });
}

/** Runs refreshFn in one tab; others wait for the published tokens. */
export async function runCoordinatedRefresh(
  refreshFn: () => Promise<RefreshResultPayload | null>,
): Promise<RefreshResultPayload | null> {
  if (tryAcquireLock()) {
    try {
      const result = await refreshFn();
      if (result) publishResult(result);
      else releaseLock();
      return result;
    } catch (err) {
      releaseLock();
      throw err;
    }
  }
  return waitForPeerRefresh();
}

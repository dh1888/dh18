// api/rateLimitInterceptor.ts
import type { AxiosInstance, InternalAxiosRequestConfig } from "axios";
import {
  loginLimiter,
  registerLimiter,
  uploadLimiter,
} from "./rateLimiter";

function normalizePath(url: string): string {
  return (url.split("?")[0] || "").replace(/^\/api\/v1/, "");
}

function getLimiterForRequest(method: string, url: string) {
  const path = normalizePath(url);
  const upperMethod = method.toUpperCase();

  if (upperMethod === "POST" && path === "/auth/login") {
    return loginLimiter;
  }
  if (upperMethod === "POST" && path === "/auth/refresh") {
    return loginLimiter;
  }
  if (upperMethod === "POST" && path === "/devices/register") {
    return registerLimiter;
  }
  if (upperMethod === "POST" && path.startsWith("/upload/")) {
    return uploadLimiter;
  }

  // 其余已登录后台请求交给服务端限流，避免列表/截图批量加载误触客户端节流
  return null;
}

export function setupRateLimitInterceptor(axiosInstance: AxiosInstance) {
  axiosInstance.interceptors.request.use(
    (config: InternalAxiosRequestConfig) => {
      const method = config.method?.toUpperCase() || "GET";
      const url = config.url || "";
      const limiter = getLimiterForRequest(method, url);

      if (limiter && !limiter.canExecute()) {
        throw new Error("请求过于频繁，请稍后再试");
      }

      return config;
    },
  );
}

import request from "./request";

const workforceApi = {
  getPortalMe: () => request.get<any>("/employee/portal/me"),
  getMyInviteCode: () => request.get<any>("/user/invite-code"),
  getMyAttendance: (yearMonth?: string) =>
    request.get<any>("/employee/attendance", { params: { year_month: yearMonth } }),
  getMyAttendanceOverview: (yearMonth?: string) =>
    request.get<any>("/employee/attendance/overview", { params: { year_month: yearMonth } }),
  getMyDevice: () => request.get<any>("/employee/device"),
  getClientDownload: () => request.get<any>("/employee/client-download"),

  downloadClientFile: () =>
    request.get<Blob>("/employee/client-download/file", {
      responseType: "blob",
    }),

  createEmployeeAccount: (data: {
    username: string;
    password: string;
    name: string;
    employee_id?: string;
    position?: string;
    department?: string;
    hire_date?: string;
    work_location?: string;
  }) => request.post("/admin/employee-accounts", data),

  listInviteCodes: (employeeId?: string) =>
    request.get<any>("/admin/invite-codes", { params: { employee_id: employeeId } }),

  listInviteCodeHistory: (employeeId?: string) =>
    request.get<any>("/admin/invite-codes/history", { params: { employee_id: employeeId } }),

  revokeInviteCode: (id: string) => request.post(`/admin/invite-codes/${id}/revoke`),

  regenerateInviteCode: (employeeId: string) =>
    request.post(`/admin/employees/${employeeId}/invite-code/regenerate`),

  getInviteCodeSettings: () => request.get<any>("/admin/invite-codes/settings"),

  updateInviteCodeSettings: (validDays: number) =>
    request.put<any>("/admin/invite-codes/settings", { validDays }),

  disableEmployee: (employeeId: string) =>
    request.post(`/admin/employees/${employeeId}/disable`),
};

export default workforceApi;

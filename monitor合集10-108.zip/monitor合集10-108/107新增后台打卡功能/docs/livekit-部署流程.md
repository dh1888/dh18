# LiveKit / 远程查看 — 生产部署流程

> **配置源（以仓库为准）**  
> - 运行配置：`livekit/livekit.yaml`、`livekit/docker-compose.yml`  
> - 本文档备份：`docs/livekit.yaml`、`docs/livekit-docker-compose.yml`（须与 `livekit/` 保持同步）  
> - 服务器路径：`/www/wwwroot/livekit`  
> - 运维清单：`docs/whip-ops.md` · 上线检查：`docs/whip-only-deploy.md`

服务器：`43.106.86.216`（`dhpg8.duckdns.org`）  
镜像：`livekit/livekit-server:v1.13.3` + `livekit/ingress:v1.4.3`

---

## 1. 架构（当前已验证：WHIP-only + SharedBridge）

```
Agent 采集（gdigrab / SharedBridge）
        │
        ├─► FFmpeg 录屏 → 本地 MP4 切片
        └─► FFmpeg WHIP ──HTTPS──► Nginx /w ──► Ingress:8085（仅本机）
                                      │
                                      └─ UDP 7893 ──► LiveKit Room
                                                          │
浏览器 ◄── wss /livekit + RTC 7881 / 7882-7892/UDP ──────┘
```

| 链路 | 入口 | 说明 |
|------|------|------|
| 浏览器信令 | `https://域名/livekit` → `:7880` | Nginx 反代 |
| 浏览器媒体 | `7881/TCP` + `7882–7892/UDP` | 安全组放行 |
| Agent WHIP 信令 | `https://域名/w` → `127.0.0.1:8085` | **勿公网开放 8085** |
| Agent WHIP 媒体 | **UDP 7893** | 必须放行 |
| RTMP | `:1935` | 仅紧急 `PROTOCOL=rtmp/auto`；whip-only 日常不用 |

**禁止：**

- Ingress 配置 `tcp_port`（FFmpeg 遇 TCP candidate → `ret=-5`）
- 对公网开放 `8085`
- 生产默认 `REMOTE_VIEW_PUBLISH_PROTOCOL=auto`（会误走 RTMP 回退）

---

## 2. 同步配置到服务器

在开发机把仓库 `livekit/` 同步上去（任选一种）：

```bash
# 推荐：直接用仓库 livekit/ 目录
scp livekit/livekit.yaml livekit/docker-compose.yml root@43.106.86.216:/www/wwwroot/livekit/

# 或使用 docs 备份（内容须与 livekit/ 一致）
# scp docs/livekit.yaml docs/livekit-docker-compose.yml ...
```

服务器上：

```bash
mkdir -p /www/wwwroot/livekit
cd /www/wwwroot/livekit
# 确认文件：livekit.yaml、docker-compose.yml

# 若 eth0 私网 IP 变更，改 docker-compose.yml 里：
#   node_ip: 43.106.86.216/<当前 eth0 私网>
docker compose up -d
docker compose ps
docker logs --tail=40 $(docker ps -qf name=ingress)
```

期望 Ingress 日志 `using external IPs` 主要为 `43.106.86.216/<eth0私网>`，不要一串 docker 桥接地址。

---

## 3. 本机自检

```bash
curl -s http://127.0.0.1:7880
# 有响应即可

curl -sI http://127.0.0.1:7880/rtc/v1/validate
# 期望 401（未带 token = 正常）

curl -sI http://127.0.0.1:8085/w/testkey
# 期望 405

ss -ulnp | grep 7893
# 应有 Ingress 监听 UDP 7893
```

公网自检（任意机器）：

```bash
curl -sI https://dhpg8.duckdns.org/livekit/
# 期望 200

curl -sI https://dhpg8.duckdns.org/w/testkey
# 期望 405
```

---

## 4. Nginx（站点 vhost）

参考 `docs/nginx.conf`，必须包含：

- `location /livekit/` → `http://127.0.0.1:7880/`（WebSocket 升级）
- `location /w/` → `http://127.0.0.1:8085/w/`（WHIP 信令）

改完后：

```bash
nginx -t && nginx -s reload
```

---

## 5. Backend `.env`（监控中心）

路径示例：`/www/wwwroot/agent/backend/.env`  
完整模板见 `docs/backend后端env服务器配置.txt`。

关键项：

```env
LIVEKIT_URL=wss://dhpg8.duckdns.org/livekit
LIVEKIT_API_HOST=http://127.0.0.1:7880
LIVEKIT_API_KEY=enterprise
LIVEKIT_API_SECRET=<与 livekit.yaml keys 一致>
LIVEKIT_WHIP_BASE_URL=https://dhpg8.duckdns.org/w
LIVEKIT_RTMP_BASE_URL=rtmp://43.106.86.216:1935/x
REMOTE_VIEW_PUBLISH_PROTOCOL=whip
REMOTE_VIEW_PUBLISHER_GRACE_SECONDS=0
```

```bash
grep -E 'REMOTE_VIEW_PUBLISH|REMOTE_VIEW_PUBLISHER|LIVEKIT_' /www/wwwroot/agent/backend/.env
# 确认 PROTOCOL=whip、PUBLISHER_GRACE=0（关页面后立即停推，避免 stale session）
# 然后重启 backend（Supervisor / systemd）
```

会话行为（当前代码）：

- 停止远程后会延迟删除 Ingress，并清理 LiveKit Room，避免下次重开订到「冻住旧画面」
- `REMOTE_VIEW_PUBLISHER_GRACE_SECONDS=0` 时关页面即停 Agent 推流，下次打开走全新 session
- 前端死帧恢复：先重 attach track → Agent 重推流 → 最后才重连 LiveKit（避免 disconnect 风暴）
- Ingress 参与者身份按会话唯一，避免同设备身份冲突

---

## 6. Agent

- 使用含 SharedBridge + WHIP（`-ts_buffer_size 8388608`）的 `publish/DHPG.exe`
- **必须**带同目录 `ffmpeg.exe`（缺 FFmpeg 则录屏/远程均失败）
- `deployment.json` 的 `serverUrl` 指向监控中心（如 `https://dhpg8.duckdns.org` 或 `http://IP:8080`）

成功日志关键字：

```text
Enter SharedBridge: ... protocol=whip
WHIP muxer ready: ... Muxer state=10
WHIP media flowing
```

---

## 7. 安全组清单

| 端口 | 协议 | 用途 |
|------|------|------|
| 443 | TCP | Nginx（HTTPS、`/w`、`/livekit`） |
| 7881 | TCP | 浏览器 WebRTC TCP |
| 7882–7892 | UDP | 浏览器 WebRTC 媒体 |
| 7893 | UDP | **Agent WHIP 媒体（必须）** |
| 1935 | TCP | 可选（RTMP 休眠） |
| 8085 | — | **仅本机**，勿公网开放 |

---

## 8. 端到端验证

1. Agent 在线，托盘健康。
2. Web「远程查看」→ 开始查看 → 数秒内出画（状态可先显示「推流启动中」）。
3. 停止查看 → 再开始查看 → 应稳定出画（不应必须「再停一次才好」）。
4. 服务器：

```bash
timeout 25 tcpdump -ni any udp port 7893 -c 30
docker logs -f --tail=30 $(docker ps -qf name=ingress)
```

---

## 9. 常见失败

| 现象 | 处理 |
|------|------|
| `ffmpeg.exe not found` | 把 ffmpeg 放到 `DHPG.exe` 同目录 |
| `Protocol tcp is not supported` / `ret=-5` | Ingress 去掉 `tcp_port`，只留 `udp_port: 7893` 后重建 |
| `UDP send blocked` / `ret=-11` | Agent 带 `-ts_buffer_size`；确认 UDP 7893 |
| 关后再开画面冻住/不实时 | 确认已部署含 Room 清理的 backend + 前端；见上文会话行为 |
| `whip_fallback_failed` | 正常：`PROTOCOL=whip` 拒绝 RTMP；修 WHIP 即可 |
| Ingress DNS / `-10054` | 勿只升级 livekit 容器而跳过 compose；保持当前 host 网络 Ingress |

---

## 10. 文件对照

| 仓库路径 | 服务器路径 |
|----------|------------|
| `livekit/livekit.yaml` | `/www/wwwroot/livekit/livekit.yaml` |
| `livekit/docker-compose.yml` | `/www/wwwroot/livekit/docker-compose.yml` |
| `docs/nginx.conf` | 宝塔站点 vhost（含 `/livekit/`、`/w/`） |
| `docs/backend后端env服务器配置.txt` | backend `.env` 参考 |

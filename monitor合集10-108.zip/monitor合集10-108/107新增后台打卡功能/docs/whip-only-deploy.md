# WHIP-only 上线（不要 RTMP 回退）

完整部署步骤见：**[livekit-部署流程.md](./livekit-部署流程.md)**。本文为检查清单。

**不要对公网开放 8085。** WHIP 信令走 `https://域名/w` → Nginx → `127.0.0.1:8085`。
媒体走 **UDP 7893**。

**配置源**：仓库 `livekit/`（`livekit.yaml` + `docker-compose.yml`）→ 服务器 `/www/wwwroot/livekit`。

Agent 保持 **SharedBridge**（单路采集、双编码器）。WHIP 启动顺序：
先挂远程 FFmpeg → 再启管道生产者 → 最后等 ICE/媒体就绪（避免旧死锁）。

## 1) 同步 LiveKit 栈

```bash
cd /www/wwwroot/livekit
# 上传仓库 livekit/livekit.yaml、livekit/docker-compose.yml
# 若 eth0 私网 IP 变更，改 compose 里 node_ip: 公网/私网
docker compose up -d
docker logs --tail=40 $(docker ps -qf name=ingress)
curl -sI http://127.0.0.1:8085/w/testkey   # 期望 405
ss -ulnp | grep 7893
```

期望 Ingress `using external IPs` 主要是 `43.106.86.216/<eth0私网>`，不要一串 docker 桥。

## 2) 安全组

入站 **UDP 7893**（必须）。不要开公网 8085。
**不要**在 Ingress 配置 `tcp_port`（FFmpeg WHIP 会因 TCP candidate 直接 `-5`）。

## 3) Backend 强制 WHIP

```bash
cd /www/wwwroot/agent/backend
sed -i 's/^REMOTE_VIEW_PUBLISH_PROTOCOL=.*/REMOTE_VIEW_PUBLISH_PROTOCOL=whip/' .env
grep -E 'REMOTE_VIEW_PUBLISH|LIVEKIT_WHIP' .env
# Supervisor 重启 agent-backend
```

`REMOTE_VIEW_PUBLISH_PROTOCOL=whip` 时：**不会**再回退 RTMP。

## 4) Agent

使用含 SharedBridge 顺序修复 + `-ts_buffer_size 8388608` 的 `publish/DHPG.exe`，同目录必须有 `ffmpeg.exe`。

## 5) 验证

```bash
timeout 25 tcpdump -ni any udp port 7893 -c 30
docker logs -f --tail=20 $(docker ps -qf name=ingress)
```

成功：tcpdump 有包；Agent `WHIP muxer ready` + `WHIP media flowing`；浏览器出画。
停止后再开始应稳定，无需「再停一次才好」。

# 域名监控探针（dm-probe）部署说明

> 整条「中心 + 探针」流程见：**[域名检测-部署流程.md](./域名检测-部署流程.md)**。本文只写探针机细节。

探针跑在**独立 VPS / 服务器**上，向监控中心拉取任务并回报结果。  
**不要**把 `DM_SERVER`、`DM_NODE_KEY` 写进监控中心 backend 的 `.env`。

---

## 环境变量填在哪里？

填在**探针机器**上，推荐写入：

```text
/opt/dm-probe/dm-probe.env
```

由 systemd 的 `EnvironmentFile=` 加载。也可在启动前 `export`，或写进 shell 启动脚本。

| 变量 | 填什么 | 从哪来 |
|------|--------|--------|
| `DM_SERVER` | 监控中心对外可访问地址，如 `https://monitor.example.com` 或 `http://1.2.3.4:8080` | 你的中心站点 URL（探针要能访问到） |
| `DM_NODE_KEY` | 节点 API Key | 后台「域名监控 → 节点」创建节点后弹窗里复制（只显示一次） |

示例 `dm-probe.env`：

```bash
DM_SERVER=https://你的监控中心域名
DM_NODE_KEY=后台返回的APIKey
```

注意：

- 文件里一般**不要**写 `export`（systemd `EnvironmentFile` 用 `KEY=value` 即可）
- 若用自动注册，可不用 `DM_NODE_KEY`，改用 `DM_REGISTER_TOKEN` + `DM_NODE_NAME`（见下文）
- 自动注册成功后会在可执行文件旁生成 `dm-node.key`，重启会复用，无需每次重新注册

---

## 要上传什么

| 文件 | 是否必须 | 说明 |
|------|----------|------|
| `dm-probe` 可执行文件 | 必须 | 按目标系统交叉编译 |
| `scripts/screenshot.mjs` | 仅需要截图检测时 | 并安装 Node + Playwright |
| Go 源码目录 | 不需要 | 生产用编译产物 |

在开发机（Windows）为 Linux amd64 打包：

```powershell
cd backend
$env:GOOS="linux"; $env:GOARCH="amd64"; $env:CGO_ENABLED="0"
go build -o dm-probe ./cmd/dm-probe
```

上传到探针服务器，例如：

```text
/opt/dm-probe/dm-probe
/opt/dm-probe/scripts/screenshot.mjs   # 可选
```

---

## 部署步骤（Linux + systemd）

### 1. 准备目录与二进制

```bash
mkdir -p /opt/dm-probe/scripts
# 将 dm-probe（及可选的 screenshot.mjs）上传到对应路径
chmod +x /opt/dm-probe/dm-probe
```

### 2. 后台准备节点 Key（手动方式，推荐生产）

1. 打开监控中心 Web：**域名监控 → 节点**
2. 添加节点（名称 / 国家等）
3. 弹窗中的 **API Key 只显示一次**，立即复制
4. 写入探针机上的 env 文件（见下一步）

### 3. 写环境文件（变量就填在这里）

```bash
cat >/opt/dm-probe/dm-probe.env <<'EOF'
DM_SERVER=https://你的监控中心域名
DM_NODE_KEY=后台返回的APIKey
EOF

chmod 600 /opt/dm-probe/dm-probe.env
```

把两行改成你的真实值。探针必须能访问 `DM_SERVER`（防火墙 / HTTPS / 反代放行）。

### 4.（可选）自动注册方式

若不想手动建节点：

1. Web：**域名监控 → 检测配置 → Probe 注册令牌** 设好令牌并保存  
2. env 改为：

```bash
DM_SERVER=https://你的监控中心域名
DM_REGISTER_TOKEN=检测配置里的注册令牌
DM_NODE_NAME=Brazil-1
DM_NODE_COUNTRY=BR
# DM_NODE_CITY=SaoPaulo
```

不要同时依赖未保存的空 `DM_NODE_KEY`；有本地 `dm-node.key` 或有效 `DM_NODE_KEY` 时优先用已有 Key。

### 5.（可选）截图能力

```bash
cd /opt/dm-probe/scripts
npm i playwright
npx playwright install chromium
```

在 `dm-probe.env` 增加：

```bash
DM_SCREENSHOT_SCRIPT=/opt/dm-probe/scripts/screenshot.mjs
```

### 6. systemd 常驻

```bash
cat >/etc/systemd/system/dm-probe.service <<'EOF'
[Unit]
Description=Domain Monitor Probe
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/dm-probe
EnvironmentFile=/opt/dm-probe/dm-probe.env
ExecStart=/opt/dm-probe/dm-probe
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now dm-probe
journalctl -u dm-probe -f
```

看到类似 `node key ready:`，且 heartbeat 无持续报错；后台「节点」页该节点在线，即部署成功。

---

## 可选环境变量

| 变量 | 说明 |
|------|------|
| `DM_NODE_KEY_FILE` | Key 文件路径，默认：可执行文件旁 `dm-node.key` |
| `DM_NODE_COUNTRY` / `DM_NODE_CITY` | 自动注册时的国家 / 城市 |
| `DM_SCREENSHOT_SCRIPT` | Playwright 脚本绝对路径 |
| `HTTP_PROXY` / `HTTPS_PROXY` | 探针本机出网代理（任务级代理优先） |

---

## 常见问题

**Q：`export DM_SERVER=...` 是在中心服务器上执行吗？**  
A：不是。在**探针 VPS** 上配置；用 systemd 时写进 `/opt/dm-probe/dm-probe.env`，不必手敲 `export`。

**Q：中心 backend `.env` 要加这些吗？**  
A：不用。中心只需正常提供 API；自动注册时在 Web「检测配置」里设注册令牌即可。

**Q：重启后又注册出一个新节点？**  
A：确认已落盘 `dm-node.key`，或固定配置了 `DM_NODE_KEY`。当前版本会持久化 Key，避免重复注册。

**Q：heartbeat 401？**  
A：Key 错误、节点被删/禁用，或 `DM_SERVER` 指到了错误环境。核对 Key 与中心地址。

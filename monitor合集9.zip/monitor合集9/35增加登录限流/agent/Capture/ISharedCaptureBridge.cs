namespace EnterpriseAgent.Agent.Capture;

public interface ISharedCaptureBridge
{
    SharedBridgeState State { get; }
    SharedBridgeReadyFlags ReadyFlags { get; }
    bool IsActive { get; }

    Task PrepareAsync(int width, int height, int fps, CancellationToken cancellationToken = default);
    Task WaitConsumersConnectedAsync(CancellationToken cancellationToken = default);
    Task StartBridgeAsync(CancellationToken cancellationToken = default);
    Task WaitFlowingAsync(CancellationToken cancellationToken = default, bool requireConsumerFirstFrames = true);
    Task StopAsync(CancellationToken cancellationToken = default);
    Task RestartProducerAsync(CancellationToken cancellationToken = default);
    Task ReconnectConsumerAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default);
    Task ResetSessionAsync(CancellationToken cancellationToken = default);
    Task DisposeAsync(CancellationToken cancellationToken = default);

    void NotifyConsumerFirstFrame(CaptureConsumer consumer);
    bool NeedsConsumerFirstFrame(CaptureConsumer consumer);
    SharedBridgeHealthSnapshot GetHealthSnapshot();
}

public sealed class SharedBridgeHealthSnapshot
{
    public SharedBridgeState State { get; init; }
    public SharedBridgeReadyFlags ReadyFlags { get; init; }
    public bool BridgeProcessAlive { get; init; }
    public bool RecordingPipeConnected { get; init; }
    public bool RemotePipeConnected { get; init; }
    public bool FrameFlowing { get; init; }
    public long FramesWritten { get; init; }
    public long FramesSinceUtc { get; init; }
    public DateTime LastFrameUtc { get; init; }
    public string? LastError { get; init; }
}

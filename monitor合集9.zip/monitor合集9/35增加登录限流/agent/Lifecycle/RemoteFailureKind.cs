namespace EnterpriseAgent.Agent.Lifecycle;

public enum RemoteFailureKind
{
    Unknown,
    UserStop,
    TransportError,
    FfmpegCrash,
    ServerKick,
    Timeout,
}

public static class RemoteFailureClassifier
{
    public static RemoteFailureKind Classify(string? detail, bool intentionalUserStop)
    {
        if (intentionalUserStop)
            return RemoteFailureKind.UserStop;

        if (string.IsNullOrWhiteSpace(detail))
            return RemoteFailureKind.Unknown;

        if (detail.Contains("Timed out waiting", StringComparison.OrdinalIgnoreCase))
            return RemoteFailureKind.Timeout;

        if (detail.Contains("-10053", StringComparison.Ordinal) ||
            detail.Contains("-10054", StringComparison.Ordinal) ||
            detail.Contains("Error submitting a packet", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("RTMP transport error", StringComparison.OrdinalIgnoreCase))
            return RemoteFailureKind.TransportError;

        if (detail.Contains("Publish failed", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("not_found", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("ingress", StringComparison.OrdinalIgnoreCase))
            return RemoteFailureKind.ServerKick;

        if (detail.Contains("exit code -1", StringComparison.OrdinalIgnoreCase) ||
            detail.Contains("exited with code -1", StringComparison.OrdinalIgnoreCase))
            return RemoteFailureKind.FfmpegCrash;

        if (detail.Contains("ffmpeg exited", StringComparison.OrdinalIgnoreCase))
            return RemoteFailureKind.FfmpegCrash;

        return RemoteFailureKind.Unknown;
    }
}

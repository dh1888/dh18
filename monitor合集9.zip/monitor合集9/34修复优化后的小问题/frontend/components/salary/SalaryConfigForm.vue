<template>
  <div class="salary-config-form">
    <div class="config-grid">
      <div v-for="field in fields" :key="field.key" class="config-field-card">
        <div class="field-head">
          <div class="field-icon" :style="{ background: field.gradient }">
            <el-icon><component :is="field.icon" /></el-icon>
          </div>
          <div>
            <div class="field-label">{{ field.label }}</div>
            <div class="field-hint">{{ field.hint }}</div>
          </div>
        </div>
        <div class="field-input-row">
          <el-input-number
            v-model="model[field.key]"
            :min="field.min"
            :max="field.max"
            :precision="field.precision"
            :step="field.step"
            controls-position="right"
            class="field-input"
          />
          <el-select
            v-if="field.currencyKey"
            v-model="model[field.currencyKey]"
            class="currency-select"
            placeholder="币种"
          >
            <el-option v-for="c in currencyOptions" :key="c" :label="c" :value="c" />
          </el-select>
        </div>
      </div>

      <div class="config-field-card exchange-card">
        <div class="field-head">
          <div class="field-icon" :style="{ background: 'linear-gradient(135deg, #fa709a, #fee140)' }">
            <el-icon><Switch /></el-icon>
          </div>
          <div>
            <div class="field-label">汇率与结算币种</div>
            <div class="field-hint">计算工资页按结算币种显示人民币换算汇率：THB 显示 CNY/THB，USD 显示 USD/CNY</div>
          </div>
        </div>

        <div class="exchange-grid">
          <div class="exchange-item">
            <label>人民币兑泰铢</label>
            <span class="exchange-desc">1 CNY =</span>
            <el-input-number
              v-model="model.cnyThbRate"
              :min="0"
              :precision="4"
              :step="0.01"
              controls-position="right"
              class="exchange-input"
            />
            <span class="exchange-unit">THB</span>
          </div>
          <div class="exchange-item">
            <label>人民币兑美元</label>
            <span class="exchange-desc">1 USD =</span>
            <el-input-number
              v-model="model.cnyUsdRate"
              :min="0"
              :precision="4"
              :step="0.01"
              controls-position="right"
              class="exchange-input"
              @change="syncLegacyExchangeRate"
            />
            <span class="exchange-unit">CNY</span>
          </div>
          <div class="exchange-item">
            <label>泰铢兑美元</label>
            <span class="exchange-desc">1 USD =</span>
            <el-input-number
              v-model="model.thbUsdRate"
              :min="0"
              :precision="4"
              :step="0.01"
              controls-position="right"
              class="exchange-input"
            />
            <span class="exchange-unit">THB</span>
          </div>
          <div class="exchange-item payout-item">
            <label>最终结算币种</label>
            <el-select v-model="model.payoutCurrency" class="payout-select">
              <el-option v-for="c in payoutOptions" :key="c" :label="c" :value="c" />
            </el-select>
          </div>
        </div>
      </div>
    </div>

    <div class="position-caps-block">
      <div class="block-head">
        <div>
          <strong>岗位底薪封顶</strong>
          <p>达到封顶后当月递增为 0；未达封顶时递增总额正常累加，最后一次递增可能不足配置值。</p>
        </div>
        <el-button type="primary" link @click="addPositionCap">
          <el-icon><Plus /></el-icon>
          添加岗位
        </el-button>
      </div>
      <el-table
        v-if="model.positionCaps?.length"
        :data="model.positionCaps"
        size="small"
        border
        class="caps-table"
      >
        <el-table-column label="岗位名称" min-width="160">
          <template #default="{ row }">
            <el-input v-model="row.position" placeholder="与员工岗位匹配" />
          </template>
        </el-table-column>
        <el-table-column label="底薪封顶 (CNY)" width="180">
          <template #default="{ row }">
            <el-input-number v-model="row.capAmount" :min="0" :precision="2" :step="500" controls-position="right" />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="80" align="center">
          <template #default="{ $index }">
            <el-button link type="danger" @click="removePositionCap($index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-else description="暂无岗位封顶规则" :image-size="64" />
    </div>

    <div class="penalty-note">
      <el-icon class="note-icon"><InfoFilled /></el-icon>
      <div>
        <strong>说明</strong>
        <p>上月底薪首次需手填；保存后下月自动取上月<strong>实际底薪</strong>链式传递。罚款从「考勤绩效 → 罚款详情」按月汇总。</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  TrendCharts,
  Calendar,
  Money,
  Switch,
  Star,
  Lock,
  InfoFilled,
  Plus,
} from "@element-plus/icons-vue";
import type { SalaryWorkConfig } from "@api/admin_api";

defineProps<{ mode?: string }>();
const model = defineModel<SalaryWorkConfig>({ required: true });

const currencyOptions = ["CNY", "USD", "THB"];
const payoutOptions = ["CNY", "USD", "THB"];

type FieldKey = keyof Pick<
  SalaryWorkConfig,
  | "totalIncrease"
  | "fullAttendanceDays"
  | "fullAttendanceAmount"
  | "performanceFullScoreAmount"
  | "protectionFee"
>;

type CurrencyKey = keyof Pick<
  SalaryWorkConfig,
  "fullAttendanceCurrency" | "performanceCurrency" | "protectionFeeCurrency"
>;

const fields: Array<{
  key: FieldKey;
  currencyKey?: CurrencyKey;
  label: string;
  hint: string;
  min: number;
  max?: number;
  precision: number;
  step: number;
  icon: typeof Money;
  gradient: string;
}> = [
  {
    key: "totalIncrease",
    label: "递增总额",
    hint: "底薪 = 上月底薪 + 递增（受岗位封顶限制）",
    min: 0,
    precision: 2,
    step: 100,
    icon: TrendCharts,
    gradient: "linear-gradient(135deg, #667eea, #764ba2)",
  },
  {
    key: "fullAttendanceDays",
    label: "满勤天数",
    hint: "0 = 上满当月自然日",
    min: 0,
    max: 31,
    precision: 0,
    step: 1,
    icon: Calendar,
    gradient: "linear-gradient(135deg, #43e97b, #38f9d7)",
  },
  {
    key: "fullAttendanceAmount",
    currencyKey: "fullAttendanceCurrency",
    label: "满勤金额",
    hint: "达到满勤天数后发放",
    min: 0,
    precision: 2,
    step: 100,
    icon: Money,
    gradient: "linear-gradient(135deg, #4facfe, #00f2fe)",
  },
  {
    key: "performanceFullScoreAmount",
    currencyKey: "performanceCurrency",
    label: "绩效奖励 (10分)",
    hint: "按实际绩效分数比例计算",
    min: 0,
    precision: 2,
    step: 50,
    icon: Star,
    gradient: "linear-gradient(135deg, #f093fb, #f5576c)",
  },
  {
    key: "protectionFee",
    currencyKey: "protectionFeeCurrency",
    label: "保护费",
    hint: "每月固定保护费扣项",
    min: 0,
    precision: 2,
    step: 50,
    icon: Lock,
    gradient: "linear-gradient(135deg, #a18cd1, #fbc2eb)",
  },
];

function syncLegacyExchangeRate() {
  if (model.value.cnyUsdRate != null) {
    model.value.exchangeRate = model.value.cnyUsdRate;
  }
}

function ensureCaps() {
  if (!model.value.positionCaps) {
    model.value.positionCaps = [];
  }
}

function addPositionCap() {
  ensureCaps();
  model.value.positionCaps!.push({ position: "", capAmount: 0 });
}

function removePositionCap(index: number) {
  ensureCaps();
  model.value.positionCaps!.splice(index, 1);
}
</script>

<style scoped>
.salary-config-form {
  width: 100%;
}

.config-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
}

.config-field-card {
  padding: 18px;
  border-radius: 16px;
  background: #f8fafc;
  border: 1px solid #eef2f7;
  transition: all 0.25s ease;
}

.config-field-card:hover {
  border-color: rgba(64, 158, 255, 0.25);
  box-shadow: 0 6px 20px rgba(64, 158, 255, 0.08);
  transform: translateY(-2px);
}

.exchange-card {
  grid-column: 1 / -1;
}

.field-head {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 14px;
}

.field-icon {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.field-label {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 4px;
}

.field-hint {
  font-size: 12px;
  color: #909399;
  line-height: 1.4;
}

.field-input-row {
  display: flex;
  gap: 8px;
  align-items: center;
}

.field-input {
  flex: 1;
}

.currency-select {
  width: 96px;
}

.exchange-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px 20px;
}

.exchange-item {
  display: grid;
  grid-template-columns: auto 1fr auto;
  align-items: center;
  gap: 8px;
  padding: 12px 14px;
  border-radius: 12px;
  background: #fff;
  border: 1px solid #ebeef5;
}

.exchange-item label {
  grid-column: 1 / -1;
  font-size: 13px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 2px;
}

.exchange-desc,
.exchange-unit {
  font-size: 12px;
  color: #909399;
  white-space: nowrap;
}

.exchange-input {
  width: 100%;
}

.payout-item {
  grid-template-columns: 1fr;
}

.payout-select {
  width: 100%;
}

.field-input :deep(.el-input__wrapper) {
  border-radius: 10px;
  box-shadow: 0 0 0 1px #e4e7ed inset;
}

.position-caps-block {
  margin-top: 20px;
  padding: 18px;
  border-radius: 16px;
  background: #fff;
  border: 1px solid #eef2f7;
}

.block-head {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 12px;
}

.block-head p {
  margin: 4px 0 0;
  font-size: 12px;
  color: #909399;
  line-height: 1.5;
}

.caps-table {
  width: 100%;
}

.penalty-note {
  display: flex;
  gap: 14px;
  margin-top: 20px;
  padding: 16px 18px;
  border-radius: 14px;
  background: linear-gradient(135deg, rgba(64, 158, 255, 0.08), rgba(64, 158, 255, 0.03));
  border: 1px solid rgba(64, 158, 255, 0.15);
}

.note-icon {
  font-size: 22px;
  color: #409eff;
  flex-shrink: 0;
  margin-top: 2px;
}

.penalty-note strong {
  display: block;
  font-size: 14px;
  color: #303133;
  margin-bottom: 4px;
}

.penalty-note p {
  margin: 0;
  font-size: 13px;
  color: #606266;
  line-height: 1.5;
}

@media (max-width: 900px) {
  .config-grid,
  .exchange-grid {
    grid-template-columns: 1fr;
  }
}
</style>

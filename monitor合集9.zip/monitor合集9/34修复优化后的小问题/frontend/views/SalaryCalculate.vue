<template>
  <div class="salary-calculate-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <div class="page-content">
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon" style="background: linear-gradient(135deg, #667eea, #764ba2)">
            <el-icon :size="24"><User /></el-icon>
          </div>
          <div>
            <div class="stat-value">{{ stats.count }}</div>
            <div class="stat-label">计算人数</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background: linear-gradient(135deg, #43e97b, #38f9d7)">
            <el-icon :size="24"><Money /></el-icon>
          </div>
          <div>
            <div class="stat-value">¥{{ formatNumber(stats.total) }}</div>
            <div class="stat-label">实发合计</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background: linear-gradient(135deg, #4facfe, #00f2fe)">
            <el-icon :size="24"><TrendCharts /></el-icon>
          </div>
          <div>
            <div class="stat-value">¥{{ formatNumber(stats.avg) }}</div>
            <div class="stat-label">人均实发</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background: linear-gradient(135deg, #f093fb, #f5576c)">
            <el-icon :size="24"><Calendar /></el-icon>
          </div>
          <div>
            <div class="stat-value">{{ displayMonth }}</div>
            <div class="stat-label">计算月份</div>
          </div>
        </div>
      </div>

      <el-card class="toolbar-card" shadow="never">
        <div class="toolbar-row">
          <div class="toolbar-filters">
            <el-date-picker
              v-model="selectedMonth"
              type="month"
              placeholder="选择月份"
              format="YYYY年MM月"
              value-format="YYYY-MM"
              size="large"
              class="month-picker"
              @change="loadDraft"
            />
            <el-input
              v-model="searchKeyword"
              placeholder="搜索员工姓名"
              clearable
              size="large"
              class="search-input"
              :prefix-icon="Search"
            />
          </div>
          <div class="toolbar-actions">
            <el-button size="large" class="action-btn" @click="loadDraft" :loading="loading">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
            <el-button size="large" type="primary" class="action-btn primary-btn" :loading="calculating" @click="calculateAll">
              <el-icon><Cpu /></el-icon>
              计算全部
            </el-button>
            <el-button size="large" type="success" class="action-btn success-btn" :loading="saving" @click="saveAll">
              <el-icon><FolderChecked /></el-icon>
              保存到工资记录
            </el-button>
          </div>
        </div>
        <div class="edit-legend">
          <span class="legend-title">可双击编辑</span>
          <el-tag v-for="tag in editableTags" :key="tag" size="small" effect="plain" class="legend-tag">
            {{ tag }}
          </el-tag>
        </div>
      </el-card>

      <el-card class="table-card" shadow="never">
        <el-table
          :data="filteredRows"
          v-loading="loading"
          class="salary-calc-table"
          height="calc(100vh - 340px)"
          stripe
          @cell-dblclick="onCellDblClick"
        >
          <el-table-column prop="employeeName" label="姓名" width="100" fixed>
            <template #default="{ row }">
              <span class="name-cell">{{ row.employeeName }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="position" label="岗位" width="100" show-overflow-tooltip />
          <el-table-column prop="hireDateDept" label="入职日期" width="130" show-overflow-tooltip />
          <el-table-column prop="workLocation" label="工作地点" width="110">
            <template #default="{ row }">
              <el-tag size="small" :type="locationTagType(row.workLocation)" effect="light" round>
                {{ row.workLocation || "现场" }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="monthsEmployed" label="在职月数" width="88" align="right" header-align="right" />
          <el-table-column prop="lastMonthBase" width="118" align="right" header-align="right" class-name="editable-col">
            <template #header>
              <el-tooltip content="首月手填；之后自动取上月实际底薪（可双击修改）" placement="top">
                <span>上月底薪</span>
              </el-tooltip>
            </template>
            <template #default="{ row }">
              <EditableCell
                editable
                :editing="isEditing(row, 'lastMonthBase')"
                :value="row.lastMonthBase"
                @save="(v) => setManual(row, 'lastMonthBase', v)"
                @close="clearEditing"
              />
            </template>
          </el-table-column>
          <el-table-column prop="totalIncrease" label="递增" width="96" align="right" header-align="right">
            <template #header>
              <el-tooltip content="受岗位封顶限制，到顶后为 0" placement="top">
                <span>递增</span>
              </el-tooltip>
            </template>
            <template #default="{ row }"><span class="money">{{ fmtMoney(row.totalIncrease) }}</span></template>
          </el-table-column>
          <el-table-column prop="baseSalary" label="底薪" width="96" align="right" header-align="right">
            <template #default="{ row }"><span class="money">{{ fmtMoney(row.baseSalary) }}</span></template>
          </el-table-column>
          <el-table-column prop="attendanceDays" label="出勤" width="72" align="right" header-align="right">
            <template #default="{ row }"><span class="num-highlight">{{ row.attendanceDays ?? 0 }}</span></template>
          </el-table-column>
          <el-table-column prop="actualBaseSalary" label="实际底薪" width="96" align="right" header-align="right">
            <template #default="{ row }"><span class="money">{{ fmtMoney(row.actualBaseSalary) }}</span></template>
          </el-table-column>
          <el-table-column prop="attendanceAdjustment" label="满勤" width="88" align="right" header-align="right">
            <template #default="{ row }"><span class="money bonus">{{ fmtMoney(row.attendanceAdjustment) }}</span></template>
          </el-table-column>
          <el-table-column prop="halfYearUnpaidLeave" label="半年未休" width="108" align="right" header-align="right" class-name="editable-col">
            <template #default="{ row }">
              <EditableCell
                editable
                :editing="isEditing(row, 'halfYearUnpaidLeave')"
                :value="row.halfYearUnpaidLeave"
                @save="(v) => setManual(row, 'halfYearUnpaidLeave', v)"
                @close="clearEditing"
              />
            </template>
          </el-table-column>
          <el-table-column prop="exchangeRate" width="108" align="right" header-align="right">
            <template #header>
              <el-tooltip
                content="按结算币种显示人民币换算汇率：THB 为 1 CNY=?THB，USD 为 1 USD=?CNY，CNY 结算为 1"
                placement="top"
              >
                <span>汇率</span>
              </el-tooltip>
            </template>
            <template #default="{ row }">
              <div class="rate-cell">
                <span class="money">{{ fmtExchangeRate(row) }}</span>
                <span v-if="exchangeRateLabel(row)" class="rate-unit">
                  {{ exchangeRateLabel(row) }}
                </span>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="performanceScore" label="绩效分" width="76" align="right" header-align="right">
            <template #default="{ row }">
              <div class="cell-align-right">
                <el-tag size="small" :type="scoreTagType(row.performanceScore)">{{ row.performanceScore ?? 10 }}</el-tag>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="performanceBonusB" label="绩效奖励" width="96" align="right" header-align="right">
            <template #default="{ row }"><span class="money bonus">{{ fmtMoney(row.performanceBonusB) }}</span></template>
          </el-table-column>
          <el-table-column prop="reward" label="奖励" width="96" align="right" header-align="right" class-name="editable-col">
            <template #default="{ row }">
              <EditableCell
                editable
                :editing="isEditing(row, 'reward')"
                :value="row.reward"
                @save="(v) => setManual(row, 'reward', v)"
                @close="clearEditing"
              />
            </template>
          </el-table-column>
          <el-table-column prop="penalty" label="罚款" width="96" align="right" header-align="right" class-name="editable-col">
            <template #default="{ row }">
              <EditableCell
                editable
                :editing="isEditing(row, 'penalty')"
                :value="row.penalty"
                penalty
                @save="(v) => setManual(row, 'penalty', v)"
                @close="clearEditing"
              />
            </template>
          </el-table-column>
          <el-table-column prop="advance" label="预支" width="96" align="right" header-align="right" class-name="editable-col">
            <template #default="{ row }">
              <EditableCell
                editable
                :editing="isEditing(row, 'advance')"
                :value="row.advance"
                @save="(v) => setManual(row, 'advance', v)"
                @close="clearEditing"
              />
            </template>
          </el-table-column>
          <el-table-column prop="otherDeduction" label="其他扣款" width="104" align="right" header-align="right" class-name="editable-col">
            <template #default="{ row }">
              <EditableCell
                editable
                :editing="isEditing(row, 'otherDeduction')"
                :value="row.otherDeduction"
                @save="(v) => setManual(row, 'otherDeduction', v)"
                @close="clearEditing"
              />
            </template>
          </el-table-column>
          <el-table-column prop="protectionReturn" label="保护返还" width="104" align="right" header-align="right" class-name="editable-col">
            <template #default="{ row }">
              <EditableCell
                editable
                :editing="isEditing(row, 'protectionReturn')"
                :value="row.protectionReturn"
                @save="(v) => setManual(row, 'protectionReturn', v)"
                @close="clearEditing"
              />
            </template>
          </el-table-column>
          <el-table-column prop="protectionFee" label="保护费" width="88" align="right" header-align="right">
            <template #default="{ row }"><span class="money penalty">{{ fmtMoney(row.protectionFee) }}</span></template>
          </el-table-column>
          <el-table-column prop="totalSalary" label="实发合计" width="120" align="right" header-align="right" fixed="right">
            <template #default="{ row }">
              <span class="total-salary">{{ currencySymbol(row.payoutCurrency) }}{{ fmtMoney(row.totalSalary) }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="remark" label="备注" min-width="120" class-name="editable-col">
            <template #default="{ row }">
              <EditableCell
                editable
                text
                :editing="isEditing(row, 'remark')"
                :value="row.remark"
                @save="(v) => setManual(row, 'remark', v, true)"
                @close="clearEditing"
              />
            </template>
          </el-table-column>
        </el-table>
      </el-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { ElMessage } from "element-plus";
import {
  User,
  Money,
  TrendCharts,
  Calendar,
  Search,
  Refresh,
  Cpu,
  FolderChecked,
} from "@element-plus/icons-vue";
import adminApi, { type SalaryCalculateRow } from "@api/admin_api";
import EditableCell from "@/components/salary/EditableCell.vue";

const loading = ref(false);
const calculating = ref(false);
const saving = ref(false);
const selectedMonth = ref(new Date().toISOString().slice(0, 7));
const searchKeyword = ref("");
const rows = ref<SalaryCalculateRow[]>([]);
const editing = ref<{ employeeId: string; field: string } | null>(null);

const editableTags = ["上月底薪", "半年未休", "奖励", "罚款", "预支", "其他扣款", "保护返还", "备注"];

const EDITABLE_FIELDS = new Set([
  "lastMonthBase",
  "halfYearUnpaidLeave",
  "reward",
  "penalty",
  "advance",
  "otherDeduction",
  "protectionReturn",
  "remark",
]);

const filteredRows = computed(() => {
  const kw = searchKeyword.value.trim().toLowerCase();
  if (!kw) return rows.value;
  return rows.value.filter((r) => r.employeeName?.toLowerCase().includes(kw));
});

const stats = computed(() => {
  const list = filteredRows.value;
  const total = list.reduce((sum, r) => sum + (Number(r.totalSalary) || 0), 0);
  return {
    count: list.length,
    total,
    avg: list.length ? total / list.length : 0,
  };
});

const displayMonth = computed(() => {
  if (!selectedMonth.value) return "-";
  const [y, m] = selectedMonth.value.split("-");
  return `${y}年${m}月`;
});

const formatNumber = (n: number) =>
  n.toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const fmtMoney = (v: number | undefined) => {
  if (v === undefined || v === null || Number.isNaN(v)) return "-";
  return formatNumber(Number(v));
};

const fmtExchangeRate = (row: SalaryCalculateRow) => {
  const payout = (row.payoutCurrency || "CNY").toUpperCase();
  if (payout === "CNY") return "1.0000";
  const rate = Number(row.exchangeRate);
  if (!Number.isFinite(rate) || rate <= 0) return "-";
  return rate.toLocaleString("zh-CN", { minimumFractionDigits: 4, maximumFractionDigits: 4 });
};

const exchangeRateLabel = (row: SalaryCalculateRow) => {
  if (row.exchangeRateLabel) return row.exchangeRateLabel;
  switch ((row.payoutCurrency || "CNY").toUpperCase()) {
    case "USD":
      return "1 USD = CNY";
    case "THB":
      return "1 CNY = THB";
    default:
      return "";
  }
};

const currencySymbol = (code?: string) => {
  switch ((code || "CNY").toUpperCase()) {
    case "USD":
      return "$";
    case "THB":
      return "฿";
    default:
      return "¥";
  }
};

const locationTagType = (loc?: string) => {
  if (loc?.includes("居家")) return "warning";
  return "success";
};

const scoreTagType = (score?: number) => {
  const s = score ?? 10;
  if (s >= 10) return "success";
  if (s >= 8) return "";
  if (s >= 6) return "warning";
  return "danger";
};

const isEditing = (row: SalaryCalculateRow, field: string) =>
  editing.value?.employeeId === row.employeeId && editing.value?.field === field;

const clearEditing = () => {
  editing.value = null;
};

const onCellDblClick = (row: SalaryCalculateRow, column: any) => {
  const field = column.property;
  if (!field || !EDITABLE_FIELDS.has(field)) return;
  editing.value = { employeeId: row.employeeId, field };
};

const addManualField = (row: SalaryCalculateRow, field: string) => {
  if (!row.manualFields) row.manualFields = [];
  if (!row.manualFields.includes(field)) row.manualFields.push(field);
};

const setManual = (
  source: SalaryCalculateRow,
  field: keyof SalaryCalculateRow,
  value: number | string,
  isText = false,
) => {
  const row = rows.value.find((r) => r.employeeId === source.employeeId);
  if (!row) return;
  if (isText) {
    row.remark = String(value ?? "");
  } else {
    (row as any)[field] = Number(value) || 0;
  }
  addManualField(row, field);
  clearEditing();
};

const loadDraft = async () => {
  if (!selectedMonth.value) return;
  loading.value = true;
  try {
    const { data } = await adminApi.getSalaryCalculateDraft(selectedMonth.value);
    rows.value = data.items || [];
  } catch (error: any) {
    ElMessage.error(error.message || "加载失败");
  } finally {
    loading.value = false;
  }
};

const calculateAll = async () => {
  if (!selectedMonth.value) return;
  calculating.value = true;
  try {
    const { data } = await adminApi.recalculateSalaryRows({
      yearMonth: selectedMonth.value,
      items: rows.value,
    });
    rows.value = data.items || [];
    ElMessage.success("已全部重新计算");
  } catch (error: any) {
    ElMessage.error(error.message || "计算失败");
  } finally {
    calculating.value = false;
  }
};

const saveAll = async () => {
  if (!selectedMonth.value) return;
  saving.value = true;
  try {
    const { data } = await adminApi.saveSalaryCalculateRows({
      yearMonth: selectedMonth.value,
      items: rows.value,
    });
    ElMessage.success(`已保存 ${data.saved ?? rows.value.length} 条工资记录`);
    await loadDraft();
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    saving.value = false;
  }
};

onMounted(loadDraft);
</script>

<style scoped>
.salary-calculate-page {
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
}

.bg-decoration {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.35;
  animation: float 20s ease-in-out infinite;
}

.blob-1 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -200px;
  right: -100px;
}

.blob-2 {
  width: 560px;
  height: 560px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -240px;
  left: -140px;
  animation-delay: -7s;
}

.blob-3 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 38%;
  left: 32%;
  animation-delay: -14s;
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(28px, -28px) scale(1.04); }
  66% { transform: translate(-18px, 18px) scale(0.96); }
}

.page-content {
  position: relative;
  z-index: 1;
  padding: 4px 0 20px;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 18px;
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px 22px;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 18px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
  transition: transform 0.25s ease, box-shadow 0.25s ease;
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 10px 28px rgba(0, 0, 0, 0.1);
}

.stat-icon {
  width: 52px;
  height: 52px;
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  flex-shrink: 0;
}

.stat-value {
  font-size: 24px;
  font-weight: 700;
  color: #1a1a2e;
  line-height: 1.2;
}

.stat-label {
  font-size: 13px;
  color: #909399;
  margin-top: 4px;
}

.toolbar-card,
.table-card {
  border-radius: 18px;
  border: 1px solid rgba(255, 255, 255, 0.5);
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(10px);
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.05);
}

.toolbar-card {
  margin-bottom: 16px;
}

.toolbar-card :deep(.el-card__body),
.table-card :deep(.el-card__body) {
  padding: 20px 22px;
}

.toolbar-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
  justify-content: space-between;
}

.toolbar-filters {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: center;
}

.month-picker {
  width: 180px;
}

.search-input {
  width: 220px;
}

.toolbar-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.action-btn {
  border-radius: 10px;
  font-weight: 500;
}

.primary-btn {
  box-shadow: 0 4px 14px rgba(64, 158, 255, 0.3);
}

.success-btn {
  box-shadow: 0 4px 14px rgba(103, 194, 58, 0.28);
}

.edit-legend {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  margin-top: 14px;
  padding-top: 14px;
  border-top: 1px dashed #ebeef5;
}

.legend-title {
  font-size: 12px;
  color: #909399;
  margin-right: 4px;
}

.legend-tag {
  border-radius: 999px;
}

.salary-calc-table :deep(.el-table__header th) {
  background: #f5f7fb !important;
  color: #606266;
  font-weight: 600;
  font-size: 12px;
}

.salary-calc-table :deep(.el-table__row:hover > td) {
  background: rgba(64, 158, 255, 0.04) !important;
}

.salary-calc-table :deep(.el-table__header th.el-table__cell.is-right .cell) {
  display: flex;
  justify-content: flex-end;
}

.salary-calc-table :deep(.el-table__body td.el-table__cell.is-right .cell) {
  display: flex;
  justify-content: flex-end;
  align-items: center;
}

.salary-calc-table :deep(td.el-table__cell.is-right .editable-cell) {
  justify-content: flex-end;
  width: 100%;
}

.salary-calc-table :deep(td.el-table__cell.is-right .cell-text) {
  justify-content: flex-end;
}

.cell-align-right {
  display: flex;
  justify-content: flex-end;
  width: 100%;
}

.rate-cell {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  line-height: 1.3;
}

.rate-unit {
  font-size: 10px;
  color: #909399;
  white-space: nowrap;
}

.salary-calc-table :deep(.editable-col) {
  background: rgba(64, 158, 255, 0.02);
}

.name-cell {
  font-weight: 600;
  color: #303133;
}

.money {
  font-variant-numeric: tabular-nums;
  color: #606266;
}

.money.bonus {
  color: #67c23a;
  font-weight: 500;
}

.money.penalty {
  color: #f56c6c;
}

.num-highlight {
  font-weight: 600;
  color: #409eff;
}

.total-salary {
  font-weight: 700;
  color: #67c23a;
  font-size: 13px;
  font-variant-numeric: tabular-nums;
}

@media (max-width: 1200px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }

  .toolbar-row {
    flex-direction: column;
    align-items: stretch;
  }

  .toolbar-actions {
    width: 100%;
  }

  .toolbar-actions .action-btn {
    flex: 1;
  }

  .month-picker,
  .search-input {
    width: 100%;
  }
}
</style>

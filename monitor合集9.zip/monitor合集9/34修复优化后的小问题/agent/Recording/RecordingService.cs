// Services/RecordingService.cs - 完整修复版（添加系统睡眠/唤醒支持）

using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Hosting;
using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Lifecycle;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.RecordingServices;

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.RecordingServices;

[SupportedOSPlatform("windows")]
public sealed partial class RecordingService : IRecordingService, IDisposable
{
    private readonly ILogger<RecordingService> _logger;
    private readonly AgentConfig _config;
    private readonly IHostEnvironment _environment;
    private readonly SemaphoreSlim _processLock = new(1, 1);
    private readonly RestartPolicyRegistry _restartPolicies;

    private AgentPolicy? _currentPolicy;
    private Process? _ffmpegProcess;
    private EventHandler? _ffmpegExitedHandler;
    private CancellationTokenSource? _recordingCts;
    private Task? _ffmpegOutputTask;

    private bool _isStopping;
    private int _intentionalProcessStop;
    private volatile bool _workSessionActive;
    private DateTime _lastSuccessfulFrame = DateTime.UtcNow;
    private long _lastObservedFileSize;
    private string? _cachedFfmpegPath;
    private DateTime _ffmpegPathCacheTime;
    private string? _cachedEncoder;
    private DateTime _encoderCacheTime;
    private (int width, int height)? _cachedDisplaySize;
    private DateTime _displaySizeCacheTime;

    private readonly Queue<DateTime> _restartHistory = new();
    private DateTime _lastRestartAttempt;
    private int _consecutiveFailures;

    // ========== 编码器智能降级字段 ==========
    private readonly SemaphoreSlim _encoderDetectionLock = new(1, 1);
    private string _currentEncoder = "libx264";
    private int _encoderFailureCount;
    private const int MaxEncoderFailures = 3;
    private DateTime _lastEncoderSwitchTime = DateTime.MinValue;
    private bool _forceSoftwareEncoder = false;
    
    // 像素格式回退标志
    private bool _needPixelFormatFallback = false;

    private DateTime _lastResumeTime = DateTime.MinValue;

    private bool _gpuDetectionFailedThisSession = false;

    // 统一重启冷却追踪（RelaunchCaptureAsync 使用）
    private DateTime _lastEncoderHeartbeat = DateTime.UtcNow;

// 重启冷却追踪
    private DateTime _lastFullRestartTime = DateTime.MinValue;
    private long _frameCount;



    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(int nIndex);
    private const int SM_CXSCREEN = 0;
    private const int SM_CYSCREEN = 1;

    public RecordingService(
        ILogger<RecordingService> logger,
        AgentConfig config,
        IHostEnvironment environment,
        ICaptureCoordinator captureCoordinator,
        RestartPolicyRegistry restartPolicies)
    {
        _logger = logger;
        _config = config;
        _environment = environment;
        _restartPolicies = restartPolicies;
        BindCaptureCoordinator(captureCoordinator);
    }

    #region 进程状态检查

    /// <summary>
    /// 检查进程是否存活（安全版本，避免休眠后异常）
    /// </summary>
    private bool IsProcessAlive()
    {
        if (_ffmpegProcess == null) return false;
        
        try
        {
            // 检查进程是否还在运行
            return !_ffmpegProcess.HasExited;
        }
        catch (InvalidOperationException)
        {
            // 进程对象已失效（休眠后常见）
            _logger.LogDebug("Process object invalid, assuming dead");
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error checking process status");
            return false;
        }
    }

    /// <summary>
    /// 安全的进程清理（增强版）- 防止资源泄漏
    /// </summary>
    private async Task CleanupProcessAsync(bool forRemoteRestart = false)
    {
        var process = _ffmpegProcess;
        if (process == null) return;

        Volatile.Write(ref _intentionalProcessStop, 1);
        var gracefulWaitSeconds = forRemoteRestart ? 1 : 3;

        try
        {
            // ✅ 安全地检查进程是否存在
            bool hasExited = true;
            try
            {
                hasExited = process.HasExited;
            }
            catch (InvalidOperationException)
            {
                // 进程已消失（如休眠后）
                _logger.LogDebug("Process already gone (invalid operation)");
            }
            
            if (!hasExited)
            {
                _logger.LogDebug(
                    "Stopping FFmpeg process gracefully (PID: {Pid}, remoteRestart={RemoteRestart})",
                    process.Id, forRemoteRestart);
                
                // 1. 先尝试优雅退出（发送 q 或关闭标准输入）
                try
                {
                    if (process.StartInfo.RedirectStandardInput)
                    {
                        await process.StandardInput.WriteLineAsync("q");
                        await process.StandardInput.FlushAsync();
                        _logger.LogDebug("Sent quit command to FFmpeg");
                    }
                    else
                    {
                        process.StandardInput?.Close();
                        _logger.LogDebug("Standard input closed");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogDebug(ex, "Could not signal FFmpeg to quit");
                }
                
                // 2. 等待让 FFmpeg 完成当前分片
                try
                {
                    await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(gracefulWaitSeconds));
                    if (process.HasExited)
                    {
                        _logger.LogDebug("FFmpeg exited gracefully");
                    }
                }
                catch (TimeoutException)
                {
                    _logger.LogWarning(
                        "FFmpeg didn't exit gracefully within {Seconds} seconds",
                        gracefulWaitSeconds);
                }
                
                // 3. 如果还没退出，强制杀死
                if (!process.HasExited)
                {
                    _logger.LogWarning("⚠️ Killing FFmpeg process (PID: {Pid})", process.Id);
                    try
                    {
                        process.Kill(entireProcessTree: true);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Could not kill process");
                    }
                    
                    // 等待进程退出
                    for (int i = 0; i < Constants.FfmpegMaxExitWaitAttempts; i++)
                    {
                        await Task.Delay(100);
                        try
                        {
                            if (process.HasExited)
                            {
                                _logger.LogDebug("Process killed successfully after {Attempts} attempts", i + 1);
                                break;
                            }
                        }
                        catch (InvalidOperationException)
                        {
                            // 进程对象已失效
                            break;
                        }
                    }
                }
            }
            
            // ✅ 最后确保 Dispose 被调用
            if (_ffmpegExitedHandler != null)
            {
                try { process.Exited -= _ffmpegExitedHandler; } catch { }
                _ffmpegExitedHandler = null;
            }
            process.Dispose();
            _logger.LogDebug("Process disposed");
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error cleaning up process");
        }
        finally
        {
            _ffmpegProcess = null;
        }

        await Task.Delay(250);
        Volatile.Write(ref _intentionalProcessStop, 0);

        // 等待后台任务完成（但不要等太久）
        await SafeWaitTaskAsync(_ffmpegOutputTask);
    }

    #endregion

    public bool WorkSessionActive => _workSessionActive;

    #region 编码器检测与智能选择（保持原有代码不变）

    private void EnsureEncoderDetected()
    {
        if (_cachedEncoder != null && DateTime.UtcNow - _encoderCacheTime < TimeSpan.FromMinutes(10))
            return;

        if (!_encoderDetectionLock.Wait(TimeSpan.FromSeconds(30)))
        {
            _logger.LogWarning("Encoder detection lock timeout, using default encoder");
            _cachedEncoder ??= "libx264";
            return;
        }

        try
        {
            if (_cachedEncoder != null && DateTime.UtcNow - _encoderCacheTime < TimeSpan.FromMinutes(10))
                return;

            var ffmpeg = FindFfmpegCached();
            if (string.IsNullOrWhiteSpace(ffmpeg))
            {
                _cachedEncoder = "libx264";
                _logger.LogWarning("FFmpeg not found, defaulting to software encoder");
                return;
            }

            _cachedEncoder = DetectAvailableEncoder(ffmpeg);
            _encoderCacheTime = DateTime.UtcNow;
            _logger.LogInformation("Encoder detection completed: {Encoder}", _cachedEncoder);
        }
        finally
        {
            _encoderDetectionLock.Release();
        }
    }

    private string DetectAvailableEncoder(string ffmpeg)
    {
        try
        {
            var availableEncoders = GetAvailableEncoders(ffmpeg);

            if (availableEncoders.Contains("h264_nvenc"))
            {
                _logger.LogInformation("✅ NVENC encoder detected (NVIDIA GPU)");
                return "h264_nvenc";
            }

            if (availableEncoders.Contains("h264_qsv"))
            {
                _logger.LogInformation("✅ QSV encoder detected (Intel GPU)");
                return "h264_qsv";
            }

            if (availableEncoders.Contains("h264_amf"))
            {
                _logger.LogInformation("✅ AMF encoder detected (AMD GPU)");
                return "h264_amf";
            }

            _logger.LogInformation("⚠️ No hardware encoder detected, using software encoder (libx264)");
            return "libx264";
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to detect hardware encoders, falling back to software");
            return "libx264";
        }
    }

    private HashSet<string> GetAvailableEncoders(string ffmpeg)
    {
        var encoders = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        try
        {
            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffmpeg,
                    Arguments = "-encoders",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };

            process.Start();
            var output = process.StandardOutput.ReadToEnd();
            process.WaitForExit(5000);

            if (output.Contains("h264_nvenc", StringComparison.OrdinalIgnoreCase))
                encoders.Add("h264_nvenc");
            if (output.Contains("h264_qsv", StringComparison.OrdinalIgnoreCase))
                encoders.Add("h264_qsv");
            if (output.Contains("h264_amf", StringComparison.OrdinalIgnoreCase))
                encoders.Add("h264_amf");
            if (output.Contains("libx264", StringComparison.OrdinalIgnoreCase))
                encoders.Add("libx264");

            _logger.LogDebug("Detected encoders: {Encoders}", string.Join(", ", encoders));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to get encoder list");
        }

        if (!encoders.Contains("libx264"))
            encoders.Add("libx264");

        return encoders;
    }

    private string GetBestEncoder(bool gpuEnabled)
    {
        // ✅ 如果本次会话已标记 GPU 失败，直接返回软件编码
        if (_gpuDetectionFailedThisSession)
        {
            _logger.LogDebug("GPU disabled for this session, using software encoder");
            return "libx264";
        }

        if (_forceSoftwareEncoder)
        {
            _logger.LogDebug("Software encoder forced due to previous failures");
            return "libx264";
        }

        if (!gpuEnabled)
        {
            _logger.LogDebug("GPU encoding disabled by policy");
            return "libx264";
        }

        EnsureEncoderDetected();
        return _cachedEncoder ?? "libx264";
    }

    private string BuildNvencTestParams(RecordingConfig config)
    {
        var q = 5;
        var rcMode = config.UseNvencHq ? "vbr_hq" : "vbr";
        var preset = ValidatePreset(config.HardwareEncoderPreset,
            new[] { "p1", "p2", "p3", "p4", "p5", "p6", "p7" }, "p4");
        
        return $"-preset {preset} -rc {rcMode} -b:v {q}M -pix_fmt nv12";
    }

    private async Task<bool> ProbeEncoderAsync(string ffmpeg, string encoder, string? testParams = null)
    {
        const int timeoutSeconds = 10;
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(timeoutSeconds));
        
        string? testOutput = null;
        
        try
        {
            testOutput = Path.GetTempFileName() + ".mp4";
            
            // 构建参数（功能与第一个代码完全相同）
            var baseArgs = $"-f lavfi -i testsrc=duration=1:size=320x240:rate=10 -c:v {encoder}";
            var args = string.IsNullOrEmpty(testParams) 
                ? $"{baseArgs} -t 1 -y {testOutput}"
                : $"{baseArgs} {testParams} -t 1 -y {testOutput}";
            
            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffmpeg,
                    Arguments = args,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardError = true
                },
                EnableRaisingEvents = true  // 新增，但不影响原有功能
            };
            
            process.Start();
            
            try
            {
                await process.WaitForExitAsync(cts.Token);
            }
            catch (OperationCanceledException)
            {
                _logger.LogWarning("Encoder {Encoder} probe test timeout after {Timeout}s", encoder, timeoutSeconds);
                try { process.Kill(); } catch { }
                return false;
            }
            
            var success = process.ExitCode == 0 && File.Exists(testOutput);
            return success;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogDebug(ex, "Encoder {Encoder} probe test exception", encoder);
            return false;
        }
        finally
        {
            // 清理临时文件（功能与第一个代码相同）
            if (testOutput != null && File.Exists(testOutput))
            {
                try { File.Delete(testOutput); } catch { }
            }
        }
    }

    private async Task<string> GetAvailableEncoderWithProbeAsync(string ffmpeg, bool gpuEnabled, RecordingConfig config)
    {
        if (!gpuEnabled || _forceSoftwareEncoder)
            return "libx264";
        
        var availableEncoders = GetAvailableEncoders(ffmpeg);
        var priorityList = config.GetEncoderPriorityList();
        
        foreach (var encoder in priorityList)
        {
            if (encoder == "libx264")
                return "libx264";
            
            if (!availableEncoders.Contains(encoder))
                continue;
            
            if (!config.EnableEncoderPreCheck)
            {
                _logger.LogInformation("Using encoder {Encoder} (pre-check disabled)", encoder);
                return encoder;
            }
            
            var testParams = encoder switch
            {
                "h264_nvenc" => BuildNvencTestParams(config),
                "h264_qsv" => "-global_quality 25",
                "h264_amf" => "-quality speed",
                _ => null
            };
            
            var isAvailable = await ProbeEncoderAsync(ffmpeg, encoder, testParams);
            
            if (isAvailable)
            {
                _logger.LogInformation("Encoder {Encoder} probe test passed, using it", encoder);
                return encoder;
            }
            
            _logger.LogWarning("Encoder {Encoder} probe test failed, trying next encoder", encoder);
        }
        
        return "libx264";
    }

    private (string encoderArgs, (int width, int height) alignedResolution) BuildEncoderArgs(
        string encoder, int quality, int fps, (int width, int height) resolution, RecordingConfig config)
    {
        var alignedResolution = resolution;

        switch (encoder)
        {
            case "h264_nvenc":
                alignedResolution.width &= ~1;
                alignedResolution.height &= ~1;
                
                if (config.EnableNvenc32Align)
                {
                    alignedResolution.width = (alignedResolution.width + 31) & ~31;
                    alignedResolution.height = (alignedResolution.height + 31) & ~31;
                }
                
                var fpsMultiplier = Math.Clamp(fps / 10.0, 0.8, 3.0);
                var baseBitrate = quality switch
                {
                    <= 30 => 2,
                    <= 60 => 5,
                    _ => 8
                };
                var q = (int)(baseBitrate * fpsMultiplier);
                q = Math.Clamp(q, 2, 20);
                
                var bitrate = $"{q}M";
                var maxrate = $"{Math.Min(q + 3, 25)}M";
                var bufsize = $"{Math.Min(q * 2, 30)}M";
                
                var rcMode = config.UseNvencHq ? "vbr_hq" : "vbr";
                
                var preset = ValidatePreset(config.HardwareEncoderPreset,
                    new[] { "p1", "p2", "p3", "p4", "p5", "p6", "p7" }, "p4");
                
                var pixFmt = _needPixelFormatFallback ? "yuv420p" : "nv12";
                
                var args = string.Join(" ", new[]
                {
                    "-c:v h264_nvenc",
                    $"-preset {preset}",
                    $"-rc {rcMode}",
                    $"-b:v {bitrate}",
                    $"-maxrate {maxrate}",
                    $"-bufsize {bufsize}",
                    $"-pix_fmt {pixFmt}"
                });
                
                _logger.LogDebug("NVENC parameters: {Args} (fps: {Fps}, quality: {Quality}, pix_fmt: {PixFmt})", 
                    args, fps, quality, pixFmt);
                
                return (args, alignedResolution);

            case "h264_qsv":
                var qsvQuality = quality switch
                {
                    <= 30 => 35,
                    <= 60 => 28,
                    _ => 23
                };
                var qsvPreset = ValidatePreset(config.HardwareEncoderPreset,
                    new[] { "veryfast", "medium", "slow" }, "veryfast");
                return ($"-c:v h264_qsv -preset {qsvPreset} -global_quality {qsvQuality} -pix_fmt nv12", alignedResolution);

            case "h264_amf":
                var amfQuality = quality switch
                {
                    <= 30 => 35,
                    <= 60 => 28,
                    _ => 23
                };
                var amfPreset = ValidatePreset(config.HardwareEncoderPreset,
                    new[] { "speed", "quality" }, "speed");
                return ($"-c:v h264_amf -quality {amfPreset} -rc cqp -qp_i {amfQuality} -qp_p {amfQuality}", alignedResolution);

            default:
                var crf = Math.Clamp(51 - (int)(quality / 100.0 * 28), 18, 51);
                var swPreset = ValidatePreset(config.SoftwareEncoderPreset,
                    new[] { "ultrafast", "veryfast", "fast", "medium", "slow", "slower" }, "veryfast");
                return ($"-c:v libx264 -preset {swPreset} -crf {crf} -pix_fmt yuv420p", alignedResolution);
        }
    }

    private string ValidatePreset(string preset, string[] validPresets, string defaultPreset)
    {
        if (string.IsNullOrWhiteSpace(preset))
            return defaultPreset;
        
        return validPresets.Contains(preset, StringComparer.OrdinalIgnoreCase) 
            ? preset.ToLowerInvariant() 
            : defaultPreset;
    }

    private bool IsEncoderError(string line)
    {
        var lowerLine = line.ToLowerInvariant();
        return (lowerLine.Contains("encoder") || lowerLine.Contains("nvenc") ||
                lowerLine.Contains("qsv") || lowerLine.Contains("amf")) &&
               (lowerLine.Contains("error") || lowerLine.Contains("failed") ||
                lowerLine.Contains("unsupported") || lowerLine.Contains("invalid"));
    }

    private void NoteEncoderRuntimeError()
    {
        if (_currentEncoder == "libx264")
            return;

        if (_currentPolicy?.GetRecordingConfig().AllowEncoderFallback == false)
            return;

        var count = Interlocked.Increment(ref _encoderFailureCount);
        _logger.LogWarning(
            "Encoder {Encoder} failure {Count}/{Max}",
            _currentEncoder, count, MaxEncoderFailures);

        if (count < MaxEncoderFailures)
            return;

        Interlocked.Exchange(ref _encoderFailureCount, 0);
        _logger.LogError(
            "Encoder {Encoder} failed repeatedly, falling back to software encoding",
            _currentEncoder);
        SwitchToSoftwareEncoder(DateTime.UtcNow);
        _logger.LogWarning("Encoder fallback to software; HealthCoordinator will recover recording");
    }

    #endregion

    private async Task<bool> StartRecordingAsync(bool orchestratorOwned = false)
    {
        if ((DateTime.UtcNow - _lastResumeTime).TotalSeconds < 10)
        {
            _logger.LogDebug("System recently resumed, waiting 3 seconds before starting recording");
            await Task.Delay(3000);
        }

        if (!await _processLock.WaitAsync(orchestratorOwned ? TimeSpan.FromSeconds(45) : TimeSpan.Zero))
        {
            _logger.LogWarning(
                "StartRecording skipped: another start/stop is in progress (orchestratorOwned={OrchestratorOwned})",
                orchestratorOwned);
            return false;
        }

        try
        {
            _isStopping = false;

            if (IsProcessAlive()) return true;
            if (!CanStartRecording(orchestratorOwned))
            {
                _logger.LogWarning("StartRecording blocked by CanStartRecording (orchestratorOwned={OrchestratorOwned})", orchestratorOwned);
                return false;
            }
            if (!HasEnoughDiskSpace())
            {
                _logger.LogError("Insufficient disk space");
                return false;
            }

            await CleanupProcessAsync();

            var ffmpeg = FindFfmpegCached();
            if (string.IsNullOrWhiteSpace(ffmpeg))
            {
                _logger.LogError("FFmpeg not found");
                _consecutiveFailures++;
                return false;
            }

            var config = _currentPolicy?.GetRecordingConfig() ?? new RecordingConfig();
            var fps = Math.Clamp(config.Fps, 1, 30);
            var sliceSeconds = Math.Max(config.GetSliceSeconds(), Constants.MinSliceSeconds);
            var resolution = GetResolution(config.Resolution);

            // ========== ✅ 每次启动时检测一次 GPU 编码器 ==========
            string newEncoder;

            // 如果本次运行已经检测过且失败了，直接使用软件编码
            if (_gpuDetectionFailedThisSession)
            {
                _logger.LogInformation("GPU encoder detection failed earlier this session, using software encoder (libx264)");
                newEncoder = "libx264";
            }
            else
            {
                // 首次启动时检测
                bool gpuRequested = config.EnableGpu && !_forceSoftwareEncoder;
                
                if (gpuRequested && config.EnableEncoderPreCheck)
                {
                    _logger.LogInformation("🔍 Probing GPU encoder availability...");
                    newEncoder = await GetAvailableEncoderWithProbeAsync(ffmpeg, true, config);
                    
                    // 如果检测失败，记录本次会话不再尝试
                    if (newEncoder == "libx264" && gpuRequested)
                    {
                        _gpuDetectionFailedThisSession = true;
                        _logger.LogWarning("❌ GPU encoder probe failed, will use software encoder for this session. Restart client to retry GPU.");
                    }
                }
                else
                {
                    newEncoder = GetBestEncoder(gpuRequested);
                    if (newEncoder == "libx264" && gpuRequested)
                    {
                        _gpuDetectionFailedThisSession = true;
                        _logger.LogWarning("❌ No GPU encoder available, will use software encoder for this session. Restart client to retry GPU.");
                    }
                }
            }

            if (_currentEncoder != newEncoder)
            {
                _logger.LogInformation("Encoder switching: {OldEncoder} -> {NewEncoder}",
                    _currentEncoder, newEncoder);
                _lastEncoderSwitchTime = DateTime.UtcNow;
                _currentEncoder = newEncoder;
            }

            var (encoderArgs, alignedResolution) = BuildEncoderArgs(_currentEncoder, config.Quality, fps, resolution, config);

            var recordingsDir = Path.Combine(_config.GetEffectiveStoragePath(), "recordings");
            Directory.CreateDirectory(recordingsDir);

            var preservePattern = orchestratorOwned && !string.IsNullOrWhiteSpace(_persistedOutputPattern);
            if (!preservePattern)
            {
                var sessionStartLocal = DateTime.Now;
                var dateDir = Path.Combine(recordingsDir, sessionStartLocal.ToLocalDateDirectory());
                Directory.CreateDirectory(dateDir);

                var testFile = Path.Combine(dateDir, ".write_test_" + Guid.NewGuid().ToString("N"));
                try
                {
                    await File.WriteAllTextAsync(testFile, "test");
                    File.Delete(testFile);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Recording directory not writable: {Directory}", dateDir);
                    throw;
                }

                _persistedOutputPattern = Path.Combine(dateDir,
                    $"{sessionStartLocal.ToString(DateTimeExtensions.DateTimeFormatForFile)}_%03d.mp4");
            }

            _logger.LogInformation("=== Recording Configuration ===");
            _logger.LogInformation("Resolution: {Width}x{Height}", alignedResolution.width, alignedResolution.height);
            _logger.LogInformation("FPS: {Fps}, Quality: {Quality}, Slice: {Slice}s", fps, config.Quality, sliceSeconds);

            if (_captureCoordinator != null)
                await _captureCoordinator.NotifyConsumerStartingAsync(CaptureConsumer.Recording);

            if (!await LaunchFfmpegCaptureAsync(ffmpeg))
            {
                _consecutiveFailures++;
                return false;
            }

            await EnsureRecordingBackgroundTasksStartedAsync();

            if (!orchestratorOwned)
                RegisterRestart();

            _consecutiveFailures = 0;
            _lastSuccessfulFrame = DateTime.UtcNow;
            _lastObservedFileSize = 0;

            var pid = _ffmpegProcess?.Id;
            _logger.LogInformation("Recording started successfully! (PID: {Pid})", pid);
            return true;
        }
        catch (Exception ex)
        {
            _consecutiveFailures++;
            _logger.LogError(ex, "Failed starting recording");
            await CleanupProcessAsync();
            return false;
        }
        finally
        {
            _processLock.Release();
        }
    }

    private async Task OnFfmpegExitedAsync()
    {
        try
        {
            var exitCode = _ffmpegProcess?.ExitCode ?? -1;
            _logger.LogInformation(
                exitCode == 0
                    ? "✓ FFmpeg exited normally"
                    : "❌ FFmpeg exited with code {ExitCode}",
                exitCode
            );

            // ========== 处理编码器失败 ==========
            // ========== 运行时编码器失败处理 ==========
            if (exitCode != 0 && _currentEncoder != "libx264")
            {
                _logger.LogWarning(
                    "⚠️ Hardware encoder {Encoder} failed at runtime (exit code: {ExitCode}), switching to software encoder for this session",
                    _currentEncoder,
                    exitCode
                );

                // ✅ 运行时失败：切换到软件编码，并标记本次会话不再尝试 GPU
                _gpuDetectionFailedThisSession = true;
                _currentEncoder = "libx264";
                
                _logger.LogWarning("✅ GPU encoding disabled for this session. Restart client to retry GPU.");
            }
            else if (exitCode == 0 && _encoderFailureCount > 0)
            {
                _encoderFailureCount--;
                _logger.LogDebug("✓ Encoder recovered, failure count: {Count}", _encoderFailureCount);
            }

            // ========== 清理进程并决定是否重启 ==========
            bool shouldRestart = false;
            // ✅ 添加超时
            if (!await _processLock.WaitAsync(TimeSpan.FromSeconds(10)))
            {
                _logger.LogWarning("Could not acquire process lock in exit handler");
                return;
            }
            
            try
            {
                if (_ffmpegProcess != null)
                {
                    _ffmpegProcess.Dispose();
                    _ffmpegProcess = null;
                }

                var config = _currentPolicy?.GetRecordingConfig();
                var recordingEnabled = config?.Enabled == true && _workSessionActive;
                var intentionalStop = _isStopping || Volatile.Read(ref _intentionalProcessStop) != 0;
                shouldRestart = !intentionalStop && recordingEnabled;
            }
            finally
            {
                _processLock.Release();
            }

            // ========== 有延迟地重启 ==========
            if (shouldRestart)
            {
                _logger.LogWarning(
                    "FFmpeg exited with code {ExitCode}; recovery delegated to HealthCoordinator",
                    exitCode);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ FFmpeg exit handler failed");
        }
    }

    private static async Task SafeWaitTaskAsync(Task? task)
    {
        if (task == null) return;
        try { await task.WaitAsync(TimeSpan.FromSeconds(3)); }
        catch { }
    }

    private async Task StopRecordingAsync(bool fullShutdown = true, bool fastTransition = false)
    {
        var lockTimeout = fullShutdown ? TimeSpan.FromSeconds(10) : TimeSpan.FromSeconds(45);
        if (!await _processLock.WaitAsync(lockTimeout))
        {
            _logger.LogWarning("Could not acquire process lock for stop");
            return;
        }

        try
        {
            if (fullShutdown)
            {
                _isStopping = true;
                _persistedOutputPattern = null;
                _recordingCts?.Cancel();
                if (_captureCoordinator != null)
                    await _captureCoordinator.NotifyConsumerStoppingAsync(CaptureConsumer.Recording);
            }
            else if (fastTransition)
            {
                // Prevent OnFfmpegExited from treating this as an unexpected crash before SharedBridge handoff.
                _isStopping = true;
            }

            await CleanupProcessAsync(forRemoteRestart: fastTransition);
            if (fullShutdown)
                EnterpriseAgent.Agent.Services.FfmpegProcessCleanup.KillAgentFfmpegProcesses(_logger);

            _logger.LogInformation(fullShutdown ? "Recording stopped" : "FFmpeg capture stopped (session preserved)");
        }
        finally
        {
            _processLock.Release();
        }
    }

    private async Task LogFfmpegOutputAsync(Process process)
    {
        try
        {
            var stderrTimeoutSeconds = _config?.RecordingHealth?.StderrReadTimeoutSeconds ?? 90;
            _ = _config?.RecordingHealth?.StderrTimeoutKillThreshold ?? 3;

            while (true)
            {
                CancellationToken ct = _recordingCts?.Token ?? CancellationToken.None;

                bool processExited;
                try
                {
                    processExited = process.HasExited;
                }
                catch (InvalidOperationException)
                {
                    _logger.LogDebug("FFmpeg process handle released, stopping stderr log reader");
                    break;
                }

                if (processExited)
                {
                    _logger.LogDebug("FFmpeg process has exited, stopping stderr log reader");
                    break;
                }

                var readTask = process.StandardError.ReadLineAsync();
                var delayTask = Task.Delay(TimeSpan.FromSeconds(stderrTimeoutSeconds), ct);

                var completed = await Task.WhenAny(readTask, delayTask);

                if (completed != readTask)
                {
                    try { await readTask.ConfigureAwait(false); }
                    catch (ObjectDisposedException) { break; }
                    catch (IOException ex) { _logger.LogDebug(ex, "FFmpeg stderr read ended after timeout"); }
                    catch (InvalidOperationException ex) { _logger.LogDebug(ex, "FFmpeg stderr read ended after timeout"); }

                    if (ct.IsCancellationRequested || process.HasExited)
                        break;

                    if (!process.HasExited)
                    {
                        _lastEncoderHeartbeat = DateTime.UtcNow;
                        _logger.LogDebug(
                            "FFmpeg stderr silent for {Seconds}s; process alive, not killing",
                            stderrTimeoutSeconds);
                    }

                    await Task.Delay(TimeSpan.FromSeconds(1), ct);
                    continue;
                }

                string? line;
                try
                {
                    line = await readTask.ConfigureAwait(false);
                }
                catch (ObjectDisposedException)
                {
                    break;
                }
                catch (IOException ex)
                {
                    _logger.LogDebug(ex, "FFmpeg stderr read failed");
                    break;
                }
                catch (InvalidOperationException ex)
                {
                    _logger.LogDebug(ex, "FFmpeg stderr read failed");
                    break;
                }

                if (line == null)
                    break;

                if (string.IsNullOrWhiteSpace(line)) continue;

                _lastEncoderHeartbeat = DateTime.UtcNow;

                if (line.Contains("frame=", StringComparison.OrdinalIgnoreCase))
                {
                    var count = Interlocked.Increment(ref _frameCount);
                    _lastSuccessfulFrame = DateTime.UtcNow;
                    if (_currentEncoder != "libx264" && Volatile.Read(ref _encoderFailureCount) > 0)
                        Interlocked.Decrement(ref _encoderFailureCount);
                    if (_captureCoordinator?.GetProfile().Mode == CaptureMode.SharedBridge &&
                        (count == 1 || _captureCoordinator.NeedsConsumerFirstFrame(CaptureConsumer.Recording)))
                    {
                        _captureCoordinator.NotifyConsumerFirstFrame(CaptureConsumer.Recording);
                    }
                    _logger.LogDebug("FFmpeg frame output received (total: {FrameCount})", count);
                }

                if (line.Contains("pixel format", StringComparison.OrdinalIgnoreCase) ||
                    line.Contains("pix_fmt", StringComparison.OrdinalIgnoreCase))
                {
                    _needPixelFormatFallback = true;
                    _logger.LogWarning("Pixel format error detected, will retry with yuv420p");
                }

                if (IsEncoderError(line))
                {
                    _logger.LogWarning("FFmpeg encoder error: {Line}", SensitiveDataFilter.FilterStatic(line));
                    NoteEncoderRuntimeError();
                }
                else if (line.Contains("error", StringComparison.OrdinalIgnoreCase))
                {
                    _logger.LogWarning("FFmpeg error: {Line}", SensitiveDataFilter.FilterStatic(line));
                }
                else
                {
                    _logger.LogDebug("FFmpeg: {Line}", line);
                }
            }
        }
        catch (OperationCanceledException) { }
        catch (ObjectDisposedException) { }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FFmpeg log reader failed");
        }
    }

    private (int width, int height) GetDisplaySize()
    {
        if (_cachedDisplaySize.HasValue && DateTime.UtcNow - _displaySizeCacheTime < TimeSpan.FromSeconds(30))
            return _cachedDisplaySize.Value;

        try
        {
            var width = GetSystemMetrics(SM_CXSCREEN);
            var height = GetSystemMetrics(SM_CYSCREEN);
            if (width > 0 && height > 0)
            {
                _cachedDisplaySize = (width, height);
                _displaySizeCacheTime = DateTime.UtcNow;
                return (width, height);
            }
        }
        catch { }
        return (1920, 1080);
    }

    private (int width, int height) GetResolution(string? resolution)
    {
        var (width, height) = ParseResolutionString(resolution);
        var screen = GetDisplaySize();
        
        width = Math.Min(width, screen.width);
        height = Math.Min(height, screen.height);
        
        const int MAX_WIDTH = 1920;
        const int MAX_HEIGHT = 1080;
        width = Math.Min(width, MAX_WIDTH);
        height = Math.Min(height, MAX_HEIGHT);
        
        width = Math.Max(width, 640);
        height = Math.Max(height, 480);
        
        width &= ~1;
        height &= ~1;
        
        if (width <= 0 || height <= 0)
        {
            _logger.LogWarning("Invalid resolution, falling back to 1280x720");
            return (1280, 720);
        }
        
        _logger.LogDebug("Base resolution: {Width}x{Height}", width, height);
        return (width, height);
    }

    private (int width, int height) ParseResolutionString(string? resolution)
    {
        const int DEFAULT_WIDTH = 1920;
        const int DEFAULT_HEIGHT = 1080;

        if (string.IsNullOrWhiteSpace(resolution))
            return (DEFAULT_WIDTH, DEFAULT_HEIGHT);

        var parts = resolution.Trim()
            .ToLowerInvariant()
            .Split(new[] { 'x', '*', '×' }, StringSplitOptions.RemoveEmptyEntries);

        if (parts.Length != 2)
            return (DEFAULT_WIDTH, DEFAULT_HEIGHT);

        int.TryParse(parts[0], out var w);
        int.TryParse(parts[1], out var h);

        if (w <= 0) w = DEFAULT_WIDTH;
        if (h <= 0) h = DEFAULT_HEIGHT;

        return (w, h);
    }

    private bool CanStartRecording(bool orchestratorOwned = false)
    {
        var now = DateTime.UtcNow;

        // =========================================================
        // 1️⃣ 软件编码器模式（libx264）
        // =========================================================
        if (_forceSoftwareEncoder || _currentEncoder == "libx264")
        {
            // ❌ 连续失败保护（硬停止）
            if (_consecutiveFailures >= 10)
            {
                _logger.LogError(
                    "Software encoder failed 10 times consecutively, stopping retries");

                return false;
            }

            // ⏳ 软件编码器冷却（防抖）
            if (now - _lastRestartAttempt < TimeSpan.FromSeconds(3))
            {
                _logger.LogDebug("Software encoder restart throttled (3s cooldown)");
                return false;
            }

            _lastRestartAttempt = now;
            return true;
        }

        // =========================================================
        // 2️⃣ 清理过期 restart 记录（5分钟窗口）
        // =========================================================
        while (_restartHistory.Count > 0 &&
               now - _restartHistory.Peek() > TimeSpan.FromMinutes(5))
        {
            _restartHistory.Dequeue();
        }

        // =========================================================
        // 3️⃣ 硬件编码器失败过多 → 降级软件
        // =========================================================
        if (_restartHistory.Count >= 10)
        {
            _logger.LogWarning(
                "Hardware encoder: {Count} restarts in 5 minutes, falling back to software",
                _restartHistory.Count);

            SwitchToSoftwareEncoder(now);

            return true; // ✅ 已切换成功，允许启动
        }

        // =========================================================
        // 4️⃣ 连续失败过多 → 降级软件
        // =========================================================
        if (_consecutiveFailures >= 5)
        {
            _logger.LogWarning(
                "Hardware encoder: {Count} consecutive failures, falling back to software",
                _consecutiveFailures);

            SwitchToSoftwareEncoder(now);

            return true; // ✅ 同样允许启动
        }

        // =========================================================
        // 5️⃣ 硬件编码器启动节流（防风暴）— orchestrator 路径可绕过
        // =========================================================
        if (!orchestratorOwned && now - _lastRestartAttempt < TimeSpan.FromSeconds(10))
        {
            _logger.LogDebug("Hardware encoder restart throttled (10s cooldown)");
            return false;
        }

        // =========================================================
        // 6️⃣ 允许启动
        // =========================================================
        _lastRestartAttempt = now;
        return true;
    }

    private void RegisterRestart() => _restartHistory.Enqueue(DateTime.UtcNow);

    private bool HasEnoughDiskSpace()
    {
        try
        {
            var drive = Path.GetPathRoot(_config.GetEffectiveStoragePath());
            if (string.IsNullOrWhiteSpace(drive)) return true;
            return new DriveInfo(drive).AvailableFreeSpace > Constants.MinDiskSpaceBytes;
        }
        catch { return true; }
    }

    private string? FindFfmpegCached()
    {
        if (_cachedFfmpegPath != null && DateTime.UtcNow - _ffmpegPathCacheTime < TimeSpan.FromMinutes(5) && File.Exists(_cachedFfmpegPath))
            return _cachedFfmpegPath;

        var path = FindFfmpeg();
        _cachedFfmpegPath = path;
        _ffmpegPathCacheTime = DateTime.UtcNow;
        return path;
    }

    private string? FindFfmpeg()
    {
        foreach (var path in GetFfmpegSearchPaths())
        {
            try
            {
                if (File.Exists(path))
                    return path;
            }
            catch
            {
                // ignore invalid paths
            }
        }

        _logger.LogError(
            "FFmpeg not found. Place ffmpeg.exe next to DHPG.exe or add it to PATH. Searched: {Paths}",
            string.Join("; ", GetFfmpegSearchPaths()));
        return null;
    }

    private static IEnumerable<string> GetFfmpegSearchPaths()
    {
        var baseDir = AppDomain.CurrentDomain.BaseDirectory;
        yield return Path.Combine(baseDir, "ffmpeg.exe");
        yield return Path.Combine(baseDir, "bin", "ffmpeg.exe");

        var projectDir = Path.GetFullPath(Path.Combine(baseDir, "..", "..", ".."));
        yield return Path.Combine(projectDir, "ffmpeg.exe");

        yield return @"C:\ffmpeg\bin\ffmpeg.exe";
        yield return @"C:\Program Files\ffmpeg\bin\ffmpeg.exe";

        var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (var dir in pathEnv.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            yield return Path.Combine(dir, "ffmpeg.exe");
        }
    }

    internal RecordingHealthSnapshot BuildRecordingHealthSnapshot(RecorderState state, bool remoteViewActive)
    {
        var config = _currentPolicy?.GetRecordingConfig();
        var enabled = config?.Enabled ?? false;
        var now = DateTime.UtcNow;

        var processAlive = false;
        try
        {
            processAlive = _ffmpegProcess != null && !_ffmpegProcess.HasExited;
        }
        catch (InvalidOperationException)
        {
            processAlive = false;
        }

        var encoderHeartbeatAge = (now - _lastEncoderHeartbeat).TotalSeconds;
        var encoderAliveThreshold = _config?.RecordingHealth?.EncoderAliveThresholdSeconds ?? 120;
        var encoderAlive = encoderHeartbeatAge < encoderAliveThreshold;

        var fileRecent = false;
        var fileGrowing = false;
        try
        {
            var recordingsPath = _config?.GetEffectiveStoragePath();
            if (!string.IsNullOrWhiteSpace(recordingsPath))
            {
                recordingsPath = Path.Combine(recordingsPath, "recordings");
            }
            if (!string.IsNullOrWhiteSpace(recordingsPath) && Directory.Exists(recordingsPath))
            {
                FileInfo? latestFile = null;
                foreach (var file in Directory.EnumerateFiles(recordingsPath, "*.mp4", SearchOption.AllDirectories))
                {
                    var info = new FileInfo(file);
                    if (latestFile == null || info.LastWriteTimeUtc > latestFile.LastWriteTimeUtc)
                        latestFile = info;
                }

                if (latestFile != null)
                {
                    var fileAliveThreshold = _config?.RecordingHealth?.FileAliveThresholdSeconds ?? 120;
                    fileRecent = (now - latestFile.LastWriteTimeUtc).TotalSeconds < fileAliveThreshold;
                    var previousSize = Volatile.Read(ref _lastObservedFileSize);
                    fileGrowing = latestFile.Length > previousSize;
                    Volatile.Write(ref _lastObservedFileSize, latestFile.Length);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to evaluate recording file health");
        }

        var fileAlive = fileGrowing || fileRecent;
        var isHealthy = !enabled
            || state == RecorderState.Transitioning
            || (processAlive && (encoderAlive || fileAlive));
        var shouldBeRecording = enabled && _workSessionActive && !_isStopping;

        return new RecordingHealthSnapshot
        {
            RecordingEnabled = enabled,
            ShouldBeRecording = shouldBeRecording,
            ProcessAlive = processAlive,
            IsHealthy = isHealthy,
            RemoteViewActive = remoteViewActive,
            RecorderState = state,
            EncoderAlive = encoderAlive,
            FileRecent = fileRecent,
            FileGrowing = fileGrowing,
            StallSeconds = (now - _lastSuccessfulFrame).TotalSeconds,
            EncoderHeartbeatAgeSeconds = encoderHeartbeatAge,
            CurrentEncoder = _currentEncoder
        };
    }

    /// <summary>
    /// 切换到软件编码器 (libx264)
    /// </summary>
    /// <param name="timestamp">切换时间戳</param>
    private void SwitchToSoftwareEncoder(DateTime timestamp)
    {
        // 记录切换前状态
        var oldEncoder = _currentEncoder;
        
        // 执行切换
        _forceSoftwareEncoder = true;
        _currentEncoder = "libx264";
        _cachedEncoder = "libx264";
        _restartHistory.Clear();
        _consecutiveFailures = 0;
        _lastEncoderSwitchTime = timestamp;
        _gpuDetectionFailedThisSession = true;
        _needPixelFormatFallback = false;  // 重置像素格式回退
        
        _logger.LogWarning(
            "🔄 Switched to software encoder: {OldEncoder} -> libx264 (Reason: hardware encoder failure)",
            oldEncoder);
    }

    /// <summary>
    /// 检查是否可以执行完整重启
    /// </summary>
    private bool CanPerformFullRestart()
    {
        var now = DateTime.UtcNow;
        
        // 清理1小时前的记录
        while (_restartHistory.Count > 0 && now - _restartHistory.Peek() > TimeSpan.FromHours(1))
            _restartHistory.Dequeue();
        
        // 1小时内超过10次则禁止
        if (_restartHistory.Count >= 10)
        {
            _logger.LogError("Too many restarts in last hour ({Count}), entering degraded mode", _restartHistory.Count);
            return false;
        }
        
        // 5分钟内超过3次则限流
        var last5MinCount = _restartHistory.Count(t => now - t < TimeSpan.FromMinutes(5));
        if (last5MinCount >= 3)
        {
            _logger.LogWarning("Too many restarts in 5 minutes ({Count}), throttling", last5MinCount);
            return false;
        }
        
        // 最小间隔30秒
        if (now - _lastFullRestartTime < TimeSpan.FromSeconds(30))
        {
            _logger.LogDebug("Restart throttled: last restart was {Seconds:F0}s ago", (now - _lastFullRestartTime).TotalSeconds);
            return false;
        }
        
        _restartHistory.Enqueue(now);
        _lastFullRestartTime = now;
        return true;
    }

    /// <summary>
    /// 重置所有信号
    /// </summary>
    private void ResetAllSignals()
    {
        var now = DateTime.UtcNow;
        _lastEncoderHeartbeat = now;
        _lastSuccessfulFrame = now;
        Volatile.Write(ref _lastObservedFileSize, 0);
        Volatile.Write(ref _frameCount, 0);
        _logger.LogDebug("All signals reset");
    }

    private (string? path, long size) GetLatestRecordingFileSnapshot()
    {
        try
        {
            var pattern = _persistedOutputPattern;
            if (string.IsNullOrWhiteSpace(pattern))
                return (null, 0);

            var dir = Path.GetDirectoryName(pattern);
            if (string.IsNullOrWhiteSpace(dir) || !Directory.Exists(dir))
                return (null, 0);

            FileInfo? latest = null;
            foreach (var file in Directory.EnumerateFiles(dir, "*.mp4"))
            {
                var info = new FileInfo(file);
                if (latest == null || info.LastWriteTimeUtc > latest.LastWriteTimeUtc)
                    latest = info;
            }

            return latest == null ? (null, 0) : (latest.FullName, latest.Length);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to snapshot latest recording file");
            return (null, 0);
        }
    }

    private async Task<bool> WaitForRecordingOutputAsync(CancellationToken ct, TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;
        var baselineFrames = Volatile.Read(ref _frameCount);
        var (_, baselineSize) = GetLatestRecordingFileSnapshot();

        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();

            if (!IsProcessAlive())
            {
                _logger.LogWarning("FFmpeg exited while waiting for recording output");
                return false;
            }

            if (Volatile.Read(ref _frameCount) > baselineFrames)
                return true;

            var (path, size) = GetLatestRecordingFileSnapshot();
            if (!string.IsNullOrWhiteSpace(path) && size > baselineSize)
                return true;

            await Task.Delay(500, ct);
        }

        _logger.LogWarning("Recording output not verified within {Seconds}s", timeout.TotalSeconds);
        return false;
    }

    public void Dispose()
    {
        _recordingCts?.Dispose();
        _processLock.Dispose();
        _encoderDetectionLock?.Dispose();
    }
}
namespace EnterpriseAgent.Agent.Services;

internal sealed class RecordingUploadCandidate
{
    public required FileInfo File { get; init; }
    public required DateTime RecordStart { get; init; }
    public required DateTime RecordEnd { get; init; }
    public string? RecordingId { get; init; }
}

using System.Globalization;
using EnterpriseAgent.Agent.Models;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 从录屏文件路径解析 UTC 起止时间（新/旧文件名格式统一入口）
/// </summary>
internal static class RecordingTimeParser
{
    private static readonly int[] CommonSliceSeconds = { 60, 180, 300, 600, 900 };
    private static readonly Lazy<TimeZoneInfo> ChinaTimeZone = new(GetChinaTimeZone);

    public static bool TryParse(
        string filePath,
        int sliceSeconds,
        out DateTime startUtc,
        out DateTime endUtc,
        Dictionary<string, int>? sliceCache = null)
    {
        startUtc = default;
        endUtc = default;

        if (string.IsNullOrWhiteSpace(filePath))
            return false;

        var inferredSlice = InferSliceSecondsFromDirectory(filePath, sliceCache);
        foreach (var candidate in BuildSliceCandidates(sliceSeconds, inferredSlice))
        {
            if (!TryParseWithSlice(filePath, candidate, out var parsedStart, out var parsedEnd))
                continue;

            if (!ValidateWithFileTime(filePath, parsedStart, parsedEnd, candidate))
                continue;

            startUtc = parsedStart;
            endUtc = RefineEndTime(filePath, parsedStart, parsedEnd, candidate);
            startUtc = RefineStartTime(filePath, startUtc, endUtc, candidate);
            return true;
        }

        // 无法校验时降级：优先目录推断，再使用传入 hint
        if (inferredSlice > 0 &&
            TryParseWithSlice(filePath, inferredSlice, out startUtc, out endUtc))
        {
            endUtc = RefineEndTime(filePath, startUtc, endUtc, inferredSlice);
            startUtc = RefineStartTime(filePath, startUtc, endUtc, inferredSlice);
            return true;
        }

        sliceSeconds = Math.Max(sliceSeconds, Constants.MinSliceSeconds);
        if (TryParseWithSlice(filePath, sliceSeconds, out startUtc, out endUtc))
        {
            endUtc = RefineEndTime(filePath, startUtc, endUtc, sliceSeconds);
            startUtc = RefineStartTime(filePath, startUtc, endUtc, sliceSeconds);
            return true;
        }

        startUtc = default;
        endUtc = default;
        return false;
    }

    private static IEnumerable<int> BuildSliceCandidates(int hint, int inferred)
    {
        var ordered = new List<int>();
        void Add(int value)
        {
            value = Math.Max(value, Constants.MinSliceSeconds);
            if (!ordered.Contains(value))
                ordered.Add(value);
        }

        if (inferred > 0)
            Add(inferred);
        if (hint > 0)
            Add(hint);
        foreach (var common in CommonSliceSeconds)
            Add(common);

        return ordered;
    }

    private static bool TryParseWithSlice(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;
        sliceSeconds = Math.Max(sliceSeconds, Constants.MinSliceSeconds);

        DateTime? bestStart = null;
        DateTime? bestEnd = null;
        var bestDrift = double.MaxValue;

        void Consider(DateTime candidateStart, DateTime candidateEnd)
        {
            if (!ValidateWithFileTime(filePath, candidateStart, candidateEnd, sliceSeconds))
                return;

            var drift = GetEndTimeDriftSeconds(filePath, candidateEnd);
            if (drift >= bestDrift)
                return;

            bestDrift = drift;
            bestStart = candidateStart;
            bestEnd = candidateEnd;
        }

        foreach (var treatFilenameAsUtc in new[] { false, true })
        {
            if (TryParseNewFormat(filePath, sliceSeconds, treatFilenameAsUtc, out var parsedStart, out var parsedEnd))
                Consider(parsedStart, parsedEnd);
        }

        if (TryParseLegacyFormat(filePath, sliceSeconds, out var legacyStart, out var legacyEnd))
            Consider(legacyStart, legacyEnd);

        if (bestStart.HasValue && bestEnd.HasValue)
        {
            startUtc = bestStart.Value;
            endUtc = bestEnd.Value;
            return true;
        }

        if (TryParseNewFormat(filePath, sliceSeconds, treatFilenameAsUtc: false, out startUtc, out endUtc) ||
            TryParseNewFormat(filePath, sliceSeconds, treatFilenameAsUtc: true, out startUtc, out endUtc) ||
            TryParseLegacyFormat(filePath, sliceSeconds, out startUtc, out endUtc) ||
            TryParseFromFileTime(filePath, sliceSeconds, out startUtc, out endUtc))
        {
            return true;
        }

        startUtc = default;
        endUtc = default;
        return false;
    }

    private static double GetEndTimeDriftSeconds(string filePath, DateTime estimatedEndUtc)
    {
        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return 0;

            return Math.Abs((fileInfo.LastWriteTimeUtc - estimatedEndUtc).TotalSeconds);
        }
        catch
        {
            return double.MaxValue;
        }
    }

    private static int InferSliceSecondsFromDirectory(string filePath, Dictionary<string, int>? sliceCache = null)
    {
        try
        {
            var dir = Path.GetDirectoryName(filePath);
            if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir))
                return 0;

            var fileName = Path.GetFileNameWithoutExtension(filePath);
            var parts = fileName.Split('_');
            if (parts.Length != 3 || parts[0].Length != 10)
                return 0;

            var sessionPrefix = $"{parts[0]}_{parts[1]}";
            var cacheKey = $"{dir}|{sessionPrefix}";
            if (sliceCache != null && sliceCache.TryGetValue(cacheKey, out var cached))
                return cached;

            var siblings = new List<(int Index, DateTime Mtime)>();

            foreach (var path in Directory.EnumerateFiles(dir, $"{sessionPrefix}_*.mp4"))
            {
                var name = Path.GetFileNameWithoutExtension(path);
                var segments = name.Split('_');
                if (segments.Length != 3 || !int.TryParse(segments[2], out var index))
                    continue;

                var info = new FileInfo(path);
                if (!info.Exists || info.Length <= Constants.MinRecordingFileBytes)
                    continue;

                siblings.Add((index, info.LastWriteTimeUtc));
            }

            if (siblings.Count < 2)
            {
                CacheSliceResult(sliceCache, cacheKey, 0);
                return 0;
            }

            siblings.Sort((a, b) => a.Index.CompareTo(b.Index));

            var deltas = new List<int>();
            for (var i = 1; i < siblings.Count; i++)
            {
                var delta = (int)Math.Round((siblings[i].Mtime - siblings[i - 1].Mtime).TotalSeconds);
                if (delta >= Constants.MinSliceSeconds && delta <= 3600)
                    deltas.Add(delta);
            }

            if (deltas.Count == 0)
            {
                CacheSliceResult(sliceCache, cacheKey, 0);
                return 0;
            }

            deltas.Sort();
            var median = deltas[deltas.Count / 2];

            var best = median;
            var bestDiff = int.MaxValue;
            foreach (var common in CommonSliceSeconds)
            {
                var diff = Math.Abs(common - median);
                if (diff < bestDiff)
                {
                    bestDiff = diff;
                    best = common;
                }
            }

            int result;
            if (bestDiff <= Math.Max(30, best / 5))
                result = best;
            else
                result = median;

            CacheSliceResult(sliceCache, cacheKey, result);
            return result;
        }
        catch
        {
            return 0;
        }
    }

    private static void CacheSliceResult(Dictionary<string, int>? sliceCache, string cacheKey, int value)
    {
        if (sliceCache == null)
            return;
        sliceCache[cacheKey] = value;
    }

    private static bool ValidateWithFileTime(string filePath, DateTime startUtc, DateTime endUtc, int sliceSeconds)
    {
        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return true;

            var writeUtc = fileInfo.LastWriteTimeUtc;
            var tolerance = TimeSpan.FromSeconds(Math.Max(60, sliceSeconds / 4));
            return writeUtc >= startUtc.Subtract(tolerance) && writeUtc <= endUtc.Add(tolerance);
        }
        catch
        {
            return true;
        }
    }

    private static bool TryParseNewFormat(
        string filePath,
        int sliceSeconds,
        bool treatFilenameAsUtc,
        out DateTime startUtc,
        out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        try
        {
            var fileName = Path.GetFileNameWithoutExtension(filePath);
            var parts = fileName.Split('_');
            if (parts.Length != 3 || parts[0].Length != 10 || !parts[0].Contains('-'))
                return false;

            if (!DateTime.TryParseExact(parts[0], "yyyy-MM-dd",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out var date))
                return false;

            var timeParts = parts[1].Split('-');
            if (timeParts.Length != 3)
                return false;

            if (!int.TryParse(timeParts[0], out var hour) ||
                !int.TryParse(timeParts[1], out var minute) ||
                !int.TryParse(timeParts[2], out var second) ||
                !int.TryParse(parts[2], out var segmentIndex))
                return false;

            DateTime baseStartUtc;
            if (treatFilenameAsUtc)
            {
                baseStartUtc = new DateTime(date.Year, date.Month, date.Day, hour, minute, second, DateTimeKind.Utc);
            }
            else
            {
                // 文件名来自 DateTime.Now，按 Agent 所在系统时区解析
                var localTime = new DateTime(date.Year, date.Month, date.Day, hour, minute, second, DateTimeKind.Unspecified);
                baseStartUtc = TimeZoneInfo.ConvertTimeToUtc(localTime, TimeZoneInfo.Local);
            }

            startUtc = baseStartUtc.AddSeconds(segmentIndex * sliceSeconds);
            endUtc = startUtc.AddSeconds(sliceSeconds);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static bool TryParseLegacyFormat(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        try
        {
            var fileName = Path.GetFileNameWithoutExtension(filePath);
            var underscoreIndex = fileName.IndexOf('_');
            var segmentIndex = 0;
            if (underscoreIndex >= 0 && underscoreIndex + 1 < fileName.Length)
                int.TryParse(fileName.Substring(underscoreIndex + 1), out segmentIndex);

            var timePart = underscoreIndex >= 0 ? fileName.Substring(0, underscoreIndex) : fileName;
            var parts = timePart.Split('-');
            if (parts.Length < 3)
                return false;

            if (!int.TryParse(parts[0], out var hour) ||
                !int.TryParse(parts[1], out var minute) ||
                !int.TryParse(parts[2], out var second))
                return false;

            var dateStr = Path.GetFileName(Path.GetDirectoryName(filePath));
            if (!DateTime.TryParseExact(dateStr, "yyyy-MM-dd",
                    CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var date))
                return false;

            var localTime = new DateTime(date.Year, date.Month, date.Day, hour, minute, second, DateTimeKind.Unspecified);
            var baseStartTime = TimeZoneInfo.ConvertTimeToUtc(localTime, ChinaTimeZone.Value);

            startUtc = baseStartTime.AddSeconds(segmentIndex * sliceSeconds);
            endUtc = startUtc.AddSeconds(sliceSeconds);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static bool TryParseFromFileTime(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return false;

            endUtc = fileInfo.LastWriteTimeUtc;
            startUtc = endUtc.AddSeconds(-sliceSeconds);
            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// 用文件创建时间校准开始时间。文件名中的时间在 FFmpeg 启动前写入，往往早于首帧实际时间。
    /// </summary>
    private static DateTime RefineStartTime(string filePath, DateTime parsedStart, DateTime endUtc, int sliceSeconds)
    {
        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return parsedStart;

            var creationUtc = fileInfo.CreationTimeUtc;
            if (creationUtc <= parsedStart || creationUtc >= endUtc)
                return parsedStart;

            var drift = creationUtc - parsedStart;
            var maxDrift = TimeSpan.FromMinutes(10);
            if (drift > maxDrift)
                return parsedStart;

            // 创建时间更接近 FFmpeg 真正开始写入该分片的时间
            return creationUtc;
        }
        catch
        {
            return parsedStart;
        }
    }

    private static DateTime RefineEndTime(string filePath, DateTime startUtc, DateTime estimatedEndUtc, int sliceSeconds)
    {
        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return estimatedEndUtc;

            var writeUtc = fileInfo.LastWriteTimeUtc;
            var maxEnd = startUtc.AddSeconds(sliceSeconds * 2);
            if (writeUtc > startUtc && writeUtc <= maxEnd)
                return writeUtc;
        }
        catch
        {
            // keep estimated end
        }

        return estimatedEndUtc;
    }

    /// <summary>
    /// 当分段索引推算时间与文件实际写入时间偏差过大时，用 mtime 校准（FFmpeg 卡顿后索引会继续递增）。
    /// </summary>
    public static void AlignWithFileWriteTime(
        FileInfo fileInfo,
        TimeSpan sliceDuration,
        ref DateTime recordStart,
        ref DateTime recordEnd)
    {
        try
        {
            if (!fileInfo.Exists)
                return;

            var writeUtc = fileInfo.LastWriteTimeUtc;
            var maxDrift = Math.Max(120, sliceDuration.TotalSeconds * 2);
            if (Math.Abs((writeUtc - recordEnd).TotalSeconds) <= maxDrift)
                return;

            recordEnd = writeUtc;
            recordStart = writeUtc.Subtract(sliceDuration);
            if (recordStart >= recordEnd)
                recordStart = recordEnd.AddSeconds(-Math.Max(60, sliceDuration.TotalSeconds));
        }
        catch
        {
            // keep parsed values
        }
    }

    private static TimeZoneInfo GetChinaTimeZone()
    {
        foreach (var id in new[] { "China Standard Time", "Asia/Shanghai" })
        {
            try
            {
                return TimeZoneInfo.FindSystemTimeZoneById(id);
            }
            catch (TimeZoneNotFoundException)
            {
            }
            catch (InvalidTimeZoneException)
            {
            }
        }

        return TimeZoneInfo.CreateCustomTimeZone("UTC+8", TimeSpan.FromHours(8), "UTC+8", "UTC+8");
    }
}

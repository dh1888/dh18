using System.Net.Http.Headers;

using System.Text;

using System.Text.Json;

using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Recorder;

using Microsoft.Extensions.Logging;



namespace EnterpriseAgent.Agent.Services;



/// <summary>

/// 上下班 Session：调用后端 checkin/checkout，并协调录屏/截图启停。

/// </summary>

public sealed class WorkSessionService

{

    private readonly ILogger<WorkSessionService> _logger;

    private readonly IHttpClientFactory _httpFactory;

    private readonly IAuthTokenProvider _authTokenProvider;

    private readonly IRecorderLifecycle _recorderLifecycle;

    private readonly ScreenshotService _screenshot;



    private string? _openSessionId;

    private volatile bool _captureLinkedToCheckin;

    private readonly object _lock = new();

    private string? _lastTelegramNotifiedSessionId;
    private string? _lastTelegramCheckoutNotifiedSessionId;

    /// <summary>本地上班会话 ID 或 open 状态变化时触发。</summary>
    public event EventHandler<WorkSessionSyncEventArgs>? SessionSyncChanged;



    public WorkSessionService(

        ILogger<WorkSessionService> logger,

        IHttpClientFactory httpFactory,

        IAuthTokenProvider authTokenProvider,

        IRecorderLifecycle recorderLifecycle,

        ScreenshotService screenshot)

    {

        _logger = logger;

        _httpFactory = httpFactory;

        _authTokenProvider = authTokenProvider;

        _recorderLifecycle = recorderLifecycle;

        _screenshot = screenshot;

    }



    public bool HasOpenSession

    {

        get { lock (_lock) return !string.IsNullOrEmpty(_openSessionId); }

    }



    public bool CaptureLinkedToCheckin => _captureLinkedToCheckin;



    public void UpdateCaptureLinkedToCheckin(bool linked)

    {

        if (_captureLinkedToCheckin == linked)

            return;



        _captureLinkedToCheckin = linked;

        _logger.LogInformation("Capture mode updated: linkedToCheckin={Linked}", linked);



        if (linked)

        {

            lock (_lock)

            {

                if (string.IsNullOrEmpty(_openSessionId))

                    StopWorkCapture();

            }

        }

    }



    public void ApplyAutoCaptureFromPolicy(Policy? policy)

    {

        if (_captureLinkedToCheckin)

            return;



        var recordingEnabled = policy?.GetRecordingConfig()?.Enabled == true;

        var screenshotEnabled = policy?.GetScreenshotConfig()?.Enabled == true;



        if (recordingEnabled || screenshotEnabled)

        {

            StartWorkCapture();

            _logger.LogInformation("Auto capture enabled from policy (recording={Recording}, screenshot={Screenshot})",

                recordingEnabled, screenshotEnabled);

        }

        else

        {

            StopWorkCapture();

            _logger.LogInformation("Auto capture disabled: recording and screenshot are off in policy");

        }

    }



    public async Task<bool> CheckInAsync(CancellationToken ct = default)

    {

        var snapshot = _authTokenProvider.GetSnapshot();

        if (!snapshot.IsApproved || string.IsNullOrEmpty(snapshot.Token))

        {

            _logger.LogWarning("Check-in rejected: device not approved or missing token");

            return false;

        }



        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/checkin");

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);



        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);

        var body = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)

        {

            _logger.LogWarning("Check-in failed: {Status} {Body}", response.StatusCode, body);

            return false;

        }



        var sessionId = ParseSessionId(body);

        lock (_lock) { _openSessionId = sessionId; }



        if (_captureLinkedToCheckin)

            StartWorkCapture();



        _logger.LogInformation("Check-in OK, session={SessionId}, captureLinked={Linked}", sessionId, _captureLinkedToCheckin);

        return true;

    }



    public async Task<bool> CheckOutAsync(CancellationToken ct = default)

    {

        var snapshot = _authTokenProvider.GetSnapshot();

        if (string.IsNullOrEmpty(snapshot.Token))

            return false;



        string? sessionId;

        lock (_lock) { sessionId = _openSessionId; }



        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/checkout");

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        if (!string.IsNullOrEmpty(sessionId))

        {

            var payload = JsonSerializer.Serialize(new { sessionId });

            request.Content = new StringContent(payload, Encoding.UTF8, "application/json");

        }



        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);

        var body = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)

        {

            _logger.LogWarning("Check-out failed: {Status} {Body}", response.StatusCode, body);

            return false;

        }



        lock (_lock) { _openSessionId = null; }



        if (_captureLinkedToCheckin)

            StopWorkCapture();



        _logger.LogInformation("Check-out OK");

        return true;

    }



    /// <summary>
    /// 启动时从服务端恢复未关闭的上班会话（崩溃/重启后续录）。
    /// </summary>
    public Task TryRestoreOpenSessionAsync(CancellationToken ct = default)
        => SyncOpenSessionFromServerAsync(ct, notifyTelegramCheckIn: false);

    /// <summary>
    /// 从服务端同步 open 会话与 capture 设置；不依赖「打卡联动录屏」也会更新托盘上班状态。
    /// </summary>
    public async Task<bool> SyncOpenSessionFromServerAsync(CancellationToken ct = default, bool notifyTelegramCheckIn = true)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return false;

        using var request = new HttpRequestMessage(HttpMethod.Get, $"{GetServerUrl()}/api/v1/agent/session");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        if (!response.IsSuccessStatusCode)
            return false;

        var body = await response.Content.ReadAsStringAsync(ct);
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return false;

            if (data.TryGetProperty("captureLinkedToCheckin", out var linkedProp) &&
                (linkedProp.ValueKind == JsonValueKind.True || linkedProp.ValueKind == JsonValueKind.False))
            {
                UpdateCaptureLinkedToCheckin(linkedProp.GetBoolean());
            }

            var open = data.TryGetProperty("workSessionOpen", out var wso) && wso.GetBoolean();
            string? sessionId = null;
            if (data.TryGetProperty("workSessionId", out var wsid))
                sessionId = wsid.GetString();

            var source = data.TryGetProperty("workSessionSource", out var srcProp)
                ? srcProp.GetString()
                : null;

            return ApplyServerSessionState(open, sessionId, source, notifyTelegramCheckIn);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to sync open work session from server");
            return false;
        }
    }



    public Task SyncCaptureSettingsAsync(CancellationToken ct = default)
        => SyncOpenSessionFromServerAsync(ct, notifyTelegramCheckIn: false);



    public void HandleTelegramCheckInNotify(string sessionId)
    {
        if (string.IsNullOrWhiteSpace(sessionId))
            return;

        ApplyServerSessionState(open: true, sessionId, source: "telegram", notifyTelegramCheckIn: true);
    }

    public void HandleTelegramCheckOutNotify(string? sessionId)
    {
        var checkoutNotified = TryNotifyTelegramCheckOut(sessionId);
        StopExternalWorkSession(sessionId);

        if (checkoutNotified)
        {
            SessionSyncChanged?.Invoke(this, new WorkSessionSyncEventArgs
            {
                TelegramCheckOutNotified = true,
            });
        }
    }



    private bool ApplyServerSessionState(bool open, string? sessionId, string? source, bool notifyTelegramCheckIn)
    {
        var wasOpen = HasOpenSession;
        string? previousSessionId;
        lock (_lock)
        {
            previousSessionId = _openSessionId;
        }

        var sessionChanged = false;
        var telegramNotified = false;

        if (open && !string.IsNullOrWhiteSpace(sessionId))
        {
            var isNewSession = !wasOpen || !string.Equals(previousSessionId, sessionId, StringComparison.Ordinal);
            lock (_lock)
            {
                sessionChanged = _openSessionId != sessionId;
                _openSessionId = sessionId;
            }

            if (_captureLinkedToCheckin && isNewSession && !_screenshot.WorkSessionActive)
            {
                StartWorkCapture();
                _logger.LogInformation("Work session synced from server, capture started (session={SessionId})", sessionId);
            }
            else if (isNewSession)
            {
                _logger.LogInformation("Work session synced from server (session={SessionId}, source={Source})", sessionId, source);
            }

            if (notifyTelegramCheckIn && isNewSession)
                telegramNotified = TryNotifyTelegramCheckIn(sessionId, source);
        }
        else
        {
            lock (_lock)
            {
                sessionChanged = !string.IsNullOrEmpty(_openSessionId);
                _openSessionId = null;
            }

            if (_captureLinkedToCheckin && wasOpen)
                StopWorkCapture();
        }

        if (sessionChanged || telegramNotified)
        {
            SessionSyncChanged?.Invoke(this, new WorkSessionSyncEventArgs
            {
                SessionStateChanged = sessionChanged,
                TelegramCheckInNotified = telegramNotified
            });
        }

        return sessionChanged;
    }



    private bool TryNotifyTelegramCheckIn(string sessionId, string? source)
    {
        if (!string.Equals(source, "telegram", StringComparison.OrdinalIgnoreCase))
            return false;

        lock (_lock)
        {
            if (string.Equals(_lastTelegramNotifiedSessionId, sessionId, StringComparison.Ordinal))
                return false;
            _lastTelegramNotifiedSessionId = sessionId;
        }

        return true;
    }

    private bool TryNotifyTelegramCheckOut(string? sessionId)
    {
        var key = string.IsNullOrWhiteSpace(sessionId) ? "*" : sessionId.Trim();
        lock (_lock)
        {
            if (string.Equals(_lastTelegramCheckoutNotifiedSessionId, key, StringComparison.Ordinal))
                return false;
            _lastTelegramCheckoutNotifiedSessionId = key;
        }

        return true;
    }



	public void StartExternalWorkSession(string sessionId, string source = "telegram")
	{
        ApplyServerSessionState(open: true, sessionId, source, notifyTelegramCheckIn: true);
	}



	public void StopExternalWorkSession(string? sessionId = null)
	{
        lock (_lock)
        {
            if (!string.IsNullOrEmpty(sessionId) && !string.IsNullOrEmpty(_openSessionId) && _openSessionId != sessionId)
                return;
        }

        ApplyServerSessionState(open: false, sessionId: null, source: null, notifyTelegramCheckIn: false);
	}



	private void StartWorkCapture()

    {

        _screenshot.StartCapture();

        _ = _recorderLifecycle.RequestAsync(
            RecorderCommand.StartWorkSession,
            new RecorderRequestContext { Reason = "WorkSession checkin" });

    }



    private void StopWorkCapture()

    {

        _ = _recorderLifecycle.RequestAsync(
            RecorderCommand.StopWorkSession,
            new RecorderRequestContext { Reason = "WorkSession checkout" });

        _screenshot.StopCapture();

    }



    private string GetServerUrl() => _serverUrlResolver?.Invoke() ?? "http://localhost:8080";



    private Func<string>? _serverUrlResolver;

    public void SetServerUrlResolver(Func<string> resolver) => _serverUrlResolver = resolver;



    private static string? ParseSessionId(string json)

    {

        try

        {

            using var doc = JsonDocument.Parse(json);

            if (doc.RootElement.TryGetProperty("data", out var data)

                && data.TryGetProperty("sessionId", out var sid))

            {

                return sid.GetString();

            }

        }

        catch { /* ignore */ }



        return null;

    }

}



// Services/FileUploadService.cs - 完整修改版（集成 AuthTokenProvider）

using System.Buffers;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using EnterpriseAgent.Agent.Extensions;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Resilience;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Hosting;
using Polly;
using Polly.Retry;
using System.Net.NetworkInformation;

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.Services;

internal sealed class UploadSessionExpiredException : Exception
{
    public UploadSessionExpiredException()
        : base("UPLOAD_SESSION_EXPIRED") { }
}

public class FileUploadService : BackgroundService
{
    private readonly ILogger<FileUploadService> _logger;
    private readonly ApiSigner _signer;
    private HttpClient _http;
    private readonly IHttpClientFactory _httpFactory;
    private readonly object _httpLock = new();
    private readonly AgentConfig _config;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly CircuitBreaker _circuitBreaker;
    private readonly IdempotencyService _idempotency;
    private readonly IAuthTokenProvider _authTokenProvider;

    private UploadConfig? _currentPolicy;
    private readonly AsyncRetryPolicy _retryPolicy;
    private readonly SemaphoreSlim _queueLock = new(1, 1);
    private readonly CancellationTokenSource _internalCts = new();
    
    private volatile bool _isStopping;
    private int _totalUploads;
    private int _failedUploads;
    private DateTime _lastUploadTimeUtc;

    // ✅ JSON 序列化配置：camelCase + 紧凑格式
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false,
        DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
    };

    public FileUploadService(
        ILogger<FileUploadService> logger,
        IServiceScopeFactory scopeFactory,
        ApiSigner signer,
        IHttpClientFactory httpFactory,
        HttpClient http,
        AgentConfig config,
        ILogger<CircuitBreaker> circuitBreakerLogger,
        ILogger<IdempotencyService> idempotencyLogger,
        IAuthTokenProvider authTokenProvider)
    {
        _logger = logger;
        _scopeFactory = scopeFactory;
        _signer = signer;
        _httpFactory = httpFactory;
        _http = http ?? _httpFactory.CreateClient("UploadClient");
        _config = config;
        _authTokenProvider = authTokenProvider;

        _circuitBreaker = new CircuitBreaker("FileUpload", circuitBreakerLogger);
        _idempotency = new IdempotencyService(idempotencyLogger);

        _http.Timeout = TimeSpan.FromMinutes(5);

        _currentPolicy = new UploadConfig
        {
            Enabled = true,
            RateLimitKBps = Constants.DefaultRateLimitKBps,
            MaxConcurrent = Constants.DefaultMaxConcurrentUploads,
            ChunkSizeKB = Constants.DefaultChunkSizeKB
        };

        _logger.LogInformation(
            "Default upload policy set: Enabled={Enabled}, RateLimit={RateLimit}KB/s, MaxConcurrent={MaxConcurrent}",
            _currentPolicy.Enabled,
            _currentPolicy.RateLimitKBps,
            _currentPolicy.MaxConcurrent);

        _retryPolicy = Polly.Policy
            .Handle<HttpRequestException>()
            .Or<UploadSessionExpiredException>()
            .Or<TaskCanceledException>()
            .Or<IOException>()
            .WaitAndRetryAsync(
                retryCount: Constants.MaxRetryCount,
                sleepDurationProvider: retry => TimeSpan.FromSeconds(Math.Pow(2, retry)),
                onRetry: (exception, delay, retryCount, _) =>
                {
                    _logger.LogWarning(
                        exception,
                        "Upload retry {Retry}/{MaxRetries} after {Delay}ms",
                        retryCount,
                        Constants.MaxRetryCount,
                        delay.TotalMilliseconds);
                });

        NetworkChange.NetworkAvailabilityChanged += OnNetworkAvailabilityChanged;
    }

    #region ========== HttpClient 管理 ==========

    /// <summary>
    /// 在网络/系统恢复时重建内部 HttpClient（线程安全）
    /// </summary>
    public void ResetHttpClient()
    {
        try
        {
            lock (_httpLock)
            {
                _http = _httpFactory.CreateClient("UploadClient");
                _http.Timeout = TimeSpan.FromMinutes(5);
            }

            _logger.LogInformation("HttpClient for FileUploadService reset successfully");
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to reset HttpClient");
        }
    }

    /// <summary>
    /// ✅ 获取当前 Token（从 Provider）
    /// </summary>
    private string GetCurrentToken()
    {
        return _authTokenProvider.GetSnapshot().Token;
    }

    /// <summary>
    /// ✅ 获取当前 DeviceId（从 Provider）
    /// </summary>
    private string GetCurrentDeviceId()
    {
        return _authTokenProvider.GetSnapshot().DeviceId;
    }

    /// <summary>
    /// ✅ 每次请求显式设置 Header（不依赖全局 HttpClient Header）
    /// </summary>
    private void ApplyAuthHeader(HttpRequestMessage request)
    {
        HttpAuthExtensions.TryApplyBearerToken(request, _authTokenProvider);
    }

    #endregion

    #region ========== Token 刷新 ==========

    private async Task<bool> TryRefreshAuthTokenAsync()
    {
        try
        {
            // ✅ 使用全局 Provider 刷新 Token
            var newToken = await _authTokenProvider.RefreshTokenAsync();
            if (!string.IsNullOrEmpty(newToken))
            {
                ResetHttpClient();
                _logger.LogInformation("Auth token refreshed successfully");
                return true;
            }

            _logger.LogWarning("Token refresh returned empty token");
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to refresh auth token");
            return false;
        }
    }

    #endregion

    #region ========== 网络状态变化 ==========

    private void OnNetworkAvailabilityChanged(object? sender, NetworkAvailabilityEventArgs e)
    {
        if (e.IsAvailable)
        {
            _logger.LogInformation("Network available - rebuilding HttpClient and resetting stuck uploads");
            ResetHttpClient();
            // 异步触发重置，不阻塞事件回调
            _ = Task.Run(async () =>
            {
                try
                {
                    using var scope = _scopeFactory.CreateScope();
                    var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
                    await repo.ResetStuckTasksAsync(TimeSpan.FromMinutes(30));
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to reset stuck uploads on network available event");
                }
            });
        }
    }

    #endregion

    #region ========== 策略更新 ==========

    public void UpdatePolicy(AgentPolicy policy)
    {
        _currentPolicy = policy.GetUploadConfig();
        _logger.LogInformation("Upload policy updated: Enabled={Enabled}, RateLimit={RateLimitKBps}KB/s, MaxConcurrent={MaxConcurrent}, ChunkSize={ChunkSizeKB}KB",
            _currentPolicy.Enabled, _currentPolicy.RateLimitKBps, _currentPolicy.MaxConcurrent, _currentPolicy.ChunkSizeKB);
    }

    #endregion

    #region ========== 队列入队 ==========

    /// <summary>
    /// 入队文件上传（带重试机制）
    /// </summary>
    public async Task QueueFileAsync(string path, string type, string id, int maxRetries = 5)
    {
        if (string.IsNullOrEmpty(path))
        {
            _logger.LogWarning("Cannot queue file: path is null or empty");
            return;
        }

        // ✅ 重试机制：处理文件暂时不可用的情况
        for (int retry = 0; retry < maxRetries; retry++)
        {
            // 检查文件是否存在
            if (!File.Exists(path))
            {
                if (retry < maxRetries - 1)
                {
                    var delayMs = 100 * (retry + 1);
                    _logger.LogDebug("File not ready, retry {Retry}/{Max} in {Delay}ms: {File}",
                        retry + 1, maxRetries, delayMs, SensitiveDataFilter.SafeFilePath(path));
                    await Task.Delay(delayMs);
                    continue;
                }

                _logger.LogWarning(
                    "Cannot queue missing file after {Retries} retries. Path={Path}, FullPath={FullPath}",
                    maxRetries, path, Path.GetFullPath(path));
                return;
            }

            // ✅ 尝试打开文件验证可读性（防止文件被锁定）
            try
            {
                using var fs = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                if (fs.Length == 0)
                {
                    _logger.LogWarning("File is empty: {File}", SensitiveDataFilter.SafeFilePath(path));
                    return;
                }
            }
            catch (IOException)
            {
                if (retry < maxRetries - 1)
                {
                    var delayMs = 100 * (retry + 1);
                    _logger.LogDebug("File locked, retry {Retry}/{Max} in {Delay}ms: {File}",
                        retry + 1, maxRetries, delayMs, SensitiveDataFilter.SafeFilePath(path));
                    await Task.Delay(delayMs);
                    continue;
                }

                _logger.LogWarning("Cannot queue locked file after {Retries} retries: {File}",
                    maxRetries, SensitiveDataFilter.SafeFilePath(path));
                return;
            }

            // ✅ 检查是否已在队列中
            if (await UploadQueueExistsAsync(path))
            {
                _logger.LogDebug("File already queued: {File}", SensitiveDataFilter.SafeFilePath(path));
                return;
            }

            // ✅ 执行入队
            var queueItem = new UploadQueue
            {
                Id = Guid.NewGuid().ToString(),
                FilePath = path,
                FileType = type,
                FileId = id,
                Status = "pending",
                Offset = 0,
                RetryCount = 0,
                CreatedAt = DateTime.UtcNow
            };

            await AddUploadQueueAsync(queueItem);
            _logger.LogInformation("Queued upload: {FileName} ({Type})", Path.GetFileName(path), type);
            return;
        }
    }

    // ✅ 带时间的入队方法
    public async Task QueueFileWithTimeAsync(UploadQueue queueItem)
    {
        if (queueItem == null)
            throw new ArgumentNullException(nameof(queueItem));

        _logger.LogDebug("QueueFileWithTimeAsync called for file: {FilePath}, FileType: {FileType}",
            Path.GetFileName(queueItem.FilePath), queueItem.FileType);

        // ✅ 关键修复：确保 UploadId 存在（使用标准 UUID 格式）
        if (string.IsNullOrWhiteSpace(queueItem.UploadId))
        {
            queueItem.UploadId = Guid.NewGuid().ToString();
            _logger.LogDebug("Generated new UploadId: {UploadId} for file: {FileName}",
                queueItem.UploadId, Path.GetFileName(queueItem.FilePath));
        }

        // ✅ 确保 Id 存在
        if (string.IsNullOrWhiteSpace(queueItem.Id))
        {
            queueItem.Id = Guid.NewGuid().ToString();
        }

        // ✅ 确保 Status 存在
        if (string.IsNullOrWhiteSpace(queueItem.Status))
        {
            queueItem.Status = "pending";
        }

        // ✅ 确保 CreatedAt 存在
        if (queueItem.CreatedAt == default)
        {
            queueItem.CreatedAt = DateTime.UtcNow;
        }

        if (!File.Exists(queueItem.FilePath))
        {
            _logger.LogWarning("Cannot queue missing file: {File}", SensitiveDataFilter.SafeFilePath(queueItem.FilePath));
            return;
        }

        if (await UploadQueueExistsAsync(queueItem.FilePath))
        {
            _logger.LogDebug("File already queued: {File}", SensitiveDataFilter.SafeFilePath(queueItem.FilePath));
            return;
        }

        await AddUploadQueueAsync(queueItem);

        _logger.LogInformation("✓ Queued upload: {FileName} ({Type}), UploadId: {UploadId}",
            Path.GetFileName(queueItem.FilePath),
            queueItem.FileType,
            queueItem.UploadId);
    }

    /// <summary>
    /// 批量入队（大批量录屏上传任务专用，单事务写入 SQLite）
    /// </summary>
    /// <returns>新入队的队列 ID 列表（含已在队列中的文件）</returns>
    public async Task<List<string>> QueueManyWithTimeAsync(IReadOnlyList<UploadQueue> queueItems)
    {
        if (queueItems == null || queueItems.Count == 0)
            return new List<string>();

        var paths = queueItems
            .Where(q => !string.IsNullOrWhiteSpace(q.FilePath) && File.Exists(q.FilePath))
            .Select(q => q.FilePath)
            .ToList();

        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        var existing = await repo.GetActiveByFilePathsAsync(paths);

        var toInsert = new List<UploadQueue>();
        var trackedIds = new List<string>(queueItems.Count);
        var seenPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var item in queueItems)
        {
            if (string.IsNullOrWhiteSpace(item.FilePath) || !File.Exists(item.FilePath))
                continue;

            if (!seenPaths.Add(item.FilePath))
                continue;

            if (existing.TryGetValue(item.FilePath, out var active))
            {
                trackedIds.Add(active.Id);
                continue;
            }

            if (string.IsNullOrWhiteSpace(item.UploadId))
                item.UploadId = Guid.NewGuid().ToString();
            if (string.IsNullOrWhiteSpace(item.Id))
                item.Id = Guid.NewGuid().ToString();
            if (string.IsNullOrWhiteSpace(item.Status))
                item.Status = "pending";
            if (item.CreatedAt == default)
                item.CreatedAt = DateTime.UtcNow;

            toInsert.Add(item);
            trackedIds.Add(item.Id);
        }

        if (toInsert.Count > 0)
            await repo.AddManyAsync(toInsert);

        _logger.LogInformation(
            "Bulk queued {New} new uploads ({Skipped} already active), total tracked {Total}",
            toInsert.Count, queueItems.Count - toInsert.Count, trackedIds.Count);

        return trackedIds;
    }

    /// <summary>
    /// 检查文件是否已在队列中
    /// </summary>
    public async Task<bool> QueueFileExistsAsync(string filePath)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        return await repo.ExistsPendingAsync(filePath);
    }

    #endregion

    #region ========== 队列操作辅助方法 ==========

    private async Task<bool> UploadQueueExistsAsync(string path)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        return await repo.ExistsPendingAsync(path);
    }

    private async Task AddUploadQueueAsync(UploadQueue queue)
    {
        _logger.LogDebug("AddUploadQueueAsync - Id: {Id}, UploadId: {UploadId}, FilePath: {FilePath}",
            queue.Id, queue.UploadId, Path.GetFileName(queue.FilePath));

        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        await repo.AddAsync(queue);

        _logger.LogDebug("AddUploadQueueAsync completed for Id: {Id}", queue.Id);
    }

    private async Task<List<UploadQueue>> GetPendingQueueAsync(int maxConcurrent)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        return await repo.GetPendingAsync(maxConcurrent);
    }

    private async Task UpdateQueueStatusAsync(string id, string status, string? message = null, int? retryCount = null)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        if (retryCount.HasValue)
            await repo.UpdateStatusAsync(id, status, message, retryCount.Value);
        else
            await repo.UpdateStatusAsync(id, status, message);
    }

    private async Task UpdateQueueUploadIdAsync(string id, string uploadId)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        await repo.UpdateUploadIdAsync(id, uploadId);
    }

    private async Task UpdateQueueOffsetAsync(string id, long offset)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        await repo.UpdateOffsetAsync(id, offset);
    }

    #endregion

    #region ========== 主循环 ==========

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("File upload service started");

        try
        {
            using var scope = _scopeFactory.CreateScope();
            var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
            var resetCount = await repo.ResetAllUploadingAsync();
            if (resetCount > 0)
            {
                _logger.LogWarning("Upload queue startup recovery: {Count} tasks reset from uploading to pending", resetCount);
            }
            await BackfillMissingRecordingTimesAsync();
            _idempotency.ClearAll();
            _circuitBreaker.Close();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Upload queue startup recovery failed");
        }

        if (_currentPolicy == null)
        {
            _logger.LogWarning("Upload policy is null, creating default policy");
            _currentPolicy = new UploadConfig
            {
                Enabled = true,
                RateLimitKBps = Constants.DefaultRateLimitKBps,
                MaxConcurrent = Constants.DefaultMaxConcurrentUploads,
                ChunkSizeKB = Constants.DefaultChunkSizeKB
            };
        }

        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken, _internalCts.Token);
        var ct = linkedCts.Token;

        try
        {
            while (!ct.IsCancellationRequested && !_isStopping)
            {
                try
                {
                    if (_currentPolicy.Enabled)
                    {
                        await ProcessQueueAsync(ct);
                    }
                    else
                    {
                        await Task.Delay(5000, ct);
                    }
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Upload service loop error");
                    await Task.Delay(10000, ct);
                }

                await Task.Delay(Constants.UploadQueuePollIntervalMs, ct);
            }
        }
        finally
        {
            _logger.LogInformation("Upload service stopped. Total={Total}, Failed={Failed}", _totalUploads, _failedUploads);
        }
    }

    #endregion

    #region ========== 队列处理 ==========

    private async Task ProcessQueueAsync(CancellationToken ct)
    {
        List<UploadQueue> items = new List<UploadQueue>();

        await _queueLock.WaitAsync(ct);

        try
        {
            var isEnabled = _currentPolicy?.Enabled ?? false;
            var maxConcurrent = Math.Max(1, _currentPolicy?.MaxConcurrent ?? Constants.DefaultMaxConcurrentUploads);

            // ✅ 从 Provider 获取 Token 状态
            var snapshot = _authTokenProvider.GetSnapshot();

            if (items.Count > 0)
            {
                _logger.LogInformation("=== Upload Queue Processing ===");
                _logger.LogInformation("Upload Enabled: {Enabled}", isEnabled);
                _logger.LogInformation("Max Concurrent: {MaxConcurrent}", maxConcurrent);
                _logger.LogInformation("Token Available: {HasToken}", snapshot.IsAuthenticated);
                _logger.LogInformation("Found {Count} pending upload items", items.Count);
            }
            else
            {
                _logger.LogDebug("Upload queue check: no pending items");
            }

            if (!isEnabled)
            {
                _logger.LogWarning("Upload is disabled by policy, skipping queue processing");
                return;
            }

            if (!snapshot.IsAuthenticated)
            {
                _logger.LogDebug("Upload queue skipped: device token not ready");
                return;
            }

            if (!snapshot.IsApproved)
            {
                if (snapshot.IsRejected)
                    _logger.LogWarning("Upload queue skipped: device registration rejected");
                else
                    _logger.LogDebug("Upload queue skipped: device pending admin approval");
                return;
            }

            if (string.IsNullOrWhiteSpace(snapshot.DeviceSecret))
            {
                _logger.LogDebug("Upload queue skipped: DeviceSecret not ready (wait for registration)");
                return;
            }

            // 先回收卡住任务，再取 pending，避免 uploading 占满并发槽
            using (var scope = _scopeFactory.CreateScope())
            {
                var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
                await repo.ResetStuckTasksAsync(TimeSpan.FromMinutes(1));

                var pendingCount = await repo.CountActiveAsync();
                if (pendingCount >= 50)
                    maxConcurrent = Math.Min(4, Math.Max(maxConcurrent, 3));
            }

            items = await GetPendingQueueAsync(maxConcurrent);

            _logger.LogInformation("Found {Count} pending upload items", items.Count);

            if (items.Count == 0) return;

            foreach (var item in items)
            {
                var fileExists = File.Exists(item.FilePath);
                _logger.LogInformation(
                    "Queue Item: Id={Id}, File={File}, Type={Type}, Status={Status}, Retry={Retry}, FileExists={FileExists}",
                    item.Id, Path.GetFileName(item.FilePath), item.FileType, item.Status, item.RetryCount, fileExists);
            }
        }
        finally
        {
            _queueLock.Release();
        }

        _logger.LogInformation("Starting to process {Count} upload items", items.Count);
        var tasks = items.Select(item => ProcessItemSafeAsync(item, ct));
        await Task.WhenAll(tasks);
        _logger.LogInformation("Finished processing {Count} upload items", items.Count);
    }

    private async Task ProcessItemSafeAsync(UploadQueue item, CancellationToken ct)
    {
        try
        {
            await ProcessItemAsync(item, ct);
        }
        catch (OperationCanceledException) { }
        catch (Exception ex)
        {
            Interlocked.Increment(ref _failedUploads);
            _logger.LogError(ex, "Unhandled upload item failure: {Id}", item.Id);
        }
    }

    private async Task ProcessItemAsync(UploadQueue item, CancellationToken ct)
    {
        if (_isStopping) return;

        if (!File.Exists(item.FilePath))
        {
            await UpdateQueueStatusAsync(item.Id, "failed", "File not found");
            Interlocked.Increment(ref _failedUploads);
            return;
        }

        if (item.RetryCount >= Constants.MaxRetryCount)
        {
            await UpdateQueueStatusAsync(item.Id, "failed", "Retry limit exceeded");
            Interlocked.Increment(ref _failedUploads);
            return;
        }

        if (_circuitBreaker.GetDiagnostics().IsOpen)
        {
            _logger.LogWarning("Upload deferred: circuit breaker open for {File}", Path.GetFileName(item.FilePath));
            await UpdateQueueStatusAsync(item.Id, "pending", "Circuit breaker open");
            return;
        }

        _logger.LogInformation("Upload started: {File} ({Type})", Path.GetFileName(item.FilePath), item.FileType);

        try
        {
            await _circuitBreaker.ExecuteAsync(async () =>
            {
                await _retryPolicy.ExecuteAsync(async () =>
                {
                    ct.ThrowIfCancellationRequested();
                    await UpdateQueueStatusAsync(item.Id, "uploading");
                    await EnsureRecordingTimesAsync(item);
                    await UploadChunkedAsync(item, ct);

                    // ✅ 新增：完成上传通知（传递整个 item，包含时间信息）
                    await CompleteUploadAsync(item, ct);

                    await UpdateQueueStatusAsync(item.Id, "completed");

                    // ✅ 原有功能：根据文件类型更新状态
                    if (item.FileType == "recording")
                        await MarkRecordingUploadedAsync(item);
                    else if (item.FileType == "screenshot")
                        await UpdateScreenshotUploadStatusAsync(item.FileId, true);

                    Interlocked.Increment(ref _totalUploads);
                    _lastUploadTimeUtc = DateTime.UtcNow;

                    _logger.LogInformation("Upload completed: {File}", Path.GetFileName(item.FilePath));
                });
            }, ct);
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("Upload cancelled: {File}", Path.GetFileName(item.FilePath));
        }
        catch (DeviceNotApprovedException ex)
        {
            await UpdateQueueStatusAsync(item.Id, "pending", "Waiting for admin approval");
            _logger.LogWarning(
                "Upload deferred for {File} until device is approved (status={Status})",
                Path.GetFileName(item.FilePath),
                ex.ApprovalStatus);
        }
        catch (Exception ex)
        {
            var retryCount = item.RetryCount + 1;
            var status = retryCount >= Constants.MaxRetryCount ? "failed" : "pending";
            await UpdateQueueStatusAsync(item.Id, status, ex.Message, retryCount);

            if (retryCount >= Constants.MaxRetryCount)
                Interlocked.Increment(ref _failedUploads);

            _logger.LogError(ex, "Upload failed: {File}", Path.GetFileName(item.FilePath));
        }
    }

    #endregion

    #region ========== 上传核心方法 ==========

    /// <summary>
    /// 分块上传核心方法 - 使用与 Go 后端对齐的签名
    /// </summary>
    private async Task UploadChunkedAsync(UploadQueue item, CancellationToken ct)
    {
        _logger.LogDebug("=== UploadChunkedAsync started ===");
        _logger.LogDebug("Item Id: {Id}, UploadId: {UploadId}, FilePath: {FilePath}",
            item.Id, item.UploadId, Path.GetFileName(item.FilePath));

        var file = new FileInfo(item.FilePath);
        var chunkSizeKB = Math.Max(Constants.MinChunkSizeKB, _currentPolicy?.ChunkSizeKB ?? Constants.DefaultChunkSizeKB);
        var chunkSize = chunkSizeKB * 1024;
        var rateLimitKBps = Math.Max(64, _currentPolicy?.RateLimitKBps ?? Constants.DefaultRateLimitKBps);
        var totalChunks = (int)Math.Ceiling((double)file.Length / chunkSize);

        var uploadId = string.IsNullOrWhiteSpace(item.UploadId) ? Guid.NewGuid().ToString() : item.UploadId;

        if (string.IsNullOrWhiteSpace(item.UploadId))
        {
            await UpdateQueueUploadIdAsync(item.Id, uploadId);
            item.UploadId = uploadId;
            _logger.LogDebug("Updated item.UploadId to {UploadId}", item.UploadId);
        }

        var startChunk = (int)(item.Offset / chunkSize);

        await using var fs = new FileStream(
            item.FilePath,
            FileMode.Open,
            FileAccess.Read,
            FileShare.ReadWrite | FileShare.Delete,
            81920,
            true);

        // 升级/策略变更导致 chunk 大小变化时，offset 可能不对齐，需重置续传
        if (item.Offset > 0 && item.Offset % chunkSize != 0)
        {
            _logger.LogWarning(
                "Upload offset {Offset} misaligned with chunk size {ChunkSize}B for {File}, restarting from scratch",
                item.Offset, chunkSize, file.Name);
            await ResetUploadSessionAsync(item);
            item.Offset = 0;
            startChunk = 0;
        }
        else if (item.Offset > 0)
        {
            fs.Seek(item.Offset, SeekOrigin.Begin);
        }

        var rentedBuffer = ArrayPool<byte>.Shared.Rent(chunkSize);

        try
        {
            for (int i = startChunk; i < totalChunks && !ct.IsCancellationRequested; i++)
            {
                ct.ThrowIfCancellationRequested();

                var remaining = file.Length - fs.Position;
                var bytesToRead = (int)Math.Min(chunkSize, remaining);
                var bytesRead = await fs.ReadAsync(rentedBuffer.AsMemory(0, bytesToRead), ct);

                if (bytesRead <= 0) break;

                var chunkData = new byte[bytesRead];
                Buffer.BlockCopy(rentedBuffer, 0, chunkData, 0, bytesRead);
                var chunkChecksum = ComputeChunkChecksum(chunkData);

                // 重试循环 - 每次重试都生成新的签名
                int retryAttempt = 0;
                const int maxRetries = 3;
                bool chunkUploaded = false;

                while (!chunkUploaded && retryAttempt < maxRetries && !ct.IsCancellationRequested)
                {
                    try
                    {
                        var signaturePayload = new UploadSignaturePayload
                        {
                            UploadId = uploadId,
                            FileName = file.Name,
                            FileType = item.FileType,
                            FileId = item.FileId,
                            ChunkIndex = i,
                            TotalChunks = totalChunks
                        };

                        var (timestamp, nonce, signature) = _signer.CreateSignedRequest(signaturePayload);

                        _logger.LogDebug("Uploading chunk {Chunk}/{Total} for {File}, Attempt {Attempt}, Nonce: {Nonce}...",
                            i + 1, totalChunks, file.Name, retryAttempt + 1, nonce.Length > 8 ? nonce[..8] : nonce);

                        var chunkUrl =
                            $"{_config.ServerUrl}/api/v1/upload/chunk?nonce={Uri.EscapeDataString(nonce)}";
                        using var request = new HttpRequestMessage(HttpMethod.Post, chunkUrl)
                        {
                            Content = new ByteArrayContent(chunkData)
                        };
                        request.Content.Headers.ContentType =
                            new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

                        request.Headers.TryAddWithoutValidation("X-Upload-Id", uploadId);
                        request.Headers.TryAddWithoutValidation("X-File-Name", file.Name);
                        if (!string.IsNullOrWhiteSpace(item.FileType))
                            request.Headers.TryAddWithoutValidation("X-File-Type", item.FileType);
                        if (!string.IsNullOrWhiteSpace(item.FileId))
                            request.Headers.TryAddWithoutValidation("X-File-Id", item.FileId);
                        request.Headers.TryAddWithoutValidation("X-Chunk-Index", i.ToString());
                        request.Headers.TryAddWithoutValidation("X-Total-Chunks", totalChunks.ToString());
                        request.Headers.TryAddWithoutValidation("X-Chunk-Checksum", chunkChecksum);

                        // ✅ 显式设置认证头（从 Provider 获取最新 Token）
                        ApplyAuthHeader(request);

                        await _signer.AddSignatureHeadersAsync(request, timestamp, nonce, signature, ct)
                            .ConfigureAwait(false);

                        // 幂等性执行 - operationId 加入重试次数确保唯一性
                        var operationId = $"{uploadId}:chunk:{i}:attempt:{retryAttempt}";

                        await _idempotency.ExecuteAsync(operationId, async () =>
                        {
                            using var response = await _http.SendAsync(request, ct);

                            if (response.IsSuccessStatusCode)
                            {
                                chunkUploaded = true;
                                return;
                            }

                            var error = await response.Content.ReadAsStringAsync(ct);
                            var statusCode = (int)response.StatusCode;

                            // 处理 401（Token 过期）
                            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                            {
                                _logger.LogWarning("Chunk upload returned 401, attempting token refresh (Attempt {Attempt}/{MaxRetries})",
                                    retryAttempt + 1, maxRetries);

                                var refreshed = await TryRefreshAuthTokenAsync();
                                if (refreshed)
                                {
                                    throw new HttpRequestException("TOKEN_REFRESHED_NEED_RETRY", null, System.Net.HttpStatusCode.Unauthorized);
                                }

                                throw new HttpRequestException($"Token refresh failed: {error}");
                            }

                            if (response.StatusCode == System.Net.HttpStatusCode.Forbidden)
                            {
                                var status = _authTokenProvider.GetSnapshot().DeviceStatus;
                                _authTokenProvider.UpdateDeviceStatus(
                                    string.IsNullOrWhiteSpace(status) ? "pending" : status);
                                throw new DeviceNotApprovedException(
                                    _authTokenProvider.GetSnapshot().DeviceStatus);
                            }

                            _logger.LogError("Chunk upload failed: StatusCode={StatusCode}, Error={Error}", statusCode, error);
                            throw new HttpRequestException($"Chunk upload failed: {statusCode} - {error}");
                        });
                    }
                    catch (HttpRequestException ex) when (ex.Message == "TOKEN_REFRESHED_NEED_RETRY")
                    {
                        retryAttempt++;
                        _logger.LogInformation("Token refreshed, retrying chunk {Chunk} with new nonce (Attempt {Attempt}/{MaxRetries})",
                            i + 1, retryAttempt + 1, maxRetries);

                        await Task.Delay(1000 * retryAttempt, ct);
                        continue;
                    }
                    catch (DeviceNotApprovedException ex)
                    {
                        _logger.LogWarning(
                            "Chunk upload paused until admin approval (status={Status})",
                            ex.ApprovalStatus);
                        throw;
                    }
                    catch (Exception ex) when (retryAttempt < maxRetries - 1)
                    {
                        retryAttempt++;
                        _logger.LogWarning(ex, "Chunk upload error, retry {Attempt}/{MaxRetries}", retryAttempt + 1, maxRetries);
                        await Task.Delay(1000 * retryAttempt, ct);
                    }
                }

                if (!chunkUploaded)
                {
                    throw new Exception($"Failed to upload chunk {i} after {maxRetries} attempts");
                }

                // 减少 SQLite 写入：每 4 块或最后一块才持久化 offset
                if (i == totalChunks - 1 || (i - startChunk + 1) % 4 == 0)
                    await UpdateQueueOffsetAsync(item.Id, fs.Position);

                await ApplyRateLimitAsync(bytesRead, rateLimitKBps, ct);
            }

            await UpdateQueueOffsetAsync(item.Id, fs.Position);
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(rentedBuffer);
        }
    }

    private static string ComputeChunkChecksum(byte[] data)
    {
        var hash = SHA256.HashData(data);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    /// <summary>
    /// 完成上传 - 使用与 Go 后端对齐的签名
    /// </summary>
    private async Task CompleteUploadAsync(UploadQueue item, CancellationToken ct)
    {
        _logger.LogDebug("=== CompleteUploadAsync called ===");
        _logger.LogDebug("Item Id: {Id}, UploadId: {UploadId}, FileType: {FileType}",
            item.Id, item.UploadId, item.FileType);

        if (string.IsNullOrWhiteSpace(item.UploadId))
        {
            _logger.LogError("❌ UploadId is null or empty for item {Id}! Cannot complete upload.", item.Id);
            throw new InvalidOperationException($"UploadId is required for item {item.Id}");
        }

        // ✅ 从 Provider 获取 DeviceId
        var snapshot = _authTokenProvider.GetSnapshot();
        var deviceId = snapshot.DeviceId;

        var signaturePayload = new CompleteUploadSignaturePayload
        {
            UploadId = item.UploadId,
            DeviceId = deviceId
        };

        var (timestamp, nonce, signature) = _signer.CreateSignedRequest(signaturePayload);

        var requestBody = new
        {
            uploadId = item.UploadId,
            deviceId = deviceId,
            nonce,
            timestamp,
            startTime = item.RecordStartTime?.ToIso8601String(),
            endTime = item.RecordEndTime?.ToIso8601String()
        };

        var json = JsonSerializer.Serialize(requestBody, JsonOptions);

        _logger.LogDebug("Complete request body: {Json}", json);

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{_config.ServerUrl}/api/v1/upload/complete")
        {
            Content = new StringContent(json, Encoding.UTF8, "application/json")
        };

        // ✅ 显式设置认证头（从 Provider 获取最新 Token）
        ApplyAuthHeader(request);

        await _signer.AddSignatureHeadersAsync(request, timestamp, nonce, signature, ct)
            .ConfigureAwait(false);

        _logger.LogDebug("Completing upload {UploadId}, StartTime: {StartTime}, EndTime: {EndTime}",
            item.UploadId, item.RecordStartTime, item.RecordEndTime);

        using var response = await _http.SendAsync(request, ct);

        if (!response.IsSuccessStatusCode)
        {
            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                var notFoundBody = await response.Content.ReadAsStringAsync(ct);
                if (notFoundBody.Contains("sessionExpired", StringComparison.OrdinalIgnoreCase) ||
                    notFoundBody.Contains("3002", StringComparison.Ordinal))
                {
                    _logger.LogWarning(
                        "Upload session expired for {UploadId}, resetting session for re-upload",
                        item.UploadId);
                    await ResetUploadSessionAsync(item);
                    throw new UploadSessionExpiredException();
                }
            }

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                _logger.LogWarning("CompleteUpload returned 401 Unauthorized, attempting token refresh...");
                var refreshed = await TryRefreshAuthTokenAsync();
                if (refreshed)
                {
                    var retrySnapshot = _authTokenProvider.GetSnapshot();
                    var retryDeviceId = retrySnapshot.DeviceId;

                    var retrySignaturePayload = new CompleteUploadSignaturePayload
                    {
                        UploadId = item.UploadId,
                        DeviceId = retryDeviceId
                    };

                    var (retryTimestamp, retryNonce, retrySignature) = _signer.CreateSignedRequest(retrySignaturePayload);

                    var retryBody = new
                    {
                        uploadId = item.UploadId,
                        deviceId = retryDeviceId,
                        nonce = retryNonce,
                        timestamp = retryTimestamp,
                        startTime = item.RecordStartTime?.ToIso8601String(),
                        endTime = item.RecordEndTime?.ToIso8601String()
                    };
                    var retryJson = JsonSerializer.Serialize(retryBody, JsonOptions);

                    using var retryReq = new HttpRequestMessage(HttpMethod.Post, $"{_config.ServerUrl}/api/v1/upload/complete")
                    {
                        Content = new StringContent(retryJson, Encoding.UTF8, "application/json")
                    };

                    // ✅ 显式设置认证头
                    ApplyAuthHeader(retryReq);
                    await _signer.AddSignatureHeadersAsync(retryReq, retryTimestamp, retryNonce, retrySignature, ct)
                        .ConfigureAwait(false);

                    using var retryResponse = await _http.SendAsync(retryReq, ct);
                    if (retryResponse.IsSuccessStatusCode)
                    {
                        _logger.LogInformation("Upload {UploadId} completed successfully after token refresh", item.UploadId);
                        return;
                    }

                    var retryErr = await retryResponse.Content.ReadAsStringAsync(ct);
                    _logger.LogError("Upload complete retry failed: StatusCode={StatusCode}, Error={Error}", retryResponse.StatusCode, retryErr);
                    throw new HttpRequestException($"Upload complete failed after token refresh: {(int)retryResponse.StatusCode} - {retryErr}");
                }
            }

            if (response.StatusCode == HttpStatusCode.Forbidden)
            {
                _authTokenProvider.UpdateDeviceStatus("pending");
                throw new DeviceNotApprovedException(_authTokenProvider.GetSnapshot().DeviceStatus);
            }

            var error = await response.Content.ReadAsStringAsync(ct);
            _logger.LogError("Upload complete failed: StatusCode={StatusCode}, Error={Error}", response.StatusCode, error);
            throw new HttpRequestException($"Upload complete failed: {(int)response.StatusCode} - {error}");
        }

        _logger.LogInformation("Upload {UploadId} completed successfully", item.UploadId);
    }

    #endregion

    #region ========== 辅助方法 ==========

    private async Task ResetUploadSessionAsync(UploadQueue item)
    {
        var newUploadId = Guid.NewGuid().ToString();
        item.UploadId = newUploadId;
        item.Offset = 0;

        await UpdateQueueUploadIdAsync(item.Id, newUploadId);
        await UpdateQueueOffsetAsync(item.Id, 0);

        _logger.LogInformation(
            "Upload session reset: QueueId={QueueId}, NewUploadId={UploadId}",
            item.Id, newUploadId);
    }

    private async Task EnsureRecordingTimesAsync(UploadQueue item)
    {
        if (item.FileType != "recording")
            return;

        if (item.RecordStartTime.HasValue && item.RecordEndTime.HasValue)
            return;

        if (!File.Exists(item.FilePath))
            return;

        var sliceSeconds = GetRecordingSliceSeconds();
        if (!RecordingTimeParser.TryParse(item.FilePath, sliceSeconds, out var startUtc, out var endUtc))
            return;

        item.RecordStartTime = startUtc;
        item.RecordEndTime = endUtc;

        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        await repo.UpdateRecordTimesAsync(item.Id, startUtc, endUtc);

        _logger.LogInformation(
            "Backfilled recording times for {File}: {Start} ~ {End} UTC",
            Path.GetFileName(item.FilePath), startUtc, endUtc);
    }

    private async Task BackfillMissingRecordingTimesAsync()
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
            var items = await repo.GetRecordingsMissingTimesAsync();
            if (items.Count == 0)
                return;

            var sliceSeconds = GetRecordingSliceSeconds();
            var filled = 0;

            foreach (var item in items)
            {
                if (!File.Exists(item.FilePath))
                    continue;

                if (RecordingTimeParser.TryParse(item.FilePath, sliceSeconds, out var startUtc, out var endUtc))
                {
                    await repo.UpdateRecordTimesAsync(item.Id, startUtc, endUtc);
                    filled++;
                }
            }

            if (filled > 0)
            {
                _logger.LogInformation("Backfilled recording times for {Count} legacy queue items", filled);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to backfill legacy recording times in upload queue");
        }
    }

    private int GetRecordingSliceSeconds()
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var policySync = scope.ServiceProvider.GetService<PolicySyncService>();
            var policy = policySync?.GetCurrentPolicy();
            if (policy != null)
                return policy.GetRecordingConfig().GetSliceSeconds();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to read recording slice config, using default");
        }

        return 60;
    }

    private static async Task ApplyRateLimitAsync(int bytesRead, int rateLimitKBps, CancellationToken ct)
    {
        if (rateLimitKBps <= 0) return;
        var delayMs = (bytesRead / (rateLimitKBps * 1024.0)) * 1000;
        if (delayMs > 1)
            await Task.Delay(TimeSpan.FromMilliseconds(delayMs), ct);
    }

    private async Task MarkRecordingUploadedAsync(UploadQueue item)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();

        if (!string.IsNullOrWhiteSpace(item.FileId))
            await repo.UpdateUploadStatusAsync(item.FileId, true);

        if (!string.IsNullOrWhiteSpace(item.FilePath))
        {
            var updated = await repo.MarkUploadedByFilePathAsync(item.FilePath);
            if (updated > 0)
            {
                _logger.LogDebug(
                    "Marked recording uploaded by file path: {File} ({Count} row(s))",
                    Path.GetFileName(item.FilePath),
                    updated);
            }
        }
    }

    private async Task UpdateScreenshotUploadStatusAsync(string fileId, bool uploaded)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<ScreenshotRepository>();
        await repo.UpdateUploadStatusAsync(fileId, uploaded);
    }

    #endregion

    #region ========== 健康检查 ==========

    /// <summary>
    /// 上传队列健康信息
    /// </summary>
    public class UploadQueueHealth
    {
        public int PendingCount { get; set; }
        public int UploadingCount { get; set; }
        public int FailedCount { get; set; }
        public int CompletedCount { get; set; }
        public bool IsHealthy { get; set; }
        public string Recommendation { get; set; } = "";
    }

    /// <summary>
    /// 检查队列健康状态
    /// </summary>
    public async Task<UploadQueueHealth> GetQueueHealthAsync()
    {
        using var scope = _scopeFactory.CreateScope();

        var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
        var stats = await repo.GetQueueStatsAsync();

        var health = new UploadQueueHealth
        {
            PendingCount = stats.pending,
            UploadingCount = stats.uploading,
            FailedCount = stats.failed,
            CompletedCount = stats.completed,
            IsHealthy = stats.pending < 100 && stats.failed < 50,
            Recommendation = stats.pending > 500
                ? "Increase max concurrent uploads"
                : stats.failed > 100
                    ? "Check network connectivity"
                    : "Normal"
        };

        if (!health.IsHealthy)
        {
            _logger.LogWarning(
                "Upload queue unhealthy: Pending={Pending}, Failed={Failed}, Rec={Rec}",
                stats.pending,
                stats.failed,
                health.Recommendation);
        }

        return health;
    }

    #endregion

    #region ========== 生命周期 ==========

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Stopping upload service...");
        _isStopping = true;

        _internalCts.Cancel();

        using var stopCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        stopCts.CancelAfter(TimeSpan.FromSeconds(8));
        try
        {
            await base.StopAsync(stopCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            _logger.LogWarning("Upload service stop timed out; open file handles may remain briefly");
        }
    }

    public override void Dispose()
    {
        NetworkChange.NetworkAvailabilityChanged -= OnNetworkAvailabilityChanged;
        _internalCts.Dispose();
        _queueLock.Dispose();
        _idempotency.Dispose();
        base.Dispose();
    }

    #endregion
}
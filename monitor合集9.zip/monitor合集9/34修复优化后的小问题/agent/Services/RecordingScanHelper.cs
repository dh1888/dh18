using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 按日期目录扫描录屏文件；无时间范围或日期目录不存在时回退全盘递归扫描。
/// 有时间范围时目录扫描会在任务日历范围两侧各扩 1 天，以覆盖跨天未切目录的片段；实际上传仍按解析出的录制时间过滤。
/// </summary>
internal static class RecordingScanHelper
{
    private const int DirectoryScanPaddingDays = 1;

    /// <summary>
    /// 枚举待检查的 mp4 路径。录屏目录结构为 recordings/yyyy-MM-dd/*.mp4（本地日历日）。
    /// </summary>
    public static IReadOnlyList<string> EnumerateMp4Files(
        string recordingsRoot,
        DateTime? startUtc,
        DateTime? endUtc,
        ILogger logger)
    {
        if (!startUtc.HasValue && !endUtc.HasValue)
        {
            return EnumerateAllMp4FilesRecursive(recordingsRoot, logger);
        }

        var dates = GetLocalDateRange(startUtc, endUtc, DirectoryScanPaddingDays).ToList();
        var files = new List<string>();
        var dirsFound = 0;

        foreach (var date in dates)
        {
            var dateDir = Path.Combine(recordingsRoot, date);
            if (!Directory.Exists(dateDir))
                continue;

            dirsFound++;
            try
            {
                files.AddRange(Directory.GetFiles(dateDir, "*.mp4", SearchOption.AllDirectories));
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Upload scan: failed reading date directory {DateDir}", dateDir);
            }
        }

        logger.LogInformation(
            "Upload scan: date-dir mode (±{PaddingDays}d), {DayCount} calendar day(s), {DirCount} dir(s) found, {FileCount} mp4 file(s)",
            DirectoryScanPaddingDays,
            dates.Count,
            dirsFound,
            files.Count);

        if (dirsFound == 0)
        {
            logger.LogWarning(
                "Upload scan: no date directories in range [{Start} .. {End}], falling back to full recursive search",
                dates.FirstOrDefault() ?? "-",
                dates.LastOrDefault() ?? "-");
            return EnumerateAllMp4FilesRecursive(recordingsRoot, logger);
        }

        return files;
    }

    /// <summary>
    /// 递归扫描 recordings 下全部 mp4（SQLite 兜底路径，确保不因目录名漏文件）。
    /// </summary>
    public static IReadOnlyList<string> EnumerateAllMp4FilesRecursive(string recordingsRoot, ILogger logger)
    {
        logger.LogInformation("Upload scan: full recursive search under {Root}", recordingsRoot);
        return Directory.GetFiles(recordingsRoot, "*.mp4", SearchOption.AllDirectories);
    }

    internal static IEnumerable<string> GetLocalDateRange(
        DateTime? startUtc,
        DateTime? endUtc,
        int directoryPaddingDays = 0)
    {
        var anchorStart = startUtc ?? endUtc ?? DateTime.UtcNow;
        var anchorEnd = endUtc ?? startUtc ?? DateTime.UtcNow;

        var startLocal = anchorStart.ToLocalTime().Date;
        var endLocal = anchorEnd.ToLocalTime().Date;
        if (endLocal < startLocal)
            (startLocal, endLocal) = (endLocal, startLocal);

        if (directoryPaddingDays > 0)
        {
            startLocal = startLocal.AddDays(-directoryPaddingDays);
            endLocal = endLocal.AddDays(directoryPaddingDays);
        }

        for (var day = startLocal; day <= endLocal; day = day.AddDays(1))
            yield return day.ToString("yyyy-MM-dd");
    }
}

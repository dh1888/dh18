namespace EnterpriseAgent.Agent.Services;

public sealed class WorkSessionSyncEventArgs : EventArgs
{
    public bool SessionStateChanged { get; init; }
    public bool TelegramCheckInNotified { get; init; }
    public bool TelegramCheckOutNotified { get; init; }
}

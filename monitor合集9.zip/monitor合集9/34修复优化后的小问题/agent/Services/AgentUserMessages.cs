namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// Maps backend API errors to user-facing localized messages.
/// </summary>
public static class AgentUserMessages
{
    public static string FormatLoginError(ILocalizationService? localization, string? apiError)
    {
        if (IsInvalidCredentialsError(apiError))
        {
            return localization?.GetString("InvalidLoginCredentials", "账号或密码错误")
                ?? "账号或密码错误";
        }

        return apiError
            ?? localization?.GetString("LoginFailedMessage", "登录失败，请检查账号密码或联系管理员。")
            ?? "登录失败，请检查账号密码或联系管理员。";
    }

    public static string FormatInvalidInviteError(ILocalizationService? localization)
        => localization?.GetString("InvalidInviteCode", "邀请码无效") ?? "邀请码无效";

    private static bool IsInvalidCredentialsError(string? apiError)
    {
        if (string.IsNullOrWhiteSpace(apiError))
            return false;

        return apiError.Contains("Invalid username or password", StringComparison.OrdinalIgnoreCase)
            || apiError.Contains("username or password", StringComparison.OrdinalIgnoreCase)
            || apiError.Contains("invalid credentials", StringComparison.OrdinalIgnoreCase);
    }
}

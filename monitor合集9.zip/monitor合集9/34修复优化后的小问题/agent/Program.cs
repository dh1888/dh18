using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Text.Json;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Extensions;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Services;
using EnterpriseAgent.Agent.Storage;
using EnterpriseAgent.Agent.UI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Serilog;
using Serilog.Core;
using Serilog.Events;

using AppConstants = EnterpriseAgent.Agent.Models.Constants;

[assembly: SupportedOSPlatform("windows")]

namespace EnterpriseAgent.Agent;

public sealed class Program
{
    private const string ServiceName = "Enterprise Agent";
    private const string AppDataFolder = "EnterpriseAgent";
    private const string ConfigFileName = "config.json";
    private const string LogsFolder = "logs";
    private const string DataFolder = "data";

    [STAThread]
    public static void Main(string[] args)
    {
        ConsoleWindowSuppressor.Suppress();
        Environment.CurrentDirectory = AppDomain.CurrentDomain.BaseDirectory;
        SetupGlobalExceptionHandlers();

        if (args.Contains("--watchdog", StringComparer.OrdinalIgnoreCase))
        {
            RunWatchdogMode();
            return;
        }

        if (args.Contains(HiddenLauncherFiles.GuardianLaunchArgument, StringComparer.OrdinalIgnoreCase))
        {
            RunGuardianMode();
            return;
        }

        // 用户直接双击/命令行启动：同进程进入 --ui，避免引导进程经 VBS 二次拉起后立刻退出（闪退）
        if (!args.Contains(HiddenLauncherFiles.UiLaunchArgument, StringComparer.OrdinalIgnoreCase)
            && !args.Contains("--service", StringComparer.OrdinalIgnoreCase))
        {
            args = new[] { HiddenLauncherFiles.UiLaunchArgument }.Concat(args).ToArray();
        }

        if (!SingleInstanceManager.TryAcquire())
            return;

        VoluntaryShutdownMarker.Clear();
        UiPresence.ClearHeartbeat();

        try
        {
            MainAsync(args)
                .GetAwaiter()
                .GetResult();
        }
        finally
        {
            SingleInstanceManager.Release();
        }
    }

    private static void SetupGlobalExceptionHandlers()
    {
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            var ex = e.ExceptionObject as Exception;
            WriteCrashLog($"Unhandled domain exception (terminating={e.IsTerminating})", ex);
        };

        TaskScheduler.UnobservedTaskException += (_, e) =>
        {
            WriteCrashLog("Unobserved task exception", e.Exception);
            e.SetObserved();
        };
    }

    private static void WriteCrashLog(string message, Exception? ex)
    {
        try
        {
            if (Log.Logger != null)
            {
                Log.Fatal(ex, message);
                return;
            }
        }
        catch
        {
            // Serilog not ready
        }

        try
        {
            var logDir = AppPaths.GetLogsPath();
            var path = Path.Combine(logDir, "crash.log");
            var line = $"{DateTime.UtcNow:O} {message}{Environment.NewLine}{ex}{Environment.NewLine}";
            File.AppendAllText(path, line);
        }
        catch
        {
            // last resort: ignore
        }
    }

    private static void RunWatchdogMode()
    {
        var logDirectory = AppPaths.GetLogsPath();

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.File(
                Path.Combine(logDirectory, "watchdog-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 7,
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
            .CreateLogger();

        try
        {
            var result = AgentProcessLauncher.EnsureRunning("watchdog-cli", CreateWatchdogLogger());
            Log.Information("Watchdog check finished: {Result}", result);
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Watchdog check failed");
        }
        finally
        {
            Log.CloseAndFlush();
        }
    }

    private static void RunGuardianMode()
    {
        var logDirectory = AppPaths.GetLogsPath();

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.File(
                Path.Combine(logDirectory, "guardian-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 7,
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
            .CreateLogger();

        try
        {
            if (!AgentGuardianManager.TryAcquire())
            {
                Log.Debug("Guardian already running, exiting duplicate");
                return;
            }

            // 新登录会话的守护进程：清除上次「主动退出」标记，否则自启动会永久失效
            VoluntaryShutdownMarker.Clear();

            var logger = CreateGuardianLogger();
            if (!AutoStartManager.EnsureEnabled(logger))
                Log.Warning("Auto-start repair failed during guardian startup");

            using var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (_, e) =>
            {
                e.Cancel = true;
                cts.Cancel();
            };

            AgentGuardianManager.RunAsync(logger, cts.Token).GetAwaiter().GetResult();
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Guardian failed");
        }
        finally
        {
            AgentGuardianManager.Release();
            Log.CloseAndFlush();
        }
    }

    private static Microsoft.Extensions.Logging.ILogger CreateGuardianLogger()
        => LoggerFactory.Create(builder => builder.AddSerilog(dispose: false))
            .CreateLogger("Guardian");

    private static Microsoft.Extensions.Logging.ILogger CreateWatchdogLogger()
        => LoggerFactory.Create(builder => builder.AddSerilog(dispose: false))
            .CreateLogger("Watchdog");

    private static async Task MainAsync(string[] args)
    {
        try
        {
            
            var isWindowsService = args.Contains("--service") || Environment.GetEnvironmentVariable("RUNNING_AS_SERVICE") == "1";
            
            var appDataPath = GetAppDataPath();
            var logDirectory = AppPaths.GetLogsPath();

            // 配置 Logger（增强版）
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                .MinimumLevel.Override("System", LogEventLevel.Warning)
                .MinimumLevel.Override("Microsoft.Hosting.Lifetime", LogEventLevel.Information)
                .WriteTo.File(
                    Path.Combine(logDirectory, "agent-.log"),
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 15,
                    fileSizeLimitBytes: 100 * 1024 * 1024,
                    rollOnFileSizeLimit: true,
                    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
                .CreateLogger();

            Log.Information("Starting Enterprise Agent v{Version}", AppConstants.DefaultAgentVersion);
            Log.Information("OS: {OS}", RuntimeInformation.OSDescription);
            Log.Information("App Data Path: {Path}", appDataPath);
            Log.Information("Running as Windows Service: {IsService}", isWindowsService);

            var host = CreateHostBuilder(args, appDataPath).Build();

            if (!isWindowsService)
            {
                var configService = host.Services.GetRequiredService<EncryptedConfigService>();
                var config = host.Services.GetRequiredService<AgentConfig>();
                
                ApplicationConfiguration.Initialize();
                var localization = host.Services.GetRequiredService<ILocalizationService>();
                
                await EnsureEmployeeInfoAsync(configService, config,localization);

                if (!config.IsWsUrlAlignedWithServer())
                {
                    config.SyncWsUrlWithServer();
                    await configService.SaveConfigAsync(ConfigFileName, config);
                    Log.Information("Persisted corrected WebSocket URL: {WsUrl}", config.WsUrl);
                }

                if (AutoStartManager.EnsureEnabled())
                    Log.Information("Auto-start configured for: {Path}", AutoStartManager.GetExecutablePath());
                else
                    Log.Warning("Auto-start setup failed; use tray menu to retry");

                await ValidateStartupAsync(host.Services);

                AgentWatchdogManager.RemoveLegacyWatchdogTask(CreateWatchdogLogger());
                AgentGuardianManager.EnsureRunning(CreateGuardianLogger());
                Log.Information("In-session guardian active (crash recovery, no periodic flash)");

                var webSocketService = host.Services.GetRequiredService<WebSocketService>();
                var workSession = host.Services.GetRequiredService<WorkSessionService>();
                var employeeSession = host.Services.GetRequiredService<EmployeeSessionService>();
                var telegramBind = host.Services.GetRequiredService<TelegramBindService>();
                workSession.SetServerUrlResolver(() => config.ServerUrl);
                employeeSession.SetServerUrlResolver(() => config.ServerUrl);
                telegramBind.SetServerUrlResolver(() => config.ServerUrl);

                async Task<bool> DoEmployeeLoginAsync()
                {
                    using var form = new EmployeeLoginForm(config.ServerUrl, localization);
                    if (form.ShowDialog() != DialogResult.OK) return false;
                    var ok = await employeeSession.LoginAsync(form.Username, form.Password);
                    if (ok)
                    {
                        var who = employeeSession.GetTrayStatus();
                        var welcomeTemplate = localization?.GetString("EmployeeLoginWelcome", "欢迎，{0}") ?? "欢迎，{0}";
                        MessageBox.Show(
                            string.Format(welcomeTemplate, who.DisplayLabel),
                            localization?.GetString("EmployeeLoginTitle", "员工登录") ?? "员工登录",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        return true;
                    }

                    MessageBox.Show(
                        AgentUserMessages.FormatLoginError(localization, employeeSession.LastLoginError),
                        localization?.GetString("LoginFailedTitle", "登录失败") ?? "登录失败",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return false;
                }

                async Task<bool> DoEmployeeLogoutAsync()
                {
                    await employeeSession.LogoutAsync();
                    MessageBox.Show(
                        localization?.GetString("LogoutMessage", "已退出登录，其他员工可使用本机账号登录")
                            ?? "已退出登录，其他员工可使用本机账号登录",
                        localization?.GetString("LogoutTitle", "提示") ?? "提示",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return true;
                }

                async Task<bool> DoCheckInAsync()
                {
                    if (!employeeSession.IsLoggedIn)
                    {
                        await employeeSession.RefreshSessionAsync();
                    }
                    if (!employeeSession.IsLoggedIn)
                    {
                        MessageBox.Show(
                            localization?.GetString("CheckInLoginRequired", "请先使用「员工登录」后再上班")
                                ?? "请先使用「员工登录」后再上班",
                            localization?.GetString("Prompt", "提示") ?? "提示",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        return false;
                    }
                    if (!await workSession.CheckInAsync())
                    {
                        MessageBox.Show(
                            localization?.GetString("CheckInFailed", "上班失败，请确认已登录且网络正常")
                                ?? "上班失败，请确认已登录且网络正常",
                            localization?.GetString("Prompt", "提示") ?? "提示",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        return false;
                    }

                    return true;
                }

                async Task<bool> DoCheckOutAsync()
                {
                    if (!await workSession.CheckOutAsync())
                    {
                        MessageBox.Show(
                            localization?.GetString("CheckOutFailed", "下班失败，请确认网络正常")
                                ?? "下班失败，请确认网络正常",
                            localization?.GetString("Prompt", "提示") ?? "提示",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        return false;
                    }

                    return true;
                }

                var deviceRegistration = host.Services.GetRequiredService<DeviceRegistrationService>();

                async Task<bool> DoBindInviteAsync()
                {
                    return await PromptDeviceBindingAsync(
                        deviceRegistration,
                        employeeSession,
                        configService,
                        config,
                        localization);
                }

                async Task<bool> DoBindTelegramAsync()
                {
                    if (!employeeSession.IsLoggedIn)
                    {
                        await employeeSession.RefreshSessionAsync();
                    }
                    if (!employeeSession.IsLoggedIn)
                    {
                        MessageBox.Show(
                            localization?.GetString("CheckInLoginRequired", "请先使用「员工登录」后再绑定 Telegram")
                                ?? "请先使用「员工登录」后再绑定 Telegram",
                            localization?.GetString("Prompt", "提示") ?? "提示",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        return false;
                    }

                    if (await telegramBind.IsTelegramBoundAsync())
                    {
                        MessageBox.Show(
                            localization?.GetString("TelegramAlreadyBound", "当前员工已绑定 Telegram")
                                ?? "当前员工已绑定 Telegram",
                            localization?.GetString("Prompt", "提示") ?? "提示",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        return true;
                    }

                    var tokenResult = await telegramBind.CreateBindTokenAsync();
                    if (tokenResult == null || string.IsNullOrWhiteSpace(tokenResult.DeepLink))
                    {
                        MessageBox.Show(
                            localization?.GetString("TelegramBindFailed", "获取 Telegram 绑定链接失败，请确认后台已配置 Bot 且网络正常")
                                ?? "获取 Telegram 绑定链接失败，请确认后台已配置 Bot 且网络正常",
                            localization?.GetString("Prompt", "提示") ?? "提示",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        return false;
                    }

                    try
                    {
                        Process.Start(new ProcessStartInfo(tokenResult.DeepLink) { UseShellExecute = true });
                    }
                    catch (Exception ex)
                    {
                        Log.Warning(ex, "Failed to open telegram deep link");
                    }

                    var msg = localization?.GetString(
                            "TelegramBindOpened",
                            "已在浏览器打开 Telegram 绑定链接。\n请在 Telegram 中点击 Start 完成绑定。\n\n备用：私聊 Bot 发送\n/bind 您的邀请码")
                        ?? $"已在浏览器打开 Telegram 绑定链接。\n请在 Telegram 中点击 Start 完成绑定。\n\n链接：{tokenResult.DeepLink}";
                    MessageBox.Show(msg,
                        localization?.GetString("BindTelegram", "绑定 Telegram") ?? "绑定 Telegram",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return true;
                }

                using var trayIcon = new TrayIcon(
                    host.Services.GetRequiredService<ILogger<TrayIcon>>(),
                    () =>
                    {
                        VoluntaryShutdownMarker.Mark();
                        AgentWatchdogManager.DisableWatchdogTask(CreateWatchdogLogger());
                        Log.Information("User voluntary exit: guardian will stop after UI exits");
                        Application.Exit();
                    },
                    () => webSocketService.IsConnected,
                    () => config.DeviceId,
                    () => config.ServerUrl,
                    localization,
                    DoCheckInAsync,
                    DoCheckOutAsync,
                    DoEmployeeLoginAsync,
                    DoEmployeeLogoutAsync,
                    () => employeeSession.GetTrayStatus(),
                    DoBindInviteAsync,
                    DoBindTelegramAsync,
                    () => workSession.HasOpenSession,
                    () => telegramBind.IsTelegramBoundAsync());

                employeeSession.SessionChanged += (_, _) => trayIcon.NotifyEmployeeSessionChanged();

                workSession.SessionSyncChanged += (_, e) =>
                {
                    if (e.SessionStateChanged)
                        trayIcon.NotifyMenuStateChanged();
                    if (e.TelegramCheckInNotified)
                        trayIcon.NotifyTelegramCheckIn();
                    if (e.TelegramCheckOutNotified)
                        trayIcon.NotifyTelegramCheckOut();
                };

                var sessionSyncTimer = new System.Windows.Forms.Timer { Interval = 30_000 };
                sessionSyncTimer.Tick += async (_, _) =>
                {
                    try
                    {
                        await workSession.SyncOpenSessionFromServerAsync();
                    }
                    catch (Exception ex)
                    {
                        Log.Debug(ex, "Periodic work session sync failed");
                    }
                };
                sessionSyncTimer.Start();

                SingleInstanceManager.SetActivateHandler(() => trayIcon.NotifyAlreadyRunning());

                await host.StartAsync();

                trayIcon.RunMessageLoop(async () =>
                {
                    await EnsureDeviceEmployeeBindingAsync(
                        deviceRegistration,
                        employeeSession,
                        configService,
                        config,
                        localization);

                    await workSession.TryRestoreOpenSessionAsync();
                    trayIcon.NotifyMenuStateChanged();

                    _ = Task.Run(async () =>
                    {
                        await Task.Delay(3000);
                        if (employeeSession.IsLoggedIn)
                            return;
                        await employeeSession.RefreshSessionAsync();
                    });
                });
                
                try
                {
                    using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
                    await host.StopAsync(cts.Token);
                    Log.Information("Host stopped cleanly");
                }
                catch (OperationCanceledException)
                {
                    Log.Warning("Host stop timed out after 30s, forcing ffmpeg cleanup");
                    FfmpegProcessCleanup.KillAgentFfmpegProcesses();
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Error stopping host");
                }
                finally
                {
                    FfmpegProcessCleanup.KillAgentFfmpegProcesses();
                    UiPresence.ClearHeartbeat();
                    Log.CloseAndFlush();
                    SingleInstanceManager.Release();
                    Environment.Exit(0);
                }
            }
            else
            {
                await ValidateStartupAsync(host.Services);

                AgentWatchdogManager.RemoveLegacyWatchdogTask(CreateWatchdogLogger());
                AgentGuardianManager.EnsureRunning(CreateGuardianLogger());

                await host.RunAsync();
            }
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Application start failed");
            if (!args.Contains("--service") && Environment.GetEnvironmentVariable("RUNNING_AS_SERVICE") != "1")
            {
                try
                {
                    ApplicationConfiguration.Initialize();
                    MessageBox.Show(
                        BuildStartupErrorMessage(ex),
                        "Enterprise Agent 启动失败",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
                catch
                {
                    // 忽略 UI 初始化失败
                }
            }
            await Task.Delay(3000);
        }
        finally
        {
            await Log.CloseAndFlushAsync();
        }
    }

    private static string BuildStartupErrorMessage(Exception ex)
    {
        var lines = new List<string> { ex.Message, "" };

        if (ex.Message.Contains("deployment.json", StringComparison.OrdinalIgnoreCase) ||
            ex.Message.Contains("AGENT_POLICY_SIGNATURE_SECRET", StringComparison.OrdinalIgnoreCase))
        {
            lines.Add("打包前请编辑配置文件（无需命令行）：");
            lines.Add("");
            lines.Add("  1. 复制 deployment.json.example → deployment.json");
            lines.Add("  2. 用记事本填写 policySignatureSecret（及可选 registrationSecret）");
            lines.Add("  3. dotnet publish 后 deployment.json 与 DHPG.exe 同目录");
            lines.Add("");
            lines.Add("本地 HTTP 调试：allowInsecureTransport 设为 true");
        }
        else if (ex.Message.Contains("https", StringComparison.OrdinalIgnoreCase) ||
                 ex.Message.Contains("wss", StringComparison.OrdinalIgnoreCase))
        {
            lines.Add("生产环境 defaultServerUrl 请使用 https://；");
            lines.Add("本地调试请在 deployment.json 中设置 allowInsecureTransport: true");
        }

        lines.Add("");
        lines.Add($"日志: {AppPaths.GetLogsPath()}");

        return string.Join(Environment.NewLine, lines);
    }

    private static IHostBuilder CreateHostBuilder(string[] args, string appDataPath)
    {
        var isWindowsService = args.Contains("--service") || Environment.GetEnvironmentVariable("RUNNING_AS_SERVICE") == "1";
        var loggerFactory = LoggerFactory.Create(builder => builder.AddSerilog());
        var dpapiScope = isWindowsService
            ? System.Security.Cryptography.DataProtectionScope.LocalMachine
            : System.Security.Cryptography.DataProtectionScope.CurrentUser;
        var dataProtection = new WindowsDataProtection(
            loggerFactory.CreateLogger<WindowsDataProtection>(),
            scope: dpapiScope);
        
        var configDirectory = Path.Combine(appDataPath, "config");
        var legacyConfigPath = Path.Combine(appDataPath, ConfigFileName);
        
        Directory.CreateDirectory(configDirectory);
        
        var configService = new EncryptedConfigService(
            loggerFactory.CreateLogger<EncryptedConfigService>(), 
            dataProtection, 
            configDirectory);
        
        var config = LoadConfigurationAsync(configService, legacyConfigPath, appDataPath).GetAwaiter().GetResult();

        NormalizeAgentConfig(config);

        var dbPath = Path.Combine(appDataPath, DataFolder, "agent.db");

        return Host.CreateDefaultBuilder(args)
            .UseWindowsService(options => options.ServiceName = ServiceName)
            .UseSerilog()
            .ConfigureServices((context, services) =>
            {
                services.Configure<HostOptions>(options =>
                {
                    options.ShutdownTimeout = TimeSpan.FromSeconds(25);
                });

                // ✅ 基础服务
                services.AddSingleton(dataProtection);
                services.AddSingleton<EncryptedConfigService>(configService);
                services.AddSingleton(config);
                services.AddSingleton<ILocalizationService, LocalizationService>();
                
                // ✅ 数据库
                services.AddSingleton(sp => new SqliteDbContext(dbPath, sp.GetRequiredService<ILogger<SqliteDbContext>>()));
                
                // ✅ 安全服务
                services.AddSingleton<DeviceFingerprinter>();
                services.AddSingleton<ISensitiveDataFilter, SensitiveDataFilter>();
                
                // ✅ 【关键】AuthTokenProvider 必须注册为 Singleton
                services.AddSingleton<IAuthTokenProvider, AuthTokenProvider>();
                
                // ✅ API 签名
                services.AddSingleton<ApiSigner>(sp => new ApiSigner(
                    sp.GetRequiredService<AgentConfig>(),
                    sp.GetService<IAuthTokenProvider>(),  // ✅ 传入 Provider（可能为 null）
                    sp.GetRequiredService<ILogger<ApiSigner>>()));
                services.AddSingleton<ISignatureService>(sp => sp.GetRequiredService<ApiSigner>());
                
                // ✅ 仓储
                services.AddRepositories();
                
                // ✅ HTTP 客户端
                services.AddHttpClientWithRetry("AgentClient", $"EnterpriseAgent/{config.AgentVersion}");
                services.AddHttpClient();
                
                // ✅ 弹性服务
                services.AddResilienceServices();
                
                // ✅ 消息总线
                services.AddSingleton<IMessageBus, MessageBus>();
                
                // ✅ 后台服务
                services.AddBackgroundServices();
                
                // ✅ ScreenCapture Logger
                services.AddSingleton(sp => sp.GetRequiredService<ILoggerFactory>().CreateLogger<ScreenCapture>());
                
                // ✅ 远程查看 + 采集架构（LiveKit / Capture / Health monitors）
                services.AddRemoteViewService(context.Configuration);
                
                // ✅ 其他后台服务
                services.AddHostedService<ActivityRealTimeReporter>();
                services.AddHostedService<MemoryManagementService>();
                services.AddHostedService<LogCleanupService>();
                
                // ✅ 健康检查
                if (config.Observability?.HealthPort > 0)
                {
                    services.AddHealthChecks()
                        .AddCheck<DatabaseHealthCheck>("database")
                        .AddCheck<RemoteViewHealthCheck>("remote_view")
                        .AddCheck<CaptureLifecycleHealthCheck>("capture_lifecycle");
                }
            });
    }
    private static void NormalizeAgentConfig(AgentConfig config)
    {
        ArgumentNullException.ThrowIfNull(config);

        config.Storage ??= new StorageConfig();
        if (string.IsNullOrWhiteSpace(config.Storage.Path))
            config.Storage.Path = config.GetEffectiveStoragePath();

        if (config.Storage.MaxSizeGB <= 0)
            config.Storage.MaxSizeGB = AppConstants.DefaultMaxStorageGB;

        config.AgentVersion = AppConstants.DefaultAgentVersion;

        config.Auth ??= new AuthConfig();
        config.Policy ??= new PolicyConfig();
        config.Observability ??= new ObservabilityConfig();
        config.Resilience ??= new ResilienceConfig();

        if (!string.IsNullOrWhiteSpace(config.ServerUrl)
            && !config.IsWsUrlAlignedWithServer())
        {
            config.SyncWsUrlWithServer();
            Log.Information("WebSocket URL synced with ServerUrl: {WsUrl}", config.WsUrl);
        }
        else if (string.IsNullOrWhiteSpace(config.WsUrl) && !string.IsNullOrWhiteSpace(config.ServerUrl))
        {
            config.WsUrl = config.GetEffectiveWsUrl();
            Log.Information("Auto-configured WebSocket URL: {WsUrl}", config.WsUrl);
        }
    }

    private static void ValidateAgentConfig(AgentConfig config)
    {
        ArgumentNullException.ThrowIfNull(config);

        if (string.IsNullOrWhiteSpace(config.ServerUrl))
        {
            throw new InvalidOperationException(
                "ServerUrl is not configured. Set it during installation or in the startup form.");
        }

        if (string.IsNullOrWhiteSpace(config.WsUrl))
        {
            config.WsUrl = config.GetEffectiveWsUrl();
            Log.Information("Auto-configured WebSocket URL: {WsUrl}", config.WsUrl);
        }
        else if (!config.IsWsUrlAlignedWithServer())
        {
            config.SyncWsUrlWithServer();
            Log.Information("WebSocket URL re-aligned with ServerUrl: {WsUrl}", config.WsUrl);
        }

        config.Storage ??= new StorageConfig();
        if (string.IsNullOrWhiteSpace(config.Storage.Path))
            config.Storage.Path = config.GetEffectiveStoragePath();

        if (config.Storage.MaxSizeGB <= 0)
            config.Storage.MaxSizeGB = AppConstants.DefaultMaxStorageGB;

        config.AgentVersion = AppConstants.DefaultAgentVersion;

        config.Auth ??= new AuthConfig();
        config.Policy ??= new PolicyConfig();
        config.Observability ??= new ObservabilityConfig();
        config.Resilience ??= new ResilienceConfig();

        EnsurePolicySignatureSecret(config);

        var (isValid, errors) = config.Validate();
        if (!isValid)
        {
            throw new InvalidOperationException(
                "Agent configuration validation failed: " + string.Join("; ", errors));
        }

        try
        {
            var storagePath = config.Storage.Path;
            Directory.CreateDirectory(storagePath);
            var testFile = Path.Combine(storagePath, ".write_test");
            File.WriteAllText(testFile, "test");
            File.Delete(testFile);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Storage path is not writable: {Path}", config.Storage.Path);
            throw;
        }
    }

    private static void ApplyDeploymentSecrets(AgentConfig config)
    {
        var bundle = DeploymentConfigLoader.TryLoad();

        var needsPolicy = string.IsNullOrWhiteSpace(config.Auth?.PolicySignatureSecret)
            && string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET"));

        if (needsPolicy)
        {
            var (valid, errors) = DeploymentConfigLoader.Validate(bundle);
            if (!valid)
            {
                var path = DeploymentConfigLoader.GetExpectedPath();
                throw new InvalidOperationException(
                    $"deployment.json 配置无效（{path}）：{string.Join("; ", errors)}");
            }
        }

        DeploymentConfigLoader.ApplyTo(config, bundle);

        if (bundle != null)
            Log.Information("Deployment secrets applied from {Path}", DeploymentConfigLoader.GetExpectedPath());
    }

    private static void EnsurePolicySignatureSecret(AgentConfig config)
    {
        if (config.Auth == null)
            return;

        if (!string.IsNullOrWhiteSpace(config.Auth.PolicySignatureSecret))
            return;

        var policySecret = Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET");
        if (!string.IsNullOrWhiteSpace(policySecret))
        {
            config.Auth.PolicySignatureSecret = policySecret;
            return;
        }

        throw new InvalidOperationException(
            "PolicySignatureSecret is required. Place policySignatureSecret in deployment.json next to the exe, or set AGENT_POLICY_SIGNATURE_SECRET.");
    }

    private static async Task ValidateStartupAsync(IServiceProvider services)
    {
        var config = services.GetRequiredService<AgentConfig>();
        ValidateAgentConfig(config);
        await services.ValidateServicesAsync();
        Log.Information("Startup validation completed");
    }

    private static async Task<AgentConfig> LoadConfigurationAsync(
        EncryptedConfigService configService, 
        string legacyConfigPath,
        string appDataPath)
    {
        var config = await configService.LoadConfigAsync<AgentConfig>(ConfigFileName);
        if (config != null)
        {
            Log.Information("Encrypted configuration loaded successfully");
            
            // 策略签名密钥
            if (config.Auth != null && string.IsNullOrEmpty(config.Auth.PolicySignatureSecret))
            {
                var policySecret = Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET");
                if (!string.IsNullOrWhiteSpace(policySecret))
                {
                    config.Auth.PolicySignatureSecret = policySecret;
                    await configService.SaveConfigAsync(ConfigFileName, config);
                    Log.Information("PolicySignatureSecret loaded from AGENT_POLICY_SIGNATURE_SECRET");
                }
            }
            
            return ApplyDeploymentSecretsToConfig(config);
        }

        if (File.Exists(legacyConfigPath))
        {
            try
            {
                var json = await File.ReadAllTextAsync(legacyConfigPath);
                var legacyConfig = JsonSerializer.Deserialize<AgentConfig>(json);
                if (legacyConfig != null)
                {
                    Log.Information("Migrating legacy configuration to encrypted format");
                    
                    if (legacyConfig.Auth != null && string.IsNullOrEmpty(legacyConfig.Auth.PolicySignatureSecret))
                    {
                        var policySecret = Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET");
                        if (!string.IsNullOrWhiteSpace(policySecret))
                            legacyConfig.Auth.PolicySignatureSecret = policySecret;
                    }
                    
                    try
                    {
                        await configService.SaveConfigAsync(ConfigFileName, legacyConfig);
                        var backupPath = legacyConfigPath + ".bak";
                        if (File.Exists(backupPath))
                            File.Delete(backupPath);
                        File.Move(legacyConfigPath, backupPath);
                        Log.Information("Legacy configuration migrated and backed up");
                    }
                    catch (Exception saveEx)
                    {
                        Log.Error(saveEx, "Failed to save migrated config, continuing with legacy config");
                    }
                    return ApplyDeploymentSecretsToConfig(legacyConfig);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Failed to load legacy configuration");
            }
        }

        Log.Warning("Configuration file not found, creating default configuration");
        var defaultConfig = CreateDefaultConfig(appDataPath);
        
        try
        {
            await configService.SaveConfigAsync(ConfigFileName, defaultConfig);
            Log.Information("Default configuration created and saved");
        }
        catch (Exception saveEx)
        {
            Log.Error(saveEx, "Failed to save default config, but continuing with in-memory config");
        }
        
        return ApplyDeploymentSecretsToConfig(defaultConfig);
    }

    private static AgentConfig ApplyDeploymentSecretsToConfig(AgentConfig config)
    {
        ApplyDeploymentSecrets(config);
        return config;
    }

    private static AgentConfig CreateDefaultConfig(string appDataPath)
    {
        var storagePath = Path.Combine(appDataPath, DataFolder);

        return new AgentConfig
        {
            ConfigVersion = 2,
            ServerUrl = "",
            WsUrl = "",
            DeviceId = "",
            AgentVersion = AppConstants.DefaultAgentVersion,

            Auth = new AuthConfig
            {
                PolicySignatureSecret = Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET") ?? "",
                RegistrationSecret = Environment.GetEnvironmentVariable("AGENT_REGISTRATION_SECRET") ?? "",
            },

            Employee = new EmployeeInfo(),

            Policy = new PolicyConfig
            {
                SyncIntervalSeconds = 300,
                LocalCache = true
            },

            Storage = new StorageConfig
            {
                Path = storagePath,
                MaxSizeGB = AppConstants.DefaultMaxStorageGB
            },

            Logging = new LoggingConfig
            {
                Level = AppConstants.DefaultLogLevel,
                MaxSizeMB = AppConstants.DefaultLogMaxSizeMB,
                MaxFiles = AppConstants.DefaultLogMaxFiles
            },

            Observability = new ObservabilityConfig
            {
                EnableMetrics = false,
                EnableStructuredLogging = true,
                MetricsPort = 0,
                HealthPort = 0
            },

            Resilience = new ResilienceConfig
            {
                EnableCircuitBreaker = true,
                EnableIdempotency = true
            }
        };
    }

    private static string GetAppDataPath()
    {
        var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), AppDataFolder);
        
        Directory.CreateDirectory(path);
        Directory.CreateDirectory(Path.Combine(path, LogsFolder));
        Directory.CreateDirectory(Path.Combine(path, DataFolder));
        Directory.CreateDirectory(Path.Combine(path, "config"));
        
        return path;
    }

    private static PendingFirstLogin? _pendingFirstLogin;

    /// <summary>
    /// WinForms 对话框必须在消息循环内显示，否则部分环境下会出现无法输入的问题。
    /// </summary>
    private static void RunWithWinFormsMessageLoop(Action action)
    {
        if (Application.MessageLoop)
        {
            action();
            return;
        }

        using var pump = new Form
        {
            WindowState = FormWindowState.Minimized,
            ShowInTaskbar = false,
            Opacity = 0,
            FormBorderStyle = FormBorderStyle.FixedToolWindow,
            Size = new Size(0, 0)
        };
        pump.Load += (_, _) =>
        {
            try
            {
                action();
            }
            finally
            {
                pump.Close();
            }
        };
        Application.Run(pump);
    }

    private static void ClearPendingFirstLogin()
    {
        _pendingFirstLogin?.Clear();
        _pendingFirstLogin = null;
    }

    private sealed class PendingFirstLogin
    {
        public required string Username { get; init; }
        private char[]? _passwordChars;

        public static PendingFirstLogin Create(string username, string password)
        {
            return new PendingFirstLogin
            {
                Username = username,
                _passwordChars = password.ToCharArray()
            };
        }

        public string GetPassword()
            => _passwordChars == null ? string.Empty : new string(_passwordChars);

        public void Clear()
        {
            if (_passwordChars == null)
                return;

            Array.Clear(_passwordChars, 0, _passwordChars.Length);
            _passwordChars = null;
        }
    }

    private static async Task EnsureEmployeeInfoAsync(
        EncryptedConfigService configService,
        AgentConfig config,
        ILocalizationService? localization = null)
    {
        if (config.Employee?.PreferSharedLogin == true)
            return;

        if (config.Employee?.FirstLoginCompleted == true
            && !string.IsNullOrWhiteSpace(config.ServerUrl))
        {
            Log.Information("First login already completed for {ServerUrl}", config.ServerUrl);
            return;
        }

        if (config.Employee?.PreferSharedLogin != true
            && !string.IsNullOrWhiteSpace(config.Employee?.InviteCode)
            && !string.IsNullOrWhiteSpace(config.ServerUrl))
        {
            Log.Information(
                "First login pending with saved invite; will bind and login after service start");
            return;
        }

        Log.Information("Showing first login setup form...");

        var deploymentBundle = DeploymentConfigLoader.TryLoad();
        var lockedServerUrl = DeploymentConfigLoader.TryGetLockedServerUrl(deploymentBundle);

        EmployeeSetupForm? setupForm = null;
        DialogResult dialogResult = DialogResult.Cancel;

        RunWithWinFormsMessageLoop(() =>
        {
            setupForm = new EmployeeSetupForm(
                null,
                localization,
                serverUrl: lockedServerUrl ?? config.ServerUrl,
                lockedServerUrl: lockedServerUrl,
                mode: EmployeeSetupFormMode.FirstLogin)
            {
                StartPosition = FormStartPosition.CenterScreen,
                TopMost = true
            };
            dialogResult = setupForm.ShowDialog();
        });

        using (setupForm)
        {
            if (dialogResult != DialogResult.OK || setupForm == null)
            {
                Log.Error("First login setup cancelled by user");
                throw new InvalidOperationException("Agent configuration is required to start.");
            }

            config.Employee ??= new EmployeeInfo();
            if (setupForm.UseSharedWorkstation)
            {
                config.Employee.PreferSharedLogin = true;
                config.Employee.InviteCode = "";
                config.Employee.FirstLoginCompleted = true;
                ClearPendingFirstLogin();
            }
            else
            {
                config.Employee.PreferSharedLogin = false;
                config.Employee.InviteCode = setupForm.InviteCode;
                config.Employee.FirstLoginCompleted = false;
                ClearPendingFirstLogin();
                _pendingFirstLogin = PendingFirstLogin.Create(setupForm.Username, setupForm.Password);
            }

            ApplyDeploymentSecrets(config);
            if (lockedServerUrl == null)
                config.ServerUrl = setupForm.ServerUrl;
            else
                config.ServerUrl = lockedServerUrl;
            config.WsUrl = config.GetEffectiveWsUrl();
            await configService.SaveConfigAsync(ConfigFileName, config);
            Log.Information("First login setup saved: ServerUrl={ServerUrl}, Shared={Shared}",
                config.ServerUrl, config.Employee.PreferSharedLogin);
        }

        if (AutoStartManager.EnsureEnabled())
            Log.Information("Auto-start enabled after initial setup");
    }

    private static async Task EnsureDeviceEmployeeBindingAsync(
        DeviceRegistrationService deviceRegistration,
        EmployeeSessionService employeeSession,
        EncryptedConfigService configService,
        AgentConfig config,
        ILocalizationService? localization)
    {
        if (config.Employee?.PreferSharedLogin == true)
        {
            Log.Information("Shared workstation mode: employee not logged in, use tray login");
            return;
        }

        if (config.Employee?.FirstLoginCompleted == true)
        {
            await employeeSession.RefreshSessionAsync().ConfigureAwait(true);
            if (employeeSession.IsLoggedIn)
                return;
        }

        await CompleteFirstLoginAsync(
            deviceRegistration,
            employeeSession,
            configService,
            config,
            localization).ConfigureAwait(true);

        if (config.Employee?.FirstLoginCompleted == true)
            return;

        Log.Information("First login incomplete; opening setup form again");
        await PromptFirstLoginRetryAsync(deviceRegistration, employeeSession, configService, config, localization)
            .ConfigureAwait(true);
    }

    private static async Task<bool> CompleteFirstLoginAsync(
        DeviceRegistrationService deviceRegistration,
        EmployeeSessionService employeeSession,
        EncryptedConfigService configService,
        AgentConfig config,
        ILocalizationService? localization)
    {
        if (config.Employee?.PreferSharedLogin == true)
            return true;

        if (config.Employee?.FirstLoginCompleted == true)
        {
            if (!employeeSession.IsLoggedIn)
                await employeeSession.RefreshSessionAsync().ConfigureAwait(true);
            return employeeSession.IsLoggedIn;
        }

        var pending = _pendingFirstLogin;
        if (pending == null)
        {
            Log.Warning("First login credentials not in memory; user must re-enter account/password");
            return false;
        }

        var inviteCode = config.Employee?.InviteCode;
        if (string.IsNullOrWhiteSpace(inviteCode))
            return false;

        Log.Information("Waiting for device registration before employee login...");

        if (!await EnsureDeviceRegisteredForFirstLoginAsync(deviceRegistration, inviteCode, localization)
                .ConfigureAwait(true))
        {
            return false;
        }

        Log.Information("Device registered; performing employee login");

        if (employeeSession.IsLoggedIn)
        {
            await FinalizeFirstLoginAsync(employeeSession, configService, config, localization)
                .ConfigureAwait(true);
            return true;
        }

        var loggedIn = await employeeSession.LoginAsync(pending.Username, pending.GetPassword()).ConfigureAwait(true);
        ClearPendingFirstLogin();
        if (loggedIn)
        {
            await employeeSession.RefreshSessionAsync().ConfigureAwait(true);
            await FinalizeFirstLoginAsync(employeeSession, configService, config, localization)
                .ConfigureAwait(true);
            return true;
        }

        MessageBox.Show(
            AgentUserMessages.FormatLoginError(localization, employeeSession.LastLoginError),
            localization?.GetString("LoginFailedTitle", "登录失败") ?? "登录失败",
            MessageBoxButtons.OK,
            MessageBoxIcon.Warning);
        return false;
    }

    private static async Task<bool> EnsureDeviceRegisteredForFirstLoginAsync(
        DeviceRegistrationService deviceRegistration,
        string inviteCode,
        ILocalizationService? localization)
    {
        if (deviceRegistration.LastRegistrationInvalidInvite)
        {
            ShowBindFailedMessage(localization);
            ClearPendingFirstLogin();
            return false;
        }

        var status = deviceRegistration.GetRegistrationStatus();
        if (!status.IsRegistered || !status.HasToken)
        {
            if (!await deviceRegistration.WaitForApprovedRegistrationAsync(45).ConfigureAwait(true))
            {
                if (deviceRegistration.LastRegistrationInvalidInvite)
                {
                    ShowBindFailedMessage(localization);
                    ClearPendingFirstLogin();
                    return false;
                }

                var bindResult = await deviceRegistration.BindWithInviteCodeAsync(inviteCode)
                    .ConfigureAwait(true);
                if (bindResult == InviteBindResult.InvalidInvite)
                {
                    ShowBindFailedMessage(localization);
                    ClearPendingFirstLogin();
                    return false;
                }

                if (bindResult != InviteBindResult.Success)
                {
                    MessageBox.Show(
                        localization?.GetString("BindPendingMessage", "设备注册或审核尚未完成，请稍后重试。")
                            ?? "设备注册或审核尚未完成，请稍后重试。",
                        localization?.GetString("BindPendingTitle", "绑定待确认") ?? "绑定待确认",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    ClearPendingFirstLogin();
                    return false;
                }
            }
        }

        return deviceRegistration.GetRegistrationStatus().HasToken;
    }

    private static void ShowBindFailedMessage(ILocalizationService? localization)
    {
        MessageBox.Show(
            AgentUserMessages.FormatInvalidInviteError(localization),
            localization?.GetString("BindFailedTitle", "绑定失败") ?? "绑定失败",
            MessageBoxButtons.OK,
            MessageBoxIcon.Warning);
    }

    private static async Task FinalizeFirstLoginAsync(
        EmployeeSessionService employeeSession,
        EncryptedConfigService configService,
        AgentConfig config,
        ILocalizationService? localization)
    {
        config.Employee ??= new EmployeeInfo();
        config.Employee.FirstLoginCompleted = true;
        ClearPendingFirstLogin();
        await configService.SaveConfigAsync(ConfigFileName, config).ConfigureAwait(true);

        var who = employeeSession.GetTrayStatus();
        var welcomeTemplate = localization?.GetString("LoginWelcomeMessage", "欢迎，{0}") ?? "欢迎，{0}";
        MessageBox.Show(
            string.Format(welcomeTemplate, who.DisplayLabel),
            localization?.GetString("LoginSuccessTitle", "登录成功") ?? "登录成功",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
    }

    private static async Task PromptFirstLoginRetryAsync(
        DeviceRegistrationService deviceRegistration,
        EmployeeSessionService employeeSession,
        EncryptedConfigService configService,
        AgentConfig config,
        ILocalizationService? localization)
    {
        using var form = new EmployeeSetupForm(
            null,
            localization,
            serverUrl: config.ServerUrl,
            lockedServerUrl: config.ServerUrl,
            mode: EmployeeSetupFormMode.FirstLogin);
        form.TopMost = true;
        form.StartPosition = FormStartPosition.CenterScreen;
        if (form.ShowDialog() != DialogResult.OK)
        {
            Log.Warning("First login retry cancelled by user");
            return;
        }

        if (form.UseSharedWorkstation)
        {
            config.Employee ??= new EmployeeInfo();
            config.Employee.PreferSharedLogin = true;
            config.Employee.InviteCode = "";
            config.Employee.FirstLoginCompleted = true;
            ClearPendingFirstLogin();
            await configService.SaveConfigAsync(ConfigFileName, config).ConfigureAwait(true);
            return;
        }

        config.Employee ??= new EmployeeInfo();
        config.Employee.PreferSharedLogin = false;
        config.Employee.InviteCode = form.InviteCode;
        config.Employee.FirstLoginCompleted = false;
        ClearPendingFirstLogin();
        _pendingFirstLogin = PendingFirstLogin.Create(form.Username, form.Password);
        await configService.SaveConfigAsync(ConfigFileName, config).ConfigureAwait(true);
        if (!await CompleteFirstLoginAsync(deviceRegistration, employeeSession, configService, config, localization)
                .ConfigureAwait(true))
        {
            Log.Warning("First login retry did not complete");
        }
    }

    /// <summary>
    /// 检测设备是否已关联员工（邀请码绑定），不要求账号密码登录。
    /// </summary>
    private static async Task<bool> TryDetectDeviceBoundAsync(EmployeeSessionService employeeSession)
    {
        for (var attempt = 0; attempt < 5; attempt++)
        {
            if (await employeeSession.IsDeviceBoundAsync().ConfigureAwait(true))
                return true;

            if (attempt < 4)
                await Task.Delay(TimeSpan.FromSeconds(1)).ConfigureAwait(true);
        }

        return false;
    }

    private static async Task<bool> PromptDeviceBindingAsync(
        DeviceRegistrationService deviceRegistration,
        EmployeeSessionService employeeSession,
        EncryptedConfigService configService,
        AgentConfig config,
        ILocalizationService? localization)
    {
        using var form = new EmployeeSetupForm(
            null,
            localization,
            serverUrl: config.ServerUrl,
            lockedServerUrl: config.ServerUrl,
            mode: EmployeeSetupFormMode.InviteBinding);
        form.TopMost = true;
        form.StartPosition = FormStartPosition.CenterScreen;
        if (form.ShowDialog() != DialogResult.OK)
        {
            Log.Warning("Device binding dialog cancelled by user");
            return false;
        }

        if (form.UseSharedWorkstation)
        {
            config.Employee ??= new EmployeeInfo();
            config.Employee.PreferSharedLogin = true;
            config.Employee.InviteCode = "";
            await configService.SaveConfigAsync(ConfigFileName, config);
            Log.Information("User chose shared workstation mode");
            return true;
        }

        var bindResult = await deviceRegistration.BindWithInviteCodeAsync(form.InviteCode).ConfigureAwait(true);
        if (bindResult == InviteBindResult.InvalidInvite)
        {
            ShowBindFailedMessage(localization);
            return false;
        }

        if (bindResult != InviteBindResult.Success)
        {
            MessageBox.Show(
                localization?.GetString("BindPendingMessage", "绑定请求已发送，但暂未从服务器确认员工信息。请稍后重启客户端，或通过托盘「绑定邀请码」重试。")
                    ?? "绑定请求已发送，但暂未从服务器确认员工信息。请稍后重启客户端，或通过托盘「绑定邀请码」重试。",
                localization?.GetString("BindPendingTitle", "绑定待确认") ?? "绑定待确认",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return false;
        }

        config.Employee ??= new EmployeeInfo();
        config.Employee.InviteCode = form.InviteCode;
        config.Employee.PreferSharedLogin = false;
        await configService.SaveConfigAsync(ConfigFileName, config);
        if (await TryDetectDeviceBoundAsync(employeeSession).ConfigureAwait(true))
        {
            MessageBox.Show(
                localization?.GetString("BindSuccessMessage", "设备已绑定员工。\n请使用「员工登录」后再上班。")
                    ?? "设备已绑定员工。\n请使用「员工登录」后再上班。",
                localization?.GetString("BindSuccessTitle", "绑定成功") ?? "绑定成功",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return true;
        }

        MessageBox.Show(
            localization?.GetString("BindPendingMessage", "绑定请求已发送，但暂未从服务器确认员工信息。请稍后重启客户端，或通过托盘「绑定邀请码」重试。")
                ?? "绑定请求已发送，但暂未从服务器确认员工信息。请稍后重启客户端，或通过托盘「绑定邀请码」重试。",
            localization?.GetString("BindPendingTitle", "绑定待确认") ?? "绑定待确认",
            MessageBoxButtons.OK,
            MessageBoxIcon.Warning);
        return true;
    }
}
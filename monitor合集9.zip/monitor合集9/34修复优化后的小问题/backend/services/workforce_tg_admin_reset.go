package services

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
)

type EmployeeDailyResetResult struct {
	BusinessDate            string `json:"businessDate"`
	ClosedActivities        int    `json:"closedActivities"`
	DeletedWorkSessions     int    `json:"deletedWorkSessions"`
	DeletedActivitySessions int    `json:"deletedActivitySessions"`
	ClearedShiftState       int    `json:"clearedShiftState"`
	AgentNotified           bool   `json:"agentNotified"`
}

func (s *WorkforceTelegramService) ResetEmployeeDailyAttendance(ctx context.Context, employeeID uuid.UUID, chatID string) (*EmployeeDailyResetResult, error) {
	if employeeID == uuid.Nil {
		return nil, fmt.Errorf("employeeId required")
	}
	now := time.Now()
	businessDate := now.Format("2006-01-02")
	if strings.TrimSpace(chatID) != "" {
		if period, err := s.DetermineCurrentPeriod(ctx, chatID, now); err == nil && period != nil {
			businessDate = period.BusinessDate
		}
	}
	out := &EmployeeDailyResetResult{BusinessDate: businessDate}

	openRows, err := s.db.QueryContext(ctx, `
		SELECT id FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND status = 'open'`, employeeID)
	if err == nil {
		defer openRows.Close()
		for openRows.Next() {
			var sid uuid.UUID
			if openRows.Scan(&sid) != nil {
				continue
			}
			if _, err := s.closeActivitySession(ctx, sid, false); err == nil {
				out.ClosedActivities++
			}
		}
	}

	actRes, err := s.db.ExecContext(ctx, `
		DELETE FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND attendance_date = $2::date`,
		employeeID, businessDate)
	if err != nil {
		return nil, err
	}
	if n, _ := actRes.RowsAffected(); n > 0 {
		out.DeletedActivitySessions = int(n)
	}

	var openSessionID uuid.UUID
	if err := s.db.QueryRowContext(ctx, `
		SELECT id FROM work_sessions
		WHERE employee_id = $1 AND status = 'open'
		ORDER BY checkin_time DESC LIMIT 1`, employeeID).Scan(&openSessionID); err == nil && openSessionID != uuid.Nil {
		s.SyncAgentCaptureStop(ctx, employeeID, openSessionID)
		s.SyncAgentTelegramCheckOutNotify(ctx, employeeID, openSessionID)
		out.AgentNotified = true
	}

	res, err := s.db.ExecContext(ctx, `
		DELETE FROM work_sessions WHERE employee_id = $1 AND attendance_date = $2::date`,
		employeeID, businessDate)
	if err != nil {
		return nil, err
	}
	if n, _ := res.RowsAffected(); n > 0 {
		out.DeletedWorkSessions = int(n)
	}

	yearMonth := businessDate
	if len(businessDate) >= 7 {
		yearMonth = businessDate[:7]
	}
	_, _ = s.db.ExecContext(ctx, `
		UPDATE attendance_records SET
			checkin_time = NULL, checkout_time = NULL,
			checkin_source = NULL, checkout_source = NULL,
			status = CASE WHEN manually_edited THEN status ELSE 'absent' END,
			updated_at = NOW()
		WHERE employee_id = $1 AND year_month = $2 AND date = $3::date AND manually_edited = FALSE`,
		employeeID, yearMonth, businessDate)

	res2, _ := s.db.ExecContext(ctx, `
		DELETE FROM wf_tg_group_shift_state WHERE employee_id = $1 AND record_date = $2::date`,
		employeeID, businessDate)
	if n, _ := res2.RowsAffected(); n > 0 {
		out.ClearedShiftState = int(n)
	}

	return out, nil
}

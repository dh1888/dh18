package services

import (
	"context"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
)

func telegramShiftStateMaxHours() int {
	if v := strings.TrimSpace(os.Getenv("TELEGRAM_SHIFT_STATE_MAX_HOURS")); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			return n
		}
	}
	return 24
}

func tgExportChatFilter(chatID string) (string, string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return "", ""
	}
	return ` AND EXISTS (
			SELECT 1 FROM employee_telegram_bindings b
			WHERE b.employee_id = ws.employee_id AND b.status = 1 AND b.chat_id = $3
		)`, chatID
}

func tgExportActivityChatFilter(chatID string) (string, string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return "", ""
	}
	return ` AND COALESCE(s.source_chat_id,'') = $3`, chatID
}

func tgExportHandoverChatFilter(chatID string) (string, string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return "", ""
	}
	return ` AND COALESCE(chat_id,'') = $3`, chatID
}

func exportFilenameSuffix(chatID, dateFrom, dateTo string) string {
	if strings.TrimSpace(chatID) == "" {
		return fmt.Sprintf("telegram_attendance_%s_%s", dateFrom, dateTo)
	}
	return fmt.Sprintf("telegram_attendance_%s_%s_%s", chatID, dateFrom, dateTo)
}

func (s *WorkforceTelegramService) resetAutoCheckoutTime(ctx context.Context, settings *TelegramSettings, chatID, exportDate, shift string) time.Time {
	loc := tgLoadLocation(settings.Timezone)
	parsed, err := time.ParseInLocation("2006-01-02", exportDate, loc)
	if err != nil {
		return time.Now().In(loc)
	}
	if shift == "night" {
		startH, startM, ok := parseClock(settings.DayStart)
		if !ok {
			startH, startM = 9, 0
		}
		return time.Date(parsed.Year(), parsed.Month(), parsed.Day()+1, startH, startM, 0, 0, loc)
	}
	resetTime := settings.DailyResetTime
	if t := s.GetGroupDailyResetTime(ctx, chatID); strings.TrimSpace(t) != "" {
		resetTime = t
	}
	resetH, resetM, ok := parseClock(resetTime)
	if !ok {
		resetH, resetM = 0, 0
	}
	return time.Date(parsed.Year(), parsed.Month(), parsed.Day(), resetH, resetM, 0, 0, loc).Add(telegramResetExecutionDelay)
}

func (s *WorkforceTelegramService) completeMissingWorkEndsForGroup(ctx context.Context, chatID, exportDate string) (int, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return 0, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return 0, err
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT ws.id, ws.employee_id, COALESCE(ws.shift_type,'day'), ws.attendance_date::text
		FROM work_sessions ws
		JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source = 'telegram' AND ws.status = 'open' AND b.chat_id = $1
		  AND ws.attendance_date <= $2::date`, chatID, exportDate)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	closed := 0
	for rows.Next() {
		var sid, empID uuid.UUID
		var shift, recordDate string
		if rows.Scan(&sid, &empID, &shift, &recordDate) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		checkoutAt := s.resetAutoCheckoutTime(ctx, settings, chatID, exportDate, shift)
		if recordDate != exportDate {
			checkoutAt = s.resetAutoCheckoutTime(ctx, settings, chatID, recordDate, shift)
		}
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, checkoutAt, "日重置补全下班"); err != nil {
			log.Printf("[Telegram] complete work end session=%s: %v", sid, err)
			continue
		}
		closed++
	}
	return closed, nil
}

func (s *WorkforceTelegramService) completeMissingAgentWorkEndsForGroup(ctx context.Context, chatID, exportDate string) (int, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return 0, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return 0, err
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT ws.id, ws.employee_id, COALESCE(ws.shift_type,'day'), ws.attendance_date::text
		FROM work_sessions ws
		JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source = 'agent' AND ws.status = 'open' AND b.chat_id = $1
		  AND ws.attendance_date <= $2::date`, chatID, exportDate)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	closed := 0
	for rows.Next() {
		var sid, empID uuid.UUID
		var shift, recordDate string
		if rows.Scan(&sid, &empID, &shift, &recordDate) != nil {
			continue
		}
		checkoutAt := s.resetAutoCheckoutTime(ctx, settings, chatID, exportDate, shift)
		if recordDate != exportDate {
			checkoutAt = s.resetAutoCheckoutTime(ctx, settings, chatID, recordDate, shift)
		}
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, checkoutAt, "日重置补全PC下班"); err != nil {
			log.Printf("[Telegram] complete agent work end session=%s: %v", sid, err)
			continue
		}
		closed++
	}
	return closed, nil
}

func (s *WorkforceTelegramService) collectGroupBindingWarnings(ctx context.Context, chatID, exportDate string) []string {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return nil
	}
	warnings := make([]string, 0)

	rows, err := s.db.QueryContext(ctx, `
		SELECT e.name
		FROM employee_telegram_bindings b
		JOIN employees e ON e.id = b.employee_id
		WHERE b.status = 1 AND COALESCE(NULLIF(TRIM(b.chat_id), ''), '') = ''
		ORDER BY e.name`)
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var name string
			if rows.Scan(&name) == nil && strings.TrimSpace(name) != "" {
				warnings = append(warnings, fmt.Sprintf("员工 %s 未设置打卡群 chat_id", name))
			}
		}
	}

	rows2, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT e.name
		FROM wf_tg_activity_sessions s
		JOIN employees e ON e.id = s.employee_id
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = s.employee_id AND b.status = 1
		WHERE s.attendance_date = $2::date
		  AND COALESCE(s.source_chat_id,'') = $1
		  AND (b.id IS NULL OR COALESCE(NULLIF(TRIM(b.chat_id), ''), '') != $1)
		ORDER BY e.name`, chatID, exportDate)
	if err == nil {
		defer rows2.Close()
		for rows2.Next() {
			var name string
			if rows2.Scan(&name) == nil && strings.TrimSpace(name) != "" {
				warnings = append(warnings, fmt.Sprintf("员工 %s 活动群与绑定 chat_id 不一致", name))
			}
		}
	}

	rows3, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT e.name
		FROM work_sessions ws
		JOIN employees e ON e.id = ws.employee_id
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.attendance_date = $2::date
		  AND ws.source IN ('telegram','agent')
		  AND EXISTS (
			SELECT 1 FROM employee_telegram_bindings bx
			WHERE bx.employee_id = ws.employee_id AND bx.status = 1 AND bx.chat_id = $1
		  )
		  AND (b.id IS NULL OR COALESCE(NULLIF(TRIM(b.chat_id), ''), '') != $1)
		ORDER BY e.name`, chatID, exportDate)
	if err == nil {
		defer rows3.Close()
		for rows3.Next() {
			var name string
			if rows3.Scan(&name) == nil && strings.TrimSpace(name) != "" {
				warnings = append(warnings, fmt.Sprintf("员工 %s 绑定群与导出群不匹配", name))
			}
		}
	}

	if len(warnings) > 12 {
		extra := len(warnings) - 12
		warnings = append(warnings[:12], fmt.Sprintf("…另有 %d 条绑定告警", extra))
	}
	return warnings
}

func (s *WorkforceTelegramService) resolveGroupResetExportDate(
	ctx context.Context,
	settings *TelegramSettings,
	chatID string,
	now time.Time,
	runOpts *DailyResetRunOptions,
) (exportDate, note string) {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	if runOpts != nil && runOpts.ExportBusinessToday {
		if period, err := s.DetermineCurrentPeriod(ctx, chatID, now); err == nil && period != nil && strings.TrimSpace(period.BusinessDate) != "" {
			return period.BusinessDate, "手动重置：导出当前业务日"
		}
		return now.Format("2006-01-02"), "手动重置：导出今日（日历日）"
	}
	exportDate = s.resetExportDateForChat(ctx, settings, chatID, now)
	return exportDate, "自动统计日（重置时刻前为前两日，之后为昨日）"
}

func (s *WorkforceTelegramService) forceCloseOpenActivitiesForGroup(ctx context.Context, chatID string) (int, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return 0, nil
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT s.employee_id FROM wf_tg_activity_sessions s
		WHERE s.status = 'open' AND COALESCE(s.source_chat_id,'') = $1`, chatID)
	if err != nil {
		return 0, err
	}
	defer rows.Close()
	closed := 0
	for rows.Next() {
		var empID uuid.UUID
		if rows.Scan(&empID) != nil {
			continue
		}
		if err := s.forceCloseOpenActivityByEmployee(ctx, empID); err == nil {
			closed++
		}
	}
	return closed, nil
}

func (s *WorkforceTelegramService) purgeDailyDetailForGroup(ctx context.Context, chatID, exportDate string) error {
	chatID = strings.TrimSpace(chatID)
	exportDate = strings.TrimSpace(exportDate)
	if chatID == "" || exportDate == "" {
		return nil
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	_, err = tx.ExecContext(ctx, `
		DELETE FROM wf_tg_activity_sessions
		WHERE status = 'closed' AND attendance_date = $2::date
		  AND COALESCE(source_chat_id,'') = $1`, chatID, exportDate)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		DELETE FROM work_sessions ws
		USING employee_telegram_bindings b
		WHERE ws.employee_id = b.employee_id AND b.status = 1 AND b.chat_id = $1
		  AND ws.source = 'telegram' AND ws.status = 'closed'
		  AND ws.attendance_date = $2::date`, chatID, exportDate)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		DELETE FROM wf_tg_group_shift_state
		WHERE chat_id = $1 AND record_date <= $2::date`, chatID, exportDate)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		DELETE FROM wf_tg_handover_cycles
		WHERE chat_id = $1 AND handover_date <= $2::date`, chatID, exportDate)
	if err != nil {
		return err
	}
	return tx.Commit()
}

func (s *WorkforceTelegramService) closeExpiredWorkSessionsForEmployee(ctx context.Context, empID uuid.UUID, chatID string) (int, error) {
	maxHours := telegramShiftStateMaxHours()
	cutoff := time.Now().Add(-time.Duration(maxHours) * time.Hour)
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, COALESCE(shift_type,'day'), attendance_date::text
		FROM work_sessions
		WHERE employee_id = $1 AND source = 'telegram' AND status = 'open'
		  AND checkin_time < $2`, empID, cutoff)
	if err != nil {
		return 0, err
	}
	defer rows.Close()
	closed := 0
	for rows.Next() {
		var sid uuid.UUID
		var shift, recordDate string
		if rows.Scan(&sid, &shift, &recordDate) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		checkoutAt := time.Now()
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, checkoutAt, fmt.Sprintf("班次超时自动下班（>%dh）", maxHours)); err != nil {
			log.Printf("[Telegram] expired shift close session=%s: %v", sid, err)
			continue
		}
		closed++
	}
	return closed, nil
}

func (s *WorkforceTelegramService) CloseExpiredWorkSessionsGlobal(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	maxHours := telegramShiftStateMaxHours()
	cutoff := time.Now().Add(-time.Duration(maxHours) * time.Hour)
	rows, err := s.db.QueryContext(ctx, `
		SELECT ws.id, ws.employee_id, COALESCE(b.chat_id,''), COALESCE(ws.shift_type,'day'), ws.attendance_date::text
		FROM work_sessions ws
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source = 'telegram' AND ws.status = 'open' AND ws.checkin_time < $1`, cutoff)
	if err != nil {
		return
	}
	defer rows.Close()
	for rows.Next() {
		var sid, empID uuid.UUID
		var chatID, shift, recordDate string
		if rows.Scan(&sid, &empID, &chatID, &shift, &recordDate) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, time.Now(), fmt.Sprintf("班次超时自动下班（>%dh）", maxHours)); err != nil {
			log.Printf("[Telegram] global expired shift close session=%s: %v", sid, err)
		}
	}
}

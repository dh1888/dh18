package services

import (
	"context"
	"database/sql"
	"fmt"
	"math"
	"strings"
	"time"

	"github.com/google/uuid"
)

type SalaryCalculateRow struct {
	ID                   string   `json:"id,omitempty"`
	EmployeeID           string   `json:"employeeId"`
	EmployeeName         string   `json:"employeeName"`
	Position             string   `json:"position"`
	HireDateDept         string   `json:"hireDateDept"`
	WorkLocation         string   `json:"workLocation"`
	WorkMode             string   `json:"workMode"`
	MonthsEmployed       int      `json:"monthsEmployed"`
	LastMonthBase        float64  `json:"lastMonthBase"`
	TotalIncrease        float64  `json:"totalIncrease"`
	BaseSalary           float64  `json:"baseSalary"`
	AttendanceDays       float64  `json:"attendanceDays"`
	ActualBaseSalary     float64  `json:"actualBaseSalary"`
	AttendanceAdjustment float64  `json:"attendanceAdjustment"`
	HalfYearUnpaidLeave  float64  `json:"halfYearUnpaidLeave"`
	ExchangeRate         float64  `json:"exchangeRate"`
	ExchangeRateLabel    string   `json:"exchangeRateLabel,omitempty"`
	PerformanceScore     int      `json:"performanceScore"`
	PerformanceBonusB    float64  `json:"performanceBonusB"`
	Reward               float64  `json:"reward"`
	Penalty              float64  `json:"penalty"`
	Advance              float64  `json:"advance"`
	OtherDeduction       float64  `json:"otherDeduction"`
	ProtectionReturn     float64  `json:"protectionReturn"`
	ProtectionFee        float64  `json:"protectionFee"`
	TotalSalary          float64  `json:"totalSalary"`
	PayoutCurrency       string   `json:"payoutCurrency,omitempty"`
	Remark               string   `json:"remark"`
	YearMonth            string   `json:"yearMonth"`
	ManualFields         []string `json:"manualFields,omitempty"`
}

type SalaryCalculator struct {
	db     *sql.DB
	config *SalaryConfigService
}

func NewSalaryCalculator(db *sql.DB) *SalaryCalculator {
	return &SalaryCalculator{
		db:     db,
		config: NewSalaryConfigService(db),
	}
}

func (c *SalaryCalculator) BuildDraftRows(ctx context.Context, yearMonth string) ([]SalaryCalculateRow, map[string]SalaryWorkConfig, error) {
	yearMonth = strings.TrimSpace(yearMonth)
	if yearMonth == "" {
		return nil, nil, fmt.Errorf("yearMonth is required")
	}

	configs, err := c.config.ListConfigs(ctx)
	if err != nil {
		return nil, nil, err
	}
	configMap := BuildSalaryConfigMap(configs)

	employees, err := c.loadActiveEmployees(ctx)
	if err != nil {
		return nil, nil, err
	}
	if len(employees) == 0 {
		return []SalaryCalculateRow{}, configMap, nil
	}

	employeeIDs := make([]string, 0, len(employees))
	for _, emp := range employees {
		employeeIDs = append(employeeIDs, emp.ID)
	}

	attendanceMap, err := c.loadAttendanceDays(ctx, yearMonth, employeeIDs)
	if err != nil {
		return nil, nil, err
	}
	performanceMap, err := c.loadPerformanceScores(ctx, yearMonth)
	if err != nil {
		return nil, nil, err
	}
	penaltyMap, err := c.loadPenaltyTotals(ctx, yearMonth)
	if err != nil {
		return nil, nil, err
	}
	prevBaseMap, err := c.loadPreviousMonthBaseSalaries(ctx, yearMonth)
	if err != nil {
		return nil, nil, err
	}
	existingMap, err := c.loadExistingSalaryRows(ctx, yearMonth)
	if err != nil {
		return nil, nil, err
	}

	rows := make([]SalaryCalculateRow, 0, len(employees))
	for _, emp := range employees {
		workMode := ResolveSalaryConfigKey(emp.WorkLocation, configs)
		cfg := configMap[workMode]
		existing := existingMap[emp.ID]

		row := SalaryCalculateRow{
			EmployeeID:   emp.ID,
			EmployeeName: emp.Name,
			Position:     emp.Position,
			HireDateDept: formatHireDateDept(emp.HireDate, emp.Department),
			WorkLocation: emp.WorkLocation,
			WorkMode:     workMode,
			YearMonth:    yearMonth,
		}
		if existing != nil {
			row = *existing
			row.WorkLocation = emp.WorkLocation
			row.WorkMode = workMode
			row.YearMonth = yearMonth
		} else if prev, ok := prevBaseMap[emp.ID]; ok && prev > 0 {
			row.LastMonthBase = prev
			row.Penalty = penaltyMap[emp.ID]
		} else {
			row.Penalty = penaltyMap[emp.ID]
		}

		row.MonthsEmployed = calcMonthsEmployed(emp.HireDate, yearMonth)
		row.AttendanceDays = attendanceMap[emp.ID]
		if score, ok := performanceMap[emp.ID]; ok {
			row.PerformanceScore = score
		} else {
			row.PerformanceScore = 10
		}
		if !containsManual(row.ManualFields, "penalty") {
			row.Penalty = penaltyMap[emp.ID]
		}

		c.applyAutoFields(&row, cfg, manualFieldSet(row.ManualFields))
		rows = append(rows, row)
	}
	return rows, configMap, nil
}

func (c *SalaryCalculator) RecalculateRows(ctx context.Context, yearMonth string, rows []SalaryCalculateRow, configMap map[string]SalaryWorkConfig) ([]SalaryCalculateRow, error) {
	yearMonth = strings.TrimSpace(yearMonth)
	employeeIDs := make([]string, 0, len(rows))
	for _, row := range rows {
		if row.EmployeeID != "" {
			employeeIDs = append(employeeIDs, row.EmployeeID)
		}
	}
	attendanceMap, err := c.loadAttendanceDays(ctx, yearMonth, employeeIDs)
	if err != nil {
		return nil, err
	}
	performanceMap, err := c.loadPerformanceScores(ctx, yearMonth)
	if err != nil {
		return nil, err
	}
	penaltyMap, err := c.loadPenaltyTotals(ctx, yearMonth)
	if err != nil {
		return nil, err
	}
	employees, err := c.loadActiveEmployees(ctx)
	if err != nil {
		return nil, err
	}
	empMap := map[string]salaryEmployee{}
	for _, emp := range employees {
		empMap[emp.ID] = emp
	}

	out := make([]SalaryCalculateRow, 0, len(rows))
	for _, row := range rows {
		cfg := configMap[row.WorkMode]
		if cfg.ConfigKey == "" {
			cfg = configMap[ResolveSalaryConfigKey(row.WorkLocation, configsFromMap(configMap))]
		}
		manual := manualFieldSet(row.ManualFields)
		if emp, ok := empMap[row.EmployeeID]; ok {
			if !manual["monthsEmployed"] {
				row.MonthsEmployed = calcMonthsEmployed(emp.HireDate, yearMonth)
			}
			if !manual["hireDateDept"] {
				row.HireDateDept = formatHireDateDept(emp.HireDate, emp.Department)
			}
			row.WorkLocation = emp.WorkLocation
			row.WorkMode = ResolveSalaryConfigKey(emp.WorkLocation, configsFromMap(configMap))
			cfg = configMap[row.WorkMode]
		}
		if !manual["attendanceDays"] {
			row.AttendanceDays = attendanceMap[row.EmployeeID]
		}
		if !manual["performanceScore"] {
			if score, ok := performanceMap[row.EmployeeID]; ok {
				row.PerformanceScore = score
			} else {
				row.PerformanceScore = 10
			}
		}
		if !manual["penalty"] {
			row.Penalty = penaltyMap[row.EmployeeID]
		}
		c.applyAutoFields(&row, cfg, manual)
		out = append(out, row)
	}
	return out, nil
}

func BuildSalaryConfigMap(configs []SalaryWorkConfig) map[string]SalaryWorkConfig {
	configMap := map[string]SalaryWorkConfig{
		SalaryWorkModeRemote: defaultSalaryWorkConfig(SalaryWorkModeRemote, "居家", 1, true),
		SalaryWorkModeOnsite: defaultSalaryWorkConfig(SalaryWorkModeOnsite, "现场", 2, true),
	}
	for _, cfg := range configs {
		cfg.normalizeAliases()
		configMap[cfg.ConfigKey] = cfg
	}
	return configMap
}

func configsFromMap(configMap map[string]SalaryWorkConfig) []SalaryWorkConfig {
	out := make([]SalaryWorkConfig, 0, len(configMap))
	for _, cfg := range configMap {
		out = append(out, cfg)
	}
	return out
}

func (c *SalaryCalculator) applyAutoFields(row *SalaryCalculateRow, cfg SalaryWorkConfig, manual map[string]bool) {
	if manual == nil {
		manual = map[string]bool{}
	}
	if !manual["totalIncrease"] {
		increase := cfg.TotalIncrease
		cap := ResolvePositionCap(cfg, row.Position)
		row.TotalIncrease = ApplyPositionCapIncrement(row.LastMonthBase, increase, cap)
	}
	if !manual["exchangeRate"] {
		rate, label := displayExchangeRate(cfg)
		row.ExchangeRate = rate
		row.ExchangeRateLabel = label
	}
	if !manual["protectionFee"] {
		row.ProtectionFee = cfg.ProtectionFee
	}
	row.PayoutCurrency = cfg.PayoutCurrency
	if !manual["baseSalary"] {
		row.BaseSalary = roundMoney(row.LastMonthBase + row.TotalIncrease)
	}
	if !manual["actualBaseSalary"] {
		row.ActualBaseSalary = row.BaseSalary
	}
	if !manual["attendanceAdjustment"] {
		required := calcRequiredAttendanceDays(cfg.FullAttendanceDays, row.YearMonth)
		if row.AttendanceDays >= required {
			row.AttendanceAdjustment = cfg.FullAttendanceAmount
		} else {
			row.AttendanceAdjustment = 0
		}
	}
	if !manual["performanceBonusB"] {
		score := row.PerformanceScore
		if score < 0 {
			score = 0
		}
		row.PerformanceBonusB = roundMoney((float64(score) / 10.0) * cfg.PerformanceFullScoreAmount)
	}
	if !manual["totalSalary"] {
		row.TotalSalary = calcTotalSalary(*row, cfg)
	}
}

func salaryAmountToCNY(amount float64, currency string, rates SalaryExchangeRates) float64 {
	switch normalizeSalaryCurrency(currency) {
	case "CNY":
		return amount
	case "USD":
		if rates.CnyUsd > 0 {
			return amount * rates.CnyUsd
		}
	case "THB":
		if rates.CnyThb > 0 {
			return amount / rates.CnyThb
		}
		if rates.ThbUsd > 0 && rates.CnyUsd > 0 {
			return (amount / rates.ThbUsd) * rates.CnyUsd
		}
	}
	return amount
}

func salaryAmountFromCNY(cny float64, currency string, rates SalaryExchangeRates) float64 {
	switch normalizeSalaryCurrency(currency) {
	case "CNY":
		return cny
	case "USD":
		if rates.CnyUsd > 0 {
			return cny / rates.CnyUsd
		}
	case "THB":
		if rates.CnyThb > 0 {
			return cny * rates.CnyThb
		}
		if rates.ThbUsd > 0 && rates.CnyUsd > 0 {
			return (cny / rates.CnyUsd) * rates.ThbUsd
		}
	}
	return cny
}

func convertSalaryAmount(amount float64, from, to string, rates SalaryExchangeRates) float64 {
	from = normalizeSalaryCurrency(from)
	to = normalizeSalaryCurrency(to)
	if amount == 0 || from == to {
		return amount
	}
	return roundMoney(salaryAmountFromCNY(salaryAmountToCNY(amount, from, rates), to, rates))
}

func calcTotalSalary(row SalaryCalculateRow, cfg SalaryWorkConfig) float64 {
	payout := normalizeSalaryCurrency(cfg.PayoutCurrency)
	rates := cfg.exchangeRates()

	baseCNY := row.ActualBaseSalary + row.HalfYearUnpaidLeave + row.Reward -
		row.Penalty - row.Advance - row.OtherDeduction + row.ProtectionReturn

	sum := convertSalaryAmount(baseCNY, "CNY", payout, rates)
	sum += convertSalaryAmount(row.AttendanceAdjustment, cfg.FullAttendanceCurrency, payout, rates)
	sum += convertSalaryAmount(row.PerformanceBonusB, cfg.PerformanceCurrency, payout, rates)
	sum -= convertSalaryAmount(row.ProtectionFee, cfg.ProtectionFeeCurrency, payout, rates)
	return roundMoney(sum)
}

func roundMoney(v float64) float64 {
	return math.Round(v*100) / 100
}

func manualFieldSet(fields []string) map[string]bool {
	out := map[string]bool{}
	for _, f := range fields {
		f = strings.TrimSpace(f)
		if f != "" {
			out[f] = true
		}
	}
	return out
}

func containsManual(fields []string, key string) bool {
	return manualFieldSet(fields)[key]
}

type salaryEmployee struct {
	ID           string
	Name         string
	Position     string
	Department   string
	HireDate     sql.NullTime
	WorkLocation string
}

func (c *SalaryCalculator) loadActiveEmployees(ctx context.Context) ([]salaryEmployee, error) {
	rows, err := c.db.QueryContext(ctx, `
		SELECT id::text, name, COALESCE(position,''), COALESCE(department,''),
		       hire_date, COALESCE(work_location,'现场')
		FROM employees WHERE status = 1
		ORDER BY name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var items []salaryEmployee
	for rows.Next() {
		var item salaryEmployee
		if err := rows.Scan(&item.ID, &item.Name, &item.Position, &item.Department, &item.HireDate, &item.WorkLocation); err != nil {
			continue
		}
		items = append(items, item)
	}
	return items, rows.Err()
}

func (c *SalaryCalculator) loadAttendanceDays(ctx context.Context, yearMonth string, employeeIDs []string) (map[string]float64, error) {
	out := map[string]float64{}
	if len(employeeIDs) == 0 {
		return out, nil
	}
	placeholders := make([]string, len(employeeIDs))
	args := []interface{}{yearMonth}
	for i, id := range employeeIDs {
		placeholders[i] = fmt.Sprintf("$%d::uuid", i+2)
		args = append(args, id)
	}
	query := fmt.Sprintf(`
		SELECT employee_id::text, status
		FROM attendance_records
		WHERE year_month = $1 AND employee_id IN (%s)`, strings.Join(placeholders, ","))
	rows, err := c.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var empID, status string
		if err := rows.Scan(&empID, &status); err != nil {
			continue
		}
		switch strings.TrimSpace(status) {
		case "work":
			out[empID] += 1
		case "rest_half", "leave":
			out[empID] += 0.5
		}
	}
	return out, rows.Err()
}

func (c *SalaryCalculator) loadPerformanceScores(ctx context.Context, yearMonth string) (map[string]int, error) {
	out := map[string]int{}
	rows, err := c.db.QueryContext(ctx, `
		SELECT employee_id::text, total_score
		FROM performance_records WHERE month = $1`, yearMonth)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var empID string
		var score int
		if err := rows.Scan(&empID, &score); err != nil {
			continue
		}
		out[empID] = score
	}
	return out, rows.Err()
}

func (c *SalaryCalculator) loadPenaltyTotals(ctx context.Context, yearMonth string) (map[string]float64, error) {
	out := map[string]float64{}
	rows, err := c.db.QueryContext(ctx, `
		SELECT employee_id::text, COALESCE(SUM(amount), 0)
		FROM penalty_records
		WHERE TO_CHAR(penalty_date, 'YYYY-MM') = $1
		GROUP BY employee_id`, yearMonth)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var empID string
		var total float64
		if err := rows.Scan(&empID, &total); err != nil {
			continue
		}
		out[empID] = roundMoney(total)
	}
	return out, rows.Err()
}

func (c *SalaryCalculator) loadPreviousMonthBaseSalaries(ctx context.Context, yearMonth string) (map[string]float64, error) {
	out := map[string]float64{}
	prevMonth, err := previousYearMonth(yearMonth)
	if err != nil {
		return out, nil
	}
	rows, err := c.db.QueryContext(ctx, `
		SELECT employee_id, COALESCE(NULLIF(actual_base_salary, 0), base_salary, 0)
		FROM salary_records WHERE year_month = $1`, prevMonth)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var empID string
		var base float64
		if err := rows.Scan(&empID, &base); err != nil {
			continue
		}
		out[empID] = base
	}
	return out, rows.Err()
}

func (c *SalaryCalculator) loadExistingSalaryRows(ctx context.Context, yearMonth string) (map[string]*SalaryCalculateRow, error) {
	out := map[string]*SalaryCalculateRow{}
	rows, err := c.db.QueryContext(ctx, `
		SELECT id, employee_id, employee_name, position, hire_date_dept, months_employed,
		       last_month_base, total_increase, base_salary, attendance_days, actual_base_salary,
		       attendance_adjustment, half_year_unpaid_leave, exchange_rate, performance_score,
		       performance_bonus_b, reward, penalty, advance, other_deduction,
		       protection_return, protection_fee, total_salary, COALESCE(remark,'')
		FROM salary_records WHERE year_month = $1`, yearMonth)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var row SalaryCalculateRow
		if err := rows.Scan(
			&row.ID, &row.EmployeeID, &row.EmployeeName, &row.Position, &row.HireDateDept, &row.MonthsEmployed,
			&row.LastMonthBase, &row.TotalIncrease, &row.BaseSalary, &row.AttendanceDays, &row.ActualBaseSalary,
			&row.AttendanceAdjustment, &row.HalfYearUnpaidLeave, &row.ExchangeRate, &row.PerformanceScore,
			&row.PerformanceBonusB, &row.Reward, &row.Penalty, &row.Advance, &row.OtherDeduction,
			&row.ProtectionReturn, &row.ProtectionFee, &row.TotalSalary, &row.Remark,
		); err != nil {
			continue
		}
		row.YearMonth = yearMonth
		copy := row
		out[row.EmployeeID] = &copy
	}
	return out, rows.Err()
}

func (c *SalaryCalculator) SaveRows(ctx context.Context, yearMonth string, rows []SalaryCalculateRow) (int, error) {
	if strings.TrimSpace(yearMonth) == "" {
		return 0, fmt.Errorf("yearMonth is required")
	}
	tx, err := c.db.BeginTx(ctx, nil)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback()

	saved := 0
	now := time.Now().UTC()
	for _, row := range rows {
		if strings.TrimSpace(row.EmployeeID) == "" {
			continue
		}
		id := strings.TrimSpace(row.ID)
		if id == "" {
			id = uuid.NewString()
		}
		_, err := tx.ExecContext(ctx, `
			INSERT INTO salary_records (
				id, employee_id, employee_name, position, hire_date_dept,
				months_employed, last_month_base, total_increase, base_salary,
				attendance_days, actual_base_salary, attendance_adjustment,
				half_year_unpaid_leave, exchange_rate, performance_score,
				performance_bonus_b, reward, penalty, advance, other_deduction,
				protection_return, protection_fee, total_salary, remark, year_month,
				paid_status, created_at, updated_at
			) VALUES (
				$1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15,
				$16, $17, $18, $19, $20, $21, $22, $23, $24, $25, 'pending', $26, $26
			)
			ON CONFLICT (employee_id, year_month) DO UPDATE SET
				employee_name = EXCLUDED.employee_name,
				position = EXCLUDED.position,
				hire_date_dept = EXCLUDED.hire_date_dept,
				months_employed = EXCLUDED.months_employed,
				last_month_base = EXCLUDED.last_month_base,
				total_increase = EXCLUDED.total_increase,
				base_salary = EXCLUDED.base_salary,
				attendance_days = EXCLUDED.attendance_days,
				actual_base_salary = EXCLUDED.actual_base_salary,
				attendance_adjustment = EXCLUDED.attendance_adjustment,
				half_year_unpaid_leave = EXCLUDED.half_year_unpaid_leave,
				exchange_rate = EXCLUDED.exchange_rate,
				performance_score = EXCLUDED.performance_score,
				performance_bonus_b = EXCLUDED.performance_bonus_b,
				reward = EXCLUDED.reward,
				penalty = EXCLUDED.penalty,
				advance = EXCLUDED.advance,
				other_deduction = EXCLUDED.other_deduction,
				protection_return = EXCLUDED.protection_return,
				protection_fee = EXCLUDED.protection_fee,
				total_salary = EXCLUDED.total_salary,
				remark = EXCLUDED.remark,
				paid_status = 'pending',
				paid_at = NULL,
				updated_at = EXCLUDED.updated_at`,
			id, row.EmployeeID, row.EmployeeName, row.Position, row.HireDateDept,
			row.MonthsEmployed, row.LastMonthBase, row.TotalIncrease, row.BaseSalary,
			row.AttendanceDays, row.ActualBaseSalary, row.AttendanceAdjustment,
			row.HalfYearUnpaidLeave, row.ExchangeRate, row.PerformanceScore,
			row.PerformanceBonusB, row.Reward, row.Penalty, row.Advance, row.OtherDeduction,
			row.ProtectionReturn, row.ProtectionFee, row.TotalSalary, row.Remark, yearMonth, now)
		if err != nil {
			return saved, err
		}
		saved++
	}
	if err := tx.Commit(); err != nil {
		return saved, err
	}
	return saved, nil
}

func calcMonthsEmployed(hireDate sql.NullTime, yearMonth string) int {
	if !hireDate.Valid {
		return 0
	}
	end, err := time.Parse("2006-01", yearMonth)
	if err != nil {
		return 0
	}
	end = time.Date(end.Year(), end.Month()+1, 0, 0, 0, 0, 0, time.UTC)
	h := hireDate.Time.UTC()
	if end.Before(h) {
		return 0
	}
	years := end.Year() - h.Year()
	months := int(end.Month()) - int(h.Month())
	total := years*12 + months
	if total < 0 {
		return 0
	}
	if total == 0 {
		return 1
	}
	return total
}

func calcRequiredAttendanceDays(fullAttendanceDays int, yearMonth string) float64 {
	if fullAttendanceDays > 0 {
		return float64(fullAttendanceDays)
	}
	t, err := time.Parse("2006-01", yearMonth)
	if err != nil {
		return 0
	}
	return float64(time.Date(t.Year(), t.Month()+1, 0, 0, 0, 0, 0, time.UTC).Day())
}

func formatHireDateDept(hireDate sql.NullTime, department string) string {
	datePart := ""
	if hireDate.Valid {
		datePart = hireDate.Time.UTC().Format("2006-01-02")
	}
	dept := strings.TrimSpace(department)
	if datePart != "" && dept != "" {
		return datePart + "-" + dept
	}
	if datePart != "" {
		return datePart
	}
	return dept
}

func previousYearMonth(yearMonth string) (string, error) {
	t, err := time.Parse("2006-01", yearMonth)
	if err != nil {
		return "", err
	}
	t = t.AddDate(0, -1, 0)
	return t.Format("2006-01"), nil
}

package handlers

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

const maxAttendanceImportRows = 500

var attendanceStatusImportMap = map[string]string{
	"出勤":  "work",
	"半休":  "rest_half",
	"全休":  "rest_full",
	"半假":  "leave",
	"旷工":  "absent",
	"全假":  "off_post",
	"离职":  "resigned",
	"work":        "work",
	"rest_half":   "rest_half",
	"rest_full":   "rest_full",
	"leave":       "leave",
	"absent":      "absent",
	"off_post":    "off_post",
	"resigned":    "resigned",
	"pending":     "pending",
}

type attendanceImportColumnMap struct {
	HireDate     int
	Name         int
	Position     int
	WorkLocation int
	EmployeeID   int
	Username     int
	Password     int
	DayColumns   map[int]int
}

type attendanceImportRow struct {
	HireDate     string
	Name         string
	Position     string
	WorkLocation string
	EmployeeID   string
	Username     string
	Password     string
	DayStatus    map[int]string
}

func normalizeImportHeader(cell string) string {
	cell = strings.TrimSpace(cell)
	cell = strings.Trim(cell, "\ufeff")
	cell = strings.ReplaceAll(cell, " ", "")
	return strings.ToLower(cell)
}

func findImportColumn(header []string, keys ...string) int {
	for i, raw := range header {
		norm := normalizeImportHeader(raw)
		for _, key := range keys {
			if norm == normalizeImportHeader(key) {
				return i
			}
		}
	}
	return -1
}

func parseAttendanceImportHeader(header []string) (attendanceImportColumnMap, error) {
	if len(header) == 0 {
		return attendanceImportColumnMap{}, fmt.Errorf("表头为空")
	}

	m := attendanceImportColumnMap{
		HireDate:     findImportColumn(header, "入职日期", "hire_date"),
		Name:         findImportColumn(header, "姓名", "name", "员工姓名"),
		Position:     findImportColumn(header, "岗位", "position"),
		WorkLocation: findImportColumn(header, "办公地点", "公地点", "work_location", "工作地点"),
		EmployeeID:   findImportColumn(header, "工号", "employee_id", "员工工号"),
		Username:     findImportColumn(header, "登录账号", "username", "子账号"),
		Password:     findImportColumn(header, "初始密码", "password", "密码"),
		DayColumns:   make(map[int]int),
	}

	if m.Name < 0 {
		return m, fmt.Errorf("缺少「姓名」列")
	}

	for i, raw := range header {
		dayText := strings.TrimSpace(raw)
		if dayText == "" {
			continue
		}
		if day, err := strconv.Atoi(dayText); err == nil && day >= 1 && day <= 31 {
			m.DayColumns[day] = i
		}
	}

	return m, nil
}

func parseAttendanceStatus(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return ""
	}
	if status, ok := attendanceStatusImportMap[raw]; ok {
		return status
	}
	if status, ok := attendanceStatusImportMap[strings.ToLower(raw)]; ok {
		return status
	}
	return ""
}

func parseAttendanceImportRows(rows [][]string, cols attendanceImportColumnMap) ([]attendanceImportRow, error) {
	if len(rows) < 2 {
		return nil, fmt.Errorf("文件中没有数据行")
	}

	getCell := func(row []string, idx int) string {
		if idx < 0 || idx >= len(row) {
			return ""
		}
		return strings.TrimSpace(row[idx])
	}

	items := make([]attendanceImportRow, 0)
	for rowIdx, row := range rows[1:] {
		name := getCell(row, cols.Name)
		if name == "" {
			continue
		}

		item := attendanceImportRow{
			HireDate:     getCell(row, cols.HireDate),
			Name:         name,
			Position:     getCell(row, cols.Position),
			WorkLocation: getCell(row, cols.WorkLocation),
			EmployeeID:   getCell(row, cols.EmployeeID),
			Username:     getCell(row, cols.Username),
			Password:     getCell(row, cols.Password),
			DayStatus:    make(map[int]string),
		}

		if item.WorkLocation == "" {
			item.WorkLocation = "现场"
		}

		for day, colIdx := range cols.DayColumns {
			status := parseAttendanceStatus(getCell(row, colIdx))
			if status != "" {
				item.DayStatus[day] = status
			}
		}

		items = append(items, item)
		if len(items) > maxAttendanceImportRows {
			return nil, fmt.Errorf("单次最多导入 %d 名员工", maxAttendanceImportRows)
		}
		_ = rowIdx
	}

	if len(items) == 0 {
		return nil, fmt.Errorf("未读取到有效员工数据")
	}
	return items, nil
}

func (h *WorkforceHandler) lookupEmployeeID(ctx *gin.Context, employeeID, name string) (uuid.UUID, bool, error) {
	if strings.TrimSpace(employeeID) != "" {
		var id uuid.UUID
		err := h.db.QueryRowContext(ctx.Request.Context(), `
			SELECT id FROM employees WHERE employee_id = $1 LIMIT 1
		`, strings.TrimSpace(employeeID)).Scan(&id)
		if err == nil {
			return id, true, nil
		}
	}

	var id uuid.UUID
	err := h.db.QueryRowContext(ctx.Request.Context(), `
		SELECT id FROM employees WHERE name = $1 ORDER BY created_at ASC LIMIT 1
	`, strings.TrimSpace(name)).Scan(&id)
	if err != nil {
		return uuid.Nil, false, nil
	}
	return id, true, nil
}

func (h *WorkforceHandler) upsertAttendanceForImport(ctx *gin.Context, employeeID uuid.UUID, yearMonth, position string, dayStatus map[int]string) (int, error) {
	if len(dayStatus) == 0 {
		return 0, nil
	}

	parts := strings.Split(yearMonth, "-")
	if len(parts) != 2 {
		return 0, fmt.Errorf("invalid year_month")
	}

	updated := 0
	for day, status := range dayStatus {
		if status == "" {
			continue
		}
		dateKey := fmt.Sprintf("%s-%02d", yearMonth, day)
		_, err := h.db.ExecContext(ctx.Request.Context(), `
			INSERT INTO attendance_records (employee_id, year_month, date, status, position_snapshot, manually_edited, created_at, updated_at)
			VALUES ($1, $2, $3, $4, $5, TRUE, NOW(), NOW())
			ON CONFLICT (employee_id, year_month, date) DO UPDATE SET
				status = EXCLUDED.status,
				position_snapshot = EXCLUDED.position_snapshot,
				manually_edited = TRUE,
				updated_at = NOW()
		`, employeeID, yearMonth, dateKey, status, position)
		if err != nil {
			return updated, err
		}
		updated++
	}
	return updated, nil
}

func (h *WorkforceHandler) ensurePerformanceForMonth(ctx *gin.Context, employeeID uuid.UUID, name, position, yearMonth string) error {
	_, err := h.db.ExecContext(ctx.Request.Context(), `
		INSERT INTO performance_records (employee_id, employee_name, position, score_records, total_score, grade, month, created_at, updated_at)
		VALUES ($1, $2, $3, '[]'::jsonb, 10, '合格', $4, NOW(), NOW())
		ON CONFLICT (employee_id, month) DO NOTHING
	`, employeeID, name, position, yearMonth)
	return err
}

// ImportAttendanceRecords 导入考勤表，新员工可自动创建子账号与邀请码
func (h *WorkforceHandler) ImportAttendanceRecords(c *gin.Context) {
	yearMonth := strings.TrimSpace(c.PostForm("year_month"))
	defaultPassword := strings.TrimSpace(c.PostForm("default_password"))

	if yearMonth == "" {
		models.SendError(c, 400, 1001, "year_month 不能为空")
		return
	}
	if len(defaultPassword) > 0 && len(defaultPassword) < 6 {
		models.SendError(c, 400, 1001, "默认密码至少 6 位")
		return
	}

	file, err := c.FormFile("file")
	if err != nil {
		models.SendError(c, 400, 1001, "请上传文件")
		return
	}

	rows, err := readSiteStatsRowsFromFileHeader(file)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	cols, err := parseAttendanceImportHeader(rows[0])
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	items, err := parseAttendanceImportRows(rows, cols)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	createdBy := parseContextUserUUID(c)
	createdEmployees := 0
	updatedEmployees := 0
	attendanceCells := 0
	newAccounts := make([]gin.H, 0)

	for _, item := range items {
		employeeUUID, found, err := h.lookupEmployeeID(c, item.EmployeeID, item.Name)
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}

		if !found {
			username := strings.TrimSpace(item.Username)
			employeeCode := strings.TrimSpace(item.EmployeeID)
			if username == "" {
				username = employeeCode
			}
			if employeeCode == "" {
				employeeCode = username
			}
			if username == "" {
				models.SendError(c, 400, 1001, fmt.Sprintf("员工「%s」不存在，请填写登录账号或工号以自动创建子账号", item.Name))
				return
			}
			if username != employeeCode {
				employeeCode = username
			}

			password := strings.TrimSpace(item.Password)
			if password == "" {
				password = defaultPassword
			}
			if len(password) < 6 {
				models.SendError(c, 400, 1001, fmt.Sprintf("员工「%s」需填写初始密码，或在导入时设置默认密码（至少6位）", item.Name))
				return
			}

			result, err := h.workforce.CreateEmployeeAccount(c.Request.Context(), &services.CreateEmployeeAccountInput{
				Username:     username,
				Password:     password,
				EmployeeID:   employeeCode,
				Name:         item.Name,
				Position:     item.Position,
				HireDate:     item.HireDate,
				WorkLocation: item.WorkLocation,
				CreatedBy:    createdBy,
			})
			if err != nil {
				if strings.Contains(err.Error(), "duplicate") || strings.Contains(err.Error(), "unique") {
					models.SendError(c, 400, 1001, fmt.Sprintf("员工「%s」创建失败：登录账号或工号已存在", item.Name))
					return
				}
				models.SendError(c, 500, 5000, fmt.Sprintf("创建员工「%s」失败: %v", item.Name, err))
				return
			}

			employeeUUID = result.EmployeeID
			createdEmployees++
			newAccounts = append(newAccounts, gin.H{
				"name":       item.Name,
				"username":   username,
				"employeeId": result.EmployeeID.String(),
				"inviteCode": result.InviteCode,
			})
		} else {
			updatedEmployees++
		}

		if err := h.ensurePerformanceForMonth(c, employeeUUID, item.Name, item.Position, yearMonth); err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}

		count, err := h.upsertAttendanceForImport(c, employeeUUID, yearMonth, item.Position, item.DayStatus)
		if err != nil {
			models.SendError(c, 500, 5000, fmt.Sprintf("导入员工「%s」考勤失败: %v", item.Name, err))
			return
		}
		attendanceCells += count
	}

	Log(c, "CREATE", "ATTENDANCE",
		fmt.Sprintf("导入 %s 月考勤：新增员工 %d，更新 %d，写入 %d 条考勤", yearMonth, createdEmployees, updatedEmployees, attendanceCells),
		"", yearMonth)

	models.Send(c, 200, 0, "Import completed", gin.H{
		"createdEmployees": createdEmployees,
		"updatedEmployees": updatedEmployees,
		"attendanceCells":  attendanceCells,
		"newAccounts":      newAccounts,
	})
}

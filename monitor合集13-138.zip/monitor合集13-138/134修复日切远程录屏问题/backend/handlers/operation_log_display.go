package handlers

import "strings"

func isGenericMiddlewareDesc(desc string) bool {
	desc = strings.TrimSpace(desc)
	switch desc {
	case "新增数据", "修改数据", "删除数据":
		return true
	default:
		return false
	}
}

func enrichOperationLogDesc(desc, method, path string) string {
	desc = strings.TrimSpace(desc)
	path = strings.TrimSpace(path)
	method = strings.TrimSpace(method)
	if path == "" || !isGenericMiddlewareDesc(desc) {
		return desc
	}
	if method == "" {
		method = "POST"
	}
	return method + " " + path
}

package handlers

import (
	"fmt"
	"strings"
	"unicode/utf8"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

const (
	screenLockPasswordMinLen = 6
	screenLockPasswordMaxLen = 64
)

func validateScreenLockPassword(password string) string {
	password = strings.TrimSpace(password)
	n := utf8.RuneCountInString(password)
	if n < screenLockPasswordMinLen {
		return "密码至少 6 位"
	}
	if n > screenLockPasswordMaxLen {
		return "密码过长"
	}
	return ""
}

func (h *UserHandler) currentUserUUID(c *gin.Context) (uuid.UUID, bool) {
	userID := strings.TrimSpace(c.GetString("userID"))
	id, err := uuid.Parse(userID)
	if err != nil || id == uuid.Nil {
		models.SendError(c, 401, 1002, "未登录")
		return uuid.Nil, false
	}
	return id, true
}

// GetScreenLockStatus reports whether the current user configured a screen-lock password.
func (h *UserHandler) GetScreenLockStatus(c *gin.Context) {
	id, ok := h.currentUserUUID(c)
	if !ok {
		return
	}
	configured, err := h.repo.ScreenLockPasswordConfigured(c.Request.Context(), id)
	if err != nil {
		if err.Error() == "user not found" {
			models.SendError(c, 404, 2001, "用户不存在")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"configured": configured})
}

type screenLockPasswordBody struct {
	Password string `json:"password"`
}

// SetupScreenLockPassword sets the screen-lock password on first use.
func (h *UserHandler) SetupScreenLockPassword(c *gin.Context) {
	id, ok := h.currentUserUUID(c)
	if !ok {
		return
	}
	var req screenLockPasswordBody
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if msg := validateScreenLockPassword(req.Password); msg != "" {
		models.SendError(c, 400, 1001, msg)
		return
	}
	configured, err := h.repo.ScreenLockPasswordConfigured(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if configured {
		models.SendError(c, 400, 1001, "锁屏密码已设置，请使用修改密码")
		return
	}
	if err := h.repo.SetScreenLockPassword(c.Request.Context(), id, req.Password); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

// VerifyScreenLockPassword checks the screen-lock password for unlocking the UI.
func (h *UserHandler) VerifyScreenLockPassword(c *gin.Context) {
	id, ok := h.currentUserUUID(c)
	if !ok {
		return
	}
	var req screenLockPasswordBody
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if strings.TrimSpace(req.Password) == "" {
		models.SendError(c, 400, 1001, "请输入密码")
		return
	}
	okPass, err := h.repo.VerifyScreenLockPassword(c.Request.Context(), id, req.Password)
	if err != nil {
		if err.Error() == "user not found" {
			models.SendError(c, 404, 2001, "用户不存在")
			return
		}
		if err.Error() == "not configured" {
			models.SendError(c, 400, 1001, "请先在个人资料中设置锁屏密码")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if !okPass {
		models.SendError(c, 400, 1001, "密码不正确")
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

type changeScreenLockPasswordBody struct {
	OldPassword string `json:"oldPassword"`
	NewPassword string `json:"newPassword"`
}

// ChangeScreenLockPassword lets the current user replace their screen-lock password.
func (h *UserHandler) ChangeScreenLockPassword(c *gin.Context) {
	id, ok := h.currentUserUUID(c)
	if !ok {
		return
	}
	var req changeScreenLockPasswordBody
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if strings.TrimSpace(req.OldPassword) == "" {
		models.SendError(c, 400, 1001, "请输入当前密码")
		return
	}
	if msg := validateScreenLockPassword(req.NewPassword); msg != "" {
		models.SendError(c, 400, 1001, msg)
		return
	}
	if req.OldPassword == req.NewPassword {
		models.SendError(c, 400, 1001, "新密码不能与当前密码相同")
		return
	}
	if err := h.repo.ChangeScreenLockPassword(c.Request.Context(), id, req.OldPassword, req.NewPassword); err != nil {
		switch err.Error() {
		case "user not found":
			models.SendError(c, 404, 2001, "用户不存在")
		case "not configured":
			models.SendError(c, 400, 1001, "请先设置锁屏密码")
		case "wrong password":
			models.SendError(c, 400, 1001, "当前密码不正确")
		default:
			models.SendError(c, 500, 5000, err.Error())
		}
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

// GetScreenLockPasswordStatus returns whether the user configured a screen-lock password.
func (h *UserHandler) GetScreenLockPasswordStatus(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}
	configured, err := h.repo.ScreenLockPasswordConfigured(c.Request.Context(), id)
	if err != nil {
		if err.Error() == "user not found" {
			models.SendError(c, 404, 2001, "User not found")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"configured": configured})
}

// ResetScreenLockPassword clears or sets the target user's screen-lock password.
func (h *UserHandler) ResetScreenLockPassword(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}

	var req struct {
		Password string `json:"password"`
		Clear    bool   `json:"clear"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	user, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "User not found")
		return
	}

	if req.Clear {
		if err := h.repo.ClearScreenLockPassword(c.Request.Context(), id); err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		Log(c, "UPDATE", "USER",
			fmt.Sprintf("清空锁屏密码：用户 %s（登录名 %s）", userLogDisplayName(user.Username, user.RealName), user.Username),
			id.String(), userLogDisplayName(user.Username, user.RealName))
		models.Send(c, 200, 0, "Screen lock password cleared", nil)
		return
	}

	password := strings.TrimSpace(req.Password)
	if msg := validateScreenLockPassword(password); msg != "" {
		models.SendError(c, 400, 1001, msg)
		return
	}
	if err := h.repo.SetScreenLockPassword(c.Request.Context(), id, password); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "USER",
		fmt.Sprintf("重置锁屏密码：用户 %s（登录名 %s）", userLogDisplayName(user.Username, user.RealName), user.Username),
		id.String(), userLogDisplayName(user.Username, user.RealName))
	models.Send(c, 200, 0, "Screen lock password reset", nil)
}

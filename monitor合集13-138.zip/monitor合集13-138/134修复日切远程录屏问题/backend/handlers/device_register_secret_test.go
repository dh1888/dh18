package handlers

import "testing"

func TestDeviceSecretMatch(t *testing.T) {
	secret := "aabbccddeeff00112233445566778899aabbccddeeff00112233445566778899"
	if !deviceSecretMatch(secret, secret) {
		t.Fatal("expected match for identical secrets")
	}
	if deviceSecretMatch("", secret) {
		t.Fatal("empty provided must not match")
	}
	if deviceSecretMatch(secret, "") {
		t.Fatal("empty stored must not match")
	}
	if deviceSecretMatch(secret, "bbbbccddeeff00112233445566778899aabbccddeeff00112233445566778899") {
		t.Fatal("different secrets must not match")
	}
	if deviceSecretMatch(secret+"x", secret) {
		t.Fatal("length mismatch must not match")
	}
	if !deviceSecretMatch("  "+secret+"  ", secret) {
		t.Fatal("trim whitespace should still match")
	}
}

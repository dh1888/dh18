package handlers

import (
	"database/sql"
	"strings"
	"unicode/utf8"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

const (
	salaryViewPasswordMinLen = 6
	salaryViewPasswordMaxLen = 64
)

type salaryViewPasswordBody struct {
	Password string `json:"password"`
}

func (h *AdminHandler) currentUserID(c *gin.Context) (string, bool) {
	userID := strings.TrimSpace(c.GetString("userID"))
	return userID, userID != ""
}

func validateSalaryViewPassword(password string) string {
	password = strings.TrimSpace(password)
	n := utf8.RuneCountInString(password)
	if n < salaryViewPasswordMinLen {
		return "密码至少 6 位"
	}
	if n > salaryViewPasswordMaxLen {
		return "密码过长"
	}
	return ""
}

func salaryViewUnlockPayload(c *gin.Context, userID string) {
	token, expiresAt := services.IssueSalaryViewUnlockToken(userID)
	models.Send(c, 200, 0, "success", gin.H{
		"unlockToken": token,
		"expiresAt":   expiresAt,
	})
}

// GetSalaryViewGateStatus reports whether the current user configured a salary-view gate password.
func (h *AdminHandler) GetSalaryViewGateStatus(c *gin.Context) {
	userID, ok := h.currentUserID(c)
	if !ok {
		models.SendError(c, 401, 1002, "未登录")
		return
	}
	var hash sql.NullString
	err := h.db.QueryRowContext(c.Request.Context(), `
		SELECT salary_view_password_hash FROM users WHERE id = $1
	`, userID).Scan(&hash)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "用户不存在")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	configured := hash.Valid && strings.TrimSpace(hash.String) != ""
	models.Send(c, 200, 0, "success", gin.H{"configured": configured})
}

// SetupSalaryViewPassword sets the gate password on first use (bcrypt hash).
func (h *AdminHandler) SetupSalaryViewPassword(c *gin.Context) {
	userID, ok := h.currentUserID(c)
	if !ok {
		models.SendError(c, 401, 1002, "未登录")
		return
	}
	var req salaryViewPasswordBody
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if msg := validateSalaryViewPassword(req.Password); msg != "" {
		models.SendError(c, 400, 1001, msg)
		return
	}

	var existing sql.NullString
	err := h.db.QueryRowContext(c.Request.Context(), `
		SELECT salary_view_password_hash FROM users WHERE id = $1
	`, userID).Scan(&existing)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "用户不存在")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if existing.Valid && strings.TrimSpace(existing.String) != "" {
		models.SendError(c, 400, 1001, "工资查看密码已设置")
		return
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	_, err = h.db.ExecContext(c.Request.Context(), `
		UPDATE users SET salary_view_password_hash = $1 WHERE id = $2
	`, string(hash), userID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	salaryViewUnlockPayload(c, userID)
}

// VerifySalaryViewPassword checks the gate password and returns a short-lived unlock token.
func (h *AdminHandler) VerifySalaryViewPassword(c *gin.Context) {
	userID, ok := h.currentUserID(c)
	if !ok {
		models.SendError(c, 401, 1002, "未登录")
		return
	}
	var req salaryViewPasswordBody
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if strings.TrimSpace(req.Password) == "" {
		models.SendError(c, 400, 1001, "请输入密码")
		return
	}

	var hash sql.NullString
	err := h.db.QueryRowContext(c.Request.Context(), `
		SELECT salary_view_password_hash FROM users WHERE id = $1
	`, userID).Scan(&hash)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "用户不存在")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if !hash.Valid || strings.TrimSpace(hash.String) == "" {
		models.SendError(c, 400, 1001, "请先设置工资查看密码")
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(hash.String), []byte(req.Password)) != nil {
		models.SendError(c, 400, 1001, "密码不正确")
		return
	}
	salaryViewUnlockPayload(c, userID)
}

type changeSalaryViewPasswordBody struct {
	OldPassword string `json:"oldPassword"`
	NewPassword string `json:"newPassword"`
}

// ChangeSalaryViewPassword lets the current user replace their salary-view gate password.
func (h *AdminHandler) ChangeSalaryViewPassword(c *gin.Context) {
	userID, ok := h.currentUserID(c)
	if !ok {
		models.SendError(c, 401, 1002, "未登录")
		return
	}
	var req changeSalaryViewPasswordBody
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if strings.TrimSpace(req.OldPassword) == "" {
		models.SendError(c, 400, 1001, "请输入当前密码")
		return
	}
	if msg := validateSalaryViewPassword(req.NewPassword); msg != "" {
		models.SendError(c, 400, 1001, msg)
		return
	}
	if req.OldPassword == req.NewPassword {
		models.SendError(c, 400, 1001, "新密码不能与当前密码相同")
		return
	}

	var hash sql.NullString
	err := h.db.QueryRowContext(c.Request.Context(), `
		SELECT salary_view_password_hash FROM users WHERE id = $1
	`, userID).Scan(&hash)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "用户不存在")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if !hash.Valid || strings.TrimSpace(hash.String) == "" {
		models.SendError(c, 400, 1001, "请先设置工资查看密码")
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(hash.String), []byte(req.OldPassword)) != nil {
		models.SendError(c, 400, 1001, "当前密码不正确")
		return
	}

	newHash, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	_, err = h.db.ExecContext(c.Request.Context(), `
		UPDATE users SET salary_view_password_hash = $1 WHERE id = $2
	`, string(newHash), userID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	salaryViewUnlockPayload(c, userID)
}

package handlers

import (
	"strings"

	"github.com/gin-gonic/gin"
)

// parseIncludeTechnical 为 true 时展示全部日志（含令牌、WS 票据等）；默认 false 为业务操作视图。
func parseIncludeTechnical(c *gin.Context) bool {
	v := strings.TrimSpace(c.Query("includeTechnical"))
	return v == "1" || strings.EqualFold(v, "true") || strings.EqualFold(v, "yes")
}

// sqlExcludeTechnicalOperationLogs 业务视图：排除非菜单业务的技术/辅助请求（仍写入库，全量开关可查看）。
func sqlExcludeTechnicalOperationLogs() string {
	return ` NOT (
		(
			ol.operation_module IN ('其他', 'OTHER')
			AND (
				ol.operation_desc IN ('新增数据', '修改数据', '删除数据')
				OR ol.operation_desc LIKE 'POST %'
				OR ol.operation_desc LIKE 'PUT %'
				OR ol.operation_desc LIKE 'DELETE %'
				OR ol.operation_desc LIKE 'PATCH %'
			)
		)
		OR ol.operation_module IN ('媒体访问', 'MEDIA')
		OR ol.operation_desc LIKE '%媒体访问令牌%'
		OR ol.operation_desc LIKE '%WebSocket 连接票据%'
		OR ol.operation_desc LIKE '%诊断中心前端上报%'
		OR ol.operation_desc LIKE '%标记%通知%已读%'
		OR ol.operation_desc LIKE '%将全部通知标记为已读%'
		OR COALESCE(ol.request_path, '') LIKE '%/media/access-token%'
		OR COALESCE(ol.request_path, '') LIKE '%/ws-ticket%'
		OR COALESCE(ol.request_path, '') LIKE '%/notifications/read-all%'
		OR COALESCE(ol.request_path, '') LIKE '%/notifications/%/read%'
		OR COALESCE(ol.request_path, '') LIKE '%/diagnostics/ingest%'
	)`
}

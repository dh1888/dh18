// backend/handlers/user.go
// 完整替换文件内容 - 修复循环导入问题

package handlers

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type UserHandler struct {
	repo      *services.UserRepository
	totp      *services.TOTPAuthService
	settings  *services.SystemSettingsService
	workforce *services.WorkforceService
}

func NewUserHandler(
	repo *services.UserRepository,
	totp *services.TOTPAuthService,
	settings *services.SystemSettingsService,
	workforce *services.WorkforceService,
) *UserHandler {
	return &UserHandler{repo: repo, totp: totp, settings: settings, workforce: workforce}
}

func userLogDisplayName(username, realName string) string {
	realName = strings.TrimSpace(realName)
	if realName != "" {
		return realName
	}
	return username
}

// ListUsers 获取用户列表
func (h *UserHandler) ListUsers(c *gin.Context) {
	page := c.DefaultQuery("page", "1")
	pageSize := c.DefaultQuery("pageSize", "20")
	keyword := c.Query("keyword")

	// 转换页码和每页大小
	pageNum, _ := strconv.Atoi(page)
	pageSizeNum, _ := strconv.Atoi(pageSize)
	if pageNum < 1 {
		pageNum = 1
	}
	if pageSizeNum < 1 {
		pageSizeNum = 20
	}
	if pageSizeNum > 100 {
		pageSizeNum = 100
	}

	users, total, err := h.repo.List(c.Request.Context(), page, pageSize, keyword)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items":    users,
		"total":    total,
		"page":     pageNum,
		"pageSize": pageSizeNum,
	})
}

func (h *UserHandler) denyNonAdminPrivilegeEscalation(c *gin.Context, roleIDs []string) bool {
	if middleware.IsAdminRole(c) {
		return false
	}
	if len(roleIDs) == 0 {
		return false
	}
	hasAdmin, err := h.repo.RoleIDsIncludeAdmin(c.Request.Context(), roleIDs)
	if err != nil {
		models.SendInternalError(c, err)
		return true
	}
	if hasAdmin {
		models.SendError(c, 403, 1003, "只有管理员可以分配管理员角色")
		return true
	}
	return false
}

func (h *UserHandler) denyNonAdminManageAdminUser(c *gin.Context, targetID uuid.UUID) bool {
	if middleware.IsAdminRole(c) {
		return false
	}
	isAdmin, err := h.repo.UserHasAdminRole(c.Request.Context(), targetID)
	if err != nil {
		if err == sql.ErrNoRows {
			models.SendError(c, 404, 2001, "User not found")
			return true
		}
		models.SendInternalError(c, err)
		return true
	}
	if isAdmin {
		models.SendError(c, 403, 1003, "只有管理员可以管理管理员账号")
		return true
	}
	return false
}

// CreateUser 创建用户
func (h *UserHandler) CreateUser(c *gin.Context) {
	var req models.CreateUserRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: "+err.Error())
		return
	}
	if h.denyNonAdminPrivilegeEscalation(c, req.RoleIDs) {
		return
	}

	user, err := h.repo.Create(c.Request.Context(), &req)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// ✅ 记录操作日志
	Log(c, "CREATE", "USER",
		fmt.Sprintf("创建系统用户：%s（登录名 %s）", userLogDisplayName(user.Username, user.RealName), user.Username),
		user.ID.String(), userLogDisplayName(user.Username, user.RealName))

	models.Send(c, 200, 0, "User created", user)
}

// GetUser 获取用户详情
func (h *UserHandler) GetUser(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}

	user, err := h.repo.Get(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "User not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", user)
}

// UpdateUser 更新用户
func (h *UserHandler) UpdateUser(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}

	var req models.UpdateUserRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if h.denyNonAdminManageAdminUser(c, id) {
		return
	}
	if req.RoleIDs != nil && h.denyNonAdminPrivilegeEscalation(c, req.RoleIDs) {
		return
	}

	user, err := h.repo.Update(c.Request.Context(), id, &req)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	if h.workforce != nil && strings.TrimSpace(req.RealName) != "" {
		if syncErr := h.workforce.SyncEmployeeProfileByUserID(c.Request.Context(), id, req.RealName, ""); syncErr != nil {
			log.Printf("SyncEmployeeProfileByUserID failed for user %s: %v", id, syncErr)
		}
	}

	if req.RoleIDs != nil {
		middleware.InvalidateUserPermissionCache(id.String())
	}

	// ✅ 记录操作日志
	Log(c, "UPDATE", "USER",
		fmt.Sprintf("修改系统用户：%s（登录名 %s）", userLogDisplayName(user.Username, user.RealName), user.Username),
		id.String(), userLogDisplayName(user.Username, user.RealName))

	models.Send(c, 200, 0, "User updated", user)
}

// DeleteUser 删除用户
func (h *UserHandler) DeleteUser(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}

	// 不能删除自己
	currentUserID := c.GetString("userID")
	if currentUserID == id.String() {
		models.SendError(c, 400, 1001, "Cannot delete yourself")
		return
	}

	// 获取用户信息用于日志
	user, err := h.repo.Get(c.Request.Context(), id)
	if err == nil && user.Username == "admin" {
		models.SendError(c, 400, 1001, "Cannot delete admin user")
		return
	}

	if err := revokeUserSessions(c.Request.Context(), id, "user_deleted"); err != nil {
		models.SendError(c, 500, 5000, "Failed to revoke user sessions")
		return
	}

	if err := h.repo.Delete(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// ✅ 记录操作日志
	if user != nil {
		Log(c, "DELETE", "USER",
			fmt.Sprintf("删除系统用户：%s（登录名 %s）", userLogDisplayName(user.Username, user.RealName), user.Username),
			id.String(), userLogDisplayName(user.Username, user.RealName))
	}

	models.Send(c, 200, 0, "User deleted", nil)
}

func revokeUserSessions(ctx context.Context, userID uuid.UUID, reason string) error {
	svc := middleware.GetSessionService()
	if svc == nil {
		return fmt.Errorf("session service unavailable")
	}
	return svc.RevokeSubjectRefreshTokens(ctx, services.SessionSubjectUser, userID, reason)
}

// ResetTotp 管理员重置用户谷歌验证器绑定
func (h *UserHandler) ResetTotp(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}
	user, err := h.repo.Get(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "User not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if err := h.repo.ResetUserTOTP(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	_ = revokeUserSessions(c.Request.Context(), id, "totp_reset")
	Log(c, "UPDATE", "USER",
		fmt.Sprintf("重置谷歌验证：用户 %s（登录名 %s）", userLogDisplayName(user.Username, user.RealName), user.Username),
		id.String(), userLogDisplayName(user.Username, user.RealName))
	models.Send(c, 200, 0, "Google Authenticator reset", nil)
}

// ResetPassword 重置用户密码（管理员）
func (h *UserHandler) ResetPassword(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}

	var req struct {
		Password string `json:"password" binding:"required,min=6"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: password is required and must be at least 6 characters")
		return
	}

	// 先获取用户信息用于日志
	user, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if h.denyNonAdminManageAdminUser(c, id) {
		return
	}

	if err := h.repo.ChangePassword(c.Request.Context(), id, req.Password); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	revokeUserSessions(c.Request.Context(), id, "password_reset")

	// ✅ 记录操作日志
	Log(c, "UPDATE", "USER",
		fmt.Sprintf("重置密码：用户 %s（登录名 %s）", userLogDisplayName(user.Username, user.RealName), user.Username),
		id.String(), userLogDisplayName(user.Username, user.RealName))

	models.Send(c, 200, 0, "Password reset successfully", nil)
}

// GetSalaryViewPasswordStatus returns whether the user configured a salary-view gate password.
func (h *UserHandler) GetSalaryViewPasswordStatus(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}
	configured, err := h.repo.SalaryViewPasswordConfigured(c.Request.Context(), id)
	if err != nil {
		if err.Error() == "user not found" {
			models.SendError(c, 404, 2001, "User not found")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"configured": configured})
}

// ResetSalaryViewPassword clears or sets the target user's salary-view gate password.
func (h *UserHandler) ResetSalaryViewPassword(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}

	var req struct {
		Password string `json:"password"`
		Clear    bool   `json:"clear"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	user, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "User not found")
		return
	}

	if req.Clear {
		if err := h.repo.ClearSalaryViewPassword(c.Request.Context(), id); err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		Log(c, "UPDATE", "USER",
			fmt.Sprintf("清空工资查看密码：用户 %s（登录名 %s）", userLogDisplayName(user.Username, user.RealName), user.Username),
			id.String(), userLogDisplayName(user.Username, user.RealName))
		models.Send(c, 200, 0, "Salary view password cleared", nil)
		return
	}

	password := strings.TrimSpace(req.Password)
	if len(password) < 6 {
		models.SendError(c, 400, 1001, "密码至少 6 位")
		return
	}
	if err := h.repo.SetSalaryViewPassword(c.Request.Context(), id, password); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "USER",
		fmt.Sprintf("重置工资查看密码：用户 %s（登录名 %s）", userLogDisplayName(user.Username, user.RealName), user.Username),
		id.String(), userLogDisplayName(user.Username, user.RealName))
	models.Send(c, 200, 0, "Salary view password reset", nil)
}

// GetProfile 获取当前用户信息
func (h *UserHandler) GetProfile(c *gin.Context) {
	userID := c.GetString("userID")
	id, err := uuid.Parse(userID)
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid user")
		return
	}

	user, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "User not found")
		return
	}

	models.Send(c, 200, 0, "success", user)
}

// UpdateProfile 更新个人信息
func (h *UserHandler) UpdateProfile(c *gin.Context) {
	userID := c.GetString("userID")
	id, err := uuid.Parse(userID)
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid user")
		return
	}

	var req struct {
		Email    string `json:"email"`
		RealName string `json:"realName"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	user, err := h.repo.UpdateProfile(c.Request.Context(), id, req.Email, req.RealName)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	if h.workforce != nil && strings.TrimSpace(req.RealName) != "" {
		if syncErr := h.workforce.SyncEmployeeProfileByUserID(c.Request.Context(), id, req.RealName, ""); syncErr != nil {
			log.Printf("SyncEmployeeProfileByUserID failed for user %s: %v", id, syncErr)
		}
	}

	// ✅ 记录操作日志
	Log(c, "UPDATE", "USER",
		fmt.Sprintf("修改个人资料：%s", userLogDisplayName(user.Username, user.RealName)),
		id.String(), userLogDisplayName(user.Username, user.RealName))

	models.Send(c, 200, 0, "Profile updated", user)
}

// ChangeOwnPassword 修改自己的密码
func (h *UserHandler) ChangeOwnPassword(c *gin.Context) {
	userID := c.GetString("userID")
	id, err := uuid.Parse(userID)
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid user")
		return
	}

	var req models.ChangePasswordRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	if err := h.repo.ChangeOwnPassword(c.Request.Context(), id, req.OldPassword, req.NewPassword); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	revokeUserSessions(c.Request.Context(), id, "password_changed")

	// ✅ 记录操作日志
	username := c.GetString("username")
	Log(c, "UPDATE", "USER",
		fmt.Sprintf("修改登录密码：%s", username), id.String(), username)

	models.Send(c, 200, 0, "Password changed successfully", nil)
}

// ========== 角色管理 ==========

// GetAllRoles 获取所有角色
func (h *UserHandler) GetAllRoles(c *gin.Context) {
	roles, err := h.repo.GetAllRoles(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", roles)
}

// GetRole 获取单个角色
func (h *UserHandler) GetRole(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid role ID")
		return
	}

	role, err := h.repo.GetRoleByID(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", role)
}

// CreateRole 创建角色
func (h *UserHandler) CreateRole(c *gin.Context) {
	var req models.CreateRoleRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: "+err.Error())
		return
	}

	role, err := h.repo.CreateRole(c.Request.Context(), &req)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// ✅ 记录操作日志
	Log(c, "CREATE", "ROLE",
		fmt.Sprintf("创建角色：%s", role.Name), role.ID.String(), role.Name)

	models.Send(c, 200, 0, "Role created", role)
}

// UpdateRole 更新角色
func (h *UserHandler) UpdateRole(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid role ID")
		return
	}

	var req models.UpdateRoleRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	role, err := h.repo.UpdateRole(c.Request.Context(), id, &req)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// ✅ 记录操作日志
	Log(c, "UPDATE", "ROLE",
		fmt.Sprintf("修改角色：%s", role.Name), id.String(), role.Name)

	middleware.InvalidateAllPermissionCache()
	models.Send(c, 200, 0, "Role updated", role)
}

// DeleteRole 删除角色
func (h *UserHandler) DeleteRole(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid role ID")
		return
	}

	// 获取角色信息用于日志
	role, err := h.repo.GetRoleByID(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	if err := h.repo.DeleteRole(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// ✅ 记录操作日志
	Log(c, "DELETE", "ROLE",
		fmt.Sprintf("删除角色：%s", role.Name), id.String(), role.Name)

	middleware.InvalidateAllPermissionCache()
	models.Send(c, 200, 0, "Role deleted", nil)
}

// AssignRole 为用户分配角色
func (h *UserHandler) AssignRole(c *gin.Context) {
	userID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}

	var req struct {
		RoleID string `json:"roleId" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	roleID, err := uuid.Parse(req.RoleID)
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid role ID")
		return
	}
	if h.denyNonAdminManageAdminUser(c, userID) {
		return
	}
	if h.denyNonAdminPrivilegeEscalation(c, []string{roleID.String()}) {
		return
	}

	// 获取用户和角色信息
	user, _ := h.repo.Get(c.Request.Context(), userID)
	role, _ := h.repo.GetRoleByID(c.Request.Context(), roleID)

	if err := h.repo.AssignRoleToUser(c.Request.Context(), userID, roleID); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// ✅ 记录操作日志
	roleName := ""
	if role != nil {
		roleName = role.Name
	}
	username := ""
	if user != nil {
		username = user.Username
	}
	Log(c, "UPDATE", "ROLE",
		fmt.Sprintf("分配角色：用户 %s → 角色 %s", username, roleName), userID.String(), username)

	middleware.InvalidateUserPermissionCache(userID.String())
	models.Send(c, 200, 0, "Role assigned", nil)
}

// RemoveRole 从用户移除角色
func (h *UserHandler) RemoveRole(c *gin.Context) {
	userID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid user ID")
		return
	}

	var req struct {
		RoleID string `json:"roleId" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		// Also accept roleId from path when present.
		if rid := strings.TrimSpace(c.Param("roleId")); rid != "" {
			req.RoleID = rid
		} else {
			models.SendError(c, 400, 1001, "Invalid request")
			return
		}
	}

	roleID, err := uuid.Parse(req.RoleID)
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid role ID")
		return
	}
	if h.denyNonAdminManageAdminUser(c, userID) {
		return
	}

	// 获取用户和角色信息
	user, _ := h.repo.Get(c.Request.Context(), userID)
	role, _ := h.repo.GetRoleByID(c.Request.Context(), roleID)

	if err := h.repo.RemoveRoleFromUser(c.Request.Context(), userID, roleID); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// ✅ 记录操作日志
	roleName := ""
	if role != nil {
		roleName = role.Name
	}
	username := ""
	if user != nil {
		username = user.Username
	}
	Log(c, "UPDATE", "ROLE",
		fmt.Sprintf("移除角色：用户 %s ← 角色 %s", username, roleName), userID.String(), username)

	middleware.InvalidateUserPermissionCache(userID.String())
	models.Send(c, 200, 0, "Role removed", nil)
}
package services

import (
	"context"
	"errors"
	"fmt"
	"html"
	"math"
	"strings"
	"time"

	"github.com/google/uuid"
)

var tgActivityEN = map[string]string{
	"吃饭":     "Meal break",
	"大厕":     "Restroom (long)",
	"小厕":     "Restroom (short)",
	"抽烟或休息": "Smoke / break",
	"抽烟":     "Smoke break",
}

func tgActivityDisplayName(name string, mode TgLangMode) string {
	name = strings.TrimSpace(name)
	if name == "" {
		return name
	}
	switch mode {
	case TgLangVi:
		if v := strings.TrimSpace(tgActivityVI[name]); v != "" {
			return v
		}
	case TgLangEn:
		if v := strings.TrimSpace(tgActivityEN[name]); v != "" {
			return v
		}
	}
	return name
}

func activityGroupNotifyPrefix(source string, mode TgLangMode) string {
	switch strings.ToLower(strings.TrimSpace(source)) {
	case PunchSourceAgent:
		return tgReplyLabel("💻 <b>PC客户端打卡</b>\n", "💻 <b>Chấm công PC</b>\n", "💻 <b>PC clock-in</b>\n", mode)
	case PunchSourceWeb:
		return tgReplyLabel("🖥 <b>后台打卡</b>\n", "🖥 <b>Chấm công admin</b>\n", "🖥 <b>Admin clock-in</b>\n", mode)
	default:
		return ""
	}
}

func buildActivityStartMessageText(mode TgLangMode, activity, workShift string, limitMin, count, maxTimes int) string {
	maxStr := tgReplyUnlimitedLabel(mode)
	if maxTimes > 0 {
		maxStr = fmt.Sprintf("%d", maxTimes)
	}
	act := tgActivityDisplayName(activity, mode)
	shiftText := tgReplyShiftLabel(workShift, mode)
	return fmt.Sprintf(
		tgReplyLabel(
			"✅ 打卡成功：%s\n📊 班次：%s\n⏰ 时限：%d 分钟\n📈 今日次数：第 %d 次（上限 %s 次）\n\n💡 结束后请点击「回座」按钮",
			"✅ Chấm công: %s\n📊 Ca: %s\n⏰ Giới hạn: %d phút\n📈 Hôm nay: lần %d (tối đa %s)\n\n💡 Xong bấm «Trở lại chỗ ngồi»",
			"✅ Activity: %s\n📊 Shift: %s\n⏰ Limit: %d min\n📈 Today: #%d (max %s)\n\n💡 Tap Back to seat when done",
			mode,
		), act, shiftText, limitMin, count, maxStr)
}

func attendanceReviewPendingHint(kind string, mode TgLangMode) string {
	switch kind {
	case "late":
		return tgReplyLabel(
			"⚠️ 迟到超过阈值，已进入【罚款详情-待确认】，未确认前不记罚款。",
			"⚠️ Đi muộn vượt ngưỡng, đã vào [Phạt-Chờ xác nhận], chưa ghi phạt trước khi xác nhận.",
			"⚠️ Late beyond threshold — pending fine review; no fine until confirmed.",
			mode,
		)
	case "early":
		return tgReplyLabel(
			"⚠️ 早退超过阈值，已进入【罚款详情-待确认】，未确认前不记罚款。",
			"⚠️ Về sớm vượt ngưỡng, đã vào [Phạt-Chờ xác nhận], chưa ghi phạt trước khi xác nhận.",
			"⚠️ Early leave beyond threshold — pending fine review; no fine until confirmed.",
			mode,
		)
	default:
		return tgReplyLabel(
			"⚠️ 已进入【罚款详情-待确认】，未确认前不记罚款。",
			"⚠️ Đã vào [Phạt-Chờ xác nhận], chưa ghi phạt trước khi xác nhận.",
			"⚠️ Pending fine review — no fine until confirmed.",
			mode,
		)
	}
}

func (s *WorkforceTelegramService) handoverStatusHint(ctx context.Context, chatID string, period *TgPeriodInfo, mode TgLangMode) string {
	if period == nil || !period.IsHandover {
		return ""
	}
	cfg, _ := s.GetHandoverConfig(ctx, chatID)
	threshold := handoverThreshold(cfg)
	if period.Cycle == 1 {
		remaining := math.Max(0, threshold-period.HoursElapsed)
		return fmt.Sprintf(
			tgReplyLabel(
				"🔄 换班日（%.0f小时制）· 第1段 · 约 %.1fh 后活动次数重置",
				"🔄 Ngày giao ca (%.0fh) · Đoạn 1 · Reset số lần sau ~%.1fh",
				"🔄 Handover day (%.0fh) · Segment 1 · Activity count resets in ~%.1fh",
				mode,
			), period.TotalHours, remaining)
	}
	return fmt.Sprintf(
		tgReplyLabel(
			"🔄 换班日（%.0f小时制）· 第2段 · 活动次数已重置",
			"🔄 Ngày giao ca (%.0fh) · Đoạn 2 · Đã reset số lần hoạt động",
			"🔄 Handover day (%.0fh) · Segment 2 · Activity count reset",
			mode,
		), period.TotalHours)
}

func (s *WorkforceTelegramService) buildRelaySuccessorHintAfterCheckIn(
	ctx context.Context, empID uuid.UUID, chatID, shift, recordDate string, now time.Time, mode TgLangMode,
) string {
	if shift != "day" {
		return ""
	}
	pending, err := s.getPendingWorkEndShift(ctx, chatID, empID)
	if err != nil || pending == nil || pending.Shift != "day" || pending.RecordDate >= recordDate {
		return ""
	}
	cfg, _ := s.GetHandoverConfig(ctx, chatID)
	settings, _ := s.GetSettings(ctx)
	loc := tgLoadLocation("")
	if settings != nil {
		loc = tgLoadLocation(settings.Timezone)
	}
	if !isHandoverRelaySuccessor(shift, recordDate, pending.Shift, pending.RecordDate, cfg, loc) {
		return ""
	}
	s.upsertRelaySuccessor(ctx, chatID, empID, pending.RecordDate, recordDate)
	dayStart := "15:00"
	if cfg != nil && strings.TrimSpace(cfg.HandoverDayStartTime) != "" {
		dayStart = cfg.HandoverDayStartTime
	}
	return fmt.Sprintf(
		tgReplyLabel(
			"\n🔄 换班接班\n• 已记录 %s 白班上班\n• 此后活动归属本班次\n• 下次「下班」将结束换班白班（%s %s 起）",
			"\n🔄 Nhận ca giao\n• Đã ghi %s ca ngày\n• Hoạt động sau thuộc ca này\n• «Tan ca» lần tới kết thúc ca giao (%s từ %s)",
			"\n🔄 Handover takeover\n• Recorded %s day shift clock-in\n• Later activities belong to this shift\n• Next clock-out ends handover day shift (from %s %s)",
			mode,
		), recordDate, pending.RecordDate, dayStart)
}

func (s *WorkforceTelegramService) buildRelayCheckoutHint(
	ctx context.Context, chatID string, empID uuid.UUID, shift, recordDate string, now time.Time, mode TgLangMode,
) string {
	cfg, _ := s.GetHandoverConfig(ctx, chatID)
	settings, _ := s.GetSettings(ctx)
	loc := tgLoadLocation("")
	if settings != nil {
		loc = tgLoadLocation(settings.Timezone)
	}
	if shift != "day" || !s.recordDateIsHandoverDay(ctx, chatID, recordDate, loc) {
		return ""
	}
	s.clearRelaySuccessor(ctx, chatID, empID)
	remaining, _ := s.getPendingWorkEndShift(ctx, chatID, empID)
	remainText := ""
	if remaining != nil {
		remainText = fmt.Sprintf(
			tgReplyLabel(
				"\n• 当前在岗：%s %s",
				"\n• Đang làm: %s %s",
				"\n• On shift: %s %s",
				mode,
			), remaining.RecordDate, tgReplyShiftLabel(remaining.Shift, mode))
	}
	startTime := "15:00"
	if cfg != nil && strings.TrimSpace(cfg.HandoverDayStartTime) != "" {
		startTime = cfg.HandoverDayStartTime
	}
	return fmt.Sprintf(
		tgReplyLabel(
			"🔄 换班白班已结束（%s %s 起）%s\n• 之后按正常流程打卡即可",
			"🔄 Ca giao ngày đã kết thúc (từ %s %s)%s\n• Tiếp tục chấm công bình thường",
			"🔄 Handover day shift ended (from %s %s)%s\n• Continue with normal punch flow",
			mode,
		), recordDate, startTime, remainText)
}

func (s *WorkforceTelegramService) buildCrossShiftActivityWarn(
	ctx context.Context, empID uuid.UUID, closingShift, recordDate string, mode TgLangMode,
) string {
	sess, err := s.getOpenActivitySession(ctx, empID)
	if errors.Is(err, ErrActivityNotActive) || err != nil {
		return ""
	}
	var actShift string
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day') FROM wf_tg_activity_sessions WHERE id = $1`, sess.ID).Scan(&actShift)
	if actShift == closingShift && sess.AttendanceDate == recordDate {
		return ""
	}
	actName := tgActivityDisplayName(sess.ActivityName, mode)
	shiftName := tgReplyShiftLabel(actShift, mode)
	return fmt.Sprintf(
		tgReplyLabel(
			"⚠️ 活动「%s」仍在进行（%s），请手动回座",
			"⚠️ Hoạt động «%s» vẫn đang diễn ra (%s), vui lòng trở lại",
			"⚠️ Activity \"%s\" still open (%s) — please return manually",
			mode,
		), actName, shiftName)
}

func appendLocalizedActivityWarnHTML(msg, activityWarn string, mode TgLangMode) string {
	warn := strings.TrimSpace(activityWarn)
	if warn == "" {
		return msg
	}
	prefix := tgReplyLabel("🔄 ", "🔄 ", "🔄 ", mode)
	return msg + "\n\n" + prefix + html.EscapeString(warn)
}

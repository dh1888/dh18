package services

import (
	"encoding/json"
	"testing"
)

func TestMapLookupBoolTripleShift(t *testing.T) {
	cases := []struct {
		name string
		in   map[string]interface{}
		want bool
		ok   bool
	}{
		{"bool true", map[string]interface{}{"tripleShiftEnabled": true}, true, true},
		{"bool false", map[string]interface{}{"tripleShiftEnabled": false}, false, true},
		{"float 1", map[string]interface{}{"tripleShiftEnabled": float64(1)}, true, true},
		{"string true", map[string]interface{}{"tripleShiftEnabled": "true"}, true, true},
		{"snake_case", map[string]interface{}{"triple_shift_enabled": true}, true, true},
		{"missing", map[string]interface{}{}, false, false},
	}
	for _, tc := range cases {
		got, ok := mapLookupBool(tc.in, "tripleShiftEnabled", "triple_shift_enabled")
		if ok != tc.ok || got != tc.want {
			t.Fatalf("%s: got=(%v,%v) want=(%v,%v)", tc.name, got, ok, tc.want, tc.ok)
		}
	}
	// Simulate encoding/json into map[string]interface{}
	var m map[string]interface{}
	if err := json.Unmarshal([]byte(`{"tripleShiftEnabled":true}`), &m); err != nil {
		t.Fatal(err)
	}
	got, ok := mapLookupBool(m, "tripleShiftEnabled")
	if !ok || !got {
		t.Fatalf("json bool: got=(%v,%v)", got, ok)
	}
}

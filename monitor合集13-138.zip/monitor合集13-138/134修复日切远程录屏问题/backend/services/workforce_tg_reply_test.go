package services

import (
	"strings"
	"testing"
)

func TestTgReplyDashedLineIsCopyableAndCompact(t *testing.T) {
	got := tgReplyDashedLine()
	if !strings.HasPrefix(got, "<code>") || !strings.HasSuffix(got, "</code>") {
		t.Fatalf("divider must be wrapped in <code> for tap-to-copy, got %q", got)
	}
	inner := strings.TrimSuffix(strings.TrimPrefix(got, "<code>"), "</code>")
	if strings.Contains(inner, "─") {
		t.Fatal("divider must not use fullwidth box-drawing bars on small screens")
	}
	if !strings.Contains(inner, "-") {
		t.Fatal("divider must look dashed")
	}
	if strings.Contains(inner, " ") {
		t.Fatalf("divider should be dense without spaces: %q", inner)
	}
	if n := strings.Count(inner, "-"); n != 26 {
		t.Fatalf("divider should be 26 dashes to fill the bubble, got %d in %q", n, inner)
	}
}

func TestFormatEmployeeNameHTML(t *testing.T) {
	got := formatEmployeeNameHTML(12345, "张三")
	if got != `<a href="tg://user?id=12345">张三</a>` {
		t.Fatalf("expected TG profile link, got %q", got)
	}
	plain := formatEmployeeNameHTML(0, "张三")
	if plain != "张三" {
		t.Fatalf("unbound name should stay plain, got %q", plain)
	}
	if strings.Contains(plain, "tg://user") {
		t.Fatal("must not emit a TG link without user id")
	}
	escaped := formatEmployeeNameHTML(0, `<b>x</b>`)
	if escaped != "&lt;b&gt;x&lt;/b&gt;" {
		t.Fatalf("plain name must be escaped, got %q", escaped)
	}
	named := formatEmployeeProfileHTML(12345, "dhpg_user", "DHPG")
	if named != `<a href="tg://user?id=12345">DHPG</a>` {
		t.Fatalf("username must not use t.me card link, got %q", named)
	}
	userOnly := formatEmployeeProfileHTML(0, "dhpg_user", "DHPG")
	if strings.Contains(userOnly, "t.me/") || strings.Contains(userOnly, "tg://user") {
		t.Fatalf("no numeric id must stay plain without card link, got %q", userOnly)
	}
}

func TestBuildActivitySoonTimeoutHTMLUsesPreferredLang(t *testing.T) {
	zh := buildActivitySoonTimeoutHTML(TgLangZh, 1, "DHPG", "小厕", "夜班")
	if !strings.Contains(zh, "即将超时警告") || !strings.Contains(zh, "小厕") {
		t.Fatalf("zh warning missing chinese copy, got %q", zh)
	}
	vi := buildActivitySoonTimeoutHTML(TgLangVi, 1, "DHPG", "小厕", "Ca đêm")
	if strings.Contains(vi, "即将超时警告") {
		t.Fatalf("vi warning should not stay chinese, got %q", vi)
	}
	if !strings.Contains(vi, "Cảnh báo sắp quá giờ") || !strings.Contains(vi, "Nhà vệ sinh nhỏ") {
		t.Fatalf("vi warning missing vietnamese copy, got %q", vi)
	}
	kb := inlineQuickBackKeyboard("sess", TgLangVi)
	rows, _ := kb["inline_keyboard"].([][]map[string]interface{})
	if len(rows) == 0 || len(rows[0]) == 0 {
		t.Fatalf("expected back button, got %#v", kb)
	}
	if rows[0][0]["text"] != "Trở lại chỗ ngồi" {
		t.Fatalf("vi back button text = %#v", rows[0][0]["text"])
	}
}

func TestTgCopyableText(t *testing.T) {
	if got := tgCopyableText("¥50.00"); got != "<code>¥50.00</code>" {
		t.Fatalf("got %q", got)
	}
	if got := tgCopyableText("  "); got != "<code>-</code>" {
		t.Fatalf("empty should fall back to dash, got %q", got)
	}
}

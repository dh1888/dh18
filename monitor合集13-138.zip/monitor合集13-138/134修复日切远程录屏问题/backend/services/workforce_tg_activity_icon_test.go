package services

import "testing"

func TestActivityKeyboardIconLabels(t *testing.T) {
	label := tgActivityKeyboardLabel("小厕", TgLangZh)
	if label != "🚾 小厕" {
		t.Fatalf("expected swapped 小厕 icon, got %q", label)
	}
	if got := tgActivityKeyboardLabel("大厕", TgLangZh); got != "🚽 大厕" {
		t.Fatalf("expected swapped 大厕 icon, got %q", got)
	}
	lookup := map[string]string{}
	tgRegisterLookup(lookup, "小厕", tgActivityKeyboardLabel("小厕", TgLangZh))
	if lookup["🚾 小厕"] != "小厕" {
		t.Fatalf("lookup mismatch: %v", lookup)
	}
}

func TestStripActivityKeyboardPrefix(t *testing.T) {
	if got := stripActivityKeyboardPrefix("🚾 小厕"); got != "小厕" {
		t.Fatalf("strip new 小厕 icon failed: %q", got)
	}
	if got := stripActivityKeyboardPrefix("🚽 小厕"); got != "小厕" {
		t.Fatalf("strip legacy 小厕 icon failed: %q", got)
	}
	if got := stripActivityKeyboardPrefix("小厕"); got != "小厕" {
		t.Fatalf("plain name changed: %q", got)
	}
}

func TestResolveActivityTypeByIconLabel(t *testing.T) {
	// Ensures API/agent paths still resolve when only icon+name text is used.
	if got := canonicalActivityTypeCode("🍱 吃饭"); got != "eat" {
		t.Fatalf("expected eat, got %q", got)
	}
}

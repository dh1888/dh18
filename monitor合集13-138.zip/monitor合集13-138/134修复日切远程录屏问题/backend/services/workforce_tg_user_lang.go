package services

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
)

// GetReplyLangForUser returns zh/vi/en for group punch reply HTML.
// Users without /lang default to Chinese.
func (s *WorkforceTelegramService) GetReplyLangForUser(ctx context.Context, telegramUserID int64) TgLangMode {
	if telegramUserID <= 0 {
		return TgLangZh
	}
	var lang sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT preferred_lang FROM wf_tg_user_lang_prefs WHERE telegram_user_id = $1`, telegramUserID).
		Scan(&lang)
	if err != nil || !lang.Valid {
		return TgLangZh
	}
	switch normalizeTgLangMode(lang.String) {
	case TgLangVi:
		return TgLangVi
	case TgLangEn:
		return TgLangEn
	default:
		return TgLangZh
	}
}

// keyboardLangForUser uses personal /lang when set; otherwise the group/bot UI language.
func (s *WorkforceTelegramService) keyboardLangForUser(ctx context.Context, chatID string, telegramUserID int64) TgLangMode {
	if telegramUserID <= 0 {
		return s.GetLangMode(ctx, chatID)
	}
	var lang sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT preferred_lang FROM wf_tg_user_lang_prefs WHERE telegram_user_id = $1`, telegramUserID).
		Scan(&lang)
	if err != nil || !lang.Valid || strings.TrimSpace(lang.String) == "" {
		return s.GetLangMode(ctx, chatID)
	}
	return s.GetReplyLangForUser(ctx, telegramUserID)
}

func normalizeUserReplyLang(raw string) (TgLangMode, bool) {
	raw = strings.ToLower(strings.TrimSpace(raw))
	switch raw {
	case "zh", "cn", "chinese", "中文":
		return TgLangZh, true
	case "vi", "vn", "vietnamese", "越南语", "越":
		return TgLangVi, true
	case "en", "english", "英语", "英文", "英":
		return TgLangEn, true
	default:
		return TgLangZh, false
	}
}

// SetUserPreferredLang stores /lang preference for punch reply templates (zh, vi, or en).
func (s *WorkforceTelegramService) SetUserPreferredLang(ctx context.Context, telegramUserID int64, lang string) error {
	if telegramUserID <= 0 {
		return fmt.Errorf("invalid telegram user id")
	}
	mode, ok := normalizeUserReplyLang(lang)
	if !ok {
		return fmt.Errorf("unsupported lang: use zh, vi, or en")
	}
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_user_lang_prefs (telegram_user_id, preferred_lang, updated_at)
		VALUES ($1, $2, NOW())
		ON CONFLICT (telegram_user_id) DO UPDATE SET
			preferred_lang = EXCLUDED.preferred_lang,
			updated_at = NOW()`, telegramUserID, string(mode))
	return err
}

func tgReplyLabel(zh, vi, en string, mode TgLangMode) string {
	switch mode {
	case TgLangVi:
		if strings.TrimSpace(vi) != "" {
			return vi
		}
	case TgLangEn:
		if strings.TrimSpace(en) != "" {
			return en
		}
	}
	return zh
}

func tgReplyShiftLabel(shift string, mode TgLangMode) string {
	switch shift {
	case "night":
		return tgReplyLabel("夜班", "Ca đêm", "Night shift", mode)
	case "middle":
		return tgReplyLabel("中班", "Ca giữa", "Middle shift", mode)
	default:
		return tgReplyLabel("白班", "Ca ngày", "Day shift", mode)
	}
}

func tgReplyUnlimitedLabel(mode TgLangMode) string {
	return tgReplyLabel("不限", "Không giới hạn", "Unlimited", mode)
}

func formatDurationForLang(seconds int, mode TgLangMode) string {
	if seconds <= 0 {
		switch mode {
		case TgLangVi:
			return "0 giây"
		case TgLangEn:
			return "0s"
		default:
			return "0秒"
		}
	}
	m, sec := seconds/60, seconds%60
	h := m / 60
	m = m % 60
	switch mode {
	case TgLangVi:
		if h > 0 {
			return fmt.Sprintf("%d giờ %d phút %d giây", h, m, sec)
		}
		if m > 0 {
			return fmt.Sprintf("%d phút %d giây", m, sec)
		}
		return fmt.Sprintf("%d giây", sec)
	case TgLangEn:
		if h > 0 {
			return fmt.Sprintf("%dh %dm %ds", h, m, sec)
		}
		if m > 0 {
			return fmt.Sprintf("%dm %ds", m, sec)
		}
		return fmt.Sprintf("%ds", sec)
	default:
		if h > 0 {
			return fmt.Sprintf("%d小时%d分%d秒", h, m, sec)
		}
		if m > 0 {
			return fmt.Sprintf("%d分%d秒", m, sec)
		}
		return fmt.Sprintf("%d秒", sec)
	}
}

package services

import (
	"testing"
	"time"
)

func TestIsWithinCheckInWindow(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	start := time.Date(2026, 7, 18, 9, 0, 0, 0, loc)

	if !isWithinCheckInWindow(time.Date(2026, 7, 18, 8, 30, 0, 0, loc), start, 60, 30) {
		t.Fatal("expected 08:30 within 60m before start")
	}
	if isWithinCheckInWindow(time.Date(2026, 7, 18, 7, 50, 0, 0, loc), start, 60, 30) {
		t.Fatal("expected 07:50 outside 60m before start")
	}
	if !isWithinCheckInWindow(time.Date(2026, 7, 18, 9, 20, 0, 0, loc), start, 60, 30) {
		t.Fatal("expected 09:20 within 30m after start")
	}
	if isWithinCheckInWindow(time.Date(2026, 7, 18, 9, 31, 0, 0, loc), start, 60, 30) {
		t.Fatal("expected 09:31 outside 30m after start")
	}
}

func TestMinutesLateUsesLateToleranceOnly(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	expected := time.Date(2026, 7, 18, 9, 0, 0, 0, loc)
	now := time.Date(2026, 7, 18, 9, 20, 0, 0, loc)
	if got := minutesLateFromExpected(now, expected, 15); got != 5 {
		t.Fatalf("late minutes = %d, want 5", got)
	}
}

func TestMinutesLateUsesClockMinuteNotCeil(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	expected := time.Date(2026, 7, 27, 9, 0, 0, 0, loc)
	// 09:01:30 previously Ceil'd to 2 minutes; clock-minute diff must be 1.
	now := time.Date(2026, 7, 27, 9, 1, 30, 0, loc)
	if got := minutesLateFromExpected(now, expected, 0); got != 1 {
		t.Fatalf("late minutes = %d, want 1", got)
	}
	// Still within the same displayed minute as start → not late.
	if got := minutesLateFromExpected(time.Date(2026, 7, 27, 9, 0, 59, 0, loc), expected, 0); got != 0 {
		t.Fatalf("09:00:59 late minutes = %d, want 0", got)
	}
}

func TestMinutesEarlyUsesEarlyLeaveTolerance(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	expected := time.Date(2026, 7, 18, 18, 0, 0, 0, loc)
	now := time.Date(2026, 7, 18, 17, 40, 0, 0, loc)
	if got := minutesEarlyFromExpected(now, expected, 15); got != 5 {
		t.Fatalf("early minutes = %d, want 5", got)
	}
}

func TestMinutesEarlyUsesClockMinuteNotCeil(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	expected := time.Date(2026, 7, 27, 18, 0, 0, 0, loc)
	// Allowed earliest without early = 18:00; leave at 17:58:40 → 2 clock minutes early.
	now := time.Date(2026, 7, 27, 17, 58, 40, 0, loc)
	if got := minutesEarlyFromExpected(now, expected, 0); got != 2 {
		t.Fatalf("early minutes = %d, want 2", got)
	}
}

func TestDefaultLateAndEarlyLeaveTolerance(t *testing.T) {
	if defaultLateTolerance != 0 {
		t.Fatalf("default late tolerance = %d, want 0", defaultLateTolerance)
	}
	if defaultEarlyLeaveTolerance != 10 {
		t.Fatalf("default early leave tolerance = %d, want 10", defaultEarlyLeaveTolerance)
	}
}

package services

import (
	"context"
	"fmt"

	"github.com/google/uuid"
)

// RevokeDeviceSessions revokes all device sessions (SSOT) and sets force-offline latch.
func RevokeDeviceSessions(ctx context.Context, repo *DeviceRepository, sessionSvc *SessionService, deviceID uuid.UUID) error {
	if sessionSvc == nil {
		return fmt.Errorf("session service unavailable")
	}
	if err := sessionSvc.RevokeSubjectRefreshTokens(ctx, SessionSubjectDevice, deviceID, "admin_force_offline"); err != nil {
		return err
	}
	if repo == nil {
		return fmt.Errorf("device repository unavailable")
	}
	return repo.SetForceOfflined(ctx, deviceID)
}

func ClearDeviceForceOffline(ctx context.Context, repo *DeviceRepository, deviceID string) {
	if repo == nil {
		return
	}
	_ = repo.ClearForceOfflined(ctx, deviceID)
}

func IsDeviceForceOfflineBlocked(ctx context.Context, repo *DeviceRepository, deviceID string) bool {
	if repo == nil {
		return false
	}
	return repo.IsForceOfflined(ctx, deviceID)
}

// AllowDeviceReregister clears the force-offline latch so the same device may register again.
// Existing sessions stay revoked; the client must re-register / re-login to get new tokens.
func AllowDeviceReregister(ctx context.Context, repo *DeviceRepository, deviceID string) error {
	if repo == nil {
		return fmt.Errorf("device repository unavailable")
	}
	return repo.ClearForceOfflined(ctx, deviceID)
}

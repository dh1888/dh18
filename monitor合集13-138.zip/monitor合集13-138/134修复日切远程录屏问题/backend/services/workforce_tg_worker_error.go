package services

import (
	"errors"
	"fmt"
	"strings"
)

type outsideWorkWindowError struct {
	Action string
	Shift  string
	Clock  string
}

func (e *outsideWorkWindowError) Error() string {
	if e == nil {
		return ErrOutsideWorkWindow.Error()
	}
	shift := shiftLabel(e.Shift)
	if e.Action == "checkout" {
		return fmt.Sprintf("当前不在%s签退窗口，请在 %s 前后（含宽容）内打下班卡", shift, e.Clock)
	}
	return fmt.Sprintf("当前不在%s上班窗口，请在 %s 前后（含宽容）内打%s卡", shift, e.Clock, shift)
}

func (e *outsideWorkWindowError) Unwrap() error { return ErrOutsideWorkWindow }

type otherWorkSessionStillOpenError struct {
	Shift  string
	Detail string
	Date   string
}

func (e *otherWorkSessionStillOpenError) Error() string {
	if e == nil {
		return ErrOtherWorkSessionOpen.Error()
	}
	return fmt.Sprintf("%s：请先下班当前%s%s（%s）", ErrOtherWorkSessionOpen.Error(), shiftLabel(e.Shift), shiftDetailLabel(e.Detail), e.Date)
}

func (e *otherWorkSessionStillOpenError) Unwrap() error { return ErrOtherWorkSessionOpen }

func warnLabel(zh, vi, en string, mode TgLangMode) string {
	return "⚠️ " + tgReplyLabel(zh, vi, en, mode)
}

func failLabel(zh, vi, en string, mode TgLangMode) string {
	return "❌ " + tgReplyLabel(zh, vi, en, mode)
}

func shiftDetailLabelForLang(detail string, mode TgLangMode) string {
	switch strings.TrimSpace(detail) {
	case "night_last":
		return tgReplyLabel("（昨晚夜班）", "（ca đêm hôm qua）", " (last night)", mode)
	case "night_tonight":
		return tgReplyLabel("（今晚夜班）", "（ca đêm nay）", " (tonight)", mode)
	case "middle_prev":
		return tgReplyLabel("（昨日中班）", "（ca giữa hôm qua）", " (yesterday middle)", mode)
	case "middle_today":
		return tgReplyLabel("（今日中班）", "（ca giữa hôm nay）", " (today middle)", mode)
	default:
		return ""
	}
}

// TelegramWorkerErrorHTTP maps punch/activity errors to API status and business code.
func TelegramWorkerErrorHTTP(err error) (status, code int) {
	switch {
	case errors.Is(err, ErrTelegramDisabled), errors.Is(err, ErrWebPunchOnlyMode),
		errors.Is(err, ErrActivityTypeDisabled):
		return 403, 1003
	case errors.Is(err, ErrTelegramNotBound), errors.Is(err, ErrNoOpenSession),
		errors.Is(err, ErrActivityNotActive), errors.Is(err, ErrActivityTypeNotFound):
		return 404, 2001
	case errors.Is(err, ErrSessionExists), errors.Is(err, ErrWorkSessionOpenOnPC),
		errors.Is(err, ErrWorkSessionOpenOnTG), errors.Is(err, ErrActivityAlreadyActive),
		errors.Is(err, ErrOpenActivityBlocksCheckout), errors.Is(err, ErrActivityLimitReached),
		errors.Is(err, ErrShiftAlreadyCompleted), errors.Is(err, ErrTelegramBoundToWorkstation),
		errors.Is(err, ErrTelegramBoundToPersonal), errors.Is(err, ErrDeviceTelegramAlreadyBound),
		errors.Is(err, ErrTelegramAlreadyBound), errors.Is(err, ErrActivityConcurrentLimit),
		errors.Is(err, ErrOtherWorkSessionOpen):
		return 409, 1004
	case errors.Is(err, ErrBackProcessing), errors.Is(err, ErrOperationBusy):
		return 429, 1005
	case errors.Is(err, ErrActivityBackNotOwner):
		return 403, 1006
	case errors.Is(err, ErrActivityNotInWork), errors.Is(err, ErrOutsideWorkWindow),
		errors.Is(err, ErrDualShiftDisabled), errors.Is(err, ErrPCLoginRequired),
		errors.Is(err, ErrWorkstationDeviceRequired), errors.Is(err, ErrWorkstationDeviceNotBound),
		errors.Is(err, ErrMultipleWorkstationLogins), errors.Is(err, ErrPCLoginMismatch),
		errors.Is(err, ErrCredentialsEmployeeMismatch), errors.Is(err, ErrWorkstationNotConfigured),
		errors.Is(err, ErrWorkstationInviteMismatch), errors.Is(err, ErrInvalidCredentials),
		errors.Is(err, ErrInviteNotFound), errors.Is(err, ErrInviteExpired),
		errors.Is(err, ErrInviteRevoked):
		return 400, 1001
	default:
		return 500, 5000
	}
}

func FormatTelegramActivityBackNotOwner(name string, mode TgLangMode) string {
	if strings.TrimSpace(name) == "" {
		name = tgReplyLabel("该用户", "Người dùng này", "This user", mode)
	}
	return fmt.Sprintf(
		tgReplyLabel("%s，这不是您的活动按钮", "%s, đây không phải nút hoạt động của bạn", "%s, this is not your activity button", mode),
		name,
	)
}

// FormatTelegramWorkerError returns the user-facing punch/activity error in zh/vi/en.
func FormatTelegramWorkerError(err error, mode TgLangMode) string {
	if err == nil {
		return ""
	}
	var window *outsideWorkWindowError
	if errors.As(err, &window) && window != nil {
		shift := tgReplyShiftLabel(window.Shift, mode)
		clock := strings.TrimSpace(window.Clock)
		if window.Action == "checkout" {
			return fmt.Sprintf(
				tgReplyLabel(
					"⚠️ 当前不在%s签退窗口，请在 %s 前后（含宽容）内打下班卡",
					"⚠️ Hiện không trong khung tan ca %s, hãy chấm tan ca quanh %s (đã gồm dung sai)",
					"⚠️ Not in the %s clock-out window. Clock out around %s (including grace)",
					mode,
				), shift, clock)
		}
		return fmt.Sprintf(
			tgReplyLabel(
				"⚠️ 当前不在%s上班窗口，请在 %s 前后（含宽容）内打%s卡",
				"⚠️ Hiện không trong khung đi làm %s, hãy chấm công quanh %s",
				"⚠️ Not in the %s clock-in window. Clock in around %s",
				mode,
			), shift, clock, shift)
	}
	var other *otherWorkSessionStillOpenError
	if errors.As(err, &other) && other != nil {
		return fmt.Sprintf(
			tgReplyLabel(
				"⚠️ 请先下班当前%s%s（%s）",
				"⚠️ Hãy tan ca ca hiện tại %s%s (%s) trước",
				"⚠️ Please clock out the current %s%s (%s) first",
				mode,
			), tgReplyShiftLabel(other.Shift, mode), shiftDetailLabelForLang(other.Detail, mode), other.Date)
	}

	switch {
	case errors.Is(err, ErrTelegramDisabled):
		return warnLabel("Telegram 考勤未启用", "Chấm công Telegram chưa bật", "Telegram attendance is disabled", mode)
	case errors.Is(err, ErrWebPunchOnlyMode):
		return warnLabel("当前为仅后台打卡模式，请使用网页端打卡", "Hiện chỉ cho phép chấm công trên web", "Web-only punch mode — use the web console", mode)
	case errors.Is(err, ErrTelegramNotBound):
		return warnLabel(
			"未绑定。个人 TG：/bind 邀请码 或 /bind 账号；多设备工位：/bind_multi 账号 或 /bind_multi 邀请码；单设备工位：/bind_workstation 邀请码",
			"Chưa gắn. Cá nhân: /bind mã mời hoặc /bind tài khoản; nhiều máy: /bind_multi; một máy: /bind_workstation",
			"Not bound. Personal: /bind invite or /bind account; multi-PC: /bind_multi; single PC: /bind_workstation",
			mode,
		)
	case errors.Is(err, ErrSessionExists):
		return warnLabel("已在上班状态", "Bạn đã đang đi làm", "You are already clocked in", mode)
	case errors.Is(err, ErrWorkSessionOpenOnPC):
		return warnLabel("PC 客户端已上班，请先在客户端下班", "PC đã đi làm, hãy tan ca trên máy trước", "PC client is clocked in — clock out there first", mode)
	case errors.Is(err, ErrWorkSessionOpenOnTG):
		return warnLabel("Telegram 已上班，请先在群内下班", "Telegram đã đi làm, hãy tan ca trong nhóm trước", "Telegram is clocked in — clock out in the group first", mode)
	case errors.Is(err, ErrNoOpenSession):
		return warnLabel("当前没有进行中的上班会话", "Hiện không có ca đang làm", "No open work session", mode)
	case errors.Is(err, ErrActivityNotInWork):
		return warnLabel("请先上班后再开始活动", "Hãy đi làm trước khi bắt đầu hoạt động", "Please clock in before starting an activity", mode)
	case errors.Is(err, ErrActivityAlreadyActive):
		return warnLabel("已有进行中的活动，请先结束", "Đã có hoạt động đang diễn ra, hãy kết thúc trước", "An activity is already in progress — end it first", mode)
	case errors.Is(err, ErrOpenActivityBlocksCheckout):
		return warnLabel("请先回座结束活动后再下班", "Hãy trở lại chỗ ngồi rồi mới tan ca", "Return to seat before clocking out", mode)
	case errors.Is(err, ErrActivityNotActive):
		return warnLabel("当前没有进行中的活动", "Hiện không có hoạt động đang diễn ra", "No activity in progress", mode)
	case errors.Is(err, ErrActivityLimitReached):
		return warnLabel("今日该活动次数已达上限", "Hôm nay hoạt động này đã đạt giới hạn", "Today's limit for this activity is reached", mode)
	case errors.Is(err, ErrActivityTypeNotFound):
		return failLabel("未知活动类型", "Loại hoạt động không xác định", "Unknown activity type", mode)
	case errors.Is(err, ErrActivityTypeDisabled):
		return warnLabel("该活动已停用", "Hoạt động này đã tắt", "This activity is disabled", mode)
	case errors.Is(err, ErrOutsideWorkWindow):
		return warnLabel("当前不在上班时间段内", "Hiện không trong khung giờ làm việc", "Outside the allowed work window", mode)
	case errors.Is(err, ErrShiftAlreadyCompleted):
		return warnLabel("今天该班次已下班，请明天再上班", "Ca này hôm nay đã tan, hãy đi làm vào ngày mai", "This shift already clocked out today — try tomorrow", mode)
	case errors.Is(err, ErrDualShiftDisabled):
		return warnLabel("双班模式未启用", "Chế độ hai ca chưa bật", "Dual-shift mode is disabled", mode)
	case errors.Is(err, ErrPCLoginRequired):
		return warnLabel("请先在 PC Agent 员工登录后再打卡", "Hãy đăng nhập nhân viên trên PC Agent trước", "Please sign in on the PC agent before punching", mode)
	case errors.Is(err, ErrWorkstationDeviceRequired), errors.Is(err, ErrMultipleWorkstationLogins):
		return warnLabel("多台设备已登录，请重新点击普通打卡按钮并选择设备", "Nhiều thiết bị đã đăng nhập, hãy bấm lại nút chấm công và chọn thiết bị", "Multiple devices are signed in — tap the punch button again and select a device", mode)
	case errors.Is(err, ErrWorkstationDeviceNotBound):
		return warnLabel("未找到该设备绑定，请重新绑定或使用正确的设备按钮", "Không thấy gắn thiết bị này, hãy gắn lại hoặc chọn đúng máy", "Device binding not found — rebind or use the correct device button", mode)
	case errors.Is(err, ErrPCLoginMismatch):
		return warnLabel("PC 当前登录员工与 Telegram 绑定不一致", "Nhân viên đang đăng nhập PC khác với Telegram", "PC signed-in employee does not match this Telegram account", mode)
	case errors.Is(err, ErrCredentialsEmployeeMismatch):
		return warnLabel("账号与邀请码所属员工不一致", "Tài khoản không khớp nhân viên của mã mời", "Account does not match the invite employee", mode)
	case errors.Is(err, ErrWorkstationNotConfigured):
		return warnLabel("该员工未配置共享工位，请先在后台添加工位成员", "Nhân viên chưa có bàn chia sẻ, hãy thêm thành viên ở trang quản trị", "Shared workstation is not configured for this employee", mode)
	case errors.Is(err, ErrTelegramBoundToWorkstation):
		return warnLabel("该 Telegram 已绑定共享工位，请使用 /bind_workstation", "Telegram này đã gắn bàn chia sẻ, dùng /bind_workstation", "This Telegram is bound to a shared workstation — use /bind_workstation", mode)
	case errors.Is(err, ErrTelegramBoundToPersonal):
		return warnLabel("该 Telegram 已绑定个人账号，请使用 /bind", "Telegram này đã gắn tài khoản cá nhân, dùng /bind", "This Telegram is bound to a personal account — use /bind", mode)
	case errors.Is(err, ErrDeviceTelegramAlreadyBound):
		return warnLabel("该工位已绑定其他 Telegram 账号", "Bàn này đã gắn Telegram khác", "This workstation is already bound to another Telegram account", mode)
	case errors.Is(err, ErrWorkstationInviteMismatch):
		return warnLabel("邀请码员工不是该设备的共享工位成员", "Nhân viên mã mời không thuộc bàn chia sẻ của máy này", "Invite employee is not a member of this workstation", mode)
	case errors.Is(err, ErrInvalidCredentials):
		return warnLabel("账号不存在、已停用或密码错误", "Tài khoản không tồn tại, đã khóa hoặc sai mật khẩu", "Account missing, disabled, or password is wrong", mode)
	case errors.Is(err, ErrInviteNotFound):
		return failLabel("邀请码无效", "Mã mời không hợp lệ", "Invalid invite code", mode)
	case errors.Is(err, ErrInviteExpired):
		return warnLabel("邀请码已过期", "Mã mời đã hết hạn", "Invite code expired", mode)
	case errors.Is(err, ErrInviteRevoked):
		return warnLabel("邀请码已撤销", "Mã mời đã bị hủy", "Invite code revoked", mode)
	case errors.Is(err, ErrTelegramAlreadyBound):
		return warnLabel("该 Telegram 账号已绑定其他员工", "Telegram này đã gắn nhân viên khác", "This Telegram account is already bound to another employee", mode)
	case errors.Is(err, ErrActivityConcurrentLimit):
		return warnLabel("该活动并发人数已达上限", "Số người đang làm hoạt động này đã đầy", "This activity's concurrent limit is reached", mode)
	case errors.Is(err, ErrBackProcessing):
		return warnLabel("回座请求处理中，请稍候", "Đang xử lý trở lại, vui lòng đợi", "Return request is already processing", mode)
	case errors.Is(err, ErrOperationBusy):
		return warnLabel("请求处理中，请稍候", "Đang xử lý yêu cầu, vui lòng đợi", "Request is already processing", mode)
	case errors.Is(err, ErrActivityBackNotOwner):
		return warnLabel("这不是您的活动，无法回座", "Đây không phải hoạt động của bạn", "This is not your activity", mode)
	case errors.Is(err, ErrEmployeeNotFound):
		return warnLabel("未找到员工", "Không tìm thấy nhân viên", "Employee not found", mode)
	default:
		msg := strings.TrimSpace(err.Error())
		if msg == "" {
			return failLabel("操作失败", "Thao tác thất bại", "Operation failed", mode)
		}
		if mode == TgLangZh || mode == TgLangBoth {
			return "❌ " + msg
		}
		return failLabel("操作失败", "Thao tác thất bại", "Operation failed", mode) + "\n" + msg
	}
}

package services

import "testing"

func TestBuildTelegramBotCommandMenuOrder(t *testing.T) {
	types := []TgActivityType{
		{Name: "吃饭"},
		{Name: "小厕"},
		{Name: "大厕"},
		{Name: "抽烟或休息"},
	}
	got := buildTelegramBotCommandMenu(types)
	want := []string{
		"checkin_day", "checkin_middle", "checkin_night", "checkout",
		"wc1", "wc2", "smoke", "at",
		"lang_zh", "lang_vi", "lang_en",
		"myinfo", "rankings", "bind", "help", "start",
		"meal", "status",
	}
	if len(got) < len(want) {
		t.Fatalf("got %d commands, want at least %d: %#v", len(got), len(want), commandNames(got))
	}
	for i, cmd := range want {
		if got[i]["command"] != cmd {
			t.Fatalf("pos %d: got %q want %q\nfull=%v", i, got[i]["command"], cmd, commandNames(got))
		}
	}
}

func commandNames(cmds []map[string]string) []string {
	out := make([]string, 0, len(cmds))
	for _, c := range cmds {
		out = append(out, c["command"])
	}
	return out
}

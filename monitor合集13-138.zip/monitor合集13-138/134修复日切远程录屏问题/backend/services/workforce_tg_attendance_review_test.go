package services

import (
	"strings"
	"testing"
)

func TestFormatAdminMentionsHTML(t *testing.T) {
	if got := formatAdminMentionsHTML(nil); got != "" {
		t.Fatalf("empty ids = %q", got)
	}
	if got := formatAdminMentionsHTML([]int64{0, -1}); got != "" {
		t.Fatalf("invalid ids = %q", got)
	}
	got := formatAdminMentionsHTML([]int64{123, 456})
	want := `<a href="tg://user?id=123">管理员</a> <a href="tg://user?id=456">管理员</a>`
	if got != want {
		t.Fatalf("mentions = %q, want %q", got, want)
	}
}

func TestAttendanceReviewConfirmFooterKeepsLegacyWhenNoAdmins(t *testing.T) {
	got := attendanceReviewConfirmFooter("")
	want := "请管理员在【罚款详情】确认：旷工 / 半休 / 半假\n未确认前：不记罚款，不改考勤状态。"
	if got != want {
		t.Fatalf("legacy footer changed: %q", got)
	}
}

func TestAttendanceReviewConfirmFooterMentionsAdmins(t *testing.T) {
	mentions := formatAdminMentionsHTML([]int64{111})
	got := attendanceReviewConfirmFooter(mentions)
	for _, part := range []string{mentions, "请确认", "旷工", "罚款详情", "不记罚款"} {
		if !strings.Contains(got, part) {
			t.Fatalf("footer missing %q: %q", part, got)
		}
	}
}

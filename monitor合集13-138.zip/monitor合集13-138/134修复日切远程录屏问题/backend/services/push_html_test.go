package services

import (
	"strings"
	"testing"
	"time"
)

func TestBuildPenaltyPushHTML(t *testing.T) {
	got := buildPenaltyPushHTML(PenaltyPushRecord{
		Date:         "2026-08-18",
		EmployeeName: "张三",
		Position:     "客服",
		Amount:       50,
		Category:     "迟到",
		Reason:       "上班迟到 15 分钟",
	}, 12345, "", "CNY")
	for _, part := range []string{
		`href="tg://user?id=12345"`,
		"张三",
		"<code>¥50.00</code>",
		"<code>2026-08-18</code>",
		"<code>迟到</code>",
		tgReplyDashedLine(),
		"⚠️",
	} {
		if !strings.Contains(got, part) {
			t.Fatalf("missing %q in:\n%s", part, got)
		}
	}

	named := buildPenaltyPushHTML(PenaltyPushRecord{EmployeeName: "DHPG", Amount: 100}, 12345, "dhpg_user", "CNY")
	if !strings.Contains(named, `href="tg://user?id=12345"`) {
		t.Fatalf("username must use tg://user without t.me card:\n%s", named)
	}
	if strings.Contains(named, "t.me/") {
		t.Fatalf("must not emit t.me card link:\n%s", named)
	}
}

func TestBuildPenaltyPushHTMLUnboundName(t *testing.T) {
	got := buildPenaltyPushHTML(PenaltyPushRecord{
		Date:         "2026-08-18",
		EmployeeName: "李四",
		Amount:       10,
		Category:     "早退",
	}, 0, "", "CNY")
	if strings.Contains(got, "tg://user") || strings.Contains(got, "t.me/") {
		t.Fatalf("unbound employee must not be a TG link:\n%s", got)
	}
	if !strings.Contains(got, "李四") {
		t.Fatalf("plain name missing:\n%s", got)
	}
	if !strings.Contains(got, "<code>¥10.00</code>") {
		t.Fatalf("amount should still be copyable:\n%s", got)
	}
}

func TestBuildPerformancePushHTML(t *testing.T) {
	got := buildPerformancePushHTML(PerformancePushRecord{
		Date:         "2026-08-18",
		EmployeeName: "张三",
		Position:     "客服",
		Score:        2,
		Reason:       "完成额外任务",
	}, 67890, "")
	for _, part := range []string{
		`href="tg://user?id=67890"`,
		"<code>+2分</code>",
		"（加分）",
		"<code>完成额外任务</code>",
		tgReplyDashedLine(),
		"📋",
	} {
		if !strings.Contains(got, part) {
			t.Fatalf("missing %q in:\n%s", part, got)
		}
	}

	deduct := buildPerformancePushHTML(PerformancePushRecord{
		EmployeeName: "张三",
		Score:        -3,
		Reason:       "迟到",
	}, 0, "")
	if !strings.Contains(deduct, "<code>-3分</code>") {
		t.Fatalf("deduct score should be copyable:\n%s", deduct)
	}
	if !strings.Contains(deduct, "扣分") {
		t.Fatalf("deduct label missing:\n%s", deduct)
	}
	if strings.Contains(deduct, "tg://user") {
		t.Fatalf("unbound name must stay plain:\n%s", deduct)
	}

	named := buildPerformancePushHTML(PerformancePushRecord{EmployeeName: "DHPG", Score: 1, Reason: "好"}, 12345, "dhpg_user")
	if !strings.Contains(named, `href="tg://user?id=12345"`) {
		t.Fatalf("performance username must use tg://user:\n%s", named)
	}
	if strings.Contains(named, "t.me/") {
		t.Fatalf("must not emit t.me card link:\n%s", named)
	}
}

func TestBuildActivityOvertimeBackPushHTMLNameLink(t *testing.T) {
	got := buildActivityOvertimeBackPushHTML("DHPG考勤", 12345, "", "DHPG", "小厕", time.Now(), 25, 100, "THB")
	if !strings.Contains(got, `href="tg://user?id=12345"`) {
		t.Fatalf("overtime back name should be TG link:\n%s", got)
	}
	named := buildActivityOvertimeBackPushHTML("DHPG考勤", 12345, "dhpg_user", "DHPG", "小厕", time.Now(), 25, 100, "THB")
	if !strings.Contains(named, `href="tg://user?id=12345"`) {
		t.Fatalf("overtime back username must use tg://user without t.me card:\n%s", named)
	}
	if strings.Contains(named, "t.me/") {
		t.Fatalf("must not emit t.me card link:\n%s", named)
	}
}

package services

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/google/uuid"
)

func StartTelegramActivityTimerScheduler(ctx context.Context, svc *WorkforceTelegramService) {
	if svc == nil {
		return
	}
	go func() {
		ticker := time.NewTicker(15 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				svc.tickActivityTimers(context.Background())
			}
		}
	}()
}

func (s *WorkforceTelegramService) tickActivityTimers(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	s.scanAndCreateAttendanceReviewTasks(ctx)
	forceBackSec := telegramForceBackOvertimeSeconds()
	rows, err := s.db.QueryContext(ctx, `
		SELECT s.id, s.employee_id, s.activity_code, s.activity_name, s.started_at, s.limit_seconds,
			COALESCE(s.source_chat_id,''), e.name, COALESCE(s.shift_type,'day'),
			COALESCE(s.limit_warning_sent, FALSE), COALESCE(s.overtime_immediate_sent, FALSE),
			COALESCE(s.overtime_5min_sent, FALSE), COALESCE(s.last_overtime_reminder_min, -1),
			COALESCE(s.force_back_sent, FALSE)
		FROM wf_tg_activity_sessions s
		JOIN employees e ON e.id = s.employee_id
		WHERE s.status = 'open' AND s.limit_seconds > 0`)
	if err != nil {
		return
	}
	defer rows.Close()
	for rows.Next() {
		var sid, empID uuid.UUID
		var code, name, chatID, empName, shiftType string
		var started time.Time
		var limitSec int
		var warned, ot0, ot5, forceBackSent bool
		var lastReminderMin int
		if rows.Scan(&sid, &empID, &code, &name, &started, &limitSec, &chatID, &empName, &shiftType,
			&warned, &ot0, &ot5, &lastReminderMin, &forceBackSent) != nil {
			continue
		}
		elapsed := int(time.Since(started).Seconds())
		warnAt := limitSec - 60
		if warnAt < 0 {
			warnAt = 0
		}

		if !warned && elapsed >= warnAt && elapsed < limitSec {
			_, _ = s.db.ExecContext(ctx, `UPDATE wf_tg_activity_sessions SET limit_warning_sent = TRUE WHERE id = $1`, sid)
			tgUID := s.employeeTelegramUserID(ctx, empID)
			mode := s.GetReplyLangForUser(ctx, tgUID)
			groupHTML := buildActivitySoonTimeoutHTML(mode, tgUID, empName, name, tgReplyShiftLabel(shiftType, mode))
			// 即将超时：打卡群 + 员工私信 + PC 客户端
			s.sendActivityTimerHTML(ctx, chatID, empID, sid, groupHTML, true, mode)
			s.syncAgentActivityNotify(empID, empName, name, "即将超时",
				fmt.Sprintf("班次：%s", shiftLabel(shiftType)), sid)
			continue
		}

		overtimeSec := elapsed - limitSec
		if overtimeSec < 0 {
			continue
		}

		if overtimeSec >= forceBackSec && !forceBackSent {
			_, _ = s.db.ExecContext(ctx, `UPDATE wf_tg_activity_sessions SET force_back_sent = TRUE WHERE id = $1`, sid)
			sess, err := s.closeActivitySession(ctx, sid, true, "system")
			if err != nil {
				log.Printf("[Telegram] force back activity %s: %v", sid, err)
				continue
			}
			tgUID := s.employeeTelegramUserID(ctx, empID)
			mode := s.GetReplyLangForUser(ctx, tgUID)
			cur := s.FineCurrencyCode(ctx)
			fineText := ""
			if sess.FineAmount > 0 {
				fineText = FormatFineAmountWithUnit(sess.FineAmount, cur)
			}
			msg := buildActivityForceBackHTML(mode, tgUID, empName, name, tgReplyShiftLabel(shiftType, mode), forceBackSec/60, fineText)
			s.sendActivityTimerHTML(ctx, chatID, empID, sid, msg, false, mode)
			userID, username := lookupEmployeeTelegramProfile(ctx, s.db, empID.String(), empName)
			if tgUID > 0 {
				if userID != tgUID {
					username = ""
				}
				userID = tgUID
			}
			pushHTML := buildActivityOvertimeBackPushHTML(s.getChatTitle(ctx, chatID), userID, username, empName, name, time.Now(), overtimeSec, sess.FineAmount, cur)
			s.pushHTMLToChatTargets(ctx, chatID, pushHTML, false)
			extra := fmt.Sprintf("班次：%s\n超时超过 %d 分钟，系统已自动回座", shiftLabel(shiftType), forceBackSec/60)
			if sess.FineAmount > 0 {
				extra += fmt.Sprintf("\n罚款 %s", FormatFineMoney(sess.FineAmount, cur))
			}
			s.syncAgentActivityNotify(empID, empName, name, "自动安全回座", extra, sid)
			continue
		}

		overtimeMin := overtimeSec / 60
		variant := -1
		updateOT0, updateOT5 := false, false
		updateLastMin := lastReminderMin

		if !ot0 && overtimeMin >= 0 {
			variant = 0
			updateOT0 = true
			updateLastMin = 0
		} else if !ot5 && overtimeMin >= 5 {
			variant = 5
			updateOT5 = true
			updateLastMin = 5
		} else if overtimeMin >= 10 && overtimeMin%10 == 0 && overtimeMin != lastReminderMin {
			variant = overtimeMin
			updateLastMin = overtimeMin
		}

		if variant < 0 {
			continue
		}
		tgUID := s.employeeTelegramUserID(ctx, empID)
		mode := s.GetReplyLangForUser(ctx, tgUID)
		pendingHTML := buildActivityOvertimeWarnHTML(mode, tgUID, empName, name, tgReplyShiftLabel(shiftType, mode), overtimeMin, variant)

		if updateOT0 {
			_, _ = s.db.ExecContext(ctx, `UPDATE wf_tg_activity_sessions SET overtime_immediate_sent = TRUE, last_overtime_reminder_min = $2 WHERE id = $1`, sid, updateLastMin)
		} else if updateOT5 {
			_, _ = s.db.ExecContext(ctx, `UPDATE wf_tg_activity_sessions SET overtime_5min_sent = TRUE, last_overtime_reminder_min = $2 WHERE id = $1`, sid, updateLastMin)
		} else {
			_, _ = s.db.ExecContext(ctx, `UPDATE wf_tg_activity_sessions SET last_overtime_reminder_min = $2 WHERE id = $1`, sid, updateLastMin)
		}
		s.sendActivityTimerHTML(ctx, chatID, empID, sid, pendingHTML, true, mode)
		extra := fmt.Sprintf("班次：%s\n已超时 %d 分钟，请立即回座", shiftLabel(shiftType), overtimeMin)
		s.syncAgentActivityNotify(empID, empName, name, "超时警告", extra, sid)
	}
}

func (s *WorkforceTelegramService) employeeTelegramUserID(ctx context.Context, empID uuid.UUID) int64 {
	return lookupEmployeeTelegramUserID(ctx, s.db, empID.String(), "")
}

func (s *WorkforceTelegramService) syncAgentActivityNotify(
	empID uuid.UUID,
	employeeName, activityName, event, extra string,
	sessionID uuid.UUID,
) {
	if s == nil || s.agentNotify == nil {
		return
	}
	s.agentNotify.PushActivityEvent(empID, employeeName, activityName, event, extra, sessionID)
}

func (s *WorkforceTelegramService) sendActivityTimerHTML(ctx context.Context, chatID string, empID, sessionID uuid.UUID, htmlText string, withInlineBack bool, mode TgLangMode) {
	markup := interface{}(nil)
	if withInlineBack {
		markup = inlineQuickBackKeyboard(sessionID.String(), mode)
	}
	replyTo := s.activitySessionTelegramMessageID(ctx, sessionID)
	if strings.TrimSpace(chatID) != "" {
		_ = s.SendTelegramHTMLReply(ctx, chatID, htmlText, replyTo, markup)
	}
	var tgUID int64
	if s.db.QueryRowContext(ctx, `
		SELECT telegram_user_id FROM employee_telegram_bindings WHERE employee_id = $1 AND status = 1 LIMIT 1`, empID).Scan(&tgUID) == nil && tgUID > 0 {
		_ = s.SendTelegramHTML(ctx, fmt.Sprintf("%d", tgUID), htmlText, markup)
	}
}

func (s *WorkforceTelegramService) activitySessionTelegramMessageID(ctx context.Context, sessionID uuid.UUID) int64 {
	var msgID sql.NullInt64
	_ = s.db.QueryRowContext(ctx, `
		SELECT telegram_message_id FROM wf_tg_activity_sessions WHERE id = $1`, sessionID).Scan(&msgID)
	if msgID.Valid && msgID.Int64 > 0 {
		return msgID.Int64
	}
	return 0
}

func (s *WorkforceTelegramService) getChatTitle(ctx context.Context, chatID string) string {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return ""
	}
	var title string
	_ = s.db.QueryRowContext(ctx, `SELECT COALESCE(chat_title,'') FROM wf_tg_groups WHERE chat_id = $1`, chatID).Scan(&title)
	if strings.TrimSpace(title) != "" {
		return title
	}
	_ = s.db.QueryRowContext(ctx, `SELECT COALESCE(chat_title,'') FROM wf_telegram_discovered_chats WHERE chat_id = $1`, chatID).Scan(&title)
	return title
}

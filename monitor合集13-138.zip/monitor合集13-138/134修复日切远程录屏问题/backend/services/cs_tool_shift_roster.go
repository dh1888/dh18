package services

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/google/uuid"
)

const maxShiftRosterJSONBytes = 256 * 1024

type ShiftPerson struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}

type ShiftStation struct {
	ID    string `json:"id"`
	Label string `json:"label"`
	Code  string `json:"code"`
}

type ShiftRow struct {
	ID           string                   `json:"id"`
	Label        string                   `json:"label"`
	Kind         string                   `json:"kind"` // split | span
	ShowAdd      *bool                    `json:"showAdd,omitempty"`
	Cells        map[string][]ShiftPerson `json:"cells,omitempty"`
	People       []ShiftPerson            `json:"people,omitempty"`
	Old          []ShiftPerson            `json:"old,omitempty"`
	New          []ShiftPerson            `json:"new,omitempty"`
	ColSpans     map[string]int           `json:"colSpans,omitempty"`
	RowSpans     map[string]int           `json:"rowSpans,omitempty"`
	LabelRowSpan int                      `json:"labelRowSpan,omitempty"`
}

type ShiftBoard struct {
	ID        string         `json:"id"`
	Title     string         `json:"title"`
	Stations  []ShiftStation `json:"stations,omitempty"`
	OldLabel  string         `json:"oldLabel,omitempty"`
	NewLabel  string         `json:"newLabel,omitempty"`
	OldCode   string         `json:"oldCode,omitempty"`
	NewCode   string         `json:"newCode,omitempty"`
	Rows      []ShiftRow     `json:"rows"`
}

type ShiftRoster struct {
	Shifts    []ShiftBoard  `json:"shifts"`
	NoRotate  []ShiftPerson `json:"noRotate"`
	RuleNote  string        `json:"ruleNote"`
	UpdatedAt string        `json:"updatedAt,omitempty"`
}

func (s *CsToolSettingsService) GetShiftRoster(ctx context.Context) (*ShiftRoster, error) {
	var raw []byte
	var updatedAt time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT payload, updated_at FROM cs_tool_shift_roster WHERE id = 1`).
		Scan(&raw, &updatedAt)
	if err == sql.ErrNoRows {
		out := DefaultShiftRoster()
		return out, nil
	}
	if err != nil {
		return nil, err
	}
	if len(raw) == 0 || strings.TrimSpace(string(raw)) == "" || strings.TrimSpace(string(raw)) == "{}" {
		out := DefaultShiftRoster()
		out.UpdatedAt = updatedAt.UTC().Format(time.RFC3339)
		return out, nil
	}
	out, err := normalizeShiftRoster(raw)
	if err != nil {
		return nil, err
	}
	out.UpdatedAt = updatedAt.UTC().Format(time.RFC3339)
	return out, nil
}

func (s *CsToolSettingsService) SaveShiftRoster(ctx context.Context, in ShiftRoster) (*ShiftRoster, error) {
	normalized, err := sanitizeShiftRoster(in)
	if err != nil {
		return nil, err
	}
	payload, err := json.Marshal(normalized)
	if err != nil {
		return nil, err
	}
	if len(payload) > maxShiftRosterJSONBytes {
		return nil, fmt.Errorf("换班表内容过大")
	}
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO cs_tool_shift_roster (id, payload, updated_at)
		VALUES (1, $1::jsonb, NOW())
		ON CONFLICT (id) DO UPDATE SET
			payload = EXCLUDED.payload,
			updated_at = NOW()`,
		payload)
	if err != nil {
		return nil, err
	}
	return s.GetShiftRoster(ctx)
}

func normalizeShiftRoster(raw []byte) (*ShiftRoster, error) {
	var in ShiftRoster
	if err := json.Unmarshal(raw, &in); err != nil {
		return nil, fmt.Errorf("换班表数据损坏")
	}
	return sanitizeShiftRoster(in)
}

func sanitizeShiftRoster(in ShiftRoster) (*ShiftRoster, error) {
	out := &ShiftRoster{
		Shifts:   make([]ShiftBoard, 0, 2),
		NoRotate: sanitizePeople(in.NoRotate),
		RuleNote: clipRunes(strings.TrimSpace(in.RuleNote), 500),
	}
	if len(in.Shifts) == 0 {
		return DefaultShiftRoster(), nil
	}
	if len(in.Shifts) > 4 {
		return nil, fmt.Errorf("班次数量超出限制")
	}
	for _, board := range in.Shifts {
		clean, err := sanitizeBoard(board)
		if err != nil {
			return nil, err
		}
		out.Shifts = append(out.Shifts, *clean)
	}
	return out, nil
}

func sanitizeBoard(in ShiftBoard) (*ShiftBoard, error) {
	id := strings.TrimSpace(in.ID)
	if id == "" {
		id = uuid.NewString()
	}
	if len(in.Rows) > 30 {
		return nil, fmt.Errorf("岗位行数超出限制")
	}
	stations := sanitizeStations(in)
	if len(stations) > 8 {
		return nil, fmt.Errorf("站点数超出限制")
	}
	out := &ShiftBoard{
		ID:       clipRunes(id, 40),
		Title:    clipRunes(strings.TrimSpace(in.Title), 20),
		Stations: stations,
		Rows:     make([]ShiftRow, 0, len(in.Rows)),
	}
	if out.Title == "" {
		out.Title = "班次"
	}
	if len(stations) > 0 {
		out.OldLabel = stations[0].Label
		out.OldCode = stations[0].Code
	}
	if len(stations) > 1 {
		out.NewLabel = stations[1].Label
		out.NewCode = stations[1].Code
	}
	for _, row := range in.Rows {
		kind := strings.ToLower(strings.TrimSpace(row.Kind))
		if kind != "span" {
			kind = "split"
		}
		rid := strings.TrimSpace(row.ID)
		if rid == "" {
			rid = uuid.NewString()
		}
		clean := ShiftRow{
			ID:           clipRunes(rid, 40),
			Label:        clipRunes(strings.TrimSpace(row.Label), 20),
			Kind:         kind,
			ColSpans:     row.ColSpans,
			RowSpans:     row.RowSpans,
			LabelRowSpan: row.LabelRowSpan,
		}
		if clean.Label == "" {
			clean.Label = "岗位"
		}
		if kind == "span" {
			clean.People = sanitizePeople(row.People)
		} else {
			clean.Cells = sanitizeCells(row)
		}
		out.Rows = append(out.Rows, clean)
	}
	for i := range out.Rows {
		remainRows := len(out.Rows) - i
		remainCols := len(stations)
		if remainCols < 1 {
			remainCols = 1
		}
		row := &out.Rows[i]
		row.ColSpans = sanitizeSpanMap(row.ColSpans, remainCols)
		row.RowSpans = sanitizeSpanMap(row.RowSpans, remainRows)
		if row.Kind == "span" {
			row.ColSpans = nil
		}
		if row.LabelRowSpan < 2 {
			row.LabelRowSpan = 0
		} else if row.LabelRowSpan > remainRows {
			row.LabelRowSpan = remainRows
		}
	}
	return out, nil
}

func sanitizeSpanMap(in map[string]int, max int) map[string]int {
	if len(in) == 0 || max < 2 {
		return nil
	}
	out := map[string]int{}
	for key, val := range in {
		k := clipRunes(strings.TrimSpace(key), 40)
		if k == "" || val < 2 {
			continue
		}
		if val > max {
			val = max
		}
		out[k] = val
	}
	if len(out) == 0 {
		return nil
	}
	return out
}

func sanitizeStations(in ShiftBoard) []ShiftStation {
	if len(in.Stations) > 0 {
		out := make([]ShiftStation, 0, len(in.Stations))
		for _, st := range in.Stations {
			sid := strings.TrimSpace(st.ID)
			if sid == "" {
				sid = uuid.NewString()
			}
			label := clipRunes(strings.TrimSpace(st.Label), 20)
			if label == "" {
				label = "新站"
			}
			out = append(out, ShiftStation{
				ID:    clipRunes(sid, 40),
				Label: label,
				Code:  clipRunes(strings.TrimSpace(st.Code), 80),
			})
		}
		return out
	}
	oldLabel := strings.TrimSpace(in.OldLabel)
	if oldLabel == "" {
		oldLabel = "老站"
	}
	newLabel := strings.TrimSpace(in.NewLabel)
	if newLabel == "" {
		newLabel = "新站"
	}
	return []ShiftStation{
		{ID: "old", Label: clipRunes(oldLabel, 20), Code: clipRunes(strings.TrimSpace(in.OldCode), 80)},
		{ID: "new", Label: clipRunes(newLabel, 20), Code: clipRunes(strings.TrimSpace(in.NewCode), 80)},
	}
}

func sanitizeCells(row ShiftRow) map[string][]ShiftPerson {
	out := map[string][]ShiftPerson{}
	if row.Cells != nil {
		for key, list := range row.Cells {
			k := clipRunes(strings.TrimSpace(key), 40)
			if k == "" {
				continue
			}
			out[k] = sanitizePeople(list)
		}
	}
	if len(out) == 0 {
		if len(row.Old) > 0 {
			out["old"] = sanitizePeople(row.Old)
		}
		if len(row.New) > 0 {
			out["new"] = sanitizePeople(row.New)
		}
	}
	return out
}

func sanitizePeople(list []ShiftPerson) []ShiftPerson {
	out := make([]ShiftPerson, 0, len(list))
	if len(list) > 40 {
		list = list[:40]
	}
	for _, p := range list {
		name := clipRunes(strings.TrimSpace(p.Name), 32)
		if name == "" {
			continue
		}
		id := strings.TrimSpace(p.ID)
		if id == "" {
			id = uuid.NewString()
		}
		out = append(out, ShiftPerson{ID: clipRunes(id, 40), Name: name})
	}
	return out
}

func clipRunes(s string, max int) string {
	if max <= 0 || utf8.RuneCountInString(s) <= max {
		return s
	}
	r := []rune(s)
	return string(r[:max])
}

func emptyPeople() []ShiftPerson {
	return []ShiftPerson{}
}

func emptyCells() map[string][]ShiftPerson {
	return map[string][]ShiftPerson{"old": {}, "new": {}}
}

func defaultBoardRows() []ShiftRow {
	return []ShiftRow{
		{ID: "cs", Label: "客服", Kind: "split", Cells: emptyCells()},
		{ID: "payout", Label: "出款", Kind: "split", Cells: emptyCells()},
		{ID: "audit", Label: "审查", Kind: "split", Cells: emptyCells()},
		{ID: "qc", Label: "质检", Kind: "split", Cells: emptyCells()},
		{ID: "leader", Label: "组长", Kind: "span", People: emptyPeople()},
		{ID: "ops", Label: "运维", Kind: "split", Cells: emptyCells()},
	}
}

func defaultStations(oldCode, newCode string) []ShiftStation {
	return []ShiftStation{
		{ID: "old", Label: "老站", Code: oldCode},
		{ID: "new", Label: "新站", Code: newCode},
	}
}

func DefaultShiftRoster() *ShiftRoster {
	stationOld := "25S-05X-D16-A02-N06-BR8"
	stationNew := "i05-73B-666BR-X06-NA5-Win168"
	return &ShiftRoster{
		Shifts: []ShiftBoard{
			{ID: "night", Title: "夜班", Stations: defaultStations(stationOld, stationNew), Rows: defaultBoardRows()},
			{ID: "day", Title: "白班", Stations: defaultStations(stationOld, stationNew), Rows: defaultBoardRows()},
		},
		NoRotate: emptyPeople(),
		RuleNote: "每月15日换班：夜班转白班、白班转夜班（以当月公布为准）。",
	}
}

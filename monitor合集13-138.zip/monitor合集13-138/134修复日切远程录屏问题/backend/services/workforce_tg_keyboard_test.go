package services

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestLocalizedMainReplyKeyboardIncludesButtonStyles(t *testing.T) {
	kb := localizedMainReplyKeyboard(TgLangBoth, false, false, []string{"小厕", "大厕", "吃饭"})
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(raw, `"style":"success"`, `"style":"danger"`) {
		t.Fatalf("expected success and danger styles in keyboard JSON, got: %s", raw)
	}

	var wrapped struct {
		Code int `json:"code"`
		Data struct {
			ReplyKeyboard map[string]interface{} `json:"replyKeyboard"`
		} `json:"data"`
	}
	wrapped.Code = 0
	wrapped.Data.ReplyKeyboard = kb
	roundTrip, err := json.Marshal(wrapped)
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(roundTrip, &wrapped); err != nil {
		t.Fatal(err)
	}
	telegramPayload := map[string]interface{}{
		"chat_id":      123,
		"text":         "hello",
		"reply_markup": wrapped.Data.ReplyKeyboard,
	}
	final, err := json.Marshal(telegramPayload)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(final, `"style":"success"`, `"style":"danger"`) {
		t.Fatalf("styles lost after round-trip, got: %s", final)
	}
}

func TestLocalizedMainReplyKeyboardDualShiftStyles(t *testing.T) {
	kb := localizedMainReplyKeyboard(TgLangBoth, true, false, []string{"小厕"})
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(raw, `"style":"success"`, `"style":"primary"`, `"style":"danger"`) {
		t.Fatalf("expected success, primary and danger styles, got: %s", raw)
	}
}

func TestLocalizedMainReplyKeyboardBackButtonStyle(t *testing.T) {
	kb := localizedMainReplyKeyboard(TgLangBoth, false, false, []string{"小厕", "大厕", "抽烟或休息", "吃饭"})
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	successCount := countSubstring(string(raw), `"style":"success"`)
	if successCount < 2 {
		t.Fatalf("expected at least 2 success styles (checkin + back), got %d in: %s", successCount, raw)
	}
}

func TestEnrichReplyKeyboardStylesAfterRoundTrip(t *testing.T) {
	kb := localizedMainReplyKeyboard(TgLangBoth, false, false, []string{"小厕", "大厕", "吃饭"})
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	var roundTrip map[string]interface{}
	if err := json.Unmarshal(raw, &roundTrip); err != nil {
		t.Fatal(err)
	}
	if rows, ok := roundTrip["keyboard"].([]interface{}); ok && len(rows) > 0 {
		if firstRow, ok := rows[0].([]interface{}); ok && len(firstRow) > 0 {
			if btn, ok := firstRow[0].(map[string]interface{}); ok {
				delete(btn, "style")
			}
		}
	}
	enriched := enrichReplyKeyboardStyles(roundTrip)
	final, err := json.Marshal(enriched)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(final, `"style":"success"`, `"style":"danger"`) {
		t.Fatalf("enrichReplyKeyboardStyles failed, got: %s", final)
	}
}

func jsonContainsAll(raw []byte, parts ...string) bool {
	s := string(raw)
	for _, part := range parts {
		if !contains(s, part) {
			return false
		}
	}
	return true
}

func countSubstring(s, sub string) int {
	n := 0
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			n++
			i += len(sub) - 1
		}
	}
	return n
}

func contains(s, sub string) bool {
	return len(s) >= len(sub) && (s == sub || len(sub) == 0 || indexOf(s, sub) >= 0)
}

func TestLocalizedMainReplyKeyboardHidesInfoButtons(t *testing.T) {
	shown := localizedMainReplyKeyboardEx(TgLangZh, false, false, []string{"小厕"}, true)
	hidden := localizedMainReplyKeyboardEx(TgLangZh, false, false, []string{"小厕"}, false)
	shownRaw, err := json.Marshal(shown)
	if err != nil {
		t.Fatal(err)
	}
	hiddenRaw, err := json.Marshal(hidden)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(shownRaw, "我的记录", "排行榜", "导出数据") {
		t.Fatalf("expected info buttons when enabled, got: %s", shownRaw)
	}
	if jsonContainsAll(hiddenRaw, "我的记录") || jsonContainsAll(hiddenRaw, "排行榜") || jsonContainsAll(hiddenRaw, "导出数据") {
		t.Fatalf("info buttons should be hidden, got: %s", hiddenRaw)
	}
	if !jsonContainsAll(hiddenRaw, "回座") {
		t.Fatalf("back button must remain when info buttons are hidden, got: %s", hiddenRaw)
	}
}

func TestVietnamesePersonalKeyboardLabels(t *testing.T) {
	kb := localizedMainReplyKeyboardEx(TgLangVi, true, false, []string{"小厕"}, false)
	kb["selective"] = true
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	got := string(raw)
	if !strings.Contains(got, `"selective":true`) {
		t.Fatalf("personal group keyboard must be selective, got %s", got)
	}
	if !strings.Contains(got, "Ca ngày Đi làm") || !strings.Contains(got, "Tan ca") {
		t.Fatalf("vi keyboard missing punch labels, got %s", got)
	}
	if strings.Contains(got, "白班上班") {
		t.Fatalf("vi keyboard should not keep chinese punch labels, got %s", got)
	}
	if !strings.Contains(got, "Nhà vệ sin") {
		t.Fatalf("vi keyboard missing activity label, got %s", got)
	}
}

func TestFitKeyboardLabelKeepsChinese(t *testing.T) {
	for _, name := range []string{"小厕", "大厕", "吃饭", "抽烟或休息"} {
		zh := tgActivityKeyboardLabel(name, TgLangZh)
		if got := tgFitKeyboardLabel(zh); got != zh {
			t.Fatalf("chinese keyboard label changed: %q -> %q", zh, got)
		}
	}
	if got := tgFitKeyboardLabel("白班上班"); got != "白班上班" {
		t.Fatalf("chinese work label changed: %q", got)
	}
}

func TestFitKeyboardLabelEllipsizesBilingual(t *testing.T) {
	full := tgActivityKeyboardLabel("小厕", TgLangBoth)
	fitted := tgFitKeyboardLabel(full)
	if fitted == full {
		t.Fatalf("expected bilingual label to ellipsize, got unchanged %q", full)
	}
	if !strings.HasSuffix(fitted, "...") {
		t.Fatalf("expected ..., got %q", fitted)
	}
	if strings.Contains(fitted, "vệ sinh") {
		t.Fatalf("expected long vietnamese to be trimmed, got %q", fitted)
	}
	if w := tgDisplayWidth(fitted); w > tgKeyboardLabelMaxWidth {
		t.Fatalf("fitted width %d exceeds max %d (%q)", w, tgKeyboardLabelMaxWidth, fitted)
	}
}

func TestFitKeyboardLabelStillResolves(t *testing.T) {
	lookup := map[string]string{}
	full := tgActivityKeyboardLabel("小厕", TgLangBoth)
	tgRegisterLookup(lookup, "小厕", full)
	fitted := tgFitKeyboardLabel(full)
	if lookup[fitted] != "小厕" {
		t.Fatalf("truncated label %q not in lookup: %#v", fitted, lookup)
	}
	kb := localizedMainReplyKeyboardEx(TgLangBoth, false, false, []string{"小厕", "大厕"}, false)
	raw, err := json.Marshal(kb)
	if err != nil {
		t.Fatal(err)
	}
	if !jsonContainsAll(raw, "...") {
		t.Fatalf("expected ellipsis on bilingual keyboard, got: %s", raw)
	}
	if jsonContainsAll(raw, "Nhà vệ sinh nhỏ") {
		t.Fatalf("full vietnamese should not appear on keyboard, got: %s", raw)
	}
}

func indexOf(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}

package services

import (
	"errors"
	"strings"
	"testing"
)

func TestFormatTelegramWorkerErrorLocalizesSentinels(t *testing.T) {
	zh := FormatTelegramWorkerError(ErrSessionExists, TgLangZh)
	if !strings.Contains(zh, "已在上班状态") {
		t.Fatalf("zh session-exists = %q", zh)
	}
	vi := FormatTelegramWorkerError(ErrSessionExists, TgLangVi)
	if strings.Contains(vi, "已在上班状态") {
		t.Fatalf("vi session-exists stayed chinese: %q", vi)
	}
	if !strings.Contains(vi, "đã đang đi làm") {
		t.Fatalf("vi session-exists missing vietnamese: %q", vi)
	}
	en := FormatTelegramWorkerError(ErrActivityNotInWork, TgLangEn)
	if strings.Contains(en, "请先上班") {
		t.Fatalf("en activity-not-in-work stayed chinese: %q", en)
	}
	if !strings.Contains(strings.ToLower(en), "clock in") {
		t.Fatalf("en activity-not-in-work missing english: %q", en)
	}
}

func TestFormatTelegramWorkerErrorWindowDetails(t *testing.T) {
	err := &outsideWorkWindowError{Action: "checkout", Shift: "night", Clock: "09:00"}
	if !errors.Is(err, ErrOutsideWorkWindow) {
		t.Fatal("typed window error must unwrap to ErrOutsideWorkWindow")
	}
	zh := FormatTelegramWorkerError(err, TgLangZh)
	if !strings.Contains(zh, "夜班") || !strings.Contains(zh, "09:00") || !strings.Contains(zh, "签退窗口") {
		t.Fatalf("zh window = %q", zh)
	}
	vi := FormatTelegramWorkerError(err, TgLangVi)
	if strings.Contains(vi, "签退窗口") {
		t.Fatalf("vi window stayed chinese: %q", vi)
	}
	if !strings.Contains(vi, "09:00") || !strings.Contains(vi, "Ca đêm") {
		t.Fatalf("vi window missing details: %q", vi)
	}
	other := &otherWorkSessionStillOpenError{Shift: "day", Detail: "night_last", Date: "2026-08-18"}
	if !errors.Is(other, ErrOtherWorkSessionOpen) {
		t.Fatal("typed other-session error must unwrap")
	}
	en := FormatTelegramWorkerError(other, TgLangEn)
	if strings.Contains(en, "请先下班") {
		t.Fatalf("en other-session stayed chinese: %q", en)
	}
	if !strings.Contains(en, "2026-08-18") || !strings.Contains(en, "last night") {
		t.Fatalf("en other-session missing details: %q", en)
	}
}

func TestFormatTelegramWorkerErrorDevicePickerPhrases(t *testing.T) {
	cases := []struct {
		mode    TgLangMode
		needAny []string
	}{
		{TgLangZh, []string{"选择设备", "多台设备已登录"}},
		{TgLangVi, []string{"chọn thiết bị", "Nhiều thiết bị"}},
		{TgLangEn, []string{"select a device", "Multiple devices"}},
	}
	for _, tc := range cases {
		msg := FormatTelegramWorkerError(ErrMultipleWorkstationLogins, tc.mode)
		ok := false
		for _, n := range tc.needAny {
			if strings.Contains(msg, n) {
				ok = true
				break
			}
		}
		if !ok {
			t.Fatalf("mode %s device error %q missing %#v", tc.mode, msg, tc.needAny)
		}
	}
}

func TestTelegramWorkerErrorHTTPCodes(t *testing.T) {
	st, code := TelegramWorkerErrorHTTP(ErrSessionExists)
	if st != 409 || code != 1004 {
		t.Fatalf("session exists http=%d code=%d", st, code)
	}
	st, code = TelegramWorkerErrorHTTP(ErrOutsideWorkWindow)
	if st != 400 || code != 1001 {
		t.Fatalf("window http=%d code=%d", st, code)
	}
	st, code = TelegramWorkerErrorHTTP(ErrActivityBackNotOwner)
	if st != 403 || code != 1006 {
		t.Fatalf("not owner http=%d code=%d", st, code)
	}
	st, code = TelegramWorkerErrorHTTP(errors.New("boom"))
	if st != 500 || code != 5000 {
		t.Fatalf("unknown http=%d code=%d", st, code)
	}
}

func TestFormatTelegramActivityBackNotOwner(t *testing.T) {
	zh := FormatTelegramActivityBackNotOwner("YuYu", TgLangZh)
	if zh != "YuYu，这不是您的活动按钮" {
		t.Fatalf("zh = %q", zh)
	}
	vi := FormatTelegramActivityBackNotOwner("YuYu", TgLangVi)
	if strings.Contains(vi, "这不是您的") {
		t.Fatalf("vi stayed chinese: %q", vi)
	}
	if !strings.HasPrefix(vi, "YuYu") {
		t.Fatalf("vi must keep name: %q", vi)
	}
}

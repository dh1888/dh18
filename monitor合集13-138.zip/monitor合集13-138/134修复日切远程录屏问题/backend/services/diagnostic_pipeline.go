package services

import (
	"context"
	"strconv"
	"strings"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

func (s *DiagnosticService) BuildPipeline(ctx context.Context, deviceIDStr string) (*models.DiagnosticPipeline, error) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return nil, err
	}

	now := models.UTCNow()
	pipeline := &models.DiagnosticPipeline{
		DeviceID:    deviceIDStr,
		GeneratedAt: now,
		OverallStatus: "unknown",
		Nodes:       []models.DiagnosticPipelineNode{},
		Edges: []models.DiagnosticPipelineEdge{
			{From: "agent", To: "capture"},
			{From: "capture", To: "ffmpeg"},
			{From: "ffmpeg", To: "whip"},
			{From: "whip", To: "ingress"},
			{From: "ingress", To: "livekit"},
			{From: "livekit", To: "frontend"},
		},
	}

	if s.deviceRepo != nil {
		if dev, err := s.deviceRepo.Get(ctx, deviceID); err == nil && dev != nil {
			pipeline.Hostname = dev.Hostname
		}
	}

	agentOnline := s.wsHub != nil && s.wsHub.IsAgentOnline(deviceIDStr)
	agentStatus := statusDown
	agentDetail := "Agent 离线"
	if agentOnline {
		agentStatus = statusHealthy
		agentDetail = "WebSocket 已连接"
	}
	pipeline.Nodes = append(pipeline.Nodes, models.DiagnosticPipelineNode{
		ID: "agent", Label: "Agent", Layer: "edge", Status: agentStatus, Detail: agentDetail,
	})

	var session *models.RemoteViewSession
	var rvStatus *models.RemoteViewStatusResponse
	if s.remoteView != nil {
		rvStatus, _ = s.remoteView.GetStatus(ctx, deviceIDStr)
		session, _ = s.remoteView.GetActiveSession(ctx, deviceID)
	}

	captureStatus, captureDetail := statusUnknown, "无活跃远程会话"
	ffmpegStatus, ffmpegDetail := statusUnknown, "未推流"
	whipStatus, whipDetail := statusUnknown, "无 WHIP 会话"
	ingressStatus, ingressDetail := statusUnknown, "无 Ingress"
	lkStatus, lkDetail := statusUnknown, "LiveKit 未就绪"

	if session != nil {
		pipeline.SessionID = session.ID.String()
		captureStatus = statusHealthy
		captureDetail = "SharedBridge / Capture 编排中"
		if session.Status == models.RemoteViewStatusStarting {
			captureStatus = statusDegraded
			captureDetail = "会话 starting，等待首帧"
		}
		if session.IngressID != "" {
			ingressStatus = statusHealthy
			ingressDetail = "Ingress " + truncateMiddle(session.IngressID, 12)
		}
		if strings.Contains(strings.ToLower(session.RTMPURL), "whip") || strings.Contains(session.RTMPURL, "/w/") {
			whipStatus = statusHealthy
			whipDetail = "WHIP publish URL 已分配"
		} else if session.RTMPURL != "" {
			whipStatus = statusDegraded
			whipDetail = "RTMP 推流（非 WHIP）"
		}
		if session.LiveKitURL != "" {
			lkStatus = statusHealthy
			lkDetail = "Room " + session.RoomName
		}
	}
	if rvStatus != nil && rvStatus.SfuChecked {
		if rvStatus.SfuPublishing {
			whipStatus = statusHealthy
			whipDetail = "SFU 确认正在推流"
			ingressStatus = statusHealthy
			ingressDetail = "Ingress publishing / 未静音视频轨"
			lkStatus = statusHealthy
			if session != nil {
				lkDetail = "Room " + session.RoomName + " publisher live"
			} else {
				lkDetail = "publisher 视频轨活跃"
			}
		} else if session != nil {
			whipStatus = statusDown
			whipDetail = "WHIP 出口未在 SFU 上推流（不采信 agent fps）"
			ingressStatus = statusDegraded
			ingressDetail = "Ingress/房间无活跃视频轨"
			lkStatus = statusDegraded
			lkDetail = "publisher 未发布或已静音"
		}
	}

	statsFresh := false
	var stats *models.RemoteViewStatsPayload
	if s.remoteView != nil {
		statsFresh = s.remoteView.hasFreshRemoteStats(deviceIDStr)
		stats = s.remoteView.GetDeviceStats(deviceIDStr)
	}
	if statsFresh && stats != nil {
		ffmpegStatus = statusHealthy
		ffmpegDetail = "编码中 " + stats.Encoder
		if stats.FPS <= 2 {
			ffmpegStatus = statusDegraded
			ffmpegDetail = "编码 FPS 过低 (" + strconv.Itoa(stats.FPS) + ")"
		}
	} else if session != nil {
		ffmpegStatus = statusDegraded
		ffmpegDetail = "推流 stats 过期或未上报"
	}

	frontendStatus, frontendDetail := statusUnknown, "无观看者"
	if rvStatus != nil && rvStatus.IsActive {
		if rvStatus.ViewerCount > 0 {
			frontendStatus = statusHealthy
			frontendDetail = "观看者 " + strconv.Itoa(rvStatus.ViewerCount)
		} else {
			frontendStatus = statusDegraded
			frontendDetail = "会话 active 但无 viewer"
		}
	}

	pipeline.Nodes = append(pipeline.Nodes,
		nodeWithMetrics("capture", "SharedBridge", "capture", captureStatus, captureDetail, nil),
		nodeWithMetrics("ffmpeg", "FFmpeg", "encode", ffmpegStatus, ffmpegDetail, statsMap(stats)),
		nodeWithMetrics("whip", "WHIP", "transport", whipStatus, whipDetail, nil),
		nodeWithMetrics("ingress", "LiveKit Ingress", "ingress", ingressStatus, ingressDetail, map[string]interface{}{"ingressId": safeStr(session, "ingress")}),
		nodeWithMetrics("livekit", "LiveKit SFU", "media", lkStatus, lkDetail, nil),
		nodeWithMetrics("frontend", "Browser Player", "client", frontendStatus, frontendDetail, map[string]interface{}{"viewers": viewerCount(rvStatus)}),
	)

	pipeline.OverallStatus = aggregatePipelineStatus(pipeline.Nodes)
	pipeline.Nodes = s.attachPipelineNodeLogs(ctx, deviceIDStr, pipeline.Nodes)
	return pipeline, nil
}

const (
	statusHealthy  = "healthy"
	statusDegraded = "degraded"
	statusDown     = "down"
	statusUnknown  = "unknown"
)

func nodeWithMetrics(id, label, layer, status, detail string, metrics map[string]interface{}) models.DiagnosticPipelineNode {
	return models.DiagnosticPipelineNode{ID: id, Label: label, Layer: layer, Status: status, Detail: detail, Metrics: metrics}
}

func aggregatePipelineStatus(nodes []models.DiagnosticPipelineNode) string {
	hasDown := false
	hasDegraded := false
	for _, n := range nodes {
		switch n.Status {
		case statusDown:
			hasDown = true
		case statusDegraded:
			hasDegraded = true
		}
	}
	if hasDown {
		return statusDown
	}
	if hasDegraded {
		return statusDegraded
	}
	allHealthy := len(nodes) > 0
	for _, n := range nodes {
		if n.Status != statusHealthy {
			allHealthy = false
			break
		}
	}
	if allHealthy {
		return statusHealthy
	}
	return statusUnknown
}

func statsMap(stats *models.RemoteViewStatsPayload) map[string]interface{} {
	if stats == nil {
		return nil
	}
	return map[string]interface{}{
		"fps":         stats.FPS,
		"bitrateKbps": stats.BitrateKbps,
		"encoder":     stats.Encoder,
	}
}

func viewerCount(st *models.RemoteViewStatusResponse) int {
	if st == nil {
		return 0
	}
	return st.ViewerCount
}

func safeStr(session *models.RemoteViewSession, field string) string {
	if session == nil {
		return ""
	}
	if field == "ingress" {
		return session.IngressID
	}
	return ""
}

func truncateMiddle(s string, keep int) string {
	if len(s) <= keep*2 {
		return s
	}
	return s[:keep] + "…" + s[len(s)-keep:]
}

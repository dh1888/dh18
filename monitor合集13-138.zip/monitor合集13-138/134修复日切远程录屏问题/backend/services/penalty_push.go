package services

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
)

type PenaltyPushService struct {
	db *sql.DB
}

func NewPenaltyPushService(db *sql.DB) *PenaltyPushService {
	return &PenaltyPushService{db: db}
}

type PenaltyPushSettings struct {
	HasBotToken bool   `json:"hasBotToken"`
	BotUsername string `json:"botUsername"`
	ChatID      string `json:"chatId"`
	ChatTitle   string `json:"chatTitle"`
	ChatType    string `json:"chatType"`
	Enabled     bool   `json:"enabled"`
	Ready       bool   `json:"ready"`
	UpdatedAt   string `json:"updatedAt,omitempty"`
}

func penaltyPushReady(hasBotToken bool, chatID string, enabled bool) bool {
	return enabled && hasBotToken && strings.TrimSpace(chatID) != ""
}

type PenaltyPushRecord struct {
	Date         string  `json:"date"`
	EmployeeID   string  `json:"employeeId"`
	EmployeeName string  `json:"employeeName"`
	Position     string  `json:"position"`
	Amount       float64 `json:"amount"`
	Category     string  `json:"category"`
	Reason       string  `json:"reason"`
}

func (s *PenaltyPushService) GetSettings(ctx context.Context) (*PenaltyPushSettings, error) {
	out := &PenaltyPushSettings{}
	var tokenEnc, botUsername, chatID, chatTitle, chatType sql.NullString
	var botID sql.NullInt64
	var enabled bool
	var updatedAt time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT bot_token_enc, bot_username, bot_id, chat_id, chat_title, chat_type, enabled, updated_at
		FROM penalty_push_settings WHERE id = 1`).
		Scan(&tokenEnc, &botUsername, &botID, &chatID, &chatTitle, &chatType, &enabled, &updatedAt)
	if err == sql.ErrNoRows {
		return out, nil
	}
	if err != nil {
		return nil, err
	}
	out.HasBotToken = tokenEnc.Valid && strings.TrimSpace(tokenEnc.String) != ""
	if botUsername.Valid {
		out.BotUsername = botUsername.String
	}
	if chatID.Valid {
		out.ChatID = chatID.String
	}
	if chatTitle.Valid {
		out.ChatTitle = chatTitle.String
	}
	if chatType.Valid {
		out.ChatType = chatType.String
	}
	out.Enabled = enabled
	out.Ready = penaltyPushReady(out.HasBotToken, out.ChatID, enabled)
	out.UpdatedAt = updatedAt.UTC().Format(time.RFC3339)
	return out, nil
}

func (s *PenaltyPushService) SetPushEnabled(ctx context.Context, enabled bool) (*PenaltyPushSettings, error) {
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO penalty_push_settings (id, enabled, updated_at)
		VALUES (1, $1, NOW())
		ON CONFLICT (id) DO UPDATE SET
			enabled = EXCLUDED.enabled,
			updated_at = NOW()`, enabled)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PenaltyPushService) SaveBotToken(ctx context.Context, token string) (*PenaltyPushSettings, error) {
	token = strings.TrimSpace(token)
	if token == "" {
		return nil, fmt.Errorf("Bot Token 不能为空")
	}
	username, botID, err := performanceTelegramGetMe(token)
	if err != nil {
		return nil, err
	}
	enc, err := EncryptSecret(token)
	if err != nil {
		return nil, err
	}
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO penalty_push_settings (id, bot_token_enc, bot_username, bot_id, updated_at)
		VALUES (1, $1, $2, $3, NOW())
		ON CONFLICT (id) DO UPDATE SET
			bot_token_enc = EXCLUDED.bot_token_enc,
			bot_username = EXCLUDED.bot_username,
			bot_id = EXCLUDED.bot_id,
			updated_at = NOW()`, enc, username, botID)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PenaltyPushService) DiscoverChats(ctx context.Context) ([]map[string]string, error) {
	token, err := s.getBotToken(ctx)
	if err != nil {
		return nil, err
	}
	return DiscoverTelegramChats(ctx, s.db, token)
}

func (s *PenaltyPushService) BindChat(ctx context.Context, chatID, chatTitle, chatType string) (*PenaltyPushSettings, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return nil, fmt.Errorf("chatId required")
	}
	if _, err := s.getBotToken(ctx); err != nil {
		return nil, err
	}
	title := strings.TrimSpace(chatTitle)
	if title == "" {
		title = chatID
	}
	chatType = strings.TrimSpace(chatType)
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO penalty_push_settings (id, chat_id, chat_title, chat_type, updated_at)
		VALUES (1, $1, $2, $3, NOW())
		ON CONFLICT (id) DO UPDATE SET
			chat_id = EXCLUDED.chat_id,
			chat_title = EXCLUDED.chat_title,
			chat_type = EXCLUDED.chat_type,
			updated_at = NOW()`, chatID, title, chatType)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PenaltyPushService) UnbindChat(ctx context.Context) (*PenaltyPushSettings, error) {
	_, err := s.db.ExecContext(ctx, `
		UPDATE penalty_push_settings
		SET chat_id = NULL, chat_title = NULL, chat_type = NULL, updated_at = NOW()
		WHERE id = 1`)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PenaltyPushService) PushPenaltyRecord(ctx context.Context, rec PenaltyPushRecord) (bool, error) {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return false, err
	}
	if !settings.Ready {
		return false, nil
	}
	token, err := s.getBotToken(ctx)
	if err != nil {
		return false, err
	}
	tgUID, username := lookupEmployeeTelegramProfile(ctx, s.db, rec.EmployeeID, rec.EmployeeName)
	text := buildPenaltyPushHTML(rec, tgUID, username, s.FineCurrencyCode(ctx))
	if err := performanceTelegramSendHTML(token, settings.ChatID, text); err != nil {
		return false, err
	}
	return true, nil
}

func (s *PenaltyPushService) TestPush(ctx context.Context) error {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return err
	}
	if settings.ChatID == "" {
		return fmt.Errorf("请先绑定频道或群组")
	}
	token, err := s.getBotToken(ctx)
	if err != nil {
		return err
	}
	text := "⚠️ <b>罚款推送测试</b>\n" + tgReplyDashedLine() + "\n配置成功，后续新增罚款将使用可点击姓名、可复制金额的模版推送到此频道/群组。"
	return performanceTelegramSendHTML(token, settings.ChatID, text)
}

func (s *PenaltyPushService) getBotToken(ctx context.Context) (string, error) {
	var enc sql.NullString
	err := s.db.QueryRowContext(ctx, `SELECT bot_token_enc FROM penalty_push_settings WHERE id = 1`).Scan(&enc)
	if err == sql.ErrNoRows || !enc.Valid || strings.TrimSpace(enc.String) == "" {
		return "", fmt.Errorf("请先配置 Bot Token")
	}
	if err != nil {
		return "", err
	}
	return DecryptSecret(enc.String)
}

// FineCurrencyCode reads TG settings fine currency (display only; default CNY).
func (s *PenaltyPushService) FineCurrencyCode(ctx context.Context) string {
	var code string
	err := s.db.QueryRowContext(ctx,
		`SELECT COALESCE(NULLIF(TRIM(fine_currency), ''), 'CNY') FROM wf_telegram_settings WHERE id = 1`,
	).Scan(&code)
	if err != nil {
		return "CNY"
	}
	return NormalizeFineCurrency(code)
}

func buildPenaltyPushHTML(rec PenaltyPushRecord, telegramUserID int64, telegramUsername, fineCurrency string) string {
	return fmt.Sprintf(
		"⚠️ <b>罚款通知</b>\n"+
			"%s\n"+
			"👤 员工：%s\n"+
			"📅 日期：%s\n"+
			"💼 岗位：%s\n"+
			"💰 金额：%s\n"+
			"📂 类别：%s\n"+
			"📝 原因：%s",
		tgReplyDashedLine(),
		formatEmployeeProfileHTML(telegramUserID, telegramUsername, rec.EmployeeName),
		tgCopyableText(rec.Date),
		tgCopyableText(rec.Position),
		tgCopyableText(FormatFineMoney(rec.Amount, fineCurrency)),
		tgCopyableText(rec.Category),
		tgCopyableText(formatPenaltyReasonDuration(rec.Reason)),
	)
}

func lookupEmployeeTelegramUserID(ctx context.Context, db *sql.DB, employeeID, employeeName string) int64 {
	userID, _ := lookupEmployeeTelegramProfile(ctx, db, employeeID, employeeName)
	return userID
}

func lookupEmployeeTelegramProfile(ctx context.Context, db *sql.DB, employeeID, employeeName string) (userID int64, username string) {
	if db == nil {
		return 0, ""
	}
	scan := func(query string, args ...interface{}) bool {
		var id int64
		var user sql.NullString
		if err := db.QueryRowContext(ctx, query, args...).Scan(&id, &user); err != nil || id <= 0 {
			return false
		}
		userID = id
		username = strings.TrimSpace(user.String)
		return true
	}
	if id, err := uuid.Parse(strings.TrimSpace(employeeID)); err == nil && id != uuid.Nil {
		if scan(`
			SELECT telegram_user_id, COALESCE(telegram_username, '')
			FROM employee_telegram_bindings
			WHERE employee_id = $1 AND status = 1
			ORDER BY bound_at DESC NULLS LAST LIMIT 1`, id) {
			return userID, username
		}
		if scan(`
			SELECT b.telegram_user_id, COALESCE(b.telegram_username, '')
			FROM device_telegram_bindings b
			JOIN devices d ON d.id = b.device_id
			WHERE d.employee_uuid = $1 AND b.status = 1
			ORDER BY b.bound_at DESC NULLS LAST LIMIT 1`, id) {
			return userID, username
		}
		if scan(`
			SELECT b.telegram_user_id, COALESCE(b.telegram_username, '')
			FROM device_telegram_bindings b
			JOIN wf_shared_workstation_members m ON m.device_id = b.device_id
			WHERE m.employee_id = $1 AND b.status = 1
			ORDER BY b.bound_at DESC NULLS LAST LIMIT 1`, id) {
			return userID, username
		}
		if scan(`
			SELECT b.telegram_user_id, COALESCE(b.telegram_username, '')
			FROM work_sessions ws
			JOIN device_telegram_bindings b ON b.device_id = ws.device_id AND b.status = 1
			WHERE ws.employee_id = $1 AND ws.status = 'open' AND ws.device_id IS NOT NULL
			ORDER BY ws.checkin_time DESC LIMIT 1`, id) {
			return userID, username
		}
	}
	name := strings.TrimSpace(employeeName)
	if name == "" {
		return 0, ""
	}
	if scan(`
		SELECT b.telegram_user_id, COALESCE(b.telegram_username, '')
		FROM employee_telegram_bindings b
		JOIN employees e ON e.id = b.employee_id
		WHERE e.name = $1 AND b.status = 1
		ORDER BY b.bound_at DESC NULLS LAST LIMIT 1`, name) {
		return userID, username
	}
	scan(`
		SELECT b.telegram_user_id, COALESCE(b.telegram_username, '')
		FROM device_telegram_bindings b
		JOIN devices d ON d.id = b.device_id
		WHERE d.employee_name = $1 AND b.status = 1
		ORDER BY b.bound_at DESC NULLS LAST LIMIT 1`, name)
	return userID, username
}

// formatPenaltyReasonDuration converts trailing "N 秒" in reason text to 分/秒 display.
func formatPenaltyReasonDuration(reason string) string {
	reason = strings.TrimSpace(reason)
	if reason == "" {
		return reason
	}
	const suffix = " 秒"
	if !strings.HasSuffix(reason, suffix) {
		return reason
	}
	body := strings.TrimSuffix(reason, suffix)
	idx := strings.LastIndex(body, " ")
	if idx < 0 {
		return reason
	}
	numPart := strings.TrimSpace(body[idx+1:])
	prefix := strings.TrimSpace(body[:idx])
	var sec int
	if _, err := fmt.Sscanf(numPart, "%d", &sec); err != nil || sec < 0 {
		return reason
	}
	if prefix == "" {
		return formatDurationZh(sec)
	}
	return prefix + " " + formatDurationZh(sec)
}

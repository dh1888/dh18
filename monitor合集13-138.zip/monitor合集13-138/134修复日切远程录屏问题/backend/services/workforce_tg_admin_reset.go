package services

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/google/uuid"
)

type EmployeeDailyResetResult struct {
	BusinessDate            string `json:"businessDate"`
	ClosedActivities        int    `json:"closedActivities"`
	ClosedWorkSessions      int    `json:"closedWorkSessions"`
	DeletedWorkSessions     int    `json:"deletedWorkSessions"`
	DeletedActivitySessions int    `json:"deletedActivitySessions"`
	ClearedShiftState       int    `json:"clearedShiftState"`
	AgentNotified           bool   `json:"agentNotified"`
}

func (s *WorkforceTelegramService) ResetEmployeeDailyAttendance(ctx context.Context, employeeID uuid.UUID, chatID string) (*EmployeeDailyResetResult, error) {
	if employeeID == uuid.Nil {
		return nil, fmt.Errorf("employeeId required")
	}
	now := time.Now()
	businessDate := now.Format("2006-01-02")
	if strings.TrimSpace(chatID) != "" {
		if period, err := s.DetermineCurrentPeriod(ctx, chatID, now); err == nil && period != nil {
			businessDate = period.BusinessDate
		}
	}
	out := &EmployeeDailyResetResult{BusinessDate: businessDate}

	openRows, err := s.db.QueryContext(ctx, `
		SELECT id FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND status = 'open'`, employeeID)
	if err == nil {
		defer openRows.Close()
		for openRows.Next() {
			var sid uuid.UUID
			if openRows.Scan(&sid) != nil {
				continue
			}
			if _, err := s.closeActivitySession(ctx, sid, false, "system"); err == nil {
				out.ClosedActivities++
			}
		}
	}

	// Close open work sessions for this business date before archive (no early-leave fine).
	// Prevents archiving status=open ghosts that later inflate export duration via NOW().
	const employeeDailyResetSkipFine = true
	wsOpenRows, err := s.db.QueryContext(ctx, `
		SELECT id FROM work_sessions
		WHERE employee_id = $1 AND status = 'open' AND attendance_date = $2::date
		ORDER BY checkin_time ASC`, employeeID, businessDate)
	if err == nil {
		defer wsOpenRows.Close()
		for wsOpenRows.Next() {
			var sid uuid.UUID
			if wsOpenRows.Scan(&sid) != nil {
				continue
			}
			if err := s.forceCheckoutWorkSessionAtWithOptions(ctx, sid, chatID, time.Now(), "单人日重置", employeeDailyResetSkipFine); err != nil {
				log.Printf("[Telegram] employee daily reset close work session=%s: %v", sid, err)
				continue
			}
			out.ClosedWorkSessions++
			out.AgentNotified = true
		}
	}

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	if err := s.mergeActivityStatsIntoMonthlyForEmployeeDateTx(ctx, tx, employeeID, businessDate); err != nil {
		return nil, err
	}
	if err := s.archiveActivitySessionsByEmployeeDate(ctx, tx, employeeID, businessDate); err != nil {
		return nil, err
	}
	if err := s.archiveWorkSessionsByEmployeeDate(ctx, tx, employeeID, businessDate); err != nil {
		return nil, err
	}

	actRes, err := tx.ExecContext(ctx, `
		DELETE FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND attendance_date = $2::date`,
		employeeID, businessDate)
	if err != nil {
		return nil, err
	}
	if n, _ := actRes.RowsAffected(); n > 0 {
		out.DeletedActivitySessions = int(n)
	}

	res, err := tx.ExecContext(ctx, `
		DELETE FROM work_sessions WHERE employee_id = $1 AND attendance_date = $2::date`,
		employeeID, businessDate)
	if err != nil {
		return nil, err
	}
	if n, _ := res.RowsAffected(); n > 0 {
		out.DeletedWorkSessions = int(n)
	}

	if err := tx.Commit(); err != nil {
		return nil, err
	}

	yearMonth := businessDate
	if len(businessDate) >= 7 {
		yearMonth = businessDate[:7]
	}
	_, _ = s.db.ExecContext(ctx, `
		UPDATE attendance_records SET
			checkin_time = NULL, checkout_time = NULL,
			checkin_source = NULL, checkout_source = NULL,
			shift_type = NULL,
			activity_seconds = NULL,
			status = CASE WHEN manually_edited THEN status ELSE 'absent' END,
			updated_at = NOW()
		WHERE employee_id = $1 AND year_month = $2 AND date = $3::date AND manually_edited = FALSE`,
		employeeID, yearMonth, businessDate)

	res2, _ := s.db.ExecContext(ctx, `
		DELETE FROM wf_tg_group_shift_state WHERE employee_id = $1 AND record_date = $2::date`,
		employeeID, businessDate)
	if n, _ := res2.RowsAffected(); n > 0 {
		out.ClearedShiftState = int(n)
	}

	return out, nil
}

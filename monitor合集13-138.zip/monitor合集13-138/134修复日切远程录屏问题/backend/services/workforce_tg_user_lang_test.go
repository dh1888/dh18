package services

import (
	"strings"
	"testing"
	"time"
)

func TestNormalizeUserReplyLang(t *testing.T) {
	if mode, ok := normalizeUserReplyLang("vi"); !ok || mode != TgLangVi {
		t.Fatalf("vi expected")
	}
	if mode, ok := normalizeUserReplyLang("zh"); !ok || mode != TgLangZh {
		t.Fatalf("zh expected")
	}
	if mode, ok := normalizeUserReplyLang("en"); !ok || mode != TgLangEn {
		t.Fatalf("en expected")
	}
	if _, ok := normalizeUserReplyLang("both"); ok {
		t.Fatal("both should be rejected")
	}
}

func TestBuildWorkStartGroupReplyHTMLLocalized(t *testing.T) {
	now := time.Date(2026, 8, 18, 9, 5, 0, 0, time.UTC)
	expected := time.Date(2026, 8, 18, 9, 0, 0, 0, time.UTC)
	zh := buildWorkStartGroupReplyHTML(TgLangZh, 123, "张三", "day", "", now, expected, 0, 0, "", "CNY")
	if !strings.Contains(zh, "白班上班完成") || !strings.Contains(zh, "准时") {
		t.Fatalf("zh reply unexpected: %s", zh)
	}
	vi := buildWorkStartGroupReplyHTML(TgLangVi, 123, "Lan", "day", "", now, expected, 0, 0, "", "CNY")
	if !strings.Contains(vi, "Ca ngày") || !strings.Contains(vi, "Đúng giờ") || strings.Contains(vi, "准时") {
		t.Fatalf("vi reply unexpected: %s", vi)
	}
}

func TestBuildWorkStartGroupReplyHTMLEnglish(t *testing.T) {
	now := time.Date(2026, 8, 18, 9, 5, 0, 0, time.UTC)
	expected := time.Date(2026, 8, 18, 9, 0, 0, 0, time.UTC)
	en := buildWorkStartGroupReplyHTML(TgLangEn, 123, "Tom", "day", "", now, expected, 0, 0, "", "CNY")
	if !strings.Contains(en, "Day shift") || !strings.Contains(en, "On time") || strings.Contains(en, "准时") {
		t.Fatalf("en reply unexpected: %s", en)
	}
}

func TestBuildActivityStartGroupReplyHTMLEnglishActivityName(t *testing.T) {
	en := buildActivityStartGroupReplyHTML(TgLangEn, 1, "Tom", "小厕", "08/18 10:00:00", "Day shift", 1, 5, 10)
	if strings.Contains(en, "小厕") || !strings.Contains(en, "Restroom") {
		t.Fatalf("en activity name unexpected: %s", en)
	}
}

func TestBuildActivityStartGroupReplyHTMLLocalized(t *testing.T) {
	vi := buildActivityStartGroupReplyHTML(TgLangVi, 1, "Lan", "小厕", "08/18 10:00:00", "Ca ngày", 1, 5, 10)
	if !strings.Contains(vi, "Chấm công") || !strings.Contains(vi, "Trở lại") {
		t.Fatalf("vi activity start unexpected: %s", vi)
	}
}

package services

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
)

type pendingWorkShift struct {
	Shift      string
	RecordDate string
	SessionID  uuid.UUID
}

func (s *WorkforceTelegramService) getPendingWorkEndShift(ctx context.Context, chatID string, empID uuid.UUID) (*pendingWorkShift, error) {
	var sid uuid.UUID
	var shift, recordDate string
	err := s.db.QueryRowContext(ctx, `
		SELECT id, COALESCE(shift_type,'day'), attendance_date::text
		FROM work_sessions
		WHERE employee_id = $1 AND status = 'open' AND source = 'telegram'
		ORDER BY checkin_time ASC LIMIT 1`, empID).Scan(&sid, &shift, &recordDate)
	if err == nil {
		return &pendingWorkShift{Shift: shift, RecordDate: recordDate, SessionID: sid}, nil
	}
	if err != sql.ErrNoRows {
		return nil, err
	}

	err = s.db.QueryRowContext(ctx, `
		SELECT gs.shift_type, gs.record_date::text
		FROM wf_tg_group_shift_state gs
		WHERE gs.chat_id = $1 AND gs.employee_id = $2
		  AND NOT EXISTS (
			SELECT 1 FROM work_sessions ws
			WHERE ws.employee_id = gs.employee_id AND ws.shift_type = gs.shift_type
			  AND ws.attendance_date = gs.record_date AND ws.status = 'closed' AND ws.source = 'telegram'
		  )
		ORDER BY gs.updated_at ASC LIMIT 1`, chatID, empID).Scan(&shift, &recordDate)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &pendingWorkShift{Shift: shift, RecordDate: recordDate}, nil
}

func (s *WorkforceTelegramService) upsertRelaySuccessor(ctx context.Context, chatID string, empID uuid.UUID, relayDate, successorDate string) {
	if chatID == "" || empID == uuid.Nil {
		return
	}
	_, _ = s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_relay_states (chat_id, employee_id, relay_handover_date, successor_record_date, updated_at)
		VALUES ($1, $2, $3::date, $4::date, NOW())
		ON CONFLICT (chat_id, employee_id) DO UPDATE SET
			relay_handover_date = EXCLUDED.relay_handover_date,
			successor_record_date = EXCLUDED.successor_record_date,
			updated_at = NOW()`,
		chatID, empID, relayDate, successorDate)
}

func (s *WorkforceTelegramService) clearRelaySuccessor(ctx context.Context, chatID string, empID uuid.UUID) {
	if chatID == "" || empID == uuid.Nil {
		return
	}
	_, _ = s.db.ExecContext(ctx, `DELETE FROM wf_tg_relay_states WHERE chat_id = $1 AND employee_id = $2`, chatID, empID)
}

func isHandoverRelaySuccessor(shift, recordDate, openShift, openDate string, cfg *TgHandoverConfigRow, loc *time.Location) bool {
	if cfg == nil || !cfg.HandoverEnabled {
		return false
	}
	if shift != "day" || openShift != "day" || strings.TrimSpace(recordDate) == "" || strings.TrimSpace(openDate) == "" {
		return false
	}
	if recordDate <= openDate {
		return false
	}
	if loc == nil {
		loc = time.Local
	}
	od, err := time.ParseInLocation("2006-01-02", openDate, loc)
	if err != nil {
		return false
	}
	return isHandoverDate(od, cfg.HandoverDay, cfg.HandoverMonth)
}

func (s *WorkforceTelegramService) getRelaySuccessorDate(ctx context.Context, chatID string, empID uuid.UUID) string {
	var d sql.NullString
	_ = s.db.QueryRowContext(ctx, `
		SELECT successor_record_date::text FROM wf_tg_relay_states
		WHERE chat_id = $1 AND employee_id = $2`, chatID, empID).Scan(&d)
	if d.Valid {
		return d.String
	}
	return ""
}

func (s *WorkforceTelegramService) validateRelayNightBlock(ctx context.Context, chatID, shift string, now time.Time) error {
	if shift != "night" {
		return nil
	}
	relay := s.getHandoverDayRelayHandoverDate(ctx, chatID, now)
	if relay == "" {
		return nil
	}
	cfg, _ := s.GetHandoverConfig(ctx, chatID)
	dh, _, ok := parseClock(cfg.DayStartTime)
	if !ok {
		dh = 9
	}
	if now.Hour() < dh {
		return fmt.Errorf("清晨不能打夜班卡，请使用「白班上班」进行换班接班")
	}
	return nil
}

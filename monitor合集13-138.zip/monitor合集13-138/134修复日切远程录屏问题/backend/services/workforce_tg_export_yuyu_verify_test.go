package services

import (
	"context"
	"database/sql"
	"os"
	"testing"
	"time"

	"github.com/joho/godotenv"
	_ "github.com/lib/pq"
)

// TestVerifyYuYuExportDuration20260729 runs against a live DB when available.
// Recomputes export duration rules for employee name YuYu on 2026-07-29.
func TestVerifyYuYuExportDuration20260729(t *testing.T) {
	_ = godotenv.Load("../.env")
	_ = godotenv.Load(".env")
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		host := getenvDefault("DB_HOST", "localhost")
		port := getenvDefault("DB_PORT", "5432")
		user := getenvDefault("DB_USER", "postgres")
		pass := os.Getenv("DB_PASSWORD")
		name := getenvDefault("DB_NAME", "postgres")
		ssl := getenvDefault("DB_SSLMODE", "disable")
		if pass == "" {
			t.Skip("no DB credentials; skip YuYu live verify")
		}
		dsn = "host=" + host + " port=" + port + " user=" + user + " password=" + pass + " dbname=" + name + " sslmode=" + ssl
	}

	db, err := sql.Open("postgres", dsn)
	if err != nil {
		t.Skipf("db open: %v", err)
	}
	defer db.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	if err := db.PingContext(ctx); err != nil {
		t.Skipf("db unreachable: %v", err)
	}

	const day = "2026-07-29"
	today := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02")

	// Prefer named YuYu; else any employee with archive open+closed night pattern on that day.
	var empID, empName string
	err = db.QueryRowContext(ctx, `
		SELECT e.id::text, e.name FROM employees e
		WHERE e.name ILIKE '%yuyu%'
		ORDER BY e.created_at DESC NULLS LAST
		LIMIT 1`).Scan(&empID, &empName)
	if err == sql.ErrNoRows || err != nil {
		err = db.QueryRowContext(ctx, `
			SELECT e.id::text, e.name
			FROM employees e
			WHERE EXISTS (
				SELECT 1 FROM work_sessions_archive o
				WHERE o.employee_id = e.id AND o.attendance_date = $1::date
				  AND (o.status = 'open' OR o.checkout_time IS NULL)
			) AND EXISTS (
				SELECT 1 FROM work_sessions_archive c
				WHERE c.employee_id = e.id AND c.attendance_date = $1::date
				  AND c.status = 'closed' AND c.checkout_time IS NOT NULL
			)
			ORDER BY e.name
			LIMIT 1`, day).Scan(&empID, &empName)
		if err == sql.ErrNoRows {
			t.Skip("no YuYu / open+closed night dirty pattern for 2026-07-29 in this DB")
		}
		if err != nil {
			// Local/dev DBs may lack archive table or production dump.
			t.Skipf("lookup dirty night pattern unavailable: %v", err)
		}
	}

	rows, err := db.QueryContext(ctx, `
		SELECT DISTINCT ON (id)
			checkin_time, checkout_time, COALESCE(status,'closed'), is_live, attendance_date::text
		FROM (
			SELECT id, checkin_time, checkout_time, status, TRUE AS is_live, attendance_date
			FROM work_sessions
			WHERE employee_id = $1::uuid
			  AND (attendance_date = $2::date OR (checkin_time AT TIME ZONE 'Asia/Shanghai')::date = $2::date)
			UNION ALL
			SELECT id, checkin_time, checkout_time, status, FALSE AS is_live, attendance_date
			FROM work_sessions_archive
			WHERE employee_id = $1::uuid
			  AND (attendance_date = $2::date OR (checkin_time AT TIME ZONE 'Asia/Shanghai')::date = $2::date)
		) u
		ORDER BY id, is_live DESC`, empID, day)
	if err != nil {
		t.Fatalf("query sessions: %v", err)
	}
	defer rows.Close()

	total := 0
	var closedSegs, openIgnored int
	var closedOnly int
	for rows.Next() {
		var checkin time.Time
		var checkout sql.NullTime
		var status string
		var isLive bool
		var attDate string
		if err := rows.Scan(&checkin, &checkout, &status, &isLive, &attDate); err != nil {
			t.Fatal(err)
		}
		isOpen := status == "open" || !checkout.Valid
		sec := exportSessionDurationSeconds(checkin, checkout.Time, checkout.Valid, isLive, isOpen, attDate, today, time.Now())
		total += sec
		if checkout.Valid {
			closedSegs++
			closedOnly += sec
		} else if sec == 0 {
			openIgnored++
		}
	}
	if err := rows.Err(); err != nil {
		t.Fatal(err)
	}
	if closedSegs == 0 && openIgnored == 0 {
		t.Skip("no sessions for 2026-07-29 in this DB")
	}
	if total != closedOnly {
		t.Fatalf("%s export duration %d != closed-only %d (open must be ignored)", empName, total, closedOnly)
	}
	if total > 12*3600 {
		t.Fatalf("%s 2026-07-29 export duration %ds (~%.1fh) still looks inflated", empName, total, float64(total)/3600)
	}

	// Sanity: a normal closed night (~11h50) must still compute correctly under the same helper.
	loc := time.FixedZone("CST", 8*3600)
	nCheckin := time.Date(2026, 7, 29, 21, 0, 0, 0, loc)
	nCheckout := time.Date(2026, 7, 30, 8, 50, 0, 0, loc)
	normal := exportSessionDurationSeconds(nCheckin, nCheckout, true, false, false, day, today, time.Now())
	if normal != int(nCheckout.Sub(nCheckin).Seconds()) {
		t.Fatalf("normal night duration broken: %d", normal)
	}

	t.Logf("verify emp=%s(%s) day=%s closedSegs=%d openIgnored=%d duration=%ds (~%.2fh); normalNight=%ds",
		empName, empID, day, closedSegs, openIgnored, total, float64(total)/3600, normal)
}

func getenvDefault(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

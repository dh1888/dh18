package services

import (
	"context"
	"database/sql"
	"strings"
	"unicode"
)

type TgLangMode string

const (
	TgLangBoth TgLangMode = "both"
	TgLangZh   TgLangMode = "zh"
	TgLangVi   TgLangMode = "vi"
	TgLangEn   TgLangMode = "en"
)

var tgActivityVI = map[string]string{
	"吃饭":     "Đi ăn",
	"大厕":     "Nhà vệ sinh lớn",
	"小厕":     "Nhà vệ sinh nhỏ",
	"抽烟或休息": "Nghỉ hoặc hút thuốc",
	"抽烟":     "Hút thuốc",
}

// tgDefaultActivityIcons maps canonical activity names to keyboard display icons.
// DB name / API resolution stay unchanged; icons are display-only on buttons.
var tgDefaultActivityIcons = map[string]string{
	"小厕":     "🚾",
	"大厕":     "🚽",
	"吃饭":     "🍱",
	"抽烟":     "🚬",
	"抽烟或休息": "🚬",
}

type tgButtonMeta struct {
	Zh     string
	Vi     string
	En     string
	Style  string
	Legacy []string
}

var tgWorkButtons = map[string]tgButtonMeta{
	"work_start_day":    {Zh: "白班上班", Vi: "Ca ngày Đi làm", En: "Day in", Style: "success"},
	"work_start_middle": {Zh: "中班上班", Vi: "Ca giữa Đi làm", En: "Mid in", Style: "primary"},
	"work_start_night":  {Zh: "夜班上班", Vi: "Ca đêm Đi làm", En: "Night in", Style: "primary"},
	"work_end":          {Zh: "下班", Vi: "Tan ca", En: "Clock out", Style: "danger", Legacy: []string{"🔴 下班"}},
}

var tgUIButtons = map[string]tgButtonMeta{
	"back":       {Zh: "回座", Vi: "Trở lại chỗ ngồi", En: "Back", Style: "success", Legacy: []string{"✅ 回座", "回来", "结束活动", "结束", "回座"}},
	"my_record":  {Zh: "我的记录", Vi: "Lịch sử của tôi", En: "My log", Legacy: []string{"我的信息", "我的记录"}},
	"rank":        {Zh: "排行榜", Vi: "Bảng xếp hạng", En: "Rank", Legacy: []string{"排名"}},
	"export_data": {Zh: "导出数据", Vi: "Xuất dữ liệu", En: "Export", Legacy: []string{"/export"}},
	"checkin":    {Zh: "上班", Vi: "Đi làm", En: "Clock in", Style: "success"},
	"status":     {Zh: "状态", Vi: "Trạng thái", En: "Status"},
	"handover":   {Zh: "交接班", Vi: "Giao ca", En: "Handover", Legacy: []string{"换班"}},
	"help":       {Zh: "帮助", Vi: "Trợ giúp", En: "Help"},
	"chatid":     {Zh: "chatid", Vi: "chatid", En: "chatid"},
}

func normalizeTgLangMode(mode string) TgLangMode {
	switch strings.ToLower(strings.TrimSpace(mode)) {
	case "zh":
		return TgLangZh
	case "vi":
		return TgLangVi
	case "en":
		return TgLangEn
	default:
		return TgLangBoth
	}
}

func (s *WorkforceTelegramService) GetLangMode(ctx context.Context, chatID string) TgLangMode {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return TgLangBoth
	}
	mode := normalizeTgLangMode(settings.BotUILang)
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return mode
	}
	var groupLang sql.NullString
	if s.db.QueryRowContext(ctx, `
		SELECT bot_ui_lang FROM wf_telegram_groups WHERE chat_id = $1`, chatID).
		Scan(&groupLang) == nil && groupLang.Valid && strings.TrimSpace(groupLang.String) != "" {
		return normalizeTgLangMode(groupLang.String)
	}
	return mode
}

func tgFormatLabel(zh, vi string, mode TgLangMode) string {
	switch mode {
	case TgLangZh:
		return zh
	case TgLangVi:
		if vi != "" {
			return vi
		}
		return zh
	default:
		if vi != "" && vi != zh {
			return zh + " / " + vi
		}
		return zh
	}
}

func tgActivityLabel(activity string, mode TgLangMode) string {
	return tgFormatLabel(activity, tgActivityVI[activity], mode)
}

func tgDefaultActivityIcon(name string) string {
	return tgDefaultActivityIcons[strings.TrimSpace(name)]
}

func tgActivityKeyboardLabel(activity string, mode TgLangMode) string {
	var base string
	switch mode {
	case TgLangZh, TgLangVi, TgLangEn:
		base = tgActivityDisplayName(activity, mode)
	default:
		base = tgActivityLabel(activity, mode)
	}
	if icon := tgDefaultActivityIcon(activity); icon != "" {
		return icon + " " + base
	}
	return base
}

// stripActivityKeyboardPrefix removes a leading default activity icon from button text.
func stripActivityKeyboardPrefix(text string) string {
	text = strings.TrimSpace(text)
	if text == "" {
		return text
	}
	seen := make(map[string]struct{}, len(tgDefaultActivityIcons))
	for _, icon := range tgDefaultActivityIcons {
		if icon == "" {
			continue
		}
		if _, ok := seen[icon]; ok {
			continue
		}
		seen[icon] = struct{}{}
		if strings.HasPrefix(text, icon+" ") {
			return strings.TrimSpace(text[len(icon)+1:])
		}
	}
	return text
}

func tgButtonLabel(meta tgButtonMeta, mode TgLangMode) string {
	switch mode {
	case TgLangVi:
		if strings.TrimSpace(meta.Vi) != "" {
			return meta.Vi
		}
	case TgLangEn:
		if strings.TrimSpace(meta.En) != "" {
			return meta.En
		}
	case TgLangBoth:
		return tgFormatLabel(meta.Zh, meta.Vi, mode)
	}
	return meta.Zh
}

// Telegram reply-keyboard rows share width by button count, not by text.
// Long bilingual labels wrap and make buttons taller; keep the original
// 3-across layout and ellipsize overflow instead.
const tgKeyboardLabelMaxWidth = 16
const tgKeyboardLabelEllipsis = "..."

func tgRuneDisplayWidth(r rune) int {
	switch {
	case r == 0 || r == '\u200d' || r == '\ufe0e' || r == '\ufe0f':
		return 0
	case unicode.Is(unicode.Mn, r) || unicode.Is(unicode.Me, r):
		return 0
	case r < 0x1100:
		return 1
	case r >= 0x2E80 && r <= 0xA4CF:
		return 2
	case r >= 0xAC00 && r <= 0xD7AF:
		return 2
	case r >= 0xF900 && r <= 0xFAFF:
		return 2
	case r >= 0xFE10 && r <= 0xFE19:
		return 2
	case r >= 0xFF00 && r <= 0xFF60:
		return 2
	case r >= 0xFFE0 && r <= 0xFFE6:
		return 2
	case r >= 0x1F000 && r <= 0x1FFFF:
		return 2
	case r >= 0x2600 && r <= 0x27BF:
		return 2
	default:
		return 1
	}
}

func tgDisplayWidth(s string) int {
	w := 0
	for _, r := range s {
		w += tgRuneDisplayWidth(r)
	}
	return w
}

func tgFitKeyboardLabel(s string) string {
	s = strings.TrimSpace(s)
	if s == "" || tgDisplayWidth(s) <= tgKeyboardLabelMaxWidth {
		return s
	}
	ellipsisW := tgDisplayWidth(tgKeyboardLabelEllipsis)
	var b strings.Builder
	w := 0
	for _, r := range s {
		rw := tgRuneDisplayWidth(r)
		if w+rw+ellipsisW > tgKeyboardLabelMaxWidth {
			break
		}
		b.WriteRune(r)
		w += rw
	}
	out := strings.TrimSpace(b.String())
	out = strings.TrimRight(out, "/ ")
	if out == "" {
		return tgKeyboardLabelEllipsis
	}
	return out + tgKeyboardLabelEllipsis
}

func tgKeyboardBtn(label, style string) map[string]interface{} {
	btn := map[string]interface{}{"text": tgFitKeyboardLabel(label)}
	if strings.TrimSpace(style) != "" {
		btn["style"] = style
	}
	return btn
}

func tgCollectStyledLabels(meta tgButtonMeta) []string {
	labels := []string{
		strings.TrimSpace(meta.Zh),
		strings.TrimSpace(meta.Vi),
		strings.TrimSpace(meta.En),
		strings.TrimSpace(tgFormatLabel(meta.Zh, meta.Vi, TgLangBoth)),
		strings.TrimSpace(tgButtonLabel(meta, TgLangZh)),
		strings.TrimSpace(tgButtonLabel(meta, TgLangVi)),
		strings.TrimSpace(tgButtonLabel(meta, TgLangEn)),
	}
	for _, legacy := range meta.Legacy {
		if legacy = strings.TrimSpace(legacy); legacy != "" {
			labels = append(labels, legacy)
		}
	}
	extra := make([]string, 0, len(labels))
	for _, label := range labels {
		if fitted := tgFitKeyboardLabel(label); fitted != "" && fitted != label {
			extra = append(extra, fitted)
		}
	}
	return append(labels, extra...)
}

func buildStyledButtonTextLookup() map[string]string {
	lookup := map[string]string{}
	addMeta := func(meta tgButtonMeta) {
		style := strings.TrimSpace(meta.Style)
		if style == "" {
			return
		}
		for _, label := range tgCollectStyledLabels(meta) {
			if label != "" {
				lookup[label] = style
			}
		}
	}
	for _, meta := range tgWorkButtons {
		addMeta(meta)
	}
	for _, meta := range tgUIButtons {
		addMeta(meta)
	}
	return lookup
}

func enrichReplyKeyboardButton(btn map[string]interface{}, lookup map[string]string) {
	text, _ := btn["text"].(string)
	text = strings.TrimSpace(text)
	if text == "" {
		return
	}
	if style, ok := lookup[text]; ok {
		btn["style"] = style
	}
}

func enrichReplyKeyboardStyles(kb map[string]interface{}) map[string]interface{} {
	if kb == nil {
		return nil
	}
	lookup := buildStyledButtonTextLookup()
	rawRows, ok := kb["keyboard"]
	if !ok || rawRows == nil {
		return kb
	}
	switch rows := rawRows.(type) {
	case [][]map[string]interface{}:
		for i := range rows {
			for j := range rows[i] {
				enrichReplyKeyboardButton(rows[i][j], lookup)
			}
		}
		kb["keyboard"] = rows
	case []interface{}:
		for _, row := range rows {
			btnRow, ok := row.([]interface{})
			if !ok {
				continue
			}
			for i, btn := range btnRow {
				switch b := btn.(type) {
				case string:
					if style, ok := lookup[strings.TrimSpace(b)]; ok {
						btnRow[i] = map[string]interface{}{"text": b, "style": style}
					}
				case map[string]interface{}:
					enrichReplyKeyboardButton(b, lookup)
				}
			}
		}
	}
	return kb
}

func tgRegisterLookup(lookup map[string]string, canonical, text string) {
	if text = strings.TrimSpace(text); text == "" {
		return
	}
	lookup[text] = canonical
	if fitted := tgFitKeyboardLabel(text); fitted != text {
		lookup[fitted] = canonical
	}
}

func tgRegisterMeta(lookup map[string]string, key string, meta tgButtonMeta, mode TgLangMode) {
	tgRegisterLookup(lookup, key, meta.Zh)
	tgRegisterLookup(lookup, key, meta.Vi)
	tgRegisterLookup(lookup, key, meta.En)
	tgRegisterLookup(lookup, key, tgButtonLabel(meta, TgLangBoth))
	tgRegisterLookup(lookup, key, tgButtonLabel(meta, TgLangEn))
	for _, legacy := range meta.Legacy {
		tgRegisterLookup(lookup, key, legacy)
	}
}

func (s *WorkforceTelegramService) BuildButtonLookup(ctx context.Context, activityNames []string) map[string]string {
	settings, _ := s.GetSettings(ctx)
	mode := normalizeTgLangMode("")
	if settings != nil {
		mode = normalizeTgLangMode(settings.BotUILang)
	}
	lookup := map[string]string{}
	for key, meta := range tgWorkButtons {
		tgRegisterMeta(lookup, key, meta, mode)
	}
	for key, meta := range tgUIButtons {
		tgRegisterMeta(lookup, key, meta, mode)
	}
	for _, act := range activityNames {
		name := strings.TrimSpace(act)
		if name == "" {
			continue
		}
		tgRegisterLookup(lookup, name, name)
		tgRegisterLookup(lookup, name, tgActivityLabel(name, TgLangZh))
		tgRegisterLookup(lookup, name, tgActivityLabel(name, TgLangVi))
		tgRegisterLookup(lookup, name, tgActivityLabel(name, TgLangBoth))
		tgRegisterLookup(lookup, name, tgActivityKeyboardLabel(name, TgLangZh))
		tgRegisterLookup(lookup, name, tgActivityKeyboardLabel(name, TgLangVi))
		tgRegisterLookup(lookup, name, tgActivityKeyboardLabel(name, TgLangEn))
		tgRegisterLookup(lookup, name, tgActivityKeyboardLabel(name, TgLangBoth))
		tgRegisterLookup(lookup, name, tgActivityDisplayName(name, TgLangEn))
		// Keep previous 小厕/大厕 icons clickable until clients refresh the keyboard.
		if name == "小厕" {
			tgRegisterLookup(lookup, name, "🚽 小厕")
		}
		if name == "大厕" {
			tgRegisterLookup(lookup, name, "🚾 大厕")
		}
	}
	// Legacy slash commands
	tgRegisterLookup(lookup, "back", "/at")
	tgRegisterLookup(lookup, "checkin", "/checkin")
	tgRegisterLookup(lookup, "work_end", "/checkout")
	tgRegisterLookup(lookup, "status", "/status")
	tgRegisterLookup(lookup, "my_record", "/myinfo")
	tgRegisterLookup(lookup, "rank", "/rankings")
	tgRegisterLookup(lookup, "handover", "/handover")
	tgRegisterLookup(lookup, "help", "/start")
	tgRegisterLookup(lookup, "help", "/help")
	tgRegisterLookup(lookup, "my_record_day", "/myinfoday")
	tgRegisterLookup(lookup, "my_record_day", "白班信息")
	tgRegisterLookup(lookup, "my_record_night", "/myinfonight")
	tgRegisterLookup(lookup, "my_record_night", "夜班信息")
	tgRegisterLookup(lookup, "rank_day", "/rankingsday")
	tgRegisterLookup(lookup, "rank_day", "白班排行")
	tgRegisterLookup(lookup, "rank_night", "/rankingsnight")
	tgRegisterLookup(lookup, "rank_night", "夜班排行")
	tgRegisterLookup(lookup, "work_start_day", "白班")
	tgRegisterLookup(lookup, "work_start_night", "夜班")
	tgRegisterLookup(lookup, "export_data", "/export")
	tgRegisterLookup(lookup, "export_data", "/exportmonthly")
	tgRegisterLookup(lookup, "export_data", "导出数据")
	tgRegisterLookup(lookup, "actstatus", "/actstatus")
	tgRegisterLookup(lookup, "showsettings", "/showsettings")
	return lookup
}

func localizedMainReplyKeyboard(mode TgLangMode, dualShift, tripleShift bool, activityNames []string) map[string]interface{} {
	return localizedMainReplyKeyboardEx(mode, dualShift, tripleShift, activityNames, true)
}

func localizedMainReplyKeyboardEx(mode TgLangMode, dualShift, tripleShift bool, activityNames []string, showInfoButtons bool) map[string]interface{} {
	return localizedMainReplyKeyboardWithDevices(mode, dualShift, tripleShift, activityNames, nil, showInfoButtons)
}

func localizedMainReplyKeyboardWithDevices(
	mode TgLangMode, dualShift, tripleShift bool, activityNames []string, deviceTags []workstationDeviceTag, showInfoButtons bool,
) map[string]interface{} {
	if len(deviceTags) >= 2 {
		return localizedMultiDeviceReplyKeyboard(mode, dualShift, tripleShift, activityNames, deviceTags, showInfoButtons)
	}
	var rows [][]map[string]interface{}
	if tripleShift {
		// 白班 / 中班 / 夜班 / 下班 — four buttons on one row
		rows = append(rows, []map[string]interface{}{
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_start_day"], mode), tgWorkButtons["work_start_day"].Style),
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_start_middle"], mode), tgWorkButtons["work_start_middle"].Style),
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_start_night"], mode), tgWorkButtons["work_start_night"].Style),
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_end"], mode), tgWorkButtons["work_end"].Style),
		})
	} else if dualShift {
		rows = append(rows, []map[string]interface{}{
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_start_day"], mode), tgWorkButtons["work_start_day"].Style),
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_start_night"], mode), tgWorkButtons["work_start_night"].Style),
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_end"], mode), tgWorkButtons["work_end"].Style),
		})
	} else {
		rows = append(rows, []map[string]interface{}{
			tgKeyboardBtn(tgButtonLabel(tgUIButtons["checkin"], mode), tgUIButtons["checkin"].Style),
			tgKeyboardBtn(tgButtonLabel(tgWorkButtons["work_end"], mode), tgWorkButtons["work_end"].Style),
		})
	}
	displayNames := make([]string, 0, len(activityNames))
	for _, name := range activityNames {
		displayNames = append(displayNames, tgActivityKeyboardLabel(strings.TrimSpace(name), mode))
	}
	rows = append(rows, buildActivityRowsWithBack(mode, displayNames)...)
	if showInfoButtons {
		rows = append(rows, []map[string]interface{}{
			tgKeyboardBtn(tgButtonLabel(tgUIButtons["my_record"], mode), ""),
			tgKeyboardBtn(tgButtonLabel(tgUIButtons["rank"], mode), ""),
			tgKeyboardBtn(tgButtonLabel(tgUIButtons["export_data"], mode), ""),
		})
	}
	return enrichReplyKeyboardStyles(map[string]interface{}{
		"keyboard":          rows,
		"resize_keyboard":   true,
		"one_time_keyboard": false,
	})
}

func localizedMultiDeviceReplyKeyboard(
	mode TgLangMode, dualShift, tripleShift bool, activityNames []string, deviceTags []workstationDeviceTag, showInfoButtons bool,
) map[string]interface{} {
	var rows [][]map[string]interface{}
	appendTaggedRow := func(label, style string) {
		row := make([]map[string]interface{}, 0, len(deviceTags))
		for _, d := range deviceTags {
			row = append(row, tgKeyboardBtn(JoinTgDeviceTag(label, d.Tag), style))
		}
		// Keep rows readable on mobile: wrap every 2 device buttons.
		for i := 0; i < len(row); i += 2 {
			end := i + 2
			if end > len(row) {
				end = len(row)
			}
			rows = append(rows, row[i:end])
		}
	}

	if tripleShift {
		appendTaggedRow(tgButtonLabel(tgWorkButtons["work_start_day"], mode), tgWorkButtons["work_start_day"].Style)
		appendTaggedRow(tgButtonLabel(tgWorkButtons["work_start_middle"], mode), tgWorkButtons["work_start_middle"].Style)
		appendTaggedRow(tgButtonLabel(tgWorkButtons["work_start_night"], mode), tgWorkButtons["work_start_night"].Style)
		appendTaggedRow(tgButtonLabel(tgWorkButtons["work_end"], mode), tgWorkButtons["work_end"].Style)
	} else if dualShift {
		appendTaggedRow(tgButtonLabel(tgWorkButtons["work_start_day"], mode), tgWorkButtons["work_start_day"].Style)
		appendTaggedRow(tgButtonLabel(tgWorkButtons["work_start_night"], mode), tgWorkButtons["work_start_night"].Style)
		appendTaggedRow(tgButtonLabel(tgWorkButtons["work_end"], mode), tgWorkButtons["work_end"].Style)
	} else {
		appendTaggedRow(tgButtonLabel(tgUIButtons["checkin"], mode), tgUIButtons["checkin"].Style)
		appendTaggedRow(tgButtonLabel(tgWorkButtons["work_end"], mode), tgWorkButtons["work_end"].Style)
	}

	for _, name := range activityNames {
		name = strings.TrimSpace(name)
		if name == "" {
			continue
		}
		appendTaggedRow(tgActivityKeyboardLabel(name, mode), "")
	}
	appendTaggedRow(tgButtonLabel(tgUIButtons["back"], mode), tgUIButtons["back"].Style)

	if showInfoButtons {
		rows = append(rows, []map[string]interface{}{
			tgKeyboardBtn(tgButtonLabel(tgUIButtons["my_record"], mode), ""),
			tgKeyboardBtn(tgButtonLabel(tgUIButtons["rank"], mode), ""),
			tgKeyboardBtn(tgButtonLabel(tgUIButtons["export_data"], mode), ""),
		})
	}
	// selective: in groups only the replied-to / mentioned user receives this keyboard.
	return enrichReplyKeyboardStyles(map[string]interface{}{
		"keyboard":          rows,
		"resize_keyboard":   true,
		"one_time_keyboard": false,
		"selective":         true,
	})
}

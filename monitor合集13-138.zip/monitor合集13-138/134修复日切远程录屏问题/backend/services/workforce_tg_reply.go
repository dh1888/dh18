package services

import (
	"fmt"
	"html"
	"strings"
	"time"
)

func formatTelegramUserLink(telegramUserID int64, displayName string) string {
	name := strings.TrimSpace(displayName)
	if name == "" {
		name = fmt.Sprintf("用户%d", telegramUserID)
	}
	return fmt.Sprintf(`<a href="tg://user?id=%d">%s</a>`, telegramUserID, html.EscapeString(name))
}

func formatEmployeeNameHTML(telegramUserID int64, displayName string) string {
	return formatEmployeeProfileHTML(telegramUserID, "", displayName)
}

func formatEmployeeProfileHTML(telegramUserID int64, telegramUsername, displayName string) string {
	name := strings.TrimSpace(displayName)
	user := strings.TrimPrefix(strings.TrimSpace(telegramUsername), "@")
	if name == "" && looksLikeTelegramUsername(user) {
		name = user
	}
	if telegramUserID > 0 {
		return formatTelegramUserLink(telegramUserID, name)
	}
	if name == "" {
		return "-"
	}
	return html.EscapeString(name)
}

func looksLikeTelegramUsername(s string) bool {
	if len(s) < 5 || len(s) > 32 {
		return false
	}
	for i, r := range s {
		ok := (r >= 'A' && r <= 'Z') || (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '_'
		if i == 0 {
			ok = (r >= 'A' && r <= 'Z') || (r >= 'a' && r <= 'z')
		}
		if !ok {
			return false
		}
	}
	return true
}

func tgCopyableText(text string) string {
	text = strings.TrimSpace(text)
	if text == "" {
		text = "-"
	}
	return "<code>" + html.EscapeString(text) + "</code>"
}

func formatAdminMentionsHTML(ids []int64) string {
	parts := make([]string, 0, len(ids))
	for _, id := range ids {
		if id <= 0 {
			continue
		}
		parts = append(parts, formatTelegramUserLink(id, "管理员"))
	}
	return strings.Join(parts, " ")
}

func resolveWorkStartExpectedTime(now time.Time, recordDate, shift, shiftDetail, startClock string, loc *time.Location) time.Time {
	rd, err := time.ParseInLocation("2006-01-02", recordDate, loc)
	if err != nil {
		rd = now.In(loc)
	}
	_ = shift
	_ = shiftDetail
	// 夜班业务日 = 开班日（含跨午夜）；统一用 recordDate + 上班时刻。
	return combineDateTime(rd, startClock, loc)
}

func resolveWorkEndExpectedTime(now time.Time, recordDate, shift, startClock, endClock string, loc *time.Location) time.Time {
	rd, err := time.ParseInLocation("2006-01-02", recordDate, loc)
	if err != nil {
		rd = now.In(loc)
	}
	sh, sm, okS := parseClock(startClock)
	eh, em, okE := parseClock(endClock)
	nextDay := false
	if okS && okE && clockToMinutes(sh, sm) > clockToMinutes(eh, em) {
		nextDay = true
	} else if (shift == "night" || shift == "middle") && okE && clockToMinutes(eh, em) <= 12*60 {
		nextDay = true
	}
	if nextDay {
		rd = rd.AddDate(0, 0, 1)
	}
	return combineDateTime(rd, endClock, loc)
}

func buildWorkStartGroupReplyHTML(
	mode TgLangMode,
	telegramUserID int64,
	employeeName, shift, shiftDetail string,
	now, expected time.Time,
	lateMin int,
	workFine float64,
	handoverHint string,
	fineCurrency string,
) string {
	_ = shiftDetail
	shiftText := tgReplyShiftLabel(shift, mode)
	actionText := tgReplyLabel("上班", "Đi làm", "Clock in", mode)
	emoji := "👍"
	status := tgReplyLabel("✅ 准时", "✅ Đúng giờ", "✅ On time", mode)

	diffSec := int(now.Sub(expected).Seconds())
	if lateMin > 0 {
		emoji = "😅"
		status = fmt.Sprintf(tgReplyLabel("🚨 迟到 %s", "🚨 Đi muộn %s", "🚨 Late %s", mode), formatDurationForLang(lateMin*60, mode))
		if workFine > 0 {
			status += fmt.Sprintf(tgReplyLabel("\n💰罚款金额: %s", "\n💰 Tiền phạt: %s", "\n💰 Fine: %s", mode), FormatFineAmountWithUnit(workFine, fineCurrency))
		}
	} else if diffSec < 0 {
		status = fmt.Sprintf(tgReplyLabel("✅ 早到 %s", "✅ Đến sớm %s", "✅ Early %s", mode), formatDurationForLang(-diffSec, mode))
	}

	title := fmt.Sprintf(tgReplyLabel("%s%s完成", "%s %s hoàn thành", "%s %s completed", mode), shiftText, actionText)
	msg := fmt.Sprintf(
		"%s <b>%s</b>\n"+
			tgReplyLabel("👤 用户：%s\n", "👤 Người dùng: %s\n", "👤 User: %s\n", mode)+
			tgReplyLabel("⏰ 打卡时间：<code>%s</code>\n", "⏰ Thời gian chấm công: <code>%s</code>\n", "⏰ Clock-in: <code>%s</code>\n", mode)+
			tgReplyLabel("📅 %s时间：<code>%s</code>\n", "📅 Thời gian %s: <code>%s</code>\n", "📅 Expected %s: <code>%s</code>\n", mode)+
			tgReplyLabel("📊 状态：%s", "📊 Trạng thái: %s", "📊 Status: %s", mode),
		emoji, title,
		formatTelegramUserLink(telegramUserID, employeeName),
		now.Format("15:04"),
		actionText, expected.Format("01/02 15:04"),
		status,
	)
	if hint := strings.TrimSpace(handoverHint); hint != "" {
		msg += "\n\n" + hint
	}
	return msg
}

func buildWorkEndGroupReplyHTML(
	mode TgLangMode,
	telegramUserID int64,
	employeeName, shift string,
	now, expected time.Time,
	earlyMin int,
	workFine float64,
	handoverHint, activityWarn string,
	fineCurrency string,
) string {
	shiftText := tgReplyShiftLabel(shift, mode)
	actionText := tgReplyLabel("下班", "Tan ca", "Clock out", mode)
	emoji := "👍"
	status := tgReplyLabel("✅ 准时", "✅ Đúng giờ", "✅ On time", mode)

	diffSec := int(now.Sub(expected).Seconds())
	if earlyMin > 0 {
		emoji = "🏃"
		sec := earlyMin * 60
		if diffSec < 0 {
			sec = -diffSec
		}
		status = fmt.Sprintf(tgReplyLabel("🚨 早退 %s", "🚨 Về sớm %s", "🚨 Early leave %s", mode), formatDurationForLang(sec, mode))
		if workFine > 0 {
			status += fmt.Sprintf(tgReplyLabel("\n💰罚款金额: %s", "\n💰 Tiền phạt: %s", "\n💰 Fine: %s", mode), FormatFineAmountWithUnit(workFine, fineCurrency))
		}
	} else if diffSec > 60 {
		emoji = "⏰"
		status = fmt.Sprintf(tgReplyLabel("✅ 加班 %s", "✅ Làm thêm %s", "✅ Overtime %s", mode), formatDurationForLang(diffSec, mode))
	}

	title := fmt.Sprintf(tgReplyLabel("%s%s完成", "%s %s hoàn thành", "%s %s completed", mode), shiftText, actionText)
	msg := fmt.Sprintf(
		"%s <b>%s</b>\n"+
			tgReplyLabel("👤 用户：%s\n", "👤 Người dùng: %s\n", "👤 User: %s\n", mode)+
			tgReplyLabel("⏰ 打卡时间：<code>%s</code>\n", "⏰ Thời gian chấm công: <code>%s</code>\n", "⏰ Clock-out: <code>%s</code>\n", mode)+
			tgReplyLabel("📅 %s时间：<code>%s</code>\n", "📅 Thời gian %s: <code>%s</code>\n", "📅 Expected %s: <code>%s</code>\n", mode)+
			tgReplyLabel("📊 状态：%s", "📊 Trạng thái: %s", "📊 Status: %s", mode),
		emoji, title,
		formatTelegramUserLink(telegramUserID, employeeName),
		now.Format("15:04"),
		actionText, expected.Format("01/02 15:04"),
		status,
	)
	if hint := strings.TrimSpace(handoverHint); hint != "" {
		msg += "\n\n" + hint
	}
	if warn := strings.TrimSpace(activityWarn); warn != "" {
		msg = appendLocalizedActivityWarnHTML(msg, warn, mode)
	}
	return msg
}

func tgReplyDashedLine() string {
	// Dense ASCII dashes inside <code>: tap-to-copy on mobile, width tuned to
	// a typical phone bubble (26 hyphens). Avoid fullwidth ──── bars.
	return "<code>--------------------------</code>"
}

func buildActivityStartGroupReplyHTML(
	mode TgLangMode,
	telegramUserID int64,
	employeeName, activity, timeStr, shiftText string,
	count, maxTimes, timeLimitMin int,
) string {
	actDisplay := tgActivityDisplayName(activity, mode)
	actEsc := html.EscapeString(actDisplay)
	maxStr := tgReplyUnlimitedLabel(mode)
	if maxTimes > 0 {
		maxStr = fmt.Sprintf("%d", maxTimes)
	}
	shiftEsc := html.EscapeString(shiftText)
	msg := fmt.Sprintf(
		tgReplyLabel("👤 用户：%s\n", "👤 Người dùng: %s\n", "👤 User: %s\n", mode)+
			tgReplyLabel("✅ 打卡成功：<code>%s</code> - <code>%s</code>\n", "✅ Chấm công: <code>%s</code> - <code>%s</code>\n", "✅ Activity started: <code>%s</code> - <code>%s</code>\n", mode),
		formatTelegramUserLink(telegramUserID, employeeName),
		actEsc, html.EscapeString(timeStr),
	)
	if shiftText != "" {
		msg += fmt.Sprintf(tgReplyLabel("📊 班次：<code>%s</code>\n", "📊 Ca: <code>%s</code>\n", "📊 Shift: <code>%s</code>\n", mode), shiftEsc)
	}
	msg += fmt.Sprintf(
		tgReplyLabel(
			"▫️ 本次活动类型：<code>%s</code>\n⏰ 单次时长限制：<code>%d</code>分钟 \n📈 今日<code>%s</code>次数：第 <code>%d</code> 次（上限 <code>%s</code> 次）\n",
			"▫️ Loại hoạt động: <code>%s</code>\n⏰ Giới hạn: <code>%d</code> phút\n📈 Hôm nay <code>%s</code>: lần <code>%d</code> (tối đa <code>%s</code>)\n",
			"▫️ Activity: <code>%s</code>\n⏰ Time limit: <code>%d</code> min\n📈 Today <code>%s</code>: #<code>%d</code> (max <code>%s</code>)\n",
			mode,
		),
		actEsc, timeLimitMin, actEsc, count, html.EscapeString(maxStr),
	)
	if maxTimes > 0 && count >= maxTimes {
		msg += fmt.Sprintf(
			tgReplyLabel(
				"🚨 警告：本次结束后，您今日的<code>%s</code>次数将达到上限，请留意！\n",
				"🚨 Cảnh báo: sau lần này <code>%s</code> sẽ đạt giới hạn hôm nay!\n",
				"🚨 Warning: this will reach today's limit for <code>%s</code>!\n",
				mode,
			),
			actEsc,
		)
	}
	msg += fmt.Sprintf(
		"%s\n%s\n%s",
		tgReplyDashedLine(),
		tgReplyLabel("💡 操作提示", "💡 Gợi ý", "💡 Tip", mode),
		tgReplyLabel(
			"活动结束后请点击下方「回座」按钮，或使用 /at。",
			"Sau khi xong, bấm «Trở lại chỗ ngồi» hoặc dùng /at.",
			"When done, tap Back to seat or use /at.",
			mode,
		),
	)
	return msg
}

func buildActivityEndGroupReplyHTML(
	mode TgLangMode,
	telegramUserID int64,
	employeeName, activity, timeStr string,
	elapsedSec, todayActivityCount, totalActivitySec, totalDailySec, totalDailyCount int,
	activityCounts map[string]int,
	isOvertime bool,
	overtimeSec int,
	fine float64,
	fineCurrency string,
) string {
	actDisplay := tgActivityDisplayName(activity, mode)
	actEsc := html.EscapeString(actDisplay)
	msg := fmt.Sprintf(
		tgReplyLabel("👤 用户：%s\n", "👤 Người dùng: %s\n", "👤 User: %s\n", mode)+
			tgReplyLabel("✅ 回座打卡：<code>%s</code>\n", "✅ Trở lại: <code>%s</code>\n", "✅ Back to seat: <code>%s</code>\n", mode)+
			"%s\n"+
			tgReplyLabel("📍 活动记录\n", "📍 Lịch sử hoạt động\n", "📍 Activity log\n", mode)+
			tgReplyLabel("▫️ 活动类型：<code>%s</code>\n", "▫️ Loại: <code>%s</code>\n", "▫️ Type: <code>%s</code>\n", mode)+
			tgReplyLabel("▫️ 本次耗时：<code>%s</code> ⏰\n", "▫️ Lần này: <code>%s</code> ⏰\n", "▫️ This session: <code>%s</code> ⏰\n", mode)+
			tgReplyLabel("▫️ 累计时长：<code>%s</code>\n", "▫️ Tổng loại: <code>%s</code>\n", "▫️ Type total: <code>%s</code>\n", mode)+
			tgReplyLabel("▫️ 今日次数：<code>%d</code>次\n", "▫️ Số lần hôm nay: <code>%d</code>\n", "▫️ Today count: <code>%d</code>\n", mode),
		formatTelegramUserLink(telegramUserID, employeeName),
		html.EscapeString(timeStr),
		tgReplyDashedLine(),
		actEsc,
		formatDurationForLang(elapsedSec, mode),
		formatDurationForLang(totalActivitySec, mode),
		todayActivityCount,
	)
	if isOvertime && overtimeSec > 0 {
		msg += "\n" + tgReplyLabel("⚠️ 超时提醒\n", "⚠️ Quá giờ\n", "⚠️ Overtime\n", mode)
		msg += fmt.Sprintf(
			tgReplyLabel("▫️ 超时时长：<code>%s</code> 🚨\n", "▫️ Quá giờ: <code>%s</code> 🚨\n", "▫️ Overtime: <code>%s</code> 🚨\n", mode),
			formatDurationForLang(overtimeSec, mode),
		)
		if fine > 0 {
			msg += fmt.Sprintf(
				tgReplyLabel("▫️ 罚款金额：<code>%s</code> 💸\n", "▫️ Tiền phạt: <code>%s</code> 💸\n", "▫️ Fine: <code>%s</code> 💸\n", mode),
				FormatFineAmountWithUnit(fine, fineCurrency),
			)
		}
	}
	msg += tgReplyDashedLine() + "\n"
	msg += tgReplyLabel("📊 今日总计\n▫️ 活动详情\n", "📊 Tổng hôm nay\n▫️ Chi tiết\n", "📊 Today total\n▫️ Details\n", mode)
	for name, count := range activityCounts {
		if count <= 0 {
			continue
		}
		displayName := tgActivityDisplayName(name, mode)
		msg += fmt.Sprintf(
			tgReplyLabel("   ➤ <code>%s</code>：<code>%d</code> 次 📝\n", "   ➤ <code>%s</code>: <code>%d</code> lần 📝\n", "   ➤ <code>%s</code>: <code>%d</code> 📝\n", mode),
			html.EscapeString(displayName), count,
		)
	}
	msg += fmt.Sprintf(
		tgReplyLabel("▫️ 总活动次数：<code>%d</code>次\n", "▫️ Tổng số lần: <code>%d</code>\n", "▫️ Total sessions: <code>%d</code>\n", mode),
		totalDailyCount,
	)
	msg += fmt.Sprintf(
		tgReplyLabel("▫️ 总活动时长：<code>%s</code>", "▫️ Tổng thời gian: <code>%s</code>", "▫️ Total duration: <code>%s</code>", mode),
		formatDurationForLang(totalDailySec, mode),
	)
	return msg
}

func buildActivitySoonTimeoutHTML(mode TgLangMode, telegramUserID int64, employeeName, activity, shiftText string) string {
	actEsc := html.EscapeString(tgActivityDisplayName(activity, mode))
	shiftEsc := html.EscapeString(shiftText)
	return fmt.Sprintf(
		tgReplyLabel(
			"⏳ <b>即将超时警告</b>\n👤 %s\n📊 班次：<code>%s</code>\n🕓 本次 <code>%s</code> 还有 <code>1</code> 分钟！\n💡 请及时回座，避免超时罚款",
			"⏳ <b>Cảnh báo sắp quá giờ</b>\n👤 %s\n📊 Ca: <code>%s</code>\n🕓 <code>%s</code> lần này còn <code>1</code> phút!\n💡 Vui lòng trở lại chỗ ngồi để tránh phạt quá giờ",
			"⏳ <b>Timeout warning</b>\n👤 %s\n📊 Shift: <code>%s</code>\n🕓 Current <code>%s</code> has <code>1</code> minute left!\n💡 Please return to your seat to avoid overtime fines",
			mode,
		),
		formatTelegramUserLink(telegramUserID, employeeName),
		shiftEsc,
		actEsc,
	)
}

func buildActivityOvertimeWarnHTML(mode TgLangMode, telegramUserID int64, employeeName, activity, shiftText string, overtimeMin, variant int) string {
	actEsc := html.EscapeString(tgActivityDisplayName(activity, mode))
	shiftEsc := html.EscapeString(shiftText)
	user := formatTelegramUserLink(telegramUserID, employeeName)
	switch variant {
	case 0:
		return fmt.Sprintf(
			tgReplyLabel(
				"⚠️ <b>超时警告</b>\n👤 %s\n📊 班次：<code>%s</code>\n🕓 本次 <code>%s</code> 已超时\n🏃‍♂️ 请立即回座，避免产生更多罚款！",
				"⚠️ <b>Cảnh báo quá giờ</b>\n👤 %s\n📊 Ca: <code>%s</code>\n🕓 <code>%s</code> lần này đã quá giờ\n🏃‍♂️ Hãy trở lại ngay để tránh phạt thêm!",
				"⚠️ <b>Overtime warning</b>\n👤 %s\n📊 Shift: <code>%s</code>\n🕓 Current <code>%s</code> is overtime\n🏃‍♂️ Please return now to avoid more fines!",
				mode,
			),
			user, shiftEsc, actEsc)
	case 5:
		return fmt.Sprintf(
			tgReplyLabel(
				"🔔 <b>超时警告</b>\n👤 %s\n📊 班次：<code>%s</code>\n🕓 本次 <code>%s</code> 已超时 <code>%d</code> 分钟！\n😤 罚款正在累积，请立即回座！",
				"🔔 <b>Cảnh báo quá giờ</b>\n👤 %s\n📊 Ca: <code>%s</code>\n🕓 <code>%s</code> lần này đã quá <code>%d</code> phút!\n😤 Tiền phạt đang cộng dồn, hãy trở lại ngay!",
				"🔔 <b>Overtime warning</b>\n👤 %s\n📊 Shift: <code>%s</code>\n🕓 Current <code>%s</code> is <code>%d</code> min overtime!\n😤 Fines are accumulating — return now!",
				mode,
			),
			user, shiftEsc, actEsc, overtimeMin)
	default:
		return fmt.Sprintf(
			tgReplyLabel(
				"🚨 <b>超时警告</b>\n👤 %s\n📊 班次：<code>%s</code>\n🕓 本次 <code>%s</code> 已超时 <code>%d</code> 分钟！\n💢 请立刻回座，避免产生更多罚款！",
				"🚨 <b>Cảnh báo quá giờ</b>\n👤 %s\n📊 Ca: <code>%s</code>\n🕓 <code>%s</code> lần này đã quá <code>%d</code> phút!\n💢 Hãy trở lại ngay để tránh phạt thêm!",
				"🚨 <b>Overtime warning</b>\n👤 %s\n📊 Shift: <code>%s</code>\n🕓 Current <code>%s</code> is <code>%d</code> min overtime!\n💢 Return immediately to avoid more fines!",
				mode,
			),
			user, shiftEsc, actEsc, overtimeMin)
	}
}

func buildActivityForceBackHTML(mode TgLangMode, telegramUserID int64, employeeName, activity, shiftText string, overtimeMin int, fineText string) string {
	msg := fmt.Sprintf(
		tgReplyLabel(
			"🛑 <b>自动安全回座</b>\n👤 %s\n📝 活动：<code>%s</code>\n📊 班次：<code>%s</code>\n⚠️ 超时超过%d分钟，系统已自动回座",
			"🛑 <b>Tự động trở lại an toàn</b>\n👤 %s\n📝 Hoạt động: <code>%s</code>\n📊 Ca: <code>%s</code>\n⚠️ Đã quá hơn %d phút, hệ thống đã tự động trở lại",
			"🛑 <b>Automatic return to seat</b>\n👤 %s\n📝 Activity: <code>%s</code>\n📊 Shift: <code>%s</code>\n⚠️ Overtime exceeded %d minutes; the system returned you automatically",
			mode,
		),
		formatTelegramUserLink(telegramUserID, employeeName),
		html.EscapeString(tgActivityDisplayName(activity, mode)),
		html.EscapeString(shiftText),
		overtimeMin,
	)
	if strings.TrimSpace(fineText) != "" {
		msg += fmt.Sprintf(
			tgReplyLabel("\n💰 本次罚款金额：<code>%s</code>", "\n💰 Tiền phạt lần này: <code>%s</code>", "\n💰 Fine this time: <code>%s</code>", mode),
			html.EscapeString(fineText),
		)
	}
	return msg
}

func buildActivitySoonTimeoutPushHTML(chatTitle, employeeName, activity string) string {
	title := html.EscapeString(strings.TrimSpace(chatTitle))
	if title == "" {
		title = "打卡群"
	}
	return fmt.Sprintf(
		"⏳ <b>即将超时提醒</b>\n🏢 群组：<code>%s</code>\n%s\n👤 %s\n📝 活动：<code>%s</code>\n💡 剩余约 1 分钟",
		title, tgReplyDashedLine(), html.EscapeString(employeeName), html.EscapeString(activity),
	)
}

func buildActivityOvertimeBackPushHTML(chatTitle string, telegramUserID int64, telegramUsername, employeeName, activity string, backAt time.Time, overtimeSec int, fine float64, fineCurrency string) string {
	title := html.EscapeString(strings.TrimSpace(chatTitle))
	if title == "" {
		title = "打卡群"
	}
	msg := fmt.Sprintf(
		"🚨 <b>超时回座通知</b>\n🏢 群组：<code>%s</code>\n%s\n"+
			"👤 用户：%s\n📝 活动：<code>%s</code>\n⏰ 回座时间：<code>%s</code>\n⏱️ 超时时长：<code>%s</code>\n",
		title, tgReplyDashedLine(),
		formatEmployeeProfileHTML(telegramUserID, telegramUsername, employeeName),
		html.EscapeString(activity),
		backAt.Format("01/02 15:04:05"),
		formatDurationZh(overtimeSec),
	)
	if fine > 0 {
		msg += fmt.Sprintf("💰 罚款金额：<code>%s</code>", FormatFineAmountWithUnit(fine, fineCurrency))
	}
	return msg
}

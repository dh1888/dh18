package services

import (
	"context"
	"fmt"
	"strings"
)

// NormalizeFineCurrency maps settings / API values to a stable ISO-like code.
// Empty or unknown → CNY (keeps existing ¥ / 元 behavior).
func NormalizeFineCurrency(code string) string {
	switch strings.ToUpper(strings.TrimSpace(code)) {
	case "THB", "฿", "BAHT":
		return "THB"
	case "USD", "$", "US$":
		return "USD"
	case "CNY", "RMB", "¥", "元", "":
		return "CNY"
	default:
		return "CNY"
	}
}

// FineCurrencySymbol is the prefix used in Web / bot money displays.
func FineCurrencySymbol(code string) string {
	switch NormalizeFineCurrency(code) {
	case "THB":
		return "฿"
	case "USD":
		return "$"
	default:
		return "¥"
	}
}

// FineCurrencyUnit is the Chinese unit suffix (replaces hard-coded「元」).
func FineCurrencyUnit(code string) string {
	switch NormalizeFineCurrency(code) {
	case "THB":
		return "泰铢"
	case "USD":
		return "美元"
	default:
		return "元"
	}
}

// FormatFineMoney formats amount with currency symbol prefix (e.g. ¥12.50 / ฿12.50).
func FormatFineMoney(amount float64, code string) string {
	return fmt.Sprintf("%s%.2f", FineCurrencySymbol(code), amount)
}

// FormatFineMoneyWhole formats with no decimals when amount is whole (bot copy often uses %.0f).
func FormatFineMoneyWhole(amount float64, code string) string {
	if amount == float64(int64(amount)) {
		return fmt.Sprintf("%s%.0f", FineCurrencySymbol(code), amount)
	}
	return FormatFineMoney(amount, code)
}

// FormatFineAmountWithUnit e.g. "12 元" / "12 泰铢" for Chinese bot sentences.
func FormatFineAmountWithUnit(amount float64, code string) string {
	if amount == float64(int64(amount)) {
		return fmt.Sprintf("%.0f %s", amount, FineCurrencyUnit(code))
	}
	return fmt.Sprintf("%.2f %s", amount, FineCurrencyUnit(code))
}

func (s *WorkforceTelegramService) FineCurrencyCode(ctx context.Context) string {
	if s == nil {
		return "CNY"
	}
	st, err := s.GetSettings(ctx)
	if err != nil || st == nil {
		return "CNY"
	}
	return NormalizeFineCurrency(st.FineCurrency)
}

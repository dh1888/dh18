package services

import (
	"testing"
	"time"
)

func TestIsHandoverDateClampsShortMonths(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	feb := time.Date(2026, 2, 28, 12, 0, 0, 0, loc)
	if !isHandoverDate(feb, 31, 0) {
		t.Fatal("handover_day=31 must clamp to Feb 28")
	}
	if isHandoverDate(time.Date(2026, 2, 27, 12, 0, 0, 0, loc), 31, 0) {
		t.Fatal("Feb 27 is not handover when day=31")
	}
	apr30 := time.Date(2026, 4, 30, 12, 0, 0, 0, loc)
	if !isHandoverDate(apr30, 0, 0) {
		t.Fatal("handover_day=0 must be last day of month")
	}
	if !isHandoverDate(time.Date(2026, 1, 31, 12, 0, 0, 0, loc), 31, 0) {
		t.Fatal("Jan 31 must still match handover_day=31")
	}
}

func TestResolveAttendanceDateMiddleUsesCalendarDay(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	now := time.Date(2026, 8, 31, 13, 0, 0, 0, loc)
	period := &TgPeriodInfo{BusinessDate: "2026-08-30", IsHandover: true, PeriodType: "handover_night"}
	got := resolveAttendanceDate("middle", "middle_today", period, now, loc)
	if got != "2026-08-31" {
		t.Fatalf("middle_today date = %s, want 2026-08-31", got)
	}
	prev := resolveAttendanceDate("middle", "middle_prev", period, time.Date(2026, 9, 1, 0, 30, 0, 0, loc), loc)
	if prev != "2026-08-31" {
		t.Fatalf("middle_prev date = %s, want 2026-08-31", prev)
	}
}

func TestOvernightCheckInContinuationAndEarlyWindow(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	settings := &TelegramSettings{
		Timezone:    "Asia/Shanghai",
		DayStart:    "09:00",
		DayEnd:      "21:00",
		NightStart:  "21:00",
		NightEnd:    "09:00",
		MiddleStart: "13:00",
		MiddleEnd:   "01:00",
	}
	grace := TgGraceConfig{CheckInBefore: 120, CheckInAfter: 360}
	s := &WorkforceTelegramService{}

	// Middle may check in 120 minutes before 13:00.
	at1200 := time.Date(2026, 8, 17, 12, 0, 0, 0, loc)
	if !s.isCheckInWindowForShift(settings, grace, "middle", at1200) {
		t.Fatal("12:00 should be inside middle check-in window")
	}
	at1259 := time.Date(2026, 8, 17, 12, 59, 0, 0, loc)
	if !s.isCheckInWindowForShift(settings, grace, "middle", at1259) {
		t.Fatal("12:59 should be inside middle check-in window")
	}
	// Overnight tail is check-out time, not check-in.
	at0030 := time.Date(2026, 8, 18, 0, 30, 0, 0, loc)
	if s.isCheckInWindowForShift(settings, grace, "middle", at0030) {
		t.Fatal("00:30 must not be a middle check-in window")
	}
	if !overnightCheckInContinuation(settings, "night", at0030) {
		t.Fatal("00:30 is overnight continuation for night")
	}
	if overnightCheckInContinuation(settings, "middle", at1200) {
		t.Fatal("12:00 is not overnight continuation for middle")
	}
}

func TestResolveWorkEndExpectedTimeOvernightAndHandover(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	now := time.Date(2026, 8, 31, 16, 0, 0, 0, loc)

	middleEnd := resolveWorkEndExpectedTime(now, "2026-08-31", "middle", "13:00", "01:00", loc)
	if middleEnd.Format("2006-01-02 15:04") != "2026-09-01 01:00" {
		t.Fatalf("middle end = %s", middleEnd)
	}
	handoverDayEnd := resolveWorkEndExpectedTime(now, "2026-08-31", "day", "15:00", "09:00", loc)
	if handoverDayEnd.Format("2006-01-02 15:04") != "2026-09-01 09:00" {
		t.Fatalf("handover day end = %s", handoverDayEnd)
	}
	handoverNightEnd := resolveWorkEndExpectedTime(now, "2026-08-30", "night", "21:00", "15:00", loc)
	if handoverNightEnd.Format("2006-01-02 15:04") != "2026-08-31 15:00" {
		t.Fatalf("handover night end = %s", handoverNightEnd)
	}
	normalDayEnd := resolveWorkEndExpectedTime(now, "2026-08-17", "day", "09:00", "21:00", loc)
	if normalDayEnd.Format("2006-01-02 15:04") != "2026-08-17 21:00" {
		t.Fatalf("normal day end = %s", normalDayEnd)
	}
}

func TestIsHandoverRelaySuccessor(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	cfg := &TgHandoverConfigRow{HandoverEnabled: true, HandoverDay: 31, HandoverMonth: 0}
	if !isHandoverRelaySuccessor("day", "2026-09-01", "day", "2026-08-31", cfg, loc) {
		t.Fatal("Sep 1 day after Aug 31 handover day must be successor")
	}
	if isHandoverRelaySuccessor("day", "2026-08-31", "day", "2026-08-31", cfg, loc) {
		t.Fatal("same date is not successor")
	}
	if isHandoverRelaySuccessor("night", "2026-09-01", "day", "2026-08-31", cfg, loc) {
		t.Fatal("night is not a day successor")
	}
	if isHandoverRelaySuccessor("day", "2026-08-16", "day", "2026-08-15", cfg, loc) {
		t.Fatal("Aug 15 is not a handover date")
	}
}

package services

import (
	"crypto/rand"
	"encoding/hex"
	"sync"
	"time"
)

const salaryViewUnlockTTL = 30 * time.Minute

type salaryViewUnlockEntry struct {
	userID    string
	expiresAt time.Time
}

var (
	salaryViewUnlockMu sync.Mutex
	salaryViewUnlocks  = map[string]salaryViewUnlockEntry{}
)

func IssueSalaryViewUnlockToken(userID string) (string, time.Time) {
	tokenBytes := make([]byte, 24)
	_, _ = rand.Read(tokenBytes)
	token := hex.EncodeToString(tokenBytes)
	expiresAt := time.Now().Add(salaryViewUnlockTTL)

	salaryViewUnlockMu.Lock()
	salaryViewUnlocks[token] = salaryViewUnlockEntry{userID: userID, expiresAt: expiresAt}
	salaryViewUnlockMu.Unlock()

	return token, expiresAt
}

func ValidateSalaryViewUnlockToken(userID, token string) bool {
	if userID == "" || token == "" {
		return false
	}
	now := time.Now()

	salaryViewUnlockMu.Lock()
	defer salaryViewUnlockMu.Unlock()

	entry, ok := salaryViewUnlocks[token]
	if !ok {
		return false
	}
	if now.After(entry.expiresAt) {
		delete(salaryViewUnlocks, token)
		return false
	}
	if entry.userID != userID {
		return false
	}
	return true
}

func RevokeSalaryViewUnlockToken(token string) {
	if token == "" {
		return
	}
	salaryViewUnlockMu.Lock()
	delete(salaryViewUnlocks, token)
	salaryViewUnlockMu.Unlock()
}

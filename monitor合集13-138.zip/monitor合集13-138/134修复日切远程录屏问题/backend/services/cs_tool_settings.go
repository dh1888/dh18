package services

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"net/url"
	"regexp"
	"strings"
	"time"
)

const (
	DefaultCsToolUrl    = "https://dh1888.github.io/168/"
	DefaultCsScriptUrl  = "https://dh1888.github.io/render/"
	maxCsToolCustomMenu = 30
)

var csToolMenuIDPattern = regexp.MustCompile(`^[a-z0-9][a-z0-9_-]{0,31}$`)

type CsToolMenuItem struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	URL  string `json:"url"`
}

type CsToolSettings struct {
	ToolUrl     string           `json:"toolUrl"`
	ScriptUrl   string           `json:"scriptUrl"`
	CustomMenus []CsToolMenuItem `json:"customMenus"`
	UpdatedAt   string           `json:"updatedAt,omitempty"`
}

type CsToolSettingsService struct {
	db *sql.DB
}

func NewCsToolSettingsService(db *sql.DB) *CsToolSettingsService {
	return &CsToolSettingsService{db: db}
}

func (s *CsToolSettingsService) GetSettings(ctx context.Context) (*CsToolSettings, error) {
	out := &CsToolSettings{
		ToolUrl:     DefaultCsToolUrl,
		ScriptUrl:   DefaultCsScriptUrl,
		CustomMenus: []CsToolMenuItem{},
	}
	var updatedAt time.Time
	var menusJSON []byte
	err := s.db.QueryRowContext(ctx, `
		SELECT tool_url, script_url, COALESCE(custom_menus, '[]'::jsonb), updated_at
		FROM cs_tool_settings WHERE id = 1`).
		Scan(&out.ToolUrl, &out.ScriptUrl, &menusJSON, &updatedAt)
	if err == sql.ErrNoRows {
		return out, nil
	}
	if err != nil {
		return nil, err
	}
	out.ToolUrl = normalizeCsToolURL(out.ToolUrl, DefaultCsToolUrl)
	out.ScriptUrl = normalizeCsToolURL(out.ScriptUrl, DefaultCsScriptUrl)
	out.CustomMenus = decodeCsToolCustomMenus(menusJSON)
	out.UpdatedAt = updatedAt.UTC().Format(time.RFC3339)
	return out, nil
}

func (s *CsToolSettingsService) SaveSettings(ctx context.Context, in CsToolSettings) (*CsToolSettings, error) {
	toolURL, err := validateCsToolURL(in.ToolUrl, DefaultCsToolUrl)
	if err != nil {
		return nil, err
	}
	scriptURL, err := validateCsToolURL(in.ScriptUrl, DefaultCsScriptUrl)
	if err != nil {
		return nil, err
	}
	menus, err := normalizeCsToolCustomMenus(in.CustomMenus)
	if err != nil {
		return nil, err
	}
	menusJSON, err := json.Marshal(menus)
	if err != nil {
		return nil, err
	}

	_, err = s.db.ExecContext(ctx, `
		INSERT INTO cs_tool_settings (id, tool_url, script_url, custom_menus, updated_at)
		VALUES (1, $1, $2, $3::jsonb, NOW())
		ON CONFLICT (id) DO UPDATE SET
			tool_url = EXCLUDED.tool_url,
			script_url = EXCLUDED.script_url,
			custom_menus = EXCLUDED.custom_menus,
			updated_at = NOW()`,
		toolURL, scriptURL, string(menusJSON))
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func decodeCsToolCustomMenus(raw []byte) []CsToolMenuItem {
	if len(raw) == 0 {
		return []CsToolMenuItem{}
	}
	var items []CsToolMenuItem
	if err := json.Unmarshal(raw, &items); err != nil {
		return []CsToolMenuItem{}
	}
	normalized, err := normalizeCsToolCustomMenus(items)
	if err != nil {
		return []CsToolMenuItem{}
	}
	return normalized
}

func normalizeCsToolCustomMenus(items []CsToolMenuItem) ([]CsToolMenuItem, error) {
	if len(items) > maxCsToolCustomMenu {
		return nil, fmt.Errorf("自定义菜单最多 %d 个", maxCsToolCustomMenu)
	}
	reserved := map[string]bool{"tool": true, "script": true, "custom": true}
	seen := map[string]bool{}
	out := make([]CsToolMenuItem, 0, len(items))
	for _, item := range items {
		id := strings.ToLower(strings.TrimSpace(item.ID))
		name := strings.TrimSpace(item.Name)
		link, err := validateCsToolURL(item.URL, "")
		if err != nil {
			return nil, fmt.Errorf("菜单「%s」跳转地址无效", nameOrID(name, id))
		}
		if id == "" || !csToolMenuIDPattern.MatchString(id) {
			return nil, fmt.Errorf("菜单「%s」标识无效", nameOrID(name, id))
		}
		if reserved[id] {
			return nil, fmt.Errorf("菜单标识 %q 为系统保留", id)
		}
		if seen[id] {
			return nil, fmt.Errorf("菜单标识 %q 重复", id)
		}
		if name == "" {
			return nil, fmt.Errorf("菜单 %q 名称不能为空", id)
		}
		if len([]rune(name)) > 32 {
			return nil, fmt.Errorf("菜单「%s」名称过长", name)
		}
		seen[id] = true
		out = append(out, CsToolMenuItem{ID: id, Name: name, URL: link})
	}
	return out, nil
}

func nameOrID(name, id string) string {
	if strings.TrimSpace(name) != "" {
		return name
	}
	if strings.TrimSpace(id) != "" {
		return id
	}
	return "未命名"
}

func validateCsToolURL(raw, fallback string) (string, error) {
	v := strings.TrimSpace(raw)
	if v == "" {
		if fallback == "" {
			return "", ErrInvalidCsToolURL
		}
		return fallback, nil
	}
	u, err := url.Parse(v)
	if err != nil || u.Scheme == "" || u.Host == "" {
		return "", ErrInvalidCsToolURL
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return "", ErrInvalidCsToolURL
	}
	return u.String(), nil
}

func normalizeCsToolURL(raw, fallback string) string {
	v, err := validateCsToolURL(raw, fallback)
	if err != nil || v == "" {
		return fallback
	}
	return v
}

var ErrInvalidCsToolURL = &csToolURLError{}

type csToolURLError struct{}

func (e *csToolURLError) Error() string { return "跳转地址必须是有效的 http 或 https URL" }

package services

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

const notificationTypeAttendanceReview = "attendance_review_pending"

// NotifyAttendanceReviewPendingUsers inserts popup notifications for users who can open 考勤待确认.
// Layout bell unread also reflects live pending count via the notifications API.
func NotifyAttendanceReviewPendingUsers(
	ctx context.Context,
	db *sql.DB,
	taskID uuid.UUID,
	employeeName, attendanceDate, triggerType string,
) {
	if db == nil || taskID == uuid.Nil {
		return
	}
	kind := "早退"
	if strings.Contains(strings.ToLower(triggerType), "late") {
		kind = "迟到"
	}
	title := "考勤待确认"
	content := fmt.Sprintf("%s 有一条%s考勤异常待确认（%s），请前往【考勤绩效 - 待确认】处理。",
		strings.TrimSpace(employeeName), kind, strings.TrimSpace(attendanceDate))
	payload, _ := json.Marshal(map[string]interface{}{
		"type":           notificationTypeAttendanceReview,
		"taskId":         taskID.String(),
		"employeeName":   employeeName,
		"attendanceDate": attendanceDate,
		"triggerType":    triggerType,
		"path":           "/attendance/review",
	})

	rows, err := db.QueryContext(ctx, `
		SELECT DISTINCT u.id::text
		FROM users u
		JOIN user_roles ur ON ur.user_id = u.id
		JOIN roles r ON r.id = ur.role_id
		WHERE u.status = 1
		  AND (
			LOWER(TRIM(r.name)) IN ('admin', 'administrator', '管理员', '超级管理员', 'superadmin')
			OR EXISTS (
				SELECT 1 FROM jsonb_array_elements_text(r.permissions) AS p(perm)
				WHERE p.perm = $1
			)
		  )`, models.PermAttendanceReviewView)
	if err != nil {
		return
	}
	defer rows.Close()

	taskIDStr := taskID.String()
	for rows.Next() {
		var userID string
		if rows.Scan(&userID) != nil || strings.TrimSpace(userID) == "" {
			continue
		}
		var exists bool
		_ = db.QueryRowContext(ctx, `
			SELECT EXISTS (
				SELECT 1 FROM user_notifications
				WHERE user_id = $1 AND type = $2
				  AND COALESCE(payload->>'taskId','') = $3
			)`, userID, notificationTypeAttendanceReview, taskIDStr).Scan(&exists)
		if exists {
			continue
		}
		_, _ = db.ExecContext(ctx, `
			INSERT INTO user_notifications (id, user_id, type, title, content, payload, is_read, show_popup)
			VALUES ($1, $2, $3, $4, $5, $6, FALSE, TRUE)
		`, uuid.NewString(), userID, notificationTypeAttendanceReview, title, content, payload)
	}
}

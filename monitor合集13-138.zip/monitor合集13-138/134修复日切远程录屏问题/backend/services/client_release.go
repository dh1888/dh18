package services

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

var (
	fileHashCacheMu sync.RWMutex
	fileHashCache   = map[string]cachedFileHash{}
)

type cachedFileHash struct {
	modTime int64
	size    int64
	hash    string
}

// ClientRelease describes installer/update artifacts exposed to agents and the employee portal.
type ClientRelease struct {
	Version             string
	FileName            string
	DownloadURL         string
	UpdatePackageURL    string
	Sha256              string
	UpdateSha256        string
	UpdateSignature     string
	UpdateSigningKeyID  string
	UpdateSignatureAlg  string
	Available           bool
	Mode                string
}

type updatePackageSidecar struct {
	Alg       string `json:"alg"`
	KeyID     string `json:"keyId"`
	Sha256    string `json:"sha256"`
	Signature string `json:"signature"`
}

func ClientReleaseFromEnv() ClientRelease {
	localPath, externalURL, fileName := ResolveClientInstaller()
	version := strings.TrimSpace(os.Getenv("CLIENT_VERSION"))
	updateFile := strings.TrimSpace(os.Getenv("CLIENT_UPDATE_FILE"))
	if updateFile == "" {
		updateFile = "MonitorAgent-update.zip"
	}

	out := ClientRelease{
		Version:  version,
		FileName: fileName,
		Mode:     "api",
	}

	if externalURL != "" {
		out.Mode = "external"
		out.DownloadURL = externalURL
		out.Available = version != ""
		return out
	}

	dir := ClientDownloadDir()
	if _, err := os.Stat(localPath); err == nil {
		out.Available = true
		out.DownloadURL = "/api/v1/employee/client-download/file"
		out.Sha256 = FileSha256HexCached(localPath)
	}

	updatePath := filepath.Join(dir, updateFile)
	if _, err := os.Stat(updatePath); err == nil {
		out.UpdatePackageURL = "/api/v1/meta/client-release/update-package"
		out.UpdateSha256 = FileSha256HexCached(updatePath)
		attachUpdateSignature(&out, updatePath)
		if version != "" {
			out.Available = true
		}
	}

	return out
}

func attachUpdateSignature(out *ClientRelease, updatePath string) {
	if out == nil || out.UpdateSha256 == "" {
		return
	}

	// Prefer publish-time sidecar next to the zip (no private key needed at runtime).
	if sc, err := loadUpdatePackageSidecar(updatePath + ".ed25519.json"); err == nil && sc != nil {
		if strings.EqualFold(strings.TrimSpace(sc.Sha256), out.UpdateSha256) &&
			strings.TrimSpace(sc.Signature) != "" &&
			strings.TrimSpace(sc.KeyID) != "" {
			out.UpdateSignature = strings.TrimSpace(sc.Signature)
			out.UpdateSigningKeyID = strings.TrimSpace(sc.KeyID)
			alg := strings.TrimSpace(sc.Alg)
			if alg == "" {
				alg = "Ed25519"
			}
			out.UpdateSignatureAlg = alg
			return
		}
	}

	// Optional env override for operators who store signature outside the downloads dir.
	sig := strings.TrimSpace(os.Getenv("CLIENT_UPDATE_SIGNATURE"))
	keyID := strings.TrimSpace(os.Getenv("CLIENT_UPDATE_SIGNING_KEY_ID"))
	if keyID == "" {
		keyID = strings.TrimSpace(os.Getenv("UPDATE_SIGNING_KEY_ID"))
	}
	if sig != "" && keyID != "" {
		out.UpdateSignature = sig
		out.UpdateSigningKeyID = keyID
		out.UpdateSignatureAlg = "Ed25519"
	}
}

func loadUpdatePackageSidecar(path string) (*updatePackageSidecar, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var sc updatePackageSidecar
	if err := json.Unmarshal(data, &sc); err != nil {
		return nil, err
	}
	return &sc, nil
}

func ResolveClientInstaller() (localPath, externalURL, fileName string) {
	fileName = strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_FILE"))
	if fileName == "" {
		fileName = "MonitorAgentSetup.exe"
	}

	configured := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_URL"))
	if configured != "" {
		if strings.HasPrefix(configured, "http://") || strings.HasPrefix(configured, "https://") {
			return "", configured, fileName
		}
		dir := ClientDownloadDir()
		if strings.HasPrefix(configured, "/") {
			rel := strings.TrimPrefix(configured, "/downloads/")
			if rel == configured {
				rel = filepath.Base(configured)
			}
			return filepath.Join(dir, rel), "", filepath.Base(rel)
		}
		return filepath.Join(configured), "", filepath.Base(configured)
	}

	return filepath.Join(ClientDownloadDir(), fileName), "", fileName
}

func ClientDownloadDir() string {
	dir := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_DIR"))
	if dir == "" {
		dir = "./downloads"
	}
	return dir
}

func ResolveClientUpdatePackage() (localPath, fileName string) {
	fileName = strings.TrimSpace(os.Getenv("CLIENT_UPDATE_FILE"))
	if fileName == "" {
		fileName = "MonitorAgent-update.zip"
	}
	return filepath.Join(ClientDownloadDir(), fileName), fileName
}

func FileSha256HexCached(path string) string {
	info, err := os.Stat(path)
	if err != nil {
		return ""
	}

	fileHashCacheMu.RLock()
	if cached, ok := fileHashCache[path]; ok && cached.modTime == info.ModTime().UnixNano() && cached.size == info.Size() {
		fileHashCacheMu.RUnlock()
		return cached.hash
	}
	fileHashCacheMu.RUnlock()

	hash := fileSha256Hex(path)
	if hash == "" {
		return ""
	}

	fileHashCacheMu.Lock()
	fileHashCache[path] = cachedFileHash{
		modTime: info.ModTime().UnixNano(),
		size:    info.Size(),
		hash:    hash,
	}
	fileHashCacheMu.Unlock()
	return hash
}

func fileSha256Hex(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}
	return hex.EncodeToString(h.Sum(nil))
}

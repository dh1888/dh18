package services

import (
	"context"
	"fmt"
	"strings"
	"time"
)

func isWithinWindowAsymmetric(nowMin, startMin, endMin, graceBefore, graceAfter int) bool {
	startMin -= graceBefore
	endMin += graceAfter
	if startMin < 0 {
		startMin = 0
	}
	if endMin > 24*60-1 {
		endMin = 24*60 - 1
	}
	if startMin <= endMin {
		return nowMin >= startMin && nowMin <= endMin
	}
	return nowMin >= startMin || nowMin <= endMin
}

func resolveExpectedStartForWindow(now time.Time, startClock string, loc *time.Location, overnightContinuation bool) time.Time {
	expectedStart := combineDateTime(now, startClock, loc)
	if now.Before(expectedStart) && overnightContinuation {
		expectedStart = expectedStart.AddDate(0, 0, -1)
	}
	return expectedStart
}

// overnightCheckInContinuation is true only on the post-midnight tail of an overnight
// shift (e.g. night 00:30 still belongs to yesterday's 21:00 start). Day/middle before
// today's start must keep today's expected start so CheckInBefore works.
func overnightCheckInContinuation(settings *TelegramSettings, shift string, now time.Time) bool {
	if shift != "night" && shift != "middle" {
		return false
	}
	startClock := shiftStartClock(settings, shift)
	endClock := shiftEndClock(settings, shift)
	sh, sm, ok1 := parseClock(startClock)
	eh, em, ok2 := parseClock(endClock)
	if !ok1 || !ok2 {
		return shift == "night" && now.Hour() < 12
	}
	startMin := clockToMinutes(sh, sm)
	endMin := clockToMinutes(eh, em)
	if startMin <= endMin {
		return false
	}
	return minutesOfDay(now) <= endMin
}

func isWithinCheckInWindow(now, expectedStart time.Time, beforeMin, afterMin int) bool {
	earliest := expectedStart.Add(-time.Duration(beforeMin) * time.Minute)
	latest := expectedStart.Add(time.Duration(afterMin) * time.Minute)
	return !now.Before(earliest) && !now.After(latest)
}

func isWithinCheckOutWindow(now, expectedEnd time.Time, beforeMin, afterMin int) bool {
	earliest := expectedEnd.Add(-time.Duration(beforeMin) * time.Minute)
	latest := expectedEnd.Add(time.Duration(afterMin) * time.Minute)
	return !now.Before(earliest) && !now.After(latest)
}

func shiftStartClock(settings *TelegramSettings, shift string) string {
	switch shift {
	case "night":
		return settings.NightStart
	case "middle":
		if strings.TrimSpace(settings.MiddleStart) != "" {
			return settings.MiddleStart
		}
		return "13:00"
	default:
		return settings.DayStart
	}
}

func shiftEndClock(settings *TelegramSettings, shift string) string {
	switch shift {
	case "night":
		return settings.NightEnd
	case "middle":
		if strings.TrimSpace(settings.MiddleEnd) != "" {
			return settings.MiddleEnd
		}
		return "01:00"
	default:
		return settings.DayEnd
	}
}

func (s *WorkforceTelegramService) isCheckInWindowForShift(settings *TelegramSettings, grace TgGraceConfig, shift string, now time.Time) bool {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	startClock := shiftStartClock(settings, shift)
	expectedStart := resolveExpectedStartForWindow(now, startClock, loc, overnightCheckInContinuation(settings, shift, now))
	return isWithinCheckInWindow(now, expectedStart, grace.CheckInBefore, grace.CheckInAfter)
}

func (s *WorkforceTelegramService) validateCheckOutWindow(ctx context.Context, chatID string, settings *TelegramSettings, grace TgGraceConfig, shiftWindowDisabled bool, shift, recordDate string, now time.Time) error {
	if shiftWindowDisabled {
		return nil
	}
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	endClock := s.resolveWorkEndClock(ctx, chatID, settings, shift, recordDate)
	expectedEnd := s.expectedWorkEnd(ctx, chatID, settings, shift, recordDate, now)
	if isWithinCheckOutWindow(now, expectedEnd, grace.CheckOutBefore, grace.CheckOutAfter) {
		return nil
	}
	return &outsideWorkWindowError{Action: "checkout", Shift: shift, Clock: endClock}
}

func resolveNightShiftDetail(settings *TelegramSettings, now time.Time) string {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	nowMin := minutesOfDay(now)
	dayEndH, dayEndM, ok1 := parseClock(settings.DayEnd)
	nightStartH, nightStartM, ok2 := parseClock(settings.NightStart)
	if !ok1 || !ok2 {
		return "night_tonight"
	}
	dayEnd := clockToMinutes(dayEndH, dayEndM)
	nightStart := clockToMinutes(nightStartH, nightStartM)
	if nowMin >= nightStart {
		return "night_tonight"
	}
	if nowMin < dayEnd {
		return "night_last"
	}
	return "night_tonight"
}

func resolveMiddleShiftDetail(settings *TelegramSettings, now time.Time) string {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	nowMin := minutesOfDay(now)
	startH, startM, ok1 := parseClock(shiftStartClock(settings, "middle"))
	endH, endM, ok2 := parseClock(shiftEndClock(settings, "middle"))
	if !ok1 || !ok2 {
		return "middle_today"
	}
	startMin := clockToMinutes(startH, startM)
	endMin := clockToMinutes(endH, endM)
	// Overnight middle (e.g. 13:00–01:00): early-morning hours belong to previous business day.
	if startMin > endMin && nowMin <= endMin {
		return "middle_prev"
	}
	if nowMin >= startMin {
		return "middle_today"
	}
	return "middle_today"
}

func nightRecordDateForDetail(businessDate, detail string) string {
	_ = detail
	return businessDate
}

// resolveAttendanceDate 返回按班次解释的统一业务日（attendance_date）。
func resolveAttendanceDate(shift, shiftDetail string, period *TgPeriodInfo, now time.Time, loc *time.Location) string {
	now = now.In(loc)
	if shift == "day" {
		return now.Format("2006-01-02")
	}
	if shift == "middle" {
		if shiftDetail == "middle_prev" {
			return now.AddDate(0, 0, -1).Format("2006-01-02")
		}
		return now.Format("2006-01-02")
	}
	bd := now.Format("2006-01-02")
	if period != nil && strings.TrimSpace(period.BusinessDate) != "" {
		bd = period.BusinessDate
	}
	return nightRecordDateForDetail(bd, shiftDetail)
}

func (s *WorkforceTelegramService) resolveCurrentShiftWithGrace(settings *TelegramSettings, grace TgGraceConfig, now time.Time) (shift, shiftDetail string, err error) {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)

	if !settings.MultiShiftEnabled() {
		if s.isCheckInWindowForShift(settings, grace, "day", now) {
			return "day", "", nil
		}
		return "", "", ErrOutsideWorkWindow
	}

	if s.isCheckInWindowForShift(settings, grace, "day", now) {
		return "day", "", nil
	}
	if settings.TripleShiftEnabled && s.isCheckInWindowForShift(settings, grace, "middle", now) {
		return "middle", resolveMiddleShiftDetail(settings, now), nil
	}
	if s.isCheckInWindowForShift(settings, grace, "night", now) {
		return "night", resolveNightShiftDetail(settings, now), nil
	}
	return "", "", ErrOutsideWorkWindow
}

func (s *WorkforceTelegramService) isForcedShiftAllowed(settings *TelegramSettings, grace TgGraceConfig, forcedShift string, now time.Time) bool {
	forced, _ := normalizeShiftType(forcedShift)
	return s.isCheckInWindowForShift(settings, grace, forced, now)
}

func shiftDetailForCheckIn(settings *TelegramSettings, shift string, now time.Time) string {
	switch shift {
	case "night":
		return resolveNightShiftDetail(settings, now)
	case "middle":
		return resolveMiddleShiftDetail(settings, now)
	default:
		return ""
	}
}

func (s *WorkforceTelegramService) resolveShiftForCheckIn(settings *TelegramSettings, grace TgGraceConfig, shiftWindowDisabled bool, forcedShift string, now time.Time) (shift, shiftDetail string, err error) {
	if forcedShift != "" {
		shift, err = normalizeShiftType(forcedShift)
		if err != nil {
			return "", "", err
		}
		if shift == "middle" && !settings.TripleShiftEnabled {
			return "", "", fmt.Errorf("三班模式未启用")
		}
		if shiftWindowDisabled {
			return shift, shiftDetailForCheckIn(settings, shift, now), nil
		}
		if !s.isForcedShiftAllowed(settings, grace, forcedShift, now) {
			return "", "", &outsideWorkWindowError{
				Action: "checkin",
				Shift:  shift,
				Clock:  shiftStartClock(settings, shift),
			}
		}
		return shift, shiftDetailForCheckIn(settings, shift, now), nil
	}
	if shiftWindowDisabled {
		if settings.MultiShiftEnabled() {
			if shift, detail, err := s.resolveCurrentShiftWithGrace(settings, grace, now); err == nil {
				return shift, detail, nil
			}
		}
		return "day", "", nil
	}
	return s.resolveCurrentShiftWithGrace(settings, grace, now)
}

func shiftDetailLabel(detail string) string {
	switch strings.TrimSpace(detail) {
	case "night_last":
		return "（昨晚夜班）"
	case "night_tonight":
		return "（今晚夜班）"
	case "middle_prev":
		return "（昨日中班）"
	case "middle_today":
		return "（今日中班）"
	default:
		return ""
	}
}

func (s *WorkforceTelegramService) resolveWorkStartClock(ctx context.Context, chatID string, settings *TelegramSettings, shift, recordDate string) string {
	if settings == nil {
		settings = &TelegramSettings{}
	}
	cfg, _ := s.GetHandoverConfig(ctx, chatID)
	loc := tgLoadLocation(settings.Timezone)
	rd, rdErr := time.ParseInLocation("2006-01-02", recordDate, loc)

	switch shift {
	case "middle":
		return shiftStartClock(settings, "middle")
	case "night":
		start := settings.NightStart
		if cfg != nil && cfg.HandoverEnabled && rdErr == nil {
			if isHandoverDate(rd.AddDate(0, 0, 1), cfg.HandoverDay, cfg.HandoverMonth) && strings.TrimSpace(cfg.NightStartTime) != "" {
				start = cfg.NightStartTime
			}
		}
		if strings.TrimSpace(start) == "" {
			start = shiftStartClock(settings, "night")
		}
		return start
	default:
		start := settings.DayStart
		if cfg != nil && cfg.HandoverEnabled && rdErr == nil && isHandoverDate(rd, cfg.HandoverDay, cfg.HandoverMonth) && strings.TrimSpace(cfg.HandoverDayStartTime) != "" {
			start = cfg.HandoverDayStartTime
		}
		if strings.TrimSpace(start) == "" {
			start = shiftStartClock(settings, "day")
		}
		return start
	}
}

func (s *WorkforceTelegramService) resolveWorkEndClock(ctx context.Context, chatID string, settings *TelegramSettings, shift, recordDate string) string {
	if settings == nil {
		settings = &TelegramSettings{}
	}
	cfg, _ := s.GetHandoverConfig(ctx, chatID)
	loc := tgLoadLocation(settings.Timezone)
	rd, rdErr := time.ParseInLocation("2006-01-02", recordDate, loc)
	if cfg != nil && cfg.HandoverEnabled && rdErr == nil {
		if shift == "day" && isHandoverDate(rd, cfg.HandoverDay, cfg.HandoverMonth) && strings.TrimSpace(cfg.DayStartTime) != "" {
			return cfg.DayStartTime
		}
		if shift == "night" && isHandoverDate(rd.AddDate(0, 0, 1), cfg.HandoverDay, cfg.HandoverMonth) && strings.TrimSpace(cfg.HandoverDayStartTime) != "" {
			return cfg.HandoverDayStartTime
		}
	}
	return shiftEndClock(settings, shift)
}

func (s *WorkforceTelegramService) expectedWorkEnd(ctx context.Context, chatID string, settings *TelegramSettings, shift, recordDate string, now time.Time) time.Time {
	loc := tgLoadLocation(settings.Timezone)
	startClock := s.resolveWorkStartClock(ctx, chatID, settings, shift, recordDate)
	endClock := s.resolveWorkEndClock(ctx, chatID, settings, shift, recordDate)
	return resolveWorkEndExpectedTime(now, recordDate, shift, startClock, endClock, loc)
}

func (s *WorkforceTelegramService) recordDateIsHandoverDay(ctx context.Context, chatID, recordDate string, loc *time.Location) bool {
	cfg, err := s.GetHandoverConfig(ctx, chatID)
	if err != nil || cfg == nil || !cfg.HandoverEnabled {
		return false
	}
	rd, err := time.ParseInLocation("2006-01-02", recordDate, loc)
	if err != nil {
		return false
	}
	return isHandoverDate(rd, cfg.HandoverDay, cfg.HandoverMonth)
}

package services

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/google/uuid"
)

func telegramResetExportDir() string {
	if v := strings.TrimSpace(os.Getenv("TELEGRAM_RESET_EXPORT_DIR")); v != "" {
		return v
	}
	return filepath.Join("uploads", "telegram-reset")
}

func (s *WorkforceTelegramService) exportBeforeReset(ctx context.Context, dateFrom, dateTo, chatID string) (string, error) {
	data, filename, err := s.ExportAttendanceXLSX(ctx, dateFrom, dateTo, chatID)
	if err != nil {
		return "", err
	}
	dir := telegramResetExportDir()
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	path := filepath.Join(dir, filename)
	if err := os.WriteFile(path, data, 0o644); err != nil {
		return "", err
	}
	return path, nil
}

func (s *WorkforceTelegramService) archiveMonthlyStats(ctx context.Context, yearMonth string) error {
	if strings.TrimSpace(yearMonth) == "" {
		return nil
	}
	t, err := time.Parse("2006-01", yearMonth)
	if err != nil {
		return err
	}
	dateFrom := t.Format("2006-01-02")
	dateTo := t.AddDate(0, 1, -1).Format("2006-01-02")

	// Activity totals are merged into wf_tg_monthly_activity_stats on each group daily reset (before purge).

	_, err = s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_monthly_work_stats (
			year_month, chat_id, employee_id, shift_type, session_count, work_fine_total, archived_at
		)
		SELECT $1, COALESCE(b.chat_id,''), ws.employee_id, COALESCE(ws.shift_type,'day'),
			COUNT(*)::int,
			COALESCE((
				SELECT SUM(p.amount) FROM penalty_records p
				WHERE p.employee_id = ws.employee_id AND p.category = 'TG考勤'
				  AND p.penalty_date BETWEEN $2::date AND $3::date
			), 0),
			NOW()
		FROM work_sessions ws
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source IN ('telegram','web') AND ws.attendance_date BETWEEN $2::date AND $3::date
		GROUP BY COALESCE(b.chat_id,''), ws.employee_id, COALESCE(ws.shift_type,'day')
		ON CONFLICT (year_month, chat_id, employee_id, shift_type) DO UPDATE SET
			session_count = EXCLUDED.session_count,
			work_fine_total = EXCLUDED.work_fine_total,
			archived_at = NOW()`, yearMonth, dateFrom, dateTo)
	return err
}

// mergeActivityStatsIntoMonthlyForGroupTx rolls closed activity sessions for one export day into the monthly table (before purge).
func (s *WorkforceTelegramService) mergeActivityStatsIntoMonthlyForGroupTx(ctx context.Context, tx execContext, chatID, exportDate string) error {
	chatID = strings.TrimSpace(chatID)
	exportDate = strings.TrimSpace(exportDate)
	if chatID == "" || exportDate == "" || len(exportDate) < 7 {
		return nil
	}
	yearMonth := exportDate[:7]
	_, err := tx.ExecContext(ctx, `
		INSERT INTO wf_tg_monthly_activity_stats (
			year_month, chat_id, employee_id, shift_type, activity_code, activity_name,
			activity_count, total_seconds, fine_total, archived_at
		)
		SELECT $1, COALESCE(s.source_chat_id,''), s.employee_id, COALESCE(s.shift_type,'day'),
			s.activity_code, s.activity_name,
			COUNT(*)::int, COALESCE(SUM(s.elapsed_seconds),0)::int, COALESCE(SUM(s.fine_amount),0), NOW()
		FROM wf_tg_activity_sessions s
		WHERE s.status = 'closed' AND s.attendance_date = $2::date
		  AND COALESCE(s.source_chat_id,'') = $3
		GROUP BY COALESCE(s.source_chat_id,''), s.employee_id, COALESCE(s.shift_type,'day'),
			s.activity_code, s.activity_name
		ON CONFLICT (year_month, chat_id, employee_id, shift_type, activity_code) DO UPDATE SET
			activity_name = EXCLUDED.activity_name,
			activity_count = wf_tg_monthly_activity_stats.activity_count + EXCLUDED.activity_count,
			total_seconds = wf_tg_monthly_activity_stats.total_seconds + EXCLUDED.total_seconds,
			fine_total = wf_tg_monthly_activity_stats.fine_total + EXCLUDED.fine_total,
			archived_at = NOW()`, yearMonth, exportDate, chatID)
	return err
}

type execContext interface {
	ExecContext(ctx context.Context, query string, args ...interface{}) (sql.Result, error)
}

func (s *WorkforceTelegramService) resetExportDate(settings *TelegramSettings, now time.Time) string {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	resetH, resetM, ok := parseClock(settings.DailyResetTime)
	if !ok {
		return now.AddDate(0, 0, -1).Format("2006-01-02")
	}
	resetToday := time.Date(now.Year(), now.Month(), now.Day(), resetH, resetM, 0, 0, loc)
	if now.Before(resetToday) {
		return now.AddDate(0, 0, -2).Format("2006-01-02")
	}
	return now.AddDate(0, 0, -1).Format("2006-01-02")
}

func (s *WorkforceTelegramService) runDailyResetCore(ctx context.Context, logDate, exportDate string) (*TgDailyResetResult, error) {
	result := &TgDailyResetResult{ResetDate: logDate}

	exportPath, exportErr := s.exportBeforeReset(ctx, exportDate, exportDate, "")
	if exportErr != nil {
		log.Printf("[Telegram] reset export failed for %s: %v — skipping cleanup", exportDate, exportErr)
		return result, fmt.Errorf("reset export failed: %w", exportErr)
	}
	result.ExportPath = exportPath

	if parsed, err := time.Parse("2006-01-02", exportDate); err == nil {
		lastOfMonth := parsed.AddDate(0, 1, -parsed.Day()).Day()
		if parsed.Day() == lastOfMonth {
			month := parsed.Format("2006-01")
			if err := s.archiveMonthlyStats(ctx, month); err != nil {
				log.Printf("[Telegram] monthly archive warning for %s: %v", month, err)
			} else {
				result.ArchivedMonth = month
			}
		}
	}

	empRows, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT employee_id FROM wf_tg_activity_sessions WHERE status = 'open'`)
	if err == nil {
		defer empRows.Close()
		for empRows.Next() {
			var empID uuid.UUID
			if empRows.Scan(&empID) == nil {
				if err := s.forceCloseOpenActivityByEmployee(ctx, empID); err == nil {
					result.ClosedActivities++
				}
			}
		}
	}

	wsRows, err := s.db.QueryContext(ctx, `
		SELECT id, employee_id, COALESCE(shift_type,'day'), attendance_date::text, COALESCE(source,'telegram')
		FROM work_sessions WHERE status = 'open' AND source IN ('telegram','web')`)
	if err == nil {
		defer wsRows.Close()
		for wsRows.Next() {
			var sid, empID uuid.UUID
			var shift, recordDate, sessionSource string
			if wsRows.Scan(&sid, &empID, &shift, &recordDate, &sessionSource) == nil {
				if s.shouldPreserveOpenShiftDuringReset(ctx, empID, recordDate, shift) {
					continue
				}
				s.SyncAgentCaptureStop(ctx, empID, sid)
				if _, err := s.workforce.CheckOutForEmployee(ctx, empID, sessionSource, nil, &sid, &CheckOutOptions{ShiftType: shift}); err == nil {
					result.ClosedWorkSessions++
				}
			}
		}
	}

	_, _ = s.db.ExecContext(ctx, `DELETE FROM wf_tg_group_shift_state`)
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_daily_reset_log (reset_date, closed_work_sessions, closed_activities)
		VALUES ($1::date, $2, $3)
		ON CONFLICT (reset_date) DO UPDATE SET
			closed_work_sessions = EXCLUDED.closed_work_sessions,
			closed_activities = EXCLUDED.closed_activities,
			run_at = NOW()`,
		logDate, result.ClosedWorkSessions, result.ClosedActivities)
	if err != nil {
		return result, err
	}

	_, _ = s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_reset_export_log (reset_date, export_path, archived_month, closed_work_sessions, closed_activities)
		VALUES ($1::date, NULLIF($2,''), NULLIF($3,''), $4, $5)
		ON CONFLICT (reset_date) DO UPDATE SET
			export_path = COALESCE(EXCLUDED.export_path, wf_tg_reset_export_log.export_path),
			archived_month = COALESCE(EXCLUDED.archived_month, wf_tg_reset_export_log.archived_month),
			closed_work_sessions = EXCLUDED.closed_work_sessions,
			closed_activities = EXCLUDED.closed_activities,
			run_at = NOW()`,
		logDate, result.ExportPath, result.ArchivedMonth, result.ClosedWorkSessions, result.ClosedActivities)

	s.pushResetExportToGroups(ctx, exportDate, result.ExportPath)

	return result, nil
}

func (s *WorkforceTelegramService) pushResetExportToGroups(ctx context.Context, exportDate, localPath string) {
	var xlsxData []byte
	var xlsxName string
	if localPath != "" {
		if data, err := os.ReadFile(localPath); err == nil {
			xlsxData = data
			xlsxName = filepath.Base(localPath)
		}
	}
	if len(xlsxData) == 0 {
		data, name, err := s.ExportAttendanceXLSX(ctx, exportDate, exportDate, "")
		if err != nil {
			log.Printf("[Telegram] reset XLSX export failed: %v", err)
			return
		}
		xlsxData, xlsxName = data, name
	}
	groups, err := s.ListGroups(ctx)
	if err != nil {
		return
	}
	caption := fmt.Sprintf("📊 日重置数据导出\n📅 统计日期：%s\n⏰ 导出时间：%s", exportDate, time.Now().Format("2006-01-02 15:04:05"))
	for _, g := range groups {
		if !g.Enabled || strings.TrimSpace(g.ChatID) == "" {
			continue
		}
		s.PushDocumentToChatTargets(ctx, g.ChatID, xlsxName, xlsxData, caption, false)
	}
}

func (s *WorkforceTelegramService) RecoverMissedDailyResets(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	settings, err := s.GetSettings(ctx)
	if err != nil || !settings.DailyResetEnabled {
		return
	}
	groups, err := s.ListGroups(ctx)
	if err != nil {
		return
	}
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)
	resetDate := now.Format("2006-01-02")

	for _, g := range groups {
		if !g.Enabled || strings.TrimSpace(g.ChatID) == "" {
			continue
		}
		if !s.shouldRunScheduledDailyReset(ctx, settings, g.ChatID, now) {
			continue
		}
		exportDate := s.scheduledResetExportDateForChat(ctx, g.ChatID, settings, now)
		opts := &DailyResetRunOptions{ForcedExportDate: exportDate}
		if _, err := s.runDailyResetForGroup(ctx, g.ChatID, resetDate, opts); err != nil {
			log.Printf("[Telegram] recovered missed group reset chat=%s export=%s reset=%s: %v", g.ChatID, exportDate, resetDate, err)
		} else {
			log.Printf("[Telegram] recovered missed group reset chat=%s export=%s reset=%s", g.ChatID, exportDate, resetDate)
		}
	}
}

func (s *WorkforceTelegramService) BuildWorkerReplyKeyboard(ctx context.Context, chatID string) map[string]interface{} {
	return s.BuildWorkerReplyKeyboardForUser(ctx, chatID, 0)
}

// BuildWorkerReplyKeyboardForUser builds the normal bottom reply keyboard.
// Device selection is intentionally not encoded in reply-keyboard labels:
// ambiguous multi-device actions are resolved by a second-step inline picker.
func (s *WorkforceTelegramService) BuildWorkerReplyKeyboardForUser(ctx context.Context, chatID string, telegramUserID int64) map[string]interface{} {
	settings, _ := s.GetSettings(ctx)
	types, _ := s.ListEnabledActivityTypesForWorker(ctx)
	names := make([]string, 0, len(types))
	for _, t := range types {
		if strings.TrimSpace(t.Name) != "" {
			names = append(names, t.Name)
		}
	}
	dual := settings != nil && settings.DualShiftEnabled
	triple := settings != nil && settings.TripleShiftEnabled
	mode := s.keyboardLangForUser(ctx, chatID, telegramUserID)
	showInfo := settings != nil && settings.ShowKeyboardInfoButtons
	kb := enrichReplyKeyboardStyles(localizedMainReplyKeyboardEx(mode, dual, triple, names, showInfo))
	if telegramUserID > 0 && kb != nil {
		// Group chats: only the replied-to user receives this keyboard.
		kb["selective"] = true
	}
	return kb
}

// DeviceTagLegendForTelegram is retained for response compatibility. The
// two-step picker no longer exposes A/B tags in the reply keyboard.
func (s *WorkforceTelegramService) DeviceTagLegendForTelegram(ctx context.Context, telegramUserID int64) string {
	return ""
}

package services

import "testing"

func TestNormalizeCsToolCustomMenus(t *testing.T) {
	got, err := normalizeCsToolCustomMenus([]CsToolMenuItem{
		{ID: "pay", Name: "充值查询", URL: "https://example.com/pay"},
		{ID: "faq", Name: "FAQ", URL: "https://example.com/faq"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 2 || got[0].ID != "pay" {
		t.Fatalf("unexpected: %#v", got)
	}
}

func TestNormalizeCsToolCustomMenusRejectsReservedID(t *testing.T) {
	_, err := normalizeCsToolCustomMenus([]CsToolMenuItem{
		{ID: "tool", Name: "冲突", URL: "https://example.com"},
	})
	if err == nil {
		t.Fatal("expected reserved id error")
	}
}

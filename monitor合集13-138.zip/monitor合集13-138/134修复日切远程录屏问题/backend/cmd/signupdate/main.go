package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"enterprise-agent/backend/security"
)

// Signs an update zip with the DEDICATED update-signing Ed25519 private key.
// Private key must NOT be deployed to the running backend or shipped to agents —
// only used on the build/signing host (see UPDATE_SIGNING_PRIVATE_KEY_PATH).
//
// Usage:
//
//	go run ./cmd/signupdate -file ../downloads/MonitorAgent-update.zip \
//	  -key ../signing-keys/update-ed25519.pem -key-id 2026-07
func main() {
	filePath := flag.String("file", "", "path to MonitorAgent-update.zip")
	keyPath := flag.String("key", "", "Ed25519 private key PEM (default: UPDATE_SIGNING_PRIVATE_KEY_PATH / UPDATE_SIGNING_PRIVATE_KEY; do NOT use policy-ed25519.pem)")
	keyID := flag.String("key-id", "", "signing key id (default: UPDATE_SIGNING_KEY_ID)")
	outPath := flag.String("out", "", "sidecar output path (default: <file>.ed25519.json)")
	flag.Parse()

	if strings.TrimSpace(*filePath) == "" {
		fmt.Fprintln(os.Stderr, "missing -file")
		os.Exit(2)
	}

	id := strings.TrimSpace(*keyID)
	if id == "" {
		id = strings.TrimSpace(os.Getenv("UPDATE_SIGNING_KEY_ID"))
	}
	if id == "" {
		fmt.Fprintln(os.Stderr, "missing -key-id / UPDATE_SIGNING_KEY_ID")
		os.Exit(2)
	}

	explicitKey := strings.TrimSpace(*keyPath)
	resolvedKey := explicitKey
	if resolvedKey == "" {
		resolvedKey = strings.TrimSpace(os.Getenv("UPDATE_SIGNING_PRIVATE_KEY_PATH"))
	}
	if resolvedKey != "" {
		base := strings.ToLower(filepath.Base(resolvedKey))
		if base == "policy-ed25519.pem" {
			if explicitKey == "" {
				fmt.Fprintln(os.Stderr, "REFUSING default/env path policy-ed25519.pem for update signing.")
				fmt.Fprintln(os.Stderr, "Generate a dedicated key: go run ./cmd/genpolicykeys -purpose=update")
				fmt.Fprintln(os.Stderr, "Then set UPDATE_SIGNING_PRIVATE_KEY_PATH to signing-keys/update-ed25519.pem")
				fmt.Fprintln(os.Stderr, "(Emergency override only: pass -key <path> explicitly.)")
				os.Exit(2)
			}
			fmt.Fprintln(os.Stderr, "WARNING: -key points at policy-ed25519.pem; this weakens update-key isolation.")
		}
	}

	priv, err := security.LoadUpdateSigningPrivateKeyFromPathOrEnv(explicitKey)
	if err != nil {
		fmt.Fprintf(os.Stderr, "load private key: %v\n", err)
		fmt.Fprintln(os.Stderr, "Hint: set UPDATE_SIGNING_PRIVATE_KEY_PATH on the build host; do not use the server policy private key.")
		os.Exit(1)
	}

	shaHex, err := fileSHA256Hex(*filePath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "hash file: %v\n", err)
		os.Exit(1)
	}

	sig, err := security.SignUpdatePackageSHA256(shaHex, priv)
	if err != nil {
		fmt.Fprintf(os.Stderr, "sign: %v\n", err)
		os.Exit(1)
	}

	sidecar := map[string]string{
		"alg":       security.UpdatePackageSignatureAlg,
		"keyId":     id,
		"sha256":    shaHex,
		"signature": sig,
	}
	out := strings.TrimSpace(*outPath)
	if out == "" {
		out = *filePath + ".ed25519.json"
	}
	data, err := json.MarshalIndent(sidecar, "", "  ")
	if err != nil {
		fmt.Fprintf(os.Stderr, "marshal: %v\n", err)
		os.Exit(1)
	}
	data = append(data, '\n')
	if err := os.WriteFile(out, data, 0644); err != nil {
		fmt.Fprintf(os.Stderr, "write sidecar: %v\n", err)
		os.Exit(1)
	}

	absFile, _ := filepath.Abs(*filePath)
	absOut, _ := filepath.Abs(out)
	fmt.Printf("signed %s\n  sha256=%s\n  keyId=%s\n  sidecar=%s\n", absFile, shaHex, id, absOut)
}

func fileSHA256Hex(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

func main() {
	purpose := flag.String("purpose", "policy", "key purpose: policy | update")
	outDir := flag.String("out", "", "output directory for private key PEM (policy default: secrets/; update default: ../signing-keys/)")
	flag.Parse()

	switch strings.ToLower(strings.TrimSpace(*purpose)) {
	case "policy", "":
		generatePolicyKeys(*outDir)
	case "update":
		generateUpdateKeys(*outDir)
	default:
		fmt.Fprintf(os.Stderr, "unknown -purpose=%q (use policy or update)\n", *purpose)
		os.Exit(2)
	}
}

func generateKeyMaterial() (ed25519.PrivateKey, string, string) {
	_, privateKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		panic(err)
	}
	publicKey := privateKey.Public().(ed25519.PublicKey)
	publicKeyB64 := base64.StdEncoding.EncodeToString(publicKey)
	keyID := time.Now().UTC().Format("2006-01")
	return privateKey, publicKeyB64, keyID
}

func writePrivateKeyPEM(path string, privateKey ed25519.PrivateKey) {
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		panic(err)
	}
	pemBytes, err := x509.MarshalPKCS8PrivateKey(privateKey)
	if err != nil {
		panic(err)
	}
	pemFile, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
	if err != nil {
		panic(err)
	}
	if err := pem.Encode(pemFile, &pem.Block{Type: "PRIVATE KEY", Bytes: pemBytes}); err != nil {
		panic(err)
	}
	if err := pemFile.Close(); err != nil {
		panic(err)
	}
}

func generatePolicyKeys(outDir string) {
	privateKey, publicKeyB64, keyID := generateKeyMaterial()

	if strings.TrimSpace(outDir) == "" {
		outDir = "secrets"
	}
	pemPath := filepath.Join(outDir, "policy-ed25519.pem")
	writePrivateKeyPEM(pemPath, privateKey)

	regSecret := strings.TrimSpace(os.Getenv("DEVICE_REGISTRATION_SECRET"))
	if regSecret == "" {
		regSecret = "CHANGE_ME_REGISTRATION_SECRET"
	}
	serverURL := strings.TrimSpace(os.Getenv("AGENT_SERVER_URL"))
	if serverURL == "" {
		serverURL = "https://YOUR_PUBLIC_DOMAIN"
	}
	deployment := map[string]any{
		"policyPublicKeys": map[string]string{
			keyID: publicKeyB64,
		},
		// updatePublicKeys must be a SEPARATE keypair (go run ./cmd/genpolicykeys -purpose=update).
		// Do not auto-fill with the policy public key.
		"updatePublicKeys": map[string]string{
			keyID: "GENERATE_WITH_genpolicykeys_-purpose=update",
		},
		"registrationSecret":     regSecret,
		"allowInsecureTransport": os.Getenv("ALLOW_INSECURE_TRANSPORT") == "true",
		"serverUrl":              serverURL,
	}

	repoRoot := filepath.Join("..")
	deploymentPaths := []string{
		filepath.Join(repoRoot, "agent", "deployment.json"),
		filepath.Join(repoRoot, "agent", "publish", "win-x64", "deployment.json"),
	}

	for _, path := range deploymentPaths {
		if err := writeJSON(path, deployment); err != nil {
			fmt.Fprintf(os.Stderr, "warn: %s: %v\n", path, err)
		}
	}

	output := map[string]string{
		"purpose":         "policy",
		"keyId":           keyID,
		"publicKeyBase64": publicKeyB64,
		"privateKeyPem":   pemPath,
		"note":            "Policy private key may live on the backend host. Generate a SEPARATE update key with: go run ./cmd/genpolicykeys -purpose=update",
	}
	encoded, _ := json.MarshalIndent(output, "", "  ")
	fmt.Println(string(encoded))
}

func generateUpdateKeys(outDir string) {
	privateKey, publicKeyB64, keyID := generateKeyMaterial()

	if strings.TrimSpace(outDir) == "" {
		// Keep off the server-deployed secrets tree by default.
		outDir = filepath.Join("..", "signing-keys")
	}
	absOut, err := filepath.Abs(outDir)
	if err != nil {
		absOut = outDir
	}
	slash := strings.ToLower(filepath.ToSlash(absOut))
	if strings.Contains(slash, "/backend/secrets") || strings.HasSuffix(slash, "/backend/secrets") {
		fmt.Fprintln(os.Stderr, "REFUSING to write update signing private key under backend/secrets/.")
		fmt.Fprintln(os.Stderr, "Update private keys must stay on the build/signing host only.")
		os.Exit(1)
	}

	pemPath := filepath.Join(outDir, "update-ed25519.pem")
	writePrivateKeyPEM(pemPath, privateKey)

	fmt.Fprintln(os.Stderr, "")
	fmt.Fprintln(os.Stderr, "=== UPDATE SIGNING KEY — READ CAREFULLY ===")
	fmt.Fprintln(os.Stderr, "This private key must NEVER be copied to backend/secrets/,")
	fmt.Fprintln(os.Stderr, "never appear on the running production server, and must only")
	fmt.Fprintln(os.Stderr, "live on the build/signing workstation used with publish-client.ps1.")
	fmt.Fprintln(os.Stderr, "Set UPDATE_SIGNING_PRIVATE_KEY_PATH to this PEM when signing.")
	fmt.Fprintln(os.Stderr, "Put ONLY the public key into agent deployment.json updatePublicKeys.")
	fmt.Fprintln(os.Stderr, "Do NOT reuse policy-ed25519.pem / policyPublicKeys for updates.")
	fmt.Fprintln(os.Stderr, "==========================================")
	fmt.Fprintln(os.Stderr, "")

	snippet := map[string]any{
		"updatePublicKeys": map[string]string{
			keyID: publicKeyB64,
		},
	}
	snippetJSON, _ := json.MarshalIndent(snippet, "", "  ")

	output := map[string]string{
		"purpose":              "update",
		"keyId":                keyID,
		"publicKeyBase64":      publicKeyB64,
		"privateKeyPem":        pemPath,
		"envPrivateKeyPath":    "UPDATE_SIGNING_PRIVATE_KEY_PATH",
		"envKeyId":             "UPDATE_SIGNING_KEY_ID",
		"deploymentSnippet":    string(snippetJSON),
		"neverDeployPrivateTo": "backend/secrets/ or any production server path",
	}
	encoded, _ := json.MarshalIndent(output, "", "  ")
	fmt.Println(string(encoded))
}

func writeJSON(path string, value any) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	data = append(data, '\n')
	return os.WriteFile(path, data, 0644)
}

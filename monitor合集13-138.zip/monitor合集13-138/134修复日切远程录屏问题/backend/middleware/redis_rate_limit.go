package middleware

import (
	"context"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// RedisRateLimit applies a fixed-window counter in Redis (multi-instance safe).
// Pass limit <= 0 to disable (middleware becomes a no-op).
func RedisRateLimit(redisClient *redis.Client, prefix string, limit int, window time.Duration, keyFn func(*gin.Context) string) gin.HandlerFunc {
	if limit <= 0 {
		return func(c *gin.Context) { c.Next() }
	}
	if window <= 0 {
		window = time.Minute
	}
	if prefix == "" {
		prefix = "rl"
	}

	return func(c *gin.Context) {
		if redisClient == nil {
			if services.IsProductionEnv() {
				models.SendError(c, 503, 5003, "Rate limit service unavailable")
				c.Abort()
				return
			}
			c.Next()
			return
		}
		keyPart := c.ClientIP()
		if keyFn != nil {
			if v := strings.TrimSpace(keyFn(c)); v != "" {
				keyPart = v
			}
		}
		redisKey := fmt.Sprintf("rl:%s:%s", prefix, keyPart)

		ctx, cancel := context.WithTimeout(c.Request.Context(), 2*time.Second)
		defer cancel()

		count, err := redisClient.Incr(ctx, redisKey).Result()
		if err != nil {
			if services.IsProductionEnv() {
				models.SendError(c, 503, 5003, "Rate limit service unavailable")
				c.Abort()
				return
			}
			c.Next()
			return
		}
		if count == 1 {
			_ = redisClient.Expire(ctx, redisKey, window).Err()
		}
		if count > int64(limit) {
			models.SendError(c, 429, 2001, "Too many requests, please try again later")
			c.Abort()
			return
		}
		c.Next()
	}
}

// GlobalAPIRateLimit throttles general API traffic per IP.
// Default OFF (0): admin UI + agents commonly share one NAT/proxy IP, so a low
// global bucket causes site-wide 429. Enable explicitly via env when needed.
// Auth / upload / device / WS keep their dedicated limiters.
func GlobalAPIRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntAllowZero("GLOBAL_API_RATE_LIMIT_PER_MIN", 0)
	if limit <= 0 {
		return func(c *gin.Context) { c.Next() }
	}
	inner := RedisRateLimit(redisClient, "global_api", limit, time.Minute, nil)
	return func(c *gin.Context) {
		if shouldSkipGlobalAPIRateLimit(c.Request.URL.Path) {
			c.Next()
			return
		}
		inner(c)
	}
}

func shouldSkipGlobalAPIRateLimit(path string) bool {
	path = strings.ToLower(path)
	switch {
	case strings.Contains(path, "/auth/"):
		return true
	case strings.Contains(path, "/upload/"):
		return true
	case strings.Contains(path, "/devices/register"),
		strings.Contains(path, "/devices/refresh"),
		strings.Contains(path, "/ws-ticket"):
		// 设备注册/刷新与 WS ticket 有专用限流，且 Agent 重连会短时打满
		return true
	case strings.Contains(path, "/screenshots/") &&
		(strings.Contains(path, "/image") || strings.Contains(path, "/thumbnail")):
		// 截图网格会短时打出大量媒体请求，走鉴权即可，勿与全局限流叠加
		return true
	case strings.Contains(path, "/recordings/") &&
		(strings.Contains(path, "/stream") || strings.Contains(path, "/download")):
		return true
	default:
		return false
	}
}

// UploadCompleteRateLimit limits merge attempts per device.
func UploadCompleteRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntDefault("UPLOAD_COMPLETE_RATE_LIMIT_PER_MIN", 12)
	return RedisRateLimit(redisClient, "upload_complete", limit, time.Minute, func(c *gin.Context) string {
		if id := strings.TrimSpace(c.GetString("deviceID")); id != "" {
			return id
		}
		return c.ClientIP()
	})
}

// UploadChunkRateLimit limits chunk uploads per device (Redis, multi-instance safe).
// Default 600/min ≈ 10/s, aligned with the in-handler IP token bucket so normal
// agents are unaffected. Set UPLOAD_CHUNK_RATE_LIMIT_PER_MIN=0 to disable.
func UploadChunkRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntAllowZero("UPLOAD_CHUNK_RATE_LIMIT_PER_MIN", 600)
	inner := RedisRateLimit(redisClient, "upload_chunk", limit, time.Minute, func(c *gin.Context) string {
		if id := strings.TrimSpace(c.GetString("deviceID")); id != "" {
			return "device:" + id
		}
		return "ip:" + c.ClientIP()
	})
	return func(c *gin.Context) {
		inner(c)
		if c.IsAborted() && c.Writer.Status() == 429 {
			deviceID := strings.TrimSpace(c.GetString("deviceID"))
			services.ObserveSecurity(services.SecuritySignal{
				EventType:   "upload_rate_limited",
				SubjectType: "device",
				SubjectID:   deviceID,
				IP:          c.ClientIP(),
				Reason:      "upload_chunk_rate_limited",
				Details: map[string]interface{}{
					"deviceId": deviceID,
					"path":     c.Request.URL.Path,
				},
			})
		}
	}
}

// WSTicketUserRateLimit limits user WS ticket issuance.
func WSTicketUserRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntDefault("WS_TICKET_RATE_LIMIT_PER_MIN", 30)
	return RedisRateLimit(redisClient, "ws_ticket_user", limit, time.Minute, func(c *gin.Context) string {
		if id := strings.TrimSpace(c.GetString("userID")); id != "" {
			return "user:" + id
		}
		return c.ClientIP()
	})
}

// WSTicketDeviceRateLimit limits device WS ticket issuance.
func WSTicketDeviceRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntDefault("WS_TICKET_RATE_LIMIT_PER_MIN", 30)
	return RedisRateLimit(redisClient, "ws_ticket_device", limit, time.Minute, func(c *gin.Context) string {
		if id := strings.TrimSpace(c.GetString("deviceID")); id != "" {
			return "device:" + id
		}
		return c.ClientIP()
	})
}

// WSHandshakeRateLimit limits WebSocket upgrade attempts per IP.
func WSHandshakeRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntDefault("WS_HANDSHAKE_RATE_LIMIT_PER_MIN", 60)
	return RedisRateLimit(redisClient, "ws_handshake", limit, time.Minute, nil)
}

// InternalOpsAuth protects /metrics and /ready in production (X-Ops-Token or Bearer).
func InternalOpsAuth() gin.HandlerFunc {
	return func(c *gin.Context) {
		if !services.IsProductionEnv() {
			c.Next()
			return
		}
		expected := strings.TrimSpace(os.Getenv("OPS_TOKEN"))
		if expected == "" {
			expected = strings.TrimSpace(os.Getenv("METRICS_TOKEN"))
		}
		if expected == "" {
			models.SendError(c, 503, 5003, "Operations endpoint not configured")
			c.Abort()
			return
		}
		got := strings.TrimSpace(c.GetHeader("X-Ops-Token"))
		if got == "" {
			auth := strings.TrimSpace(c.GetHeader("Authorization"))
			if strings.HasPrefix(auth, "Bearer ") {
				got = strings.TrimSpace(strings.TrimPrefix(auth, "Bearer "))
			}
		}
		if got != expected {
			models.SendError(c, 401, 1002, "Unauthorized")
			c.Abort()
			return
		}
		c.Next()
	}
}

func envIntDefault(key string, def int) int {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil || n <= 0 {
		return def
	}
	return n
}

// envIntAllowZero returns 0 when env is explicitly "0" (used to disable a limiter).
func envIntAllowZero(key string, def int) int {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil || n < 0 {
		return def
	}
	return n
}

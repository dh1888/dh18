package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// AuthenticateTelegramWorker validates the Telegram Worker shared secret from
// X-Telegram-Worker-Secret or Authorization: Bearer. On failure it writes 401
// and returns false (caller should Abort).
func AuthenticateTelegramWorker(c *gin.Context, telegram *services.WorkforceTelegramService) bool {
	secret := strings.TrimSpace(c.GetHeader("X-Telegram-Worker-Secret"))
	if secret == "" {
		secret = strings.TrimSpace(c.GetHeader("Authorization"))
		secret = strings.TrimPrefix(secret, "Bearer ")
	}
	if err := telegram.ValidateWorkerSecret(c.Request.Context(), secret); err != nil {
		models.SendError(c, 401, 1002, "invalid worker secret")
		return false
	}
	return true
}

// TelegramWorkerAuth is a Gin middleware that requires a valid worker secret.
// Mount on the authenticated /telegram/worker subgroup only — do not mount on /pair.
func TelegramWorkerAuth(telegram *services.WorkforceTelegramService) gin.HandlerFunc {
	return func(c *gin.Context) {
		if telegram == nil || !AuthenticateTelegramWorker(c, telegram) {
			if telegram == nil {
				models.SendError(c, 401, 1002, "invalid worker secret")
			}
			c.Abort()
			return
		}
		c.Next()
	}
}

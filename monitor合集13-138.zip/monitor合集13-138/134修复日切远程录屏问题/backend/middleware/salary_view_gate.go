package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

const SalaryViewUnlockHeader = "X-Salary-View-Unlock"

func salaryViewGateBypass(c *gin.Context) bool {
	return UserHasPermission(c, "salary:upload") ||
		UserHasPermission(c, "salary:edit") ||
		UserHasPermission(c, "salary:delete") ||
		UserHasPermission(c, "salary:payment_address:view")
}

// RequireSalaryViewUnlock ensures employees with only salary:view verified the gate password recently.
func RequireSalaryViewUnlock() gin.HandlerFunc {
	return func(c *gin.Context) {
		if salaryViewGateBypass(c) {
			c.Next()
			return
		}
		userID := strings.TrimSpace(c.GetString("userID"))
		token := strings.TrimSpace(c.GetHeader(SalaryViewUnlockHeader))
		if services.ValidateSalaryViewUnlockToken(userID, token) {
			c.Next()
			return
		}
		models.SendError(c, 403, 1012, "请先验证工资查看密码")
		c.Abort()
	}
}

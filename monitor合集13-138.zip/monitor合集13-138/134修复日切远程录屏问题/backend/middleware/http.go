package middleware

import (
	"sync"

	"github.com/gin-gonic/gin"
	"golang.org/x/time/rate"

	"enterprise-agent/backend/models"
)

type ipRateLimiter struct {
	mu       sync.Mutex
	limiters map[string]*rate.Limiter
	limit    rate.Limit
	burst    int
}

func newIPRateLimiter(rps float64, burst int) *ipRateLimiter {
	if rps <= 0 {
		rps = 1
	}
	if burst <= 0 {
		burst = 5
	}
	return &ipRateLimiter{
		limiters: make(map[string]*rate.Limiter),
		limit:    rate.Limit(rps),
		burst:    burst,
	}
}

func (l *ipRateLimiter) getLimiter(ip string) *rate.Limiter {
	l.mu.Lock()
	defer l.mu.Unlock()

	entry, ok := l.limiters[ip]
	if !ok {
		entry = rate.NewLimiter(l.limit, l.burst)
		l.limiters[ip] = entry
	}
	return entry
}

// RateLimitByIP 按客户端 IP 限流
func RateLimitByIP(requestsPerMinute int, burst int) gin.HandlerFunc {
	if requestsPerMinute <= 0 {
		requestsPerMinute = 30
	}
	rps := float64(requestsPerMinute) / 60.0
	limiter := newIPRateLimiter(rps, burst)

	return func(c *gin.Context) {
		if !limiter.getLimiter(c.ClientIP()).Allow() {
			models.SendError(c, 429, 2001, "Too many requests, please try again later")
			c.Abort()
			return
		}
		c.Next()
	}
}

// AuthRateLimit 登录/刷新/登出限流（约 30 次/分钟，突发 10 次）
func AuthRateLimit() gin.HandlerFunc {
	return RateLimitByIP(30, 10)
}

// CaptchaRateLimit 验证码获取限流（约 30 次/分钟，突发 10 次；与登录限流隔离）
func CaptchaRateLimit() gin.HandlerFunc {
	return RateLimitByIP(30, 10)
}

// DeviceTokenRefreshRateLimit 设备 Token 刷新限流（约 60 次/分钟，突发 20 次）
func DeviceTokenRefreshRateLimit() gin.HandlerFunc {
	return RateLimitByIP(60, 20)
}

// DeviceRegisterRateLimit 设备注册限流（约 5 次/分钟，突发 3 次；防批量伪注册）
func DeviceRegisterRateLimit() gin.HandlerFunc {
	return RateLimitByIP(5, 3)
}

// SecurityHeaders 添加常见 HTTP 安全响应头
func SecurityHeaders() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Header("X-Content-Type-Options", "nosniff")
		c.Header("X-Frame-Options", "DENY")
		c.Header("Referrer-Policy", "strict-origin-when-cross-origin")
		c.Header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
		c.Header("X-XSS-Protection", "0")
		if c.GetHeader("X-Forwarded-Proto") == "https" || c.Request.TLS != nil {
			c.Header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
		}
		c.Next()
	}
}

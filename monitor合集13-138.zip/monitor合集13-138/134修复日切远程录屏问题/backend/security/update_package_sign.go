package security

import (
	"crypto/ed25519"
	"encoding/base64"
	"fmt"
	"os"
	"strings"
)

// Update package signatures use a DEDICATED Ed25519 keypair, distinct from
// policy signing (POLICY_SIGNING_*). The update private key must live only on
// the build/signing host (UPDATE_SIGNING_PRIVATE_KEY_PATH) and must never be
// deployed to the running backend. Runtime serves precomputed sidecar metadata.

const (
	UpdatePackageSignatureAlg = "Ed25519"
	// UpdatePackageSignPrefix domain-separates update signatures from policy JCS signatures.
	UpdatePackageSignPrefix = "MonitorAgent-update-v1\n"
)

// UpdatePackageSignMessage builds the exact byte sequence that is Ed25519-signed.
// Input is the lowercase hex SHA-256 of the update zip.
func UpdatePackageSignMessage(sha256Hex string) []byte {
	return []byte(UpdatePackageSignPrefix + strings.ToLower(strings.TrimSpace(sha256Hex)))
}

// SignUpdatePackageSHA256 signs the domain-separated SHA-256 digest of an update package.
func SignUpdatePackageSHA256(sha256Hex string, privateKey ed25519.PrivateKey) (string, error) {
	if len(privateKey) != ed25519.PrivateKeySize {
		return "", fmt.Errorf("invalid Ed25519 private key size")
	}
	hex := strings.ToLower(strings.TrimSpace(sha256Hex))
	if len(hex) != 64 {
		return "", fmt.Errorf("sha256 hex must be 64 chars, got %d", len(hex))
	}
	sig := ed25519.Sign(privateKey, UpdatePackageSignMessage(hex))
	return base64.StdEncoding.EncodeToString(sig), nil
}

// VerifyUpdatePackageSHA256 verifies an update package signature over sha256 hex.
func VerifyUpdatePackageSHA256(sha256Hex, signatureBase64 string, publicKey ed25519.PublicKey) error {
	if len(publicKey) != ed25519.PublicKeySize {
		return fmt.Errorf("invalid Ed25519 public key size")
	}
	hex := strings.ToLower(strings.TrimSpace(sha256Hex))
	if len(hex) != 64 {
		return fmt.Errorf("sha256 hex must be 64 chars")
	}
	sig, err := base64.StdEncoding.DecodeString(strings.TrimSpace(signatureBase64))
	if err != nil {
		return fmt.Errorf("decode signature: %w", err)
	}
	if !ed25519.Verify(publicKey, UpdatePackageSignMessage(hex), sig) {
		return fmt.Errorf("update package signature verification failed")
	}
	return nil
}

// LoadUpdateSigningPrivateKeyFromPathOrEnv loads the dedicated update-signing private key.
// Prefer explicitPath (-key); otherwise UPDATE_SIGNING_PRIVATE_KEY_PATH / UPDATE_SIGNING_PRIVATE_KEY.
// Does NOT fall back to POLICY_SIGNING_* (policy key must stay isolated on the server).
func LoadUpdateSigningPrivateKeyFromPathOrEnv(explicitPath string) (ed25519.PrivateKey, error) {
	if strings.TrimSpace(explicitPath) != "" {
		data, err := os.ReadFile(explicitPath)
		if err != nil {
			return nil, err
		}
		return ParseEd25519PrivateKey(data)
	}
	data, err := loadUpdatePrivateKeyMaterial()
	if err != nil {
		return nil, err
	}
	return ParseEd25519PrivateKey(data)
}

func loadUpdatePrivateKeyMaterial() ([]byte, error) {
	if path := strings.TrimSpace(os.Getenv("UPDATE_SIGNING_PRIVATE_KEY_PATH")); path != "" {
		data, err := os.ReadFile(path)
		if err != nil {
			return nil, fmt.Errorf("read UPDATE_SIGNING_PRIVATE_KEY_PATH: %w", err)
		}
		return data, nil
	}
	if inline := strings.TrimSpace(os.Getenv("UPDATE_SIGNING_PRIVATE_KEY")); inline != "" {
		return []byte(strings.ReplaceAll(inline, `\n`, "\n")), nil
	}
	return nil, fmt.Errorf("UPDATE_SIGNING_PRIVATE_KEY_PATH or UPDATE_SIGNING_PRIVATE_KEY is required (do not use POLICY_SIGNING_* for update packages)")
}

// Deprecated: use LoadUpdateSigningPrivateKeyFromPathOrEnv. Kept temporarily for callers
// that still pass an explicit -key path; no longer falls back to policy env vars.
func LoadEd25519PrivateKeyFromPathOrEnv(explicitPath string) (ed25519.PrivateKey, error) {
	return LoadUpdateSigningPrivateKeyFromPathOrEnv(explicitPath)
}

// ParseEd25519PrivateKey parses PKCS8 PEM, raw seed, or base64 seed.
func ParseEd25519PrivateKey(keyMaterial []byte) (ed25519.PrivateKey, error) {
	return parseEd25519PrivateKey(keyMaterial)
}

// PublicKeyBase64 returns the standard Base64 encoding of an Ed25519 public key.
func PublicKeyBase64(publicKey ed25519.PublicKey) string {
	return base64.StdEncoding.EncodeToString(publicKey)
}

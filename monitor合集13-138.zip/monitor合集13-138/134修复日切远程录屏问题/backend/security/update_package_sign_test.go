package security

import (
	"crypto/ed25519"
	"testing"
)

func TestUpdatePackageSignVerifyRoundTrip(t *testing.T) {
	_, priv, err := ed25519.GenerateKey(nil)
	if err != nil {
		t.Fatal(err)
	}
	pub := priv.Public().(ed25519.PublicKey)
	sha := "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
	sig, err := SignUpdatePackageSHA256(sha, priv)
	if err != nil {
		t.Fatal(err)
	}
	if err := VerifyUpdatePackageSHA256(sha, sig, pub); err != nil {
		t.Fatalf("verify: %v", err)
	}
}

func TestUpdatePackageRejectTamperedHash(t *testing.T) {
	_, priv, err := ed25519.GenerateKey(nil)
	if err != nil {
		t.Fatal(err)
	}
	pub := priv.Public().(ed25519.PublicKey)
	sha := "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	sig, err := SignUpdatePackageSHA256(sha, priv)
	if err != nil {
		t.Fatal(err)
	}
	tampered := "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
	if err := VerifyUpdatePackageSHA256(tampered, sig, pub); err == nil {
		t.Fatal("expected reject for tampered package hash with original signature")
	}
}

func TestUpdatePackageRejectForeignKey(t *testing.T) {
	_, privA, err := ed25519.GenerateKey(nil)
	if err != nil {
		t.Fatal(err)
	}
	_, privB, err := ed25519.GenerateKey(nil)
	if err != nil {
		t.Fatal(err)
	}
	pubB := privB.Public().(ed25519.PublicKey)
	sha := "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"
	sig, err := SignUpdatePackageSHA256(sha, privA)
	if err != nil {
		t.Fatal(err)
	}
	if err := VerifyUpdatePackageSHA256(sha, sig, pubB); err == nil {
		t.Fatal("expected reject for signature from foreign private key")
	}
}

// Core scenario: attacker compromises server, replaces zip + updateSha256, but cannot forge signature.
func TestUpdatePackageRejectServerCompromiseWithoutPrivateKey(t *testing.T) {
	_, legitPriv, err := ed25519.GenerateKey(nil)
	if err != nil {
		t.Fatal(err)
	}
	legitPub := legitPriv.Public().(ed25519.PublicKey)

	originalSHA := "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd"
	legitSig, err := SignUpdatePackageSHA256(originalSHA, legitPriv)
	if err != nil {
		t.Fatal(err)
	}

	attackerSHA := "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"
	if err := VerifyUpdatePackageSHA256(attackerSHA, legitSig, legitPub); err == nil {
		t.Fatal("expected reject when server advertises new sha256 with old signature")
	}

	_, attackerPriv, err := ed25519.GenerateKey(nil)
	if err != nil {
		t.Fatal(err)
	}
	attackerSig, err := SignUpdatePackageSHA256(attackerSHA, attackerPriv)
	if err != nil {
		t.Fatal(err)
	}
	if err := VerifyUpdatePackageSHA256(attackerSHA, attackerSig, legitPub); err == nil {
		t.Fatal("expected reject for attacker self-signed update under legitimate public key")
	}

	if err := VerifyUpdatePackageSHA256(originalSHA, legitSig, legitPub); err != nil {
		t.Fatalf("legit verify failed: %v", err)
	}
}

// Core scenario: attacker has the server-resident POLICY private key, but Agent
// verifies updates with a dedicated updatePublicKey. Forged signatures must fail.
func TestUpdatePackageRejectPolicyPrivateKeyAgainstDedicatedUpdatePublicKey(t *testing.T) {
	_, policyPriv, err := ed25519.GenerateKey(nil)
	if err != nil {
		t.Fatal(err)
	}
	_, updatePriv, err := ed25519.GenerateKey(nil)
	if err != nil {
		t.Fatal(err)
	}
	updatePub := updatePriv.Public().(ed25519.PublicKey)

	sha := "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
	policySig, err := SignUpdatePackageSHA256(sha, policyPriv)
	if err != nil {
		t.Fatal(err)
	}
	if err := VerifyUpdatePackageSHA256(sha, policySig, updatePub); err == nil {
		t.Fatal("expected reject: signature made with policy private key must not verify under dedicated update public key")
	}

	legitSig, err := SignUpdatePackageSHA256(sha, updatePriv)
	if err != nil {
		t.Fatal(err)
	}
	if err := VerifyUpdatePackageSHA256(sha, legitSig, updatePub); err != nil {
		t.Fatalf("dedicated update key round-trip failed: %v", err)
	}
}

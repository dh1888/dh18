package domainmonitor

import (
	"net"
	"strings"

	"enterprise-agent/backend/internal/ssrfguard"
)

func normalizeDomain(d string) string {
	d = strings.TrimSpace(strings.ToLower(d))
	d = strings.TrimPrefix(d, "http://")
	d = strings.TrimPrefix(d, "https://")
	if i := strings.Index(d, "/"); i >= 0 {
		d = d[:i]
	}
	if i := strings.Index(d, ":"); i >= 0 {
		d = d[:i]
	}
	return strings.TrimSuffix(d, ".")
}

func validateDomainName(domain string) error {
	domain = normalizeDomain(domain)
	if domain == "" {
		return fmtErr("domain is empty")
	}
	if len(domain) > 253 {
		return fmtErr("domain too long")
	}
	if strings.Contains(domain, " ") || strings.Contains(domain, "..") {
		return fmtErr("invalid domain format")
	}
	if ip := net.ParseIP(domain); ip != nil {
		if ssrfguard.IsBlockedIP(ip) {
			return fmtErr("domain IP is not allowed (private/loopback/metadata)")
		}
		return nil
	}
	if strings.HasPrefix(domain, ".") || strings.HasSuffix(domain, ".") {
		return fmtErr("invalid domain format")
	}
	labels := strings.Split(domain, ".")
	if len(labels) < 2 {
		return fmtErr("invalid domain: need at least two labels (e.g. example.com)")
	}
	for _, label := range labels {
		if !isValidDomainLabel(label) {
			return fmtErr("invalid domain label: %s", label)
		}
	}
	return nil
}

func isValidDomainLabel(label string) bool {
	if label == "" || len(label) > 63 {
		return false
	}
	if label[0] == '-' || label[len(label)-1] == '-' {
		return false
	}
	for i := 0; i < len(label); i++ {
		c := label[i]
		if (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' {
			continue
		}
		return false
	}
	return true
}

func isValidDomainName(domain string) bool {
	return validateDomainName(domain) == nil
}

func invalidDomainReason(domain string) string {
	if err := validateDomainName(domain); err != nil {
		return err.Error()
	}
	return "域名无效"
}

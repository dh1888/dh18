// Package probechecks 供远程探针 (cmd/dm-probe) 在本地网络环境执行检测。
// DNS 禁止走代理；HTTP/内容/用户模拟可按 spec 选择直连或代理。
package probechecks

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"enterprise-agent/backend/internal/proxytransport"
	"enterprise-agent/backend/internal/ssrfguard"

	"github.com/likexian/whois"
)

const (
	StatusOK       = "ok"
	StatusWarning  = "warning"
	StatusError    = "error"
	StatusCritical = "critical"
)

type Spec struct {
	Type         string   `json:"type"`
	URL          string   `json:"url,omitempty"`
	UseProxy     bool     `json:"useProxy,omitempty"`
	HttpProxyURL string   `json:"httpProxyUrl,omitempty"`
	FastDNS      bool     `json:"fastDns,omitempty"`
	Keywords     []string `json:"keywords,omitempty"`
}

type Result struct {
	CheckType     string `json:"checkType"`
	Status        string `json:"status"`
	DurationMs    int    `json:"durationMs"`
	HTTPStatus    int    `json:"httpStatus,omitempty"`
	FinalURL      string `json:"finalUrl,omitempty"`
	DNSRecords    string `json:"dnsRecords,omitempty"`
	SSLInfo       string `json:"sslInfo,omitempty"`
	RedirectChain string `json:"redirectChain,omitempty"`
	RawDetail     string `json:"rawDetail,omitempty"`
}

var dnsResolver = &net.Resolver{PreferGo: true}

func Run(ctx context.Context, domain string, spec Spec) Result {
	start := time.Now()
	res := Result{CheckType: spec.Type}
	switch spec.Type {
	case "dns":
		rec, st := checkDNS(ctx, domain, spec.FastDNS)
		res.Status = st
		res.DNSRecords = rec
		res.RawDetail = rec
	case "http":
		res = checkHTTP(ctx, domain, spec)
	case "ssl":
		info, st := checkSSL(ctx, domain)
		res.Status = st
		res.SSLInfo = info
		res.RawDetail = info
	case "whois":
		detail, st := checkWhois(ctx, domain)
		res.Status = st
		res.RawDetail = detail
	case "content":
		res = checkContent(ctx, domain, spec)
	case "userSimulation":
		res = checkUserSimulation(ctx, domain, spec)
	default:
		res.Status = StatusError
		res.RawDetail = mustJSON(map[string]string{"error": "unknown check type"})
	}
	if res.DurationMs == 0 {
		res.DurationMs = int(time.Since(start).Milliseconds())
	}
	return res
}

func checkDNS(ctx context.Context, host string, fast bool) (string, string) {
	rec := map[string]interface{}{}
	status := StatusOK
	if ips, err := dnsResolver.LookupHost(ctx, host); err == nil {
		rec["A_AAAA"] = ips
	} else {
		rec["lookupError"] = err.Error()
		status = classifyDNSError(err)
	}
	if !fast {
		if cname, err := dnsResolver.LookupCNAME(ctx, host); err == nil && cname != "" {
			rec["CNAME"] = cname
		}
		if ns, err := dnsResolver.LookupNS(ctx, host); err == nil {
			names := make([]string, 0, len(ns))
			for _, n := range ns {
				names = append(names, n.Host)
			}
			rec["NS"] = names
		}
		if mx, err := dnsResolver.LookupMX(ctx, host); err == nil {
			rec["MX"] = mx
		}
		if txt, err := dnsResolver.LookupTXT(ctx, host); err == nil {
			rec["TXT"] = txt
		}
	}
	return mustJSON(rec), status
}

func classifyDNSError(err error) string {
	msg := strings.ToLower(err.Error())
	if strings.Contains(msg, "no such host") || strings.Contains(msg, "nxdomain") {
		return StatusCritical
	}
	return StatusError
}

func checkHTTP(ctx context.Context, domain string, spec Spec) Result {
	target := spec.URL
	if target == "" {
		target = "https://" + domain
	}
	start := time.Now()
	if err := ssrfguard.ValidateOutboundURL(target); err != nil {
		return Result{
			CheckType:  "http",
			Status:     StatusError,
			DurationMs: int(time.Since(start).Milliseconds()),
			FinalURL:   target,
			RawDetail:  mustJSON(map[string]string{"error": err.Error(), "url": target}),
		}
	}
	client := newHTTPClient(20*time.Second, proxyFor(spec))
	chain := []string{target}
	code := 0
	finalURL := target
	status := StatusOK

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	if err != nil {
		return Result{
			CheckType:  "http",
			Status:     StatusError,
			DurationMs: int(time.Since(start).Milliseconds()),
			RawDetail:  mustJSON(map[string]string{"error": err.Error()}),
		}
	}
	req.Header.Set("User-Agent", "EnterpriseDomainMonitor-Probe/1.0")
	resp, err := client.Do(req)
	if err != nil {
		return Result{
			CheckType:  "http",
			Status:     StatusError,
			DurationMs: int(time.Since(start).Milliseconds()),
			FinalURL:   target,
			RawDetail:  mustJSON(httpErrorDetail(err)),
		}
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	code = resp.StatusCode
	if resp.Request != nil && resp.Request.URL != nil {
		finalURL = resp.Request.URL.String()
		if finalURL != target {
			chain = append(chain, finalURL)
		}
	}
	switch {
	case code >= 200 && code < 400:
		status = StatusOK
	case code == 403 || code == 404:
		status = StatusWarning
	default:
		status = StatusError
	}
	detail := map[string]interface{}{"statusCode": code, "finalUrl": finalURL}
	if spec.UseProxy && spec.HttpProxyURL != "" {
		detail["proxy"] = spec.HttpProxyURL
	}
	return Result{
		CheckType:     "http",
		Status:        status,
		DurationMs:    int(time.Since(start).Milliseconds()),
		HTTPStatus:    code,
		FinalURL:      finalURL,
		RedirectChain: mustJSON(chain),
		RawDetail:     mustJSON(detail),
	}
}

func checkSSL(ctx context.Context, domain string) (string, string) {
	if err := ssrfguard.ValidateOutboundURL("https://" + domain); err != nil {
		return mustJSON(map[string]string{"error": err.Error()}), StatusError
	}
	addr := net.JoinHostPort(domain, "443")
	dialer := &net.Dialer{Timeout: 15 * time.Second}
	rawConn, err := proxytransport.SafeDialContext(dialer)(ctx, "tcp", addr)
	if err != nil {
		return mustJSON(map[string]string{"error": err.Error()}), StatusError
	}
	conn := tls.Client(rawConn, &tls.Config{ServerName: domain, MinVersion: tls.VersionTLS12})
	if err := conn.HandshakeContext(ctx); err != nil {
		rawConn.Close()
		return mustJSON(map[string]string{"error": err.Error()}), StatusError
	}
	defer conn.Close()
	certs := conn.ConnectionState().PeerCertificates
	if len(certs) == 0 {
		return mustJSON(map[string]string{"error": "no certificate"}), StatusError
	}
	leaf := certs[0]
	daysLeft := int(time.Until(leaf.NotAfter).Hours() / 24)
	match := certMatchesDomain(domain, leaf)
	info := map[string]interface{}{
		"daysLeft":      daysLeft,
		"issuer":        leaf.Issuer.String(),
		"notAfter":      leaf.NotAfter.UTC().Format(time.RFC3339),
		"san":           leaf.DNSNames,
		"hostnameMatch": match,
		"commonName":    leaf.Subject.CommonName,
	}
	st := StatusOK
	switch {
	case daysLeft < 0, daysLeft <= 3:
		st = StatusCritical
	case daysLeft <= 7:
		st = StatusError
	case daysLeft <= 30, !match:
		st = StatusWarning
	}
	return mustJSON(info), st
}

func certMatchesDomain(domain string, cert *x509.Certificate) bool {
	domain = strings.TrimSpace(strings.ToLower(domain))
	if domain == "" || cert == nil {
		return false
	}
	if cert.VerifyHostname(domain) == nil {
		return true
	}
	if strings.HasPrefix(domain, "www.") {
		return cert.VerifyHostname(strings.TrimPrefix(domain, "www.")) == nil
	}
	return cert.VerifyHostname("www."+domain) == nil
}

func checkWhois(ctx context.Context, domain string) (string, string) {
	type out struct {
		raw string
		err error
	}
	ch := make(chan out, 1)
	go func() {
		raw, err := whois.Whois(domain)
		ch <- out{raw: raw, err: err}
	}()
	select {
	case <-ctx.Done():
		return mustJSON(map[string]string{"error": "whois timeout"}), StatusError
	case r := <-ch:
		if r.err != nil {
			return mustJSON(map[string]string{"error": r.err.Error()}), StatusError
		}
		return mustJSON(map[string]string{"raw": truncate(r.raw, 4096)}), StatusOK
	}
}

func checkContent(ctx context.Context, domain string, spec Spec) Result {
	target := spec.URL
	if target == "" {
		target = "https://" + domain
	}
	start := time.Now()
	if err := ssrfguard.ValidateOutboundURL(target); err != nil {
		return Result{CheckType: "content", Status: StatusError, DurationMs: int(time.Since(start).Milliseconds()),
			RawDetail: mustJSON(map[string]string{"error": err.Error(), "url": target})}
	}
	client := newHTTPClient(25*time.Second, proxyFor(spec))
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	req.Header.Set("User-Agent", "EnterpriseDomainMonitor-Probe/1.0")
	resp, err := client.Do(req)
	if err != nil {
		return Result{CheckType: "content", Status: StatusError, DurationMs: int(time.Since(start).Milliseconds()),
			RawDetail: mustJSON(map[string]string{"error": err.Error()})}
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
	text := string(body)
	missing := missingKeywords(text, spec.Keywords)
	st := StatusOK
	if len(missing) > 0 {
		st = StatusWarning
	}
	return Result{
		CheckType:  "content",
		Status:     st,
		DurationMs: int(time.Since(start).Milliseconds()),
		HTTPStatus: resp.StatusCode,
		FinalURL:   target,
		RawDetail: mustJSON(map[string]interface{}{
			"missingKeywords": missing,
			"statusCode":      resp.StatusCode,
		}),
	}
}

var (
	reAccessDenied = regexp.MustCompile(`(?i)access denied|geo.?block|not available in your (country|region)`)
	reCloudflare   = regexp.MustCompile(`(?i)cloudflare|cf-challenge|checking your browser`)
	reForbidden    = regexp.MustCompile(`(?i)403 forbidden|forbidden`)
)

func checkUserSimulation(ctx context.Context, domain string, spec Spec) Result {
	target := spec.URL
	if target == "" {
		target = "https://" + domain
	}
	start := time.Now()
	if err := ssrfguard.ValidateOutboundURL(target); err != nil {
		return Result{CheckType: "userSimulation", Status: StatusError, DurationMs: int(time.Since(start).Milliseconds()),
			RawDetail: mustJSON(map[string]string{"error": err.Error(), "url": target, "issue": "ssrf_blocked"})}
	}
	client := newHTTPClient(30*time.Second, proxyFor(spec))
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
	resp, err := client.Do(req)
	if err != nil {
		detail := httpErrorDetail(err)
		detail["issue"] = "load_failed"
		return Result{CheckType: "userSimulation", Status: StatusError, DurationMs: int(time.Since(start).Milliseconds()),
			RawDetail: mustJSON(detail)}
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
	text := string(body)
	finalURL := target
	if resp.Request != nil && resp.Request.URL != nil {
		finalURL = resp.Request.URL.String()
	}
	issues := []string{}
	if resp.StatusCode == 403 {
		issues = append(issues, "403 Forbidden")
	}
	if reAccessDenied.MatchString(text) {
		issues = append(issues, "Access Denied / Geo Block")
	}
	if reCloudflare.MatchString(text) {
		issues = append(issues, "Cloudflare Challenge")
	}
	if reForbidden.MatchString(text) && resp.StatusCode != 403 {
		issues = append(issues, "Forbidden page")
	}
	missing := missingKeywords(text, spec.Keywords)
	if len(missing) > 0 {
		issues = append(issues, "missing keywords: "+strings.Join(missing, ", "))
	}
	if hostFromURL(finalURL) != "" && !hostsEquivalent(domain, hostFromURL(finalURL)) {
		issues = append(issues, "abnormal redirect to "+hostFromURL(finalURL))
	}
	st := StatusOK
	if len(issues) > 0 {
		st = StatusWarning
	}
	if resp.StatusCode >= 500 || resp.StatusCode == 0 {
		st = StatusError
	}
	return Result{
		CheckType:  "userSimulation",
		Status:     st,
		DurationMs: int(time.Since(start).Milliseconds()),
		HTTPStatus: resp.StatusCode,
		FinalURL:   finalURL,
		RawDetail: mustJSON(map[string]interface{}{
			"issues":     issues,
			"statusCode": resp.StatusCode,
			"finalUrl":   finalURL,
			"proxy":      spec.HttpProxyURL,
		}),
	}
}

func missingKeywords(text string, keywords []string) []string {
	if len(keywords) == 0 {
		return nil
	}
	lower := strings.ToLower(text)
	var missing []string
	for _, kw := range keywords {
		kw = strings.TrimSpace(kw)
		if kw == "" {
			continue
		}
		if !strings.Contains(lower, strings.ToLower(kw)) {
			missing = append(missing, kw)
		}
	}
	return missing
}

func proxyFor(spec Spec) string {
	if spec.UseProxy {
		return strings.TrimSpace(spec.HttpProxyURL)
	}
	return ""
}

func newHTTPClient(timeout time.Duration, proxyURL string) *http.Client {
	return proxytransport.NewHTTPClient(timeout, proxyURL)
}

func httpErrorDetail(err error) map[string]interface{} {
	if err == nil {
		return map[string]interface{}{"summary": "HTTP 请求失败"}
	}
	msg := err.Error()
	lower := strings.ToLower(msg)
	summary := "HTTP 请求失败"
	hint := ""
	switch {
	case strings.Contains(msg, "malformed HTTP response"):
		summary = "HTTP 协议不匹配（代理或站点返回了 HTTP/2 二进制帧）"
		hint = "请检查探针/中心节点的 HTTP 代理配置是否正确"
	case strings.Contains(lower, "timeout") || strings.Contains(lower, "deadline exceeded"):
		summary = "连接超时"
	case strings.Contains(lower, "connection refused"):
		summary = "连接被拒绝"
	case strings.Contains(lower, "no such host"):
		summary = "DNS 解析失败"
	}
	out := map[string]interface{}{"summary": summary, "error": msg}
	if hint != "" {
		out["hint"] = hint
	}
	return out
}

func hostFromURL(raw string) string {
	u, err := url.Parse(raw)
	if err != nil || u.Host == "" {
		return ""
	}
	host := u.Host
	if h, _, err := net.SplitHostPort(host); err == nil {
		return h
	}
	return host
}

func normalizeHost(host string) string {
	host = strings.TrimSpace(strings.ToLower(host))
	host = strings.TrimSuffix(host, ".")
	if strings.HasPrefix(host, "www.") {
		host = strings.TrimPrefix(host, "www.")
	}
	return host
}

func hostsEquivalent(a, b string) bool {
	return normalizeHost(a) != "" && normalizeHost(a) == normalizeHost(b)
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

func mustJSON(v interface{}) string {
	b, _ := json.Marshal(v)
	return string(b)
}

func ToMap(r Result) map[string]interface{} {
	m := map[string]interface{}{
		"checkType":  r.CheckType,
		"status":     r.Status,
		"durationMs": r.DurationMs,
	}
	if r.HTTPStatus > 0 {
		m["httpStatus"] = r.HTTPStatus
	}
	if r.FinalURL != "" {
		m["finalUrl"] = r.FinalURL
	}
	if r.DNSRecords != "" {
		m["dnsRecords"] = r.DNSRecords
	}
	if r.SSLInfo != "" {
		m["sslInfo"] = r.SSLInfo
	}
	if r.RedirectChain != "" {
		m["redirectChain"] = r.RedirectChain
	}
	if r.RawDetail != "" {
		m["rawDetail"] = r.RawDetail
	}
	return m
}

package tgbot

import (
	"fmt"
	"html"
	"strings"
)

type tgUserRef struct {
	ID        int64
	Username  string
	FirstName string
	LastName  string
}

func tgUserFromMessage(msg *tgMessage) tgUserRef {
	if msg == nil {
		return tgUserRef{}
	}
	return tgUserRef{
		ID:        msg.From.ID,
		Username:  msg.From.Username,
		FirstName: msg.From.FirstName,
		LastName:  msg.From.LastName,
	}
}

func tgUserFromCallback(cb *tgCallbackQuery) tgUserRef {
	if cb == nil {
		return tgUserRef{}
	}
	return tgUserRef{
		ID:        cb.From.ID,
		Username:  cb.From.Username,
		FirstName: cb.From.FirstName,
		LastName:  cb.From.LastName,
	}
}

func tgUserFromID(id int64) tgUserRef {
	return tgUserRef{ID: id}
}

func (u tgUserRef) displayName() string {
	var parts []string
	if s := strings.TrimSpace(u.FirstName); s != "" {
		parts = append(parts, s)
	}
	if s := strings.TrimSpace(u.LastName); s != "" {
		parts = append(parts, s)
	}
	if name := strings.TrimSpace(strings.Join(parts, " ")); name != "" {
		return name
	}
	user := strings.TrimPrefix(strings.TrimSpace(u.Username), "@")
	if user != "" {
		return "@" + user
	}
	if u.ID > 0 {
		return fmt.Sprintf("用户%d", u.ID)
	}
	return "用户"
}

func (u tgUserRef) htmlProfileLink() string {
	name := u.displayName()
	if u.ID > 0 {
		return fmt.Sprintf(`<a href="tg://user?id=%d">%s</a>`, u.ID, html.EscapeString(name))
	}
	return html.EscapeString(name)
}

func isUnboundAlert(text string) bool {
	return strings.Contains(text, "未绑定") ||
		strings.Contains(text, "尚未绑定") ||
		strings.Contains(text, "Chưa gắn") ||
		strings.Contains(text, "Not bound")
}

func buildUnboundAlertHTML(user tgUserRef) string {
	link := user.htmlProfileLink()
	switch userLang(user.ID) {
	case "vi":
		return fmt.Sprintf(
			"⚠️ %s Bạn chưa gắn Telegram chấm công. Hãy gắn theo cách sau rồi mới chấm công:\n"+
				"Cá nhân: /bind mã mời hoặc /bind tài khoản;\n"+
				"Nhiều máy: /bind_multi tài khoản hoặc /bind_multi mã mời;\n"+
				"Một máy: /bind_workstation mã mời",
			link,
		)
	case "en":
		return fmt.Sprintf(
			"⚠️ %s You have not bound Telegram attendance. Bind first, then punch:\n"+
				"Personal: /bind invite or /bind account;\n"+
				"Multi-PC: /bind_multi account or /bind_multi invite;\n"+
				"Single PC: /bind_workstation invite",
			link,
		)
	default:
		return fmt.Sprintf(
			"⚠️ %s 您还未绑定Telegram打卡群，请按照以下方式绑定后再进行打卡活动：\n"+
				"个人 TG：/bind 邀请码 或 /bind 账号；\n"+
				"多设备工位：/bind_multi 账号 或 /bind_multi 邀请码；\n"+
				"单设备工位：/bind_workstation 邀请码",
			link,
		)
	}
}

func enrichUnboundAlertHTML(user tgUserRef, plainText string) string {
	_ = plainText
	return buildUnboundAlertHTML(user)
}

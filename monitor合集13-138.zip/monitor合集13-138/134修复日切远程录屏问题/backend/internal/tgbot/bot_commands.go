package tgbot

import (
	"bytes"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"log"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	processedUpdates = map[int64]time.Time{}
	cachedAdminIDs   = map[int64]bool{}
	actionRateMu     sync.Mutex
	actionRateCalls  = map[string][]time.Time{}
	botCommandsMu    sync.Mutex
	lastBotCommands  string
)

func isDuplicateUpdate(updateID int64) bool {
	if updateID <= 0 {
		return false
	}
	now := time.Now()
	if exp, ok := processedUpdates[updateID]; ok && exp.After(now) {
		return true
	}
	processedUpdates[updateID] = now.Add(10 * time.Minute)
	if len(processedUpdates) > 5000 {
		for k, v := range processedUpdates {
			if v.Before(now) {
				delete(processedUpdates, k)
			}
		}
	}
	return false
}

func allowActionRate(userID int64, action string, limit int, window time.Duration) bool {
	key := fmt.Sprintf("%d:%s", userID, action)
	actionRateMu.Lock()
	defer actionRateMu.Unlock()
	now := time.Now()
	cutoff := now.Add(-window)
	calls := actionRateCalls[key]
	filtered := calls[:0]
	for _, t := range calls {
		if t.After(cutoff) {
			filtered = append(filtered, t)
		}
	}
	if len(filtered) >= limit {
		actionRateCalls[key] = filtered
		return false
	}
	actionRateCalls[key] = append(filtered, now)
	return true
}

func syncBotCommands(cfg config, commands []map[string]interface{}) {
	if strings.TrimSpace(cfg.BotToken) == "" {
		return
	}
	normalized := normalizeBotCommands(commands)
	if len(normalized) == 0 {
		return
	}
	fp := botCommandsFingerprint(normalized)
	botCommandsMu.Lock()
	if fp == lastBotCommands {
		botCommandsMu.Unlock()
		return
	}
	botCommandsMu.Unlock()

	names := make([]string, 0, len(normalized))
	for _, c := range normalized {
		names = append(names, c["command"])
	}
	log.Printf("setMyCommands: applying %d commands: %s", len(normalized), strings.Join(names, ", "))

	scopes := []map[string]interface{}{
		{"type": "default"},
		{"type": "all_private_chats"},
		{"type": "all_group_chats"},
	}
	staleLangs := []string{"zh", "zh-hans", "zh-hant", "vi", "en"}
	for _, scope := range scopes {
		for _, lang := range staleLangs {
			deleteBotCommandsForScope(cfg, scope, lang)
		}
	}
	ok := true
	for _, scope := range scopes {
		if !setBotCommandsForScope(cfg, normalized, scope, "") {
			ok = false
		}
	}
	if !ok {
		return
	}
	botCommandsMu.Lock()
	lastBotCommands = fp
	botCommandsMu.Unlock()
}

func normalizeBotCommands(raw []map[string]interface{}) []map[string]string {
	seen := map[string]bool{}
	out := make([]map[string]string, 0, len(raw))
	for _, item := range raw {
		if item == nil {
			continue
		}
		cmd := strings.ToLower(strings.TrimSpace(fmt.Sprint(item["command"])))
		desc := strings.TrimSpace(fmt.Sprint(item["description"]))
		if cmd == "<nil>" {
			cmd = ""
		}
		if desc == "<nil>" {
			desc = ""
		}
		if cmd == "" || desc == "" || seen[cmd] || !isTelegramCommandName(cmd) {
			continue
		}
		seen[cmd] = true
		out = append(out, map[string]string{"command": cmd, "description": desc})
	}
	if len(out) > 100 {
		out = out[:100]
	}
	return out
}

func isTelegramCommandName(cmd string) bool {
	if cmd == "" || len(cmd) > 32 {
		return false
	}
	for i := 0; i < len(cmd); i++ {
		c := cmd[i]
		if (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' {
			continue
		}
		return false
	}
	return true
}

func botCommandsFingerprint(commands []map[string]string) string {
	parts := make([]string, 0, len(commands))
	for _, c := range commands {
		parts = append(parts, c["command"]+"="+c["description"])
	}
	return strings.Join(parts, "\n")
}

func deleteBotCommandsForScope(cfg config, scope map[string]interface{}, languageCode string) {
	payload := map[string]interface{}{"scope": scope}
	if languageCode != "" {
		payload["language_code"] = languageCode
	}
	postTelegramAPI(cfg, "deleteMyCommands", payload)
}

func setBotCommandsForScope(cfg config, commands []map[string]string, scope map[string]interface{}, languageCode string) bool {
	payload := map[string]interface{}{
		"commands": commands,
		"scope":    scope,
	}
	if languageCode != "" {
		payload["language_code"] = languageCode
	}
	raw, err := postTelegramAPI(cfg, "setMyCommands", payload)
	if err != nil {
		log.Printf("setMyCommands scope=%v lang=%q: %v", scope["type"], languageCode, err)
		return false
	}
	var parsed struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
	}
	if err := json.Unmarshal(raw, &parsed); err != nil || !parsed.OK {
		log.Printf("setMyCommands scope=%v lang=%q failed: %s", scope["type"], languageCode, strings.TrimSpace(string(raw)))
		return false
	}
	return true
}

func postTelegramAPI(cfg config, method string, payload map[string]interface{}) ([]byte, error) {
	body, err := json.Marshal(payload)
	if err != nil {
		return nil, err
	}
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/%s", cfg.BotToken, method)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	return io.ReadAll(resp.Body)
}

func syncBotCommandsForScope(cfg config, commands []map[string]interface{}, scope map[string]interface{}) {
	setBotCommandsForScope(cfg, normalizeBotCommands(commands), scope, "")
}

func isAdminUser(userID int64) bool {
	return cachedAdminIDs[userID]
}

func parseAdminIDs(raw string) {
	cachedAdminIDs = map[int64]bool{}
	for _, part := range strings.Split(raw, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		var id int64
		if _, err := fmt.Sscanf(part, "%d", &id); err == nil {
			cachedAdminIDs[id] = true
		}
	}
}

func notifyAdminsStartup(cfg config, mode string) {
	for id := range cachedAdminIDs {
		msg := fmt.Sprintf("✅ monitorWin Telegram Worker 已启动\n模式：%s", mode)
		_ = sendTelegramWithMarkup(cfg, id, msg, nil)
	}
}

func handleSlashCommand(cfg config, msg *tgMessage) bool {
	if msg == nil {
		return false
	}
	text := strings.TrimSpace(msg.Text)
	if !strings.HasPrefix(text, "/") {
		return false
	}
	chatID := strconv.FormatInt(msg.Chat.ID, 10)
	userID := msg.From.ID
	user := tgUserFromMessage(msg)
	parts := strings.Fields(text)
	cmd := strings.TrimPrefix(strings.ToLower(parts[0]), "/")
	if i := strings.Index(cmd, "@"); i > 0 {
		cmd = cmd[:i]
	}
	args := ""
	if len(parts) > 1 {
		args = strings.Join(parts[1:], " ")
	}

	switch cmd {
	case "start":
		if args != "" {
			payload := strings.TrimSpace(args)
			if strings.HasPrefix(strings.ToLower(payload), "bind_") {
				payload = strings.TrimPrefix(payload, "bind_")
				payload = strings.TrimPrefix(payload, "BIND_")
			}
			if payload != "" {
				replyBind(cfg, userID, msg.From.Username, chatID, payload, msg.Chat.ID, msg.MessageID)
				return true
			}
		}
		replyHelp(cfg, msg)
		return true
	case "bind":
		replyBind(cfg, userID, msg.From.Username, chatID, args, msg.Chat.ID, msg.MessageID)
		return true
	case "bind_multi":
		replyBindMulti(cfg, userID, msg.From.Username, chatID, args, msg.Chat.ID, msg.MessageID)
		return true
	case "bind_workstation":
		replyBindWorkstation(cfg, userID, msg.From.Username, chatID, args, msg.Chat.ID, msg.MessageID)
		return true
	case "help":
		replyHelp(cfg, msg)
		return true
	case "lang", "language", "lang_zh", "lang_vi", "lang_en":
		langArg := args
		switch cmd {
		case "lang_zh":
			langArg = "zh"
		case "lang_vi":
			langArg = "vi"
		case "lang_en":
			langArg = "en"
		}
		replyLangSwitch(cfg, msg, langArg)
		return true
	case "chatid", "groupid", "channelid", "id", "群id", "频道id":
		replyChatID(cfg, msg.Chat.ID, msg.Chat.Type, msg.Chat.Title, msg.MessageID)
		return true
	case "checkin", "checkin_day", "checkin_middle", "checkin_night":
		shift := args
		switch cmd {
		case "checkin_day":
			shift = "day"
		case "checkin_middle":
			shift = "middle"
		case "checkin_night":
			shift = "night"
		default:
			if shift != "day" && shift != "night" && shift != "middle" {
				shift = ""
			}
		}
		arg := shift
		if arg == "" {
			arg = "-"
		}
		withDeviceSelection(cfg, userID, chatID, msg.MessageID, "ci", arg,
			"请选择上班设备", func() {
				replyCheckIn(cfg, user, chatID, shift, msg.MessageID, "")
			})
		return true
	case "checkout":
		withDeviceSelection(cfg, userID, chatID, msg.MessageID, "co", "-",
			"请选择下班设备", func() {
				replyCheckOut(cfg, user, chatID, msg.MessageID, "")
			})
		return true
	case "at":
		withDeviceSelection(cfg, userID, chatID, msg.MessageID, "bk", "-",
			"请选择回座设备", func() {
				replyEndActivity(cfg, user, chatID, msg.MessageID, "")
			})
		return true
	case "status":
		replyStatus(cfg, userID)
		return true
	case "myinfo", "myinfoday", "myinfomiddle", "myinfonight":
		shift := ""
		switch cmd {
		case "myinfoday":
			shift = "day"
		case "myinfomiddle":
			shift = "middle"
		case "myinfonight":
			shift = "night"
		}
		replyMyInfo(cfg, user, chatID, shift, msg.MessageID)
		return true
	case "rankings", "rankingsday", "rankingsmiddle", "rankingsnight":
		shift := ""
		switch cmd {
		case "rankingsday":
			shift = "day"
		case "rankingsmiddle":
			shift = "middle"
		case "rankingsnight":
			shift = "night"
		}
		replyRankings(cfg, user, chatID, shift, msg.MessageID)
		return true
	case "handover":
		replyHandover(cfg, userID, args)
		return true
	case "export":
		if !allowActionRate(userID, "export", 2, time.Minute) {
			_ = sendTelegramByUser(cfg, userID, tRateLimited())
			return true
		}
		path := fmt.Sprintf("/telegram/worker/export?chatId=%s", url.QueryEscape(chatID))
		var res struct {
			Code int `json:"code"`
			Data struct {
				Caption string `json:"caption"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err != nil {
			_ = sendTelegramByUser(cfg, userID, "导出失败："+err.Error())
			return true
		}
		msg := res.Data.Caption
		if msg == "" {
			msg = "导出已推送到群组"
		}
		_ = sendTelegramByUser(cfg, userID, msg)
		return true
	case "exportmonthly":
		if !allowActionRate(userID, "export", 2, time.Minute) {
			_ = sendTelegramByUser(cfg, userID, tRateLimited())
			return true
		}
		month := args
		if month == "" {
			month = time.Now().AddDate(0, -1, 0).Format("2006-01")
		}
		path := fmt.Sprintf("/telegram/worker/export?chatId=%s&month=%s", url.QueryEscape(chatID), url.QueryEscape(month))
		var res struct {
			Code int `json:"code"`
			Data struct {
				Caption string `json:"caption"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err != nil {
			_ = sendTelegramByUser(cfg, userID, "导出失败："+err.Error())
			return true
		}
		msg := res.Data.Caption
		if msg == "" {
			msg = "月导出已推送到群组"
		}
		_ = sendTelegramByUser(cfg, userID, msg)
		return true
	case "monthlyreport":
		path := fmt.Sprintf("/telegram/worker/monthly-report?chatId=%s", url.QueryEscape(chatID))
		if args != "" {
			path += "&month=" + url.QueryEscape(args)
		}
		var res struct {
			Code int `json:"code"`
			Data struct {
				DisplayText string `json:"displayText"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err != nil || res.Data.DisplayText == "" {
			_ = sendTelegramByUser(cfg, userID, "月报生成失败")
			return true
		}
		_ = sendTelegramHTML(cfg, userID, res.Data.DisplayText)
		return true
	case "actstatus":
		path := fmt.Sprintf("/telegram/worker/actstatus?chatId=%s", url.QueryEscape(chatID))
		var res struct {
			Code int `json:"code"`
			Data struct {
				DisplayText string `json:"displayText"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err == nil && res.Data.DisplayText != "" {
			_ = sendTelegramByUser(cfg, userID, res.Data.DisplayText)
		}
		return true
	case "ci":
		if args == "" {
			_ = sendTelegramByUser(cfg, userID, "用法：/ci 活动名")
			return true
		}
		replyStartActivityByCI(cfg, user, chatID, args, msg.MessageID)
		return true
	case "showsettings", "checkdb", "fixmessages":
		if !isAdminUser(userID) {
			_ = sendTelegramByUser(cfg, userID, "需要管理员权限")
			return true
		}
		switch cmd {
		case "showsettings":
			path := fmt.Sprintf("/telegram/worker/showsettings?telegramUserId=%d&chatId=%s", userID, url.QueryEscape(chatID))
			var res struct {
				Code int `json:"code"`
				Data struct {
					DisplayText string `json:"displayText"`
				} `json:"data"`
			}
			if err := backendGet(cfg, path, &res); err == nil {
				_ = sendTelegramHTML(cfg, userID, res.Data.DisplayText)
			}
		case "checkdb":
			path := fmt.Sprintf("/telegram/worker/checkdb?telegramUserId=%d", userID)
			var res struct {
				Code int `json:"code"`
				Data struct {
					DisplayText string `json:"displayText"`
				} `json:"data"`
			}
			if err := backendGet(cfg, path, &res); err == nil {
				_ = sendTelegramByUser(cfg, userID, res.Data.DisplayText)
			}
		case "fixmessages":
			var res apiResult
			res.Data = map[string]interface{}{}
			_ = backendPost(cfg, "/telegram/worker/admin/fixmessages", map[string]interface{}{
				"telegramUserId": userID,
			}, &res)
			_ = sendTelegramByUser(cfg, userID, fmt.Sprintf("已清理 %v 条 message_id", res.Data["cleared"]))
		}
		return true
	default:
		path := fmt.Sprintf("/telegram/worker/resolve-ci?text=%s", url.QueryEscape(cmd))
		var res struct {
			Code int `json:"code"`
			Data struct {
				ActivityName string `json:"activityName"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err == nil && res.Data.ActivityName != "" {
			replyStartActivityWithDeviceSelection(cfg, user, chatID, res.Data.ActivityName, msg.MessageID)
			return true
		}
	}
	return false
}

func replyStartActivityByCI(cfg config, user tgUserRef, chatID, text string, replyTo int64) {
	path := fmt.Sprintf("/telegram/worker/resolve-ci?text=%s", url.QueryEscape(text))
	var res struct {
		Code int `json:"code"`
		Data struct {
			ActivityName string `json:"activityName"`
		} `json:"data"`
	}
	if err := backendGet(cfg, path, &res); err != nil || res.Data.ActivityName == "" {
		replyWorkHTMLError(cfg, user, chatID, activityNotFoundPrefix(user.ID)+text, replyTo)
		return
	}
	replyStartActivityWithDeviceSelection(cfg, user, chatID, res.Data.ActivityName, replyTo)
}

func replyLangSwitch(cfg config, msg *tgMessage, langArg string) {
	if msg == nil {
		return
	}
	langArg = strings.TrimSpace(strings.ToLower(langArg))
	if langArg == "" {
		usage := "用法 / Usage: /lang zh | vi | en"
		_ = sendTelegramHTMLReply(cfg, msg.Chat.ID, html.EscapeString(usage), msg.MessageID, nil)
		return
	}
	var res struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
	}
	err := backendPost(cfg, "/telegram/worker/lang", map[string]interface{}{
		"telegramUserId": msg.From.ID,
		"lang":           langArg,
	}, &res)
	if err != nil {
		log.Printf("lang switch failed user=%d lang=%s: %v", msg.From.ID, langArg, err)
		fail := "语言设置失败 / Language update failed: " + err.Error()
		_ = sendTelegramHTMLReply(cfg, msg.Chat.ID, html.EscapeString(fail), msg.MessageID, nil)
		return
	}
	if res.Code != 0 {
		errMsg := strings.TrimSpace(res.Message)
		if errMsg == "" {
			errMsg = "unsupported lang"
		}
		log.Printf("lang switch rejected user=%d lang=%s code=%d msg=%s", msg.From.ID, langArg, res.Code, errMsg)
		_ = sendTelegramHTMLReply(cfg, msg.Chat.ID, html.EscapeString("❌ "+errMsg+"\n/lang zh | vi | en"), msg.MessageID, nil)
		return
	}
	var okMsg string
	switch langArg {
	case "vi", "vn", "vietnamese", "越南语", "越":
		okMsg = "✅ Ngôn ngữ phản hồi chấm công: Tiếng Việt"
	case "en", "english", "英语", "英文", "英":
		okMsg = "✅ Punch reply language: English"
	default:
		okMsg = "✅ 打卡回复语言已设为中文"
	}
	rememberUserLang(msg.From.ID, langArg)
	chatID := strconv.FormatInt(msg.Chat.ID, 10)
	kb := replyKeyboardForUser(cfg, chatID, msg.From.ID)
	_ = sendTelegramHTMLReply(cfg, msg.Chat.ID, html.EscapeString(okMsg), msg.MessageID, kb)
}

func sendTelegramHTML(cfg config, chatID int64, text string) error {
	payload := map[string]interface{}{
		"chat_id":    chatID,
		"text":       text,
		"parse_mode": "HTML",
	}
	kb := currentReplyKeyboard()
	if kb != nil {
		payload["reply_markup"] = kb
	}
	body, _ := json.Marshal(payload)
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", cfg.BotToken)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader(body))
	if err == nil {
		resp.Body.Close()
	}
	return err
}

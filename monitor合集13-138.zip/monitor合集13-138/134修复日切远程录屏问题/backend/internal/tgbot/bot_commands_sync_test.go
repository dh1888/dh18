package tgbot

import "testing"

func TestNormalizeBotCommandsKeepsMenuOrder(t *testing.T) {
	raw := []map[string]interface{}{
		{"command": "checkin_day", "description": "白班上班 / Day shift"},
		{"command": "CHECKIN_DAY", "description": "dup"},
		{"command": "checkin_middle", "description": "中班上班 / Middle shift"},
		{"command": "坏命令", "description": "invalid"},
		{"command": "lang_zh", "description": "设为中文 / Set Chinese"},
	}
	got := normalizeBotCommands(raw)
	if len(got) != 3 {
		t.Fatalf("got %d commands: %#v", len(got), got)
	}
	if got[0]["command"] != "checkin_day" || got[1]["command"] != "checkin_middle" || got[2]["command"] != "lang_zh" {
		t.Fatalf("order mismatch: %#v", got)
	}
}

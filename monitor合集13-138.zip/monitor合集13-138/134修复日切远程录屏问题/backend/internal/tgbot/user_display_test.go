package tgbot

import (
	"strings"
	"testing"
)

func TestTGUserRefDisplayName(t *testing.T) {
	u := tgUserRef{ID: 99, FirstName: "Lan", LastName: "Nguyen", Username: "lan_vn"}
	if got := u.displayName(); got != "Lan Nguyen" {
		t.Fatalf("expected full name, got %q", got)
	}
	u = tgUserRef{ID: 99, Username: "lan_vn"}
	if got := u.displayName(); got != "@lan_vn" {
		t.Fatalf("expected @username, got %q", got)
	}
	u = tgUserRef{ID: 99}
	if got := u.displayName(); got != "用户99" {
		t.Fatalf("expected fallback id, got %q", got)
	}
}

func TestEnrichUnboundAlertHTMLPlainName(t *testing.T) {
	u := tgUserRef{ID: 12345, FirstName: "梁上听珂", Username: "testuser"}
	got := enrichUnboundAlertHTML(u, "⚠️ 未绑定")
	if strings.Contains(got, "t.me/") {
		t.Fatalf("unbound alert must not use t.me card: %q", got)
	}
	if !strings.Contains(got, `<a href="tg://user?id=12345">梁上听珂</a>`) {
		t.Fatalf("unbound name should open that TG user: %q", got)
	}
	if !strings.Contains(got, "您还未绑定Telegram打卡群") {
		t.Fatalf("expected new unbound format: %q", got)
	}
	if !strings.Contains(got, "/bind_workstation 邀请码") {
		t.Fatalf("expected bind instructions: %q", got)
	}
}

func TestTGUserRefHTMLProfileLink(t *testing.T) {
	u := tgUserRef{ID: 12345, FirstName: "Tom", Username: "tom_user"}
	got := u.htmlProfileLink()
	want := `<a href="tg://user?id=12345">Tom</a>`
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
	u = tgUserRef{ID: 12345, FirstName: "张三"}
	got = u.htmlProfileLink()
	want = `<a href="tg://user?id=12345">张三</a>`
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

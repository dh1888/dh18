package tgbot

import (
	"fmt"
	"strings"
	"sync"
)

var cachedUserLang sync.Map

func rememberUserLang(userID int64, lang string) {
	if userID <= 0 {
		return
	}
	switch strings.ToLower(strings.TrimSpace(lang)) {
	case "vi", "vn", "vietnamese", "越南语", "越":
		cachedUserLang.Store(userID, "vi")
	case "en", "english", "英语", "英文", "英":
		cachedUserLang.Store(userID, "en")
	case "zh", "cn", "chinese", "中文", "both":
		cachedUserLang.Store(userID, "zh")
	}
}

func userLang(userID int64) string {
	if userID <= 0 {
		return "zh"
	}
	if v, ok := cachedUserLang.Load(userID); ok {
		if s, _ := v.(string); s == "vi" || s == "en" || s == "zh" {
			return s
		}
	}
	return "zh"
}

func tUser(userID int64, zh, vi, en string) string {
	switch userLang(userID) {
	case "vi":
		return vi
	case "en":
		return en
	default:
		return zh
	}
}

func punchFailPrefix(userID int64) string {
	return tUser(userID, "打卡失败：", "Chấm công thất bại: ", "Clock-in failed: ")
}

func checkoutFailPrefix(userID int64) string {
	return tUser(userID, "签退失败：", "Tan ca thất bại: ", "Clock-out failed: ")
}

func startActivityFailPrefix(userID int64) string {
	return tUser(userID, "开始活动失败：", "Bắt đầu hoạt động thất bại: ", "Start activity failed: ")
}

func endActivityFailPrefix(userID int64) string {
	return tUser(userID, "结束活动失败：", "Kết thúc hoạt động thất bại: ", "End activity failed: ")
}

func activityNotFoundPrefix(userID int64) string {
	return tUser(userID, "未找到活动：", "Không tìm thấy hoạt động: ", "Activity not found: ")
}

func currentLangMode() string {
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	if cachedLangMode == "" {
		return "both"
	}
	return cachedLangMode
}

// Built-in labels so button presses still work before /config is loaded.
var builtinButtonLookup = map[string]string{
	"上班": "checkin", "Đi làm": "checkin", "上班 / Đi làm": "checkin", "Clock in": "checkin",
	"下班": "work_end", "Tan ca": "work_end", "下班 / Tan ca": "work_end", "🔴 下班": "work_end", "Clock out": "work_end",
	"白班上班": "work_start_day", "Ca ngày Đi làm": "work_start_day", "Day in": "work_start_day",
	"中班上班": "work_start_middle", "Ca giữa Đi làm": "work_start_middle", "Mid in": "work_start_middle",
	"夜班上班": "work_start_night", "Ca đêm Đi làm": "work_start_night", "Night in": "work_start_night",
	"回座": "back", "Trở lại chỗ ngồi": "back", "✅ 回座": "back", "Back": "back",
	"我的记录": "my_record", "Lịch sử của tôi": "my_record", "我的信息": "my_record", "My log": "my_record",
	"排行榜": "rank", "Bảng xếp hạng": "rank", "排名": "rank", "Rank": "rank",
	"状态": "status", "Trạng thái": "status", "Status": "status",
	"交接班": "handover", "Giao ca": "handover", "换班": "handover", "Handover": "handover",
	"帮助": "help", "Trợ giúp": "help", "Help": "help",
	"chatid": "chatid",
	"导出数据":   "export_data", "Xuất dữ liệu": "export_data", "Export": "export_data",
	"🚾 小厕": "小厕", "🚽 大厕": "大厕",
	"🚽 小厕": "小厕", "🚾 大厕": "大厕", "🍱 吃饭": "吃饭", "🚬 抽烟": "抽烟", "🚬 抽烟或休息": "抽烟或休息",
	"🚾 Nhà vệ sinh nhỏ": "小厕", "🚽 Nhà vệ sinh lớn": "大厕",
	"🍱 Đi ăn": "吃饭", "🚬 Hút thuốc": "抽烟", "🚬 Nghỉ hoặc hút thuốc": "抽烟或休息",
	"🚾 Restroom (short)": "小厕", "🚽 Restroom (long)": "大厕",
	"🍱 Meal break": "吃饭", "🚬 Smoke break": "抽烟", "🚬 Smoke / break": "抽烟或休息",
}

const deviceTagSep = " · "

func splitDeviceTag(text string) (base, deviceHint string) {
	text = strings.TrimSpace(text)
	if text == "" {
		return "", ""
	}
	idx := strings.LastIndex(text, deviceTagSep)
	if idx <= 0 {
		return text, ""
	}
	base = strings.TrimSpace(text[:idx])
	deviceHint = strings.TrimSpace(text[idx+len(deviceTagSep):])
	if base == "" || deviceHint == "" {
		return text, ""
	}
	return base, deviceHint
}

func resolveButton(text string) string {
	text = strings.TrimSpace(text)
	if text == "" {
		return ""
	}
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	if canonical, ok := cachedButtonLookup[text]; ok {
		return canonical
	}
	if canonical, ok := builtinButtonLookup[text]; ok {
		return canonical
	}
	return text
}

func resolveActivityName(text string) string {
	canonical := resolveButton(text)
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	for _, name := range cachedActivities {
		if canonical == name {
			return name
		}
	}
	return ""
}

func isActivityInput(text string) bool {
	return resolveActivityName(text) != ""
}

func tRateLimited() string {
	switch currentLangMode() {
	case "vi":
		return "Thao tác quá nhanh, vui lòng thử lại sau."
	case "zh":
		return "操作过于频繁，请稍后再试。"
	default:
		return "操作过于频繁，请稍后再试。 / Thao tác quá nhanh, vui lòng thử lại sau."
	}
}

func helpText() string {
	activitiesMu.RLock()
	acts := strings.Join(cachedActivities, "、")
	mode := cachedLangMode
	activitiesMu.RUnlock()
	if mode == "" {
		mode = "both"
	}
	switch mode {
	case "vi":
		return fmt.Sprintf(`Bot chấm công Telegram

Ca ngày / Ca đêm (chế độ hai ca)
Đi làm: gửi nút tương ứng
Tan ca: gửi nút Tan ca
Hoạt động: gửi tên hoạt động (%s)
Trở lại: gửi nút Trở lại chỗ ngồi
Giao ca: gửi Giao ca
Trạng thái / Lịch sử / Bảng xếp hạng: dùng nút bàn phím
Ngôn ngữ phản hồi chấm công của bạn: /lang_zh /lang_vi /lang_en`, acts)
	case "zh":
		return fmt.Sprintf(`Telegram 考勤 Bot

绑定个人 TG（无需客户端）：/bind 邀请码 或 /bind 账号
多设备共用 TG（共享工位）：/bind_multi 账号 或 /bind_multi 邀请码（同一 TG 可绑多台；点普通打卡按钮后选择设备）
单设备工位 TG：/bind_workstation 邀请码（打卡需 PC 登录）
客户端：登录后托盘「绑定 Telegram」获取链接
群内键盘按钮无反应：请在 @BotFather 对该 Bot 执行 /setprivacy → Disable
或在群内使用命令：/checkin_day /checkin_middle /checkin_night /checkout
白班 / 中班 / 夜班上班（双班或三班模式）
上班：发送对应按钮，或 /checkin_day /checkin_middle /checkin_night
下班：发送「下班」或 /checkout
活动：发送活动名称开始（%s）
结束活动：发送「回座」或 /at
交接班：发送「交接班」（双班 day↔night；三班 day→middle→night→day）
状态 / 我的记录 / 排行榜：使用键盘按钮
查询本群/频道 ID：/chatid（或 /groupid、/channelid）
个人打卡回复语言：点 /lang_zh /lang_vi /lang_en（也可 /lang zh|vi|en，未设置默认中文）`, acts)
	default:
		return fmt.Sprintf(`Telegram 考勤 Bot / Bot chấm công

个人 /bind 邀请码 或 /bind 账号 | 多设备 /bind_multi 账号 或 /bind_multi 邀请码 | 工位 /bind_workstation 邀请码
白班 / 中班 / 夜班 | Ca ngày / giữa / đêm
上班 / 下班 | Đi làm / Tan ca
活动 (%s) | Hoạt động
回座 / 状态 / 我的记录 / 排行榜
Trở lại / Trạng thái / Lịch sử / Bảng xếp hạng
/chatid 查询群或频道 ID
/lang_zh /lang_vi /lang_en 个人打卡回复语言（默认 zh）`, acts)
	}
}

func tGroupWelcome(chatType, title string, chatID int64) string {
	name := title
	if name == "" {
		name = "本群"
	}
	mode := currentLangMode()
	if chatType == "channel" {
		switch mode {
		case "vi":
			return fmt.Sprintf("🤖 Bot đã tham gia kênh\n\n📢 %s\n🆔 ID: %d\n\nThêm ID này trong trang quản trị monitorWin.", name, chatID)
		case "zh":
			return fmt.Sprintf("🤖 机器人已加入频道\n\n📢 %s\n🆔 频道 ID：%d\n\n请在后台「Telegram 考勤 → 推送配置」绑定此 ID。", name, chatID)
		default:
			return fmt.Sprintf("🤖 机器人已加入频道 / Bot đã tham gia kênh\n\n📢 %s\n🆔 ID：%d\n\n后台绑定此 ID。", name, chatID)
		}
	}
	switch mode {
	case "vi":
		return fmt.Sprintf("🤖 Bot đã tham gia nhóm\n\n💬 %s\n🆔 ID: %d\n\nThêm Chat ID trong trang quản trị hoặc gửi /chatid.", name, chatID)
	case "zh":
		return fmt.Sprintf("🤖 机器人已加入群组\n\n💬 %s\n🆔 群组 ID：%d\n\n请在后台「群组绑定」添加此 Chat ID；也可发送 /chatid 查看。", name, chatID)
	default:
		return fmt.Sprintf("🤖 机器人已加入群组 / Bot đã tham gia nhóm\n\n💬 %s\n🆔 ID：%d\n\n后台「群组绑定」或 /chatid", name, chatID)
	}
}

func tChatIDHint(chatType, title string, chatID int64) string {
	name := title
	if name == "" {
		name = fmt.Sprintf("%d", chatID)
	}
	mode := currentLangMode()
	switch mode {
	case "vi":
		return fmt.Sprintf("📋 %s\n🆔 %s: %d", name, chatIDLabel(chatType), chatID)
	case "zh":
		return fmt.Sprintf("📋 %s\n🆔 %s：%d", name, chatIDLabel(chatType), chatID)
	default:
		return fmt.Sprintf("📋 %s\n🆔 %s：%d", name, chatIDLabel(chatType), chatID)
	}
}

func chatIDLabel(chatType string) string {
	mode := currentLangMode()
	if chatType == "channel" {
		switch mode {
		case "vi":
			return "ID kênh"
		case "zh":
			return "频道 ID"
		default:
			return "频道 ID / ID kênh"
		}
	}
	switch mode {
	case "vi":
		return "Chat ID"
	case "zh":
		return "群组 ID"
	default:
		return "群组 ID / Chat ID"
	}
}

func needsDeviceSelectionRetry(msg string) bool {
	lower := strings.ToLower(msg)
	return strings.Contains(msg, "选择设备") ||
		strings.Contains(msg, "多台设备已登录") ||
		strings.Contains(msg, "chọn thiết bị") ||
		strings.Contains(msg, "Nhiều thiết bị") ||
		strings.Contains(lower, "select a device") ||
		strings.Contains(lower, "multiple devices")
}

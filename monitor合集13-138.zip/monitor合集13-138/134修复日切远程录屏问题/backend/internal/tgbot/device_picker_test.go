package tgbot

import "testing"

func TestPackInlineButtonsWrapsByNameWidth(t *testing.T) {
	buttons := []map[string]interface{}{
		{"text": "张三"},
		{"text": "李四"},
		{"text": "王五"},
		{"text": "一个很长的员工姓名"},
		{"text": "赵六"},
	}
	rows := packInlineButtons(buttons)
	if len(rows) != 3 {
		t.Fatalf("expected 3 rows, got %d: %#v", len(rows), rows)
	}
	if len(rows[0]) != 3 {
		t.Fatalf("expected three short names in first row, got %d", len(rows[0]))
	}
	if len(rows[1]) != 1 || len(rows[2]) != 1 {
		t.Fatalf("expected long name and final name to wrap, got %#v", rows)
	}
}

func TestInlineLabelVisualWidth(t *testing.T) {
	if got := inlineLabelVisualWidth("张三"); got != 4 {
		t.Fatalf("Chinese width=%d", got)
	}
	if got := inlineLabelVisualWidth("Alice"); got != 5 {
		t.Fatalf("ASCII width=%d", got)
	}
}

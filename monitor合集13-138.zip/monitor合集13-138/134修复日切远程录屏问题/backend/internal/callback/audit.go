package callback

import (
	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/handlers"
)

const operationModuleCallback = "CALLBACK"

func auditCB(c *gin.Context, opType, desc, targetID, targetName string) {
	handlers.Log(c, opType, operationModuleCallback, desc, targetID, targetName)
}

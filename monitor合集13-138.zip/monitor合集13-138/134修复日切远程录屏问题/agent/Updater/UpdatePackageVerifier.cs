using System.Security.Cryptography;

using System.Text;

using System.Text.Json;

using Org.BouncyCastle.Crypto.Parameters;

using Org.BouncyCastle.Crypto.Signers;



namespace EnterpriseAgent.Updater;



/// <summary>

/// Verifies update-package Ed25519 signatures produced by backend/cmd/signupdate

/// over domain-separated SHA-256 hex (same scheme as security.UpdatePackageSignMessage).

/// Uses dedicated updatePublicKeys only — does not fall back to policyPublicKeys.

/// </summary>

public static class UpdatePackageVerifier

{

    public const string SignatureAlg = "Ed25519";

    public const string SignPrefix = "MonitorAgent-update-v1\n";



    public static byte[] BuildSignMessage(string sha256Hex)

    {

        var normalized = (sha256Hex ?? "").Trim().ToLowerInvariant();

        return Encoding.UTF8.GetBytes(SignPrefix + normalized);

    }



    public static bool TryVerify(

        string sha256Hex,

        string signatureBase64,

        string keyId,

        IReadOnlyDictionary<string, string> publicKeysById,

        out string? error)

    {

        error = null;

        if (string.IsNullOrWhiteSpace(sha256Hex) || sha256Hex.Trim().Length != 64)

        {

            error = "sha256 hex must be 64 characters";

            return false;

        }



        if (string.IsNullOrWhiteSpace(signatureBase64))

        {

            error = "update signature is missing";

            return false;

        }



        if (string.IsNullOrWhiteSpace(keyId))

        {

            error = "update signing keyId is missing";

            return false;

        }



        if (publicKeysById == null || publicKeysById.Count == 0)

        {

            error = "no updatePublicKeys configured in deployment.json";

            return false;

        }



        if (!publicKeysById.TryGetValue(keyId.Trim(), out var keyBase64) || string.IsNullOrWhiteSpace(keyBase64))

        {

            error = $"unknown update signing keyId '{keyId}'";

            return false;

        }



        byte[] publicKey;

        try

        {

            publicKey = Convert.FromBase64String(keyBase64.Trim());

        }

        catch

        {

            error = $"public key for '{keyId}' is not valid Base64";

            return false;

        }



        if (publicKey.Length != 32)

        {

            error = $"public key for '{keyId}' must decode to 32 bytes";

            return false;

        }



        byte[] signature;

        try

        {

            signature = Convert.FromBase64String(signatureBase64.Trim());

        }

        catch

        {

            error = "update signature is not valid Base64";

            return false;

        }



        var message = BuildSignMessage(sha256Hex);

        var keyParams = new Ed25519PublicKeyParameters(publicKey, 0);

        var verifier = new Ed25519Signer();

        verifier.Init(false, keyParams);

        verifier.BlockUpdate(message, 0, message.Length);

        if (!verifier.VerifySignature(signature))

        {

            error = "Ed25519 update signature verification failed";

            return false;

        }



        return true;

    }



    /// <summary>

    /// Loads updatePublicKeys from deployment.json. Does not fall back to policyPublicKeys

    /// (scheme A: dedicated update key required for update isolation).

    /// </summary>

    public static Dictionary<string, string> LoadPublicKeys(string installDirectory)

    {

        var result = new Dictionary<string, string>(StringComparer.Ordinal);

        var path = Path.Combine(installDirectory, "deployment.json");

        if (!File.Exists(path))

            return result;



        try

        {

            using var doc = JsonDocument.Parse(File.ReadAllText(path));

            var root = doc.RootElement;

            if (root.TryGetProperty("updatePublicKeys", out var updateKeys) && updateKeys.ValueKind == JsonValueKind.Object)

                MergeKeys(result, updateKeys);

        }

        catch

        {

            // caller treats empty as hard failure when signature is required

        }



        return result;

    }



    private static void MergeKeys(Dictionary<string, string> target, JsonElement obj)

    {

        foreach (var prop in obj.EnumerateObject())

        {

            var value = prop.Value.GetString();

            if (!string.IsNullOrWhiteSpace(prop.Name) && !string.IsNullOrWhiteSpace(value))

                target[prop.Name.Trim()] = value.Trim();

        }

    }



    public static async Task<string> ComputeSha256HexAsync(string path)

    {

        await using var stream = File.OpenRead(path);

        var hash = await SHA256.HashDataAsync(stream);

        return Convert.ToHexString(hash).ToLowerInvariant();

    }

}



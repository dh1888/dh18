using System.Text.Json;
using EnterpriseAgent.Agent.Services;

namespace EnterpriseAgent.Agent.Infrastructure;

/// <summary>
/// Persists effective client protection for the guardian process (no DI).
/// </summary>
internal static class ClientProtectionStateFile
{
    private static string FilePath =>
        Path.Combine(AppPaths.GetAppDataPath(), "client_protection.json");

    public static void Save(ClientProtectionConfig cfg)
    {
        try
        {
            var json = JsonSerializer.Serialize(cfg);
            File.WriteAllText(FilePath, json);
        }
        catch
        {
            // non-fatal
        }
    }

    public static ClientProtectionConfig Load()
    {
        try
        {
            if (!File.Exists(FilePath))
                return new ClientProtectionConfig();
            var json = File.ReadAllText(FilePath);
            return JsonSerializer.Deserialize<ClientProtectionConfig>(json) ?? new ClientProtectionConfig();
        }
        catch
        {
            return new ClientProtectionConfig();
        }
    }

    /// <summary>
    /// When UI is gone without voluntary exit, guardian may restart the main process.
    /// Aligns with ClientProtectionConfig.CanExitNow: only restart when exit is denied and RestartOnKill is on.
    /// </summary>
    public static bool ShouldGuardianRestartUi()
    {
        var cfg = Load();
        if (cfg.IsTemporaryExitActive)
            return false;
        if (cfg.TemporaryExitUntil.HasValue)
            return cfg.RestartOnKill;
        if (cfg.AllowUserExit)
            return false;
        return cfg.RestartOnKill;
    }
}

using EnterpriseAgent.Shared;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;

namespace EnterpriseAgent.Agent.Services;

internal enum AutoStartLaunchMode
{
    HiddenVbs,
    DirectGuardianExe,
}

public static partial class AutoStartManager
{
    private const string StartupShortcutFileName = AppIdentity.ShortcutFileName;
    private const string StartupApprovedRunPath = @"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run";

    public static string? LastTaskCreationFailure { get; private set; }

    public static string? LastEnableNoticeKey { get; private set; }

    public static object[]? LastEnableNoticeArgs { get; private set; }

    public static string? ResolveEnableNotice(ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(LastEnableNoticeKey))
            return null;

        var template = localization?.GetString(LastEnableNoticeKey, LastEnableNoticeKey) ?? LastEnableNoticeKey;
        if (LastEnableNoticeArgs is { Length: > 0 })
        {
            try
            {
                return string.Format(template, LastEnableNoticeArgs);
            }
            catch (FormatException)
            {
                return template;
            }
        }

        return template;
    }

    internal static void ClearEnableNotice()
    {
        LastEnableNoticeKey = null;
        LastEnableNoticeArgs = null;
    }

    internal static void SetEnableNotice(string key, params object[] args)
    {
        LastEnableNoticeKey = key;
        LastEnableNoticeArgs = args.Length > 0 ? args : null;
    }

    private static bool AutoStartEntryMatches(string? entryText, string exePath)
    {
        if (string.IsNullOrWhiteSpace(entryText))
            return false;

        if (EntryUsesDirectGuardianExe(entryText, exePath))
            return true;

        var guardianVbs = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
        return entryText.Contains("wscript.exe", StringComparison.OrdinalIgnoreCase)
               && entryText.Contains(guardianVbs, StringComparison.OrdinalIgnoreCase);
    }

    private static bool EntryUsesDirectGuardianExe(string entryText, string exePath)
        => ScheduledTaskHelper.ReferencesExecutable(entryText, exePath)
           && entryText.Contains(HiddenLauncherFiles.GuardianLaunchArgument, StringComparison.OrdinalIgnoreCase);

    private static bool EntryUsesVbsLauncher(string? entryText, string exePath)
    {
        if (string.IsNullOrWhiteSpace(entryText))
            return false;

        if (EntryUsesDirectGuardianExe(entryText, exePath))
            return false;

        var guardianVbs = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
        return entryText.Contains("wscript.exe", StringComparison.OrdinalIgnoreCase)
               && entryText.Contains(guardianVbs, StringComparison.OrdinalIgnoreCase);
    }

    private static string BuildRegistryCommand(string exePath, ILogger? logger, out AutoStartLaunchMode mode)
    {
        HiddenLauncherFiles.EnsureGuardianVbs(exePath);
        var vbsPath = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
        if (File.Exists(vbsPath))
        {
            mode = AutoStartLaunchMode.HiddenVbs;
            return
                $"\"{HiddenLauncherFiles.GetWscriptPath()}\" {HiddenLauncherFiles.BuildWscriptArguments(vbsPath)}";
        }

        mode = AutoStartLaunchMode.DirectGuardianExe;
        logger?.LogWarning(
            "Guardian VBS unavailable; registry Run will launch {Exe} --guardian directly",
            AppIdentity.ExeFileName);
        return $"\"{exePath}\" {HiddenLauncherFiles.GuardianLaunchArgument}";
    }

    private static void RepairRegistryWhenVbsMissing(string exePath, ILogger? logger)
    {
        var registryValue = ReadRegistryAutoStartValue();
        if (string.IsNullOrWhiteSpace(registryValue))
            return;

        if (EntryUsesDirectGuardianExe(registryValue, exePath))
            return;

        var vbsPath = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
        if (File.Exists(vbsPath))
            return;

        logger?.LogWarning(
            "Registry auto-start references missing guardian VBS; repairing launch command");
        TryEnableRegistry(exePath, logger);
    }

    private static bool LoginAutostartIsOperational(
        AutoStartChannel activeChannel,
        bool taskMatches,
        bool registryMatches,
        string? registryValue,
        string? taskOutput,
        string exePath,
        bool vbsExists)
    {
        if (activeChannel == AutoStartChannel.None)
            return false;

        if (!File.Exists(exePath))
            return false;

        if (EntryUsesDirectGuardianExe(registryValue ?? "", exePath)
            || EntryUsesDirectGuardianExe(taskOutput ?? "", exePath))
        {
            return true;
        }

        if ((EntryUsesVbsLauncher(registryValue, exePath) && registryMatches)
            || (taskMatches && EntryUsesVbsLauncher(taskOutput, exePath)))
        {
            return vbsExists;
        }

        return vbsExists;
    }

    private static string GetStartupShortcutPath()
    {
        var folder = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
        return Path.Combine(folder, StartupShortcutFileName);
    }

    /// <summary>
    /// Windows「启动」页通常不显示 wscript 间接启动项；补充「启动」文件夹快捷方式以便用户可见。
    /// </summary>
    private static void TryEnableStartupFolderShortcut(string exePath, ILogger? logger)
    {
        try
        {
            var shortcutPath = GetStartupShortcutPath();
            var shellType = Type.GetTypeFromProgID("WScript.Shell");
            if (shellType == null)
            {
                logger?.LogWarning("WScript.Shell unavailable; startup folder shortcut skipped");
                return;
            }

            dynamic shell = Activator.CreateInstance(shellType)!;
            dynamic shortcut = shell.CreateShortcut(shortcutPath);
            shortcut.TargetPath = exePath;
            shortcut.Arguments = HiddenLauncherFiles.GuardianLaunchArgument;
            shortcut.WorkingDirectory = Path.GetDirectoryName(exePath) ?? "";
            shortcut.WindowStyle = 7;
            shortcut.Description = AppIdentity.ShortcutDescription;
            shortcut.Save();
            logger?.LogInformation("Startup folder shortcut created: {Path}", shortcutPath);
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "Failed to create startup folder shortcut");
        }
    }

    private static void TryDisableStartupFolderShortcut(ILogger? logger)
    {
        try
        {
            var shortcutPath = GetStartupShortcutPath();
            if (File.Exists(shortcutPath))
            {
                File.Delete(shortcutPath);
                logger?.LogDebug("Startup folder shortcut removed");
            }
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "Failed to remove startup folder shortcut");
        }
    }

    /// <summary>
    /// 标记 Run 项在 Windows「启动」设置中为已启用（否则 wscript 项可能不显示或被静默忽略）。
    /// </summary>
    private static void SetStartupApprovedRun(string name, bool enabled, ILogger? logger)
    {
        try
        {
            using var key = Registry.CurrentUser.CreateSubKey(StartupApprovedRunPath);
            if (key == null)
                return;

            var bytes = enabled
                ? new byte[] { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }
                : new byte[] { 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
            key.SetValue(name, bytes, RegistryValueKind.Binary);
            logger?.LogDebug("StartupApproved\\Run updated for {Name}: {State}", name, enabled ? "enabled" : "disabled");
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "Failed to update StartupApproved for {Name}", name);
        }
    }
}

using EnterpriseAgent.Shared;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;

namespace EnterpriseAgent.Agent.Services;

public enum AutoStartChannel
{
    None,
    ScheduledTask,
    Registry
}

public sealed class AutoStartDiagnosticReport
{
    public bool IsConfigured { get; init; }
    public AutoStartChannel ActiveChannel { get; init; }
    public bool ScheduledTaskPresent { get; init; }
    public bool ScheduledTaskRunnable { get; init; }
    public bool ScheduledTaskPathMatches { get; init; }
    public bool RegistryPresent { get; init; }
    public bool RegistryPathMatches { get; init; }
    public bool GuardianVbsExists { get; init; }
    public bool UsesDirectExeFallback { get; init; }
    public bool InstallDirectoryWritable { get; init; }
    public bool GuardianProcessRunning { get; init; }
    public bool MainUiRunning { get; init; }
    public bool VoluntaryExitMarkerActive { get; init; }
    public string ExecutablePath { get; init; } = "";
    public string GuardianVbsPath { get; init; } = "";
    public string? ScheduledTaskCreationFailure { get; init; }
    public IReadOnlyList<string> Issues { get; init; } = Array.Empty<string>();
    public IReadOnlyList<string> Hints { get; init; } = Array.Empty<string>();

    public bool HasBlockingIssues => Issues.Count > 0;

    public string FormatSummary(ILocalizationService? localization)
    {
        var lines = new List<string>();
        var title = localization?.GetString("AutoStartDiagnosticTitle", "登录自启动诊断") ?? "登录自启动诊断";
        lines.Add(title);
        lines.Add("");

        if (IsConfigured && ActiveChannel != AutoStartChannel.None)
        {
            var channelText = ActiveChannel switch
            {
                AutoStartChannel.ScheduledTask =>
                    localization?.GetString("AutoStartChannelTask", "方式：计划任务（用户登录后约 15 秒）")
                    ?? "方式：计划任务（用户登录后约 15 秒）",
                AutoStartChannel.Registry =>
                    localization?.GetString("AutoStartChannelRegistry", "方式：注册表 Run（用户登录后）")
                    ?? "方式：注册表 Run（用户登录后）",
                _ => localization?.GetString("AutoStartChannelUnknown", "方式：未知") ?? "方式：未知"
            };
            lines.Add(channelText);
            if (!HasBlockingIssues)
            {
                lines.Add(localization?.GetString("AutoStartConfigOk",
                    "配置状态：正常（将在下次登录 Windows 桌面后自动启动）")
                    ?? "配置状态：正常（将在下次登录 Windows 桌面后自动启动）");
                if (UsesDirectExeFallback)
                {
                    lines.Add(localization?.GetString("AutoStartDirectExeFallbackHint",
                        $"说明：当前使用 {AppIdentity.ExeFileName} --guardian 直接启动兜底（VBS 不可用时）")
                        ?? $"说明：当前使用 {AppIdentity.ExeFileName} --guardian 直接启动兜底（VBS 不可用时）");
                }
            }
        }
        else
        {
            lines.Add(localization?.GetString("AutoStartNotConfigured", "状态：未配置登录自启动")
                ?? "状态：未配置登录自启动");
        }

        var guardianText = GuardianProcessRunning
            ? localization?.GetString("AutoStartGuardianRunning", "守护进程：运行中")
            : localization?.GetString("AutoStartGuardianStopped", "守护进程：未运行");
        lines.Add(guardianText ?? (GuardianProcessRunning ? "守护进程：运行中" : "守护进程：未运行"));

        if (!GuardianProcessRunning && MainUiRunning)
        {
            lines.Add(localization?.GetString("AutoStartGuardianStoppedWhileUiHint",
                "说明：登录自启配置正常；当前会话守护未运行，仅影响本机崩溃后自动恢复，不影响下次登录自启。")
                ?? "说明：登录自启配置正常；当前会话守护未运行，仅影响本机崩溃后自动恢复，不影响下次登录自启。");
        }

        if (VoluntaryExitMarkerActive)
        {
            lines.Add(localization?.GetString("AutoStartVoluntaryExitHint",
                "提示：上次为托盘主动退出，本次登录窗口期内不会自动拉起。")
                ?? "提示：上次为托盘主动退出，本次登录窗口期内不会自动拉起。");
        }

        if (Issues.Count > 0)
        {
            lines.Add("");
            lines.Add(localization?.GetString("AutoStartIssuesHeader", "问题：") ?? "问题：");
            foreach (var issue in Issues)
                lines.Add("• " + issue);
        }

        if (Hints.Count > 0)
        {
            lines.Add("");
            lines.Add(localization?.GetString("AutoStartHintsHeader", "说明：") ?? "说明：");
            foreach (var hint in Hints)
                lines.Add("• " + hint);
        }

        return string.Join(Environment.NewLine, lines);
    }

    public string FormatShortStatus(ILocalizationService? localization)
    {
        if (!IsConfigured || ActiveChannel == AutoStartChannel.None)
        {
            return localization?.GetString("AutoStartShortOff", "登录自启：关")
                ?? "登录自启：关";
        }

        var channel = ActiveChannel == AutoStartChannel.ScheduledTask
            ? localization?.GetString("AutoStartShortTask", "计划任务") ?? "计划任务"
            : localization?.GetString("AutoStartShortRegistry", "注册表") ?? "注册表";

        if (HasBlockingIssues)
        {
            return string.Format(
                localization?.GetString("AutoStartShortIssue", "登录自启：{0}（异常）") ?? "登录自启：{0}（异常）",
                channel);
        }

        return string.Format(
            localization?.GetString("AutoStartShortOn", "登录自启：{0}") ?? "登录自启：{0}",
            channel);
    }
}

public static partial class AutoStartManager
{
    public static AutoStartDiagnosticReport Diagnose(ILogger? logger = null, ILocalizationService? localization = null)
    {
        string T(string key, string fallback) => localization?.GetString(key, fallback) ?? fallback;

        var exePath = GetExecutablePath();
        var guardianVbs = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
        var launcherDir = Path.GetDirectoryName(guardianVbs)
            ?? AppDomain.CurrentDomain.BaseDirectory;

        var taskOutput = ScheduledTaskHelper.QueryTaskOutput(TaskName);
        var taskPresent = taskOutput != null;
        var taskRunnable = taskPresent && ScheduledTaskHelper.IsTaskRunnable(TaskName);
        var taskMatches = TaskSchedulerMatches(exePath);

        var registryValue = ReadRegistryAutoStartValue();
        var registryPresent = !string.IsNullOrWhiteSpace(registryValue);
        var registryMatches = RegistryAutoStartMatches(exePath);
        var registryUsesVbs = EntryUsesVbsLauncher(registryValue, exePath);
        var registryUsesDirectExe = EntryUsesDirectGuardianExe(registryValue ?? "", exePath);

        var vbsExists = File.Exists(guardianVbs);
        var dirWritable = IsDirectoryWritable(launcherDir);
        var guardianRunning = AgentGuardianManager.IsRunning();
        var mainUiRunning = UiPresence.IsMainUiRunning();
        var voluntaryExit = VoluntaryShutdownMarker.IsActive();
        var exeExists = File.Exists(exePath);

        var activeChannel = ResolveActiveChannel(taskMatches, taskRunnable, registryMatches);
        var loginReady = LoginAutostartIsOperational(
            activeChannel,
            taskMatches,
            registryMatches,
            registryValue,
            taskOutput,
            exePath,
            vbsExists);
        var isConfigured = activeChannel != AutoStartChannel.None && loginReady;
        var usesDirectExeFallback = registryUsesDirectExe
            || EntryUsesDirectGuardianExe(taskOutput ?? "", exePath);

        var issues = new List<string>();
        var hints = new List<string>();

        if (!exeExists)
        {
            issues.Add(T("AutoStartIssueExeMissing", "客户端程序不存在或路径无效。"));
        }

        if (taskPresent && !taskMatches)
        {
            issues.Add(T("AutoStartIssueTaskStalePath", "计划任务存在，但指向旧路径；请在托盘重新开启登录自启动以修复。"));
        }
        else if (taskPresent && !taskRunnable)
        {
            issues.Add(T("AutoStartIssueTaskDisabled", "计划任务存在但处于禁用/不可用状态。"));
        }

        if (registryPresent && !registryMatches)
        {
            issues.Add(T("AutoStartIssueRegistryStalePath", "注册表自启项存在，但指向旧路径；请重新开启登录自启动。"));
        }

        if (!vbsExists && (registryUsesVbs || (taskMatches && EntryUsesVbsLauncher(taskOutput, exePath))))
        {
            issues.Add(T("AutoStartIssueVbsMissingBlocking",
                $"登录自启动依赖的 {AppIdentity.GuardianVbsFileName} 缺失，下次登录将无法启动；请点击自动修复。"));
        }

        if (!dirWritable)
        {
            issues.Add(T("AutoStartIssueLauncherDirNotWritable", "当前用户的启动脚本目录不可写，无法更新 VBS 启动脚本。"));
        }

        if (!isConfigured)
        {
            issues.Add(T("AutoStartIssueNotConfigured", "当前未配置有效的登录自启动项。"));
        }

        if (!guardianRunning && mainUiRunning && isConfigured)
        {
            hints.Add(T("AutoStartHintRepairGuardian", "可点击「自动修复」尝试启动当前会话守护进程（用于崩溃后自动恢复）。"));
        }

        if (!taskPresent && !string.IsNullOrWhiteSpace(LastTaskCreationFailure))
        {
            hints.Add(string.Format(
                T("AutoStartHintTaskUnavailable", "计划任务不可用：{0}"),
                LastTaskCreationFailure));
        }

        if (!vbsExists && usesDirectExeFallback)
        {
            hints.Add(T("AutoStartHintVbsDirectExeFallback",
                $"{AppIdentity.GuardianVbsFileName} 缺失；当前使用 {AppIdentity.ExeFileName} --guardian 直接启动兜底。"));
        }

        hints.Add(T("AutoStartHintVbsPath",
            $"VBS 路径：%LOCALAPPDATA%\\EnterpriseAgent\\launchers\\{AppIdentity.GuardianVbsFileName}"));
        hints.Add(T("AutoStartHintLogonTrigger", "登录自启动在用户登录 Windows 桌面后触发，不是通电即启动；无需管理员权限。"));
        hints.Add(T("AutoStartHintRegistryFallback", "若计划任务被公司策略禁用，会自动回退到当前用户注册表 Run。"));

        if (voluntaryExit)
        {
            hints.Add(T("AutoStartHintVoluntaryExitRelogin", "若曾从托盘退出，需重新登录 Windows 或重启后才会再次自动启动。"));
        }

        logger?.LogDebug(
            "Auto-start diagnose: configured={Configured}, channel={Channel}, task={TaskPresent}/{TaskMatch}, registry={RegistryPresent}/{RegistryMatch}, vbs={Vbs}, writable={Writable}",
            isConfigured, activeChannel, taskPresent, taskMatches, registryPresent, registryMatches, vbsExists, dirWritable);

        return new AutoStartDiagnosticReport
        {
            IsConfigured = isConfigured,
            ActiveChannel = activeChannel,
            ScheduledTaskPresent = taskPresent,
            ScheduledTaskRunnable = taskRunnable,
            ScheduledTaskPathMatches = taskMatches,
            RegistryPresent = registryPresent,
            RegistryPathMatches = registryMatches,
            GuardianVbsExists = vbsExists,
            UsesDirectExeFallback = usesDirectExeFallback,
            InstallDirectoryWritable = dirWritable,
            GuardianProcessRunning = guardianRunning,
            MainUiRunning = mainUiRunning,
            VoluntaryExitMarkerActive = voluntaryExit,
            ExecutablePath = exePath,
            GuardianVbsPath = guardianVbs,
            ScheduledTaskCreationFailure = LastTaskCreationFailure,
            Issues = issues,
            Hints = hints
        };
    }

    public static bool TryRepair(ILogger? logger = null)
    {
        var ok = EnsureEnabled(logger);
        if (!ok)
            ok = Enable(logger);
        if (UiPresence.IsMainUiRunning())
            AgentGuardianManager.EnsureRunning(logger);
        return ok;
    }

    private static AutoStartChannel ResolveActiveChannel(
        bool taskMatches,
        bool taskRunnable,
        bool registryMatches)
    {
        if (taskMatches && taskRunnable)
            return AutoStartChannel.ScheduledTask;

        if (registryMatches)
            return AutoStartChannel.Registry;

        return AutoStartChannel.None;
    }

    private static string? ReadRegistryAutoStartValue()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run");
            return key?.GetValue(RegistryValueName) as string;
        }
        catch
        {
            return null;
        }
    }

    private static bool IsDirectoryWritable(string directory)
    {
        if (string.IsNullOrWhiteSpace(directory) || !Directory.Exists(directory))
            return false;

        try
        {
            var probe = Path.Combine(directory, $".{AppIdentity.BaseName.ToLowerInvariant()}-write-test-{Guid.NewGuid():N}");
            File.WriteAllText(probe, "ok");
            File.Delete(probe);
            return true;
        }
        catch
        {
            return false;
        }
    }
}

using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using EnterpriseAgent.Agent.Infrastructure;
using EnterpriseAgent.Agent.Models;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

public sealed class ClientProtectionConfig
{
    [JsonPropertyName("allowUserExit")]
    public bool AllowUserExit { get; set; } = true;

    [JsonPropertyName("allowAutoStartToggle")]
    public bool AllowAutoStartToggle { get; set; } = true;

    [JsonPropertyName("restartOnKill")]
    public bool RestartOnKill { get; set; }

    [JsonPropertyName("unlockCodeConfigured")]
    public bool UnlockCodeConfigured { get; set; }

    [JsonPropertyName("temporaryExitUntil")]
    public DateTime? TemporaryExitUntil { get; set; }

    public bool IsTemporaryExitActive =>
        TemporaryExitUntil.HasValue && TemporaryExitUntil.Value.ToUniversalTime() > DateTime.UtcNow;

    public bool CanExitNow(bool allowExitOnceLatch)
    {
        if (allowExitOnceLatch)
            return true;
        if (IsTemporaryExitActive)
            return true;
        // Server used to set AllowUserExit=true for the whole temp window; after expiry treat as deny until resync.
        if (TemporaryExitUntil.HasValue)
            return false;
        return AllowUserExit;
    }
}

public sealed class ClientProtectionService
{
    private readonly IHttpClientFactory _httpFactory;
    private readonly IAuthTokenProvider _auth;
    private readonly AgentConfig _config;
    private readonly ILogger<ClientProtectionService> _logger;
    private readonly object _lock = new();
    private ClientProtectionConfig _configSnapshot = new();
    private bool _allowExitOnce;

    public ClientProtectionService(
        IHttpClientFactory httpFactory,
        IAuthTokenProvider auth,
        AgentConfig config,
        ILogger<ClientProtectionService> logger)
    {
        _httpFactory = httpFactory;
        _auth = auth;
        _config = config;
        _logger = logger;
    }

    public ClientProtectionConfig GetSnapshot()
    {
        lock (_lock)
        {
            return new ClientProtectionConfig
            {
                AllowUserExit = _configSnapshot.AllowUserExit,
                AllowAutoStartToggle = _configSnapshot.AllowAutoStartToggle,
                RestartOnKill = _configSnapshot.RestartOnKill,
                UnlockCodeConfigured = _configSnapshot.UnlockCodeConfigured,
                TemporaryExitUntil = _configSnapshot.TemporaryExitUntil,
            };
        }
    }

    public bool CanUserExitNow()
    {
        lock (_lock)
        {
            return _configSnapshot.CanExitNow(_allowExitOnce);
        }
    }

    public bool CanToggleAutoStart()
    {
        lock (_lock)
        {
            return _configSnapshot.AllowAutoStartToggle;
        }
    }

    public bool ShouldGuardAgainstVoluntaryExit()
    {
        lock (_lock)
        {
            if (_configSnapshot.CanExitNow(_allowExitOnce))
                return false;
            return _configSnapshot.RestartOnKill;
        }
    }

    public void ApplyFromServer(ClientProtectionConfig incoming)
    {
        lock (_lock)
        {
            _configSnapshot = incoming ?? new ClientProtectionConfig();
            PersistForGuardian(_configSnapshot);
            _logger.LogInformation(
                "Client protection updated: AllowUserExit={AllowExit}, AutoStartToggle={AutoStart}, RestartOnKill={Restart}, TempUntil={Temp}",
                _configSnapshot.AllowUserExit,
                _configSnapshot.AllowAutoStartToggle,
                _configSnapshot.RestartOnKill,
                _configSnapshot.TemporaryExitUntil);
        }
    }

    public void ApplyWebSocketPayload(JsonElement root)
    {
        if (!root.TryGetProperty("config", out var configEl))
            return;
        try
        {
            var cfg = JsonSerializer.Deserialize<ClientProtectionConfig>(configEl.GetRawText());
            if (cfg != null)
                ApplyFromServer(cfg);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to parse client_protection_update");
        }
    }

    public void GrantExitOnce()
    {
        lock (_lock)
        {
            _allowExitOnce = true;
        }
    }

    public void ConsumeExitOnceIfNeeded()
    {
        lock (_lock)
        {
            _allowExitOnce = false;
        }
    }

    public async Task SyncFromServerAsync(CancellationToken ct = default)
    {
        var snapshot = _auth.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return;

        try
        {
            using var client = _httpFactory.CreateClient("AgentClient");
            using var request = new HttpRequestMessage(HttpMethod.Get,
                $"{_config.ServerUrl}/api/v1/agent/client-protection");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
            using var response = await client.SendAsync(request, ct);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogDebug("Client protection sync failed: {Status}", response.StatusCode);
                return;
            }

            // API returns { code, data }; unwrap data so defaults (AllowUserExit=true) are not applied by mistake.
            var envelope = await response.Content.ReadFromJsonAsync<ApiEnvelope<ClientProtectionConfig>>(
                cancellationToken: ct);
            if (envelope?.Data == null)
            {
                _logger.LogDebug(
                    "Client protection sync skipped: empty data (code={Code})",
                    envelope?.Code);
                return;
            }

            ApplyFromServer(envelope.Data);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Client protection sync error");
        }
    }

    private void PersistForGuardian(ClientProtectionConfig cfg)
    {
        ClientProtectionStateFile.Save(cfg);
    }

    private sealed class ApiEnvelope<T>
    {
        [JsonPropertyName("code")]
        public int Code { get; set; }

        [JsonPropertyName("data")]
        public T? Data { get; set; }
    }

    public async Task<bool> TryVerifyUnlockCodeAsync(string code, CancellationToken ct = default)
    {
        code = (code ?? "").Trim();
        if (code.Length == 0)
            return false;

        var snapshot = _auth.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return false;

        try
        {
            using var client = _httpFactory.CreateClient("AgentClient");
            using var request = new HttpRequestMessage(HttpMethod.Post,
                $"{_config.ServerUrl}/api/v1/agent/client-protection/verify-unlock")
            {
                Content = JsonContent.Create(new { code }),
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
            using var response = await client.SendAsync(request, ct);
            if (!response.IsSuccessStatusCode)
                return false;

            GrantExitOnce();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Unlock code verification failed");
            return false;
        }
    }
}

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 设备尚未通过管理员审核，无法执行上传或任务相关 API。
/// </summary>
internal sealed class DeviceNotApprovedException : Exception
{
    public DeviceNotApprovedException(string status)
        : base($"Device not approved (status: {status})")
    {
        ApprovalStatus = status;
    }

    public string ApprovalStatus { get; }
}

/// <summary>
/// Refresh token is unusable; device must re-register with existing deviceSecret.
/// Do not retry the same upload until a new session is issued.
/// </summary>
internal sealed class DeviceAuthExpiredException : Exception
{
    public DeviceAuthExpiredException(string? detail = null)
        : base(string.IsNullOrWhiteSpace(detail)
            ? "Device refresh token is invalid; re-register required"
            : detail)
    {
    }
}

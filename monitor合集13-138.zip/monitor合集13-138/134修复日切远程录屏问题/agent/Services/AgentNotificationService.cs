using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Infrastructure;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.UI;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

public enum LocalNotifyKind
{
    Always = 0,
    Startup = 1,
    Login = 2,
    Attendance = 3,
    Bind = 4,
}

public sealed class AgentLocalNotificationSettings
{
    [JsonPropertyName("startupEnabled")]
    public bool StartupEnabled { get; set; } = true;

    [JsonPropertyName("localLoginEnabled")]
    public bool LocalLoginEnabled { get; set; } = true;

    [JsonPropertyName("localAttendanceEnabled")]
    public bool LocalAttendanceEnabled { get; set; } = true;

    [JsonPropertyName("localBindEnabled")]
    public bool LocalBindEnabled { get; set; } = true;

    [JsonPropertyName("localDurationSec")]
    public int LocalDurationSec { get; set; } = AgentNotificationService.LocalDurationSec;
}

/// <summary>
/// Unified agent desktop notification service with stackable bottom-right toasts.
/// </summary>
public sealed class AgentNotificationService
{
    private readonly ILogger<AgentNotificationService> _logger;
    private readonly IHttpClientFactory? _httpFactory;
    private readonly IAuthTokenProvider? _auth;
    private readonly AgentConfig? _config;
    private readonly object _lock = new();
    private readonly List<NotificationToastForm> _activeToasts = new();
    private SynchronizationContext? _uiSync;
    private AgentLocalNotificationSettings _localSettings = AgentLocalNotificationStateFile.Load();

    private const int ToastWidth = 400;
    private const int ToastMargin = 16;
    private const int ToastGap = 10;
    private const int MaxVisibleToasts = 3;
    private const int DefaultDurationSec = 60;
    private const int MinDurationSec = 8;
    private const int MaxDurationSec = 600;
    public const int LocalDurationSec = 60;

    public static AgentNotificationService? Current { get; private set; }

    public AgentNotificationService(
        ILogger<AgentNotificationService> logger,
        IHttpClientFactory? httpFactory = null,
        IAuthTokenProvider? auth = null,
        AgentConfig? config = null)
    {
        _logger = logger;
        _httpFactory = httpFactory;
        _auth = auth;
        _config = config;
        Current = this;
    }

    public void BindUiThread(SynchronizationContext sync)
    {
        _uiSync = sync;
    }

    public bool IsLocalKindEnabled(LocalNotifyKind kind)
    {
        var settings = GetLocalSettings();
        return kind switch
        {
            LocalNotifyKind.Startup => settings.StartupEnabled,
            LocalNotifyKind.Login => settings.LocalLoginEnabled,
            LocalNotifyKind.Attendance => settings.LocalAttendanceEnabled,
            LocalNotifyKind.Bind => settings.LocalBindEnabled,
            _ => true,
        };
    }

    public int GetLocalDurationSec()
    {
        return ClampDuration(GetLocalSettings().LocalDurationSec, LocalDurationSec);
    }

    public void ApplyLocalSettings(AgentLocalNotificationSettings? incoming)
    {
        var next = Normalize(incoming);
        lock (_lock)
        {
            _localSettings = next;
        }
        AgentLocalNotificationStateFile.Save(next);
        _logger.LogInformation(
            "Local notification settings updated: startup={Startup} login={Login} attendance={Attendance} bind={Bind} duration={Duration}s",
            next.StartupEnabled,
            next.LocalLoginEnabled,
            next.LocalAttendanceEnabled,
            next.LocalBindEnabled,
            next.LocalDurationSec);
    }

    public void ApplyWebSocketPayload(JsonElement root)
    {
        try
        {
            var incoming = JsonSerializer.Deserialize<AgentLocalNotificationSettings>(root.GetRawText());
            if (incoming != null)
                ApplyLocalSettings(incoming);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to parse agent_notification_settings");
        }
    }

    public async Task SyncFromServerAsync(CancellationToken ct = default)
    {
        if (_httpFactory == null || _auth == null || _config == null)
            return;

        var snapshot = _auth.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return;

        try
        {
            using var client = _httpFactory.CreateClient("AgentClient");
            using var request = new HttpRequestMessage(HttpMethod.Get,
                $"{_config.ServerUrl}/api/v1/agent/notification-settings");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
            using var response = await client.SendAsync(request, ct);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogDebug("Local notification settings sync failed: {Status}", response.StatusCode);
                return;
            }

            var envelope = await response.Content.ReadFromJsonAsync<ApiEnvelope<AgentLocalNotificationSettings>>(
                cancellationToken: ct);
            if (envelope?.Data == null)
            {
                _logger.LogDebug(
                    "Local notification settings sync skipped: empty data (code={Code})",
                    envelope?.Code);
                return;
            }

            ApplyLocalSettings(envelope.Data);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Local notification settings sync error");
        }
    }

    public void ShowLocal(
        string title,
        string message,
        string level = "info",
        int durationSec = 0,
        LocalNotifyKind kind = LocalNotifyKind.Always)
    {
        if (!IsLocalKindEnabled(kind))
            return;

        if (durationSec <= 0)
            durationSec = kind == LocalNotifyKind.Always ? LocalDurationSec : GetLocalDurationSec();

        Show(title, message, level, durationSec);
    }

    public void Show(string title, string message, string level, int durationSec)
        => Show(title, message, level, durationSec, null, null, null);

    public void Show(
        string title,
        string message,
        string level,
        int durationSec,
        string? actionLabel,
        string? sessionId,
        Func<string, Task<(bool Success, string Message)>>? onActionAsync)
    {
        if (string.IsNullOrWhiteSpace(title) && string.IsNullOrWhiteSpace(message))
            return;

        message = DurationFormatter.NormalizeMessageDurations(message);
        durationSec = ClampDuration(durationSec, DefaultDurationSec);

        void Dispatch() => ShowOnUiThread(title, message, level, durationSec, actionLabel, sessionId, onActionAsync);

        if (_uiSync != null)
        {
            _uiSync.Post(_ => Dispatch(), null);
            return;
        }

        if (Application.MessageLoop)
        {
            Dispatch();
            return;
        }

        _logger.LogWarning("Skipped agent notification because UI thread is not ready");
    }

    private void ShowOnUiThread(
        string title,
        string message,
        string level,
        int durationSec,
        string? actionLabel,
        string? sessionId,
        Func<string, Task<(bool Success, string Message)>>? onActionAsync)
    {
        Func<Task>? toastAction = null;
        NotificationToastForm? toastRef = null;
        if (!string.IsNullOrWhiteSpace(actionLabel) &&
            !string.IsNullOrWhiteSpace(sessionId) &&
            onActionAsync != null)
        {
            var sid = sessionId.Trim();
            toastAction = async () =>
            {
                var (success, resultMessage) = await onActionAsync(sid);
                if (success)
                    toastRef?.ForceClose();
                ShowLocal(success ? "回座成功" : "回座失败", resultMessage, success ? "success" : "warning");
            };
        }

        lock (_lock)
        {
            while (_activeToasts.Count >= MaxVisibleToasts)
            {
                _activeToasts[0].ForceClose();
                _activeToasts.RemoveAt(0);
            }

            var toast = new NotificationToastForm(
                title,
                message,
                level,
                durationSec,
                toastAction != null ? actionLabel : null,
                toastAction);
            toastRef = toast;
            toast.FormClosed += (_, _) =>
            {
                lock (_lock)
                {
                    _activeToasts.Remove(toast);
                    RepositionToasts();
                }
            };
            _activeToasts.Add(toast);
            RepositionToasts();
            toast.Show();
        }

        _logger.LogInformation("Agent notification shown: {Title}", title);
    }

    private void RepositionToasts()
    {
        var screen = Screen.PrimaryScreen;
        if (screen == null)
            return;

        var workArea = screen.WorkingArea;
        var bottom = workArea.Bottom - ToastMargin;

        for (var i = _activeToasts.Count - 1; i >= 0; i--)
        {
            var toast = _activeToasts[i];
            bottom -= toast.Height;
            toast.SetStackPosition(workArea.Right - ToastWidth - ToastMargin, bottom);
            bottom -= ToastGap;
        }
    }

    private AgentLocalNotificationSettings GetLocalSettings()
    {
        lock (_lock)
        {
            return new AgentLocalNotificationSettings
            {
                StartupEnabled = _localSettings.StartupEnabled,
                LocalLoginEnabled = _localSettings.LocalLoginEnabled,
                LocalAttendanceEnabled = _localSettings.LocalAttendanceEnabled,
                LocalBindEnabled = _localSettings.LocalBindEnabled,
                LocalDurationSec = _localSettings.LocalDurationSec,
            };
        }
    }

    private static AgentLocalNotificationSettings Normalize(AgentLocalNotificationSettings? incoming)
    {
        var next = incoming ?? new AgentLocalNotificationSettings();
        next.LocalDurationSec = ClampDuration(next.LocalDurationSec, LocalDurationSec);
        return next;
    }

    private static int ClampDuration(int durationSec, int fallback)
    {
        if (durationSec <= 0)
            durationSec = fallback;
        if (durationSec < MinDurationSec)
            return MinDurationSec;
        if (durationSec > MaxDurationSec)
            return MaxDurationSec;
        return durationSec;
    }

    private sealed class ApiEnvelope<T>
    {
        [JsonPropertyName("code")]
        public int Code { get; set; }

        [JsonPropertyName("data")]
        public T? Data { get; set; }
    }
}

internal static class AgentLocalNotificationStateFile
{
    private static string FilePath =>
        Path.Combine(AppPaths.GetAppDataPath(), "agent_notification.json");

    public static void Save(AgentLocalNotificationSettings settings)
    {
        try
        {
            var json = JsonSerializer.Serialize(settings);
            File.WriteAllText(FilePath, json);
        }
        catch
        {
            // non-fatal
        }
    }

    public static AgentLocalNotificationSettings Load()
    {
        try
        {
            if (!File.Exists(FilePath))
                return new AgentLocalNotificationSettings();
            var json = File.ReadAllText(FilePath);
            return JsonSerializer.Deserialize<AgentLocalNotificationSettings>(json)
                   ?? new AgentLocalNotificationSettings();
        }
        catch
        {
            return new AgentLocalNotificationSettings();
        }
    }
}

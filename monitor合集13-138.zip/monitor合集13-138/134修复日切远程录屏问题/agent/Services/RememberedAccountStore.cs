using System.Text.Json;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// Persists remembered employee login usernames per server URL on this device.
/// Passwords are never stored.
/// </summary>
public static class RememberedAccountStore
{
    private const string PreferenceFolder = "EnterpriseAgent";
    private const string FileName = "remembered-accounts.json";
    private const int MaxAccountsPerServer = 20;

    private static readonly object Lock = new();

    public static string NormalizeServerKey(string? serverUrl)
    {
        if (string.IsNullOrWhiteSpace(serverUrl))
            return "_default";

        var trimmed = serverUrl.Trim().TrimEnd('/');
        if (!trimmed.StartsWith("http://", StringComparison.OrdinalIgnoreCase)
            && !trimmed.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            trimmed = "https://" + trimmed;
        }

        return trimmed.ToLowerInvariant();
    }

    public static IReadOnlyList<string> GetAccounts(string serverKey)
    {
        lock (Lock)
        {
            var data = Load();
            return data.TryGetValue(serverKey, out var entry)
                ? entry.Accounts.ToList()
                : Array.Empty<string>();
        }
    }

    /// <summary>
    /// Accounts for this server, or (if empty) a de-duplicated union of all remembered
    /// usernames on this device — so quick-select still appears after server URL normalization changes.
    /// </summary>
    public static IReadOnlyList<string> GetAccountsForQuickSelect(string serverKey)
    {
        lock (Lock)
        {
            var data = Load();
            if (data.TryGetValue(serverKey, out var entry) && entry.Accounts.Count > 0)
                return entry.Accounts.ToList();

            var merged = new List<string>();
            foreach (var serverEntry in data.Values)
            {
                foreach (var account in serverEntry.Accounts)
                {
                    if (merged.Any(a => string.Equals(a, account, StringComparison.OrdinalIgnoreCase)))
                        continue;
                    merged.Add(account);
                }
            }

            return merged;
        }
    }

    public static string? GetLastUsed(string serverKey)
    {
        lock (Lock)
        {
            var data = Load();
            if (!data.TryGetValue(serverKey, out var entry))
                return null;

            if (!string.IsNullOrWhiteSpace(entry.LastUsed)
                && entry.Accounts.Contains(entry.LastUsed, StringComparer.OrdinalIgnoreCase))
            {
                return entry.Accounts.First(a =>
                    string.Equals(a, entry.LastUsed, StringComparison.OrdinalIgnoreCase));
            }

            return entry.Accounts.FirstOrDefault();
        }
    }

    public static void Remember(string serverKey, string username)
    {
        username = username.Trim();
        if (string.IsNullOrWhiteSpace(username))
            return;

        lock (Lock)
        {
            var data = Load();
            if (!data.TryGetValue(serverKey, out var entry))
            {
                entry = new ServerEntry();
                data[serverKey] = entry;
            }

            entry.Accounts.RemoveAll(a => string.Equals(a, username, StringComparison.OrdinalIgnoreCase));
            entry.Accounts.Insert(0, username);
            if (entry.Accounts.Count > MaxAccountsPerServer)
                entry.Accounts.RemoveRange(MaxAccountsPerServer, entry.Accounts.Count - MaxAccountsPerServer);

            entry.LastUsed = username;
            Save(data);
        }
    }

    public static void Remove(string serverKey, string username)
    {
        username = username.Trim();
        if (string.IsNullOrWhiteSpace(username))
            return;

        lock (Lock)
        {
            var data = Load();
            if (!data.TryGetValue(serverKey, out var entry))
                return;

            entry.Accounts.RemoveAll(a => string.Equals(a, username, StringComparison.OrdinalIgnoreCase));
            if (string.Equals(entry.LastUsed, username, StringComparison.OrdinalIgnoreCase))
                entry.LastUsed = entry.Accounts.FirstOrDefault() ?? string.Empty;

            if (entry.Accounts.Count == 0)
                data.Remove(serverKey);

            Save(data);
        }
    }

    private static string GetStorePath()
    {
        var root = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        return Path.Combine(root, PreferenceFolder, FileName);
    }

    private static Dictionary<string, ServerEntry> Load()
    {
        try
        {
            var path = GetStorePath();
            if (!File.Exists(path))
                return new Dictionary<string, ServerEntry>(StringComparer.OrdinalIgnoreCase);

            var json = File.ReadAllText(path);
            var payload = JsonSerializer.Deserialize<StorePayload>(json);
            if (payload?.Servers == null)
                return new Dictionary<string, ServerEntry>(StringComparer.OrdinalIgnoreCase);

            var result = new Dictionary<string, ServerEntry>(StringComparer.OrdinalIgnoreCase);
            foreach (var (key, entry) in payload.Servers)
            {
                if (entry == null)
                    continue;

                var normalized = new ServerEntry
                {
                    LastUsed = entry.LastUsed?.Trim() ?? string.Empty
                };
                foreach (var account in entry.Accounts ?? [])
                {
                    var trimmed = account?.Trim();
                    if (string.IsNullOrWhiteSpace(trimmed))
                        continue;
                    if (normalized.Accounts.Any(a => string.Equals(a, trimmed, StringComparison.OrdinalIgnoreCase)))
                        continue;
                    normalized.Accounts.Add(trimmed);
                }

                if (normalized.Accounts.Count > 0)
                    result[key] = normalized;
            }

            return result;
        }
        catch
        {
            return new Dictionary<string, ServerEntry>(StringComparer.OrdinalIgnoreCase);
        }
    }

    private static void Save(Dictionary<string, ServerEntry> data)
    {
        try
        {
            var path = GetStorePath();
            var directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrWhiteSpace(directory) && !Directory.Exists(directory))
                Directory.CreateDirectory(directory);

            var payload = new StorePayload
            {
                Servers = data.ToDictionary(
                    kvp => kvp.Key,
                    kvp => new ServerEntryDto
                    {
                        Accounts = kvp.Value.Accounts.ToList(),
                        LastUsed = kvp.Value.LastUsed
                    },
                    StringComparer.OrdinalIgnoreCase)
            };

            var json = JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(path, json);
        }
        catch
        {
            /* ignore persistence errors */
        }
    }

    private sealed class StorePayload
    {
        public Dictionary<string, ServerEntryDto>? Servers { get; set; }
    }

    private sealed class ServerEntryDto
    {
        public List<string> Accounts { get; set; } = [];
        public string LastUsed { get; set; } = string.Empty;
    }

    private sealed class ServerEntry
    {
        public List<string> Accounts { get; } = [];
        public string LastUsed { get; set; } = string.Empty;
    }
}

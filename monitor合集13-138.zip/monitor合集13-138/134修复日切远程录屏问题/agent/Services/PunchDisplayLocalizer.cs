using System.Globalization;
using System.Text.RegularExpressions;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 将 TG/服务端返回的中文活动名、记录文案映射为当前 UI 语言。
/// </summary>
public static class PunchDisplayLocalizer
{
    private static readonly Dictionary<string, string> ActivityNameToCode = new(StringComparer.Ordinal)
    {
        ["小厕"] = "wc_small",
        ["大厕"] = "wc_large",
        ["吃饭"] = "eat",
        ["抽烟或休息"] = "smoke",
        ["抽烟"] = "smoke",
    };

    private static readonly Regex ChineseDurationRegex = new(
        @"^(?:(?<h>\d+)时)?(?:(?<m>\d+)分)?(?:(?<s>\d+)秒)?$",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);

    public static string LocalizeActivityName(
        string? name,
        IEnumerable<TgActivityTypeItem>? activityTypes,
        ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(name))
            return string.Empty;

        var trimmed = name.Trim();
        var code = ResolveActivityCode(trimmed, activityTypes);
        var localized = LocalizeActivityByCode(code, localization);
        return localized ?? trimmed;
    }

    public static string LocalizeActivityType(TgActivityTypeItem type, ILocalizationService? localization)
    {
        var localized = LocalizeActivityByCode(type.Code, localization);
        if (!string.IsNullOrWhiteSpace(localized))
            return localized;

        return LocalizeActivityName(type.Name, null, localization);
    }

    public static string? LocalizeActivityByCode(string? code, ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(code))
            return null;

        return code.Trim().ToLowerInvariant() switch
        {
            "wc_small" => localization?.GetString("ActivityWcSmall", "小厕") ?? "小厕",
            "wc_large" => localization?.GetString("ActivityWcLarge", "大厕") ?? "大厕",
            "eat" => localization?.GetString("ActivityEat", "吃饭") ?? "吃饭",
            "smoke" => localization?.GetString("ActivitySmoke", "抽烟或休息") ?? "抽烟或休息",
            _ => null
        };
    }

    public static string LocalizeRecordEvent(
        string? eventText,
        IEnumerable<TgActivityTypeItem>? activityTypes,
        ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(eventText))
            return string.Empty;

        var value = eventText.Trim();
        var mapped = value switch
        {
            "白班上班" => localization?.GetString("CheckInDay", "白班上班") ?? "白班上班",
            "中班上班" => localization?.GetString("CheckInMiddle", "中班上班") ?? "中班上班",
            "夜班上班" => localization?.GetString("CheckInNight", "夜班上班") ?? "夜班上班",
            "白班下班" => localization?.GetString("TrayPunchEventDayCheckOut", "白班下班") ?? "白班下班",
            "中班下班" => localization?.GetString("TrayPunchEventMiddleCheckOut", "中班下班") ?? "中班下班",
            "夜班下班" => localization?.GetString("TrayPunchEventNightCheckOut", "夜班下班") ?? "夜班下班",
            "下班" => localization?.GetString("CheckOut", "下班") ?? "下班",
            "上班" => localization?.GetString("CheckIn", "上班") ?? "上班",
            _ => null
        };

        if (!string.IsNullOrWhiteSpace(mapped))
            return mapped;

        return LocalizeActivityName(value, activityTypes, localization);
    }

    public static string LocalizeRecordDetail(string? detail, ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(detail))
            return string.Empty;

        var value = detail.Trim();
        var mapped = value switch
        {
            "上班打卡" => localization?.GetString("TrayPunchCheckInDetail", "上班打卡") ?? "上班打卡",
            "上班中" => localization?.GetString("TrayPunchWorkInProgress", "上班中") ?? "上班中",
            "下班打卡" => localization?.GetString("TrayPunchCheckOutDetail", "下班打卡") ?? "下班打卡",
            "开始" => localization?.GetString("TrayPunchActivityStarted", "开始") ?? "开始",
            "进行中" => localization?.GetString("TrayPunchInProgress", "进行中") ?? "进行中",
            "已结束" => localization?.GetString("TrayPunchActivityEnded", "已结束") ?? "已结束",
            _ => null
        };

        if (!string.IsNullOrWhiteSpace(mapped))
            return mapped;

        if (TryParseChineseDuration(value, out var seconds))
            return DurationFormatter.FormatDuration(seconds, localization);

        return value;
    }

    public static string LocalizeRecordSource(string? source, ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(source) || source == "-")
            return "-";

        return source.Trim().ToUpperInvariant() switch
        {
            "PC" => localization?.GetString("TrayPunchSourcePc", "PC") ?? "PC",
            "TG" => localization?.GetString("TrayPunchSourceTg", "TG") ?? "TG",
            "TELEGRAM" => localization?.GetString("TrayPunchSourceTg", "TG") ?? "TG",
            "AGENT" => localization?.GetString("TrayPunchSourcePc", "PC") ?? "PC",
            _ => source.Trim()
        };
    }

    public static string LocalizeShiftType(string? shiftType, ILocalizationService? localization)
    {
        var key = (shiftType ?? string.Empty).Trim().ToLowerInvariant();
        return key switch
        {
            "night" or "夜班" => localization?.GetString("TrayPunchShiftNight", "夜班") ?? "夜班",
            "middle" or "中班" => localization?.GetString("TrayPunchShiftMiddle", "中班") ?? "中班",
            _ => localization?.GetString("TrayPunchShiftDay", "白班") ?? "白班",
        };
    }

    /// <summary>
    /// PC toast body for starting an activity. Uses the client UI language, not Telegram /lang.
    /// </summary>
    public static string FormatActivityStartToast(
        string? activityName,
        IEnumerable<TgActivityTypeItem>? activityTypes,
        string? shiftType,
        int limitSeconds,
        int todayCountAfter,
        int maxTimesPerDay,
        ILocalizationService? localization)
    {
        var name = LocalizeActivityName(activityName, activityTypes, localization);
        if (string.IsNullOrWhiteSpace(name))
            name = localization?.GetString("TrayPunchSectionActivity", "活动") ?? "活动";

        var shift = LocalizeShiftType(shiftType, localization);
        var limitMin = LimitMinutes(limitSeconds);
        var count = Math.Max(1, todayCountAfter);
        var maxLabel = maxTimesPerDay > 0
            ? maxTimesPerDay.ToString(CultureInfo.InvariantCulture)
            : localization?.GetString("ActivityStartToastUnlimited", "不限") ?? "不限";

        var template = localization?.GetString(
                           "ActivityStartToastBody",
                           "✅ 打卡成功：{0}\n📊 班次：{1}\n⏰ 时限：{2} 分钟\n📈 今日次数：第 {3} 次（上限 {4}）\n\n💡 结束后请点击「回座」按钮")
                       ?? "✅ 打卡成功：{0}\n📊 班次：{1}\n⏰ 时限：{2} 分钟\n📈 今日次数：第 {3} 次（上限 {4}）\n\n💡 结束后请点击「回座」按钮";
        return string.Format(CultureInfo.InvariantCulture, template, name, shift, limitMin, count, maxLabel);
    }

    /// <summary>
    /// PC toast body for returning to seat. Uses the client UI language, not Telegram /lang.
    /// </summary>
    public static string FormatActivityBackToast(
        string? activityName,
        int elapsedSeconds,
        IEnumerable<TgActivityTypeItem>? activityTypes,
        ILocalizationService? localization)
    {
        var name = LocalizeActivityName(activityName, activityTypes, localization);
        if (string.IsNullOrWhiteSpace(name))
            name = localization?.GetString("ActivityBack", "回座") ?? "回座";

        var duration = DurationFormatter.FormatDuration(elapsedSeconds, localization);
        var template = localization?.GetString("ActivityBackToastBody", "✅ 「{0}」已结束，用时 {1}")
                       ?? "✅ 「{0}」已结束，用时 {1}";
        return string.Format(CultureInfo.InvariantCulture, template, name, duration);
    }

    public static int ElapsedSecondsFromStartedAt(string? startedAt, DateTime? nowUtc = null)
    {
        if (string.IsNullOrWhiteSpace(startedAt))
            return 0;

        if (!DateTime.TryParse(startedAt, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var started)
            && !DateTime.TryParse(startedAt, out started))
            return 0;

        var startedUtc = started.Kind == DateTimeKind.Local
            ? started.ToUniversalTime()
            : DateTime.SpecifyKind(started, DateTimeKind.Utc);
        var now = nowUtc ?? DateTime.UtcNow;
        return Math.Max(0, (int)(now - startedUtc).TotalSeconds);
    }

    private static int LimitMinutes(int limitSeconds)
    {
        if (limitSeconds <= 0)
            return 0;
        var minutes = limitSeconds / 60;
        if (limitSeconds % 60 != 0)
            minutes++;
        return minutes;
    }

    private static string? ResolveActivityCode(string name, IEnumerable<TgActivityTypeItem>? activityTypes)
    {
        if (activityTypes != null)
        {
            foreach (var type in activityTypes)
            {
                if (string.Equals(type.Name, name, StringComparison.OrdinalIgnoreCase)
                    && !string.IsNullOrWhiteSpace(type.Code))
                {
                    return type.Code;
                }
            }
        }

        return ActivityNameToCode.TryGetValue(name, out var code) ? code : null;
    }

    private static bool TryParseChineseDuration(string text, out int totalSeconds)
    {
        totalSeconds = 0;
        var match = ChineseDurationRegex.Match(text.Trim());
        if (!match.Success)
            return false;

        var hasPart = false;
        if (match.Groups["h"].Success && int.TryParse(match.Groups["h"].Value, NumberStyles.None, CultureInfo.InvariantCulture, out var hours))
        {
            totalSeconds += hours * 3600;
            hasPart = true;
        }

        if (match.Groups["m"].Success && int.TryParse(match.Groups["m"].Value, NumberStyles.None, CultureInfo.InvariantCulture, out var minutes))
        {
            totalSeconds += minutes * 60;
            hasPart = true;
        }

        if (match.Groups["s"].Success && int.TryParse(match.Groups["s"].Value, NumberStyles.None, CultureInfo.InvariantCulture, out var seconds))
        {
            totalSeconds += seconds;
            hasPart = true;
        }

        return hasPart;
    }
}

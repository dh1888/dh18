using System.Diagnostics;
using System.Net.Http.Json;
using System.Text.Json.Serialization;
using EnterpriseAgent.Agent.Extensions;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Shared;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

public sealed class ClientReleaseInfo
{
    [JsonPropertyName("version")]
    public string Version { get; set; } = "";

    [JsonPropertyName("downloadUrl")]
    public string DownloadUrl { get; set; } = "";

    [JsonPropertyName("updatePackageUrl")]
    public string UpdatePackageUrl { get; set; } = "";

    [JsonPropertyName("sha256")]
    public string Sha256 { get; set; } = "";

    [JsonPropertyName("updateSha256")]
    public string UpdateSha256 { get; set; } = "";

    [JsonPropertyName("updateSignature")]
    public string UpdateSignature { get; set; } = "";

    [JsonPropertyName("updateSigningKeyId")]
    public string UpdateSigningKeyId { get; set; } = "";

    [JsonPropertyName("updateSignatureAlg")]
    public string UpdateSignatureAlg { get; set; } = "";

    [JsonPropertyName("fileName")]
    public string FileName { get; set; } = "";

    [JsonPropertyName("available")]
    public bool Available { get; set; }

    public string GetEffectiveUpdateUrl()
    {
        if (!string.IsNullOrWhiteSpace(UpdatePackageUrl))
            return UpdatePackageUrl;
        return DownloadUrl;
    }

    public string GetEffectiveUpdateSha256()
    {
        if (!string.IsNullOrWhiteSpace(UpdateSha256))
            return UpdateSha256;
        return Sha256;
    }
}

public sealed class ClientUpdateService
{
    private readonly AgentConfig _config;
    private readonly IHttpClientFactory _httpFactory;
    private readonly IAuthTokenProvider _authTokenProvider;
    private readonly ILogger<ClientUpdateService> _logger;

    public ClientUpdateService(
        AgentConfig config,
        IHttpClientFactory httpFactory,
        IAuthTokenProvider authTokenProvider,
        ILogger<ClientUpdateService> logger)
    {
        _config = config;
        _httpFactory = httpFactory;
        _authTokenProvider = authTokenProvider;
        _logger = logger;
    }

    public string CurrentVersion => AppVersion.Current;

    public async Task<ClientReleaseInfo?> FetchReleaseAsync(CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(_config.ServerUrl))
            return null;

        var url = $"{_config.ServerUrl.TrimEnd('/')}/api/v1/meta/client-release";
        try
        {
            var client = _httpFactory.CreateClient("AgentClient");
            using var response = await client.GetAsync(url, cancellationToken);
            response.EnsureSuccessStatusCode();
            var payload = await response.Content.ReadFromJsonAsync<ApiEnvelope<ClientReleaseInfo>>(cancellationToken);
            return payload?.Data;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to fetch client release from {Url}", url);
            return null;
        }
    }

    public bool IsNewerVersionAvailable(ClientReleaseInfo release)
    {
        if (!release.Available || string.IsNullOrWhiteSpace(release.Version))
            return false;
        return CompareSemVer(release.Version, CurrentVersion) > 0;
    }

    public async Task<bool> TryApplyUpdateAsync(ClientReleaseInfo release, CancellationToken cancellationToken = default)
    {
        var updateUrl = release.GetEffectiveUpdateUrl();
        if (string.IsNullOrWhiteSpace(updateUrl))
        {
            _logger.LogWarning("Update release has no download URL");
            return false;
        }

        var updaterPath = ResolveUpdaterPath();
        if (updaterPath == null)
        {
            _logger.LogError("{Updater} not found next to agent or in Updater folder", AppIdentity.UpdaterExeFileName);
            return false;
        }

        var installDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\', '/');
        var sha256 = release.GetEffectiveUpdateSha256();
        if (string.IsNullOrWhiteSpace(sha256) ||
            string.IsNullOrWhiteSpace(release.UpdateSignature) ||
            string.IsNullOrWhiteSpace(release.UpdateSigningKeyId))
        {
            _logger.LogError(
                "Refusing update: release metadata missing sha256/signature/keyId (server must publish signed update package)");
            return false;
        }

        // Download with device Bearer token (update-package requires auth); pass local zip to Updater.
        var tempZip = Path.Combine(Path.GetTempPath(), $"{AppIdentity.BaseName.ToLowerInvariant()}-update-{Guid.NewGuid():N}.zip");
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, updateUrl);
            if (!HttpAuthExtensions.TryApplyBearerToken(request, _authTokenProvider))
            {
                _logger.LogWarning("No device token available for authenticated update download");
                return false;
            }

            using var client = _httpFactory.CreateClient("AgentClient");
            using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("Update package download failed: {Status} {Url}", (int)response.StatusCode, updateUrl);
                return false;
            }

            await using (var src = await response.Content.ReadAsStreamAsync(cancellationToken))
            await using (var dst = File.Create(tempZip))
            {
                await src.CopyToAsync(dst, cancellationToken);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to download update package from {Url}", updateUrl);
            TryDelete(tempZip);
            return false;
        }

        var args = new List<string>
        {
            "--install-dir", Quote(installDir),
            "--package", Quote(tempZip),
            "--sha256", Quote(sha256),
            "--signature", Quote(release.UpdateSignature.Trim()),
            "--signing-key-id", Quote(release.UpdateSigningKeyId.Trim()),
            "--restart",
        };
        if (!string.IsNullOrWhiteSpace(release.UpdateSignatureAlg))
        {
            args.Add("--signature-alg");
            args.Add(Quote(release.UpdateSignatureAlg.Trim()));
        }

        _logger.LogInformation("Launching updater {Updater} for version {Version}", updaterPath, release.Version);
        MarkVoluntaryExitForUpdate();

        var tempUpdater = Path.Combine(Path.GetTempPath(), $"{AppIdentity.UpdaterProcessName}-{Guid.NewGuid():N}.exe");
        File.Copy(updaterPath, tempUpdater, overwrite: true);

        Process.Start(new ProcessStartInfo
        {
            FileName = tempUpdater,
            Arguments = string.Join(" ", args),
            UseShellExecute = true,
            WorkingDirectory = installDir,
        });

        await Task.Delay(500, cancellationToken);
        return true;
    }

    private static void TryDelete(string path)
    {
        try
        {
            if (File.Exists(path))
                File.Delete(path);
        }
        catch
        {
            // best-effort
        }
    }

    private static string? ResolveUpdaterPath()
    {
        var baseDir = AppDomain.CurrentDomain.BaseDirectory;
        foreach (var candidate in new[]
                 {
                     Path.Combine(baseDir, "Updater", AppIdentity.UpdaterExeFileName),
                     Path.Combine(baseDir, AppIdentity.UpdaterExeFileName),
                 })
        {
            if (File.Exists(candidate))
                return candidate;
        }

        return null;
    }

    private static void MarkVoluntaryExitForUpdate()
    {
        try
        {
            var marker = Path.Combine(AppPaths.GetAppDataPath(), "voluntary_exit.marker");
            File.WriteAllText(marker, DateTime.UtcNow.ToString("O"));
        }
        catch
        {
            // updater also sets marker
        }
    }

    private static string Quote(string value) => $"\"{value.Replace("\"", "\\\"")}\"";

    internal static int CompareSemVer(string left, string right)
    {
        static int[] Parts(string v) => v.Split('.', '-', '+')
            .Select(p => int.TryParse(p, out var n) ? n : 0)
            .ToArray();

        var a = Parts(left);
        var b = Parts(right);
        var len = Math.Max(a.Length, b.Length);
        for (var i = 0; i < len; i++)
        {
            var av = i < a.Length ? a[i] : 0;
            var bv = i < b.Length ? b[i] : 0;
            if (av != bv)
                return av.CompareTo(bv);
        }

        return 0;
    }

    private sealed class ApiEnvelope<T>
    {
        [JsonPropertyName("code")]
        public int Code { get; set; }

        [JsonPropertyName("data")]
        public T? Data { get; set; }
    }
}

public sealed class ClientUpdateBackgroundService : BackgroundService
{
    private static readonly TimeSpan CheckInterval = TimeSpan.FromHours(12);
    private readonly ClientUpdateService _updateService;
    private readonly AgentNotificationService _notifications;
    private readonly ILocalizationService? _localization;
    private readonly ILogger<ClientUpdateBackgroundService> _logger;

    public ClientUpdateBackgroundService(
        ClientUpdateService updateService,
        AgentNotificationService notifications,
        ILogger<ClientUpdateBackgroundService> logger,
        ILocalizationService? localization = null)
    {
        _updateService = updateService;
        _notifications = notifications;
        _logger = logger;
        _localization = localization;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await Task.Delay(TimeSpan.FromMinutes(2), stoppingToken);
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await CheckSilentlyAsync(stoppingToken);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogDebug(ex, "Background update check failed");
            }

            await Task.Delay(CheckInterval, stoppingToken);
        }
    }

    private async Task CheckSilentlyAsync(CancellationToken cancellationToken)
    {
        var release = await _updateService.FetchReleaseAsync(cancellationToken);
        if (release == null || !_updateService.IsNewerVersionAvailable(release))
            return;

        var title = _localization?.GetString("UpdateAvailableTitle", "客户端更新") ?? "客户端更新";
        var bodyTemplate = _localization?.GetString("UpdateAvailableBody", "新版本 {0} 可用，当前 {1}。请从托盘菜单检查更新。")
                           ?? "新版本 {0} 可用，当前 {1}。请从托盘菜单检查更新。";
        _notifications.ShowLocal(
            title,
            string.Format(bodyTemplate, release.Version, _updateService.CurrentVersion),
            "info");
    }
}

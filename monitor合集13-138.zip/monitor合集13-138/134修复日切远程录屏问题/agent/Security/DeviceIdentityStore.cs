using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Security;

/// <summary>
/// Durable deviceId + deviceSecret store (DPAPI), separate from config.json so recreating
/// default config after a wipe does not lose re-registration continuity proof.
/// </summary>
public sealed class DeviceIdentityStore
{
    private const string FileName = "device.identity";
    private readonly ILogger<DeviceIdentityStore> _logger;
    private readonly WindowsDataProtection _dataProtection;
    private readonly string _filePath;
    private readonly object _gate = new();

    public DeviceIdentityStore(
        ILogger<DeviceIdentityStore> logger,
        WindowsDataProtection dataProtection,
        string configDirectory)
    {
        _logger = logger;
        _dataProtection = dataProtection;
        Directory.CreateDirectory(configDirectory);
        _filePath = Path.Combine(configDirectory, FileName);
    }

    public sealed class Identity
    {
        public string DeviceId { get; set; } = "";
        public string DeviceSecret { get; set; } = "";
    }

    public Identity? TryLoad()
    {
        lock (_gate)
        {
            try
            {
                if (!File.Exists(_filePath))
                    return null;

                var sealedBytes = File.ReadAllBytes(_filePath);
                var json = Encoding.UTF8.GetString(_dataProtection.Decrypt(sealedBytes));
                var identity = JsonSerializer.Deserialize<Identity>(json);
                if (identity == null ||
                    string.IsNullOrWhiteSpace(identity.DeviceId) ||
                    string.IsNullOrWhiteSpace(identity.DeviceSecret))
                {
                    return null;
                }

                return identity;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to load durable device identity from {Path}", _filePath);
                return null;
            }
        }
    }

    public void Save(string deviceId, string deviceSecret)
    {
        if (string.IsNullOrWhiteSpace(deviceId) || string.IsNullOrWhiteSpace(deviceSecret))
            return;

        lock (_gate)
        {
            try
            {
                var json = JsonSerializer.Serialize(new Identity
                {
                    DeviceId = deviceId.Trim(),
                    DeviceSecret = deviceSecret.Trim(),
                });
                var sealedBytes = _dataProtection.Encrypt(Encoding.UTF8.GetBytes(json));
                var tmp = _filePath + ".tmp";
                File.WriteAllBytes(tmp, sealedBytes);
                File.Copy(tmp, _filePath, overwrite: true);
                File.Delete(tmp);
                _logger.LogDebug("Durable device identity saved");
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to save durable device identity to {Path}", _filePath);
            }
        }
    }
}

namespace EnterpriseAgent.Agent.RemoteView;

/// <summary>
/// Lifecycle identity for a remote publish session (session + quality + URL).
/// Used to detect QualityChange / session swap vs same-param recovery.
/// </summary>
internal static class RemoteLifecycleFingerprint
{
    public static string Build(RemoteViewStartParams p)
    {
        ArgumentNullException.ThrowIfNull(p);
        return $"{p.SessionId}|{p.ResolvePublishProtocol()}|{p.NetworkProfile}|{p.Width}x{p.Height}@{p.Fps}|{p.VideoBitrateKbps}|{p.ResolvePublishUrl()}";
    }

    /// <summary>
    /// Pure check: whether a recovery snapshot is still allowed to mutate FFmpeg/pipe.
    /// </summary>
    public static bool IsRecoveryStillValid(
        int capturedGeneration,
        int currentGeneration,
        int capturedEpoch,
        int currentEpoch,
        RemoteViewStartParams snapshot,
        RemoteViewStartParams? activeParams,
        string capturedFingerprint,
        out string abortDetail)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        ArgumentNullException.ThrowIfNull(capturedFingerprint);

        if (capturedGeneration != currentGeneration)
        {
            abortDetail = $"generation-stale captured={capturedGeneration} current={currentGeneration}";
            return false;
        }

        if (capturedEpoch != currentEpoch)
        {
            abortDetail = $"epoch-stale captured={capturedEpoch} current={currentEpoch}";
            return false;
        }

        if (activeParams == null)
        {
            abortDetail = "active-params-null";
            return false;
        }

        if (!string.Equals(activeParams.SessionId, snapshot.SessionId, StringComparison.Ordinal))
        {
            abortDetail =
                $"session-mismatch want={snapshot.SessionId} have={activeParams.SessionId}";
            return false;
        }

        var activeFp = Build(activeParams);
        if (!string.Equals(activeFp, capturedFingerprint, StringComparison.Ordinal))
        {
            abortDetail = "fingerprint-mismatch";
            return false;
        }

        abortDetail = "";
        return true;
    }
}

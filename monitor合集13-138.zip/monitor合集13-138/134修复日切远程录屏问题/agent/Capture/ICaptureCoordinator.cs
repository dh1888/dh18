namespace EnterpriseAgent.Agent.Capture;

public enum CaptureConsumer
{
    Recording,
    RemoteView,
}

public enum CaptureMode
{
    /// <summary>Each service runs its own gdigrab FFmpeg input.</summary>
    DualGdigrab = 0,

    /// <summary>Single capture bridge feeds raw frames to separate encoder processes.</summary>
    SharedBridge = 1,
}

public sealed class CaptureProfile
{
    public int RecordingWidth { get; init; }
    public int RecordingHeight { get; init; }
    public int RecordingFps { get; init; }
    public int RemoteWidth { get; init; }
    public int RemoteHeight { get; init; }
    public int RemoteFps { get; init; }
    public CaptureMode Mode { get; init; }
    public string? RecordingInputArgs { get; init; }
    public string? RemoteInputArgs { get; init; }
}

public interface ICaptureCoordinator
{
    CaptureMode Mode { get; }
    bool IsSharedCaptureActive { get; }
    bool IsSharedBridgeOrchestrated { get; }

    CaptureProfile GetProfile();
    Task NotifyConsumerStartingAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default);
    Task NotifyConsumerStoppingAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default);

    Task PrepareSharedCaptureAsync(CancellationToken cancellationToken = default);
    Task WaitSharedConsumersConnectedAsync(CancellationToken cancellationToken = default, bool requireRemote = true);
    Task StartSharedCaptureAsync(CancellationToken cancellationToken = default);
    Task WaitSharedBridgeFlowingAsync(
        CancellationToken cancellationToken = default,
        bool requireConsumerFirstFrames = true,
        bool requireRemoteConsumer = true);
    Task StopSharedCaptureAsync(CancellationToken cancellationToken = default);
    Task DisposeSharedCaptureAsync(CancellationToken cancellationToken = default);
    Task RestartSharedBridgeProducerAsync(CancellationToken cancellationToken = default);
    /// <summary>
    /// Recreate the server pipe and block until the FFmpeg client connects (up to 30s).
    /// Do not use this to "confirm" a recording consumer after Recreate + Start —
    /// that wait becomes a startup precondition and can stall date rollover.
    /// </summary>
    Task ReconnectSharedBridgeConsumerAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default);
    /// <summary>
    /// Recreate pipe and listen without waiting for FFmpeg to connect.
    /// Date rollover / recording relaunch: Recreate(listen) → StartRecording → return.
    /// Pipe/first-frame observation is health's job, never ReconnectPipeAsync after Start.
    /// </summary>
    Task RecreateSharedBridgeConsumerPipeAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default);
    void ResetSharedBridgeConsumerFrameReader(CaptureConsumer consumer, bool snapToLatest = true);
    int GetSharedFrameHubEnterRemoteWarmMs();
    Task ReconnectBrokenSharedBridgeConsumersAsync(CancellationToken cancellationToken = default);

    void NotifyConsumerFirstFrame(CaptureConsumer consumer);
    bool NeedsConsumerFirstFrame(CaptureConsumer consumer);
    void SetSharedBridgeOrchestrated(bool orchestrated);
    void ResetConsumerTracking();
    SharedBridgeHealthSnapshot GetSharedBridgeHealth();
    PipelineDiagBridgeSnapshot GetPipelineDiagSnapshot();
}

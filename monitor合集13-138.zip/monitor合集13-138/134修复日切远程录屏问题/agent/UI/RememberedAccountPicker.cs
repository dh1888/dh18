// UI/RememberedAccountPicker.cs — username combo + remember checkbox (stacked rows)
using System.Drawing;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Services;

namespace EnterpriseAgent.Agent.UI;

/// <summary>
/// Username entry on one row, "remember account" on the next.
/// Avatar quick-select lives in <see cref="RememberedAccountAvatarStrip"/> (sibling control).
/// </summary>
public sealed class RememberedAccountPicker : UserControl
{
    private const int RowGap = 6;
    private const int PickerHeight = 58;

    private readonly ComboBox _accountCombo;
    private readonly CheckBox _rememberCheck;
    private readonly ContextMenuStrip _accountMenu;
    private readonly ToolStripMenuItem _removeCurrentItem;
    private ILocalizationService? _localization;
    private Func<string> _serverKeyProvider = () => RememberedAccountStore.NormalizeServerKey(null);
    private bool _suppressTextSync;
    private bool _layoutBusy;

    public RememberedAccountPicker()
    {
        Width = 298;
        Height = PickerHeight;
        MinimumSize = new Size(120, PickerHeight);
        MaximumSize = new Size(LoginUiChrome.DialogWidth, PickerHeight);
        BackColor = Color.Transparent;

        _accountCombo = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDown,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 10F),
            IntegralHeight = false,
            MaxDropDownItems = 10,
            BackColor = LoginUiChrome.FieldBg,
            ForeColor = LoginUiChrome.TextPrimary
        };
        _accountCombo.TextChanged += (_, _) =>
        {
            if (!_suppressTextSync)
                UsernameChanged?.Invoke(this, EventArgs.Empty);
        };

        _rememberCheck = new CheckBox
        {
            AutoSize = true,
            Checked = true,
            ForeColor = LoginUiChrome.TextMuted,
            Font = new Font("Segoe UI", 8.75F),
            UseVisualStyleBackColor = true
        };

        _removeCurrentItem = new ToolStripMenuItem();
        _removeCurrentItem.Click += (_, _) => RemoveCurrentAccount();
        _accountMenu = new ContextMenuStrip();
        _accountMenu.Items.Add(_removeCurrentItem);
        _accountCombo.ContextMenuStrip = _accountMenu;

        Controls.Add(_accountCombo);
        Controls.Add(_rememberCheck);

        Resize += (_, _) =>
        {
            if (!_layoutBusy)
                LayoutControls();
        };
        LayoutControls();
        ApplyLocalization(null);
    }

    public event EventHandler? AccountQuickSelected;
    public event EventHandler? AccountsRefreshed;
    public event EventHandler? UsernameChanged;
    public event EventHandler? LayoutChanged;

    public string Username => _accountCombo.Text.Trim();

    public bool RememberAccount => _rememberCheck.Checked;

    public string GetServerKey() => _serverKeyProvider();

    public IReadOnlyList<string> GetRememberedAccountItems()
        => _accountCombo.Items.Cast<object>().Select(o => o?.ToString()?.Trim() ?? string.Empty)
            .Where(s => s.Length > 0)
            .ToList();

    public void SetServerKeyProvider(Func<string> provider)
    {
        _serverKeyProvider = provider ?? (() => RememberedAccountStore.NormalizeServerKey(null));
        RefreshAccounts();
    }

    public void SetServerKey(string? serverUrl)
        => SetServerKeyProvider(() => RememberedAccountStore.NormalizeServerKey(serverUrl));

    public void ApplyLocalization(ILocalizationService? localization)
    {
        _localization = localization;
        _rememberCheck.Text = L("RememberAccount", "记住账号");
        _removeCurrentItem.Text = L("RemoveRememberedAccount", "清除此账号");
        LayoutControls();
    }

    public void ApplyChrome()
    {
        BackColor = Color.Transparent;
        _accountCombo.FlatStyle = FlatStyle.Flat;
        _accountCombo.Font = new Font("Segoe UI", 10F);
        _accountCombo.BackColor = LoginUiChrome.FieldBg;
        _accountCombo.ForeColor = LoginUiChrome.TextPrimary;
        _rememberCheck.ForeColor = LoginUiChrome.TextMuted;
        _rememberCheck.Font = new Font("Segoe UI", 8.75F);
        LayoutControls();
    }

    public void RefreshAccounts()
    {
        var serverKey = _serverKeyProvider();
        var accounts = RememberedAccountStore.GetAccountsForQuickSelect(serverKey);
        var previous = _accountCombo.Text;

        _suppressTextSync = true;
        _accountCombo.BeginUpdate();
        try
        {
            _accountCombo.Items.Clear();
            foreach (var account in accounts)
                _accountCombo.Items.Add(account);
        }
        finally
        {
            _accountCombo.EndUpdate();
            _suppressTextSync = false;
        }

        var lastUsed = RememberedAccountStore.GetLastUsed(serverKey);
        if (!string.IsNullOrWhiteSpace(lastUsed))
            _accountCombo.Text = lastUsed;
        else if (!string.IsNullOrWhiteSpace(previous))
            _accountCombo.Text = previous;

        LayoutControls();
        AccountsRefreshed?.Invoke(this, EventArgs.Empty);
        UsernameChanged?.Invoke(this, EventArgs.Empty);
    }

    public void FocusUsername()
    {
        _accountCombo.Focus();
        _accountCombo.SelectAll();
    }

    public void SelectAccount(string username, bool raiseQuickSelected = true)
    {
        username = username.Trim();
        if (string.IsNullOrWhiteSpace(username))
            return;

        _suppressTextSync = true;
        try
        {
            _accountCombo.Text = username;
        }
        finally
        {
            _suppressTextSync = false;
        }

        if (raiseQuickSelected)
            AccountQuickSelected?.Invoke(this, EventArgs.Empty);
        UsernameChanged?.Invoke(this, EventArgs.Empty);
    }

    private void RemoveCurrentAccount()
    {
        var username = Username;
        if (string.IsNullOrWhiteSpace(username))
            return;

        RememberedAccountStore.Remove(_serverKeyProvider(), username);
        _accountCombo.Text = string.Empty;
        RefreshAccounts();
    }

    private void LayoutControls()
    {
        if (_layoutBusy)
            return;

        _layoutBusy = true;
        try
        {
            var width = Math.Max(120, Width);

            _accountCombo.Location = new Point(0, 0);
            _accountCombo.Width = width;
            _accountCombo.Height = LoginUiChrome.FieldHeight;

            _rememberCheck.MaximumSize = Size.Empty;
            _rememberCheck.Location = new Point(0, _accountCombo.Bottom + RowGap);

            MinimumSize = new Size(120, PickerHeight);
            MaximumSize = new Size(LoginUiChrome.DialogWidth, PickerHeight);
            if (Height != PickerHeight)
                Height = PickerHeight;

            Parent?.PerformLayout();
            LayoutChanged?.Invoke(this, EventArgs.Empty);
        }
        finally
        {
            _layoutBusy = false;
        }
    }

    private string L(string key, string fallback)
        => _localization?.GetString(key, fallback) ?? fallback;
}

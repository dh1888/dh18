// UI/RememberedAccountAvatarStrip.cs — quick-select avatars (sibling of account field)
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Services;

namespace EnterpriseAgent.Agent.UI;

/// <summary>
/// Horizontal avatar chips for remembered accounts. Separate from the username field
/// so FlowLayoutPanel cannot clip it. Click fills username only (no password / auto-login).
/// </summary>
public sealed class RememberedAccountAvatarStrip : UserControl
{
    private const int MaxVisibleAvatars = 6;
    private const int ChipWidth = 56;
    private const int AvatarSize = 48;
    private const int StripBodyHeight = 56;

    private readonly Label _title;
    private readonly FlowLayoutPanel _strip;
    private readonly ToolTip _toolTip = new() { ShowAlways = true };
    private ILocalizationService? _localization;
    private Func<string> _serverKeyProvider = () => RememberedAccountStore.NormalizeServerKey(null);
    private string? _selectedUsername;
    private RememberedAccountPicker? _boundPicker;

    public RememberedAccountAvatarStrip()
    {
        Width = LoginUiChrome.ContentWidth;
        BackColor = Color.Transparent;
        Margin = new Padding(0, 0, 0, 6);
        Visible = false;
        Height = 0;

        _title = new Label
        {
            AutoSize = false,
            Height = 18,
            Dock = DockStyle.Top,
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
            ForeColor = LoginUiChrome.TextMuted,
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent
        };

        _strip = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            WrapContents = false,
            AutoScroll = true,
            FlowDirection = FlowDirection.LeftToRight,
            BackColor = Color.Transparent,
            Padding = new Padding(0, 2, 0, 0),
            Margin = new Padding(0)
        };

        Controls.Add(_strip);
        Controls.Add(_title);
        ApplyLocalization(null);
    }

    public event EventHandler? LayoutChanged;

    public void BindPicker(RememberedAccountPicker picker)
    {
        if (_boundPicker != null)
            _boundPicker.AccountsRefreshed -= OnPickerAccountsRefreshed;

        _boundPicker = picker ?? throw new ArgumentNullException(nameof(picker));
        _boundPicker.AccountsRefreshed += OnPickerAccountsRefreshed;
        _serverKeyProvider = _boundPicker.GetServerKey;
        RefreshFromStore();
    }

    public void SetServerKeyProvider(Func<string> provider)
    {
        _serverKeyProvider = provider ?? (() => RememberedAccountStore.NormalizeServerKey(null));
        RefreshFromStore();
    }

    public void ApplyLocalization(ILocalizationService? localization)
    {
        _localization = localization;
        _title.Text = L("QuickSelectAccount", "选择账号");
    }

    public void RefreshFromStore()
    {
        var accounts = RememberedAccountStore.GetAccountsForQuickSelect(_serverKeyProvider());
        // Also include whatever is currently in the bound combo (covers edge sync cases).
        if (_boundPicker != null)
        {
            foreach (var item in _boundPicker.GetRememberedAccountItems())
            {
                if (accounts.Any(a => string.Equals(a, item, StringComparison.OrdinalIgnoreCase)))
                    continue;
                accounts = accounts.Append(item).ToList();
            }
        }

        Rebuild(accounts);
        _selectedUsername = _boundPicker?.Username;
        InvalidateChips();
    }

    public void SyncSelectedUsername(string? username)
    {
        _selectedUsername = username?.Trim();
        InvalidateChips();
    }

    private void OnPickerAccountsRefreshed(object? sender, EventArgs e) => RefreshFromStore();

    private void Rebuild(IReadOnlyList<string> accounts)
    {
        var old = _strip.Controls.Cast<Control>().ToArray();
        _strip.Controls.Clear();
        foreach (var c in old)
            c.Dispose();

        if (accounts.Count == 0)
        {
            Visible = false;
            Height = 0;
            MinimumSize = new Size(0, 0);
            MaximumSize = new Size(0, 0);
            LayoutChanged?.Invoke(this, EventArgs.Empty);
            return;
        }

        foreach (var account in accounts.Take(MaxVisibleAvatars))
            _strip.Controls.Add(CreateChip(account));

        var height = 18 + StripBodyHeight + 4;
        Visible = true;
        MinimumSize = new Size(120, height);
        MaximumSize = new Size(LoginUiChrome.DialogWidth, height);
        Height = height;
        Width = Math.Max(Width, LoginUiChrome.ContentWidth);
        LayoutChanged?.Invoke(this, EventArgs.Empty);
    }

    private Control CreateChip(string username)
    {
        var chip = new Panel
        {
            Width = ChipWidth,
            Height = AvatarSize + 4,
            Margin = new Padding(0, 0, 10, 0),
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand,
            Tag = username
        };

        var avatarHost = new Panel
        {
            Size = new Size(AvatarSize, AvatarSize),
            Location = new Point((ChipWidth - AvatarSize) / 2, 2),
            BackColor = Color.Transparent
        };

        avatarHost.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            var selected = string.Equals(_selectedUsername, username, StringComparison.OrdinalIgnoreCase);
            var rect = new Rectangle(1, 1, avatarHost.Width - 3, avatarHost.Height - 3);

            using (var path = LoginUiChrome.CreateRoundedPath(rect, rect.Width / 2))
            {
                g.SetClip(path);
                g.DrawImage(AccountAvatarGallery.GetAvatar(username), rect);
                g.ResetClip();
            }

            // Built-in style chips keep a light initial for disambiguation; custom photos stay clean.
            if (!AccountAvatarGallery.UsesCustomImages)
            {
                var initial = AccountAvatarGallery.GetInitial(username);
                using var font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
                using var brush = new SolidBrush(Color.FromArgb(235, Color.White));
                var size = g.MeasureString(initial, font);
                g.DrawString(
                    initial,
                    font,
                    brush,
                    (avatarHost.Width - size.Width) / 2f,
                    (avatarHost.Height - size.Height) / 2f + 1f);
            }

            using var ring = new Pen(
                selected ? LoginUiChrome.Accent : Color.FromArgb(180, LoginUiChrome.Border),
                selected ? 2.4f : 1.2f);
            g.DrawEllipse(ring, rect);

            if (selected)
            {
                using var glow = new Pen(Color.FromArgb(70, LoginUiChrome.Accent), 4f);
                g.DrawEllipse(glow, Rectangle.Inflate(rect, 1, 1));
            }
        };

        void SelectThis(object? sender, EventArgs e)
        {
            _selectedUsername = username;
            InvalidateChips();
            _boundPicker?.SelectAccount(username, raiseQuickSelected: true);
        }

        chip.Click += SelectThis;
        avatarHost.Click += SelectThis;
        _toolTip.SetToolTip(chip, username);
        _toolTip.SetToolTip(avatarHost, username);

        var removeItem = new ToolStripMenuItem(L("RemoveRememberedAccount", "清除此账号"));
        removeItem.Click += (_, _) =>
        {
            RememberedAccountStore.Remove(_serverKeyProvider(), username);
            _boundPicker?.RefreshAccounts();
            RefreshFromStore();
        };
        var menu = new ContextMenuStrip();
        menu.Items.Add(removeItem);
        chip.ContextMenuStrip = menu;
        avatarHost.ContextMenuStrip = menu;

        chip.Controls.Add(avatarHost);
        return chip;
    }

    private void InvalidateChips()
    {
        foreach (Control chip in _strip.Controls)
        {
            foreach (Control child in chip.Controls)
                child.Invalidate();
            chip.Invalidate();
        }
    }

    private string L(string key, string fallback)
        => _localization?.GetString(key, fallback) ?? fallback;
}

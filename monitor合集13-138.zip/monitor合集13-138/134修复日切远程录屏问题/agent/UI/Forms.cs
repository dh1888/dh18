// UI/Forms.cs - UI 表单合并（EmployeeSetupForm / EmployeeLoginForm / StatusForm）支持多语言

using System.Drawing;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Services;
using EnterpriseAgent.Shared;
using Microsoft.Extensions.Logging;
using DrawingImage = System.Drawing.Image;
using DrawingSize = System.Drawing.Size;
using DrawingColor = System.Drawing.Color;
using DrawingPoint = System.Drawing.Point;
using DrawingPointF = System.Drawing.PointF;

namespace EnterpriseAgent.Agent.UI;

public enum EmployeeSetupFormMode
{
    /// <summary>首次登录：服务器 + 邀请码 + 账号密码</summary>
    FirstLogin,
    /// <summary>托盘补绑：仅邀请码 / 共享工位</summary>
    InviteBinding
}

#region EmployeeSetupForm

public class EmployeeSetupForm : Form
{
    private TextBox txtPassword = null!;
    private TextBox txtInviteCode = null!;
    private TextBox txtServerUrl = null!;
    private Panel serverUrlHost = null!;
    private Panel inviteCodeHost = null!;
    private Panel passwordHost = null!;
    private Button btnSave = null!;
    private Button btnShared = null!;
    private Button btnCancel = null!;
    private Label lblTitle = null!;
    private Label lblInvite = null!;
    private Label lblUsername = null!;
    private RememberedAccountPicker accountPicker = null!;
    private RememberedAccountAvatarStrip accountAvatarStrip = null!;
    private Label lblPassword = null!;
    private Label lblServerUrl = null!;
    private Label lblHint = null!;
    private Label lblLanguage = null!;
    private ComboBox cboLanguage = null!;
    private PictureBox pictLogo = null!;
    private Panel headerBand = null!;
    private Panel bodyPanel = null!;
    private Panel footerPanel = null!;

    private readonly ILogger<EmployeeSetupForm>? _logger;
    private readonly ILocalizationService? _localization;
    private readonly string? _lockedServerUrl;
    private readonly EmployeeSetupFormMode _mode;
    private bool _languageComboUpdating;
    private bool _exitPromptActive;

    public EmployeeInfo? EmployeeInfo { get; private set; }
    public string ServerUrl { get; private set; } = string.Empty;
    public bool UseSharedWorkstation { get; private set; }
    public string InviteCode => txtInviteCode.Text.Trim();
    public string Username => accountPicker.Username;
    public bool RememberAccount => accountPicker.RememberAccount;
    public string Password => txtPassword.Text;

    public EmployeeSetupForm(
        ILogger<EmployeeSetupForm>? logger = null,
        ILocalizationService? localization = null,
        string? serverUrl = null,
        string? lockedServerUrl = null,
        EmployeeSetupFormMode mode = EmployeeSetupFormMode.FirstLogin)
    {
        _logger = logger;
        _localization = localization;
        _mode = mode;
        _lockedServerUrl = string.IsNullOrWhiteSpace(lockedServerUrl) ? null : lockedServerUrl.Trim();

        InitializeComponent();
        ConfigureForMode();
        ApplyLocalization();
        ConfigureServerUrlField(serverUrl);
        if (_localization != null)
            _localization.LanguageChanged += OnLanguageChanged;
        CenterToScreen();
    }

    public EmployeeSetupForm(ILogger<EmployeeSetupForm>? logger = null, ILocalizationService? localization = null, string? serverUrl = null)
        : this(logger, localization, serverUrl, lockedServerUrl: null, mode: EmployeeSetupFormMode.FirstLogin)
    {
    }

    private void ConfigureServerUrlField(string? serverUrl)
    {
        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            ServerUrl = _lockedServerUrl ?? serverUrl ?? string.Empty;
            return;
        }

        if (!string.IsNullOrWhiteSpace(_lockedServerUrl))
        {
            txtServerUrl.Text = _lockedServerUrl;
            txtServerUrl.ReadOnly = true;
            txtServerUrl.TabStop = false;
            txtServerUrl.BackColor = LoginUiChrome.FieldReadonlyBg;
            serverUrlHost.BackColor = LoginUiChrome.FieldReadonlyBg;
            serverUrlHost.Invalidate();
        }
        else
        {
            txtServerUrl.Text = serverUrl ?? string.Empty;
            txtServerUrl.ReadOnly = false;
            txtServerUrl.TabStop = true;
            txtServerUrl.BackColor = LoginUiChrome.FieldBg;
            serverUrlHost.BackColor = LoginUiChrome.FieldBg;
            serverUrlHost.Invalidate();
        }

        accountPicker.RefreshAccounts();
    }

    private void ConfigureForMode()
    {
        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            SetFieldVisible(lblServerUrl, serverUrlHost, false);
            SetFieldVisible(lblUsername, accountPicker, false);
            accountAvatarStrip.Visible = false;
            accountAvatarStrip.Height = 0;
            SetFieldVisible(lblPassword, passwordHost, false);
            btnShared.Visible = true;
            ClientSize = new DrawingSize(LoginUiChrome.DialogWidth, 420);
            AcceptButton = btnSave;
            CancelButton = btnCancel;
            return;
        }

        SetFieldVisible(lblServerUrl, serverUrlHost, true);
        SetFieldVisible(lblUsername, accountPicker, true);
        accountAvatarStrip.Visible = true;
        accountAvatarStrip.RefreshFromStore();
        SetFieldVisible(lblPassword, passwordHost, true);
        btnShared.Visible = true;
        ClientSize = new DrawingSize(LoginUiChrome.DialogWidth, 720);
    }

    private static void SetFieldVisible(Control label, Control field, bool visible)
    {
        label.Visible = visible;
        field.Visible = visible;
        label.Margin = visible ? new Padding(0, 6, 0, 2) : Padding.Empty;
        field.Margin = visible ? new Padding(0, 0, 0, 0) : Padding.Empty;
        if (!visible)
        {
            label.Height = 0;
            // Keep field height for layout math when re-shown; collapse via Visible only.
        }
    }

    private void InitializeComponent()
    {
        LoginUiChrome.ApplyDialogChrome(this);
        ClientSize = new DrawingSize(LoginUiChrome.DialogWidth, 700);

        headerBand = LoginUiChrome.CreateHeaderBand(128);
        LoginUiChrome.EnableDragMove(headerBand, this);

        var closeChip = LoginUiChrome.CreateCloseChip((_, _) => BtnCancel_Click(this, EventArgs.Empty));
        closeChip.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        LoginUiChrome.PlaceCloseChip(closeChip, headerBand);

        pictLogo = new PictureBox
        {
            Size = new DrawingSize(44, 44),
            Location = new DrawingPoint(LoginUiChrome.SidePadding, 16),
            BackColor = DrawingColor.Transparent,
            SizeMode = PictureBoxSizeMode.Zoom,
            Image = LoadAppLogo()
        };

        var titleStack = new Panel
        {
            Location = new DrawingPoint(LoginUiChrome.SidePadding + 56, 12),
            Size = new DrawingSize(LoginUiChrome.ContentWidth - 72, 108),
            BackColor = DrawingColor.Transparent
        };

        lblTitle = LoginUiChrome.CreateTitleLabel();
        lblTitle.Text = AppIdentity.ProcessName;

        lblHint = LoginUiChrome.CreateHintLabel(68);
        lblHint.Text = GetDefaultWelcomeText();

        titleStack.Controls.Add(lblHint);
        titleStack.Controls.Add(lblTitle);
        headerBand.Controls.Add(pictLogo);
        headerBand.Controls.Add(titleStack);
        headerBand.Controls.Add(closeChip);

        bodyPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = LoginUiChrome.Bg,
            Padding = new Padding(LoginUiChrome.SidePadding, 10, LoginUiChrome.SidePadding, 8),
            AutoScroll = true
        };

        var fields = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            BackColor = DrawingColor.Transparent,
            Padding = new Padding(0)
        };

        lblLanguage = LoginUiChrome.CreateFieldLabel();
        cboLanguage = new ComboBox { Height = LoginUiChrome.FieldHeight };
        LoginUiChrome.BindContentWidth(cboLanguage);
        LoginUiChrome.StyleComboBox(cboLanguage);
        cboLanguage.SelectedIndexChanged += (_, _) => OnLanguageComboChanged();

        lblServerUrl = LoginUiChrome.CreateFieldLabel();
        txtServerUrl = new TextBox();
        serverUrlHost = LoginUiChrome.WrapTextBox(txtServerUrl);

        lblInvite = LoginUiChrome.CreateFieldLabel();
        txtInviteCode = new TextBox();
        inviteCodeHost = LoginUiChrome.WrapTextBox(txtInviteCode);

        lblUsername = LoginUiChrome.CreateFieldLabel();
        accountPicker = new RememberedAccountPicker
        {
            Margin = new Padding(0, 0, 0, 4)
        };
        LoginUiChrome.BindContentWidth(accountPicker);
        accountPicker.ApplyChrome();
        accountPicker.SetServerKeyProvider(() =>
            RememberedAccountStore.NormalizeServerKey(_lockedServerUrl ?? txtServerUrl.Text));

        accountAvatarStrip = new RememberedAccountAvatarStrip();
        LoginUiChrome.BindContentWidth(accountAvatarStrip);
        accountAvatarStrip.BindPicker(accountPicker);

        accountPicker.AccountQuickSelected += (_, _) =>
        {
            txtPassword.Focus();
            txtPassword.SelectAll();
        };
        accountPicker.UsernameChanged += (_, _) =>
            accountAvatarStrip.SyncSelectedUsername(accountPicker.Username);
        txtServerUrl.TextChanged += (_, _) => accountPicker.RefreshAccounts();

        lblPassword = LoginUiChrome.CreateFieldLabel();
        txtPassword = new TextBox { UseSystemPasswordChar = true };
        passwordHost = LoginUiChrome.WrapPasswordBox(txtPassword, (key, fallback) =>
            _localization?.GetString(key, fallback) ?? fallback);

        fields.Controls.AddRange(new Control[]
        {
            lblLanguage, cboLanguage,
            lblServerUrl, serverUrlHost,
            lblInvite, inviteCodeHost,
            lblUsername, accountPicker,
            accountAvatarStrip,
            lblPassword, passwordHost
        });
        bodyPanel.Controls.Add(fields);

        footerPanel = new Panel
        {
            Dock = DockStyle.Bottom,
            Height = 128,
            BackColor = LoginUiChrome.Bg,
            Padding = new Padding(LoginUiChrome.SidePadding, 8, LoginUiChrome.SidePadding, 18)
        };

        btnSave = LoginUiChrome.CreatePrimaryButton("登录");
        btnSave.Width = 148;
        btnSave.Click += BtnSave_Click;

        btnCancel = LoginUiChrome.CreateSecondaryButton("退出");
        btnCancel.Width = 120;
        btnCancel.Margin = new Padding(12, 0, 0, 0);
        btnCancel.Click += BtnCancel_Click;

        var buttonHost = LoginUiChrome.CreateCenteredButtonHost(btnSave, btnCancel);
        buttonHost.Dock = DockStyle.Top;
        buttonHost.Height = 46;

        btnShared = LoginUiChrome.CreateGhostButton("共享工位（稍后登录）");
        btnShared.Dock = DockStyle.Top;
        btnShared.Height = 36;
        LoginUiChrome.BindContentWidth(btnShared);
        btnShared.Click += BtnShared_Click;

        // Dock order: last added docks first to the edge.
        footerPanel.Controls.Add(btnShared);
        footerPanel.Controls.Add(buttonHost);

        Controls.Add(bodyPanel);
        Controls.Add(footerPanel);
        Controls.Add(headerBand);

        FormClosing += EmployeeSetupForm_FormClosing;
        Shown += (_, _) => FocusFirstInput();
        AcceptButton = btnSave;
    }

    /// <summary>首次打开时将焦点置于第一个可编辑字段（避免无消息循环时无法输入）。</summary>
    public void FocusFirstInput()
    {
        Activate();
        BringToFront();

        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            txtInviteCode.Focus();
            txtInviteCode.Select();
            return;
        }

        if (!_lockedServerUrlIsSet())
        {
            txtServerUrl.Focus();
            txtServerUrl.SelectAll();
            return;
        }

        txtInviteCode.Focus();
        txtInviteCode.Select();
    }

    private bool _lockedServerUrlIsSet()
        => !string.IsNullOrWhiteSpace(_lockedServerUrl);

    private void ApplyLocalization()
    {
        lblLanguage.Text = _localization?.GetString("EmployeeLoginLanguageLabel", "界面语言") ?? "界面语言";

        if (_localization == null)
        {
            accountPicker.ApplyLocalization(null);
            accountAvatarStrip.ApplyLocalization(null);
            PopulateLanguageCombo();
            return;
        }

        lblTitle.Text = _localization.GetString("AppTitle", AppIdentity.ProcessName);
        lblServerUrl.Text = _localization.GetString("ServerURL", "服务器地址");
        lblInvite.Text = _localization.GetString("InviteCodeLabel", "邀请码");
        lblUsername.Text = _localization.GetString("LoginUsernameLabel", "账号");
        lblPassword.Text = _localization.GetString("LoginPasswordLabel", "密码");
        txtServerUrl.PlaceholderText = _localization.GetString("ServerUrlPlaceholder", "请输入服务器地址");
        txtInviteCode.PlaceholderText = _localization.GetString("InviteCodePlaceholder", "请输入管理员提供的邀请码");
        txtPassword.PlaceholderText = _localization.GetString("LoginPasswordPlaceholder", "员工后台登录密码");
        accountPicker.ApplyLocalization(_localization);
        accountPicker.RefreshAccounts();
        accountAvatarStrip.ApplyLocalization(_localization);
        accountAvatarStrip.RefreshFromStore();

        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            Text = _localization.GetString("DeviceBindingTitle", "完善设备绑定");
            lblHint.Text = _localization.GetString(
                "DeviceBindingPrompt",
                "此设备尚未绑定员工。\n请输入管理员提供的邀请码，或选择共享工位稍后登录。");
            btnSave.Text = _localization.GetString("BindDevice", "绑定设备");
            btnCancel.Text = _localization.GetString("Cancel", "取消");
            btnShared.Text = _localization.GetString("SharedWorkstation", "共享工位（稍后登录）");
            PopulateLanguageCombo();
            return;
        }

        Text = _localization.GetString("SetupTitle", AppIdentity.ProcessName);
        lblHint.Text = BuildWelcomeText(_localization);
        btnSave.Text = _localization.GetString("FirstLoginButton", "登录");
        btnCancel.Text = _localization.GetString("Exit", "退出");
        btnShared.Text = _localization.GetString("SharedWorkstation", "共享工位（稍后登录）");
        PopulateLanguageCombo();
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        if (_localization != null)
            _localization.LanguageChanged -= OnLanguageChanged;
        base.OnFormClosed(e);
    }

    private void OnLanguageChanged()
    {
        if (IsDisposed)
            return;

        if (InvokeRequired)
        {
            BeginInvoke(ApplyLocalization);
            return;
        }

        ApplyLocalization();
    }

    private void OnLanguageComboChanged()
    {
        if (_languageComboUpdating || _localization == null || cboLanguage.SelectedItem is not SetupLanguageOption option)
            return;

        if (string.Equals(_localization.GetCurrentLanguage(), option.Code, StringComparison.OrdinalIgnoreCase))
            return;

        _localization.SetLanguage(option.Code);
    }

    private void PopulateLanguageCombo()
    {
        _languageComboUpdating = true;
        try
        {
            var current = _localization?.GetCurrentLanguage() ?? "zh-CN";
            cboLanguage.Items.Clear();
            var selectedIndex = 0;

            for (var i = 0; i < LanguageCatalog.SupportedCodes.Length; i++)
            {
                var code = LanguageCatalog.SupportedCodes[i];
                cboLanguage.Items.Add(new SetupLanguageOption(
                    code,
                    LanguageCatalog.GetDisplayName(code, _localization)));

                if (string.Equals(code, current, StringComparison.OrdinalIgnoreCase))
                    selectedIndex = i;
            }

            cboLanguage.DisplayMember = nameof(SetupLanguageOption.DisplayName);
            if (cboLanguage.Items.Count > 0)
                cboLanguage.SelectedIndex = Math.Min(selectedIndex, cboLanguage.Items.Count - 1);

            cboLanguage.Enabled = _localization != null;
        }
        finally
        {
            _languageComboUpdating = false;
        }
    }

    private sealed record SetupLanguageOption(string Code, string DisplayName);

    private static string GetDefaultWelcomeText()
        => "欢迎使用！未来的工作，我们并肩前行。🚀\n请填写服务器地址、邀请码与员工账号密码。";

    private static string BuildWelcomeText(ILocalizationService localization)
    {
        var welcome = localization.GetString("SetupWelcome", "欢迎使用！未来的工作，我们并肩前行。🚀");
        var hint = localization.GetString("FirstLoginHint", "请填写服务器地址、邀请码与员工账号密码，完成设备绑定并登录。");
        return $"{welcome}\n{hint}";
    }

    private DrawingImage LoadAppLogo()
    {
        var iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
        if (File.Exists(iconPath))
        {
            try
            {
                using var icon = new Icon(iconPath, 64, 64);
                return icon.ToBitmap();
            }
            catch (Exception ex)
            {
                _logger?.LogWarning(ex, "Failed to load logo from {Path}", iconPath);
            }
        }

        return CreateDefaultIcon();
    }

    private DrawingImage CreateDefaultIcon()
    {
        var bitmap = new Bitmap(64, 64);
        using var g = Graphics.FromImage(bitmap);
        g.Clear(LoginUiChrome.Accent);
        using var font = new Font("Segoe UI", 28, FontStyle.Bold);
        var appShortName = _localization?.GetString("AppShortName", "EA") ?? "EA";
        g.DrawString(appShortName, font, Brushes.White, new DrawingPointF(12, 12));
        return bitmap;
    }

    private void BtnSave_Click(object? sender, EventArgs e)
    {
        var inviteCode = txtInviteCode.Text.Trim();
        var serverUrl = _lockedServerUrl ?? txtServerUrl.Text.Trim();
        var username = accountPicker.Username;
        var password = txtPassword.Text;

        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            if (string.IsNullOrWhiteSpace(inviteCode))
            {
                ShowWarning("InviteCodeRequired", "请输入邀请码");
                txtInviteCode.Focus();
                return;
            }

            UseSharedWorkstation = false;
            EmployeeInfo = new EmployeeInfo { InviteCode = inviteCode, PreferSharedLogin = false };
            ServerUrl = serverUrl;
            DialogResult = DialogResult.OK;
            Close();
            return;
        }

        if (string.IsNullOrWhiteSpace(serverUrl))
        {
            ShowWarning("ServerUrlRequired", "请输入服务器地址");
            if (_lockedServerUrl == null)
                txtServerUrl.Focus();
            return;
        }

        if (string.IsNullOrWhiteSpace(inviteCode))
        {
            ShowWarning("InviteCodeRequired", "请输入邀请码");
            txtInviteCode.Focus();
            return;
        }

        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password))
        {
            ShowWarning("LoginCredentialsRequired", "请输入账号和密码");
            if (string.IsNullOrWhiteSpace(username))
                accountPicker.FocusUsername();
            else
                txtPassword.Focus();
            return;
        }

        EmployeeInfo = new EmployeeInfo { InviteCode = inviteCode, PreferSharedLogin = false };
        ServerUrl = serverUrl;
        _logger?.LogInformation("First login setup saved for server {ServerUrl}", serverUrl);
        DialogResult = DialogResult.OK;
        Close();
    }

    private void BtnShared_Click(object? sender, EventArgs e)
    {
        var serverUrl = _lockedServerUrl ?? txtServerUrl.Text.Trim();
        if (_mode == EmployeeSetupFormMode.FirstLogin && string.IsNullOrWhiteSpace(serverUrl))
        {
            ShowWarning("ServerUrlRequired", "请输入服务器地址");
            if (_lockedServerUrl == null)
                txtServerUrl.Focus();
            return;
        }

        UseSharedWorkstation = true;
        EmployeeInfo = new EmployeeInfo { InviteCode = "", PreferSharedLogin = true };
        ServerUrl = serverUrl;
        DialogResult = DialogResult.OK;
        Close();
    }

    private void BtnCancel_Click(object? sender, EventArgs e)
    {
        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            DialogResult = DialogResult.Cancel;
            Close();
            return;
        }

        // Clear TopMost before Close so FormClosing's confirm dialog cannot appear behind this window.
        _logger?.LogWarning("Startup configuration cancelled by user");
        TopMost = false;
        DialogResult = DialogResult.Cancel;
        Close();
    }

    private void EmployeeSetupForm_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (_mode == EmployeeSetupFormMode.InviteBinding)
            return;

        // System/process shutdown: never block with a confirm dialog.
        if (e.CloseReason is CloseReason.WindowsShutDown
            or CloseReason.TaskManagerClosing
            or CloseReason.ApplicationExitCall)
            return;

        if (EmployeeInfo != null || DialogResult == DialogResult.OK)
            return;

        if (_exitPromptActive)
            return;

        _exitPromptActive = true;
        var wasTopMost = TopMost;
        try
        {
            // First-login is created with TopMost=true in Program.cs. Ownerless MessageBox
            // would open behind this window and look frozen; always own + clear TopMost.
            TopMost = false;
            BringToFront();
            Activate();
            var title = _localization?.GetString("ConfirmExit", "确认退出") ?? "确认退出";
            var message = _localization?.GetString("ExitConfirm", "确定要退出吗？") ?? "确定要退出吗？";
            var answer = MessageBox.Show(
                this,
                message,
                title,
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);
            if (answer != DialogResult.Yes)
            {
                e.Cancel = true;
                TopMost = wasTopMost;
                BringToFront();
                Activate();
            }
        }
        finally
        {
            _exitPromptActive = false;
        }
    }

    private void ShowWarning(string messageKey, string defaultMessage)
    {
        var title = _localization?.GetString("ValidationError", "验证错误") ?? "验证错误";
        var message = _localization?.GetString(messageKey, defaultMessage) ?? defaultMessage;
        var wasTopMost = TopMost;
        TopMost = false;
        try
        {
            BringToFront();
            Activate();
            MessageBox.Show(this, message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        finally
        {
            TopMost = wasTopMost;
            if (wasTopMost && !IsDisposed && Visible)
            {
                BringToFront();
                Activate();
            }
        }
    }
}

#endregion

#region EmployeeLoginForm

public class EmployeeLoginForm : Form
{
    private readonly string? _serverHint;
    private readonly ILocalizationService? _localization;

    private Label lblHints = null!;
    private Label lblTitle = null!;
    private Label lblLanguage = null!;
    private ComboBox cboLanguage = null!;
    private Label lblUser = null!;
    private RememberedAccountPicker accountPicker = null!;
    private RememberedAccountAvatarStrip accountAvatarStrip = null!;
    private Label lblPwd = null!;
    private TextBox txtPassword = null!;
    private Button btnLogin = null!;
    private Button btnCancel = null!;
    private PictureBox pictLogo = null!;
    private bool _languageComboUpdating;

    public string Username => accountPicker.Username;
    public bool RememberAccount => accountPicker.RememberAccount;
    public string Password => txtPassword.Text;

    public EmployeeLoginForm(string? serverHint = null, ILocalizationService? localization = null)
    {
        _serverHint = serverHint;
        _localization = localization;

        LoginUiChrome.ApplyDialogChrome(this);
        TopMost = true;
        ClientSize = new DrawingSize(LoginUiChrome.DialogWidth, 400);

        // Compact header: brand + short hint; language sits beside close (out of main flow).
        var headerBand = LoginUiChrome.CreateHeaderBand(96);
        LoginUiChrome.EnableDragMove(headerBand, this);

        var closeChip = LoginUiChrome.CreateCloseChip((_, _) =>
        {
            DialogResult = DialogResult.Cancel;
            Close();
        });
        closeChip.Anchor = AnchorStyles.Top | AnchorStyles.Right;

        cboLanguage = new ComboBox
        {
            Width = 120,
            Height = 28,
            DropDownStyle = ComboBoxStyle.DropDownList,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 8.75F),
            Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        LoginUiChrome.StyleComboBox(cboLanguage);
        cboLanguage.Margin = new Padding(0);
        cboLanguage.SelectedIndexChanged += (_, _) => OnLanguageComboChanged();

        void PlaceHeaderActions()
        {
            const int margin = 12;
            closeChip.Location = new DrawingPoint(
                Math.Max(margin, headerBand.ClientSize.Width - closeChip.Width - margin),
                margin);
            cboLanguage.Location = new DrawingPoint(
                Math.Max(margin, closeChip.Left - 8 - cboLanguage.Width),
                margin + (closeChip.Height - cboLanguage.Height) / 2);
        }
        PlaceHeaderActions();
        headerBand.Resize += (_, _) => PlaceHeaderActions();

        pictLogo = new PictureBox
        {
            Size = new DrawingSize(40, 40),
            Location = new DrawingPoint(LoginUiChrome.SidePadding, 18),
            BackColor = DrawingColor.Transparent,
            SizeMode = PictureBoxSizeMode.Zoom,
            Image = LoadAppLogo()
        };

        var titleStack = new Panel
        {
            Location = new DrawingPoint(LoginUiChrome.SidePadding + 52, 14),
            Size = new DrawingSize(LoginUiChrome.ContentWidth - 200, 68),
            BackColor = DrawingColor.Transparent
        };

        lblTitle = LoginUiChrome.CreateTitleLabel();
        lblHints = LoginUiChrome.CreateHintLabel(32);
        lblHints.Font = new Font("Segoe UI", 8.75F);

        // Keep label instance for localization API compatibility; language UI is header combo only.
        lblLanguage = LoginUiChrome.CreateFieldLabel();
        lblLanguage.Visible = false;
        lblLanguage.Height = 0;

        titleStack.Controls.Add(lblHints);
        titleStack.Controls.Add(lblTitle);
        headerBand.Controls.Add(pictLogo);
        headerBand.Controls.Add(titleStack);
        headerBand.Controls.Add(cboLanguage);
        headerBand.Controls.Add(closeChip);

        var footer = new Panel
        {
            Dock = DockStyle.Bottom,
            Height = 78,
            BackColor = LoginUiChrome.Bg,
            Padding = new Padding(LoginUiChrome.SidePadding, 8, LoginUiChrome.SidePadding, 16)
        };

        var body = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = LoginUiChrome.Bg,
            Padding = new Padding(LoginUiChrome.SidePadding, 10, LoginUiChrome.SidePadding, 4)
        };

        var fields = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = DrawingColor.Transparent,
            AutoScroll = false,
            Padding = new Padding(0)
        };

        accountAvatarStrip = new RememberedAccountAvatarStrip
        {
            Margin = new Padding(0, 0, 0, 8)
        };
        LoginUiChrome.BindContentWidth(accountAvatarStrip);

        lblUser = LoginUiChrome.CreateFieldLabel();
        lblUser.Margin = new Padding(0, 2, 0, 2);
        accountPicker = new RememberedAccountPicker
        {
            Margin = new Padding(0, 0, 0, 6)
        };
        LoginUiChrome.BindContentWidth(accountPicker);
        accountPicker.ApplyChrome();
        accountPicker.SetServerKey(serverHint);
        accountAvatarStrip.BindPicker(accountPicker);

        lblPwd = LoginUiChrome.CreateFieldLabel();
        lblPwd.Margin = new Padding(0, 2, 0, 2);
        txtPassword = new TextBox { UseSystemPasswordChar = true };
        var passwordHost = LoginUiChrome.WrapPasswordBox(txtPassword, (key, fallback) =>
            _localization?.GetString(key, fallback) ?? fallback);
        passwordHost.Margin = new Padding(0, 0, 0, 0);

        accountPicker.AccountQuickSelected += (_, _) =>
        {
            txtPassword.Focus();
            txtPassword.SelectAll();
        };
        accountPicker.UsernameChanged += (_, _) =>
            accountAvatarStrip.SyncSelectedUsername(accountPicker.Username);

        void Relayout() => PackLoginFormHeight(headerBand, body, fields, footer);
        accountPicker.LayoutChanged += (_, _) => Relayout();
        accountAvatarStrip.LayoutChanged += (_, _) => Relayout();

        // Main path: avatars → account → password (language already in header).
        fields.Controls.AddRange(new Control[]
        {
            accountAvatarStrip,
            lblUser, accountPicker,
            lblPwd, passwordHost
        });
        body.Controls.Add(fields);

        btnLogin = LoginUiChrome.CreatePrimaryButton("登录");
        btnLogin.Width = 260;
        btnLogin.Height = 42;
        btnLogin.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrEmpty(Password))
            {
                ShowOwnedMessage(
                    L("LoginCredentialsRequired", "请输入账号和密码"),
                    L("Prompt", "提示"),
                    MessageBoxIcon.Warning);
                return;
            }
            DialogResult = DialogResult.OK;
            Close();
        };

        btnCancel = LoginUiChrome.CreateSecondaryButton("取消");
        btnCancel.Width = 96;
        btnCancel.Height = 42;
        btnCancel.Margin = new Padding(12, 0, 0, 0);
        btnCancel.DialogResult = DialogResult.Cancel;

        footer.Controls.Add(LoginUiChrome.CreateCenteredButtonHost(btnLogin, btnCancel));

        Controls.Add(body);
        Controls.Add(footer);
        Controls.Add(headerBand);

        AcceptButton = btnLogin;
        CancelButton = btnCancel;

        Shown += (_, _) =>
        {
            accountPicker.RefreshAccounts();
            accountAvatarStrip.RefreshFromStore();
            PackLoginFormHeight(headerBand, body, fields, footer);
            Activate();
            BringToFront();
            if (accountAvatarStrip.Visible)
            {
                // Prefer password when a remembered account is already selected.
                if (!string.IsNullOrWhiteSpace(accountPicker.Username))
                {
                    txtPassword.Focus();
                    txtPassword.SelectAll();
                }
                else
                {
                    accountPicker.FocusUsername();
                }
            }
            else if (!string.IsNullOrWhiteSpace(accountPicker.Username))
            {
                txtPassword.Focus();
                txtPassword.SelectAll();
            }
            else
            {
                accountPicker.FocusUsername();
            }
        };

        if (_localization != null)
            _localization.LanguageChanged += OnLanguageChanged;

        ApplyLocalization();
        PackLoginFormHeight(headerBand, body, fields, footer);
    }

    /// <summary>Shrink dialog to content so password→buttons has no large empty band.</summary>
    private void PackLoginFormHeight(Control headerBand, Control body, FlowLayoutPanel fields, Control footer)
    {
        fields.PerformLayout();
        var fieldsHeight = 0;
        foreach (Control child in fields.Controls)
        {
            if (!child.Visible || child.Height <= 0)
                continue;
            fieldsHeight += child.Height + child.Margin.Top + child.Margin.Bottom;
        }

        var packed = headerBand.Height
            + body.Padding.Top + body.Padding.Bottom
            + fieldsHeight
            + footer.Height
            + 8;
        packed = Math.Max(360, Math.Min(720, packed));
        if (ClientSize.Height != packed)
            ClientSize = new DrawingSize(LoginUiChrome.DialogWidth, packed);
    }

    private DrawingImage LoadAppLogo()
    {
        var iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
        if (File.Exists(iconPath))
        {
            try
            {
                using var icon = new Icon(iconPath, 64, 64);
                return icon.ToBitmap();
            }
            catch
            {
                // fall through
            }
        }

        var bitmap = new Bitmap(64, 64);
        using var g = Graphics.FromImage(bitmap);
        g.Clear(LoginUiChrome.Accent);
        using var font = new Font("Segoe UI", 28, FontStyle.Bold);
        g.DrawString("EA", font, Brushes.White, new DrawingPointF(12, 12));
        return bitmap;
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        if (_localization != null)
            _localization.LanguageChanged -= OnLanguageChanged;
        base.OnFormClosed(e);
    }

    private void OnLanguageChanged()
    {
        if (IsDisposed)
            return;

        if (InvokeRequired)
        {
            BeginInvoke(ApplyLocalization);
            return;
        }

        ApplyLocalization();
    }

    private void OnLanguageComboChanged()
    {
        if (_languageComboUpdating || _localization == null || cboLanguage.SelectedItem is not LanguageOption option)
            return;

        if (string.Equals(_localization.GetCurrentLanguage(), option.Code, StringComparison.OrdinalIgnoreCase))
            return;

        _localization.SetLanguage(option.Code);
    }

    private void ApplyLocalization()
    {
        Text = L("EmployeeLoginTitle", "员工登录");
        lblTitle.Text = L("EmployeeLoginTitle", "员工登录");
        lblHints.Text = BuildHintText();
        lblLanguage.Text = L("EmployeeLoginLanguageLabel", "界面语言");
        lblUser.Text = L("LoginUsernameLabel", "账号");
        lblPwd.Text = L("LoginPasswordLabel", "密码");
        btnLogin.Text = L("FirstLoginButton", "登录");
        btnCancel.Text = L("Cancel", "取消");
        accountPicker.ApplyLocalization(_localization);
        accountPicker.RefreshAccounts();
        accountAvatarStrip.ApplyLocalization(_localization);
        accountAvatarStrip.RefreshFromStore();
        PopulateLanguageCombo();
    }

    private string BuildHintText()
    {
        // One short supporting line only — keep the header light.
        if (!string.IsNullOrWhiteSpace(_serverHint))
        {
            return string.Format(
                L("EmployeeLoginServerHint", "服务器：{0}"),
                _serverHint.Trim());
        }

        return L("EmployeeLoginHint", "请使用后台子账号登录（同一电脑可多人轮流使用）");
    }

    private void PopulateLanguageCombo()
    {
        if (cboLanguage == null)
            return;

        _languageComboUpdating = true;
        try
        {
            var current = _localization?.GetCurrentLanguage() ?? "zh-CN";
            cboLanguage.Items.Clear();
            var selectedIndex = 0;

            for (var i = 0; i < LanguageCatalog.SupportedCodes.Length; i++)
            {
                var code = LanguageCatalog.SupportedCodes[i];
                cboLanguage.Items.Add(new LanguageOption(
                    code,
                    LanguageCatalog.GetDisplayName(code, _localization)));

                if (string.Equals(code, current, StringComparison.OrdinalIgnoreCase))
                    selectedIndex = i;
            }

            cboLanguage.DisplayMember = nameof(LanguageOption.DisplayName);
            if (cboLanguage.Items.Count > 0)
                cboLanguage.SelectedIndex = Math.Min(selectedIndex, cboLanguage.Items.Count - 1);

            cboLanguage.Enabled = _localization != null;
        }
        finally
        {
            _languageComboUpdating = false;
        }
    }

    private string L(string key, string fallback)
        => _localization?.GetString(key, fallback) ?? fallback;

    private void ShowOwnedMessage(string message, string title, MessageBoxIcon icon)
    {
        var wasTopMost = TopMost;
        TopMost = false;
        try
        {
            MessageBox.Show(this, message, title, MessageBoxButtons.OK, icon);
        }
        finally
        {
            TopMost = wasTopMost;
        }
    }

    private sealed record LanguageOption(string Code, string DisplayName);
}

#endregion

#region StatusForm

public sealed class StatusFormQuickActions
{
    public Func<Task>? OnBindInviteAsync { get; init; }
    public Action? OnOpenLog { get; init; }
    public Action? OnToggleAutoStart { get; init; }
    public Func<bool>? IsAutoStartEnabled { get; init; }
    public Func<AutoStartDiagnosticReport>? GetAutoStartDiagnostic { get; init; }
    public Action? ShowAutoStartDiagnostic { get; init; }
}

public class StatusForm : Form
{
    private readonly Func<string> _getDeviceId;
    private readonly Func<string> _getServerUrl;
    private readonly Func<bool> _isConnected;
    private readonly ILocalizationService? _localization;
    private readonly StatusFormQuickActions? _quickActions;

    private GroupBox groupDevice = null!;
    private GroupBox groupConnection = null!;
    private GroupBox groupServices = null!;
    private GroupBox? groupQuickActions;
    private Label lblDeviceId = null!;
    private Label lblDeviceIdValue = null!;
    private Label lblAgentVersion = null!;
    private Label lblAgentVersionValue = null!;
    private Label lblServerUrl = null!;
    private Label lblServerUrlValue = null!;
    private Label lblConnectionStatus = null!;
    private Label lblConnectionStatusValue = null!;
    private Label lblRecording = null!;
    private Label lblRecordingValue = null!;
    private Button btnRefresh = null!;
    private Button btnCopyDeviceId = null!;
    private Button? btnBindInvite;
    private Button? btnOpenLog;
    private Button? btnAutoStart;
    private ToolTip? _toolTip;

    public StatusForm(
        Func<string> getDeviceId,
        Func<string> getServerUrl,
        Func<bool> isConnected,
        ILocalizationService? localization = null,
        StatusFormQuickActions? quickActions = null)
    {
        _getDeviceId = getDeviceId;
        _getServerUrl = getServerUrl;
        _isConnected = isConnected;
        _localization = localization;
        _quickActions = quickActions;

        InitializeComponent();
        _toolTip = new ToolTip { AutoPopDelay = 15000, InitialDelay = 400, ReshowDelay = 200 };
        ApplyLocalization();
        RefreshStatus();
    }

    private void InitializeComponent()
    {
        Text = "Agent Status";
        Size = new DrawingSize(480, _quickActions != null ? 460 : 380);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;

        groupDevice = new GroupBox { Location = new DrawingPoint(20, 15), Size = new DrawingSize(420, 90) };
        lblDeviceId = new Label { Location = new DrawingPoint(15, 28), Size = new DrawingSize(90, 23), Text = "Device ID:" };
        lblDeviceIdValue = new Label { Location = new DrawingPoint(110, 28), Size = new DrawingSize(290, 23), AutoEllipsis = true };
        lblAgentVersion = new Label { Location = new DrawingPoint(15, 55), Size = new DrawingSize(90, 23), Text = "Agent Version:" };
        lblAgentVersionValue = new Label { Location = new DrawingPoint(110, 55), Size = new DrawingSize(290, 23), Text = AppVersion.Current };
        groupDevice.Controls.AddRange(new Control[] { lblDeviceId, lblDeviceIdValue, lblAgentVersion, lblAgentVersionValue });

        groupConnection = new GroupBox { Location = new DrawingPoint(20, 115), Size = new DrawingSize(420, 90) };
        lblServerUrl = new Label { Location = new DrawingPoint(15, 28), Size = new DrawingSize(90, 23), Text = "Server URL:" };
        lblServerUrlValue = new Label { Location = new DrawingPoint(110, 28), Size = new DrawingSize(290, 23), AutoEllipsis = true };
        lblConnectionStatus = new Label { Location = new DrawingPoint(15, 55), Size = new DrawingSize(90, 23), Text = "Status:" };
        lblConnectionStatusValue = new Label { Location = new DrawingPoint(110, 55), Size = new DrawingSize(290, 23) };
        groupConnection.Controls.AddRange(new Control[] { lblServerUrl, lblServerUrlValue, lblConnectionStatus, lblConnectionStatusValue });

        groupServices = new GroupBox { Location = new DrawingPoint(20, 215), Size = new DrawingSize(420, 60) };
        lblRecording = new Label { Location = new DrawingPoint(15, 28), Size = new DrawingSize(90, 23), Text = "Recording:" };
        lblRecordingValue = new Label { Location = new DrawingPoint(110, 28), Size = new DrawingSize(290, 23), Text = "-" };
        groupServices.Controls.AddRange(new Control[] { lblRecording, lblRecordingValue });

        var actionRowY = 295;
        if (_quickActions != null)
        {
            groupQuickActions = new GroupBox { Location = new DrawingPoint(20, 285), Size = new DrawingSize(420, 72), Text = "快捷操作" };

            if (_quickActions.OnBindInviteAsync != null)
            {
                btnBindInvite = new Button { Location = new DrawingPoint(15, 28), Size = new DrawingSize(120, 32), Text = "补绑定邀请码" };
                btnBindInvite.Click += async (_, _) => await _quickActions.OnBindInviteAsync();
                groupQuickActions.Controls.Add(btnBindInvite);
            }

            if (_quickActions.OnOpenLog != null)
            {
                btnOpenLog = new Button
                {
                    Location = new DrawingPoint(btnBindInvite != null ? 150 : 15, 28),
                    Size = new DrawingSize(100, 32),
                    Text = "打开日志"
                };
                btnOpenLog.Click += (_, _) => _quickActions.OnOpenLog();
                groupQuickActions.Controls.Add(btnOpenLog);
            }

            if (_quickActions.OnToggleAutoStart != null)
            {
                btnAutoStart = new Button
                {
                    Location = new DrawingPoint(btnOpenLog != null ? 260 : (btnBindInvite != null ? 150 : 15), 28),
                    Size = new DrawingSize(140, 32),
                    Text = GetAutoStartButtonText()
                };
                btnAutoStart.MouseUp += (_, e) =>
                {
                    if (e.Button == MouseButtons.Right)
                    {
                        _quickActions.ShowAutoStartDiagnostic?.Invoke();
                        return;
                    }

                    if (e.Button == MouseButtons.Left)
                    {
                        _quickActions.OnToggleAutoStart();
                        RefreshAutoStartState();
                    }
                };
                groupQuickActions.Controls.Add(btnAutoStart);
            }

            actionRowY = 375;
        }

        btnRefresh = new Button { Location = new DrawingPoint(20, actionRowY), Size = new DrawingSize(100, 32), Text = "Refresh" };
        btnRefresh.Click += (_, _) => RefreshStatus();
        btnCopyDeviceId = new Button { Location = new DrawingPoint(130, actionRowY), Size = new DrawingSize(100, 32), Text = "Copy" };
        btnCopyDeviceId.Click += (_, _) => CopyDeviceId();

        var controls = new List<Control> { groupDevice, groupConnection, groupServices, btnRefresh, btnCopyDeviceId };
        if (groupQuickActions != null)
            controls.Add(groupQuickActions);
        Controls.AddRange(controls.ToArray());
    }

    public void RefreshAutoStartState()
    {
        if (btnAutoStart == null)
            return;

        btnAutoStart.Text = GetAutoStartButtonText();

        if (_toolTip == null || _quickActions?.GetAutoStartDiagnostic == null)
            return;

        try
        {
            var report = _quickActions.GetAutoStartDiagnostic();
            _toolTip.SetToolTip(btnAutoStart, report.FormatSummary(_localization));
        }
        catch
        {
            // ignore tooltip failures
        }
    }

    private string GetAutoStartButtonText()
    {
        var label = _localization?.GetString("AutoStart", "开机自启动") ?? "开机自启动";
        if (_quickActions?.IsAutoStartEnabled == null)
            return label;

        var enabled = _quickActions.IsAutoStartEnabled();
        var state = enabled
            ? (_localization?.GetString("AutoStartOn", "开") ?? "开")
            : (_localization?.GetString("AutoStartOff", "关") ?? "关");
        return $"{label}: {state}";
    }

    public void RefreshLocalization()
    {
        ApplyLocalization();
        RefreshStatus();
    }

    private void ApplyLocalization()
    {
        if (_localization == null) return;

        Text = _localization.GetString("AgentStatus", "Agent Status");
        groupDevice.Text = _localization.GetString("DeviceInformation", "Device Information");
        groupConnection.Text = _localization.GetString("Connection", "Connection");
        groupServices.Text = _localization.GetString("Services", "Services");
        btnRefresh.Text = _localization.GetString("Refresh", "Refresh");
        btnCopyDeviceId.Text = _localization.GetString("Copy", "Copy");
        lblDeviceId.Text = _localization.GetString("DeviceId", "Device ID:");
        lblAgentVersion.Text = _localization.GetString("AgentVersion", "Agent Version:");
        lblServerUrl.Text = _localization.GetString("ServerURL", "Server URL:");
        lblConnectionStatus.Text = _localization.GetString("Status", "Status:");
        lblRecording.Text = _localization.GetString("Recording", "Recording:");
        if (groupQuickActions != null)
            groupQuickActions.Text = _localization.GetString("QuickActions", "快捷操作");
        if (btnBindInvite != null)
            btnBindInvite.Text = _localization.GetString("BindInviteCodeAdvanced", "补绑定邀请码");
        if (btnOpenLog != null)
            btnOpenLog.Text = _localization.GetString("OpenLog", "打开日志");
        RefreshAutoStartState();
    }

    private void RefreshStatus()
    {
        var deviceId = _getDeviceId();
        var notRegistered = _localization?.GetString("NotRegistered", "Not registered") ?? "Not registered";
        lblDeviceIdValue.Text = string.IsNullOrWhiteSpace(deviceId) ? notRegistered : deviceId;
        lblServerUrlValue.Text = _getServerUrl();
        var connectedText = _isConnected()
            ? (_localization?.GetString("Connected", "Connected") ?? "Connected")
            : (_localization?.GetString("Disconnected", "Disconnected") ?? "Disconnected");
        lblConnectionStatusValue.Text = connectedText;
        RefreshAutoStartState();
    }

    private void CopyDeviceId()
    {
        var deviceId = _getDeviceId();
        if (string.IsNullOrWhiteSpace(deviceId))
        {
            var title = _localization?.GetString("Error", "Error") ?? "Error";
            MessageBox.Show(_localization?.GetString("DeviceIdNotRegistered", "Device not yet registered") ?? "Device not yet registered", title);
            return;
        }

        Clipboard.SetText(deviceId);
        MessageBox.Show(
            _localization?.GetString("DeviceIdCopied", "Device ID copied to clipboard") ?? "Device ID copied to clipboard",
            _localization?.GetString("Copied", "Copied") ?? "Copied");
    }
}

#endregion

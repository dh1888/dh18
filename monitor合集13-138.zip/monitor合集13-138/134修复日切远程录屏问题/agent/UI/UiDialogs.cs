// UI/UiDialogs.cs — MessageBox helpers that stay visible above TopMost login/setup windows
using System.Windows.Forms;

namespace EnterpriseAgent.Agent.UI;

/// <summary>
/// WinForms MessageBox with TopMost login/setup dialogs present often opens behind those
/// windows (looks frozen). Temporarily demote TopMost and own the dialog when possible.
/// </summary>
internal static class UiDialogs
{
    public static DialogResult Show(
        string text,
        string caption,
        MessageBoxButtons buttons = MessageBoxButtons.OK,
        MessageBoxIcon icon = MessageBoxIcon.None,
        MessageBoxDefaultButton defaultButton = MessageBoxDefaultButton.Button1)
    {
        var demoted = new List<Form>();
        Form? owner = null;

        try
        {
            foreach (Form form in Application.OpenForms.Cast<Form>().ToArray())
            {
                if (form.IsDisposed || !form.Visible)
                    continue;

                if (form.TopMost)
                {
                    form.TopMost = false;
                    demoted.Add(form);
                }

                // Prefer the active modal (login / setup) as MessageBox owner.
                if (form.Modal)
                    owner = form;
            }

            owner ??= Form.ActiveForm;
            if (owner != null && (owner.IsDisposed || !owner.Visible))
                owner = null;

            if (owner != null)
            {
                owner.BringToFront();
                owner.Activate();
                return MessageBox.Show(owner, text, caption, buttons, icon, defaultButton);
            }

            return MessageBox.Show(text, caption, buttons, icon, defaultButton);
        }
        finally
        {
            foreach (var form in demoted)
            {
                if (form.IsDisposed)
                    continue;
                form.TopMost = true;
                if (form.Visible)
                {
                    form.BringToFront();
                }
            }
        }
    }

    /// <summary>
    /// Run a modal dialog while TopMost windows are temporarily cleared so it cannot appear behind them.
    /// </summary>
    public static DialogResult ShowDialogDemoted(Form dialog, Form? preferredOwner = null)
    {
        ArgumentNullException.ThrowIfNull(dialog);

        var demoted = new List<Form>();
        Form? owner = preferredOwner;

        try
        {
            foreach (Form form in Application.OpenForms.Cast<Form>().ToArray())
            {
                if (ReferenceEquals(form, dialog) || form.IsDisposed || !form.Visible)
                    continue;

                if (form.TopMost)
                {
                    form.TopMost = false;
                    demoted.Add(form);
                }

                if (owner == null && form.Modal)
                    owner = form;
            }

            owner ??= Form.ActiveForm;
            if (owner != null && (owner.IsDisposed || !owner.Visible || ReferenceEquals(owner, dialog)))
                owner = null;

            return owner != null ? dialog.ShowDialog(owner) : dialog.ShowDialog();
        }
        finally
        {
            foreach (var form in demoted)
            {
                if (form.IsDisposed)
                    continue;
                form.TopMost = true;
                if (form.Visible)
                    form.BringToFront();
            }
        }
    }
}

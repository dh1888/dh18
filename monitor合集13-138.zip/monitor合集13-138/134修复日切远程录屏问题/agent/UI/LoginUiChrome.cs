// UI/LoginUiChrome.cs — shared modern chrome for first-login / employee-login dialogs
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace EnterpriseAgent.Agent.UI;

/// <summary>
/// Visual helpers only — login dialogs keep their own validation and DialogResult contracts.
/// Aligns with PunchPanelPalette.Light / ModernTrayMenuForm tones.
/// </summary>
internal static class LoginUiChrome
{
    public static readonly Color Bg = Color.FromArgb(246, 248, 252);
    public static readonly Color CardBg = Color.FromArgb(255, 255, 255);
    public static readonly Color HeaderBg = Color.FromArgb(236, 242, 250);
    public static readonly Color Border = Color.FromArgb(206, 214, 226);
    public static readonly Color TextPrimary = Color.FromArgb(28, 32, 40);
    public static readonly Color TextMuted = Color.FromArgb(104, 112, 126);
    public static readonly Color Accent = Color.FromArgb(37, 128, 228);
    public static readonly Color AccentSoft = Color.FromArgb(24, 108, 200);
    public static readonly Color NeutralButton = Color.FromArgb(224, 230, 240);
    public static readonly Color NeutralButtonText = Color.FromArgb(52, 58, 68);
    public static readonly Color FieldBg = Color.FromArgb(255, 255, 255);
    public static readonly Color FieldBorder = Color.FromArgb(190, 200, 214);
    public static readonly Color FieldReadonlyBg = Color.FromArgb(236, 240, 246);

    public const int CornerRadius = 14;
    public const int DialogWidth = 500;
    public const int SidePadding = 36;
    public const int ContentWidth = DialogWidth - SidePadding * 2; // 428 — fits inside rounded client
    public const int FieldHeight = 34;

    public static void ApplyDialogChrome(Form form)
    {
        form.FormBorderStyle = FormBorderStyle.None;
        form.MaximizeBox = false;
        form.MinimizeBox = false;
        form.StartPosition = FormStartPosition.CenterScreen;
        form.BackColor = Bg;
        form.Font = new Font("Segoe UI", 9.75F);
        form.Padding = new Padding(0);
        form.ShowInTaskbar = true;
        form.ClientSize = new Size(DialogWidth, form.ClientSize.Height);

        void ApplyRegion()
        {
            if (!form.IsHandleCreated || form.ClientSize.Width <= 0 || form.ClientSize.Height <= 0)
                return;
            using var path = CreateRoundedPath(new Rectangle(0, 0, form.ClientSize.Width, form.ClientSize.Height), CornerRadius);
            form.Region?.Dispose();
            form.Region = new Region(path);
        }

        form.HandleCreated += (_, _) => ApplyRegion();
        form.Resize += (_, _) => ApplyRegion();
        form.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, form.ClientSize.Width - 1, form.ClientSize.Height - 1);
            using var path = CreateRoundedPath(rect, CornerRadius);
            using var border = new Pen(Border);
            g.DrawPath(border, path);
        };
    }

    public static void BindContentWidth(Control field)
    {
        field.Width = ContentWidth;
        if (field is ComboBox combo)
            combo.DropDownWidth = Math.Max(ContentWidth, combo.DropDownWidth);
    }

    public static Panel CreateCenteredButtonHost(params Control[] buttons)
    {
        var host = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 3,
            RowCount = 1,
            BackColor = Color.Transparent,
            Padding = new Padding(0)
        };
        host.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        host.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        host.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        host.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

        var row = new FlowLayoutPanel
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0),
            Anchor = AnchorStyles.None
        };
        foreach (var button in buttons)
            row.Controls.Add(button);

        host.Controls.Add(row, 1, 0);
        return host;
    }

    public static Panel CreateHeaderBand(int height = 118)
    {
        var band = new Panel
        {
            Dock = DockStyle.Top,
            Height = height,
            BackColor = HeaderBg,
            Padding = new Padding(SidePadding, 12, SidePadding, 8)
        };
        band.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = band.ClientRectangle;
            using var brush = new LinearGradientBrush(
                rect,
                Color.FromArgb(232, 240, 252),
                Color.FromArgb(246, 248, 252),
                90f);
            g.FillRectangle(brush, rect);
            using var accent = new LinearGradientBrush(
                new Rectangle(0, 0, 5, rect.Height),
                Accent,
                AccentSoft,
                90f);
            g.FillRectangle(accent, 0, 0, 5, rect.Height);
            using var line = new Pen(Color.FromArgb(180, Border));
            g.DrawLine(line, 0, rect.Height - 1, rect.Width, rect.Height - 1);
        };
        return band;
    }

    public static Label CreateTitleLabel()
        => new()
        {
            AutoSize = false,
            Dock = DockStyle.Top,
            // 16pt bold CJK glyphs need ~34–36px; 28–30 clips descenders/bottom strokes.
            Height = 36,
            Font = new Font("Microsoft YaHei UI", 15F, FontStyle.Bold),
            ForeColor = TextPrimary,
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0, 2, 0, 2),
            UseCompatibleTextRendering = true
        };

    public static Label CreateHintLabel(int height = 52)
        => new()
        {
            AutoSize = false,
            Dock = DockStyle.Top,
            Height = height,
            Font = new Font("Segoe UI", 9F),
            ForeColor = TextMuted,
            TextAlign = ContentAlignment.TopLeft,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 4, 0, 0)
        };

    public static Label CreateFieldLabel()
        => new()
        {
            AutoSize = false,
            Dock = DockStyle.Top,
            Height = 20,
            Font = new Font("Segoe UI Semibold", 8.75F, FontStyle.Bold),
            ForeColor = TextMuted,
            TextAlign = ContentAlignment.BottomLeft,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 6, 0, 2)
        };

    public static void StyleTextBox(TextBox box, bool readOnly = false)
    {
        box.BorderStyle = BorderStyle.None;
        box.Font = new Font("Segoe UI", 10F);
        box.BackColor = readOnly ? FieldReadonlyBg : FieldBg;
        box.ForeColor = TextPrimary;
        box.ReadOnly = readOnly;
        box.Margin = new Padding(0);
        if (readOnly)
            box.TabStop = false;
    }

    /// <summary>
    /// WinForms single-line TextBox ignores Height and draws a thin FixedSingle border.
    /// Host panel gives a stable combo-like field so password/server inputs are fully visible.
    /// </summary>
    public static Panel WrapTextBox(TextBox box, bool readOnly = false)
    {
        StyleTextBox(box, readOnly);
        var host = new Panel
        {
            Width = ContentWidth,
            Height = FieldHeight,
            BackColor = readOnly ? FieldReadonlyBg : FieldBg,
            Margin = new Padding(0, 0, 0, 6),
            Padding = new Padding(10, 7, 10, 7)
        };
        PaintInputHost(host);
        box.Dock = DockStyle.Fill;
        host.Controls.Add(box);
        host.Click += (_, _) => box.Focus();
        return host;
    }

    /// <summary>Password field with show/hide toggle. Does not change login validation contracts.</summary>
    public static Panel WrapPasswordBox(TextBox box, Func<string, string, string>? localize = null)
    {
        string L(string key, string fallback)
            => localize?.Invoke(key, fallback) ?? fallback;

        box.UseSystemPasswordChar = true;
        StyleTextBox(box);

        var host = new Panel
        {
            Width = ContentWidth,
            Height = FieldHeight,
            BackColor = FieldBg,
            Margin = new Padding(0, 0, 0, 6),
            Padding = new Padding(10, 4, 4, 4)
        };
        PaintInputHost(host);

        var toggle = new Button
        {
            Text = L("ShowPassword", "显示"),
            Dock = DockStyle.Right,
            Width = 52,
            FlatStyle = FlatStyle.Flat,
            BackColor = FieldBg,
            ForeColor = Accent,
            Font = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold),
            Cursor = Cursors.Hand,
            TabStop = false,
            Margin = new Padding(0)
        };
        toggle.FlatAppearance.BorderSize = 0;
        toggle.FlatAppearance.MouseOverBackColor = Color.FromArgb(232, 240, 252);
        toggle.FlatAppearance.MouseDownBackColor = Color.FromArgb(220, 230, 244);

        var revealed = false;
        toggle.Click += (_, _) =>
        {
            revealed = !revealed;
            box.UseSystemPasswordChar = !revealed;
            toggle.Text = revealed
                ? L("HidePassword", "隐藏")
                : L("ShowPassword", "显示");
            box.Focus();
            box.SelectionStart = box.TextLength;
        };

        box.Dock = DockStyle.Fill;
        // Dock Right first (added last), then Fill.
        host.Controls.Add(box);
        host.Controls.Add(toggle);
        host.Click += (_, _) => box.Focus();
        return host;
    }

    private static void PaintInputHost(Panel host)
    {
        host.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, host.Width - 1, host.Height - 1);
            using var fill = new SolidBrush(host.BackColor);
            using var path = CreateRoundedPath(rect, 6);
            g.FillPath(fill, path);
            using var pen = new Pen(FieldBorder);
            g.DrawPath(pen, path);
        };
        host.Resize += (_, _) => host.Invalidate();
    }

    public static void StyleComboBox(ComboBox box)
    {
        box.FlatStyle = FlatStyle.Flat;
        box.Font = new Font("Segoe UI", 10F);
        box.BackColor = FieldBg;
        box.ForeColor = TextPrimary;
        box.DropDownStyle = ComboBoxStyle.DropDownList;
        box.Margin = new Padding(0, 0, 0, 6);
    }

    public static Button CreatePrimaryButton(string text)
    {
        var btn = new Button
        {
            Text = text,
            Height = 38,
            FlatStyle = FlatStyle.Flat,
            BackColor = Accent,
            ForeColor = Color.White,
            Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold),
            Cursor = Cursors.Hand,
            Margin = new Padding(0)
        };
        btn.FlatAppearance.BorderSize = 0;
        btn.FlatAppearance.MouseOverBackColor = AccentSoft;
        btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(18, 92, 180);
        return btn;
    }

    public static Button CreateSecondaryButton(string text)
    {
        var btn = new Button
        {
            Text = text,
            Height = 38,
            FlatStyle = FlatStyle.Flat,
            BackColor = NeutralButton,
            ForeColor = NeutralButtonText,
            Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold),
            Cursor = Cursors.Hand,
            Margin = new Padding(0)
        };
        btn.FlatAppearance.BorderSize = 0;
        btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(210, 218, 230);
        btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(196, 204, 218);
        return btn;
    }

    public static Button CreateGhostButton(string text)
    {
        var btn = new Button
        {
            Text = text,
            Height = 34,
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.Transparent,
            ForeColor = Accent,
            Font = new Font("Segoe UI Semibold", 9.25F, FontStyle.Bold),
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 4, 0, 0)
        };
        btn.FlatAppearance.BorderSize = 0;
        btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(232, 240, 252);
        btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(220, 230, 244);
        return btn;
    }

    /// <summary>
    /// Custom-painted close control: WinForms Button "×" text rarely centers and hover
    /// rectangles clip oddly against the rounded dialog region.
    /// </summary>
    public static Panel CreateCloseChip(EventHandler onClick)
    {
        const int size = 28;
        var host = new Panel
        {
            Size = new Size(size, size),
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand,
            TabStop = false
        };

        var hover = false;
        var pressed = false;

        void InvalidateChip() => host.Invalidate();

        host.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;

            var rect = new Rectangle(0, 0, host.Width - 1, host.Height - 1);
            if (hover || pressed)
            {
                var fillColor = pressed
                    ? Color.FromArgb(200, 208, 220)
                    : Color.FromArgb(220, 226, 236);
                using var fill = new SolidBrush(fillColor);
                using var path = CreateRoundedPath(rect, 7);
                g.FillPath(fill, path);
            }

            // Geometric X — true center (glyph "×" sits low in Button text metrics).
            var inset = 8f;
            var x1 = inset;
            var y1 = inset;
            var x2 = host.Width - 1 - inset;
            var y2 = host.Height - 1 - inset;
            using var pen = new Pen(TextMuted, 1.75f)
            {
                StartCap = LineCap.Round,
                EndCap = LineCap.Round
            };
            g.DrawLine(pen, x1, y1, x2, y2);
            g.DrawLine(pen, x2, y1, x1, y2);
        };

        host.MouseEnter += (_, _) =>
        {
            hover = true;
            InvalidateChip();
        };
        host.MouseLeave += (_, _) =>
        {
            hover = false;
            pressed = false;
            InvalidateChip();
        };
        host.MouseDown += (_, e) =>
        {
            if (e.Button != MouseButtons.Left)
                return;
            pressed = true;
            InvalidateChip();
        };
        host.MouseUp += (_, e) =>
        {
            if (e.Button != MouseButtons.Left)
                return;
            var inside = host.ClientRectangle.Contains(e.Location);
            pressed = false;
            InvalidateChip();
            if (inside)
                onClick(host, EventArgs.Empty);
        };

        return host;
    }

    /// <summary>Inset from the rounded top-right corner so hover is not clipped.</summary>
    public static void PlaceCloseChip(Control closeChip, Control headerBand)
    {
        const int margin = 12;
        void Relayout()
        {
            closeChip.Location = new Point(
                Math.Max(margin, headerBand.ClientSize.Width - closeChip.Width - margin),
                margin);
        }
        Relayout();
        headerBand.Resize += (_, _) => Relayout();
    }

    public static void EnableDragMove(Control handle, Form form)
    {
        Point? dragOrigin = null;
        handle.MouseDown += (_, e) =>
        {
            if (e.Button == MouseButtons.Left)
                dragOrigin = e.Location;
        };
        handle.MouseMove += (_, e) =>
        {
            if (dragOrigin is null || e.Button != MouseButtons.Left)
                return;
            form.Location = new Point(
                form.Location.X + e.X - dragOrigin.Value.X,
                form.Location.Y + e.Y - dragOrigin.Value.Y);
        };
        handle.MouseUp += (_, _) => dragOrigin = null;
    }

    public static GraphicsPath CreateRoundedPath(Rectangle bounds, int radius)
    {
        var path = new GraphicsPath();
        var d = radius * 2;
        path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
        path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
        path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }
}

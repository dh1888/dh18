import request from "./request";

export interface CsToolMenuItem {
  id: string;
  name: string;
  url: string;
}

export interface CsToolSettings {
  toolUrl: string;
  scriptUrl: string;
  customMenus?: CsToolMenuItem[];
  updatedAt?: string;
}

export interface ShiftPerson {
  id: string;
  name: string;
}

export interface ShiftStation {
  id: string;
  label: string;
  code: string;
}

export interface ShiftRow {
  id: string;
  label: string;
  kind: "split" | "span";
  showAdd?: boolean;
  cells?: Record<string, ShiftPerson[]>;
  people?: ShiftPerson[];
  old?: ShiftPerson[];
  new?: ShiftPerson[];
  colSpans?: Record<string, number>;
  rowSpans?: Record<string, number>;
  labelRowSpan?: number;
}

export interface ShiftBoard {
  id: string;
  title: string;
  stations?: ShiftStation[];
  oldLabel?: string;
  newLabel?: string;
  oldCode?: string;
  newCode?: string;
  rows: ShiftRow[];
}

export interface ShiftRoster {
  shifts: ShiftBoard[];
  noRotate: ShiftPerson[];
  ruleNote: string;
  updatedAt?: string;
}

const csToolApi = {
  getSettings: () => request.get<CsToolSettings>("/admin/cs-tool/settings"),
  saveSettings: (data: CsToolSettings) =>
    request.put<CsToolSettings>("/admin/cs-tool/settings", data),
  getShiftRoster: () => request.get<ShiftRoster>("/admin/cs-tool/shift-roster"),
  saveShiftRoster: (data: ShiftRoster) =>
    request.put<ShiftRoster>("/admin/cs-tool/shift-roster", data),
};

export default csToolApi;

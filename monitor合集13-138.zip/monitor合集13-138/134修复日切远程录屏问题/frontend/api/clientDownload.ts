import { ElMessage } from "element-plus";
import workforceApi from "./workforce_api";

function apiBaseUrl(): string {
  return ((import.meta.env.VITE_API_BASE_URL as string) || "/api/v1").replace(
    /\/$/,
    "",
  );
}

function triggerNativeDownload(url: string): void {
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
}

export async function downloadClientInstaller(): Promise<void> {
  const metaRes = await workforceApi.getClientDownload();
  const meta = metaRes.data || metaRes;

  if (meta.mode === "external" && meta.downloadUrl) {
    window.open(meta.downloadUrl, "_blank", "noopener");
    ElMessage.success("正在打开客户端下载页面");
    return;
  }

  const token = sessionStorage.getItem("token");
  if (!token) {
    throw new Error("请先登录");
  }

  const downloadUrl = `${apiBaseUrl()}/client-download/file?token=${encodeURIComponent(token)}`;
  triggerNativeDownload(downloadUrl);
  ElMessage.success("客户端下载已开始");
}

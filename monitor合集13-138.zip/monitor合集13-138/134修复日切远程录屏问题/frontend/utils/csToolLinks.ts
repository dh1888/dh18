import { ref } from "vue";
import csToolApi, { type CsToolMenuItem, type CsToolSettings } from "@/api/cs_tool_api";
import { ElMessage } from "element-plus";

const DEFAULT_URLS: CsToolSettings = {
  toolUrl: "https://dh1888.github.io/168/",
  scriptUrl: "https://dh1888.github.io/render/",
  customMenus: [],
};

let cachedUrls: CsToolSettings = { ...DEFAULT_URLS, customMenus: [] };
let loadingPromise: Promise<CsToolSettings> | null = null;

export const csToolCustomMenus = ref<CsToolMenuItem[]>([]);

function syncCustomMenus(menus: CsToolMenuItem[] | undefined) {
  const next = Array.isArray(menus) ? menus : [];
  cachedUrls.customMenus = next;
  csToolCustomMenus.value = next;
}

export function getCsToolUrls() {
  return cachedUrls;
}

export async function preloadCsToolUrls(force = false): Promise<CsToolSettings> {
  if (!force && loadingPromise) return loadingPromise;
  loadingPromise = csToolApi
    .getSettings()
    .then((res) => {
      const data = res.data;
      cachedUrls = {
        toolUrl: data?.toolUrl || DEFAULT_URLS.toolUrl,
        scriptUrl: data?.scriptUrl || DEFAULT_URLS.scriptUrl,
        updatedAt: data?.updatedAt,
        customMenus: data?.customMenus || [],
      };
      syncCustomMenus(cachedUrls.customMenus);
      return cachedUrls;
    })
    .catch(() => cachedUrls)
    .finally(() => {
      loadingPromise = null;
    });
  return loadingPromise;
}

export function openCsToolLink(key: keyof Pick<CsToolSettings, "toolUrl" | "scriptUrl">) {
  const url = cachedUrls[key] || DEFAULT_URLS[key];
  if (!url) {
    ElMessage.warning("请先在地址配置中设置跳转地址");
    return;
  }
  window.open(url, "_blank", "noopener");
}

export function openCsToolCustomMenu(menuId: string) {
  const menu = (cachedUrls.customMenus || []).find((item) => item.id === menuId);
  if (!menu?.url) {
    ElMessage.warning("菜单不存在或尚未配置跳转地址");
    return;
  }
  window.open(menu.url, "_blank", "noopener");
}

export function setCsToolUrls(next: CsToolSettings) {
  cachedUrls = {
    toolUrl: next.toolUrl || DEFAULT_URLS.toolUrl,
    scriptUrl: next.scriptUrl || DEFAULT_URLS.scriptUrl,
    updatedAt: next.updatedAt,
    customMenus: next.customMenus || [],
  };
  syncCustomMenus(cachedUrls.customMenus);
}

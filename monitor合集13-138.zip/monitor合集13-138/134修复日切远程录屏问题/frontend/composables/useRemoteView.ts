import { ref, shallowRef } from "vue";
import {
  Room,
  RoomEvent,
  Track,
  ConnectionState,
  type RemoteTrack,
  type RemoteTrackPublication,
  type RemoteParticipant,
} from "livekit-client";
import { remoteViewApi } from "@api/index";
import type { RemoteViewStartSession, RemoteViewStatus } from "@api/types";
import {
  mediaStreamTrackIds,
  remoteViewLifecycleDiag,
} from "@/utils/remoteViewLifecycleDiag";

export type RemoteViewStartupPhase =
  | "idle"
  | "preparing"
  | "publisher"
  | "player"
  | "active";

const PUBLISHER_POLL_MS = 200;
const PUBLISHER_SETTLE_MS = 120;
const QUALITY_SWITCH_SETTLE_MS = 900;
const QUALITY_SWITCH_COOLDOWN_MS = 12_000;
const VIDEO_ATTACH_TIMEOUT_MS = 2200;
const BACKGROUND_LIVE_SAMPLE_MS = 1200;
const RTP_BYTES_DELTA_MIN = 500;
/** Align with backend REMOTE_VIEW_STARTING_TIMEOUT_SECONDS default (90). */
const REMOTE_VIEW_STARTING_WARMUP_MS = 90_000;
const BACKGROUND_LIVE_RETRIES = 4;
const BACKGROUND_LIVE_RETRY_GAP_MS = 2000;
const WHIP_FIRST_FRAME_BUFFER_MS = 3500;
const MAX_DEAD_FRAME_RECOVERIES = 2;
/** After max recoveries, wait this long then run one more automatic recovery cycle. */
const DEAD_FRAME_EXHAUST_COOLDOWN_MS = 15_000;
/** Extra automatic cycles after first exhaust (then require manual fresh retry). */
const MAX_DEAD_FRAME_AUTO_CYCLES = 1;
/** Refresh LiveKit viewer JWT this long before expiresAt. */
const VIEWER_TOKEN_REFRESH_BEFORE_MS = 90_000;
const VIEWER_TOKEN_REFRESH_MIN_DELAY_MS = 5_000;

const expectedPublisherIdentity = (deviceId: string, sessionId: string) => {
  const short = sessionId.replace(/-/g, "").slice(0, 8);
  return `agent-${deviceId}-${short}`;
};

const isExpectedPublisher = (
  participant: RemoteParticipant,
  deviceId: string,
  sessionId: string,
) => participant.identity === expectedPublisherIdentity(deviceId, sessionId);

export function useRemoteView() {
  const room = shallowRef<Room | null>(null);
  const connectionState = ref<ConnectionState>(ConnectionState.Disconnected);
  const sessionInfo = ref<RemoteViewStartSession | null>(null);
  const sessionStatus = ref("");
  const startupPhase = ref<RemoteViewStartupPhase>("idle");
  /** True when dead-frame recovery exhausted; UI can offer fresh retry. */
  const playbackDegraded = ref(false);
  const stats = ref({
    fps: 0,
    bitrateKbps: 0,
    encoder: "",
  });

  let reconnectAttempts = 0;
  let reconnectTimer: number | null = null;
  let viewGeneration = 0;
  let activeVideoContainer: HTMLElement | null = null;
  // normal: room auto-attach + waitForVideoTrack both allowed
  // switchPending: block room auto-attach; waitForVideoTrack is the only attach path
  type AttachMode = "normal" | "switchPending";
  let attachMode: AttachMode = "normal";
  let qualitySwitchCooldownUntil = 0;
  let livePlaybackWatchdogId = 0;
  let deadFrameExhaustTimer: number | null = null;
  let deadFrameAutoCycles = 0;
  // Invariant: at most one connect / disconnect / republish runs at a time.
  // connectionChain is the only mutex. Vue UI (start/stop/quality) and
  // background paths (resumeView, recoverFromDeadFrame) all enqueue here.
  // Nested withConnectionLock deadlocks — startView / stopView / setQuality
  // are unlocked internals and must be invoked by a holder of this lock.
  let connectionChain = Promise.resolve();
  let activeQuality: "weak" | "auto" | "strong" = "strong";
  let lastTrackSid = "";
  let deadFrameRecoveryAttempts = 0;
  let viewerTokenRefreshTimer: number | null = null;
  const MAX_RECONNECT = 5;

  const withConnectionLock = async <T>(operation: () => Promise<T>): Promise<T> => {
    const op = connectionChain.then(operation);
    connectionChain = op.then(
      () => undefined,
      () => undefined,
    );
    return op;
  };

  const clearVideoContainer = (container?: HTMLElement | null) => {
    const target = container ?? activeVideoContainer;
    target?.replaceChildren();
  };

  const attachVideo = (
    container: HTMLElement,
    track: RemoteTrack,
    context?: { trackSid?: string; source?: string },
  ) => {
    const prevVideo = container.querySelector("video") as HTMLVideoElement | null;
    const prevSrcObject = prevVideo?.srcObject ?? null;
    const prevTrackSid = lastTrackSid;
    const resolvedTrackSid = context?.trackSid ?? track.sid ?? "-";

    try {
      track.setPlayoutDelay(0);
    } catch {
      // older SDK / non-video tracks
    }
    try {
      track.start();
    } catch {
      // already started
    }
    const element = track.attach() as HTMLVideoElement;
    element.className = "remote-video-player";
    element.playsInline = true;
    element.muted = true;
    element.autoplay = true;
    try {
      const mediaTrack = track.mediaStreamTrack;
      if (mediaTrack && mediaTrack.enabled === false) {
        mediaTrack.enabled = true;
      }
    } catch {
      // ignore
    }
    container.replaceChildren(element);

    remoteViewLifecycleDiag("srcObject-switch", {
      source: context?.source ?? "attachVideo",
      sessionId: sessionInfo.value?.sessionId,
      prevTrackSid: prevTrackSid || "-",
      newTrackSid: resolvedTrackSid,
      prevMediaTrackIds: mediaStreamTrackIds(prevSrcObject),
      newMediaTrackIds: mediaStreamTrackIds(element.srcObject),
      srcObjectChanged: prevSrcObject !== element.srcObject,
      videoElementReplaced: prevVideo !== element,
    });

    if (resolvedTrackSid !== "-") {
      if (lastTrackSid && lastTrackSid !== resolvedTrackSid) {
        remoteViewLifecycleDiag("trackSid-changed", {
          sessionId: sessionInfo.value?.sessionId,
          prevTrackSid: lastTrackSid,
          newTrackSid: resolvedTrackSid,
          source: context?.source ?? "attachVideo",
        });
      }
      lastTrackSid = resolvedTrackSid;
    }

    void element.play().catch(() => {
      window.setTimeout(() => {
        void element.play().catch(() => {});
      }, 300);
    });
  };

  const clearReconnectTimer = () => {
    if (reconnectTimer != null) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
  };

  const clearViewerTokenRefresh = () => {
    if (viewerTokenRefreshTimer != null) {
      window.clearTimeout(viewerTokenRefreshTimer);
      viewerTokenRefreshTimer = null;
    }
  };

  const scheduleViewerTokenRefresh = (expiresAt?: string | Date | null) => {
    clearViewerTokenRefresh();
    if (!expiresAt) return;
    const expMs = new Date(expiresAt).getTime();
    if (!Number.isFinite(expMs)) return;
    const delay = Math.max(
      expMs - Date.now() - VIEWER_TOKEN_REFRESH_BEFORE_MS,
      VIEWER_TOKEN_REFRESH_MIN_DELAY_MS,
    );
    viewerTokenRefreshTimer = window.setTimeout(() => {
      void refreshViewerTokenBeforeExpiry();
    }, delay);
  };

  /** Renew JWT and soft-reconnect before LiveKit kicks the viewer (avoids ~TTL black screen). */
  const refreshViewerTokenBeforeExpiry = () =>
    withConnectionLock(async () => {
      const generation = viewGeneration;
      const info = sessionInfo.value;
      const container = activeVideoContainer;
      if (!info?.sessionId || !container) return;
      if (generation !== viewGeneration) return;

      try {
        const { data } = await remoteViewApi.refreshViewerToken(
          info.deviceId,
          info.sessionId,
        );
        if (generation !== viewGeneration) return;
        sessionInfo.value = {
          ...info,
          viewerToken: data.viewerToken,
          livekitUrl: data.livekitUrl || info.livekitUrl,
          expiresAt: data.expiresAt,
          roomName: data.roomName || info.roomName,
        };
        scheduleViewerTokenRefresh(data.expiresAt);

        const lkRoom = room.value;
        if (!lkRoom || lkRoom.state === ConnectionState.Disconnected) {
          // resumeView / next reconnect will use the new token
          return;
        }
        remoteViewLifecycleDiag("viewer-token-refresh", {
          sessionId: info.sessionId,
          expiresAt: data.expiresAt,
        });
        const attached = await reconnectLiveKitPlayer(container, generation);
        if (generation !== viewGeneration) return;
        if (attached) {
          sessionStatus.value = "active";
          startupPhase.value = "active";
          resumePlayback(container);
        }
      } catch (error) {
        console.warn("[RemoteView] viewer token refresh failed", error);
        // Retry once in 30s if still on same generation
        if (generation === viewGeneration) {
          viewerTokenRefreshTimer = window.setTimeout(() => {
            void refreshViewerTokenBeforeExpiry();
          }, 30_000);
        }
      }
    });

  const subscribePublisherVideo = (
    publication: RemoteTrackPublication,
    participant: RemoteParticipant,
    deviceId: string,
    sessionId: string,
  ) => {
    if (!isExpectedPublisher(participant, deviceId, sessionId)) return;
    if (publication.kind === Track.Kind.Video && !publication.isSubscribed) {
      publication.setSubscribed(true);
    }
  };

  const subscribeExpectedPublisherTracks = (
    lkRoom: Room,
    deviceId: string,
    sessionId: string,
  ) => {
    for (const participant of lkRoom.remoteParticipants.values()) {
      for (const publication of participant.trackPublications.values()) {
        subscribePublisherVideo(
          publication as RemoteTrackPublication,
          participant,
          deviceId,
          sessionId,
        );
      }
    }
  };

  const attachExistingVideoTracks = (
    lkRoom: Room,
    container: HTMLElement,
    deviceId: string,
    sessionId: string,
  ) => {
    for (const participant of lkRoom.remoteParticipants.values()) {
      if (!isExpectedPublisher(participant, deviceId, sessionId)) continue;
      for (const publication of participant.trackPublications.values()) {
        const pub = publication as RemoteTrackPublication;
        if (pub.track && pub.kind === Track.Kind.Video) {
          attachVideo(container, pub.track as RemoteTrack, {
            trackSid: pub.trackSid,
            source: "attachExistingVideoTracks",
          });
          return;
        }
      }
    }
  };

  const bindRoomEvents = (
    lkRoom: Room,
    videoContainer: HTMLElement,
    generation: number,
    deviceId: string,
    sessionId: string,
  ) => {
    lkRoom.on(RoomEvent.ParticipantConnected, (participant) => {
      if (generation !== viewGeneration) return;
      for (const publication of participant.trackPublications.values()) {
        subscribePublisherVideo(
          publication as RemoteTrackPublication,
          participant,
          deviceId,
          sessionId,
        );
      }
    });

    // autoSubscribe=false: must subscribe when Ingress republishes a new track
    // on an already-connected publisher (quality / WHIP restart).
    lkRoom.on(RoomEvent.TrackPublished, (publication, participant) => {
      if (generation !== viewGeneration) return;
      subscribePublisherVideo(
        publication as RemoteTrackPublication,
        participant,
        deviceId,
        sessionId,
      );
    });

    lkRoom.on(RoomEvent.TrackSubscribed, (track, publication, participant) => {
      if (generation !== viewGeneration) return;
      if (track.kind !== Track.Kind.Video) return;
      if (attachMode !== "normal") {
        remoteViewLifecycleDiag("track-subscribed-suppressed", {
          sessionId,
          trackSid: publication.trackSid,
          participantIdentity: participant.identity,
          attachMode,
        });
        return;
      }
      if (!isExpectedPublisher(participant, deviceId, sessionId)) return;
      remoteViewLifecycleDiag("track-subscribed", {
        sessionId,
        trackSid: publication.trackSid,
        participantIdentity: participant.identity,
        prevTrackSid: lastTrackSid || "-",
      });
      attachVideo(videoContainer, track as RemoteTrack, {
        trackSid: publication.trackSid,
        source: "TrackSubscribed",
      });
      sessionStatus.value = "active";
      startupPhase.value = "active";
    });

    lkRoom.on(RoomEvent.TrackUnsubscribed, (track, publication, participant) => {
      if (generation !== viewGeneration) return;
      if (track.kind !== Track.Kind.Video) return;
      remoteViewLifecycleDiag("track-unsubscribed", {
        sessionId,
        trackSid: publication.trackSid,
        participantIdentity: participant.identity,
        attachMode,
      });
      track.detach();
      // During quality switch the publisher restarts; keep the last frame visible.
      if (attachMode !== "normal") return;
      clearVideoContainer(videoContainer);
      if (generation === viewGeneration) {
        sessionStatus.value = "starting";
        startupPhase.value = "player";
      }
    });

    lkRoom.on(RoomEvent.ConnectionStateChanged, (state) => {
      if (generation !== viewGeneration) return;
      connectionState.value = state;
      if (state === ConnectionState.Connected) {
        reconnectAttempts = 0;
        if (sessionStatus.value !== "active") {
          sessionStatus.value = "starting";
          startupPhase.value = "player";
        }
      } else if (state === ConnectionState.Reconnecting) {
        sessionStatus.value = "reconnecting";
      }
    });

    lkRoom.on(RoomEvent.Reconnected, () => {
      if (generation !== viewGeneration) return;
      reconnectAttempts = 0;
      subscribeExpectedPublisherTracks(lkRoom, deviceId, sessionId);
      attachExistingVideoTracks(lkRoom, videoContainer, deviceId, sessionId);
      if (videoContainer.querySelector("video")) {
        sessionStatus.value = "active";
        startupPhase.value = "active";
        resumePlayback(videoContainer);
      }
    });

    lkRoom.on(RoomEvent.Disconnected, () => {
      if (generation !== viewGeneration) return;
      sessionStatus.value = "disconnected";
      startupPhase.value = "idle";
      console.warn("[RemoteView] LiveKit disconnected; waiting for SDK reconnect or manual stop");
    });
  };

  const resumePlayback = (container: HTMLElement) => {
    const video = container.querySelector("video") as HTMLVideoElement | null;
    if (video) {
      void video.play().catch(() => {});
    }
  };

  const resumeView = () =>
    withConnectionLock(async () => {
      const generation = viewGeneration;
      const info = sessionInfo.value;
      const container = activeVideoContainer;
      const lkRoom = room.value;
      if (!info || !container || !lkRoom) return;
      if (generation !== viewGeneration) return;

      const state = lkRoom.state;
      if (
        state === ConnectionState.Connecting ||
        state === ConnectionState.Reconnecting
      ) {
        return;
      }

      if (state === ConnectionState.Connected) {
        if (sessionStatus.value === "starting") return;
        if (sessionStatus.value === "active") resumePlayback(container);
        return;
      }

      if (state !== ConnectionState.Disconnected) return;
      if (sessionStatus.value !== "disconnected" && sessionStatus.value !== "active") {
        return;
      }

      sessionStatus.value = "reconnecting";
      startupPhase.value = "player";
      try {
        await lkRoom.connect(info.livekitUrl, info.viewerToken);
        if (generation !== viewGeneration) return;
        connectionState.value = ConnectionState.Connected;
        const attached = await waitForVideoTrack(
          lkRoom,
          container,
          generation,
          info.deviceId,
          info.sessionId,
          VIDEO_ATTACH_TIMEOUT_MS,
        );
        if (generation !== viewGeneration) return;
        if (attached) {
          sessionStatus.value = "active";
          startupPhase.value = "active";
        } else {
          sessionStatus.value = "starting";
        }
      } catch (error) {
        if (generation !== viewGeneration) return;
        sessionStatus.value = "disconnected";
        startupPhase.value = "idle";
        console.warn("[RemoteView] resumeView failed", error);
      }
    });

  const refreshVideoAttachment = async () => {
    const container = activeVideoContainer;
    const lkRoom = room.value;
    const info = sessionInfo.value;
    const generation = viewGeneration;
    if (!container || !lkRoom || !info || lkRoom.state !== ConnectionState.Connected) {
      return;
    }
    clearVideoContainer(container);
    sessionStatus.value = "starting";
    startupPhase.value = "player";
    subscribeExpectedPublisherTracks(lkRoom, info.deviceId, info.sessionId);
    const attached = await waitForVideoTrack(
      lkRoom,
      container,
      generation,
      info.deviceId,
      info.sessionId,
      VIDEO_ATTACH_TIMEOUT_MS,
    );
    if (room.value !== lkRoom || viewGeneration !== generation) return;
    if (attached) {
      sessionStatus.value = "active";
      startupPhase.value = "active";
      resumePlayback(container);
    }
  };

  const VIDEO_LIVE_MIN_DELTA = 0.05;

  const readPaintedFrameCount = (video: HTMLVideoElement): number => {
    try {
      const quality = video.getVideoPlaybackQuality?.();
      if (quality && Number.isFinite(quality.totalVideoFrames)) {
        return quality.totalVideoFrames;
      }
    } catch {
      // unsupported
    }
    return -1;
  };

  const sampleInboundVideoStats = async (): Promise<{
    bytesReceived: number;
    framesDecoded: number;
  } | null> => {
    const lkRoom = room.value;
    if (!lkRoom) return null;
    let bytesReceived = 0;
    let framesDecoded = 0;
    let found = false;
    for (const participant of lkRoom.remoteParticipants.values()) {
      for (const publication of participant.trackPublications.values()) {
        const remote = publication.track as RemoteTrack | undefined;
        if (!remote || remote.kind !== Track.Kind.Video) continue;
        const receiver = (remote as unknown as { receiver?: RTCRtpReceiver }).receiver;
        if (!receiver?.getStats) continue;
        try {
          const report = await receiver.getStats();
          report.forEach((entry) => {
            const row = entry as RTCInboundRtpStreamStats & { kind?: string; bytesReceived?: number; framesDecoded?: number };
            if (row.type !== "inbound-rtp") return;
            if (row.kind && row.kind !== "video") return;
            found = true;
            bytesReceived += row.bytesReceived ?? 0;
            framesDecoded += row.framesDecoded ?? 0;
          });
        } catch {
          // ignore per-track stats errors
        }
      }
    }
    return found ? { bytesReceived, framesDecoded } : null;
  };

  const waitForPaintedVideoFrame = (
    video: HTMLVideoElement,
    timeoutMs: number,
  ): Promise<boolean> =>
    new Promise((resolve) => {
      const rvfc = (
        video as HTMLVideoElement & {
          requestVideoFrameCallback?: (cb: () => void) => number;
        }
      ).requestVideoFrameCallback;
      if (typeof rvfc === "function") {
        let settled = false;
        const timer = window.setTimeout(() => {
          if (settled) return;
          settled = true;
          resolve(false);
        }, timeoutMs);
        rvfc.call(video, () => {
          if (settled) return;
          settled = true;
          window.clearTimeout(timer);
          resolve(true);
        });
        return;
      }
      window.setTimeout(() => {
        resolve(video.videoWidth > 0 && video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA);
      }, Math.min(timeoutMs, 400));
    });

  const isVideoPlaybackLive = async (
    container: HTMLElement,
    sampleMs = BACKGROUND_LIVE_SAMPLE_MS,
  ): Promise<boolean> => {
    const video = container.querySelector("video") as HTMLVideoElement | null;
    if (!video) return false;

    if (video.paused) {
      try {
        await video.play();
      } catch {
        // autoplay / play race
      }
    }

    // Prefer real paint / decode signals — WebRTC MediaStream often keeps currentTime ~0.
    if (await waitForPaintedVideoFrame(video, Math.min(sampleMs, 900))) {
      return true;
    }

    const painted0 = readPaintedFrameCount(video);
    const rtc0 = await sampleInboundVideoStats();
    const t0 = video.currentTime;
    const width0 = video.videoWidth;
    await sleep(sampleMs);
    const painted1 = readPaintedFrameCount(video);
    const rtpDelta = await sampleRtpDeltaAfter(rtc0);
    const t1 = video.currentTime;

    if (painted0 >= 0 && painted1 > painted0) return true;
    if (rtpDelta.flowing) {
      return true;
    }
    if (video.videoWidth > 0 && width0 > 0 && video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) {
      // Dimensions stable with data: treat as live even if currentTime is sticky.
      if (t1 - t0 >= VIDEO_LIVE_MIN_DELTA) return true;
      if (painted1 > 0 || (rtpDelta.rtc1?.framesDecoded ?? 0) > 0) return true;
    }
    return t1 - t0 >= VIDEO_LIVE_MIN_DELTA;
  };

  /** Shared RTP window delta used by live-check and dead-frame recovery. */
  const sampleRtpDeltaAfter = async (
    rtc0: { bytesReceived: number; framesDecoded: number } | null,
  ): Promise<{
    flowing: boolean;
    deltaFrames: number;
    deltaBytes: number;
    rtc1: { bytesReceived: number; framesDecoded: number } | null;
  }> => {
    const rtc1 = await sampleInboundVideoStats();
    const deltaFrames = (rtc1?.framesDecoded ?? 0) - (rtc0?.framesDecoded ?? 0);
    const deltaBytes = (rtc1?.bytesReceived ?? 0) - (rtc0?.bytesReceived ?? 0);
    const flowing =
      !!rtc0 &&
      !!rtc1 &&
      (deltaFrames > 0 || deltaBytes > RTP_BYTES_DELTA_MIN);
    return { flowing, deltaFrames, deltaBytes, rtc1 };
  };

  const sampleRtpFlowing = async (
    sampleMs = BACKGROUND_LIVE_SAMPLE_MS,
  ): Promise<boolean> => {
    const rtc0 = await sampleInboundVideoStats();
    await sleep(sampleMs);
    const { flowing } = await sampleRtpDeltaAfter(rtc0);
    return flowing;
  };

  const isHealthyActiveSession = (status?: RemoteViewStatus | null) => {
    if (!status?.isActive || status.status !== "active") return false;
    // SFU track presence alone is not enough (empty / pre-media track → black screen).
    if (status.sfuChecked && !status.sfuPublishing) return false;
    return status.statsFresh === true && (status.stats?.fps ?? 0) > 0;
  };

  const hasFreshPublisherStats = (status?: RemoteViewStatus | null) => {
    if (status?.sfuChecked && !status.sfuPublishing) return false;
    if (!status?.statsFresh || !status.stats) return false;
    const fps = status.stats.fps ?? 0;
    const bitrate = status.stats.bitrateKbps ?? 0;
    return fps > 0 || bitrate > 0;
  };

  /** True when backend would treat the session as still in stats warm-up (never had stats). */
  const isPublisherStatsWarmup = (status?: RemoteViewStatus | null) => {
    if (!status?.isActive || !status.sessionId) return false;
    // Fresh stats payload means warm-up ended (backend neverHadStats=false).
    if (status.statsFresh === true) return false;

    const warmupMs =
      typeof status.startingTimeoutSec === "number" && status.startingTimeoutSec > 0
        ? status.startingTimeoutSec * 1000
        : REMOTE_VIEW_STARTING_WARMUP_MS;

    // Mirror backend publisherInStatsWarmup:
    // starting → UpdatedAt; active → StartedAt (not updatedAt — viewer_join must not extend).
    if (status.status === "starting") {
      const anchor = status.updatedAt || status.startedAt;
      if (!anchor) return true;
      const ageMs = Date.now() - Date.parse(anchor);
      return !Number.isFinite(ageMs) || ageMs < warmupMs;
    }
    if (status.status === "active") {
      if (!status.startedAt) return false;
      const ageMs = Date.now() - Date.parse(status.startedAt);
      return Number.isFinite(ageMs) && ageMs < warmupMs;
    }
    return false;
  };

  /**
   * Mirrors backend publisherIsLive: SFU not-publishing ⇒ dead;
   * agent fps>0 ⇒ live; else warm-up may allow young sessions.
   */
  const publisherLooksLive = (status?: RemoteViewStatus | null) => {
    if (!status?.isActive || !status.sessionId) return false;
    if (status.sfuChecked && status.sfuPublishing === false) return false;

    const agentLive =
      status.statsFresh === true && (status.stats?.fps ?? 0) > 0;
    if (agentLive) return true;
    return isPublisherStatsWarmup(status);
  };

  /** Align with backend StartSession reuseOK + publisherIsLive double-check. */
  const canReuseSession = (status?: RemoteViewStatus | null) => {
    if (!status?.isActive || !status.sessionId) return false;
    if (status.sfuChecked && status.sfuPublishing === false) return false;

    if (status.status === "starting" && isPublisherStatsWarmup(status)) {
      return true;
    }
    if (status.status === "starting" && !status.startedAt) {
      // Status says starting but clock unknown — prefer reuse over hard-stop.
      return true;
    }
    return publisherLooksLive(status);
  };

  const waitForVideoTrack = (
    lkRoom: Room,
    container: HTMLElement,
    generation: number,
    deviceId: string,
    sessionId: string,
    timeoutMs = VIDEO_ATTACH_TIMEOUT_MS,
  ) =>
    new Promise<boolean>((resolve) => {
      if (generation !== viewGeneration) {
        resolve(false);
        return;
      }

      subscribeExpectedPublisherTracks(lkRoom, deviceId, sessionId);
      attachExistingVideoTracks(lkRoom, container, deviceId, sessionId);
      if (container.querySelector("video")) {
        resolve(true);
        return;
      }

      let settled = false;
      const finish = (ok: boolean) => {
        if (settled) return;
        settled = true;
        lkRoom.off(RoomEvent.TrackSubscribed, onTrack);
        window.clearTimeout(timer);
        resolve(ok);
      };

      const onTrack = (
        track: RemoteTrack,
        publication: RemoteTrackPublication,
        participant: RemoteParticipant,
      ) => {
        if (generation !== viewGeneration) {
          finish(false);
          return;
        }
        if (track.kind !== Track.Kind.Video) return;
        // switchPending: waitForVideoTrack is the only allowed attach path
        if (!isExpectedPublisher(participant, deviceId, sessionId)) return;
        attachVideo(container, track, {
          trackSid: publication.trackSid,
          source: "waitForVideoTrack",
        });
        finish(true);
      };

      lkRoom.on(RoomEvent.TrackSubscribed, onTrack);
      const timer = window.setTimeout(
        () => finish(!!container.querySelector("video")),
        timeoutMs,
      );
    });

  const reconnectLiveKitPlayer = async (
    container: HTMLElement,
    generation: number,
  ) => {
    const lkRoom = room.value;
    const info = sessionInfo.value;
    if (!lkRoom || !info || generation !== viewGeneration) return false;

    remoteViewLifecycleDiag("livekit-reconnect-begin", {
      sessionId: info.sessionId,
      prevTrackSid: lastTrackSid || "-",
      roomState: lkRoom.state,
    });

    try {
      await lkRoom.disconnect();
      if (generation !== viewGeneration) return false;
      await lkRoom.connect(info.livekitUrl, info.viewerToken);
      if (generation !== viewGeneration) return false;
      connectionState.value = ConnectionState.Connected;
      subscribeExpectedPublisherTracks(lkRoom, info.deviceId, info.sessionId);
      const attached = await waitForVideoTrack(
        lkRoom,
        container,
        generation,
        info.deviceId,
        info.sessionId,
        VIDEO_ATTACH_TIMEOUT_MS,
      );
      if (generation !== viewGeneration) return false;
      remoteViewLifecycleDiag("livekit-reconnect-end", {
        sessionId: info.sessionId,
        attached,
        trackSid: lastTrackSid || "-",
      });
      return attached;
    } catch (error) {
      remoteViewLifecycleDiag("livekit-reconnect-failed", {
        sessionId: info.sessionId,
        error: error instanceof Error ? error.message : String(error),
      });
      console.warn("[RemoteView] LiveKit reconnect failed", error);
      return false;
    }
  };

  const recoverPlayerAfterPublisherReady = async (
    container: HTMLElement,
    generation: number,
  ) => {
    if (generation !== viewGeneration) return false;
    startupPhase.value = "player";
    // Encoder restart publishes a new LiveKit track — reconnect subscribes to it.
    let attached = await reconnectLiveKitPlayer(container, generation);
    if (generation !== viewGeneration) return false;
    if (!attached) {
      await refreshVideoAttachment();
      if (generation !== viewGeneration) return false;
      attached = !!container.querySelector("video");
    }
    if (attached && generation === viewGeneration) {
      sessionStatus.value = "active";
      startupPhase.value = "active";
      resumePlayback(container);
    }
    return attached;
  };

  const cancelLivePlaybackWatchdog = () => {
    livePlaybackWatchdogId += 1;
  };

  const clearDeadFrameExhaustTimer = () => {
    if (deadFrameExhaustTimer != null) {
      window.clearTimeout(deadFrameExhaustTimer);
      deadFrameExhaustTimer = null;
    }
  };

  const resetDeadFrameRecoveryState = () => {
    clearDeadFrameExhaustTimer();
    deadFrameRecoveryAttempts = 0;
    deadFrameAutoCycles = 0;
    playbackDegraded.value = false;
  };

  /**
   * After max in-cycle recoveries: mark degraded, optionally schedule one delayed
   * auto cycle, then require manual retryFreshView.
   */
  const scheduleDeadFrameExhaustRetry = (
    container: HTMLElement,
    generation: number,
  ) => {
    if (generation !== viewGeneration) return;
    playbackDegraded.value = true;
    if (deadFrameAutoCycles >= MAX_DEAD_FRAME_AUTO_CYCLES) {
      console.warn(
        "[RemoteView] dead frame auto-retry cycles exhausted; waiting for manual fresh retry",
      );
      return;
    }
    clearDeadFrameExhaustTimer();
    deadFrameExhaustTimer = window.setTimeout(() => {
      deadFrameExhaustTimer = null;
      if (generation !== viewGeneration) return;
      if (activeVideoContainer !== container) return;
      deadFrameAutoCycles += 1;
      deadFrameRecoveryAttempts = 0;
      playbackDegraded.value = false;
      console.warn(
        `[RemoteView] dead frame exhaust auto-retry cycle ${deadFrameAutoCycles}/${MAX_DEAD_FRAME_AUTO_CYCLES}`,
      );
      ensureLivePlaybackInBackground(container, generation);
    }, DEAD_FRAME_EXHAUST_COOLDOWN_MS);
  };

  const switchQuality = async (
    deviceId: string,
    quality: "weak" | "auto" | "strong",
    sessionId: string,
    generation: number,
  ) => {
    cancelLivePlaybackWatchdog();
    // Drop any pending exhaust timer from a prior dead-frame cycle so it cannot
    // fire into the quality-switch cooldown and burn an auto-retry slot.
    clearDeadFrameExhaustTimer();
    deadFrameAutoCycles = 0;
    deadFrameRecoveryAttempts = 0;
    playbackDegraded.value = false;
    qualitySwitchCooldownUntil = Date.now() + QUALITY_SWITCH_COOLDOWN_MS;
    if (generation !== viewGeneration) return;
    activeQuality = quality;
    qualitySwitchCooldownUntil = Date.now() + QUALITY_SWITCH_COOLDOWN_MS;
    attachMode = "switchPending";
    startupPhase.value = "publisher";
    sessionStatus.value = "starting";
    let liveWatchdogArmed = false;
    try {
      await remoteViewApi.setQuality(deviceId, quality, sessionId);
      if (generation !== viewGeneration) return;
      const ready = await waitForPublisherReady(deviceId, sessionId, generation);
      if (!ready) {
        throw new Error("画质切换超时，请重试");
      }
      if (generation !== viewGeneration) return;
      await sleep(QUALITY_SWITCH_SETTLE_MS);
      if (generation !== viewGeneration) return;
      const container = activeVideoContainer;
      if (!container) return;
      const attached = await recoverPlayerAfterPublisherReady(container, generation);
      if (!attached && generation === viewGeneration) {
        throw new Error("画质切换后未能恢复画面");
      }
      if (attached && generation === viewGeneration) {
        ensureLivePlaybackInBackground(container, generation);
        liveWatchdogArmed = true;
      }
    } finally {
      if (generation === viewGeneration) attachMode = "normal";
      // Entry cancels the prior watchdog; on failure/early-exit still re-arm so
      // dead-frame recovery stays closed (waitOutQualityCooldown respects cooldown).
      if (
        !liveWatchdogArmed &&
        generation === viewGeneration &&
        activeVideoContainer
      ) {
        ensureLivePlaybackInBackground(activeVideoContainer, generation);
      }
    }
  };

  const ensureLivePlaybackInBackground = (
    container: HTMLElement,
    generation: number,
  ) => {
    const watchdogId = ++livePlaybackWatchdogId;
    void (async () => {
      const aborted = () =>
        watchdogId !== livePlaybackWatchdogId || generation !== viewGeneration;

      /** Wait out quality-switch cooldown instead of bailing — otherwise watchdog never restarts. */
      const waitOutQualityCooldown = async () => {
        while (!aborted() && Date.now() < qualitySwitchCooldownUntil) {
          const waitMs = Math.min(
            500,
            Math.max(50, qualitySwitchCooldownUntil - Date.now()),
          );
          await sleep(waitMs);
        }
        return !aborted();
      };

      if (aborted()) return;
      if (!(await waitOutQualityCooldown())) return;

      await sleep(WHIP_FIRST_FRAME_BUFFER_MS);
      if (aborted()) return;
      if (!(await waitOutQualityCooldown())) return;

      for (let attempt = 0; attempt < BACKGROUND_LIVE_RETRIES; attempt++) {
        if (aborted()) return;
        if (!(await waitOutQualityCooldown())) return;

        await sleep(BACKGROUND_LIVE_SAMPLE_MS);
        if (aborted()) return;
        if (await isVideoPlaybackLive(container, BACKGROUND_LIVE_SAMPLE_MS)) {
          playbackDegraded.value = false;
          return;
        }
        if (attempt < BACKGROUND_LIVE_RETRIES - 1) {
          await sleep(BACKGROUND_LIVE_RETRY_GAP_MS);
        }
      }

      // Up to MAX recoveries in this watchdog run, then exhaust → delayed auto cycle / UI.
      while (deadFrameRecoveryAttempts < MAX_DEAD_FRAME_RECOVERIES) {
        if (aborted()) return;
        if (!(await waitOutQualityCooldown())) return;

        deadFrameRecoveryAttempts += 1;
        console.warn(
          `[RemoteView] dead frame after attach; recovering playback (attempt ${deadFrameRecoveryAttempts}/${MAX_DEAD_FRAME_RECOVERIES})`,
        );
        const recovered = await recoverFromDeadFrame(container, generation);
        if (aborted()) return;
        if (recovered && (await isVideoPlaybackLive(container))) {
          playbackDegraded.value = false;
          return;
        }
        console.warn(
          recovered
            ? "[RemoteView] recovery finished but playback still not live"
            : "[RemoteView] dead-frame recovery failed",
        );
      }

      if (aborted()) return;
      scheduleDeadFrameExhaustRetry(container, generation);
    })();
  };

  const sleep = (ms: number) =>
    new Promise<void>((resolve) => {
      window.setTimeout(resolve, ms);
    });

  const waitForPublisherReady = async (
    deviceId: string,
    sessionId: string,
    generation: number,
  ): Promise<boolean> => {
    let resolved = false;
    let ready = false;
    let sawPublished = false;
    let skipSleepOnce = false;

    const onPublishedEvent = (event: Event) => {
      if (generation !== viewGeneration || resolved) return;
      const detail = (event as CustomEvent).detail as {
        deviceId?: string;
        sessionId?: string;
        event?: string;
      };
      if (detail.deviceId !== deviceId || detail.sessionId !== sessionId) return;
      if (detail.event === "failed") {
        resolved = true;
        ready = false;
      }
      if (detail.event === "published") {
        // Do not treat published alone as ready — still require agent fps + SFU ok via poll.
        sawPublished = true;
        skipSleepOnce = true;
      }
    };

    window.addEventListener("remote-view-event", onPublishedEvent);

    const deadline = Date.now() + 25_000;
    while (Date.now() < deadline && generation === viewGeneration && !resolved) {
      try {
        const data = await refreshStatus(deviceId);
        if (generation !== viewGeneration) break;
        if (data.sessionId !== sessionId) {
          // keep waiting for this session
        } else {
          const fps = data.stats?.fps ?? 0;
          const agentLive = data.statsFresh === true && fps > 0;
          // SFU track existence alone is not media-ready (causes premature attach → black).
          const sfuOk = !data.sfuChecked || data.sfuPublishing === true;
          if (agentLive && sfuOk) {
            resolved = true;
            ready = true;
            break;
          }
          if (sawPublished && !sfuOk) {
            remoteViewLifecycleDiag("publisher-published-waiting-sfu", {
              sessionId,
              sfuChecked: data.sfuChecked,
              sfuPublishing: data.sfuPublishing,
            });
          }
        }
      } catch {
        // ignore polling errors
      }
      if (skipSleepOnce) {
        skipSleepOnce = false;
      } else {
        await sleep(PUBLISHER_POLL_MS);
      }
    }

    window.removeEventListener("remote-view-event", onPublishedEvent);
    if (generation !== viewGeneration) return false;
    if (ready) await sleep(PUBLISHER_SETTLE_MS);
    return generation === viewGeneration && ready;
  };

  const recoverFromDeadFrame = async (
    container: HTMLElement,
    generation: number,
  ): Promise<boolean> =>
    withConnectionLock(async () => {
      if (generation !== viewGeneration) return false;
      if (Date.now() < qualitySwitchCooldownUntil) return false;

      resumePlayback(container);
      if (await isVideoPlaybackLive(container)) {
        return generation === viewGeneration;
      }

      await refreshVideoAttachment();
      if (generation !== viewGeneration) return false;
      resumePlayback(container);
      if (await isVideoPlaybackLive(container)) {
        return generation === viewGeneration;
      }

      const info = sessionInfo.value;
      if (!info || generation !== viewGeneration) return false;
      if (Date.now() < qualitySwitchCooldownUntil) return false;

      // Windowed RTP delta (same rules as isVideoPlaybackLive) — not cumulative counters.
      const rtpFlowing = await sampleRtpFlowing(BACKGROUND_LIVE_SAMPLE_MS);
      if (generation !== viewGeneration) return false;

      if (rtpFlowing) {
        console.warn(
          "[RemoteView] dead frame but RTP flowing; reconnecting player only (no encoder republish)",
        );
        const attached = await reconnectLiveKitPlayer(container, generation);
        if (generation !== viewGeneration) return false;
        if (!attached) return false;
        resumePlayback(container);
        if (await isVideoPlaybackLive(container)) {
          sessionStatus.value = "active";
          startupPhase.value = "active";
          return true;
        }
        return false;
      }

      // No RTP delta: if agent still reports fresh fps, prefer player reconnect once
      // before encoder republish (avoids restart storms on brief jitter).
      let preferPlayerOnly = false;
      try {
        const status = await refreshStatus(info.deviceId);
        if (generation !== viewGeneration) return false;
        preferPlayerOnly =
          status?.statsFresh === true && (status.stats?.fps ?? 0) > 0;
      } catch {
        // keep existing debounce paths if status refresh fails
      }

      if (preferPlayerOnly) {
        console.warn(
          "[RemoteView] dead frame, no RTP delta but agent fps fresh; reconnecting player only",
        );
        const attached = await reconnectLiveKitPlayer(container, generation);
        if (generation !== viewGeneration) return false;
        if (!attached) return false;
        resumePlayback(container);
        if (await isVideoPlaybackLive(container)) {
          sessionStatus.value = "active";
          startupPhase.value = "active";
          return true;
        }
        // Fall through to encoder republish
      }

      console.warn("[RemoteView] dead frame with no RTP; republishing encoder then reconnecting player");
      attachMode = "switchPending";
      try {
        await remoteViewApi.setQuality(info.deviceId, activeQuality, info.sessionId);
        if (generation !== viewGeneration) return false;
        const ready = await waitForPublisherReady(
          info.deviceId,
          info.sessionId,
          generation,
        );
        if (!ready || generation !== viewGeneration) return false;
        await sleep(QUALITY_SWITCH_SETTLE_MS);
        if (generation !== viewGeneration) return false;
        const attached = await recoverPlayerAfterPublisherReady(container, generation);
        if (generation !== viewGeneration) return false;
        if (!attached) return false;
        resumePlayback(container);
        if (await isVideoPlaybackLive(container)) {
          if (generation !== viewGeneration) return false;
          sessionStatus.value = "active";
          startupPhase.value = "active";
          return true;
        }
      } finally {
        if (generation === viewGeneration) attachMode = "normal";
      }

      return false;
    });

  const ensureCleanStart = async (deviceId: string, generation: number) => {
    const existing = room.value;
    if (existing) {
      try {
        await existing.disconnect();
      } catch {
        // ignore
      }
      if (generation !== viewGeneration) return null;
      if (room.value === existing) {
        room.value = null;
      }
    }
    if (generation !== viewGeneration) return null;
    clearVideoContainer(activeVideoContainer);
    sessionInfo.value = null;
    stats.value = { fps: 0, bitrateKbps: 0, encoder: "" };

    try {
      const { data: status } = await remoteViewApi.getStatus(deviceId);
      if (generation !== viewGeneration) return status;
      // Only hard-stop sessions the backend would also discard (not starting/warmup).
      if (status?.isActive && status.sessionId && !canReuseSession(status)) {
        console.warn(
          "[RemoteView] ensureCleanStart hard-stop non-reusable session",
          status.sessionId,
          status.status,
          { statsFresh: status.statsFresh, sfuPublishing: status.sfuPublishing },
        );
        await remoteViewApi.stop(deviceId, status.sessionId, { hard: true });
        if (generation !== viewGeneration) return null;
        await sleep(200);
        if (generation !== viewGeneration) return null;
        return null;
      }
      return status;
    } catch {
      return null;
    }
  };

  // Called under withConnectionLock from RemoteScreenManager (connect / toggleView).
  const startView = async (
    deviceId: string,
    videoContainer: HTMLElement,
    quality: "weak" | "auto" | "strong" = "strong",
  ) => {
    let startedSessionId: string | undefined;
    const generation = ++viewGeneration;
    resetDeadFrameRecoveryState();
    activeVideoContainer = videoContainer;
    clearVideoContainer(videoContainer);
    startupPhase.value = "preparing";

    try {
      const priorStatus = await ensureCleanStart(deviceId, generation);
      if (generation !== viewGeneration) {
        throw new Error("Remote view start cancelled");
      }

      const freshStart = !canReuseSession(priorStatus);
      activeQuality = quality;
      startupPhase.value = "publisher";

      const { data } = await remoteViewApi.start(deviceId, { quality, freshStart });
      if (generation !== viewGeneration) {
        await remoteViewApi.stop(deviceId, data.sessionId, { hard: true });
        throw new Error("Remote view start cancelled");
      }

      sessionInfo.value = data;
      sessionStatus.value = "starting";
      startedSessionId = data.sessionId;

      const skipPublisherWait =
        !freshStart &&
        (isHealthyActiveSession(priorStatus) ||
          (priorStatus?.sessionId === data.sessionId &&
            priorStatus?.status === "active" &&
            hasFreshPublisherStats(priorStatus)));

      let publisherReady = skipPublisherWait;
      startupPhase.value = "player";
      const lkRoom = new Room({
        adaptiveStream: false,
        dynacast: false,
        disconnectOnPageLeave: true,
        autoSubscribe: false,
        expFastStart: true,
      });

      bindRoomEvents(lkRoom, videoContainer, generation, deviceId, data.sessionId);
      attachMode = "normal";

      const connectPlayer = async () => {
        await lkRoom.connect(data.livekitUrl, data.viewerToken);
        if (generation !== viewGeneration) {
          await lkRoom.disconnect();
          throw new Error("Remote view start cancelled");
        }
        room.value = lkRoom;
        connectionState.value = ConnectionState.Connected;
        subscribeExpectedPublisherTracks(lkRoom, deviceId, data.sessionId);
      };

      const publisherPromise = publisherReady
        ? Promise.resolve(true)
        : waitForPublisherReady(deviceId, data.sessionId, generation);

      const [, publisherReadyResult] = await Promise.all([
        connectPlayer(),
        publisherPromise,
      ]);
      publisherReady = publisherReadyResult;

      if (generation !== viewGeneration) {
        await lkRoom.disconnect();
        throw new Error("Remote view start cancelled");
      }
      if (!publisherReady) {
        await lkRoom.disconnect();
        throw new Error("远程推流启动超时，请重试");
      }

      const attached = await waitForVideoTrack(
        lkRoom,
        videoContainer,
        generation,
        deviceId,
        data.sessionId,
        VIDEO_ATTACH_TIMEOUT_MS,
      );
      if (generation !== viewGeneration) {
        await lkRoom.disconnect();
        throw new Error("Remote view start cancelled");
      }

      if (attached) {
        sessionStatus.value = "active";
        startupPhase.value = "active";
        resumePlayback(videoContainer);
        // Agent sends "published" only after WHIP is ready (incl. slow-publish recovery).
        // Reconnecting here adds ~1–2s glass-to-glass latency on first open.
      }

      scheduleViewerTokenRefresh(data.expiresAt);
      ensureLivePlaybackInBackground(videoContainer, generation);

      return data;
    } catch (error) {
      if (generation === viewGeneration) {
        attachMode = "normal";
        startupPhase.value = "idle";
      }
      if (startedSessionId) {
        try {
          await remoteViewApi.stop(deviceId, startedSessionId, { hard: true });
        } catch {
          // ignore cleanup errors
        }
      }
      if (generation === viewGeneration) {
        sessionInfo.value = null;
        sessionStatus.value = "";
      }
      throw error;
    }
  };

  // Called under withConnectionLock from RemoteScreenManager (onQualityChange).
  const setQuality = async (
    deviceId: string,
    quality: "weak" | "auto" | "strong",
  ) => {
    const sessionId = sessionInfo.value?.sessionId;
    if (!sessionId) throw new Error("No active remote view session");
    await switchQuality(deviceId, quality, sessionId, viewGeneration);
  };

  // Called under withConnectionLock from RemoteScreenManager (disconnect / unmount).
  const stopView = async (
    deviceId: string,
    opts?: { hardStop?: boolean },
  ) => {
    remoteViewLifecycleDiag("view-stop-begin", {
      sessionId: sessionInfo.value?.sessionId,
      trackSid: lastTrackSid || "-",
      hardStop: opts?.hardStop ?? false,
    });
    viewGeneration += 1;
    const generation = viewGeneration;
    resetDeadFrameRecoveryState();
    cancelLivePlaybackWatchdog();
    clearViewerTokenRefresh();
    attachMode = "normal";
    reconnectAttempts = MAX_RECONNECT;
    clearReconnectTimer();
    const container = activeVideoContainer;
    const sessionId = sessionInfo.value?.sessionId;
    const lkRoom = room.value;
    if (lkRoom) {
      try {
        await lkRoom.disconnect();
      } catch {
        // ignore
      }
      if (room.value === lkRoom) {
        room.value = null;
      }
    }
    if (generation !== viewGeneration) return;
    clearVideoContainer(container);
    activeVideoContainer = null;
    lastTrackSid = "";
    if (sessionId) {
      try {
        await remoteViewApi.stop(deviceId, sessionId, { hard: opts?.hardStop ?? false });
      } catch {
        // ignore duplicate stop
      }
    }
    if (generation !== viewGeneration) return;
    sessionInfo.value = null;
    sessionStatus.value = "";
    startupPhase.value = "idle";
    connectionState.value = ConnectionState.Disconnected;
    stats.value = { fps: 0, bitrateKbps: 0, encoder: "" };
  };

  /**
   * Hard tear-down + fresh start after dead-frame recovery is exhausted.
   * Must be invoked under withConnectionLock (same as startView/stopView).
   */
  const retryFreshView = async (
    deviceId: string,
    videoContainer: HTMLElement,
    quality: "weak" | "auto" | "strong" = "strong",
  ) => {
    resetDeadFrameRecoveryState();
    await stopView(deviceId, { hardStop: true });
    await startView(deviceId, videoContainer, quality);
  };

  const refreshStatus = async (deviceId: string) => {
    const generation = viewGeneration;
    const { data } = await remoteViewApi.getStatus(deviceId);
    if (generation !== viewGeneration) return data;
    sessionStatus.value = data.status || (data.isActive ? "active" : "");
    if (data.statsFresh && data.stats) {
      stats.value = {
        fps: data.stats.fps,
        bitrateKbps: data.stats.bitrateKbps,
        encoder: data.stats.encoder,
      };
    } else if (!data.isActive) {
      stats.value = { fps: 0, bitrateKbps: 0, encoder: "" };
    }
    return data;
  };

  const applyRemoteStats = (payload: {
    fps?: number;
    bitrateKbps?: number;
    encoder?: string;
  }) => {
    stats.value = {
      fps: payload.fps ?? stats.value.fps,
      bitrateKbps: payload.bitrateKbps ?? stats.value.bitrateKbps,
      encoder: payload.encoder ?? stats.value.encoder,
    };
  };

  return {
    room,
    connectionState,
    sessionInfo,
    sessionStatus,
    startupPhase,
    playbackDegraded,
    stats,
    startView,
    setQuality,
    stopView,
    retryFreshView,
    refreshStatus,
    applyRemoteStats,
    resumeView,
    withConnectionLock,
  };
}

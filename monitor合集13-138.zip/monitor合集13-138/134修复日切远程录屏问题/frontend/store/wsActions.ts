/** WebSocket actions bridge to avoid user <-> websocket circular imports. */

type WsActions = {
  connect: (token: string) => void;
  disconnect: () => void;
  isConnected: () => boolean;
};

let actions: WsActions | null = null;

export function registerWebSocketActions(next: WsActions) {
  actions = next;
}

export function connectRegisteredWebSocket(token: string) {
  if (!actions || !token) return;
  if (actions.isConnected()) {
    actions.disconnect();
  }
  actions.connect(token);
}

export function disconnectRegisteredWebSocket() {
  actions?.disconnect();
}

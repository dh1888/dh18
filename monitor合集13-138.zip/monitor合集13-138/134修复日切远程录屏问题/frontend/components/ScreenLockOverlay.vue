<template>
  <Teleport to="body">
    <transition name="lock-fade">
      <div v-if="visible" class="screen-lock-overlay">
        <div class="lock-bg">
          <template v-if="bgImages.length">
            <div
              v-for="(img, i) in bgImages"
              :key="img"
              class="lock-photo"
              :class="{ 'is-active': i === photoIndex }"
              :style="{ backgroundImage: `url(${img})` }"
            ></div>
            <div class="lock-photo-overlay"></div>
          </template>
          <template v-else>
            <div class="lock-orb lock-orb--a"></div>
            <div class="lock-orb lock-orb--b"></div>
          </template>
          <div class="lock-grid"></div>
        </div>

        <div class="screen-lock-panel">
          <div class="lock-clock">
            <span class="lock-clock__time">{{ timeString }}</span>
            <span class="lock-clock__date">{{ dateString }}</span>
          </div>

          <div class="lock-divider"></div>

          <div class="lock-identity">
            <div class="lock-avatar-wrap">
              <div class="lock-avatar-ring"></div>
              <img v-if="avatarUrl" :src="avatarUrl" alt="" class="lock-avatar lock-avatar--img" />
              <div v-else class="lock-avatar">{{ avatarInitial }}</div>
              <div class="lock-badge">
                <el-icon :size="14"><Lock /></el-icon>
              </div>
            </div>
            <h2 class="screen-lock-title">工作台已锁定</h2>
            <p class="screen-lock-subtitle">{{ username || "当前用户" }}</p>
          </div>

          <el-form @submit.prevent="submitUnlock" class="lock-form">
            <el-input
              ref="passwordInputRef"
              v-model="password"
              type="password"
              show-password
              placeholder="请输入锁屏密码"
              size="large"
              class="screen-lock-input"
              :class="{ 'is-shaking': shake }"
              :disabled="loading"
              @keyup.enter="submitUnlock"
              @animationend="shake = false"
            >
              <template #prefix>
                <el-icon><Lock /></el-icon>
              </template>
            </el-input>
            <el-button
              type="primary"
              size="large"
              class="screen-lock-btn"
              :loading="loading"
              @click="submitUnlock"
            >
              解锁
            </el-button>
          </el-form>

          <p v-if="errorMessage" class="screen-lock-error">
            <el-icon :size="14"><WarningFilled /></el-icon>
            {{ errorMessage }}
          </p>

          <p class="lock-hint">忘记密码请联系管理员协助解锁</p>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, watch, computed, nextTick, onMounted, onBeforeUnmount } from "vue";
import { Lock, WarningFilled } from "@element-plus/icons-vue";
import { userApi } from "@api/index";
import { clearScreenLocked } from "@/utils/screenLock";

const props = defineProps<{
  visible: boolean;
  username?: string;
  /** 兼容旧用法:单张背景图 */
  backgroundImage?: string;
  /** 多张背景图,自动轮播 */
  backgroundImages?: string[];
  /** 轮播间隔(毫秒),默认 10000 */
  backgroundInterval?: number;
  /** 头像图片地址,不传则显示用户名首字母 */
  avatarUrl?: string;
}>();

const emit = defineEmits<{
  unlocked: [];
}>();

const password = ref("");
const loading = ref(false);
const errorMessage = ref("");
const passwordInputRef = ref();
const shake = ref(false);

const now = ref(new Date());
let clockTimer: number | undefined;

onMounted(() => {
  clockTimer = window.setInterval(() => {
    now.value = new Date();
  }, 1000);
});

onBeforeUnmount(() => {
  if (clockTimer) {
    window.clearInterval(clockTimer);
  }
});

const timeString = computed(() => {
  const d = now.value;
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  const ss = String(d.getSeconds()).padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
});

const weekdayLabels = ["日", "一", "二", "三", "四", "五", "六"];
const dateString = computed(() => {
  const d = now.value;
  return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日 星期${weekdayLabels[d.getDay()]}`;
});

const avatarInitial = computed(() => {
  const name = (props.username || "").trim();
  return name ? name.charAt(0).toUpperCase() : "U";
});

const bgImages = computed(() => {
  if (props.backgroundImages && props.backgroundImages.length) {
    return props.backgroundImages;
  }
  return props.backgroundImage ? [props.backgroundImage] : [];
});

const photoIndex = ref(0);
let photoTimer: number | undefined;

function stopPhotoRotation() {
  if (photoTimer) {
    window.clearInterval(photoTimer);
    photoTimer = undefined;
  }
}

function startPhotoRotation() {
  stopPhotoRotation();
  if (bgImages.value.length <= 1) return;
  const interval = props.backgroundInterval || 10000;
  photoTimer = window.setInterval(() => {
    photoIndex.value = (photoIndex.value + 1) % bgImages.value.length;
  }, interval);
}

onBeforeUnmount(() => {
  stopPhotoRotation();
});

watch(
  () => props.visible,
  (v) => {
    if (v) {
      password.value = "";
      errorMessage.value = "";
      if (bgImages.value.length) {
        const key = "lockBgIndex";
        const last = Number(window.localStorage.getItem(key) || "0");
        const nextStart = bgImages.value.length ? last % bgImages.value.length : 0;
        photoIndex.value = nextStart;
        window.localStorage.setItem(key, String(nextStart + 1));
      }
      startPhotoRotation();
      nextTick(() => {
        passwordInputRef.value?.focus?.();
      });
    } else {
      stopPhotoRotation();
    }
  },
);

watch(errorMessage, (v) => {
  if (v) {
    shake.value = false;
    nextTick(() => {
      shake.value = true;
    });
  }
});

async function submitUnlock() {
  if (loading.value) return;
  const pwd = password.value.trim();
  if (!pwd) {
    errorMessage.value = "请输入锁屏密码";
    return;
  }
  loading.value = true;
  errorMessage.value = "";
  try {
    await userApi.verifyScreenLockPassword({ password: pwd });
    clearScreenLocked();
    password.value = "";
    emit("unlocked");
  } catch (e: any) {
    errorMessage.value = e?.message || "解锁失败";
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
@import url("https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&display=swap");

.lock-fade-enter-active,
.lock-fade-leave-active {
  transition: opacity 0.35s ease;
}
.lock-fade-enter-from,
.lock-fade-leave-to {
  opacity: 0;
}

.screen-lock-overlay {
  position: fixed;
  inset: 0;
  z-index: 10000;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  background: #0a0e1a;
}

.lock-bg {
  position: absolute;
  inset: 0;
  overflow: hidden;
}

.lock-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(90px);
  opacity: 0.45;
  animation: drift 16s ease-in-out infinite;
}

.lock-orb--a {
  width: 480px;
  height: 480px;
  top: -120px;
  left: -100px;
  background: radial-gradient(circle, #4a5cff 0%, transparent 70%);
}

.lock-orb--b {
  width: 420px;
  height: 420px;
  bottom: -140px;
  right: -80px;
  background: radial-gradient(circle, #2fd9c4 0%, transparent 70%);
  animation-delay: -8s;
}

@keyframes drift {
  0%, 100% { transform: translate(0, 0) scale(1); }
  50% { transform: translate(40px, 30px) scale(1.08); }
}

.lock-grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(148, 163, 220, 0.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(148, 163, 220, 0.06) 1px, transparent 1px);
  background-size: 42px 42px;
  mask-image: radial-gradient(circle at center, black 0%, transparent 75%);
}

.lock-photo {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: center;
  opacity: 0;
  transition: opacity 1.2s ease;
}

.lock-photo.is-active {
  opacity: 1;
}

.lock-photo-overlay {
  position: absolute;
  inset: 0;
  background:
    linear-gradient(180deg, rgba(6, 9, 18, 0.2) 0%, rgba(6, 9, 18, 0.32) 60%, rgba(6, 9, 18, 0.48) 100%);
}

.screen-lock-panel {
  position: relative;
  z-index: 1;
  width: min(400px, 92vw);
  padding: 36px 32px 28px;
  text-align: center;
  background: rgba(19, 27, 46, 0.62);
  border: 1px solid rgba(148, 163, 220, 0.16);
  border-radius: 20px;
  backdrop-filter: blur(20px);
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.45);
}

.lock-clock {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 20px;
}

.lock-clock__time {
  font-family: "JetBrains Mono", "SFMono-Regular", Consolas, monospace;
  font-size: 40px;
  font-weight: 500;
  letter-spacing: 2px;
  color: #eef1fc;
  line-height: 1.1;
  font-variant-numeric: tabular-nums;
}

.lock-clock__date {
  margin-top: 6px;
  font-size: 13px;
  letter-spacing: 1px;
  color: #7d87ab;
}

.lock-divider {
  height: 1px;
  margin: 0 auto 20px;
  width: 64px;
  background: linear-gradient(90deg, transparent, rgba(148, 163, 220, 0.4), transparent);
}

.lock-identity {
  margin-bottom: 24px;
}

.lock-avatar-wrap {
  position: relative;
  width: 76px;
  height: 76px;
  margin: 0 auto 16px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.lock-avatar-ring {
  position: absolute;
  inset: -8px;
  border-radius: 50%;
  border: 1px solid rgba(108, 140, 255, 0.35);
  animation: breathe 3s ease-in-out infinite;
}

@keyframes breathe {
  0%, 100% { transform: scale(0.94); opacity: 0.35; }
  50% { transform: scale(1.08); opacity: 0.9; }
}

.lock-avatar {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  font-weight: 600;
  color: #eef1fc;
  background: linear-gradient(145deg, #4a5cff, #2fd9c4);
}

.lock-avatar--img {
  object-fit: cover;
  border: 2px solid rgba(255, 255, 255, 0.15);
}

.lock-badge {
  position: absolute;
  right: -2px;
  bottom: -2px;
  width: 26px;
  height: 26px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #0a0e1a;
  background: #eef1fc;
  border: 3px solid #131b2e;
}

.screen-lock-title {
  margin: 0 0 6px;
  font-size: 19px;
  font-weight: 600;
  color: #eef1fc;
}

.screen-lock-subtitle {
  margin: 0;
  font-size: 13px;
  color: #7d87ab;
}

.lock-form {
  margin-bottom: 4px;
}

.screen-lock-input {
  margin-bottom: 14px;
}

.screen-lock-input :deep(.el-input__wrapper) {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(148, 163, 220, 0.18);
  box-shadow: none;
  border-radius: 10px;
  padding: 4px 14px;
}

.screen-lock-input :deep(.el-input__wrapper.is-focus) {
  border-color: rgba(108, 140, 255, 0.65);
  background: rgba(255, 255, 255, 0.08);
}

.screen-lock-input :deep(.el-input__inner) {
  color: #eef1fc;
}

.screen-lock-input :deep(.el-input__inner::placeholder) {
  color: #5b6488;
}

.screen-lock-input :deep(.el-input__prefix),
.screen-lock-input :deep(.el-input__suffix) {
  color: #7d87ab;
}

.screen-lock-input.is-shaking {
  animation: shake 0.4s ease;
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  20% { transform: translateX(-8px); }
  40% { transform: translateX(6px); }
  60% { transform: translateX(-4px); }
  80% { transform: translateX(2px); }
}

.screen-lock-btn {
  width: 100%;
  height: 44px;
  font-weight: 600;
  letter-spacing: 1px;
  border: none;
  border-radius: 10px;
  background: linear-gradient(135deg, #4a5cff, #2fd9c4);
  transition: filter 0.2s ease, transform 0.15s ease;
}

.screen-lock-btn:hover {
  filter: brightness(1.08);
}

.screen-lock-btn:active {
  transform: scale(0.98);
}

.screen-lock-error {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  margin: 14px 0 0;
  font-size: 13px;
  color: #ff8080;
}

.lock-hint {
  margin: 20px 0 0;
  font-size: 12px;
  color: #4a5372;
}

@media (max-width: 420px) {
  .lock-clock__time {
    font-size: 34px;
  }
  .screen-lock-panel {
    padding: 28px 22px 22px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .lock-orb,
  .lock-avatar-ring {
    animation: none;
  }
  .screen-lock-input.is-shaking {
    animation: none;
  }
  .lock-photo {
    transition: none;
  }
}
</style>
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

public sealed class TgActivityTypeItem
{
    public string Code { get; init; } = string.Empty;
    public string Name { get; init; } = string.Empty;
    public int TimeLimitSeconds { get; init; }
    public int MaxTimesPerDay { get; init; }
    public int TodayCount { get; init; }
    public int SortOrder { get; init; }
}

public sealed class TgPunchDashboard
{
    public bool LoggedIn { get; set; }
    public bool WorkSessionOpen { get; set; }
    public string? WorkShiftType { get; set; }
    public bool DualShiftEnabled { get; set; }
    public TgOpenActivity? OpenActivity { get; set; }
    public List<TgActivityTypeItem> ActivityTypes { get; set; } = new();
    public List<TgPunchRecord> Records { get; set; } = new();
    public double TodayFineTotal { get; set; }
}

public sealed class TgOpenActivity
{
    public string SessionId { get; init; } = string.Empty;
    public string ActivityName { get; init; } = string.Empty;
    public string? StartedAt { get; init; }
    public int LimitSeconds { get; init; }
}

public sealed class TgPunchRecord
{
    public string Time { get; init; } = string.Empty;
    public string Event { get; init; } = string.Empty;
    public string Detail { get; init; } = string.Empty;
    public string Status { get; init; } = string.Empty;
    public string Source { get; init; } = string.Empty;
    public string? SessionId { get; init; }
    public double FineAmount { get; init; }
}

public sealed class TgPunchService
{
    private readonly ILogger<TgPunchService> _logger;
    private readonly IHttpClientFactory _httpFactory;
    private readonly IAuthTokenProvider _authTokenProvider;
    private Func<string>? _serverUrlResolver;
    private TgPunchDashboard? _cachedDashboard;

    public TgPunchDashboard? CachedDashboard => _cachedDashboard;

    public event EventHandler<TgActivitySyncEventArgs>? ActivitySyncChanged;

    public TgPunchService(
        ILogger<TgPunchService> logger,
        IHttpClientFactory httpFactory,
        IAuthTokenProvider authTokenProvider)
    {
        _logger = logger;
        _httpFactory = httpFactory;
        _authTokenProvider = authTokenProvider;
    }

    public void SetServerUrlResolver(Func<string> resolver) => _serverUrlResolver = resolver;

    public void HandleActivityStateSync(TgActivitySyncEventArgs args)
    {
        _logger.LogDebug(
            "Activity state sync from server: open={Open} source={Source} activity={Activity}",
            args.Open,
            args.Source,
            args.ActivityName);

        _cachedDashboard ??= new TgPunchDashboard
        {
            LoggedIn = true,
            Records = new List<TgPunchRecord>()
        };

        if (args.Open)
        {
            var name = args.ActivityName;
            if (string.IsNullOrWhiteSpace(name))
                name = args.ActivityCode;

            _cachedDashboard.OpenActivity = new TgOpenActivity
            {
                SessionId = args.SessionId ?? string.Empty,
                ActivityName = name ?? string.Empty,
                StartedAt = args.StartedAt,
                LimitSeconds = args.LimitSeconds
            };
        }
        else
        {
            _cachedDashboard.OpenActivity = null;
        }

        ActivitySyncChanged?.Invoke(this, args);
    }

    public async Task<TgPunchDashboard?> GetDashboardAsync(CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return null;

        using var request = new HttpRequestMessage(HttpMethod.Get, $"{GetServerUrl()}/api/v1/agent/tg-dashboard");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning("TG dashboard failed: {Status} {Body}", response.StatusCode, body);
            return null;
        }

        try
        {
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return null;

            var dash = ParseDashboard(data);
            if (dash != null)
            {
                if (dash.Records.Count == 0 && _cachedDashboard?.Records.Count > 0)
                {
                    dash.Records = new List<TgPunchRecord>(_cachedDashboard.Records);
                }
                if (dash.Records.Count > 0 || dash.WorkSessionOpen || dash.OpenActivity != null)
                    _cachedDashboard = CloneDashboard(dash);
            }

            return dash ?? (_cachedDashboard != null ? CloneDashboard(_cachedDashboard) : null);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to parse TG dashboard");
            return _cachedDashboard != null ? CloneDashboard(_cachedDashboard) : null;
        }
    }

    public void RememberLocalRecord(TgPunchRecord record)
    {
        _cachedDashboard ??= new TgPunchDashboard { LoggedIn = true, Records = new List<TgPunchRecord>() };
        _cachedDashboard.Records.Insert(0, record);
        while (_cachedDashboard.Records.Count > 30)
            _cachedDashboard.Records.RemoveAt(_cachedDashboard.Records.Count - 1);
    }

    public void UpdateCachedOpenActivity(TgOpenActivity? openActivity)
    {
        if (_cachedDashboard == null && openActivity == null)
            return;

        _cachedDashboard ??= new TgPunchDashboard
        {
            LoggedIn = true,
            WorkSessionOpen = true,
            Records = new List<TgPunchRecord>()
        };
        _cachedDashboard.OpenActivity = openActivity;
    }

    private static TgPunchDashboard ParseDashboard(JsonElement data)
    {
        var dash = new TgPunchDashboard
        {
            LoggedIn = data.TryGetProperty("loggedIn", out var li) && li.GetBoolean(),
            WorkSessionOpen = data.TryGetProperty("workSessionOpen", out var wso) && wso.GetBoolean(),
            WorkShiftType = data.TryGetProperty("workShiftType", out var wst) ? wst.GetString() : null,
            DualShiftEnabled = data.TryGetProperty("dualShiftEnabled", out var dse) && dse.GetBoolean(),
            TodayFineTotal = data.TryGetProperty("todayFineTotal", out var tft) && tft.TryGetDouble(out var fine)
                ? fine
                : 0
        };

        if (data.TryGetProperty("openActivity", out var oa) && oa.ValueKind == JsonValueKind.Object)
        {
            dash.OpenActivity = new TgOpenActivity
            {
                SessionId = oa.TryGetProperty("sessionId", out var sid) ? sid.GetString() ?? "" : "",
                ActivityName = oa.TryGetProperty("activityName", out var an) ? an.GetString() ?? "" : "",
                StartedAt = oa.TryGetProperty("startedAt", out var sa) ? sa.GetString() : null,
                LimitSeconds = oa.TryGetProperty("limitSeconds", out var ls) && ls.TryGetInt32(out var lim)
                    ? lim
                    : 0
            };
        }

        if (data.TryGetProperty("records", out var records) && records.ValueKind == JsonValueKind.Array)
        {
            var list = new List<TgPunchRecord>();
            foreach (var item in records.EnumerateArray())
            {
                list.Add(new TgPunchRecord
                {
                    Time = item.TryGetProperty("time", out var t) ? t.GetString() ?? "" : "",
                    Event = item.TryGetProperty("event", out var ev) ? ev.GetString() ?? "" : "",
                    Detail = item.TryGetProperty("detail", out var d) ? d.GetString() ?? "" : "",
                    Status = item.TryGetProperty("status", out var st) ? st.GetString() ?? "" : "",
                    Source = item.TryGetProperty("source", out var src) ? src.GetString() ?? "" : "",
                    SessionId = item.TryGetProperty("sessionId", out var rsid) ? rsid.GetString() : null,
                    FineAmount = item.TryGetProperty("fineAmount", out var fa) && fa.TryGetDouble(out var fam)
                        ? fam
                        : 0
                });
            }
            dash.Records = list;
        }

        if (data.TryGetProperty("activityTypes", out var activityTypes) &&
            activityTypes.ValueKind == JsonValueKind.Array)
        {
            var types = new List<TgActivityTypeItem>();
            foreach (var item in activityTypes.EnumerateArray())
            {
                types.Add(new TgActivityTypeItem
                {
                    Code = item.TryGetProperty("code", out var code) ? code.GetString() ?? "" : "",
                    Name = item.TryGetProperty("name", out var name) ? name.GetString() ?? "" : "",
                    TimeLimitSeconds = item.TryGetProperty("timeLimitSeconds", out var ls) && ls.TryGetInt32(out var lim)
                        ? lim
                        : 0,
                    MaxTimesPerDay = item.TryGetProperty("maxTimesPerDay", out var mt) && mt.TryGetInt32(out var max)
                        ? max
                        : 0,
                    TodayCount = item.TryGetProperty("todayCount", out var tc) && tc.TryGetInt32(out var used)
                        ? used
                        : 0,
                    SortOrder = item.TryGetProperty("sortOrder", out var so) && so.TryGetInt32(out var order)
                        ? order
                        : 0,
                });
            }
            dash.ActivityTypes = types;
        }

        return dash;
    }

    private static TgPunchDashboard CloneDashboard(TgPunchDashboard source)
        => new()
        {
            LoggedIn = source.LoggedIn,
            WorkSessionOpen = source.WorkSessionOpen,
            WorkShiftType = source.WorkShiftType,
            DualShiftEnabled = source.DualShiftEnabled,
            TodayFineTotal = source.TodayFineTotal,
            OpenActivity = source.OpenActivity,
            ActivityTypes = new List<TgActivityTypeItem>(source.ActivityTypes),
            Records = new List<TgPunchRecord>(source.Records)
        };

    public async Task<(bool Success, string Message, TgOpenActivity? OpenActivity)> StartActivityAsync(
        string activity,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(activity))
            return (false, "活动类型无效", null);

        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return (false, "请先登录员工账号", null);

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/activity/start");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
        request.Content = new StringContent(
            JsonSerializer.Serialize(new { activity }),
            Encoding.UTF8,
            "application/json");

        var (success, message, openActivity) = await ParseSessionActionResponseAsync(request, ct, "活动已开始");
        if (success && openActivity != null)
            ApplyOpenActivityToCache(openActivity);

        return (success, message, openActivity);
    }

    public async Task<(bool Success, string Message)> ActivityBackAsync(string? sessionId = null, CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return (false, "请先登录员工账号");

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/activity/back");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
        var payload = string.IsNullOrWhiteSpace(sessionId)
            ? "{}"
            : JsonSerializer.Serialize(new { sessionId });
        request.Content = new StringContent(payload, Encoding.UTF8, "application/json");

        var (success, message, _) = await ParseSessionActionResponseAsync(request, ct, "回座完成");
        if (success && _cachedDashboard != null)
            _cachedDashboard.OpenActivity = null;

        return (success, message);
    }

    private void ApplyOpenActivityToCache(TgOpenActivity openActivity)
    {
        _cachedDashboard ??= new TgPunchDashboard
        {
            LoggedIn = true,
            WorkSessionOpen = true,
            Records = new List<TgPunchRecord>()
        };
        _cachedDashboard.OpenActivity = openActivity;
    }

    private static TgOpenActivity? ParseOpenActivityFromSessionJson(JsonElement data)
    {
        if (data.ValueKind != JsonValueKind.Object)
            return null;

        var hasSession = data.TryGetProperty("sessionId", out var sidProp) &&
                         sidProp.ValueKind == JsonValueKind.String;
        var hasStarted = data.TryGetProperty("startedAt", out var startedProp) &&
                         startedProp.ValueKind == JsonValueKind.String;
        if (!hasSession && !hasStarted)
            return null;

        var activityName = data.TryGetProperty("activityName", out var nameProp)
            ? nameProp.GetString() ?? string.Empty
            : string.Empty;
        if (string.IsNullOrWhiteSpace(activityName) &&
            data.TryGetProperty("activityCode", out var codeProp))
        {
            activityName = codeProp.GetString() ?? string.Empty;
        }

        return new TgOpenActivity
        {
            SessionId = hasSession ? sidProp.GetString() ?? string.Empty : string.Empty,
            ActivityName = activityName,
            StartedAt = hasStarted ? startedProp.GetString() : null,
            LimitSeconds = data.TryGetProperty("limitSeconds", out var limitProp) &&
                           limitProp.TryGetInt32(out var limit)
                ? limit
                : 0
        };
    }

    private async Task<(bool Success, string Message, TgOpenActivity? OpenActivity)> ParseSessionActionResponseAsync(
        HttpRequestMessage request,
        CancellationToken ct,
        string successFallback)
    {
        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        try
        {
            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            var message = root.TryGetProperty("message", out var msgProp)
                ? msgProp.GetString() ?? string.Empty
                : string.Empty;

            if (!response.IsSuccessStatusCode)
                return (false, string.IsNullOrWhiteSpace(message) ? "操作失败" : message, null);

            TgOpenActivity? openActivity = null;
            var displayMessage = string.IsNullOrWhiteSpace(message) ? successFallback : message;

            if (root.TryGetProperty("data", out var data))
            {
                openActivity = ParseOpenActivityFromSessionJson(data);
                if (data.TryGetProperty("messageText", out var textProp))
                {
                    var text = textProp.GetString();
                    if (!string.IsNullOrWhiteSpace(text))
                        displayMessage = text;
                }
            }

            return (true, displayMessage, openActivity);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to parse TG punch action response");
            if (!response.IsSuccessStatusCode && !string.IsNullOrWhiteSpace(body))
            {
                try
                {
                    using var doc = JsonDocument.Parse(body);
                    if (doc.RootElement.TryGetProperty("message", out var msgProp))
                    {
                        var msg = msgProp.GetString();
                        if (!string.IsNullOrWhiteSpace(msg))
                            return (false, msg, null);
                    }
                }
                catch
                {
                    // ignore secondary parse errors
                }
            }

            if (ex is TaskCanceledException or OperationCanceledException)
                return (false, "请求超时，请稍后重试", null);
            return response.IsSuccessStatusCode ? (true, successFallback, null) : (false, "操作失败", null);
        }
    }

    private string GetServerUrl() => _serverUrlResolver?.Invoke() ?? "http://localhost:8080";
}

public sealed class TgActivitySyncEventArgs : EventArgs
{
    public bool Open { get; init; }
    public string? Source { get; init; }
    public string? ActivityName { get; init; }
    public string? ActivityCode { get; init; }
    public string? SessionId { get; init; }
    public string? StartedAt { get; init; }
    public int LimitSeconds { get; init; }

    public bool IsRemoteSource =>
        string.Equals(Source, "telegram", StringComparison.OrdinalIgnoreCase)
        || string.Equals(Source, "system", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Whether to show a desktop toast for this sync (avoid duplicate toast after local PC 回座).
    /// </summary>
    public bool ShouldNotifyDesktop =>
        Open
            ? IsRemoteSource
            : !string.Equals(Source, "agent", StringComparison.OrdinalIgnoreCase);
}

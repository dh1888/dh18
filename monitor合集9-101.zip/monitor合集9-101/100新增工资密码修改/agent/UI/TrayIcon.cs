// UI/TrayIcon.cs - 完整版（支持开机自启动 + 多语言 + 打开日志）

using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Extensions.Logging;
using EnterpriseAgent.Agent.Services;
using DrawingColor = System.Drawing.Color;
using DrawingPointF = System.Drawing.PointF; 

namespace EnterpriseAgent.Agent.UI;

public class TrayIcon : IDisposable
{
    private readonly ILogger<TrayIcon>? _logger;
    private readonly NotifyIcon _notifyIcon;
    private readonly ContextMenuStrip _contextMenu;
    private readonly Form _uiSyncForm;
    private readonly Action _onExit;
    private readonly Func<bool> _isConnected;
    private readonly Func<string> _getDeviceId;
    private readonly Func<string> _getServerUrl;
    private readonly ILocalizationService? _localization;
    private StatusForm? _statusForm;
    private bool _disposed;
    
    // 服务状态
    private bool _isRecording;
    private bool _isScreenshotting;
    private bool _isUploading;
    
    // 菜单项
    private ToolStripMenuItem? _autoStartItem;
    private ToolStripMenuItem? _forceDirectNetworkItem;
    private ToolStripMenuItem? _statusItem;
    private ToolStripMenuItem? _employeeItem;
    private ToolStripMenuItem? _showStatusItem;
    private ToolStripMenuItem? _exitItem;
    private ToolStripMenuItem? _loginItem;
    private ToolStripMenuItem? _logoutItem;
    private ToolStripMenuItem? _settingsMenu;
    private ToolStripMenuItem? _languageMenu;
    
    private ToolStripMenuItem? _checkInItem;
    private ToolStripMenuItem? _checkInDayItem;
    private ToolStripMenuItem? _checkInNightItem;
    private ToolStripMenuItem? _checkOutItem;
    private ToolStripMenuItem? _bindTelegramItem;
    private readonly Func<Task<bool>>? _onCheckIn;
    private readonly Func<string, Task<bool>>? _onCheckInShift;
    private readonly Func<Task<bool>>? _onCheckOut;
    private readonly Func<Task<bool>>? _onEmployeeLogin;
    private readonly Func<Task<bool>>? _onEmployeeLogout;
    private readonly Func<Task<bool>>? _onBindInvite;
    private readonly Func<Task<bool>>? _onBindTelegram;
    private readonly Func<EmployeeTrayStatus>? _getEmployeeStatus;
    private readonly Func<bool>? _getHasOpenSession;
    private readonly Func<bool>? _getDualShiftEnabled;
    private readonly Func<Task<TelegramBindStatus>>? _getTelegramBindStatusAsync;
    private readonly AgentNotificationService? _agentNotification;
    private readonly TgPunchService? _tgPunchService;
    private readonly Func<Task>? _onCheckForUpdates;
    private readonly Func<bool>? _getForceDirectConnection;
    private readonly Func<bool, Task<bool>>? _onForceDirectConnectionChanged;
    private readonly ClientProtectionService? _clientProtection;

    private TrayPunchPanelForm? _punchPanel;
    private readonly System.Windows.Forms.Timer _singleClickTimer;
    private DateTime _suppressPunchPanelUntilUtc = DateTime.MinValue;
    private int _pendingLeftClickCount;
    private const int SingleClickDelayMs = 100;
    private string _serviceStatusSuffix = "";
    private bool _telegramBound;
    private string _telegramUsername = "";
    private bool _telegramWorkstationChannel;
    private bool _telegramBoundLoading;
    private DateTime _telegramBoundCheckedAt = DateTime.MinValue;
    private static readonly TimeSpan TelegramStatusRefreshInterval = TimeSpan.FromSeconds(30);
    
    public TrayIcon(
        ILogger<TrayIcon>? logger,
        Action onExit,
        Func<bool> isConnected,
        Func<string> getDeviceId,
        Func<string> getServerUrl,
        ILocalizationService? localization = null,
        Func<Task<bool>>? onCheckIn = null,
        Func<Task<bool>>? onCheckOut = null,
        Func<Task<bool>>? onEmployeeLogin = null,
        Func<Task<bool>>? onEmployeeLogout = null,
        Func<EmployeeTrayStatus>? getEmployeeStatus = null,
        Func<Task<bool>>? onBindInvite = null,
        Func<Task<bool>>? onBindTelegram = null,
        Func<bool>? getHasOpenSession = null,
        Func<Task<TelegramBindStatus>>? getTelegramBindStatusAsync = null,
        Func<string, Task<bool>>? onCheckInShift = null,
        Func<bool>? getDualShiftEnabled = null,
        AgentNotificationService? agentNotification = null,
        TgPunchService? tgPunchService = null,
        Func<Task>? onCheckForUpdates = null,
        Func<bool>? getForceDirectConnection = null,
        Func<bool, Task<bool>>? onForceDirectConnectionChanged = null,
        ClientProtectionService? clientProtection = null)
    {
        _clientProtection = clientProtection;
        _logger = logger;
        _agentNotification = agentNotification;
        _tgPunchService = tgPunchService;
        _onCheckForUpdates = onCheckForUpdates;
        _getForceDirectConnection = getForceDirectConnection;
        _onForceDirectConnectionChanged = onForceDirectConnectionChanged;
        _onExit = onExit ?? throw new ArgumentNullException(nameof(onExit));
        _isConnected = isConnected ?? throw new ArgumentNullException(nameof(isConnected));
        _getDeviceId = getDeviceId ?? throw new ArgumentNullException(nameof(getDeviceId));
        _getServerUrl = getServerUrl ?? throw new ArgumentNullException(nameof(getServerUrl));
        _localization = localization;
        _onCheckIn = onCheckIn;
        _onCheckInShift = onCheckInShift;
        _onCheckOut = onCheckOut;
        _onEmployeeLogin = onEmployeeLogin;
        _onEmployeeLogout = onEmployeeLogout;
        _getEmployeeStatus = getEmployeeStatus;
        _onBindInvite = onBindInvite;
        _onBindTelegram = onBindTelegram;
        _getHasOpenSession = getHasOpenSession;
        _getDualShiftEnabled = getDualShiftEnabled;
        _getTelegramBindStatusAsync = getTelegramBindStatusAsync;

        if (_localization != null)
            _localization.LanguageChanged += HandleLanguageChanged;
        
        _singleClickTimer = new System.Windows.Forms.Timer { Interval = SingleClickDelayMs };
        _singleClickTimer.Tick += (_, _) =>
        {
            _singleClickTimer.Stop();
            if (DateTime.UtcNow < _suppressPunchPanelUntilUtc)
            {
                _pendingLeftClickCount = 0;
                return;
            }

            if (_pendingLeftClickCount == 1)
                RunOnUiThread(ShowPunchPanel);
            _pendingLeftClickCount = 0;
        };

        _uiSyncForm = new Form
        {
            ShowInTaskbar = false,
            FormBorderStyle = FormBorderStyle.None,
            Size = new Size(0, 0),
            Opacity = 0
        };
        _uiSyncForm.Load += (_, _) => _uiSyncForm.Hide();
        if (!_uiSyncForm.IsHandleCreated)
            _ = _uiSyncForm.Handle;
        
        _contextMenu = new ContextMenuStrip();
        BuildContextMenu();
        _contextMenu.Opening += (_, _) =>
        {
            CancelPendingLeftClick();
            _suppressPunchPanelUntilUtc = DateTime.UtcNow.AddMilliseconds(350);

            var loggedIn = _getEmployeeStatus?.Invoke().IsLoggedIn ?? false;
            if (loggedIn)
                _ = RefreshTelegramBoundAsync(loggedIn, force: true);
        };
        
        var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
        _notifyIcon = new NotifyIcon
        {
            Icon = GetAppIcon(),
            Text = appName,
            ContextMenuStrip = _contextMenu,
            Visible = true
        };
        
        _notifyIcon.DoubleClick += (_, _) => HandleTrayDoubleClick();
        _notifyIcon.MouseClick += (_, e) =>
        {
            if (e.Button == MouseButtons.Right)
            {
                CancelPendingLeftClick();
                return;
            }

            if (e.Button == MouseButtons.Left)
                HandleTrayLeftClick();
        };
        
        var timer = new System.Windows.Forms.Timer { Interval = 5000 };
        timer.Tick += (s, e) => UpdateTrayStatus();
        timer.Start();
        
        _logger?.LogInformation("Tray icon initialized");
    }

    private void CancelPendingLeftClick()
    {
        _singleClickTimer.Stop();
        _pendingLeftClickCount = 0;
    }

    private void HandleTrayLeftClick()
    {
        if (DateTime.UtcNow < _suppressPunchPanelUntilUtc)
            return;

        _pendingLeftClickCount++;
        _singleClickTimer.Stop();
        _singleClickTimer.Start();
    }

    private void HandleTrayDoubleClick()
    {
        CancelPendingLeftClick();
        _suppressPunchPanelUntilUtc = DateTime.UtcNow.AddMilliseconds(500);

        RunOnUiThread(() =>
        {
            if (_punchPanel != null && !_punchPanel.IsDisposed && _punchPanel.IsOpen)
                _punchPanel.HideToTray();
            ShowStatusWindow();
        });
    }

    public void NotifyAlreadyRunning()
    {
        RunOnUiThread(() =>
        {
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var message = _localization?.GetString("AlreadyRunning", "程序已在运行中，请勿重复打开。")
                ?? "程序已在运行中，请勿重复打开。";
            ShowUserNotification(appName, message, "info", durationSec: 8);
            _logger?.LogInformation("Blocked duplicate launch attempt");

            try
            {
                ShowStatusWindow();
            }
            catch (Exception ex)
            {
                _logger?.LogDebug(ex, "Could not bring status window forward on duplicate launch");
            }
        });
    }

    public void NotifyTelegramCheckIn()
    {
        RunOnUiThread(() =>
        {
            var title = _localization?.GetString("CheckInSuccess", "上班成功") ?? "上班成功";
            var message = _localization?.GetString("TelegramCheckInNotify", "已通过 Telegram 上班")
                ?? "已通过 Telegram 上班";
            ShowUserNotification(title, message, "success");
            _logger?.LogInformation("Telegram check-in notification shown");
        });
    }

    public void NotifyTelegramCheckOut()
    {
        RunOnUiThread(() =>
        {
            var title = _localization?.GetString("CheckOutSuccess", "下班成功") ?? "下班成功";
            var message = _localization?.GetString("TelegramCheckOutNotify", "已通过 Telegram 下班")
                ?? "已通过 Telegram 下班";
            ShowUserNotification(title, message, "success");
            _logger?.LogInformation("Telegram check-out notification shown");
        });
    }

    public void NotifyTelegramActivitySync(TgActivitySyncEventArgs e)
    {
        RunOnUiThread(() =>
        {
            var activity = string.IsNullOrWhiteSpace(e.ActivityName) ? "活动" : e.ActivityName.Trim();
            if (e.Open)
            {
                var title = _localization?.GetString("ActivityStartSuccess", "活动已开始") ?? "活动已开始";
                var template = _localization?.GetString("TelegramActivityStartedNotify", "已通过 Telegram 开始：{0}")
                    ?? "已通过 Telegram 开始：{0}";
                ShowUserNotification(title, string.Format(template, activity), "success", durationSec: 8);
                _logger?.LogInformation("Telegram activity start notification shown: {Activity}", activity);
                return;
            }

            var endTitle = _localization?.GetString("ActivityBackSuccess", "回座成功") ?? "回座成功";
            var endTemplate = string.Equals(e.Source, "system", StringComparison.OrdinalIgnoreCase)
                ? _localization?.GetString("TelegramActivityAutoEndedNotify", "活动已自动结束：{0}")
                  ?? "活动已自动结束：{0}"
                : _localization?.GetString("TelegramActivityEndedNotify", "已通过 Telegram 回座：{0}")
                  ?? "已通过 Telegram 回座：{0}";
            ShowUserNotification(endTitle, string.Format(endTemplate, activity), "success", durationSec: 8);
            _logger?.LogInformation("Telegram activity end notification shown: {Activity}", activity);
        });
    }

    private void ShowUserNotification(string title, string message, string level = "info", int durationSec = AgentNotificationService.LocalDurationSec)
    {
        if (_agentNotification != null)
        {
            _agentNotification.ShowLocal(title, message, level, durationSec);
            return;
        }

        var icon = level switch
        {
            "warning" => ToolTipIcon.Warning,
            "success" => ToolTipIcon.Info,
            _ => ToolTipIcon.Info
        };
        ShowBalloonTip(title, message, icon);
    }

    private void RunOnUiThread(Action action)
    {
        if (_uiSyncForm.IsHandleCreated && _uiSyncForm.InvokeRequired)
            _uiSyncForm.BeginInvoke(action);
        else
            action();
    }

    public void NotifyClientProtectionChanged() =>
        RunOnUiThread(BuildContextMenu);

    private async Task HandleExitClickAsync()
    {
        if (_clientProtection != null && !_clientProtection.CanUserExitNow())
        {
            var title = _localization?.GetString("ConfirmExit", "确认退出") ?? "确认退出";
            var lockedMsg = _localization?.GetString(
                "ClientProtectionExitLocked",
                "管理员已禁止退出客户端。如需退出请输入解锁码，或联系管理员在后台授予临时退出。")
                ?? "管理员已禁止退出客户端。如需退出请输入解锁码，或联系管理员在后台授予临时退出。";

            if (_clientProtection.GetSnapshot().UnlockCodeConfigured)
            {
                var code = PromptUnlockCode(title);
                if (string.IsNullOrWhiteSpace(code))
                    return;
                if (!await _clientProtection.TryVerifyUnlockCodeAsync(code))
                {
                    MessageBox.Show(
                        _localization?.GetString("ClientProtectionUnlockFailed", "解锁码不正确、已使用或已过期") ?? "解锁码不正确、已使用或已过期",
                        title,
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }
            }
            else
            {
                MessageBox.Show(
                    _localization?.GetString(
                        "ClientProtectionNoUnlockCode",
                        "当前没有有效的退出解锁码。请联系管理员在后台「员工管理 → 防护」中生成解锁码，或使用临时允许退出。")
                        ?? "当前没有有效的退出解锁码。请联系管理员在后台「员工管理 → 防护」中生成解锁码，或使用临时允许退出。",
                    title,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }
        }
        else
        {
            var confirm = _localization?.GetString("ExitConfirm", "确定要退出吗？") ?? "确定要退出吗？";
            var title = _localization?.GetString("ConfirmExit", "确认退出") ?? "确认退出";
            if (MessageBox.Show(confirm, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;
        }

        _logger?.LogInformation("Exit requested from tray menu");
        _clientProtection?.ConsumeExitOnceIfNeeded();
        _notifyIcon.Visible = false;
        _onExit();
    }

    private static string? PromptUnlockCode(string title)
    {
        using var form = new Form
        {
            Text = title,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            StartPosition = FormStartPosition.CenterScreen,
            MinimizeBox = false,
            MaximizeBox = false,
            ClientSize = new Size(360, 120),
        };
        var label = new Label { Text = "解锁码：", AutoSize = true, Location = new Point(12, 18) };
        var input = new TextBox { Location = new Point(12, 42), Width = 330, UseSystemPasswordChar = true };
        var ok = new Button { Text = "确定", DialogResult = DialogResult.OK, Location = new Point(180, 78), Width = 75 };
        var cancel = new Button { Text = "取消", DialogResult = DialogResult.Cancel, Location = new Point(265, 78), Width = 75 };
        form.Controls.AddRange(new Control[] { label, input, ok, cancel });
        form.AcceptButton = ok;
        form.CancelButton = cancel;
        return form.ShowDialog() == DialogResult.OK ? input.Text.Trim() : null;
    }
    
    /// <summary>
    /// 检查是否已开启开机自启动
    /// </summary>
    private bool IsAutoStartEnabled() => AutoStartManager.IsEnabled();

    private void SetAutoStart(bool enabled)
    {
        try
        {
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";

            if (enabled)
            {
                if (!AutoStartManager.Enable(_logger))
                {
                    ShowAutoStartDiagnosticDialog(repairOffer: true);
                    if (_autoStartItem != null)
                        _autoStartItem.Checked = AutoStartManager.IsEnabled();
                    _statusForm?.RefreshAutoStartState();
                    return;
                }

                _logger?.LogInformation("Auto-start enabled: {Path}", AutoStartManager.GetExecutablePath());
                var report = AutoStartManager.Diagnose(_logger, _localization);
                if (report.HasBlockingIssues)
                {
                    ShowAutoStartDiagnosticDialog(report, repairOffer: true);
                }
                else
                {
                    var message = report.ActiveChannel == AutoStartChannel.ScheduledTask
                        ? _localization?.GetString("AutoStartEnabledTask", "已开启登录自启动（计划任务，登录后约 15 秒）")
                            ?? "已开启登录自启动（计划任务，登录后约 15 秒）"
                        : _localization?.GetString("AutoStartEnabledRegistry", "已开启登录自启动（注册表，登录后）")
                            ?? "已开启登录自启动（注册表，登录后）";
                    var enableNotice = AutoStartManager.ResolveEnableNotice(_localization);
                    if (!string.IsNullOrWhiteSpace(enableNotice))
                        message = enableNotice;
                    ShowBalloonTip(appName, message, ToolTipIcon.Info);
                }
            }
            else
            {
                AutoStartManager.Disable(_logger);
                var message = _localization?.GetString("AutoStartDisabled", "已关闭开机自启动")
                    ?? "已关闭开机自启动";
                ShowBalloonTip(appName, message, ToolTipIcon.Info);
            }

            if (_autoStartItem != null)
                _autoStartItem.Checked = AutoStartManager.IsEnabled();

            _statusForm?.RefreshAutoStartState();
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Failed to set auto-start");
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            ShowAutoStartDiagnosticDialog(repairOffer: true);
            ShowBalloonTip(
                appName,
                _localization?.GetString("AutoStartFailed", "设置开机自启动失败，请检查权限")
                    ?? "设置开机自启动失败，请检查权限",
                ToolTipIcon.Error);
        }
    }

    public void ShowAutoStartDiagnosticDialog(AutoStartDiagnosticReport? report = null, bool repairOffer = false)
    {
        RunOnUiThread(() =>
        {
            report ??= AutoStartManager.Diagnose(_logger, _localization);
            var title = _localization?.GetString("AutoStartDiagnosticTitle", "登录自启动诊断") ?? "登录自启动诊断";
            var body = report.FormatSummary(_localization);

            if (repairOffer && report.HasBlockingIssues)
            {
                var prompt = _localization?.GetString("AutoStartRepairPrompt", "是否尝试自动修复？")
                    ?? "是否尝试自动修复？";
                var result = MessageBox.Show(
                    body + Environment.NewLine + Environment.NewLine + prompt,
                    title,
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);
                if (result == DialogResult.Yes && AutoStartManager.TryRepair(_logger))
                {
                    report = AutoStartManager.Diagnose(_logger, _localization);
                    body = report.FormatSummary(_localization);
                    MessageBox.Show(
                        body,
                        title,
                        MessageBoxButtons.OK,
                        report.HasBlockingIssues ? MessageBoxIcon.Warning : MessageBoxIcon.Information);
                }
                else if (result == DialogResult.Yes)
                {
                    MessageBox.Show(body, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                if (_autoStartItem != null)
                    _autoStartItem.Checked = AutoStartManager.IsEnabled();
                _statusForm?.RefreshAutoStartState();
                return;
            }

            MessageBox.Show(
                body,
                title,
                MessageBoxButtons.OK,
                report.HasBlockingIssues ? MessageBoxIcon.Warning : MessageBoxIcon.Information);
        });
    }
    
    /// <summary>
    /// 切换开机自启动状态
    /// </summary>
    private void ToggleAutoStart()
    {
        if (_clientProtection != null && !_clientProtection.CanToggleAutoStart())
        {
            var title = _localization?.GetString("Settings", "设置") ?? "设置";
            var message = _localization?.GetString(
                "ClientProtectionAutoStartLocked",
                "管理员已禁止修改登录自启动。") ?? "管理员已禁止修改登录自启动。";
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (_autoStartItem != null)
                _autoStartItem.Checked = IsAutoStartEnabled();
            return;
        }

        var newState = !IsAutoStartEnabled();
        SetAutoStart(newState);
    }

    private async Task ToggleForceDirectNetworkAsync()
    {
        if (_forceDirectNetworkItem == null || _onForceDirectConnectionChanged == null)
            return;

        var desired = _forceDirectNetworkItem.Checked;
        try
        {
            var ok = await _onForceDirectConnectionChanged(desired);
            if (!ok)
            {
                _forceDirectNetworkItem.Checked = !desired;
                var title = _localization?.GetString("Settings", "设置") ?? "设置";
                var message = _localization?.GetString(
                    "NetworkForceDirectSaveFailed",
                    "无法保存网络设置，请检查安装目录下的 appsettings.json 是否可写。")
                    ?? "无法保存网络设置，请检查安装目录下的 appsettings.json 是否可写。";
                MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Failed to toggle force-direct network");
            _forceDirectNetworkItem.Checked = !desired;
        }
    }
    
    private async Task RunUpdateCheckAsync()
    {
        if (_onCheckForUpdates == null)
            return;

        try
        {
            await _onCheckForUpdates();
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Manual update check failed");
            var title = _localization?.GetString("UpdateCheckFailedTitle", "检查更新") ?? "检查更新";
            var message = _localization?.GetString("UpdateCheckFailed", "无法检查更新，请稍后重试。") ?? "无法检查更新，请稍后重试。";
            ShowBalloonTip(title, message, ToolTipIcon.Error);
        }
    }

    /// <summary>
    /// 打开日志文件夹
    /// </summary>
    private void OpenLogFolder()
    {
        try
        {
            var logPath = AppPaths.GetLogsPath();
            foreach (var legacyPath in new[]
                     {
                         Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                             "EnterpriseAgent", "logs"),
                         Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs")
                     })
            {
                if (Directory.Exists(legacyPath))
                {
                    logPath = legacyPath;
                    break;
                }
            }
            
            // 打开资源管理器
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = $"\"{logPath}\"",
                UseShellExecute = true
            });
            
            _logger?.LogInformation("Opened log folder: {LogPath}", logPath);
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Failed to open log folder");
            
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var message = _localization?.GetString("OpenLogFailed", "无法打开日志文件夹") ?? "无法打开日志文件夹";
            ShowBalloonTip(appName, message, ToolTipIcon.Error);
        }
    }
    
    private async Task RunWorkAction(
        Func<Task<bool>> action,
        string successTitleKey,
        string successTitleDefault,
        string? successMessageKey = null,
        string? successMessageDefault = null,
        bool notifyOnSuccess = true)
    {
        try
        {
            var ok = await action();
            if (ok && notifyOnSuccess)
            {
                var title = _localization?.GetString(successTitleKey, successTitleDefault) ?? successTitleDefault;
                var message = successMessageKey != null
                    ? _localization?.GetString(successMessageKey, successMessageDefault ?? string.Empty) ?? successMessageDefault ?? string.Empty
                    : title;
                if (string.IsNullOrWhiteSpace(message))
                    message = title;
                ShowUserNotification(title, message, "success");
                InvalidateTelegramStatus();
                NotifyMenuStateChanged();
            }
            else if (ok)
            {
                InvalidateTelegramStatus();
                NotifyMenuStateChanged();
            }
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Work session action failed");
            var title = _localization?.GetString("Prompt", "提示") ?? "提示";
            var message = _localization?.GetString("ActionFailed", "操作失败，请查看日志") ?? "操作失败，请查看日志";
            ShowUserNotification(title, message, "warning");
        }
    }
    
    private void BuildContextMenu()
    {
        _contextMenu.Items.Clear();
        
        var statusLabel = _localization?.GetString("Status", "状态") ?? "状态";
        _statusItem = new ToolStripMenuItem($"{statusLabel}: …") { Enabled = false };
        _contextMenu.Items.Add(_statusItem);

        _employeeItem = new ToolStripMenuItem(FormatEmployeeLine(null)) { Enabled = false };
        _contextMenu.Items.Add(_employeeItem);
        _contextMenu.Items.Add(new ToolStripSeparator());

        if (_onEmployeeLogin != null)
        {
            var loginText = _localization?.GetString("EmployeeLogin", "员工登录") ?? "员工登录";
            _loginItem = new ToolStripMenuItem(loginText, null,
                async (s, e) => await RunWorkAction(_onEmployeeLogin, "EmployeeLoginTitle", "员工登录", notifyOnSuccess: false));
            _contextMenu.Items.Add(_loginItem);
        }
        if (_onEmployeeLogout != null)
        {
            var logoutText = _localization?.GetString("Logout", "退出登录") ?? "退出登录";
            _logoutItem = new ToolStripMenuItem(logoutText, null,
                async (s, e) => await RunWorkAction(_onEmployeeLogout, "LogoutTitle", "提示", notifyOnSuccess: false));
            _contextMenu.Items.Add(_logoutItem);
        }

        _contextMenu.Items.Add(new ToolStripSeparator());

        if (_onCheckIn != null || _onCheckInShift != null)
        {
            var checkInText = _localization?.GetString("CheckIn", "上班") ?? "上班";
            _checkInItem = new ToolStripMenuItem(checkInText, null,
                async (s, e) => await RunWorkAction(_onCheckIn!, "CheckInSuccess", "上班成功"));
            _contextMenu.Items.Add(_checkInItem);

            var dayText = _localization?.GetString("CheckInDay", "白班上班") ?? "白班上班";
            _checkInDayItem = new ToolStripMenuItem(dayText, null,
                async (s, e) => await RunWorkAction(() => _onCheckInShift!("day"), "CheckInSuccess", "上班成功"));
            _checkInDayItem.Visible = false;
            _contextMenu.Items.Add(_checkInDayItem);

            var nightText = _localization?.GetString("CheckInNight", "夜班上班") ?? "夜班上班";
            _checkInNightItem = new ToolStripMenuItem(nightText, null,
                async (s, e) => await RunWorkAction(() => _onCheckInShift!("night"), "CheckInSuccess", "上班成功"));
            _checkInNightItem.Visible = false;
            _contextMenu.Items.Add(_checkInNightItem);
        }
        if (_onCheckOut != null)
        {
            var checkOutText = _localization?.GetString("CheckOut", "下班") ?? "下班";
            _checkOutItem = new ToolStripMenuItem(checkOutText, null,
                async (s, e) => await RunWorkAction(_onCheckOut, "CheckOutSuccess", "下班成功"));
            _contextMenu.Items.Add(_checkOutItem);
        }

        _contextMenu.Items.Add(new ToolStripSeparator());

        if (_onBindTelegram != null)
        {
            var bindTgText = _localization?.GetString("BindTelegram", "绑定 Telegram") ?? "绑定 Telegram";
            _bindTelegramItem = new ToolStripMenuItem(bindTgText, null,
                async (s, e) => await RunWorkAction(_onBindTelegram, "BindTelegramComplete", "请在 Telegram 中完成绑定"));
            _contextMenu.Items.Add(_bindTelegramItem);
        }

        _contextMenu.Items.Add(new ToolStripSeparator());

        var showStatusText = _localization?.GetString("ShowStatusWindow", "显示状态窗口") ?? "显示状态窗口";
        _showStatusItem = new ToolStripMenuItem(showStatusText, null, (s, e) => ShowStatusWindow());
        _contextMenu.Items.Add(_showStatusItem);

        _contextMenu.Items.Add(new ToolStripSeparator());

        var settingsText = _localization?.GetString("Settings", "设置") ?? "设置";
        _settingsMenu = new ToolStripMenuItem(settingsText);

        if (_onBindInvite != null)
        {
            var bindText = _localization?.GetString("BindInviteCodeAdvanced", "绑定邀请码（补绑）") ?? "绑定邀请码（补绑）";
            _settingsMenu.DropDownItems.Add(new ToolStripMenuItem(bindText, null,
                async (s, e) => await RunWorkAction(_onBindInvite, "BindSuccessTitle", "绑定成功", notifyOnSuccess: false)));
        }

        var openLogText = _localization?.GetString("OpenLog", "打开日志") ?? "打开日志";
        _settingsMenu.DropDownItems.Add(new ToolStripMenuItem(openLogText, null, (s, e) => OpenLogFolder()));

        if (_onCheckForUpdates != null)
        {
            var updateText = _localization?.GetString("CheckForUpdates", "检查更新") ?? "检查更新";
            _settingsMenu.DropDownItems.Add(new ToolStripMenuItem(updateText, null,
                async (s, e) => await RunUpdateCheckAsync()));
        }

        var copyDeviceIdText = _localization?.GetString("CopyDeviceId", "复制设备ID") ?? "复制设备ID";
        _settingsMenu.DropDownItems.Add(new ToolStripMenuItem(copyDeviceIdText, null, (s, e) => CopyDeviceId()));

        var copyServerText = _localization?.GetString("CopyServerUrl", "复制服务器地址") ?? "复制服务器地址";
        _settingsMenu.DropDownItems.Add(new ToolStripMenuItem(copyServerText, null, (s, e) => CopyServerUrl()));

        _settingsMenu.DropDownItems.Add(new ToolStripSeparator());

        _languageMenu = LanguageMenuBuilder.CreateLanguageSubmenu(_localization, SelectLanguage);
        _settingsMenu.DropDownItems.Add(_languageMenu);

        _settingsMenu.DropDownItems.Add(new ToolStripSeparator());

        var autoStartText = _localization?.GetString("AutoStart", "开机自启动") ?? "开机自启动";
        _autoStartItem = new ToolStripMenuItem(autoStartText);
        _autoStartItem.Checked = IsAutoStartEnabled();
        _autoStartItem.Click += (s, e) => ToggleAutoStart();
        if (_clientProtection != null && !_clientProtection.CanToggleAutoStart())
            _autoStartItem.Enabled = false;
        _settingsMenu.DropDownItems.Add(_autoStartItem);

        var forceDirectText = _localization?.GetString(
            "NetworkForceDirectMenu",
            "监控直连（不走 VPN 代理）") ?? "监控直连（不走 VPN 代理）";
        _forceDirectNetworkItem = new ToolStripMenuItem(forceDirectText)
        {
            CheckOnClick = true,
            Checked = _getForceDirectConnection?.Invoke() ?? true,
        };
        _forceDirectNetworkItem.Click += async (_, _) => await ToggleForceDirectNetworkAsync();
        _settingsMenu.DropDownItems.Add(_forceDirectNetworkItem);

        var autoStartDiagText = _localization?.GetString("AutoStartDiagnosticMenu", "登录自启诊断…") ?? "登录自启诊断…";
        _settingsMenu.DropDownItems.Add(new ToolStripMenuItem(autoStartDiagText, null,
            (s, e) => ShowAutoStartDiagnosticDialog()));

        _contextMenu.Items.Add(_settingsMenu);

        _contextMenu.Items.Add(new ToolStripSeparator());

        var exitText = _localization?.GetString("Exit", "退出") ?? "退出";
        _exitItem = new ToolStripMenuItem(exitText, null, async (_, _) => await HandleExitClickAsync());
        _contextMenu.Items.Add(_exitItem);

        UpdateActionMenuState(false, false, false);
    }

    private void SelectLanguage(string languageCode)
    {
        if (_localization == null)
            return;

        if (string.Equals(_localization.GetCurrentLanguage(), languageCode, StringComparison.OrdinalIgnoreCase))
            return;

        _localization.SetLanguage(languageCode);
    }

    private void HandleLanguageChanged()
    {
        RunOnUiThread(() =>
        {
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var languageName = LanguageCatalog.GetDisplayName(_localization?.GetCurrentLanguage() ?? "zh-CN", _localization);
            var message = string.Format(
                _localization?.GetString("LanguageChangedNotice", "语言已切换为 {0}") ?? "语言已切换为 {0}",
                languageName);

            BuildContextMenu();
            UpdateTrayStatusCore();
            _statusForm?.RefreshLocalization();
            _punchPanel?.ApplyLocalization();
            ShowBalloonTip(appName, message, ToolTipIcon.Info);
            _logger?.LogInformation("UI language changed to {Language}", _localization?.GetCurrentLanguage());
        });
    }

    private string WorkStatusText(bool hasOpenSession) =>
        hasOpenSession
            ? (_localization?.GetString("WorkStatusOnShift", "上班中") ?? "上班中")
            : (_localization?.GetString("WorkStatusOffShift", "未上班") ?? "未上班");

    private string TelegramStatusSuffix(bool loggedIn, bool bound, string username, bool workstationChannel = false)
    {
        if (!loggedIn)
            return "";

        if (!bound)
            return " · " + (_localization?.GetString("TelegramNotBoundShort", "TG 未绑定") ?? "TG 未绑定");

        if (workstationChannel)
        {
            var handle = string.IsNullOrWhiteSpace(username) ? "" : " @" + username.TrimStart('@');
            return " · " + (_localization?.GetString("TelegramWorkstationBoundShort", "工位 TG 已绑定") ?? "工位 TG 已绑定") + handle;
        }

        var personalHandle = string.IsNullOrWhiteSpace(username) ? "" : " @" + username.TrimStart('@');
        return " · " + (_localization?.GetString("TelegramBoundShort", "TG 已绑定") ?? "TG 已绑定") + personalHandle;
    }

    private void UpdateActionMenuState(bool loggedIn, bool telegramBound, bool hasOpenSession)
    {
        if (_loginItem != null)
            _loginItem.Visible = !loggedIn;
        if (_logoutItem != null)
            _logoutItem.Visible = loggedIn;

        // 上班中：上班置灰；未上班：下班置灰（与 Telegram 群打卡状态同步）
        var dual = _getDualShiftEnabled?.Invoke() == true && _onCheckInShift != null;
        if (_checkInItem != null)
        {
            _checkInItem.Visible = !dual;
            _checkInItem.Enabled = !dual && loggedIn && !hasOpenSession;
        }
        if (_checkInDayItem != null)
        {
            _checkInDayItem.Visible = dual;
            _checkInDayItem.Enabled = dual && loggedIn && !hasOpenSession;
        }
        if (_checkInNightItem != null)
        {
            _checkInNightItem.Visible = dual;
            _checkInNightItem.Enabled = dual && loggedIn && !hasOpenSession;
        }
        if (_checkOutItem != null)
            _checkOutItem.Enabled = loggedIn && hasOpenSession;

        if (_bindTelegramItem != null)
        {
            if (!loggedIn)
            {
                _bindTelegramItem.Enabled = false;
                _bindTelegramItem.Text = _localization?.GetString("BindTelegram", "绑定 Telegram") ?? "绑定 Telegram";
            }
            else if (telegramBound)
            {
                _bindTelegramItem.Enabled = false;
                var boundText = _telegramWorkstationChannel
                    ? (_localization?.GetString("TelegramWorkstationBoundMenu", "工位 Telegram 已绑定") ?? "工位 Telegram 已绑定")
                    : (_localization?.GetString("TelegramBoundMenu", "Telegram 已绑定") ?? "Telegram 已绑定");
                if (!string.IsNullOrWhiteSpace(_telegramUsername))
                    boundText += " @" + _telegramUsername.TrimStart('@');
                _bindTelegramItem.Text = boundText;
            }
            else
            {
                _bindTelegramItem.Enabled = true;
                _bindTelegramItem.Text = _localization?.GetString("BindTelegram", "绑定 Telegram") ?? "绑定 Telegram";
            }
        }
    }

    private DateTime _lastTrayStatusCoreUtc = DateTime.MinValue;
    private static readonly TimeSpan TrayStatusMinInterval = TimeSpan.FromMilliseconds(300);

    public void InvalidateTelegramStatus() => _telegramBoundCheckedAt = DateTime.MinValue;

    public void NotifyMenuStateChanged() => RunOnUiThread(() =>
    {
        UpdateTrayStatus();
        _punchPanel?.RefreshState();
    });

    private async Task RefreshTelegramBoundAsync(bool loggedIn, bool force = false)
    {
        if (!loggedIn || _getTelegramBindStatusAsync == null || _telegramBoundLoading)
            return;

        if (!force && DateTime.UtcNow - _telegramBoundCheckedAt < TelegramStatusRefreshInterval)
            return;

        _telegramBoundLoading = true;
        try
        {
            var status = await _getTelegramBindStatusAsync().ConfigureAwait(false);
            _telegramBound = status.Bound;
            _telegramUsername = status.TelegramUsername ?? "";
            _telegramWorkstationChannel = status.IsWorkstationChannel;
            _telegramBoundCheckedAt = DateTime.UtcNow;
            RunOnUiThread(UpdateTrayStatusCore);
        }
        catch (Exception ex)
        {
            _logger?.LogDebug(ex, "Failed to refresh telegram bind status");
        }
        finally
        {
            _telegramBoundLoading = false;
        }
    }
    
    private string FormatEmployeeLine(string? displayName)
    {
        var label = _localization?.GetString("EmployeeLabel", "员工") ?? "员工";
        if (!string.IsNullOrWhiteSpace(displayName))
            return $"{label}: {displayName}";

        var notLoggedIn = _localization?.GetString("EmployeeNotLoggedIn", "未登录（请使用「员工登录」）")
            ?? "未登录（请使用「员工登录」）";
        return $"{label}: {notLoggedIn}";
    }
    
    private void UpdateTrayStatus()
    {
        try
        {
            UpdateTrayStatusCore();
            var loggedIn = _getEmployeeStatus?.Invoke().IsLoggedIn ?? false;
            _ = RefreshTelegramBoundAsync(loggedIn);
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Error updating tray status");
        }
    }

    private void UpdateTrayStatusCore()
    {
        var now = DateTime.UtcNow;
        if (now - _lastTrayStatusCoreUtc < TrayStatusMinInterval)
            return;
        _lastTrayStatusCoreUtc = now;

        var isConnected = _isConnected();
        var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
        var statusLabel = _localization?.GetString("Status", "状态") ?? "状态";
        var deviceLabel = _localization?.GetString("Device", "设备") ?? "设备";
        var notRegistered = _localization?.GetString("NotRegistered", "未注册") ?? "未注册";
        var connectedText = isConnected
            ? (_localization?.GetString("Connected", "已连接") ?? "已连接")
            : (_localization?.GetString("Disconnected", "未连接") ?? "未连接");

        var hasOpenSession = _getHasOpenSession?.Invoke() ?? false;
        var workStatus = WorkStatusText(hasOpenSession);
        var loggedIn = false;
        EmployeeTrayStatus? employee = null;

        if (_getEmployeeStatus != null)
        {
            try
            {
                employee = _getEmployeeStatus();
                loggedIn = employee.IsLoggedIn;
            }
            catch (Exception ex)
            {
                _logger?.LogDebug(ex, "Failed to read employee tray status");
            }
        }

        if (!loggedIn)
        {
            _telegramBound = false;
            _telegramUsername = "";
            _telegramWorkstationChannel = false;
            _telegramBoundCheckedAt = DateTime.MinValue;
        }

        UpdateActionMenuState(loggedIn, _telegramBound, hasOpenSession);

        if (_statusItem != null)
        {
            var statusIcon = isConnected ? "●" : "○";
            var line1 = $"{statusLabel}: {statusIcon} {connectedText} · {workStatus}";
            _statusItem.Text = string.IsNullOrEmpty(_serviceStatusSuffix)
                ? line1
                : $"{line1}\n{_serviceStatusSuffix}";
            _statusItem.ForeColor = isConnected ? DrawingColor.Green : DrawingColor.Red;
        }

        if (_employeeItem != null)
        {
            if (loggedIn && employee != null)
            {
                _employeeItem.Text = FormatEmployeeLine(employee.DisplayLabel)
                    + TelegramStatusSuffix(true, _telegramBound, _telegramUsername, _telegramWorkstationChannel);
                _employeeItem.ForeColor = DrawingColor.FromArgb(0, 100, 0);
            }
            else
            {
                _employeeItem.Text = FormatEmployeeLine(null);
                _employeeItem.ForeColor = DrawingColor.Gray;
            }
        }

        var deviceId = _getDeviceId();
        var shortDeviceId = string.IsNullOrEmpty(deviceId) ? notRegistered
            : (deviceId.Length > 12 ? deviceId[..12] + "..." : deviceId);
        var employeeLabel = _localization?.GetString("EmployeeLabel", "员工") ?? "员工";
        _notifyIcon.Text = employee != null && employee.IsLoggedIn
            ? $"{appName}\n{employeeLabel}: {employee.DisplayLabel}\n{workStatus}{TelegramStatusSuffix(true, _telegramBound, _telegramUsername, _telegramWorkstationChannel)}\n{deviceLabel}: {shortDeviceId}\n{statusLabel}: {connectedText}"
            : $"{appName}\n{deviceLabel}: {shortDeviceId}\n{statusLabel}: {connectedText}";
    }
    
    private void ShowPunchPanel()
    {
        try
        {
            if (_punchPanel != null && !_punchPanel.IsDisposed && _punchPanel.IsOpen)
            {
                _punchPanel.HideToTray();
                return;
            }

            if (_punchPanel == null || _punchPanel.IsDisposed)
                _punchPanel = new TrayPunchPanelForm(BuildPunchActions());

            _punchPanel.EnsureExpandedVisible();
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Error showing punch panel");
        }
    }

    private TrayPunchActions BuildPunchActions() => new()
    {
        GetIsConnected = _isConnected,
        GetEmployeeStatus = _getEmployeeStatus,
        OnCheckInShift = _onCheckInShift,
        OnCheckOut = _onCheckOut,
        OnEmployeeLogin = _onEmployeeLogin,
        LoadDashboardAsync = _tgPunchService != null
            ? () => _tgPunchService.GetDashboardAsync()
            : null,
        GetCachedDashboard = _tgPunchService != null
            ? () => _tgPunchService.CachedDashboard
            : null,
        RememberLocalRecord = _tgPunchService != null
            ? record => _tgPunchService.RememberLocalRecord(record)
            : null,
        UpdateCachedOpenActivity = _tgPunchService != null
            ? openActivity => _tgPunchService.UpdateCachedOpenActivity(openActivity)
            : null,
        OnStartActivityAsync = _tgPunchService != null
            ? activity => _tgPunchService.StartActivityAsync(activity)
            : null,
        OnActivityBackAsync = _tgPunchService != null
            ? sessionId => _tgPunchService.ActivityBackAsync(sessionId)
            : null,
        Notifications = _agentNotification,
        Localization = _localization,
        Logger = _logger,
        OnStateChanged = () =>
        {
            InvalidateTelegramStatus();
            NotifyMenuStateChanged();
        }
    };

    private void ShowStatusWindow()
    {
        try
        {
            if (_statusForm == null || _statusForm.IsDisposed)
            {
                var quickActions = new StatusFormQuickActions
                {
                    OnBindInviteAsync = _onBindInvite != null
                        ? () => RunWorkAction(_onBindInvite, "BindSuccessTitle", "绑定成功", notifyOnSuccess: false)
                        : null,
                    OnOpenLog = OpenLogFolder,
                    OnToggleAutoStart = ToggleAutoStart,
                    IsAutoStartEnabled = IsAutoStartEnabled,
                    GetAutoStartDiagnostic = () => AutoStartManager.Diagnose(_logger, _localization),
                    ShowAutoStartDiagnostic = () => ShowAutoStartDiagnosticDialog()
                };

                _statusForm = new StatusForm(_getDeviceId, _getServerUrl, _isConnected, _localization, quickActions);
                _statusForm.FormClosed += (s, e) => _statusForm = null;
            }
            
            if (_statusForm.WindowState == FormWindowState.Minimized)
                _statusForm.WindowState = FormWindowState.Normal;
            
            _statusForm.Show();
            _statusForm.BringToFront();
            _statusForm.Activate();
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Error showing status window");
        }
    }
    
    private void CopyDeviceId()
    {
        try
        {
            var deviceId = _getDeviceId();
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            
            if (!string.IsNullOrEmpty(deviceId))
            {
                Clipboard.SetText(deviceId);
                _logger?.LogInformation("Device ID copied to clipboard");
                var message = _localization?.GetString("DeviceIdCopied", "设备ID已复制到剪贴板") ?? "设备ID已复制到剪贴板";
                ShowBalloonTip(appName, message, ToolTipIcon.Info);
            }
            else
            {
                var message = _localization?.GetString("DeviceIdNotRegistered", "设备尚未注册") ?? "设备尚未注册";
                ShowBalloonTip(appName, message, ToolTipIcon.Warning);
            }
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Failed to copy device ID");
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var message = _localization?.GetString("CopyFailed", "复制失败") ?? "复制失败";
            ShowBalloonTip(appName, message, ToolTipIcon.Error);
        }
    }
    
    private void CopyServerUrl()
    {
        try
        {
            var serverUrl = _getServerUrl();
            if (!string.IsNullOrEmpty(serverUrl))
            {
                Clipboard.SetText(serverUrl);
                _logger?.LogInformation("Server URL copied to clipboard");
                var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
                var message = _localization?.GetString("ServerUrlCopied", "服务器地址已复制到剪贴板") ?? "服务器地址已复制到剪贴板";
                ShowBalloonTip(appName, message, ToolTipIcon.Info);
            }
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Failed to copy server URL");
        }
    }
    
    private void ShowBalloonTip(string title, string message, ToolTipIcon icon)
    {
        _notifyIcon.ShowBalloonTip(3000, title, message, icon);
    }
    
    private Icon GetAppIcon()
    {
        // 从输出目录加载自定义图标
        var iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
        if (File.Exists(iconPath))
        {
            try
            {
                return new Icon(iconPath);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Failed to load icon from {Path}", iconPath);
            }
        }

        // 后备方案：动态生成
        var bitmap = new Bitmap(64, 64);

        using var g = Graphics.FromImage(bitmap);
        g.Clear(DrawingColor.FromArgb(0, 120, 212));

        using var font = new Font("Segoe UI", 28, FontStyle.Bold);

        g.DrawString("DH", font, Brushes.White, new DrawingPointF(12, 12));

        var hIcon = bitmap.GetHicon();

        return Icon.FromHandle(hIcon);
    }
    
    public void NotifyEmployeeSessionChanged()
    {
        InvalidateTelegramStatus();
        NotifyMenuStateChanged();
    }

    /// <summary>
    /// 启动 WinForms 消息循环；在循环就绪后执行 startup 任务（弹窗等必须在消息循环内）。
    /// </summary>
    public void RunMessageLoop(Func<Task>? onMessageLoopReady = null)
    {
        if (onMessageLoopReady != null)
        {
            void OnIdle(object? sender, EventArgs e)
            {
                Application.Idle -= OnIdle;
                _ = RunStartupUiTaskAsync(onMessageLoopReady);
            }

            Application.Idle += OnIdle;
        }

        Application.Run(_uiSyncForm);
    }

    private async Task RunStartupUiTaskAsync(Func<Task> task)
    {
        try
        {
            await task().ConfigureAwait(true);
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Startup UI task failed");
        }
    }

    public void SetRecordingStatus(bool isRecording)
    {
        _isRecording = isRecording;
        UpdateServiceStatus();
    }
    
    public void SetScreenshotStatus(bool isScreenshotting)
    {
        _isScreenshotting = isScreenshotting;
        UpdateServiceStatus();
    }
    
    public void SetUploadStatus(bool isUploading)
    {
        _isUploading = isUploading;
        UpdateServiceStatus();
    }
    
    private void UpdateServiceStatus()
    {
        if (_isRecording)
        {
            _serviceStatusSuffix = _localization?.GetString("Recording", "● 录屏中") ?? "● 录屏中";
        }
        else if (_isScreenshotting)
        {
            _serviceStatusSuffix = _localization?.GetString("Screenshot", "● 截图中") ?? "● 截图中";
        }
        else if (_isUploading)
        {
            _serviceStatusSuffix = _localization?.GetString("Uploading", "● 上传中") ?? "● 上传中";
        }
        else
        {
            _serviceStatusSuffix = _localization?.GetString("Idle", "○ 空闲") ?? "○ 空闲";
        }

        RunOnUiThread(UpdateTrayStatusCore);
    }
    
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        if (_localization != null)
            _localization.LanguageChanged -= HandleLanguageChanged;
        
        _statusForm?.Close();
        _statusForm?.Dispose();
        _punchPanel?.Close();
        _punchPanel?.Dispose();
        _singleClickTimer.Stop();
        _singleClickTimer.Dispose();
        _notifyIcon?.Dispose();
        _contextMenu?.Dispose();
        _uiSyncForm?.Close();
        _uiSyncForm?.Dispose();
        
        _logger?.LogInformation("Tray icon disposed");
    }
}
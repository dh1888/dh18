package services

import (
	"testing"
	"time"
)

func TestIsWithinCheckInWindow(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	start := time.Date(2026, 7, 18, 9, 0, 0, 0, loc)

	if !isWithinCheckInWindow(time.Date(2026, 7, 18, 8, 30, 0, 0, loc), start, 60, 30) {
		t.Fatal("expected 08:30 within 60m before start")
	}
	if isWithinCheckInWindow(time.Date(2026, 7, 18, 7, 50, 0, 0, loc), start, 60, 30) {
		t.Fatal("expected 07:50 outside 60m before start")
	}
	if !isWithinCheckInWindow(time.Date(2026, 7, 18, 9, 20, 0, 0, loc), start, 60, 30) {
		t.Fatal("expected 09:20 within 30m after start")
	}
	if isWithinCheckInWindow(time.Date(2026, 7, 18, 9, 31, 0, 0, loc), start, 60, 30) {
		t.Fatal("expected 09:31 outside 30m after start")
	}
}

func TestMinutesLateUsesLateToleranceOnly(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	expected := time.Date(2026, 7, 18, 9, 0, 0, 0, loc)
	now := time.Date(2026, 7, 18, 9, 20, 0, 0, loc)
	if got := minutesLateFromExpected(now, expected, 15); got != 5 {
		t.Fatalf("late minutes = %d, want 5", got)
	}
}

func TestMinutesEarlyUsesEarlyLeaveTolerance(t *testing.T) {
	loc := time.FixedZone("CST", 8*3600)
	expected := time.Date(2026, 7, 18, 18, 0, 0, 0, loc)
	now := time.Date(2026, 7, 18, 17, 40, 0, 0, loc)
	if got := minutesEarlyFromExpected(now, expected, 15); got != 5 {
		t.Fatalf("early minutes = %d, want 5", got)
	}
}

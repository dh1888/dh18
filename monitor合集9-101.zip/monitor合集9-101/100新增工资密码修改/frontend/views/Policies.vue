<template>
  <div class="policies-page">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <!-- 顶部工具栏 -->
    <el-card class="toolbar-card card-hover" shadow="hover">
      <div class="toolbar">
        <div class="toolbar-left">
          <el-icon class="title-icon"><Document /></el-icon>
          <span class="title">策略管理</span>
          <el-tag type="info" size="small" effect="plain">
            共 {{ policies.length }} 个策略
          </el-tag>
          <el-icon class="help-icon" @click.stop="showPolicyHelp">
            <QuestionFilled />
          </el-icon>
        </div>
        <div class="toolbar-right">
          <el-button type="primary" @click="handleCreate" v-permission="'policy:create'">
            <el-icon><Plus /></el-icon>
            新建策略
          </el-button>
          <el-button @click="loadPolicies" :loading="listLoading">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
        </div>
      </div>
    </el-card>

    <!-- 策略表格 -->
    <el-card class="table-card" shadow="hover" v-loading="listLoading">
      <el-table :data="policies" stripe style="width: 100%">
        <!-- 表格内容保持不变 -->
        <el-table-column
          prop="name"
          label="策略名称"
          min-width="180"
          align="center"
        >
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              class="policy-name-link"
              @click="showDetail(row)"
            >
              <el-icon><Document /></el-icon>
              <span>{{ row.name }}</span>
            </el-button>
          </template>
        </el-table-column>

        <el-table-column prop="version" label="版本" width="100" align="center">
          <template #default="{ row }">
            <div class="version-vertical">
              <div class="version-number">v{{ row.version }}</div>
              <el-tag
                v-if="row.isCurrent"
                size="small"
                type="success"
                effect="dark"
                class="current-badge-vertical"
              >
                生效中
              </el-tag>
            </div>
          </template>
        </el-table-column>

        <!-- 录屏配置摘要 -->
        <el-table-column label="录屏配置" min-width="220">
          <template #default="{ row }">
            <div class="config-card" v-if="getRecordingConfig(row)">
              <div class="config-row">
                <span class="config-label">状态：</span>
                <el-tag
                  size="small"
                  :type="getRecordingConfig(row).enabled ? 'success' : 'info'"
                  effect="light"
                >
                  {{ getRecordingConfig(row).enabled ? "启用" : "禁用" }}
                </el-tag>
              </div>
              <div
                v-if="getRecordingConfig(row).enabled"
                class="config-detail-list"
              >
                <div class="config-row">
                  <span class="config-label">帧率：</span>
                  <span class="config-value"
                    >{{ getRecordingConfig(row).fps }} fps</span
                  >
                </div>
                <div class="config-row">
                  <span class="config-label">画质：</span>
                  <span class="config-value"
                    >{{ getRecordingConfig(row).quality }}%</span
                  >
                </div>
                <div class="config-row">
                  <span class="config-label">GPU加速：</span>
                  <el-tag
                    size="small"
                    :type="
                      getRecordingConfig(row).enableGpu ? 'success' : 'info'
                    "
                    effect="light"
                  >
                    {{ getRecordingConfig(row).enableGpu ? "启用" : "禁用" }}
                  </el-tag>
                </div>
                <div class="config-row">
                  <span class="config-label">分段时长：</span>
                  <span class="config-value"
                    >{{ getRecordingConfig(row).sliceMinutes }} 分钟/段</span
                  >
                </div>
              </div>
            </div>
            <span v-else class="text-muted">未配置</span>
          </template>
        </el-table-column>

        <!-- 截图配置摘要 -->
        <el-table-column label="截图配置" min-width="200">
          <template #default="{ row }">
            <div class="config-card" v-if="getScreenshotConfig(row)">
              <div class="config-row">
                <span class="config-label">状态：</span>
                <el-tag
                  size="small"
                  :type="getScreenshotConfig(row).enabled ? 'success' : 'info'"
                  effect="light"
                >
                  {{ getScreenshotConfig(row).enabled ? "启用" : "禁用" }}
                </el-tag>
              </div>
              <div
                v-if="getScreenshotConfig(row).enabled"
                class="config-detail-list"
              >
                <div class="config-row">
                  <span class="config-label">截图时间：</span>
                  <span class="config-value"
                    >{{ getScreenshotConfig(row).intervalSeconds }} 秒</span
                  >
                </div>
                <div class="config-row">
                  <span class="config-label">画质：</span>
                  <span class="config-value"
                    >{{ getScreenshotConfig(row).quality }}%</span
                  >
                </div>
                <div class="config-row">
                  <span class="config-label">格式：</span>
                  <el-tag size="small" type="info" effect="light">{{
                    getScreenshotConfig(row).format?.toUpperCase()
                  }}</el-tag>
                </div>
              </div>
            </div>
            <span v-else class="text-muted">未配置</span>
          </template>
        </el-table-column>

        <!-- 远程查看配置摘要 -->
        <el-table-column label="远程查看" min-width="180">
          <template #default="{ row }">
            <div class="config-card" v-if="getRemoteViewConfig(row)">
              <div class="config-detail-list">
                <div class="config-row">
                  <span class="config-label">分辨率：</span>
                  <span class="config-value"
                    >{{ getRemoteViewConfig(row).width }}×{{
                      getRemoteViewConfig(row).height
                    }}</span
                  >
                </div>
                <div class="config-row">
                  <span class="config-label">帧率：</span>
                  <span class="config-value"
                    >{{ getRemoteViewConfig(row).fps }} fps</span
                  >
                </div>
              </div>
            </div>
            <span v-else class="text-muted">未配置</span>
          </template>
        </el-table-column>

        <!-- 活动日志配置摘要 -->
        <el-table-column label="活动日志" min-width="180">
          <template #default="{ row }">
            <div class="config-card" v-if="getActivityConfig(row)">
              <div class="config-row">
                <span class="config-label">状态：</span>
                <el-tag
                  size="small"
                  :type="getActivityConfig(row).enabled ? 'success' : 'info'"
                  effect="light"
                >
                  {{ getActivityConfig(row).enabled ? "启用" : "禁用" }}
                </el-tag>
              </div>
              <div
                v-if="getActivityConfig(row).enabled"
                class="config-detail-list"
              >
                <div class="config-row">
                  <span class="config-label">空闲检测：</span>
                  <el-tag
                    size="small"
                    :type="
                      getActivityConfig(row).trackIdle ? 'success' : 'info'
                    "
                    effect="light"
                  >
                    {{ getActivityConfig(row).trackIdle ? "启用" : "禁用" }}
                  </el-tag>
                </div>
                <div class="config-row" v-if="getActivityConfig(row).trackIdle">
                  <span class="config-label">空闲阈值：</span>
                  <span class="config-value"
                    >{{ getActivityConfig(row).idleThresholdSeconds }} 秒</span
                  >
                </div>
              </div>
            </div>
            <span v-else class="text-muted">未配置</span>
          </template>
        </el-table-column>

        <!-- 清理配置摘要 -->
        <el-table-column label="保留策略" min-width="220">
          <template #default="{ row }">
            <div class="config-card" v-if="getCleanupConfig(row)">
              <div class="config-detail-list">
                <div class="config-row">
                  <span class="config-label">录制保留：</span>
                  <span class="config-value"
                    >{{ getCleanupConfig(row).recordingDays }} 天</span
                  >
                </div>
                <div class="config-row">
                  <span class="config-label">截图保留：</span>
                  <span class="config-value"
                    >{{ getCleanupConfig(row).screenshotDays }} 天</span
                  >
                </div>
                <div class="config-row">
                  <span class="config-label">日志保留：</span>
                  <span class="config-value"
                    >{{ getCleanupConfig(row).logDays }} 天</span
                  >
                </div>
                <div class="config-row">
                  <span class="config-label">磁盘阈值：</span>
                  <span class="config-value"
                    >{{ getCleanupConfig(row).diskThresholdPercent }}%</span
                  >
                </div>
              </div>
            </div>
            <span v-else class="text-muted">未配置</span>
          </template>
        </el-table-column>

        <!-- 客户端防护摘要 -->
        <el-table-column label="客户端防护" min-width="200">
          <template #default="{ row }">
            <div class="config-card" v-if="getClientProtectionConfig(row)">
              <div class="config-detail-list">
                <div class="config-row">
                  <span class="config-label">允许退出：</span>
                  <el-tag
                    size="small"
                    :type="
                      getClientProtectionConfig(row).allowUserExit
                        ? 'warning'
                        : 'success'
                    "
                    effect="light"
                  >
                    {{
                      getClientProtectionConfig(row).allowUserExit
                        ? "允许"
                        : "禁止"
                    }}
                  </el-tag>
                </div>
                <div class="config-row">
                  <span class="config-label">自启动开关：</span>
                  <el-tag size="small" type="info" effect="light">
                    {{
                      getClientProtectionConfig(row).allowAutoStartToggle
                        ? "可改"
                        : "锁定"
                    }}
                  </el-tag>
                </div>
                <div class="config-row">
                  <span class="config-label">杀进程拉起：</span>
                  <el-tag
                    size="small"
                    :type="
                      getClientProtectionConfig(row).restartOnKill
                        ? 'success'
                        : 'info'
                    "
                    effect="light"
                  >
                    {{
                      getClientProtectionConfig(row).restartOnKill
                        ? "启用"
                        : "禁用"
                    }}
                  </el-tag>
                </div>
              </div>
            </div>
            <span v-else class="text-muted">未配置</span>
          </template>
        </el-table-column>

        <!-- 安全配置摘要 -->
        <el-table-column label="安全配置" min-width="160">
          <template #default="{ row }">
            <div class="config-card" v-if="getSecurityConfig(row)">
              <div class="config-detail-list">
                <div class="config-row">
                  <span class="config-label">加密传输：</span>
                  <el-tag
                    size="small"
                    :type="
                      getSecurityConfig(row).enableEncryption
                        ? 'success'
                        : 'info'
                    "
                    effect="light"
                  >
                    {{
                      getSecurityConfig(row).enableEncryption ? "启用" : "禁用"
                    }}
                  </el-tag>
                </div>
                <div class="config-row">
                  <span class="config-label">VPN要求：</span>
                  <el-tag
                    size="small"
                    :type="
                      getSecurityConfig(row).enableVPN ? 'warning' : 'info'
                    "
                    effect="light"
                  >
                    {{ getSecurityConfig(row).enableVPN ? "要求" : "不要求" }}
                  </el-tag>
                </div>
              </div>
            </div>
            <span v-else class="text-muted">未配置</span>
          </template>
        </el-table-column>

        <el-table-column prop="status" label="状态" width="120" align="center">
          <template #default="{ row }">
            <div class="status-cell">
              <el-tag
                :type="row.status === 1 ? 'success' : 'info'"
                size="small"
                effect="light"
              >
                {{ row.status === 1 ? "已发布" : "草稿" }}
              </el-tag>
              <el-tag
                v-if="row.isCurrent"
                size="small"
                type="danger"
                effect="dark"
                class="active-badge"
              >
                当前生效
              </el-tag>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="updatedAt" label="更新时间" width="170">
          <template #default="{ row }">
            {{ formatDateTime(row.updatedAt || row.createdAt) }}
          </template>
        </el-table-column>

        <el-table-column label="操作" width="280" fixed="right" align="center">
          <template #default="{ row }">
            <div class="action-buttons">
              <el-button
                link
                type="primary"
                size="small"
                @click="selectPolicy(row)"
                class="action-btn edit-btn"
              >
                <el-icon><Edit /></el-icon>
                编辑
              </el-button>
              <el-button
                v-if="row.status !== 1"
                link
                type="success"
                size="small"
                @click="publishPolicy(row)"
                class="action-btn publish-btn"
              >
                <el-icon><Upload /></el-icon>
                发布
              </el-button>
              <el-button
                v-if="row.status === 1"
                link
                type="warning"
                size="small"
                @click="rollbackPolicy(row)"
                class="action-btn rollback-btn"
              >
                <el-icon><Refresh /></el-icon>
                回滚
              </el-button>
              <el-popconfirm
                title="确定删除此策略吗？"
                @confirm="deletePolicy(row)"
                confirm-button-text="确定"
                cancel-button-text="取消"
              >
                <template #reference>
                  <el-button
                    link
                    type="danger"
                    size="small"
                    class="action-btn delete-btn"
                  >
                    <el-icon><Delete /></el-icon>
                    删除
                  </el-button>
                </template>
              </el-popconfirm>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <el-empty
        v-if="policies.length === 0 && !listLoading"
        description="暂无策略"
      />
    </el-card>

    <!-- 右侧抽屉：新建/编辑策略 -->
    <el-drawer
      v-model="drawerVisible"
      :title="isEditing ? '编辑策略' : '新建策略'"
      size="55%"
      direction="rtl"
      :close-on-click-modal="false"
      class="policy-drawer"
    >
      <div class="drawer-content">
        <el-form
          :model="form"
          :rules="rules"
          ref="formRef"
          label-width="140px"
          label-position="top"
        >
          <el-form-item label="策略名称" prop="name">
            <el-input
              v-model="form.name"
              placeholder="请输入策略名称"
              clearable
              size="large"
            />
          </el-form-item>

          <el-divider content-position="left">
            <el-icon><VideoCamera /></el-icon>
            录屏配置
          </el-divider>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="启用录屏">
                <el-switch v-model="form.recording.enabled" />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="GPU加速" v-if="form.recording.enabled">
                <el-switch v-model="form.recording.enableGpu" />
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="20" v-if="form.recording.enabled">
            <el-col :span="8">
              <el-form-item label="帧率 (fps)">
                <el-slider
                  v-model="form.recording.fps"
                  :min="1"
                  :max="30"
                  :step="1"
                  show-input
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="画质">
                <el-slider
                  v-model="form.recording.quality"
                  :min="10"
                  :max="100"
                  :step="5"
                  show-input
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="分段时长(分钟)">
                <el-input-number
                  v-model="form.recording.sliceMinutes"
                  :min="1"
                  :max="30"
                />
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="20" v-if="form.recording.enabled">
            <el-col :span="12">
              <el-form-item label="索引后自动上传">
                <el-switch v-model="form.recording.autoUploadOnIndex" />
                <div class="field-hint">需同时启用下方「上传配置」；默认关闭，推荐管理端任务上传</div>
              </el-form-item>
            </el-col>
          </el-row>

          <el-divider content-position="left">
            <el-icon><Upload /></el-icon>
            上传配置
          </el-divider>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="启用上传">
                <el-switch v-model="form.upload.enabled" />
              </el-form-item>
            </el-col>
            <el-col :span="12" v-if="form.upload.enabled">
              <el-form-item label="最大并发">
                <el-input-number v-model="form.upload.maxConcurrent" :min="1" :max="10" />
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="20" v-if="form.upload.enabled">
            <el-col :span="12">
              <el-form-item label="速率限制(KB/s)">
                <el-input-number v-model="form.upload.rateLimitKBps" :min="64" :max="10240" :step="64" />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="分片大小(KB)">
                <el-input-number v-model="form.upload.chunkSizeKB" :min="64" :max="4096" :step="64" />
              </el-form-item>
            </el-col>
          </el-row>

          <el-divider content-position="left">
            <el-icon><Camera /></el-icon>
            截图配置
          </el-divider>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="启用截图">
                <el-switch v-model="form.screenshot.enabled" />
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="20" v-if="form.screenshot.enabled">
            <el-col :span="8">
              <el-form-item label="截图间隔(秒)">
                <el-input-number
                  v-model="form.screenshot.intervalSeconds"
                  :min="5"
                  :max="300"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="画质">
                <el-slider
                  v-model="form.screenshot.quality"
                  :min="10"
                  :max="100"
                  :step="5"
                  show-input
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="格式">
                <el-select v-model="form.screenshot.format">
                  <el-option label="WebP" value="webp" />
                  <el-option label="JPEG" value="jpeg" />
                  <el-option label="PNG" value="png" />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>

          <el-divider content-position="left">
            <el-icon><Connection /></el-icon>
            远程查看配置
          </el-divider>

          <el-row :gutter="20">
            <el-col :span="8">
              <el-form-item label="宽度">
                <el-input-number v-model="form.remoteView.width" :min="640" :max="3840" :step="2" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="高度">
                <el-input-number v-model="form.remoteView.height" :min="480" :max="2160" :step="2" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="帧率 (fps)">
                <el-input-number v-model="form.remoteView.fps" :min="1" :max="30" />
              </el-form-item>
            </el-col>
          </el-row>

          <el-divider content-position="left">
            <el-icon><List /></el-icon>
            活动日志配置
          </el-divider>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="启用活动日志">
                <el-switch v-model="form.activity.enabled" />
              </el-form-item>
            </el-col>
            <el-col :span="12" v-if="form.activity.enabled">
              <el-form-item label="空闲检测">
                <el-switch v-model="form.activity.trackIdle" />
              </el-form-item>
            </el-col>
          </el-row>

          <el-row
            :gutter="20"
            v-if="form.activity.enabled && form.activity.trackIdle"
          >
            <el-col :span="12">
              <el-form-item label="空闲阈值(秒)">
                <el-input-number
                  v-model="form.activity.idleThresholdSeconds"
                  :min="30"
                  :max="600"
                  :step="30"
                />
              </el-form-item>
            </el-col>
          </el-row>

          <el-divider content-position="left">
            <el-icon><Timer /></el-icon>
            清理策略
          </el-divider>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="录制保留天数">
                <el-input-number
                  v-model="form.cleanup.recordingDays"
                  :min="1"
                  :max="365"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="截图保留天数">
                <el-input-number
                  v-model="form.cleanup.screenshotDays"
                  :min="1"
                  :max="365"
                />
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="日志保留天数">
                <el-input-number
                  v-model="form.cleanup.logDays"
                  :min="1"
                  :max="365"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="磁盘阈值(%)">
                <el-input-number
                  v-model="form.cleanup.diskThresholdPercent"
                  :min="50"
                  :max="95"
                />
              </el-form-item>
            </el-col>
          </el-row>

          <el-divider content-position="left">
            <el-icon><Lock /></el-icon>
            客户端防护
          </el-divider>
          <p class="field-hint section-hint">
            发布或回滚生效策略时同步为全局默认；单台设备可在「员工管理 → 防护」覆盖
          </p>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="允许员工退出客户端">
                <el-switch v-model="form.clientProtection.allowUserExit" />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="允许修改登录自启动">
                <el-switch v-model="form.clientProtection.allowAutoStartToggle" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="进程被结束后自动拉起">
                <el-switch v-model="form.clientProtection.restartOnKill" />
                <div class="field-hint">禁止退出时生效</div>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="未使用解锁码有效期(分钟)">
                <el-input-number
                  v-model="form.clientProtection.unlockCodeUnusedExpireMinutes"
                  :min="5"
                  :max="1440"
                />
              </el-form-item>
            </el-col>
          </el-row>

          <el-divider content-position="left">
            <el-icon><Setting /></el-icon>
            安全配置
          </el-divider>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="加密传输">
                <el-switch v-model="form.security.enableEncryption" />
                <div class="field-hint">客户端仍使用 HTTPS 与本地 DPAPI；关闭仅作策略标记</div>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="VPN要求">
                <el-switch v-model="form.security.enableVPN" />
                <div class="field-hint">Windows 客户端暂未强制 VPN，启用后仅记录告警</div>
              </el-form-item>
            </el-col>
          </el-row>

          <!-- 高级选项 -->
          <el-divider content-position="left">
            <el-button
              link
              type="info"
              size="small"
              @click="showAdvanced = !showAdvanced"
            >
              <el-icon><Setting /></el-icon>
              {{ showAdvanced ? "收起高级编辑" : "高级编辑(JSON)" }}
            </el-button>
          </el-divider>

          <div v-if="showAdvanced">
            <el-form-item label="JSON内容">
              <el-input
                v-model="form.contentText"
                type="textarea"
                :rows="12"
                placeholder="JSON格式的策略内容"
                class="policy-textarea"
              />
              <div class="json-tip">
                <el-button size="small" @click="formatJson">格式化</el-button>
                <el-button size="small" @click="validateJson">验证</el-button>
                <el-button size="small" type="primary" @click="syncFormToJson">
                  从表单同步到JSON
                </el-button>
                <el-button size="small" @click="showTemplate"
                  >重置为模板</el-button
                >
              </div>
            </el-form-item>
          </div>

          <el-form-item v-if="form.contentError" label=" ">
            <el-alert
              :title="form.contentError"
              type="error"
              show-icon
              :closable="false"
            />
          </el-form-item>

          <el-form-item>
            <div class="drawer-actions">
              <el-button @click="drawerVisible = false">取消</el-button>
              <el-button
                type="primary"
                :loading="saveLoading"
                @click="handleSave"
              >
                {{ isEditing ? "保存修改" : "创建策略" }}
              </el-button>
              <el-button
                v-if="isEditing && currentPolicy && currentPolicy.status === 1"
                type="success"
                :loading="saveAndPublishLoading"
                @click="handleSaveAndPublish"
              >
                <el-icon><Upload /></el-icon>
                保存并发布
              </el-button>
              <el-button
                v-if="isEditing && currentPolicy && currentPolicy.status !== 1"
                type="success"
                :loading="publishLoading"
                @click="handlePublish"
              >
                发布
              </el-button>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </el-drawer>

    <!-- 策略详情对话框 -->
    <el-dialog
      v-model="detailVisible"
      :title="detailPolicy?.name"
      width="800px"
      class="policy-detail-dialog"
    >
      <div class="policy-detail" v-if="detailPolicy">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="策略名称" :span="2">
            {{ detailPolicy.name }}
          </el-descriptions-item>
          <el-descriptions-item label="版本号">
            v{{ detailPolicy.version }}
          </el-descriptions-item>
          <el-descriptions-item label="状态">
            <div class="status-info">
              <el-tag
                :type="detailPolicy.status === 1 ? 'success' : 'info'"
                size="small"
              >
                {{ detailPolicy.status === 1 ? "已发布" : "草稿" }}
              </el-tag>
              <el-tag
                v-if="detailPolicy.isCurrent"
                type="danger"
                size="small"
                style="margin-left: 8px"
              >
                当前生效中
              </el-tag>
            </div>
          </el-descriptions-item>
          <el-descriptions-item label="创建时间">
            {{ formatDateTime(detailPolicy.createdAt) }}
          </el-descriptions-item>
          <el-descriptions-item label="更新时间">
            {{
              formatDateTime(detailPolicy.updatedAt || detailPolicy.createdAt)
            }}
          </el-descriptions-item>

          <!-- 其他详情内容保持不变 -->
          <el-descriptions-item
            label="录屏配置"
            :span="2"
            v-if="getRecordingConfig(detailPolicy)"
          >
            <div class="detail-config-group">
              <div class="detail-config-item">
                <span class="detail-label">状态</span>
                <el-tag
                  size="small"
                  :type="
                    getRecordingConfig(detailPolicy).enabled
                      ? 'success'
                      : 'info'
                  "
                >
                  {{
                    getRecordingConfig(detailPolicy).enabled ? "启用" : "禁用"
                  }}
                </el-tag>
              </div>
              <div
                class="detail-config-item"
                v-if="getRecordingConfig(detailPolicy).enabled"
              >
                <span class="detail-label">帧率</span>
                <span>{{ getRecordingConfig(detailPolicy).fps }} fps</span>
              </div>
              <div
                class="detail-config-item"
                v-if="getRecordingConfig(detailPolicy).enabled"
              >
                <span class="detail-label">画质</span>
                <span>{{ getRecordingConfig(detailPolicy).quality }}</span>
              </div>
              <div
                class="detail-config-item"
                v-if="getRecordingConfig(detailPolicy).enabled"
              >
                <span class="detail-label">GPU加速</span>
                <el-tag
                  size="small"
                  :type="
                    getRecordingConfig(detailPolicy).enableGpu
                      ? 'success'
                      : 'info'
                  "
                >
                  {{
                    getRecordingConfig(detailPolicy).enableGpu ? "启用" : "禁用"
                  }}
                </el-tag>
              </div>
              <div
                class="detail-config-item"
                v-if="getRecordingConfig(detailPolicy).enabled"
              >
                <span class="detail-label">分段录制</span>
                <span
                  >{{
                    getRecordingConfig(detailPolicy).sliceMinutes
                  }}
                  分钟/段</span
                >
              </div>
            </div>
          </el-descriptions-item>

          <!-- 截图配置详情 -->
          <el-descriptions-item
            label="截图配置"
            :span="2"
            v-if="getScreenshotConfig(detailPolicy)"
          >
            <div class="detail-config-group">
              <div class="detail-config-item">
                <span class="detail-label">状态</span>
                <el-tag
                  size="small"
                  :type="
                    getScreenshotConfig(detailPolicy).enabled
                      ? 'success'
                      : 'info'
                  "
                >
                  {{
                    getScreenshotConfig(detailPolicy).enabled ? "启用" : "禁用"
                  }}
                </el-tag>
              </div>
              <div
                class="detail-config-item"
                v-if="getScreenshotConfig(detailPolicy).enabled"
              >
                <span class="detail-label">截图间隔</span>
                <span
                  >{{
                    getScreenshotConfig(detailPolicy).intervalSeconds
                  }}
                  秒</span
                >
              </div>
              <div
                class="detail-config-item"
                v-if="getScreenshotConfig(detailPolicy).enabled"
              >
                <span class="detail-label">画质</span>
                <span>{{ getScreenshotConfig(detailPolicy).quality }}</span>
              </div>
              <div
                class="detail-config-item"
                v-if="getScreenshotConfig(detailPolicy).enabled"
              >
                <span class="detail-label">格式</span>
                <el-tag size="small" type="info">{{
                  getScreenshotConfig(detailPolicy).format
                }}</el-tag>
              </div>
            </div>
          </el-descriptions-item>

          <!-- 其他配置详情... -->
          <el-descriptions-item label="原始内容" :span="2">
            <pre class="policy-content-preview">{{
              formatPolicyContent(detailPolicy.content)
            }}</pre>
          </el-descriptions-item>
        </el-descriptions>
      </div>
      <template #footer>
        <el-button @click="detailVisible = false">关闭</el-button>
        <el-button type="primary" @click="editFromDetail">
          <el-icon><Edit /></el-icon>
          编辑策略
        </el-button>
        <el-button
          v-if="detailPolicy?.status !== 1"
          type="success"
          @click="publishFromDetail"
        >
          <el-icon><Upload /></el-icon>
          发布
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, onUnmounted, watch } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Plus,
  Refresh,
  Delete,
  Document,
  Edit,
  Upload,
  VideoCamera,
  Camera,
  List,
  Timer,
  Lock,
  Connection,
  Setting,
  QuestionFilled,
} from "@element-plus/icons-vue";
import { policyApi, settingsApi } from "@api/index";
import type { Policy, PolicyContent, PolicyClientProtectionConfig } from "@api/types";

const listLoading = ref(false);
const saveLoading = ref(false);
const publishLoading = ref(false);
const rollbackLoading = ref(false);
const deleteLoading = ref(false);
const policies = ref<Policy[]>([]);
const currentPolicy = ref<Policy | null>(null);
const isEditing = ref(false);
const formRef = ref();
const drawerVisible = ref(false);
const detailVisible = ref(false);
const detailPolicy = ref<Policy | null>(null);
const showAdvanced = ref(false);

const saveAndPublishLoading = ref(false);

// ========== 表单数据（结构化） ==========
const form = reactive({
  id: "",
  name: "",
  contentText: "",
  contentError: "",
  recording: {
    enabled: true,
    fps: 5,
    quality: 70,
    enableGpu: true,
    sliceMinutes: 1,
    autoUploadOnIndex: false,
  },
  screenshot: {
    enabled: true,
    intervalSeconds: 30,
    quality: 80,
    format: "webp",
  },
  upload: {
    enabled: true,
    rateLimitKBps: 1024,
    maxConcurrent: 3,
    chunkSizeKB: 2048,
  },
  remoteView: {
    width: 1280,
    height: 720,
    fps: 10,
  },
  activity: {
    enabled: true,
    trackIdle: true,
    idleThresholdSeconds: 300,
  },
  security: {
    enableEncryption: true,
    enableVPN: false,
  },
  cleanup: {
    recordingDays: 7,
    screenshotDays: 15,
    logDays: 3,
    diskThresholdPercent: 80,
  },
  clientProtection: {
    allowUserExit: true,
    allowAutoStartToggle: true,
    restartOnKill: false,
    unlockCodeUnusedExpireMinutes: 30,
  },
});

const defaultClientProtectionForm = (): PolicyClientProtectionConfig => ({
  allowUserExit: true,
  allowAutoStartToggle: true,
  restartOnKill: false,
  unlockCodeUnusedExpireMinutes: 30,
});

const applyClientProtectionDefaultsToForm = async () => {
  try {
    const res = await settingsApi.getClientProtectionDefaults();
    Object.assign(form.clientProtection, res.data);
  } catch {
    Object.assign(form.clientProtection, defaultClientProtectionForm());
  }
};

// ========== 验证规则 ==========
const rules = {
  name: [{ required: true, message: "请输入策略名称", trigger: "blur" }],
};

// ========== 辅助函数 ==========
const formatDateTime = (time: string) => {
  if (!time) return "-";
  const date = new Date(time);
  return date.toLocaleString("zh-CN");
};

const formatPolicyContent = (content: string) => {
  try {
    return JSON.stringify(JSON.parse(content), null, 2);
  } catch {
    return content;
  }
};

// ========== 解析策略配置 ==========
const parsePolicyContent = (content: string): any => {
  if (!content) return {};
  try {
    return JSON.parse(content);
  } catch {
    return {};
  }
};

const getRecordingConfig = (policy: Policy) => {
  if (!policy || !policy.content) return null;
  const parsed = parsePolicyContent(policy.content);
  return parsed.config?.recording || null;
};

const getScreenshotConfig = (policy: Policy) => {
  if (!policy || !policy.content) return null;
  const parsed = parsePolicyContent(policy.content);
  return parsed.config?.screenshot || null;
};

const getActivityConfig = (policy: Policy) => {
  if (!policy || !policy.content) return null;
  const parsed = parsePolicyContent(policy.content);
  return parsed.config?.activity || null;
};

const getCleanupConfig = (policy: Policy) => {
  if (!policy || !policy.content) return null;
  const parsed = parsePolicyContent(policy.content);
  return parsed.config?.cleanup || null;
};

const getSecurityConfig = (policy: Policy) => {
  if (!policy || !policy.content) return null;
  const parsed = parsePolicyContent(policy.content);
  return parsed.config?.security || null;
};

const getRemoteViewConfig = (policy: Policy) => {
  if (!policy || !policy.content) return null;
  const parsed = parsePolicyContent(policy.content);
  return parsed.config?.remoteView || null;
};

const getClientProtectionConfig = (policy: Policy) => {
  if (!policy || !policy.content) return null;
  const parsed = parsePolicyContent(policy.content);
  return parsed.config?.clientProtection || null;
};

const normalizePolicyContent = (raw: any): PolicyContent => {
  const content: PolicyContent = {
    version: raw?.version ?? 1,
    rules: raw?.rules ?? [],
    config: raw?.config ? { ...raw.config } : {},
  };

  if (!content.config) content.config = {};

  const legacyKeys = [
    "recording",
    "screenshot",
    "upload",
    "remoteView",
    "activity",
    "security",
    "cleanup",
    "clientProtection",
  ] as const;

  for (const key of legacyKeys) {
    if (raw?.[key] && !content.config[key]) {
      content.config[key] = raw[key];
    }
  }

  return content;
};

// ========== 表单与JSON转换 ==========
// 将表单数据转换为 PolicyContent 对象
const formToPolicyContent = (version = 1): PolicyContent => {
  return {
    version,
    rules: [],
    config: {
      recording: {
        enabled: form.recording.enabled,
        fps: form.recording.fps,
        quality: form.recording.quality,
        enableGpu: form.recording.enableGpu,
        sliceMinutes: form.recording.sliceMinutes,
        autoUploadOnIndex: form.recording.autoUploadOnIndex,
      },
      upload: {
        enabled: form.upload.enabled,
        rateLimitKBps: form.upload.rateLimitKBps,
        maxConcurrent: form.upload.maxConcurrent,
        chunkSizeKB: form.upload.chunkSizeKB,
      },
      remoteView: {
        width: form.remoteView.width,
        height: form.remoteView.height,
        fps: form.remoteView.fps,
      },
      screenshot: {
        enabled: form.screenshot.enabled,
        intervalSeconds: form.screenshot.intervalSeconds,
        quality: form.screenshot.quality,
        format: form.screenshot.format,
      },
      activity: {
        enabled: form.activity.enabled,
        trackIdle: form.activity.trackIdle,
        idleThresholdSeconds: form.activity.idleThresholdSeconds,
      },
      security: {
        enableEncryption: form.security.enableEncryption,
        enableVPN: form.security.enableVPN,
      },
      cleanup: {
        enabled: true,
        recordingDays: form.cleanup.recordingDays,
        screenshotDays: form.cleanup.screenshotDays,
        logDays: form.cleanup.logDays,
        diskThresholdPercent: form.cleanup.diskThresholdPercent,
      },
      clientProtection: {
        allowUserExit: form.clientProtection.allowUserExit,
        allowAutoStartToggle: form.clientProtection.allowAutoStartToggle,
        restartOnKill: form.clientProtection.restartOnKill,
        unlockCodeUnusedExpireMinutes:
          form.clientProtection.unlockCodeUnusedExpireMinutes,
      },
    },
  };
};

// 将 PolicyContent 解析到表单
const policyContentToForm = (content: PolicyContent) => {
  // ✅ 必须从 config 对象中读取
  const config = content.config || {};

  // 录屏配置
  form.recording.enabled = config.recording?.enabled ?? true;
  form.recording.fps = config.recording?.fps ?? 5;
  form.recording.quality = config.recording?.quality ?? 70;
  form.recording.enableGpu = config.recording?.enableGpu ?? true;
  form.recording.sliceMinutes = config.recording?.sliceMinutes ?? 1;
  form.recording.autoUploadOnIndex = config.recording?.autoUploadOnIndex ?? false;

  form.upload.enabled = config.upload?.enabled ?? true;
  form.upload.rateLimitKBps = config.upload?.rateLimitKBps ?? 1024;
  form.upload.maxConcurrent = config.upload?.maxConcurrent ?? 3;
  form.upload.chunkSizeKB = config.upload?.chunkSizeKB ?? 2048;

  form.remoteView.width = config.remoteView?.width ?? 1280;
  form.remoteView.height = config.remoteView?.height ?? 720;
  form.remoteView.fps = config.remoteView?.fps ?? 10;

  // 截图配置
  form.screenshot.enabled = config.screenshot?.enabled ?? true;
  form.screenshot.intervalSeconds = config.screenshot?.intervalSeconds ?? 30;
  form.screenshot.quality = config.screenshot?.quality ?? 80;
  form.screenshot.format = config.screenshot?.format ?? "webp";

  // 活动日志配置
  form.activity.enabled = config.activity?.enabled ?? true;
  form.activity.trackIdle = config.activity?.trackIdle ?? true;
  form.activity.idleThresholdSeconds =
    config.activity?.idleThresholdSeconds ?? 300;

  // 安全配置
  form.security.enableEncryption = config.security?.enableEncryption ?? true;
  form.security.enableVPN = config.security?.enableVPN ?? false;

  // 清理策略
  form.cleanup.recordingDays = config.cleanup?.recordingDays ?? 7;
  form.cleanup.screenshotDays = config.cleanup?.screenshotDays ?? 15;
  form.cleanup.logDays = config.cleanup?.logDays ?? 3;
  form.cleanup.diskThresholdPercent =
    config.cleanup?.diskThresholdPercent ?? 80;

  const cp = config.clientProtection;
  form.clientProtection.allowUserExit = cp?.allowUserExit ?? true;
  form.clientProtection.allowAutoStartToggle = cp?.allowAutoStartToggle ?? true;
  form.clientProtection.restartOnKill = cp?.restartOnKill ?? false;
  form.clientProtection.unlockCodeUnusedExpireMinutes =
    cp?.unlockCodeUnusedExpireMinutes ?? 30;
};

// 同步表单到 JSON 文本框
const syncFormToJson = () => {
  const content = formToPolicyContent();
  form.contentText = JSON.stringify(content, null, 2);
  form.contentError = "";
  ElMessage.success("已从表单同步到JSON");
};

// 获取提交时的内容
const getSubmitContent = (): PolicyContent => {
  if (showAdvanced.value && form.contentText && !form.contentError) {
    try {
      return normalizePolicyContent(JSON.parse(form.contentText));
    } catch {
      return formToPolicyContent();
    }
  }
  return formToPolicyContent();
};

// 保存时自动递增版本号，确保客户端能识别策略更新
const buildContentForSave = (): PolicyContent => {
  const content = getSubmitContent();
  if (isEditing.value && currentPolicy.value) {
    content.version = currentPolicy.value.version + 1;
  } else {
    content.version = content.version ?? 1;
  }
  return content;
};

const formatJson = () => {
  try {
    const parsed = normalizePolicyContent(JSON.parse(form.contentText));
    form.contentText = JSON.stringify(parsed, null, 2);
    form.contentError = "";
    ElMessage.success("格式化成功");
  } catch (e: any) {
    ElMessage.error(`格式化失败: ${e.message}`);
  }
};

const validateJson = () => {
  try {
    const parsed = normalizePolicyContent(JSON.parse(form.contentText));
    form.contentText = JSON.stringify(parsed, null, 2);
    form.contentError = "";
    ElMessage.success("JSON 格式正确，已规范化到 config.* 结构");
  } catch (e: any) {
    ElMessage.error(`JSON 格式错误: ${e.message}`);
  }
};

// 完整的客户端支持模板
const getFullTemplate = () => `{
  "version": 1,
  "rules": [],
  "config": {
    "recording": {
      "enabled": true,
      "fps": 5,
      "quality": 70,
      "enableGpu": true,
      "sliceMinutes": 1,
      "autoUploadOnIndex": false
    },
    "upload": {
      "enabled": true,
      "rateLimitKBps": 1024,
      "maxConcurrent": 3,
      "chunkSizeKB": 2048
    },
    "remoteView": {
      "width": 1280,
      "height": 720,
      "fps": 10
    },
    "screenshot": {
      "enabled": true,
      "intervalSeconds": 30,
      "quality": 70,
      "format": "webp"
    },
    "activity": {
      "enabled": true,
      "trackIdle": true,
      "idleThresholdSeconds": 300
    },
    "security": {
      "enableEncryption": true,
      "enableVPN": false
    },
    "cleanup": {
      "enabled": true,
      "recordingDays": 7,
      "screenshotDays": 15,
      "logDays": 3,
      "diskThresholdPercent": 80
    },
    "clientProtection": {
      "allowUserExit": true,
      "allowAutoStartToggle": true,
      "restartOnKill": false,
      "unlockCodeUnusedExpireMinutes": 30
    }
  }
}`;

const showTemplate = () => {
  form.contentText = getFullTemplate();
  ElMessage.success("已重置为完整模板");
};

// ========== 数据加载 ==========
const loadPolicies = async () => {
  listLoading.value = true;
  try {
    const { data } = await policyApi.list();
    policies.value = data;
  } catch (error: any) {
    ElMessage.error(error.message || "加载策略列表失败");
  } finally {
    listLoading.value = false;
  }
};

// 显示策略帮助说明
const showPolicyHelp = () => {
  ElMessageBox.alert(
    `<div style="line-height: 1.8;">
      <p style="margin-bottom: 12px; font-weight: bold;">📋 策略说明</p>
      <p style="margin-bottom: 8px;">此策略用于控制<strong style="color: #409eff;">客户端设备</strong>的行为，包括：</p>
      <ul style="margin: 8px 0 12px 20px; padding-left: 0;">
        <li>🎬 录屏配置（帧率、画质、GPU加速、分段时长）</li>
        <li>📸 截图配置（间隔、画质、格式）</li>
        <li>📊 活动日志配置（空闲检测、阈值）</li>
        <li>🗑 本地清理策略（保留天数、磁盘阈值）</li>
        <li>🛡 客户端防护（退出、自启动、杀进程拉起、解锁码有效期）</li>
        <li>🔒 安全配置（加密传输、VPN要求）</li>
        <li>🛡 客户端防护（页面顶部：退出/自启动/解锁码等全局默认，保存后立即下发）</li>
      </ul>
      <p style="color: #909399; font-size: 12px; margin-top: 8px;">
        💡 发布后自动推送到所有在线设备，设备会按策略执行相应功能。
      </p>
    </div>`,
    "策略说明",
    {
      dangerouslyUseHTMLString: true,
      confirmButtonText: "知道了",
      type: "info",
      customClass: "policy-help-dialog",
    },
  );
};

// ========== 策略操作 ==========
const selectPolicy = async (policy: Policy) => {
  currentPolicy.value = policy;
  isEditing.value = true;
  form.id = policy.id;
  form.name = policy.name;

  try {
    const parsed = normalizePolicyContent(JSON.parse(policy.content));
    policyContentToForm(parsed);
    if (!parsed.config?.clientProtection) {
      await applyClientProtectionDefaultsToForm();
    }
    form.contentText = JSON.stringify(
      formToPolicyContent(parsed.version ?? policy.version),
      null,
      2,
    );
    form.contentError = "";
  } catch {
    form.contentText = policy.content;
  }
  drawerVisible.value = true;
};
const handleCreate = async () => {
  currentPolicy.value = null;
  isEditing.value = false;
  form.id = "";
  form.name = "";
  // 重置表单为默认值
  form.recording = {
    enabled: true,
    fps: 5,
    quality: 70,
    enableGpu: true,
    sliceMinutes: 1,
    autoUploadOnIndex: false,
  };
  form.screenshot = {
    enabled: true,
    intervalSeconds: 30,
    quality: 70,
    format: "webp",
  };
  form.upload = {
    enabled: true,
    rateLimitKBps: 1024,
    maxConcurrent: 3,
    chunkSizeKB: 2048,
  };
  form.remoteView = {
    width: 1280,
    height: 720,
    fps: 10,
  };
  form.activity = {
    enabled: true,
    trackIdle: true,
    idleThresholdSeconds: 300,
  };
  form.security = {
    enableEncryption: true,
    enableVPN: false,
  };
  form.cleanup = {
    recordingDays: 30,
    screenshotDays: 30,
    logDays: 90,
    diskThresholdPercent: 80,
  };
  await applyClientProtectionDefaultsToForm();
  form.contentError = "";
  syncFormToJson();
  drawerVisible.value = true;
};

const handleSave = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
  } catch {
    return;
  }

  const content = buildContentForSave();

  // ✅ 修改验证逻辑：检查 config 中是否有任何配置
  const config = content.config || {};
  const hasAnyConfig =
    Object.keys(config.recording || {}).length > 0 ||
    Object.keys(config.upload || {}).length > 0 ||
    Object.keys(config.remoteView || {}).length > 0 ||
    Object.keys(config.screenshot || {}).length > 0 ||
    Object.keys(config.activity || {}).length > 0 ||
    Object.keys(config.security || {}).length > 0 ||
    Object.keys(config.cleanup || {}).length > 0 ||
    Object.keys(config.clientProtection || {}).length > 0;

  if (!hasAnyConfig) {
    ElMessage.error("至少需要配置一项策略内容");
    return;
  }

  saveLoading.value = true;
  try {
    if (isEditing.value && currentPolicy.value) {
      await policyApi.update(form.id, form.name, content);
      if (currentPolicy.value.isCurrent) {
        await policyApi.publish(currentPolicy.value.id);
        ElMessage.success("策略已保存并推送到所有设备");
      } else {
        ElMessage.success("策略已保存（草稿需点击「发布」后才会下发到设备）");
      }
    } else {
      await policyApi.create(form.name, content);
      ElMessage.success("策略创建成功");
    }
    drawerVisible.value = false;
    await loadPolicies();
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    saveLoading.value = false;
  }
};

const publishPolicy = async (policy: Policy) => {
  publishLoading.value = true;
  try {
    await policyApi.publish(policy.id);
    ElMessage.success("策略发布成功，已推送到所有设备");
    await loadPolicies();
  } catch (error: any) {
    ElMessage.error(error.message || "发布失败");
  } finally {
    publishLoading.value = false;
  }
};

const handleSaveAndPublish = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
  } catch {
    return;
  }

  saveAndPublishLoading.value = true;

  try {
    const content = buildContentForSave();

    // 1. 先保存更新
    await policyApi.update(form.id, form.name, content);
    ElMessage.success("策略保存成功");

    // 2. 再发布
    if (currentPolicy.value) {
      await policyApi.publish(currentPolicy.value.id);
      ElMessage.success("策略发布成功，已推送到所有设备");
    }

    drawerVisible.value = false;
    await loadPolicies();
  } catch (error: any) {
    ElMessage.error(error.message || "保存并发布失败");
  } finally {
    saveAndPublishLoading.value = false;
  }
};

const handlePublish = async () => {
  if (!currentPolicy.value) return;
  await publishPolicy(currentPolicy.value);
  drawerVisible.value = false;
};

const rollbackPolicy = async (policy: Policy) => {
  try {
    await ElMessageBox.confirm(
      "确定要回滚到上一个版本吗？当前版本的配置将被覆盖。",
      "警告",
      {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      },
    );
  } catch {
    return;
  }

  rollbackLoading.value = true;
  try {
    await policyApi.rollback(policy.id);
    ElMessage.success("策略已回滚到上一个版本");
    await loadPolicies();
  } catch (error: any) {
    ElMessage.error(error.message || "回滚失败");
  } finally {
    rollbackLoading.value = false;
  }
};

const deletePolicy = async (policy: Policy) => {
  deleteLoading.value = true;
  try {
    await policyApi.delete(policy.id);
    ElMessage.success("策略已删除");
    await loadPolicies();
  } catch (error: any) {
    ElMessage.error(error.message || "删除失败");
  } finally {
    deleteLoading.value = false;
  }
};

// ========== 详情对话框 ==========
const showDetail = (policy: Policy) => {
  detailPolicy.value = policy;
  detailVisible.value = true;
};

const editFromDetail = () => {
  if (detailPolicy.value) {
    detailVisible.value = false;
    selectPolicy(detailPolicy.value);
  }
};

const publishFromDetail = () => {
  if (detailPolicy.value) {
    detailVisible.value = false;
    publishPolicy(detailPolicy.value);
  }
};

// ========== 监听表单变化，自动更新 JSON（可选）==========
watch(
  () => [
    form.recording,
    form.screenshot,
    form.activity,
    form.security,
    form.cleanup,
    form.clientProtection,
  ],
  () => {
    if (!showAdvanced.value) {
      syncFormToJson();
    }
  },
  { deep: true },
);

// ========== 生命周期 ==========
const handlePolicyUpdate = () => {
  ElMessage.info("收到新策略更新");
  loadPolicies();
};

onMounted(() => {
  loadPolicies();
  window.addEventListener("policy-update", handlePolicyUpdate);
});

onUnmounted(() => {
  window.removeEventListener("policy-update", handlePolicyUpdate);
});
</script>

<style scoped>
.policies-page {
  padding: 0px;
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
}

.section-hint {
  margin: -8px 0 16px;
  font-size: 12px;
  color: #909399;
}

.field-hint {
  margin-top: 4px;
  font-size: 12px;
  color: #909399;
  line-height: 1.4;
}

/* ========== 背景装饰 ========== */
.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}

.blob-1 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -200px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 600px;
  height: 600px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -250px;
  left: -150px;
  animation-delay: -5s;
}

.blob-3 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 30%;
  animation-delay: -10s;
}

@keyframes float {
  0%,
  100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -30px) scale(1.05);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.95);
  }
}

/* 确保内容在背景之上 */
.toolbar-card,
.table-card,
.policy-drawer,
.policy-detail-dialog {
  position: relative;
  z-index: 1;
}

/* 工具栏卡片 */
.toolbar-card {
  margin-bottom: 20px;
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  transition: all 0.3s ease;
}

.toolbar-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}

.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 16px;
}

.toolbar-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 24px;
  color: #409eff;
}

.title {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}

.toolbar-right {
  display: flex;
  gap: 12px;
}

/* 表格卡片 */
.table-card {
  border-radius: 16px;
  overflow: hidden;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  transition: all 0.3s ease;
}

.table-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}

/* 按钮样式 */
:deep(.el-button--primary) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border: none;
  transition: all 0.3s ease;
}

:deep(.el-button--primary):hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

:deep(.el-button--success) {
  background: linear-gradient(135deg, #43e97b, #38f9d7);
  border: none;
  color: #1a1a2e;
}

:deep(.el-button--success):hover {
  transform: translateY(-2px);
}

/* 抽屉样式 */
.policy-drawer :deep(.el-drawer__header) {
  margin-bottom: 0;
  padding: 16px 20px;
  background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
  color: white;
  border-bottom: none;
}

.policy-drawer :deep(.el-drawer__title) {
  color: white;
  font-weight: 600;
}

.policy-drawer :deep(.el-drawer__close-btn) {
  color: white;
}

.policy-drawer :deep(.el-drawer__body) {
  padding: 20px;
  background: rgba(255, 255, 255, 0.98);
}

/* 对话框样式 */
.policy-detail-dialog :deep(.el-dialog) {
  border-radius: 20px;
  overflow: hidden;
}

.policy-detail-dialog :deep(.el-dialog__header) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  padding: 16px 20px;
  margin: 0;
}

.policy-detail-dialog :deep(.el-dialog__title) {
  color: white;
  font-weight: 600;
  font-size: 18px;
}

.policy-detail-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: white;
  font-size: 18px;
}

.policy-detail-dialog :deep(.el-dialog__body) {
  padding: 20px;
  max-height: 60vh;
  overflow-y: auto;
}

/* 配置卡片样式 */
.config-card {
  background: rgba(248, 250, 252, 0.9);
  border-radius: 8px;
  padding: 8px 10px;
  font-size: 12px;
  transition: all 0.2s ease;
}

.config-card:hover {
  background: rgba(241, 245, 249, 0.95);
  transform: translateX(2px);
}

/* 响应式 */
@media (max-width: 1200px) {
  .policies-page {
    padding: 16px;
  }

  .blob-1,
  .blob-2,
  .blob-3 {
    opacity: 0.2;
  }
}

@media (max-width: 768px) {
  .policies-page {
    padding: 12px;
  }

  .blob-1,
  .blob-2,
  .blob-3 {
    display: none;
  }

  .toolbar {
    flex-direction: column;
    align-items: flex-start;
  }

  .toolbar-right {
    width: 100%;
    justify-content: flex-start;
  }

  .policy-drawer :deep(.el-drawer) {
    width: 90% !important;
  }
}

/* 其他原有样式保持不变 */
/* 胶囊按钮样式 */
.policy-name-link {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 16px;
  background: #f0f2f5;
  border-radius: 30px;
  font-size: 13px;
  font-weight: 500;
  color: #409eff;
  transition: all 0.2s ease;
}

.policy-name-link:hover {
  background: #e6f7ff;
  transform: scale(1.02);
}

.policy-name-link .el-icon {
  font-size: 14px;
}

.text-muted {
  color: #c0c4cc;
  font-size: 12px;
}

.drawer-content {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.drawer-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding-top: 20px;
  border-top: 1px solid #ebeef5;
  margin-top: 20px;
}

.policy-textarea :deep(textarea) {
  font-family: "Monaco", "Menlo", "Consolas", monospace;
  font-size: 13px;
  line-height: 1.5;
  background: #fafafa;
}

.json-tip {
  margin-top: 12px;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.version-vertical {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.status-cell {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  flex-wrap: wrap;
}

.active-badge {
  font-size: 10px;
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
}

.config-detail-list {
  margin-top: 4px;
  padding-left: 4px;
  border-left: 2px solid #409eff;
}

.config-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  margin-bottom: 4px;
}

.config-row:last-child {
  margin-bottom: 0;
}

.config-label {
  color: #909399;
  min-width: 62px;
  font-size: 12px;
}

.config-value {
  color: #303133;
  font-weight: 500;
}

.detail-config-group {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}

.detail-config-item {
  display: flex;
  align-items: center;
  gap: 8px;
}

.detail-label {
  font-size: 12px;
  color: #909399;
  min-width: 70px;
}

.policy-content-preview {
  max-height: 300px;
  overflow: auto;
  background: #f5f7fa;
  padding: 12px;
  border-radius: 8px;
  font-family: monospace;
  font-size: 12px;
  margin: 0;
  white-space: pre-wrap;
  word-break: break-all;
}

.help-icon {
  margin-left: 6px;
  font-size: 14px;
  cursor: pointer;
  vertical-align: middle;
  transition: all 0.2s ease;
}

.help-icon:hover {
  color: #409eff;
  transform: scale(1.1);
}

/* 滚动条美化 */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(135deg, #5a67d8, #6b46c1);
}

/* 操作按钮组 */
.action-buttons {
  display: flex;
  gap: 6px;
  justify-content: center;
  flex-wrap: wrap;
}

.action-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  border-radius: 16px;
  font-size: 12px;
  font-weight: 500;
  transition: all 0.2s ease;
}

/* 编辑按钮 */
.edit-btn {
  background: rgba(64, 158, 255, 0.1);
  color: #409eff;
}

.edit-btn:hover {
  background: rgba(64, 158, 255, 0.2);
  transform: translateY(-1px);
}

/* 发布按钮 */
.publish-btn {
  background: rgba(103, 194, 58, 0.1);
  color: #67c23a;
}

.publish-btn:hover {
  background: rgba(103, 194, 58, 0.2);
  transform: translateY(-1px);
}

/* 回滚按钮 */
.rollback-btn {
  background: rgba(230, 162, 60, 0.1);
  color: #e6a23c;
}

.rollback-btn:hover {
  background: rgba(230, 162, 60, 0.2);
  transform: translateY(-1px);
}

/* 删除按钮 */
.delete-btn {
  background: rgba(245, 108, 108, 0.1);
  color: #f56c6c;
}

.delete-btn:hover {
  background: rgba(245, 108, 108, 0.2);
  transform: translateY(-1px);
}

/* 按钮图标样式 */
.action-btn .el-icon {
  font-size: 13px;
}

.action-btn:hover .el-icon {
  transform: scale(1.05);
}
</style>

; Enterprise Agent installer (Inno Setup 6)
; Build via scripts/publish-client.ps1 (requires ISCC on PATH)
; Pass publish output: ISCC.exe "/DSourcePath=C:\path\to\agent\publish\win-x64" EnterpriseAgent.iss

#ifndef SourcePath
  #define SourcePath "..\agent\publish\win-x64"
#endif

#define MyAppName "Enterprise Agent"
#define MyAppPublisher "Enterprise"
#define MyAppExeName "DHPG.exe"
#define MyAppVersion GetVersionNumbersString(AddBackslash(SourcePath) + "DHPG.exe")
#define PublishRoot AddBackslash(SourcePath)

[Setup]
AppId={{A7B4E2C1-9F3D-4E8A-B1C6-2D5E8F0A3B7C}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\DHPGAgent
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputBaseFilename=MonitorAgentSetup
OutputDir=..\downloads
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}
CloseApplications=force
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "{#PublishRoot}*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
; NOTE: Do not use "Flags: ignoreversion" on shared system files

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Parameters: "--ui"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Parameters: "--ui"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Parameters: "--ui"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{cmd}"; Parameters: "/C taskkill /F /IM DHPG.exe /T & taskkill /F /IM ffmpeg.exe /T"; Flags: runhidden skipifdoesntexist

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  ResultCode: Integer;
begin
  if CurUninstallStep = usUninstall then
  begin
    Exec('schtasks.exe', '/Delete /TN "DHPG-Agent" /F', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  end;
end;

using System.Text.RegularExpressions;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 与 TG 推送一致的时长/时刻展示（时分秒）。
/// </summary>
public static class DurationFormatter
{
    public static string FormatDurationZh(int totalSeconds)
    {
        if (totalSeconds < 0)
            totalSeconds = 0;

        var hours = totalSeconds / 3600;
        var minutes = (totalSeconds % 3600) / 60;
        var seconds = totalSeconds % 60;

        if (hours > 0)
            return $"{hours}时{minutes}分{seconds}秒";
        if (minutes > 0)
            return $"{minutes}分{seconds}秒";
        return $"{seconds}秒";
    }

    public static string FormatTimeOfDay(DateTime time)
        => time.ToString("HH:mm:ss");

    /// <summary>
    /// 将通知文案中的「用时 233 秒」等裸秒数替换为时分秒展示。
    /// </summary>
    public static string NormalizeMessageDurations(string? message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return message ?? string.Empty;

        return DurationInMessageRegex().Replace(message, match =>
        {
            var prefix = match.Groups[1].Value;
            if (!int.TryParse(match.Groups[2].Value, out var seconds) || seconds < 0)
                return match.Value;
            return $"{prefix} {FormatDurationZh(seconds)}";
        });
    }

    private static Regex DurationInMessageRegex() => new(
        @"(用时|超时时长|已超时|超时超过|剩余约)\s*(\d+)\s*秒",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);
}

namespace EnterpriseAgent.Agent.Capture;

public readonly record struct PipeConsumerWriteResult(bool Written, bool TimedOut);

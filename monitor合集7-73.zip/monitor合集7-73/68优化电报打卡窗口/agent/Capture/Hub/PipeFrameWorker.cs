using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Capture.Hub;

public interface IFrameWorkerHost
{
    void OnWorkerFirstFrame(CaptureConsumer consumer);
    void OnWorkerPipeFailure(CaptureConsumer consumer, Exception ex);
}

/// <summary>Hub reader → named pipe writer with Sequential or LatestOnly policy.</summary>
public sealed class PipeFrameWorker
{
    private readonly ILogger _logger;
    private readonly SharedFrameHub _hub;
    private readonly SharedCapturePipeHost _pipeHost;
    private readonly IFrameWorkerHost _host;
    private readonly CaptureConsumer _consumer;
    private readonly FrameHubReadPolicy _policy;
    private readonly int _writeTimeoutMs;
    private readonly string _label;

    private long _lastGeneration;
    private bool _notifiedFirst;
    private long _lastHubOverwrites;

    public PipeFrameWorker(
        ILogger logger,
        SharedFrameHub hub,
        SharedCapturePipeHost pipeHost,
        IFrameWorkerHost host,
        CaptureConsumer consumer,
        FrameHubReadPolicy policy,
        int writeTimeoutMs = 0)
    {
        _logger = logger;
        _hub = hub;
        _pipeHost = pipeHost;
        _host = host;
        _consumer = consumer;
        _policy = policy;
        _writeTimeoutMs = Math.Max(writeTimeoutMs, 0);
        _label = consumer == CaptureConsumer.Recording ? "RecordingWorker" : "RemoteWorker";
        Stats = new FrameWorkerStats();
    }

    public FrameWorkerStats Stats { get; }

    /// <summary>Reset reader cursor after remote pipe / FFmpeg epoch change.</summary>
    public void ResetReader(bool snapToLatest = true)
    {
        _lastGeneration = snapToLatest ? _hub.LatestGeneration : 0;
        _notifiedFirst = false;
        _lastHubOverwrites = _hub.DroppedOverwrites;
        _logger.LogInformation(
            "{Label} reader reset snapToLatest={Snap} lastGen={Gen}",
            _label,
            snapToLatest,
            _lastGeneration);
    }

    public async Task RunAsync(CancellationToken cancellationToken)
    {
        _lastHubOverwrites = _hub.DroppedOverwrites;

        while (!cancellationToken.IsCancellationRequested && _hub.IsActive)
        {
            TrackHubRingDrops();

            if (!_hub.WaitForFrame(ref _lastGeneration, TimeSpan.FromMilliseconds(500), cancellationToken))
                continue;

            if (_policy == FrameHubReadPolicy.LatestOnly)
                await ProcessLatestAsync(cancellationToken);
            else
                await ProcessSequentialAsync(cancellationToken);
        }
    }

    private async Task ProcessLatestAsync(CancellationToken cancellationToken)
    {
        if (!_hub.TryAcquireLatest(ref _lastGeneration, out var lease, out var skipped) || !lease.IsValid)
            return;

        if (skipped > 0)
            Stats.RecordSkipped(skipped);

        await WriteLeaseAsync(lease, cancellationToken);
    }

    private async Task ProcessSequentialAsync(CancellationToken cancellationToken)
    {
        while (_hub.TryAcquireSequential(ref _lastGeneration, out var lease) && lease.IsValid)
            await WriteLeaseAsync(lease, cancellationToken);
    }

    private async Task WriteLeaseAsync(FrameHubLease lease, CancellationToken cancellationToken)
    {
        try
        {
            var result = await _pipeHost.WriteConsumerFrameAsync(
                _consumer,
                lease.Memory,
                cancellationToken,
                _writeTimeoutMs > 0 ? TimeSpan.FromMilliseconds(_writeTimeoutMs) : null);

            if (result.TimedOut)
            {
                Stats.RecordWriteTimeout();
                return;
            }

            if (!result.Written)
            {
                Stats.RecordPipeUnavailable();
                return;
            }

            Stats.RecordWritten();

            if (!_notifiedFirst)
            {
                _notifiedFirst = true;
                _host.OnWorkerFirstFrame(_consumer);
            }
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException)
        {
            _logger.LogWarning(ex, "{Label} pipe write failed", _label);
            _host.OnWorkerPipeFailure(_consumer, ex);
        }
        finally
        {
            lease.Release();
        }
    }

    private void TrackHubRingDrops()
    {
        var overwrites = _hub.DroppedOverwrites;
        if (overwrites > _lastHubOverwrites)
        {
            Stats.RecordHubRingDrops(overwrites - _lastHubOverwrites);
            _lastHubOverwrites = overwrites;
        }
    }
}

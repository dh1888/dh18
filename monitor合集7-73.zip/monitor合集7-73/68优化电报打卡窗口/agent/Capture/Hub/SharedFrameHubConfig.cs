namespace EnterpriseAgent.Agent.Capture.Hub;

public sealed class SharedFrameHubConfig
{
    /// <summary>Fixed-size frame pool / ring slot count.</summary>
    public int PoolSlotCount { get; set; } = 4;

    public FrameHubReadPolicy RecordingReaderPolicy { get; set; } = FrameHubReadPolicy.Sequential;

    /// <summary>Remote: LatestOnly drops stale frames when pipe/encoder is slow (P2 default).</summary>
    public FrameHubReadPolicy RemoteReaderPolicy { get; set; } = FrameHubReadPolicy.LatestOnly;

    /// <summary>
    /// Remote pipe write timeout (ms). 0 = block until written.
    /// When &gt; 0 and write exceeds timeout, frame is dropped and worker grabs next latest.
    /// </summary>
    public int RemotePipeWriteTimeoutMs { get; set; } = 80;

    /// <summary>After bridge flowing, optional delay before launching remote FFmpeg (Enter plan B).</summary>
    public int EnterRemoteWarmMs { get; set; } = 200;
}

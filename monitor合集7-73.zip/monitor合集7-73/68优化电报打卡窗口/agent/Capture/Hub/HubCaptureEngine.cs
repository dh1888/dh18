using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Capture.Hub;

/// <summary>gdigrab FFmpeg producer → SharedFrameHub.Publish.</summary>
public sealed class HubCaptureEngine
{
    private readonly ILogger _logger;
    private readonly SharedFrameHub _hub;

    public HubCaptureEngine(ILogger logger, SharedFrameHub hub)
    {
        _logger = logger;
        _hub = hub;
    }

    public async Task RunAsync(
        Process process,
        byte[] readBuffer,
        Action onFramePublished,
        CancellationToken cancellationToken)
    {
        var stdout = process.StandardOutput.BaseStream;

        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                if (process.HasExited)
                    break;

                var offset = 0;
                while (offset < readBuffer.Length)
                {
                    var read = await stdout.ReadAsync(
                        readBuffer.AsMemory(offset, readBuffer.Length - offset),
                        cancellationToken);
                    if (read == 0)
                        throw new EndOfStreamException("Capture stdout ended before full frame");

                    offset += read;
                }

                _hub.Publish(readBuffer);
                onFramePublished();
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // expected
        }
        catch (EndOfStreamException ex)
        {
            _logger.LogWarning(ex, "SharedFrameHub capture stdout ended");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "SharedFrameHub capture engine failed");
            throw;
        }
    }

    public static Process StartGdigrabProcess(
        ILogger logger,
        string ffmpeg,
        int width,
        int height,
        int fps,
        CancellationToken cancellationToken)
    {
        var args =
            $"-hide_banner -loglevel error -nostats " +
            $"-f gdigrab -framerate {fps} -i desktop " +
            $"-vf \"fps={fps},scale={width}:{height}:force_original_aspect_ratio=decrease," +
            $"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,format=bgr24\" " +
            "-f rawvideo -pix_fmt bgr24 -";

        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = ffmpeg,
                Arguments = args,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true,
                RedirectStandardOutput = true,
            },
            EnableRaisingEvents = true,
        };

        if (!process.Start())
            throw new InvalidOperationException("Failed to start SharedFrameHub capture process");

        _ = Task.Run(async () =>
        {
            try
            {
                while (!cancellationToken.IsCancellationRequested &&
                       !process.HasExited &&
                       process.StandardError.ReadLine() is { } line)
                {
                    if (line.Contains("error", StringComparison.OrdinalIgnoreCase))
                        logger.LogWarning("Capture producer: {Line}", line);
                }
            }
            catch
            {
                // ignore stderr drain errors
            }
        }, CancellationToken.None);

        return process;
    }
}

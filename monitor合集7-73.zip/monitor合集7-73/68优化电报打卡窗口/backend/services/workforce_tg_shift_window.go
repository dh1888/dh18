package services

import (
	"fmt"
	"strings"
	"time"
)

func isWithinWindowAsymmetric(nowMin, startMin, endMin, graceBefore, graceAfter int) bool {
	startMin -= graceBefore
	endMin += graceAfter
	if startMin < 0 {
		startMin = 0
	}
	if endMin > 24*60-1 {
		endMin = 24*60 - 1
	}
	if startMin <= endMin {
		return nowMin >= startMin && nowMin <= endMin
	}
	return nowMin >= startMin || nowMin <= endMin
}

func resolveNightShiftDetail(settings *TelegramSettings, now time.Time) string {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	nowMin := minutesOfDay(now)
	dayEndH, dayEndM, ok1 := parseClock(settings.DayEnd)
	nightStartH, nightStartM, ok2 := parseClock(settings.NightStart)
	if !ok1 || !ok2 {
		return "night_tonight"
	}
	dayEnd := clockToMinutes(dayEndH, dayEndM)
	nightStart := clockToMinutes(nightStartH, nightStartM)
	if nowMin >= nightStart {
		return "night_tonight"
	}
	if nowMin < dayEnd {
		return "night_last"
	}
	return "night_tonight"
}

func nightRecordDateForDetail(businessDate, detail string) string {
	// DetermineCurrentPeriod 已按凌晨/夜间给出正确业务日；
	// night_last 不再二次减一天，避免 01:xx 被记到大前天。
	_ = detail
	return businessDate
}

// resolveAttendanceDate 返回按班次解释的统一业务日（attendance_date）。
// 白班：配置时区自然日（day_start 前也不落在昨夜业务日）；
// 夜班：周期业务日（DetermineCurrentPeriod.BusinessDate）。
func resolveAttendanceDate(shift, shiftDetail string, period *TgPeriodInfo, now time.Time, loc *time.Location) string {
	now = now.In(loc)
	if shift == "day" {
		return now.Format("2006-01-02")
	}
	bd := now.Format("2006-01-02")
	if period != nil && strings.TrimSpace(period.BusinessDate) != "" {
		bd = period.BusinessDate
	}
	return nightRecordDateForDetail(bd, shiftDetail)
}

func (s *WorkforceTelegramService) resolveCurrentShiftWithGrace(settings *TelegramSettings, grace TgGraceConfig, now time.Time) (shift, shiftDetail string, err error) {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	nowMin := minutesOfDay(now)

	dayStartH, dayStartM, ok1 := parseClock(settings.DayStart)
	dayEndH, dayEndM, ok2 := parseClock(settings.DayEnd)
	if !ok1 || !ok2 {
		return "day", "", nil
	}
	dayStart := clockToMinutes(dayStartH, dayStartM)
	dayEnd := clockToMinutes(dayEndH, dayEndM)

	if !settings.DualShiftEnabled {
		if isWithinWindowAsymmetric(nowMin, dayStart, dayEnd, grace.ShiftGraceBefore, grace.ShiftGraceAfter) {
			return "day", "", nil
		}
		return "", "", ErrOutsideWorkWindow
	}

	nightStartH, nightStartM, ok3 := parseClock(settings.NightStart)
	nightEndH, nightEndM, ok4 := parseClock(settings.NightEnd)
	if !ok3 || !ok4 {
		return "", "", fmt.Errorf("invalid night shift window")
	}
	nightStart := clockToMinutes(nightStartH, nightStartM)
	nightEnd := clockToMinutes(nightEndH, nightEndM)

	if isWithinWindowAsymmetric(nowMin, dayStart, dayEnd, grace.ShiftGraceBefore, grace.ShiftGraceAfter) {
		return "day", "", nil
	}
	if isWithinWindowAsymmetric(nowMin, nightStart, nightEnd, grace.ShiftGraceBefore, grace.ShiftGraceAfter) {
		return "night", resolveNightShiftDetail(settings, now), nil
	}
	return "", "", ErrOutsideWorkWindow
}

func (s *WorkforceTelegramService) isForcedShiftAllowed(settings *TelegramSettings, grace TgGraceConfig, forcedShift string, now time.Time) bool {
	shift, _, err := s.resolveCurrentShiftWithGrace(settings, grace, now)
	if err != nil {
		shift = ""
	}
	forced, _ := normalizeShiftType(forcedShift)
	if shift == forced {
		return true
	}
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	nowMin := minutesOfDay(now)
	if forced == "day" {
		dayStartH, dayStartM, _ := parseClock(settings.DayStart)
		dayEndH, dayEndM, _ := parseClock(settings.DayEnd)
		return isWithinWindowAsymmetric(nowMin, clockToMinutes(dayStartH, dayStartM), clockToMinutes(dayEndH, dayEndM), grace.ShiftGraceBefore, grace.ShiftGraceAfter)
	}
	if forced == "night" {
		nightStartH, nightStartM, _ := parseClock(settings.NightStart)
		nightEndH, nightEndM, _ := parseClock(settings.NightEnd)
		return isWithinWindowAsymmetric(nowMin, clockToMinutes(nightStartH, nightStartM), clockToMinutes(nightEndH, nightEndM), grace.ShiftGraceBefore, grace.ShiftGraceAfter)
	}
	return false
}

func shiftWindowHint(settings *TelegramSettings, forcedShift string) string {
	forced, _ := normalizeShiftType(forcedShift)
	if forced == "night" {
		return fmt.Sprintf("当前不在夜班窗口，请在 %s–%s（含宽容）内打夜班卡", settings.NightStart, settings.NightEnd)
	}
	return fmt.Sprintf("当前不在白班窗口，请在 %s–%s（含宽容）内打白班卡", settings.DayStart, settings.DayEnd)
}

func (s *WorkforceTelegramService) resolveShiftForCheckIn(settings *TelegramSettings, grace TgGraceConfig, shiftWindowDisabled bool, forcedShift string, now time.Time) (shift, shiftDetail string, err error) {
	if forcedShift != "" {
		shift, err = normalizeShiftType(forcedShift)
		if err != nil {
			return "", "", err
		}
		if shiftWindowDisabled {
			detail := ""
			if shift == "night" {
				detail = resolveNightShiftDetail(settings, now)
			}
			return shift, detail, nil
		}
		if !s.isForcedShiftAllowed(settings, grace, forcedShift, now) {
			return "", "", fmt.Errorf("%s；%w", shiftWindowHint(settings, forcedShift), ErrOutsideWorkWindow)
		}
		detail := ""
		if shift == "night" {
			detail = resolveNightShiftDetail(settings, now)
		}
		return shift, detail, nil
	}
	if shiftWindowDisabled {
		// 「不限打卡时段」只放开窗口校验；双班开启时仍按当前时间归班，避免凌晨默认白班。
		if settings.DualShiftEnabled {
			if shift, detail, err := s.resolveCurrentShiftWithGrace(settings, grace, now); err == nil {
				return shift, detail, nil
			}
		}
		return "day", "", nil
	}
	return s.resolveCurrentShiftWithGrace(settings, grace, now)
}

func shiftDetailLabel(detail string) string {
	switch strings.TrimSpace(detail) {
	case "night_last":
		return "（昨晚夜班）"
	case "night_tonight":
		return "（今晚夜班）"
	default:
		return ""
	}
}

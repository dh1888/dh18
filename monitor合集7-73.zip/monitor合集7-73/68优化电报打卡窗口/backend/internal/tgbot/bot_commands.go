package tgbot

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	processedUpdates  = map[int64]time.Time{}
	cachedAdminIDs    = map[int64]bool{}
	actionRateMu      sync.Mutex
	actionRateCalls   = map[string][]time.Time{}
)

func isDuplicateUpdate(updateID int64) bool {
	if updateID <= 0 {
		return false
	}
	now := time.Now()
	if exp, ok := processedUpdates[updateID]; ok && exp.After(now) {
		return true
	}
	processedUpdates[updateID] = now.Add(10 * time.Minute)
	if len(processedUpdates) > 5000 {
		for k, v := range processedUpdates {
			if v.Before(now) {
				delete(processedUpdates, k)
			}
		}
	}
	return false
}

func allowActionRate(userID int64, action string, limit int, window time.Duration) bool {
	key := fmt.Sprintf("%d:%s", userID, action)
	actionRateMu.Lock()
	defer actionRateMu.Unlock()
	now := time.Now()
	cutoff := now.Add(-window)
	calls := actionRateCalls[key]
	filtered := calls[:0]
	for _, t := range calls {
		if t.After(cutoff) {
			filtered = append(filtered, t)
		}
	}
	if len(filtered) >= limit {
		actionRateCalls[key] = filtered
		return false
	}
	actionRateCalls[key] = append(filtered, now)
	return true
}

func syncBotCommands(cfg config, commands []map[string]interface{}) {
	if len(commands) == 0 {
		return
	}
	payload := map[string]interface{}{"commands": commands}
	body, _ := json.Marshal(payload)
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/setMyCommands", cfg.BotToken)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader(body))
	if err != nil {
		log.Printf("setMyCommands: %v", err)
		return
	}
	resp.Body.Close()
}

func isAdminUser(userID int64) bool {
	return cachedAdminIDs[userID]
}

func parseAdminIDs(raw string) {
	cachedAdminIDs = map[int64]bool{}
	for _, part := range strings.Split(raw, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		var id int64
		if _, err := fmt.Sscanf(part, "%d", &id); err == nil {
			cachedAdminIDs[id] = true
		}
	}
}

func notifyAdminsStartup(cfg config, mode string) {
	for id := range cachedAdminIDs {
		msg := fmt.Sprintf("✅ monitorWin Telegram Worker 已启动\n模式：%s", mode)
		_ = sendTelegramWithMarkup(cfg, id, msg, nil)
	}
}

func handleSlashCommand(cfg config, msg *tgMessage) bool {
	if msg == nil {
		return false
	}
	text := strings.TrimSpace(msg.Text)
	if !strings.HasPrefix(text, "/") {
		return false
	}
	chatID := strconv.FormatInt(msg.Chat.ID, 10)
	userID := msg.From.ID
	parts := strings.Fields(text)
	cmd := strings.TrimPrefix(strings.ToLower(parts[0]), "/")
	if i := strings.Index(cmd, "@"); i > 0 {
		cmd = cmd[:i]
	}
	args := ""
	if len(parts) > 1 {
		args = strings.Join(parts[1:], " ")
	}

	switch cmd {
	case "start":
		if args != "" {
			payload := strings.TrimSpace(args)
			if strings.HasPrefix(strings.ToLower(payload), "bind_") {
				payload = strings.TrimPrefix(payload, "bind_")
				payload = strings.TrimPrefix(payload, "BIND_")
			}
			if payload != "" {
				replyBind(cfg, userID, msg.From.Username, chatID, payload, msg.Chat.ID, msg.MessageID)
				return true
			}
		}
		refreshRuntimeConfig(&cfg, chatID)
		_ = sendTelegramWithMarkup(cfg, msg.Chat.ID, helpText(), currentReplyKeyboard())
		return true
	case "bind":
		replyBind(cfg, userID, msg.From.Username, chatID, args, msg.Chat.ID, msg.MessageID)
		return true
	case "help":
		refreshRuntimeConfig(&cfg, chatID)
		_ = sendTelegramWithMarkup(cfg, msg.Chat.ID, helpText(), currentReplyKeyboard())
		return true
	case "chatid":
		replyChatID(cfg, msg.Chat.ID, msg.Chat.Type, msg.Chat.Title, msg.MessageID)
		return true
	case "checkin":
		shift := args
		if shift != "day" && shift != "night" {
			shift = ""
		}
		replyCheckIn(cfg, userID, chatID, shift, msg.MessageID)
		return true
	case "checkout":
		replyCheckOut(cfg, userID, chatID, msg.MessageID)
		return true
	case "at":
		replyEndActivity(cfg, userID, chatID, msg.MessageID)
		return true
	case "status":
		replyStatus(cfg, userID)
		return true
	case "myinfo", "myinfoday", "myinfonight":
		shift := ""
		if cmd == "myinfoday" {
			shift = "day"
		} else if cmd == "myinfonight" {
			shift = "night"
		}
		replyMyInfo(cfg, userID, chatID, shift, msg.MessageID)
		return true
	case "rankings", "rankingsday", "rankingsnight":
		shift := ""
		if cmd == "rankingsday" {
			shift = "day"
		} else if cmd == "rankingsnight" {
			shift = "night"
		}
		replyRankings(cfg, userID, chatID, shift, msg.MessageID)
		return true
	case "handover":
		replyHandover(cfg, userID, args)
		return true
	case "export":
		if !allowActionRate(userID, "export", 2, time.Minute) {
			_ = sendTelegramByUser(cfg, userID, tRateLimited())
			return true
		}
		path := fmt.Sprintf("/telegram/worker/export?chatId=%s", url.QueryEscape(chatID))
		var res struct {
			Code int `json:"code"`
			Data struct {
				Caption string `json:"caption"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err != nil {
			_ = sendTelegramByUser(cfg, userID, "导出失败："+err.Error())
			return true
		}
		msg := res.Data.Caption
		if msg == "" {
			msg = "导出已推送到群组"
		}
		_ = sendTelegramByUser(cfg, userID, msg)
		return true
	case "exportmonthly":
		if !allowActionRate(userID, "export", 2, time.Minute) {
			_ = sendTelegramByUser(cfg, userID, tRateLimited())
			return true
		}
		month := args
		if month == "" {
			month = time.Now().AddDate(0, -1, 0).Format("2006-01")
		}
		path := fmt.Sprintf("/telegram/worker/export?chatId=%s&month=%s", url.QueryEscape(chatID), url.QueryEscape(month))
		var res struct {
			Code int `json:"code"`
			Data struct {
				Caption string `json:"caption"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err != nil {
			_ = sendTelegramByUser(cfg, userID, "导出失败："+err.Error())
			return true
		}
		msg := res.Data.Caption
		if msg == "" {
			msg = "月导出已推送到群组"
		}
		_ = sendTelegramByUser(cfg, userID, msg)
		return true
	case "monthlyreport":
		path := fmt.Sprintf("/telegram/worker/monthly-report?chatId=%s", url.QueryEscape(chatID))
		if args != "" {
			path += "&month=" + url.QueryEscape(args)
		}
		var res struct {
			Code int `json:"code"`
			Data struct {
				DisplayText string `json:"displayText"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err != nil || res.Data.DisplayText == "" {
			_ = sendTelegramByUser(cfg, userID, "月报生成失败")
			return true
		}
		_ = sendTelegramHTML(cfg, userID, res.Data.DisplayText)
		return true
	case "actstatus":
		path := fmt.Sprintf("/telegram/worker/actstatus?chatId=%s", url.QueryEscape(chatID))
		var res struct {
			Code int `json:"code"`
			Data struct {
				DisplayText string `json:"displayText"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err == nil && res.Data.DisplayText != "" {
			_ = sendTelegramByUser(cfg, userID, res.Data.DisplayText)
		}
		return true
	case "ci":
		if args == "" {
			_ = sendTelegramByUser(cfg, userID, "用法：/ci 活动名")
			return true
		}
		replyStartActivityByCI(cfg, userID, chatID, args, msg.MessageID)
		return true
	case "showsettings", "checkdb", "fixmessages":
		if !isAdminUser(userID) {
			_ = sendTelegramByUser(cfg, userID, "需要管理员权限")
			return true
		}
		switch cmd {
		case "showsettings":
			path := fmt.Sprintf("/telegram/worker/showsettings?telegramUserId=%d&chatId=%s", userID, url.QueryEscape(chatID))
			var res struct {
				Code int `json:"code"`
				Data struct {
					DisplayText string `json:"displayText"`
				} `json:"data"`
			}
			if err := backendGet(cfg, path, &res); err == nil {
				_ = sendTelegramHTML(cfg, userID, res.Data.DisplayText)
			}
		case "checkdb":
			path := fmt.Sprintf("/telegram/worker/checkdb?telegramUserId=%d", userID)
			var res struct {
				Code int `json:"code"`
				Data struct {
					DisplayText string `json:"displayText"`
				} `json:"data"`
			}
			if err := backendGet(cfg, path, &res); err == nil {
				_ = sendTelegramByUser(cfg, userID, res.Data.DisplayText)
			}
		case "fixmessages":
			var res apiResult
			res.Data = map[string]interface{}{}
			_ = backendPost(cfg, "/telegram/worker/admin/fixmessages", map[string]interface{}{
				"telegramUserId": userID,
			}, &res)
			_ = sendTelegramByUser(cfg, userID, fmt.Sprintf("已清理 %v 条 message_id", res.Data["cleared"]))
		}
		return true
	default:
		path := fmt.Sprintf("/telegram/worker/resolve-ci?text=%s", url.QueryEscape(cmd))
		var res struct {
			Code int `json:"code"`
			Data struct {
				ActivityName string `json:"activityName"`
			} `json:"data"`
		}
		if err := backendGet(cfg, path, &res); err == nil && res.Data.ActivityName != "" {
			replyStartActivity(cfg, userID, chatID, res.Data.ActivityName, msg.MessageID)
			return true
		}
	}
	return false
}

func replyStartActivityByCI(cfg config, userID int64, chatID, text string, replyTo int64) {
	path := fmt.Sprintf("/telegram/worker/resolve-ci?text=%s", url.QueryEscape(text))
	var res struct {
		Code int `json:"code"`
		Data struct {
			ActivityName string `json:"activityName"`
		} `json:"data"`
	}
	if err := backendGet(cfg, path, &res); err != nil || res.Data.ActivityName == "" {
		replyWorkHTMLError(cfg, chatID, "未找到活动："+text, replyTo)
		return
	}
	replyStartActivity(cfg, userID, chatID, res.Data.ActivityName, replyTo)
}

func sendTelegramHTML(cfg config, chatID int64, text string) error {
	payload := map[string]interface{}{
		"chat_id":    chatID,
		"text":       text,
		"parse_mode": "HTML",
	}
	kb := currentReplyKeyboard()
	if kb != nil {
		payload["reply_markup"] = kb
	}
	body, _ := json.Marshal(payload)
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", cfg.BotToken)
	resp, err := http.Post(apiURL, "application/json", bytes.NewReader(body))
	if err == nil {
		resp.Body.Close()
	}
	return err
}

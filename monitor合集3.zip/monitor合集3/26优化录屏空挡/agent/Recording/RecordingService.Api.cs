using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Lifecycle;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Recorder;
using Microsoft.Extensions.Logging;

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.RecordingServices;

public sealed partial class RecordingService : IRecordingService
{
    bool IRecordingService.IsRunning => IsProcessAlive();

    bool IRecordingService.WorkSessionActive => _workSessionActive;

    string? IRecordingService.OutputPattern => _persistedOutputPattern;

    public void SetWorkSessionActive(bool active) => _workSessionActive = active;

    public void UpdatePolicy(AgentPolicy policy)
    {
        _currentPolicy = policy;
        NotifyPolicyForCapture(policy);

        var recordingConfig = policy.GetRecordingConfig();
        if (!recordingConfig.EnableGpu)
        {
            _forceSoftwareEncoder = false;
            _encoderFailureCount = 0;
            _logger.LogDebug("GPU encoding disabled in policy, resetting encoder force flag");
        }

        if (recordingConfig.EnableGpu && _forceSoftwareEncoder)
        {
            var timeSinceFallback = DateTime.UtcNow - _lastEncoderSwitchTime;
            if (timeSinceFallback > TimeSpan.FromMinutes(30))
            {
                _logger.LogInformation("Retrying hardware encoder after 30 minutes cooldown");
                _forceSoftwareEncoder = false;
                _encoderFailureCount = 0;
                _encoderCacheTime = DateTime.MinValue;
            }
        }
    }

    Task<bool> IRecordingService.TryStartAsync(CancellationToken cancellationToken) =>
        StartRecordingAsync(orchestratorOwned: true);

    async Task IRecordingService.WaitUntilQuiescentAsync(CancellationToken cancellationToken)
    {
        for (var attempt = 0; attempt < 60; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (await _processLock.WaitAsync(0, cancellationToken))
            {
                try
                {
                    if (!IsProcessAlive())
                        return;
                }
                finally
                {
                    _processLock.Release();
                }
            }

            await Task.Delay(250, cancellationToken);
        }

        _logger.LogWarning("Timed out waiting for recording process quiescence");
    }

    Task IRecordingService.StopAsync(bool fullShutdown, bool fastTransition, CancellationToken cancellationToken) =>
        StopRecordingAsync(fullShutdown, fastTransition);

    Task<bool> IRecordingService.RestoreGdigrabCaptureAsync(CancellationToken cancellationToken) =>
        RestoreGdigrabCaptureAsync(cancellationToken);

    public Task RestartAsync(string reason, CancellationToken cancellationToken = default)
    {
        if (reason.Contains("Retry encoder", StringComparison.OrdinalIgnoreCase))
            ApplyEncoderRetryFlags();

        var bucket = reason.Contains("Retry encoder", StringComparison.OrdinalIgnoreCase)
            ? RestartPolicyBucket.EncoderRetry
            : reason.Contains("Policy", StringComparison.OrdinalIgnoreCase) ||
              reason.Contains("System resume", StringComparison.OrdinalIgnoreCase)
                ? RestartPolicyBucket.UserInitiated
                : RestartPolicyBucket.LifecycleTransition;

        return RelaunchCaptureAsync(reason, bucket, cancellationToken);
    }

    Task<bool> IRecordingService.RecoverForHealthAsync(string reason, CancellationToken cancellationToken) =>
        RelaunchCaptureAsync(reason, RestartPolicyBucket.HealthRecovery, cancellationToken);

    public void RestoreOutputPattern(string? pattern)
    {
        if (!string.IsNullOrWhiteSpace(pattern))
            _persistedOutputPattern = pattern;
    }

    public RecordingHealthSnapshot GetHealthSnapshot(RecorderState state, bool remoteViewActive) =>
        BuildRecordingHealthSnapshot(state, remoteViewActive);

    private void ApplyEncoderRetryFlags()
    {
        _forceSoftwareEncoder = false;
        _encoderFailureCount = 0;
        _needPixelFormatFallback = false;
        _encoderCacheTime = DateTime.MinValue;
        _lastEncoderSwitchTime = DateTime.MinValue;
    }

    private async Task<bool> RelaunchCaptureAsync(string reason, RestartPolicyBucket bucket, CancellationToken ct)
    {
        if (reason.Contains("Retry encoder", StringComparison.OrdinalIgnoreCase))
            ApplyEncoderRetryFlags();

        if (!_restartPolicies.TryAcquire(bucket, out var blockReason))
        {
            _logger.LogWarning(
                "Recording relaunch throttled bucket={Bucket}: {Reason} ({BlockReason})",
                bucket,
                reason,
                blockReason);
            return false;
        }

        _logger.LogWarning("Recording relaunch: {Reason} bucket={Bucket}", reason, bucket);

        if (_captureCoordinator?.IsSharedCaptureActive == true)
        {
            await StopRecordingAsync(fullShutdown: false, fastTransition: true);

            var health = _captureCoordinator.GetSharedBridgeHealth();
            if (!health.RecordingPipeConnected)
                await _captureCoordinator.ReconnectSharedBridgeConsumerAsync(CaptureConsumer.Recording, ct);

            ResetAllSignals();
            _isStopping = false;
            if (!_workSessionActive)
                return false;

            var started = await StartRecordingAsync(orchestratorOwned: true);
            if (started)
                _consecutiveFailures = 0;
            else
                Interlocked.Increment(ref _consecutiveFailures);

            return started && IsProcessAlive();
        }

        var skipPostStopDelay = reason.Contains("Restore gdigrab", StringComparison.OrdinalIgnoreCase);
        await StopRecordingAsync(fullShutdown: false, fastTransition: skipPostStopDelay);
        if (!skipPostStopDelay)
            await Task.Delay(2000, ct);

        if (!reason.Contains("Retry encoder", StringComparison.OrdinalIgnoreCase))
        {
            _forceSoftwareEncoder = false;
            _encoderFailureCount = 0;
            _needPixelFormatFallback = false;
            _encoderCacheTime = DateTime.MinValue;
        }

        ResetAllSignals();
        _isStopping = false;

        if (!_workSessionActive)
            return false;

        var ok = await StartRecordingAsync(orchestratorOwned: true);
        if (!skipPostStopDelay)
            await Task.Delay(3000, ct);

        if (ok && IsProcessAlive())
        {
            if (skipPostStopDelay)
                ok = await WaitForRecordingOutputAsync(ct, TimeSpan.FromSeconds(45));

            if (ok)
                _consecutiveFailures = 0;
            else
                Interlocked.Increment(ref _consecutiveFailures);
        }
        else
            Interlocked.Increment(ref _consecutiveFailures);

        return ok && IsProcessAlive();
    }

    private async Task<bool> RestoreGdigrabCaptureAsync(CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();

        if (_captureCoordinator != null)
            await _captureCoordinator.NotifyConsumerStoppingAsync(CaptureConsumer.Recording, ct);

        ResetAllSignals();
        _isStopping = false;

        if (!_workSessionActive)
            return false;

        _logger.LogInformation("Restoring gdigrab recording after SharedBridge (fast path)");
        var started = await StartRecordingAsync(orchestratorOwned: true);
        if (!started || !IsProcessAlive())
        {
            Interlocked.Increment(ref _consecutiveFailures);
            return false;
        }

        var verified = await WaitForRecordingOutputAsync(ct, TimeSpan.FromSeconds(45));
        if (!verified)
        {
            _logger.LogError("Gdigrab restore: FFmpeg started but no verified output; stopping capture");
            await StopRecordingAsync(fullShutdown: false, fastTransition: true);
            Interlocked.Increment(ref _consecutiveFailures);
            return false;
        }

        _consecutiveFailures = 0;
        var pid = _ffmpegProcess?.Id;
        _logger.LogInformation(
            "Gdigrab recording restored and verified (PID: {Pid}, pattern: {Pattern})",
            pid,
            _persistedOutputPattern);
        return true;
    }
}

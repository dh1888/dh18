# 隐藏窗口管理器（现代 UI 版本）

用 WPF 重构的窗口隐藏工具，深色主题 + 自定义无边框标题栏 + 圆角卡片式布局，
功能上与之前的 WinForms 版本完全一致，只是把界面全部重新设计成现代风格。

## 界面特点

- 无边框自定义标题栏（可拖动、双击最大化、自定义最小化/关闭按钮）
- 深色主题（背景 #1B1D26，强调色紫蓝 #7C6BFF）
- 圆角卡片式列表，鼠标悬停/选中有高亮描边反馈
- 自定义 Toggle 开关控件替代传统 CheckBox
- 自定义下拉框、输入框、滚动条样式，去掉了 Windows 原生控件的方块感

## 功能（与之前版本相同）

- 枚举当前所有可见窗口
- 按标题 / 类名 / 进程名 三种方式添加隐藏规则
- 全局热键一键隐藏 / 恢复（默认 Ctrl+Alt+H，可在界面里按下新组合键修改）
- 可选：恢复前需要密码验证
- 可选：开机自动启动
- 最小化到系统托盘，双击或右键菜单可以呼出/切换/退出

## 新增行为：隐藏后自动收进托盘

无论是按全局热键"全部隐藏"，还是给单条规则设置的专属热键/按钮触发隐藏，
只要真的把目标窗口隐藏了，管理器自己的主界面也会跟着 `Hide()` 到托盘，
桌面上不会留下管理器窗口。恢复窗口时不会自动弹回主界面（如果开了密码保护，
恢复前依然会弹密码框），需要打开主界面时双击托盘图标或用右键菜单里的
"显示主窗口"即可。

## 编译方法

需要 Windows + .NET 8 SDK。

```bash
cd HiddenWindowManager
dotnet build -c Release
```

```bash
cd HiddenWindowManager
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true
```

编译产物：`bin\Release\net8.0-windows\HiddenWindowManager.exe`

打包成免安装单文件 exe（自带 .NET 运行时，发给别人电脑上不用装 .NET 也能直接双击运行）：

```bash
dotnet publish -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true ^
  -p:IncludeNativeLibrariesForSelfExtract=true ^
  -p:EnableCompressionInSingleFile=true
```

（Windows 命令提示符 / PowerShell 里的续行符是 `^`，如果是一行写完可以去掉 `^` 直接拼在一起。）

生成的单文件在：

```
bin\Release\net8.0-windows\win-x64\publish\HiddenWindowManager.exe
```

这一个 exe 文件已经把 .NET 8 桌面运行时和所有依赖都打进去了，体积会比较大
（一般 100MB+），但只要把这一个文件拷给别人，对方电脑不需要预装任何 .NET
运行时就能直接双击运行。配置文件会在对方电脑的
`%AppData%\HiddenWindowManager\config.json` 自动生成，不需要额外部署。

## 自定义程序图标

把你喜欢的图片准备成 `.ico` 格式（Windows 图标只认 `.ico`），命名为 `icon.ico`，
放到跟 `HiddenWindowManager.csproj` 同一级目录下，然后重新编译即可：

- 如果图片是 `.png` / `.jpg`，需要先转换成 `.ico`。可以用在线工具（搜索"图片转
  ico"，选一个支持多尺寸的，建议勾选 256x256、48x48、32x32、16x16 几个尺寸都
  包含进去，这样任务栏和托盘小图标都清晰），或者本地装了 ImageMagick 的话可以：
  ```bash
  magick convert my-photo.png -define icon:auto-resize=256,64,48,32,16 icon.ico
  ```
- 放好 `icon.ico` 后，`dotnet build` / `dotnet publish` 会自动把它设置成
  exe 本身的图标、窗口标题栏图标、以及系统托盘图标（三处保持一致）。
- 如果不放这个文件，程序照常编译运行，只是继续用默认图标，不影响任何功能。

## 项目结构

```
HiddenWindowManager/
├── HiddenWindowManager.csproj
├── App.xaml / App.xaml.cs          全局主题样式 + 应用入口
├── MainWindow.xaml / .xaml.cs       主界面
├── HotkeyDialog.xaml / .xaml.cs     热键设置弹窗
├── PasswordDialog.xaml / .xaml.cs   密码输入弹窗
├── NativeMethods.cs                 Win32 API 封装
├── WindowEnumerator.cs               枚举窗口
├── WindowInfo.cs                     数据结构
└── AppConfig.cs                      配置读写
```

## 后续可以继续美化的方向

- 换成 Fluent Design 风格的第三方库（如 WPF-UI / ModernWpfUI），拿到 Windows 11
  原生的亚克力/云母背景效果（这需要联网安装 NuGet 包）
- 给隐藏/恢复动作加过渡动画（Storyboard 淡入淡出）
- 支持浅色/深色主题切换（当前只做了深色，配置里已经预留了 DarkTheme 字段）
- 隐藏列表支持拖拽排序、分组（比如"工作时隐藏"/"游戏时隐藏"两组规则一键切换）

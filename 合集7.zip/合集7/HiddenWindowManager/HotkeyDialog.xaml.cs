using System.Windows;
using System.Windows.Input;
using KeyEventArgs = System.Windows.Input.KeyEventArgs;

namespace HiddenWindowManager
{
    public partial class HotkeyDialog : Window
    {
        public uint SelectedModifiers { get; private set; }
        public uint SelectedKey { get; private set; }

        public HotkeyDialog(uint currentMods, uint currentKey)
        {
            InitializeComponent();
            SelectedModifiers = currentMods;
            SelectedKey = currentKey;
            CaptureLabel.Text = MainWindow.DescribeHotkey(currentMods, currentKey);
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            var key = e.Key == Key.System ? e.SystemKey : e.Key;

            if (key is Key.LeftCtrl or Key.RightCtrl or Key.LeftAlt or Key.RightAlt
                or Key.LeftShift or Key.RightShift or Key.LWin or Key.RWin)
                return;

            uint mods = 0;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) mods |= NativeMethods.MOD_CONTROL;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Alt)) mods |= NativeMethods.MOD_ALT;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) mods |= NativeMethods.MOD_SHIFT;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Windows)) mods |= NativeMethods.MOD_WIN;

            if (mods == 0)
            {
                CaptureLabel.Text = "请至少包含一个修饰键";
                return;
            }

            uint vk = (uint)KeyInterop.VirtualKeyFromKey(key);

            SelectedModifiers = mods;
            SelectedKey = vk;
            CaptureLabel.Text = MainWindow.DescribeHotkey(mods, vk);

            e.Handled = true;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            SelectedModifiers = 0;
            SelectedKey = 0;
            DialogResult = true;
        }
    }
}

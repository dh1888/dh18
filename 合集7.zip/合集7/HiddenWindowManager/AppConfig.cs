using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace HiddenWindowManager
{
    public class AppConfig
    {
        public List<HideRule> HideRules { get; set; } = new();

        public uint HotkeyModifiers { get; set; } = NativeMethods.MOD_CONTROL | NativeMethods.MOD_ALT;
        public uint HotkeyKey { get; set; } = 0x48; // 默认 VK_H

        public bool PasswordEnabled { get; set; } = false;
        public string PasswordHash { get; set; } = string.Empty;

        public bool RunAtStartup { get; set; } = false;
        public bool DarkTheme { get; set; } = true;

        private static string ConfigDir =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HiddenWindowManager");

        private static string ConfigPath => Path.Combine(ConfigDir, "config.json");

        public static AppConfig Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                {
                    var json = File.ReadAllText(ConfigPath);
                    var cfg = JsonSerializer.Deserialize<AppConfig>(json);
                    if (cfg != null) return cfg;
                }
            }
            catch
            {
                // 配置损坏则使用默认值
            }
            return new AppConfig();
        }

        public void Save()
        {
            Directory.CreateDirectory(ConfigDir);
            var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(ConfigPath, json);
        }

        public static string HashPassword(string plain)
        {
            var bytes = Encoding.UTF8.GetBytes(plain);
            var hash = SHA256.HashData(bytes);
            return Convert.ToHexString(hash);
        }
    }
}

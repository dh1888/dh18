using System.Windows;
using Application = System.Windows.Application;

namespace HiddenWindowManager
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            ShutdownMode = ShutdownMode.OnExplicitShutdown;
            var main = new MainWindow();
            main.Show();
        }
    }
}

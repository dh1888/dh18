using System.Diagnostics;
using System.Text;

namespace HiddenWindowManager
{
    public static class WindowEnumerator
    {
        public static List<WindowInfo> GetTopLevelWindows()
        {
            var result = new List<WindowInfo>();

            NativeMethods.EnumWindows((hWnd, _) =>
            {
                if (!NativeMethods.IsWindowVisible(hWnd))
                    return true;

                if (NativeMethods.GetWindow(hWnd, NativeMethods.GW_OWNER) != IntPtr.Zero)
                    return true;

                int length = NativeMethods.GetWindowTextLength(hWnd);
                if (length == 0)
                    return true;

                var titleBuilder = new StringBuilder(length + 1);
                NativeMethods.GetWindowText(hWnd, titleBuilder, titleBuilder.Capacity);

                var classBuilder = new StringBuilder(256);
                NativeMethods.GetClassName(hWnd, classBuilder, classBuilder.Capacity);

                NativeMethods.GetWindowThreadProcessId(hWnd, out uint pid);

                string processName = "unknown";
                try
                {
                    processName = Process.GetProcessById((int)pid).ProcessName;
                }
                catch
                {
                    // 进程可能已退出
                }

                result.Add(new WindowInfo
                {
                    Handle = hWnd,
                    Title = titleBuilder.ToString(),
                    ClassName = classBuilder.ToString(),
                    ProcessName = processName,
                    ProcessId = pid
                });

                return true;
            }, IntPtr.Zero);

            return result;
        }
    }
}

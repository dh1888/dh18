<template>
  <div class="security-whitelist-page">
    <el-card class="section-card">
      <template #header>
        <span>CORS / WebSocket Origin 白名单</span>
      </template>
      <p class="section-desc">
        填写浏览器地址栏中的完整 Origin（含协议与端口）。保存后立即生效，用于 API 跨域与 WebSocket 连接校验。
      </p>

      <el-form label-width="160px">
        <el-form-item label="允许的来源">
          <el-select
            v-model="corsOrigins"
            multiple
            filterable
            allow-create
            default-first-option
            placeholder="例如 https://monitor.example.com:8888"
            style="width: 100%"
          >
            <el-option
              v-for="item in corsOrigins"
              :key="item"
              :label="item"
              :value="item"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="当前生效">
          <div class="tag-list">
            <el-tag
              v-for="item in corsConfig.effectiveOrigins"
              :key="item"
              size="small"
              class="list-tag"
            >
              {{ item }}
            </el-tag>
            <span v-if="!corsConfig.effectiveOrigins?.length" class="empty-tip">
              未配置（生产环境将导致 Web 无法连接）
            </span>
          </div>
          <p class="form-tip block-tip">
            来源：{{ corsSourceLabel
            }}<span v-if="corsConfig.updatedAt"
              >，更新于 {{ formatTime(corsConfig.updatedAt) }}</span
            >
          </p>
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            :loading="corsSaveLoading"
            @click="handleSaveCorsOrigins"
          >
            保存 Origin 白名单
          </el-button>
          <el-button @click="loadCorsOrigins">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card class="section-card">
      <template #header>
        <span>登录安全</span>
      </template>
      <p class="section-desc">
        控制 Web 后台登录时的图形验证码与谷歌验证器（TOTP）。开启 TOTP
        后，用户首次登录需绑定验证器，之后每次登录需输入动态验证码。
      </p>

      <el-form label-width="160px">
        <el-form-item label="图形验证码">
          <el-switch v-model="authSecurity.loginCaptchaEnabled" />
          <span class="form-tip">开启后登录页需输入服务端生成的验证码</span>
        </el-form-item>

        <el-form-item label="谷歌验证器">
          <el-switch v-model="authSecurity.loginTotpEnabled" />
          <span class="form-tip"
            >开启后用户需使用 Google Authenticator 等应用完成二次验证</span
          >
        </el-form-item>

        <el-form-item v-if="authSecurity.updatedAt" label="上次更新">
          <span class="form-tip">{{ formatTime(authSecurity.updatedAt) }}</span>
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            :loading="authSecuritySaveLoading"
            @click="handleSaveAuthSecurity"
          >
            保存登录安全
          </el-button>
          <el-button @click="loadAuthSecurity">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card class="section-card">
      <template #header>
        <span>登录 IP 白名单</span>
      </template>
      <p class="section-desc">
        开启后，仅列表中的 IP 或网段可登录 Web 管理后台（含 TOTP 第二步）。关闭或未配置时不限制登录
        IP。客户端识别优先使用 Nginx 转发的 X-Forwarded-For 首段 IP。
      </p>

      <el-form label-width="160px">
        <el-form-item label="启用 IP 白名单">
          <el-switch v-model="loginIPWhitelist.enabled" />
          <span class="form-tip">关闭时不校验登录 IP</span>
        </el-form-item>

        <el-form-item label="允许的 IP">
          <el-select
            v-model="loginIPWhitelistIPs"
            multiple
            filterable
            allow-create
            default-first-option
            placeholder="例如 203.0.113.10 或 192.168.1.0/24"
            style="width: 100%"
            :disabled="!loginIPWhitelist.enabled"
          >
            <el-option
              v-for="item in loginIPWhitelistIPs"
              :key="item"
              :label="item"
              :value="item"
            />
          </el-select>
        </el-form-item>

        <el-form-item v-if="loginIPWhitelist.updatedAt" label="上次更新">
          <span class="form-tip">{{
            formatTime(loginIPWhitelist.updatedAt)
          }}</span>
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            :loading="loginIPSaveLoading"
            @click="handleSaveLoginIPWhitelist"
          >
            保存 IP 白名单
          </el-button>
          <el-button @click="loadLoginIPWhitelist">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, computed } from "vue";
import { ElMessage } from "element-plus";
import {
  settingsApi,
  type AuthSecurityConfig,
  type CorsOriginsConfig,
  type LoginIPWhitelistConfig,
} from "@api/index";

const corsOrigins = ref<string[]>([]);
const corsSaveLoading = ref(false);
const corsConfig = reactive<CorsOriginsConfig>({
  origins: [],
  effectiveOrigins: [],
  source: "none",
});

const corsSourceLabel = computed(() => {
  const map: Record<string, string> = {
    database: "Web 后台配置",
    environment: ".env 环境变量",
    default: "开发环境默认值",
    none: "未配置",
  };
  return map[corsConfig.source] || corsConfig.source;
});

const authSecurity = reactive<AuthSecurityConfig>({
  loginCaptchaEnabled: true,
  loginTotpEnabled: false,
});
const authSecuritySaveLoading = ref(false);

const loginIPWhitelist = reactive<LoginIPWhitelistConfig>({
  enabled: false,
  ips: [],
});
const loginIPWhitelistIPs = ref<string[]>([]);
const loginIPSaveLoading = ref(false);

const formatTime = (time: string | null) => {
  if (!time) return "—";
  const date = new Date(time);
  return date.toLocaleString("zh-CN");
};

const loadCorsOrigins = async () => {
  try {
    const { data } = await settingsApi.getCorsOrigins();
    Object.assign(corsConfig, data);
    corsOrigins.value = [...(data.origins || [])];
  } catch (error: any) {
    ElMessage.error(error.message || "加载 CORS 白名单失败");
  }
};

const handleSaveCorsOrigins = async () => {
  corsSaveLoading.value = true;
  try {
    const { data } = await settingsApi.updateCorsOrigins(corsOrigins.value);
    Object.assign(corsConfig, data);
    corsOrigins.value = [...(data.origins || [])];
    ElMessage.success("CORS 白名单已保存并立即生效");
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    corsSaveLoading.value = false;
  }
};

const loadAuthSecurity = async () => {
  try {
    const { data } = await settingsApi.getAuthSecurity();
    Object.assign(authSecurity, data);
  } catch (error: any) {
    ElMessage.error(error.message || "加载登录安全配置失败");
  }
};

const handleSaveAuthSecurity = async () => {
  authSecuritySaveLoading.value = true;
  try {
    const { data } = await settingsApi.updateAuthSecurity({
      loginCaptchaEnabled: authSecurity.loginCaptchaEnabled,
      loginTotpEnabled: authSecurity.loginTotpEnabled,
    });
    Object.assign(authSecurity, data);
    ElMessage.success("登录安全配置已保存");
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    authSecuritySaveLoading.value = false;
  }
};

const loadLoginIPWhitelist = async () => {
  try {
    const { data } = await settingsApi.getLoginIPWhitelist();
    Object.assign(loginIPWhitelist, data);
    loginIPWhitelistIPs.value = [...(data.ips || [])];
  } catch (error: any) {
    ElMessage.error(error.message || "加载登录 IP 白名单失败");
  }
};

const handleSaveLoginIPWhitelist = async () => {
  if (loginIPWhitelist.enabled && loginIPWhitelistIPs.value.length === 0) {
    ElMessage.warning("启用 IP 白名单时请至少添加一条 IP 或网段");
    return;
  }

  loginIPSaveLoading.value = true;
  try {
    const { data } = await settingsApi.updateLoginIPWhitelist({
      enabled: loginIPWhitelist.enabled,
      ips: loginIPWhitelistIPs.value,
    });
    Object.assign(loginIPWhitelist, data);
    loginIPWhitelistIPs.value = [...(data.ips || [])];
    ElMessage.success("登录 IP 白名单已保存并立即生效");
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    loginIPSaveLoading.value = false;
  }
};

onMounted(() => {
  loadCorsOrigins();
  loadAuthSecurity();
  loadLoginIPWhitelist();
});
</script>

<style scoped>
.security-whitelist-page {
  min-height: 100%;
}

.section-card {
  border-radius: 8px;
  margin-bottom: 20px;
}

.section-desc {
  margin: 0 0 16px;
  font-size: 13px;
  line-height: 1.6;
  color: #909399;
}

.form-tip {
  margin-left: 12px;
  font-size: 12px;
  color: #8c8c8c;
}

.block-tip {
  margin-left: 0;
  margin-top: 8px;
}

.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  min-height: 24px;
}

.list-tag {
  margin: 0;
}

.empty-tip {
  font-size: 13px;
  color: #f56c6c;
}
</style>

<template>
  <div class="settings-page">
    <!-- 第一行：策略配置 + 存储统计 -->
    <el-row :gutter="20">
      <el-col :span="16">
        <el-card class="settings-card">
          <template #header>
            <span>清理策略配置</span>
          </template>

          <el-form
            :model="policy"
            :rules="rules"
            ref="policyFormRef"
            label-width="160px"
          >
            <el-form-item label="自动清理">
              <el-switch v-model="policy.autoCleanupEnabled" />
              <span class="form-tip">开启后系统将自动清理过期数据</span>
            </el-form-item>

            <el-form-item
              label="录制文件保留天数"
              prop="recordingRetentionDays"
            >
              <el-input-number
                v-model="policy.recordingRetentionDays"
                :min="0"
                :max="365"
              />
              <span class="form-tip">天，超过此天数的录制将被删除</span>
            </el-form-item>

            <el-form-item label="截图保留天数" prop="screenshotRetentionDays">
              <el-input-number
                v-model="policy.screenshotRetentionDays"
                :min="0"
                :max="365"
              />
              <span class="form-tip">天</span>
            </el-form-item>

            <el-form-item label="日志保留天数" prop="logRetentionDays">
              <el-input-number
                v-model="policy.logRetentionDays"
                :min="0"
                :max="730"
              />
              <span class="form-tip">天</span>
            </el-form-item>

            <el-form-item label="磁盘使用阈值" prop="diskUsageThresholdPercent">
              <el-input-number
                v-model="policy.diskUsageThresholdPercent"
                :min="1"
                :max="100"
              />
              <span class="form-tip">%，超过此阈值触发清理</span>
            </el-form-item>

            <el-form-item label="清理间隔" prop="cleanupIntervalMinutes">
              <el-input-number
                v-model="policy.cleanupIntervalMinutes"
                :min="1"
                :max="1440"
              />
              <span class="form-tip">分钟</span>
            </el-form-item>

            <el-form-item>
              <el-button
                type="primary"
                :loading="saveLoading"
                @click="handleSavePolicy"
              >
                保存策略
              </el-button>
              <el-button @click="handleManualCleanup" :loading="cleanupLoading">
                立即清理
              </el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>

      <el-col :span="8">
        <el-card class="stats-card">
          <template #header>
            <span>存储统计</span>
          </template>

          <div class="stats-content" v-loading="statsLoading">
            <div class="stat-item">
              <span class="stat-label">磁盘总容量</span>
              <span class="stat-value">{{
                formatBytes(stats.totalBytes)
              }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">分区已用</span>
              <span class="stat-value">{{ formatBytes(stats.usedBytes) }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">分区剩余</span>
              <span class="stat-value">{{ formatBytes(stats.freeBytes) }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">磁盘使用率</span>
              <el-progress
                :percentage="stats.diskUsagePercent"
                :color="getUsageColor(stats.diskUsagePercent)"
                :format="() => `${stats.diskUsagePercent}%`"
              />
            </div>
            <div class="stat-item">
              <span class="stat-label">业务数据占用</span>
              <span class="stat-value">{{
                formatBytes(stats.uploadsBytes ?? 0)
              }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">录制文件数</span>
              <span class="stat-value">{{ stats.recordingCount }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">截图文件数</span>
              <span class="stat-value">{{ stats.screenshotCount }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">活动日志数</span>
              <span class="stat-value">{{ stats.logCount }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">上次清理时间</span>
              <span class="stat-value">{{
                formatTime(stats.lastCleanupAt)
              }}</span>
            </div>
            <p class="stats-tip">
              磁盘使用率与自动清理阈值判断一致；业务数据为录制/截图等登记文件占用。
            </p>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 第二行：清理日志（带分页） -->
    <el-row :gutter="20" style="margin-top: 20px">
      <el-col :span="24">
        <el-card class="logs-card">
          <template #header>
            <div class="card-header">
              <span>
                <el-icon><Document /></el-icon>
                清理日志
                <el-badge
                  :value="logsPagination.total"
                  :hidden="logsPagination.total === 0"
                  class="total-badge"
                />
              </span>
              <el-button
                size="small"
                @click="handleRefreshLogs"
                :loading="logsLoading"
              >
                <el-icon><Refresh /></el-icon>
                刷新
              </el-button>
            </div>
          </template>

          <el-empty
            v-if="cleanupLogs.length === 0 && !logsLoading"
            description="尚无实际清理记录"
          />

          <template v-else>
            <el-table :data="cleanupLogs" v-loading="logsLoading" stripe>
              <el-table-column prop="triggerType" label="触发方式" width="140">
                <template #default="{ row }">
                  <el-tag :type="getTriggerTypeTag(row.triggerType)" size="small">
                    {{ getTriggerTypeText(row.triggerType) }}
                  </el-tag>
                </template>
              </el-table-column>

              <el-table-column prop="status" label="状态" width="90">
                <template #default="{ row }">
                  <el-tag
                    :type="
                      row.status === 'success'
                        ? 'success'
                        : row.status === 'partial'
                          ? 'warning'
                          : 'danger'
                    "
                    size="small"
                  >
                    {{
                      row.status === "success"
                        ? "成功"
                        : row.status === "partial"
                          ? "部分成功"
                          : "失败"
                    }}
                  </el-tag>
                </template>
              </el-table-column>

              <el-table-column prop="startedAt" label="执行时间" width="180">
                <template #default="{ row }">
                  {{ formatTime(row.startedAt) }}
                </template>
              </el-table-column>

              <el-table-column label="清理结果" min-width="320">
                <template #default="{ row }">
                  <span class="cleanup-result">
                    {{ formatCleanupResult(row) }}
                  </span>
                </template>
              </el-table-column>
            </el-table>

            <div class="pagination-container">
              <el-pagination
                v-model:current-page="logsPagination.page"
                v-model:page-size="logsPagination.pageSize"
                :total="logsPagination.total"
                :page-sizes="[10, 20, 50, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleLogsSizeChange"
                @current-change="handleLogsCurrentChange"
              />
            </div>
          </template>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { cleanupApi } from "@api/index";
import type { CleanupPolicy, StorageStats, CleanupLog } from "@api/types";
import { Document, Refresh } from "@element-plus/icons-vue";

// ========== 策略配置相关 ==========
const policyFormRef = ref();
const saveLoading = ref(false);
const cleanupLoading = ref(false);
const statsLoading = ref(false);

const policy = reactive<CleanupPolicy>({
  autoCleanupEnabled: true,
  recordingRetentionDays: 30,
  screenshotRetentionDays: 30,
  logRetentionDays: 90,
  diskUsageThresholdPercent: 80,
  cleanupIntervalMinutes: 60,
  lastRunAt: null,
  updatedAt: "",
});

const stats = reactive<StorageStats>({
  totalBytes: 0,
  usedBytes: 0,
  freeBytes: 0,
  diskUsagePercent: 0,
  uploadsBytes: 0,
  recordingCount: 0,
  screenshotCount: 0,
  logCount: 0,
  lastCleanupAt: null,
});

const rules = {
  recordingRetentionDays: [
    { required: true, type: "number", min: 0, message: "请输入有效的天数" },
  ],
  screenshotRetentionDays: [
    { required: true, type: "number", min: 0, message: "请输入有效的天数" },
  ],
  logRetentionDays: [
    { required: true, type: "number", min: 0, message: "请输入有效的天数" },
  ],
  diskUsageThresholdPercent: [
    {
      required: true,
      type: "number",
      min: 1,
      max: 100,
      message: "请输入 1-100 之间的值",
    },
  ],
  cleanupIntervalMinutes: [
    { required: true, type: "number", min: 1, message: "请输入有效的分钟数" },
  ],
};

// ========== 清理日志相关（服务端分页） ==========
const cleanupLogs = ref<CleanupLog[]>([]);
const logsLoading = ref(false);

const logsPagination = reactive({
  page: 1,
  pageSize: 10,
  total: 0,
});

// ========== 工具函数 ==========
const formatBytes = (bytes: number) => {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
};

const formatTime = (time: string | null) => {
  if (!time) return "从未执行";
  const date = new Date(time);
  return date.toLocaleString("zh-CN");
};

const getUsageColor = (percent: number) => {
  if (percent < 60) return "#67c23a";
  if (percent < 80) return "#e6a23c";
  return "#f56c6c";
};

// ========== 触发方式映射 ==========
const getTriggerTypeTag = (type: string): string => {
  const map: Record<string, string> = {
    auto: "info",
    manual: "primary",
    auto_disk_threshold: "warning",
    auto_disk_critical: "danger",
  };
  return map[type] || "info";
};

const getTriggerTypeText = (type: string): string => {
  const map: Record<string, string> = {
    auto: "定时清理",
    manual: "手动清理",
    auto_disk_threshold: "磁盘阈值",
    auto_disk_critical: "磁盘临界",
  };
  return map[type] || type;
};

const isCleanupEmpty = (row: CleanupLog) =>
  row.deletedRecordings === 0 &&
  row.deletedScreenshots === 0 &&
  row.deletedLogs === 0 &&
  row.deletedBytes === 0;

const formatCleanupResult = (row: CleanupLog) => {
  if (row.message?.trim()) {
    return row.message;
  }

  const parts: string[] = [];
  if (row.deletedRecordings > 0) {
    parts.push(`录制 ${row.deletedRecordings} 个`);
  }
  if (row.deletedScreenshots > 0) {
    parts.push(`截图 ${row.deletedScreenshots} 个`);
  }
  if (row.deletedLogs > 0) {
    parts.push(`日志 ${row.deletedLogs} 条`);
  }

  const summary = parts.join("、");
  if (row.deletedBytes > 0) {
    return `删除 ${summary}，释放 ${formatBytes(row.deletedBytes)}`;
  }
  return `删除 ${summary}`;
};

const handleLogsSizeChange = (size: number) => {
  logsPagination.pageSize = size;
  logsPagination.page = 1;
  loadCleanupLogs();
};

const handleLogsCurrentChange = (page: number) => {
  logsPagination.page = page;
  loadCleanupLogs();
};

const handleRefreshLogs = () => {
  loadCleanupLogs();
};

// ========== API 调用 ==========
const loadPolicy = async () => {
  try {
    const { data } = await cleanupApi.getPolicy();
    Object.assign(policy, data);
  } catch (error: any) {
    ElMessage.error(error.message || "加载策略失败");
  }
};

const loadStats = async () => {
  statsLoading.value = true;
  try {
    const { data } = await cleanupApi.getStats();
    Object.assign(stats, data);
  } catch (error: any) {
    ElMessage.error(error.message || "加载统计失败");
  } finally {
    statsLoading.value = false;
  }
};

const loadCleanupLogs = async () => {
  logsLoading.value = true;
  try {
    const { data } = await cleanupApi.getLogs({
      page: logsPagination.page,
      pageSize: logsPagination.pageSize,
    });
    cleanupLogs.value = (data?.items ?? []).filter((row) => !isCleanupEmpty(row));
    logsPagination.total = data?.total ?? cleanupLogs.value.length;
  } catch (error: any) {
    ElMessage.error(error.message || "加载清理日志失败");
    cleanupLogs.value = [];
    logsPagination.total = 0;
  } finally {
    logsLoading.value = false;
  }
};

const handleSavePolicy = async () => {
  if (!policyFormRef.value) return;

  try {
    await policyFormRef.value.validate();
  } catch {
    return;
  }

  saveLoading.value = true;
  try {
    await cleanupApi.updatePolicy(policy);
    ElMessage.success("策略保存成功");
    await loadPolicy();
    await loadStats();
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    saveLoading.value = false;
  }
};

const handleManualCleanup = async () => {
  cleanupLoading.value = true;
  try {
    const { data } = await cleanupApi.manualCleanup();
    const empty =
      data.deletedRecordings === 0 &&
      data.deletedScreenshots === 0 &&
      data.deletedLogs === 0 &&
      data.deletedBytes === 0;

    ElMessage.success(
      empty
        ? "检查完成，当前无需要清理的文件"
        : `清理完成：录制 ${data.deletedRecordings}、截图 ${data.deletedScreenshots}、日志 ${data.deletedLogs}，释放 ${formatBytes(data.deletedBytes)}`,
    );
    logsPagination.page = 1;
    await loadStats();
    await loadCleanupLogs();
  } catch (error: any) {
    ElMessage.error(error.message || "清理失败");
  } finally {
    cleanupLoading.value = false;
  }
};

// ========== 生命周期 ==========
onMounted(() => {
  loadPolicy();
  loadStats();
  loadCleanupLogs();
});
</script>

<style scoped>
.settings-page {
  min-height: 100%;
}

.settings-card,
.stats-card,
.logs-card {
  border-radius: 8px;
}

.form-tip {
  margin-left: 12px;
  font-size: 12px;
  color: #8c8c8c;
}

.stats-content {
  padding: 10px 0;
}

.stat-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;
}

.stat-item:last-child {
  border-bottom: none;
}

.stat-label {
  font-size: 14px;
  color: #666;
}

.stat-value {
  font-size: 14px;
  font-weight: 500;
  color: #333;
}

.stats-tip {
  margin: 8px 0 0;
  font-size: 12px;
  line-height: 1.5;
  color: #909399;
}

.cleanup-result {
  color: #303133;
}

/* 卡片头部样式 */
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* 表格内文字颜色 */
.text-success {
  color: #67c23a;
  font-weight: 500;
}

.text-warning {
  color: #e6a23c;
  font-weight: 500;
}

/* 分页容器 */
.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

/* 总数徽章 */
.total-badge :deep(.el-badge__content) {
  background-color: #409eff;
}

/* 响应式适配 */
@media (max-width: 768px) {
  .logs-card :deep(.el-table) {
    overflow-x: auto;
  }

  .pagination-container {
    overflow-x: auto;
  }

  .pagination-container :deep(.el-pagination) {
    flex-wrap: wrap;
    justify-content: center;
  }
}
</style>

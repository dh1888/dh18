using System.Globalization;
using EnterpriseAgent.Agent.Models;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 从录屏文件路径解析 UTC 起止时间（新/旧文件名格式统一入口）
/// </summary>
internal static class RecordingTimeParser
{
    private static readonly int[] CommonSliceSeconds = { 60, 180, 300, 600, 900 };

    public static bool TryParse(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        if (string.IsNullOrWhiteSpace(filePath))
            return false;

        var inferredSlice = InferSliceSecondsFromDirectory(filePath);
        foreach (var candidate in BuildSliceCandidates(sliceSeconds, inferredSlice))
        {
            if (!TryParseWithSlice(filePath, candidate, out var parsedStart, out var parsedEnd))
                continue;

            if (!ValidateWithFileTime(filePath, parsedStart, parsedEnd, candidate))
                continue;

            startUtc = parsedStart;
            endUtc = RefineEndTime(filePath, parsedStart, parsedEnd, candidate);
            return true;
        }

        // 无法校验时降级：优先目录推断，再使用传入 hint
        if (inferredSlice > 0 &&
            TryParseWithSlice(filePath, inferredSlice, out startUtc, out endUtc))
        {
            endUtc = RefineEndTime(filePath, startUtc, endUtc, inferredSlice);
            return true;
        }

        sliceSeconds = Math.Max(sliceSeconds, Constants.MinSliceSeconds);
        if (TryParseWithSlice(filePath, sliceSeconds, out startUtc, out endUtc))
        {
            endUtc = RefineEndTime(filePath, startUtc, endUtc, sliceSeconds);
            return true;
        }

        startUtc = default;
        endUtc = default;
        return false;
    }

    private static IEnumerable<int> BuildSliceCandidates(int hint, int inferred)
    {
        var ordered = new List<int>();
        void Add(int value)
        {
            value = Math.Max(value, Constants.MinSliceSeconds);
            if (!ordered.Contains(value))
                ordered.Add(value);
        }

        if (inferred > 0)
            Add(inferred);
        if (hint > 0)
            Add(hint);
        foreach (var common in CommonSliceSeconds)
            Add(common);

        return ordered;
    }

    private static bool TryParseWithSlice(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;
        sliceSeconds = Math.Max(sliceSeconds, Constants.MinSliceSeconds);

        return TryParseNewFormat(filePath, sliceSeconds, out startUtc, out endUtc) ||
               TryParseLegacyFormat(filePath, sliceSeconds, out startUtc, out endUtc) ||
               TryParseFromFileTime(filePath, sliceSeconds, out startUtc, out endUtc);
    }

    private static int InferSliceSecondsFromDirectory(string filePath)
    {
        try
        {
            var dir = Path.GetDirectoryName(filePath);
            if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir))
                return 0;

            var fileName = Path.GetFileNameWithoutExtension(filePath);
            var parts = fileName.Split('_');
            if (parts.Length != 3 || parts[0].Length != 10)
                return 0;

            var sessionPrefix = $"{parts[0]}_{parts[1]}";
            var siblings = new List<(int Index, DateTime Mtime)>();

            foreach (var path in Directory.EnumerateFiles(dir, $"{sessionPrefix}_*.mp4"))
            {
                var name = Path.GetFileNameWithoutExtension(path);
                var segments = name.Split('_');
                if (segments.Length != 3 || !int.TryParse(segments[2], out var index))
                    continue;

                var info = new FileInfo(path);
                if (!info.Exists || info.Length <= Constants.MinRecordingFileBytes)
                    continue;

                siblings.Add((index, info.LastWriteTimeUtc));
            }

            if (siblings.Count < 2)
                return 0;

            siblings.Sort((a, b) => a.Index.CompareTo(b.Index));

            var deltas = new List<int>();
            for (var i = 1; i < siblings.Count; i++)
            {
                var delta = (int)Math.Round((siblings[i].Mtime - siblings[i - 1].Mtime).TotalSeconds);
                if (delta >= Constants.MinSliceSeconds && delta <= 3600)
                    deltas.Add(delta);
            }

            if (deltas.Count == 0)
                return 0;

            deltas.Sort();
            var median = deltas[deltas.Count / 2];

            var best = median;
            var bestDiff = int.MaxValue;
            foreach (var common in CommonSliceSeconds)
            {
                var diff = Math.Abs(common - median);
                if (diff < bestDiff)
                {
                    bestDiff = diff;
                    best = common;
                }
            }

            if (bestDiff <= Math.Max(30, best / 5))
                return best;

            return median;
        }
        catch
        {
            return 0;
        }
    }

    private static bool ValidateWithFileTime(string filePath, DateTime startUtc, DateTime endUtc, int sliceSeconds)
    {
        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return true;

            var writeUtc = fileInfo.LastWriteTimeUtc;
            var tolerance = TimeSpan.FromSeconds(Math.Max(60, sliceSeconds / 4));
            return writeUtc >= startUtc.Subtract(tolerance) && writeUtc <= endUtc.Add(tolerance);
        }
        catch
        {
            return true;
        }
    }

    private static bool TryParseNewFormat(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        try
        {
            var fileName = Path.GetFileNameWithoutExtension(filePath);
            var parts = fileName.Split('_');
            if (parts.Length != 3 || parts[0].Length != 10 || !parts[0].Contains('-'))
                return false;

            if (!DateTime.TryParseExact(parts[0], "yyyy-MM-dd",
                    CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var date))
                return false;

            var timeParts = parts[1].Split('-');
            if (timeParts.Length != 3)
                return false;

            if (!int.TryParse(timeParts[0], out var hour) ||
                !int.TryParse(timeParts[1], out var minute) ||
                !int.TryParse(timeParts[2], out var second) ||
                !int.TryParse(parts[2], out var segmentIndex))
                return false;

            startUtc = new DateTime(date.Year, date.Month, date.Day, hour, minute, second, DateTimeKind.Utc)
                .AddSeconds(segmentIndex * sliceSeconds);
            endUtc = startUtc.AddSeconds(sliceSeconds);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static bool TryParseLegacyFormat(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        try
        {
            var fileName = Path.GetFileNameWithoutExtension(filePath);
            var underscoreIndex = fileName.IndexOf('_');
            var segmentIndex = 0;
            if (underscoreIndex >= 0 && underscoreIndex + 1 < fileName.Length)
                int.TryParse(fileName.Substring(underscoreIndex + 1), out segmentIndex);

            var timePart = underscoreIndex >= 0 ? fileName.Substring(0, underscoreIndex) : fileName;
            var parts = timePart.Split('-');
            if (parts.Length < 3)
                return false;

            if (!int.TryParse(parts[0], out var hour) ||
                !int.TryParse(parts[1], out var minute) ||
                !int.TryParse(parts[2], out var second))
                return false;

            var dateStr = Path.GetFileName(Path.GetDirectoryName(filePath));
            if (!DateTime.TryParseExact(dateStr, "yyyy-MM-dd",
                    CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var date))
                return false;

            var localTime = new DateTime(date.Year, date.Month, date.Day, hour, minute, second, DateTimeKind.Unspecified);
            var cstZone = TimeZoneInfo.FindSystemTimeZoneById("China Standard Time");
            var baseStartTime = TimeZoneInfo.ConvertTimeToUtc(localTime, cstZone);

            startUtc = baseStartTime.AddSeconds(segmentIndex * sliceSeconds);
            endUtc = startUtc.AddSeconds(sliceSeconds);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static bool TryParseFromFileTime(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return false;

            endUtc = fileInfo.LastWriteTimeUtc;
            startUtc = endUtc.AddSeconds(-sliceSeconds);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static DateTime RefineEndTime(string filePath, DateTime startUtc, DateTime estimatedEndUtc, int sliceSeconds)
    {
        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return estimatedEndUtc;

            var writeUtc = fileInfo.LastWriteTimeUtc;
            var maxEnd = startUtc.AddSeconds(sliceSeconds * 2);
            if (writeUtc > startUtc && writeUtc <= maxEnd)
                return writeUtc;
        }
        catch
        {
            // keep estimated end
        }

        return estimatedEndUtc;
    }
}

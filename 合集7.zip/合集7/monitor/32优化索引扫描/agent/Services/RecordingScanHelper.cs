using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 按日期目录扫描录屏文件；无时间范围或日期目录不存在时回退全盘递归扫描。
/// </summary>
internal static class RecordingScanHelper
{
    /// <summary>
    /// 枚举待检查的 mp4 路径。录屏目录结构为 recordings/yyyy-MM-dd/*.mp4（本地日历日）。
    /// </summary>
    public static IReadOnlyList<string> EnumerateMp4Files(
        string recordingsRoot,
        DateTime? startUtc,
        DateTime? endUtc,
        ILogger logger)
    {
        if (!startUtc.HasValue && !endUtc.HasValue)
        {
            logger.LogInformation("Upload scan: no time range, using full recursive search under {Root}", recordingsRoot);
            return Directory.GetFiles(recordingsRoot, "*.mp4", SearchOption.AllDirectories);
        }

        var dates = GetLocalDateRange(startUtc, endUtc).ToList();
        var files = new List<string>();
        var dirsFound = 0;

        foreach (var date in dates)
        {
            var dateDir = Path.Combine(recordingsRoot, date);
            if (!Directory.Exists(dateDir))
                continue;

            dirsFound++;
            try
            {
                files.AddRange(Directory.GetFiles(dateDir, "*.mp4", SearchOption.AllDirectories));
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Upload scan: failed reading date directory {DateDir}", dateDir);
            }
        }

        logger.LogInformation(
            "Upload scan: date-dir mode, {DayCount} calendar day(s), {DirCount} dir(s) found, {FileCount} mp4 file(s)",
            dates.Count,
            dirsFound,
            files.Count);

        if (dirsFound == 0)
        {
            logger.LogWarning(
                "Upload scan: no date directories in range [{Start} .. {End}], falling back to full recursive search",
                dates.FirstOrDefault() ?? "-",
                dates.LastOrDefault() ?? "-");
            return Directory.GetFiles(recordingsRoot, "*.mp4", SearchOption.AllDirectories);
        }

        return files;
    }

    internal static IEnumerable<string> GetLocalDateRange(DateTime? startUtc, DateTime? endUtc)
    {
        var anchorStart = startUtc ?? endUtc ?? DateTime.UtcNow;
        var anchorEnd = endUtc ?? startUtc ?? DateTime.UtcNow;

        var startLocal = anchorStart.ToLocalTime().Date;
        var endLocal = anchorEnd.ToLocalTime().Date;
        if (endLocal < startLocal)
            (startLocal, endLocal) = (endLocal, startLocal);

        for (var day = startLocal; day <= endLocal; day = day.AddDays(1))
            yield return day.ToString("yyyy-MM-dd");
    }
}

using System.Diagnostics;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

internal enum RecordingUploadScanSource
{
    Sqlite,
    FilesystemFull,
}

internal sealed class RecordingUploadScanResult
{
    public required List<(FileInfo File, DateTime RecordStart, DateTime RecordEnd)> Files { get; init; }
    public RecordingUploadScanSource Source { get; init; }
    public double ScanMs { get; init; }
    public int ParseCacheEntries { get; init; }
}

/// <summary>
/// Resolves local recording files for upload tasks: SQLite index first, filesystem scan as fallback.
/// </summary>
internal static class RecordingUploadCandidateResolver
{
    private const int DefaultLookbackDays = 30;
    private const int MaxLookbackDays = 90;

    public static async Task<RecordingUploadScanResult> ResolveAsync(
        string recordingsPath,
        DateTime? startTime,
        DateTime? endTime,
        int sliceSeconds,
        IServiceScopeFactory scopeFactory,
        ILogger logger,
        CancellationToken ct = default)
    {
        var scanStarted = Stopwatch.GetTimestamp();
        var sliceDuration = TimeSpan.FromSeconds(sliceSeconds);
        var sliceCache = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        var (queryStart, queryEnd) = ResolveSqliteQueryRange(startTime, endTime);
        var sqliteCandidates = await TryResolveFromSqliteAsync(
            scopeFactory,
            queryStart,
            queryEnd,
            startTime,
            endTime,
            sliceDuration,
            logger,
            ct);

        if (sqliteCandidates.Count > 0)
        {
            return new RecordingUploadScanResult
            {
                Files = sqliteCandidates,
                Source = RecordingUploadScanSource.Sqlite,
                ScanMs = Stopwatch.GetElapsedTime(scanStarted).TotalMilliseconds,
                ParseCacheEntries = 0,
            };
        }

        logger.LogInformation(
            "Upload scan: SQLite returned no valid candidates for [{Start} .. {End}] UTC; falling back to filesystem scan",
            FormatUtc(startTime),
            FormatUtc(endTime));

        IReadOnlyList<string> filePaths;
        RecordingUploadScanSource source;
        if (startTime.HasValue || endTime.HasValue)
        {
            filePaths = RecordingScanHelper.EnumerateAllMp4FilesRecursive(recordingsPath, logger);
            source = RecordingUploadScanSource.FilesystemFull;
        }
        else
        {
            filePaths = RecordingScanHelper.EnumerateMp4Files(recordingsPath, null, null, logger);
            source = RecordingUploadScanSource.FilesystemFull;
        }

        var filesystemCandidates = BuildCandidatesFromPaths(
            filePaths,
            sliceSeconds,
            sliceDuration,
            sliceCache,
            startTime,
            endTime);

        return new RecordingUploadScanResult
        {
            Files = filesystemCandidates,
            Source = source,
            ScanMs = Stopwatch.GetElapsedTime(scanStarted).TotalMilliseconds,
            ParseCacheEntries = sliceCache.Count,
        };
    }

    private static async Task<List<(FileInfo File, DateTime RecordStart, DateTime RecordEnd)>> TryResolveFromSqliteAsync(
        IServiceScopeFactory scopeFactory,
        DateTime queryStart,
        DateTime queryEnd,
        DateTime? taskStart,
        DateTime? taskEnd,
        TimeSpan sliceDuration,
        ILogger logger,
        CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();
        var indexed = await repo.GetUnuploadedAsync(queryStart, queryEnd);

        logger.LogInformation(
            "Upload scan: SQLite index returned {Count} unuploaded row(s) for [{Start} .. {End}] UTC",
            indexed.Count,
            queryStart.ToString("yyyy-MM-dd HH:mm:ss"),
            queryEnd.ToString("yyyy-MM-dd HH:mm:ss"));

        var candidates = new List<(FileInfo File, DateTime RecordStart, DateTime RecordEnd)>();
        var missing = 0;
        var tooSmall = 0;
        var filteredOut = 0;

        foreach (var recording in indexed)
        {
            ct.ThrowIfCancellationRequested();

            if (string.IsNullOrWhiteSpace(recording.FilePath))
            {
                missing++;
                continue;
            }

            if (!File.Exists(recording.FilePath))
            {
                missing++;
                continue;
            }

            var fileInfo = new FileInfo(recording.FilePath);
            if (fileInfo.Length <= Constants.MinRecordingFileBytes)
            {
                tooSmall++;
                continue;
            }

            var recordStart = recording.StartTime.ToUniversalTime();
            var recordEnd = recording.EndTime.ToUniversalTime();
            RecordingTimeParser.AlignWithFileWriteTime(fileInfo, sliceDuration, ref recordStart, ref recordEnd);

            if (taskStart.HasValue && recordEnd < taskStart.Value)
            {
                filteredOut++;
                continue;
            }

            if (taskEnd.HasValue && recordStart > taskEnd.Value)
            {
                filteredOut++;
                continue;
            }

            candidates.Add((fileInfo, recordStart, recordEnd));
        }

        if (indexed.Count > 0)
        {
            logger.LogInformation(
                "Upload scan: SQLite validated {Valid} file(s) (missing={Missing}, tooSmall={TooSmall}, filtered={Filtered})",
                candidates.Count,
                missing,
                tooSmall,
                filteredOut);
        }

        return candidates;
    }

    private static List<(FileInfo File, DateTime RecordStart, DateTime RecordEnd)> BuildCandidatesFromPaths(
        IReadOnlyList<string> filePaths,
        int sliceSeconds,
        TimeSpan sliceDuration,
        Dictionary<string, int> sliceCache,
        DateTime? startTime,
        DateTime? endTime)
    {
        var filesToUpload = new List<(FileInfo File, DateTime RecordStart, DateTime RecordEnd)>();

        foreach (var file in filePaths)
        {
            var fileInfo = new FileInfo(file);
            DateTime recordStart;
            DateTime recordEnd;
            if (RecordingTimeParser.TryParse(file, sliceSeconds, out recordStart, out recordEnd, sliceCache))
            {
                // parsed
            }
            else
            {
                recordStart = fileInfo.LastWriteTimeUtc;
                recordEnd = recordStart.Add(sliceDuration);
            }

            RecordingTimeParser.AlignWithFileWriteTime(fileInfo, sliceDuration, ref recordStart, ref recordEnd);

            if (startTime.HasValue && recordEnd < startTime.Value)
                continue;
            if (endTime.HasValue && recordStart > endTime.Value)
                continue;

            if (fileInfo.Length <= Constants.MinRecordingFileBytes)
                continue;

            filesToUpload.Add((fileInfo, recordStart, recordEnd));
        }

        return filesToUpload;
    }

    private static (DateTime Start, DateTime End) ResolveSqliteQueryRange(DateTime? startTime, DateTime? endTime)
    {
        if (startTime.HasValue && endTime.HasValue)
            return (startTime.Value.ToUniversalTime(), endTime.Value.ToUniversalTime());

        if (startTime.HasValue)
            return (startTime.Value.ToUniversalTime(), DateTime.UtcNow);

        if (endTime.HasValue)
        {
            var endUtc = endTime.Value.ToUniversalTime();
            return (endUtc.AddDays(-MaxLookbackDays), endUtc);
        }

        var now = DateTime.UtcNow;
        return (now.AddDays(-DefaultLookbackDays), now);
    }

    private static string FormatUtc(DateTime? value) =>
        value?.ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss") ?? "any";
}

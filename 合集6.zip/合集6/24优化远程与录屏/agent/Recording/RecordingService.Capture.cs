using System.Diagnostics;
using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Models;
using Microsoft.Extensions.Logging;

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.RecordingServices;

public sealed partial class RecordingService
{
    private ICaptureCoordinator? _captureCoordinator;
    private string? _persistedOutputPattern;

    internal void BindCaptureCoordinator(ICaptureCoordinator captureCoordinator) =>
        _captureCoordinator = captureCoordinator;

    internal void NotifyPolicyForCapture(AgentPolicy? policy)
    {
        if (_captureCoordinator is CaptureCoordinator coordinator)
            coordinator.UpdatePolicy(policy);
    }

    private async Task<bool> LaunchFfmpegCaptureAsync(string ffmpeg)
    {
        var args = BuildFfmpegCaptureArguments();
        if (string.IsNullOrWhiteSpace(args))
        {
            _logger.LogError("Failed to build FFmpeg arguments");
            return false;
        }

        _logger.LogInformation("FFmpeg recording args: {Args}", args);

        _ffmpegProcess = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = ffmpeg,
                Arguments = args,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
            },
            EnableRaisingEvents = true,
        };

        if (_ffmpegExitedHandler != null)
            _ffmpegProcess.Exited -= _ffmpegExitedHandler;

        _ffmpegExitedHandler = async (_, _) => await OnFfmpegExitedAsync();
        _ffmpegProcess.Exited += _ffmpegExitedHandler;

        if (!_ffmpegProcess.Start())
        {
            _logger.LogError("Failed to start FFmpeg");
            await CleanupProcessAsync();
            return false;
        }

        _lastSuccessfulFrame = DateTime.UtcNow;
        _lastEncoderHeartbeat = DateTime.UtcNow;
        return true;
    }

    private async Task EnsureRecordingBackgroundTasksStartedAsync()
    {
        if (_recordingCts == null || _recordingCts.IsCancellationRequested)
        {
            try { _recordingCts?.Cancel(); } catch { }
            _recordingCts?.Dispose();
            _recordingCts = new CancellationTokenSource();
        }

        if (_ffmpegProcess != null)
        {
            await SafeWaitTaskAsync(_ffmpegOutputTask);
            _ffmpegOutputTask = Task.Run(() => LogFfmpegOutputAsync(_ffmpegProcess));
        }
    }

    private string BuildFfmpegCaptureArguments()
    {
        if (string.IsNullOrWhiteSpace(_persistedOutputPattern))
            return "";

        var config = _currentPolicy?.GetRecordingConfig() ?? new RecordingConfig();
        var fps = Math.Clamp(config.Fps, 1, 30);
        var sliceSeconds = Math.Max(config.GetSliceSeconds(), Constants.MinSliceSeconds);
        var resolution = GetResolution(config.Resolution);
        var (encoderArgs, alignedRes) = BuildEncoderArgs(_currentEncoder, config.Quality, fps, resolution, config);
        var profile = _captureCoordinator?.GetProfile();

        var sb = new System.Text.StringBuilder();
        var sharedBridgeInput = profile?.Mode == CaptureMode.SharedBridge &&
                                !string.IsNullOrWhiteSpace(profile.RecordingInputArgs);
        sb.Append(sharedBridgeInput
            ? "-hide_banner -loglevel warning -progress pipe:2 -nostats "
            : "-hide_banner -loglevel warning -nostats ");

        if (sharedBridgeInput)
        {
            sb.Append(profile!.RecordingInputArgs).Append(' ');
            sb.Append($"-vf \"fps={fps},scale={alignedRes.width}:{alignedRes.height}\" ");
        }
        else
        {
            sb.Append($"-f gdigrab -framerate {fps} -i desktop ");
            sb.Append($"-vf \"fps={fps},scale={alignedRes.width}:{alignedRes.height}\" ");
        }

        sb.Append(encoderArgs);
        sb.Append(" -movflags +faststart ");
        sb.Append($"-f segment -segment_time {sliceSeconds} -reset_timestamps 1 ");
        sb.Append('"').Append(_persistedOutputPattern).Append('"');
        return sb.ToString();
    }
}

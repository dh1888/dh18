import { ElMessage } from "element-plus";
import workforceApi from "./workforce_api";

export async function downloadClientInstaller(): Promise<void> {
  const metaRes = await workforceApi.getClientDownload();
  const meta = metaRes.data || metaRes;

  if (meta.mode === "external" && meta.downloadUrl) {
    window.open(meta.downloadUrl, "_blank", "noopener");
    ElMessage.success("正在打开客户端下载页面");
    return;
  }

  const res = await workforceApi.downloadClientFile();
  const blob = res.data as Blob;
  const fileName =
    meta.fileName || meta.filename || "EnterpriseAgent-setup.exe";
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  anchor.click();
  URL.revokeObjectURL(url);
  ElMessage.success("客户端下载已开始");
}

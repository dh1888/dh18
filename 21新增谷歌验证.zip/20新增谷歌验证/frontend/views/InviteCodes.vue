<template>
  <div class="invite-codes-page">
    <el-card shadow="hover">
      <template #header>
        <div class="card-header">
          <span>邀请码管理</span>
          <el-button type="primary" @click="loadInviteCodes">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
        </div>
      </template>

      <el-form :inline="true" class="filter-form">
        <el-form-item label="员工">
          <el-select
            v-model="employeeFilter"
            placeholder="全部员工"
            clearable
            filterable
            style="width: 240px"
            @change="loadInviteCodes"
          >
            <el-option
              v-for="emp in employees"
              :key="emp.id"
              :label="`${emp.name}${emp.employeeId ? ` (${emp.employeeId})` : ''}`"
              :value="emp.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select
            v-model="statusFilter"
            placeholder="全部状态"
            clearable
            style="width: 140px"
            @change="applyFilters"
          >
            <el-option label="有效" value="active" />
            <el-option label="已使用" value="used" />
            <el-option label="已过期" value="expired" />
            <el-option label="已作废" value="revoked" />
          </el-select>
        </el-form-item>
      </el-form>

      <el-table v-loading="loading" :data="filteredItems" stripe>
        <el-table-column prop="code" label="邀请码" min-width="160">
          <template #default="{ row }">
            <code class="code-text">{{ row.code }}</code>
            <el-button link type="primary" size="small" @click="copyCode(row.code)">
              复制
            </el-button>
          </template>
        </el-table-column>
        <el-table-column prop="employeeName" label="员工" min-width="120" />
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)" size="small">
              {{ statusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="expiresAt" label="过期时间" min-width="170">
          <template #default="{ row }">{{ formatTime(row.expiresAt) }}</template>
        </el-table-column>
        <el-table-column prop="usedAt" label="使用时间" min-width="170">
          <template #default="{ row }">{{ formatTime(row.usedAt) }}</template>
        </el-table-column>
        <el-table-column prop="deviceId" label="绑定设备" min-width="120">
          <template #default="{ row }">
            {{ row.deviceId ? row.deviceId.slice(0, 8) + "..." : "-" }}
          </template>
        </el-table-column>
        <el-table-column prop="createdAt" label="创建时间" min-width="170">
          <template #default="{ row }">{{ formatTime(row.createdAt) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button
              v-if="row.status === 'active'"
              link
              type="danger"
              size="small"
              v-permission="'invite:manage'"
              @click="handleRevoke(row)"
            >
              作废
            </el-button>
            <el-button
              link
              type="primary"
              size="small"
              v-permission="'invite:manage'"
              @click="handleRegenerate(row)"
            >
              重新生成
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { Refresh } from "@element-plus/icons-vue";
import workforceApi from "@api/workforce_api";
import adminApi from "@api/admin_api";

interface InviteCodeRow {
  id: string;
  code: string;
  employeeId: string;
  employeeName: string;
  status: string;
  expiresAt?: string;
  usedAt?: string;
  revokedAt?: string;
  createdAt?: string;
  deviceId?: string;
}

interface EmployeeOption {
  id: string;
  name: string;
  employeeId?: string;
}

const loading = ref(false);
const items = ref<InviteCodeRow[]>([]);
const employees = ref<EmployeeOption[]>([]);
const employeeFilter = ref("");
const statusFilter = ref("");

const filteredItems = computed(() => {
  if (!statusFilter.value) return items.value;
  return items.value.filter((row) => row.status === statusFilter.value);
});

const statusLabel = (status: string) => {
  const map: Record<string, string> = {
    active: "有效",
    used: "已使用",
    expired: "已过期",
    revoked: "已作废",
  };
  return map[status] || status;
};

const statusTagType = (status: string) => {
  const map: Record<string, string> = {
    active: "success",
    used: "info",
    expired: "warning",
    revoked: "danger",
  };
  return map[status] || "info";
};

const formatTime = (value?: string) => {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
};

const loadEmployees = async () => {
  try {
    const { data } = await adminApi.getEmployees({ limit: 500 });
    employees.value = (data.items || data || []).map((e: any) => ({
      id: e.id,
      name: e.name,
      employeeId: e.employee_id || e.employeeId,
    }));
  } catch {
    employees.value = [];
  }
};

const loadInviteCodes = async () => {
  loading.value = true;
  try {
    const { data } = await workforceApi.listInviteCodes(
      employeeFilter.value || undefined,
    );
    items.value = data.items || [];
  } catch (error: any) {
    ElMessage.error(error.message || "加载邀请码失败");
  } finally {
    loading.value = false;
  }
};

const applyFilters = () => {
  // client-side status filter via computed
};

const copyCode = async (code: string) => {
  try {
    await navigator.clipboard.writeText(code);
    ElMessage.success("已复制邀请码");
  } catch {
    ElMessage.error("复制失败");
  }
};

const handleRevoke = (row: InviteCodeRow) => {
  ElMessageBox.confirm(`确定作废邀请码 ${row.code} 吗？`, "作废邀请码", {
    type: "warning",
  }).then(async () => {
    await workforceApi.revokeInviteCode(row.id);
    ElMessage.success("邀请码已作废");
    await loadInviteCodes();
  });
};

const handleRegenerate = (row: InviteCodeRow) => {
  ElMessageBox.confirm(
    `将为员工「${row.employeeName}」生成新的邀请码，旧的有效码将作废。`,
    "重新生成邀请码",
    { type: "info" },
  ).then(async () => {
    const { data } = await workforceApi.regenerateInviteCode(row.employeeId);
    ElMessage.success(`新邀请码：${data.code}`);
    await loadInviteCodes();
  });
};

onMounted(async () => {
  await Promise.all([loadEmployees(), loadInviteCodes()]);
});
</script>

<style scoped>
.invite-codes-page {
  padding: 0;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.filter-form {
  margin-bottom: 16px;
}

.code-text {
  font-family: Consolas, monospace;
  margin-right: 8px;
}
</style>

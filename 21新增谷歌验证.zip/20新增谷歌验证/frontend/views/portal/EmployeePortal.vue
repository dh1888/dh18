<template>
  <div class="employee-portal" v-loading="loading">
    <el-row :gutter="20">
      <el-col :span="24">
        <el-card shadow="hover">
          <template #header>
            <div class="card-header">
              <span>我的首页</span>
              <el-tag v-if="portal?.todayAttendance?.status" type="success">
                今日：{{ statusLabel(portal?.todayAttendance?.status) }}
              </el-tag>
            </div>
          </template>
          <el-descriptions :column="2" border>
            <el-descriptions-item label="姓名">{{ portal?.employee?.name }}</el-descriptions-item>
            <el-descriptions-item label="工号">{{ portal?.employee?.employeeNumber || "-" }}</el-descriptions-item>
            <el-descriptions-item label="岗位">{{ portal?.employee?.position || "-" }}</el-descriptions-item>
            <el-descriptions-item label="部门">{{ portal?.employee?.department || "-" }}</el-descriptions-item>
            <el-descriptions-item label="设备绑定">
              <el-tag :type="portal?.deviceBound ? 'success' : 'info'">
                {{ portal?.deviceBound ? "已绑定" : "未绑定" }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="在线状态">
              {{ portal?.device?.onlineStatus === "online" ? "在线" : "离线" }}
            </el-descriptions-item>
          </el-descriptions>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" style="margin-top: 20px">
      <el-col :md="12" :span="24">
        <el-card shadow="hover">
          <template #header>我的邀请码</template>
          <div v-if="portal?.inviteCode" class="invite-box">
            <code class="invite-code">{{ portal.inviteCode }}</code>
            <el-button size="small" @click="copyInvite">复制</el-button>
          </div>
          <el-empty v-else description="暂无有效邀请码，请联系管理员" />
          <p class="hint">邀请码用于客户端首次激活，一次性有效。</p>
          <el-button v-if="portal?.deviceBound" type="primary" link @click="$router.push('/recordings')">
            查看我的录屏
          </el-button>
        </el-card>
      </el-col>
      <el-col :md="12" :span="24">
        <el-card shadow="hover">
          <template #header>客户端下载</template>
          <p>请下载并安装 WinForms 客户端，启动后输入上方邀请码完成绑定。</p>
          <el-button type="primary" :loading="downloadLoading" @click="handleDownloadClient">
            下载客户端
          </el-button>
          <p v-if="clientVersion" class="hint">版本：{{ clientVersion }}</p>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" style="margin-top: 20px">
      <el-col :span="24">
        <el-card shadow="hover">
          <template #header>
            <div class="card-header">
              <span>我的考勤（{{ attendanceMonth }}）</span>
              <el-date-picker
                v-model="attendanceMonth"
                type="month"
                value-format="YYYY-MM"
                @change="loadAttendance"
              />
            </div>
          </template>
          <el-table :data="attendanceItems" size="small">
            <el-table-column prop="date" label="日期" width="120" />
            <el-table-column label="状态" width="120">
              <template #default="{ row }">{{ statusLabel(row.status) }}</template>
            </el-table-column>
            <el-table-column prop="checkinTime" label="上班" />
            <el-table-column prop="checkoutTime" label="下班" />
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from "vue";
import { ElMessage } from "element-plus";
import workforceApi from "@api/workforce_api";
import { downloadClientInstaller } from "@api/clientDownload";

const loading = ref(false);
const portal = ref<any>(null);
const attendanceMonth = ref(new Date().toISOString().slice(0, 7));
const attendanceItems = ref<any[]>([]);
const downloadUrl = ref("#");
const downloadLoading = ref(false);
const clientVersion = ref("");

const statusMap: Record<string, string> = {
  pending: "未上班",
  working: "工作中",
  work: "已下班",
  leave: "请假",
  absent: "旷工",
  rest_full: "全休",
  rest_half: "半休",
};

const statusLabel = (s?: string) => statusMap[s || ""] || s || "-";

const loadPortal = async () => {
  loading.value = true;
  try {
    const res = await workforceApi.getPortalMe();
    portal.value = res.data || res;
  } catch {
    ElMessage.error("加载个人中心失败");
  } finally {
    loading.value = false;
  }
};

const loadAttendance = async () => {
  try {
    const res = await workforceApi.getMyAttendance(attendanceMonth.value);
    const data = res.data || res;
    attendanceItems.value = data.items || [];
  } catch {
    attendanceItems.value = [];
  }
};

const loadDownload = async () => {
  try {
    const res = await workforceApi.getClientDownload();
    const data = res.data || res;
    downloadUrl.value = data.downloadUrl || "#";
    clientVersion.value = data.version || "";
  } catch {
    downloadUrl.value = "#";
  }
};

const handleDownloadClient = async () => {
  downloadLoading.value = true;
  try {
    await downloadClientInstaller();
  } catch {
    ElMessage.error("下载失败，请联系管理员配置安装包");
  } finally {
    downloadLoading.value = false;
  }
};

const copyInvite = async () => {
  if (!portal.value?.inviteCode) return;
  try {
    await navigator.clipboard.writeText(portal.value.inviteCode);
    ElMessage.success("邀请码已复制");
  } catch {
    ElMessage.error("复制失败");
  }
};

onMounted(async () => {
  await loadPortal();
  await loadAttendance();
  await loadDownload();
});
</script>

<style scoped>
.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.invite-box {
  display: flex;
  align-items: center;
  gap: 12px;
}
.invite-code {
  font-size: 20px;
  letter-spacing: 2px;
  padding: 8px 12px;
  background: #f5f7fa;
  border-radius: 6px;
}
.hint {
  color: #909399;
  font-size: 12px;
  margin-top: 8px;
}
</style>

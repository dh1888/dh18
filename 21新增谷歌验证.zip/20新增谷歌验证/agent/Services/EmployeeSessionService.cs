using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using EnterpriseAgent.Agent.Models;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 共享工位：员工使用后台账号密码登录/登出，同一终端可轮流多人使用。
/// </summary>
public sealed class EmployeeSessionService
{
    private readonly ILogger<EmployeeSessionService> _logger;
    private readonly IHttpClientFactory _httpFactory;
    private readonly AuthTokenProvider _authTokenProvider;
    private readonly WorkSessionService? _workSession;

    private readonly object _lock = new();
    private string? _employeeName;
    private string? _username;

    public EmployeeSessionService(
        ILogger<EmployeeSessionService> logger,
        IHttpClientFactory httpFactory,
        AuthTokenProvider authTokenProvider,
        WorkSessionService? workSession = null)
    {
        _logger = logger;
        _httpFactory = httpFactory;
        _authTokenProvider = authTokenProvider;
        _workSession = workSession;
    }

    private Func<string>? _serverUrlResolver;
    public void SetServerUrlResolver(Func<string> resolver) => _serverUrlResolver = resolver;

    public bool IsLoggedIn
    {
        get { lock (_lock) return !string.IsNullOrEmpty(_employeeName); }
    }

    public string? EmployeeName
    {
        get { lock (_lock) return _employeeName; }
    }

    public string? Username
    {
        get { lock (_lock) return _username; }
    }

    public async Task<bool> RefreshSessionAsync(CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return false;

        using var request = new HttpRequestMessage(HttpMethod.Get, $"{ServerUrl()}/api/v1/agent/session");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        if (!response.IsSuccessStatusCode)
            return false;

        var body = await response.Content.ReadAsStringAsync(ct);
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return false;
            var loggedIn = data.TryGetProperty("loggedIn", out var li) && li.GetBoolean();
            if (!loggedIn)
            {
                ClearLocal();
                return false;
            }
            var name = data.TryGetProperty("name", out var n) ? n.GetString() : "";
            var user = data.TryGetProperty("username", out var u) ? u.GetString() : "";
            lock (_lock)
            {
                _employeeName = name;
                _username = user;
            }
            return true;
        }
        catch
        {
            return false;
        }
    }

    public async Task<bool> LoginAsync(string username, string password, CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
        {
            _logger.LogWarning("Employee login failed: device not registered");
            return false;
        }

        var payload = JsonSerializer.Serialize(new { username, password });
        using var request = new HttpRequestMessage(HttpMethod.Post, $"{ServerUrl()}/api/v1/agent/employee-login")
        {
            Content = new StringContent(payload, Encoding.UTF8, "application/json")
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning("Employee login failed: {Status} {Body}", response.StatusCode, body);
            return false;
        }

        string? name = null;
        string? user = username;
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("data", out var data))
            {
                name = data.TryGetProperty("name", out var n) ? n.GetString() : null;
                user = data.TryGetProperty("username", out var u) ? u.GetString() : username;
            }
        }
        catch { /* ignore */ }

        lock (_lock)
        {
            _employeeName = name ?? username;
            _username = user;
        }
        _logger.LogInformation("Employee logged in: {Name} ({User})", _employeeName, _username);
        return true;
    }

    public async Task<bool> LogoutAsync(CancellationToken ct = default)
    {
        if (_workSession != null && _workSession.HasOpenSession)
        {
            await _workSession.CheckOutAsync(ct);
        }

        var snapshot = _authTokenProvider.GetSnapshot();
        if (!string.IsNullOrEmpty(snapshot.Token))
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, $"{ServerUrl()}/api/v1/agent/employee-logout");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
            using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("Employee logout API failed: {Status}", response.StatusCode);
            }
        }

        ClearLocal();
        _logger.LogInformation("Employee logged out");
        return true;
    }

    private void ClearLocal()
    {
        lock (_lock)
        {
            _employeeName = null;
            _username = null;
        }
    }

    private string ServerUrl() => _serverUrlResolver?.Invoke() ?? "http://localhost:8080";
}

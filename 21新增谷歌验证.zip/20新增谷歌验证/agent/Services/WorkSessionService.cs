using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using EnterpriseAgent.Agent.Models;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 上下班 Session：调用后端 checkin/checkout，并协调录屏启停。
/// </summary>
public sealed class WorkSessionService
{
    private readonly ILogger<WorkSessionService> _logger;
    private readonly IHttpClientFactory _httpFactory;
    private readonly AuthTokenProvider _authTokenProvider;
    private readonly ScreenRecorderService _recorder;
    private readonly FileUploadService? _uploadService;

    private string? _openSessionId;
    private readonly object _lock = new();

    public WorkSessionService(
        ILogger<WorkSessionService> logger,
        IHttpClientFactory httpFactory,
        AuthTokenProvider authTokenProvider,
        ScreenRecorderService recorder,
        FileUploadService? uploadService = null)
    {
        _logger = logger;
        _httpFactory = httpFactory;
        _authTokenProvider = authTokenProvider;
        _recorder = recorder;
        _uploadService = uploadService;
    }

    public bool HasOpenSession
    {
        get { lock (_lock) return !string.IsNullOrEmpty(_openSessionId); }
    }

    public async Task<bool> CheckInAsync(CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (!snapshot.IsApproved || string.IsNullOrEmpty(snapshot.Token))
        {
            _logger.LogWarning("Check-in rejected: device not approved or missing token");
            return false;
        }

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/checkin");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning("Check-in failed: {Status} {Body}", response.StatusCode, body);
            return false;
        }

        var sessionId = ParseSessionId(body);
        lock (_lock) { _openSessionId = sessionId; }

        _recorder.StartRecording();
        _logger.LogInformation("Check-in OK, session={SessionId}", sessionId);
        return true;
    }

    public async Task<bool> CheckOutAsync(CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return false;

        string? sessionId;
        lock (_lock) { sessionId = _openSessionId; }

        _recorder.StopRecording();

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/checkout");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
        if (!string.IsNullOrEmpty(sessionId))
        {
            var payload = JsonSerializer.Serialize(new { sessionId });
            request.Content = new StringContent(payload, Encoding.UTF8, "application/json");
        }

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning("Check-out failed: {Status} {Body}", response.StatusCode, body);
            return false;
        }

        lock (_lock) { _openSessionId = null; }
        _logger.LogInformation("Check-out OK");
        return true;
    }

    private string GetServerUrl()
    {
        // WorkSessionService 无直接 config 注入时从 Auth 快照无法取 URL；由 Program 注册时通过 optional delegate 更好。
        // 简化：从环境或默认 — 实际通过 SetServerUrlResolver 设置。
        return _serverUrlResolver?.Invoke() ?? "http://localhost:8080";
    }

    private Func<string>? _serverUrlResolver;
    public void SetServerUrlResolver(Func<string> resolver) => _serverUrlResolver = resolver;

    private static string? ParseSessionId(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("data", out var data))
            {
                if (data.TryGetProperty("sessionId", out var sid))
                    return sid.GetString();
            }
        }
        catch { /* ignore */ }
        return null;
    }
}

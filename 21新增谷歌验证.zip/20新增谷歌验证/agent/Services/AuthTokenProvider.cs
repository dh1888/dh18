// Services/AuthTokenProvider.cs - 修复编译错误

using System.Collections.Concurrent;
using System.Text;
using System.Text.Json;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;  // ✅ 添加：SensitiveDataFilter 所在命名空间
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;  // ✅ 添加：IHttpClientFactory 所在命名空间

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 认证快照（不可变对象）
/// </summary>
public sealed record AuthSnapshot(
    string DeviceId,
    string Token,
    string RefreshToken,
    string DeviceSecret,
    string DeviceStatus,
    long Version
)
{
    public bool IsAuthenticated => !string.IsNullOrEmpty(Token);
    public bool HasDeviceId => !string.IsNullOrEmpty(DeviceId);
    public bool IsApproved =>
        string.Equals(DeviceStatus, "approved", StringComparison.OrdinalIgnoreCase);
    public bool IsRejected =>
        string.Equals(DeviceStatus, "rejected", StringComparison.OrdinalIgnoreCase);
    public bool IsPendingApproval =>
        !IsApproved && !IsRejected;

    public static AuthSnapshot Empty => new("", "", "", "", "", 0);
}

/// <summary>
/// Provider接口
/// </summary>
public interface IAuthTokenProvider
{
    AuthSnapshot GetSnapshot();
    bool IsAuthenticated { get; }

    void UpdateAuth(string? deviceId, string? token, string? refreshToken = null, string? deviceSecret = null, string? deviceStatus = null);

    void UpdateDeviceStatus(string deviceStatus);

    void ClearAuth();

    bool IsSessionRevoked { get; }

    void RevokeSession();

    void ClearSessionRevoke();

    IDisposable Subscribe(Action<AuthSnapshot> onNext);

    Task<string?> RefreshTokenAsync(CancellationToken ct = default);

    DateTime? GetTokenExpiresAtUtc();
}

/// <summary>
/// 企业级线程安全实现（最终生产版）
/// </summary>
public sealed class AuthTokenProvider : IAuthTokenProvider, IDisposable
{
    private readonly ILogger<AuthTokenProvider> _logger;
    private readonly AgentConfig _config;
    private readonly HttpClient _httpClient;

    private AuthSnapshot _state = AuthSnapshot.Empty;
    private long _version = 0;

    private readonly ConcurrentDictionary<Guid, Action<AuthSnapshot>> _subscribers = new();

    private int _disposed;

    // 防止 refresh 并发风暴
    private readonly SemaphoreSlim _refreshLock = new(1, 1);

    private DateTime? _tokenExpiresAtUtc;

    private volatile bool _sessionRevoked;

    public bool IsSessionRevoked => _sessionRevoked;

    public bool IsAuthenticated => GetSnapshot().IsAuthenticated;

    public DateTime? GetTokenExpiresAtUtc() => _tokenExpiresAtUtc;

    public AuthTokenProvider(
        ILogger<AuthTokenProvider> logger,
        AgentConfig config,
        IHttpClientFactory httpFactory)
    {
        _logger = logger;
        _config = config;

        _httpClient = httpFactory.CreateClient("AgentClient");
        _httpClient.Timeout = TimeSpan.FromSeconds(30);

        // 初始化 state
        if (!string.IsNullOrEmpty(config.DeviceId) &&
            !string.IsNullOrEmpty(config.Auth.Token))
        {
            var version = Interlocked.Increment(ref _version);
            _state = new AuthSnapshot(
                config.DeviceId,
                config.Auth.Token,
                config.Auth.RefreshToken ?? "",
                config.Auth.DeviceSecret ?? "",
                config.Auth.DeviceStatus ?? "",
                version
            );
            SyncTokenExpiry(config.Auth.Token);
            _logger.LogInformation("AuthTokenProvider initialized from config v{Version}", version);
        }
        else
        {
            _logger.LogInformation("AuthTokenProvider initialized with empty state");
        }
    }

    // ================= CORE =================

    public AuthSnapshot GetSnapshot()
        => Volatile.Read(ref _state);

    public void UpdateAuth(string? deviceId, string? token, string? refreshToken = null, string? deviceSecret = null, string? deviceStatus = null)
    {
        if (IsDisposed()) return;

        var old = GetSnapshot();

        var newDeviceId = deviceId ?? old.DeviceId;
        var newToken = token ?? old.Token;
        var newRefreshToken = refreshToken ?? old.RefreshToken;
        var newDeviceSecret = deviceSecret ?? old.DeviceSecret;
        var newDeviceStatus = deviceStatus ?? old.DeviceStatus;

        if (old.DeviceId == newDeviceId &&
            old.Token == newToken &&
            old.RefreshToken == newRefreshToken &&
            old.DeviceSecret == newDeviceSecret &&
            old.DeviceStatus == newDeviceStatus)
        {
            _logger.LogDebug("UpdateAuth called but no changes, skipping");
            return;
        }

        var newVersion = Interlocked.Increment(ref _version);

        var newState = new AuthSnapshot(
            newDeviceId,
            newToken,
            newRefreshToken,
            newDeviceSecret,
            newDeviceStatus,
            newVersion
        );

        Volatile.Write(ref _state, newState);
        SyncTokenExpiry(newToken);

        try
        {
            if (deviceId != null) _config.DeviceId = deviceId;
            if (token != null) _config.Auth.Token = token;
            if (refreshToken != null) _config.Auth.RefreshToken = refreshToken;
            if (deviceSecret != null) _config.Auth.DeviceSecret = deviceSecret;
            if (deviceStatus != null) _config.Auth.DeviceStatus = deviceStatus;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to sync config, provider state is authoritative");
        }

        _logger.LogInformation(
            "Auth updated v{Old} → v{New}, device={Device}, status={Status}, token length={TokenLen}",
            old.Version,
            newVersion,
            SensitiveDataFilter.SafeDeviceId(newState.DeviceId),
            string.IsNullOrEmpty(newState.DeviceStatus) ? "unknown" : newState.DeviceStatus,
            newToken?.Length ?? 0
        );

        Notify(newState);
    }

    public void UpdateDeviceStatus(string deviceStatus)
    {
        if (IsDisposed()) return;

        var normalized = deviceStatus.Trim().ToLowerInvariant();
        if (normalized is not ("pending" or "approved" or "rejected"))
        {
            _logger.LogWarning("Ignored invalid device status: {Status}", deviceStatus);
            return;
        }

        var snapshot = GetSnapshot();
        UpdateAuth(snapshot.DeviceId, snapshot.Token, snapshot.RefreshToken, snapshot.DeviceSecret, normalized);
    }

    public void ClearAuth()
    {
        if (IsDisposed()) return;

        var newVersion = Interlocked.Increment(ref _version);

        var state = AuthSnapshot.Empty with { Version = newVersion };
        Volatile.Write(ref _state, state);
        _tokenExpiresAtUtc = null;

        try
        {
            _config.DeviceId = "";
            _config.Auth.Clear();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to clear config, provider state is authoritative");
        }

        _logger.LogWarning("Auth cleared v{Version}", newVersion);

        Notify(state);
    }

    public void RevokeSession()
    {
        _sessionRevoked = true;
        ClearAuth();
    }

    public void ClearSessionRevoke()
    {
        _sessionRevoked = false;
    }

    // ================= SUBSCRIBE =================

    public IDisposable Subscribe(Action<AuthSnapshot> onNext)
    {
        if (IsDisposed())
            throw new ObjectDisposedException(nameof(AuthTokenProvider));

        var id = Guid.NewGuid();
        _subscribers[id] = onNext;

        // 立即推送当前状态
        SafeInvoke(onNext, GetSnapshot());

        _logger.LogDebug("New subscription, total={Count}", _subscribers.Count);

        return new SubscriptionHandle(this, id);
    }

    private void Notify(AuthSnapshot state)
    {
        foreach (var sub in _subscribers.Values)
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                SafeInvoke(sub, state);
            });
        }
    }

    private void SafeInvoke(Action<AuthSnapshot> sub, AuthSnapshot state)
    {
        try
        {
            sub(state);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Subscriber callback error ignored");
        }
    }

    // ================= REFRESH =================

    public async Task<string?> RefreshTokenAsync(CancellationToken ct = default)
    {
        var versionBeforeWait = GetSnapshot().Version;

        if (!await _refreshLock.WaitAsync(0, ct))
        {
            _logger.LogDebug("Refresh already in progress, waiting...");
            await _refreshLock.WaitAsync(ct);
        }

        try
        {
            var snapshot = GetSnapshot();
            if (snapshot.Version > versionBeforeWait && snapshot.IsAuthenticated)
            {
                _logger.LogDebug(
                    "Refresh completed by another caller, reusing token v{Version}",
                    snapshot.Version);
                return snapshot.Token;
            }

            if (string.IsNullOrEmpty(snapshot.RefreshToken))
            {
                _logger.LogWarning("Refresh skipped: RefreshToken is empty");
                return null;
            }

            var requestBody = new
            {
                refreshToken = snapshot.RefreshToken,
                deviceId = snapshot.DeviceId
            };

            using var request = new HttpRequestMessage(HttpMethod.Post,
                $"{_config.ServerUrl}/api/v1/devices/refresh")
            {
                Content = new StringContent(
                    JsonSerializer.Serialize(requestBody),
                    Encoding.UTF8,
                    "application/json")
            };

            using var response = await _httpClient.SendAsync(request, ct);
            var body = await response.Content.ReadAsStringAsync(ct);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("Refresh failed: {StatusCode}, Response: {Response}",
                    response.StatusCode,
                    body.Length > 200 ? body[..200] : body);
                if (body.Contains("revoked", StringComparison.OrdinalIgnoreCase) ||
                    body.Contains("version conflict", StringComparison.OrdinalIgnoreCase))
                {
                    RevokeSession();
                }
                return null;
            }

            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;

            string? token = null;
            string? refresh = null;
            DateTime? expiresAt = null;

            if (root.TryGetProperty("data", out var data))
            {
                if (data.TryGetProperty("token", out var t))
                    token = t.GetString();
                if (data.TryGetProperty("refreshToken", out var r))
                    refresh = r.GetString();
                if (data.TryGetProperty("expiresAt", out var e) && e.ValueKind == JsonValueKind.String)
                    expiresAt = TryParseExpiresAt(e.GetString());
            }
            else
            {
                if (root.TryGetProperty("token", out var t))
                    token = t.GetString();
                if (root.TryGetProperty("refreshToken", out var r))
                    refresh = r.GetString();
                if (root.TryGetProperty("expiresAt", out var e) && e.ValueKind == JsonValueKind.String)
                    expiresAt = TryParseExpiresAt(e.GetString());
            }

            if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(refresh))
            {
                _logger.LogWarning("Refresh response missing token or refreshToken");
                return null;
            }

            // 更新认证信息
            UpdateAuth(snapshot.DeviceId, token, refresh);
            if (expiresAt.HasValue)
                ApplyTokenExpiresAt(expiresAt);

            _logger.LogInformation("Token refreshed successfully v{Version}", _version);
            return token;
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("Refresh cancelled");
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Refresh error");
            return null;
        }
        finally
        {
            _refreshLock.Release();
        }
    }

    // ================= DISPOSE =================

    private bool IsDisposed()
        => Volatile.Read(ref _disposed) == 1;

    public void Dispose()
    {
        if (Interlocked.Exchange(ref _disposed, 1) == 1)
            return;

        _subscribers.Clear();
        _refreshLock.Dispose();

        _logger.LogInformation("AuthTokenProvider disposed");
    }

    private static DateTime? TryParseExpiresAt(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return null;

        if (DateTime.TryParse(value, null, System.Globalization.DateTimeStyles.RoundtripKind, out var parsed))
            return parsed.ToUniversalTime();

        return null;
    }

    private void SyncTokenExpiry(string? token, DateTime? explicitExpiry = null)
    {
        if (explicitExpiry.HasValue)
        {
            _tokenExpiresAtUtc = explicitExpiry.Value.ToUniversalTime();
            return;
        }

        _tokenExpiresAtUtc = JwtTokenExpiryParser.TryGetExpiryUtc(token)
            ?? (string.IsNullOrEmpty(token) ? null : DateTime.UtcNow.AddDays(7));
    }

    public void ApplyTokenExpiresAt(DateTime? expiresAtUtc)
    {
        if (expiresAtUtc.HasValue)
            _tokenExpiresAtUtc = expiresAtUtc.Value.ToUniversalTime();
    }

    private sealed class SubscriptionHandle : IDisposable
    {
        private readonly AuthTokenProvider _provider;
        private readonly Guid _id;
        private int _disposed;

        public SubscriptionHandle(AuthTokenProvider provider, Guid id)
        {
            _provider = provider;
            _id = id;
        }

        public void Dispose()
        {
            if (Interlocked.Exchange(ref _disposed, 1) == 1)
                return;

            _provider._subscribers.TryRemove(_id, out _);
        }
    }
}

/// <summary>
/// 在 Token 到期前主动刷新，避免等到 401 才恢复。
/// </summary>
public sealed class TokenProactiveRefreshService : BackgroundService
{
    private static readonly TimeSpan CheckInterval = TimeSpan.FromMinutes(30);
    private static readonly TimeSpan RefreshBeforeExpiry = TimeSpan.FromHours(24);

    private readonly ILogger<TokenProactiveRefreshService> _logger;
    private readonly IAuthTokenProvider _authTokenProvider;

    public TokenProactiveRefreshService(
        ILogger<TokenProactiveRefreshService> logger,
        IAuthTokenProvider authTokenProvider)
    {
        _logger = logger;
        _authTokenProvider = authTokenProvider;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation(
            "Token proactive refresh started (check every {Minutes}m, refresh {Hours}h before expiry)",
            CheckInterval.TotalMinutes, RefreshBeforeExpiry.TotalHours);

        await Task.Delay(TimeSpan.FromMinutes(2), stoppingToken);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await TryRefreshIfNeededAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Proactive token refresh check failed");
            }

            await Task.Delay(CheckInterval, stoppingToken);
        }
    }

    private async Task TryRefreshIfNeededAsync(CancellationToken ct)
    {
        if (!_authTokenProvider.IsAuthenticated)
            return;

        var expiresAt = _authTokenProvider.GetTokenExpiresAtUtc();
        if (!expiresAt.HasValue)
            return;

        var remaining = expiresAt.Value - DateTime.UtcNow;
        if (remaining > RefreshBeforeExpiry)
            return;

        _logger.LogInformation("Token expires in {Hours:F1}h, refreshing proactively", remaining.TotalHours);

        var token = await _authTokenProvider.RefreshTokenAsync(ct);
        if (string.IsNullOrEmpty(token))
            _logger.LogWarning("Proactive token refresh failed");
        else
            _logger.LogInformation("Proactive token refresh succeeded");
    }
}
using System.Text;
using System.Text.Json;

namespace EnterpriseAgent.Agent.Security;

/// <summary>
/// Reads JWT exp claim without signature verification (expiry hint only).
/// </summary>
public static class JwtTokenExpiryParser
{
    public static DateTime? TryGetExpiryUtc(string? token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return null;

        var parts = token.Split('.');
        if (parts.Length != 3)
            return null;

        try
        {
            var payload = parts[1]
                .Replace('-', '+')
                .Replace('_', '/');
            var pad = payload.Length % 4;
            if (pad > 0)
                payload = payload.PadRight(payload.Length + (4 - pad), '=');

            var bytes = Convert.FromBase64String(payload);
            using var doc = JsonDocument.Parse(bytes);
            if (!doc.RootElement.TryGetProperty("exp", out var expElement))
                return null;

            if (expElement.ValueKind == JsonValueKind.Number && expElement.TryGetInt64(out var exp))
                return DateTimeOffset.FromUnixTimeSeconds(exp).UtcDateTime;

            return null;
        }
        catch
        {
            return null;
        }
    }
}

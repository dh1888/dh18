package services

import (
	"net/http"
	"strconv"
	"sync/atomic"
	"time"
)

// AppMetrics holds lightweight counters for /metrics exposition.
type AppMetrics struct {
	HTTPRequests             atomic.Int64
	HTTP5xx                  atomic.Int64
	UploadChunks             atomic.Int64
	UploadCompletes          atomic.Int64
	UploadFailures           atomic.Int64
	SessionRevokes           atomic.Int64
	WSAdminConns             atomic.Int64
	WSAgentConns             atomic.Int64
	WSDropsTotal             atomic.Int64
	WSDropsRevoke            atomic.Int64
	WSDropsGuard             atomic.Int64
	SessionValidationCount   atomic.Int64
	SessionValidationNanos   atomic.Int64
	DeploymentDriftDetected  atomic.Int64
	startedAt                time.Time
}

var GlobalMetrics = &AppMetrics{startedAt: time.Now().UTC()}

func (m *AppMetrics) ObserveHTTP(status int) {
	m.HTTPRequests.Add(1)
	if status >= 500 {
		m.HTTP5xx.Add(1)
	}
}

func (m *AppMetrics) ObserveSessionValidation(d time.Duration) {
	m.SessionValidationCount.Add(1)
	m.SessionValidationNanos.Add(d.Nanoseconds())
}

func (m *AppMetrics) ObserveWSDrop(reason string) {
	m.WSDropsTotal.Add(1)
	switch reason {
	case "revoke", "logout", "session_revoked", "user_logout":
		m.WSDropsRevoke.Add(1)
	case "guard", "session_invalid":
		m.WSDropsGuard.Add(1)
	}
}

func (m *AppMetrics) Handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain; version=0.0.4")
		uptime := int64(time.Since(m.startedAt).Seconds())
		writeMetric(w, "monitorwin_uptime_seconds", "Process uptime seconds", uptime)
		writeMetric(w, "monitorwin_http_requests_total", "Total HTTP requests", m.HTTPRequests.Load())
		writeMetric(w, "monitorwin_http_5xx_total", "Total HTTP 5xx responses", m.HTTP5xx.Load())
		writeMetric(w, "monitorwin_upload_chunks_total", "Upload chunks stored", m.UploadChunks.Load())
		writeMetric(w, "monitorwin_upload_complete_total", "Successful upload completions", m.UploadCompletes.Load())
		writeMetric(w, "monitorwin_upload_failures_total", "Failed upload completions", m.UploadFailures.Load())
		writeMetric(w, "monitorwin_upload_success_rate_percent", "Upload success rate percent", m.uploadSuccessRatePercent())
		writeMetric(w, "monitorwin_session_revokes_total", "Session revoke events handled", m.SessionRevokes.Load())
		writeMetric(w, "monitorwin_ws_admin_connections", "Current admin WS connections", m.WSAdminConns.Load())
		writeMetric(w, "monitorwin_ws_agent_connections", "Current agent WS connections", m.WSAgentConns.Load())
		writeMetric(w, "monitorwin_ws_connection_drops_total", "Total WS connections dropped", m.WSDropsTotal.Load())
		writeMetric(w, "monitorwin_ws_connection_drops_revoke_total", "WS drops due to session revoke", m.WSDropsRevoke.Load())
		writeMetric(w, "monitorwin_ws_connection_drops_guard_total", "WS drops due to session guard", m.WSDropsGuard.Load())
		writeMetric(w, "monitorwin_ws_connection_drop_rate_percent", "WS drop rate percent at scrape time", m.wsDropRatePercent())
		writeMetric(w, "monitorwin_session_validation_count_total", "Session validation calls", m.SessionValidationCount.Load())
		writeMetric(w, "monitorwin_session_validation_latency_ms_avg", "Average session validation latency ms", m.sessionValidationLatencyMsAvg())
		writeMetric(w, "monitorwin_deployment_drift_detected", "1 when cluster config drift detected", m.DeploymentDriftDetected.Load())
	})
}

func (m *AppMetrics) uploadSuccessRatePercent() int64 {
	completes := m.UploadCompletes.Load()
	failures := m.UploadFailures.Load()
	attempts := completes + failures
	if attempts == 0 {
		return 100
	}
	return completes * 100 / attempts
}

func (m *AppMetrics) wsDropRatePercent() int64 {
	drops := m.WSDropsTotal.Load()
	open := m.WSAdminConns.Load() + m.WSAgentConns.Load()
	denominator := drops + open
	if denominator == 0 {
		return 0
	}
	return drops * 100 / denominator
}

func (m *AppMetrics) sessionValidationLatencyMsAvg() int64 {
	count := m.SessionValidationCount.Load()
	if count == 0 {
		return 0
	}
	return m.SessionValidationNanos.Load() / count / int64(time.Millisecond)
}

func writeMetric(w http.ResponseWriter, name, help string, value int64) {
	_, _ = w.Write([]byte("# HELP " + name + " " + help + "\n"))
	_, _ = w.Write([]byte("# TYPE " + name + " counter\n"))
	_, _ = w.Write([]byte(name + " " + strconv.FormatInt(value, 10) + "\n"))
}

package services

import (
	"bytes"
	"context"
	"io"
	"os"
	"path/filepath"
	"testing"
)

func TestUploadChunkStoreLocalRoundTrip(t *testing.T) {
	t.Parallel()

	root := t.TempDir()
	client := &MinIOClient{
		bucket:  "test",
		enabled: true,
		rootDir: root,
	}
	store := NewUploadChunkStore(client)
	ctx := context.Background()
	uploadID := "550e8400-e29b-41d4-a716-446655440000"

	payload := []byte("hello-chunk-data")
	if err := store.Save(ctx, uploadID, 0, payload); err != nil {
		t.Fatalf("save chunk: %v", err)
	}
	if err := store.Save(ctx, uploadID, 1, []byte("part-two")); err != nil {
		t.Fatalf("save chunk 1: %v", err)
	}

	if count, err := store.CountChunks(ctx, uploadID, 2); err != nil || count != 2 {
		t.Fatalf("count chunks: count=%d err=%v", count, err)
	}

	merge := store.MergeReader(ctx, uploadID, 2)
	defer merge.Close()
	var buf bytes.Buffer
	if _, err := io.Copy(&buf, merge); err != nil {
		t.Fatalf("merge read: %v", err)
	}
	if buf.String() != "hello-chunk-datapart-two" {
		t.Fatalf("unexpected merged payload: %q", buf.String())
	}

	if err := store.DeleteAll(ctx, uploadID); err != nil {
		t.Fatalf("delete all: %v", err)
	}
	chunkDir := filepath.Join(root, "upload-chunks", uploadID)
	if _, err := os.Stat(chunkDir); !os.IsNotExist(err) {
		t.Fatalf("expected chunk dir removed, stat err=%v", err)
	}
}

func TestUploadChunkStoreChunkObjectName(t *testing.T) {
	t.Parallel()
	store := NewUploadChunkStore(&MinIOClient{enabled: true, rootDir: t.TempDir()})
	name := store.chunkObjectName("550e8400-e29b-41d4-a716-446655440000", 3)
	want := "upload-chunks/550e8400-e29b-41d4-a716-446655440000/chunk_00003"
	if name != want {
		t.Fatalf("got %q want %q", name, want)
	}
}

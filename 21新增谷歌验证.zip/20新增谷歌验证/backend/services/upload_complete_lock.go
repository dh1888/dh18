package services

import (
	"context"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
)

const (
	uploadCompleteLockPrefix = "upload:complete:lock:"
	uploadCompleteLockTTL    = 15 * time.Minute
)

// UploadCompleteLock provides cross-instance mutual exclusion for upload completion.
type UploadCompleteLock struct {
	redis *redis.Client
}

func NewUploadCompleteLock(redisClient *redis.Client) *UploadCompleteLock {
	if redisClient == nil {
		return nil
	}
	return &UploadCompleteLock{redis: redisClient}
}

func (l *UploadCompleteLock) lockKey(uploadID string) string {
	return uploadCompleteLockPrefix + uploadID
}

// Acquire tries to claim the upload completion lock. release must be called when done.
func (l *UploadCompleteLock) Acquire(ctx context.Context, uploadID string) (release func(), ok bool, err error) {
	if l == nil || l.redis == nil {
		if IsProductionEnv() {
			return func() {}, false, fmt.Errorf("upload complete lock unavailable")
		}
		return func() {}, true, nil
	}
	if uploadID == "" {
		return func() {}, false, fmt.Errorf("upload id required")
	}
	token := uuid.NewString()
	key := l.lockKey(uploadID)
	acquired, err := l.redis.SetNX(ctx, key, token, uploadCompleteLockTTL).Result()
	if err != nil {
		return func() {}, false, err
	}
	if !acquired {
		return func() {}, false, nil
	}
	releaseFn := func() {
		relCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		_ = l.release(relCtx, key, token)
	}
	return releaseFn, true, nil
}

func (l *UploadCompleteLock) release(ctx context.Context, key, token string) error {
	const script = `
if redis.call("GET", KEYS[1]) == ARGV[1] then
  return redis.call("DEL", KEYS[1])
end
return 0`
	return l.redis.Eval(ctx, script, []string{key}, token).Err()
}

// Extend refreshes lock TTL during long merges.
func (l *UploadCompleteLock) Extend(ctx context.Context, uploadID string) error {
	if l == nil || l.redis == nil || uploadID == "" {
		return nil
	}
	return l.redis.Expire(ctx, l.lockKey(uploadID), uploadCompleteLockTTL).Err()
}

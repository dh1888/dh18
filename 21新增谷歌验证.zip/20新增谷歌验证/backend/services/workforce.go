package services

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
)

var (
	ErrInviteNotFound        = errors.New("invite code not found")
	ErrInviteExpired         = errors.New("invite code expired")
	ErrInviteUsed            = errors.New("invite code already used")
	ErrInviteRevoked         = errors.New("invite code revoked")
	ErrEmployeeBound         = errors.New("employee already has a bound device")
	ErrEmployeeOnOtherDevice = errors.New("employee active on another device")
	ErrNoOpenSession         = errors.New("no open work session")
	ErrSessionExists         = errors.New("work session already open")
	ErrEmployeeNotFound      = errors.New("employee not found")
	ErrInvalidCredentials    = errors.New("invalid credentials")
	ErrNotEmployeeRole       = errors.New("not an employee account")
)

const defaultInviteValidDays = 7

// WorkforceService HR + invite + attendance orchestration.
type WorkforceService struct {
	db *sql.DB
}

func NewWorkforceService(db *sql.DB) *WorkforceService {
	return &WorkforceService{db: db}
}

type CreateEmployeeAccountInput struct {
	Username     string
	Password     string
	EmployeeID   string
	Name         string
	Position     string
	Department   string
	HireDate     string
	WorkLocation string
	CreatedBy    uuid.UUID
}

type CreateEmployeeAccountResult struct {
	UserID     uuid.UUID
	EmployeeID uuid.UUID
	InviteCode string
	InviteID   uuid.UUID
}

func (s *WorkforceService) CreateEmployeeAccount(ctx context.Context, in *CreateEmployeeAccountInput) (*CreateEmployeeAccountResult, error) {
	if s.db == nil {
		return nil, fmt.Errorf("database not initialized")
	}
	username := strings.TrimSpace(in.Username)
	if username == "" || strings.TrimSpace(in.Password) == "" || strings.TrimSpace(in.Name) == "" {
		return nil, fmt.Errorf("username, password and name are required")
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(in.Password), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	var userID uuid.UUID
	err = tx.QueryRowContext(ctx, `
		INSERT INTO users (id, username, password_hash, email, real_name, status, created_at)
		VALUES (gen_random_uuid(), $1, $2, '', $3, 1, NOW())
		RETURNING id`,
		username, string(hash), in.Name,
	).Scan(&userID)
	if err != nil {
		return nil, fmt.Errorf("create user: %w", err)
	}

	var employeeRoleID uuid.UUID
	err = tx.QueryRowContext(ctx, `SELECT id FROM roles WHERE name = '员工' LIMIT 1`).Scan(&employeeRoleID)
	if err != nil {
		return nil, fmt.Errorf("employee role not found: %w", err)
	}
	if _, err = tx.ExecContext(ctx, `INSERT INTO user_roles (user_id, role_id, created_at) VALUES ($1, $2, NOW())`, userID, employeeRoleID); err != nil {
		return nil, err
	}

	empUUID := uuid.New()
	var hireDate interface{}
	if strings.TrimSpace(in.HireDate) != "" {
		hireDate = in.HireDate
	}
	if _, err = tx.ExecContext(ctx, `
		INSERT INTO employees (id, employee_id, name, position, department, hire_date, work_location, user_id, status, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 1, NOW())`,
		empUUID, nullString(strings.TrimSpace(in.EmployeeID)), in.Name, nullString(in.Position),
		nullString(in.Department), hireDate, nullString(in.WorkLocation), userID,
	); err != nil {
		return nil, err
	}

	currentMonth := time.Now().Format("2006-01")
	if _, err = tx.ExecContext(ctx, `
		INSERT INTO performance_records (employee_id, employee_name, position, score_records, total_score, grade, month, created_at, updated_at)
		VALUES ($1, $2, $3, '[]'::jsonb, 10, '合格', $4, NOW(), NOW())
		ON CONFLICT (employee_id, month) DO NOTHING`,
		empUUID, in.Name, in.Position, currentMonth,
	); err != nil {
		return nil, err
	}

	if err = s.ensureTodayAttendanceTx(ctx, tx, empUUID, in.Position); err != nil {
		return nil, err
	}

	code, inviteID, err := s.createInviteCodeTx(ctx, tx, empUUID, in.CreatedBy, defaultInviteValidDays)
	if err != nil {
		return nil, err
	}

	if err = tx.Commit(); err != nil {
		return nil, err
	}

	return &CreateEmployeeAccountResult{
		UserID:     userID,
		EmployeeID: empUUID,
		InviteCode: code,
		InviteID:   inviteID,
	}, nil
}

func (s *WorkforceService) ensureTodayAttendanceTx(ctx context.Context, tx *sql.Tx, employeeID uuid.UUID, position string) error {
	today := time.Now().Format("2006-01-02")
	yearMonth := time.Now().Format("2006-01")
	_, err := tx.ExecContext(ctx, `
		INSERT INTO attendance_records (employee_id, year_month, date, status, position_snapshot, created_at, updated_at)
		VALUES ($1, $2, $3, 'pending', $4, NOW(), NOW())
		ON CONFLICT (employee_id, year_month, date) DO NOTHING`,
		employeeID, yearMonth, today, nullString(position),
	)
	return err
}

func (s *WorkforceService) EnsureTodayAttendance(ctx context.Context, employeeID uuid.UUID, position string) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if err = s.ensureTodayAttendanceTx(ctx, tx, employeeID, position); err != nil {
		return err
	}
	return tx.Commit()
}

func (s *WorkforceService) SeedDailyAttendance(ctx context.Context) (int64, error) {
	res, err := s.db.ExecContext(ctx, `
		INSERT INTO attendance_records (employee_id, year_month, date, status, position_snapshot, created_at, updated_at)
		SELECT e.id, to_char(CURRENT_DATE, 'YYYY-MM'), CURRENT_DATE, 'pending', e.position, NOW(), NOW()
		FROM employees e
		WHERE e.status = 1
		ON CONFLICT (employee_id, year_month, date) DO NOTHING`)
	if err != nil {
		return 0, err
	}
	return res.RowsAffected()
}

func generateInviteCodeString() (string, error) {
	b := make([]byte, 5)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	raw := strings.ToUpper(hex.EncodeToString(b))
	return fmt.Sprintf("%s-%s", raw[:4], raw[4:]), nil
}

func (s *WorkforceService) createInviteCodeTx(ctx context.Context, tx *sql.Tx, employeeID, createdBy uuid.UUID, validDays int) (string, uuid.UUID, error) {
	if _, err := tx.ExecContext(ctx, `
		UPDATE device_invite_codes SET revoked_at = NOW(), superseded_at = NOW()
		WHERE employee_id = $1 AND used_at IS NULL AND revoked_at IS NULL AND expires_at > NOW()`,
		employeeID); err != nil {
		return "", uuid.Nil, err
	}

	code, err := generateInviteCodeString()
	if err != nil {
		return "", uuid.Nil, err
	}
	id := uuid.New()
	expires := time.Now().Add(time.Duration(validDays) * 24 * time.Hour)
	if err = tx.QueryRowContext(ctx, `
		INSERT INTO device_invite_codes (id, code, employee_id, created_by, expires_at, created_at)
		VALUES ($1, $2, $3, $4, $5, NOW()) RETURNING id`,
		id, code, employeeID, nullUUID(createdBy), expires,
	).Scan(&id); err != nil {
		return "", uuid.Nil, err
	}
	return code, id, nil
}

func nullUUID(id uuid.UUID) interface{} {
	if id == uuid.Nil {
		return nil
	}
	return id
}

type InviteCodeRow struct {
	ID           uuid.UUID
	Code         string
	EmployeeID   uuid.UUID
	EmployeeName string
	ExpiresAt    time.Time
	UsedAt       *time.Time
	RevokedAt    *time.Time
	CreatedAt    time.Time
	DeviceID     *uuid.UUID
}

func (s *WorkforceService) ListInviteCodes(ctx context.Context, employeeID *uuid.UUID) ([]InviteCodeRow, error) {
	query := `
		SELECT ic.id, ic.code, ic.employee_id, COALESCE(e.name,''), ic.expires_at, ic.used_at, ic.revoked_at, ic.created_at, ic.used_by_device_id
		FROM device_invite_codes ic
		JOIN employees e ON e.id = ic.employee_id`
	args := []interface{}{}
	if employeeID != nil {
		query += ` WHERE ic.employee_id = $1`
		args = append(args, *employeeID)
	}
	query += ` ORDER BY ic.created_at DESC LIMIT 200`

	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []InviteCodeRow
	for rows.Next() {
		var row InviteCodeRow
		var usedAt, revokedAt sql.NullTime
		var deviceID sql.NullString
		if err := rows.Scan(&row.ID, &row.Code, &row.EmployeeID, &row.EmployeeName, &row.ExpiresAt, &usedAt, &revokedAt, &row.CreatedAt, &deviceID); err != nil {
			continue
		}
		if usedAt.Valid {
			row.UsedAt = &usedAt.Time
		}
		if revokedAt.Valid {
			row.RevokedAt = &revokedAt.Time
		}
		if deviceID.Valid {
			if did, err := uuid.Parse(deviceID.String); err == nil {
				row.DeviceID = &did
			}
		}
		list = append(list, row)
	}
	return list, nil
}

func inviteStatus(row InviteCodeRow, now time.Time) string {
	if row.RevokedAt != nil {
		return "revoked"
	}
	if row.UsedAt != nil {
		return "used"
	}
	if now.After(row.ExpiresAt) {
		return "expired"
	}
	return "active"
}

func (s *WorkforceService) RevokeInviteCode(ctx context.Context, inviteID uuid.UUID) error {
	res, err := s.db.ExecContext(ctx, `
		UPDATE device_invite_codes SET revoked_at = NOW()
		WHERE id = $1 AND used_at IS NULL AND revoked_at IS NULL`, inviteID)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return ErrInviteNotFound
	}
	return nil
}

func (s *WorkforceService) RegenerateInviteCode(ctx context.Context, employeeID, createdBy uuid.UUID) (string, uuid.UUID, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return "", uuid.Nil, err
	}
	defer tx.Rollback()

	code, id, err := s.createInviteCodeTx(ctx, tx, employeeID, createdBy, defaultInviteValidDays)
	if err != nil {
		return "", uuid.Nil, err
	}
	if err = tx.Commit(); err != nil {
		return "", uuid.Nil, err
	}
	return code, id, nil
}

type InviteValidationResult struct {
	EmployeeID     uuid.UUID
	EmployeeName   string
	EmployeeNumber string
	Position       string
	Department     string
	InviteID       uuid.UUID
	UserID         *uuid.UUID
}

func (s *WorkforceService) ValidateInviteCode(ctx context.Context, code string) (*InviteValidationResult, error) {
	code = strings.TrimSpace(strings.ToUpper(code))
	var row InviteValidationResult
	var usedAt, revokedAt sql.NullTime
	var expiresAt time.Time
	var userID sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT ic.id, ic.employee_id, e.name, COALESCE(e.employee_id,''), COALESCE(e.position,''), COALESCE(e.department,''),
			ic.expires_at, ic.used_at, ic.revoked_at, e.user_id::text
		FROM device_invite_codes ic
		JOIN employees e ON e.id = ic.employee_id
		WHERE ic.code = $1`, code,
	).Scan(&row.InviteID, &row.EmployeeID, &row.EmployeeName, &row.EmployeeNumber, &row.Position, &row.Department,
		&expiresAt, &usedAt, &revokedAt, &userID)
	if err == sql.ErrNoRows {
		return nil, ErrInviteNotFound
	}
	if err != nil {
		return nil, err
	}
	if revokedAt.Valid {
		return nil, ErrInviteRevoked
	}
	if usedAt.Valid {
		return nil, ErrInviteUsed
	}
	if time.Now().After(expiresAt) {
		return nil, ErrInviteExpired
	}
	if userID.Valid {
		if uid, err := uuid.Parse(userID.String); err == nil {
			row.UserID = &uid
		}
	}
	return &row, nil
}

func (s *WorkforceService) ConsumeInviteCode(ctx context.Context, inviteID, deviceID uuid.UUID) error {
	res, err := s.db.ExecContext(ctx, `
		UPDATE device_invite_codes SET used_at = NOW(), used_by_device_id = $2
		WHERE id = $1 AND used_at IS NULL AND revoked_at IS NULL AND expires_at > NOW()`,
		inviteID, deviceID)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return ErrInviteUsed
	}
	return nil
}

func (s *WorkforceService) EmployeeBoundToOtherDevice(ctx context.Context, employeeID, currentDeviceID uuid.UUID) (bool, error) {
	var otherID uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM devices
		WHERE employee_uuid = $1 AND id != $2 AND status IN ('pending', 'approved')
		LIMIT 1`, employeeID, currentDeviceID).Scan(&otherID)
	if err == sql.ErrNoRows {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return otherID != uuid.Nil, nil
}

func (s *WorkforceService) EmployeeHasBoundDevice(ctx context.Context, employeeID uuid.UUID) (bool, error) {
	var count int
	err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM devices
		WHERE employee_uuid = $1 AND status IN ('pending', 'approved')`, employeeID).Scan(&count)
	return count > 0, err
}

func (s *WorkforceService) ClearDeviceEmployee(ctx context.Context, deviceID uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `
		UPDATE devices SET employee_uuid = NULL, user_id = NULL, employee_id = NULL,
			employee_name = NULL, employee_number = NULL, position = NULL
		WHERE id = $1`, deviceID)
	return err
}

type EmployeeLoginResult struct {
	EmployeeID     uuid.UUID
	EmployeeName   string
	EmployeeNumber string
	Position       string
	Username       string
}

func (s *WorkforceService) EmployeeLogin(ctx context.Context, deviceID uuid.UUID, username, password string) (*EmployeeLoginResult, error) {
	username = strings.TrimSpace(username)
	if username == "" || password == "" {
		return nil, ErrInvalidCredentials
	}

	var userID uuid.UUID
	var passwordHash string
	var status int
	var roleName string
	err := s.db.QueryRowContext(ctx, `
		SELECT u.id, u.password_hash, u.status,
			COALESCE((SELECT r.name FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = u.id LIMIT 1), '')
		FROM users u WHERE u.username = $1`, username).Scan(&userID, &passwordHash, &status, &roleName)
	if err == sql.ErrNoRows {
		return nil, ErrInvalidCredentials
	}
	if err != nil {
		return nil, err
	}
	if status != 1 {
		return nil, ErrInvalidCredentials
	}
	roleNorm := strings.ToLower(strings.TrimSpace(roleName))
	if roleNorm != "员工" && roleNorm != "employee" {
		return nil, ErrNotEmployeeRole
	}
	if bcrypt.CompareHashAndPassword([]byte(passwordHash), []byte(password)) != nil {
		return nil, ErrInvalidCredentials
	}

	empID, err := s.ResolveEmployeeByUserID(ctx, userID)
	if err != nil {
		return nil, err
	}

	boundElsewhere, err := s.EmployeeBoundToOtherDevice(ctx, empID, deviceID)
	if err != nil {
		return nil, err
	}
	if boundElsewhere {
		return nil, ErrEmployeeOnOtherDevice
	}

	var name, empNumber, position string
	_ = s.db.QueryRowContext(ctx, `
		SELECT name, COALESCE(employee_id,''), COALESCE(position,'') FROM employees WHERE id = $1`, empID).
		Scan(&name, &empNumber, &position)

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	// 共享电脑：切换账号前关闭本机 open session
	_, _ = tx.ExecContext(ctx, `
		UPDATE work_sessions SET status = 'closed', checkout_time = NOW(), updated_at = NOW()
		WHERE device_id = $1 AND status = 'open'`, deviceID)

	if err = s.bindDeviceToEmployeeTx(ctx, tx, deviceID, empID, empNumber, name, position, &userID); err != nil {
		return nil, err
	}

	if err = s.ensureTodayAttendanceTx(ctx, tx, empID, position); err != nil {
		return nil, err
	}

	_, _ = tx.ExecContext(ctx, `UPDATE users SET last_login_at = NOW() WHERE id = $1`, userID)

	if err = tx.Commit(); err != nil {
		return nil, err
	}

	return &EmployeeLoginResult{
		EmployeeID: empID, EmployeeName: name, EmployeeNumber: empNumber,
		Position: position, Username: username,
	}, nil
}

func (s *WorkforceService) bindDeviceToEmployeeTx(ctx context.Context, tx *sql.Tx, deviceID, employeeID uuid.UUID, empNumber, name, position string, userID *uuid.UUID) error {
	var uid interface{}
	if userID != nil {
		uid = *userID
	}
	_, err := tx.ExecContext(ctx, `
		UPDATE devices SET
			employee_uuid = $1, user_id = $2, employee_id = $3, employee_name = $4,
			employee_number = $5, position = $6, status = 'approved',
			bound_at = COALESCE(bound_at, NOW())
		WHERE id = $7`,
		employeeID, uid, empNumber, name, empNumber, position, deviceID)
	return err
}

func (s *WorkforceService) EmployeeLogout(ctx context.Context, deviceID uuid.UUID) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	_, _ = tx.ExecContext(ctx, `
		UPDATE work_sessions SET status = 'closed', checkout_time = NOW(), updated_at = NOW()
		WHERE device_id = $1 AND status = 'open'`, deviceID)

	_, err = tx.ExecContext(ctx, `
		UPDATE devices SET employee_uuid = NULL, user_id = NULL, employee_id = NULL,
			employee_name = NULL, employee_number = NULL, position = NULL
		WHERE id = $1`, deviceID)
	if err != nil {
		return err
	}
	return tx.Commit()
}

func (s *WorkforceService) BindDeviceToEmployee(ctx context.Context, deviceID, employeeID uuid.UUID, empNumber, name, position string, userID *uuid.UUID) error {
	var uid interface{}
	if userID != nil {
		uid = *userID
	}
	_, err := s.db.ExecContext(ctx, `
		UPDATE devices SET
			employee_uuid = $1,
			user_id = $2,
			employee_id = $3,
			employee_name = $4,
			employee_number = $5,
			position = $6,
			status = 'approved',
			bound_at = COALESCE(bound_at, NOW())
		WHERE id = $7`,
		employeeID, uid, empNumber, name, empNumber, position, deviceID)
	return err
}

func (s *WorkforceService) ResolveEmployeeByUserID(ctx context.Context, userID uuid.UUID) (uuid.UUID, error) {
	var empID uuid.UUID
	err := s.db.QueryRowContext(ctx, `SELECT id FROM employees WHERE user_id = $1 AND status = 1`, userID).Scan(&empID)
	if err == sql.ErrNoRows {
		return uuid.Nil, ErrEmployeeNotFound
	}
	return empID, err
}

func (s *WorkforceService) ResolveEmployeeByDeviceID(ctx context.Context, deviceID uuid.UUID) (uuid.UUID, error) {
	var empID uuid.UUID
	err := s.db.QueryRowContext(ctx, `SELECT employee_uuid FROM devices WHERE id = $1`, deviceID).Scan(&empID)
	if err != nil || empID == uuid.Nil {
		return uuid.Nil, ErrEmployeeNotFound
	}
	return empID, err
}

type CheckInResult struct {
	SessionID uuid.UUID
	Date      string
}

func (s *WorkforceService) CheckIn(ctx context.Context, deviceID uuid.UUID) (*CheckInResult, error) {
	empID, err := s.ResolveEmployeeByDeviceID(ctx, deviceID)
	if err != nil {
		return nil, err
	}

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	var openCount int
	if err = tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM work_sessions WHERE employee_id = $1 AND status = 'open'`, empID).Scan(&openCount); err != nil {
		return nil, err
	}
	if openCount > 0 {
		return nil, ErrSessionExists
	}

	today := time.Now().Format("2006-01-02")
	yearMonth := time.Now().Format("2006-01")
	var position string
	_ = tx.QueryRowContext(ctx, `SELECT COALESCE(position,'') FROM employees WHERE id = $1`, empID).Scan(&position)

	_, err = tx.ExecContext(ctx, `
		INSERT INTO attendance_records (employee_id, year_month, date, status, position_snapshot, checkin_time, created_at, updated_at)
		VALUES ($1, $2, $3, 'working', $4, NOW(), NOW(), NOW())
		ON CONFLICT (employee_id, year_month, date) DO UPDATE SET
			status = CASE WHEN attendance_records.status IN ('leave','absent','rest_full','rest_half','off_post','resigned')
				THEN attendance_records.status ELSE 'working' END,
			checkin_time = COALESCE(attendance_records.checkin_time, NOW()),
			position_snapshot = COALESCE(attendance_records.position_snapshot, EXCLUDED.position_snapshot),
			updated_at = NOW()`,
		empID, yearMonth, today, position)
	if err != nil {
		return nil, err
	}

	sessionID := uuid.New()
	if _, err = tx.ExecContext(ctx, `
		INSERT INTO work_sessions (id, employee_id, attendance_date, device_id, checkin_time, status, created_at, updated_at)
		VALUES ($1, $2, $3, $4, NOW(), 'open', NOW(), NOW())`,
		sessionID, empID, today, deviceID); err != nil {
		return nil, err
	}

	if err = tx.Commit(); err != nil {
		return nil, err
	}
	return &CheckInResult{SessionID: sessionID, Date: today}, nil
}

type CheckOutResult struct {
	SessionID uuid.UUID
}

func (s *WorkforceService) CheckOut(ctx context.Context, deviceID uuid.UUID, sessionID *uuid.UUID) (*CheckOutResult, error) {
	empID, err := s.ResolveEmployeeByDeviceID(ctx, deviceID)
	if err != nil {
		return nil, err
	}

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	var sid uuid.UUID
	if sessionID != nil && *sessionID != uuid.Nil {
		sid = *sessionID
	} else {
		err = tx.QueryRowContext(ctx, `
			SELECT id FROM work_sessions WHERE employee_id = $1 AND device_id = $2 AND status = 'open'
			ORDER BY checkin_time DESC LIMIT 1`, empID, deviceID).Scan(&sid)
		if err == sql.ErrNoRows {
			return nil, ErrNoOpenSession
		}
		if err != nil {
			return nil, err
		}
	}

	today := time.Now().Format("2006-01-02")
	yearMonth := time.Now().Format("2006-01")

	if _, err = tx.ExecContext(ctx, `
		UPDATE work_sessions SET status = 'closed', checkout_time = NOW(), updated_at = NOW()
		WHERE id = $1 AND status = 'open'`, sid); err != nil {
		return nil, err
	}

	_, err = tx.ExecContext(ctx, `
		UPDATE attendance_records SET
			status = CASE WHEN status IN ('leave','absent','rest_full','rest_half','off_post','resigned') THEN status ELSE 'work' END,
			checkout_time = NOW(),
			updated_at = NOW()
		WHERE employee_id = $1 AND year_month = $2 AND date = $3`,
		empID, yearMonth, today)
	if err != nil {
		return nil, err
	}

	if err = tx.Commit(); err != nil {
		return nil, err
	}
	return &CheckOutResult{SessionID: sid}, nil
}

func (s *WorkforceService) DisableEmployee(ctx context.Context, employeeID uuid.UUID) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	var userID sql.NullString
	_ = tx.QueryRowContext(ctx, `SELECT user_id::text FROM employees WHERE id = $1`, employeeID).Scan(&userID)

	if _, err = tx.ExecContext(ctx, `UPDATE employees SET status = 0, updated_at = NOW() WHERE id = $1`, employeeID); err != nil {
		return err
	}
	if userID.Valid {
		if _, err = tx.ExecContext(ctx, `UPDATE users SET status = 0, updated_at = NOW() WHERE id = $1`, userID.String); err != nil {
			return err
		}
	}
	if _, err = tx.ExecContext(ctx, `
		UPDATE device_invite_codes SET revoked_at = NOW()
		WHERE employee_id = $1 AND used_at IS NULL AND revoked_at IS NULL`, employeeID); err != nil {
		return err
	}
	if _, err = tx.ExecContext(ctx, `
		UPDATE devices SET employee_uuid = NULL, user_id = NULL, employee_id = NULL, employee_name = NULL, employee_number = NULL, position = NULL, bound_at = NULL
		WHERE employee_uuid = $1`, employeeID); err != nil {
		return err
	}
	return tx.Commit()
}

// StartAttendanceScheduler runs daily attendance seed at local midnight + offset.
func StartAttendanceScheduler(ctx context.Context, svc *WorkforceService) {
	if svc == nil || svc.db == nil {
		return
	}
	go func() {
		for {
			now := time.Now()
			next := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 5, 0, 0, now.Location())
			timer := time.NewTimer(time.Until(next))
			select {
			case <-ctx.Done():
				timer.Stop()
				return
			case <-timer.C:
				n, err := svc.SeedDailyAttendance(context.Background())
				if err != nil {
					fmt.Printf("[Workforce] daily attendance seed error: %v\n", err)
				} else {
					fmt.Printf("[Workforce] daily attendance seeded %d rows\n", n)
				}
			}
		}
	}()
}

// InviteStatusLabel exported for handlers.
func InviteStatusLabel(row InviteCodeRow) string {
	return inviteStatus(row, time.Now())
}

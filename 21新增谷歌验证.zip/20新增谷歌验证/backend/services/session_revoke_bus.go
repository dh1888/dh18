package services

import (
	"context"
	"encoding/json"
	"log"
	"time"

	"github.com/redis/go-redis/v9"
)

const sessionRevokeChannel = "session:revoke:v1"

// SessionRevokeEvent is published when a session becomes invalid.
type SessionRevokeEvent struct {
	SessionID string `json:"sessionId"`
	Reason    string `json:"reason"`
}

func (s *SessionService) publishSessionRevoke(ctx context.Context, sessionID, reason string) {
	if s == nil || s.redis == nil || sessionID == "" {
		return
	}
	payload, err := json.Marshal(SessionRevokeEvent{
		SessionID: sessionID,
		Reason:    reason,
	})
	if err != nil {
		return
	}
	pubCtx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	if err := s.redis.Publish(pubCtx, sessionRevokeChannel, payload).Err(); err != nil {
		log.Printf("[SessionRevoke] publish failed session=%s: %v", sessionID, err)
	}
}

// StartSessionRevokeListener subscribes to cross-instance session revoke events.
func StartSessionRevokeListener(ctx context.Context, redisClient *redis.Client, onRevoke func(event SessionRevokeEvent)) {
	if redisClient == nil || onRevoke == nil {
		return
	}
	go func() {
		sub := redisClient.Subscribe(ctx, sessionRevokeChannel)
		defer sub.Close()
		log.Printf("[SessionRevoke] listening on %s", sessionRevokeChannel)
		for {
			msg, err := sub.ReceiveMessage(ctx)
			if err != nil {
				if ctx.Err() != nil {
					return
				}
				log.Printf("[SessionRevoke] subscribe error: %v", err)
				time.Sleep(time.Second)
				continue
			}
			var event SessionRevokeEvent
			if err := json.Unmarshal([]byte(msg.Payload), &event); err != nil {
				continue
			}
			if event.SessionID == "" {
				continue
			}
			onRevoke(event)
		}
	}()
}

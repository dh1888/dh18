package services

import (
	"context"
	"encoding/json"
	"fmt"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

const (
	uploadManifestPrefix     = "upload:manifest:"
	uploadManifestPartsSuffix = ":parts"
	uploadManifestTTL        = time.Hour
)

// UploadManifest is the cross-instance source of truth for received chunks.
type UploadManifest struct {
	UploadID    string    `json:"uploadId"`
	DeviceID    string    `json:"deviceId"`
	FileName    string    `json:"fileName"`
	FileType    string    `json:"fileType"`
	FileID      string    `json:"fileId,omitempty"`
	TotalChunks int       `json:"totalChunks"`
	TotalSize   int64     `json:"totalSize"`
	UpdatedAt   time.Time `json:"updatedAt"`
}

// UploadManifestStore tracks chunk receipt in Redis and mirrors manifest.json to object storage.
type UploadManifestStore struct {
	redis      *redis.Client
	chunkStore *UploadChunkStore
}

func NewUploadManifestStore(redisClient *redis.Client, chunks *UploadChunkStore) *UploadManifestStore {
	if redisClient == nil {
		return nil
	}
	return &UploadManifestStore{redis: redisClient, chunkStore: chunks}
}

func (s *UploadManifestStore) metaKey(uploadID string) string {
	return uploadManifestPrefix + uploadID
}

func (s *UploadManifestStore) partsKey(uploadID string) string {
	return uploadManifestPrefix + uploadID + uploadManifestPartsSuffix
}

func (s *UploadManifestStore) manifestObjectName(uploadID string) string {
	return filepath.ToSlash(filepath.Join(uploadChunkRoot, uploadID, "manifest.json"))
}

// Init creates or refreshes manifest metadata for an upload.
func (s *UploadManifestStore) Init(ctx context.Context, m UploadManifest) error {
	if s == nil || s.redis == nil {
		return fmt.Errorf("upload manifest store unavailable")
	}
	if m.UploadID == "" || m.DeviceID == "" || m.TotalChunks <= 0 {
		return fmt.Errorf("invalid upload manifest")
	}
	m.UpdatedAt = time.Now().UTC()
	payload, err := json.Marshal(m)
	if err != nil {
		return err
	}

	metaKey := s.metaKey(m.UploadID)
	ok, err := s.redis.SetNX(ctx, metaKey, payload, uploadManifestTTL).Result()
	if err != nil {
		return err
	}
	if !ok {
		raw, getErr := s.redis.Get(ctx, metaKey).Bytes()
		if getErr != nil {
			return getErr
		}
		var existing UploadManifest
		if err := json.Unmarshal(raw, &existing); err != nil {
			return err
		}
		if !stringsEqualFold(existing.DeviceID, m.DeviceID) {
			return fmt.Errorf("upload manifest device mismatch")
		}
		pipe := s.redis.TxPipeline()
		pipe.Expire(ctx, metaKey, uploadManifestTTL)
		pipe.Expire(ctx, s.partsKey(m.UploadID), uploadManifestTTL)
		if _, err := pipe.Exec(ctx); err != nil {
			return err
		}
		return s.persistObjectManifest(ctx, m.UploadID)
	}

	pipe := s.redis.TxPipeline()
	pipe.Expire(ctx, s.partsKey(m.UploadID), uploadManifestTTL)
	if _, err := pipe.Exec(ctx); err != nil {
		return err
	}
	return s.persistObjectManifest(ctx, m.UploadID)
}

// RecordChunk marks a chunk as stored and returns received count.
func (s *UploadManifestStore) RecordChunk(ctx context.Context, uploadID string, chunkIndex int, chunkSize int64, checksum string) (int, error) {
	if s == nil || s.redis == nil {
		return 0, fmt.Errorf("upload manifest store unavailable")
	}
	part := strconv.Itoa(chunkIndex)
	pipe := s.redis.TxPipeline()
	pipe.SAdd(ctx, s.partsKey(uploadID), part)
	if checksum != "" {
		pipe.HSet(ctx, s.metaKey(uploadID)+":checksums", part, checksum)
	}
	if chunkSize > 0 {
		pipe.HIncrBy(ctx, s.metaKey(uploadID)+":meta", "totalSize", chunkSize)
	}
	pipe.Expire(ctx, s.partsKey(uploadID), uploadManifestTTL)
	pipe.Expire(ctx, s.metaKey(uploadID)+":checksums", uploadManifestTTL)
	pipe.Expire(ctx, s.metaKey(uploadID)+":meta", uploadManifestTTL)
	if _, err := pipe.Exec(ctx); err != nil {
		return 0, err
	}
	count, err := s.redis.SCard(ctx, s.partsKey(uploadID)).Result()
	if err != nil {
		return 0, err
	}
	return int(count), s.persistObjectManifest(ctx, uploadID)
}

// Verify ensures manifest ownership, chunk completeness, index continuity, and checksums.
func (s *UploadManifestStore) Verify(ctx context.Context, uploadID, deviceID string, totalChunks int, chunkChecksums map[int]string) (*UploadManifest, error) {
	if s == nil || s.redis == nil {
		return nil, fmt.Errorf("upload manifest store unavailable")
	}
	raw, err := s.redis.Get(ctx, s.metaKey(uploadID)).Bytes()
	if err != nil {
		if err == redis.Nil {
			return nil, fmt.Errorf("upload manifest not found")
		}
		return nil, err
	}
	var manifest UploadManifest
	if err := json.Unmarshal(raw, &manifest); err != nil {
		return nil, err
	}
	if !stringsEqualFold(manifest.DeviceID, deviceID) {
		return nil, fmt.Errorf("upload manifest device mismatch")
	}
	if manifest.TotalChunks != totalChunks {
		return nil, fmt.Errorf("upload manifest total chunks mismatch")
	}

	parts, err := s.redis.SMembers(ctx, s.partsKey(uploadID)).Result()
	if err != nil {
		return nil, err
	}
	if len(parts) != totalChunks {
		return nil, fmt.Errorf("upload manifest missing chunks: expected %d got %d", totalChunks, len(parts))
	}

	seen := make(map[int]bool, totalChunks)
	for _, part := range parts {
		idx, convErr := strconv.Atoi(part)
		if convErr != nil || idx < 0 || idx >= totalChunks {
			return nil, fmt.Errorf("upload manifest invalid chunk index: %q", part)
		}
		if seen[idx] {
			return nil, fmt.Errorf("upload manifest duplicate chunk index: %d", idx)
		}
		seen[idx] = true
	}
	for i := 0; i < totalChunks; i++ {
		if !seen[i] {
			return nil, fmt.Errorf("upload manifest missing chunk index: %d", i)
		}
	}

	if len(chunkChecksums) > 0 {
		stored, err := s.redis.HGetAll(ctx, s.metaKey(uploadID)+":checksums").Result()
		if err != nil {
			return nil, err
		}
		for i := 0; i < totalChunks; i++ {
			expected := chunkChecksums[i]
			if expected == "" {
				continue
			}
			got := stored[strconv.Itoa(i)]
			if got == "" {
				return nil, fmt.Errorf("upload manifest missing checksum for chunk %d", i)
			}
			if got != expected {
				return nil, fmt.Errorf("upload manifest checksum mismatch for chunk %d", i)
			}
		}
	}

	return &manifest, nil
}

// Delete removes manifest keys and object storage manifest snapshot.
func (s *UploadManifestStore) Delete(ctx context.Context, uploadID string) error {
	if s == nil || s.redis == nil {
		return nil
	}
	pipe := s.redis.TxPipeline()
	pipe.Del(ctx, s.metaKey(uploadID))
	pipe.Del(ctx, s.partsKey(uploadID))
	pipe.Del(ctx, s.metaKey(uploadID)+":checksums")
	pipe.Del(ctx, s.metaKey(uploadID)+":meta")
	_, err := pipe.Exec(ctx)
	if s.chunkStore != nil && s.chunkStore.minio != nil {
		_ = s.chunkStore.minio.RemoveObject(ctx, s.manifestObjectName(uploadID))
	}
	return err
}

func (s *UploadManifestStore) persistObjectManifest(ctx context.Context, uploadID string) error {
	if s.chunkStore == nil || s.chunkStore.minio == nil {
		return nil
	}
	raw, err := s.redis.Get(ctx, s.metaKey(uploadID)).Bytes()
	if err != nil {
		return err
	}
	parts, err := s.redis.SMembers(ctx, s.partsKey(uploadID)).Result()
	if err != nil {
		return err
	}
	checksums, _ := s.redis.HGetAll(ctx, s.metaKey(uploadID)+":checksums").Result()
	totalSize, _ := s.redis.HGet(ctx, s.metaKey(uploadID)+":meta", "totalSize").Int64()

	var manifest UploadManifest
	if err := json.Unmarshal(raw, &manifest); err != nil {
		return err
	}
	snapshot := struct {
		UploadManifest
		ReceivedParts []string          `json:"receivedParts"`
		Checksums     map[string]string `json:"checksums,omitempty"`
		TotalSize     int64             `json:"totalSizeTracked"`
	}{
		UploadManifest: manifest,
		ReceivedParts:  parts,
		Checksums:      checksums,
		TotalSize:      totalSize,
	}
	payload, err := json.Marshal(snapshot)
	if err != nil {
		return err
	}
	return s.chunkStore.minio.Save(ctx, s.manifestObjectName(uploadID), payload)
}

func stringsEqualFold(a, b string) bool {
	return strings.TrimSpace(a) != "" && strings.EqualFold(strings.TrimSpace(a), strings.TrimSpace(b))
}

package services

import (
	"context"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/minio/minio-go/v7"
)

const uploadChunkRoot = "upload-chunks"

// UploadChunkStore persists upload parts in shared object storage (MinIO/S3 or UPLOADS_DIR mirror).
type UploadChunkStore struct {
	minio *MinIOClient
}

func NewUploadChunkStore(m *MinIOClient) *UploadChunkStore {
	if m == nil {
		return nil
	}
	return &UploadChunkStore{minio: m}
}

// NewLocalMinIOForTests returns a file-backed storage client for integration tests.
func NewLocalMinIOForTests(rootDir string) *MinIOClient {
	return &MinIOClient{bucket: "test", enabled: true, rootDir: rootDir}
}

// SharedAcrossInstances is true when chunks are stored in remote object storage.
func (s *UploadChunkStore) SharedAcrossInstances() bool {
	return s != nil && s.minio != nil && s.minio.UsesRemote()
}

func (s *UploadChunkStore) chunkObjectName(uploadID string, index int) string {
	return filepath.ToSlash(filepath.Join(uploadChunkRoot, uploadID, fmt.Sprintf("chunk_%05d", index)))
}

func (s *UploadChunkStore) chunkPrefix(uploadID string) string {
	return filepath.ToSlash(filepath.Join(uploadChunkRoot, uploadID)) + "/"
}

func (s *UploadChunkStore) Save(ctx context.Context, uploadID string, index int, data []byte) error {
	if s == nil || s.minio == nil {
		return fmt.Errorf("upload chunk store unavailable")
	}
	return s.minio.Save(ctx, s.chunkObjectName(uploadID, index), data)
}

func (s *UploadChunkStore) Open(ctx context.Context, uploadID string, index int) (io.ReadCloser, error) {
	if s == nil || s.minio == nil {
		return nil, fmt.Errorf("upload chunk store unavailable")
	}
	return s.minio.Open(ctx, s.chunkObjectName(uploadID, index))
}

func (s *UploadChunkStore) DeleteAll(ctx context.Context, uploadID string) error {
	if s == nil || s.minio == nil {
		return nil
	}
	return s.minio.RemovePrefix(ctx, s.chunkPrefix(uploadID))
}

// DeleteChunk removes a single stored chunk (rollback after manifest failure).
func (s *UploadChunkStore) DeleteChunk(ctx context.Context, uploadID string, index int) error {
	if s == nil || s.minio == nil {
		return nil
	}
	return s.minio.RemoveObject(ctx, s.chunkObjectName(uploadID, index))
}

// VerifyChunksReadable probes each chunk object before merge (read-after-write).
func (s *UploadChunkStore) VerifyChunksReadable(ctx context.Context, uploadID string, totalChunks int) error {
	if s == nil || s.minio == nil {
		return fmt.Errorf("upload chunk store unavailable")
	}
	for i := 0; i < totalChunks; i++ {
		rc, err := s.Open(ctx, uploadID, i)
		if err != nil {
			return fmt.Errorf("chunk %d not readable: %w", i, err)
		}
		_ = rc.Close()
	}
	return nil
}

func (s *UploadChunkStore) CountChunks(ctx context.Context, uploadID string, expectedTotal int) (int, error) {
	if s == nil || s.minio == nil {
		return 0, fmt.Errorf("upload chunk store unavailable")
	}
	names, err := s.minio.ListObjectNames(ctx, s.chunkPrefix(uploadID))
	if err != nil {
		return 0, err
	}
	count := 0
	for _, name := range names {
		base := filepath.Base(name)
		if !strings.HasPrefix(base, "chunk_") {
			continue
		}
		count++
	}
	if expectedTotal > 0 && count != expectedTotal {
		return count, fmt.Errorf("chunk count mismatch: expected %d, got %d", expectedTotal, count)
	}
	return count, nil
}

// MergeReader streams chunks in order as one io.Reader.
func (s *UploadChunkStore) MergeReader(ctx context.Context, uploadID string, totalChunks int) io.ReadCloser {
	return &orderedChunkReader{
		store:       s,
		ctx:         ctx,
		uploadID:    uploadID,
		totalChunks: totalChunks,
	}
}

type orderedChunkReader struct {
	store       *UploadChunkStore
	ctx         context.Context
	uploadID    string
	totalChunks int
	current     int
	cur         io.ReadCloser
	closed      bool
	readErr     error
}

func (r *orderedChunkReader) Read(p []byte) (int, error) {
	if r.closed {
		return 0, io.EOF
	}
	if r.readErr != nil {
		return 0, r.readErr
	}
	for {
		if r.cur == nil {
			if r.current >= r.totalChunks {
				return 0, io.EOF
			}
			rc, err := r.store.Open(r.ctx, r.uploadID, r.current)
			if err != nil {
				r.readErr = fmt.Errorf("open chunk %d: %w", r.current, err)
				return 0, r.readErr
			}
			r.cur = rc
		}
		n, err := r.cur.Read(p)
		if n > 0 {
			if err == io.EOF {
				_ = r.cur.Close()
				r.cur = nil
				r.current++
			}
			return n, nil
		}
		if err == io.EOF {
			_ = r.cur.Close()
			r.cur = nil
			r.current++
			continue
		}
		if err != nil {
			r.readErr = err
			return 0, err
		}
	}
}

func (r *orderedChunkReader) Close() error {
	r.closed = true
	if r.cur != nil {
		return r.cur.Close()
	}
	return nil
}

// UsesRemote exposes remote MinIO availability for startup checks.
func (m *MinIOClient) UsesRemote() bool {
	return m.usesRemote()
}

// Open returns a reader for an object in shared storage.
func (m *MinIOClient) Open(ctx context.Context, objectName string) (io.ReadCloser, error) {
	if m == nil || !m.enabled {
		return nil, fmt.Errorf("storage unavailable")
	}
	cleanObjectName, err := m.cleanObjectName(objectName)
	if err != nil {
		return nil, err
	}
	if m.usesRemote() {
		return m.client.GetObject(ctx, m.bucket, cleanObjectName, minio.GetObjectOptions{})
	}
	filePath := filepath.Join(m.rootDir, filepath.FromSlash(cleanObjectName))
	return os.Open(filePath)
}

// ListObjectNames lists object keys under prefix.
func (m *MinIOClient) ListObjectNames(ctx context.Context, prefix string) ([]string, error) {
	if m == nil || !m.enabled {
		return nil, fmt.Errorf("storage unavailable")
	}
	cleanPrefix, err := m.cleanObjectName(strings.TrimSuffix(prefix, "/"))
	if err != nil {
		return nil, err
	}
	cleanPrefix = strings.TrimSuffix(cleanPrefix, "/") + "/"

	if m.usesRemote() {
		var names []string
		for obj := range m.client.ListObjects(ctx, m.bucket, minio.ListObjectsOptions{
			Prefix:    cleanPrefix,
			Recursive: true,
		}) {
			if obj.Err != nil {
				return nil, obj.Err
			}
			names = append(names, obj.Key)
		}
		return names, nil
	}

	dir := filepath.Join(m.rootDir, filepath.FromSlash(cleanPrefix))
	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var names []string
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		names = append(names, filepath.ToSlash(filepath.Join(cleanPrefix, e.Name())))
	}
	return names, nil
}

// RemovePrefix deletes all objects under prefix.
func (m *MinIOClient) RemovePrefix(ctx context.Context, prefix string) error {
	if m == nil || !m.enabled {
		return nil
	}
	names, err := m.ListObjectNames(ctx, prefix)
	if err != nil {
		return err
	}
	for _, name := range names {
		if err := m.RemoveObject(ctx, name); err != nil {
			return err
		}
	}
	if m.usesRemote() {
		return nil
	}
	cleanPrefix, err := m.cleanObjectName(strings.TrimSuffix(prefix, "/"))
	if err != nil {
		return err
	}
	dir := filepath.Join(m.rootDir, filepath.FromSlash(strings.TrimSuffix(cleanPrefix, "/")))
	if err := os.RemoveAll(dir); err != nil && !os.IsNotExist(err) {
		return err
	}
	return nil
}

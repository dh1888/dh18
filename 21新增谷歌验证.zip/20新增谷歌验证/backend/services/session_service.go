package services

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
)

const (
	SessionSubjectUser   = "user"
	SessionSubjectDevice = "device"

	SessionStatusActive  = "active"
	SessionStatusRevoked = "revoked"
	SessionStatusExpired = "expired"
)

var (
	ErrSessionNotFound        = errors.New("session not found")
	ErrSessionRevoked         = errors.New("session revoked")
	ErrSessionExpired         = errors.New("session expired")
	ErrSessionVersionConflict = errors.New("session version conflict")
	ErrWSTicketInvalid        = errors.New("ws ticket invalid")
	ErrSessionUnavailable     = errors.New("session store unavailable")
)

type AuthSession struct {
	ID           uuid.UUID
	SubjectType  string
	SubjectID    uuid.UUID
	Status       string
	Version      int
	ExpiresAt    time.Time
	RevokedAt    *time.Time
	RevokeReason string
	ClientIP     string
	UserAgent    string
	CreatedAt    time.Time
	UpdatedAt    time.Time
}

type sessionCachePayload struct {
	Status      string    `json:"status"`
	Version     int       `json:"version"`
	ExpiresAt   time.Time `json:"expiresAt"`
	SubjectType string    `json:"subjectType"`
	SubjectID   string    `json:"subjectId"`
}

type SessionService struct {
	db         *sql.DB
	redis      *redis.Client
	revokeHook func(SessionRevokeEvent)
}

func NewSessionService(db *sql.DB, redis *redis.Client) *SessionService {
	return &SessionService{db: db, redis: redis}
}

// SetRevokeHook registers a synchronous local listener for session revoke (WS kick).
func (s *SessionService) SetRevokeHook(fn func(SessionRevokeEvent)) {
	s.revokeHook = fn
}

func (s *SessionService) emitSessionRevoke(sessionID, reason string) {
	if sessionID == "" {
		return
	}
	event := SessionRevokeEvent{SessionID: sessionID, Reason: reason}
	if s.revokeHook != nil {
		s.revokeHook(event)
	}
}

func sessionCacheKey(id string) string       { return "sess:" + id }
func sessionRefreshKey(token string) string { return "sess:refresh:" + token }
func wsTicketKey(ticket string) string      { return "ws_ticket:" + ticket }

func (s *SessionService) CreateSession(
	ctx context.Context,
	subjectType string,
	subjectID uuid.UUID,
	expiresAt time.Time,
	clientIP, userAgent string,
) (*AuthSession, error) {
	if s.db == nil {
		return nil, ErrSessionUnavailable
	}

	id := uuid.New()
	now := models.UTCNow()
	sess := &AuthSession{
		ID:          id,
		SubjectType: subjectType,
		SubjectID:   subjectID,
		Status:      SessionStatusActive,
		Version:     1,
		ExpiresAt:   expiresAt,
		ClientIP:    clientIP,
		UserAgent:   userAgent,
		CreatedAt:   now,
		UpdatedAt:   now,
	}

	_, err := s.db.ExecContext(ctx, `
		INSERT INTO auth_sessions (
			id, subject_type, subject_id, status, version, expires_at, client_ip, user_agent, created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, NULLIF($7, ''), NULLIF($8, ''), $9, $10)`,
		sess.ID, sess.SubjectType, sess.SubjectID, sess.Status, sess.Version,
		sess.ExpiresAt, clientIP, userAgent, sess.CreatedAt, sess.UpdatedAt,
	)
	if err != nil {
		return nil, fmt.Errorf("create session: %w", err)
	}

	s.cacheSession(ctx, sess)
	return sess, nil
}

func (s *SessionService) GetSession(ctx context.Context, sessionID string) (*AuthSession, error) {
	if sessionID == "" {
		return nil, ErrSessionNotFound
	}

	if tomb, ok := s.loadSessionTombstone(ctx, sessionID); ok {
		return tomb, nil
	}

	if s.db == nil {
		return nil, ErrSessionUnavailable
	}

	if cached, err := s.loadSessionCache(ctx, sessionID); err == nil && cached != nil {
		if cached.Status != SessionStatusActive {
			return cached, nil
		}
		if tomb, ok := s.loadSessionTombstone(ctx, sessionID); ok {
			return tomb, nil
		}
		// Active cache must be confirmed against DB (fail-closed on revoke drift).
		sess, err := s.loadSessionFromDB(ctx, sessionID)
		if err != nil {
			return nil, err
		}
		s.cacheSession(ctx, sess)
		return sess, nil
	}

	sess, err := s.loadSessionFromDB(ctx, sessionID)
	if err != nil {
		return nil, err
	}
	s.cacheSession(ctx, sess)
	return sess, nil
}

func (s *SessionService) loadSessionFromDB(ctx context.Context, sessionID string) (*AuthSession, error) {
	parsedID, err := uuid.Parse(sessionID)
	if err != nil {
		return nil, ErrSessionNotFound
	}

	sess := &AuthSession{}
	var revokedAt sql.NullTime
	err = s.db.QueryRowContext(ctx, `
		SELECT id, subject_type, subject_id, status, version, expires_at,
		       revoked_at, COALESCE(revoke_reason, ''), COALESCE(client_ip::text, ''), COALESCE(user_agent, ''),
		       created_at, updated_at
		FROM auth_sessions WHERE id = $1`, parsedID,
	).Scan(
		&sess.ID, &sess.SubjectType, &sess.SubjectID, &sess.Status, &sess.Version, &sess.ExpiresAt,
		&revokedAt, &sess.RevokeReason, &sess.ClientIP, &sess.UserAgent,
		&sess.CreatedAt, &sess.UpdatedAt,
	)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrSessionNotFound
		}
		return nil, err
	}
	if revokedAt.Valid {
		sess.RevokedAt = &revokedAt.Time
	}
	if sess.Status == SessionStatusActive && models.UTCNow().After(sess.ExpiresAt) {
		sess.Status = SessionStatusExpired
	}
	return sess, nil
}

func (s *SessionService) RevokeSession(ctx context.Context, sessionID, reason string) error {
	if sessionID == "" || s.db == nil {
		return nil
	}
	parsedID, err := uuid.Parse(sessionID)
	if err != nil {
		return nil
	}

	now := models.UTCNow()
	_, err = s.db.ExecContext(ctx, `
		UPDATE auth_sessions
		SET status = $2, revoked_at = $3, revoke_reason = $4, updated_at = $3
		WHERE id = $1 AND status = $5`,
		parsedID, SessionStatusRevoked, now, reason, SessionStatusActive,
	)
	if err != nil {
		return err
	}

	s.invalidateSessionCache(ctx, sessionID)
	s.writeSessionTombstone(ctx, sessionID, SessionStatusRevoked, reason)
	s.publishSessionRevoke(ctx, sessionID, reason)
	s.emitSessionRevoke(sessionID, reason)
	return nil
}

func (s *SessionService) RevokeSessionsBySubject(ctx context.Context, subjectType string, subjectID uuid.UUID, reason string) error {
	if s.db == nil {
		return ErrSessionUnavailable
	}

	now := models.UTCNow()
	rows, err := s.db.QueryContext(ctx, `
		UPDATE auth_sessions
		SET status = $4, revoked_at = $5, revoke_reason = $6, updated_at = $5
		WHERE subject_type = $1 AND subject_id = $2 AND status = $3
		RETURNING id`,
		subjectType, subjectID, SessionStatusActive, SessionStatusRevoked, now, reason,
	)
	if err != nil {
		return err
	}
	defer rows.Close()

	for rows.Next() {
		var id uuid.UUID
		if err := rows.Scan(&id); err != nil {
			continue
		}
		s.invalidateSessionCache(ctx, id.String())
		s.writeSessionTombstone(ctx, id.String(), SessionStatusRevoked, reason)
		s.publishSessionRevoke(ctx, id.String(), reason)
		s.emitSessionRevoke(id.String(), reason)
	}
	return rows.Err()
}

func (s *SessionService) BumpVersion(ctx context.Context, sessionID string, expectedVersion int) (int, error) {
	if s.db == nil {
		return 0, ErrSessionUnavailable
	}
	parsedID, err := uuid.Parse(sessionID)
	if err != nil {
		return 0, ErrSessionNotFound
	}

	var newVersion int
	err = s.db.QueryRowContext(ctx, `
		UPDATE auth_sessions
		SET version = version + 1, updated_at = NOW()
		WHERE id = $1 AND version = $2 AND status = $3
		RETURNING version`,
		parsedID, expectedVersion, SessionStatusActive,
	).Scan(&newVersion)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return 0, ErrSessionVersionConflict
		}
		return 0, err
	}

	s.invalidateSessionCache(ctx, sessionID)
	return newVersion, nil
}

func (s *SessionService) BindRefreshToken(ctx context.Context, refreshToken, sessionID string, ttl time.Duration) error {
	if s.redis == nil || refreshToken == "" || sessionID == "" {
		return nil
	}
	return s.redis.Set(ctx, sessionRefreshKey(refreshToken), sessionID, ttl).Err()
}

func (s *SessionService) LookupSessionByRefresh(ctx context.Context, refreshToken string) (string, error) {
	if s.redis == nil || refreshToken == "" {
		return "", redis.Nil
	}
	return s.redis.Get(ctx, sessionRefreshKey(refreshToken)).Result()
}

func (s *SessionService) DeleteRefreshBinding(ctx context.Context, refreshToken string) {
	if s.redis == nil || refreshToken == "" {
		return
	}
	_ = s.redis.Del(ctx, sessionRefreshKey(refreshToken)).Err()
}

func (s *SessionService) IssueWSTicket(ctx context.Context, sessionID string) (string, time.Duration, error) {
	if s.redis == nil {
		return "", 0, ErrSessionUnavailable
	}
	if sessionID == "" {
		return "", 0, ErrSessionNotFound
	}

	sess, err := s.GetSession(ctx, sessionID)
	if err != nil {
		return "", 0, err
	}
	if sess.Status != SessionStatusActive {
		return "", 0, ErrSessionRevoked
	}
	if models.UTCNow().After(sess.ExpiresAt) {
		return "", 0, ErrSessionExpired
	}

	ttl := WSTicketTTL()
	ticket := uuid.New().String()
	if err := s.redis.Set(ctx, wsTicketKey(ticket), sessionID, ttl).Err(); err != nil {
		return "", 0, err
	}
	return ticket, ttl, nil
}

func (s *SessionService) RedeemWSTicket(ctx context.Context, ticket string) (string, error) {
	if s.redis == nil || ticket == "" {
		return "", ErrWSTicketInvalid
	}
	sessionID, err := s.redis.GetDel(ctx, wsTicketKey(ticket)).Result()
	if err != nil {
		if errors.Is(err, redis.Nil) {
			return "", ErrWSTicketInvalid
		}
		return "", err
	}
	if sessionID == "" {
		return "", ErrWSTicketInvalid
	}
	return sessionID, nil
}

func (s *SessionService) ValidateActiveSession(ctx context.Context, sessionID string) (*AuthSession, error) {
	start := time.Now()
	defer func() {
		GlobalMetrics.ObserveSessionValidation(time.Since(start))
	}()

	sess, err := s.GetSession(ctx, sessionID)
	if err != nil {
		return nil, err
	}
	switch sess.Status {
	case SessionStatusRevoked:
		return nil, ErrSessionRevoked
	case SessionStatusExpired:
		return nil, ErrSessionExpired
	case SessionStatusActive:
		if models.UTCNow().After(sess.ExpiresAt) {
			return nil, ErrSessionExpired
		}
		return sess, nil
	default:
		return nil, ErrSessionRevoked
	}
}

func (s *SessionService) RevokeSubjectRefreshTokens(ctx context.Context, subjectType string, subjectID uuid.UUID, reason string) error {
	if err := s.RevokeSessionsBySubject(ctx, subjectType, subjectID, reason); err != nil {
		return err
	}
	if s.redis == nil {
		return nil
	}
	indexKey := sessionRefreshIndexKey(subjectType, subjectID.String())
	tokens, err := s.redis.SMembers(ctx, indexKey).Result()
	if err != nil && err != redis.Nil {
		return err
	}
	pipe := s.redis.Pipeline()
	for _, token := range tokens {
		pipe.Del(ctx, sessionRefreshKey(token))
	}
	pipe.Del(ctx, indexKey)
	_, err = pipe.Exec(ctx)
	return err
}

func sessionRefreshIndexKey(subjectType, subjectID string) string {
	return "sess:refresh_index:" + subjectType + ":" + subjectID
}

func IndexSessionRefreshToken(ctx context.Context, redisClient *redis.Client, subjectType, subjectID, refreshToken string, ttl time.Duration) error {
	if redisClient == nil || refreshToken == "" {
		return nil
	}
	key := sessionRefreshIndexKey(subjectType, subjectID)
	pipe := redisClient.Pipeline()
	pipe.SAdd(ctx, key, refreshToken)
	pipe.Expire(ctx, key, ttl)
	_, err := pipe.Exec(ctx)
	return err
}

func (s *SessionService) cacheSession(ctx context.Context, sess *AuthSession) {
	if s.redis == nil || sess == nil {
		return
	}
	payload, err := json.Marshal(sessionCachePayload{
		Status:      sess.Status,
		Version:     sess.Version,
		ExpiresAt:   sess.ExpiresAt,
		SubjectType: sess.SubjectType,
		SubjectID:   sess.SubjectID.String(),
	})
	if err != nil {
		return
	}
	ttl := time.Until(sess.ExpiresAt)
	if ttl <= 0 {
		ttl = time.Minute
	}
	if err := s.redis.Set(ctx, sessionCacheKey(sess.ID.String()), payload, ttl).Err(); err != nil {
		log.Printf("[Session] cache set failed for %s: %v", sess.ID, err)
	}
}

func (s *SessionService) loadSessionCache(ctx context.Context, sessionID string) (*AuthSession, error) {
	if s.redis == nil {
		return nil, redis.Nil
	}
	raw, err := s.redis.Get(ctx, sessionCacheKey(sessionID)).Result()
	if err != nil {
		return nil, err
	}
	var payload sessionCachePayload
	if err := json.Unmarshal([]byte(raw), &payload); err != nil {
		return nil, err
	}
	subjectID, err := uuid.Parse(payload.SubjectID)
	if err != nil {
		return nil, err
	}
	parsedID, err := uuid.Parse(sessionID)
	if err != nil {
		return nil, err
	}
	status := payload.Status
	if status == SessionStatusActive && models.UTCNow().After(payload.ExpiresAt) {
		status = SessionStatusExpired
	}
	return &AuthSession{
		ID:          parsedID,
		SubjectType: payload.SubjectType,
		SubjectID:   subjectID,
		Status:      status,
		Version:     payload.Version,
		ExpiresAt:   payload.ExpiresAt,
	}, nil
}

func (s *SessionService) invalidateSessionCache(ctx context.Context, sessionID string) {
	if s.redis == nil || sessionID == "" {
		return
	}
	_ = s.redis.Del(ctx, sessionCacheKey(sessionID)).Err()
}

func ClientIPFromContext(forwarded, remoteAddr string) string {
	forwarded = strings.TrimSpace(forwarded)
	if forwarded != "" {
		if idx := strings.IndexByte(forwarded, ','); idx >= 0 {
			forwarded = strings.TrimSpace(forwarded[:idx])
		}
		if forwarded != "" {
			return forwarded
		}
	}
	if host, _, err := net.SplitHostPort(remoteAddr); err == nil {
		return host
	}
	return remoteAddr
}

// SweepExpiredSessions marks overdue active sessions as expired.
func (s *SessionService) SweepExpiredSessions(ctx context.Context) (int64, error) {
	if s.db == nil {
		return 0, nil
	}
	rows, err := s.db.QueryContext(ctx, `
		UPDATE auth_sessions
		SET status = $1, updated_at = NOW()
		WHERE status = $2 AND expires_at < NOW()
		RETURNING id`, SessionStatusExpired, SessionStatusActive)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	var count int64
	for rows.Next() {
		var id uuid.UUID
		if err := rows.Scan(&id); err != nil {
			continue
		}
		s.invalidateSessionCache(ctx, id.String())
		s.writeSessionTombstone(ctx, id.String(), SessionStatusExpired, "expired")
		count++
	}
	return count, rows.Err()
}

// SessionStats counts sessions grouped by status.
type SessionStats struct {
	Active  int64
	Revoked int64
	Expired int64
}

func (s *SessionService) GetSessionStats(ctx context.Context) (SessionStats, error) {
	var stats SessionStats
	if s.db == nil {
		return stats, ErrSessionUnavailable
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT status, COUNT(*)::bigint FROM auth_sessions GROUP BY status`)
	if err != nil {
		return stats, err
	}
	defer rows.Close()
	for rows.Next() {
		var status string
		var count int64
		if err := rows.Scan(&status, &count); err != nil {
			continue
		}
		switch status {
		case SessionStatusActive:
			stats.Active = count
		case SessionStatusRevoked:
			stats.Revoked = count
		case SessionStatusExpired:
			stats.Expired = count
		}
	}
	return stats, rows.Err()
}

// StartSessionMaintenance runs periodic expiry sweeps until ctx is cancelled.
func StartSessionMaintenance(ctx context.Context, svc *SessionService) {
	if svc == nil || svc.db == nil {
		return
	}
	go func() {
		interval := SessionMaintenanceInterval()
		ticker := time.NewTicker(interval)
		defer ticker.Stop()
		log.Printf("[Session] maintenance started (interval=%v)", interval)
		logSessionStats := func() {
			statsCtx, statsCancel := context.WithTimeout(context.Background(), 10*time.Second)
			stats, err := svc.GetSessionStats(statsCtx)
			statsCancel()
			if err != nil {
				log.Printf("[Session] stats query failed: %v", err)
				return
			}
			log.Printf("[Session] stats active=%d revoked=%d expired=%d", stats.Active, stats.Revoked, stats.Expired)
		}
		logSessionStats()
		for {
			select {
			case <-ctx.Done():
				log.Printf("[Session] maintenance stopped")
				return
			case <-ticker.C:
				sweepCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
				n, err := svc.SweepExpiredSessions(sweepCtx)
				cancel()
				if err != nil {
					log.Printf("[Session] expiry sweep failed: %v", err)
				} else if n > 0 {
					log.Printf("[Session] marked %d sessions expired", n)
				}
				logSessionStats()
			}
		}
	}()
}

-- Server-side auth sessions (SSOT) for JWT / WS / refresh / revoke unification
CREATE TABLE IF NOT EXISTS auth_sessions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subject_type    VARCHAR(16) NOT NULL,
    subject_id      UUID NOT NULL,
    status          VARCHAR(16) NOT NULL DEFAULT 'active',
    version         INT NOT NULL DEFAULT 1,
    expires_at      TIMESTAMPTZ NOT NULL,
    revoked_at      TIMESTAMPTZ,
    revoke_reason   VARCHAR(64),
    client_ip       INET,
    user_agent      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_auth_sessions_subject ON auth_sessions(subject_type, subject_id);
CREATE INDEX IF NOT EXISTS idx_auth_sessions_status ON auth_sessions(status) WHERE status = 'active';

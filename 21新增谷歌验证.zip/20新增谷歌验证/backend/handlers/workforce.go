package handlers

import (
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type WorkforceHandler struct {
	db        *sql.DB
	workforce *services.WorkforceService
	userRepo  *services.UserRepository
	deviceRepo *services.DeviceRepository
	wsHub     *services.WebSocketHub
}

func NewWorkforceHandler(db *sql.DB, workforce *services.WorkforceService, userRepo *services.UserRepository, deviceRepo *services.DeviceRepository, wsHub *services.WebSocketHub) *WorkforceHandler {
	return &WorkforceHandler{db: db, workforce: workforce, userRepo: userRepo, deviceRepo: deviceRepo, wsHub: wsHub}
}

// CreateEmployeeAccount orchestrates user + employee + invite + today attendance.
func (h *WorkforceHandler) CreateEmployeeAccount(c *gin.Context) {
	var req struct {
		Username     string `json:"username" binding:"required"`
		Password     string `json:"password" binding:"required,min=6"`
		EmployeeID   string `json:"employee_id"`
		Name         string `json:"name" binding:"required"`
		Position     string `json:"position"`
		Department   string `json:"department"`
		HireDate     string `json:"hire_date"`
		WorkLocation string `json:"work_location"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	createdBy := uuid.Nil
	if uid := c.GetString("userID"); uid != "" {
		if id, err := uuid.Parse(uid); err == nil {
			createdBy = id
		}
	}

	result, err := h.workforce.CreateEmployeeAccount(c.Request.Context(), &services.CreateEmployeeAccountInput{
		Username:     req.Username,
		Password:     req.Password,
		EmployeeID:   req.EmployeeID,
		Name:         req.Name,
		Position:     req.Position,
		Department:   req.Department,
		HireDate:     req.HireDate,
		WorkLocation: req.WorkLocation,
		CreatedBy:    createdBy,
	})
	if err != nil {
		if strings.Contains(err.Error(), "duplicate") || strings.Contains(err.Error(), "unique") {
			models.SendError(c, 400, 1001, "username or employee id already exists")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	Log(c, "CREATE", "EMPLOYEE_ACCOUNT",
		fmt.Sprintf("创建员工子账号：%s（登录名 %s）", req.Name, req.Username),
		result.EmployeeID.String(), req.Name)

	models.Send(c, 200, 0, "Employee account created", gin.H{
		"userId":     result.UserID,
		"employeeId": result.EmployeeID,
		"inviteCode": result.InviteCode,
		"inviteId":   result.InviteID,
	})
}

func (h *WorkforceHandler) ListInviteCodes(c *gin.Context) {
	var employeeFilter *uuid.UUID
	if eid := c.Query("employee_id"); eid != "" {
		if id, err := uuid.Parse(eid); err == nil {
			employeeFilter = &id
		}
	}

	rows, err := h.workforce.ListInviteCodes(c.Request.Context(), employeeFilter)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	items := make([]gin.H, 0, len(rows))
	for _, row := range rows {
		items = append(items, gin.H{
			"id":           row.ID,
			"code":         row.Code,
			"employeeId":   row.EmployeeID,
			"employeeName": row.EmployeeName,
			"status":       services.InviteStatusLabel(row),
			"expiresAt":    row.ExpiresAt,
			"usedAt":       row.UsedAt,
			"revokedAt":    row.RevokedAt,
			"createdAt":    row.CreatedAt,
			"deviceId":     row.DeviceID,
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items})
}

func (h *WorkforceHandler) RevokeInviteCode(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid invite id")
		return
	}
	if err := h.workforce.RevokeInviteCode(c.Request.Context(), id); err != nil {
		if errors.Is(err, services.ErrInviteNotFound) {
			models.SendError(c, 404, 2001, "invite not found or already used")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "INVITE_CODE", "作废邀请码", id.String(), id.String())
	models.Send(c, 200, 0, "Invite revoked", nil)
}

func (h *WorkforceHandler) RegenerateInviteCode(c *gin.Context) {
	employeeID, err := uuid.Parse(c.Param("employeeId"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid employee id")
		return
	}
	createdBy := uuid.Nil
	if uid := c.GetString("userID"); uid != "" {
		if id, err := uuid.Parse(uid); err == nil {
			createdBy = id
		}
	}
	code, inviteID, err := h.workforce.RegenerateInviteCode(c.Request.Context(), employeeID, createdBy)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "CREATE", "INVITE_CODE", fmt.Sprintf("重新生成邀请码（员工 %s）", employeeID), inviteID.String(), employeeID.String())
	models.Send(c, 200, 0, "Invite regenerated", gin.H{"code": code, "inviteId": inviteID})
}

func (h *WorkforceHandler) GetPortalMe(c *gin.Context) {
	userID, err := uuid.Parse(c.GetString("userID"))
	if err != nil {
		models.SendError(c, 401, 1002, "unauthorized")
		return
	}

	empID, err := h.workforce.ResolveEmployeeByUserID(c.Request.Context(), userID)
	if err != nil {
		models.SendError(c, 404, 2001, "employee profile not found")
		return
	}

	var name, empNumber, position, department string
	var status int
	_ = h.db.QueryRowContext(c.Request.Context(), `
		SELECT name, COALESCE(employee_id,''), COALESCE(position,''), COALESCE(department,''), status
		FROM employees WHERE id = $1`, empID).Scan(&name, &empNumber, &position, &department, &status)

	today := ""
	var attStatus sql.NullString
	var checkin, checkout sql.NullTime
	_ = h.db.QueryRowContext(c.Request.Context(), `
		SELECT date::text, status, checkin_time, checkout_time FROM attendance_records
		WHERE employee_id = $1 AND date = CURRENT_DATE`, empID).Scan(&today, &attStatus, &checkin, &checkout)

	invites, _ := h.workforce.ListInviteCodes(c.Request.Context(), &empID)
	var activeInvite string
	for _, inv := range invites {
		if services.InviteStatusLabel(inv) == "active" {
			activeInvite = inv.Code
			break
		}
	}

	var deviceBound bool
	var deviceInfo gin.H
	var devID uuid.UUID
	var hostname, agentVer, osVer, devStatus string
	var lastSeen sql.NullTime
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT id, COALESCE(hostname,''), COALESCE(agent_version,''), COALESCE(os_version,''), status, last_seen_at
		FROM devices WHERE employee_uuid = $1 ORDER BY bound_at DESC NULLS LAST LIMIT 1`, empID).
		Scan(&devID, &hostname, &agentVer, &osVer, &devStatus, &lastSeen)
	if err == nil {
		deviceBound = true
		online := "offline"
		if lastSeen.Valid && timeWithinOnline(lastSeen.Time) {
			online = "online"
		}
		deviceInfo = gin.H{
			"id":           devID,
			"hostname":     hostname,
			"agentVersion": agentVer,
			"osVersion":    osVer,
			"status":       devStatus,
			"onlineStatus": online,
			"lastSeenAt":   lastSeen.Time,
		}
	}

	models.Send(c, 200, 0, "success", gin.H{
		"employee": gin.H{
			"id": empID, "name": name, "employeeNumber": empNumber,
			"position": position, "department": department, "status": status,
		},
		"inviteCode":  activeInvite,
		"deviceBound": deviceBound,
		"device":      deviceInfo,
		"todayAttendance": gin.H{
			"date": today, "status": attStatus.String,
			"checkinTime": checkin.Time, "checkoutTime": checkout.Time,
		},
	})
}

func timeWithinOnline(t time.Time) bool {
	return time.Since(t) < 3*time.Minute
}

func (h *WorkforceHandler) GetMyInviteCode(c *gin.Context) {
	userID, _ := uuid.Parse(c.GetString("userID"))
	empID, err := h.workforce.ResolveEmployeeByUserID(c.Request.Context(), userID)
	if err != nil {
		models.SendError(c, 404, 2001, "employee not found")
		return
	}
	invites, err := h.workforce.ListInviteCodes(c.Request.Context(), &empID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	for _, inv := range invites {
		if services.InviteStatusLabel(inv) == "active" {
			models.Send(c, 200, 0, "success", gin.H{
				"code": inv.Code, "expiresAt": inv.ExpiresAt, "status": "active",
			})
			return
		}
	}
	models.Send(c, 200, 0, "success", gin.H{"code": "", "status": "none"})
}

func (h *WorkforceHandler) GetMyAttendance(c *gin.Context) {
	userID, _ := uuid.Parse(c.GetString("userID"))
	empID, err := h.workforce.ResolveEmployeeByUserID(c.Request.Context(), userID)
	if err != nil {
		models.SendError(c, 404, 2001, "employee not found")
		return
	}
	yearMonth := c.DefaultQuery("year_month", timeNowYearMonth())
	rows, err := h.db.QueryContext(c.Request.Context(), `
		SELECT date::text, status, checkin_time, checkout_time, position_snapshot
		FROM attendance_records WHERE employee_id = $1 AND year_month = $2 ORDER BY date`, empID, yearMonth)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()
	items := []gin.H{}
	for rows.Next() {
		var date, status, snapshot string
		var checkin, checkout sql.NullTime
		if err := rows.Scan(&date, &status, &checkin, &checkout, &snapshot); err != nil {
			continue
		}
		items = append(items, gin.H{
			"date": date, "status": status, "positionSnapshot": snapshot,
			"checkinTime": checkin.Time, "checkoutTime": checkout.Time,
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"yearMonth": yearMonth, "items": items})
}

func (h *WorkforceHandler) GetMyDevice(c *gin.Context) {
	userID, _ := uuid.Parse(c.GetString("userID"))
	empID, err := h.workforce.ResolveEmployeeByUserID(c.Request.Context(), userID)
	if err != nil {
		models.SendError(c, 404, 2001, "employee not found")
		return
	}
	var devID uuid.UUID
	var hostname, agentVer, osVer, status string
	var lastSeen sql.NullTime
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT id, hostname, agent_version, os_version, status, last_seen_at
		FROM devices WHERE employee_uuid = $1 LIMIT 1`, empID).
		Scan(&devID, &hostname, &agentVer, &osVer, &status, &lastSeen)
	if err == sql.ErrNoRows {
		models.Send(c, 200, 0, "success", gin.H{"bound": false})
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	online := "offline"
	if lastSeen.Valid && timeWithinOnline(lastSeen.Time) {
		online = "online"
	}
	models.Send(c, 200, 0, "success", gin.H{
		"bound": true,
		"device": gin.H{
			"id": devID, "hostname": hostname, "agentVersion": agentVer,
			"osVersion": osVer, "status": status, "onlineStatus": online, "lastSeenAt": lastSeen.Time,
		},
	})
}

func (h *WorkforceHandler) GetClientDownload(c *gin.Context) {
	localPath, externalURL, fileName := resolveClientInstaller()
	version := strings.TrimSpace(os.Getenv("CLIENT_VERSION"))

	if externalURL != "" {
		models.Send(c, 200, 0, "success", gin.H{
			"downloadUrl": externalURL,
			"version":     version,
			"fileName":    fileName,
			"mode":        "external",
		})
		return
	}

	if _, err := os.Stat(localPath); err != nil {
		models.Send(c, 200, 0, "success", gin.H{
			"downloadUrl": "/api/v1/employee/client-download/file",
			"version":     version,
			"fileName":    fileName,
			"mode":        "api",
			"available":   false,
		})
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"downloadUrl": "/api/v1/employee/client-download/file",
		"version":     version,
		"fileName":    fileName,
		"mode":        "api",
		"available":   true,
	})
}

func (h *WorkforceHandler) DownloadClientFile(c *gin.Context) {
	localPath, externalURL, fileName := resolveClientInstaller()
	if externalURL != "" {
		c.Redirect(http.StatusFound, externalURL)
		return
	}

	if _, err := os.Stat(localPath); err != nil {
		models.SendError(c, 404, 3001, "Client installer not found. Ask admin to place the file in downloads/ or set CLIENT_DOWNLOAD_URL")
		return
	}

	c.Header("Content-Disposition", "attachment; filename="+fileName)
	c.Header("Content-Type", "application/octet-stream")
	c.File(localPath)
}

func resolveClientInstaller() (localPath, externalURL, fileName string) {
	fileName = strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_FILE"))
	if fileName == "" {
		fileName = "EnterpriseAgent-setup.exe"
	}

	configured := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_URL"))
	if configured != "" {
		if strings.HasPrefix(configured, "http://") || strings.HasPrefix(configured, "https://") {
			return "", configured, fileName
		}
		if strings.HasPrefix(configured, "/") {
			dir := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_DIR"))
			if dir == "" {
				dir = "./downloads"
			}
			rel := strings.TrimPrefix(configured, "/downloads/")
			if rel == configured {
				rel = filepath.Base(configured)
			}
			return filepath.Join(dir, rel), "", filepath.Base(rel)
		}
		return filepath.Join(configured), "", filepath.Base(configured)
	}

	dir := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_DIR"))
	if dir == "" {
		dir = "./downloads"
	}
	return filepath.Join(dir, fileName), "", fileName
}

func (h *WorkforceHandler) EmployeeLogin(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	var req struct {
		Username string `json:"username" binding:"required"`
		Password string `json:"password" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	result, err := h.workforce.EmployeeLogin(c.Request.Context(), deviceID, req.Username, req.Password)
	if err != nil {
		switch {
		case errors.Is(err, services.ErrInvalidCredentials):
			models.SendError(c, 401, 1002, "Invalid username or password")
		case errors.Is(err, services.ErrNotEmployeeRole):
			models.SendError(c, 403, 1003, "Only employee accounts can login here")
		case errors.Is(err, services.ErrEmployeeOnOtherDevice):
			models.SendError(c, 409, 1004, "Employee is active on another device")
		case errors.Is(err, services.ErrEmployeeNotFound):
			models.SendError(c, 404, 2001, "Employee profile not found")
		default:
			models.SendError(c, 500, 5000, err.Error())
		}
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type": "employee.login", "deviceId": deviceID.String(),
			"employeeId": result.EmployeeID.String(), "name": result.EmployeeName,
		})
	}
	models.Send(c, 200, 0, "login success", gin.H{
		"employeeId": result.EmployeeID, "name": result.EmployeeName,
		"employeeNumber": result.EmployeeNumber, "position": result.Position,
		"username": result.Username,
	})
}

func (h *WorkforceHandler) EmployeeLogout(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	if err := h.workforce.EmployeeLogout(c.Request.Context(), deviceID); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{"type": "employee.logout", "deviceId": deviceID.String()})
	}
	models.Send(c, 200, 0, "logout success", nil)
}

func (h *WorkforceHandler) GetAgentSession(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	var name, empNumber, position, username sql.NullString
	var empUUID sql.NullString
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT d.employee_uuid::text, d.employee_name, d.employee_number, d.position, u.username
		FROM devices d
		LEFT JOIN users u ON u.id = d.user_id
		WHERE d.id = $1`, deviceID).Scan(&empUUID, &name, &empNumber, &position, &username)
	if err != nil || !empUUID.Valid || empUUID.String == "" {
		models.Send(c, 200, 0, "success", gin.H{"loggedIn": false})
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"loggedIn": true,
		"employeeId": empUUID.String,
		"name": name.String,
		"employeeNumber": empNumber.String,
		"position": position.String,
		"username": username.String,
	})
}

func (h *WorkforceHandler) CheckIn(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	result, err := h.workforce.CheckIn(c.Request.Context(), deviceID)
	if err != nil {
		if errors.Is(err, services.ErrSessionExists) {
			models.SendError(c, 409, 1004, "work session already open")
			return
		}
		if errors.Is(err, services.ErrEmployeeNotFound) {
			models.SendError(c, 400, 1001, "please login with employee account first")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type": "employee.checkin", "deviceId": deviceID.String(),
			"sessionId": result.SessionID.String(), "date": result.Date,
		})
	}
	models.Send(c, 200, 0, "checked in", gin.H{
		"sessionId": result.SessionID, "date": result.Date,
	})
}

func (h *WorkforceHandler) CheckOut(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	var req struct {
		SessionID string `json:"sessionId"`
	}
	_ = c.ShouldBindJSON(&req)
	var sid *uuid.UUID
	if req.SessionID != "" {
		if id, err := uuid.Parse(req.SessionID); err == nil {
			sid = &id
		}
	}
	result, err := h.workforce.CheckOut(c.Request.Context(), deviceID, sid)
	if err != nil {
		if errors.Is(err, services.ErrNoOpenSession) {
			models.SendError(c, 404, 2001, "no open work session")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type": "employee.checkout", "deviceId": deviceID.String(),
			"sessionId": result.SessionID.String(),
		})
	}
	models.Send(c, 200, 0, "checked out", gin.H{"sessionId": result.SessionID})
}

func (h *WorkforceHandler) DisableEmployee(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid employee id")
		return
	}
	if err := h.workforce.DisableEmployee(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	var userIDStr sql.NullString
	_ = h.db.QueryRowContext(c.Request.Context(), `SELECT user_id::text FROM employees WHERE id = $1`, id).Scan(&userIDStr)
	if userIDStr.Valid {
		if uid, parseErr := uuid.Parse(userIDStr.String); parseErr == nil {
			_ = revokeUserSessions(c.Request.Context(), uid, "user_disabled")
		}
	}
	Log(c, "UPDATE", "EMPLOYEE", "禁用员工（软删除）", id.String(), id.String())
	models.Send(c, 200, 0, "Employee disabled", nil)
}

func timeNowYearMonth() string {
	return time.Now().Format("2006-01")
}

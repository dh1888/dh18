// backend/handlers/device.go
package handlers

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

const deviceRefreshTokenTTL = 30 * 24 * time.Hour

type DeviceHandler struct {
	repo      *services.DeviceRepository
	wsHub     *services.WebSocketHub
	redis     *redis.Client
	workforce *services.WorkforceService
	sessions  *services.SessionService
}

func NewDeviceHandler(repo *services.DeviceRepository, wsHub *services.WebSocketHub, redisClient *redis.Client, workforce *services.WorkforceService, sessions *services.SessionService) *DeviceHandler {
	return &DeviceHandler{repo: repo, wsHub: wsHub, redis: redisClient, workforce: workforce, sessions: sessions}
}

// List 获取设备列表（支持多条件筛选和分页）
// List 获取设备列表（支持多条件筛选和分页）
func (h *DeviceHandler) List(c *gin.Context) {
    // 解析分页参数
    page, err := strconv.Atoi(c.DefaultQuery("page", "1"))
    if err != nil || page < 1 {
        page = 1
    }
    
    pageSize, err := strconv.Atoi(c.DefaultQuery("pageSize", "20"))
    if err != nil || pageSize < 1 {
        pageSize = 20
    }
    if pageSize > 100 {
        pageSize = 100
    }
    
    // 筛选参数
    status := c.Query("status")                    // 审核状态: pending, approved
    employeeSearch := c.Query("employeeSearch")    // 员工搜索（姓名/工号/职位）
    deviceStatus := c.Query("deviceStatus")        // 设备状态: pending, approved_online, approved_offline
    keyword := c.Query("keyword")                  // 设备名称搜索

    // ✅ 使用结构体参数
    opts := services.DeviceListOptions{
        Page:           page,
        PageSize:       pageSize,
        Status:         status,
        EmployeeSearch: employeeSearch,
        DeviceStatus:   deviceStatus,
        Keyword:        keyword,
    }

    devices, total, err := h.repo.List(c.Request.Context(), opts)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // 动态计算在线状态
    for i := range devices {
        devices[i].OnlineStatus = devices[i].GetOnlineStatus()
    }

    models.Send(c, 200, 0, "success", gin.H{
        "items":    devices,
        "total":    total,
        "page":     page,
        "pageSize": pageSize,
    })
}

// Get 获取设备详情
func (h *DeviceHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	device, err := h.repo.Get(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Device not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", device)
}

// Bind 绑定设备到员工
func (h *DeviceHandler) Bind(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	var req struct {
		EmployeeID     string `json:"employeeId" binding:"required"`
		EmployeeName   string `json:"employeeName"`
		EmployeeNumber string `json:"employeeNumber"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: employeeId required")
		return
	}

	if err := h.repo.Bind(c.Request.Context(), id, req.EmployeeID, req.EmployeeName, req.EmployeeNumber); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// 广播设备状态变更
	h.wsHub.BroadcastToAdmin(gin.H{
		"type":       "device_status",
		"deviceId":   id.String(),
		"status":     "bound",
		"employeeId": req.EmployeeID,
		"timestamp":  models.FormatUTC(models.UTCNow()),
	})

	models.Send(c, 200, 0, "Device bound successfully", nil)
}

// Unbind 解绑设备
func (h *DeviceHandler) Unbind(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	if err := h.repo.Unbind(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// 广播设备状态变更
	h.wsHub.BroadcastToAdmin(gin.H{
		"type":      "device_status",
		"deviceId":  id.String(),
		"status":    "unbound",
		"timestamp": models.FormatUTC(models.UTCNow()),
	})

	models.Send(c, 200, 0, "Device unbound successfully", nil)
}

// ForceOffline 撤销设备 Token 并强制下线
func (h *DeviceHandler) ForceOffline(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	if _, err := h.repo.Get(c.Request.Context(), id); err != nil {
		models.SendError(c, 404, 2001, "Device not found")
		return
	}

	if err := services.RevokeDeviceSessions(c.Request.Context(), h.repo, h.sessions, id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	h.wsHub.ForceDisconnectAgent(id.String(), "admin_force_offline")

	h.wsHub.BroadcastToAdmin(gin.H{
		"type":      "device_status",
		"deviceId":  id.String(),
		"status":    "force_offline",
		"timestamp": models.FormatUTC(models.UTCNow()),
	})

	Log(c, "UPDATE", "DEVICE", fmt.Sprintf("强制下线设备 %s", id), id.String(), id.String())
	models.Send(c, 200, 0, "Device forced offline", nil)
}

// UpdateStatus 更新设备审核状态
func (h *DeviceHandler) UpdateStatus(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	var req struct {
		Status string `json:"status" binding:"required,oneof=pending approved rejected"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: status must be pending/approved/rejected")
		return
	}

	if err := h.repo.UpdateStatus(c.Request.Context(), id, req.Status); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	if req.Status == "approved" && h.redis != nil {
		services.ClearDeviceForceOffline(c.Request.Context(), h.repo, id.String())
	}

	if req.Status == "approved" {
		h.wsHub.BroadcastToAgent(id.String(), gin.H{
			"type":      "device_approved",
			"deviceId":  id.String(),
			"status":    "approved",
			"timestamp": models.FormatUTC(models.UTCNow()),
		})
	} else if req.Status == "rejected" {
		h.wsHub.BroadcastToAgent(id.String(), gin.H{
			"type":      "device_rejected",
			"deviceId":  id.String(),
			"status":    "rejected",
			"timestamp": models.FormatUTC(models.UTCNow()),
		})
	}

	models.Send(c, 200, 0, "Status updated", nil)
}

// OnlineStats 获取在线统计
func (h *DeviceHandler) OnlineStats(c *gin.Context) {
	online, offline, err := h.repo.GetOnlineStats(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"online":  online,
		"offline": offline,
		"total":   online + offline,
	})
}

// resolveNewDeviceStatus 仅用于首次出现的未知设备：已信任来源自动通过，其余待审核。
func resolveNewDeviceStatus(
	registrationSecretEnabled, registrationSecretOK, requireManualApproval bool,
	employeeName, employeeNumber string,
	inviteResult *services.InviteValidationResult,
) string {
	if inviteResult != nil {
		return "approved"
	}
	if registrationSecretEnabled && registrationSecretOK {
		return "approved"
	}
	if strings.TrimSpace(employeeName) == "" && strings.TrimSpace(employeeNumber) == "" && !requireManualApproval {
		return "approved"
	}
	return "pending"
}

// Register 设备注册
func (h *DeviceHandler) Register(c *gin.Context) {
	registrationSecret := strings.TrimSpace(os.Getenv("DEVICE_REGISTRATION_SECRET"))
	registrationSecretEnabled := registrationSecret != ""
	registrationSecretOK := !registrationSecretEnabled ||
		strings.TrimSpace(c.GetHeader("X-Registration-Secret")) == registrationSecret
	if registrationSecretEnabled && !registrationSecretOK {
		models.SendError(c, 403, 1003, "Invalid registration secret")
		return
	}
	requireManualApproval := os.Getenv("DEVICE_REQUIRE_MANUAL_APPROVAL") == "true"

	var req struct {
		DeviceId     string            `json:"deviceId" binding:"required"`
		Hostname     string            `json:"hostname"`
		OsVersion    string            `json:"osVersion"`
		AgentVersion string            `json:"agentVersion"`
		Fingerprint  map[string]string `json:"fingerprint"`
		PublicKey    string            `json:"publicKey"`
		InviteCode   string            `json:"inviteCode"`
		Employee *struct {
			Name           string `json:"name"`
			EmployeeNumber string `json:"employeeNumber"`
		} `json:"employee,omitempty"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: deviceId required")
		return
	}

	existing, _ := h.repo.GetByDeviceId(c.Request.Context(), req.DeviceId)
	var deviceID uuid.UUID
	var isNew bool

	var inviteResult *services.InviteValidationResult
	if strings.TrimSpace(req.InviteCode) != "" && h.workforce != nil {
		var err error
		inviteResult, err = h.workforce.ValidateInviteCode(c.Request.Context(), req.InviteCode)
		if err != nil {
			switch {
			case errors.Is(err, services.ErrInviteNotFound):
				models.SendError(c, 400, 1001, "Invalid invite code")
			case errors.Is(err, services.ErrInviteExpired):
				models.SendError(c, 400, 1001, "Invite code expired")
			case errors.Is(err, services.ErrInviteUsed):
				models.SendError(c, 400, 1001, "Invite code already used")
			case errors.Is(err, services.ErrInviteRevoked):
				models.SendError(c, 400, 1001, "Invite code revoked")
			default:
				models.SendError(c, 500, 5000, err.Error())
			}
			return
		}
	}

	// ✅ 提取员工信息
	var employeeID, employeeName, employeeNumber, employeePosition string
	if inviteResult != nil {
		employeeName = inviteResult.EmployeeName
		employeeNumber = inviteResult.EmployeeNumber
		employeePosition = inviteResult.Position
		if employeeNumber != "" {
			employeeID = employeeNumber
		} else {
			employeeID = inviteResult.EmployeeID.String()
		}
	} else if req.Employee != nil {
		employeeName = req.Employee.Name
		employeeNumber = req.Employee.EmployeeNumber
		// 生成员工ID（可以使用工号或者UUID）
		if employeeNumber != "" {
			employeeID = employeeNumber
		} else {
			employeeID = uuid.New().String()
		}
	}

	var deviceStatus string
	if existing != nil {
		deviceStatus = existing.Status
		if inviteResult != nil {
			deviceStatus = "approved"
		}
	} else {
		deviceStatus = resolveNewDeviceStatus(
			registrationSecretEnabled, registrationSecretOK, requireManualApproval,
			employeeName, employeeNumber, inviteResult,
		)
	}

	if existing == nil {
		boundAt := models.UTCNow()
		var err error
		// 生成 device secret（32 字节随机 hex）
		secretBytes := make([]byte, 32)
		if _, err := rand.Read(secretBytes); err != nil {
			models.SendError(c, 500, 5000, "failed to generate device secret")
			return
		}
		secretHex := hex.EncodeToString(secretBytes)

		deviceID, err = h.repo.Create(c.Request.Context(), &models.Device{
			DeviceFingerprint: req.DeviceId,
			Hostname:          req.Hostname,
			OSVersion:         req.OsVersion,
			AgentVersion:      req.AgentVersion,
			EmployeeID:        employeeID,
			EmployeeName:      employeeName,
			EmployeeNumber:    employeeNumber,
			Position:          employeePosition,
			Status:            deviceStatus,
			BoundAt:           &boundAt,
			DeviceSecret:      secretHex,
		})
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		isNew = true
	} else {
		deviceID = existing.ID
		if err := h.repo.UpdateInfo(c.Request.Context(), deviceID, req.Hostname, req.OsVersion, req.AgentVersion); err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}

		// 如果已有设备但未配置 device secret，则生成并持久化
		if strings.TrimSpace(existing.DeviceSecret) == "" {
			b := make([]byte, 32)
			if _, err := rand.Read(b); err == nil {
				secretHex := hex.EncodeToString(b)
				_ = h.repo.UpdateSecret(c.Request.Context(), deviceID, secretHex)
			}
		}
		// ✅ 更新员工信息
		if employeeName != "" || employeeNumber != "" {
			if err := h.repo.UpdateEmployeeInfo(c.Request.Context(), deviceID, employeeID, employeeName, employeeNumber, employeePosition); err != nil {
				models.SendError(c, 500, 5000, err.Error())
				return
			}
		}
		if inviteResult != nil {
			if err := h.repo.UpdateStatus(c.Request.Context(), deviceID, "approved"); err != nil {
				models.SendError(c, 500, 5000, err.Error())
				return
			}
		}
		// 更新最后在线时间
		deviceIDCopy := deviceID
		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			_ = h.repo.UpdateLastSeen(ctx, deviceIDCopy)
		}()
	}

	if inviteResult != nil && h.workforce != nil {
		bound, err := h.workforce.EmployeeBoundToOtherDevice(c.Request.Context(), inviteResult.EmployeeID, deviceID)
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		if bound {
			models.SendError(c, 409, 1004, "Employee already active on another device")
			return
		}
	}

	if services.IsDeviceForceOfflineBlocked(c.Request.Context(), h.repo, deviceID.String()) {
		models.SendError(c, 403, 1003, "Device session has been revoked by administrator")
		return
	}

	// 生成设备 token
	clientIP := services.ClientIPFromContext(c.GetHeader("X-Forwarded-For"), c.ClientIP())
	userAgent := c.GetHeader("User-Agent")
	sessionExpires := models.UTCNow().Add(deviceRefreshTokenTTL)
	tokenExpiresAt := models.UTCNow().Add(7 * 24 * time.Hour)

	if h.sessions == nil {
		models.SendError(c, 500, 5000, "Session service unavailable")
		return
	}
	sess, sessErr := h.sessions.CreateSession(
		c.Request.Context(),
		services.SessionSubjectDevice,
		deviceID,
		sessionExpires,
		clientIP,
		userAgent,
	)
	if sessErr != nil {
		log.Printf("Register failed: session create error for device %s: %v", deviceID, sessErr)
		models.SendError(c, 500, 5000, "Failed to create device session")
		return
	}
	sessionID := sess.ID.String()

	token := mustSignSessionJWT(c, sessionID, tokenExpiresAt)
	if token == "" {
		models.SendError(c, 500, 5000, "Token generation failed")
		return
	}
	refreshToken := uuid.New().String()

	if h.redis == nil || h.sessions == nil {
		models.SendError(c, 500, 5000, "Refresh token store unavailable")
		return
	}

	if err := h.bindDeviceRefresh(c.Request.Context(), refreshToken, sessionID, deviceID.String()); err != nil {
		log.Printf("Failed to store device refresh token: %v", err)
		models.SendError(c, 500, 5000, "Failed to store refresh token")
		return
	}
	if err := services.IndexSessionRefreshToken(c.Request.Context(), h.redis, services.SessionSubjectDevice, deviceID.String(), refreshToken, services.RefreshTokenTTL()); err != nil {
		log.Printf("Failed to index device refresh token: %v", err)
	}

	if inviteResult != nil && h.workforce != nil {
		if err := h.workforce.BindDeviceToEmployee(c.Request.Context(), deviceID, inviteResult.EmployeeID,
			inviteResult.EmployeeNumber, inviteResult.EmployeeName, inviteResult.Position, inviteResult.UserID); err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		if err := h.workforce.ConsumeInviteCode(c.Request.Context(), inviteResult.InviteID, deviceID); err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
	}

	// 广播新设备注册
	if isNew {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type":     "device_registered",
			"deviceId": deviceID.String(),
			"hostname": req.Hostname,
			"employee": gin.H{
				"name":   employeeName,
				"number": employeeNumber,
			},
			"timestamp": models.FormatUTC(models.UTCNow()),
		})
	}

	// 返回 deviceSecret 给客户端（新注册或已存在设备都返回）
	var respSecret string
	var respStatus string
	if d, err := h.repo.Get(c.Request.Context(), deviceID); err == nil && d != nil {
		respSecret = d.DeviceSecret
		respStatus = d.Status
	}

	models.Send(c, 200, 0, "success", gin.H{
		"deviceId":     deviceID.String(),
		"deviceSecret": respSecret,
		"status":       respStatus,
		"token":        token,
		"refreshToken": refreshToken,
		"expiresAt":    models.FormatUTC(tokenExpiresAt),
	})
}

// Refresh 使用设备 refresh token 轮换访问令牌
func (h *DeviceHandler) Refresh(c *gin.Context) {
	var req struct {
		RefreshToken string `json:"refreshToken"`
		DeviceId     string `json:"deviceId"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	req.RefreshToken = strings.TrimSpace(req.RefreshToken)
	req.DeviceId = strings.TrimSpace(req.DeviceId)
	if req.RefreshToken == "" || req.DeviceId == "" {
		models.SendError(c, 400, 1001, "refreshToken and deviceId are required")
		return
	}

	if h.redis == nil || h.sessions == nil {
		models.SendError(c, 500, 5000, "Refresh token store unavailable")
		return
	}

	ctx := c.Request.Context()
	sessionID, err := h.sessions.LookupSessionByRefresh(ctx, req.RefreshToken)
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid refresh token")
		return
	}

	sess, err := h.sessions.ValidateActiveSession(ctx, sessionID)
	if err != nil || sess.SubjectType != services.SessionSubjectDevice {
		models.SendError(c, 401, 1002, "Device session has been revoked")
		return
	}

	deviceID := sess.SubjectID.String()
	if !strings.EqualFold(deviceID, req.DeviceId) {
		models.SendError(c, 401, 1002, "Device ID mismatch")
		return
	}

	if services.IsDeviceForceOfflineBlocked(ctx, h.repo, deviceID) {
		models.SendError(c, 401, 1002, "Device session has been revoked")
		return
	}

	parsedDeviceID, err := uuid.Parse(deviceID)
	if err != nil || parsedDeviceID != sess.SubjectID {
		models.SendError(c, 401, 1002, "Invalid device ID")
		return
	}

	if _, err := h.repo.Get(ctx, parsedDeviceID); err != nil {
		models.SendError(c, 401, 1002, "Device not found")
		return
	}

	expiresAt := models.UTCNow().Add(services.DeviceAccessTokenTTL())
	token := mustSignSessionJWT(c, sessionID, expiresAt)
	if token == "" {
		models.SendError(c, 500, 5000, "Token generation failed")
		return
	}

	newRefreshToken := uuid.New().String()
	h.sessions.DeleteRefreshBinding(ctx, req.RefreshToken)
	if err := h.bindDeviceRefresh(ctx, newRefreshToken, sessionID, deviceID); err != nil {
		models.SendInternalError(c, err)
		return
	}
	_ = services.IndexSessionRefreshToken(ctx, h.redis, services.SessionSubjectDevice, deviceID, newRefreshToken, services.RefreshTokenTTL())

	models.Send(c, 200, 0, "success", gin.H{
		"token":        token,
		"refreshToken": newRefreshToken,
		"expiresAt":    models.FormatUTC(expiresAt),
	})
}

// Verify 验证设备（需要设备认证）
func (h *DeviceHandler) Verify(c *gin.Context) {
	// 从认证中间件获取设备 ID
	deviceIDFromToken := c.GetString("deviceID")
	if deviceIDFromToken == "" {
		models.SendError(c, 401, 1002, "Device not authenticated")
		return
	}

	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	// 验证 URL 中的设备 ID 与 token 中的一致
	if deviceIDFromToken != id.String() {
		models.SendError(c, 403, 1003, "Device ID mismatch")
		return
	}

	device, err := h.repo.Get(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Device not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// 异步更新最后在线时间
	go func() {
		_ = h.repo.UpdateLastSeen(c.Request.Context(), id)
	}()

	// ✅ 修复：处理指针类型的时间字段
	boundAtStr := ""
	if device.BoundAt != nil {
		boundAtStr = models.FormatUTC(*device.BoundAt)
	}

	models.Send(c, 200, 0, "verified", gin.H{
		"deviceId":   device.ID.String(),
		"status":     device.Status,
		"employeeId": device.EmployeeID,
		"boundAt":    boundAtStr,
	})
}

// ReportInfo 上报设备信息（支持 UUID 或 device_fingerprint）
func (h *DeviceHandler) ReportInfo(c *gin.Context) {
	var req struct {
		DeviceId       string `json:"deviceId" binding:"required"`
		Hostname       string `json:"hostname"`
		OsVersion      string `json:"osVersion"`
		AgentVersion   string `json:"agentVersion"`
		ProcessorCount int    `json:"processorCount"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	var device *models.Device
	var err error

	if id, parseErr := uuid.Parse(req.DeviceId); parseErr == nil {
		device, err = h.repo.Get(c.Request.Context(), id)
	} else {
		device, err = h.repo.GetByDeviceId(c.Request.Context(), req.DeviceId)
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if device == nil {
		models.SendError(c, 404, 2001, "Device not found")
		return
	}

	if !canReportDeviceInfo(c, device, req.DeviceId) {
		models.SendError(c, 403, 1003, "Permission denied")
		return
	}

	if err := h.repo.UpdateInfo(c.Request.Context(), device.ID, req.Hostname, req.OsVersion, req.AgentVersion); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	go func() {
		_ = h.repo.UpdateLastSeen(c.Request.Context(), device.ID)
	}()

	models.Send(c, 200, 0, "info reported", nil)
}

func canReportDeviceInfo(c *gin.Context, device *models.Device, requestedDeviceID string) bool {
	tokenDeviceID := c.GetString("deviceID")
	if tokenDeviceID != "" {
		return deviceMatchesIdentifier(device, tokenDeviceID) &&
			deviceMatchesIdentifier(device, requestedDeviceID)
	}

	userID := c.GetString("userID")
	if userID == "" {
		return false
	}
	if c.GetString("role") == "admin" {
		return true
	}
	perms, ok := c.Get("permissions")
	if !ok {
		return false
	}
	userPermissions, ok := perms.([]string)
	if !ok {
		return false
	}
	for _, p := range userPermissions {
		if p == "device:manage" {
			return true
		}
	}
	return false
}

func deviceMatchesIdentifier(device *models.Device, identifier string) bool {
	if identifier == "" || device == nil {
		return false
	}
	if device.ID.String() == identifier {
		return true
	}
	return device.DeviceFingerprint == identifier
}

// UpdateEmployee 更新设备员工信息
func (h *DeviceHandler) UpdateEmployee(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	var req struct {
		EmployeeID     string `json:"employeeId"`
		EmployeeName   string `json:"employeeName"`
		EmployeeNumber string `json:"employeeNumber"`
		Position       string `json:"position"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request payload")
		return
	}

	if err := h.repo.UpdateEmployeeInfo(c.Request.Context(), id, req.EmployeeID, req.EmployeeName, req.EmployeeNumber, req.Position); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "Employee information updated", nil)
}

func (h *DeviceHandler) Heartbeat(c *gin.Context) {
	deviceIDFromToken := c.GetString("deviceID")
	if deviceIDFromToken == "" {
		models.SendError(c, 401, 1002, "Device not authenticated")
		return
	}

	id, err := uuid.Parse(deviceIDFromToken)
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	if err := h.repo.UpdateLastSeen(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "pong", nil)
}

// HandleAgentWebSocket Agent WebSocket 连接
func (h *DeviceHandler) HandleAgentWebSocket(c *gin.Context) {
    deviceIDFromToken := c.GetString("deviceID")
    if deviceIDFromToken == "" {
        models.SendError(c, 401, 1002, "Device not authenticated")
        return
    }
    if !h.wsHub.CanAcceptConnection() {
        c.JSON(http.StatusServiceUnavailable, gin.H{"code": 5003, "message": "WebSocket connection limit reached"})
        return
    }
    h.wsHub.HandleAgentWithDeviceID(c, deviceIDFromToken)
}

// HandleAdminWebSocket Admin WebSocket 连接
func (h *DeviceHandler) HandleAdminWebSocket(c *gin.Context) {
	if !middleware.UserHasPermission(c, "device:view") {
		c.JSON(http.StatusForbidden, gin.H{"code": 1003, "message": "Permission denied: device:view required"})
		return
	}
	if !h.wsHub.CanAcceptConnection() {
		c.JSON(http.StatusServiceUnavailable, gin.H{"code": 5003, "message": "WebSocket connection limit reached"})
		return
	}
	h.wsHub.HandleAdmin(c)
}

// ========== 辅助函数 ==========

func mustSignSessionJWT(c *gin.Context, sessionID string, expiresAt time.Time) string {
	token, err := services.SignSessionJWT(sessionID, expiresAt)
	if err != nil {
		log.Printf("SignSessionJWT failed: %v", err)
		return ""
	}
	return token
}

func (h *DeviceHandler) bindDeviceRefresh(ctx context.Context, refreshToken, sessionID, deviceID string) error {
	if err := h.sessions.BindRefreshToken(ctx, refreshToken, sessionID, services.RefreshTokenTTL()); err != nil {
		return err
	}
	return services.IndexSessionRefreshToken(ctx, h.redis, services.SessionSubjectDevice, deviceID, refreshToken, services.RefreshTokenTTL())
}

// ExportEmployees 导出员工信息
func (h *DeviceHandler) ExportEmployees(c *gin.Context) {
	// ✅ 修复：使用结构体参数调用新的 List 方法
	opts := services.DeviceListOptions{
		Page:     1,
		PageSize: 10000,
		Status:   "", // 不过滤审核状态
		// 其他筛选条件为空，表示不过滤
	}

	devices, _, err := h.repo.List(c.Request.Context(), opts)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	var builder strings.Builder
	builder.WriteString("设备ID,设备指纹,员工ID,员工姓名,工号,主机名,操作系统,状态,绑定时间,最后在线时间,注册时间\n")

	for _, d := range devices {
		boundAt := ""
		if d.BoundAt != nil {
			boundAt = d.BoundAt.Format(time.RFC3339)
		}
		lastSeen := ""
		if d.LastSeenAt != nil {
			lastSeen = d.LastSeenAt.Format(time.RFC3339)
		}
		builder.WriteString(fmt.Sprintf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
			d.ID.String(), d.DeviceFingerprint, d.EmployeeID, d.EmployeeName, d.EmployeeNumber,
			d.Hostname, d.OSVersion, d.Status, boundAt, lastSeen, d.CreatedAt.Format(time.RFC3339)))
	}

	c.Header("Content-Type", "text/csv; charset=utf-8")
	c.Header("Content-Disposition", "attachment; filename=employees.csv")
	c.String(200, builder.String())
}
package integration_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/google/uuid"

	"enterprise-agent/backend/services"
)

func TestValidateActiveSessionAfterRevoke(t *testing.T) {
	defer func() {
		if r := recover(); r != nil {
			t.Skipf("Skipping test because database is unavailable: %v", r)
		}
	}()

	db := services.NewDatabase()
	if db == nil {
		t.Fatal("expected database handle")
	}
	defer db.Close()

	svc := services.NewSessionService(db, nil)
	ctx := context.Background()
	subjectID := uuid.New()
	expiresAt := time.Now().UTC().Add(time.Hour)

	sess, err := svc.CreateSession(ctx, services.SessionSubjectDevice, subjectID, expiresAt, "127.0.0.1", "integration-test")
	if err != nil {
		t.Fatalf("create session: %v", err)
	}

	if _, err := svc.ValidateActiveSession(ctx, sess.ID.String()); err != nil {
		t.Fatalf("expected active session: %v", err)
	}

	if err := svc.RevokeSession(ctx, sess.ID.String(), "logout"); err != nil {
		t.Fatalf("revoke session: %v", err)
	}

	_, err = svc.ValidateActiveSession(ctx, sess.ID.String())
	if !errors.Is(err, services.ErrSessionRevoked) {
		t.Fatalf("expected ErrSessionRevoked after revoke, got %v", err)
	}
}

func TestIsProductionEnv(t *testing.T) {
	t.Setenv("ENV", "production")
	if !services.IsProductionEnv() {
		t.Fatal("expected production env")
	}
	t.Setenv("ENV", "development")
	if services.IsProductionEnv() {
		t.Fatal("expected non-production env")
	}
}

func TestWSTicketRequiredProductionDefault(t *testing.T) {
	t.Setenv("WS_TICKET_REQUIRED", "")
	t.Setenv("ENV", "production")

	if !services.WSTicketRequired() {
		t.Fatal("expected WS ticket required when ENV=production and WS_TICKET_REQUIRED unset")
	}
}

func TestWSTicketRequiredExplicitOverride(t *testing.T) {
	t.Setenv("ENV", "production")
	t.Setenv("WS_TICKET_REQUIRED", "false")

	if services.WSTicketRequired() {
		t.Fatal("expected explicit WS_TICKET_REQUIRED=false to disable requirement")
	}
}

func TestWSTicketRequiredExplicitTrue(t *testing.T) {
	t.Setenv("ENV", "development")
	t.Setenv("WS_TICKET_REQUIRED", "true")

	if !services.WSTicketRequired() {
		t.Fatal("expected WS_TICKET_REQUIRED=true to enable requirement in development")
	}
}

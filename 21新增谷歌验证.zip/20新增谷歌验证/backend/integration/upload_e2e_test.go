package integration_test

import (
	"bytes"
	"context"
	"io"
	"os"
	"testing"
	"time"

	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/services"
)

func testRedis(t *testing.T) *redis.Client {
	t.Helper()
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "127.0.0.1:6379"
	}
	client := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: os.Getenv("REDIS_PASSWORD"),
		DB:       13,
	})
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		t.Skipf("redis unavailable at %s: %v", addr, err)
	}
	return client
}

func TestUploadManifestChunkMergeE2E(t *testing.T) {
	client := testRedis(t)
	defer client.Close()

	root := t.TempDir()
	minio := services.NewLocalMinIOForTests(root)
	chunks := services.NewUploadChunkStore(minio)
	manifest := services.NewUploadManifestStore(client, chunks)
	ctx := context.Background()

	uploadID := "integration-upload-" + time.Now().Format("150405.000")
	deviceID := "device-integration"

	t.Cleanup(func() {
		_ = manifest.Delete(context.Background(), uploadID)
		_ = chunks.DeleteAll(context.Background(), uploadID)
	})

	if err := manifest.Init(ctx, services.UploadManifest{
		UploadID:    uploadID,
		DeviceID:    deviceID,
		FileName:    "sample.webp",
		FileType:    "screenshot",
		TotalChunks: 3,
	}); err != nil {
		t.Fatalf("init manifest: %v", err)
	}

	parts := [][]byte{[]byte("part-a-"), []byte("part-b-"), []byte("part-c")}
	for i, part := range parts {
		if err := chunks.Save(ctx, uploadID, i, part); err != nil {
			t.Fatalf("save chunk %d: %v", i, err)
		}
		if count, err := manifest.RecordChunk(ctx, uploadID, i, int64(len(part)), "chk"); err != nil || count != i+1 {
			t.Fatalf("record chunk %d: count=%d err=%v", i, count, err)
		}
	}

	if _, err := manifest.Verify(ctx, uploadID, deviceID, 3, map[int]string{0: "chk", 1: "chk", 2: "chk"}); err != nil {
		t.Fatalf("verify: %v", err)
	}

	merge := chunks.MergeReader(ctx, uploadID, 3)
	defer merge.Close()
	var buf bytes.Buffer
	if _, err := io.Copy(&buf, merge); err != nil {
		t.Fatalf("merge: %v", err)
	}
	if buf.String() != "part-a-part-b-part-c" {
		t.Fatalf("unexpected merged data: %q", buf.String())
	}
}

package integration_test

import (
	"context"
	"errors"
	"os"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/services"
)

func testAttackChainRedis(t *testing.T) *redis.Client {
	t.Helper()
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "127.0.0.1:6379"
	}
	client := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: os.Getenv("REDIS_PASSWORD"),
		DB:       11,
	})
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		t.Skipf("redis unavailable: %v", err)
	}
	return client
}

func TestAttackChainRevokeBlocksSessionUploadAndMedia(t *testing.T) {
	defer func() {
		if r := recover(); r != nil {
			t.Skipf("database unavailable: %v", r)
		}
	}()

	db := services.NewDatabase()
	if db == nil {
		t.Fatal("database required")
	}
	defer db.Close()

	redisClient := testAttackChainRedis(t)
	defer redisClient.Close()

	ctx := context.Background()
	svc := services.NewSessionService(db, redisClient)
	mediaSvc := services.NewMediaTokenService(redisClient, svc)
	expires := time.Now().UTC().Add(time.Hour)

	deviceSubject := uuid.New()
	deviceSess, err := svc.CreateSession(ctx, services.SessionSubjectDevice, deviceSubject, expires, "127.0.0.1", "attack-test")
	if err != nil {
		t.Fatalf("create device session: %v", err)
	}

	userSubject := uuid.New()
	userSess, err := svc.CreateSession(ctx, services.SessionSubjectUser, userSubject, expires, "127.0.0.1", "attack-test")
	if err != nil {
		t.Fatalf("create user session: %v", err)
	}

	recID := "rec-attack-" + uuid.NewString()
	token, _, err := mediaSvc.Issue(ctx, services.MediaAccessGrant{
		SessionID:    userSess.ID.String(),
		UserID:       userSubject.String(),
		Username:     "attack-user",
		ResourceType: "recording",
		ResourceID:   recID,
		Action:       "download",
	})
	if err != nil {
		t.Fatalf("issue media token: %v", err)
	}

	if _, err := svc.ValidateActiveSession(ctx, deviceSess.ID.String()); err != nil {
		t.Fatalf("device session should be active: %v", err)
	}

	if err := svc.RevokeSession(ctx, deviceSess.ID.String(), "attack_test"); err != nil {
		t.Fatalf("revoke device session: %v", err)
	}
	if err := svc.RevokeSession(ctx, userSess.ID.String(), "attack_test"); err != nil {
		t.Fatalf("revoke user session: %v", err)
	}

	if _, err := svc.ValidateActiveSession(ctx, deviceSess.ID.String()); !errors.Is(err, services.ErrSessionRevoked) {
		t.Fatalf("device session should be revoked, got %v", err)
	}
	if _, err := svc.ValidateActiveSession(ctx, userSess.ID.String()); !errors.Is(err, services.ErrSessionRevoked) {
		t.Fatalf("user session should be revoked, got %v", err)
	}

	if _, err := mediaSvc.Validate(ctx, token, "recording", recID, "download"); !errors.Is(err, services.ErrMediaTokenExpired) {
		t.Fatalf("media token should fail after user session revoke, got %v", err)
	}
}

func TestAttackChainWSRevokeDisconnectsBoundConnections(t *testing.T) {
	hub := services.NewWebSocketHub()
	sessionID := uuid.NewString()

	agent := &services.AgentConn{
		DeviceID:  "device-ws-attack",
		SessionID: sessionID,
		Send:      make(chan []byte, 4),
	}
	hub.RegisterAgentForTest(agent)

	admin := services.NewAdminConn(nil)
	admin.SessionID = sessionID
	admin.UserID = "user-ws-attack"
	hub.RegisterAdminForTest(admin)

	hub.DisconnectAgentsBySession(sessionID, "session_revoked")
	hub.DisconnectAdminsBySession(sessionID, "session_revoked")

	if !agent.IsClosed() {
		t.Fatal("agent connection should be closed after session revoke")
	}
	if !admin.IsClosed() {
		t.Fatal("admin connection should be closed after session revoke")
	}
}

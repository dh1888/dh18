// backend/middleware/auth.go — Session SSOT unified authentication

package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// Auth requires an active user session (JWT sid → auth_sessions).
func Auth(_ *redis.Client) gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString := extractToken(c)
		if tokenString == "" {
			models.SendError(c, 401, 1002, "Missing authorization token")
			c.Abort()
			return
		}
		if !authenticateSessionJWT(c, tokenString, true, false) {
			return
		}
		c.Next()
	}
}

// DeviceAuth requires an active device session.
func DeviceAuth(_ *redis.Client) gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString := extractToken(c)
		if tokenString == "" {
			models.SendError(c, 401, 1002, "Missing device token")
			c.Abort()
			return
		}
		if !authenticateSessionJWT(c, tokenString, false, true) {
			return
		}
		c.Next()
	}
}

// UserOrDeviceAuth accepts user or device session.
func UserOrDeviceAuth(_ *redis.Client) gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString := extractToken(c)
		if tokenString == "" {
			models.SendError(c, 401, 1002, "Missing authorization token")
			c.Abort()
			return
		}
		if !authenticateSessionJWT(c, tokenString, false, false) {
			return
		}
		c.Next()
	}
}

func extractToken(c *gin.Context) string {
	authHeader := c.GetHeader("Authorization")
	if authHeader != "" {
		token := strings.TrimPrefix(authHeader, "Bearer ")
		if token != authHeader {
			return strings.TrimSpace(token)
		}
	}
	if services.IsProductionEnv() {
		return ""
	}
	if token := strings.TrimSpace(c.Query("token")); token != "" {
		return token
	}
	if token, err := c.Cookie("token"); err == nil && token != "" {
		return strings.TrimSpace(token)
	}
	return ""
}

func normalizeRoleName(roleName string) string {
	switch strings.TrimSpace(strings.ToLower(roleName)) {
	case "管理员", "admin", "administrator", "超级管理员", "superadmin":
		return "admin"
	case "审计员", "auditor":
		return "auditor"
	case "操作员", "operator", "ops":
		return "operator"
	case "员工", "employee":
		return "employee"
	case "查看员", "viewer":
		return "viewer"
	default:
		return "auditor"
	}
}

// RequirePermission checks permission using DB-backed role (JWT carries no permissions).
func RequirePermission(permission string) gin.HandlerFunc {
	return func(c *gin.Context) {
		userID := c.GetString("userID")
		if userID == "" {
			models.SendError(c, 401, 1002, "User not authenticated")
			c.Abort()
			return
		}

		role := c.GetString("role")
		var perms []string
		if p, exists := c.Get("permissions"); exists {
			if list, ok := p.([]string); ok {
				perms = list
			}
		}
		if dbRole, dbPerms, ok := loadUserAuthFromDB(c.Request.Context(), userID); ok {
			c.Set("role", dbRole)
			c.Set("permissions", dbPerms)
			role = dbRole
			perms = dbPerms
		}

		if checkPermissionList(role, perms, permission) {
			c.Next()
			return
		}
		models.SendError(c, 403, 1003, "Permission denied: "+permission)
		c.Abort()
	}
}

func RequireAnyPermission(permissions ...string) gin.HandlerFunc {
	return func(c *gin.Context) {
		userID := c.GetString("userID")
		if userID == "" {
			models.SendError(c, 401, 1002, "User not authenticated")
			c.Abort()
			return
		}

		role := c.GetString("role")
		var perms []string
		if p, exists := c.Get("permissions"); exists {
			if list, ok := p.([]string); ok {
				perms = list
			}
		}
		if dbRole, dbPerms, ok := loadUserAuthFromDB(c.Request.Context(), userID); ok {
			c.Set("role", dbRole)
			c.Set("permissions", dbPerms)
			role = dbRole
			perms = dbPerms
		}

		if checkAnyPermissionList(role, perms, permissions...) {
			c.Next()
			return
		}
		models.SendError(c, 403, 1003, "Permission denied")
		c.Abort()
	}
}

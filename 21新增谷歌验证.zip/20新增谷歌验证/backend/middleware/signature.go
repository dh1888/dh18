package middleware

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/url"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/security"
	"enterprise-agent/backend/services"
)


var signatureNonceStore *security.DistributedNonceStore

// InitSignatureNonceStore 初始化签名 nonce 防重放缓存
func InitSignatureNonceStore(redisClient *redis.Client) {
	signatureNonceStore = security.NewDistributedNonceStore(redisClient, 10*time.Minute)
}

// CloseSignatureNonceStore 关闭 nonce 缓存
func CloseSignatureNonceStore() {
	if signatureNonceStore != nil {
		_ = signatureNonceStore.Close()
	}
}

// SafetyCheckSignaturePrerequisites 在签名验证前执行安全检查
// 返回 true 表示通过安全检查，false 表示应该拒绝请求
func SafetyCheckSignaturePrerequisites(c *gin.Context, logger interface {
	Warnf(format string, args ...interface{})
	Errorf(format string, args ...interface{})
}) bool {
	// 检查 1: Non-UTF-8 encoding（高风险）
	contentType := c.GetHeader("Content-Type")
	if strings.Contains(contentType, "charset=") {
		if !strings.Contains(strings.ToLower(contentType), "charset=utf-8") &&
			!strings.Contains(strings.ToLower(contentType), "charset=utf8") {
			logger.Errorf("Non-UTF-8 encoding detected: %s (will reject)", contentType)
			return false // 拒绝非 UTF-8
		}
	}

	// 检查 2: Path modification by proxy（记录但不拒绝）
	if originalURI := c.GetHeader("X-Original-URI"); originalURI != "" {
		if originalURI != c.Request.RequestURI {
			logger.Warnf("Path potentially modified by proxy: %s -> %s",
				originalURI, c.Request.RequestURI)
		}
	}

	// 检查 3: Forwarded header（记录代理链）
	if forwarded := c.GetHeader("X-Forwarded-For"); forwarded != "" {
		logger.Warnf("Request forwarded through proxy chain: %s", forwarded)
	}

	// 检查 4: Empty body for POST/PUT（警告但不拒绝）
	if (c.Request.Method == "POST" || c.Request.Method == "PUT") &&
		c.Request.ContentLength <= 0 {
		logger.Warnf("Empty or missing Content-Length for %s request", c.Request.Method)
	}

	return true
}

// ValidateBodyHashConsistency 验证 body 是否被修改
// 在验证前后计算 hash，确保一致
func ValidateBodyHashConsistency(bodyBefore, bodyAfter []byte, logger interface {
	Errorf(format string, args ...interface{})
}) bool {
	if len(bodyBefore) != len(bodyAfter) {
		logger.Errorf("Body size changed: %d -> %d bytes (potential middleware tampering)",
			len(bodyBefore), len(bodyAfter))
		return false
	}

	// 简单字节对比（不计算 hash，节省 CPU）
	for i := 0; i < len(bodyBefore); i++ {
		if bodyBefore[i] != bodyAfter[i] {
			logger.Errorf("Body content changed at byte %d (potential middleware tampering)", i)
			return false
		}
	}

	return true
}

// SignatureDriftDetector 漂移检测器
type SignatureDriftDetector struct {
	logger interface {
		Infof(format string, args ...interface{})
		Errorf(format string, args ...interface{})
	}
}

// NewSignatureDriftDetector 创建新的漂移检测器
func NewSignatureDriftDetector(logger interface {
	Infof(format string, args ...interface{})
	Errorf(format string, args ...interface{})
}) *SignatureDriftDetector {
	return &SignatureDriftDetector{logger: logger}
}

// DetectV1Drift 检测 v1 签名是否漂移
// 通过比较 Go 当前实现与冻结的 test vectors
func (d *SignatureDriftDetector) DetectV1Drift() (hasDrift bool, diffs []string) {
	vectors := security.GetV1TestVectors()
	
	// 只检查前 3 个已验证的向量
	expectedCSharpOutputs := map[string]string{
		"POST upload chunk with JSON":      "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
		"POST upload complete":             "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
		"GET device verify with empty body": "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d",
	}
	
	for i, vec := range vectors {
		if i >= 3 {
			break // 只检查前 3 个
		}
		
		computed := security.ComputeSignatureV1(
			vec.Timestamp, vec.Method, vec.Path, []byte(vec.Body), vec.DeviceSecret,
		)
		expected := expectedCSharpOutputs[vec.Name]
		
		if computed != expected {
			hasDrift = true
			diffs = append(diffs, fmt.Sprintf(
				"DRIFT DETECTED: %s\n  Expected (C#): %s\n  Got (Go):      %s",
				vec.Name, expected, computed,
			))
		}
	}
	
	return
}

// RunOnStartup 在应用启动时执行漂移检测
// 如果检测到漂移，将阻止应用启动
func (d *SignatureDriftDetector) RunOnStartup() error {
	d.logger.Infof("[STARTUP] Running v1 signature drift detection...")
	
	hasDrift, diffs := d.DetectV1Drift()
	
	if hasDrift {
		errMsg := fmt.Sprintf("CRITICAL: Signature drift detected on %d test vectors:\n%s",
			len(diffs), strings.Join(diffs, "\n"))
		d.logger.Errorf(errMsg)
		return fmt.Errorf("%s", errMsg)
	}
	
	d.logger.Infof("[STARTUP] ✓ Signature drift detection PASSED (3/3 vectors match)")
	return nil
}

// CheckPeriodicDrift 周期性检查漂移（可在后台运行）
func (d *SignatureDriftDetector) CheckPeriodicDrift() {
	hasDrift, diffs := d.DetectV1Drift()
	
	if hasDrift {
		d.logger.Errorf("[PERIODIC] ALERT: Signature drift detected:\n%s",
			strings.Join(diffs, "\n"))
		// 可选：发送告警到监控系统
	}
}

// SignatureMetrics tracks signature verification metrics
type SignatureMetrics struct {
	SuccessCount         int64     // 签名验证成功计数
	FailureCount         int64     // 签名验证失败计数
	MissingSecretCount   int64     // device_secret 缺失或为空计数
	TimestampRejectedCount int64   // 时间戳超过 ±5 分钟计数
	InvalidFormatCount   int64     // 无效格式计数
	LastUpdateTime       time.Time // 最后更新时间
	mu                   sync.RWMutex
}

var globalSignatureMetrics = &SignatureMetrics{
	LastUpdateTime: time.Now(),
}

// RecordSuccess 记录验证成功
func RecordSignatureSuccess() {
	atomic.AddInt64(&globalSignatureMetrics.SuccessCount, 1)
	globalSignatureMetrics.mu.Lock()
	globalSignatureMetrics.LastUpdateTime = time.Now()
	globalSignatureMetrics.mu.Unlock()
}

// RecordFailure 记录验证失败
func RecordSignatureFailure(reason string) {
	atomic.AddInt64(&globalSignatureMetrics.FailureCount, 1)
	globalSignatureMetrics.mu.Lock()
	globalSignatureMetrics.LastUpdateTime = time.Now()
	globalSignatureMetrics.mu.Unlock()
}

// RecordMissingSecret 记录缺失 secret
func RecordMissingSecret() {
	atomic.AddInt64(&globalSignatureMetrics.MissingSecretCount, 1)
}

// RecordTimestampRejected 记录时间戳被拒绝
func RecordTimestampRejected() {
	atomic.AddInt64(&globalSignatureMetrics.TimestampRejectedCount, 1)
}

// RecordInvalidFormat 记录无效格式
func RecordInvalidFormat() {
	atomic.AddInt64(&globalSignatureMetrics.InvalidFormatCount, 1)
}

// GetMetrics 获取当前指标快照
func GetSignatureMetrics() SignatureMetrics {
	globalSignatureMetrics.mu.RLock()
	defer globalSignatureMetrics.mu.RUnlock()
	
	return SignatureMetrics{
		SuccessCount:           atomic.LoadInt64(&globalSignatureMetrics.SuccessCount),
		FailureCount:           atomic.LoadInt64(&globalSignatureMetrics.FailureCount),
		MissingSecretCount:     atomic.LoadInt64(&globalSignatureMetrics.MissingSecretCount),
		TimestampRejectedCount: atomic.LoadInt64(&globalSignatureMetrics.TimestampRejectedCount),
		InvalidFormatCount:     atomic.LoadInt64(&globalSignatureMetrics.InvalidFormatCount),
		LastUpdateTime:         globalSignatureMetrics.LastUpdateTime,
	}
}

// ResetMetrics 重置指标（用于测试）
func ResetSignatureMetrics() {
	atomic.StoreInt64(&globalSignatureMetrics.SuccessCount, 0)
	atomic.StoreInt64(&globalSignatureMetrics.FailureCount, 0)
	atomic.StoreInt64(&globalSignatureMetrics.MissingSecretCount, 0)
	atomic.StoreInt64(&globalSignatureMetrics.TimestampRejectedCount, 0)
	atomic.StoreInt64(&globalSignatureMetrics.InvalidFormatCount, 0)
}

// IsHealthy 检查签名系统是否健康
// 如果失败率 > 5%，视为不健康
func IsSignatureSystemHealthy() bool {
	metrics := GetSignatureMetrics()
	total := metrics.SuccessCount + metrics.FailureCount
	
	if total == 0 {
		return true // 无样本
	}
	
	failureRate := float64(metrics.FailureCount) / float64(total)
	return failureRate < 0.05 // 5% 阈值
}

// VerifyDeviceSignature 使用每设备 device_secret 验证请求签名
// 签名规则： HMACSHA256(timestamp + method + path + bodyHash, deviceSecret)
// Header: X-Device-Id, X-Timestamp, X-Signature
func VerifyDeviceSignature(deviceRepo *services.DeviceRepository, redisClient *redis.Client) gin.HandlerFunc {
    return func(c *gin.Context) {
        // 读取并恢复请求体
        rawBody, _ := io.ReadAll(c.Request.Body)
        c.Request.Body = io.NopCloser(bytes.NewReader(rawBody))

        // 优先使用 Header
        deviceId := strings.TrimSpace(c.GetHeader("X-Device-Id"))
        timestamp := strings.TrimSpace(c.GetHeader("X-Timestamp"))
        signature := strings.TrimSpace(c.GetHeader("X-Signature"))
        nonce := strings.TrimSpace(c.GetHeader("X-Nonce"))

        // 兼容：尝试从 body 中解析 deviceId/timestamp/signature
        if deviceId == "" || timestamp == "" || signature == "" {
            var probe struct {
                DeviceId  string `json:"deviceId"`
                Timestamp string `json:"timestamp"`
                Signature string `json:"signature"`
                Nonce     string `json:"nonce"`
            }
            _ = json.Unmarshal(rawBody, &probe)
            if deviceId == "" {
                deviceId = probe.DeviceId
            }
            if timestamp == "" {
                timestamp = probe.Timestamp
            }
            if signature == "" {
                signature = probe.Signature
            }
            if nonce == "" {
                nonce = probe.Nonce
            }
        }

        if nonce == "" {
            nonce = strings.TrimSpace(c.Query("nonce"))
        }
        if nonce == "" {
            nonce = strings.TrimSpace(c.GetHeader("X-Upload-Nonce"))
        }

        if nonce == "" {
            models.SendError(c, 401, 1002, "missing nonce")
            c.Abort()
            return
        }

        // 不允许缺失签名（已结束兼容放行）
        if signature == "" {
            models.SendError(c, 401, 1002, "missing signature")
            c.Abort()
            return
        }

        if deviceId == "" {
            models.SendError(c, 401, 1002, "missing device id")
            c.Abort()
            return
        }

        // 解析时间戳（RFC3339）并验证 ±300s
        ts, err := time.Parse(time.RFC3339, timestamp)
        if err != nil {
            models.SendError(c, 401, 1002, "invalid timestamp format")
            c.Abort()
            return
        }
        now := time.Now().UTC()
        if now.Sub(ts) > 5*time.Minute || ts.Sub(now) > 5*time.Minute {
            models.SendError(c, 401, 1002, "timestamp expired")
            c.Abort()
            return
        }

        // 获取 device secret（deviceId 可能是 UUID 或 fingerprint）
        var dev *models.Device
        if _, err := uuid.Parse(deviceId); err == nil {
            // UUID 格式
            id, _ := uuid.Parse(deviceId)
            dev, err = deviceRepo.Get(c.Request.Context(), id)
            if err != nil {
                models.SendError(c, 500, 5000, "failed to query device")
                c.Abort()
                return
            }
        } else {
            dev, err = deviceRepo.GetByDeviceId(c.Request.Context(), deviceId)
            if err != nil {
                models.SendError(c, 500, 5000, "failed to query device")
                c.Abort()
                return
            }
        }

        if dev == nil || strings.TrimSpace(dev.DeviceSecret) == "" {
            models.SendError(c, 401, 1002, "device secret not configured")
            c.Abort()
            return
        }

        if strings.ToLower(strings.TrimSpace(dev.Status)) != "approved" {
            models.SendError(c, 403, 1003, "device not approved for upload")
            c.Abort()
            return
        }

        if dev.ID != uuid.Nil && deviceRepo.IsForceOfflined(c.Request.Context(), dev.ID.String()) {
            models.SendError(c, 403, 1003, "device session revoked")
            c.Abort()
            return
        }

        if signatureNonceStore != nil {
            nonceKey := deviceId + ":" + nonce
            if err := signatureNonceStore.CheckAndStore(nonceKey); err != nil {
                if err == security.ErrNonceReused {
                    models.SendError(c, 401, 1002, "nonce already used")
                } else if err == security.ErrNonceUnavailable {
                    models.SendError(c, 503, 5003, "Signature verification temporarily unavailable")
                } else {
                    models.SendError(c, 401, 1002, "invalid nonce")
                }
                c.Abort()
                return
            }
        }

        // 计算 bodyHash
        bodyHash := sha256.Sum256(rawBody)
        bodyHashHex := hex.EncodeToString(bodyHash[:])

        // 计算 path（使用原始路径，不含 host/query）
        path := c.Request.URL.Path
        if u, err := url.PathUnescape(path); err == nil {
            path = u
        }

        message := timestamp + c.Request.Method + path + bodyHashHex

        mac := hmac.New(sha256.New, []byte(dev.DeviceSecret))
        _, _ = mac.Write([]byte(message))
        expected := hex.EncodeToString(mac.Sum(nil))

        if !hmac.Equal([]byte(strings.ToLower(expected)), []byte(strings.ToLower(signature))) {
            models.SendError(c, 401, 1002, "invalid signature")
            c.Abort()
            return
        }

        // Session SSOT：JWT 已认证的 device 必须与签名 device 一致
        if sessionDeviceID := strings.TrimSpace(c.GetString("deviceID")); sessionDeviceID != "" && dev.ID != uuid.Nil {
            if !strings.EqualFold(sessionDeviceID, dev.ID.String()) {
                models.SendError(c, 403, 1003, "device session mismatch")
                c.Abort()
                return
            }
        }

        // 验证通过，设置 deviceID 到 context（UUID 字符串）
        if dev.ID != uuid.Nil {
            c.Set("deviceID", dev.ID.String())
        }
        c.Set("signatureVersion", "v1")
        c.Next()
    }
}

package middleware

import (
	"context"
	"database/sql"
	"os"
	"strconv"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
)

var (
	permissionDB  *sql.DB
	permissionTTL = 30 * time.Second
)

type permissionCacheEntry struct {
	role   string
	perms  []string
	expiry time.Time
}

var permissionCache sync.Map

// InitPermissionDB 启用 RequirePermission 的数据库实时权限校验（带 TTL 缓存）
func InitPermissionDB(db *sql.DB) {
	permissionDB = db
	if v := os.Getenv("PERMISSION_CACHE_TTL_SECONDS"); v != "" {
		if sec, err := strconv.Atoi(v); err == nil && sec >= 0 {
			permissionTTL = time.Duration(sec) * time.Second
		}
	}
}

// InvalidateUserPermissionCache 角色变更后清除指定用户的权限缓存
func InvalidateUserPermissionCache(userID string) {
	if userID == "" {
		return
	}
	permissionCache.Delete(userID)
}

// InvalidateAllPermissionCache 角色定义变更后清除全部权限缓存
func InvalidateAllPermissionCache() {
	permissionCache.Range(func(key, _ any) bool {
		permissionCache.Delete(key)
		return true
	})
}

func loadUserAuthFromDB(ctx context.Context, userID string) (role string, perms []string, ok bool) {
	if permissionDB == nil || userID == "" {
		return "", nil, false
	}
	if permissionTTL > 0 {
		if v, hit := permissionCache.Load(userID); hit {
			entry := v.(permissionCacheEntry)
			if time.Now().Before(entry.expiry) {
				return entry.role, entry.perms, true
			}
			permissionCache.Delete(userID)
		}
	}

	roleName := "auditor"
	err := permissionDB.QueryRowContext(ctx, `
		SELECT COALESCE(r.name, 'auditor')
		FROM user_roles ur
		JOIN roles r ON ur.role_id = r.id
		WHERE ur.user_id = $1
		LIMIT 1`, userID).Scan(&roleName)
	if err != nil && err != sql.ErrNoRows {
		return "", nil, false
	}

	rows, err := permissionDB.QueryContext(ctx, `
		SELECT DISTINCT jsonb_array_elements_text(r.permissions)
		FROM user_roles ur
		JOIN roles r ON ur.role_id = r.id
		WHERE ur.user_id = $1`, userID)
	if err != nil {
		return "", nil, false
	}
	defer rows.Close()

	seen := make(map[string]struct{})
	for rows.Next() {
		var perm string
		if err := rows.Scan(&perm); err != nil {
			continue
		}
		seen[perm] = struct{}{}
	}
	perms = make([]string, 0, len(seen))
	for p := range seen {
		perms = append(perms, p)
	}

	normalizedRole := normalizeRoleName(roleName)
	if permissionTTL > 0 {
		permissionCache.Store(userID, permissionCacheEntry{
			role:   normalizedRole,
			perms:  perms,
			expiry: time.Now().Add(permissionTTL),
		})
	}
	return normalizedRole, perms, true
}

func checkPermissionList(role string, perms []string, required string) bool {
	if normalizeRoleName(role) == "admin" {
		return true
	}
	for _, p := range perms {
		if p == required {
			return true
		}
	}
	return false
}

func checkAnyPermissionList(role string, perms []string, required ...string) bool {
	if normalizeRoleName(role) == "admin" {
		return true
	}
	allowed := make(map[string]struct{}, len(required))
	for _, p := range required {
		allowed[p] = struct{}{}
	}
	for _, p := range perms {
		if _, ok := allowed[p]; ok {
			return true
		}
	}
	return false
}

// UserHasPermission checks whether the authenticated user holds a permission.
func UserHasPermission(c *gin.Context, permission string) bool {
	userID := c.GetString("userID")
	if userID == "" {
		return false
	}
	role := c.GetString("role")
	var perms []string
	if p, ok := c.Get("permissions"); ok {
		if list, ok := p.([]string); ok {
			perms = list
		}
	}
	if dbRole, dbPerms, ok := loadUserAuthFromDB(c.Request.Context(), userID); ok {
		role = dbRole
		perms = dbPerms
	}
	return checkPermissionList(role, perms, permission)
}

func loadUsernameFromDB(ctx context.Context, userID string) (string, bool) {
	if permissionDB == nil || userID == "" {
		return "", false
	}
	var username string
	if err := permissionDB.QueryRowContext(ctx, `SELECT username FROM users WHERE id = $1`, userID).Scan(&username); err != nil {
		return "", false
	}
	return username, true
}

func loadUserAccountActive(ctx context.Context, userID string) (bool, bool) {
	if permissionDB == nil || userID == "" {
		return false, false
	}
	var status int
	if err := permissionDB.QueryRowContext(ctx, `SELECT status FROM users WHERE id = $1`, userID).Scan(&status); err != nil {
		return false, false
	}
	return status == 1, true
}

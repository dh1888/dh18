package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/services"
)

// WebSocketAuth — ticket 优先；生产环境 WS_TICKET_REQUIRED 禁用 JWT fallback
func WebSocketAuth(_ *redis.Client) gin.HandlerFunc {
	return func(c *gin.Context) {
		if ticket := strings.TrimSpace(c.Query("ticket")); ticket != "" {
			sess, ok := redeemWSTicket(c, ticket)
			if !ok {
				return
			}
			if sess.SubjectType != services.SessionSubjectUser {
				c.AbortWithStatusJSON(403, gin.H{"code": 1003, "message": "User session required"})
				return
			}
			c.Next()
			return
		}

		if services.WSTicketRequired() {
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "WS ticket required"})
			return
		}

		token := extractToken(c)
		if token == "" {
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Missing ticket"})
			return
		}

		if !authenticateSessionJWT(c, token, true, false) {
			return
		}
		c.Next()
	}
}

// AgentWebSocketAuth — ticket 优先；生产环境禁用 JWT fallback
func AgentWebSocketAuth(_ *redis.Client) gin.HandlerFunc {
	return func(c *gin.Context) {
		deviceID := strings.TrimSpace(c.Query("deviceId"))
		if deviceID == "" {
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Missing deviceId"})
			return
		}

		if ticket := strings.TrimSpace(c.Query("ticket")); ticket != "" {
			sess, ok := redeemWSTicket(c, ticket)
			if !ok {
				return
			}
			if sess.SubjectType != services.SessionSubjectDevice || sess.SubjectID.String() != deviceID {
				c.AbortWithStatusJSON(403, gin.H{"code": 1003, "message": "Ticket device mismatch"})
				return
			}
			c.Next()
			return
		}

		if services.WSTicketRequired() {
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "WS ticket required"})
			return
		}

		token := extractToken(c)
		if token == "" {
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Missing ticket or token"})
			return
		}

		if !authenticateSessionJWT(c, token, false, true) {
			return
		}
		if c.GetString("deviceID") != deviceID {
			c.AbortWithStatusJSON(403, gin.H{"code": 1003, "message": "Device ID mismatch"})
			return
		}
		c.Next()
	}
}

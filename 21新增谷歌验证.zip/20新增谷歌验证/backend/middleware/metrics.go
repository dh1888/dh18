package middleware

import (
	"time"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/services"
)

// Metrics records request counts and latency-friendly trace headers.
func Metrics() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		c.Next()
		services.GlobalMetrics.ObserveHTTP(c.Writer.Status())
		traceID := c.GetString("requestID")
		c.Header("X-Trace-Id", traceID)
		if sessionID := c.GetString("sessionID"); sessionID != "" {
			c.Header("X-Session-Id", sessionID)
		}
		if uploadID := c.GetString("uploadId"); uploadID != "" {
			c.Header("X-Upload-Id", uploadID)
		}
		_ = start
	}
}

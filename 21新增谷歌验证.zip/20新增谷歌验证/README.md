# monitorWin

企业终端监控平台：Go 后端 + Vue 管理端 + WinForms 客户端（DHPG）。

详细配置见 [docs/配置说明.md](docs/配置说明.md)。

## 快速启动

```powershell
# 后端
cd backend
copy .env.example .env
# 编辑 .env 后
go run .

# 前端
cd frontend
npm install
npm run dev

# 客户端打包（自包含，供员工 Web 下载）
powershell -ExecutionPolicy Bypass -File scripts/publish-client.ps1
```

## CORS / WebSocket Origin 白名单

控制 Web 管理端 API 跨域与 WebSocket（`/ws/admin`）连接。

**优先级（高 → 低）：**

1. **Web 后台配置** — 系统设置 → 清理策略配置下方「CORS / WebSocket Origin 白名单」，保存后立即生效
2. **环境变量** — `backend/.env` 中的 `CORS_ALLOWED_ORIGINS`
3. **开发默认值** — 非 production 时自动允许 `http://localhost:5173` 等

**生产部署示例：**

```env
# backend/.env（首次部署或未在 Web 配置时使用）
CORS_ALLOWED_ORIGINS=https://monitor.example.com,https://monitor.example.com:8888
```

或在管理端系统设置页添加相同 Origin（须与浏览器地址栏完全一致，含 `http/https` 与端口）。

## 客户端下载

1. 运行 `scripts/publish-client.ps1` 生成 `downloads/EnterpriseAgent-setup.zip`
2. 在 `.env` 配置：

```env
CLIENT_DOWNLOAD_FILE=EnterpriseAgent-setup.zip
CLIENT_VERSION=2.0.0
```

3. 员工登录 Web 后点击右上角下载图标

## 目录结构

| 目录 | 说明 |
|------|------|
| `backend/` | Go API 服务 |
| `frontend/` | Vue 3 管理端 |
| `agent/` | WinForms 客户端源码 |
| `downloads/` | 客户端安装包（供 Web 下载） |
| `scripts/` | 打包脚本 |
| `docs/` | 完整配置文档 |

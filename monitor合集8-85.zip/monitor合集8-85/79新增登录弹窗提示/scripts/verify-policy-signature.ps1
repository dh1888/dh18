# Verify production Backend policy signature (V2.1 Ed25519 vs legacy HMAC)
#
# Option A - use device JWT directly:
#   .\verify-policy-signature.ps1 -ServerUrl "https://dhpg8.duckdns.org" -DeviceToken "eyJhbGci..."
#
# Option B - obtain token via device register:
#   .\verify-policy-signature.ps1 -ServerUrl "https://dhpg8.duckdns.org" `
#     -RegistrationSecret "..." -DeviceId "your-device-id"

param(
    [Parameter(Mandatory = $true)]
    [string]$ServerUrl,

    [string]$DeviceToken = "",

    [string]$RegistrationSecret = "",

    [string]$DeviceId = ""
)

function Test-LooksLikeJwt([string]$Value) {
    $parts = $Value.Split('.')
    return ($parts.Count -eq 3 -and $parts[0].StartsWith("eyJ"))
}

function Get-DeviceTokenFromRegister {
    param(
        [string]$BaseUrl,
        [string]$Secret,
        [string]$Fingerprint
    )

    $body = @{
        deviceId     = $Fingerprint
        hostname     = "policy-verify-script"
        osVersion    = "Windows"
        agentVersion = "2.1.0"
    } | ConvertTo-Json

    $headers = @{
        Accept                  = "application/json"
        "Content-Type"          = "application/json"
        "X-Registration-Secret" = $Secret
    }

    $registerUrl = "$BaseUrl/api/v1/devices/register"
    Write-Host "POST $registerUrl (obtain device token)" -ForegroundColor Cyan
    $resp = Invoke-RestMethod -Uri $registerUrl -Method Post -Headers $headers -Body $body
    $token = $resp.data.token
    if ([string]::IsNullOrWhiteSpace($token)) {
        throw "Register succeeded but no token in response. Device status: $($resp.data.status)"
    }
    Write-Host "  deviceId : $($resp.data.deviceId)" -ForegroundColor DarkGray
    Write-Host "  status   : $($resp.data.status)" -ForegroundColor DarkGray
    if ($resp.data.status -ne "approved") {
        Write-Host "  WARN: device not approved; /policies/current may return 403" -ForegroundColor Yellow
    }
    return $token
}

$base = $ServerUrl.TrimEnd('/')

if ([string]::IsNullOrWhiteSpace($DeviceToken)) {
    if ([string]::IsNullOrWhiteSpace($RegistrationSecret) -or [string]::IsNullOrWhiteSpace($DeviceId)) {
        Write-Host "ERROR: provide -DeviceToken OR (-RegistrationSecret + -DeviceId)" -ForegroundColor Red
        exit 1
    }
    try {
        $DeviceToken = Get-DeviceTokenFromRegister -BaseUrl $base -Secret $RegistrationSecret -Fingerprint $DeviceId
    }
    catch {
        Write-Host "Register failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

if (-not (Test-LooksLikeJwt $DeviceToken)) {
    Write-Host "ERROR: -DeviceToken is NOT a JWT." -ForegroundColor Red
    Write-Host "  Do not use JWT_SECRET or admin Web Bearer token." -ForegroundColor Yellow
    Write-Host "  Device JWT looks like: eyJhbGci.... (three dot-separated parts)" -ForegroundColor Yellow
    exit 1
}

$url = "$base/api/v1/policies/current"
Write-Host "GET $url" -ForegroundColor Cyan

try {
    $response = Invoke-RestMethod -Uri $url -Headers @{
        Authorization = "Bearer $DeviceToken"
        Accept        = "application/json"
    } -Method Get
}
catch {
    $status = $_.Exception.Response.StatusCode.value__
    Write-Host "Request failed (HTTP $status)." -ForegroundColor Red
    if ($status -eq 401) {
        Write-Host "  Token invalid or expired. Re-register or copy token from Agent." -ForegroundColor Yellow
    }
    elseif ($status -eq 403) {
        Write-Host "  Device not approved. Approve device in Web admin first." -ForegroundColor Yellow
    }
    exit 1
}

$data = $response.data
if (-not $data) {
    Write-Host "Unexpected response:" -ForegroundColor Red
    $response | ConvertTo-Json -Depth 8
    exit 1
}

Write-Host ""
Write-Host "=== Policy /policies/current response ===" -ForegroundColor Green

$fields = @(
    "signatureAlg",
    "signatureVersion",
    "keyId",
    "signature",
    "policy",
    "content",
    "version"
)

foreach ($name in $fields) {
    if ($data.PSObject.Properties.Name -contains $name) {
        $val = $data.$name
        if ($name -eq "signature" -and $val) {
            $val = $val.Substring(0, [Math]::Min(24, $val.Length)) + "..."
        }
        if ($name -eq "policy" -and $val) {
            $val = "<policy object present>"
        }
        if ($name -eq "content" -and $val) {
            $val = "<content string, len=$($data.content.Length)>"
        }
        Write-Host ("  {0,-18} {1}" -f $name, $val)
    }
    else {
        Write-Host ("  {0,-18} (missing)" -f $name) -ForegroundColor DarkYellow
    }
}

Write-Host ""
$isV21 = ($data.signatureAlg -eq "Ed25519") -and ($data.keyId) -and ($null -ne $data.signatureVersion) -and ($data.policy)
$isLegacy = ($data.signature -and -not $data.signatureAlg) -or ($data.signatureAlg -eq "HMAC-SHA256")

if ($isV21) {
    Write-Host "RESULT: V2.1 Ed25519 + JCS is ACTIVE on this server." -ForegroundColor Green
    Write-Host ("Agent deployment.json must include policyPublicKeys['{0}']" -f $data.keyId) -ForegroundColor Cyan
    exit 0
}

if ($isLegacy) {
    Write-Host "RESULT: Legacy HMAC signing. Backend not fully on V2.1." -ForegroundColor Red
    Write-Host "Deploy new Backend binary + POLICY_SIGNING_* in .env + restart." -ForegroundColor Yellow
    exit 2
}

Write-Host "RESULT: Unknown response. Paste full JSON for review." -ForegroundColor Yellow
$response | ConvertTo-Json -Depth 8
exit 3

# 打包 WinForms 客户端：publish → 更新 ZIP → Inno Setup 安装包
# 用法（在项目根目录）:
#   powershell -ExecutionPolicy Bypass -File scripts/publish-client.ps1
# 可选环境变量:
#   $env:SKIP_INNO = "1"     # 只 publish，不编译安装包
#   $env:ISCC = "C:\...\ISCC.exe"

$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$AgentDir = Join-Path $Root "agent"
$UpdaterDir = Join-Path $AgentDir "Updater"
$PublishDir = Join-Path $AgentDir "publish\win-x64"
$DownloadsDir = Join-Path $Root "downloads"
$UpdateZipName = "MonitorAgent-update.zip"
$UpdateZipPath = Join-Path $DownloadsDir $UpdateZipName
$SetupName = "MonitorAgentSetup.exe"
$SetupPath = Join-Path $DownloadsDir $SetupName
$IssPath = Join-Path $Root "installer\EnterpriseAgent.iss"

Write-Host "==> Enterprise Agent client publish" -ForegroundColor Cyan
Write-Host "    Root: $Root"

if (-not (Test-Path (Join-Path $AgentDir "EnterpriseAgent.Agent.csproj"))) {
    throw "Cannot find agent project under $AgentDir"
}

$deploymentPath = Join-Path $AgentDir "deployment.json"
if (-not (Test-Path $deploymentPath)) {
    Write-Host "WARN: agent/deployment.json not found. Copy deployment.json.example first." -ForegroundColor Yellow
    Copy-Item (Join-Path $AgentDir "deployment.json.example") $deploymentPath
    throw "Please edit agent/deployment.json (serverUrl, secrets) and run again."
}

$deployment = Get-Content $deploymentPath -Raw | ConvertFrom-Json
if ([string]::IsNullOrWhiteSpace($deployment.serverUrl) -and [string]::IsNullOrWhiteSpace($deployment.defaultServerUrl)) {
    Write-Host "WARN: deployment.json has no serverUrl. Employees must enter server URL manually on first run." -ForegroundColor Yellow
}

if ($deployment.allowInsecureTransport -eq $true) {
    Write-Host "WARN: allowInsecureTransport=true - use only for local HTTP debugging, not production publish." -ForegroundColor Yellow
}

$ffmpegPath = Join-Path $AgentDir "ffmpeg.exe"
if (-not (Test-Path $ffmpegPath)) {
    Write-Host "WARN: agent/ffmpeg.exe not found. Screen recording may fail until ffmpeg is bundled." -ForegroundColor Yellow
}

Write-Host "==> dotnet publish agent (self-contained win-x64)..." -ForegroundColor Cyan
Push-Location $AgentDir
try {
    dotnet publish EnterpriseAgent.Agent.csproj `
        -c Release `
        -r win-x64 `
        --self-contained true `
        /p:PublishReadyToRun=true `
        /p:IncludeNativeLibrariesForSelfExtract=true `
        -o $PublishDir
    if ($LASTEXITCODE -ne 0) { throw "Agent publish failed with exit code $LASTEXITCODE" }
}
finally {
    Pop-Location
}

Write-Host "==> dotnet publish updater (self-contained win-x64)..." -ForegroundColor Cyan
Push-Location $UpdaterDir
try {
    dotnet publish EnterpriseAgent.Updater.csproj `
        -c Release `
        -r win-x64 `
        --self-contained true `
        -o (Join-Path $PublishDir "Updater")
    if ($LASTEXITCODE -ne 0) { throw "Updater publish failed with exit code $LASTEXITCODE" }
}
finally {
    Pop-Location
}

if (-not (Test-Path (Join-Path $PublishDir "DHPG.exe"))) {
    throw "Publish output missing DHPG.exe at $PublishDir"
}
if (-not (Test-Path (Join-Path $PublishDir "Updater\DHPGUpdater.exe"))) {
    throw "Publish output missing Updater\DHPGUpdater.exe"
}

New-Item -ItemType Directory -Force -Path $DownloadsDir | Out-Null
if (Test-Path $UpdateZipPath) { Remove-Item $UpdateZipPath -Force }

Write-Host "==> Creating update zip: $UpdateZipPath" -ForegroundColor Cyan
Compress-Archive -Path (Join-Path $PublishDir "*") -DestinationPath $UpdateZipPath -CompressionLevel Optimal

$version = (Select-Xml -Path (Join-Path $AgentDir "EnterpriseAgent.Agent.csproj") -XPath "//Version" | Select-Object -First 1).Node.InnerText
if ([string]::IsNullOrWhiteSpace($version)) { $version = "2.0.0" }

function Get-FileSha256Hex([string]$Path) {
    $hash = Get-FileHash -Path $Path -Algorithm SHA256
    return $hash.Hash.ToLowerInvariant()
}

$updateSha256 = Get-FileSha256Hex $UpdateZipPath
$setupBuilt = $false
$setupSha256 = ""

if ($env:SKIP_INNO -ne "1") {
    $iscc = $env:ISCC
    if ([string]::IsNullOrWhiteSpace($iscc)) {
        $isccCmd = Get-Command ISCC.exe -ErrorAction SilentlyContinue
        if ($isccCmd) { $iscc = $isccCmd.Source }
    }
    if ([string]::IsNullOrWhiteSpace($iscc)) {
        $defaultIscc = "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe"
        if (Test-Path $defaultIscc) { $iscc = $defaultIscc }
    }
    if ([string]::IsNullOrWhiteSpace($iscc)) {
        $userIscc = Join-Path $env:LOCALAPPDATA "Inno\ISCC.exe"
        if (Test-Path $userIscc) { $iscc = $userIscc }
    }

    if ([string]::IsNullOrWhiteSpace($iscc) -or -not (Test-Path $iscc)) {
        Write-Host "WARN: Inno Setup (ISCC.exe) not found. Skipping MonitorAgentSetup.exe." -ForegroundColor Yellow
        Write-Host "      Install Inno Setup 6 or set `$env:ISCC to ISCC.exe path." -ForegroundColor Yellow
    }
    else {
        Write-Host "==> Building installer with Inno Setup..." -ForegroundColor Cyan
        & $iscc "/DSourcePath=$PublishDir" $IssPath
        if ($LASTEXITCODE -ne 0) { throw "Inno Setup compile failed with exit code $LASTEXITCODE" }
        if (-not (Test-Path $SetupPath)) {
            throw "Expected installer not found: $SetupPath"
        }
        $setupBuilt = $true
        $setupSha256 = Get-FileSha256Hex $SetupPath
    }
}

Write-Host ""
Write-Host "Done." -ForegroundColor Green
$updateSizeMb = [math]::Round((Get-Item $UpdateZipPath).Length / 1MB, 2)
Write-Host ('  Update ZIP : {0} ({1} MB)' -f $UpdateZipPath, $updateSizeMb)
Write-Host "  Update SHA256: $updateSha256"
if ($setupBuilt) {
    $setupSizeMb = [math]::Round((Get-Item $SetupPath).Length / 1MB, 2)
    Write-Host ('  Setup EXE  : {0} ({1} MB)' -f $SetupPath, $setupSizeMb)
    Write-Host "  Setup SHA256: $setupSha256"
}
Write-Host ""
Write-Host "Add to backend/.env (then restart backend):" -ForegroundColor Yellow
Write-Host "  CLIENT_DOWNLOAD_FILE=$SetupName"
Write-Host "  CLIENT_UPDATE_FILE=$UpdateZipName"
Write-Host "  CLIENT_VERSION=$version"
Write-Host ""
Write-Host "Employee usage:" -ForegroundColor Yellow
Write-Host "  1. Login web portal -> download Enterprise Agent"
Write-Host "  2. Run MonitorAgentSetup.exe (or use in-app update from tray)"
Write-Host "  3. Login with employee account or invite code"

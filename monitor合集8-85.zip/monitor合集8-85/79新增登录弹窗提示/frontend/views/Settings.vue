<template>
  <div class="settings-page">
    <!-- 第一行：策略配置 + 存储统计 -->
    <el-row :gutter="20" class="settings-top-row">
      <el-col :span="16">
        <div class="left-stack">
          <el-card class="settings-card">
            <template #header>
              <div class="card-header">
                <span>清理策略配置</span>
                <el-button
                  link
                  type="primary"
                  class="guide-trigger"
                  @click="guideDialogVisible = true"
                >
                  <el-icon><QuestionFilled /></el-icon>
                  清理说明
                </el-button>
              </div>
            </template>

            <el-form
              :model="policy"
              :rules="rules"
              ref="policyFormRef"
              label-width="160px"
            >
              <el-form-item label="自动清理">
                <el-switch v-model="policy.autoCleanupEnabled" />
                <span class="form-tip">开启后系统将自动清理过期数据</span>
              </el-form-item>

              <el-divider content-position="left">文件与日志</el-divider>

              <el-form-item
                label="录制文件保留天数"
                prop="recordingRetentionDays"
              >
                <el-input-number
                  v-model="policy.recordingRetentionDays"
                  :min="0"
                  :max="365"
                />
                <span class="form-tip">天，超过此天数的录制将被删除</span>
              </el-form-item>

              <el-form-item label="截图保留天数" prop="screenshotRetentionDays">
                <el-input-number
                  v-model="policy.screenshotRetentionDays"
                  :min="0"
                  :max="365"
                />
                <span class="form-tip">天</span>
              </el-form-item>

              <el-form-item label="日志保留天数" prop="logRetentionDays">
                <el-input-number
                  v-model="policy.logRetentionDays"
                  :min="0"
                  :max="730"
                />
                <span class="form-tip">天，含活动/操作/远程审计等系统日志</span>
              </el-form-item>

              <el-divider content-position="left">业务数据（默认 0 不清理）</el-divider>

              <el-form-item label="考勤保留月数" prop="attendanceRetentionMonths">
                <el-input-number
                  v-model="policy.attendanceRetentionMonths"
                  :min="0"
                  :max="120"
                />
                <span class="form-tip">月，按考勤日期清理过期格子记录</span>
              </el-form-item>

              <el-form-item label="绩效保留月数" prop="performanceRetentionMonths">
                <el-input-number
                  v-model="policy.performanceRetentionMonths"
                  :min="0"
                  :max="120"
                />
                <span class="form-tip">月，按考核月份清理</span>
              </el-form-item>

              <el-form-item label="罚款保留月数" prop="penaltyRetentionMonths">
                <el-input-number
                  v-model="policy.penaltyRetentionMonths"
                  :min="0"
                  :max="120"
                />
                <span class="form-tip">月，按罚款日期清理</span>
              </el-form-item>

              <el-form-item label="工资保留月数" prop="salaryRetentionMonths">
                <el-input-number
                  v-model="policy.salaryRetentionMonths"
                  :min="0"
                  :max="120"
                />
                <span class="form-tip">月，含工资记录与打款截图</span>
              </el-form-item>

              <el-form-item label="出款统计保留月数" prop="siteStatsRetentionMonths">
                <el-input-number
                  v-model="policy.siteStatsRetentionMonths"
                  :min="0"
                  :max="120"
                />
                <span class="form-tip">月，按统计日期清理</span>
              </el-form-item>

              <el-divider content-position="left">触发条件</el-divider>

              <el-form-item label="磁盘使用阈值" prop="diskUsageThresholdPercent">
                <el-input-number
                  v-model="policy.diskUsageThresholdPercent"
                  :min="1"
                  :max="100"
                />
                <span class="form-tip">%，超过此阈值触发清理</span>
              </el-form-item>

              <el-form-item label="清理间隔" prop="cleanupIntervalMinutes">
                <el-input-number
                  v-model="policy.cleanupIntervalMinutes"
                  :min="1"
                  :max="1440"
                />
                <span class="form-tip">分钟</span>
              </el-form-item>

              <el-form-item>
                <el-button
                  type="primary"
                  :loading="saveLoading"
                  @click="handleSavePolicy"
                >
                  保存策略
                </el-button>
                <el-button @click="handleManualCleanup" :loading="cleanupLoading">
                  立即清理
                </el-button>
              </el-form-item>
            </el-form>
          </el-card>
        </div>
      </el-col>

      <el-col :span="8">
        <el-card class="stats-card">
          <template #header>
            <span>存储统计</span>
          </template>

          <div class="stats-content" v-loading="statsLoading">
            <div class="stat-item">
              <span class="stat-label">磁盘总容量</span>
              <span class="stat-value">{{
                formatBytes(stats.totalBytes)
              }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">分区已用</span>
              <span class="stat-value">{{ formatBytes(stats.usedBytes) }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">分区剩余</span>
              <span class="stat-value">{{ formatBytes(stats.freeBytes) }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">磁盘使用率</span>
              <el-progress
                :percentage="stats.diskUsagePercent"
                :color="getUsageColor(stats.diskUsagePercent)"
                :format="() => `${stats.diskUsagePercent}%`"
              />
            </div>
            <div class="stat-item">
              <span class="stat-label">业务数据占用</span>
              <span class="stat-value">{{
                formatBytes(stats.uploadsBytes ?? 0)
              }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">录制文件数</span>
              <span class="stat-value">{{ stats.recordingCount }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">截图文件数</span>
              <span class="stat-value">{{ stats.screenshotCount }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">业务记录条目</span>
              <span class="stat-value">{{
                stats.businessRecords?.totalCount ?? 0
              }}</span>
            </div>
            <div class="stat-item stat-item-sub" v-if="stats.businessRecords">
              <span class="stat-label">考勤 / 绩效 / 罚款</span>
              <span class="stat-value stat-value-muted">
                {{ stats.businessRecords.attendanceCount }} /
                {{ stats.businessRecords.performanceCount }} /
                {{ stats.businessRecords.penaltyCount }}
              </span>
            </div>
            <div class="stat-item stat-item-sub" v-if="stats.businessRecords">
              <span class="stat-label">工资 / 出款统计</span>
              <span class="stat-value stat-value-muted">
                {{ stats.businessRecords.salaryCount }} /
                {{ stats.businessRecords.siteStatsCount }}
              </span>
            </div>
            <div class="stat-item">
              <span class="stat-label">日志条目数</span>
              <span class="stat-value">{{ stats.logCount }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">上次清理时间</span>
              <span class="stat-value">{{
                formatTime(stats.lastCleanupAt)
              }}</span>
            </div>
            <p class="stats-tip">
              磁盘占用主要来自录屏/截图文件；考勤、绩效、罚款、工资、出款统计为数据库记录，单条很小，但长期累积也会增长。设为 0 的业务保留月数表示不自动清理。
            </p>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 第二行：清理日志（带分页） -->
    <el-row :gutter="20" style="margin-top: 20px">
      <el-col :span="24">
        <el-card class="logs-card">
          <template #header>
            <div class="card-header">
              <span>
                <el-icon><Document /></el-icon>
                清理日志
                <el-badge
                  :value="logsPagination.total"
                  :hidden="logsPagination.total === 0"
                  class="total-badge"
                />
              </span>
              <el-button
                size="small"
                @click="handleRefreshLogs"
                :loading="logsLoading"
              >
                <el-icon><Refresh /></el-icon>
                刷新
              </el-button>
            </div>
          </template>

          <el-empty
            v-if="cleanupLogs.length === 0 && !logsLoading"
            description="尚无实际清理记录"
          />

          <template v-else>
            <el-table :data="cleanupLogs" v-loading="logsLoading" stripe>
              <el-table-column prop="triggerType" label="触发方式" width="140">
                <template #default="{ row }">
                  <el-tag :type="getTriggerTypeTag(row.triggerType)" size="small">
                    {{ getTriggerTypeText(row.triggerType) }}
                  </el-tag>
                </template>
              </el-table-column>

              <el-table-column prop="status" label="状态" width="90">
                <template #default="{ row }">
                  <el-tag
                    :type="
                      row.status === 'success'
                        ? 'success'
                        : row.status === 'partial'
                          ? 'warning'
                          : 'danger'
                    "
                    size="small"
                  >
                    {{
                      row.status === "success"
                        ? "成功"
                        : row.status === "partial"
                          ? "部分成功"
                          : "失败"
                    }}
                  </el-tag>
                </template>
              </el-table-column>

              <el-table-column prop="startedAt" label="执行时间" width="180">
                <template #default="{ row }">
                  {{ formatTime(row.startedAt) }}
                </template>
              </el-table-column>

              <el-table-column label="清理结果" min-width="320">
                <template #default="{ row }">
                  <span class="cleanup-result">
                    {{ formatCleanupResult(row) }}
                  </span>
                </template>
              </el-table-column>
            </el-table>

            <div class="pagination-container">
              <el-pagination
                v-model:current-page="logsPagination.page"
                v-model:page-size="logsPagination.pageSize"
                :total="logsPagination.total"
                :page-sizes="[10, 20, 50, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleLogsSizeChange"
                @current-change="handleLogsCurrentChange"
              />
            </div>
          </template>
        </el-card>
      </el-col>
    </el-row>

    <el-dialog
      v-model="guideDialogVisible"
      title="清理说明"
      width="640px"
      class="cleanup-guide-dialog"
    >
      <ul class="cleanup-guide-list">
        <li>
          <strong>自动清理：</strong>开启后按「清理间隔」定时检查；到达保留期限的录制、截图、日志与业务数据会被删除。
        </li>
        <li>
          <strong>文件与日志：</strong>录制/截图按天清理；日志含活动、操作、远程审计、上传任务、登录会话、Telegram 历史等。设为 0 表示不清理。
        </li>
        <li>
          <strong>业务数据：</strong>考勤、绩效、罚款、工资、出款统计按「保留月数」清理，从当月 1 日往前推算；默认均为 0（不清理），需手动配置后才会删除过期业务记录。
        </li>
        <li>
          <strong>占用说明：</strong>录屏/截图占磁盘最大；业务表为 PostgreSQL 行数据，通常远小于文件，但条目多时会增加数据库体积与备份大小。
        </li>
        <li>
          <strong>磁盘阈值：</strong>分区使用率超过设定百分比时会额外触发清理，优先删除已过期数据。
        </li>
        <li>
          <strong>立即清理：</strong>手动执行一次，仅删除当前策略下已过期项，不会误删未到期数据。
        </li>
      </ul>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { cleanupApi } from "@api/index";
import type { CleanupPolicy, StorageStats, CleanupLog } from "@api/types";
import { Document, Refresh, QuestionFilled } from "@element-plus/icons-vue";

const guideDialogVisible = ref(false);

// ========== 策略配置相关 ==========
const policyFormRef = ref();
const saveLoading = ref(false);
const cleanupLoading = ref(false);
const statsLoading = ref(false);

const policy = reactive<CleanupPolicy>({
  autoCleanupEnabled: true,
  recordingRetentionDays: 30,
  screenshotRetentionDays: 30,
  logRetentionDays: 90,
  attendanceRetentionMonths: 0,
  performanceRetentionMonths: 0,
  penaltyRetentionMonths: 0,
  salaryRetentionMonths: 0,
  siteStatsRetentionMonths: 0,
  diskUsageThresholdPercent: 80,
  cleanupIntervalMinutes: 60,
  lastRunAt: null,
  updatedAt: "",
});

const stats = reactive<StorageStats>({
  totalBytes: 0,
  usedBytes: 0,
  freeBytes: 0,
  diskUsagePercent: 0,
  uploadsBytes: 0,
  recordingCount: 0,
  screenshotCount: 0,
  logCount: 0,
  businessRecords: {
    attendanceCount: 0,
    performanceCount: 0,
    penaltyCount: 0,
    salaryCount: 0,
    siteStatsCount: 0,
    totalCount: 0,
  },
  lastCleanupAt: null,
});

const rules = {
  recordingRetentionDays: [
    { required: true, type: "number", min: 0, message: "请输入有效的天数" },
  ],
  screenshotRetentionDays: [
    { required: true, type: "number", min: 0, message: "请输入有效的天数" },
  ],
  logRetentionDays: [
    { required: true, type: "number", min: 0, message: "请输入有效的天数" },
  ],
  attendanceRetentionMonths: [
    { required: true, type: "number", min: 0, message: "请输入有效的月数" },
  ],
  performanceRetentionMonths: [
    { required: true, type: "number", min: 0, message: "请输入有效的月数" },
  ],
  penaltyRetentionMonths: [
    { required: true, type: "number", min: 0, message: "请输入有效的月数" },
  ],
  salaryRetentionMonths: [
    { required: true, type: "number", min: 0, message: "请输入有效的月数" },
  ],
  siteStatsRetentionMonths: [
    { required: true, type: "number", min: 0, message: "请输入有效的月数" },
  ],
  diskUsageThresholdPercent: [
    {
      required: true,
      type: "number",
      min: 1,
      max: 100,
      message: "请输入 1-100 之间的值",
    },
  ],
  cleanupIntervalMinutes: [
    { required: true, type: "number", min: 1, message: "请输入有效的分钟数" },
  ],
};

// ========== 清理日志相关（服务端分页） ==========
const cleanupLogs = ref<CleanupLog[]>([]);
const logsLoading = ref(false);

const logsPagination = reactive({
  page: 1,
  pageSize: 10,
  total: 0,
});

// ========== 工具函数 ==========
const formatBytes = (bytes: number) => {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
};

const formatTime = (time: string | null) => {
  if (!time) return "从未执行";
  const date = new Date(time);
  return date.toLocaleString("zh-CN");
};

const getUsageColor = (percent: number) => {
  if (percent < 60) return "#67c23a";
  if (percent < 80) return "#e6a23c";
  return "#f56c6c";
};

// ========== 触发方式映射 ==========
const getTriggerTypeTag = (type: string): string => {
  const map: Record<string, string> = {
    auto: "info",
    manual: "primary",
    auto_disk_threshold: "warning",
    auto_disk_critical: "danger",
  };
  return map[type] || "info";
};

const getTriggerTypeText = (type: string): string => {
  const map: Record<string, string> = {
    auto: "定时清理",
    manual: "手动清理",
    auto_disk_threshold: "磁盘阈值",
    auto_disk_critical: "磁盘临界",
  };
  return map[type] || type;
};

const isCleanupEmpty = (row: CleanupLog) =>
  row.deletedRecordings === 0 &&
  row.deletedScreenshots === 0 &&
  row.deletedLogs === 0 &&
  (row.deletedBusinessRecords ?? 0) === 0 &&
  row.deletedBytes === 0;

const formatCleanupResult = (row: CleanupLog) => {
  if (row.message?.trim()) {
    return row.message;
  }

  const parts: string[] = [];
  if (row.deletedRecordings > 0) {
    parts.push(`录制 ${row.deletedRecordings} 个`);
  }
  if (row.deletedScreenshots > 0) {
    parts.push(`截图 ${row.deletedScreenshots} 个`);
  }
  if (row.deletedLogs > 0) {
    parts.push(`日志 ${row.deletedLogs} 条`);
  }
  if ((row.deletedBusinessRecords ?? 0) > 0) {
    parts.push(`业务 ${row.deletedBusinessRecords} 条`);
  }

  const summary = parts.join("、");
  if (row.deletedBytes > 0) {
    return `删除 ${summary}，释放 ${formatBytes(row.deletedBytes)}`;
  }
  return `删除 ${summary}`;
};

const handleLogsSizeChange = (size: number) => {
  logsPagination.pageSize = size;
  logsPagination.page = 1;
  loadCleanupLogs();
};

const handleLogsCurrentChange = (page: number) => {
  logsPagination.page = page;
  loadCleanupLogs();
};

const handleRefreshLogs = () => {
  loadCleanupLogs();
};

// ========== API 调用 ==========
const loadPolicy = async () => {
  try {
    const { data } = await cleanupApi.getPolicy();
    Object.assign(policy, {
      attendanceRetentionMonths: 0,
      performanceRetentionMonths: 0,
      penaltyRetentionMonths: 0,
      salaryRetentionMonths: 0,
      siteStatsRetentionMonths: 0,
      ...data,
    });
  } catch (error: any) {
    ElMessage.error(error.message || "加载策略失败");
  }
};

const loadStats = async () => {
  statsLoading.value = true;
  try {
    const { data } = await cleanupApi.getStats();
    Object.assign(stats, data);
  } catch (error: any) {
    ElMessage.error(error.message || "加载统计失败");
  } finally {
    statsLoading.value = false;
  }
};

const loadCleanupLogs = async () => {
  logsLoading.value = true;
  try {
    const { data } = await cleanupApi.getLogs({
      page: logsPagination.page,
      pageSize: logsPagination.pageSize,
    });
    cleanupLogs.value = (data?.items ?? []).filter((row) => !isCleanupEmpty(row));
    logsPagination.total = data?.total ?? cleanupLogs.value.length;
  } catch (error: any) {
    ElMessage.error(error.message || "加载清理日志失败");
    cleanupLogs.value = [];
    logsPagination.total = 0;
  } finally {
    logsLoading.value = false;
  }
};

const handleSavePolicy = async () => {
  if (!policyFormRef.value) return;

  try {
    await policyFormRef.value.validate();
  } catch {
    return;
  }

  saveLoading.value = true;
  try {
    await cleanupApi.updatePolicy(policy);
    ElMessage.success("策略保存成功");
    await loadPolicy();
    await loadStats();
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    saveLoading.value = false;
  }
};

const handleManualCleanup = async () => {
  cleanupLoading.value = true;
  try {
    const { data } = await cleanupApi.manualCleanup();
    const empty =
      data.deletedRecordings === 0 &&
      data.deletedScreenshots === 0 &&
      data.deletedLogs === 0 &&
      (data.deletedBusinessRecords ?? 0) === 0 &&
      data.deletedBytes === 0;

    ElMessage.success(
      empty
        ? "检查完成，当前无需要清理的数据"
        : `清理完成：录制 ${data.deletedRecordings}、截图 ${data.deletedScreenshots}、日志 ${data.deletedLogs}、业务 ${data.deletedBusinessRecords ?? 0}，释放 ${formatBytes(data.deletedBytes)}`,
    );
    logsPagination.page = 1;
    await loadStats();
    await loadCleanupLogs();
  } catch (error: any) {
    ElMessage.error(error.message || "清理失败");
  } finally {
    cleanupLoading.value = false;
  }
};

// ========== 生命周期 ==========
onMounted(() => {
  loadPolicy();
  loadStats();
  loadCleanupLogs();
});
</script>

<style scoped>
.settings-page {
  min-height: 100%;
}

.settings-top-row {
  align-items: stretch;
}

.settings-top-row :deep(.el-col) {
  display: flex;
}

.left-stack {
  display: flex;
  flex-direction: column;
  gap: 20px;
  width: 100%;
  flex: 1;
}

.settings-card,
.stats-card,
.logs-card {
  border-radius: 8px;
}

.guide-trigger {
  font-size: 13px;
}

.stats-card {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.stats-card :deep(.el-card__body) {
  flex: 1;
}

.stat-item-sub {
  padding: 6px 0 6px 12px;
  border-bottom: none;
}

.stat-value-muted {
  font-size: 12px;
  color: #909399;
  font-weight: 400;
}

.cleanup-guide-dialog .cleanup-guide-list {
  margin: 0;
  padding-left: 18px;
}

.cleanup-guide-list {
  color: #606266;
  font-size: 13px;
  line-height: 1.75;
}

.cleanup-guide-list li + li {
  margin-top: 10px;
}

.cleanup-guide-list strong {
  color: #303133;
  font-weight: 600;
}

.form-tip {
  margin-left: 12px;
  font-size: 12px;
  color: #8c8c8c;
}

.stats-content {
  padding: 10px 0;
}

.stat-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;
}

.stat-item:last-child {
  border-bottom: none;
}

.stat-label {
  font-size: 14px;
  color: #666;
}

.stat-value {
  font-size: 14px;
  font-weight: 500;
  color: #333;
}

.stats-tip {
  margin: 8px 0 0;
  font-size: 12px;
  line-height: 1.5;
  color: #909399;
}

.cleanup-result {
  color: #303133;
}

/* 卡片头部样式 */
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* 表格内文字颜色 */
.text-success {
  color: #67c23a;
  font-weight: 500;
}

.text-warning {
  color: #e6a23c;
  font-weight: 500;
}

/* 分页容器 */
.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

/* 总数徽章 */
.total-badge :deep(.el-badge__content) {
  background-color: #409eff;
}

/* 响应式适配 */
@media (max-width: 768px) {
  .logs-card :deep(.el-table) {
    overflow-x: auto;
  }

  .pagination-container {
    overflow-x: auto;
  }

  .pagination-container :deep(.el-pagination) {
    flex-wrap: wrap;
    justify-content: center;
  }
}
</style>

<template>
  <div class="payment-addresses-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <el-card class="toolbar-card" shadow="hover">
      <div class="toolbar">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索姓名、工号、部门、岗位、账号或地址"
          clearable
          :prefix-icon="Search"
          @input="handleSearch"
          style="width: 340px"
        />
        <el-button type="primary" @click="loadData">
          <el-icon><Refresh /></el-icon>
          刷新
        </el-button>
        <span class="toolbar-hint">点击姓名或操作列「查看」打开详情</span>
      </div>
    </el-card>

    <el-card class="table-card" shadow="hover">
      <el-table
        :data="items"
        v-loading="loading"
        stripe
        border
      >
        <el-table-column label="姓名" min-width="120">
          <template #default="{ row }">
            <span class="name-link" @click.stop="openDetail(row)">{{ row.employeeName }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="employeeCode" label="工号" width="120" />
        <el-table-column prop="department" label="部门" min-width="110">
          <template #default="{ row }">{{ row.department || "-" }}</template>
        </el-table-column>
        <el-table-column prop="position" label="岗位" min-width="110">
          <template #default="{ row }">{{ row.position || "-" }}</template>
        </el-table-column>
        <el-table-column label="工资状态" min-width="180">
          <template #default="{ row }">
            <div class="salary-status-cell">
              <span class="salary-month">{{ row.lastMonthLabel || "-" }}</span>
              <span class="salary-amount" v-if="row.lastMonthAmount != null">
                ¥{{ formatSalaryAmount(row.lastMonthAmount) }}
              </span>
              <span class="salary-amount pending-text" v-else-if="row.lastMonthStatus === 'pending'">
                应发
              </span>
              <el-tag
                size="small"
                :type="salaryStatusTagType(row.lastMonthStatus)"
              >
                {{ row.lastMonthStatusLabel || "-" }}
              </el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="绑定账号/地址" min-width="280">
          <template #default="{ row }">
            <div class="bound-list" v-if="row.boundAccounts?.length">
              <div
                v-for="(acc, idx) in row.boundAccounts"
                :key="idx"
                class="bound-item"
                :class="{ preferred: acc.isPreferred }"
              >
                <span class="bound-label">{{ acc.label }}</span>
                <CopyableText :text="acc.display" :label="acc.label" />
                <el-tag v-if="acc.isPreferred" size="small" type="success">默认</el-tag>
              </div>
            </div>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <el-table-column prop="updatedAt" label="更新时间" width="170">
          <template #default="{ row }">
            {{ row.updatedAt ? formatTime(row.updatedAt) : "-" }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="210" align="center" fixed="right">
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              size="small"
              @click.stop="openDetail(row)"
            >
              查看
            </el-button>
            <el-button
              link
              type="primary"
              size="small"
              v-permission="['salary:upload', 'salary:payment_address:view']"
              @click.stop="openProofUploadDialog(row)"
            >
              上传图片
            </el-button>
            <SalaryPaidStatusButton
              v-permission="'salary:upload'"
              :status="row.lastMonthStatus || 'pending'"
              :disabled="!row.lastMonthSalaryId || row.lastMonthStatus === 'paid'"
              @click.stop="markPaid(row)"
            />
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="page"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[20, 50, 100, 200]"
          layout="total, sizes, prev, pager, next"
          @size-change="loadData"
          @current-change="loadData"
        />
      </div>
    </el-card>

    <el-drawer
      v-model="detailVisible"
      :title="detailTitle"
      size="500px"
      destroy-on-close
    >
      <div v-if="selectedRow" class="detail-panel">
        <div class="employee-block">
          <el-avatar :size="56" :style="{ backgroundColor: getAvatarColor(selectedRow.employeeName) }">
            {{ selectedRow.employeeName?.charAt(0) }}
          </el-avatar>
          <div>
            <div class="employee-name">{{ selectedRow.employeeName }}</div>
            <div class="employee-meta">
              <el-tag size="small" type="info">{{ selectedRow.employeeCode || "无工号" }}</el-tag>
              <el-tag size="small" v-if="selectedRow.department">{{ selectedRow.department }}</el-tag>
              <el-tag size="small" v-if="selectedRow.position">{{ selectedRow.position }}</el-tag>
            </div>
          </div>
        </div>

        <div class="preferred-banner" v-if="selectedRow.preferredMethodLabel">
          默认收款方式：<strong>{{ selectedRow.preferredMethodLabel }}</strong>
        </div>

        <SalaryYearCollapse
          :key="selectedRow.employeeUuid"
          v-model:salary-year="salaryYear"
          :salary-months="salaryMonths"
          :loading="salaryYearLoading"
          :year-options="salaryYearOptions"
          :last-month-year-month="lastMonthYearMonth"
          @year-change="loadSalaryYear"
        />

        <template v-for="acc in selectedRow.boundAccounts || []" :key="acc.type">
          <div class="account-block" :class="{ preferred: acc.isPreferred }">
            <div class="account-block-header">
              <h4 class="block-title">{{ acc.label }}</h4>
              <el-tag v-if="acc.isPreferred" size="small" type="success">默认使用</el-tag>
            </div>
            <div class="info-list">
              <template v-if="acc.type === 'bank'">
                <div class="info-row">
                  <span class="label">收款人</span>
                  <span class="value">{{ selectedRow.accountHolder }}</span>
                </div>
                <div class="info-row">
                  <span class="label">开户行</span>
                  <span class="value">{{ selectedRow.bankName }}</span>
                </div>
                <div class="info-row">
                  <span class="label">银行账号</span>
                  <CopyableText class="value" :text="selectedRow.bankAccount" label="银行账号" />
                </div>
              </template>
              <template v-else-if="acc.type === 'usdt'">
                <div class="info-row">
                  <span class="label">网络</span>
                  <span class="value">{{ selectedRow.usdtNetwork || "-" }}</span>
                </div>
                <div class="info-row">
                  <span class="label">地址</span>
                  <CopyableText class="value" :text="selectedRow.usdtAddress" label="USDT地址" />
                </div>
              </template>
              <template v-else>
                <div class="info-row">
                  <span class="label">类型</span>
                  <span class="value">{{ selectedRow.otherWalletType || "-" }}</span>
                </div>
                <div class="info-row">
                  <span class="label">地址/账号</span>
                  <CopyableText class="value" :text="selectedRow.otherWalletAddress" label="钱包地址" />
                </div>
              </template>
            </div>
          </div>
        </template>

        <template v-if="selectedRow.remark">
          <h4 class="block-title">备注</h4>
          <p class="remark-text">{{ selectedRow.remark }}</p>
        </template>

        <div class="updated-at" v-if="selectedRow.updatedAt">
          最后更新：{{ formatTime(selectedRow.updatedAt) }}
        </div>
      </div>
      <template #footer>
        <SalaryDrawerFooter
          :paid-status="drawerLastMonthStatus || 'pending'"
          :mark-paid-disabled="drawerMarkPaidDisabled"
          @upload="handleDrawerUpload"
          @mark-paid="handleDrawerMarkPaid"
        />
      </template>
    </el-drawer>

    <SalaryPaymentProofDialog
      :key="proofUploadTarget?.employeeId || 'proof'"
      v-model:visible="proofUploadVisible"
      v-model:year-month="proofUploadForm.yearMonth"
      :uploading="proofUploading"
      :target="proofUploadTarget"
      :preview-url="proofPreviewUrl"
      @file-change="handleProofFileChange"
      @submit="submitProofUpload"
      @closed="clearProofPreview"
      @update:year-month="onProofMonthChange"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { Search, Refresh } from "@element-plus/icons-vue";
import adminApi from "@api/admin_api";
import SalaryYearCollapse from "@/components/salary/SalaryYearCollapse.vue";
import SalaryDrawerFooter from "@/components/salary/SalaryDrawerFooter.vue";
import SalaryPaidStatusButton from "@/components/salary/SalaryPaidStatusButton.vue";
import SalaryPaymentProofDialog from "@/components/salary/SalaryPaymentProofDialog.vue";
import CopyableText from "@/components/CopyableText.vue";
import { useSalaryPaymentActions } from "@/composables/useSalaryPaymentActions";
import {
  findSalaryMonthItem,
  formatSalaryAmount,
  getLastMonth,
  salaryStatusTagType,
} from "@/utils/salaryHelpers";

const loading = ref(false);
const items = ref<any[]>([]);
const total = ref(0);
const page = ref(1);
const pageSize = ref(50);
const searchKeyword = ref("");
const detailVisible = ref(false);
const selectedRow = ref<any>(null);
const salaryYear = ref(parseInt(getLastMonth().split("-")[0], 10));
const salaryYearOptions = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);
const salaryMonths = ref<any[]>([]);
const salaryYearLoading = ref(false);
const lastMonthYearMonth = getLastMonth();
let searchTimer: ReturnType<typeof setTimeout> | null = null;

async function refreshAfterPaymentAction() {
  await loadData();
  if (detailVisible.value && selectedRow.value?.employeeUuid) {
    const uuid = selectedRow.value.employeeUuid;
    await loadSalaryYear();
    const updated = items.value.find((item) => item.employeeUuid === uuid);
    if (updated) selectedRow.value = updated;
  }
}

const {
  proofUploading,
  proofUploadVisible,
  proofUploadTarget,
  proofUploadForm,
  proofPreviewUrl,
  clearProofPreview,
  openProofUploadDialog,
  handleProofFileChange,
  onProofMonthChange,
  submitProofUpload,
  markPaid,
} = useSalaryPaymentActions({ onSuccess: refreshAfterPaymentAction });

const detailTitle = computed(() =>
  selectedRow.value ? `${selectedRow.value.employeeName} · 收款信息` : "收款信息",
);

const drawerLastMonthStatus = computed(() => {
  const item = findSalaryMonthItem(salaryMonths.value, lastMonthYearMonth);
  return item?.status ?? selectedRow.value?.lastMonthStatus;
});

const drawerMarkPaidDisabled = computed(() => {
  if (!selectedRow.value) return true;
  const item = findSalaryMonthItem(salaryMonths.value, lastMonthYearMonth);
  const status = item?.status ?? selectedRow.value.lastMonthStatus;
  if (status === "paid") return true;
  if (item?.amount == null && !selectedRow.value.lastMonthSalaryId) return true;
  return false;
});

function formatTime(value: string) {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString("zh-CN", { hour12: false });
}

function getAvatarColor(name: string) {
  const colors = ["#667eea", "#764ba2", "#4facfe", "#43e97b", "#fa709a"];
  return colors[(name?.charCodeAt(0) || 0) % colors.length];
}

async function loadSalaryYear() {
  if (!selectedRow.value?.employeeUuid) return;
  salaryYearLoading.value = true;
  try {
    const response = await adminApi.getPaymentAddressSalaryYear(
      selectedRow.value.employeeUuid,
      { year: salaryYear.value },
    );
    salaryMonths.value = response.data?.months || [];
  } catch (error: any) {
    ElMessage.error(error.message || "加载工资明细失败");
    salaryMonths.value = [];
  } finally {
    salaryYearLoading.value = false;
  }
}

function openDetail(row: any) {
  selectedRow.value = row;
  detailVisible.value = true;
  salaryYear.value = parseInt(getLastMonth().split("-")[0], 10);
  loadSalaryYear();
}

function handleDrawerUpload() {
  if (selectedRow.value) {
    openProofUploadDialog(selectedRow.value, lastMonthYearMonth);
  }
}

function handleDrawerMarkPaid() {
  if (selectedRow.value) {
    markPaid(selectedRow.value, drawerLastMonthStatus.value);
  }
}

async function loadData() {
  loading.value = true;
  try {
    const response = await adminApi.listPaymentAddresses({
      skip: (page.value - 1) * pageSize.value,
      limit: pageSize.value,
      search: searchKeyword.value.trim() || undefined,
    });
    items.value = response.data?.items || [];
    total.value = response.data?.total || 0;
  } catch (error: any) {
    ElMessage.error(error.message || "加载收款地址失败");
  } finally {
    loading.value = false;
  }
}

function handleSearch() {
  if (searchTimer) clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    page.value = 1;
    loadData();
  }, 300);
}

onMounted(loadData);
</script>

<style scoped>
.payment-addresses-page {
  min-height: 100vh;
  padding: 0px;
  position: relative;
  background: #f0f2f6;
}

.bg-decoration {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.35;
}

.blob-1 {
  width: 420px;
  height: 420px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -120px;
  right: -80px;
}

.blob-2 {
  width: 520px;
  height: 520px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  bottom: -180px;
  left: -120px;
}

.blob-3 {
  width: 360px;
  height: 360px;
  background: linear-gradient(135deg, #43e97b, #38f9d7);
  top: 40%;
  left: 35%;
}

.toolbar-card,
.table-card {
  position: relative;
  z-index: 1;
  margin-bottom: 16px;
  border-radius: 16px;
}

.toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: center;
}

.toolbar-hint {
  color: #909399;
  font-size: 13px;
}

.name-link {
  color: #409eff;
  cursor: pointer;
  font-weight: 500;
}

.name-link:hover {
  text-decoration: underline;
}

.bound-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.bound-item {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  font-size: 13px;
}

.bound-item.preferred {
  color: #303133;
}

.bound-label {
  color: #909399;
  flex-shrink: 0;
}

.bound-value {
  word-break: break-all;
}

.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.pagination-wrapper {
  margin-top: 16px;
  display: flex;
  justify-content: flex-end;
}

.detail-panel {
  padding: 0 4px 24px;
}

.employee-block {
  display: flex;
  gap: 16px;
  align-items: center;
  padding-bottom: 20px;
  margin-bottom: 16px;
  border-bottom: 1px solid #ebeef5;
}

.employee-name {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
}

.employee-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.preferred-banner {
  margin-bottom: 16px;
  padding: 10px 12px;
  background: #f0f9eb;
  border-radius: 8px;
  color: #67c23a;
  font-size: 14px;
}

.account-block {
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ebeef5;
  border-radius: 10px;
}

.account-block.preferred {
  border-color: #b3e19d;
  background: #fafdf8;
}

.account-block-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}

.block-title {
  margin: 0;
  font-size: 15px;
  color: #606266;
}

.info-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.info-row {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  padding: 8px 10px;
  background: #f5f7fa;
  border-radius: 8px;
}

.info-row .label {
  color: #909399;
  flex-shrink: 0;
}

.info-row .value {
  color: #303133;
  font-weight: 500;
  text-align: right;
  word-break: break-all;
}

.info-row :deep(.copyable-text.value) {
  text-align: right;
  max-width: 100%;
}

.remark-text {
  margin: 0 0 24px;
  padding: 12px;
  background: #f5f7fa;
  border-radius: 8px;
  color: #606266;
  line-height: 1.6;
}

.updated-at {
  font-size: 13px;
  color: #909399;
}

.salary-status-cell {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  font-size: 13px;
}

.salary-month {
  color: #606266;
  font-weight: 500;
}

.salary-amount {
  color: #303133;
  font-weight: 600;
}

.pending-text {
  color: #e6a23c;
}

.salary-year-section {
  margin-bottom: 24px;
  padding-bottom: 20px;
  border-bottom: 1px solid #ebeef5;
}

.salary-year-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.salary-month-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  min-height: 48px;
}

.salary-month-item {
  padding: 10px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  background: #fafafa;
  text-align: center;
}

.salary-month-item.paid {
  border-color: #b3e19d;
  background: #fafdf8;
}

.salary-month-item.pending {
  border-color: #f3d19e;
  background: #fdfaf3;
}

.salary-month-item .month-label {
  font-size: 13px;
  color: #909399;
  margin-bottom: 4px;
}

.salary-month-item .month-amount {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 6px;
  word-break: break-all;
}

.salary-month-item .month-amount.empty {
  color: #c0c4cc;
  font-weight: 400;
}
</style>

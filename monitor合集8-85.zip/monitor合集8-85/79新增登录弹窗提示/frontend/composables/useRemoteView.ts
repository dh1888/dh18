import { ref, shallowRef } from "vue";
import {
  Room,
  RoomEvent,
  Track,
  ConnectionState,
  type RemoteTrack,
  type RemoteTrackPublication,
  type RemoteParticipant,
} from "livekit-client";
import { remoteViewApi } from "@api/index";
import type { RemoteViewStartSession, RemoteViewStatus } from "@api/types";

export type RemoteViewStartupPhase =
  | "idle"
  | "preparing"
  | "publisher"
  | "player"
  | "active";

const PUBLISHER_POLL_MS = 200;
const PUBLISHER_SETTLE_MS = 120;
const QUALITY_SWITCH_SETTLE_MS = 900;
const QUALITY_SWITCH_COOLDOWN_MS = 12_000;
const VIDEO_ATTACH_TIMEOUT_MS = 2200;
const BACKGROUND_LIVE_SAMPLE_MS = 1200;
const BACKGROUND_LIVE_RETRIES = 3;
const BACKGROUND_LIVE_RETRY_GAP_MS = 2000;
const WHIP_FIRST_FRAME_BUFFER_MS = 2000;

const expectedPublisherIdentity = (deviceId: string, sessionId: string) => {
  const short = sessionId.replace(/-/g, "").slice(0, 8);
  return `agent-${deviceId}-${short}`;
};

const isExpectedPublisher = (
  participant: RemoteParticipant,
  deviceId: string,
  sessionId: string,
) => participant.identity === expectedPublisherIdentity(deviceId, sessionId);

export function useRemoteView() {
  const room = shallowRef<Room | null>(null);
  const connectionState = ref<ConnectionState>(ConnectionState.Disconnected);
  const sessionInfo = ref<RemoteViewStartSession | null>(null);
  const sessionStatus = ref("");
  const startupPhase = ref<RemoteViewStartupPhase>("idle");
  const stats = ref({
    fps: 0,
    bitrateKbps: 0,
    encoder: "",
  });

  let reconnectAttempts = 0;
  let reconnectTimer: number | null = null;
  let viewGeneration = 0;
  let activeVideoContainer: HTMLElement | null = null;
  let suppressTrackAttach = false;
  let qualitySwitchCooldownUntil = 0;
  let republishChain = Promise.resolve();
  let activeQuality: "weak" | "auto" | "strong" = "strong";
  const MAX_RECONNECT = 5;

  const withRepublishLock = async <T>(operation: () => Promise<T>): Promise<T> => {
    const op = republishChain.then(operation);
    republishChain = op.then(
      () => undefined,
      () => undefined,
    );
    return op;
  };

  const clearVideoContainer = (container?: HTMLElement | null) => {
    const target = container ?? activeVideoContainer;
    target?.replaceChildren();
  };

  const attachVideo = (container: HTMLElement, track: RemoteTrack) => {
    try {
      track.setPlayoutDelay(0);
    } catch {
      // older SDK / non-video tracks
    }
    try {
      track.start();
    } catch {
      // already started
    }
    const element = track.attach() as HTMLVideoElement;
    element.className = "remote-video-player";
    element.playsInline = true;
    element.muted = true;
    element.autoplay = true;
    container.replaceChildren(element);
    void element.play().catch(() => {
      window.setTimeout(() => {
        void element.play().catch(() => {});
      }, 300);
    });
  };

  const clearReconnectTimer = () => {
    if (reconnectTimer != null) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
  };

  const subscribeExpectedPublisherTracks = (
    lkRoom: Room,
    deviceId: string,
    sessionId: string,
  ) => {
    for (const participant of lkRoom.remoteParticipants.values()) {
      if (!isExpectedPublisher(participant, deviceId, sessionId)) continue;
      for (const publication of participant.trackPublications.values()) {
        const pub = publication as RemoteTrackPublication;
        if (pub.kind === Track.Kind.Video && !pub.isSubscribed) {
          pub.setSubscribed(true);
        }
      }
    }
  };

  const attachExistingVideoTracks = (
    lkRoom: Room,
    container: HTMLElement,
    deviceId: string,
    sessionId: string,
  ) => {
    for (const participant of lkRoom.remoteParticipants.values()) {
      if (!isExpectedPublisher(participant, deviceId, sessionId)) continue;
      for (const publication of participant.trackPublications.values()) {
        const pub = publication as RemoteTrackPublication;
        if (pub.track && pub.kind === Track.Kind.Video) {
          attachVideo(container, pub.track as RemoteTrack);
          return;
        }
      }
    }
  };

  const bindRoomEvents = (
    lkRoom: Room,
    videoContainer: HTMLElement,
    generation: number,
    deviceId: string,
    sessionId: string,
  ) => {
    lkRoom.on(RoomEvent.ParticipantConnected, (participant) => {
      if (generation !== viewGeneration) return;
      if (!isExpectedPublisher(participant, deviceId, sessionId)) return;
      for (const publication of participant.trackPublications.values()) {
        const pub = publication as RemoteTrackPublication;
        if (pub.kind === Track.Kind.Video && !pub.isSubscribed) {
          pub.setSubscribed(true);
        }
      }
    });

    lkRoom.on(RoomEvent.TrackSubscribed, (track, _publication, participant) => {
      if (generation !== viewGeneration) return;
      if (track.kind !== Track.Kind.Video) return;
      if (suppressTrackAttach) return;
      if (!isExpectedPublisher(participant, deviceId, sessionId)) return;
      attachVideo(videoContainer, track as RemoteTrack);
      sessionStatus.value = "active";
      startupPhase.value = "active";
    });

    lkRoom.on(RoomEvent.TrackUnsubscribed, (track) => {
      if (generation !== viewGeneration) return;
      if (track.kind !== Track.Kind.Video) return;
      track.detach();
      // During quality switch the publisher restarts; keep the last frame visible.
      if (suppressTrackAttach) return;
      clearVideoContainer(videoContainer);
      if (generation === viewGeneration) {
        sessionStatus.value = "starting";
        startupPhase.value = "player";
      }
    });

    lkRoom.on(RoomEvent.ConnectionStateChanged, (state) => {
      if (generation !== viewGeneration) return;
      connectionState.value = state;
      if (state === ConnectionState.Connected) {
        reconnectAttempts = 0;
        if (sessionStatus.value !== "active") {
          sessionStatus.value = "starting";
          startupPhase.value = "player";
        }
      } else if (state === ConnectionState.Reconnecting) {
        sessionStatus.value = "reconnecting";
      }
    });

    lkRoom.on(RoomEvent.Reconnected, () => {
      if (generation !== viewGeneration) return;
      reconnectAttempts = 0;
      subscribeExpectedPublisherTracks(lkRoom, deviceId, sessionId);
      attachExistingVideoTracks(lkRoom, videoContainer, deviceId, sessionId);
      if (videoContainer.querySelector("video")) {
        sessionStatus.value = "active";
        startupPhase.value = "active";
        resumePlayback(videoContainer);
      }
    });

    lkRoom.on(RoomEvent.Disconnected, () => {
      if (generation !== viewGeneration) return;
      sessionStatus.value = "disconnected";
      startupPhase.value = "idle";
      console.warn("[RemoteView] LiveKit disconnected; waiting for SDK reconnect or manual stop");
    });
  };

  const resumePlayback = (container: HTMLElement) => {
    const video = container.querySelector("video") as HTMLVideoElement | null;
    if (video) {
      void video.play().catch(() => {});
    }
  };

  let resuming = false;

  const resumeView = async () => {
    if (resuming) return;
    const info = sessionInfo.value;
    const container = activeVideoContainer;
    const lkRoom = room.value;
    if (!info || !container || !lkRoom) return;

    const state = lkRoom.state;
    if (
      state === ConnectionState.Connecting ||
      state === ConnectionState.Reconnecting
    ) {
      return;
    }

    if (state === ConnectionState.Connected) {
      if (sessionStatus.value === "starting") return;
      if (sessionStatus.value === "active") resumePlayback(container);
      return;
    }

    if (state !== ConnectionState.Disconnected) return;
    if (sessionStatus.value !== "disconnected" && sessionStatus.value !== "active") {
      return;
    }

    resuming = true;
    try {
      sessionStatus.value = "reconnecting";
      startupPhase.value = "player";
      await lkRoom.connect(info.livekitUrl, info.viewerToken);
      connectionState.value = ConnectionState.Connected;
      const attached = await waitForVideoTrack(
        lkRoom,
        container,
        viewGeneration,
        info.deviceId,
        info.sessionId,
        VIDEO_ATTACH_TIMEOUT_MS,
      );
      if (attached) {
        sessionStatus.value = "active";
        startupPhase.value = "active";
      } else {
        sessionStatus.value = "starting";
      }
    } catch (error) {
      sessionStatus.value = "disconnected";
      startupPhase.value = "idle";
      console.warn("[RemoteView] resumeView failed", error);
    } finally {
      resuming = false;
    }
  };

  const refreshVideoAttachment = async () => {
    const container = activeVideoContainer;
    const lkRoom = room.value;
    const info = sessionInfo.value;
    const generation = viewGeneration;
    if (!container || !lkRoom || !info || lkRoom.state !== ConnectionState.Connected) {
      return;
    }
    clearVideoContainer(container);
    sessionStatus.value = "starting";
    startupPhase.value = "player";
    subscribeExpectedPublisherTracks(lkRoom, info.deviceId, info.sessionId);
    const attached = await waitForVideoTrack(
      lkRoom,
      container,
      generation,
      info.deviceId,
      info.sessionId,
      VIDEO_ATTACH_TIMEOUT_MS,
    );
    if (room.value !== lkRoom || viewGeneration !== generation) return;
    if (attached) {
      sessionStatus.value = "active";
      startupPhase.value = "active";
      resumePlayback(container);
    }
  };

  const VIDEO_LIVE_MIN_DELTA = 0.15;

  const isVideoPlaybackLive = async (
    container: HTMLElement,
    sampleMs = BACKGROUND_LIVE_SAMPLE_MS,
  ): Promise<boolean> => {
    const video = container.querySelector("video") as HTMLVideoElement | null;
    if (!video || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) {
      return false;
    }
    const t0 = video.currentTime;
    await sleep(sampleMs);
    const t1 = video.currentTime;
    return t1 - t0 >= VIDEO_LIVE_MIN_DELTA;
  };

  const isHealthyActiveSession = (status?: RemoteViewStatus | null) =>
    !!status?.isActive &&
    status.status === "active" &&
    status.statsFresh === true &&
    (status.stats?.fps ?? 0) > 0;

  const hasFreshPublisherStats = (status?: RemoteViewStatus | null) => {
    if (!status?.statsFresh || !status.stats) return false;
    const fps = status.stats.fps ?? 0;
    const bitrate = status.stats.bitrateKbps ?? 0;
    return fps > 0 || bitrate > 0;
  };

  const canReuseSession = (status?: RemoteViewStatus | null) => {
    if (!status?.isActive || !status.sessionId) return false;
    if (!status.statsFresh) return false;
    if (isHealthyActiveSession(status)) return true;
    if (status.status === "active" && hasFreshPublisherStats(status)) return true;
    return status.status === "starting";
  };

  const waitForVideoTrack = (
    lkRoom: Room,
    container: HTMLElement,
    generation: number,
    deviceId: string,
    sessionId: string,
    timeoutMs = VIDEO_ATTACH_TIMEOUT_MS,
  ) =>
    new Promise<boolean>((resolve) => {
      if (generation !== viewGeneration) {
        resolve(false);
        return;
      }

      subscribeExpectedPublisherTracks(lkRoom, deviceId, sessionId);
      attachExistingVideoTracks(lkRoom, container, deviceId, sessionId);
      if (container.querySelector("video")) {
        resolve(true);
        return;
      }

      let settled = false;
      const finish = (ok: boolean) => {
        if (settled) return;
        settled = true;
        lkRoom.off(RoomEvent.TrackSubscribed, onTrack);
        window.clearTimeout(timer);
        resolve(ok);
      };

      const onTrack = (
        track: RemoteTrack,
        _publication: RemoteTrackPublication,
        participant: RemoteParticipant,
      ) => {
        if (generation !== viewGeneration) {
          finish(false);
          return;
        }
        if (track.kind !== Track.Kind.Video) return;
        if (suppressTrackAttach) return;
        if (!isExpectedPublisher(participant, deviceId, sessionId)) return;
        attachVideo(container, track);
        finish(true);
      };

      lkRoom.on(RoomEvent.TrackSubscribed, onTrack);
      const timer = window.setTimeout(
        () => finish(!!container.querySelector("video")),
        timeoutMs,
      );
    });

  const reconnectLiveKitPlayer = async (
    container: HTMLElement,
    generation: number,
  ) => {
    const lkRoom = room.value;
    const info = sessionInfo.value;
    if (!lkRoom || !info || generation !== viewGeneration) return false;

    try {
      await lkRoom.disconnect();
      await lkRoom.connect(info.livekitUrl, info.viewerToken);
      if (generation !== viewGeneration) return false;
      connectionState.value = ConnectionState.Connected;
      subscribeExpectedPublisherTracks(lkRoom, info.deviceId, info.sessionId);
      return waitForVideoTrack(
        lkRoom,
        container,
        generation,
        info.deviceId,
        info.sessionId,
        VIDEO_ATTACH_TIMEOUT_MS,
      );
    } catch (error) {
      console.warn("[RemoteView] LiveKit reconnect failed", error);
      return false;
    }
  };

  const recoverPlayerAfterPublisherReady = async (
    container: HTMLElement,
    generation: number,
  ) => {
    if (generation !== viewGeneration) return false;
    startupPhase.value = "player";
    // Encoder restart publishes a new LiveKit track — reconnect subscribes to it.
    let attached = await reconnectLiveKitPlayer(container, generation);
    if (!attached) {
      await refreshVideoAttachment();
      attached = !!container.querySelector("video");
    }
    if (attached && generation === viewGeneration) {
      sessionStatus.value = "active";
      startupPhase.value = "active";
      resumePlayback(container);
    }
    return attached;
  };

  const switchQuality = async (
    deviceId: string,
    quality: "weak" | "auto" | "strong",
    sessionId: string,
    generation: number,
  ) => {
    await withRepublishLock(async () => {
      if (generation !== viewGeneration) return;
      activeQuality = quality;
      qualitySwitchCooldownUntil = Date.now() + QUALITY_SWITCH_COOLDOWN_MS;
      suppressTrackAttach = true;
      startupPhase.value = "publisher";
      sessionStatus.value = "starting";
      try {
        await remoteViewApi.setQuality(deviceId, quality, sessionId);
        const ready = await waitForPublisherReady(deviceId, sessionId, generation);
        if (!ready) {
          throw new Error("画质切换超时，请重试");
        }
        if (generation !== viewGeneration) return;
        await sleep(QUALITY_SWITCH_SETTLE_MS);
        const container = activeVideoContainer;
        if (!container) return;
        const attached = await recoverPlayerAfterPublisherReady(container, generation);
        if (!attached && generation === viewGeneration) {
          throw new Error("画质切换后未能恢复画面");
        }
      } finally {
        if (generation === viewGeneration) suppressTrackAttach = false;
      }
    });
  };

  const ensureLivePlaybackInBackground = (
    container: HTMLElement,
    generation: number,
  ) => {
    void (async () => {
      if (generation !== viewGeneration) return;
      if (Date.now() < qualitySwitchCooldownUntil) return;

      await sleep(WHIP_FIRST_FRAME_BUFFER_MS);

      for (let attempt = 0; attempt < BACKGROUND_LIVE_RETRIES; attempt++) {
        if (generation !== viewGeneration) return;
        if (Date.now() < qualitySwitchCooldownUntil) return;

        await sleep(BACKGROUND_LIVE_SAMPLE_MS);
        if (generation !== viewGeneration) return;
        if (await isVideoPlaybackLive(container, BACKGROUND_LIVE_SAMPLE_MS)) {
          return;
        }
        if (attempt < BACKGROUND_LIVE_RETRIES - 1) {
          await sleep(BACKGROUND_LIVE_RETRY_GAP_MS);
        }
      }

      if (generation !== viewGeneration) return;
      console.warn("[RemoteView] dead frame after attach; recovering playback");
      await recoverFromDeadFrame(container, generation);
    })();
  };

  const sleep = (ms: number) =>
    new Promise<void>((resolve) => {
      window.setTimeout(resolve, ms);
    });

  const waitForPublisherReady = async (
    deviceId: string,
    sessionId: string,
    generation: number,
  ): Promise<boolean> => {
    let resolved = false;
    let ready = false;

    const onPublishedEvent = (event: Event) => {
      if (generation !== viewGeneration || resolved) return;
      const detail = (event as CustomEvent).detail as {
        deviceId?: string;
        sessionId?: string;
        event?: string;
      };
      if (detail.deviceId !== deviceId || detail.sessionId !== sessionId) return;
      if (detail.event === "failed") {
        resolved = true;
        ready = false;
      }
      if (detail.event === "published") {
        resolved = true;
        ready = true;
      }
    };

    window.addEventListener("remote-view-event", onPublishedEvent);

    const deadline = Date.now() + 25_000;
    let liveTicks = 0;
    while (Date.now() < deadline && generation === viewGeneration && !resolved) {
      try {
        const data = await refreshStatus(deviceId);
        if (data.sessionId !== sessionId) {
          liveTicks = 0;
        } else if (data.status === "active" && (data.stats?.fps ?? 0) > 0) {
          resolved = true;
          ready = true;
          break;
        } else if (data.status === "active" || (data.stats?.fps ?? 0) > 0) {
          liveTicks += 1;
          if (liveTicks >= 1) {
            resolved = true;
            ready = true;
            break;
          }
        } else {
          liveTicks = 0;
        }
      } catch {
        // ignore polling errors
      }
      await sleep(PUBLISHER_POLL_MS);
    }

    window.removeEventListener("remote-view-event", onPublishedEvent);
    if (ready) await sleep(PUBLISHER_SETTLE_MS);
    return ready;
  };

  const recoverFromDeadFrame = async (
    container: HTMLElement,
    generation: number,
  ): Promise<boolean> => {
    if (generation !== viewGeneration) return false;

    await refreshVideoAttachment();
    resumePlayback(container);
    if (await isVideoPlaybackLive(container)) {
      return true;
    }

    const info = sessionInfo.value;
    if (!info || generation !== viewGeneration) return false;

    const status = await refreshStatus(info.deviceId);
    if (generation !== viewGeneration) return false;

    if (!hasFreshPublisherStats(status)) {
      console.warn("[RemoteView] publisher stats stale; republishing encoder");
      await withRepublishLock(async () => {
        if (generation !== viewGeneration) return;
        await remoteViewApi.setQuality(info.deviceId, activeQuality, info.sessionId);
        const ready = await waitForPublisherReady(
          info.deviceId,
          info.sessionId,
          generation,
        );
        if (!ready || generation !== viewGeneration) return;
        await sleep(QUALITY_SWITCH_SETTLE_MS);
        await refreshVideoAttachment();
      });
      resumePlayback(container);
      if (await isVideoPlaybackLive(container)) {
        if (generation === viewGeneration) {
          sessionStatus.value = "active";
          startupPhase.value = "active";
        }
        return true;
      }
    }

    console.warn("[RemoteView] dead frame persists; reconnecting LiveKit player");
    const attached = await reconnectLiveKitPlayer(container, generation);
    if (attached && generation === viewGeneration) {
      sessionStatus.value = "active";
      startupPhase.value = "active";
      resumePlayback(container);
    }
    return attached;
  };

  const ensureCleanStart = async (deviceId: string, generation: number) => {
    if (room.value) {
      try {
        await room.value.disconnect();
      } catch {
        // ignore
      }
      room.value = null;
    }
    clearVideoContainer(activeVideoContainer);
    sessionInfo.value = null;
    stats.value = { fps: 0, bitrateKbps: 0, encoder: "" };

    try {
      const { data: status } = await remoteViewApi.getStatus(deviceId);
      if (generation !== viewGeneration) return status;
      if (
        status?.isActive &&
        status.sessionId &&
        (!status.statsFresh || !isHealthyActiveSession(status))
      ) {
        await remoteViewApi.stop(deviceId, status.sessionId, { hard: true });
        await sleep(200);
        return null;
      }
      return status;
    } catch {
      return null;
    }
  };

  const startView = async (
    deviceId: string,
    videoContainer: HTMLElement,
    quality: "weak" | "auto" | "strong" = "strong",
  ) => {
    let startedSessionId: string | undefined;
    const generation = ++viewGeneration;
    activeVideoContainer = videoContainer;
    clearVideoContainer(videoContainer);
    startupPhase.value = "preparing";

    try {
      const priorStatus = await ensureCleanStart(deviceId, generation);
      if (generation !== viewGeneration) {
        throw new Error("Remote view start cancelled");
      }

      const freshStart = !canReuseSession(priorStatus);
      activeQuality = quality;
      startupPhase.value = "publisher";

      const { data } = await remoteViewApi.start(deviceId, { quality, freshStart });
      if (generation !== viewGeneration) {
        await remoteViewApi.stop(deviceId, data.sessionId, { hard: true });
        throw new Error("Remote view start cancelled");
      }

      sessionInfo.value = data;
      sessionStatus.value = "starting";
      startedSessionId = data.sessionId;

      const skipPublisherWait =
        !freshStart &&
        (isHealthyActiveSession(priorStatus) ||
          (priorStatus?.sessionId === data.sessionId &&
            priorStatus?.status === "active" &&
            hasFreshPublisherStats(priorStatus)));

      let publisherReady = skipPublisherWait;
      startupPhase.value = "player";
      const lkRoom = new Room({
        adaptiveStream: false,
        dynacast: false,
        disconnectOnPageLeave: true,
        autoSubscribe: false,
        expFastStart: true,
      });

      bindRoomEvents(lkRoom, videoContainer, generation, deviceId, data.sessionId);
      suppressTrackAttach = false;

      const connectPlayer = async () => {
        await lkRoom.connect(data.livekitUrl, data.viewerToken);
        if (generation !== viewGeneration) {
          await lkRoom.disconnect();
          throw new Error("Remote view start cancelled");
        }
        room.value = lkRoom;
        connectionState.value = ConnectionState.Connected;
        subscribeExpectedPublisherTracks(lkRoom, deviceId, data.sessionId);
      };

      const publisherPromise = publisherReady
        ? Promise.resolve(true)
        : waitForPublisherReady(deviceId, data.sessionId, generation);

      const [, publisherReadyResult] = await Promise.all([
        connectPlayer(),
        publisherPromise,
      ]);
      publisherReady = publisherReadyResult;

      if (generation !== viewGeneration) {
        await lkRoom.disconnect();
        throw new Error("Remote view start cancelled");
      }
      if (!publisherReady) {
        await lkRoom.disconnect();
        throw new Error("远程推流启动超时，请重试");
      }

      const attached = await waitForVideoTrack(
        lkRoom,
        videoContainer,
        generation,
        deviceId,
        data.sessionId,
        VIDEO_ATTACH_TIMEOUT_MS,
      );
      if (generation !== viewGeneration) {
        await lkRoom.disconnect();
        throw new Error("Remote view start cancelled");
      }

      if (attached) {
        sessionStatus.value = "active";
        startupPhase.value = "active";
        resumePlayback(videoContainer);
        // Agent sends "published" only after WHIP is ready (incl. slow-publish recovery).
        // Reconnecting here adds ~1–2s glass-to-glass latency on first open.
      }

      ensureLivePlaybackInBackground(videoContainer, generation);

      return data;
    } catch (error) {
      suppressTrackAttach = false;
      startupPhase.value = "idle";
      if (startedSessionId) {
        try {
          await remoteViewApi.stop(deviceId, startedSessionId, { hard: true });
        } catch {
          // ignore cleanup errors
        }
      }
      sessionInfo.value = null;
      sessionStatus.value = "";
      throw error;
    }
  };

  const setQuality = async (
    deviceId: string,
    quality: "weak" | "auto" | "strong",
  ) => {
    const sessionId = sessionInfo.value?.sessionId;
    if (!sessionId) throw new Error("No active remote view session");
    await switchQuality(deviceId, quality, sessionId, viewGeneration);
  };

  const stopView = async (
    deviceId: string,
    opts?: { hardStop?: boolean },
  ) => {
    viewGeneration += 1;
    suppressTrackAttach = false;
    reconnectAttempts = MAX_RECONNECT;
    clearReconnectTimer();
    const container = activeVideoContainer;
    const sessionId = sessionInfo.value?.sessionId;
    if (room.value) {
      try {
        await room.value.disconnect();
      } catch {
        // ignore
      }
      room.value = null;
    }
    clearVideoContainer(container);
    activeVideoContainer = null;
    if (sessionId) {
      try {
        await remoteViewApi.stop(deviceId, sessionId, { hard: opts?.hardStop ?? false });
      } catch {
        // ignore duplicate stop
      }
    }
    sessionInfo.value = null;
    sessionStatus.value = "";
    startupPhase.value = "idle";
    connectionState.value = ConnectionState.Disconnected;
    stats.value = { fps: 0, bitrateKbps: 0, encoder: "" };
  };

  const refreshStatus = async (deviceId: string) => {
    const { data } = await remoteViewApi.getStatus(deviceId);
    sessionStatus.value = data.status || (data.isActive ? "active" : "");
    if (data.statsFresh && data.stats) {
      stats.value = {
        fps: data.stats.fps,
        bitrateKbps: data.stats.bitrateKbps,
        encoder: data.stats.encoder,
      };
    } else if (!data.isActive) {
      stats.value = { fps: 0, bitrateKbps: 0, encoder: "" };
    }
    return data;
  };

  const applyRemoteStats = (payload: {
    fps?: number;
    bitrateKbps?: number;
    encoder?: string;
  }) => {
    stats.value = {
      fps: payload.fps ?? stats.value.fps,
      bitrateKbps: payload.bitrateKbps ?? stats.value.bitrateKbps,
      encoder: payload.encoder ?? stats.value.encoder,
    };
  };

  return {
    room,
    connectionState,
    sessionInfo,
    sessionStatus,
    startupPhase,
    stats,
    startView,
    setQuality,
    stopView,
    refreshStatus,
    applyRemoteStats,
    resumeView,
  };
}

import { ref } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import adminApi from "@api/admin_api";
import {
  formatMonthLabel,
  getLastMonth,
  normalizeSalaryEmployee,
  type SalaryEmployeeContext,
} from "@/utils/salaryHelpers";

export function useSalaryPaymentActions(hooks?: {
  onSuccess?: () => void | Promise<void>;
}) {
  const proofUploading = ref(false);
  const proofUploadVisible = ref(false);
  const proofUploadTarget = ref<SalaryEmployeeContext | null>(null);
  const proofUploadForm = ref({ yearMonth: "", file: null as File | null });
  const proofUploadRef = ref();
  const proofPreviewUrl = ref("");

  function clearProofPreview() {
    if (proofPreviewUrl.value) {
      URL.revokeObjectURL(proofPreviewUrl.value);
      proofPreviewUrl.value = "";
    }
  }

  async function loadExistingProofPreview(employeeId: string, yearMonth: string) {
    clearProofPreview();
    if (!employeeId || !yearMonth) return;
    try {
      const res = await adminApi.getSalaryPaymentProof({ employeeId, yearMonth });
      const proof = res.data;
      if (proof?.id) {
        const blobRes = await adminApi.fetchSalaryPaymentProofFile(proof.id);
        proofPreviewUrl.value = URL.createObjectURL(blobRes.data as Blob);
      }
    } catch {
      /* ignore */
    }
  }

  function openProofUploadDialog(row: any, yearMonth?: string) {
    const context = normalizeSalaryEmployee(row);
    if (!context) {
      ElMessage.warning("员工信息无效");
      return;
    }
    proofUploadTarget.value = context;
    proofUploadForm.value = {
      yearMonth: yearMonth || context.lastMonthYearMonth || getLastMonth(),
      file: null,
    };
    proofUploadVisible.value = true;
    if (proofUploadRef.value) proofUploadRef.value.clearFiles();
    loadExistingProofPreview(context.employeeId, proofUploadForm.value.yearMonth);
  }

  function handleProofFileChange(file: any) {
    proofUploadForm.value.file = file.raw;
  }

  function onProofMonthChange(month: string) {
    if (proofUploadTarget.value?.employeeId && month) {
      loadExistingProofPreview(proofUploadTarget.value.employeeId, month);
    }
  }

  async function submitProofUpload() {
    if (!proofUploadForm.value.yearMonth) {
      ElMessage.warning("请选择工资月份");
      return;
    }
    if (!proofUploadForm.value.file) {
      ElMessage.warning("请选择打款截图");
      return;
    }
    if (!proofUploadTarget.value?.employeeId) {
      ElMessage.warning("员工信息无效");
      return;
    }
    proofUploading.value = true;
    try {
      const formData = new FormData();
      formData.append("file", proofUploadForm.value.file);
      formData.append("employeeId", proofUploadTarget.value.employeeId);
      formData.append("yearMonth", proofUploadForm.value.yearMonth);
      await adminApi.uploadSalaryPaymentProof(formData);
      ElMessage.success("打款截图上传成功");
      proofUploadVisible.value = false;
      await hooks?.onSuccess?.();
    } catch (error: any) {
      ElMessage.error(error.message || "上传失败");
    } finally {
      proofUploading.value = false;
    }
  }

  async function markPaidRecord(options: {
    employeeId: string;
    employeeName: string;
    yearMonth: string;
    salaryId?: string;
    status?: string;
  }) {
    if (options.status === "paid") {
      ElMessage.info("该月工资已是已发状态");
      return;
    }
    try {
      await ElMessageBox.confirm(
        `确认将 ${options.employeeName} ${formatMonthLabel(options.yearMonth)} 工资标记为已发？`,
        "标记已发",
        { type: "warning", confirmButtonText: "确认", cancelButtonText: "取消" },
      );
      await adminApi.markSalaryPaid({
        id: options.salaryId || undefined,
        employeeId: options.employeeId,
        yearMonth: options.yearMonth,
      });
      ElMessage.success("已标记为已发");
      await hooks?.onSuccess?.();
    } catch (error: any) {
      if (error !== "cancel") {
        ElMessage.error(error.message || "操作失败");
      }
    }
  }

  async function markPaid(row: any, monthStatus?: string) {
    const context = normalizeSalaryEmployee(row);
    if (!context) {
      ElMessage.warning("员工信息无效");
      return;
    }
    await markPaidRecord({
      employeeId: context.employeeId,
      employeeName: context.employeeName,
      yearMonth: context.lastMonthYearMonth || getLastMonth(),
      salaryId: context.lastMonthSalaryId,
      status: monthStatus ?? context.lastMonthStatus,
    });
  }

  function isMarkPaidDisabled(row: any, monthStatus?: string) {
    const context = normalizeSalaryEmployee(row);
    if (!context) return true;
    const status = monthStatus ?? context.lastMonthStatus;
    return status === "paid";
  }

  return {
    proofUploading,
    proofUploadVisible,
    proofUploadTarget,
    proofUploadForm,
    proofUploadRef,
    proofPreviewUrl,
    clearProofPreview,
    openProofUploadDialog,
    handleProofFileChange,
    onProofMonthChange,
    submitProofUpload,
    markPaid,
    markPaidRecord,
    isMarkPaidDisabled,
  };
}

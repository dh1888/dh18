# cyberphone/json-canonicalization (vendored)

RFC 8785 JCS reference implementation used by Backend (Go) and Agent (C#).

Source: https://github.com/cyberphone/json-canonicalization (Apache-2.0)

- Go: `go/src/webpki.org/jsoncanonicalizer/`
- .NET: `dotnet/jsoncanonicalizer/` + `dotnet/es6numberserializer/`

Do not modify vendored files unless upgrading to a new upstream release.

# LiveKit 部署文件（生产）

本目录是**线上配置源**，与服务器 `/www/wwwroot/livekit` 对齐。  
文档备份：`docs/livekit.yaml`、`docs/livekit-docker-compose.yml`（须同步）。  
完整步骤：[`docs/livekit-部署流程.md`](../docs/livekit-部署流程.md)

## 架构（已验证：WHIP-only + SharedBridge）

```
录屏(gdigrab 或 SharedBridge 生产者)
        │
        ├─► FFmpeg 录屏 → 本地 MP4 切片
        └─► FFmpeg WHIP → Nginx /w → Ingress:8085（仅本机）
                              │
                              └─ UDP 7893 → LiveKit Room
                                              │
浏览器 ◄── wss /livekit + RTC 7881/7882-7892 ─┘
```

- **协议**：`REMOTE_VIEW_PUBLISH_PROTOCOL=whip`（不回退 RTMP）
- **采集**：有录屏 → SharedBridge；无录屏 → DualGdigrab
- **镜像**：`livekit-server:v1.13.3` + `ingress:v1.4.3`

## 同步到服务器

```bash
mkdir -p /www/wwwroot/livekit
# 上传本目录 livekit.yaml、docker-compose.yml
cd /www/wwwroot/livekit
# eth0 私网变更时改 compose 内 node_ip: 公网/私网
docker compose up -d
docker logs --tail=40 $(docker ps -qf name=ingress)
curl -sI http://127.0.0.1:8085/w/testkey   # 期望 405
ss -ulnp | grep 7893
```

## Backend（关键）

```env
LIVEKIT_URL=wss://dhpg8.duckdns.org/livekit
LIVEKIT_API_HOST=http://127.0.0.1:7880
LIVEKIT_API_KEY=enterprise
LIVEKIT_API_SECRET=<与 livekit.yaml keys 一致>
LIVEKIT_WHIP_BASE_URL=https://dhpg8.duckdns.org/w
REMOTE_VIEW_PUBLISH_PROTOCOL=whip
```

## 安全组

| 端口 | 说明 |
|------|------|
| 443/TCP | Nginx `/w`、`/livekit` |
| 7881/TCP | 浏览器 WebRTC TCP |
| 7882–7892/UDP | 浏览器媒体 |
| **7893/UDP** | Agent WHIP 媒体（必须） |
| 1935/TCP | 可选（RTMP 休眠） |

**不要**公网开放 8085；**不要**给 Ingress 配 `tcp_port`。

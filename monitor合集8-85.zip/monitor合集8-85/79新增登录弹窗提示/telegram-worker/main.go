// Optional standalone Telegram worker (default: bot is embedded in backend).
package main

import (
	"context"
	"log"

	"enterprise-agent/backend/internal/tgbot"
)

func main() {
	if err := tgbot.RunStandalone(context.Background()); err != nil {
		log.Fatal(err)
	}
}

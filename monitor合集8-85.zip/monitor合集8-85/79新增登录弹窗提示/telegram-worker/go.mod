module enterprise-agent/telegram-worker

go 1.26

require enterprise-agent/backend v0.0.0

replace enterprise-agent/backend => ../backend

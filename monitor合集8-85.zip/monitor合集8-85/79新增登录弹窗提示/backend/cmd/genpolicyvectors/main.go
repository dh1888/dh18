package main

import (
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"enterprise-agent/backend/security"
)

func main() {
	seed, err := base64.StdEncoding.DecodeString("qJ7y3mR8pT1vN6wK4xL9sH2fD5gB0cE3jM8nP1rU6yA=")
	if err != nil {
		panic(err)
	}
	privateKey := ed25519.NewKeyFromSeed(seed)
	publicKey := privateKey.Public().(ed25519.PublicKey)

	type vec struct {
		Name         string
		InputContent string
	}
	vectors := []vec{
		{
			Name:         "minimal-config-only",
			InputContent: `{"version":1,"config":{"recording":{"enabled":true,"fps":5,"quality":70}}}`,
		},
		{
			Name:         "strip-metadata-and-defaults",
			InputContent: `{"signature":"x","signatureAlg":"Ed25519","keyId":"k","signatureVersion":1,"version":2,"rules":null,"config":{"upload":{"enabled":true}}}`,
		},
		{
			Name:         "rules-present",
			InputContent: `{"version":3,"rules":[{"id":"r1","action":"allow","match":"*"}],"config":{"screenshot":{"enabled":false}}}`,
		},
	}

	outVectors := make([]map[string]any, 0, len(vectors))
	for _, v := range vectors {
		canonical, payload, err := security.CanonicalizePolicyFromContent(v.InputContent)
		if err != nil {
			panic(err)
		}
		sig := ed25519.Sign(privateKey, canonical)
		policyJSON, err := json.Marshal(payload)
		if err != nil {
			panic(err)
		}
		outVectors = append(outVectors, map[string]any{
			"name":            v.Name,
			"inputContent":    v.InputContent,
			"payload":         json.RawMessage(policyJSON),
			"canonicalUtf8":   string(canonical),
			"signatureBase64": base64.StdEncoding.EncodeToString(sig),
		})
	}

	out := map[string]any{
		"schemaVersion": 1,
		"keys": map[string]string{
			"keyId":             "2026-test",
			"publicKeyBase64":   base64.StdEncoding.EncodeToString(publicKey),
			"privateKeySeedB64": base64.StdEncoding.EncodeToString(seed),
		},
		"vectors": outVectors,
	}

	path := filepath.Join("..", "shared", "policy_signature", "test_vectors.json")
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		panic(err)
	}
	data, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		panic(err)
	}
	if err := os.WriteFile(path, data, 0644); err != nil {
		panic(err)
	}
	fmt.Println(string(data))
}

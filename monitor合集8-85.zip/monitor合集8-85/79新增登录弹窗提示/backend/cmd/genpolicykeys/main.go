package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

func main() {
	_, privateKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		panic(err)
	}

	publicKey := privateKey.Public().(ed25519.PublicKey)
	publicKeyB64 := base64.StdEncoding.EncodeToString(publicKey)

	keyID := time.Now().UTC().Format("2006-01")

	secretsDir := filepath.Join("secrets")
	if err := os.MkdirAll(secretsDir, 0700); err != nil {
		panic(err)
	}

	pemPath := filepath.Join(secretsDir, "policy-ed25519.pem")
	pemBytes, err := x509.MarshalPKCS8PrivateKey(privateKey)
	if err != nil {
		panic(err)
	}
	pemFile, err := os.OpenFile(pemPath, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
	if err != nil {
		panic(err)
	}
	if err := pem.Encode(pemFile, &pem.Block{Type: "PRIVATE KEY", Bytes: pemBytes}); err != nil {
		panic(err)
	}
	if err := pemFile.Close(); err != nil {
		panic(err)
	}

	deployment := map[string]any{
		"policyPublicKeys": map[string]string{
			keyID: publicKeyB64,
		},
		"registrationSecret":     "mR9xKp2vN7qL4wT8hJ3sF6cB1gD0eA5yU",
		"allowInsecureTransport": true,
		"serverUrl":              "http://43.106.86.216:8080",
	}

	repoRoot := filepath.Join("..")
	deploymentPaths := []string{
		filepath.Join(repoRoot, "agent", "deployment.json"),
		filepath.Join(repoRoot, "agent", "publish", "win-x64", "deployment.json"),
	}

	for _, path := range deploymentPaths {
		if err := writeJSON(path, deployment); err != nil {
			fmt.Fprintf(os.Stderr, "warn: %s: %v\n", path, err)
		}
	}

	output := map[string]string{
		"keyId":           keyID,
		"publicKeyBase64": publicKeyB64,
		"privateKeyPem":   pemPath,
	}
	encoded, _ := json.MarshalIndent(output, "", "  ")
	fmt.Println(string(encoded))
}

func writeJSON(path string, value any) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	data = append(data, '\n')
	return os.WriteFile(path, data, 0644)
}

package security

import (
	"encoding/json"
	"fmt"
)

const (
	PolicySignatureVersion = 1
	PolicySignatureAlg     = "Ed25519"
)

// PolicySignPayload is the only JSON object participating in policy signatures.
type PolicySignPayload struct {
	Version int             `json:"version"`
	Rules   []PolicyRule    `json:"rules"`
	Config  json.RawMessage `json:"config"`
}

// PolicyRule mirrors models.PolicyRule for signing purposes.
type PolicyRule struct {
	ID     string `json:"id"`
	Action string `json:"action"`
	Match  string `json:"match"`
}

var excludedPolicySignFields = map[string]struct{}{
	"signature":        {},
	"signatureAlg":     {},
	"signatureVersion": {},
	"keyId":            {},
}

// NormalizePolicySignPayloadFromContent parses stored policy content and returns
// the normalized signing payload (version, rules, config only).
func NormalizePolicySignPayloadFromContent(content string) (PolicySignPayload, error) {
	if content == "" {
		return PolicySignPayload{}, fmt.Errorf("policy content is empty")
	}
	return NormalizePolicySignPayloadFromJSON(json.RawMessage(content))
}

// NormalizePolicySignPayloadFromJSON parses JSON and strips signing metadata fields.
func NormalizePolicySignPayloadFromJSON(raw json.RawMessage) (PolicySignPayload, error) {
	var data map[string]json.RawMessage
	if err := json.Unmarshal(raw, &data); err != nil {
		return PolicySignPayload{}, fmt.Errorf("invalid policy json: %w", err)
	}
	return normalizePolicyMap(data)
}

// NormalizePolicySignPayloadFromObject normalizes a generic decoded policy object.
func NormalizePolicySignPayloadFromObject(raw any) (PolicySignPayload, error) {
	bytes, err := json.Marshal(raw)
	if err != nil {
		return PolicySignPayload{}, fmt.Errorf("marshal policy object: %w", err)
	}
	return NormalizePolicySignPayloadFromJSON(bytes)
}

func normalizePolicyMap(data map[string]json.RawMessage) (PolicySignPayload, error) {
	var version int
	if rawVersion, ok := data["version"]; ok && string(rawVersion) != "null" {
		if err := json.Unmarshal(rawVersion, &version); err != nil {
			return PolicySignPayload{}, fmt.Errorf("invalid policy version: %w", err)
		}
	}
	if version <= 0 {
		return PolicySignPayload{}, fmt.Errorf("policy version must be > 0")
	}

	rules := make([]PolicyRule, 0)
	if rawRules, ok := data["rules"]; ok && string(rawRules) != "null" {
		if err := json.Unmarshal(rawRules, &rules); err != nil {
			return PolicySignPayload{}, fmt.Errorf("invalid policy rules: %w", err)
		}
	}

	config := json.RawMessage("{}")
	if rawConfig, ok := data["config"]; ok && string(rawConfig) != "null" {
		if !json.Valid(rawConfig) {
			return PolicySignPayload{}, fmt.Errorf("invalid policy config json")
		}
		config = append(json.RawMessage(nil), rawConfig...)
	}

	for key := range data {
		if key == "version" || key == "rules" || key == "config" {
			continue
		}
		if _, excluded := excludedPolicySignFields[key]; excluded {
			continue
		}
		return PolicySignPayload{}, fmt.Errorf("unsupported top-level policy field %q", key)
	}

	return PolicySignPayload{
		Version: version,
		Rules:   rules,
		Config:  config,
	}, nil
}

// MarshalPolicyObject returns normalized policy JSON for API responses (not canonical form).
func (p PolicySignPayload) MarshalPolicyObject() (json.RawMessage, error) {
	return json.Marshal(p)
}

package security_test

import (
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"enterprise-agent/backend/security"

	"github.com/stretchr/testify/require"
)

type sharedVectorFile struct {
	SchemaVersion int `json:"schemaVersion"`
	Vectors       []struct {
		Name           string          `json:"name"`
		InputContent   string          `json:"inputContent,omitempty"`
		Payload        json.RawMessage `json:"payload,omitempty"`
		CanonicalUTF8  string          `json:"canonicalUtf8"`
		SignatureBase64 string         `json:"signatureBase64,omitempty"`
	} `json:"vectors"`
	Keys struct {
		KeyID            string `json:"keyId"`
		PublicKeyBase64  string `json:"publicKeyBase64"`
		PrivateKeySeedB64 string `json:"privateKeySeedBase64"`
	} `json:"keys"`
}

func testSeedPrivateKey(t *testing.T) ed25519.PrivateKey {
	t.Helper()
	seed, err := base64.StdEncoding.DecodeString("qJ7y3mR8pT1vN6wK4xL9sH2fD5gB0cE3jM8nP1rU6yA=")
	require.NoError(t, err)
	require.Len(t, seed, ed25519.SeedSize)
	return ed25519.NewKeyFromSeed(seed)
}

func TestNormalizeAndCanonicalizeVectors(t *testing.T) {
	vectorsPath := filepath.Join("..", "..", "shared", "policy_signature", "test_vectors.json")
	raw, err := os.ReadFile(vectorsPath)
	require.NoError(t, err)

	var file sharedVectorFile
	require.NoError(t, json.Unmarshal(raw, &file))
	require.NotEmpty(t, file.Vectors)

	for _, vector := range file.Vectors {
		t.Run(vector.Name, func(t *testing.T) {
			var payload security.PolicySignPayload
			var canonical []byte
			var err error

			switch {
			case vector.InputContent != "":
				canonical, payload, err = security.CanonicalizePolicyFromContent(vector.InputContent)
			case len(vector.Payload) > 0:
				payload, err = security.NormalizePolicySignPayloadFromJSON(vector.Payload)
				require.NoError(t, err)
				canonical, err = security.CanonicalizePolicyPayload(payload)
			default:
				t.Fatal("vector must define inputContent or payload")
			}
			require.NoError(t, err)
			require.Equal(t, vector.CanonicalUTF8, string(canonical))
		})
	}
}

func TestEd25519RoundTripFromSharedVectors(t *testing.T) {
	privateKey := testSeedPrivateKey(t)
	publicKey := privateKey.Public().(ed25519.PublicKey)

	vectorsPath := filepath.Join("..", "..", "shared", "policy_signature", "test_vectors.json")
	raw, err := os.ReadFile(vectorsPath)
	require.NoError(t, err)

	var file sharedVectorFile
	require.NoError(t, json.Unmarshal(raw, &file))
	require.Equal(t, base64.StdEncoding.EncodeToString(publicKey), file.Keys.PublicKeyBase64)

	for _, vector := range file.Vectors {
		if vector.SignatureBase64 == "" {
			continue
		}
		t.Run(vector.Name+"_verify", func(t *testing.T) {
			payload, err := security.NormalizePolicySignPayloadFromContent(vector.InputContent)
			require.NoError(t, err)
			require.NoError(t, security.VerifyPolicySignature(publicKey, payload, vector.SignatureBase64))
		})
	}
}

func TestSignPolicyPayloadMatchesSharedVector(t *testing.T) {
	t.Setenv("POLICY_SIGNING_KEY_ID", "2026-test")
	t.Setenv("POLICY_SIGNING_PRIVATE_KEY", base64.StdEncoding.EncodeToString(testSeedPrivateKey(t).Seed()))

	signed, err := security.SignPolicyContent(`{
		"version": 1,
		"config": {
			"recording": { "enabled": true, "fps": 5, "quality": 70 }
		}
	}`)
	require.NoError(t, err)
	require.Equal(t, "Ed25519", signed.SignatureAlg)
	require.Equal(t, 1, signed.SignatureVersion)
	require.Equal(t, "2026-test", signed.KeyID)
	require.NotEmpty(t, signed.Signature)
}

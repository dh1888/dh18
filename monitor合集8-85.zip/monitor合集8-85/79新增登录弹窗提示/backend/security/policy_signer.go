package security

import (
	"crypto/ed25519"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"fmt"
	"os"
	"strings"
	"sync"
)

// SignedPolicyEnvelope contains runtime signature metadata for Agent delivery.
type SignedPolicyEnvelope struct {
	Policy           PolicySignPayload `json:"policy"`
	Signature        string            `json:"signature"`
	SignatureAlg     string            `json:"signatureAlg"`
	SignatureVersion int               `json:"signatureVersion"`
	KeyID            string            `json:"keyId"`
	ContentCompat    string            `json:"content,omitempty"`
}

var (
	policySignerOnce sync.Once
	policySignerErr  error
	policyPrivateKey ed25519.PrivateKey
	policyKeyID      string
)

// InitPolicySigner loads Ed25519 private key material from environment.
func InitPolicySigner() error {
	policySignerOnce.Do(func() {
		policyKeyID = strings.TrimSpace(os.Getenv("POLICY_SIGNING_KEY_ID"))
		if policyKeyID == "" {
			policySignerErr = fmt.Errorf("POLICY_SIGNING_KEY_ID is required")
			return
		}

		keyMaterial, err := loadPolicyPrivateKeyMaterial()
		if err != nil {
			policySignerErr = err
			return
		}

		privateKey, err := parseEd25519PrivateKey(keyMaterial)
		if err != nil {
			policySignerErr = err
			return
		}
		policyPrivateKey = privateKey
	})
	return policySignerErr
}

// SignPolicyContent signs normalized policy content using JCS + Ed25519.
func SignPolicyContent(content string) (*SignedPolicyEnvelope, error) {
	if err := InitPolicySigner(); err != nil {
		return nil, err
	}

	canonical, payload, err := CanonicalizePolicyFromContent(content)
	if err != nil {
		return nil, err
	}

	signature := ed25519.Sign(policyPrivateKey, canonical)
	return &SignedPolicyEnvelope{
		Policy:           payload,
		Signature:        base64.StdEncoding.EncodeToString(signature),
		SignatureAlg:     PolicySignatureAlg,
		SignatureVersion: PolicySignatureVersion,
		KeyID:            policyKeyID,
		ContentCompat:    content,
	}, nil
}

// SignPolicyPayload signs an already-normalized payload.
func SignPolicyPayload(payload PolicySignPayload) (*SignedPolicyEnvelope, error) {
	if err := InitPolicySigner(); err != nil {
		return nil, err
	}

	canonical, err := CanonicalizePolicyPayload(payload)
	if err != nil {
		return nil, err
	}

	signature := ed25519.Sign(policyPrivateKey, canonical)
	policyJSON, err := payload.MarshalPolicyObject()
	if err != nil {
		return nil, err
	}

	return &SignedPolicyEnvelope{
		Policy:           payload,
		Signature:        base64.StdEncoding.EncodeToString(signature),
		SignatureAlg:     PolicySignatureAlg,
		SignatureVersion: PolicySignatureVersion,
		KeyID:            policyKeyID,
		ContentCompat:    string(policyJSON),
	}, nil
}

// PolicyPublicKeyBase64 returns the Base64-encoded Ed25519 public key for deployment bundles.
func PolicyPublicKeyBase64() (string, error) {
	if err := InitPolicySigner(); err != nil {
		return "", err
	}
	publicKey := policyPrivateKey.Public().(ed25519.PublicKey)
	return base64.StdEncoding.EncodeToString(publicKey), nil
}

func loadPolicyPrivateKeyMaterial() ([]byte, error) {
	if path := strings.TrimSpace(os.Getenv("POLICY_SIGNING_PRIVATE_KEY_PATH")); path != "" {
		data, err := os.ReadFile(path)
		if err != nil {
			return nil, fmt.Errorf("read POLICY_SIGNING_PRIVATE_KEY_PATH: %w", err)
		}
		return data, nil
	}

	if inline := strings.TrimSpace(os.Getenv("POLICY_SIGNING_PRIVATE_KEY")); inline != "" {
		return []byte(strings.ReplaceAll(inline, `\n`, "\n")), nil
	}

	return nil, fmt.Errorf("POLICY_SIGNING_PRIVATE_KEY_PATH or POLICY_SIGNING_PRIVATE_KEY is required")
}

func parseEd25519PrivateKey(keyMaterial []byte) (ed25519.PrivateKey, error) {
	if block, _ := pem.Decode(keyMaterial); block != nil {
		keyMaterial = block.Bytes
	}

	if key, err := x509.ParsePKCS8PrivateKey(keyMaterial); err == nil {
		edKey, ok := key.(ed25519.PrivateKey)
		if !ok {
			return nil, fmt.Errorf("private key is not Ed25519")
		}
		return edKey, nil
	}

	if len(keyMaterial) == ed25519.SeedSize {
		return ed25519.NewKeyFromSeed(keyMaterial), nil
	}

	if seed, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(keyMaterial))); err == nil && len(seed) == ed25519.SeedSize {
		return ed25519.NewKeyFromSeed(seed), nil
	}

	return nil, fmt.Errorf("unsupported Ed25519 private key format")
}

// VerifyPolicySignature verifies a signature for test and diagnostics use.
func VerifyPolicySignature(publicKey ed25519.PublicKey, payload PolicySignPayload, signatureBase64 string) error {
	canonical, err := CanonicalizePolicyPayload(payload)
	if err != nil {
		return err
	}
	signature, err := base64.StdEncoding.DecodeString(signatureBase64)
	if err != nil {
		return fmt.Errorf("decode signature: %w", err)
	}
	if !ed25519.Verify(publicKey, canonical, signature) {
		return fmt.Errorf("policy signature verification failed")
	}
	return nil
}

package services

import (
	"context"
	"database/sql"
	"strings"
)

const (
	defaultCheckInBefore       = 120
	defaultCheckInAfter        = 360
	defaultCheckOutBefore      = 120
	defaultCheckOutAfter       = 360
	defaultLateTolerance       = 360
	defaultEarlyLeaveTolerance = 120
)

// TgGraceConfig separates punch windows from late/early-leave penalty tolerances.
type TgGraceConfig struct {
	CheckInBefore       int
	CheckInAfter        int
	CheckOutBefore      int
	CheckOutAfter       int
	LateTolerance       int
	EarlyLeaveTolerance int
}

func normalizeGraceConfig(cfg TgGraceConfig) TgGraceConfig {
	if cfg.CheckInBefore < 30 {
		cfg.CheckInBefore = defaultCheckInBefore
	}
	if cfg.CheckInAfter < 30 {
		cfg.CheckInAfter = defaultCheckInAfter
	}
	if cfg.CheckOutBefore < 30 {
		cfg.CheckOutBefore = defaultCheckOutBefore
	}
	if cfg.CheckOutAfter < 30 {
		cfg.CheckOutAfter = defaultCheckOutAfter
	}
	if cfg.LateTolerance < 0 {
		cfg.LateTolerance = 0
	}
	if cfg.EarlyLeaveTolerance < 0 {
		cfg.EarlyLeaveTolerance = 0
	}
	return cfg
}

func (s *WorkforceTelegramService) graceFromSettings(settings *TelegramSettings) TgGraceConfig {
	cfg := TgGraceConfig{
		CheckInBefore:       settings.GraceMinutes,
		CheckInAfter:        settings.GraceMinutesAfter,
		CheckOutBefore:      settings.CheckOutGraceBefore,
		CheckOutAfter:       settings.WorkEndGraceAfter,
		LateTolerance:       settings.LateToleranceMinutes,
		EarlyLeaveTolerance: settings.EarlyLeaveToleranceMinutes,
	}
	return normalizeGraceConfig(cfg)
}

func (s *WorkforceTelegramService) GetGraceConfig(ctx context.Context, chatID string) (TgGraceConfig, error) {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return TgGraceConfig{}, err
	}
	cfg := s.graceFromSettings(settings)
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return cfg, nil
	}
	var sb, sa, cb, ca, lt, el sql.NullInt32
	err = s.db.QueryRowContext(ctx, `
		SELECT shift_grace_before, shift_grace_after, work_end_grace_before, work_end_grace_after,
			late_tolerance_minutes, early_leave_tolerance_minutes
		FROM wf_telegram_groups WHERE chat_id = $1`, chatID).
		Scan(&sb, &sa, &cb, &ca, &lt, &el)
	if err == sql.ErrNoRows {
		return cfg, nil
	}
	if err != nil {
		return cfg, err
	}
	if sb.Valid && int(sb.Int32) > 0 {
		cfg.CheckInBefore = int(sb.Int32)
	}
	if sa.Valid && int(sa.Int32) > 0 {
		cfg.CheckInAfter = int(sa.Int32)
	}
	if cb.Valid && int(cb.Int32) > 0 {
		cfg.CheckOutBefore = int(cb.Int32)
	}
	if ca.Valid && int(ca.Int32) > 0 {
		cfg.CheckOutAfter = int(ca.Int32)
	}
	if lt.Valid && int(lt.Int32) >= 0 {
		cfg.LateTolerance = int(lt.Int32)
	}
	if el.Valid && int(el.Int32) >= 0 {
		cfg.EarlyLeaveTolerance = int(el.Int32)
	}
	return normalizeGraceConfig(cfg), nil
}

func (s *WorkforceTelegramService) GetGroupDailyResetTime(ctx context.Context, chatID string) string {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return "09:00"
	}
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return settings.DailyResetTime
	}
	var t sql.NullString
	if s.db.QueryRowContext(ctx, `
		SELECT daily_reset_time FROM wf_telegram_groups WHERE chat_id = $1`, chatID).Scan(&t) != nil || !t.Valid || strings.TrimSpace(t.String) == "" {
		return settings.DailyResetTime
	}
	return strings.TrimSpace(t.String)
}

// backend/services/repositories.go
// 完整替换文件内容 - 修复 NULL 字段处理

package services

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"crypto/rand"
	"encoding/hex"

	"github.com/google/uuid"
	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
	"github.com/redis/go-redis/v9"
	"golang.org/x/crypto/bcrypt"

	_ "github.com/lib/pq"

	"enterprise-agent/backend/models"
)

var ErrRecordingRemoteStorage = fmt.Errorf("recording stored in remote object storage")

// ========== 数据库初始化 ==========

func NewDatabase() *sql.DB {
	host := os.Getenv("DB_HOST")
	if host == "" {
		host = "localhost"
	}
	port := os.Getenv("DB_PORT")
	if port == "" {
		port = "5432"
	}
	user := os.Getenv("DB_USER")
	if user == "" {
		user = "agent"
	}
	password := os.Getenv("DB_PASSWORD")
	if password == "" {
		password = "agent123"
	}
	dbname := os.Getenv("DB_NAME")
	if dbname == "" {
		dbname = "agent"
	}
	sslmode := os.Getenv("DB_SSLMODE")
	if sslmode == "" {
		sslmode = "disable"
	}

	dsn := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
		host, port, user, password, dbname, sslmode)

	db, err := sql.Open("postgres", dsn)
	if err != nil {
		panic(fmt.Sprintf("failed to open database: %v", err))
	}

	db.SetMaxOpenConns(30)
	db.SetMaxIdleConns(15)
	db.SetConnMaxLifetime(5 * time.Minute)

	if err := db.Ping(); err != nil {
		panic(fmt.Sprintf("failed to ping database: %v", err))
	}

	// 初始化schema（如果表不存在）
	if err := initializeSchema(db); err != nil {
		panic(fmt.Sprintf("failed to initialize schema: %v", err))
	}
	if err := ensureAuthSessionsSchema(db); err != nil {
		panic(fmt.Sprintf("failed to ensure auth_sessions schema: %v", err))
	}
	if err := ensureWorkforceSchema(db); err != nil {
		panic(fmt.Sprintf("failed to ensure workforce schema: %v", err))
	}
	if err := ensureWorkforceTelegramSchema(db); err != nil {
		panic(fmt.Sprintf("failed to ensure workforce telegram schema: %v", err))
	}

	if err := seedDefaultAdmin(db); err != nil {
		panic(fmt.Sprintf("failed to seed default admin: %v", err))
	}

    if err := EnsureDefaultPolicy(db); err != nil {
        log.Printf("⚠️ 警告: 创建默认策略失败: %v", err)
    }

	fmt.Println("PostgreSQL connected successfully")
	return db


}

func initializeSchema(db *sql.DB) error {
	// 检查表是否存在
	var exists bool
	err := db.QueryRow(`SELECT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'users')`).Scan(&exists)
	if err != nil {
		return err
	}

	if exists {
		// 表已存在，检查并添加缺失的列
		return migrateSchema(db)
	}

	// 读取schema文件
	schemaPath := "schema_postgresql.sql"
	schema, err := os.ReadFile(schemaPath)
	if err != nil {
		// 如果文件不存在，使用内嵌SQL
		return initEmbeddedSchema(db)
	}

	_, err = db.Exec(string(schema))
	return err
}

func migrateSchema(db *sql.DB) error {
    migrations := []string{
        // 出款和考勤业务表（如果缺失则创建）
        `CREATE TABLE IF NOT EXISTS employees (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id VARCHAR(100),
            name VARCHAR(255),
            position VARCHAR(100),
            hire_date DATE,
            work_location VARCHAR(255),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employees_employee_id ON employees(employee_id)`,
        `CREATE TABLE IF NOT EXISTS attendance_records (
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            year_month VARCHAR(7) NOT NULL,
            date DATE NOT NULL,
            status VARCHAR(50) NOT NULL,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (employee_id, year_month, date)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_attendance_records_employee_id ON attendance_records(employee_id)`,
        `CREATE TABLE IF NOT EXISTS performance_records (
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            employee_name VARCHAR(255),
            position VARCHAR(100),
            score_records JSONB,
            total_score INTEGER DEFAULT 0,
            grade VARCHAR(50),
            month VARCHAR(7) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (employee_id, month)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_performance_records_month ON performance_records(month)`,
        `CREATE TABLE IF NOT EXISTS penalty_records (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
            employee_name VARCHAR(255),
            position VARCHAR(100),
            amount NUMERIC(12,2) NOT NULL DEFAULT 0,
            category VARCHAR(100),
            reason TEXT,
            penalty_date DATE NOT NULL,
            created_by VARCHAR(100),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_penalty_records_employee_id ON penalty_records(employee_id)`,
        `CREATE INDEX IF NOT EXISTS idx_penalty_records_penalty_date ON penalty_records(penalty_date)`,
        `CREATE TABLE IF NOT EXISTS sites (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            code VARCHAR(100) NOT NULL UNIQUE,
            name VARCHAR(255) NOT NULL,
            sort_order INTEGER NOT NULL DEFAULT 0,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,
        `CREATE TABLE IF NOT EXISTS employee_accounts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            site_id UUID NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
            name VARCHAR(255),
            account_name VARCHAR(255) NOT NULL,
            shift VARCHAR(50),
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            UNIQUE (site_id, account_name)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employee_accounts_site_id ON employee_accounts(site_id)`,
        `CREATE TABLE IF NOT EXISTS site_stats (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_account_id UUID NOT NULL REFERENCES employee_accounts(id) ON DELETE CASCADE,
            site_id UUID NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
            stat_date DATE NOT NULL,
            shift VARCHAR(50),
            order_count INTEGER NOT NULL DEFAULT 0,
            avg_time_seconds INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            UNIQUE (employee_account_id, stat_date, shift)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_site_id ON site_stats(site_id)`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_employee_account_id ON site_stats(employee_account_id)`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_stat_date ON site_stats(stat_date)`,

        // 用户表
        `ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP WITH TIME ZONE`,
        
        // 策略表
        `ALTER TABLE policies ADD COLUMN IF NOT EXISTS is_current BOOLEAN DEFAULT FALSE`,
        
        // 录屏表
        `ALTER TABLE recordings ADD COLUMN IF NOT EXISTS duration INTEGER DEFAULT 0`,
        `ALTER TABLE recordings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE`,
        
        // 截图表
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS width INTEGER DEFAULT 0`,
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS height INTEGER DEFAULT 0`,
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS format VARCHAR(10) DEFAULT 'jpg'`,
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS uploaded_at TIMESTAMP WITH TIME ZONE`,
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS encrypted BOOLEAN DEFAULT FALSE`,
        
        // 活动日志表
        `ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS reported BOOLEAN DEFAULT FALSE`,
        `ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS reported_at TIMESTAMP WITH TIME ZONE`,
        `ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS retry_count INTEGER DEFAULT 0`,
        `ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS error_message TEXT DEFAULT ''`,

        `ALTER TABLE upload_tasks ADD COLUMN IF NOT EXISTS task_type VARCHAR(50) NOT NULL DEFAULT 'upload_recordings'`,
        `ALTER TABLE upload_tasks ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`,

        // ========== ⭐ ==========
        `ALTER TABLE operation_logs ADD COLUMN IF NOT EXISTS execution_time_ms INTEGER DEFAULT 0`,
        `ALTER TABLE operation_logs ADD COLUMN IF NOT EXISTS target_name VARCHAR(255)`,

        `ALTER TABLE cleanup_policy ADD COLUMN IF NOT EXISTS attendance_retention_months INTEGER NOT NULL DEFAULT 0`,
        `ALTER TABLE cleanup_policy ADD COLUMN IF NOT EXISTS performance_retention_months INTEGER NOT NULL DEFAULT 0`,
        `ALTER TABLE cleanup_policy ADD COLUMN IF NOT EXISTS penalty_retention_months INTEGER NOT NULL DEFAULT 0`,
        `ALTER TABLE cleanup_policy ADD COLUMN IF NOT EXISTS salary_retention_months INTEGER NOT NULL DEFAULT 0`,
        `ALTER TABLE cleanup_policy ADD COLUMN IF NOT EXISTS site_stats_retention_months INTEGER NOT NULL DEFAULT 0`,
        `ALTER TABLE cleanup_logs ADD COLUMN IF NOT EXISTS deleted_business_records INTEGER NOT NULL DEFAULT 0`,
        
        // 索引（建议先添加列，后添加索引）
        `CREATE INDEX IF NOT EXISTS idx_screenshots_device_captured ON screenshots(device_id, captured_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_recordings_uploaded ON recordings(uploaded)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_device_started ON activity_logs(device_id, started_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_reported ON activity_logs(reported)`,

		`ALTER TABLE devices DROP CONSTRAINT IF EXISTS devices_status_check`,
        `ALTER TABLE devices ADD CONSTRAINT devices_status_check CHECK (status IN ('pending', 'approved', 'rejected'))`,
        
        // 修复错误数据
        `UPDATE devices SET status = 'approved' WHERE status NOT IN ('pending', 'approved', 'rejected')`,

        // ========== 工资记录表 ==========
        `CREATE TABLE IF NOT EXISTS salary_records (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(100) NOT NULL,
            employee_name VARCHAR(255) NOT NULL,
            position VARCHAR(100),
            hire_date_dept VARCHAR(255),
            months_employed INTEGER DEFAULT 0,
            last_month_base DECIMAL(12,2) DEFAULT 0,
            total_increase DECIMAL(12,2) DEFAULT 0,
            base_salary DECIMAL(12,2) DEFAULT 0,
            attendance_days DECIMAL(10,2) DEFAULT 0,
            actual_base_salary DECIMAL(12,2) DEFAULT 0,
            attendance_adjustment DECIMAL(12,2) DEFAULT 0,
            half_year_unpaid_leave DECIMAL(12,2) DEFAULT 0,
            exchange_rate DECIMAL(10,4) DEFAULT 0,
            performance_score INTEGER DEFAULT 0,
            performance_bonus_b DECIMAL(12,2) DEFAULT 0,
            reward DECIMAL(12,2) DEFAULT 0,
            penalty DECIMAL(12,2) DEFAULT 0,
            advance DECIMAL(12,2) DEFAULT 0,
            other_deduction DECIMAL(12,2) DEFAULT 0,
            protection_return DECIMAL(12,2) DEFAULT 0,
            protection_fee DECIMAL(12,2) DEFAULT 0,
            total_salary DECIMAL(12,2) DEFAULT 0,
            remark TEXT,
            year_month VARCHAR(7) NOT NULL,
            paid_status VARCHAR(16) NOT NULL DEFAULT 'pending',
            paid_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(employee_id, year_month)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_employee_id ON salary_records(employee_id)`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_year_month ON salary_records(year_month)`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_employee_name ON salary_records(employee_name)`,
        `ALTER TABLE salary_records ADD COLUMN IF NOT EXISTS paid_status VARCHAR(16) NOT NULL DEFAULT 'pending'`,
        `ALTER TABLE salary_records ADD COLUMN IF NOT EXISTS paid_at TIMESTAMP WITH TIME ZONE`,
        `ALTER TABLE salary_records ADD COLUMN IF NOT EXISTS sheet_values JSONB`,
        `CREATE TABLE IF NOT EXISTS salary_month_layouts (
            year_month VARCHAR(7) PRIMARY KEY,
            headers JSONB NOT NULL DEFAULT '[]'::jsonb,
            name_column_index INTEGER NOT NULL DEFAULT 1,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE TABLE IF NOT EXISTS salary_configs (
            config_key VARCHAR(64) PRIMARY KEY,
            config_name VARCHAR(64) NOT NULL DEFAULT '',
            total_increase DECIMAL(12,2) NOT NULL DEFAULT 0,
            full_attendance_days INTEGER NOT NULL DEFAULT 0,
            full_attendance_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            full_attendance_currency VARCHAR(8) NOT NULL DEFAULT 'CNY',
            exchange_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
            cny_thb_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
            cny_usd_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
            thb_usd_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
            performance_full_score_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            performance_currency VARCHAR(8) NOT NULL DEFAULT 'CNY',
            protection_fee DECIMAL(12,2) NOT NULL DEFAULT 0,
            protection_fee_currency VARCHAR(8) NOT NULL DEFAULT 'CNY',
            payout_currency VARCHAR(8) NOT NULL DEFAULT 'CNY',
            position_caps JSONB NOT NULL DEFAULT '[]'::jsonb,
            sort_order INTEGER NOT NULL DEFAULT 0,
            is_builtin BOOLEAN NOT NULL DEFAULT false,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `DROP TRIGGER IF EXISTS update_salary_records_updated_at ON salary_records;
        CREATE TRIGGER update_salary_records_updated_at
            BEFORE UPDATE ON salary_records
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,

        // ========== 员工收款地址表 ==========
        `CREATE TABLE IF NOT EXISTS employee_payment_accounts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID NOT NULL UNIQUE REFERENCES employees(id) ON DELETE CASCADE,
            account_holder VARCHAR(255) NOT NULL DEFAULT '',
            bank_name VARCHAR(255) NOT NULL DEFAULT '',
            bank_account VARCHAR(128) NOT NULL DEFAULT '',
            usdt_network VARCHAR(32) NOT NULL DEFAULT '',
            usdt_address VARCHAR(255) NOT NULL DEFAULT '',
            other_wallet_type VARCHAR(64) NOT NULL DEFAULT '',
            other_wallet_address VARCHAR(255) NOT NULL DEFAULT '',
            preferred_method VARCHAR(16) NOT NULL DEFAULT '',
            remark TEXT NOT NULL DEFAULT '',
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employee_payment_accounts_employee_id ON employee_payment_accounts(employee_id)`,
        `ALTER TABLE employee_payment_accounts ADD COLUMN IF NOT EXISTS preferred_method VARCHAR(16) NOT NULL DEFAULT ''`,
        `DROP TRIGGER IF EXISTS update_employee_payment_accounts_updated_at ON employee_payment_accounts;
        CREATE TRIGGER update_employee_payment_accounts_updated_at
            BEFORE UPDATE ON employee_payment_accounts
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,

        // ========== 工资打款截图 ==========
        `CREATE TABLE IF NOT EXISTS salary_payment_proofs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            year_month VARCHAR(7) NOT NULL,
            file_path VARCHAR(512) NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            content_type VARCHAR(128) NOT NULL DEFAULT 'image/jpeg',
            uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
            uploaded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(employee_id, year_month)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_salary_payment_proofs_employee_month ON salary_payment_proofs(employee_id, year_month)`,

        // ========== 用户通知（公告、工资发放等）==========
        `CREATE TABLE IF NOT EXISTS user_notifications (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            type VARCHAR(32) NOT NULL DEFAULT 'announcement',
            title VARCHAR(255) NOT NULL,
            content TEXT NOT NULL,
            payload JSONB,
            is_read BOOLEAN NOT NULL DEFAULT FALSE,
            show_popup BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_user_notifications_user_id ON user_notifications(user_id)`,
        `CREATE INDEX IF NOT EXISTS idx_user_notifications_unread ON user_notifications(user_id, is_read) WHERE is_read = FALSE`,
        
        // ========== 操作日志表 ==========
        `CREATE TABLE IF NOT EXISTS operation_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            operator_id VARCHAR(36),
            operator_name VARCHAR(100) NOT NULL,
            operator_role VARCHAR(50),
            operation_type VARCHAR(50) NOT NULL,
            operation_module VARCHAR(50) NOT NULL,
            operation_desc TEXT NOT NULL,
            target_id VARCHAR(100),
            target_name VARCHAR(255),
            ip_address VARCHAR(45),
            user_agent TEXT,
            request_method VARCHAR(10),
            request_path VARCHAR(255),
            request_params TEXT,
            response_status INTEGER,
            execution_time_ms INTEGER,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        `CREATE INDEX IF NOT EXISTS idx_operation_logs_operator_name ON operation_logs(operator_name)`,
        `CREATE INDEX IF NOT EXISTS idx_operation_logs_created_at ON operation_logs(created_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_operation_logs_operation_module ON operation_logs(operation_module)`,
        `CREATE INDEX IF NOT EXISTS idx_operation_logs_operation_type ON operation_logs(operation_type)`,

        // ========== 远程查看（LiveKit）==========
        `CREATE TABLE IF NOT EXISTS remote_view_sessions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id),
            room_name VARCHAR(128) NOT NULL,
            status VARCHAR(32) NOT NULL,
            started_by UUID NOT NULL,
            started_by_name VARCHAR(128) NOT NULL,
            viewer_count INTEGER NOT NULL DEFAULT 0,
            publisher_identity VARCHAR(128) NOT NULL,
            livekit_url VARCHAR(512) NOT NULL,
            ingress_id VARCHAR(128),
            rtmp_url VARCHAR(512),
            started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            ended_at TIMESTAMPTZ,
            end_reason VARCHAR(512),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )`,
        `ALTER TABLE remote_view_sessions ALTER COLUMN end_reason TYPE VARCHAR(512)`,
        `CREATE INDEX IF NOT EXISTS idx_rv_sessions_device_id ON remote_view_sessions(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_rv_sessions_status ON remote_view_sessions(status)`,
        `CREATE INDEX IF NOT EXISTS idx_rv_sessions_started_at ON remote_view_sessions(started_at DESC)`,

        `CREATE TABLE IF NOT EXISTS remote_view_audit_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            session_id UUID REFERENCES remote_view_sessions(id),
            device_id UUID NOT NULL,
            operator_id UUID NOT NULL,
            operator_name VARCHAR(128) NOT NULL,
            action VARCHAR(64) NOT NULL,
            detail JSONB,
            client_ip VARCHAR(64),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_rv_audit_device_id ON remote_view_audit_logs(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_rv_audit_created_at ON remote_view_audit_logs(created_at DESC)`,

        // Session SSOT + login security settings (existing DB upgrade)
        `CREATE TABLE IF NOT EXISTS auth_sessions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            subject_type VARCHAR(16) NOT NULL,
            subject_id UUID NOT NULL,
            status VARCHAR(16) NOT NULL DEFAULT 'active',
            version INT NOT NULL DEFAULT 1,
            expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
            revoked_at TIMESTAMP WITH TIME ZONE,
            revoke_reason VARCHAR(64),
            client_ip INET,
            user_agent TEXT,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_auth_sessions_subject ON auth_sessions(subject_type, subject_id)`,
        `CREATE INDEX IF NOT EXISTS idx_auth_sessions_status ON auth_sessions(status) WHERE status = 'active'`,

        `CREATE TABLE IF NOT EXISTS system_settings (
            key VARCHAR(128) PRIMARY KEY,
            value TEXT NOT NULL DEFAULT '',
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        `ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_secret TEXT`,
        `ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_enabled BOOLEAN NOT NULL DEFAULT FALSE`,

        `CREATE INDEX IF NOT EXISTS idx_upload_tasks_device_status ON upload_tasks(device_id, status)`,
    }

    for _, migration := range migrations {
        if _, err := db.Exec(migration); err != nil {
            // 记录警告但继续执行
            log.Printf("Migration warning (non-fatal): %v\nSQL: %s\n", err, migration)
        }
    }
    // Ensure devices table has device_secret column
    if _, err := db.Exec(`ALTER TABLE devices ADD COLUMN IF NOT EXISTS device_secret VARCHAR(128)`); err != nil {
        log.Printf("Warning: failed to add device_secret column: %v", err)
    }

    // 为现有设备生成 device_secret（如果为空）
    if err := ensureDeviceSecrets(db); err != nil {
        log.Printf("Warning: failed to ensure device secrets: %v", err)
    }
    return nil
}

// ensureDeviceSecrets 为 devices 表中缺失 device_secret 的行生成随机 secret
func ensureDeviceSecrets(db *sql.DB) error {
    rows, err := db.Query(`SELECT id FROM devices WHERE device_secret IS NULL OR device_secret = ''`)
    if err != nil {
        return err
    }
    defer rows.Close()

    var ids []string
    for rows.Next() {
        var id string
        if err := rows.Scan(&id); err != nil {
            return err
        }
        ids = append(ids, id)
    }
    for _, id := range ids {
        // 生成 32 字节随机数，hex 编码
        b := make([]byte, 32)
        if _, err := rand.Read(b); err != nil {
            log.Printf("failed to generate device secret for %s: %v", id, err)
            continue
        }
        secret := hex.EncodeToString(b)
        if _, err := db.Exec(`UPDATE devices SET device_secret = $1 WHERE id = $2`, secret, id); err != nil {
            log.Printf("failed to store device secret for %s: %v", id, err)
            continue
        }
        log.Printf("Generated device_secret for device %s", id)
    }
    return nil
}

// ensureAuthSessionsSchema creates session/login-security tables required for SSOT auth.
func ensureAuthSessionsSchema(db *sql.DB) error {
	stmts := []string{
		`CREATE TABLE IF NOT EXISTS auth_sessions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            subject_type VARCHAR(16) NOT NULL,
            subject_id UUID NOT NULL,
            status VARCHAR(16) NOT NULL DEFAULT 'active',
            version INT NOT NULL DEFAULT 1,
            expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
            revoked_at TIMESTAMP WITH TIME ZONE,
            revoke_reason VARCHAR(64),
            client_ip INET,
            user_agent TEXT,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE INDEX IF NOT EXISTS idx_auth_sessions_subject ON auth_sessions(subject_type, subject_id)`,
		`CREATE INDEX IF NOT EXISTS idx_auth_sessions_status ON auth_sessions(status) WHERE status = 'active'`,
		`CREATE TABLE IF NOT EXISTS system_settings (
            key VARCHAR(128) PRIMARY KEY,
            value TEXT NOT NULL DEFAULT '',
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_secret TEXT`,
		`ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_enabled BOOLEAN NOT NULL DEFAULT FALSE`,
	}
	for _, stmt := range stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec failed: %w\nSQL: %s", err, stmt)
		}
	}
	var exists bool
	if err := db.QueryRow(`SELECT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'auth_sessions')`).Scan(&exists); err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("auth_sessions table still missing after migration")
	}
	log.Println("auth_sessions schema ready")
	return nil
}

// closeDuplicateOpenWorkSessions keeps the newest open session per partition and closes the rest.
func closeDuplicateOpenWorkSessions(db *sql.DB, partitionBy string) error {
	_, err := db.Exec(fmt.Sprintf(`
		WITH ranked AS (
			SELECT id, ROW_NUMBER() OVER (PARTITION BY %s ORDER BY checkin_time DESC) AS rn
			FROM work_sessions WHERE status = 'open'
		)
		UPDATE work_sessions ws
		SET status = 'closed', checkout_time = COALESCE(ws.checkout_time, NOW()), updated_at = NOW()
		FROM ranked r WHERE ws.id = r.id AND r.rn > 1`, partitionBy))
	return err
}

func closeDuplicateOpenActivitySessions(db *sql.DB) error {
	_, err := db.Exec(`
		WITH ranked AS (
			SELECT id, ROW_NUMBER() OVER (PARTITION BY employee_id ORDER BY started_at DESC) AS rn
			FROM wf_tg_activity_sessions WHERE status = 'open'
		)
		UPDATE wf_tg_activity_sessions ws
		SET status = 'closed', ended_at = COALESCE(ws.ended_at, NOW())
		FROM ranked r WHERE ws.id = r.id AND r.rn > 1`)
	return err
}

// ensureWorkforceSchema creates employee invite / session tables for existing DB upgrades.
func ensureWorkforceSchema(db *sql.DB) error {
	stmts := []string{
		`ALTER TABLE employees ADD COLUMN IF NOT EXISTS department VARCHAR(100)`,
		`ALTER TABLE employees ADD COLUMN IF NOT EXISTS status SMALLINT NOT NULL DEFAULT 1`,
		`ALTER TABLE employees ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES users(id) ON DELETE SET NULL`,
		`CREATE UNIQUE INDEX IF NOT EXISTS idx_employees_user_id ON employees(user_id) WHERE user_id IS NOT NULL`,
		`CREATE INDEX IF NOT EXISTS idx_employees_department ON employees(department)`,
		`CREATE INDEX IF NOT EXISTS idx_employees_status ON employees(status)`,
		`ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS position_snapshot VARCHAR(100)`,
		`ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS checkin_time TIMESTAMP WITH TIME ZONE`,
		`ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS checkout_time TIMESTAMP WITH TIME ZONE`,
		`ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS manually_edited BOOLEAN NOT NULL DEFAULT FALSE`,
		`UPDATE attendance_records SET status = 'work' WHERE status = 'working'`,
		`ALTER TABLE devices ADD COLUMN IF NOT EXISTS employee_uuid UUID REFERENCES employees(id) ON DELETE SET NULL`,
		`ALTER TABLE devices ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES users(id) ON DELETE SET NULL`,
		`ALTER TABLE devices ADD COLUMN IF NOT EXISTS employee_session_at TIMESTAMP WITH TIME ZONE`,
		`ALTER TABLE devices ADD COLUMN IF NOT EXISTS client_ip VARCHAR(64)`,
		`CREATE INDEX IF NOT EXISTS idx_devices_employee_uuid ON devices(employee_uuid)`,
		`CREATE TABLE IF NOT EXISTS device_invite_codes (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            code VARCHAR(32) NOT NULL UNIQUE,
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            created_by UUID REFERENCES users(id) ON DELETE SET NULL,
            expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
            used_at TIMESTAMP WITH TIME ZONE,
            used_by_device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
            revoked_at TIMESTAMP WITH TIME ZONE,
            superseded_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE INDEX IF NOT EXISTS idx_invite_codes_employee ON device_invite_codes(employee_id)`,
		`CREATE INDEX IF NOT EXISTS idx_invite_codes_code ON device_invite_codes(code)`,
		`CREATE TABLE IF NOT EXISTS work_sessions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            attendance_date DATE NOT NULL,
            device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
            checkin_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            checkout_time TIMESTAMP WITH TIME ZONE,
            status VARCHAR(20) NOT NULL DEFAULT 'open',
            recording_id UUID REFERENCES recordings(id) ON DELETE SET NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE INDEX IF NOT EXISTS idx_work_sessions_employee_date ON work_sessions(employee_id, attendance_date DESC)`,
	}
	for _, stmt := range stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec failed: %w\nSQL: %s", err, stmt)
		}
	}
	if err := closeDuplicateOpenWorkSessions(db, "employee_id"); err != nil {
		return fmt.Errorf("dedupe open work_sessions: %w", err)
	}
	if _, err := db.Exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_work_sessions_open ON work_sessions(employee_id) WHERE status = 'open'`); err != nil {
		return fmt.Errorf("exec failed: %w\nSQL: CREATE UNIQUE INDEX idx_work_sessions_open", err)
	}
	var exists bool
	if err := db.QueryRow(`SELECT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'device_invite_codes')`).Scan(&exists); err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("device_invite_codes table still missing after migration")
	}
	log.Println("workforce schema ready")
	return nil
}

// ensureWorkforceTelegramSchema adds Telegram attendance integration tables (P0).
func ensureWorkforceTelegramSchema(db *sql.DB) error {
	stmts := []string{
		`ALTER TABLE work_sessions ADD COLUMN IF NOT EXISTS source VARCHAR(32) NOT NULL DEFAULT 'agent'`,

		`CREATE TABLE IF NOT EXISTS wf_telegram_settings (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            bot_token_enc TEXT,
            bot_username VARCHAR(64),
            bot_id BIGINT,
            worker_secret VARCHAR(128),
            timezone VARCHAR(64) NOT NULL DEFAULT 'Asia/Shanghai',
            day_start VARCHAR(5) NOT NULL DEFAULT '09:00',
            day_end VARCHAR(5) NOT NULL DEFAULT '21:00',
            grace_minutes INT NOT NULL DEFAULT 5,
            dual_shift_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

		`CREATE TABLE IF NOT EXISTS wf_telegram_groups (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            chat_id VARCHAR(64) NOT NULL UNIQUE,
            chat_title VARCHAR(256),
            enabled BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

		`CREATE TABLE IF NOT EXISTS employee_telegram_bindings (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            telegram_user_id BIGINT NOT NULL,
            telegram_username VARCHAR(128),
            chat_id VARCHAR(64),
            bound_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            status SMALLINT NOT NULL DEFAULT 1,
            UNIQUE(employee_id),
            UNIQUE(telegram_user_id)
        )`,
		`CREATE INDEX IF NOT EXISTS idx_employee_telegram_bindings_employee ON employee_telegram_bindings(employee_id)`,
	}
	for _, stmt := range stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec failed: %w\nSQL: %s", err, stmt)
		}
	}
	var count int
	if err := db.QueryRow(`SELECT COUNT(*) FROM wf_telegram_settings`).Scan(&count); err != nil {
		return err
	}
	if count == 0 {
		if _, err := db.Exec(`INSERT INTO wf_telegram_settings (enabled) VALUES (FALSE)`); err != nil {
			return err
		}
	}

	p1Stmts := []string{
		`CREATE TABLE IF NOT EXISTS wf_tg_activity_types (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            code VARCHAR(32) NOT NULL UNIQUE,
            name VARCHAR(64) NOT NULL,
            max_times_per_day INT NOT NULL DEFAULT 0,
            time_limit_seconds INT NOT NULL DEFAULT 300,
            sort_order INT NOT NULL DEFAULT 0,
            enabled BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_activity_fines (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            activity_code VARCHAR(32) NOT NULL REFERENCES wf_tg_activity_types(code) ON DELETE CASCADE,
            segment_minutes INT NOT NULL,
            fine_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
            UNIQUE(activity_code, segment_minutes)
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_activity_sessions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            activity_code VARCHAR(32) NOT NULL,
            activity_name VARCHAR(64) NOT NULL,
            attendance_date DATE NOT NULL,
            started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            ended_at TIMESTAMP WITH TIME ZONE,
            elapsed_seconds INT NOT NULL DEFAULT 0,
            limit_seconds INT NOT NULL DEFAULT 0,
            overtime_seconds INT NOT NULL DEFAULT 0,
            fine_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
            penalty_record_id UUID,
            status VARCHAR(16) NOT NULL DEFAULT 'open',
            source VARCHAR(32) NOT NULL DEFAULT 'telegram',
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE INDEX IF NOT EXISTS idx_wf_tg_activity_sessions_employee ON wf_tg_activity_sessions(employee_id, attendance_date DESC)`,
	}
	for _, stmt := range p1Stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec p1 failed: %w\nSQL: %s", err, stmt)
		}
	}
	if err := closeDuplicateOpenActivitySessions(db); err != nil {
		return fmt.Errorf("dedupe open activity sessions: %w", err)
	}
	if _, err := db.Exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_wf_tg_activity_sessions_open ON wf_tg_activity_sessions(employee_id) WHERE status = 'open'`); err != nil {
		return fmt.Errorf("exec p1 index failed: %w", err)
	}
	if err := seedDefaultTelegramActivityTypes(db); err != nil {
		return err
	}

	p2Stmts := []string{
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS night_start VARCHAR(5) NOT NULL DEFAULT '21:00'`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS night_end VARCHAR(5) NOT NULL DEFAULT '09:00'`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS daily_reset_time VARCHAR(5) NOT NULL DEFAULT '09:00'`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS daily_reset_enabled BOOLEAN NOT NULL DEFAULT TRUE`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS daily_reset_execution_offset_minutes INT NOT NULL DEFAULT 120`,
		`ALTER TABLE work_sessions ADD COLUMN IF NOT EXISTS shift_type VARCHAR(16) NOT NULL DEFAULT 'day'`,
		`CREATE TABLE IF NOT EXISTS wf_tg_group_shift_state (
            chat_id VARCHAR(64) PRIMARY KEY,
            current_shift VARCHAR(16) NOT NULL DEFAULT 'day',
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_handovers (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            employee_name VARCHAR(128) NOT NULL DEFAULT '',
            chat_id VARCHAR(64),
            from_shift VARCHAR(16) NOT NULL,
            to_shift VARCHAR(16) NOT NULL,
            note TEXT,
            handover_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE INDEX IF NOT EXISTS idx_wf_tg_handovers_at ON wf_tg_handovers(handover_at DESC)`,
		`CREATE TABLE IF NOT EXISTS wf_tg_daily_reset_log (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            reset_date DATE NOT NULL,
            closed_work_sessions INT NOT NULL DEFAULT 0,
            closed_activities INT NOT NULL DEFAULT 0,
            run_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(reset_date)
        )`,
	}
	for _, stmt := range p2Stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec p2 failed: %w\nSQL: %s", err, stmt)
		}
	}

	p4Stmts := []string{
		`DROP INDEX IF EXISTS idx_work_sessions_open`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS shift_window_disabled BOOLEAN NOT NULL DEFAULT FALSE`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS work_end_grace_minutes INT NOT NULL DEFAULT 5`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS require_pc_login BOOLEAN NOT NULL DEFAULT TRUE`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS capture_linked_to_checkin BOOLEAN NOT NULL DEFAULT FALSE`,
		`ALTER TABLE devices ADD COLUMN IF NOT EXISTS invited_employee_uuid UUID REFERENCES employees(id) ON DELETE SET NULL`,
		`ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS checkin_source VARCHAR(32)`,
		`ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS checkout_source VARCHAR(32)`,
		`CREATE TABLE IF NOT EXISTS wf_tg_bind_tokens (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            token VARCHAR(32) NOT NULL UNIQUE,
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
            expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
            used_at TIMESTAMP WITH TIME ZONE,
            used_by_telegram_user_id BIGINT,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE INDEX IF NOT EXISTS idx_wf_tg_bind_tokens_employee ON wf_tg_bind_tokens(employee_id)`,
		`ALTER TABLE wf_tg_activity_types ADD COLUMN IF NOT EXISTS max_concurrent INT NOT NULL DEFAULT 0`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS shift_type VARCHAR(16) NOT NULL DEFAULT 'day'`,
		`ALTER TABLE devices ADD COLUMN IF NOT EXISTS is_shared_workstation BOOLEAN NOT NULL DEFAULT FALSE`,
		`CREATE TABLE IF NOT EXISTS wf_shared_workstation_members (
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (device_id, employee_id)
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_work_fines (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            checkin_type VARCHAR(16) NOT NULL,
            segment_minutes INT NOT NULL,
            fine_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
            UNIQUE(checkin_type, segment_minutes)
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_handover_configs (
            chat_id VARCHAR(64) PRIMARY KEY,
            handover_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            handover_day INT NOT NULL DEFAULT 31,
            handover_month INT NOT NULL DEFAULT 0,
            handover_day_start_time VARCHAR(5) NOT NULL DEFAULT '15:00',
            night_start_time VARCHAR(5) NOT NULL DEFAULT '21:00',
            day_start_time VARCHAR(5) NOT NULL DEFAULT '09:00',
            handover_night_hours INT NOT NULL DEFAULT 18,
            handover_day_hours INT NOT NULL DEFAULT 18,
            normal_night_hours INT NOT NULL DEFAULT 12,
            normal_day_hours INT NOT NULL DEFAULT 12,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_employee_shift_state (
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            chat_id VARCHAR(64) NOT NULL DEFAULT '',
            shift_type VARCHAR(16) NOT NULL,
            record_date DATE NOT NULL,
            session_id UUID,
            started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (employee_id, shift_type)
        )`,
		`DROP TABLE IF EXISTS wf_tg_group_shift_state`,
		`CREATE TABLE IF NOT EXISTS wf_tg_group_shift_state (
            chat_id VARCHAR(64) NOT NULL,
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            shift_type VARCHAR(16) NOT NULL,
            record_date DATE NOT NULL,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (chat_id, employee_id, shift_type)
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_handover_cycles (
            chat_id VARCHAR(64) NOT NULL,
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            handover_date DATE NOT NULL,
            shift_type VARCHAR(16) NOT NULL,
            cycle_number INT NOT NULL,
            cycle_start_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            total_work_seconds INT NOT NULL DEFAULT 0,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (chat_id, employee_id, handover_date, shift_type, cycle_number)
        )`,
	}
	for _, stmt := range p4Stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec p4 failed: %w\nSQL: %s", err, stmt)
		}
	}
	if err := closeDuplicateOpenWorkSessions(db, "employee_id, shift_type"); err != nil {
		return fmt.Errorf("dedupe open work_sessions by shift: %w", err)
	}
	if _, err := db.Exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_work_sessions_open_shift ON work_sessions(employee_id, shift_type) WHERE status = 'open'`); err != nil {
		return fmt.Errorf("exec p4 index failed: %w", err)
	}

	p5Stmts := []string{
		`ALTER TABLE wf_tg_handover_configs ADD COLUMN IF NOT EXISTS handover_reset_threshold_hours NUMERIC(6,2) NOT NULL DEFAULT 12`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS source_chat_id VARCHAR(64)`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS telegram_message_id BIGINT`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS limit_warning_sent BOOLEAN NOT NULL DEFAULT FALSE`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS auto_ended BOOLEAN NOT NULL DEFAULT FALSE`,
		`CREATE TABLE IF NOT EXISTS wf_tg_push_settings (
            chat_id VARCHAR(64) PRIMARY KEY,
            channel_id VARCHAR(64),
            notification_group_id VARCHAR(64),
            extra_work_group_id VARCHAR(64),
            enable_channel_push BOOLEAN NOT NULL DEFAULT TRUE,
            enable_group_push BOOLEAN NOT NULL DEFAULT TRUE,
            enable_admin_push BOOLEAN NOT NULL DEFAULT FALSE,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_monthly_activity_stats (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            year_month VARCHAR(7) NOT NULL,
            chat_id VARCHAR(64) NOT NULL DEFAULT '',
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            shift_type VARCHAR(16) NOT NULL DEFAULT 'day',
            activity_code VARCHAR(64) NOT NULL,
            activity_name VARCHAR(128) NOT NULL DEFAULT '',
            activity_count INT NOT NULL DEFAULT 0,
            total_seconds INT NOT NULL DEFAULT 0,
            fine_total NUMERIC(12,2) NOT NULL DEFAULT 0,
            archived_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(year_month, chat_id, employee_id, shift_type, activity_code)
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_monthly_work_stats (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            year_month VARCHAR(7) NOT NULL,
            chat_id VARCHAR(64) NOT NULL DEFAULT '',
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            shift_type VARCHAR(16) NOT NULL DEFAULT 'day',
            session_count INT NOT NULL DEFAULT 0,
            work_fine_total NUMERIC(12,2) NOT NULL DEFAULT 0,
            archived_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(year_month, chat_id, employee_id, shift_type)
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_reset_export_log (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            reset_date DATE NOT NULL,
            export_path TEXT,
            archived_month VARCHAR(7),
            closed_work_sessions INT NOT NULL DEFAULT 0,
            closed_activities INT NOT NULL DEFAULT 0,
            run_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(reset_date)
        )`,
		`CREATE TABLE IF NOT EXISTS wf_tg_relay_states (
            chat_id VARCHAR(64) NOT NULL,
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            relay_handover_date DATE NOT NULL,
            successor_record_date DATE NOT NULL,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (chat_id, employee_id)
        )`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS admin_telegram_user_ids TEXT`,
	}
	for _, stmt := range p5Stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec p5 failed: %w\nSQL: %s", err, stmt)
		}
	}
	p7Stmts := []string{
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS grace_minutes_after INT NOT NULL DEFAULT 360`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS work_end_grace_after INT NOT NULL DEFAULT 360`,
		`ALTER TABLE wf_telegram_groups ADD COLUMN IF NOT EXISTS shift_grace_before INT`,
		`ALTER TABLE wf_telegram_groups ADD COLUMN IF NOT EXISTS shift_grace_after INT`,
		`ALTER TABLE wf_telegram_groups ADD COLUMN IF NOT EXISTS work_end_grace_before INT`,
		`ALTER TABLE wf_telegram_groups ADD COLUMN IF NOT EXISTS work_end_grace_after INT`,
		`ALTER TABLE wf_telegram_groups ADD COLUMN IF NOT EXISTS daily_reset_time VARCHAR(5)`,
		`ALTER TABLE work_sessions ADD COLUMN IF NOT EXISTS shift_detail VARCHAR(16)`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS telegram_message_id BIGINT`,
		`DROP INDEX IF EXISTS idx_work_sessions_open_shift`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS overtime_immediate_sent BOOLEAN NOT NULL DEFAULT FALSE`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS overtime_5min_sent BOOLEAN NOT NULL DEFAULT FALSE`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS last_overtime_reminder_min INT NOT NULL DEFAULT -1`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS force_back_sent BOOLEAN NOT NULL DEFAULT FALSE`,
		`ALTER TABLE wf_tg_activity_sessions ADD COLUMN IF NOT EXISTS end_source VARCHAR(32)`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS bot_mode VARCHAR(16) NOT NULL DEFAULT 'polling'`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS webhook_url TEXT`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS webhook_secret VARCHAR(64)`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS bot_ui_lang VARCHAR(8) NOT NULL DEFAULT 'both'`,
		`ALTER TABLE wf_telegram_groups ADD COLUMN IF NOT EXISTS bot_ui_lang VARCHAR(8)`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS worker_pairing_code VARCHAR(16)`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS worker_pairing_expires_at TIMESTAMP WITH TIME ZONE`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS worker_last_seen_at TIMESTAMP WITH TIME ZONE`,
		`CREATE TABLE IF NOT EXISTS wf_telegram_discovered_chats (
			chat_id VARCHAR(64) PRIMARY KEY,
			chat_title VARCHAR(256),
			chat_type VARCHAR(32),
			first_seen_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
			last_seen_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
		)`,
		`CREATE INDEX IF NOT EXISTS idx_wf_tg_discovered_last_seen ON wf_telegram_discovered_chats(last_seen_at DESC)`,
		`CREATE TABLE IF NOT EXISTS wf_tg_group_reset_log (
			chat_id VARCHAR(64) NOT NULL,
			reset_date DATE NOT NULL,
			closed_work_sessions INT NOT NULL DEFAULT 0,
			closed_activities INT NOT NULL DEFAULT 0,
			run_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
			UNIQUE(chat_id, reset_date)
		)`,
		`ALTER TABLE employee_telegram_bindings ADD COLUMN IF NOT EXISTS last_group_bot_message_id BIGINT`,
	}
	for _, stmt := range p7Stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec p7 failed: %w\nSQL: %s", err, stmt)
		}
	}
	if err := closeDuplicateOpenWorkSessions(db, "employee_id, shift_type, attendance_date"); err != nil {
		return fmt.Errorf("dedupe open work_sessions by shift/date: %w", err)
	}
	if _, err := db.Exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_work_sessions_open_shift_date ON work_sessions(employee_id, shift_type, attendance_date) WHERE status = 'open'`); err != nil {
		return fmt.Errorf("exec p7 index failed: %w", err)
	}
	if err := seedDefaultTelegramWorkFines(db); err != nil {
		return err
	}
	p8Stmts := []string{
		`CREATE TABLE IF NOT EXISTS performance_push_settings (
            id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
            bot_token_enc TEXT NOT NULL DEFAULT '',
            bot_username VARCHAR(128),
            bot_id BIGINT,
            chat_id VARCHAR(64),
            chat_title VARCHAR(255),
            chat_type VARCHAR(32),
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )`,
		`CREATE TABLE IF NOT EXISTS penalty_push_settings (
            id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
            bot_token_enc TEXT NOT NULL DEFAULT '',
            bot_username VARCHAR(128),
            bot_id BIGINT,
            chat_id VARCHAR(64),
            chat_title VARCHAR(255),
            chat_type VARCHAR(32),
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )`,
		`CREATE TABLE IF NOT EXISTS agent_notification_settings (
            id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
            enabled BOOLEAN NOT NULL DEFAULT TRUE,
            salary_paid_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            penalty_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            performance_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            attendance_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            activity_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            default_duration_sec INT NOT NULL DEFAULT 300,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )`,
		`INSERT INTO agent_notification_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING`,
		`CREATE TABLE IF NOT EXISTS cs_tool_settings (
            id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
            tool_url TEXT NOT NULL DEFAULT 'https://dh1888.github.io/168/',
            script_url TEXT NOT NULL DEFAULT 'https://dh1888.github.io/render/',
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )`,
		`INSERT INTO cs_tool_settings (id, tool_url, script_url) VALUES (
            1,
            'https://dh1888.github.io/168/',
            'https://dh1888.github.io/render/'
        ) ON CONFLICT (id) DO NOTHING`,
	}
	for _, stmt := range p8Stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec p8 failed: %w\nSQL: %s", err, stmt)
		}
	}
	p9Stmts := []string{
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS late_tolerance_minutes INT`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS early_leave_tolerance_minutes INT`,
		`ALTER TABLE wf_telegram_settings ADD COLUMN IF NOT EXISTS check_out_grace_before INT`,
		`ALTER TABLE wf_telegram_groups ADD COLUMN IF NOT EXISTS late_tolerance_minutes INT`,
		`ALTER TABLE wf_telegram_groups ADD COLUMN IF NOT EXISTS early_leave_tolerance_minutes INT`,
	}
	for _, stmt := range p9Stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec p9 failed: %w\nSQL: %s", err, stmt)
		}
	}
	if _, err := db.Exec(`
		UPDATE wf_telegram_settings SET
			late_tolerance_minutes = COALESCE(late_tolerance_minutes, grace_minutes_after, 360),
			early_leave_tolerance_minutes = COALESCE(early_leave_tolerance_minutes, work_end_grace_minutes, 120),
			check_out_grace_before = COALESCE(check_out_grace_before, 120)`); err != nil {
		return fmt.Errorf("backfill grace tolerance settings: %w", err)
	}
	if _, err := db.Exec(`
		UPDATE wf_telegram_groups SET
			early_leave_tolerance_minutes = COALESCE(early_leave_tolerance_minutes, work_end_grace_before)
		WHERE work_end_grace_before IS NOT NULL AND early_leave_tolerance_minutes IS NULL`); err != nil {
		return fmt.Errorf("backfill group early leave tolerance: %w", err)
	}
	if _, err := db.Exec(`
		ALTER TABLE wf_telegram_settings
			ALTER COLUMN late_tolerance_minutes SET DEFAULT 360,
			ALTER COLUMN early_leave_tolerance_minutes SET DEFAULT 120,
			ALTER COLUMN check_out_grace_before SET DEFAULT 120`); err != nil {
		return fmt.Errorf("set grace tolerance defaults: %w", err)
	}
	p10Stmts := []string{
		`ALTER TABLE employees ADD COLUMN IF NOT EXISTS attendance_mode VARCHAR(32) NOT NULL DEFAULT 'pc_tg'`,
		`CREATE TABLE IF NOT EXISTS device_telegram_bindings (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            telegram_user_id BIGINT NOT NULL,
            telegram_username VARCHAR(128),
            chat_id VARCHAR(64),
            bound_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            status SMALLINT NOT NULL DEFAULT 1,
            UNIQUE(device_id),
            UNIQUE(telegram_user_id)
        )`,
		`CREATE INDEX IF NOT EXISTS idx_device_telegram_bindings_device ON device_telegram_bindings(device_id)`,
	}
	for _, stmt := range p10Stmts {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("exec p10 failed: %w\nSQL: %s", err, stmt)
		}
	}
	log.Println("workforce telegram schema ready")
	return nil
}

func seedDefaultTelegramWorkFines(db *sql.DB) error {
	defaults := []struct {
		typ     string
		segment int
		amount  float64
	}{
		{"work_start", 5, 10},
		{"work_start", 15, 30},
		{"work_end", 5, 10},
		{"work_end", 15, 30},
	}
	for _, d := range defaults {
		_, err := db.Exec(`
			INSERT INTO wf_tg_work_fines (checkin_type, segment_minutes, fine_amount)
			VALUES ($1, $2, $3) ON CONFLICT (checkin_type, segment_minutes) DO NOTHING`,
			d.typ, d.segment, d.amount)
		if err != nil {
			return err
		}
	}
	return nil
}

func seedDefaultTelegramActivityTypes(db *sql.DB) error {
	defaults := []struct {
		code, name string
		limitSec   int
		maxTimes   int
		order      int
	}{
		{"wc_small", "小厕", 180, 0, 1},
		{"wc_large", "大厕", 600, 0, 2},
		{"smoke", "抽烟", 300, 0, 3},
		{"eat", "吃饭", 1800, 0, 4},
	}
	for _, d := range defaults {
		_, err := db.Exec(`
			INSERT INTO wf_tg_activity_types (code, name, max_times_per_day, time_limit_seconds, sort_order, enabled)
			VALUES ($1, $2, $3, $4, $5, TRUE)
			ON CONFLICT (code) DO NOTHING`,
			d.code, d.name, d.maxTimes, d.limitSec, d.order)
		if err != nil {
			return err
		}
	}
	return nil
}

func initEmbeddedSchema(db *sql.DB) error {
    statements := []string{
        // `CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`,

        // ========== 用户表 ==========
        `CREATE TABLE IF NOT EXISTS users (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            username VARCHAR(100) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            email VARCHAR(255),
            real_name VARCHAR(100),
            status SMALLINT NOT NULL DEFAULT 1,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            last_login_at TIMESTAMP WITH TIME ZONE
        )`,

        // ========== 角色表 ==========
        `CREATE TABLE IF NOT EXISTS roles (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            name VARCHAR(100) NOT NULL UNIQUE,
            description TEXT,
            permissions JSONB NOT NULL DEFAULT '[]',
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 用户角色关联表 ==========
        `CREATE TABLE IF NOT EXISTS user_roles (
            user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (user_id, role_id)
        )`,

        // ========== 设备表 ==========
        `CREATE TABLE IF NOT EXISTS devices (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id VARCHAR(100),
            employee_name VARCHAR(255),
            employee_number VARCHAR(100),
            position VARCHAR(100),
            device_fingerprint VARCHAR(255) NOT NULL UNIQUE,
            hostname VARCHAR(255) NOT NULL,
            os_version VARCHAR(255),
            agent_version VARCHAR(50),
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            bound_at TIMESTAMP WITH TIME ZONE,
            last_seen_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            device_secret VARCHAR(128)
        )`,

        // ========== 设备表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_devices_device_fingerprint ON devices(device_fingerprint)`,
        `CREATE INDEX IF NOT EXISTS idx_devices_status ON devices(status)`,
        `CREATE INDEX IF NOT EXISTS idx_devices_last_seen ON devices(last_seen_at)`,
        `CREATE INDEX IF NOT EXISTS idx_devices_employee_id ON devices(employee_id)`,

        // ========== 录屏记录表 ==========
        `CREATE TABLE IF NOT EXISTS recordings (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            start_time TIMESTAMP WITH TIME ZONE NOT NULL,
            end_time TIMESTAMP WITH TIME ZONE NOT NULL,
            file_path TEXT NOT NULL,
            file_size BIGINT NOT NULL DEFAULT 0,
            sha256 VARCHAR(64),
            uploaded BOOLEAN NOT NULL DEFAULT FALSE,
            duration INTEGER DEFAULT 0,
            updated_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 录屏表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_recordings_device_id ON recordings(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_recordings_start_time ON recordings(start_time)`,
        `CREATE INDEX IF NOT EXISTS idx_recordings_uploaded ON recordings(uploaded)`,
        `CREATE INDEX IF NOT EXISTS idx_recordings_device_start ON recordings(device_id, start_time DESC)`,

        // ========== 截图表（✅ 添加新字段） ==========
        `CREATE TABLE IF NOT EXISTS screenshots (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            captured_at TIMESTAMP WITH TIME ZONE NOT NULL,
            file_path TEXT NOT NULL,
            file_size BIGINT NOT NULL DEFAULT 0,
            uploaded BOOLEAN NOT NULL DEFAULT FALSE,
            width INTEGER DEFAULT 0,
            height INTEGER DEFAULT 0,
            format VARCHAR(10) DEFAULT 'jpg',
            uploaded_at TIMESTAMP WITH TIME ZONE,
            encrypted BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 截图表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_screenshots_device_id ON screenshots(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_screenshots_captured_at ON screenshots(captured_at)`,
        `CREATE INDEX IF NOT EXISTS idx_screenshots_device_captured ON screenshots(device_id, captured_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_screenshots_uploaded ON screenshots(uploaded)`,

        // ========== 活动日志表（✅ 添加新字段） ==========
        `CREATE TABLE IF NOT EXISTS activity_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            process_name VARCHAR(255),
            window_title TEXT,
            browser_title TEXT,
            started_at TIMESTAMP WITH TIME ZONE NOT NULL,
            ended_at TIMESTAMP WITH TIME ZONE,
            is_idle BOOLEAN NOT NULL DEFAULT FALSE,
            duration_seconds INTEGER NOT NULL DEFAULT 0,
            reported BOOLEAN DEFAULT FALSE,
            reported_at TIMESTAMP WITH TIME ZONE,
            retry_count INTEGER DEFAULT 0,
            error_message TEXT DEFAULT '',
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 活动日志表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_device_id ON activity_logs(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_started_at ON activity_logs(started_at)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_process_name ON activity_logs(process_name)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_device_started ON activity_logs(device_id, started_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_reported ON activity_logs(reported)`,

        // ========== 策略表 ==========
        `CREATE TABLE IF NOT EXISTS policies (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            name VARCHAR(200) NOT NULL,
            version INTEGER NOT NULL DEFAULT 1,
            content JSONB NOT NULL,
            signature VARCHAR(255),
            is_current BOOLEAN NOT NULL DEFAULT FALSE,
            status SMALLINT NOT NULL DEFAULT 1,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,

        // ========== 策略表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_policies_is_current ON policies(is_current) WHERE is_current = TRUE`,
        `CREATE INDEX IF NOT EXISTS idx_policies_version ON policies(version)`,

        // ========== 上传任务表 ==========
        `CREATE TABLE IF NOT EXISTS upload_tasks (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            task_type VARCHAR(50) NOT NULL DEFAULT 'upload_recordings',
            start_time TIMESTAMP WITH TIME ZONE NOT NULL,
            end_time TIMESTAMP WITH TIME ZONE,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            progress INTEGER NOT NULL DEFAULT 0,
            result TEXT,
            completed_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 上传任务表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_upload_tasks_device_id ON upload_tasks(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_upload_tasks_status ON upload_tasks(status)`,
        `CREATE INDEX IF NOT EXISTS idx_upload_tasks_created_at ON upload_tasks(created_at)`,

        // ========== 清理策略表 ==========
        `CREATE TABLE IF NOT EXISTS cleanup_policy (
            id VARCHAR(50) PRIMARY KEY DEFAULT 'default',
            auto_cleanup_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            recording_retention_days INTEGER NOT NULL DEFAULT 30,
            screenshot_retention_days INTEGER NOT NULL DEFAULT 30,
            log_retention_days INTEGER NOT NULL DEFAULT 90,
            disk_usage_threshold_percent INTEGER NOT NULL DEFAULT 80,
            cleanup_interval_minutes INTEGER NOT NULL DEFAULT 60,
            last_run_at TIMESTAMP WITH TIME ZONE,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 清理日志表 ==========
        `CREATE TABLE IF NOT EXISTS cleanup_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            trigger_type VARCHAR(20) NOT NULL,
            status VARCHAR(20) NOT NULL,
            deleted_recordings INTEGER NOT NULL DEFAULT 0,
            deleted_screenshots INTEGER NOT NULL DEFAULT 0,
            deleted_logs INTEGER NOT NULL DEFAULT 0,
            deleted_bytes BIGINT NOT NULL DEFAULT 0,
            message TEXT,
            started_at TIMESTAMP WITH TIME ZONE NOT NULL,
            completed_at TIMESTAMP WITH TIME ZONE NOT NULL
        )`,

        // ========== 清理日志表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_cleanup_logs_started_at ON cleanup_logs(started_at)`,
        `CREATE INDEX IF NOT EXISTS idx_cleanup_logs_trigger_type ON cleanup_logs(trigger_type)`,

        // ========== 出款与考勤业务表 ==========
        `CREATE TABLE IF NOT EXISTS employees (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id VARCHAR(100),
            name VARCHAR(255),
            position VARCHAR(100),
            hire_date DATE,
            work_location VARCHAR(255),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employees_employee_id ON employees(employee_id)`,
        `CREATE TABLE IF NOT EXISTS attendance_records (
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            year_month VARCHAR(7) NOT NULL,
            date DATE NOT NULL,
            status VARCHAR(50) NOT NULL,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (employee_id, year_month, date)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_attendance_records_employee_id ON attendance_records(employee_id)`,
        `CREATE TABLE IF NOT EXISTS performance_records (
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            employee_name VARCHAR(255),
            position VARCHAR(100),
            score_records JSONB,
            total_score INTEGER DEFAULT 0,
            grade VARCHAR(50),
            month VARCHAR(7) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (employee_id, month)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_performance_records_month ON performance_records(month)`,
        `CREATE TABLE IF NOT EXISTS penalty_records (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
            employee_name VARCHAR(255),
            position VARCHAR(100),
            amount NUMERIC(12,2) NOT NULL DEFAULT 0,
            category VARCHAR(100),
            reason TEXT,
            penalty_date DATE NOT NULL,
            created_by VARCHAR(100),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_penalty_records_employee_id ON penalty_records(employee_id)`,
        `CREATE INDEX IF NOT EXISTS idx_penalty_records_penalty_date ON penalty_records(penalty_date)`,
        `CREATE TABLE IF NOT EXISTS sites (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            code VARCHAR(100) NOT NULL UNIQUE,
            name VARCHAR(255) NOT NULL,
            sort_order INTEGER NOT NULL DEFAULT 0,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,
        `CREATE TABLE IF NOT EXISTS employee_accounts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            site_id UUID NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
            name VARCHAR(255),
            account_name VARCHAR(255) NOT NULL,
            shift VARCHAR(50),
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            UNIQUE (site_id, account_name)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employee_accounts_site_id ON employee_accounts(site_id)`,
        `CREATE TABLE IF NOT EXISTS site_stats (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_account_id UUID NOT NULL REFERENCES employee_accounts(id) ON DELETE CASCADE,
            site_id UUID NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
            stat_date DATE NOT NULL,
            shift VARCHAR(50),
            order_count INTEGER NOT NULL DEFAULT 0,
            avg_time_seconds INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            UNIQUE (employee_account_id, stat_date, shift)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_site_id ON site_stats(site_id)`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_employee_account_id ON site_stats(employee_account_id)`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_stat_date ON site_stats(stat_date)`,

        // ========== 添加 updated_at 自动更新触发器 ==========
        `CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql`,

        // ========== 为 users 表添加触发器 ==========
        `DROP TRIGGER IF EXISTS update_users_updated_at ON users;
        CREATE TRIGGER update_users_updated_at
            BEFORE UPDATE ON users
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,

        // ========== 为 policies 表添加触发器 ==========
        `DROP TRIGGER IF EXISTS update_policies_updated_at ON policies;
        CREATE TRIGGER update_policies_updated_at
            BEFORE UPDATE ON policies
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,

		`ALTER TABLE devices DROP CONSTRAINT IF EXISTS devices_status_check`,
        `ALTER TABLE devices ADD CONSTRAINT devices_status_check CHECK (status IN ('pending', 'approved', 'rejected'))`,

        // ========== 工资记录表 ==========
        `CREATE TABLE IF NOT EXISTS salary_records (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id VARCHAR(100) NOT NULL,
            employee_name VARCHAR(255) NOT NULL,
            position VARCHAR(100),
            hire_date_dept VARCHAR(255),
            months_employed INTEGER DEFAULT 0,
            last_month_base DECIMAL(12,2) DEFAULT 0,
            total_increase DECIMAL(12,2) DEFAULT 0,
            base_salary DECIMAL(12,2) DEFAULT 0,
            attendance_days DECIMAL(10,2) DEFAULT 0,
            actual_base_salary DECIMAL(12,2) DEFAULT 0,
            attendance_adjustment DECIMAL(12,2) DEFAULT 0,
            half_year_unpaid_leave DECIMAL(12,2) DEFAULT 0,
            exchange_rate DECIMAL(10,4) DEFAULT 0,
            performance_score INTEGER DEFAULT 0,
            performance_bonus_b DECIMAL(12,2) DEFAULT 0,
            reward DECIMAL(12,2) DEFAULT 0,
            penalty DECIMAL(12,2) DEFAULT 0,
            advance DECIMAL(12,2) DEFAULT 0,
            other_deduction DECIMAL(12,2) DEFAULT 0,
            protection_return DECIMAL(12,2) DEFAULT 0,
            protection_fee DECIMAL(12,2) DEFAULT 0,
            total_salary DECIMAL(12,2) DEFAULT 0,
            remark TEXT,
            year_month VARCHAR(7) NOT NULL,
            paid_status VARCHAR(16) NOT NULL DEFAULT 'pending',
            paid_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(employee_id, year_month)
        )`,

        `CREATE INDEX IF NOT EXISTS idx_salary_records_employee_id ON salary_records(employee_id)`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_year_month ON salary_records(year_month)`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_employee_name ON salary_records(employee_name)`,
        `ALTER TABLE salary_records ADD COLUMN IF NOT EXISTS paid_status VARCHAR(16) NOT NULL DEFAULT 'pending'`,
        `ALTER TABLE salary_records ADD COLUMN IF NOT EXISTS paid_at TIMESTAMP WITH TIME ZONE`,
        `ALTER TABLE salary_records ADD COLUMN IF NOT EXISTS sheet_values JSONB`,
        `CREATE TABLE IF NOT EXISTS salary_month_layouts (
            year_month VARCHAR(7) PRIMARY KEY,
            headers JSONB NOT NULL DEFAULT '[]'::jsonb,
            name_column_index INTEGER NOT NULL DEFAULT 1,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE TABLE IF NOT EXISTS salary_configs (
            config_key VARCHAR(64) PRIMARY KEY,
            config_name VARCHAR(64) NOT NULL DEFAULT '',
            total_increase DECIMAL(12,2) NOT NULL DEFAULT 0,
            full_attendance_days INTEGER NOT NULL DEFAULT 0,
            full_attendance_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            full_attendance_currency VARCHAR(8) NOT NULL DEFAULT 'CNY',
            exchange_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
            cny_thb_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
            cny_usd_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
            thb_usd_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
            performance_full_score_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            performance_currency VARCHAR(8) NOT NULL DEFAULT 'CNY',
            protection_fee DECIMAL(12,2) NOT NULL DEFAULT 0,
            protection_fee_currency VARCHAR(8) NOT NULL DEFAULT 'CNY',
            payout_currency VARCHAR(8) NOT NULL DEFAULT 'CNY',
            position_caps JSONB NOT NULL DEFAULT '[]'::jsonb,
            sort_order INTEGER NOT NULL DEFAULT 0,
            is_builtin BOOLEAN NOT NULL DEFAULT false,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        `DROP TRIGGER IF EXISTS update_salary_records_updated_at ON salary_records;
        CREATE TRIGGER update_salary_records_updated_at
            BEFORE UPDATE ON salary_records
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,

        // ========== 员工收款地址表 ==========
        `CREATE TABLE IF NOT EXISTS employee_payment_accounts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID NOT NULL UNIQUE REFERENCES employees(id) ON DELETE CASCADE,
            account_holder VARCHAR(255) NOT NULL DEFAULT '',
            bank_name VARCHAR(255) NOT NULL DEFAULT '',
            bank_account VARCHAR(128) NOT NULL DEFAULT '',
            usdt_network VARCHAR(32) NOT NULL DEFAULT '',
            usdt_address VARCHAR(255) NOT NULL DEFAULT '',
            other_wallet_type VARCHAR(64) NOT NULL DEFAULT '',
            other_wallet_address VARCHAR(255) NOT NULL DEFAULT '',
            preferred_method VARCHAR(16) NOT NULL DEFAULT '',
            remark TEXT NOT NULL DEFAULT '',
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employee_payment_accounts_employee_id ON employee_payment_accounts(employee_id)`,
        `ALTER TABLE employee_payment_accounts ADD COLUMN IF NOT EXISTS preferred_method VARCHAR(16) NOT NULL DEFAULT ''`,
        `DROP TRIGGER IF EXISTS update_employee_payment_accounts_updated_at ON employee_payment_accounts;
        CREATE TRIGGER update_employee_payment_accounts_updated_at
            BEFORE UPDATE ON employee_payment_accounts
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,

        `CREATE TABLE IF NOT EXISTS salary_payment_proofs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            year_month VARCHAR(7) NOT NULL,
            file_path VARCHAR(512) NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            content_type VARCHAR(128) NOT NULL DEFAULT 'image/jpeg',
            uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
            uploaded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(employee_id, year_month)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_salary_payment_proofs_employee_month ON salary_payment_proofs(employee_id, year_month)`,

        // ========== 用户通知（公告、工资发放等）==========
        `CREATE TABLE IF NOT EXISTS user_notifications (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            type VARCHAR(32) NOT NULL DEFAULT 'announcement',
            title VARCHAR(255) NOT NULL,
            content TEXT NOT NULL,
            payload JSONB,
            is_read BOOLEAN NOT NULL DEFAULT FALSE,
            show_popup BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_user_notifications_user_id ON user_notifications(user_id)`,
        `CREATE INDEX IF NOT EXISTS idx_user_notifications_unread ON user_notifications(user_id, is_read) WHERE is_read = FALSE`,

        // ========== 员工主数据 / 邀请码 / 工作 Session（Workforce）==========
        `ALTER TABLE employees ADD COLUMN IF NOT EXISTS department VARCHAR(100)`,
        `ALTER TABLE employees ADD COLUMN IF NOT EXISTS status SMALLINT NOT NULL DEFAULT 1`,
        `ALTER TABLE employees ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES users(id) ON DELETE SET NULL`,
        `CREATE UNIQUE INDEX IF NOT EXISTS idx_employees_user_id ON employees(user_id) WHERE user_id IS NOT NULL`,
        `CREATE INDEX IF NOT EXISTS idx_employees_department ON employees(department)`,
        `CREATE INDEX IF NOT EXISTS idx_employees_status ON employees(status)`,

        `ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS position_snapshot VARCHAR(100)`,
        `ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS checkin_time TIMESTAMP WITH TIME ZONE`,
        `ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS checkout_time TIMESTAMP WITH TIME ZONE`,
        `ALTER TABLE attendance_records ADD COLUMN IF NOT EXISTS manually_edited BOOLEAN NOT NULL DEFAULT FALSE`,
        `UPDATE attendance_records SET status = 'work' WHERE status = 'working'`,

        `ALTER TABLE devices ADD COLUMN IF NOT EXISTS employee_uuid UUID REFERENCES employees(id) ON DELETE SET NULL`,
        `ALTER TABLE devices ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES users(id) ON DELETE SET NULL`,
        `ALTER TABLE devices ADD COLUMN IF NOT EXISTS employee_session_at TIMESTAMP WITH TIME ZONE`,
        `ALTER TABLE devices ADD COLUMN IF NOT EXISTS client_ip VARCHAR(64)`,
        `CREATE INDEX IF NOT EXISTS idx_devices_employee_uuid ON devices(employee_uuid)`,
        `CREATE UNIQUE INDEX IF NOT EXISTS idx_devices_one_employee ON devices(employee_uuid) WHERE employee_uuid IS NOT NULL AND status != 'rejected'`,

        `CREATE TABLE IF NOT EXISTS device_invite_codes (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            code VARCHAR(32) NOT NULL UNIQUE,
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            created_by UUID REFERENCES users(id) ON DELETE SET NULL,
            expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
            used_at TIMESTAMP WITH TIME ZONE,
            used_by_device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
            revoked_at TIMESTAMP WITH TIME ZONE,
            superseded_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_invite_codes_employee ON device_invite_codes(employee_id)`,
        `CREATE INDEX IF NOT EXISTS idx_invite_codes_code ON device_invite_codes(code)`,

        `CREATE TABLE IF NOT EXISTS work_sessions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            attendance_date DATE NOT NULL,
            device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
            checkin_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            checkout_time TIMESTAMP WITH TIME ZONE,
            status VARCHAR(20) NOT NULL DEFAULT 'open',
            recording_id UUID REFERENCES recordings(id) ON DELETE SET NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_work_sessions_employee_date ON work_sessions(employee_id, attendance_date DESC)`,
        `CREATE UNIQUE INDEX IF NOT EXISTS idx_work_sessions_open ON work_sessions(employee_id) WHERE status = 'open'`,

        `CREATE TABLE IF NOT EXISTS auth_sessions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            subject_type VARCHAR(16) NOT NULL,
            subject_id UUID NOT NULL,
            status VARCHAR(16) NOT NULL DEFAULT 'active',
            version INT NOT NULL DEFAULT 1,
            expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
            revoked_at TIMESTAMP WITH TIME ZONE,
            revoke_reason VARCHAR(64),
            client_ip INET,
            user_agent TEXT,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_auth_sessions_subject ON auth_sessions(subject_type, subject_id)`,
        `CREATE INDEX IF NOT EXISTS idx_auth_sessions_status ON auth_sessions(status) WHERE status = 'active'`,

        `ALTER TABLE devices ADD COLUMN IF NOT EXISTS force_offlined_at TIMESTAMP WITH TIME ZONE`,

        // 共享工位：允许多员工轮流使用同一终端（取消一人一机唯一约束）
        `DROP INDEX IF EXISTS idx_devices_one_employee`,

        `CREATE TABLE IF NOT EXISTS system_settings (
            key VARCHAR(128) PRIMARY KEY,
            value TEXT NOT NULL DEFAULT '',
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        `CREATE TABLE IF NOT EXISTS auth_sessions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            subject_type VARCHAR(16) NOT NULL,
            subject_id UUID NOT NULL,
            status VARCHAR(16) NOT NULL DEFAULT 'active',
            version INT NOT NULL DEFAULT 1,
            expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
            revoked_at TIMESTAMP WITH TIME ZONE,
            revoke_reason VARCHAR(64),
            client_ip INET,
            user_agent TEXT,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_auth_sessions_subject ON auth_sessions(subject_type, subject_id)`,
        `CREATE INDEX IF NOT EXISTS idx_auth_sessions_status ON auth_sessions(status) WHERE status = 'active'`,

        `ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_secret TEXT`,
        `ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_enabled BOOLEAN NOT NULL DEFAULT FALSE`,
    }

    for _, stmt := range statements {
        if _, err := db.Exec(stmt); err != nil {
            // 如果表已存在，忽略错误
            if !strings.Contains(err.Error(), "already exists") {
                return fmt.Errorf("failed to execute statement: %s\nError: %v", stmt, err)
            }
        }
    }
    return nil
}

var defaultAdminPermissions = models.AllAdminPermissions()

func seedDefaultAdmin(db *sql.DB) error {
	// 插入/更新默认角色
	var adminRoleID string
	for _, role := range models.DefaultRoleSeeds {
		permissionsJSON, _ := json.Marshal(role.Permissions)

		var roleID string
		err := db.QueryRow(`
			INSERT INTO roles (id, name, description, permissions, created_at, updated_at)
			VALUES (gen_random_uuid(), $1, $2, $3, NOW(), NOW())
			ON CONFLICT (name) DO UPDATE SET
				description = EXCLUDED.description,
				updated_at = NOW()
			RETURNING id`,
			role.Name, role.Description, string(permissionsJSON)).Scan(&roleID)
		if err != nil {
			return err
		}
		if role.Name == "管理员" {
			adminRoleID = roleID
		}
	}

	if adminRoleID == "" {
		return fmt.Errorf("admin role not found")
	}

	for _, role := range models.DefaultRoleSeeds {
		if role.ExactSync {
			if err := syncRolePermissionsExact(db, role.Name, role.Permissions); err != nil {
				return err
			}
		} else if err := mergeRolePermissions(db, role.Name, role.Permissions); err != nil {
			return err
		}
	}

	if err := retireLegacyEmployeeRole(db); err != nil {
		return err
	}

	// 创建默认管理员用户（已存在时不覆盖密码）
	username := os.Getenv("ADMIN_USERNAME")
	if username == "" {
		username = "admin"
	}
	password := strings.TrimSpace(os.Getenv("ADMIN_PASSWORD"))
	env := strings.ToLower(strings.TrimSpace(os.Getenv("ENV")))
	isProduction := env == "production" || env == "prod"
	if password == "" {
		if isProduction {
			return fmt.Errorf("ADMIN_PASSWORD is required in production")
		}
		password = "admin123"
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}

	var userID string
	err = db.QueryRow(`
		INSERT INTO users (id, username, password_hash, email, real_name, status, created_at)
		VALUES (gen_random_uuid(), $1, $2, $3, $4, 1, NOW())
		ON CONFLICT (username) DO NOTHING
		RETURNING id`,
		username, string(hash), "admin@example.com", "系统管理员").Scan(&userID)
	if err != nil {
		if err != sql.ErrNoRows {
			return err
		}
		err = db.QueryRow(`SELECT id FROM users WHERE username = $1`, username).Scan(&userID)
		if err != nil {
			return err
		}
	}

	// 关联用户和角色
	_, err = db.Exec(`
		INSERT INTO user_roles (user_id, role_id, created_at)
		VALUES ($1, $2, NOW())
		ON CONFLICT (user_id, role_id) DO NOTHING`,
		userID, adminRoleID)

	// 初始化清理策略
	_, err = db.Exec(`
		INSERT INTO cleanup_policy (id, auto_cleanup_enabled, recording_retention_days, 
			screenshot_retention_days, log_retention_days, disk_usage_threshold_percent, 
			cleanup_interval_minutes, updated_at)
		VALUES (gen_random_uuid(), TRUE, 5, 5, 3, 70, 60, NOW())
		ON CONFLICT (id) DO NOTHING`)

	return err
}

// mergeRolePermissions 将缺失的权限合并进已有角色（不删除自定义权限）
func mergeRolePermissions(db *sql.DB, roleName string, required []string) error {
	var permissionsJSON string
	err := db.QueryRow(`SELECT permissions FROM roles WHERE name = $1`, roleName).Scan(&permissionsJSON)
	if err != nil {
		return err
	}

	var existing []string
	if permissionsJSON != "" && permissionsJSON != "null" {
		if err := json.Unmarshal([]byte(permissionsJSON), &existing); err != nil {
			return err
		}
	}

	seen := make(map[string]struct{}, len(existing)+len(required))
	for _, p := range existing {
		seen[p] = struct{}{}
	}
	merged := append([]string(nil), existing...)
	for _, p := range required {
		if _, ok := seen[p]; ok {
			continue
		}
		seen[p] = struct{}{}
		merged = append(merged, p)
	}

	if len(merged) == len(existing) {
		return nil
	}

	out, err := json.Marshal(merged)
	if err != nil {
		return err
	}
	_, err = db.Exec(`UPDATE roles SET permissions = $1, updated_at = NOW() WHERE name = $2`, string(out), roleName)
	return err
}

// syncRolePermissionsExact 将角色权限对齐为指定列表（用于默认角色模板）
func syncRolePermissionsExact(db *sql.DB, roleName string, permissions []string) error {
	out, err := json.Marshal(permissions)
	if err != nil {
		return err
	}
	_, err = db.Exec(`UPDATE roles SET permissions = $1, updated_at = NOW() WHERE name = $2`, string(out), roleName)
	return err
}

// retireLegacyEmployeeRole 迁移并删除已废弃的「员工」角色
func retireLegacyEmployeeRole(db *sql.DB) error {
	var employeeRoleID string
	err := db.QueryRow(`SELECT id FROM roles WHERE name = '员工'`).Scan(&employeeRoleID)
	if err == sql.ErrNoRows {
		return nil
	}
	if err != nil {
		return err
	}

	var viewerRoleID string
	if err := db.QueryRow(`SELECT id FROM roles WHERE name = '查看员'`).Scan(&viewerRoleID); err != nil {
		return err
	}

	if _, err = db.Exec(`
		INSERT INTO user_roles (user_id, role_id, created_at)
		SELECT ur.user_id, $1, NOW()
		FROM user_roles ur
		WHERE ur.role_id = $2
		ON CONFLICT (user_id, role_id) DO NOTHING`, viewerRoleID, employeeRoleID); err != nil {
		return err
	}
	if _, err = db.Exec(`DELETE FROM user_roles WHERE role_id = $1`, employeeRoleID); err != nil {
		return err
	}
	_, err = db.Exec(`DELETE FROM roles WHERE id = $1`, employeeRoleID)
	return err
}

func NewRedis() *redis.Client {
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "localhost:6379"
	}
	password := os.Getenv("REDIS_PASSWORD")
	db := 0
	if dbStr := os.Getenv("REDIS_DB"); dbStr != "" {
		db, _ = strconv.Atoi(dbStr)
	}
	return redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password,
		DB:       db,
	})
}

// ========== MinIO客户端 ==========

type MinIOClient struct {
	bucket    string
	enabled   bool
	rootDir   string
	endpoint  string
	accessKey string
	secretKey string
	useSSL    bool
	client    *minio.Client
}

func NewMinIO() *MinIOClient {
	bucket := os.Getenv("MINIO_BUCKET")
	if bucket == "" {
		bucket = "recordings"
	}
	rootDir := os.Getenv("UPLOADS_DIR")
	if rootDir == "" {
		rootDir = filepath.Join(".", "uploads")
	}
	absRoot, err := filepath.Abs(rootDir)
	if err == nil {
		rootDir = absRoot
	}
	m := &MinIOClient{
		bucket:    bucket,
		enabled:   true,
		rootDir:   rootDir,
		endpoint:  strings.TrimSpace(os.Getenv("MINIO_ENDPOINT")),
		accessKey: strings.TrimSpace(os.Getenv("MINIO_ACCESS_KEY")),
		secretKey: strings.TrimSpace(os.Getenv("MINIO_SECRET_KEY")),
		useSSL:    os.Getenv("MINIO_USE_SSL") == "true",
	}
	if m.endpoint != "" && m.accessKey != "" && m.secretKey != "" {
		client, err := minio.New(m.endpoint, &minio.Options{
			Creds:  credentials.NewStaticV4(m.accessKey, m.secretKey, ""),
			Secure: m.useSSL,
		})
		if err != nil {
			log.Printf("Warning: failed to initialize MinIO client: %v", err)
		} else {
			m.client = client
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			exists, bucketErr := client.BucketExists(ctx, m.bucket)
			cancel()
			if bucketErr != nil {
				log.Printf("Warning: failed to check MinIO bucket %q: %v", m.bucket, bucketErr)
			} else if !exists {
				ctx, cancel = context.WithTimeout(context.Background(), 10*time.Second)
				if err := client.MakeBucket(ctx, m.bucket, minio.MakeBucketOptions{}); err != nil {
					log.Printf("Warning: failed to create MinIO bucket %q: %v", m.bucket, err)
				}
				cancel()
			}
		}
	}
	return m
}

func (m *MinIOClient) usesRemote() bool {
	return m != nil && m.client != nil
}

func (m *MinIOClient) cleanObjectName(objectName string) (string, error) {
	cleanObjectName := strings.TrimPrefix(filepath.ToSlash(objectName), "/")
	if cleanObjectName == "" {
		return "", fmt.Errorf("object name is required")
	}
	return cleanObjectName, nil
}

func (m *MinIOClient) Save(ctx context.Context, objectName string, data []byte) error {
	if m == nil || !m.enabled {
		return nil
	}
	cleanObjectName, err := m.cleanObjectName(objectName)
	if err != nil {
		return err
	}
	if m.usesRemote() {
		_, err := m.client.PutObject(ctx, m.bucket, cleanObjectName, bytes.NewReader(data), int64(len(data)), minio.PutObjectOptions{
			ContentType: "application/octet-stream",
		})
		if err != nil {
			return fmt.Errorf("failed to upload to minio: %w", err)
		}
		return nil
	}
	if err := os.MkdirAll(m.rootDir, 0o755); err != nil {
		return err
	}
	outputPath := filepath.Join(m.rootDir, filepath.FromSlash(cleanObjectName))
	if err := os.MkdirAll(filepath.Dir(outputPath), 0o755); err != nil {
		return err
	}
	if err := os.WriteFile(outputPath, data, 0o644); err != nil {
		return err
	}
	return nil
}

func (m *MinIOClient) GetURL(ctx context.Context, objectName string) (string, error) {
	cleanObjectName, err := m.cleanObjectName(objectName)
	if err != nil {
		return "", err
	}
	if m.usesRemote() {
		presigned, err := m.client.PresignedGetObject(ctx, m.bucket, cleanObjectName, time.Hour, nil)
		if err != nil {
			return "", fmt.Errorf("failed to presign minio object: %w", err)
		}
		return presigned.String(), nil
	}
	return "/uploads/" + cleanObjectName, nil
}

func (m *MinIOClient) SaveStream(ctx context.Context, objectName string, reader io.Reader) error {
	if m == nil || !m.enabled {
		return nil
	}

	cleanObjectName, err := m.cleanObjectName(objectName)
	if err != nil {
		return err
	}

	if m.usesRemote() {
		_, err := m.client.PutObject(ctx, m.bucket, cleanObjectName, reader, -1, minio.PutObjectOptions{
			ContentType: "application/octet-stream",
		})
		if err != nil {
			return fmt.Errorf("failed to upload to minio: %w", err)
		}
		return nil
	}

	filePath := filepath.Join(m.rootDir, filepath.FromSlash(cleanObjectName))
	if err := os.MkdirAll(filepath.Dir(filePath), 0755); err != nil {
		return fmt.Errorf("failed to create directory: %w", err)
	}

	out, err := os.Create(filePath)
	if err != nil {
		return fmt.Errorf("failed to create file: %w", err)
	}
	defer out.Close()

	if _, err = io.Copy(out, reader); err != nil {
		return fmt.Errorf("failed to write file: %w", err)
	}

	return nil
}

// RemoveObject 删除 MinIO 对象或本地镜像文件
func (m *MinIOClient) RemoveObject(ctx context.Context, objectName string) error {
	if m == nil || !m.enabled {
		return nil
	}

	cleanObjectName, err := m.cleanObjectName(objectName)
	if err != nil {
		return err
	}

	if m.usesRemote() {
		return m.client.RemoveObject(ctx, m.bucket, cleanObjectName, minio.RemoveObjectOptions{})
	}

	filePath := filepath.Join(m.rootDir, filepath.FromSlash(cleanObjectName))
	if err := os.Remove(filePath); err != nil && !os.IsNotExist(err) {
		return err
	}
	return nil
}

// ========== DeviceRepository PostgreSQL实现 ==========

type DeviceRepository struct {
	db *sql.DB
}

// DeviceListOptions 设备列表查询参数
type DeviceListOptions struct {
	Page           int    // 页码
	PageSize       int    // 每页数量
	Status         string // 审核状态: pending, approved
	EmployeeSearch string // 员工搜索（姓名/工号/职位）
	DeviceStatus   string // 设备状态: pending, approved_online, approved_offline
	Keyword        string // 设备名称搜索
}

func NewDeviceRepository(db *sql.DB) *DeviceRepository {
	return &DeviceRepository{db: db}
}

// List 获取设备列表（支持多条件筛选和分页）
func (r *DeviceRepository) List(ctx context.Context, opts DeviceListOptions) ([]models.Device, int, error) {
    pageNum := opts.Page
    if pageNum < 1 {
        pageNum = 1
    }
    pageSizeNum := opts.PageSize
    if pageSizeNum < 1 {
        pageSizeNum = 20
    }
    if pageSizeNum > 100 {
        pageSizeNum = 100
    }

    offset := (pageNum - 1) * pageSizeNum
    args := []interface{}{}
    conditions := []string{}
    argIdx := 1

    // 1. 审核状态筛选
    if opts.Status != "" {
        conditions = append(conditions, fmt.Sprintf("d.status = $%d", argIdx))
        args = append(args, opts.Status)
        argIdx++
    }

    // 2. 员工搜索（姓名、工号、职位）
    if opts.EmployeeSearch != "" {
        searchPattern := "%" + opts.EmployeeSearch + "%"
        conditions = append(conditions, fmt.Sprintf("(d.employee_name ILIKE $%d OR d.employee_number ILIKE $%d OR d.position ILIKE $%d)", argIdx, argIdx+1, argIdx+2))
        args = append(args, searchPattern, searchPattern, searchPattern)
        argIdx += 3
    }

    // 3. 设备名称搜索
    if opts.Keyword != "" {
        searchPattern := "%" + opts.Keyword + "%"
        conditions = append(conditions, fmt.Sprintf("d.hostname ILIKE $%d", argIdx))
        args = append(args, searchPattern)
        argIdx++
    }

    // 4. 设备状态筛选（pending / approved_online / approved_offline）
    if opts.DeviceStatus != "" {
        switch opts.DeviceStatus {
        case "pending":
            conditions = append(conditions, fmt.Sprintf("d.status = $%d", argIdx))
            args = append(args, "pending")
            argIdx++
        case "rejected":
            conditions = append(conditions, fmt.Sprintf("d.status = $%d", argIdx))
            args = append(args, "rejected")
            argIdx++
        case "approved_online":
            conditions = append(conditions, "d.status = 'approved' AND (d.last_seen_at IS NOT NULL AND d.last_seen_at > NOW() - INTERVAL '3 minutes')")
        case "approved_offline":
            conditions = append(conditions, "d.status = 'approved' AND (d.last_seen_at IS NULL OR d.last_seen_at <= NOW() - INTERVAL '3 minutes')")
        }
    }

    whereClause := ""
    if len(conditions) > 0 {
        whereClause = " WHERE " + strings.Join(conditions, " AND ")
    }

    // 查询总数
    countQuery := "SELECT COUNT(*) FROM devices d" + whereClause
    var total int
    if err := r.db.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
        return nil, 0, err
    }

    // 查询数据
    dataQuery := `SELECT d.id, d.employee_id, d.employee_name, d.employee_number, d.position, d.device_fingerprint, 
                         d.hostname, d.os_version, d.agent_version, d.status, d.bound_at, d.last_seen_at, d.created_at,
                         COALESCE(
                           (SELECT ic.code FROM device_invite_codes ic
                            WHERE ic.used_by_device_id = d.id
                            ORDER BY ic.used_at DESC NULLS LAST, ic.created_at DESC
                            LIMIT 1),
                           (SELECT ic.code FROM device_invite_codes ic
                            WHERE ic.employee_id = COALESCE(d.employee_uuid, e.id)
                              AND ic.used_at IS NULL AND ic.revoked_at IS NULL AND ic.expires_at > NOW()
                            ORDER BY ic.created_at DESC
                            LIMIT 1)
                         ) AS active_invite_code
                  FROM devices d
                  LEFT JOIN employees e ON (
                      (d.employee_uuid IS NOT NULL AND e.id = d.employee_uuid)
                      OR (d.employee_uuid IS NULL AND e.employee_id IS NOT NULL AND e.employee_id = d.employee_number)
                  )` + whereClause + `
                  ORDER BY d.created_at DESC
                  LIMIT $` + strconv.Itoa(argIdx) + ` OFFSET $` + strconv.Itoa(argIdx+1)

    args = append(args, pageSizeNum, offset)

    rows, err := r.db.QueryContext(ctx, dataQuery, args...)
    if err != nil {
        return nil, 0, err
    }
    defer rows.Close()

    var devices []models.Device
    for rows.Next() {
        var d models.Device
        var boundAt, lastSeenAt sql.NullTime
        var employeeID, employeeName, employeeNumber, position, activeInvite sql.NullString

        err := rows.Scan(
            &d.ID,
            &employeeID, &employeeName, &employeeNumber, &position,
            &d.DeviceFingerprint, &d.Hostname,
            &d.OSVersion, &d.AgentVersion,
            &d.Status, &boundAt, &lastSeenAt, &d.CreatedAt, &activeInvite)
        if err != nil {
            return nil, 0, err
        }

        // 处理 NULL 值
        if employeeID.Valid {
            d.EmployeeID = employeeID.String
        }
        if employeeName.Valid {
            d.EmployeeName = employeeName.String
        }
        if employeeNumber.Valid {
            d.EmployeeNumber = employeeNumber.String
        }
        if position.Valid {
            d.Position = position.String
        }
        if boundAt.Valid {
            d.BoundAt = &boundAt.Time
        }
        if lastSeenAt.Valid {
            d.LastSeenAt = &lastSeenAt.Time
        }
        if activeInvite.Valid {
            d.ActiveInviteCode = activeInvite.String
        }
        devices = append(devices, d)
    }

    return devices, total, nil
}

// ✅ 修复：使用 sql.NullString 处理 NULL 字段
func (r *DeviceRepository) Get(ctx context.Context, id uuid.UUID) (*models.Device, error) {
	var d models.Device
	var boundAt, lastSeenAt sql.NullTime
	var employeeID, employeeName, employeeNumber, position sql.NullString

    query := `SELECT id, employee_id, employee_name, employee_number, position, device_fingerprint, hostname, os_version, agent_version, status, bound_at, last_seen_at, created_at, device_secret
              FROM devices WHERE id = $1`
    var deviceSecret sql.NullString
    err := r.db.QueryRowContext(ctx, query, id).Scan(
        &d.ID,
        &employeeID, &employeeName, &employeeNumber, &position,
        &d.DeviceFingerprint, &d.Hostname,
        &d.OSVersion, &d.AgentVersion,
        &d.Status, &boundAt, &lastSeenAt, &d.CreatedAt, &deviceSecret)
	if err == sql.ErrNoRows {
		return nil, err
	}
	if err != nil {
		return nil, err
	}

	// 处理 NULL 值
	if employeeID.Valid {
		d.EmployeeID = employeeID.String
	}
	if employeeName.Valid {
		d.EmployeeName = employeeName.String
	}
	if employeeNumber.Valid {
		d.EmployeeNumber = employeeNumber.String
	}
	if position.Valid {
		d.Position = position.String
	}
	if boundAt.Valid {
		d.BoundAt = &boundAt.Time
	}
	if lastSeenAt.Valid {
		d.LastSeenAt = &lastSeenAt.Time
	}
    if deviceSecret.Valid {
        d.DeviceSecret = deviceSecret.String
    }
	return &d, nil
}

// ✅ 修复：使用 sql.NullString 处理 NULL 字段
func (r *DeviceRepository) GetByDeviceId(ctx context.Context, deviceID string) (*models.Device, error) {
	var d models.Device
	var boundAt, lastSeenAt sql.NullTime
	var employeeID, employeeName, employeeNumber, position sql.NullString

    query := `SELECT id, employee_id, employee_name, employee_number, position, device_fingerprint, hostname, os_version, agent_version, status, bound_at, last_seen_at, created_at, device_secret
              FROM devices WHERE device_fingerprint = $1`
    var deviceSecret sql.NullString
    err := r.db.QueryRowContext(ctx, query, deviceID).Scan(
        &d.ID,
        &employeeID, &employeeName, &employeeNumber, &position,
        &d.DeviceFingerprint, &d.Hostname,
        &d.OSVersion, &d.AgentVersion,
        &d.Status, &boundAt, &lastSeenAt, &d.CreatedAt, &deviceSecret)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	// 处理 NULL 值
	if employeeID.Valid {
		d.EmployeeID = employeeID.String
	}
	if employeeName.Valid {
		d.EmployeeName = employeeName.String
	}
	if employeeNumber.Valid {
		d.EmployeeNumber = employeeNumber.String
	}
	if position.Valid {
		d.Position = position.String
	}
	if boundAt.Valid {
		d.BoundAt = &boundAt.Time
	}
	if lastSeenAt.Valid {
		d.LastSeenAt = &lastSeenAt.Time
	}
    if deviceSecret.Valid {
        d.DeviceSecret = deviceSecret.String
    }
	return &d, nil
}

func (r *DeviceRepository) Create(ctx context.Context, device *models.Device) (uuid.UUID, error) {
	if device.ID == uuid.Nil {
		device.ID = uuid.New()
	}
	if device.CreatedAt.IsZero() {
		device.CreatedAt = models.UTCNow()
	}

    query := `
        INSERT INTO devices (id, employee_id, employee_name, employee_number, position, device_fingerprint, hostname, os_version, agent_version, status, bound_at, created_at, device_secret)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        ON CONFLICT (device_fingerprint) DO UPDATE SET
            hostname = EXCLUDED.hostname,
            os_version = EXCLUDED.os_version,
            last_seen_at = NOW(),
            device_secret = COALESCE(NULLIF(devices.device_secret, ''), EXCLUDED.device_secret)
        RETURNING id`
    err := r.db.QueryRowContext(ctx, query,
        device.ID,
        nullString(device.EmployeeID),
        nullString(device.EmployeeName),
        nullString(device.EmployeeNumber),
        nullString(device.Position),
        device.DeviceFingerprint,
        device.Hostname,
        device.OSVersion,
        device.AgentVersion,
        device.Status,
        nullTime(device.BoundAt),
        device.CreatedAt,
        nullString(device.DeviceSecret),
    ).Scan(&device.ID)
	if err != nil {
		return uuid.Nil, err
	}
	return device.ID, nil
}

// UpdateSecret updates device_secret for a device
func (r *DeviceRepository) UpdateSecret(ctx context.Context, id uuid.UUID, secret string) error {
    query := `UPDATE devices SET device_secret = $1 WHERE id = $2`
    _, err := r.db.ExecContext(ctx, query, secret, id)
    return err
}

func (r *DeviceRepository) UpdateInfo(ctx context.Context, id uuid.UUID, hostname, osVersion, agentVersion string) error {
	query := `UPDATE devices SET hostname = $1, os_version = $2, agent_version = $3, last_seen_at = NOW() WHERE id = $4`
	_, err := r.db.ExecContext(ctx, query, hostname, osVersion, agentVersion, id)
	return err
}

func (r *DeviceRepository) Bind(ctx context.Context, id uuid.UUID, employeeID, employeeName, employeeNumber string) error {
    // ✅ 删除 status = 'online'，只更新员工信息
    query := `UPDATE devices SET employee_id = $1, employee_name = $2, employee_number = $3, bound_at = $4 WHERE id = $5`
    _, err := r.db.ExecContext(ctx, query, employeeID, nullString(employeeName), nullString(employeeNumber), models.UTCNow(), id)
    return err
}

func (r *DeviceRepository) UpdateEmployeeInfo(ctx context.Context, id uuid.UUID, employeeID, employeeName, employeeNumber, position string) error {
	query := `UPDATE devices SET employee_id = $1, employee_name = $2, employee_number = $3, position = $4 WHERE id = $5`
	_, err := r.db.ExecContext(ctx, query, nullString(employeeID), nullString(employeeName), nullString(employeeNumber), nullString(position), id)
	return err
}

func (r *DeviceRepository) Unbind(ctx context.Context, id uuid.UUID) error {
    query := `UPDATE devices SET employee_id = NULL, employee_name = NULL, employee_number = NULL, position = NULL, bound_at = NULL, employee_uuid = NULL, user_id = NULL WHERE id = $1`
    _, err := r.db.ExecContext(ctx, query, id)
    return err
}

func (r *DeviceRepository) UpdateStatus(ctx context.Context, id uuid.UUID, status string) error {
	query := `UPDATE devices SET status = $1 WHERE id = $2`
	_, err := r.db.ExecContext(ctx, query, status, id)
	return err
}

func (r *DeviceRepository) GetOnlineStats(ctx context.Context) (int, int, error) {
    // ✅ 使用 last_seen_at 判断在线状态（3分钟内活跃为在线）
    var online, offline int
    err := r.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM devices WHERE last_seen_at > NOW() - INTERVAL '3 minutes'`).Scan(&online)
    if err != nil {
        return 0, 0, err
    }
    err = r.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM devices WHERE last_seen_at IS NULL OR last_seen_at <= NOW() - INTERVAL '3 minutes'`).Scan(&offline)
    if err != nil {
        return 0, 0, err
    }
    return online, offline, nil
}

func (r *DeviceRepository) UpdateLastSeen(ctx context.Context, id uuid.UUID) error {
	_, err := r.db.ExecContext(ctx, `UPDATE devices SET last_seen_at = NOW() WHERE id = $1`, id)
	return err
}

func (r *DeviceRepository) SetForceOfflined(ctx context.Context, id uuid.UUID) error {
	_, err := r.db.ExecContext(ctx,
		`UPDATE devices SET force_offlined_at = NOW(), updated_at = NOW() WHERE id = $1`, id)
	return err
}

func (r *DeviceRepository) ClearForceOfflined(ctx context.Context, deviceID string) error {
	id, err := uuid.Parse(deviceID)
	if err != nil {
		return err
	}
	_, err = r.db.ExecContext(ctx,
		`UPDATE devices SET force_offlined_at = NULL, updated_at = NOW() WHERE id = $1`, id)
	return err
}

func (r *DeviceRepository) IsForceOfflined(ctx context.Context, deviceID string) bool {
	if deviceID == "" {
		return false
	}
	id, err := uuid.Parse(deviceID)
	if err != nil {
		return false
	}
	var ts sql.NullTime
	err = r.db.QueryRowContext(ctx, `SELECT force_offlined_at FROM devices WHERE id = $1`, id).Scan(&ts)
	return err == nil && ts.Valid
}

// ========== RecordingRepository PostgreSQL实现 ==========

type RecordingRepository struct {
	db    *sql.DB
	minio *MinIOClient
}

func NewRecordingRepository(db *sql.DB, minio *MinIOClient) *RecordingRepository {
	return &RecordingRepository{db: db, minio: minio}
}

// appendRecordingTimeOverlapFilter 按时间范围重叠筛选录屏（而非完全包含）
func appendRecordingTimeOverlapFilter(conditions *[]string, args *[]interface{}, argIdx *int, startTime, endTime string) error {
	var startObj, endObj time.Time
	hasStart := startTime != ""
	hasEnd := endTime != ""

	if hasStart {
		parsed, err := models.ParseFlexibleUTC(startTime)
		if err != nil {
			return fmt.Errorf("invalid startTime format: %w", err)
		}
		startObj = parsed
	}
	if hasEnd {
		parsed, err := models.ParseFlexibleUTC(endTime)
		if err != nil {
			return fmt.Errorf("invalid endTime format: %w", err)
		}
		endObj = parsed
	}

	switch {
	case hasStart && hasEnd:
		*conditions = append(*conditions, fmt.Sprintf("start_time <= $%d AND end_time >= $%d", *argIdx, *argIdx+1))
		*args = append(*args, endObj, startObj)
		*argIdx += 2
	case hasStart:
		*conditions = append(*conditions, fmt.Sprintf("end_time >= $%d", *argIdx))
		*args = append(*args, startObj)
		*argIdx++
	case hasEnd:
		*conditions = append(*conditions, fmt.Sprintf("start_time <= $%d", *argIdx))
		*args = append(*args, endObj)
		*argIdx++
	}
	return nil
}

// List 获取录制列表（分页）
func (r *RecordingRepository) List(ctx context.Context, deviceID, startTime, endTime, page, pageSize string) ([]models.Recording, int, error) {
    pageNum := 1
    pageSizeNum := 20
    if page != "" {
        if v, err := strconv.Atoi(page); err == nil && v > 0 {
            pageNum = v
        }
    }
    if pageSize != "" {
        if v, err := strconv.Atoi(pageSize); err == nil && v > 0 {
            pageSizeNum = v
        }
    }

    offset := (pageNum - 1) * pageSizeNum
    args := []interface{}{}
    conditions := []string{}
    argIdx := 1

    if deviceID != "" {
        conditions = append(conditions, fmt.Sprintf("device_id = $%d", argIdx))
        args = append(args, deviceID)
        argIdx++
    }

    if err := appendRecordingTimeOverlapFilter(&conditions, &args, &argIdx, startTime, endTime); err != nil {
        return nil, 0, err
    }

    whereClause := ""
    if len(conditions) > 0 {
        whereClause = " WHERE " + strings.Join(conditions, " AND ")
    }

    // 查询总数
    countQuery := "SELECT COUNT(*) FROM recordings" + whereClause
    var total int
    if err := r.db.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
        return nil, 0, fmt.Errorf("count query failed: %w", err)
    }

    // 查询数据
    dataQuery := "SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, duration, created_at" +
        " FROM recordings" + whereClause +
        " ORDER BY start_time DESC" +
        " LIMIT $" + strconv.Itoa(argIdx) + " OFFSET $" + strconv.Itoa(argIdx+1)

    args = append(args, pageSizeNum, offset)

    rows, err := r.db.QueryContext(ctx, dataQuery, args...)
    if err != nil {
        return nil, 0, fmt.Errorf("query failed: %w", err)
    }
    defer rows.Close()

    var recordings []models.Recording
    for rows.Next() {
        var rec models.Recording
        var deviceUUID uuid.UUID
        var duration sql.NullInt64
        if err := rows.Scan(&rec.ID, &deviceUUID, &rec.StartTime, &rec.EndTime, &rec.FilePath, &rec.FileSize, &rec.SHA256, &rec.Uploaded, &duration, &rec.CreatedAt); err != nil {
            return nil, 0, fmt.Errorf("scan failed: %w", err)
        }
        rec.DeviceID = deviceUUID
        if duration.Valid {
            rec.Duration = int(duration.Int64)
        }
        recordings = append(recordings, rec)
    }

    return recordings, total, nil
}

func (r *RecordingRepository) GetPlayURL(ctx context.Context, id uuid.UUID) (string, error) {
	var filePath string
	query := `SELECT file_path FROM recordings WHERE id = $1`
	err := r.db.QueryRowContext(ctx, query, id).Scan(&filePath)
	if err != nil {
		return "", err
	}
	if r.minio != nil {
		return r.minio.GetURL(ctx, filePath)
	}
	return "/uploads/" + strings.TrimPrefix(filepath.ToSlash(filePath), "/"), nil
}

func (r *RecordingRepository) GetDownloadURL(ctx context.Context, id uuid.UUID) (string, error) {
	return r.GetPlayURL(ctx, id)
}

// removeRecordingFile 删除录制对应的物理文件（兼容 /uploads/ 前缀与相对路径）
func (r *RecordingRepository) removeRecordingFile(filePath string) error {
	if filePath == "" {
		return nil
	}

	clean := strings.TrimPrefix(filepath.ToSlash(filePath), "/")
	clean = strings.TrimPrefix(clean, "uploads/")
	if clean == "" {
		return nil
	}

	fullPath := filepath.Join(r.getUploadsDir(), filepath.FromSlash(clean))
	if err := os.Remove(fullPath); err != nil && !os.IsNotExist(err) {
		return err
	}
	return nil
}

// Delete 删除单个录制（同时删除物理文件）
func (r *RecordingRepository) Delete(ctx context.Context, id uuid.UUID) error {
	var filePath string
	err := r.db.QueryRowContext(ctx, `SELECT file_path FROM recordings WHERE id = $1`, id).Scan(&filePath)
	if err != nil {
		return err
	}

	if err := r.removeRecordingFile(filePath); err != nil {
		log.Printf("Failed to delete recording file %s: %v", filePath, err)
	}

	_, err = r.db.ExecContext(ctx, `DELETE FROM recordings WHERE id = $1`, id)
	return err
}

func (r *RecordingRepository) Add(ctx context.Context, recording *models.Recording) error {
	if recording.ID == uuid.Nil {
		recording.ID = uuid.New()
	}
	if recording.CreatedAt.IsZero() {
		recording.CreatedAt = models.UTCNow()
	}
	query := `INSERT INTO recordings (id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, duration, created_at)
              VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`
	var durationParam interface{}
	if recording.Duration > 0 {
		durationParam = recording.Duration
	}
	_, err := r.db.ExecContext(ctx, query, recording.ID, recording.DeviceID, recording.StartTime, recording.EndTime,
		recording.FilePath, recording.FileSize, recording.SHA256, recording.Uploaded, durationParam, recording.CreatedAt)
	return err
}

// GetByID 根据ID获取录制详情
func (r *RecordingRepository) GetByID(ctx context.Context, id uuid.UUID) (*models.Recording, error) {
	var rec models.Recording
	var deviceID uuid.UUID

	query := `SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, created_at
	          FROM recordings WHERE id = $1`
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&rec.ID, &deviceID, &rec.StartTime, &rec.EndTime, &rec.FilePath, &rec.FileSize, &rec.SHA256, &rec.Uploaded, &rec.CreatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, err
		}
		return nil, err
	}
	rec.DeviceID = deviceID
	return &rec, nil
}

// ExistsByFilePathPattern 检查是否已有以 uploadId 为文件名的存储记录
func (r *RecordingRepository) ExistsByFilePathPattern(ctx context.Context, pattern string) (bool, error) {
	var exists bool
	err := r.db.QueryRowContext(ctx,
		`SELECT EXISTS(SELECT 1 FROM recordings WHERE file_path LIKE $1)`,
		pattern).Scan(&exists)
	return exists, err
}

// GetFilePath 获取文件路径
func (r *RecordingRepository) getUploadsDir() string {
	uploadsDir := os.Getenv("UPLOADS_DIR")
	if uploadsDir == "" {
		uploadsDir = "./uploads"
	}
	return uploadsDir
}

// usesRemoteObjectStorage 仅当 MinIO 客户端可用时才走对象存储
func (r *RecordingRepository) usesRemoteObjectStorage() bool {
	return r.minio != nil && r.minio.usesRemote()
}

// GetFilePath 返回录制文件的本地绝对路径（远程 MinIO 场景返回 ErrRecordingRemoteStorage）
func (r *RecordingRepository) GetFilePath(ctx context.Context, id uuid.UUID) (string, error) {
	if r.usesRemoteObjectStorage() {
		return "", ErrRecordingRemoteStorage
	}

	var filePath string
	query := `SELECT file_path FROM recordings WHERE id = $1`
	err := r.db.QueryRowContext(ctx, query, id).Scan(&filePath)
	if err != nil {
		return "", err
	}
	if filePath == "" {
		return "", fmt.Errorf("recording file path is empty")
	}

	fullPath := filepath.Join(r.getUploadsDir(), filePath)
	if _, err := os.Stat(fullPath); err != nil {
		if os.IsNotExist(err) {
			return "", fmt.Errorf("recording file not found on disk")
		}
		return "", err
	}
	return fullPath, nil
}

// BatchDelete 批量删除录制（同时删除物理文件）
func (r *RecordingRepository) BatchDelete(ctx context.Context, ids []uuid.UUID) (int64, error) {
    if len(ids) == 0 {
        return 0, nil
    }

    // 1. 先获取所有文件的路径
    placeholders := make([]string, len(ids))
    args := make([]interface{}, len(ids))
    for i, id := range ids {
        placeholders[i] = "$" + strconv.Itoa(i+1)
        args[i] = id
    }

    rows, err := r.db.QueryContext(ctx, `SELECT id, file_path FROM recordings WHERE id IN (`+strings.Join(placeholders, ",")+`)`, args...)
    if err != nil {
        return 0, err
    }
    defer rows.Close()

    var filePaths []string
    var idList []uuid.UUID
    for rows.Next() {
        var id uuid.UUID
        var filePath string
        if err := rows.Scan(&id, &filePath); err != nil {
            continue
        }
        idList = append(idList, id)
        if filePath != "" {
            filePaths = append(filePaths, filePath)
        }
    }

    if len(idList) == 0 {
        return 0, nil
    }

    // 2. 删除物理文件
    for _, filePath := range filePaths {
        if err := r.removeRecordingFile(filePath); err != nil {
            log.Printf("Failed to delete recording file %s: %v", filePath, err)
        }
    }

    // 3. 删除数据库记录
    query := `DELETE FROM recordings WHERE id IN (` + strings.Join(placeholders, ",") + `)`
    result, err := r.db.ExecContext(ctx, query, args...)
    if err != nil {
        return 0, err
    }
    return result.RowsAffected()
}

// GetStats 获取录制统计
func (r *RecordingRepository) GetStats(ctx context.Context, deviceID, startTime, endTime string) (map[string]interface{}, error) {
	stats := make(map[string]interface{})

	args := []interface{}{}
	where := "1=1"
	argIdx := 1

	if deviceID != "" {
		where += " AND device_id = $" + strconv.Itoa(argIdx)
		args = append(args, deviceID)
		argIdx++
	}
	timeConditions := []string{}
	if err := appendRecordingTimeOverlapFilter(&timeConditions, &args, &argIdx, startTime, endTime); err != nil {
		return nil, err
	}
	for _, cond := range timeConditions {
		where += " AND " + cond
	}

	// 总数
	var total int
	err := r.db.QueryRowContext(ctx, "SELECT COUNT(*) FROM recordings WHERE "+where, args...).Scan(&total)
	if err != nil {
		return nil, err
	}
	stats["total"] = total

	// 总大小
	var totalSize int64
	err = r.db.QueryRowContext(ctx, "SELECT COALESCE(SUM(file_size), 0) FROM recordings WHERE "+where, args...).Scan(&totalSize)
	if err != nil {
		return nil, err
	}
	stats["totalSize"] = totalSize

	// 平均大小
	var avgSize float64
	err = r.db.QueryRowContext(ctx, "SELECT COALESCE(AVG(file_size), 0) FROM recordings WHERE "+where, args...).Scan(&avgSize)
	if err != nil {
		return nil, err
	}
	stats["avgSize"] = avgSize

	// 今日新增
	today := time.Now().UTC().Truncate(24 * time.Hour)
	var todayCount int
	todayQuery := "SELECT COUNT(*) FROM recordings WHERE " + where + " AND created_at >= $" + strconv.Itoa(argIdx)
	err = r.db.QueryRowContext(ctx, todayQuery, append(args, today)...).Scan(&todayCount)
	if err != nil {
		todayCount = 0
	}
	stats["todayCount"] = todayCount

	return stats, nil
}

// ListByDevice 获取指定设备的所有录制
func (r *RecordingRepository) ListByDevice(ctx context.Context, deviceID, startTime, endTime string, limit int) ([]models.Recording, error) {
    args := []interface{}{}
    conditions := []string{}
    argIdx := 1

    if deviceID != "" {
        conditions = append(conditions, fmt.Sprintf("device_id = $%d", argIdx))
        args = append(args, deviceID)
        argIdx++
    }

    if err := appendRecordingTimeOverlapFilter(&conditions, &args, &argIdx, startTime, endTime); err != nil {
        return nil, err
    }

    whereClause := ""
    if len(conditions) > 0 {
        whereClause = " WHERE " + strings.Join(conditions, " AND ")
    }

    query := "SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, duration, created_at" +
        " FROM recordings" + whereClause +
        " ORDER BY start_time DESC LIMIT $" + strconv.Itoa(argIdx)

    args = append(args, limit)

    rows, err := r.db.QueryContext(ctx, query, args...)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    var recordings []models.Recording
    for rows.Next() {
        var rec models.Recording
        var deviceUUID uuid.UUID
        var duration sql.NullInt64
        if err := rows.Scan(&rec.ID, &deviceUUID, &rec.StartTime, &rec.EndTime, &rec.FilePath, &rec.FileSize, &rec.SHA256, &rec.Uploaded, &duration, &rec.CreatedAt); err != nil {
            return nil, err
        }
        rec.DeviceID = deviceUUID
        if duration.Valid {
            rec.Duration = int(duration.Int64)
        }
        recordings = append(recordings, rec)
    }
    return recordings, nil
}

// GetPlaybackInfo 获取播放信息
func (r *RecordingRepository) GetPlaybackInfo(ctx context.Context, id uuid.UUID) (map[string]interface{}, error) {
	var rec models.Recording
	var deviceID uuid.UUID

	query := `SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, created_at
	          FROM recordings WHERE id = $1`
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&rec.ID, &deviceID, &rec.StartTime, &rec.EndTime, &rec.FilePath, &rec.FileSize, &rec.SHA256, &rec.Uploaded, &rec.CreatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, err
		}
		return nil, err
	}

	info := map[string]interface{}{
		"id":         rec.ID.String(),
		"deviceId":   deviceID.String(),
		"startTime":  rec.StartTime,
		"endTime":    rec.EndTime,
		"duration":   rec.EndTime.Sub(rec.StartTime).Seconds(),
		"fileSize":   rec.FileSize,
		"fileSizeMB": float64(rec.FileSize) / 1024 / 1024,
		"uploaded":   rec.Uploaded,
	}
	return info, nil
}

// ExportCSV 导出为CSV
func (r *RecordingRepository) ExportCSV(ctx context.Context, deviceID, startTime, endTime string) (string, error) {
	recordings, err := r.ListByDevice(ctx, deviceID, startTime, endTime, 10000)
	if err != nil {
		return "", err
	}

	var builder strings.Builder
	builder.WriteString("ID,设备ID,开始时间,结束时间,时长(秒),文件大小(字节),SHA256,已上传,创建时间\n")

	for _, rec := range recordings {
		duration := rec.EndTime.Sub(rec.StartTime).Seconds()
		uploaded := "否"
		if rec.Uploaded {
			uploaded = "是"
		}
		builder.WriteString(fmt.Sprintf("%s,%s,%s,%s,%.2f,%d,%s,%s,%s\n",
			rec.ID.String(), rec.DeviceID.String(),
			rec.StartTime.Format(time.RFC3339), rec.EndTime.Format(time.RFC3339),
			duration, rec.FileSize, rec.SHA256, uploaded,
			rec.CreatedAt.Format(time.RFC3339)))
	}
	return builder.String(), nil
}

// ========== TaskRepository PostgreSQL实现 ==========

type TaskRepository struct {
	db *sql.DB
}

func NewTaskRepository(db *sql.DB) *TaskRepository {
	return &TaskRepository{db: db}
}

// GetPendingByDevice 获取指定设备的待处理任务
func (r *TaskRepository) GetPendingByDevice(ctx context.Context, deviceID string) ([]models.UploadTask, error) {
	// 确保 deviceID 是有效的 UUID
	deviceUUID, err := uuid.Parse(deviceID)
	if err != nil {
		return nil, fmt.Errorf("invalid device ID format: %w", err)
	}
	
	log.Printf("TaskRepository.GetPendingByDevice: querying for device %s", deviceUUID.String())
	
	query := `SELECT id, device_id, COALESCE(NULLIF(task_type, ''), 'upload_recordings'), start_time, end_time, status, progress, result, completed_at, created_at
              FROM upload_tasks WHERE status = 'pending' AND device_id = $1
              ORDER BY created_at ASC`
	
	rows, err := r.db.QueryContext(ctx, query, deviceUUID)
	if err != nil {
		log.Printf("Query error: %v", err)
		return nil, fmt.Errorf("query failed: %w", err)
	}
	defer rows.Close()
	
	var tasks []models.UploadTask
	for rows.Next() {
		var t models.UploadTask
		var completedAt sql.NullTime
		var taskDeviceUUID uuid.UUID
		
		if err := rows.Scan(&t.ID, &taskDeviceUUID, &t.Type, &t.StartTime, &t.EndTime, &t.Status, &t.Progress, &t.Result, &completedAt, &t.CreatedAt); err != nil {
			log.Printf("Scan error: %v", err)
			return nil, fmt.Errorf("scan failed: %w", err)
		}
		t.DeviceID = taskDeviceUUID
		if completedAt.Valid {
			t.CompletedAt = &completedAt.Time
		}
		tasks = append(tasks, t)
	}
	
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}
	
	log.Printf("Found %d pending tasks for device %s", len(tasks), deviceUUID.String())
	
	return tasks, nil
}

func (r *TaskRepository) List(ctx context.Context) ([]models.UploadTask, error) {
	rows, err := r.db.QueryContext(ctx, `SELECT id, device_id, COALESCE(NULLIF(task_type, ''), 'upload_recordings'), start_time, end_time, status, progress, result, completed_at, created_at
                                          FROM upload_tasks ORDER BY created_at DESC LIMIT 100`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tasks []models.UploadTask
	for rows.Next() {
		var t models.UploadTask
		var completedAt sql.NullTime
		var deviceUUID uuid.UUID
		if err := rows.Scan(&t.ID, &deviceUUID, &t.Type, &t.StartTime, &t.EndTime, &t.Status, &t.Progress, &t.Result, &completedAt, &t.CreatedAt); err != nil {
			return nil, err
		}
		t.DeviceID = deviceUUID
		if completedAt.Valid {
			t.CompletedAt = &completedAt.Time
		}
		tasks = append(tasks, t)
	}
	return tasks, nil
}

func (r *TaskRepository) GetByID(ctx context.Context, taskID string) (*models.UploadTask, error) {
	id, err := uuid.Parse(taskID)
	if err != nil {
		return nil, fmt.Errorf("invalid task id: %w", err)
	}

	var t models.UploadTask
	var deviceUUID uuid.UUID
	var completedAt sql.NullTime

	query := `SELECT id, device_id, COALESCE(NULLIF(task_type, ''), 'upload_recordings'), start_time, end_time, status, progress, result, completed_at, created_at
	          FROM upload_tasks WHERE id = $1`
	err = r.db.QueryRowContext(ctx, query, id).Scan(
		&t.ID, &deviceUUID, &t.Type, &t.StartTime, &t.EndTime,
		&t.Status, &t.Progress, &t.Result, &completedAt, &t.CreatedAt,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	t.DeviceID = deviceUUID
	if completedAt.Valid {
		t.CompletedAt = &completedAt.Time
	}
	return &t, nil
}

func (r *TaskRepository) UpdateStatus(ctx context.Context, taskID, status, result string, progress int, completedAt *time.Time) error {
	id, err := uuid.Parse(taskID)
	if err != nil {
		return err
	}
	query := `UPDATE upload_tasks SET status = $1, result = $2, progress = $3, completed_at = $4, updated_at = NOW() WHERE id = $5`
	_, err = r.db.ExecContext(ctx, query, status, result, progress, completedAt, id)
	return err
}

func (r *TaskRepository) Create(ctx context.Context, task *models.UploadTask) error {
	if task.ID == uuid.Nil {
		task.ID = uuid.New()
	}
	if task.CreatedAt.IsZero() {
		task.CreatedAt = models.UTCNow()
	}
	if task.Type == "" {
		task.Type = "upload_recordings"
	}
	query := `INSERT INTO upload_tasks (id, device_id, task_type, start_time, end_time, status, progress, result, completed_at, created_at, updated_at)
              VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $10)`
	_, err := r.db.ExecContext(ctx, query, task.ID, task.DeviceID, task.Type, task.StartTime, task.EndTime,
		task.Status, task.Progress, task.Result, task.CompletedAt, task.CreatedAt)
	return err
}

// ListRecentlyFailed 供告警扫描近期失败任务
func (r *TaskRepository) ListRecentlyFailed(ctx context.Context, since time.Duration) ([]models.UploadTask, error) {
	cutoff := time.Now().Add(-since)
	rows, err := r.db.QueryContext(ctx, `
		SELECT id, device_id, COALESCE(NULLIF(task_type, ''), 'upload_recordings'),
		       start_time, end_time, status, progress, result, completed_at, created_at
		FROM upload_tasks
		WHERE status = 'failed' AND COALESCE(completed_at, updated_at, created_at) >= $1
		ORDER BY COALESCE(completed_at, updated_at, created_at) DESC
		LIMIT 50`, cutoff)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tasks []models.UploadTask
	for rows.Next() {
		var t models.UploadTask
		var deviceUUID uuid.UUID
		var completedAt sql.NullTime
		if err := rows.Scan(
			&t.ID, &deviceUUID, &t.Type, &t.StartTime, &t.EndTime,
			&t.Status, &t.Progress, &t.Result, &completedAt, &t.CreatedAt,
		); err != nil {
			return nil, err
		}
		t.DeviceID = deviceUUID
		if completedAt.Valid {
			t.CompletedAt = &completedAt.Time
		}
		tasks = append(tasks, t)
	}
	return tasks, rows.Err()
}

// ExpireStaleRunningTasks 将长时间无更新的 running 任务标为 failed。
func (r *TaskRepository) ExpireStaleRunningTasks(ctx context.Context, timeout time.Duration) (int64, error) {
	if timeout <= 0 {
		timeout = 90 * time.Minute
	}

	cutoff := models.UTCNow().Add(-timeout)
	resultMsg := fmt.Sprintf("任务超时：超过 %d 分钟无进度更新", int(timeout.Minutes()))

	res, err := r.db.ExecContext(ctx, `
		UPDATE upload_tasks
		SET status = 'failed',
		    result = $1,
		    completed_at = NOW(),
		    updated_at = NOW()
		WHERE status = 'running'
		  AND updated_at < $2`,
		resultMsg, cutoff)
	if err != nil {
		return 0, err
	}
	return res.RowsAffected()
}

// StartStaleTaskMonitor 定期清扫卡住的 running 任务。
func (r *TaskRepository) StartStaleTaskMonitor(ctx context.Context) {
	const (
		checkInterval = 5 * time.Minute
		runningTimeout = 90 * time.Minute
	)

	ticker := time.NewTicker(checkInterval)
	defer ticker.Stop()

	log.Printf("[TaskMonitor] Stale running task monitor started (timeout=%v)", runningTimeout)

	for {
		select {
		case <-ctx.Done():
			log.Println("[TaskMonitor] Stale running task monitor stopped")
			return
		case <-ticker.C:
			n, err := r.ExpireStaleRunningTasks(ctx, runningTimeout)
			if err != nil {
				log.Printf("[TaskMonitor] Failed to expire stale tasks: %v", err)
				continue
			}
			if n > 0 {
				log.Printf("[TaskMonitor] Expired %d stale running task(s)", n)
			}
		}
	}
}

// ========== 辅助函数 ==========

// formatArg 格式化参数占位符（支持多位数）
func formatArg(n int) string {
	return "$" + strconv.Itoa(n)
}

// itoa 已弃用，使用 formatArg 代替
// 保留用于兼容性
func itoa(n int) string {
	return formatArg(n)
}

func nullString(s string) sql.NullString {
	if s == "" {
		return sql.NullString{Valid: false}
	}
	return sql.NullString{String: s, Valid: true}
}

func nullTime(t *time.Time) sql.NullTime {
	if t == nil {
		return sql.NullTime{Valid: false}
	}
	return sql.NullTime{Time: *t, Valid: true}
}

// EnsureDefaultPolicy 确保数据库中存在默认策略
func EnsureDefaultPolicy(db *sql.DB) error {
    var count int
    err := db.QueryRow(`SELECT COUNT(*) FROM policies`).Scan(&count)
    if err != nil {
        return err
    }
    
    if count > 0 {
        log.Println("📋 策略表已有数据，跳过默认策略创建")
        return nil
    }
    
    log.Println("📋 未发现策略，正在创建默认策略...")
    
    // 默认策略内容（与客户端对齐）
    defaultPolicyContent := `{
        "version": 1,
        "config": {
            "recording": {
                "enabled": true,
                "fps": 5,
                "quality": 70,
                "enableGpu": true,
                "sliceMinutes": 1,
                "autoUploadOnIndex": false
            },
            "upload": {
                "enabled": true,
                "rateLimitKBps": 1024,
                "maxConcurrent": 3,
                "chunkSizeKB": 2048
            },
            "remoteView": {
                "width": 1280,
                "height": 720,
                "fps": 10
            },
            "screenshot": {
                "enabled": true,
                "intervalSeconds": 30,
                "quality": 70,
                "format": "webp"
            },
            "activity": {
                "enabled": true,
                "trackIdle": true,
                "idleThresholdSeconds": 300
            },
            "security": {
                "enableEncryption": true,
                "enableVPN": false
            },
            "cleanup": {
                "enabled": true,
                "recordingDays": 7,
                "screenshotDays": 15,
                "logDays": 3,
                "diskThresholdPercent": 80
            }
        }
    }`
    
    _, err = db.Exec(`
        INSERT INTO policies (id, name, version, content, signature, is_current, status, created_at)
        VALUES (
            gen_random_uuid(),
            '默认策略',
            1,
            $1,
            '',
            true,
            1,
            NOW()
        )
    `, defaultPolicyContent)
    
    if err != nil {
        return fmt.Errorf("插入默认策略失败: %w", err)
    }
    
    log.Println("✅ 默认策略创建成功")
    return nil
}

// EnsurePolicySignatures is deprecated: policy signatures are generated at runtime (V2.1 Ed25519+JCS).
func EnsurePolicySignatures(db *sql.DB) error {
    return nil
}


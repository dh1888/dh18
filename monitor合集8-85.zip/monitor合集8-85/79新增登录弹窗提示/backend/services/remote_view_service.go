package services

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"

	"enterprise-agent/backend/config"
	"enterprise-agent/backend/models"
)

const (
	remoteViewStartAgentDelay    = 50 * time.Millisecond
	remoteViewIngressReadyMin    = 120 * time.Millisecond
	remoteViewIngressReadyStep   = 80 * time.Millisecond
	remoteViewIngressReadyMax    = 420 * time.Millisecond
	remoteViewFreshStartSettle   = 200 * time.Millisecond
	// Keep WHIP/RTMP ingress alive long enough for Agent reconnect / fallback;
	// 2s was deleting stream keys while FFmpeg still POSTed → "ingress does not exist".
	remoteViewIngressDeleteDelay = 15 * time.Second
	// Wipe SFU room shortly after last viewer leaves so the next start does not
	// subscribe to a ghost Ingress participant (frozen / non-realtime frame).
	remoteViewRoomDeleteDelay = 1500 * time.Millisecond
	// Reuse an active session when agent stats arrived recently (covers publisher grace window).
	remoteViewStatsStaleBuffer = 15 * time.Second
)

type publisherGraceStop struct {
	timer *time.Timer
}

type remoteViewStatsEntry struct {
	stats    *models.RemoteViewStatsPayload
	received time.Time
}

type RemoteViewService struct {
	cfg         config.LiveKitConfig
	repo        *RemoteViewRepository
	deviceRepo  *DeviceRepository
	policyRepo  *PolicyRepository
	wsHub       *WebSocketHub
	tokens      *LiveKitTokenService
	ingress     *liveKitIngressClient
	statsMu     sync.RWMutex
	deviceStats map[string]*remoteViewStatsEntry
	startLocks  sync.Map
	graceMu     sync.Mutex
	graceStops  map[string]*publisherGraceStop
}

func NewRemoteViewService(
	cfg config.LiveKitConfig,
	repo *RemoteViewRepository,
	deviceRepo *DeviceRepository,
	policyRepo *PolicyRepository,
	wsHub *WebSocketHub,
) *RemoteViewService {
	svc := &RemoteViewService{
		cfg:         cfg,
		repo:        repo,
		deviceRepo:  deviceRepo,
		policyRepo:  policyRepo,
		wsHub:       wsHub,
		tokens:      NewLiveKitTokenService(cfg.APIKey, cfg.APISecret, cfg.TokenTTL),
		deviceStats: make(map[string]*remoteViewStatsEntry),
		graceStops:  make(map[string]*publisherGraceStop),
	}
	if cfg.Enabled() {
		svc.ingress = newLiveKitIngressClient(cfg.APIHost, cfg.APIKey, cfg.APISecret, cfg.RTMPBaseURL, cfg.WHIPBaseURL)
	}
	return svc
}

func (s *RemoteViewService) UpdateDeviceStats(deviceID string, stats *models.RemoteViewStatsPayload) {
	if stats == nil {
		return
	}
	s.statsMu.Lock()
	s.deviceStats[deviceID] = &remoteViewStatsEntry{stats: stats, received: time.Now()}
	s.statsMu.Unlock()

	if s.wsHub != nil {
		s.wsHub.BroadcastToAdmin(gin.H{
			"type":        "remote_view_stats",
			"deviceId":    deviceID,
			"fps":         stats.FPS,
			"bitrateKbps": stats.BitrateKbps,
			"encoder":     stats.Encoder,
		})
	}
}

func (s *RemoteViewService) GetDeviceStats(deviceID string) *models.RemoteViewStatsPayload {
	s.statsMu.RLock()
	defer s.statsMu.RUnlock()
	entry := s.deviceStats[deviceID]
	if entry == nil {
		return nil
	}
	return entry.stats
}

func (s *RemoteViewService) statsStaleAfter() time.Duration {
	grace := s.cfg.PublisherGrace
	if grace <= 0 {
		return 20 * time.Second
	}
	return grace + remoteViewStatsStaleBuffer
}

func (s *RemoteViewService) hasFreshRemoteStats(deviceID string) bool {
	s.statsMu.RLock()
	defer s.statsMu.RUnlock()
	entry := s.deviceStats[deviceID]
	if entry == nil || entry.stats == nil {
		return false
	}
	return time.Since(entry.received) <= s.statsStaleAfter()
}

func (s *RemoteViewService) StartSession(
	ctx context.Context,
	deviceIDStr, userIDStr, username, clientIP, quality string,
	freshStart bool,
) (*models.RemoteViewStartResponse, error) {
	if !s.cfg.Enabled() {
		return nil, fmt.Errorf("livekit is not configured")
	}

	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid device id")
	}

	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid user id")
	}

	device, err := s.deviceRepo.Get(ctx, deviceID)
	if err != nil {
		return nil, fmt.Errorf("device not found")
	}

	if !s.wsHub.IsAgentOnline(deviceIDStr) {
		return nil, fmt.Errorf("device is not connected")
	}

	unlock := s.lockDeviceStart(deviceIDStr)
	defer unlock()

	s.expireStaleStartingIfNeeded(ctx, deviceID)

	roomName := config.RoomNameForDevice(deviceIDStr)
	expiresAt := models.UTCNow().Add(s.cfg.TokenTTL)

	active, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err == nil && active != nil && freshStart {
		log.Printf("[RemoteView] freshStart: tearing down session %s device=%s", active.ID, deviceIDStr)
		s.forceStopSessionLocked(ctx, active, "fresh_start")
		active = nil
		time.Sleep(remoteViewFreshStartSettle)
	}

	if err == nil && active != nil {
		// Zombie / stale active sessions (viewer left without clean stop, or agent
		// stopped publishing) cause the next open to viewer_join a dead room and
		// show a frozen non-realtime frame. Force a fresh session in that case.
		reuseOK := active.Status == models.RemoteViewStatusActive &&
			s.hasFreshRemoteStats(deviceIDStr)
		if active.Status == models.RemoteViewStatusStarting &&
			time.Since(active.UpdatedAt) < s.cfg.StartingTimeout {
			reuseOK = true
		}
		if !reuseOK {
			log.Printf("[RemoteView] discarding stale session %s device=%s status=%s viewers=%d freshStats=%v",
				active.ID, deviceIDStr, active.Status, active.ViewerCount, s.hasFreshRemoteStats(deviceIDStr))
			s.forceStopSessionLocked(ctx, active, "stale_reopen")
			active = nil
		}
	}

	if active != nil {
		s.cancelPublisherGraceStop(active.ID.String())

		if active.ViewerCount >= s.cfg.MaxViewersPerDev {
			return nil, fmt.Errorf("maximum viewers reached for this device")
		}

		// Double-check publisher is still live before viewer_join (no start_remote_view).
		if !s.hasFreshRemoteStats(deviceIDStr) {
			log.Printf("[RemoteView] viewer_join blocked: stale stats session=%s device=%s", active.ID, deviceIDStr)
			s.forceStopSessionLocked(ctx, active, "stale_viewer_join")
			active = nil
		}
	}

	if active != nil {
		viewerToken, err := s.tokens.CreateSubscriberToken(roomName, userIDStr, active.ID.String())
		if err != nil {
			return nil, err
		}

		if _, err := s.repo.IncrementViewerCount(ctx, active.ID); err != nil {
			return nil, err
		}

		s.writeAudit(ctx, &active.ID, deviceID, userID, username, "viewer_join", clientIP, gin.H{
			"roomName": roomName,
		})

		// Do not re-send start_remote_view on viewer join: it races the delayed first
		// start (status=starting) and can tear down a healthy publisher mid-handshake.
		// Quality changes go through UpdateQuality / the initial session start only.

		return &models.RemoteViewStartResponse{
			SessionID:   active.ID.String(),
			DeviceID:    deviceIDStr,
			DeviceName:  device.Hostname,
			RoomName:    roomName,
			LiveKitURL:  s.cfg.URL,
			ViewerToken: viewerToken,
			ExpiresAt:   expiresAt,
		}, nil
	}

	sessionID := uuid.New()
	now := models.UTCNow()
	session := &models.RemoteViewSession{
		ID:                sessionID,
		DeviceID:          deviceID,
		RoomName:          roomName,
		Status:            models.RemoteViewStatusStarting,
		StartedBy:         userID,
		StartedByName:     username,
		ViewerCount:       1,
		PublisherIdentity: publisherIdentityForSession(deviceIDStr, sessionID),
		LiveKitURL:        s.cfg.URL,
		StartedAt:         now,
		CreatedAt:         now,
		UpdatedAt:         now,
	}

	publishURL, ingressID, protocol, err := s.ensureIngress(ctx, roomName, deviceIDStr, sessionID)
	if err != nil {
		return nil, err
	}
	session.IngressID = ingressID
	session.RTMPURL = publishURL

	if err := s.repo.Create(ctx, session); err != nil {
		if s.ingress != nil && ingressID != "" {
			_ = s.ingress.DeleteIngress(ctx, ingressID)
		}
		return nil, err
	}

	viewerToken, err := s.tokens.CreateSubscriberToken(roomName, userIDStr, sessionID.String())
	if err != nil {
		return nil, err
	}

	s.writeAudit(ctx, &sessionID, deviceID, userID, username, "session_start", clientIP, gin.H{
		"roomName":        roomName,
		"publishProtocol": protocol,
	})

	go func() {
		time.Sleep(remoteViewStartAgentDelay)
		rv := s.resolveRemoteViewPublishParams(ctx, quality)
		s.sendStartRemoteViewCommand(deviceIDStr, sessionID.String(), roomName, publishURL, protocol, rv)
	}()

	return &models.RemoteViewStartResponse{
		SessionID:   sessionID.String(),
		DeviceID:    deviceIDStr,
		DeviceName:  device.Hostname,
		RoomName:    roomName,
		LiveKitURL:  s.cfg.URL,
		ViewerToken: viewerToken,
		ExpiresAt:   expiresAt,
	}, nil
}

// UpdateQuality re-sends start_remote_view with a new network profile for an active session.
func (s *RemoteViewService) UpdateQuality(
	ctx context.Context,
	deviceIDStr, sessionIDStr, quality, userIDStr, username, clientIP string,
) (string, error) {
	if !s.cfg.Enabled() {
		return "", fmt.Errorf("livekit is not configured")
	}

	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return "", fmt.Errorf("invalid device id")
	}

	if !s.wsHub.IsAgentOnline(deviceIDStr) {
		return "", fmt.Errorf("device is not connected")
	}

	var session *models.RemoteViewSession
	if sessionIDStr != "" {
		sid, parseErr := uuid.Parse(sessionIDStr)
		if parseErr != nil {
			return "", fmt.Errorf("invalid session id")
		}
		var getErr error
		session, getErr = s.repo.GetByID(ctx, sid)
		if getErr != nil || session == nil {
			return "", fmt.Errorf("session not found")
		}
		if session.DeviceID != deviceID {
			return "", fmt.Errorf("session does not belong to device")
		}
		if session.Status != models.RemoteViewStatusActive &&
			session.Status != models.RemoteViewStatusStarting {
			return "", fmt.Errorf("no active remote view session")
		}
	} else {
		session, err = s.repo.GetActiveByDevice(ctx, deviceID)
		if err != nil || session == nil {
			return "", fmt.Errorf("no active remote view session")
		}
	}

	if session.RTMPURL == "" {
		return "", fmt.Errorf("session publish url missing")
	}

	protocol := publishProtocolFromURL(session.RTMPURL)
	rv := s.resolveRemoteViewPublishParams(ctx, quality)
	s.sendStartRemoteViewCommand(deviceIDStr, session.ID.String(), session.RoomName, session.RTMPURL, protocol, rv)

	userID, _ := uuid.Parse(userIDStr)
	s.writeAudit(ctx, &session.ID, deviceID, userID, username, "quality_change", clientIP, gin.H{
		"networkProfile":  rv.NetworkProfile,
		"publishProtocol": protocol,
		"width":           rv.Width,
		"height":          rv.Height,
		"fps":             rv.Fps,
	})

	return rv.NetworkProfile, nil
}

type remoteViewPublishParams struct {
	Width            int
	Height           int
	Fps              int
	NetworkProfile   string
	VideoBitrateKbps int
}

func normalizeRemoteViewNetworkProfile(quality string) string {
	switch strings.ToLower(strings.TrimSpace(quality)) {
	case "weak", "fluent", "smooth":
		return "weak"
	case "strong", "hd", "high":
		return "strong"
	default:
		return "auto"
	}
}

func (s *RemoteViewService) sendStartRemoteViewCommand(
	deviceIDStr, sessionID, roomName, publishURL, protocol string,
	rv remoteViewPublishParams,
) {
	if protocol == "" {
		protocol = publishProtocolFromURL(publishURL)
	}
	payload := gin.H{
		"sessionId":        sessionID,
		"roomName":         roomName,
		"livekitUrl":       s.cfg.URL,
		"publishProtocol":  protocol,
		"width":            rv.Width,
		"height":           rv.Height,
		"fps":              rv.Fps,
		"networkProfile":   rv.NetworkProfile,
	}
	if protocol == "whip" {
		payload["whipUrl"] = publishURL
		payload["rtmpUrl"] = ""
	} else {
		payload["rtmpUrl"] = publishURL
		payload["whipUrl"] = ""
	}
	if key := streamKeyFromPublishURL(publishURL); key != "" {
		payload["streamKey"] = key
	}
	if rv.VideoBitrateKbps > 0 {
		payload["videoBitrateKbps"] = rv.VideoBitrateKbps
	}
	s.wsHub.SendCommandToDevice(deviceIDStr, "start_remote_view", payload)
	log.Printf("[RemoteView] start_remote_view sent to device %s session=%s protocol=%s profile=%s url=%s size=%dx%d@%d bitrate=%d",
		deviceIDStr, sessionID, protocol, rv.NetworkProfile, maskPublishURL(publishURL), rv.Width, rv.Height, rv.Fps, rv.VideoBitrateKbps)
}

func (s *RemoteViewService) resolveRemoteViewPublishParams(ctx context.Context, quality string) remoteViewPublishParams {
	base := s.resolveRemoteViewPolicyParams(ctx)
	profile := normalizeRemoteViewNetworkProfile(quality)
	params := remoteViewPublishParams{
		Width:          base.Width,
		Height:         base.Height,
		Fps:            base.Fps,
		NetworkProfile: profile,
	}

	switch profile {
	case "weak":
		params.Width = 854
		params.Height = 480
		params.Fps = 8
		params.VideoBitrateKbps = 600
	case "auto":
		// Keep auto aligned with bridge/WHIP default fps so the first publish and
		// later UpdateQuality do not trigger pointless in-place encoder restarts.
		if params.Fps < models.DefaultRemoteViewFps {
			params.Fps = models.DefaultRemoteViewFps
		}
	case "strong":
		if params.Width < models.DefaultRemoteViewWidth {
			params.Width = models.DefaultRemoteViewWidth
		}
		if params.Height < models.DefaultRemoteViewHeight {
			params.Height = models.DefaultRemoteViewHeight
		}
		if params.Fps < models.DefaultRemoteViewFps {
			params.Fps = models.DefaultRemoteViewFps
		}
		// 15fps WHIP needs a bit more bitrate than the old 10fps/1500k profile.
		params.VideoBitrateKbps = 2000
	}

	return params
}

func (s *RemoteViewService) resolveRemoteViewPolicyParams(ctx context.Context) models.RemoteViewPolicyConfig {
	defaults := models.RemoteViewPolicyConfig{
		Width:  models.DefaultRemoteViewWidth,
		Height: models.DefaultRemoteViewHeight,
		Fps:    models.DefaultRemoteViewFps,
	}
	if s.policyRepo == nil {
		return defaults
	}

	policy, err := s.policyRepo.GetCurrent(ctx)
	if err != nil || policy == nil {
		return defaults
	}

	return models.ParseRemoteViewFromPolicyContent(string(policy.Content))
}

func (s *RemoteViewService) StopSession(
	ctx context.Context,
	deviceIDStr, userIDStr, username, sessionIDStr, clientIP string,
	hardStop bool,
) (bool, error) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return false, fmt.Errorf("invalid device id")
	}

	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		return false, fmt.Errorf("invalid user id")
	}

	var session *models.RemoteViewSession
	if sessionIDStr != "" {
		sessionID, parseErr := uuid.Parse(sessionIDStr)
		if parseErr != nil {
			return false, fmt.Errorf("invalid session id")
		}
		session, err = s.repo.GetByID(ctx, sessionID)
	} else {
		session, err = s.repo.GetActiveByDevice(ctx, deviceID)
	}
	if err != nil || session == nil {
		return false, fmt.Errorf("session not found")
	}

	if session.DeviceID != deviceID {
		return false, fmt.Errorf("session does not belong to device")
	}

	// 已结束或正在结束：幂等返回，避免重复减计数、重复删 Ingress
	if session.Status == models.RemoteViewStatusStopped || session.Status == models.RemoteViewStatusStopping {
		return false, nil
	}

	sessionDeviceID := session.DeviceID.String()

	viewerCount, err := s.repo.DecrementViewerCount(ctx, session.ID)
	if err != nil {
		return false, err
	}

	s.writeAudit(ctx, &session.ID, deviceID, userID, username, "viewer_leave", clientIP, gin.H{
		"viewerCount": viewerCount,
	})

	publisherStopped := false
	if viewerCount <= 0 {
		if hardStop || s.cfg.PublisherGrace <= 0 {
			s.cancelPublisherGraceStop(session.ID.String())
			s.forceStopSessionLocked(ctx, session, "user_stop")
			publisherStopped = true
			s.writeAudit(ctx, &session.ID, deviceID, userID, username, "session_stop", clientIP, nil)
		} else {
			s.schedulePublisherGraceStop(session)
			log.Printf("[RemoteView] publisher grace started session=%s device=%s grace=%s",
				session.ID, sessionDeviceID, s.cfg.PublisherGrace)
		}
	}

	return publisherStopped, nil
}

func (s *RemoteViewService) schedulePublisherGraceStop(session *models.RemoteViewSession) {
	if session == nil {
		return
	}
	sessionID := session.ID.String()
	grace := s.cfg.PublisherGrace
	if grace <= 0 {
		return
	}

	s.graceMu.Lock()
	if existing, ok := s.graceStops[sessionID]; ok && existing != nil && existing.timer != nil {
		existing.timer.Stop()
	}
	snapshot := *session
	s.graceStops[sessionID] = &publisherGraceStop{
		timer: time.AfterFunc(grace, func() {
			s.graceMu.Lock()
			delete(s.graceStops, sessionID)
			s.graceMu.Unlock()

			ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
			defer cancel()
			current, err := s.repo.GetByID(ctx, snapshot.ID)
			if err != nil || current == nil {
				return
			}
			if current.Status == models.RemoteViewStatusStopped {
				return
			}
			log.Printf("[RemoteView] publisher grace expired session=%s device=%s", snapshot.ID, snapshot.DeviceID)
			s.forceStopSessionLocked(ctx, current, "grace_expired")
		}),
	}
	s.graceMu.Unlock()
}

func (s *RemoteViewService) cancelPublisherGraceStop(sessionID string) {
	if strings.TrimSpace(sessionID) == "" {
		return
	}
	s.graceMu.Lock()
	defer s.graceMu.Unlock()
	if entry, ok := s.graceStops[sessionID]; ok && entry != nil && entry.timer != nil {
		entry.timer.Stop()
	}
	delete(s.graceStops, sessionID)
}

func (s *RemoteViewService) GetStatus(ctx context.Context, deviceIDStr string) (*models.RemoteViewStatusResponse, error) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid device id")
	}

	s.expireStaleStartingIfNeeded(ctx, deviceID)

	session, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err != nil {
		return &models.RemoteViewStatusResponse{IsActive: false}, nil
	}

	resp := &models.RemoteViewStatusResponse{
		IsActive:    true,
		SessionID:   session.ID.String(),
		Status:      session.Status,
		ViewerCount: session.ViewerCount,
		StartedAt:   models.FormatUTC(session.StartedAt),
		StatsFresh:  s.hasFreshRemoteStats(deviceIDStr),
	}
	if resp.StatsFresh {
		resp.Stats = s.GetDeviceStats(deviceIDStr)
	}
	return resp, nil
}

func (s *RemoteViewService) MarkSessionActive(ctx context.Context, deviceIDStr, sessionIDStr string) error {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return fmt.Errorf("invalid device id")
	}
	sessionID, err := uuid.Parse(sessionIDStr)
	if err != nil {
		return fmt.Errorf("invalid session id")
	}

	session, err := s.repo.GetByID(ctx, sessionID)
	if err != nil || session == nil {
		return fmt.Errorf("session not found")
	}
	if session.DeviceID != deviceID {
		return fmt.Errorf("session does not belong to device")
	}
	if session.Status == models.RemoteViewStatusStopped {
		return fmt.Errorf("session already stopped")
	}

	return s.repo.UpdateStatus(ctx, sessionID, models.RemoteViewStatusActive)
}

func (s *RemoteViewService) MarkSessionFailed(ctx context.Context, deviceIDStr, sessionIDStr, reason string) error {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return fmt.Errorf("invalid device id")
	}
	sessionID, err := uuid.Parse(sessionIDStr)
	if err != nil {
		return fmt.Errorf("invalid session id")
	}
	if strings.TrimSpace(reason) == "" {
		reason = "publish_failed"
	}

	session, err := s.repo.GetByID(ctx, sessionID)
	if err != nil || session == nil {
		return fmt.Errorf("session not found")
	}
	if session.DeviceID != deviceID {
		return fmt.Errorf("session does not belong to device")
	}
	if session.Status == models.RemoteViewStatusStopped || session.Status == models.RemoteViewStatusFailed {
		return nil
	}

	if s.ingress != nil && session.IngressID != "" {
		s.scheduleIngressDelete(session.IngressID)
	}
	s.scheduleRoomDelete(session.RoomName)
	if err := s.repo.MarkFailed(ctx, session.ID, reason); err != nil {
		return err
	}
	s.statsMu.Lock()
	delete(s.deviceStats, deviceIDStr)
	s.statsMu.Unlock()
	return nil
}

// FallbackSessionToRtmp replaces a WHIP ingress with RTMP and re-commands the agent.
// Used when Agent reports whip_fallback_request after consecutive WHIP publish failures.
func (s *RemoteViewService) FallbackSessionToRtmp(ctx context.Context, deviceIDStr, sessionIDStr, detail string) error {
	if !s.cfg.AllowRtmpFallback() {
		return fmt.Errorf("RTMP fallback disabled (REMOTE_VIEW_PUBLISH_PROTOCOL=whip); fix WHIP ICE/UDP 7893")
	}
	if !s.cfg.Enabled() || s.ingress == nil {
		return fmt.Errorf("livekit is not configured")
	}
	if strings.TrimSpace(s.cfg.RTMPBaseURL) == "" {
		return fmt.Errorf("LIVEKIT_RTMP_BASE_URL not configured; cannot fallback")
	}

	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return fmt.Errorf("invalid device id")
	}
	sessionID, err := uuid.Parse(sessionIDStr)
	if err != nil {
		return fmt.Errorf("invalid session id")
	}

	unlock := s.lockDeviceStart(deviceIDStr)
	defer unlock()

	session, err := s.repo.GetByID(ctx, sessionID)
	if err != nil || session == nil {
		return fmt.Errorf("session not found")
	}
	if session.DeviceID != deviceID {
		return fmt.Errorf("session does not belong to device")
	}

	// Allow starting/active/failed. Also revive a just-stopped session: frontend often
	// calls stop when LiveKit has no tracks yet, racing with Agent whip_fallback_request.
	switch session.Status {
	case models.RemoteViewStatusActive, models.RemoteViewStatusStarting, models.RemoteViewStatusFailed:
		// ok
	case models.RemoteViewStatusStopped, models.RemoteViewStatusStopping:
		if session.EndReason == "user_stop" && time.Since(session.UpdatedAt) > 5*time.Second {
			return fmt.Errorf("session stopped by user")
		}
		log.Printf("[RemoteView] WHIP fallback reviving session=%s status=%s reason=%s",
			sessionID, session.Status, session.EndReason)
	default:
		return fmt.Errorf("session not active (status=%s)", session.Status)
	}

	if publishProtocolFromURL(session.RTMPURL) == "rtmp" {
		log.Printf("[RemoteView] fallback skipped session=%s already on RTMP", sessionID)
		return nil
	}

	oldIngress := session.IngressID
	rtmpURL, ingressID, err := s.ingress.CreateRTMPIngress(ctx, session.RoomName, deviceIDStr, session.ID)
	if err != nil {
		return fmt.Errorf("create rtmp ingress for fallback: %w", err)
	}

	if err := s.waitIngressReady(ctx); err != nil {
		_ = s.ingress.DeleteIngress(context.Background(), ingressID)
		return err
	}

	if err := s.repo.UpdateIngress(ctx, session.ID, ingressID, rtmpURL); err != nil {
		_ = s.ingress.DeleteIngress(ctx, ingressID)
		return err
	}
	if err := s.repo.ReviveForFallback(ctx, session.ID); err != nil {
		log.Printf("[RemoteView] revive session for fallback: %v", err)
	}
	if oldIngress != "" {
		s.scheduleIngressDelete(oldIngress)
	}

	rv := s.resolveRemoteViewPublishParams(ctx, "auto")
	s.sendStartRemoteViewCommand(deviceIDStr, session.ID.String(), session.RoomName, rtmpURL, "rtmp", rv)

	s.writeAudit(ctx, &session.ID, deviceID, session.StartedBy, session.StartedByName, "whip_fallback_rtmp", "", gin.H{
		"detail":   detail,
		"protocol": "rtmp",
	})
	log.Printf("[RemoteView] WHIP→RTMP fallback session=%s device=%s detail=%s", sessionID, deviceIDStr, detail)
	return nil
}

func (s *RemoteViewService) expireStaleStartingIfNeeded(ctx context.Context, deviceID uuid.UUID) {
	session, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err != nil || session == nil {
		return
	}
	if session.Status != models.RemoteViewStatusStarting {
		return
	}
	if time.Since(session.UpdatedAt) < s.cfg.StartingTimeout {
		return
	}

	log.Printf("[RemoteView] expiring stale starting session %s for device %s", session.ID, deviceID)
	if s.ingress != nil && session.IngressID != "" {
		_ = s.ingress.DeleteIngress(ctx, session.IngressID)
	}
	s.scheduleRoomDelete(session.RoomName)
	_ = s.repo.MarkFailed(ctx, session.ID, "starting_timeout")
	s.statsMu.Lock()
	delete(s.deviceStats, deviceID.String())
	s.statsMu.Unlock()
	s.wsHub.SendCommandToDevice(deviceID.String(), "stop_remote_view", gin.H{
		"sessionId": session.ID.String(),
	})
}

// forceStopSessionLocked tears down an active/starting session while startLocks is held.
func (s *RemoteViewService) forceStopSessionLocked(ctx context.Context, session *models.RemoteViewSession, reason string) {
	if session == nil {
		return
	}
	s.cancelPublisherGraceStop(session.ID.String())
	deviceID := session.DeviceID.String()
	s.wsHub.SendCommandToDevice(deviceID, "stop_remote_view", gin.H{
		"sessionId": session.ID.String(),
	})
	if s.ingress != nil && session.IngressID != "" {
		s.scheduleIngressDelete(session.IngressID)
	}
	s.scheduleRoomDelete(session.RoomName)
	_ = s.repo.MarkStopped(ctx, session.ID, reason)
	s.statsMu.Lock()
	delete(s.deviceStats, deviceID)
	s.statsMu.Unlock()
}

func (s *RemoteViewService) lockDeviceStart(deviceID string) func() {
	v, _ := s.startLocks.LoadOrStore(deviceID, &sync.Mutex{})
	mu := v.(*sync.Mutex)
	mu.Lock()
	return mu.Unlock
}

func (s *RemoteViewService) PingLiveKit(ctx context.Context) error {
	if s.ingress == nil {
		return fmt.Errorf("livekit is not configured")
	}
	return s.ingress.Ping(ctx)
}

func publisherIdentityForSession(deviceID string, sessionID uuid.UUID) string {
	short := strings.ReplaceAll(sessionID.String(), "-", "")
	if len(short) > 8 {
		short = short[:8]
	}
	return "agent-" + deviceID + "-" + short
}

func (s *RemoteViewService) ensureIngress(ctx context.Context, roomName, deviceID string, sessionID uuid.UUID) (publishURL, ingressID, protocol string, err error) {
	if s.ingress == nil {
		return "", "", "", fmt.Errorf("livekit ingress client not configured")
	}

	if err := s.ingress.Ping(ctx); err != nil {
		return "", "", "", fmt.Errorf("livekit unreachable before create ingress: %w", err)
	}

	// Clear leftover SFU participants from the previous session before publishing again.
	if err := s.ingress.DeleteRoomWithRetry(ctx, roomName, 3); err != nil {
		log.Printf("[RemoteView] pre-create DeleteRoom %s after retries: %v", roomName, err)
	}

	protocol = s.cfg.ResolvePublishProtocol()
	if protocol == "whip" {
		publishURL, ingressID, err = s.ingress.CreateWHIPIngress(ctx, roomName, deviceID, sessionID)
		if err != nil {
			if s.cfg.AllowRtmpFallback() && s.cfg.RTMPBaseURL != "" {
				log.Printf("[RemoteView] WHIP ingress failed, falling back to RTMP: %v", err)
				protocol = "rtmp"
				publishURL, ingressID, err = s.ingress.CreateRTMPIngress(ctx, roomName, deviceID, sessionID)
			}
			if err != nil {
				return "", "", "", fmt.Errorf("create ingress: %w", err)
			}
		}
	} else {
		publishURL, ingressID, err = s.ingress.CreateRTMPIngress(ctx, roomName, deviceID, sessionID)
		if err != nil {
			return "", "", "", fmt.Errorf("create ingress: %w", err)
		}
	}
	log.Printf("[RemoteView] ingress created protocol=%s ingressID=%s streamKey=%s url=%s room=%s identity=%s",
		protocol, ingressID, streamKeyFromPublishURL(publishURL), maskPublishURL(publishURL), roomName,
		publisherIdentityForSession(deviceID, sessionID))

	if err := s.waitIngressReady(ctx); err != nil {
		if s.ingress != nil && ingressID != "" {
			_ = s.ingress.DeleteIngress(context.Background(), ingressID)
		}
		return "", "", "", err
	}

	return publishURL, ingressID, protocol, nil
}

func (s *RemoteViewService) waitIngressReady(ctx context.Context) error {
	if s.ingress == nil {
		return nil
	}

	started := time.Now()
	for {
		if err := ctx.Err(); err != nil {
			return err
		}

		elapsed := time.Since(started)
		if elapsed >= remoteViewIngressReadyMin {
			if err := s.ingress.Ping(ctx); err == nil {
				return nil
			}
		}
		if elapsed >= remoteViewIngressReadyMax {
			return nil
		}

		wait := remoteViewIngressReadyStep
		if remaining := remoteViewIngressReadyMax - elapsed; wait > remaining {
			wait = remaining
		}
		if wait <= 0 {
			return nil
		}

		timer := time.NewTimer(wait)
		select {
		case <-ctx.Done():
			timer.Stop()
			return ctx.Err()
		case <-timer.C:
		}
	}
}

// scheduleIngressDelete waits before tearing down Ingress so the agent can finish publish teardown.
func (s *RemoteViewService) scheduleIngressDelete(ingressID string) {
	if s.ingress == nil || ingressID == "" {
		return
	}
	go func(id string) {
		time.Sleep(remoteViewIngressDeleteDelay)
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		if err := s.ingress.DeleteIngress(ctx, id); err != nil {
			log.Printf("[RemoteView] delete ingress failed: %v", err)
		}
	}(ingressID)
}

func (s *RemoteViewService) scheduleRoomDelete(roomName string) {
	if s.ingress == nil || strings.TrimSpace(roomName) == "" {
		return
	}
	go func(name string) {
		time.Sleep(remoteViewRoomDeleteDelay)
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		if err := s.ingress.DeleteRoomWithRetry(ctx, name, 3); err != nil {
			log.Printf("[RemoteView] delete room failed after retries: %v", err)
		}
	}(roomName)
}

func (s *RemoteViewService) writeAudit(
	ctx context.Context,
	sessionID *uuid.UUID,
	deviceID, operatorID uuid.UUID,
	operatorName, action, clientIP string,
	detail interface{},
) {
	entry := &models.RemoteViewAuditLog{
		ID:           uuid.New(),
		SessionID:    sessionID,
		DeviceID:     deviceID,
		OperatorID:   operatorID,
		OperatorName: operatorName,
		Action:       action,
		Detail:       auditDetail(detail),
		ClientIP:     clientIP,
		CreatedAt:    models.UTCNow(),
	}
	if err := s.repo.InsertAudit(ctx, entry); err != nil {
		log.Printf("[RemoteView] audit insert failed: %v", err)
	}
}

func (s *RemoteViewService) ListAuditLogs(ctx context.Context, deviceID *uuid.UUID, page, pageSize int) ([]models.RemoteViewAuditLog, int, error) {
	return s.repo.ListAuditLogs(ctx, deviceID, page, pageSize)
}

// SweepZombieSessions stops orphaned active/starting sessions after backend restart or missed grace timers.
func (s *RemoteViewService) SweepZombieSessions(ctx context.Context) {
	threshold := s.statsStaleAfter()
	sessions, err := s.repo.ListStalePublisherSessions(ctx, threshold)
	if err != nil {
		log.Printf("[RemoteView] startup sweep query failed: %v", err)
		return
	}
	for _, session := range sessions {
		if session == nil {
			continue
		}
		deviceID := session.DeviceID.String()
		if s.hasFreshRemoteStats(deviceID) {
			continue
		}
		log.Printf("[RemoteView] startup sweep stopping zombie session=%s device=%s status=%s viewers=%d",
			session.ID, deviceID, session.Status, session.ViewerCount)
		unlock := s.lockDeviceStart(deviceID)
		s.forceStopSessionLocked(ctx, session, "startup_sweep")
		unlock()
	}
}

func (s *RemoteViewService) OnAgentDisconnected(ctx context.Context, deviceIDStr string) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return
	}
	session, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err != nil || session == nil {
		return
	}
	s.cancelPublisherGraceStop(session.ID.String())
	_ = s.repo.MarkStopped(ctx, session.ID, "agent_offline")
	if s.ingress != nil && session.IngressID != "" {
		_ = s.ingress.DeleteIngress(ctx, session.IngressID)
	}
	s.scheduleRoomDelete(session.RoomName)
	s.statsMu.Lock()
	delete(s.deviceStats, deviceIDStr)
	s.statsMu.Unlock()
}

type LiveKitTokenService struct {
	apiKey    string
	apiSecret string
	ttl       time.Duration
}

func NewLiveKitTokenService(apiKey, apiSecret string, ttl time.Duration) *LiveKitTokenService {
	return &LiveKitTokenService{
		apiKey:    apiKey,
		apiSecret: apiSecret,
		ttl:       ttl,
	}
}

type liveKitVideoGrant struct {
	RoomJoin      bool   `json:"roomJoin,omitempty"`
	Room          string `json:"room,omitempty"`
	RoomCreate    bool   `json:"roomCreate,omitempty"`
	RoomAdmin     bool   `json:"roomAdmin,omitempty"`
	CanPublish    bool   `json:"canPublish,omitempty"`
	CanSubscribe  bool   `json:"canSubscribe,omitempty"`
	IngressAdmin  bool   `json:"ingressAdmin,omitempty"`
}

type liveKitClaims struct {
	Video liveKitVideoGrant `json:"video"`
	jwt.RegisteredClaims
}

func (s *LiveKitTokenService) signToken(identity string, grant liveKitVideoGrant) (string, error) {
	if s.apiKey == "" || s.apiSecret == "" {
		return "", fmt.Errorf("livekit api credentials not configured")
	}

	now := time.Now()
	claims := liveKitClaims{
		Video: grant,
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    s.apiKey,
			Subject:   identity,
			NotBefore: jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(s.ttl)),
			IssuedAt:  jwt.NewNumericDate(now),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.apiSecret))
}

func (s *LiveKitTokenService) CreateSubscriberToken(roomName, userID, sessionID string) (string, error) {
	return s.signToken(fmt.Sprintf("viewer-%s-%s", userID, sessionID), liveKitVideoGrant{
		RoomJoin:     true,
		Room:         roomName,
		CanPublish:   false,
		CanSubscribe: true,
	})
}

func (s *LiveKitTokenService) createAdminToken(ttl time.Duration) (string, error) {
	if s.apiKey == "" || s.apiSecret == "" {
		return "", fmt.Errorf("livekit api credentials not configured")
	}
	now := time.Now()
	claims := liveKitClaims{
		Video: liveKitVideoGrant{
			RoomCreate:   true,
			RoomAdmin:    true,
			IngressAdmin: true,
		},
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    s.apiKey,
			Subject:   "remote-view-admin",
			NotBefore: jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(ttl)),
			IssuedAt:  jwt.NewNumericDate(now),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.apiSecret))
}

type liveKitIngressClient struct {
	apiHost     string
	apiKey      string
	apiSecret   string
	rtmpBaseURL string
	whipBaseURL string
	http        *http.Client
	tokens      *LiveKitTokenService
}

func newLiveKitIngressClient(apiHost, apiKey, apiSecret, rtmpBaseURL, whipBaseURL string) *liveKitIngressClient {
	return &liveKitIngressClient{
		apiHost:     strings.TrimSuffix(apiHost, "/"),
		apiKey:      apiKey,
		apiSecret:   apiSecret,
		rtmpBaseURL: strings.TrimSuffix(strings.TrimSpace(rtmpBaseURL), "/"),
		whipBaseURL: strings.TrimSuffix(strings.TrimSpace(whipBaseURL), "/"),
		http:        &http.Client{Timeout: 15 * time.Second},
		tokens:      NewLiveKitTokenService(apiKey, apiSecret, 5*time.Minute),
	}
}

type createIngressRequest struct {
	InputType           int    `json:"input_type"`
	Name                string `json:"name"`
	RoomName            string `json:"room_name"`
	ParticipantIdentity string `json:"participant_identity"`
	ParticipantName     string `json:"participant_name"`
	// EnableTranscoding: false = passthrough encoded media (lower latency for WHIP/H264).
	EnableTranscoding *bool `json:"enable_transcoding,omitempty"`
}

type ingressInfoResponse struct {
	IngressId string `json:"ingress_id"`
	Url       string `json:"url"`
	StreamKey string `json:"stream_key"`
}

func (c *liveKitIngressClient) CreateRTMPIngress(ctx context.Context, roomName, deviceID string, sessionID uuid.UUID) (rtmpURL, ingressID string, err error) {
	// Agent already encodes H264; skip Ingress GST/simulcast re-encode (was ~1–2s extra latency).
	identity := publisherIdentityForSession(deviceID, sessionID)
	short := strings.ReplaceAll(sessionID.String(), "-", "")
	if len(short) > 8 {
		short = short[:8]
	}
	bypass := false
	body, _ := json.Marshal(createIngressRequest{
		InputType:           0,
		Name:                roomName + "-" + short,
		RoomName:            roomName,
		ParticipantIdentity: identity,
		ParticipantName:     identity,
		EnableTranscoding:   &bypass,
	})

	info, err := c.postCreateIngress(ctx, body)
	if err != nil {
		return "", "", err
	}

	rtmpURL, err = normalizeRTMPIngressURL(c.rtmpBaseURL, info.Url, info.StreamKey)
	if err != nil {
		return "", "", fmt.Errorf("normalize rtmp url: %w", err)
	}
	return rtmpURL, info.IngressId, nil
}

func (c *liveKitIngressClient) CreateWHIPIngress(ctx context.Context, roomName, deviceID string, sessionID uuid.UUID) (whipURL, ingressID string, err error) {
	identity := publisherIdentityForSession(deviceID, sessionID)
	short := strings.ReplaceAll(sessionID.String(), "-", "")
	if len(short) > 8 {
		short = short[:8]
	}
	bypass := false
	body, _ := json.Marshal(createIngressRequest{
		InputType:           1, // INGRESS_INPUT_WHIP
		Name:                roomName + "-" + short,
		RoomName:            roomName,
		ParticipantIdentity: identity,
		ParticipantName:     identity,
		EnableTranscoding:   &bypass,
	})

	info, err := c.postCreateIngress(ctx, body)
	if err != nil {
		return "", "", err
	}

	whipURL, err = normalizeWHIPIngressURL(c.whipBaseURL, info.Url, info.StreamKey)
	if err != nil {
		return "", "", fmt.Errorf("normalize whip url: %w", err)
	}
	return whipURL, info.IngressId, nil
}

func (c *liveKitIngressClient) postCreateIngress(ctx context.Context, body []byte) (*ingressInfoResponse, error) {
	token, err := c.tokens.createAdminToken(5 * time.Minute)
	if err != nil {
		return nil, err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.apiHost+"/twirp/livekit.Ingress/CreateIngress", bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, fmt.Errorf("create ingress http %d: %s", resp.StatusCode, string(respBody))
	}

	var info ingressInfoResponse
	if err := json.Unmarshal(respBody, &info); err != nil {
		return nil, err
	}
	return &info, nil
}

func (c *liveKitIngressClient) DeleteIngress(ctx context.Context, ingressID string) error {
	body, _ := json.Marshal(map[string]string{"ingress_id": ingressID})

	token, err := c.tokens.createAdminToken(5 * time.Minute)
	if err != nil {
		return err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.apiHost+"/twirp/livekit.Ingress/DeleteIngress", bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		respBody, _ := io.ReadAll(resp.Body)
		if isIngressNotFound(resp.StatusCode, string(respBody)) {
			return nil
		}
		return fmt.Errorf("delete ingress http %d: %s", resp.StatusCode, string(respBody))
	}
	return nil
}

func (c *liveKitIngressClient) DeleteRoom(ctx context.Context, roomName string) error {
	return c.deleteRoomOnce(ctx, roomName)
}

func (c *liveKitIngressClient) DeleteRoomWithRetry(ctx context.Context, roomName string, attempts int) error {
	if attempts < 1 {
		attempts = 1
	}
	var lastErr error
	for i := 0; i < attempts; i++ {
		if err := c.deleteRoomOnce(ctx, roomName); err == nil {
			return nil
		} else {
			lastErr = err
			if i < attempts-1 {
				time.Sleep(time.Duration(250*(i+1)) * time.Millisecond)
			}
		}
	}
	return lastErr
}

func (c *liveKitIngressClient) deleteRoomOnce(ctx context.Context, roomName string) error {
	roomName = strings.TrimSpace(roomName)
	if roomName == "" {
		return nil
	}
	body, _ := json.Marshal(map[string]string{"room": roomName})

	token, err := c.tokens.createAdminToken(5 * time.Minute)
	if err != nil {
		return err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.apiHost+"/twirp/livekit.RoomService/DeleteRoom", bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		respBody, _ := io.ReadAll(resp.Body)
		msg := string(respBody)
		// Room already gone is fine — next CreateIngress will recreate it.
		if resp.StatusCode == http.StatusNotFound ||
			strings.Contains(strings.ToLower(msg), "not found") ||
			strings.Contains(strings.ToLower(msg), "does not exist") {
			return nil
		}
		return fmt.Errorf("delete room http %d: %s", resp.StatusCode, msg)
	}
	return nil
}

func (c *liveKitIngressClient) Ping(ctx context.Context) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.apiHost, nil)
	if err != nil {
		return err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 400 {
		return fmt.Errorf("livekit http %d", resp.StatusCode)
	}
	return nil
}

type RemoteViewRepository struct {
	db *sql.DB
}

func NewRemoteViewRepository(db *sql.DB) *RemoteViewRepository {
	return &RemoteViewRepository{db: db}
}

func (r *RemoteViewRepository) GetActiveByDevice(ctx context.Context, deviceID uuid.UUID) (*models.RemoteViewSession, error) {
	row := r.db.QueryRowContext(ctx, `
		SELECT id, device_id, room_name, status, started_by, started_by_name, viewer_count,
		       publisher_identity, livekit_url, COALESCE(ingress_id, ''), COALESCE(rtmp_url, ''),
		       started_at, ended_at, COALESCE(end_reason, ''), created_at, updated_at
		FROM remote_view_sessions
		WHERE device_id = $1 AND status IN ('starting', 'active')
		ORDER BY created_at DESC
		LIMIT 1
	`, deviceID)

	return scanRemoteViewSession(row)
}

func (r *RemoteViewRepository) ListStalePublisherSessions(ctx context.Context, olderThan time.Duration) ([]*models.RemoteViewSession, error) {
	if olderThan <= 0 {
		olderThan = 60 * time.Second
	}
	seconds := int64(olderThan.Seconds())
	if seconds < 1 {
		seconds = 1
	}
	rows, err := r.db.QueryContext(ctx, `
		SELECT id, device_id, room_name, status, started_by, started_by_name, viewer_count,
		       publisher_identity, livekit_url, COALESCE(ingress_id, ''), COALESCE(rtmp_url, ''),
		       started_at, ended_at, COALESCE(end_reason, ''), created_at, updated_at
		FROM remote_view_sessions
		WHERE status IN ('starting', 'active')
		  AND viewer_count = 0
		  AND updated_at < NOW() - ($1 * INTERVAL '1 second')
		ORDER BY updated_at ASC
	`, seconds)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var sessions []*models.RemoteViewSession
	for rows.Next() {
		var session models.RemoteViewSession
		var endedAt sql.NullTime
		if err := rows.Scan(
			&session.ID, &session.DeviceID, &session.RoomName, &session.Status,
			&session.StartedBy, &session.StartedByName, &session.ViewerCount,
			&session.PublisherIdentity, &session.LiveKitURL, &session.IngressID, &session.RTMPURL,
			&session.StartedAt, &endedAt, &session.EndReason, &session.CreatedAt, &session.UpdatedAt,
		); err != nil {
			return nil, err
		}
		if endedAt.Valid {
			session.EndedAt = &endedAt.Time
		}
		sessions = append(sessions, &session)
	}
	return sessions, rows.Err()
}

func (r *RemoteViewRepository) GetByID(ctx context.Context, sessionID uuid.UUID) (*models.RemoteViewSession, error) {
	row := r.db.QueryRowContext(ctx, `
		SELECT id, device_id, room_name, status, started_by, started_by_name, viewer_count,
		       publisher_identity, livekit_url, COALESCE(ingress_id, ''), COALESCE(rtmp_url, ''),
		       started_at, ended_at, COALESCE(end_reason, ''), created_at, updated_at
		FROM remote_view_sessions
		WHERE id = $1
	`, sessionID)
	return scanRemoteViewSession(row)
}

func (r *RemoteViewRepository) Create(ctx context.Context, session *models.RemoteViewSession) error {
	_, err := r.db.ExecContext(ctx, `
		INSERT INTO remote_view_sessions (
			id, device_id, room_name, status, started_by, started_by_name, viewer_count,
			publisher_identity, livekit_url, ingress_id, rtmp_url, started_at, created_at, updated_at
		) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
	`, session.ID, session.DeviceID, session.RoomName, session.Status, session.StartedBy,
		session.StartedByName, session.ViewerCount, session.PublisherIdentity, session.LiveKitURL,
		session.IngressID, session.RTMPURL, session.StartedAt, session.CreatedAt, session.UpdatedAt)
	return err
}

func (r *RemoteViewRepository) IncrementViewerCount(ctx context.Context, sessionID uuid.UUID) (int, error) {
	var count int
	err := r.db.QueryRowContext(ctx, `
		UPDATE remote_view_sessions
		SET viewer_count = viewer_count + 1, updated_at = NOW()
		WHERE id = $1
		RETURNING viewer_count
	`, sessionID).Scan(&count)
	return count, err
}

func (r *RemoteViewRepository) DecrementViewerCount(ctx context.Context, sessionID uuid.UUID) (int, error) {
	var count int
	err := r.db.QueryRowContext(ctx, `
		UPDATE remote_view_sessions
		SET viewer_count = GREATEST(viewer_count - 1, 0), updated_at = NOW()
		WHERE id = $1
		RETURNING viewer_count
	`, sessionID).Scan(&count)
	return count, err
}

func (r *RemoteViewRepository) UpdateStatus(ctx context.Context, sessionID uuid.UUID, status string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions SET status = $2, updated_at = NOW() WHERE id = $1
	`, sessionID, status)
	return err
}

func (r *RemoteViewRepository) MarkStopped(ctx context.Context, sessionID uuid.UUID, reason string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET status = 'stopped', end_reason = $2, ended_at = NOW(), updated_at = NOW()
		WHERE id = $1
	`, sessionID, truncateEndReason(reason))
	return err
}

func (r *RemoteViewRepository) MarkFailed(ctx context.Context, sessionID uuid.UUID, reason string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET status = 'failed', end_reason = $2, ended_at = NOW(), updated_at = NOW()
		WHERE id = $1 AND status IN ('starting', 'active', 'stopping')
	`, sessionID, truncateEndReason(reason))
	return err
}

func truncateEndReason(reason string) string {
	reason = strings.TrimSpace(reason)
	const max = 500
	if len(reason) <= max {
		return reason
	}
	return reason[:max]
}

func (r *RemoteViewRepository) UpdateIngress(ctx context.Context, sessionID uuid.UUID, ingressID, rtmpURL string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET ingress_id = $2, rtmp_url = $3, updated_at = NOW()
		WHERE id = $1
	`, sessionID, ingressID, rtmpURL)
	return err
}

// ReviveForFallback re-opens a session that failed/stopped during WHIP→RTMP fallback race.
func (r *RemoteViewRepository) ReviveForFallback(ctx context.Context, sessionID uuid.UUID) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET status = 'starting',
		    viewer_count = GREATEST(viewer_count, 1),
		    end_reason = NULL,
		    ended_at = NULL,
		    updated_at = NOW()
		WHERE id = $1
	`, sessionID)
	return err
}

func (r *RemoteViewRepository) InsertAudit(ctx context.Context, entry *models.RemoteViewAuditLog) error {
	var detail interface{}
	if entry.Detail != "" {
		detail = entry.Detail
	}
	_, err := r.db.ExecContext(ctx, `
		INSERT INTO remote_view_audit_logs (
			id, session_id, device_id, operator_id, operator_name, action, detail, client_ip, created_at
		) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8,$9)
	`, entry.ID, entry.SessionID, entry.DeviceID, entry.OperatorID, entry.OperatorName,
		entry.Action, detail, entry.ClientIP, entry.CreatedAt)
	return err
}

func (r *RemoteViewRepository) ListAuditLogs(ctx context.Context, deviceID *uuid.UUID, page, pageSize int) ([]models.RemoteViewAuditLog, int, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 100 {
		pageSize = 20
	}
	offset := (page - 1) * pageSize

	countQuery := `SELECT COUNT(*) FROM remote_view_audit_logs a`
	listQuery := `
		SELECT a.id, a.session_id, a.device_id, a.operator_id, a.operator_name, a.action,
		       COALESCE(a.detail::text, ''), COALESCE(a.client_ip, ''), a.created_at,
		       COALESCE(d.employee_name, ''), COALESCE(d.employee_number, ''), COALESCE(d.hostname, '')
		FROM remote_view_audit_logs a
		LEFT JOIN devices d ON d.id = a.device_id
	`
	args := []interface{}{}
	argIdx := 1
	where := ""
	if deviceID != nil {
		where = fmt.Sprintf(" WHERE a.device_id = $%d", argIdx)
		args = append(args, *deviceID)
		argIdx++
	}

	var total int
	if err := r.db.QueryRowContext(ctx, countQuery+where, args...).Scan(&total); err != nil {
		return nil, 0, err
	}

	listQuery += where + fmt.Sprintf(" ORDER BY a.created_at DESC LIMIT $%d OFFSET $%d", argIdx, argIdx+1)
	args = append(args, pageSize, offset)

	rows, err := r.db.QueryContext(ctx, listQuery, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	var logs []models.RemoteViewAuditLog
	for rows.Next() {
		var item models.RemoteViewAuditLog
		var sessionID sql.NullString
		if err := rows.Scan(&item.ID, &sessionID, &item.DeviceID, &item.OperatorID, &item.OperatorName,
			&item.Action, &item.Detail, &item.ClientIP, &item.CreatedAt,
			&item.EmployeeName, &item.EmployeeNumber, &item.Hostname); err != nil {
			return nil, 0, err
		}
		if sessionID.Valid {
			if sid, err := uuid.Parse(sessionID.String); err == nil {
				item.SessionID = &sid
			}
		}
		logs = append(logs, item)
	}
	return logs, total, rows.Err()
}

func scanRemoteViewSession(row *sql.Row) (*models.RemoteViewSession, error) {
	var session models.RemoteViewSession
	var endedAt sql.NullTime
	err := row.Scan(
		&session.ID, &session.DeviceID, &session.RoomName, &session.Status,
		&session.StartedBy, &session.StartedByName, &session.ViewerCount,
		&session.PublisherIdentity, &session.LiveKitURL, &session.IngressID, &session.RTMPURL,
		&session.StartedAt, &endedAt, &session.EndReason, &session.CreatedAt, &session.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}
	if endedAt.Valid {
		session.EndedAt = &endedAt.Time
	}
	return &session, nil
}

func auditDetail(v interface{}) string {
	if v == nil {
		return ""
	}
	b, err := json.Marshal(v)
	if err != nil {
		log.Printf("[RemoteView] audit detail marshal failed: %v", err)
		return ""
	}
	return string(b)
}

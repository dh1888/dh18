package services

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"time"

	"enterprise-agent/backend/models"
)

func businessMonthCutoff(now time.Time, retentionMonths int) (time.Time, string) {
	if retentionMonths <= 0 {
		return time.Time{}, ""
	}
	year, month, _ := now.Date()
	firstOfMonth := time.Date(year, month, 1, 0, 0, 0, 0, time.UTC)
	cutoff := firstOfMonth.AddDate(0, -retentionMonths, 0)
	return cutoff, cutoff.Format("2006-01")
}

func (r *CleanupRepository) purgeExpiredBusinessRecords(
	ctx context.Context,
	policy *models.CleanupPolicy,
	uploadsDir string,
	batchSize int,
) (deleted int, freedBytes int64, err error) {
	if r.db == nil || policy == nil {
		return 0, 0, nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}
	now := models.UTCNow()

	if policy.AttendanceRetentionMonths > 0 {
		cutoff, _ := businessMonthCutoff(now, policy.AttendanceRetentionMonths)
		n, err := r.purgeBusinessBatch(ctx, "attendance_records",
			`DELETE FROM attendance_records WHERE ctid IN (
				SELECT ctid FROM attendance_records WHERE date < $1 LIMIT $2)`,
			cutoff, batchSize)
		if err != nil {
			return deleted, freedBytes, err
		}
		deleted += n
	}

	if policy.PerformanceRetentionMonths > 0 {
		_, cutoffMonth := businessMonthCutoff(now, policy.PerformanceRetentionMonths)
		n, err := r.purgeBusinessBatch(ctx, "performance_records",
			`DELETE FROM performance_records WHERE ctid IN (
				SELECT ctid FROM performance_records WHERE month < $1 LIMIT $2)`,
			cutoffMonth, batchSize)
		if err != nil {
			return deleted, freedBytes, err
		}
		deleted += n
	}

	if policy.PenaltyRetentionMonths > 0 {
		cutoff, _ := businessMonthCutoff(now, policy.PenaltyRetentionMonths)
		n, err := r.purgeBusinessBatch(ctx, "penalty_records",
			`DELETE FROM penalty_records WHERE id IN (
				SELECT id FROM penalty_records WHERE penalty_date < $1 LIMIT $2)`,
			cutoff, batchSize)
		if err != nil {
			return deleted, freedBytes, err
		}
		deleted += n
	}

	if policy.SalaryRetentionMonths > 0 {
		_, cutoffMonth := businessMonthCutoff(now, policy.SalaryRetentionMonths)
		bytes, err := r.purgeSalaryPaymentProofs(ctx, cutoffMonth, uploadsDir, batchSize)
		if err != nil {
			return deleted, freedBytes, err
		}
		freedBytes += bytes

		n, err := r.purgeBusinessBatch(ctx, "salary_records",
			`DELETE FROM salary_records WHERE ctid IN (
				SELECT ctid FROM salary_records WHERE year_month < $1 LIMIT $2)`,
			cutoffMonth, batchSize)
		if err != nil {
			return deleted, freedBytes, err
		}
		deleted += n

		n, err = r.purgeBusinessBatch(ctx, "salary_month_layouts",
			`DELETE FROM salary_month_layouts WHERE ctid IN (
				SELECT ctid FROM salary_month_layouts WHERE year_month < $1 LIMIT $2)`,
			cutoffMonth, batchSize)
		if err != nil && !isMissingRelationErr(err) {
			return deleted, freedBytes, err
		}
		deleted += n
	}

	if policy.SiteStatsRetentionMonths > 0 {
		cutoff, _ := businessMonthCutoff(now, policy.SiteStatsRetentionMonths)
		n, err := r.purgeBusinessBatch(ctx, "site_stats",
			`DELETE FROM site_stats WHERE id IN (
				SELECT id FROM site_stats WHERE stat_date < $1 LIMIT $2)`,
			cutoff, batchSize)
		if err != nil {
			return deleted, freedBytes, err
		}
		deleted += n
	}

	return deleted, freedBytes, nil
}

func (r *CleanupRepository) purgeBusinessBatch(
	ctx context.Context,
	label, deleteSQL string,
	cutoff interface{},
	batchSize int,
) (int, error) {
	total := 0
	batchNum := 0
	for {
		batchNum++
		result, err := r.db.ExecContext(ctx, deleteSQL, cutoff, batchSize)
		if err != nil {
			if isMissingRelationErr(err) {
				return 0, nil
			}
			return total, fmt.Errorf("%s: %w", label, err)
		}
		n, _ := result.RowsAffected()
		if n == 0 {
			break
		}
		total += int(n)
		log.Printf("[Cleanup] %s batch %d: deleted %d rows", label, batchNum, n)
		if n < int64(batchSize) {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if total > 0 {
		log.Printf("[Cleanup] %s: deleted %d rows total", label, total)
	}
	return total, nil
}

func (r *CleanupRepository) purgeSalaryPaymentProofs(
	ctx context.Context,
	cutoffMonth, uploadsDir string,
	batchSize int,
) (int64, error) {
	if r.db == nil || cutoffMonth == "" {
		return 0, nil
	}
	var freed int64
	for {
		rows, err := r.db.QueryContext(ctx, `
			SELECT id, file_path FROM salary_payment_proofs
			WHERE year_month < $1
			LIMIT $2`, cutoffMonth, batchSize)
		if err != nil {
			if isMissingRelationErr(err) {
				return freed, nil
			}
			return freed, err
		}

		type proofRow struct {
			id, path string
		}
		var batch []proofRow
		for rows.Next() {
			var item proofRow
			if err := rows.Scan(&item.id, &item.path); err != nil {
				continue
			}
			batch = append(batch, item)
		}
		rows.Close()
		if len(batch) == 0 {
			break
		}

		ids := make([]string, len(batch))
		for i, item := range batch {
			ids[i] = item.id
			if item.path == "" {
				continue
			}
			localPath := filepath.Join(uploadsDir, filepath.FromSlash(normalizeStoragePath(item.path)))
			if info, statErr := os.Stat(localPath); statErr == nil {
				freed += info.Size()
			}
			if err := r.deleteStoredFile(ctx, uploadsDir, item.path); err != nil {
				log.Printf("[Cleanup] salary proof file delete failed (%s): %v", item.path, err)
			}
		}

		ph := make([]string, len(ids))
		args := make([]interface{}, len(ids))
		for i, id := range ids {
			ph[i] = fmt.Sprintf("$%d", i+1)
			args[i] = id
		}
		delSQL := fmt.Sprintf(`DELETE FROM salary_payment_proofs WHERE id IN (%s)`, joinStrings(ph))
		if _, err := r.db.ExecContext(ctx, delSQL, args...); err != nil {
			return freed, err
		}
		if len(batch) < batchSize {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	return freed, nil
}

func joinStrings(items []string) string {
	out := ""
	for i, s := range items {
		if i > 0 {
			out += ","
		}
		out += s
	}
	return out
}

func (r *CleanupRepository) countBusinessRecords(ctx context.Context) models.BusinessRecordStats {
	stats := models.BusinessRecordStats{}
	if r.db == nil {
		return stats
	}
	stats.AttendanceCount = countTableRows(ctx, r.db, "attendance_records")
	stats.PerformanceCount = countTableRows(ctx, r.db, "performance_records")
	stats.PenaltyCount = countTableRows(ctx, r.db, "penalty_records")
	stats.SalaryCount = countTableRows(ctx, r.db, "salary_records")
	stats.SiteStatsCount = countTableRows(ctx, r.db, "site_stats")
	stats.TotalCount = stats.AttendanceCount + stats.PerformanceCount + stats.PenaltyCount + stats.SalaryCount + stats.SiteStatsCount
	return stats
}

package services

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"
)

type TelegramDiscoveredChat struct {
	ChatID    string `json:"chatId"`
	ChatTitle string `json:"chatTitle"`
	ChatType  string `json:"chatType"`
	Bound     bool   `json:"bound"`
	Source    string `json:"source,omitempty"`
}

func (s *WorkforceTelegramService) RecordDiscoveredChat(ctx context.Context, chatID, chatTitle, chatType string) error {
	return RecordTelegramDiscoveredChat(ctx, s.db, chatID, chatTitle, chatType)
}

// RecordTelegramDiscoveredChat persists a chat seen via join/message updates.
// Used by attendance worker and push discover so joining a group is enough.
func RecordTelegramDiscoveredChat(ctx context.Context, db *sql.DB, chatID, chatTitle, chatType string) error {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" || db == nil {
		return nil
	}
	chatType = strings.TrimSpace(chatType)
	if chatType != "group" && chatType != "supergroup" && chatType != "channel" {
		return nil
	}
	title := strings.TrimSpace(chatTitle)
	_, err := db.ExecContext(ctx, `
		INSERT INTO wf_telegram_discovered_chats (chat_id, chat_title, chat_type, first_seen_at, last_seen_at)
		VALUES ($1, $2, $3, NOW(), NOW())
		ON CONFLICT (chat_id) DO UPDATE SET
			chat_title = CASE WHEN EXCLUDED.chat_title <> '' THEN EXCLUDED.chat_title ELSE wf_telegram_discovered_chats.chat_title END,
			chat_type = CASE WHEN EXCLUDED.chat_type <> '' THEN EXCLUDED.chat_type ELSE wf_telegram_discovered_chats.chat_type END,
			last_seen_at = NOW()`, chatID, title, chatType)
	return err
}

func (s *WorkforceTelegramService) DiscoverGroups(ctx context.Context) ([]TelegramDiscoveredChat, error) {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return nil, err
	}
	if !settings.HasBotToken {
		return nil, fmt.Errorf("请先保存 Bot Token")
	}
	if !settings.Enabled {
		return nil, fmt.Errorf("请先启用 Telegram")
	}

	bound := map[string]bool{}
	rows, err := s.db.QueryContext(ctx, `SELECT chat_id FROM wf_telegram_groups`)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var id string
		if rows.Scan(&id) == nil {
			bound[strings.TrimSpace(id)] = true
		}
	}
	rows.Close()

	token, _ := s.GetBotTokenForWorker(ctx)
	raw, err := DiscoverTelegramChats(ctx, s.db, token)
	if err != nil {
		return nil, err
	}

	out := make([]TelegramDiscoveredChat, 0, len(raw))
	seen := map[string]bool{}
	for _, g := range raw {
		id := strings.TrimSpace(g["chatId"])
		if id == "" {
			continue
		}
		seen[id] = true
		item := TelegramDiscoveredChat{
			ChatID:    id,
			ChatTitle: g["groupName"],
			ChatType:  g["chatType"],
			Bound:     bound[id],
			Source:    g["source"],
		}
		if item.ChatTitle == "" {
			item.ChatTitle = id
		}
		out = append(out, item)
	}

	for chatID := range bound {
		if seen[chatID] {
			continue
		}
		item := TelegramDiscoveredChat{ChatID: chatID, Bound: true, Source: "bound"}
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(chat_title,'') FROM wf_telegram_groups WHERE chat_id = $1`, chatID).Scan(&item.ChatTitle)
		if item.ChatTitle == "" {
			item.ChatTitle = chatID
		}
		out = append(out, item)
	}

	sort.Slice(out, func(i, j int) bool {
		if out[i].Bound != out[j].Bound {
			return !out[i].Bound
		}
		return out[i].ChatTitle < out[j].ChatTitle
	})
	return out, nil
}

type tgUpdatesResponse struct {
	OK     bool `json:"ok"`
	Result []struct {
		Message *struct {
			Chat struct {
				ID    int64  `json:"id"`
				Type  string `json:"type"`
				Title string `json:"title"`
			} `json:"chat"`
		} `json:"message"`
		ChannelPost *struct {
			Chat struct {
				ID    int64  `json:"id"`
				Type  string `json:"type"`
				Title string `json:"title"`
			} `json:"chat"`
		} `json:"channel_post"`
		MyChatMember *struct {
			Chat struct {
				ID    int64  `json:"id"`
				Type  string `json:"type"`
				Title string `json:"title"`
			} `json:"chat"`
		} `json:"my_chat_member"`
	} `json:"result"`
}

// DiscoverTelegramChats merges persisted join/message history with a live getUpdates scan.
// Telegram Bot API cannot list chats; joining a group (my_chat_member) is enough when
// recorded. Live scan may 409 if another poller owns the token — history still returns.
func DiscoverTelegramChats(ctx context.Context, db *sql.DB, token string) ([]map[string]string, error) {
	merged := map[string]map[string]string{}

	if db != nil {
		discRows, err := db.QueryContext(ctx, `
			SELECT chat_id, COALESCE(chat_title,''), COALESCE(chat_type,'')
			FROM wf_telegram_discovered_chats
			ORDER BY last_seen_at DESC`)
		if err == nil {
			for discRows.Next() {
				var id, title, chatType string
				if discRows.Scan(&id, &title, &chatType) != nil {
					continue
				}
				id = strings.TrimSpace(id)
				if id == "" {
					continue
				}
				name := strings.TrimSpace(title)
				if name == "" {
					name = id
				}
				merged[id] = map[string]string{
					"chatId":    id,
					"groupName": name,
					"chatType":  chatType,
					"source":    "history",
				}
			}
			discRows.Close()
		}
	}

	token = strings.TrimSpace(token)
	if token != "" {
		live, scanErr := telegramScanRecentChats(token)
		if scanErr == nil {
			for _, g := range live {
				id := strings.TrimSpace(g["chatId"])
				if id == "" {
					continue
				}
				existing, ok := merged[id]
				if ok {
					if existing["groupName"] == "" || existing["groupName"] == id {
						existing["groupName"] = g["groupName"]
					}
					if existing["chatType"] == "" {
						existing["chatType"] = g["chatType"]
					}
					if existing["source"] == "history" {
						existing["source"] = "history,live"
					}
					merged[id] = existing
				} else {
					g["source"] = "live"
					merged[id] = g
				}
				_ = RecordTelegramDiscoveredChat(ctx, db, id, g["groupName"], g["chatType"])
			}
		}
	}

	out := make([]map[string]string, 0, len(merged))
	for _, v := range merged {
		out = append(out, v)
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i]["groupName"] < out[j]["groupName"]
	})
	return out, nil
}

func telegramScanRecentChats(token string) ([]map[string]string, error) {
	client := &http.Client{Timeout: 12 * time.Second}
	// Explicitly request join events and channel posts — a plain group message is not required.
	url := fmt.Sprintf(
		"https://api.telegram.org/bot%s/getUpdates?limit=100&timeout=0&allowed_updates=%s",
		token,
		"%5B%22message%22%2C%22channel_post%22%2C%22my_chat_member%22%5D",
	)
	resp, err := client.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusConflict {
		return nil, fmt.Errorf("bot is polling updates")
	}
	var out tgUpdatesResponse
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return nil, err
	}
	if !out.OK {
		return nil, fmt.Errorf("getUpdates failed")
	}
	seen := map[string]map[string]string{}
	addChat := func(id int64, chatType, title string) {
		if chatType != "group" && chatType != "supergroup" && chatType != "channel" {
			return
		}
		key := strconv.FormatInt(id, 10)
		if _, ok := seen[key]; ok {
			return
		}
		name := strings.TrimSpace(title)
		if name == "" {
			name = key
		}
		seen[key] = map[string]string{
			"chatId":    key,
			"groupName": name,
			"chatType":  chatType,
		}
	}
	for _, u := range out.Result {
		if u.Message != nil {
			c := u.Message.Chat
			addChat(c.ID, c.Type, c.Title)
		}
		if u.ChannelPost != nil {
			c := u.ChannelPost.Chat
			addChat(c.ID, c.Type, c.Title)
		}
		if u.MyChatMember != nil {
			c := u.MyChatMember.Chat
			addChat(c.ID, c.Type, c.Title)
		}
	}
	list := make([]map[string]string, 0, len(seen))
	for _, v := range seen {
		list = append(list, v)
	}
	return list, nil
}

package services

import (
	"context"
	"database/sql"
	"log"
	"strings"
	"time"

	"github.com/google/uuid"
)

const (
	telegramDailyRetentionDays   = 30
	telegramMonthlyRetentionDays = 40
)

func StartTelegramMaintenanceScheduler(ctx context.Context, svc *WorkforceTelegramService) {
	if svc == nil {
		return
	}
	go func() {
		hourly := time.NewTicker(time.Hour)
		daily := time.NewTicker(24 * time.Hour)
		defer hourly.Stop()
		defer daily.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-hourly.C:
				svc.RecoverMissedDailyResets(context.Background())
				svc.RecoverExpiredActivities(context.Background())
				svc.CloseExpiredWorkSessionsGlobal(context.Background())
			case <-daily.C:
				if err := svc.CleanupTelegramRetention(context.Background()); err != nil {
					log.Printf("[Telegram] retention cleanup: %v", err)
				}
				svc.MaybePushMonthlyArchive(context.Background())
			}
		}
	}()
}

func (s *WorkforceTelegramService) CleanupTelegramRetention(ctx context.Context) error {
	if !TelegramAttendanceEnabled() {
		return nil
	}
	cutoff := time.Now().AddDate(0, 0, -telegramDailyRetentionDays).Format("2006-01-02")
	monthCutoff := time.Now().AddDate(0, 0, -telegramMonthlyRetentionDays).Format("2006-01")
	_, err := s.db.ExecContext(ctx, `
		DELETE FROM wf_tg_activity_sessions
		WHERE status = 'closed' AND attendance_date < $1::date`, cutoff)
	if err != nil {
		return err
	}
	_, _ = s.db.ExecContext(ctx, `DELETE FROM wf_tg_monthly_activity_stats WHERE year_month < $1`, monthCutoff)
	_, _ = s.db.ExecContext(ctx, `DELETE FROM wf_tg_monthly_work_stats WHERE year_month < $1`, monthCutoff)
	log.Printf("[Telegram] retention cleanup before %s", cutoff)
	return nil
}

func (s *WorkforceTelegramService) MaybePushMonthlyArchive(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return
	}
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)
	if now.Day() != 1 || now.Hour() != 15 {
		return
	}
	prev := now.AddDate(0, -1, 0).Format("2006-01")
	data, filename, err := s.ExportMonthlyArchiveXLSX(ctx, prev)
	if err != nil || len(data) == 0 {
		log.Printf("[Telegram] monthly archive export %s: %v", prev, err)
		return
	}
	groups, _ := s.ListGroups(ctx)
	caption := "📊 月度归档报表 " + prev
	for _, g := range groups {
		if g.Enabled && g.ChatID != "" {
			s.PushDocumentToChatTargets(ctx, g.ChatID, filename, data, caption, false)
		}
	}
}

func (s *WorkforceTelegramService) ExportMonthlyArchiveXLSX(ctx context.Context, yearMonth string) ([]byte, string, error) {
	t, err := time.Parse("2006-01", yearMonth)
	if err != nil {
		return nil, "", err
	}
	dateFrom := t.Format("2006-01-02")
	dateTo := t.AddDate(0, 1, -1).Format("2006-01-02")
	return s.ExportAttendanceXLSX(ctx, dateFrom, dateTo, "")
}

func (s *WorkforceTelegramService) SetActivityTelegramMessageID(ctx context.Context, sessionID uuid.UUID, messageID int64) {
	if sessionID == uuid.Nil || messageID <= 0 {
		return
	}
	_, _ = s.db.ExecContext(ctx, `
		UPDATE wf_tg_activity_sessions SET telegram_message_id = $2 WHERE id = $1`, sessionID, messageID)
}

func (s *WorkforceTelegramService) GetActivitySessionTelegramMessageID(ctx context.Context, sessionID uuid.UUID) int64 {
	return s.activitySessionTelegramMessageID(ctx, sessionID)
}

func (s *WorkforceTelegramService) getEmployeeLastGroupBotMessageID(ctx context.Context, chatID string, empID uuid.UUID) int64 {
	if empID == uuid.Nil || strings.TrimSpace(chatID) == "" {
		return 0
	}
	var msgID sql.NullInt64
	_ = s.db.QueryRowContext(ctx, `
		SELECT last_group_bot_message_id FROM employee_telegram_bindings
		WHERE employee_id = $1 AND status = 1 AND COALESCE(chat_id,'') = $2`,
		empID, strings.TrimSpace(chatID)).Scan(&msgID)
	if msgID.Valid && msgID.Int64 > 0 {
		return msgID.Int64
	}
	return 0
}

func (s *WorkforceTelegramService) setEmployeeLastGroupBotMessageID(ctx context.Context, chatID string, empID uuid.UUID, messageID int64) {
	if empID == uuid.Nil || messageID <= 0 || strings.TrimSpace(chatID) == "" {
		return
	}
	_, _ = s.db.ExecContext(ctx, `
		UPDATE employee_telegram_bindings
		SET last_group_bot_message_id = $3
		WHERE employee_id = $1 AND status = 1 AND COALESCE(chat_id,'') = $2`,
		empID, strings.TrimSpace(chatID), messageID)
}

func (s *WorkforceTelegramService) hasOpenNightContinuation(ctx context.Context, empID uuid.UUID, recordDate string) bool {
	t, err := time.Parse("2006-01-02", recordDate)
	if err != nil {
		return false
	}
	next := t.AddDate(0, 0, 1).Format("2006-01-02")
	var count int
	_ = s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM work_sessions
		WHERE employee_id = $1 AND shift_type = 'night' AND status = 'open'
		  AND attendance_date IN ($2::date, $3::date)`, empID, recordDate, next).Scan(&count)
	return count > 0 && time.Now().Hour() < 12
}

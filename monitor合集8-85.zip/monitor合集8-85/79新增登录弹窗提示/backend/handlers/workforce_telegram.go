package handlers

import (
	"database/sql"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/internal/tgbot"
	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type WorkforceTelegramHandler struct {
	db        *sql.DB
	telegram  *services.WorkforceTelegramService
	wsHub     *services.WebSocketHub
}

func NewWorkforceTelegramHandler(db *sql.DB, telegram *services.WorkforceTelegramService, wsHub *services.WebSocketHub) *WorkforceTelegramHandler {
	return &WorkforceTelegramHandler{db: db, telegram: telegram, wsHub: wsHub}
}

func (h *WorkforceTelegramHandler) workerAuth(c *gin.Context) bool {
	secret := strings.TrimSpace(c.GetHeader("X-Telegram-Worker-Secret"))
	if secret == "" {
		secret = strings.TrimSpace(c.GetHeader("Authorization"))
		secret = strings.TrimPrefix(secret, "Bearer ")
	}
	if err := h.telegram.ValidateWorkerSecret(c.Request.Context(), secret); err != nil {
		models.SendError(c, 401, 1002, "invalid worker secret")
		return false
	}
	return true
}

func (h *WorkforceTelegramHandler) GetSettings(c *gin.Context) {
	settings, err := h.telegram.GetSettings(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"id":               settings.ID,
		"enabled":          settings.Enabled,
		"botUsername":      settings.BotUsername,
		"botId":            settings.BotID,
		"hasBotToken":      settings.HasBotToken,
		"timezone":         settings.Timezone,
		"dayStart":         settings.DayStart,
		"dayEnd":           settings.DayEnd,
		"graceMinutes":         settings.GraceMinutes,
		"graceMinutesAfter":    settings.GraceMinutesAfter,
		"checkInGraceBefore":   settings.GraceMinutes,
		"checkInGraceAfter":    settings.GraceMinutesAfter,
		"checkOutGraceBefore":  settings.CheckOutGraceBefore,
		"checkOutGraceAfter":   settings.WorkEndGraceAfter,
		"lateToleranceMinutes": settings.LateToleranceMinutes,
		"earlyLeaveToleranceMinutes": settings.EarlyLeaveToleranceMinutes,
		"workEndGraceAfter":    settings.WorkEndGraceAfter,
		"dualShiftEnabled": settings.DualShiftEnabled,
		"nightStart":       settings.NightStart,
		"nightEnd":         settings.NightEnd,
		"dailyResetTime":   settings.DailyResetTime,
		"dailyResetEnabled": settings.DailyResetEnabled,
		"dailyResetExecutionOffsetMinutes": settings.DailyResetExecutionOffsetMinutes,
		"shiftWindowDisabled": settings.ShiftWindowDisabled,
		"workEndGraceMinutes": settings.EarlyLeaveToleranceMinutes,
		"requirePCLogin":           settings.RequirePCLogin,
		"adminTelegramUserIds":     settings.AdminTelegramUserIDs,
		"botMode":              settings.BotMode,
		"webhookUrl":           settings.WebhookURL,
		"hasWebhookSecret":     settings.HasWebhookSecret,
		"botUiLang":            settings.BotUILang,
		"updatedAt":        models.FormatUTC(settings.UpdatedAt),
		"moduleEnabled":          services.TelegramAttendanceEnabled(),
		"captureLinkedToCheckin": services.CaptureLinkedToCheckin(c.Request.Context(), h.db),
		"captureLinkedEnvOverride": func() bool {
			_, explicit := services.CaptureLinkedToCheckinEnvOverride()
			return explicit
		}(),
	})
}

func (h *WorkforceTelegramHandler) UpdateSettings(c *gin.Context) {
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	settings, err := h.telegram.UpdateSettings(c.Request.Context(), req)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE", "更新 Telegram 考勤配置", settings.ID.String(), "Telegram")
	models.Send(c, 200, 0, "success", gin.H{
		"enabled":          settings.Enabled,
		"botUsername":      settings.BotUsername,
		"botId":            settings.BotID,
		"hasBotToken":      settings.HasBotToken,
		"timezone":         settings.Timezone,
		"dayStart":         settings.DayStart,
		"dayEnd":           settings.DayEnd,
		"graceMinutes":         settings.GraceMinutes,
		"graceMinutesAfter":    settings.GraceMinutesAfter,
		"checkInGraceBefore":   settings.GraceMinutes,
		"checkInGraceAfter":    settings.GraceMinutesAfter,
		"checkOutGraceBefore":  settings.CheckOutGraceBefore,
		"checkOutGraceAfter":   settings.WorkEndGraceAfter,
		"lateToleranceMinutes": settings.LateToleranceMinutes,
		"earlyLeaveToleranceMinutes": settings.EarlyLeaveToleranceMinutes,
		"workEndGraceAfter":    settings.WorkEndGraceAfter,
		"dualShiftEnabled": settings.DualShiftEnabled,
		"nightStart":       settings.NightStart,
		"nightEnd":         settings.NightEnd,
		"dailyResetTime":   settings.DailyResetTime,
		"dailyResetEnabled": settings.DailyResetEnabled,
		"dailyResetExecutionOffsetMinutes": settings.DailyResetExecutionOffsetMinutes,
		"shiftWindowDisabled": settings.ShiftWindowDisabled,
		"workEndGraceMinutes": settings.EarlyLeaveToleranceMinutes,
		"requirePCLogin":           settings.RequirePCLogin,
		"captureLinkedToCheckin": settings.CaptureLinkedToCheckin,
		"adminTelegramUserIds":     settings.AdminTelegramUserIDs,
		"botMode":              settings.BotMode,
		"webhookUrl":           settings.WebhookURL,
		"hasWebhookSecret":     settings.HasWebhookSecret,
		"botUiLang":            settings.BotUILang,
		"updatedAt":        models.FormatUTC(settings.UpdatedAt),
	})
}

func (h *WorkforceTelegramHandler) RegenerateWorkerSecret(c *gin.Context) {
	settings, err := h.telegram.UpdateSettings(c.Request.Context(), map[string]interface{}{
		"regenerateWorkerSecret": true,
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	var secret sql.NullString
	_ = h.db.QueryRowContext(c.Request.Context(), `
		SELECT worker_secret FROM wf_telegram_settings WHERE id = $1`, settings.ID).Scan(&secret)
	if !secret.Valid {
		models.SendError(c, 500, 5000, "failed to generate worker secret")
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE", "重新生成 Telegram Worker Secret", settings.ID.String(), "Telegram")
	models.Send(c, 200, 0, "success", gin.H{"workerSecret": secret.String})
}

func (h *WorkforceTelegramHandler) RegenerateWebhookSecret(c *gin.Context) {
	settings, err := h.telegram.UpdateSettings(c.Request.Context(), map[string]interface{}{
		"regenerateWebhookSecret": true,
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	secret, err := h.telegram.GetWebhookSecret(c.Request.Context())
	if err != nil || secret == "" {
		models.SendError(c, 500, 5000, "failed to generate webhook secret")
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE", "重新生成 Telegram Webhook Secret", settings.ID.String(), "Telegram")
	models.Send(c, 200, 0, "success", gin.H{"webhookSecret": secret})
}

func (h *WorkforceTelegramHandler) GenerateWorkerPairing(c *gin.Context) {
	if !services.TelegramAttendanceEnabled() {
		models.SendError(c, 400, 1001, "Telegram 考勤模块已禁用")
		return
	}
	code, expiresAt, err := h.telegram.GenerateWorkerPairing(c.Request.Context())
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE", "生成 Telegram Worker 配对码", code, "Telegram")
	models.Send(c, 200, 0, "success", gin.H{
		"pairingCode": code,
		"expiresAt":   models.FormatUTC(expiresAt),
	})
}

func (h *WorkforceTelegramHandler) GetWorkerConnection(c *gin.Context) {
	info, err := h.telegram.GetWorkerConnectionInfo(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	resp := gin.H{
		"online":           info.Online,
		"hasWorkerSecret":  info.HasWorkerSecret,
		"hasActivePairing": info.HasActivePairing,
		"embedded":         services.TelegramBotEmbedded(),
	}
	if info.LastSeenAt != nil {
		resp["lastSeenAt"] = models.FormatUTC(*info.LastSeenAt)
	}
	if info.PairingExpiresAt != nil {
		resp["pairingExpiresAt"] = models.FormatUTC(*info.PairingExpiresAt)
	}
	models.Send(c, 200, 0, "success", resp)
}

func (h *WorkforceTelegramHandler) WorkerPair(c *gin.Context) {
	if !services.TelegramAttendanceEnabled() {
		models.SendError(c, 503, 5000, "Telegram attendance disabled")
		return
	}
	var req struct {
		PairingCode string `json:"pairingCode" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	workerSecret, botToken, err := h.telegram.PairWorker(c.Request.Context(), req.PairingCode)
	if err != nil {
		models.SendError(c, 401, 1002, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"workerSecret": workerSecret,
		"botToken":     botToken,
	})
}

func (h *WorkforceTelegramHandler) WorkerHeartbeat(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	if err := h.telegram.TouchWorkerHeartbeat(c.Request.Context()); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) TelegramWebhook(c *gin.Context) {
	if !services.TelegramAttendanceEnabled() {
		c.Status(http.StatusNotFound)
		return
	}
	body, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.Status(http.StatusBadRequest)
		return
	}
	log.Printf("[TelegramWebhook] received %d bytes", len(body))
	cfg := tgbot.ActiveConfig()
	if strings.TrimSpace(cfg.BotToken) == "" {
		port := strings.TrimSpace(os.Getenv("PORT"))
		if port == "" {
			port = "8080"
		}
		opts, err := h.telegram.BuildTelegramBotOptions(port)
		if err != nil {
			c.Status(http.StatusServiceUnavailable)
			return
		}
		cfg = tgbot.ConfigFromOptions(opts)
	}
	if err := tgbot.HandleWebhookBody(cfg, c.GetHeader("X-Telegram-Bot-Api-Secret-Token"), body); err != nil {
		if err.Error() == "forbidden" {
			c.Status(http.StatusForbidden)
			return
		}
		c.Status(http.StatusBadRequest)
		return
	}
	c.Status(http.StatusOK)
}

func (h *WorkforceTelegramHandler) DiscoverGroups(c *gin.Context) {
	items, err := h.telegram.DiscoverGroups(c.Request.Context())
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, item := range items {
		out = append(out, gin.H{
			"chatId":    item.ChatID,
			"groupName": item.ChatTitle,
			"chatTitle": item.ChatTitle,
			"chatType":  item.ChatType,
			"bound":     item.Bound,
			"source":    item.Source,
		})
	}
	models.Send(c, 200, 0, "success", out)
}

func (h *WorkforceTelegramHandler) WorkerRecordChatSeen(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		ChatID    string `json:"chatId" binding:"required"`
		ChatTitle string `json:"chatTitle"`
		ChatType  string `json:"chatType"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if err := h.telegram.RecordDiscoveredChat(c.Request.Context(), req.ChatID, req.ChatTitle, req.ChatType); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) ListGroups(c *gin.Context) {
	items, err := h.telegram.ListGroups(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, item := range items {
		row := gin.H{
			"id":        item.ID,
			"chatId":    item.ChatID,
			"chatTitle": item.ChatTitle,
			"enabled":   item.Enabled,
			"createdAt": models.FormatUTC(item.CreatedAt),
		}
		if item.ShiftGraceBefore != nil {
			row["shiftGraceBefore"] = *item.ShiftGraceBefore
		}
		if item.ShiftGraceAfter != nil {
			row["shiftGraceAfter"] = *item.ShiftGraceAfter
		}
		if item.CheckOutGraceBefore != nil {
			row["checkOutGraceBefore"] = *item.CheckOutGraceBefore
			row["workEndGraceBefore"] = *item.CheckOutGraceBefore
		}
		if item.CheckOutGraceAfter != nil {
			row["checkOutGraceAfter"] = *item.CheckOutGraceAfter
			row["workEndGraceAfter"] = *item.CheckOutGraceAfter
		}
		if item.LateToleranceMinutes != nil {
			row["lateToleranceMinutes"] = *item.LateToleranceMinutes
		}
		if item.EarlyLeaveToleranceMinutes != nil {
			row["earlyLeaveToleranceMinutes"] = *item.EarlyLeaveToleranceMinutes
		}
		if item.DailyResetTime != "" {
			row["dailyResetTime"] = item.DailyResetTime
		}
		if item.BotUILang != "" {
			row["botUiLang"] = item.BotUILang
		}
		out = append(out, row)
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) UpsertGroup(c *gin.Context) {
	var req struct {
		ChatID                     string `json:"chatId" binding:"required"`
		ChatTitle                  string `json:"chatTitle"`
		Enabled                    *bool  `json:"enabled"`
		ShiftGraceBefore           *int   `json:"shiftGraceBefore"`
		ShiftGraceAfter            *int   `json:"shiftGraceAfter"`
		CheckInGraceBefore           *int   `json:"checkInGraceBefore"`
		CheckInGraceAfter            *int   `json:"checkInGraceAfter"`
		CheckOutGraceBefore          *int   `json:"checkOutGraceBefore"`
		CheckOutGraceAfter           *int   `json:"checkOutGraceAfter"`
		WorkEndGraceBefore           *int   `json:"workEndGraceBefore"`
		WorkEndGraceAfter            *int   `json:"workEndGraceAfter"`
		LateToleranceMinutes         *int   `json:"lateToleranceMinutes"`
		EarlyLeaveToleranceMinutes   *int   `json:"earlyLeaveToleranceMinutes"`
		DailyResetTime               string `json:"dailyResetTime"`
		BotUILang                    string `json:"botUiLang"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	enabled := true
	if req.Enabled != nil {
		enabled = *req.Enabled
	}
	overrides := map[string]interface{}{}
	if req.ShiftGraceBefore != nil {
		overrides["shiftGraceBefore"] = *req.ShiftGraceBefore
	}
	if req.CheckInGraceBefore != nil {
		overrides["checkInGraceBefore"] = *req.CheckInGraceBefore
	}
	if req.ShiftGraceAfter != nil {
		overrides["shiftGraceAfter"] = *req.ShiftGraceAfter
	}
	if req.CheckInGraceAfter != nil {
		overrides["checkInGraceAfter"] = *req.CheckInGraceAfter
	}
	if req.CheckOutGraceBefore != nil {
		overrides["checkOutGraceBefore"] = *req.CheckOutGraceBefore
	}
	if req.WorkEndGraceBefore != nil {
		overrides["workEndGraceBefore"] = *req.WorkEndGraceBefore
	}
	if req.CheckOutGraceAfter != nil {
		overrides["checkOutGraceAfter"] = *req.CheckOutGraceAfter
	}
	if req.WorkEndGraceAfter != nil {
		overrides["workEndGraceAfter"] = *req.WorkEndGraceAfter
	}
	if req.LateToleranceMinutes != nil {
		overrides["lateToleranceMinutes"] = *req.LateToleranceMinutes
	}
	if req.EarlyLeaveToleranceMinutes != nil {
		overrides["earlyLeaveToleranceMinutes"] = *req.EarlyLeaveToleranceMinutes
	}
	if strings.TrimSpace(req.DailyResetTime) != "" {
		overrides["dailyResetTime"] = strings.TrimSpace(req.DailyResetTime)
	}
	if strings.TrimSpace(req.BotUILang) != "" {
		overrides["botUiLang"] = strings.TrimSpace(req.BotUILang)
	}
	row, err := h.telegram.UpsertGroup(c.Request.Context(), req.ChatID, req.ChatTitle, enabled, overrides)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE", fmt.Sprintf("绑定 Telegram 群 %s", req.ChatID), row.ID.String(), req.ChatTitle)
	resp := gin.H{
		"id": row.ID, "chatId": row.ChatID, "chatTitle": row.ChatTitle, "enabled": row.Enabled,
	}
	if row.ShiftGraceBefore != nil {
		resp["shiftGraceBefore"] = *row.ShiftGraceBefore
	}
	if row.ShiftGraceAfter != nil {
		resp["shiftGraceAfter"] = *row.ShiftGraceAfter
	}
	if row.CheckOutGraceBefore != nil {
		resp["checkOutGraceBefore"] = *row.CheckOutGraceBefore
		resp["workEndGraceBefore"] = *row.CheckOutGraceBefore
	}
	if row.CheckOutGraceAfter != nil {
		resp["checkOutGraceAfter"] = *row.CheckOutGraceAfter
		resp["workEndGraceAfter"] = *row.CheckOutGraceAfter
	}
	if row.LateToleranceMinutes != nil {
		resp["lateToleranceMinutes"] = *row.LateToleranceMinutes
	}
	if row.EarlyLeaveToleranceMinutes != nil {
		resp["earlyLeaveToleranceMinutes"] = *row.EarlyLeaveToleranceMinutes
	}
	if row.DailyResetTime != "" {
		resp["dailyResetTime"] = row.DailyResetTime
	}
	if row.BotUILang != "" {
		resp["botUiLang"] = row.BotUILang
	}
	models.Send(c, 200, 0, "success", resp)
}

func (h *WorkforceTelegramHandler) DeleteGroup(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.telegram.DeleteGroup(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	Log(c, "DELETE", "TELEGRAM_ATTENDANCE", "删除 Telegram 群绑定", id.String(), id.String())
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) ListBindings(c *gin.Context) {
	items, err := h.telegram.ListBindings(c.Request.Context(), c.Query("search"))
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, item := range items {
		out = append(out, gin.H{
			"id":               item.ID,
			"employeeId":       item.EmployeeID,
			"employeeName":     item.EmployeeName,
			"employeeCode":     item.EmployeeCode,
			"attendanceMode":   item.AttendanceMode,
			"channel":          services.TelegramChannelPersonal,
			"telegramUserId":   item.TelegramUserID,
			"telegramUsername": item.TelegramUsername,
			"chatId":           item.ChatID,
			"boundAt":          models.FormatUTC(item.BoundAt),
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) CreateBinding(c *gin.Context) {
	var req struct {
		EmployeeID       string `json:"employeeId" binding:"required"`
		TelegramUserID   int64  `json:"telegramUserId" binding:"required"`
		TelegramUsername string `json:"telegramUsername"`
		ChatID           string `json:"chatId"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	empID, err := uuid.Parse(req.EmployeeID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid employee id")
		return
	}
	row, err := h.telegram.CreateBinding(c.Request.Context(), empID, req.TelegramUserID, req.TelegramUsername, req.ChatID)
	if err != nil {
		if errors.Is(err, services.ErrEmployeeNotFound) {
			models.SendError(c, 404, 2001, "员工不存在")
			return
		}
		if strings.Contains(err.Error(), "duplicate") || strings.Contains(err.Error(), "unique") {
			models.SendError(c, 400, 1001, "该 Telegram 账号或员工已绑定")
			return
		}
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "CREATE", "TELEGRAM_ATTENDANCE",
		fmt.Sprintf("绑定 Telegram：%s ↔ %d", row.EmployeeName, row.TelegramUserID),
		row.ID.String(), row.EmployeeName)
	models.Send(c, 200, 0, "success", gin.H{
		"id": row.ID, "employeeId": row.EmployeeID, "employeeName": row.EmployeeName,
		"telegramUserId": row.TelegramUserID, "telegramUsername": row.TelegramUsername,
	})
}

func (h *WorkforceTelegramHandler) DeleteBinding(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.telegram.DeleteBinding(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	Log(c, "DELETE", "TELEGRAM_ATTENDANCE", "解除 Telegram 绑定", id.String(), id.String())
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) ResetBindingDaily(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	binding, err := h.telegram.GetBindingByID(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "binding not found")
		return
	}
	result, err := h.telegram.ResetEmployeeDailyAttendance(c.Request.Context(), binding.EmployeeID, binding.ChatID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE",
		fmt.Sprintf("重置 %s 当日考勤（业务日 %s）", binding.EmployeeName, result.BusinessDate),
		id.String(), binding.EmployeeName)
	models.Send(c, 200, 0, "success", result)
}

func (h *WorkforceTelegramHandler) ResetEmployeeDaily(c *gin.Context) {
	var req struct {
		EmployeeID string `json:"employeeId" binding:"required"`
		ChatID     string `json:"chatId"`
		DeviceID   string `json:"deviceId"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	empID, err := uuid.Parse(req.EmployeeID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid employee id")
		return
	}
	chatID := strings.TrimSpace(req.ChatID)
	if chatID == "" && strings.TrimSpace(req.DeviceID) != "" {
		if deviceID, parseErr := uuid.Parse(req.DeviceID); parseErr == nil {
			_, _, chatID, _ = h.telegram.GetDeviceTelegramBindingByDevice(c.Request.Context(), deviceID)
		}
	}
	var empName string
	_ = h.db.QueryRowContext(c.Request.Context(), `SELECT name FROM employees WHERE id = $1`, empID).Scan(&empName)
	result, err := h.telegram.ResetEmployeeDailyAttendance(c.Request.Context(), empID, chatID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE",
		fmt.Sprintf("重置 %s 当日考勤（业务日 %s）", empName, result.BusinessDate),
		empID.String(), empName)
	models.Send(c, 200, 0, "success", result)
}

func (h *WorkforceTelegramHandler) ResetDeviceBindingDaily(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	row, err := h.telegram.GetDeviceTelegramBindingByID(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "device binding not found")
		return
	}
	empID, err := h.telegram.ResolveLoggedInEmployeeOnDevice(c.Request.Context(), row.DeviceID)
	if err != nil {
		if errors.Is(err, services.ErrPCLoginRequired) {
			models.SendError(c, 400, 1001, "⚠️ 该工位 PC 未登录员工，请从「共享工位成员」按员工重置")
			return
		}
		models.SendInternalError(c, err)
		return
	}
	var empName string
	_ = h.db.QueryRowContext(c.Request.Context(), `SELECT name FROM employees WHERE id = $1`, empID).Scan(&empName)
	result, err := h.telegram.ResetEmployeeDailyAttendance(c.Request.Context(), empID, row.ChatID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE",
		fmt.Sprintf("工位 TG 重置 %s 当日考勤（业务日 %s）", empName, result.BusinessDate),
		id.String(), empName)
	models.Send(c, 200, 0, "success", gin.H{
		"employeeId": empID, "employeeName": empName,
		"businessDate": result.BusinessDate, "deletedWorkSessions": result.DeletedWorkSessions,
		"deletedActivitySessions": result.DeletedActivitySessions, "closedActivities": result.ClosedActivities,
		"clearedShiftState": result.ClearedShiftState, "agentNotified": result.AgentNotified,
	})
}

func (h *WorkforceTelegramHandler) WorkerBind(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		TelegramUserID   int64  `json:"telegramUserId" binding:"required"`
		TelegramUsername string `json:"telegramUsername"`
		InviteCode       string `json:"inviteCode"`
		BindToken        string `json:"bindToken"`
		Username         string `json:"username"`
		Password         string `json:"password"`
		ChatID           string `json:"chatId"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	row, err := h.telegram.BindTelegramSelf(c.Request.Context(), req.TelegramUserID, req.TelegramUsername, req.InviteCode, req.BindToken, req.Username, req.Password, req.ChatID)
	if err != nil {
		h.sendTelegramWorkerError(c, err)
		return
	}
	Log(c, "CREATE", "TELEGRAM_ATTENDANCE",
		fmt.Sprintf("自助绑定 Telegram（个人）：%s ↔ %d", row.EmployeeName, row.TelegramUserID),
		row.ID.String(), row.EmployeeName)
	models.Send(c, 200, 0, "success", gin.H{
		"channel":        services.TelegramChannelPersonal,
		"employeeId":     row.EmployeeID,
		"employeeName":   row.EmployeeName,
		"attendanceMode": row.AttendanceMode,
		"telegramUserId": row.TelegramUserID,
		"telegramUsername": row.TelegramUsername,
	})
}

func (h *WorkforceTelegramHandler) WorkerBindWorkstation(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		TelegramUserID   int64  `json:"telegramUserId" binding:"required"`
		TelegramUsername string `json:"telegramUsername"`
		InviteCode       string `json:"inviteCode" binding:"required"`
		ChatID           string `json:"chatId"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	row, err := h.telegram.BindWorkstationTelegramByInviteCode(c.Request.Context(), req.TelegramUserID, req.TelegramUsername, req.InviteCode, req.ChatID)
	if err != nil {
		h.sendTelegramWorkerError(c, err)
		return
	}
	Log(c, "CREATE", "TELEGRAM_ATTENDANCE",
		fmt.Sprintf("工位 TG 绑定：%s ↔ %d", row.DeviceName, row.TelegramUserID),
		row.ID.String(), row.DeviceName)
	models.Send(c, 200, 0, "success", gin.H{
		"channel":          services.TelegramChannelWorkstation,
		"deviceId":         row.DeviceID,
		"deviceName":       row.DeviceName,
		"telegramUserId":   row.TelegramUserID,
		"telegramUsername": row.TelegramUsername,
	})
}

func (h *WorkforceTelegramHandler) WorkerStatus(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	tgID, err := services.ParseTelegramUserID(c.Query("telegramUserId"))
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	binding, err := h.telegram.ResolveTelegramBinding(c.Request.Context(), tgID)
	if err != nil {
		if errors.Is(err, services.ErrTelegramNotBound) {
			models.Send(c, 200, 0, "success", gin.H{"bound": false})
			return
		}
		models.SendInternalError(c, err)
		return
	}
	if binding.Channel == services.TelegramChannelWorkstation {
		resp := gin.H{
			"bound": true, "channel": services.TelegramChannelWorkstation,
			"deviceId": binding.DeviceID, "deviceName": binding.DeviceName,
			"pcLoginRequired": binding.RequiresPCLogin || binding.EmployeeID == uuid.Nil,
			"workSessionOpen": false, "openShifts": []interface{}{},
		}
		if binding.EmployeeID != uuid.Nil {
			var name, empCode string
			_ = h.db.QueryRowContext(c.Request.Context(), `
				SELECT name, COALESCE(employee_id,'') FROM employees WHERE id = $1`, binding.EmployeeID).Scan(&name, &empCode)
			resp["employeeId"] = binding.EmployeeID
			resp["employeeName"] = name
			resp["employeeCode"] = empCode
			open, sessionID, _ := h.telegram.GetEmployeeSessionStatus(c.Request.Context(), binding.EmployeeID)
			resp["workSessionOpen"] = open
			if sessionID != nil {
				resp["workSessionId"] = sessionID.String()
			}
			openShifts, _ := h.telegram.GetEmployeeOpenShifts(c.Request.Context(), binding.EmployeeID)
			resp["openShifts"] = openShifts
		}
		models.Send(c, 200, 0, "success", resp)
		return
	}
	empID := binding.EmployeeID
	open, sessionID, err := h.telegram.GetEmployeeSessionStatus(c.Request.Context(), empID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	openShifts, _ := h.telegram.GetEmployeeOpenShifts(c.Request.Context(), empID)
	var name, empCode, attendanceMode string
	_ = h.db.QueryRowContext(c.Request.Context(), `
		SELECT name, COALESCE(employee_id,''), COALESCE(NULLIF(TRIM(attendance_mode), ''), 'pc_tg')
		FROM employees WHERE id = $1`, empID).Scan(&name, &empCode, &attendanceMode)
	resp := gin.H{
		"bound": true, "channel": services.TelegramChannelPersonal,
		"employeeId": empID, "employeeName": name, "employeeCode": empCode,
		"attendanceMode": attendanceMode,
		"workSessionOpen": open, "openShifts": openShifts,
	}
	if sessionID != nil {
		resp["workSessionId"] = sessionID.String()
	}
	if act, err := h.telegram.GetOpenActivitySession(c.Request.Context(), empID); err == nil {
		resp["currentActivity"] = act.ActivityName
		resp["activityStartedAt"] = models.FormatUTC(act.StartedAt)
	}
	var shiftType string
	_ = h.db.QueryRowContext(c.Request.Context(), `
		SELECT COALESCE(shift_type,'day') FROM work_sessions
		WHERE employee_id = $1 AND status = 'open' ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&shiftType)
	if shiftType != "" && open {
		resp["shiftType"] = shiftType
		resp["shiftLabel"] = services.ShiftLabelPublic(shiftType)
	}
	models.Send(c, 200, 0, "success", resp)
}

func (h *WorkforceTelegramHandler) WorkerCheckIn(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		TelegramUserID int64  `json:"telegramUserId" binding:"required"`
		ChatID         string `json:"chatId"`
		Shift          string `json:"shift"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	result, empID, name, workFine, handoverHint, groupReplyHTML, err := h.telegram.TelegramCheckIn(c.Request.Context(), req.TelegramUserID, req.ChatID, req.Shift)
	if err != nil {
		h.sendTelegramWorkerError(c, err)
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type": "employee.telegram.checkin",
			"employeeId": empID.String(), "employeeName": name,
			"sessionId": result.SessionID.String(), "date": result.Date,
		})
	}
	models.Send(c, 200, 0, "checked in", gin.H{
		"sessionId": result.SessionID, "date": result.Date,
		"employeeId": empID, "employeeName": name, "shiftType": result.ShiftType,
		"shiftLabel": services.ShiftLabelPublic(result.ShiftType),
		"workFine": workFine, "handoverHint": handoverHint,
		"groupReplyHtml": groupReplyHTML,
	})
}

func (h *WorkforceTelegramHandler) WorkerCheckOut(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		TelegramUserID int64  `json:"telegramUserId" binding:"required"`
		ChatID         string `json:"chatId"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	result, empID, name, workFine, handoverHint, activityWarn, groupReplyHTML, err := h.telegram.TelegramCheckOut(c.Request.Context(), req.TelegramUserID, req.ChatID)
	if err != nil {
		h.sendTelegramWorkerError(c, err)
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type": "employee.telegram.checkout",
			"employeeId": empID.String(), "employeeName": name,
			"sessionId": result.SessionID.String(),
		})
	}
	models.Send(c, 200, 0, "checked out", gin.H{
		"sessionId": result.SessionID, "employeeId": empID, "employeeName": name,
		"shiftType": result.ShiftType, "shiftLabel": services.ShiftLabelPublic(result.ShiftType),
		"workFine": workFine, "handoverHint": handoverHint, "activityWarn": activityWarn,
		"groupReplyHtml": groupReplyHTML,
	})
}

func (h *WorkforceTelegramHandler) sendTelegramWorkerError(c *gin.Context, err error) {
	switch {
	case errors.Is(err, services.ErrTelegramDisabled):
		models.SendError(c, 403, 1003, "⚠️ Telegram 考勤未启用")
	case errors.Is(err, services.ErrTelegramNotBound):
		models.SendError(c, 404, 2001, "⚠️ 未绑定。个人 TG：/bind 邀请码 账号；工位 TG：/bind_workstation 邀请码")
	case errors.Is(err, services.ErrSessionExists):
		models.SendError(c, 409, 1004, "⚠️ 已在上班状态")
	case errors.Is(err, services.ErrWorkSessionOpenOnPC):
		models.SendError(c, 409, 1004, "⚠️ PC 客户端已上班，请先在客户端下班")
	case errors.Is(err, services.ErrWorkSessionOpenOnTG):
		models.SendError(c, 409, 1004, "⚠️ Telegram 已上班，请先在群内下班")
	case errors.Is(err, services.ErrNoOpenSession):
		models.SendError(c, 404, 2001, "⚠️ 当前没有进行中的上班会话")
	case errors.Is(err, services.ErrActivityNotInWork):
		models.SendError(c, 400, 1001, "⚠️ 请先上班后再开始活动")
	case errors.Is(err, services.ErrActivityAlreadyActive):
		models.SendError(c, 409, 1004, "⚠️ 已有进行中的活动，请先结束")
	case errors.Is(err, services.ErrOpenActivityBlocksCheckout):
		models.SendError(c, 409, 1004, "⚠️ 请先回座结束活动后再下班")
	case errors.Is(err, services.ErrActivityNotActive):
		models.SendError(c, 404, 2001, "⚠️ 当前没有进行中的活动")
	case errors.Is(err, services.ErrActivityLimitReached):
		models.SendError(c, 409, 1004, "⚠️ 今日该活动次数已达上限")
	case errors.Is(err, services.ErrActivityTypeNotFound):
		models.SendError(c, 404, 2001, "❌ 未知活动类型")
	case errors.Is(err, services.ErrActivityTypeDisabled):
		models.SendError(c, 403, 1003, "⚠️ 该活动已停用")
	case errors.Is(err, services.ErrOutsideWorkWindow):
		models.SendError(c, 400, 1001, "⚠️ 当前不在上班时间段内")
	case errors.Is(err, services.ErrShiftAlreadyCompleted):
		models.SendError(c, 409, 1004, "⚠️ 今日该班次已完成打卡，无法重复上班")
	case errors.Is(err, services.ErrDualShiftDisabled):
		models.SendError(c, 400, 1001, "⚠️ 双班模式未启用")
	case errors.Is(err, services.ErrPCLoginRequired):
		models.SendError(c, 400, 1001, "⚠️ 请先在 PC Agent 员工登录后再打卡")
	case errors.Is(err, services.ErrPCLoginMismatch):
		models.SendError(c, 400, 1001, "⚠️ PC 当前登录员工与 Telegram 绑定不一致")
	case errors.Is(err, services.ErrCredentialsEmployeeMismatch):
		models.SendError(c, 400, 1001, "⚠️ 账号与邀请码所属员工不一致")
	case errors.Is(err, services.ErrWorkstationNotConfigured):
		models.SendError(c, 400, 1001, "⚠️ 该员工未配置共享工位，请先在后台添加工位成员")
	case errors.Is(err, services.ErrTelegramBoundToWorkstation):
		models.SendError(c, 409, 1004, "⚠️ 该 Telegram 已绑定共享工位，请使用 /bind_workstation")
	case errors.Is(err, services.ErrTelegramBoundToPersonal):
		models.SendError(c, 409, 1004, "⚠️ 该 Telegram 已绑定个人账号，请使用 /bind")
	case errors.Is(err, services.ErrDeviceTelegramAlreadyBound):
		models.SendError(c, 409, 1004, "⚠️ 该工位已绑定其他 Telegram 账号")
	case errors.Is(err, services.ErrInvalidCredentials):
		models.SendError(c, 400, 1001, "⚠️ 账号不存在、已停用或密码错误")
	case errors.Is(err, services.ErrInviteNotFound):
		models.SendError(c, 400, 1001, "❌ 邀请码无效")
	case errors.Is(err, services.ErrInviteExpired):
		models.SendError(c, 400, 1001, "⚠️ 邀请码已过期")
	case errors.Is(err, services.ErrInviteRevoked):
		models.SendError(c, 400, 1001, "⚠️ 邀请码已撤销")
	case errors.Is(err, services.ErrTelegramAlreadyBound):
		models.SendError(c, 409, 1004, "⚠️ 该 Telegram 账号已绑定其他员工")
	case errors.Is(err, services.ErrActivityConcurrentLimit):
		models.SendError(c, 409, 1004, "⚠️ 该活动并发人数已达上限")
	case errors.Is(err, services.ErrBackProcessing):
		models.SendError(c, 429, 1005, "⚠️ 回座请求处理中，请稍候")
	case errors.Is(err, services.ErrOperationBusy):
		models.SendError(c, 429, 1005, "⚠️ 请求处理中，请稍候")
	default:
		models.SendError(c, 500, 5000, "❌ "+err.Error())
	}
}

func (h *WorkforceTelegramHandler) WorkerConfig(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	settings, err := h.telegram.GetSettings(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	active, _ := h.telegram.IsActive(c.Request.Context())
	types, _ := h.telegram.ListEnabledActivityTypesForWorker(c.Request.Context())
	actItems := make([]gin.H, 0, len(types))
	actNames := make([]string, 0, len(types))
	for _, t := range types {
		actItems = append(actItems, gin.H{
			"code": t.Code, "name": t.Name, "timeLimitSeconds": t.TimeLimitSeconds,
		})
		if strings.TrimSpace(t.Name) != "" {
			actNames = append(actNames, t.Name)
		}
	}
	chatID := strings.TrimSpace(c.Query("chatId"))
	webhookSecret, _ := h.telegram.GetWebhookSecret(c.Request.Context())
	resp := gin.H{
		"active":              active,
		"dayStart":            settings.DayStart,
		"dayEnd":              settings.DayEnd,
		"nightStart":          settings.NightStart,
		"nightEnd":            settings.NightEnd,
		"graceMinutes":        settings.GraceMinutes,
		"dualShiftEnabled":    settings.DualShiftEnabled,
		"shiftWindowDisabled": settings.ShiftWindowDisabled,
		"dailyResetTime":      settings.DailyResetTime,
		"botMode":             settings.BotMode,
		"webhookUrl":          settings.WebhookURL,
		"webhookSecret":       webhookSecret,
		"webhookPath":         "/telegram/webhook",
		"langMode":            settings.BotUILang,
		"buttonLookup":        h.telegram.BuildButtonLookup(c.Request.Context(), actNames),
		"botCommands":         h.telegram.BuildActivityBotCommands(c.Request.Context()),
		"adminTelegramUserIds": settings.AdminTelegramUserIDs,
		"activities":          actItems,
		"replyKeyboard":       h.telegram.BuildWorkerReplyKeyboard(c.Request.Context(), chatID),
	}
	if token, err := h.telegram.GetBotTokenForWorker(c.Request.Context()); err == nil && token != "" {
		resp["botToken"] = token
	}
	models.Send(c, http.StatusOK, 0, "success", resp)
}

func sessionToJSON(s *services.TgActivitySession) gin.H {
	if s == nil {
		return nil
	}
	item := gin.H{
		"id": s.ID, "sessionId": s.ID.String(), "employeeId": s.EmployeeID, "employeeName": s.EmployeeName,
		"activityCode": s.ActivityCode, "activityName": s.ActivityName,
		"attendanceDate": s.AttendanceDate, "startedAt": models.FormatUTC(s.StartedAt),
		"startSource": s.StartSource, "endSource": s.EndSource,
		"elapsedSeconds": s.ElapsedSeconds, "limitSeconds": s.LimitSeconds,
		"overtimeSeconds": s.OvertimeSeconds, "fineAmount": s.FineAmount, "status": s.Status,
	}
	if s.EndedAt != nil {
		item["endedAt"] = models.FormatUTC(*s.EndedAt)
	}
	if s.GroupReplyHTML != "" {
		item["groupReplyHtml"] = s.GroupReplyHTML
	}
	return item
}

func (h *WorkforceTelegramHandler) ListActivityTypes(c *gin.Context) {
	items, err := h.telegram.ListActivityTypes(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, t := range items {
		out = append(out, gin.H{
			"id": t.ID, "code": t.Code, "name": t.Name,
			"maxTimesPerDay": t.MaxTimesPerDay, "maxConcurrent": t.MaxConcurrent,
			"timeLimitSeconds": t.TimeLimitSeconds,
			"sortOrder": t.SortOrder, "enabled": t.Enabled,
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) UpsertActivityType(c *gin.Context) {
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	row, err := h.telegram.UpsertActivityType(c.Request.Context(), req)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"code": row.Code, "name": row.Name, "maxTimesPerDay": row.MaxTimesPerDay,
		"maxConcurrent": row.MaxConcurrent,
		"timeLimitSeconds": row.TimeLimitSeconds, "enabled": row.Enabled,
	})
}

func (h *WorkforceTelegramHandler) DeleteActivityType(c *gin.Context) {
	code := c.Param("code")
	if err := h.telegram.DeleteActivityType(c.Request.Context(), code); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) ListActivityFines(c *gin.Context) {
	items, err := h.telegram.ListActivityFines(c.Request.Context(), c.Query("activityCode"))
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, f := range items {
		out = append(out, gin.H{
			"id": f.ID, "activityCode": f.ActivityCode,
			"segmentMinutes": f.SegmentMinutes, "fineAmount": f.FineAmount,
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) UpsertActivityFine(c *gin.Context) {
	var req struct {
		ActivityCode   string  `json:"activityCode" binding:"required"`
		SegmentMinutes int     `json:"segmentMinutes" binding:"required"`
		FineAmount     float64 `json:"fineAmount"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	row, err := h.telegram.UpsertActivityFine(c.Request.Context(), req.ActivityCode, req.SegmentMinutes, req.FineAmount)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"id": row.ID, "activityCode": row.ActivityCode,
		"segmentMinutes": row.SegmentMinutes, "fineAmount": row.FineAmount,
	})
}

func (h *WorkforceTelegramHandler) BatchUpsertActivityFines(c *gin.Context) {
	var req struct {
		ActivityCode  string   `json:"activityCode"`
		ActivityCodes []string `json:"activityCodes"`
		Items         []struct {
			SegmentMinutes int     `json:"segmentMinutes" binding:"required"`
			FineAmount     float64 `json:"fineAmount"`
		} `json:"items" binding:"required,min=1,dive"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	codes := append([]string{}, req.ActivityCodes...)
	if strings.TrimSpace(req.ActivityCode) != "" {
		codes = append(codes, req.ActivityCode)
	}
	batchItems := make([]services.TgActivityFineBatchItem, 0, len(req.Items))
	for _, item := range req.Items {
		batchItems = append(batchItems, services.TgActivityFineBatchItem{
			SegmentMinutes: item.SegmentMinutes,
			FineAmount:     item.FineAmount,
		})
	}
	rows, err := h.telegram.BatchUpsertActivityFines(c.Request.Context(), codes, batchItems)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	out := make([]gin.H, 0, len(rows))
	for _, row := range rows {
		out = append(out, gin.H{
			"id": row.ID, "activityCode": row.ActivityCode,
			"segmentMinutes": row.SegmentMinutes, "fineAmount": row.FineAmount,
		})
	}
	Log(c, "CREATE", "TELEGRAM_ATTENDANCE",
		fmt.Sprintf("批量新增活动超时罚款规则：%d 个活动 × %d 档（共 %d 条）", len(codes), len(req.Items), len(out)),
		"", "")
	models.Send(c, 200, 0, "success", gin.H{"items": out, "count": len(out)})
}

func (h *WorkforceTelegramHandler) DeleteActivityFine(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.telegram.DeleteActivityFine(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) ListActivitySessions(c *gin.Context) {
	items, err := h.telegram.ListActivitySessions(c.Request.Context(),
		c.Query("date"), c.Query("employeeId"), c.Query("search"), 200)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for i := range items {
		out = append(out, sessionToJSON(&items[i]))
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) ListWorkSessions(c *gin.Context) {
	items, err := h.telegram.ListWorkSessions(c.Request.Context(),
		c.Query("date"), c.Query("employeeId"), c.Query("search"), 200)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for i := range items {
		row := &items[i]
		item := gin.H{
			"id": row.ID, "employeeId": row.EmployeeID, "employeeName": row.EmployeeName,
			"employeeCode": row.EmployeeCode, "attendanceDate": row.AttendanceDate,
			"shiftType": row.ShiftType, "checkinTime": models.FormatUTC(row.CheckinTime),
			"source": row.Source, "status": row.Status,
		}
		if row.CheckoutTime != nil {
			item["checkoutTime"] = models.FormatUTC(*row.CheckoutTime)
		}
		out = append(out, item)
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) WorkerStartActivity(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		TelegramUserID   int64  `json:"telegramUserId" binding:"required"`
		ChatID           string `json:"chatId"`
		Activity         string `json:"activity" binding:"required"`
		ReplyToMessageID int64  `json:"replyToMessageId"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	result, err := h.telegram.TelegramStartActivity(c.Request.Context(), req.TelegramUserID, req.ChatID, req.Activity, req.ReplyToMessageID)
	if err != nil {
		h.sendTelegramWorkerError(c, err)
		return
	}
	resp := sessionToJSON(result.Session)
	resp["messageText"] = result.MessageText
	resp["groupReplyHtml"] = result.GroupReplyHTML
	resp["inlineKeyboard"] = result.InlineKeyboard
	resp["groupReplySent"] = result.GroupReplySent
	models.Send(c, 200, 0, "activity started", resp)
}

func (h *WorkforceTelegramHandler) WorkerEndActivity(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		TelegramUserID int64 `json:"telegramUserId" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	sess, err := h.telegram.TelegramEndActivity(c.Request.Context(), req.TelegramUserID)
	if err != nil {
		h.sendTelegramWorkerError(c, err)
		return
	}
	resp := sessionToJSON(sess)
	if sess != nil && strings.TrimSpace(sess.GroupReplyHTML) != "" {
		resp["groupReplySent"] = true
		if anchorID := h.telegram.GetActivitySessionTelegramMessageID(c.Request.Context(), sess.ID); anchorID > 0 {
			resp["activityAnchorMessageId"] = anchorID
		}
	}
	models.Send(c, 200, 0, "activity ended", resp)
}

func (h *WorkforceTelegramHandler) WorkerMyInfo(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	tgID, err := services.ParseTelegramUserID(c.Query("telegramUserId"))
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	info, err := h.telegram.GetMyInfoForShift(c.Request.Context(), tgID, c.Query("shift"), c.Query("chatId"))
	if err != nil {
		if errors.Is(err, services.ErrTelegramNotBound) {
			models.Send(c, 200, 0, "success", gin.H{"bound": false})
			return
		}
		h.sendTelegramWorkerError(c, err)
		return
	}
	displayText, _ := h.telegram.BuildRichMyInfo(c.Request.Context(), tgID, c.Query("shift"), c.Query("chatId"))
	resp := gin.H{
		"bound": true, "employeeName": info.EmployeeName,
		"workSessionOpen": info.WorkSessionOpen, "currentActivity": info.CurrentActivity,
		"todayActivities": info.TodayActivities, "todayFineTotal": info.TodayFineTotal,
		"shiftType": info.ShiftFilter, "shiftLabel": info.ShiftLabel,
		"displayText": displayText,
	}
	if info.ActivityStartedAt != nil {
		resp["activityStartedAt"] = models.FormatUTC(*info.ActivityStartedAt)
	}
	models.Send(c, 200, 0, "success", resp)
}

func (h *WorkforceTelegramHandler) ListHandovers(c *gin.Context) {
	items, err := h.telegram.ListHandovers(c.Request.Context(), c.Query("date"), c.Query("search"), 200)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, row := range items {
		out = append(out, gin.H{
			"id": row.ID, "employeeId": row.EmployeeID, "employeeName": row.EmployeeName,
			"chatId": row.ChatID, "fromShift": row.FromShift, "toShift": row.ToShift,
			"fromShiftLabel": services.ShiftLabelPublic(row.FromShift),
			"toShiftLabel":   services.ShiftLabelPublic(row.ToShift),
			"note": row.Note, "handoverAt": models.FormatUTC(row.HandoverAt),
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) ListRankings(c *gin.Context) {
	items, err := h.telegram.ListRankingsForShift(c.Request.Context(), c.Query("date"), c.Query("metric"), c.Query("shift"), c.Query("chatId"), 30)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, row := range items {
		out = append(out, gin.H{
			"rank": row.Rank, "employeeId": row.EmployeeID, "employeeName": row.EmployeeName,
			"employeeCode": row.EmployeeCode, "activityCount": row.ActivityCount,
			"overtimeSeconds": row.OvertimeSeconds, "fineTotal": row.FineTotal,
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out, "date": c.Query("date"), "metric": c.Query("metric")})
}

func (h *WorkforceTelegramHandler) ExportAttendance(c *gin.Context) {
	dateFrom := strings.TrimSpace(c.Query("dateFrom"))
	dateTo := strings.TrimSpace(c.Query("dateTo"))
	month := strings.TrimSpace(c.Query("month"))
	if month != "" && dateFrom == "" {
		dateFrom = month + "-01"
		if t, err := time.Parse("2006-01-02", dateFrom); err == nil {
			dateTo = t.AddDate(0, 1, -1).Format("2006-01-02")
		}
	}
	data, filename, err := h.telegram.ExportAttendanceXLSX(c.Request.Context(), dateFrom, dateTo, "")
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	c.Header("Content-Disposition", "attachment; filename="+filename)
	c.Data(http.StatusOK, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", data)
}

func (h *WorkforceTelegramHandler) RunDailyReset(c *gin.Context) {
	var req struct {
		ExportBusinessToday bool `json:"exportBusinessToday"`
	}
	_ = c.ShouldBindJSON(&req)

	runOpts := &services.DailyResetRunOptions{ManualTrigger: true}
	if req.ExportBusinessToday {
		runOpts.ExportBusinessToday = true
	}

	result, err := h.telegram.RunDailyReset(c.Request.Context(), runOpts)
	if err != nil {
		if errors.Is(err, services.ErrTelegramDisabled) {
			models.SendError(c, 403, 1003, "Telegram 考勤未启用")
			return
		}
		models.SendInternalError(c, err)
		return
	}
	if result == nil {
		models.Send(c, 200, 0, "already reset today or disabled", gin.H{"skipped": true})
		return
	}
	if result.SkippedAllGroups {
		models.Send(c, 200, 0, "all groups already reset today", gin.H{
			"skipped":          true,
			"skippedAllGroups": true,
			"resetDate":        result.ResetDate,
		})
		return
	}
	Log(c, "POST", "TELEGRAM_ATTENDANCE", "手动日重置", result.ResetDate, "Telegram")
	models.Send(c, 200, 0, "daily reset completed", gin.H{
		"resetDate":           result.ResetDate,
		"exportDate":          result.ExportDate,
		"exportDateNote":      result.ExportDateNote,
		"closedWorkSessions":  result.ClosedWorkSessions,
		"closedAgentSessions": result.ClosedAgentSessions,
		"closedActivities":    result.ClosedActivities,
		"exportPath":          result.ExportPath,
		"archivedMonth":       result.ArchivedMonth,
		"bindingWarnings":     result.BindingWarnings,
		"groupsProcessed":     result.GroupsProcessed,
	})
}

func (h *WorkforceTelegramHandler) WorkerHandover(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		TelegramUserID int64  `json:"telegramUserId" binding:"required"`
		Note           string `json:"note"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	result, handover, err := h.telegram.TelegramHandover(c.Request.Context(), req.TelegramUserID, req.Note)
	if err != nil {
		h.sendTelegramWorkerError(c, err)
		return
	}
	models.Send(c, 200, 0, "handover completed", gin.H{
		"sessionId": result.SessionID, "shiftType": result.ShiftType,
		"shiftLabel": services.ShiftLabelPublic(result.ShiftType),
		"fromShift": handover.FromShift, "toShift": handover.ToShift,
	})
}

func (h *WorkforceTelegramHandler) WorkerRankings(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	chatID := c.Query("chatId")
	shift := c.Query("shift")
	groups, header, err := h.telegram.ListActivityRankGroups(c.Request.Context(), chatID, shift)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	displayText := h.telegram.FormatActivityRankingsText(groups, header, shift)
	models.Send(c, 200, 0, "success", gin.H{"displayText": displayText, "groups": groups})
}

func (h *WorkforceTelegramHandler) WorkerCallbackQuickBack(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		SessionID      string `json:"sessionId" binding:"required"`
		TelegramUserID int64  `json:"telegramUserId" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	sid, err := uuid.Parse(req.SessionID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid sessionId")
		return
	}
	sess, err := h.telegram.TelegramEndActivityBySession(c.Request.Context(), sid, req.TelegramUserID)
	if err != nil {
		if errors.Is(err, services.ErrActivityBackNotOwner) {
			name := h.telegram.EmployeeNameByTelegramUserID(c.Request.Context(), req.TelegramUserID)
			if name == "" {
				name = "该用户"
			}
			models.SendError(c, 403, 1006, fmt.Sprintf("%s，这不是您的活动按钮", name))
			return
		}
		h.sendTelegramWorkerError(c, err)
		return
	}
	item := sessionToJSON(sess)
	msg := fmt.Sprintf("✅ 「%s」已结束，用时 %s", sess.ActivityName, services.FormatDurationZh(sess.ElapsedSeconds))
	if sess.FineAmount > 0 {
		msg += fmt.Sprintf("\n⚠️ 超时罚款 ¥%.2f", sess.FineAmount)
	}
	item["messageText"] = msg
	if strings.TrimSpace(sess.GroupReplyHTML) != "" {
		item["groupReplySent"] = true
		if anchorID := h.telegram.GetActivitySessionTelegramMessageID(c.Request.Context(), sess.ID); anchorID > 0 {
			item["activityAnchorMessageId"] = anchorID
		}
	}
	models.Send(c, 200, 0, "activity ended", item)
}

func (h *WorkforceTelegramHandler) WorkerActivityMessageID(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		SessionID string `json:"sessionId" binding:"required"`
		MessageID int64  `json:"messageId" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	sid, err := uuid.Parse(req.SessionID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid sessionId")
		return
	}
	h.telegram.SetActivityTelegramMessageID(c.Request.Context(), sid, req.MessageID)
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) WorkerRegisterGroup(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		ChatID    string `json:"chatId" binding:"required"`
		ChatTitle string `json:"chatTitle"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	row, err := h.telegram.UpsertGroup(c.Request.Context(), req.ChatID, req.ChatTitle, true, nil)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	_ = h.telegram.RecordDiscoveredChat(c.Request.Context(), req.ChatID, req.ChatTitle, "supergroup")
	models.Send(c, 200, 0, "success", gin.H{
		"id": row.ID, "chatId": row.ChatID, "chatTitle": row.ChatTitle,
	})
}

func (h *WorkforceTelegramHandler) GetPushSettings(c *gin.Context) {
	chatID := c.Query("chatId")
	if strings.TrimSpace(chatID) == "" {
		models.SendError(c, 400, 1001, "chatId required")
		return
	}
	ps, err := h.telegram.GetPushSettings(c.Request.Context(), chatID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"chatId": ps.ChatID, "channelId": ps.ChannelID,
		"notificationGroupId": ps.NotificationGroupID, "extraWorkGroupId": ps.ExtraWorkGroupID,
		"enableChannelPush": ps.EnableChannelPush, "enableGroupPush": ps.EnableGroupPush,
		"enableAdminPush": ps.EnableAdminPush, "updatedAt": models.FormatUTC(ps.UpdatedAt),
	})
}

func (h *WorkforceTelegramHandler) UpsertPushSettings(c *gin.Context) {
	var req struct {
		ChatID string                 `json:"chatId" binding:"required"`
		Data   map[string]interface{} `json:"data"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	in := req.Data
	if in == nil {
		in = map[string]interface{}{}
	}
	ps, err := h.telegram.UpsertPushSettings(c.Request.Context(), req.ChatID, in)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE", "更新 Telegram 推送配置", ps.ChatID, ps.ChatID)
	models.Send(c, 200, 0, "success", gin.H{"chatId": ps.ChatID})
}

func (h *WorkforceTelegramHandler) TestPushSettings(c *gin.Context) {
	chatID := strings.TrimSpace(c.Query("chatId"))
	if chatID == "" {
		var req struct {
			ChatID string `json:"chatId"`
		}
		if c.ShouldBindJSON(&req) == nil {
			chatID = strings.TrimSpace(req.ChatID)
		}
	}
	if chatID == "" {
		models.SendError(c, 400, 1001, "chatId required")
		return
	}
	if err := h.telegram.TestPushSettings(c.Request.Context(), chatID); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE", "测试 Telegram 推送配置", chatID, chatID)
	models.Send(c, 200, 0, "测试消息已发送", nil)
}

func (h *WorkforceTelegramHandler) GetHandoverConfig(c *gin.Context) {
	chatID := c.Query("chatId")
	if strings.TrimSpace(chatID) == "" {
		models.SendError(c, 400, 1001, "chatId required")
		return
	}
	cfg, err := h.telegram.GetHandoverConfig(c.Request.Context(), chatID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"chatId": cfg.ChatID, "handoverEnabled": cfg.HandoverEnabled,
		"handoverDay": cfg.HandoverDay, "handoverMonth": cfg.HandoverMonth,
		"handoverDayStartTime": cfg.HandoverDayStartTime,
		"nightStartTime": cfg.NightStartTime, "dayStartTime": cfg.DayStartTime,
		"handoverNightHours": cfg.HandoverNightHours, "handoverDayHours": cfg.HandoverDayHours,
		"normalNightHours": cfg.NormalNightHours, "normalDayHours": cfg.NormalDayHours,
		"handoverResetThresholdHours": cfg.HandoverResetThresholdHours,
		"updatedAt": models.FormatUTC(cfg.UpdatedAt),
	})
}

func (h *WorkforceTelegramHandler) UpsertHandoverConfig(c *gin.Context) {
	var req struct {
		ChatID string                 `json:"chatId" binding:"required"`
		Data   map[string]interface{} `json:"data"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	in := req.Data
	if in == nil {
		in = map[string]interface{}{}
	}
	cfg, err := h.telegram.UpsertHandoverConfig(c.Request.Context(), req.ChatID, in)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "TELEGRAM_ATTENDANCE", "更新换班日配置", cfg.ChatID, cfg.ChatID)
	models.Send(c, 200, 0, "success", gin.H{"chatId": cfg.ChatID, "handoverEnabled": cfg.HandoverEnabled})
}

func (h *WorkforceTelegramHandler) ListWorkFines(c *gin.Context) {
	items, err := h.telegram.ListWorkFines(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, f := range items {
		out = append(out, gin.H{
			"id": f.ID, "checkinType": f.CheckinType,
			"segmentMinutes": f.SegmentMinutes, "fineAmount": f.FineAmount,
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) UpsertWorkFine(c *gin.Context) {
	var req struct {
		CheckinType    string  `json:"checkinType" binding:"required"`
		SegmentMinutes int     `json:"segmentMinutes" binding:"required"`
		FineAmount     float64 `json:"fineAmount"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	row, err := h.telegram.UpsertWorkFine(c.Request.Context(), req.CheckinType, req.SegmentMinutes, req.FineAmount)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"id": row.ID, "checkinType": row.CheckinType,
		"segmentMinutes": row.SegmentMinutes, "fineAmount": row.FineAmount,
	})
}

func (h *WorkforceTelegramHandler) BatchUpsertWorkFines(c *gin.Context) {
	var req struct {
		CheckinType  string   `json:"checkinType"`
		CheckinTypes []string `json:"checkinTypes"`
		Items        []struct {
			SegmentMinutes int     `json:"segmentMinutes" binding:"required"`
			FineAmount     float64 `json:"fineAmount"`
		} `json:"items" binding:"required,min=1,dive"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	types := append([]string{}, req.CheckinTypes...)
	if strings.TrimSpace(req.CheckinType) != "" {
		types = append(types, req.CheckinType)
	}
	batchItems := make([]services.TgWorkFineBatchItem, 0, len(req.Items))
	for _, item := range req.Items {
		batchItems = append(batchItems, services.TgWorkFineBatchItem{
			SegmentMinutes: item.SegmentMinutes,
			FineAmount:     item.FineAmount,
		})
	}
	rows, err := h.telegram.BatchUpsertWorkFines(c.Request.Context(), types, batchItems)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	out := make([]gin.H, 0, len(rows))
	for _, row := range rows {
		out = append(out, gin.H{
			"id": row.ID, "checkinType": row.CheckinType,
			"segmentMinutes": row.SegmentMinutes, "fineAmount": row.FineAmount,
		})
	}
	Log(c, "CREATE", "TELEGRAM_ATTENDANCE",
		fmt.Sprintf("批量新增上下班罚款规则：%d 种类型 × %d 档（共 %d 条）", len(types), len(req.Items), len(out)),
		"", "")
	models.Send(c, 200, 0, "success", gin.H{"items": out, "count": len(out)})
}

func (h *WorkforceTelegramHandler) DeleteWorkFine(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.telegram.DeleteWorkFine(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) ListSharedWorkstationMembers(c *gin.Context) {
	items, err := h.telegram.ListSharedWorkstationMembers(c.Request.Context(), c.Query("deviceId"))
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, m := range items {
		out = append(out, gin.H{
			"deviceId": m.DeviceID, "deviceName": m.DeviceName,
			"employeeId": m.EmployeeID, "employeeName": m.EmployeeName, "employeeCode": m.EmployeeCode,
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) ListDeviceTelegramBindings(c *gin.Context) {
	items, err := h.telegram.ListDeviceTelegramBindings(c.Request.Context(), c.Query("search"))
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(items))
	for _, item := range items {
		row := gin.H{
			"id":               item.ID,
			"deviceId":         item.DeviceID,
			"deviceName":       item.DeviceName,
			"channel":          services.TelegramChannelWorkstation,
			"telegramUserId":   item.TelegramUserID,
			"telegramUsername": item.TelegramUsername,
			"chatId":           item.ChatID,
			"boundAt":          models.FormatUTC(item.BoundAt),
		}
		if item.EmployeeID != uuid.Nil {
			row["employeeId"] = item.EmployeeID
			row["employeeName"] = item.EmployeeName
			row["employeeCode"] = item.EmployeeCode
		}
		out = append(out, row)
	}
	models.Send(c, 200, 0, "success", gin.H{"items": out})
}

func (h *WorkforceTelegramHandler) DeleteDeviceTelegramBinding(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.telegram.DeleteDeviceTelegramBinding(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	Log(c, "DELETE", "TELEGRAM_ATTENDANCE", "解除工位 Telegram 绑定", id.String(), id.String())
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) AddSharedWorkstationMember(c *gin.Context) {
	var req struct {
		DeviceID   string `json:"deviceId" binding:"required"`
		EmployeeID string `json:"employeeId" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	deviceID, err := uuid.Parse(req.DeviceID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid device id")
		return
	}
	employeeID, err := uuid.Parse(req.EmployeeID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid employee id")
		return
	}
	if err := h.telegram.AddSharedWorkstationMember(c.Request.Context(), deviceID, employeeID); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "CREATE", "TELEGRAM_ATTENDANCE", "添加共享工位成员", deviceID.String(), employeeID.String())
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) RemoveSharedWorkstationMember(c *gin.Context) {
	var req struct {
		DeviceID   string `json:"deviceId" binding:"required"`
		EmployeeID string `json:"employeeId" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	deviceID, _ := uuid.Parse(req.DeviceID)
	employeeID, _ := uuid.Parse(req.EmployeeID)
	if err := h.telegram.RemoveSharedWorkstationMember(c.Request.Context(), deviceID, employeeID); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

func (h *WorkforceTelegramHandler) WorkerExport(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	chatID := strings.TrimSpace(c.Query("chatId"))
	dateFrom := c.Query("dateFrom")
	dateTo := c.Query("dateTo")
	if month := strings.TrimSpace(c.Query("month")); month != "" && dateFrom == "" {
		if t, err := time.Parse("2006-01", month); err == nil {
			dateFrom = t.Format("2006-01-02")
			dateTo = t.AddDate(0, 1, -1).Format("2006-01-02")
		}
	}
	caption, err := h.telegram.BotExportAndPush(c.Request.Context(), chatID, dateFrom, dateTo)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"caption": caption})
}

func (h *WorkforceTelegramHandler) WorkerMonthlyReport(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	chatID := strings.TrimSpace(c.Query("chatId"))
	month := c.Query("month")
	text, err := h.telegram.FormatMonthlyReport(c.Request.Context(), chatID, month)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"displayText": text, "parseMode": "HTML"})
}

func (h *WorkforceTelegramHandler) WorkerActStatus(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	chatID := strings.TrimSpace(c.Query("chatId"))
	models.Send(c, 200, 0, "success", gin.H{"displayText": h.telegram.FormatActivityOccupancy(c.Request.Context(), chatID)})
}

func (h *WorkforceTelegramHandler) WorkerShowSettings(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	tgID, err := services.ParseTelegramUserID(c.Query("telegramUserId"))
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if !h.telegram.IsAdminTelegramUser(c.Request.Context(), tgID) {
		models.SendError(c, 403, 1003, "admin only")
		return
	}
	chatID := strings.TrimSpace(c.Query("chatId"))
	models.Send(c, 200, 0, "success", gin.H{
		"displayText": h.telegram.FormatShowSettings(c.Request.Context(), chatID),
		"parseMode":   "HTML",
	})
}

func (h *WorkforceTelegramHandler) WorkerCheckDB(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	tgID, err := services.ParseTelegramUserID(c.Query("telegramUserId"))
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if !h.telegram.IsAdminTelegramUser(c.Request.Context(), tgID) {
		models.SendError(c, 403, 1003, "admin only")
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"displayText": h.telegram.FormatCheckDB(c.Request.Context())})
}

func (h *WorkforceTelegramHandler) WorkerFixMessages(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	var req struct {
		TelegramUserID int64 `json:"telegramUserId" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if !h.telegram.IsAdminTelegramUser(c.Request.Context(), req.TelegramUserID) {
		models.SendError(c, 403, 1003, "admin only")
		return
	}
	n := h.telegram.FixActivityMessageIDs(c.Request.Context())
	models.Send(c, 200, 0, "success", gin.H{"cleared": n})
}

func (h *WorkforceTelegramHandler) WorkerResolveCI(c *gin.Context) {
	if !h.workerAuth(c) {
		return
	}
	text := strings.TrimSpace(c.Query("text"))
	act := h.telegram.ResolveActivityFromCI(c.Request.Context(), text)
	if act == "" {
		models.SendError(c, 404, 1004, "activity not found")
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"activityName": act})
}

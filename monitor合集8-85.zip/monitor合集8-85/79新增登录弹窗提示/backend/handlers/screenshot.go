// backend/handlers/screenshot.go
// 完整修复版本 - 修复路径穿越漏洞

package handlers

import (
	"database/sql"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// 常量定义
const (
	maxBatchDeleteSize      = 100
	screenshotPurgeBatchSize = 500
	imageCacheMaxAge        = 3600 // 1小时
)

// ✅ 允许的图片扩展名
var allowedImageExts = []string{
	".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp",
}

// ✅ 安全的基础目录（在初始化时设置）
var (
	safeBaseDirs     []string
	safeBaseDirsLock sync.RWMutex
)

// InitScreenshotSecurity 初始化截图安全配置（在 main.go 中调用）
func InitScreenshotSecurity(uploadsDir, dataDir string) {
	safeBaseDirsLock.Lock()
	defer safeBaseDirsLock.Unlock()

	safeBaseDirs = make([]string, 0)

	// 添加配置的目录
	dirs := []string{uploadsDir, dataDir}
	for _, dir := range dirs {
		if dir != "" {
			absDir, err := filepath.Abs(dir)
			if err == nil {
				safeBaseDirs = append(safeBaseDirs, absDir)
			}
		}
	}

	// 添加当前工作目录下的常见目录
	workDir, _ := os.Getwd()
	commonDirs := []string{
		filepath.Join(workDir, "uploads"),
		filepath.Join(workDir, "data"),
		filepath.Join(workDir, "uploads", "screenshots"),
		filepath.Join(workDir, "data", "screenshots"),
	}
	for _, dir := range commonDirs {
		absDir, err := filepath.Abs(dir)
		if err == nil {
			safeBaseDirs = append(safeBaseDirs, absDir)
		}
	}

	// 去重
	safeBaseDirs = uniqueStrings(safeBaseDirs)
}

// uniqueStrings 去重
func uniqueStrings(strs []string) []string {
	seen := make(map[string]bool)
	result := make([]string, 0)
	for _, s := range strs {
		if !seen[s] {
			seen[s] = true
			result = append(result, s)
		}
	}
	return result
}

// getSafeBaseDirs 获取安全的基础目录列表（线程安全）
func getSafeBaseDirs() []string {
	safeBaseDirsLock.RLock()
	defer safeBaseDirsLock.RUnlock()
	return safeBaseDirs
}

type ScreenshotHandler struct {
	repo       *services.ScreenshotRepository
	deviceRepo *services.DeviceRepository
}

func NewScreenshotHandler(repo *services.ScreenshotRepository, deviceRepo *services.DeviceRepository) *ScreenshotHandler {
	return &ScreenshotHandler{
		repo:       repo,
		deviceRepo: deviceRepo,
	}
}

func (h *ScreenshotHandler) loadScreenshotWithAccess(c *gin.Context, screenshotID string) (*models.Screenshot, bool) {
	screenshot, err := h.repo.GetByID(c.Request.Context(), screenshotID)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Screenshot not found")
		return nil, false
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return nil, false
	}
	deviceID, err := uuid.Parse(screenshot.DeviceID)
	if err != nil {
		models.SendError(c, 500, 5000, "Invalid screenshot device reference")
		return nil, false
	}
	if !middleware.EnforceEmployeeDeviceScope(c, deviceID) {
		return nil, false
	}
	return screenshot, true
}

func (h *ScreenshotHandler) enforceScreenshotAccessByID(c *gin.Context, screenshotID string) bool {
	_, ok := h.loadScreenshotWithAccess(c, screenshotID)
	return ok
}

func serveStaticImageFile(c *gin.Context, filePath string, contentType string) {
	info, err := os.Stat(filePath)
	if err != nil {
		models.SendError(c, 404, 3001, "Image file not found")
		return
	}

	etag := fmt.Sprintf(`"%d-%d"`, info.ModTime().Unix(), info.Size())
	c.Header("Cache-Control", "public, max-age=3600")
	c.Header("Last-Modified", info.ModTime().UTC().Format(http.TimeFormat))
	c.Header("ETag", etag)
	c.Header("X-Content-Type-Options", "nosniff")
	c.Header("Content-Security-Policy", "default-src 'none'")
	if contentType != "" {
		c.Header("Content-Type", contentType)
	}

	if inm := c.GetHeader("If-None-Match"); inm == etag {
		c.Status(http.StatusNotModified)
		return
	}
	if ims := c.GetHeader("If-Modified-Since"); ims != "" {
		if t, err := time.Parse(http.TimeFormat, ims); err == nil && !info.ModTime().After(t) {
			c.Status(http.StatusNotModified)
			return
		}
	}

	c.File(filePath)
}

// ListScreenshots 获取截图列表（分页）
func (h *ScreenshotHandler) ListScreenshots(c *gin.Context) {
	deviceID := c.Query("deviceId")
	startDate := c.Query("startDate")
	endDate := c.Query("endDate")
	startTime := c.Query("startTime")
	endTime := c.Query("endTime")

	filteredDeviceID, ok := middleware.ResolveEmployeeListDeviceFilter(c, deviceID)
	if !ok {
		return
	}
	deviceID = filteredDeviceID

	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "20"))

	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 20
	}
	if pageSize > 100 {
		pageSize = 100
	}

	// ✅ 修改：传递 startTime 和 endTime 参数
	screenshots, total, err := h.repo.List(c.Request.Context(), deviceID, startDate, endDate, startTime, endTime, page, pageSize)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items":    screenshots,
		"total":    total,
		"page":     page,
		"pageSize": pageSize,
	})
}

// GetScreenshot 获取单张截图信息
func (h *ScreenshotHandler) GetScreenshot(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		models.SendError(c, 400, 1001, "Screenshot ID is required")
		return
	}
	screenshot, ok := h.loadScreenshotWithAccess(c, id)
	if !ok {
		return
	}

	models.Send(c, 200, 0, "success", screenshot)
}

// GetScreenshotImage ✅ 修复：严格验证路径，防止路径穿越
func (h *ScreenshotHandler) GetScreenshotImage(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		models.SendError(c, 400, 1001, "Screenshot ID is required")
		return
	}

	screenshot, ok := h.loadScreenshotWithAccess(c, id)
	if !ok {
		return
	}

	// ✅ 修复：严格验证文件路径
	safePath, err := validateScreenshotPath(screenshot.FilePath)
	if err != nil {
		models.SendError(c, 403, 1003, err.Error())
		return
	}

	if !fileExists(safePath) {
		models.SendError(c, 404, 3001, "Image file not found")
		return
	}

	serveStaticImageFile(c, safePath, getImageContentType(safePath))
}

// GetScreenshotThumbnail 返回缩小后的 JPEG 缩略图（磁盘缓存）；失败时回退原图。
func (h *ScreenshotHandler) GetScreenshotThumbnail(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		models.SendError(c, 400, 1001, "Screenshot ID is required")
		return
	}

	screenshot, ok := h.loadScreenshotWithAccess(c, id)
	if !ok {
		return
	}

	safePath, err := validateScreenshotPath(screenshot.FilePath)
	if err != nil {
		models.SendError(c, 403, 1003, err.Error())
		return
	}

	if !fileExists(safePath) {
		models.SendError(c, 404, 3001, "Image file not found")
		return
	}

	thumbPath, thumbErr := services.EnsureScreenshotThumbnail(safePath)
	if thumbErr != nil {
		log.Printf("[Screenshot] thumbnail generate failed id=%s: %v", id, thumbErr)
		serveStaticImageFile(c, safePath, getImageContentType(safePath))
		return
	}

	serveStaticImageFile(c, thumbPath, "image/jpeg")
}

// validateScreenshotPath ✅ 核心修复：严格验证路径安全性
func validateScreenshotPath(filePath string) (string, error) {
	if filePath == "" {
		return "", fmt.Errorf("empty file path")
	}

	// 1. 将 /uploads/... 虚拟路径映射到 UPLOADS_DIR 下的真实磁盘路径
	normalized := filepath.ToSlash(filepath.Clean(filePath))
	if strings.HasPrefix(normalized, "/uploads/") {
		uploadsDir := os.Getenv("UPLOADS_DIR")
		if uploadsDir == "" {
			uploadsDir = "./uploads"
		}
		absUploads, err := filepath.Abs(uploadsDir)
		if err != nil {
			return "", fmt.Errorf("failed to resolve uploads dir: %w", err)
		}
		rel := strings.TrimPrefix(normalized, "/uploads/")
		if strings.Contains(rel, "..") {
			return "", fmt.Errorf("path traversal detected")
		}
		filePath = filepath.Join(absUploads, filepath.FromSlash(rel))
	}

	// 2. 清理路径
	cleanPath := filepath.Clean(filePath)

	// 2. 检查路径遍历攻击
	if strings.Contains(cleanPath, "..") {
		return "", fmt.Errorf("path traversal detected")
	}

	// 3. 检查文件扩展名
	ext := strings.ToLower(filepath.Ext(cleanPath))
	validExt := false
	for _, allowed := range allowedImageExts {
		if ext == allowed {
			validExt = true
			break
		}
	}
	if !validExt {
		return "", fmt.Errorf("invalid file type: %s", ext)
	}

	// 4. 获取绝对路径
	absPath, err := filepath.Abs(cleanPath)
	if err != nil {
		return "", fmt.Errorf("failed to resolve path: %w", err)
	}

	// 5. 检查是否在允许的基础目录内
	safeDirs := getSafeBaseDirs()
	if len(safeDirs) == 0 {
		return "", fmt.Errorf("security not initialized")
	}

	allowed := false
	for _, baseDir := range safeDirs {
		// 确保基础目录存在
		if _, err := os.Stat(baseDir); os.IsNotExist(err) {
			continue
		}
		if strings.HasPrefix(absPath, baseDir) {
			allowed = true
			break
		}
	}

	if !allowed {
		return "", fmt.Errorf("access denied: path outside allowed directory")
	}

	return absPath, nil
}

// DeleteScreenshot 删除截图
func (h *ScreenshotHandler) DeleteScreenshot(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		models.SendError(c, 400, 1001, "Screenshot ID is required")
		return
	}
	if !h.enforceScreenshotAccessByID(c, id) {
		return
	}

	screenshot, err := h.repo.GetByID(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Screenshot not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// ✅ 修复：删除前验证路径
	if screenshot.FilePath != "" {
		if safePath, err := validateScreenshotPath(screenshot.FilePath); err == nil {
			services.RemoveScreenshotThumbnail(safePath)
			_ = os.Remove(safePath)
		}
	}

	if err := h.repo.Delete(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	Log(c, "DELETE", "SCREENSHOT", fmt.Sprintf("删除截图：%s", id), id, id)
	models.Send(c, 200, 0, "Screenshot deleted successfully", nil)
}

// BatchDeleteScreenshots 批量删除截图
func (h *ScreenshotHandler) BatchDeleteScreenshots(c *gin.Context) {
	var req struct {
		IDs []string `json:"ids"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: "+err.Error())
		return
	}

	if len(req.IDs) == 0 {
		models.SendError(c, 400, 1001, "No IDs provided")
		return
	}

	if len(req.IDs) > maxBatchDeleteSize {
		models.SendError(c, 400, 1001, "Maximum 100 screenshots can be deleted at once")
		return
	}

	var deletedCount int
	var failedIDs []string
	allowedIDs := make([]string, 0, len(req.IDs))

	for _, id := range req.IDs {
		if !h.enforceScreenshotAccessByID(c, id) {
			return
		}
		allowedIDs = append(allowedIDs, id)
	}

	// ✅ 修复：删除前验证每个路径
	for _, id := range allowedIDs {
		screenshot, err := h.repo.GetByID(c.Request.Context(), id)
		if err != nil {
			failedIDs = append(failedIDs, id)
			continue
		}
		if screenshot.FilePath != "" {
			if safePath, err := validateScreenshotPath(screenshot.FilePath); err == nil {
				services.RemoveScreenshotThumbnail(safePath)
				_ = os.Remove(safePath)
			}
		}
		deletedCount++
	}

	if err := h.repo.DeleteBatch(c.Request.Context(), allowedIDs); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	Log(c, "DELETE", "SCREENSHOT", fmt.Sprintf("批量删除截图 %d 张", deletedCount), "", fmt.Sprintf("%d 张", deletedCount))
	models.Send(c, 200, 0, "Screenshots deleted", gin.H{
		"deleted":   deletedCount,
		"total":     len(req.IDs),
		"failedIds": failedIDs,
	})
}

// PurgeScreenshots 按日期或全部删除截图
func (h *ScreenshotHandler) PurgeScreenshots(c *gin.Context) {
	var req struct {
		DeleteAll bool   `json:"deleteAll"`
		StartDate string `json:"startDate"`
		EndDate   string `json:"endDate"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: "+err.Error())
		return
	}

	if !req.DeleteAll && (req.StartDate == "" || req.EndDate == "") {
		models.SendError(c, 400, 1001, "请提供删除日期范围，或选择全部删除")
		return
	}

	var deviceFilter []uuid.UUID
	if middleware.IsEmployeeRole(c) {
		ids, ok := middleware.ResolveEmployeeDeviceIDs(c)
		if !ok || len(ids) == 0 {
			models.SendError(c, 403, 1003, "No device bound to your account")
			return
		}
		deviceFilter = ids
	}

	var startUTC, endUTC *time.Time
	if !req.DeleteAll {
		startParsed, err := time.Parse(time.RFC3339, req.StartDate)
		if err != nil {
			models.SendError(c, 400, 1001, "Invalid startDate format")
			return
		}
		endParsed, err := time.Parse(time.RFC3339, req.EndDate)
		if err != nil {
			models.SendError(c, 400, 1001, "Invalid endDate format")
			return
		}
		startUTC = &startParsed
		endUTC = &endParsed
	}

	ctx := c.Request.Context()
	totalDeleted := 0

	for {
		batch, err := h.repo.FetchBatchForPurge(ctx, deviceFilter, startUTC, endUTC, screenshotPurgeBatchSize)
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		if len(batch) == 0 {
			break
		}

		ids := make([]string, 0, len(batch))
		for _, screenshot := range batch {
			if screenshot.FilePath != "" {
				if safePath, err := validateScreenshotPath(screenshot.FilePath); err == nil {
					services.RemoveScreenshotThumbnail(safePath)
					_ = os.Remove(safePath)
				}
			}
			ids = append(ids, screenshot.ID)
		}

		if err := h.repo.DeleteBatch(ctx, ids); err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		totalDeleted += len(ids)

		if len(batch) < screenshotPurgeBatchSize {
			break
		}
	}

	if totalDeleted == 0 {
		models.Send(c, 200, 0, "没有符合条件的截图", gin.H{"deleted": 0})
		return
	}

	models.Send(c, 200, 0, fmt.Sprintf("已删除 %d 张截图", totalDeleted), gin.H{
		"deleted": totalDeleted,
	})
	Log(c, "DELETE", "SCREENSHOT", fmt.Sprintf("清理截图 %d 张", totalDeleted), "", fmt.Sprintf("%d 张", totalDeleted))
}

// GetScreenshotsByDevice 获取指定设备的所有截图
func (h *ScreenshotHandler) GetScreenshotsByDevice(c *gin.Context) {
	deviceID := c.Param("deviceId")
	if deviceID == "" {
		models.SendError(c, 400, 1001, "Device ID is required")
		return
	}

	startDate := c.Query("startDate")
	endDate := c.Query("endDate")
	limit := 1000

	screenshots, err := h.repo.ListByDevice(c.Request.Context(), deviceID, startDate, endDate, limit)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// ✅ 修复：返回时脱敏文件路径（不暴露完整路径）
	for i := range screenshots {
		screenshots[i].FilePath = filepath.Base(screenshots[i].FilePath)
	}

	models.Send(c, 200, 0, "success", screenshots)
}

// GetScreenshotStats 获取截图统计信息
func (h *ScreenshotHandler) GetScreenshotStats(c *gin.Context) {
	deviceID := c.Query("deviceId")
	filteredDeviceID, ok := middleware.ResolveEmployeeListDeviceFilter(c, deviceID)
	if !ok {
		return
	}

	stats, err := h.repo.GetStats(c.Request.Context(), filteredDeviceID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", stats)
}

// ========== 辅助函数 ==========

// fileExists 检查文件是否存在
func fileExists(path string) bool {
	if path == "" {
		return false
	}
	info, err := os.Stat(path)
	if os.IsNotExist(err) {
		return false
	}
	if err != nil {
		return false
	}
	return !info.IsDir()
}

// getImageContentType 根据文件扩展名获取Content-Type
func getImageContentType(path string) string {
	ext := strings.ToLower(filepath.Ext(path))
	switch ext {
	case ".jpg", ".jpeg":
		return "image/jpeg"
	case ".png":
		return "image/png"
	case ".gif":
		return "image/gif"
	case ".webp":
		return "image/webp"
	case ".bmp":
		return "image/bmp"
	default:
		return "application/octet-stream"
	}
}

// Delete 删除截图
func (h *ScreenshotHandler) Delete(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		models.SendError(c, 400, 1001, "Screenshot ID is required")
		return
	}
	if !h.enforceScreenshotAccessByID(c, id) {
		return
	}

	// 获取截图信息
	screenshot, err := h.repo.GetByID(c.Request.Context(), id)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			models.SendError(c, 404, 3001, "Screenshot not found")
		} else {
			models.SendError(c, 500, 5000, err.Error())
		}
		return
	}

	// 删除文件（如果有）
	if screenshot.FilePath != "" {
		// 从文件路径中提取相对路径
		filePath := strings.TrimPrefix(screenshot.FilePath, "/uploads/")
		fullPath := filepath.Join("uploads", filePath)
		services.RemoveScreenshotThumbnail(fullPath)
		if err := os.Remove(fullPath); err != nil && !os.IsNotExist(err) {
			// 文件删除失败只记录日志，不影响数据库删除
			log.Printf("Failed to delete screenshot file: %v", err)
		}
	}

	// 从数据库删除记录
	if err := h.repo.Delete(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "Screenshot deleted successfully", nil)
}

// GetOverview 截图概览：每位员工最近 N 张截图
func (h *ScreenshotHandler) GetOverview(c *gin.Context) {
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "10"))
	if limit < 1 {
		limit = 10
	}
	if limit > 30 {
		limit = 30
	}

	var deviceFilter []uuid.UUID
	if middleware.IsEmployeeRole(c) {
		ids, ok := middleware.ResolveEmployeeDeviceIDs(c)
		if !ok || len(ids) == 0 {
			models.SendError(c, 403, 1003, "No device bound to your account")
			return
		}
		deviceFilter = ids
	}

	startDate := c.Query("startDate")
	endDate := c.Query("endDate")
	startTime := c.Query("startTime")
	endTime := c.Query("endTime")

	items, err := h.repo.ListOverview(c.Request.Context(), limit, deviceFilter, startDate, endDate, startTime, endTime)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", models.ScreenshotOverviewResponse{
		Limit: limit,
		Items: items,
	})
}

// GetEmployeeScreenshotStats 获取员工的截图统计（今日 + 总计）
func (h *ScreenshotHandler) GetEmployeeScreenshotStats(c *gin.Context) {
    deviceID := c.Param("deviceId")
    if deviceID == "" {
        models.SendError(c, 400, 1001, "Device ID is required")
        return
    }
    parsedDeviceID, err := uuid.Parse(deviceID)
    if err != nil {
        models.SendError(c, 400, 1001, "Invalid device ID")
        return
    }
    if !middleware.EnforceEmployeeDeviceScope(c, parsedDeviceID) {
        return
    }

    // 获取今日截图数量
    todayCount, err := h.repo.CountTodayByDevice(c.Request.Context(), deviceID)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // 获取总截图数量
    totalCount, err := h.repo.CountByDevice(c.Request.Context(), deviceID)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    models.Send(c, 200, 0, "success", gin.H{
        "todayCount": todayCount,
        "totalCount": totalCount,
    })
}

// GetBatchEmployeeScreenshotStats 批量获取设备截图统计
func (h *ScreenshotHandler) GetBatchEmployeeScreenshotStats(c *gin.Context) {
    deviceIDs := c.QueryArray("deviceIds[]")
    if len(deviceIDs) == 0 {
        if raw := strings.TrimSpace(c.Query("deviceIds")); raw != "" {
            deviceIDs = strings.Split(raw, ",")
        }
    }
    if len(deviceIDs) == 0 {
        models.Send(c, 200, 0, "success", gin.H{})
        return
    }
    if len(deviceIDs) > 200 {
        models.SendError(c, 400, 1001, "deviceIds too many (max 200)")
        return
    }

    allowed := make([]string, 0, len(deviceIDs))
    for _, id := range deviceIDs {
        id = strings.TrimSpace(id)
        if id == "" {
            continue
        }
        parsed, err := uuid.Parse(id)
        if err != nil {
            continue
        }
        if !middleware.EnforceEmployeeDeviceScope(c, parsed) {
            return
        }
        allowed = append(allowed, id)
    }

    stats, err := h.repo.CountStatsByDevices(c.Request.Context(), allowed)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    payload := make(map[string]gin.H, len(allowed))
    for _, id := range allowed {
        if s, ok := stats[id]; ok {
            payload[id] = gin.H{"todayCount": s.TodayCount, "totalCount": s.TotalCount}
        } else {
            payload[id] = gin.H{"todayCount": 0, "totalCount": 0}
        }
    }
    models.Send(c, 200, 0, "success", payload)
}

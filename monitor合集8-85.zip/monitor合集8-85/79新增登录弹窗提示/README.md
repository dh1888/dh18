# monitorWin

企业终端监控平台：**Go 后端** + **Vue 管理端** + **Windows 客户端（DHPG / Enterprise Agent）**。

支持设备在线、录屏/截图、远程查看（LiveKit WHIP）、域名健康检测、考勤等模块。

| 文档 | 内容 |
|------|------|
| [docs/配置说明.md](docs/配置说明.md) | 环境变量、Nginx、CORS 等总配置 |
| [docs/livekit-部署流程.md](docs/livekit-部署流程.md) | LiveKit / 远程查看完整部署 |
| [docs/域名检测-部署流程.md](docs/域名检测-部署流程.md) | 域名监控中心 + dm-probe |
| [docs/backend后端env服务器配置.txt](docs/backend后端env服务器配置.txt) | 生产 backend `.env` 参考 |
| [docs/nginx.conf](docs/nginx.conf) | 宝塔站点 vhost 示例 |

**生产示例主机：** `43.106.86.216` / `https://dhpg8.duckdns.org`（按实际域名替换下文中的占位符）。

---

## 目录结构

| 路径 | 说明 |
|------|------|
| `backend/` | Go API、WebSocket、域名监控中心、dm-probe 源码 |
| `frontend/` | Vue 3 管理端 |
| `agent/` | Windows 客户端源码与 `publish/` 产物 |
| `livekit/` | **LiveKit 生产配置源**（同步到服务器） |
| `docs/` | 部署与运维文档 |
| `downloads/` | 客户端安装包（供 Web 下载） |
| `scripts/publish-client.ps1` | 客户端打包脚本 |

---

## 一、本地开发快速启动

### 1. 后端

依赖：PostgreSQL、Redis、Go 1.21+。

```powershell
cd backend
copy .env.example .env
# 编辑 .env：数据库、Redis、JWT_SECRET、POLICY_SIGNATURE_SECRET 等
go run .
# 默认监听 :8080
```

本地远程查看可选：按 `docs/livekit-部署流程.md` 起 LiveKit，或暂时不测远程模块。

### 2. 前端

```powershell
cd frontend
copy .env.example .env.development   # 如需要
npm install
npm run dev
# 默认 http://localhost:5173，API 经 Vite 代理到后端
```

### 3. 客户端（开发调试）

```powershell
# 编辑 agent/deployment.json（serverUrl 指向本地或测试服）
cd agent
dotnet run
# 或使用 publish/DHPG.exe（须同目录有 ffmpeg.exe）
```

打包供 Web 下载与自动更新：

```powershell
# 在项目根目录（需安装 Inno Setup 6 以生成 MonitorAgentSetup.exe）
powershell -ExecutionPolicy Bypass -File scripts/publish-client.ps1
# 生成 downloads/MonitorAgentSetup.exe 与 downloads/MonitorAgent-update.zip
```

后端 `.env` 示例：

```env
CLIENT_DOWNLOAD_FILE=MonitorAgentSetup.exe
CLIENT_UPDATE_FILE=MonitorAgent-update.zip
CLIENT_VERSION=2.0.0
```

---

## 二、生产部署总览

推荐单机布局（可按实际调整）：

```text
/www/wwwroot/agent/backend/     # Go 后端 + .env + uploads
/www/wwwroot/agent/frontend/dist/  # 前端静态资源（Nginx root）
/www/wwwroot/livekit/           # LiveKit + Ingress + Redis(compose)
Nginx 反代：HTTPS 443 → 静态 + /api/v1 + /ws + /livekit + /w
```

部署顺序建议：

1. PostgreSQL / Redis  
2. Backend `.env` + 进程守护  
3. 前端 `npm run build` 上传 dist  
4. Nginx + 证书  
5. LiveKit（若要用远程查看）  
6. 客户端打包与下载配置  
7. 域名检测探针（可选）

---

## 三、Backend 生产部署

### 1. 准备环境

- PostgreSQL（库名按 `.env`）
- Redis
- 上传编译好的 Linux 二进制，或在服务器 `go build -o agent-backend .`

### 2. 配置 `.env`

参考：`docs/backend后端env服务器配置.txt`。关键项示例：

```env
PORT=8080
ENV=production
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=<强密码>
DB_NAME=postgres

JWT_SECRET=<随机长串>
POLICY_SIGNATURE_SECRET=<与 agent/deployment.json 一致>
DEVICE_REGISTRATION_SECRET=<随机串>

REDIS_ADDR=localhost:6379
REDIS_PASSWORD=<密码>
REDIS_DB=0

CORS_ALLOWED_ORIGINS=https://dhpg8.duckdns.org,https://43.106.86.216
UPLOADS_DIR=./uploads
UPLOAD_SHARED_STORAGE=true

CLIENT_DOWNLOAD_DIR=./downloads
CLIENT_DOWNLOAD_FILE=MonitorAgentSetup.exe
CLIENT_UPDATE_FILE=MonitorAgent-update.zip
CLIENT_VERSION=2.0.0

WS_TICKET_REQUIRED=true

# LiveKit（远程查看）
LIVEKIT_URL=wss://dhpg8.duckdns.org/livekit
LIVEKIT_API_HOST=http://127.0.0.1:7880
LIVEKIT_API_KEY=enterprise
LIVEKIT_API_SECRET=<与 livekit/livekit.yaml 一致>
LIVEKIT_WHIP_BASE_URL=https://dhpg8.duckdns.org/w
LIVEKIT_RTMP_BASE_URL=rtmp://43.106.86.216:1935/x
REMOTE_VIEW_PUBLISH_PROTOCOL=whip

# 域名监控中心
DOMAIN_MONITOR_ENABLED=true
DM_SECRET_KEY=<随机串>
DM_WORKER_POOL_SIZE=50
DM_REPORTS_ENABLED=true
```

> 生产务必改掉文档里的示例密码与密钥。`REMOTE_VIEW_PUBLISH_PROTOCOL` 必须为 **`whip`**（不要用 `auto`）。

### 3. 启动

用 Supervisor / systemd / 宝塔进程守护，工作目录指向 backend，加载 `.env`。

自检：

```bash
curl -sI http://127.0.0.1:8080/api/v1/meta/capabilities
```

---

## 四、Frontend 生产部署

```powershell
cd frontend
# 检查 .env.production（同域反代时可留空 API 基址，走相对路径）
npm ci
npm run build
```

将 `frontend/dist/` 上传到服务器，例如：

```text
/www/wwwroot/agent/frontend/dist/
```

Nginx `root` 指向该目录（见下一节）。

---

## 五、Nginx

完整示例：`docs/nginx.conf`。必须包含：

| location | 后端 |
|----------|------|
| `/` | 静态 dist |
| `/api/v1/` | `http://127.0.0.1:8080` |
| `/ws/` | WebSocket 升级到 backend |
| `/livekit/` | `http://127.0.0.1:7880/`（LiveKit 信令） |
| `/w/` | `http://127.0.0.1:8085/w/`（Agent WHIP 信令，仅反代本机） |

```bash
nginx -t && nginx -s reload
```

CORS：同域反代时影响较小；生产仍建议在 `.env` 或 Web「系统设置」配置：

```env
CORS_ALLOWED_ORIGINS=https://你的域名
```

优先级：Web 后台白名单 > `.env` > 开发默认值。

---

## 六、LiveKit / 远程查看

**详细步骤：** [docs/livekit-部署流程.md](docs/livekit-部署流程.md)

### 要点

1. 配置源是仓库 **`livekit/`**（不是过时的本地 tools）。
2. 同步到服务器 `/www/wwwroot/livekit/`：

```bash
mkdir -p /www/wwwroot/livekit
# 上传 livekit/livekit.yaml、livekit/docker-compose.yml
cd /www/wwwroot/livekit
# eth0 私网变更时改 compose 内 node_ip: 公网IP/私网IP
docker compose up -d
curl -sI http://127.0.0.1:8085/w/testkey   # 期望 405
ss -ulnp | grep 7893
```

3. 安全组放行：`443`、`7881/TCP`、`7882–7892/UDP`、**`7893/UDP`**；**不要**公网开 `8085`；Ingress **不要**配 `tcp_port`。
4. Backend：`REMOTE_VIEW_PUBLISH_PROTOCOL=whip` + `LIVEKIT_WHIP_BASE_URL=https://域名/w`。
5. Agent：`publish/DHPG.exe` **同目录必须有 `ffmpeg.exe`**；成功日志含 `WHIP muxer ready` / `WHIP media flowing`。

### 公网快速自检

```bash
curl -sI https://dhpg8.duckdns.org/livekit/    # 200
curl -sI https://dhpg8.duckdns.org/w/testkey   # 405
```

---

## 七、Windows 客户端（Agent）

1. 编辑 `agent/deployment.json`：
   - `serverUrl`：生产 HTTPS 域名（或调试用 HTTP IP）
   - `policySignatureSecret`：与 backend `.env` 一致
   - 生产：`allowInsecureTransport: false`，`wsTicketRequired: true`
2. 打包：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/publish-client.ps1
```

3. 确认 `downloads/MonitorAgentSetup.exe` 与 `MonitorAgent-update.zip`，backend `.env` 中 `CLIENT_DOWNLOAD_*` / `CLIENT_UPDATE_FILE` / `CLIENT_VERSION` 已配置。
4. 打包机需安装 **Inno Setup 6** 才能生成 Setup.exe（员工端不需要）。
5. 发布目录内放置 **`ffmpeg.exe`**（录屏与远程查看都依赖它）。
6. 员工 Web 登录后右上角下载安装程序运行；托盘应显示已连接。已安装用户可通过 **设置 → 检查更新** 升级。

---

## 八、域名检测（中心 + 探针）

**详细步骤：** [docs/域名检测-部署流程.md](docs/域名检测-部署流程.md)

### 中心

```env
DOMAIN_MONITOR_ENABLED=true
DM_SECRET_KEY=<随机串>
DM_REPORTS_ENABLED=true
```

重启 backend → Web「域名监控」添加域名 / 检测配置 / 节点。

**不要**在中心 `.env` 写 `DM_SERVER`、`DM_NODE_KEY`。

### 探针（独立 VPS）

```powershell
cd backend
$env:GOOS="linux"; $env:GOARCH="amd64"; $env:CGO_ENABLED="0"
go build -o dm-probe ./cmd/dm-probe
```

探针机：

```bash
# /opt/dm-probe/dm-probe.env
DM_SERVER=https://dhpg8.duckdns.org
DM_NODE_KEY=<后台节点 API Key>
```

systemd 常驻后，中心「节点」页应显示在线。更多见 `docs/dm-probe-部署说明.md`。

---

## 九、客户端下载（员工端）

1. **打包机**安装 [Inno Setup 6](https://jrsoftware.org/isinfo.php)，在项目根目录运行 `scripts/publish-client.ps1`。
2. 将 `downloads/MonitorAgentSetup.exe` 与 `MonitorAgent-update.zip` 放到 backend 的 `CLIENT_DOWNLOAD_DIR`。
3. `.env`：

```env
CLIENT_DOWNLOAD_FILE=MonitorAgentSetup.exe
CLIENT_UPDATE_FILE=MonitorAgent-update.zip
CLIENT_VERSION=2.0.0
```

4. 员工登录管理端 → 右上角下载安装程序；已安装客户端可通过托盘 **检查更新** 热升级。

---

## 十、上线验收清单

- [ ] `https://域名` 打开管理端，可登录  
- [ ] API / WebSocket 正常（设备列表、在线状态）  
- [ ] 客户端能注册、策略下发、截图/录屏（有 ffmpeg）  
- [ ] 远程查看：开始/停止/再开始均能出画（WHIP）  
- [ ] （可选）域名监控节点在线、任务有结果  
- [ ] CORS Origin 含实际访问地址  
- [ ] 生产密钥已非文档默认值  

---

## 十一、常见问题

| 现象 | 处理 |
|------|------|
| 远程黑屏 / `ffmpeg not found` | Agent 目录放置 `ffmpeg.exe` |
| WHIP `ret=-5` | Ingress 去掉 `tcp_port`，只保留 UDP 7893 |
| 关远程再开画面冻住 | 确认已部署含 Room 清理的 backend + 前端；见 LiveKit 文档 |
| 探针 heartbeat 401 | 检查 `DM_NODE_KEY` 与 `DM_SERVER` |
| 跨域 / WS 失败 | 配置 `CORS_ALLOWED_ORIGINS` 或 Web 白名单 |
| 客户端连不上 | `serverUrl`、证书、`WS_TICKET_REQUIRED` 与 ticket 流程 |

---

## 十二、文档索引

| 文件 | 用途 |
|------|------|
| `docs/配置说明.md` | 全量配置说明 |
| `docs/livekit-部署流程.md` | LiveKit 逐步部署 |
| `docs/whip-only-deploy.md` / `docs/whip-ops.md` | WHIP 上线检查 / 运维 |
| `docs/域名检测-部署流程.md` | 域名监控全流程 |
| `docs/dm-probe-部署说明.md` | 探针专项 |
| `docs/backend后端env服务器配置.txt` | 生产 env 参考 |
| `docs/nginx.conf` | Nginx vhost |
| `livekit/` | LiveKit 配置源 + README |

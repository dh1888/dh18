using System.Diagnostics;
using EnterpriseAgent.Agent.Capture.Hub;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EnterpriseAgent.Agent.Capture;

/// <summary>
/// Desktop capture (gdigrab) → SharedFrameHub → per-consumer frame workers → named pipes.
/// </summary>
public sealed class SharedCaptureBridge : ISharedCaptureBridge, IFrameWorkerHost
{
    private static readonly TimeSpan ConsumerConnectTimeout = TimeSpan.FromSeconds(30);
    private static readonly TimeSpan FlowingTimeout = TimeSpan.FromSeconds(45);

    private readonly ILogger<SharedCaptureBridge> _logger;
    private readonly SharedCapturePipeHost _pipeHost;
    private readonly SharedFrameHub _hub = new();
    private readonly SharedFrameHubConfig _hubConfig;
    private readonly object _stateGate = new();
    private TaskCompletionSource _flowingTcs = CreateFlowingTcs();

    private Process? _bridgeProcess;
    private Task? _captureTask;
    private Task? _recordingWorkerTask;
    private Task? _remoteWorkerTask;
    private PipeFrameWorker? _recordingWorker;
    private PipeFrameWorker? _remoteWorker;
    private CancellationTokenSource? _bridgeCts;
    private byte[]? _readBuffer;
    private int _captureWidth;
    private int _captureHeight;
    private int _captureFps;
    private SharedBridgeState _state = SharedBridgeState.Idle;
    private SharedBridgeReadyFlags _readyFlags;
    private DateTime _lastFrameUtc = DateTime.MinValue;
    private long _lastFrameCount;
    private long _producerSessionFrames;
    private SharedBridgeReadyFlags _flowingRequiredFlags = SharedBridgeReady.RunningRequired;
    private string? _lastError;
    private bool _disposed;

    // [PipelineDiag] temporary: hub publish rate once per second
    private long _diagLastPublishedSnapshot;
    private DateTime _diagFpsLogUtc = DateTime.MinValue;

    public SharedCaptureBridge(
        ILogger<SharedCaptureBridge> logger,
        SharedCapturePipeHost pipeHost,
        IOptions<CaptureConfig> config)
    {
        _logger = logger;
        _pipeHost = pipeHost;
        _hubConfig = config.Value.SharedFrameHub ?? new SharedFrameHubConfig();
    }

    public SharedBridgeState State
    {
        get { lock (_stateGate) return _state; }
    }

    public SharedBridgeReadyFlags ReadyFlags
    {
        get { lock (_stateGate) return _readyFlags; }
    }

    public bool IsActive =>
        State is SharedBridgeState.Preparing
            or SharedBridgeState.PipesListening
            or SharedBridgeState.ConsumersConnected
            or SharedBridgeState.BridgeStarting
            or SharedBridgeState.Flowing;

    public async Task PrepareAsync(int width, int height, int fps, CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        if (State == SharedBridgeState.Stopped)
            TransitionTo(SharedBridgeState.Idle);

        _captureWidth = width;
        _captureHeight = height;
        _captureFps = fps;

        TransitionTo(SharedBridgeState.Preparing);
        _logger.LogInformation("Bridge Preparing: {Width}x{Height}@{Fps}", width, height, fps);

        ResetFlowingSignal();
        SetReadyFlag(SharedBridgeReadyFlags.None, replace: true);

        await _pipeHost.PrepareAsync(width, height, fps, cancellationToken);
        _hub.StartSession(_pipeHost.FrameBytes, _hubConfig.PoolSlotCount);
        _readBuffer = new byte[_pipeHost.FrameBytes];

        SetReadyFlag(SharedBridgeReadyFlags.PipesListening);
        TransitionTo(SharedBridgeState.PipesListening);
        _logger.LogInformation(
            "Bridge state: PipesListening (SharedFrameHub poolSlots={PoolSlots})",
            _hubConfig.PoolSlotCount);
    }

    public async Task WaitConsumersConnectedAsync(CancellationToken cancellationToken = default, bool requireRemote = true)
    {
        EnsureState(SharedBridgeState.PipesListening);
        if (requireRemote)
        {
            await _pipeHost.WaitConsumersConnectedAsync(ConsumerConnectTimeout, cancellationToken);
            SetReadyFlag(SharedBridgeReadyFlags.RecordingConnected | SharedBridgeReadyFlags.RemoteConnected);
            _logger.LogInformation("Recording Connected; Remote Connected");
        }
        else
        {
            await _pipeHost.WaitConsumerConnectedAsync(
                CaptureConsumer.Recording, ConsumerConnectTimeout, cancellationToken);
            SetReadyFlag(SharedBridgeReadyFlags.RecordingConnected);
            _logger.LogInformation("Recording Connected (remote FFmpeg deferred)");
        }

        TransitionTo(SharedBridgeState.ConsumersConnected);
    }

    public async Task StartBridgeAsync(CancellationToken cancellationToken = default)
    {
        EnsureState(SharedBridgeState.ConsumersConnected);

        var ffmpeg = FindFfmpeg();
        if (string.IsNullOrWhiteSpace(ffmpeg))
            throw new InvalidOperationException("ffmpeg.exe not found for SharedCaptureBridge");

        if (!_hub.IsActive)
        {
            _hub.StartSession(_pipeHost.FrameBytes, _hubConfig.PoolSlotCount);
            _readBuffer ??= new byte[_pipeHost.FrameBytes];
        }

        TransitionTo(SharedBridgeState.BridgeStarting);
        _logger.LogInformation("Bridge Started (launching gdigrab → SharedFrameHub)");

        _bridgeCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var linked = _bridgeCts.Token;

        var captureEngine = new HubCaptureEngine(_logger, _hub);
        _recordingWorker = new PipeFrameWorker(
            _logger,
            _hub,
            _pipeHost,
            this,
            CaptureConsumer.Recording,
            _hubConfig.RecordingReaderPolicy);
        _remoteWorker = new PipeFrameWorker(
            _logger,
            _hub,
            _pipeHost,
            this,
            CaptureConsumer.RemoteView,
            _hubConfig.RemoteReaderPolicy,
            _hubConfig.RemotePipeWriteTimeoutMs);

        _logger.LogInformation(
            "SharedFrameHub workers: recording={RecPolicy} remote={RemotePolicy} remoteWriteTimeoutMs={WriteTimeoutMs}",
            _hubConfig.RecordingReaderPolicy,
            _hubConfig.RemoteReaderPolicy,
            _hubConfig.RemotePipeWriteTimeoutMs);

        _bridgeProcess = HubCaptureEngine.StartGdigrabProcess(
            _logger,
            ffmpeg,
            _captureWidth,
            _captureHeight,
            _captureFps,
            linked);

        Interlocked.Exchange(ref _producerSessionFrames, 0);
        _diagLastPublishedSnapshot = _hub.PublishedFrames;
        _diagFpsLogUtc = DateTime.UtcNow;

        _recordingWorkerTask = Task.Run(() => _recordingWorker.RunAsync(linked), CancellationToken.None);
        _remoteWorkerTask = Task.Run(() => _remoteWorker.RunAsync(linked), CancellationToken.None);
        _captureTask = Task.Run(
            () => captureEngine.RunAsync(_bridgeProcess, _readBuffer!, OnCaptureFramePublished, linked),
            CancellationToken.None);

        ObserveTask(_captureTask, "capture");
        ObserveTask(_recordingWorkerTask, "recording-worker");
        ObserveTask(_remoteWorkerTask, "remote-worker");

        SetReadyFlag(SharedBridgeReadyFlags.BridgeStarted);
        _logger.LogInformation("Bridge producer process started pid={Pid}", _bridgeProcess.Id);
    }

    public async Task WaitFlowingAsync(
        CancellationToken cancellationToken = default,
        bool requireConsumerFirstFrames = true,
        bool requireRemoteConsumer = true)
    {
        EnsureAtLeast(SharedBridgeState.BridgeStarting);

        _flowingRequiredFlags = !requireRemoteConsumer
            ? SharedBridgeReady.RecordingFlowingRequired
            : requireConsumerFirstFrames
                ? SharedBridgeReady.RunningRequired
                : SharedBridgeReady.ProducerFlowingRequired;

        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(FlowingTimeout);

        try
        {
            await _flowingTcs.Task.WaitAsync(timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException(
                $"Timed out waiting for SharedBridge first frame (ready={ReadyFlags}, required={_flowingRequiredFlags}, hubPublished={_hub.PublishedFrames}, producerFrames={_producerSessionFrames})");
        }

        if ((ReadyFlags & _flowingRequiredFlags) != _flowingRequiredFlags)
        {
            throw new InvalidOperationException(
                $"SharedBridge not fully ready: missing {(_flowingRequiredFlags & ~ReadyFlags)}");
        }

        TransitionTo(SharedBridgeState.Flowing);
        _logger.LogInformation("Bridge Flowing");
    }

    public async Task RestartProducerAsync(CancellationToken cancellationToken = default)
    {
        if (State is not (SharedBridgeState.Flowing
            or SharedBridgeState.BridgeStarting
            or SharedBridgeState.ConsumersConnected))
        {
            _logger.LogWarning("SharedBridge producer restart skipped in state {State}", State);
            return;
        }

        _logger.LogInformation("SharedBridge producer restart (consumers remain connected)");

        if (State is not SharedBridgeState.ConsumersConnected)
            await StopProducerInternalAsync(cancellationToken);

        lock (_stateGate)
        {
            _readyFlags &= SharedBridgeReadyFlags.PipesListening
                | SharedBridgeReadyFlags.RecordingConnected
                | SharedBridgeReadyFlags.RemoteConnected
                | SharedBridgeReadyFlags.RecordingFirstFrame
                | SharedBridgeReadyFlags.RemoteFirstFrame;
        }

        ResetFlowingSignal();
        _flowingRequiredFlags = SharedBridgeReady.ProducerFlowingRequired;
        TransitionTo(SharedBridgeState.ConsumersConnected);
        await StartBridgeAsync(cancellationToken);
        await WaitFlowingAsync(cancellationToken, requireConsumerFirstFrames: false);
    }

    public async Task ReconnectConsumerAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        if (State is SharedBridgeState.Idle or SharedBridgeState.Stopped or SharedBridgeState.Preparing)
        {
            throw new InvalidOperationException(
                $"Cannot reconnect {consumer} pipe while SharedBridge is in state {State}");
        }

        _logger.LogInformation("SharedBridge reconnect consumer: {Consumer}", consumer);

        await _pipeHost.ReconnectPipeAsync(consumer, ConsumerConnectTimeout, cancellationToken);

        lock (_stateGate)
        {
            if (consumer == CaptureConsumer.Recording)
            {
                _readyFlags |= SharedBridgeReadyFlags.RecordingConnected;
                _readyFlags &= ~SharedBridgeReadyFlags.RecordingFirstFrame;
            }
            else
            {
                _readyFlags |= SharedBridgeReadyFlags.RemoteConnected;
                _readyFlags &= ~SharedBridgeReadyFlags.RemoteFirstFrame;
            }
        }

        _logger.LogInformation("SharedBridge consumer reconnected: {Consumer}", consumer);
    }

    public async Task RecreateConsumerPipeAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        if (State is SharedBridgeState.Idle or SharedBridgeState.Stopped or SharedBridgeState.Preparing)
        {
            throw new InvalidOperationException(
                $"Cannot recreate {consumer} pipe while SharedBridge is in state {State}");
        }

        _logger.LogInformation("SharedBridge recreate consumer pipe (listen): {Consumer}", consumer);
        await _pipeHost.RecreatePipeListeningAsync(consumer, cancellationToken);

        if (consumer == CaptureConsumer.RemoteView)
            ResetConsumerFrameReader(CaptureConsumer.RemoteView, snapToLatest: true);

        lock (_stateGate)
        {
            if (consumer == CaptureConsumer.Recording)
            {
                _readyFlags &= ~SharedBridgeReadyFlags.RecordingConnected;
                _readyFlags &= ~SharedBridgeReadyFlags.RecordingFirstFrame;
            }
            else
            {
                _readyFlags &= ~SharedBridgeReadyFlags.RemoteConnected;
                _readyFlags &= ~SharedBridgeReadyFlags.RemoteFirstFrame;
            }
        }
    }

    public void ResetConsumerFrameReader(CaptureConsumer consumer, bool snapToLatest = true)
    {
        var worker = consumer == CaptureConsumer.Recording ? _recordingWorker : _remoteWorker;
        worker?.ResetReader(snapToLatest);

        lock (_stateGate)
        {
            if (consumer == CaptureConsumer.Recording)
                _readyFlags &= ~SharedBridgeReadyFlags.RecordingFirstFrame;
            else
                _readyFlags &= ~SharedBridgeReadyFlags.RemoteFirstFrame;
        }
    }

    public Task ResetSessionAsync(CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        ResetFlowingSignal();
        SetReadyFlag(SharedBridgeReadyFlags.None, replace: true);
        TransitionTo(SharedBridgeState.Idle);
        _lastError = null;
        _lastFrameUtc = DateTime.MinValue;
        Interlocked.Exchange(ref _lastFrameCount, 0);
        _readBuffer = null;
        _hub.StopSession();

        _logger.LogInformation("SharedBridge session reset to Idle");
        return Task.CompletedTask;
    }

    public async Task StopAsync(CancellationToken cancellationToken = default)
    {
        if (State is SharedBridgeState.Idle or SharedBridgeState.Stopped)
            return;

        TransitionTo(SharedBridgeState.Stopping);
        _logger.LogInformation("Bridge Stop");

        await StopProducerInternalAsync(cancellationToken);
        await _pipeHost.StopAsync();
        TransitionTo(SharedBridgeState.Stopped);
        _logger.LogInformation("Bridge Stopped");
    }

    private async Task StopProducerInternalAsync(CancellationToken cancellationToken)
    {
        _bridgeCts?.Cancel();

        if (_bridgeProcess is { HasExited: false })
        {
            try
            {
                if (!_bridgeProcess.WaitForExit(3000))
                    _bridgeProcess.Kill(entireProcessTree: true);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to stop bridge producer process");
            }
        }

        await WaitWorkerTaskAsync(_captureTask, cancellationToken);
        await WaitWorkerTaskAsync(_recordingWorkerTask, cancellationToken);
        await WaitWorkerTaskAsync(_remoteWorkerTask, cancellationToken);

        _hub.StopSession();

        _bridgeProcess?.Dispose();
        _bridgeProcess = null;
        _captureTask = null;
        _recordingWorkerTask = null;
        _remoteWorkerTask = null;
        _remoteWorker = null;
        _recordingWorker = null;
        _bridgeCts?.Dispose();
        _bridgeCts = null;
    }

    private static async Task WaitWorkerTaskAsync(Task? task, CancellationToken cancellationToken)
    {
        if (task == null)
            return;

        try
        {
            await task.WaitAsync(TimeSpan.FromSeconds(5), cancellationToken);
        }
        catch
        {
            // ignore worker shutdown timeout
        }
    }

    public async Task DisposeAsync(CancellationToken cancellationToken = default)
    {
        if (_disposed) return;
        _disposed = true;
        await StopAsync(cancellationToken);
        await _pipeHost.DisposeAsync();
        _hub.Dispose();
    }

    void IFrameWorkerHost.OnWorkerFirstFrame(CaptureConsumer consumer) =>
        NotifyConsumerFirstFrame(consumer);

    void IFrameWorkerHost.OnWorkerPipeFailure(CaptureConsumer consumer, Exception ex) =>
        _lastError = ex.Message;

    private void OnCaptureFramePublished()
    {
        _lastFrameUtc = DateTime.UtcNow;

        if (Interlocked.Increment(ref _producerSessionFrames) == 1)
        {
            SetReadyFlag(SharedBridgeReadyFlags.FirstFrameWritten);
            _logger.LogInformation("First Frame published to SharedFrameHub");
            TryMarkFlowing();
        }

        MaybeLogPipelineDiagFramesPerSecond();
    }

    public void NotifyConsumerFirstFrame(CaptureConsumer consumer)
    {
        switch (consumer)
        {
            case CaptureConsumer.Recording:
                SetReadyFlag(SharedBridgeReadyFlags.RecordingFirstFrame);
                _logger.LogInformation("Recording first frame observed on SharedBridge consumer");
                break;
            case CaptureConsumer.RemoteView:
                SetReadyFlag(SharedBridgeReadyFlags.RemoteFirstFrame);
                _logger.LogInformation("Remote first frame observed on SharedBridge consumer");
                break;
        }

        TryMarkFlowing();
    }

    public bool NeedsConsumerFirstFrame(CaptureConsumer consumer)
    {
        lock (_stateGate)
        {
            if (State is SharedBridgeState.Idle or SharedBridgeState.Stopped or SharedBridgeState.Preparing)
                return false;

            var flag = consumer == CaptureConsumer.Recording
                ? SharedBridgeReadyFlags.RecordingFirstFrame
                : SharedBridgeReadyFlags.RemoteFirstFrame;

            if ((_readyFlags & flag) != 0)
                return false;

            return consumer == CaptureConsumer.Recording
                ? _pipeHost.RecordingConnected
                : _pipeHost.RemoteConnected;
        }
    }

    public SharedBridgeHealthSnapshot GetHealthSnapshot()
    {
        var frames = _hub.IsActive ? _hub.PublishedFrames : _pipeHost.FramesWritten;
        var now = DateTime.UtcNow;
        var frameAge = _lastFrameUtc == DateTime.MinValue ? double.MaxValue : (now - _lastFrameUtc).TotalSeconds;
        var previous = Interlocked.Exchange(ref _lastFrameCount, frames);

        return new SharedBridgeHealthSnapshot
        {
            State = State,
            ReadyFlags = ReadyFlags,
            BridgeProcessAlive = IsBridgeProcessAliveSafe(),
            RecordingPipeConnected = _pipeHost.RecordingConnected,
            RemotePipeConnected = _pipeHost.RemoteConnected,
            RemotePipeServerActive = _pipeHost.RemotePipeServerActive,
            FrameFlowing = frames > 0 && frameAge < 5,
            FramesWritten = frames,
            FramesSinceUtc = frames - previous,
            LastFrameUtc = _lastFrameUtc,
            LastError = _lastError,
        };
    }

    private bool IsBridgeProcessAliveSafe()
    {
        try
        {
            var process = _bridgeProcess;
            return process is { HasExited: false };
        }
        catch (InvalidOperationException)
        {
            return false;
        }
        catch (Exception)
        {
            return false;
        }
    }

    private void ObserveTask(Task? task, string label)
    {
        if (task == null)
            return;

        _ = task.ContinueWith(
            t =>
            {
                if (t.Exception == null)
                    return;

                var ex = t.Exception.GetBaseException();
                _lastError = ex.Message;
                _logger.LogError(ex, "SharedBridge {Label} task faulted", label);
                if (label == "capture")
                {
                    _flowingTcs.TrySetException(ex);
                    StopProducerAfterCaptureFailure();
                }
            },
            CancellationToken.None,
            TaskContinuationOptions.OnlyOnFaulted,
            TaskScheduler.Default);
    }

    private void TryMarkFlowing()
    {
        if ((ReadyFlags & _flowingRequiredFlags) != _flowingRequiredFlags)
            return;

        _flowingTcs.TrySetResult();
    }

    private void StopProducerAfterCaptureFailure()
    {
        try
        {
            _bridgeCts?.Cancel();

            if (_bridgeProcess is { HasExited: false })
            {
                try
                {
                    if (!_bridgeProcess.WaitForExit(3000))
                        _bridgeProcess.Kill(entireProcessTree: true);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to kill bridge producer after capture failure");
                }
            }

            _hub.StopSession();
            _bridgeProcess?.Dispose();
            _bridgeProcess = null;
            _bridgeCts?.Dispose();
            _bridgeCts = null;

            if (State is SharedBridgeState.Flowing or SharedBridgeState.BridgeStarting)
            {
                lock (_stateGate)
                {
                    _readyFlags &= SharedBridgeReadyFlags.PipesListening
                        | SharedBridgeReadyFlags.RecordingConnected
                        | SharedBridgeReadyFlags.RemoteConnected
                        | SharedBridgeReadyFlags.RecordingFirstFrame
                        | SharedBridgeReadyFlags.RemoteFirstFrame;
                }

                TransitionTo(SharedBridgeState.ConsumersConnected);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to stop SharedBridge producer after capture failure");
        }
    }

    private void ResetFlowingSignal() => _flowingTcs = CreateFlowingTcs();

    private static TaskCompletionSource CreateFlowingTcs() =>
        new(TaskCreationOptions.RunContinuationsAsynchronously);

    private void SetReadyFlag(SharedBridgeReadyFlags flag, bool replace = false)
    {
        lock (_stateGate)
            _readyFlags = replace ? flag : _readyFlags | flag;
    }

    private void TransitionTo(SharedBridgeState state)
    {
        lock (_stateGate)
            _state = state;
    }

    private void EnsureState(SharedBridgeState expected)
    {
        if (State != expected)
            throw new InvalidOperationException($"SharedBridge expected state {expected} but was {State}");
    }

    private void EnsureAtLeast(SharedBridgeState expected)
    {
        if (State < expected)
            throw new InvalidOperationException($"SharedBridge expected at least {expected} but was {State}");
    }

    private static string? FindFfmpeg()
    {
        var paths = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "ffmpeg.exe"),
            Path.Combine(AppContext.BaseDirectory, "bin", "ffmpeg.exe"),
            @"C:\ffmpeg\bin\ffmpeg.exe",
        };

        foreach (var path in paths)
        {
            if (File.Exists(path))
                return path;
        }

        return null;
    }

    /// <summary>[PipelineDiag] temporary — log hub publish rate once per second.</summary>
    private void MaybeLogPipelineDiagFramesPerSecond()
    {
        var now = DateTime.UtcNow;
        if (_diagFpsLogUtc != DateTime.MinValue && now - _diagFpsLogUtc < TimeSpan.FromSeconds(1))
            return;

        var elapsedSec = _diagFpsLogUtc == DateTime.MinValue
            ? 1.0
            : Math.Max((now - _diagFpsLogUtc).TotalSeconds, 0.001);
        var total = _hub.PublishedFrames;
        var delta = total - _diagLastPublishedSnapshot;
        _diagLastPublishedSnapshot = total;
        _diagFpsLogUtc = now;

        var remoteStats = _remoteWorker?.Stats;
        var recordingStats = _recordingWorker?.Stats;
        var hubOverwrites = _hub.DroppedOverwrites;

        _logger.LogInformation(
            "[PipelineDiag] Hub Publish/s={Rate:F1} windowFrames={Delta} hubOverwrites={Overwrites} " +
            "recWritten={RecWritten} remoteWritten={RemoteWritten} remoteSkipped={RemoteSkipped} remoteWriteTimeouts={RemoteTimeouts} remoteRingDrops={RemoteRingDrops} pipeFrames={PipeFrames}",
            delta / elapsedSec,
            delta,
            hubOverwrites,
            recordingStats?.FramesWritten ?? 0,
            remoteStats?.FramesWritten ?? 0,
            remoteStats?.FramesSkipped ?? 0,
            remoteStats?.WriteTimeouts ?? 0,
            remoteStats?.HubRingDrops ?? 0,
            _pipeHost.FramesWritten);
    }
}

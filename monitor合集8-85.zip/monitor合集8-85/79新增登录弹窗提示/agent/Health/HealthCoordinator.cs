using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Lifecycle;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.RemoteView;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Health;

public sealed class HealthCoordinator : BackgroundService
{
    private readonly ILogger<HealthCoordinator> _logger;
    private readonly IRecordingHealthProbe _recordingProbe;
    private readonly IRemoteHealthProbe _remoteProbe;
    private readonly RecoveryPolicy _policy;
    private readonly ILifecycleCoordinator _lifecycle;
    private readonly IRecoveryRequestSink _recoverySink;
    private readonly ICaptureCoordinator _captureCoordinator;
    private readonly ISharedBridgeHealthProbe _sharedBridgeProbe;
    private readonly SemaphoreSlim _recoveryLock = new(1, 1);
    private DateTime _lastRecordingRecoveryUtc = DateTime.MinValue;
    private DateTime _lastRemoteRecoveryUtc = DateTime.MinValue;
    private DateTime _lastBridgeRecoveryUtc = DateTime.MinValue;

    public HealthCoordinator(
        ILogger<HealthCoordinator> logger,
        IRecordingHealthProbe recordingProbe,
        IRemoteHealthProbe remoteProbe,
        RecoveryPolicy policy,
        ILifecycleCoordinator lifecycle,
        IRecoveryRequestSink recoverySink,
        ICaptureCoordinator captureCoordinator,
        ISharedBridgeHealthProbe sharedBridgeProbe)
    {
        _logger = logger;
        _recordingProbe = recordingProbe;
        _remoteProbe = remoteProbe;
        _policy = policy;
        _lifecycle = lifecycle;
        _recoverySink = recoverySink;
        _captureCoordinator = captureCoordinator;
        _sharedBridgeProbe = sharedBridgeProbe;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await Task.Delay(TimeSpan.FromSeconds(20), stoppingToken);
        _logger.LogInformation("HealthCoordinator started");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var recording = _recordingProbe.Sample();
                var remote = _remoteProbe.Sample();
                var sharedActive = _captureCoordinator.IsSharedCaptureActive;
                var bridge = sharedActive ? _sharedBridgeProbe.Sample() : null;

                if (sharedActive && bridge != null)
                    LogSharedBridgeHealth(bridge);

                var captureDiagnostics = _lifecycle.GetDiagnostics();
                if (ShouldDeferRecovery(captureDiagnostics, _lifecycle.LastEnterFailureUtc))
                    continue;

                RecoveryDecision decision;
                if (_recoverySink.TryTakePendingRecordingRecovery(out var forcedReason))
                {
                    decision = new RecoveryDecision
                    {
                        Action = RecoveryAction.RecoverRecording,
                        Reason = forcedReason,
                    };
                }
                else
                {
                    decision = _policy.Evaluate(
                        recording,
                        remote,
                        bridge,
                        sharedActive,
                        _lifecycle.LastResumeUtc,
                        DateTime.UtcNow);
                }

                if (decision.Action != RecoveryAction.None)
                    await ExecuteRecoveryAsync(decision, stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "HealthCoordinator cycle error");
            }

            await Task.Delay(TimeSpan.FromSeconds(15), stoppingToken);
        }
    }

    private static bool ShouldDeferRecovery(CaptureLifecycleDiagnostics capture, DateTime lastEnterFailureUtc)
    {
        if (capture.CaptureState is CaptureLifecycleState.PreparingSharedBridge
            or CaptureLifecycleState.Rollback
            or CaptureLifecycleState.Recovering
            or CaptureLifecycleState.Stopping)
        {
            return true;
        }

        if (lastEnterFailureUtc != DateTime.MinValue
            && (DateTime.UtcNow - lastEnterFailureUtc).TotalSeconds < 90)
        {
            return true;
        }

        return false;
    }

    private async Task ExecuteRecoveryAsync(RecoveryDecision decision, CancellationToken ct)
    {
        if (!await _recoveryLock.WaitAsync(TimeSpan.FromSeconds(5), ct))
            return;

        try
        {
            switch (decision.Action)
            {
                case RecoveryAction.RecoverRecording:
                    if (DateTime.UtcNow - _lastRecordingRecoveryUtc < TimeSpan.FromSeconds(45))
                        return;
                    _lastRecordingRecoveryUtc = DateTime.UtcNow;
                    _logger.LogWarning("HealthCoordinator emitting RecoverRecording intent: {Reason}", decision.Reason);
                    await _lifecycle.RequestAsync(
                        RecorderCommand.RecoverRecording,
                        new RecorderRequestContext { Reason = decision.Reason },
                        ct);
                    break;

                case RecoveryAction.ReconnectRemote:
                    if (DateTime.UtcNow - _lastRemoteRecoveryUtc < TimeSpan.FromSeconds(30))
                        return;
                    _lastRemoteRecoveryUtc = DateTime.UtcNow;
                    _logger.LogWarning("HealthCoordinator reconnecting remote: {Reason}", decision.Reason);
                    await _lifecycle.RequestAsync(
                        RecorderCommand.ReconnectRemote,
                        new RecorderRequestContext { Reason = decision.Reason },
                        ct);
                    break;

                case RecoveryAction.RecoverSharedBridge:
                    if (DateTime.UtcNow - _lastBridgeRecoveryUtc < TimeSpan.FromSeconds(45))
                        return;
                    _lastBridgeRecoveryUtc = DateTime.UtcNow;
                    _logger.LogWarning("HealthCoordinator recovering SharedBridge via lifecycle: {Reason}", decision.Reason);
                    await _lifecycle.RequestAsync(
                        RecorderCommand.RecoverSharedBridge,
                        new RecorderRequestContext { Reason = decision.Reason },
                        ct);
                    break;

                case RecoveryAction.ExitRemoteFailed:
                    _logger.LogError("HealthCoordinator remote failed: {Reason}", decision.Reason);
                    await _lifecycle.RequestAsync(
                        RecorderCommand.ExitRemoteView,
                        new RecorderRequestContext { Reason = decision.Reason },
                        ct);
                    break;
            }
        }
        finally
        {
            _recoveryLock.Release();
        }
    }

    private void LogSharedBridgeHealth(SharedBridgeHealthSnapshot bridge)
    {
        if (bridge.State != SharedBridgeState.Flowing)
            return;

        if (bridge.FrameFlowing)
            return;

        _logger.LogWarning(
            "SharedBridge unhealthy: state={State} bridgeAlive={BridgeAlive} recPipe={RecPipe} remotePipe={RemotePipe} frames={Frames} error={Error}",
            bridge.State,
            bridge.BridgeProcessAlive,
            bridge.RecordingPipeConnected,
            bridge.RemotePipeConnected,
            bridge.FramesWritten,
            bridge.LastError);
    }
}

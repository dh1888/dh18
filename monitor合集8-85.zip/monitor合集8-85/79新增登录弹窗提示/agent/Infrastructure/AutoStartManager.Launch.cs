using Microsoft.Extensions.Logging;
using Microsoft.Win32;

namespace EnterpriseAgent.Agent.Services;

internal enum AutoStartLaunchMode
{
    HiddenVbs,
    DirectGuardianExe,
}

public static partial class AutoStartManager
{
    public static string? LastTaskCreationFailure { get; private set; }

    public static string? LastEnableNoticeKey { get; private set; }

    public static object[]? LastEnableNoticeArgs { get; private set; }

    public static string? ResolveEnableNotice(ILocalizationService? localization)
    {
        if (string.IsNullOrWhiteSpace(LastEnableNoticeKey))
            return null;

        var template = localization?.GetString(LastEnableNoticeKey, LastEnableNoticeKey) ?? LastEnableNoticeKey;
        if (LastEnableNoticeArgs is { Length: > 0 })
        {
            try
            {
                return string.Format(template, LastEnableNoticeArgs);
            }
            catch (FormatException)
            {
                return template;
            }
        }

        return template;
    }

    internal static void ClearEnableNotice()
    {
        LastEnableNoticeKey = null;
        LastEnableNoticeArgs = null;
    }

    internal static void SetEnableNotice(string key, params object[] args)
    {
        LastEnableNoticeKey = key;
        LastEnableNoticeArgs = args.Length > 0 ? args : null;
    }

    private static bool AutoStartEntryMatches(string? entryText, string exePath)
    {
        if (string.IsNullOrWhiteSpace(entryText))
            return false;

        if (EntryUsesDirectGuardianExe(entryText, exePath))
            return true;

        var guardianVbs = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
        return entryText.Contains("wscript.exe", StringComparison.OrdinalIgnoreCase)
               && entryText.Contains(guardianVbs, StringComparison.OrdinalIgnoreCase);
    }

    private static bool EntryUsesDirectGuardianExe(string entryText, string exePath)
        => ScheduledTaskHelper.ReferencesExecutable(entryText, exePath)
           && entryText.Contains(HiddenLauncherFiles.GuardianLaunchArgument, StringComparison.OrdinalIgnoreCase);

    private static bool EntryUsesVbsLauncher(string? entryText, string exePath)
    {
        if (string.IsNullOrWhiteSpace(entryText))
            return false;

        if (EntryUsesDirectGuardianExe(entryText, exePath))
            return false;

        var guardianVbs = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
        return entryText.Contains("wscript.exe", StringComparison.OrdinalIgnoreCase)
               && entryText.Contains(guardianVbs, StringComparison.OrdinalIgnoreCase);
    }

    private static string BuildRegistryCommand(string exePath, ILogger? logger, out AutoStartLaunchMode mode)
    {
        HiddenLauncherFiles.EnsureGuardianVbs(exePath);
        var vbsPath = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
        if (File.Exists(vbsPath))
        {
            mode = AutoStartLaunchMode.HiddenVbs;
            return
                $"\"{HiddenLauncherFiles.GetWscriptPath()}\" {HiddenLauncherFiles.BuildWscriptArguments(vbsPath)}";
        }

        mode = AutoStartLaunchMode.DirectGuardianExe;
        logger?.LogWarning(
            "Guardian VBS unavailable; registry Run will launch DHPG.exe --guardian directly");
        return $"\"{exePath}\" {HiddenLauncherFiles.GuardianLaunchArgument}";
    }

    private static void RepairRegistryWhenVbsMissing(string exePath, ILogger? logger)
    {
        var registryValue = ReadRegistryAutoStartValue();
        if (string.IsNullOrWhiteSpace(registryValue))
            return;

        if (EntryUsesDirectGuardianExe(registryValue, exePath))
            return;

        var vbsPath = HiddenLauncherFiles.GetGuardianVbsPath(exePath);
        if (File.Exists(vbsPath))
            return;

        logger?.LogWarning(
            "Registry auto-start references missing guardian VBS; repairing launch command");
        TryEnableRegistry(exePath, logger);
    }

    private static bool LoginAutostartIsOperational(
        AutoStartChannel activeChannel,
        bool taskMatches,
        bool registryMatches,
        string? registryValue,
        string? taskOutput,
        string exePath,
        bool vbsExists)
    {
        if (activeChannel == AutoStartChannel.None)
            return false;

        if (!File.Exists(exePath))
            return false;

        if (EntryUsesDirectGuardianExe(registryValue ?? "", exePath)
            || EntryUsesDirectGuardianExe(taskOutput ?? "", exePath))
        {
            return true;
        }

        if ((EntryUsesVbsLauncher(registryValue, exePath) && registryMatches)
            || (taskMatches && EntryUsesVbsLauncher(taskOutput, exePath)))
        {
            return vbsExists;
        }

        return vbsExists;
    }
}

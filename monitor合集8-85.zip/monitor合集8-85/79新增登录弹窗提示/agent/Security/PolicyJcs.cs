using Org.Webpki.JsonCanonicalizer;

namespace EnterpriseAgent.Agent.Security;

public static class PolicyJcs
{
    public static byte[] CanonicalizeUtf8(ReadOnlySpan<byte> jsonUtf8)
    {
        var canonicalizer = new JsonCanonicalizer(jsonUtf8.ToArray());
        return canonicalizer.GetEncodedUTF8();
    }

    public static byte[] CanonicalizePolicyPayload(PolicySignPayload payload)
    {
        var encoded = PolicySignPayloadNormalizer.SerializeNormalized(payload);
        return CanonicalizeUtf8(encoded);
    }
}

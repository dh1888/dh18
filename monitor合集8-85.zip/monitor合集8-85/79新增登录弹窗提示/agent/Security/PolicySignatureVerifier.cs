using System.Text.Json;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Signers;

namespace EnterpriseAgent.Agent.Security;

public sealed class PolicySignatureVerifier
{
    private readonly IReadOnlyDictionary<string, byte[]> _publicKeysById;

    public PolicySignatureVerifier(IReadOnlyDictionary<string, string> policyPublicKeys)
    {
        if (policyPublicKeys == null || policyPublicKeys.Count == 0)
            throw new InvalidOperationException("policyPublicKeys is required");

        var parsed = new Dictionary<string, byte[]>(StringComparer.Ordinal);
        foreach (var (keyId, keyBase64) in policyPublicKeys)
        {
            if (string.IsNullOrWhiteSpace(keyId) || string.IsNullOrWhiteSpace(keyBase64))
                continue;

            var publicKey = Convert.FromBase64String(keyBase64.Trim());
            if (publicKey.Length != 32)
                throw new InvalidOperationException($"policy public key '{keyId}' must decode to 32 bytes");

            parsed[keyId.Trim()] = publicKey;
        }

        if (parsed.Count == 0)
            throw new InvalidOperationException("policyPublicKeys does not contain any valid Ed25519 public keys");

        _publicKeysById = parsed;
    }

    public bool TryVerifyPolicy(
        JsonElement policyElement,
        string signatureBase64,
        string signatureAlg,
        int signatureVersion,
        string keyId,
        out string? error)
    {
        error = null;

        if (signatureVersion != PolicySignPayloadNormalizer.SupportedSignatureVersion)
        {
            error = $"unsupported signatureVersion {signatureVersion}";
            return false;
        }

        if (!string.Equals(signatureAlg, PolicySignPayloadNormalizer.SupportedSignatureAlg, StringComparison.Ordinal))
        {
            error = $"unsupported signatureAlg '{signatureAlg}'";
            return false;
        }

        if (string.IsNullOrWhiteSpace(keyId) || !_publicKeysById.TryGetValue(keyId, out var publicKey))
        {
            error = $"unknown keyId '{keyId}'";
            return false;
        }

        if (string.IsNullOrWhiteSpace(signatureBase64))
        {
            error = "signature is missing";
            return false;
        }

        byte[] signature;
        try
        {
            signature = Convert.FromBase64String(signatureBase64.Trim());
        }
        catch
        {
            error = "signature is not valid Base64";
            return false;
        }

        byte[] canonical;
        try
        {
            var payload = PolicySignPayloadNormalizer.NormalizeFromJsonElement(policyElement);
            canonical = PolicyJcs.CanonicalizePolicyPayload(payload);
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }

        if (!VerifyEd25519(publicKey, canonical, signature))
        {
            error = "Ed25519 signature verification failed";
            return false;
        }

        return true;
    }

    private static bool VerifyEd25519(byte[] publicKey, byte[] message, byte[] signature)
    {
        var keyParams = new Ed25519PublicKeyParameters(publicKey, 0);
        var verifier = new Ed25519Signer();
        verifier.Init(false, keyParams);
        verifier.BlockUpdate(message, 0, message.Length);
        return verifier.VerifySignature(signature);
    }
}

using System.Text.Json;
using System.Text.Json.Serialization;

namespace EnterpriseAgent.Agent.Security;

public sealed class PolicySignPayload
{
    [JsonPropertyName("version")]
    public int Version { get; set; }

    [JsonPropertyName("rules")]
    public List<PolicySignRule> Rules { get; set; } = new();

    [JsonPropertyName("config")]
    public JsonElement Config { get; set; }
}

public sealed class PolicySignRule
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = "";

    [JsonPropertyName("action")]
    public string Action { get; set; } = "";

    [JsonPropertyName("match")]
    public string Match { get; set; } = "";
}

public static class PolicySignPayloadNormalizer
{
    public const int SupportedSignatureVersion = 1;
    public const string SupportedSignatureAlg = "Ed25519";

    private static readonly HashSet<string> ExcludedFields = new(StringComparer.Ordinal)
    {
        "signature",
        "signatureAlg",
        "signatureVersion",
        "keyId",
    };

    public static PolicySignPayload NormalizeFromJsonElement(JsonElement root)
    {
        if (root.ValueKind != JsonValueKind.Object)
            throw new InvalidOperationException("policy must be a JSON object");

        if (!root.TryGetProperty("version", out var versionProp) ||
            versionProp.ValueKind != JsonValueKind.Number ||
            !versionProp.TryGetInt32(out var version) ||
            version <= 0)
        {
            throw new InvalidOperationException("policy version must be > 0");
        }

        var rules = new List<PolicySignRule>();
        if (root.TryGetProperty("rules", out var rulesProp) &&
            rulesProp.ValueKind != JsonValueKind.Null &&
            rulesProp.ValueKind != JsonValueKind.Undefined)
        {
            if (rulesProp.ValueKind != JsonValueKind.Array)
                throw new InvalidOperationException("policy rules must be an array");

            foreach (var rule in rulesProp.EnumerateArray())
            {
                var parsed = JsonSerializer.Deserialize<PolicySignRule>(rule.GetRawText());
                if (parsed != null)
                    rules.Add(parsed);
            }
        }

        JsonElement config;
        if (root.TryGetProperty("config", out var configProp) &&
            configProp.ValueKind != JsonValueKind.Null &&
            configProp.ValueKind != JsonValueKind.Undefined)
        {
            if (configProp.ValueKind != JsonValueKind.Object)
                throw new InvalidOperationException("policy config must be an object");
            config = configProp.Clone();
        }
        else
        {
            config = JsonDocument.Parse("{}").RootElement;
        }

        foreach (var property in root.EnumerateObject())
        {
            if (property.Name is "version" or "rules" or "config")
                continue;
            if (ExcludedFields.Contains(property.Name))
                continue;
            throw new InvalidOperationException($"unsupported top-level policy field '{property.Name}'");
        }

        return new PolicySignPayload
        {
            Version = version,
            Rules = rules,
            Config = config,
        };
    }

    public static PolicySignPayload NormalizeFromJson(string json)
    {
        using var doc = JsonDocument.Parse(json);
        return NormalizeFromJsonElement(doc.RootElement);
    }

    public static byte[] SerializeNormalized(PolicySignPayload payload)
    {
        return JsonSerializer.SerializeToUtf8Bytes(payload, PolicyJsonOptions.Normalized);
    }
}

internal static class PolicyJsonOptions
{
    internal static readonly JsonSerializerOptions Normalized = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.Never,
    };
}

using System.Diagnostics;
using System.Text;
using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Lifecycle;
using EnterpriseAgent.Agent.Security;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EnterpriseAgent.Agent.RemoteView;

/// <summary>
/// Independent remote view publishing service (FFmpeg gdigrab or shared bridge → WHIP/RTMP → LiveKit Ingress).
/// </summary>
public sealed class RemoteViewService : IRemoteViewService, IRemoteViewPublisher, IDisposable
{
    private static readonly TimeSpan SharedBridgeReadyTimeout = TimeSpan.FromSeconds(20);
    private static readonly TimeSpan RtmpReadyTimeout = TimeSpan.FromSeconds(15);

    private readonly ILogger<RemoteViewService> _logger;
    private readonly RemoteViewConfig _config;
    private readonly ICaptureCoordinator _captureCoordinator;
    private readonly object _gate = new();
    private Process? _ffmpegProcess;
    private RemoteViewStartParams? _activeParams;
    private string _encoder = "";
    private bool _encoderVerified;
    private string? _cachedProbeEncoder;
    private int _cachedProbeWidth;
    private int _cachedProbeHeight;
    private int _cachedProbeFps;
    private DateTime _encoderCachedAtUtc = DateTime.MinValue;
    private static readonly TimeSpan EncoderCacheLifetime = TimeSpan.FromHours(2);
    private int _frameCount;
    private DateTime _statsSinceUtc = DateTime.UtcNow;
    private DateTime _lastFrameUtc = DateTime.MinValue;
    private long _lastOutTimeUs;
    private long _lastTotalSize;
    private int _restartCount;
    private int _networkDegradeSteps;
    private int _activeBitrateKbps;
    private string? _lastError;
    private string? _pendingTransportError;
    private bool _whipFallbackRequested;
    private bool _disposed;
    private readonly List<string> _recentStderr = new();
    private readonly object _stderrLock = new();
    private readonly SemaphoreSlim _publishLock = new(1, 1);
    private int _encoderWarmupRunning;
    private TaskCompletionSource? _firstFrameTcs;
    private volatile bool _userInitiatedStop;
    private int _processEpoch;
    private int _remotePipeRestartInProgress;

    // [PipelineDiag] temporary: FFmpeg -progress cumulative counters (pipe → encode → WHIP)
    private long _diagFfFrame;
    private long _diagFfDupFrames;
    private long _diagFfDropFrames;
    private long _diagSnapshotFrame;
    private long _diagSnapshotDupFrames;
    private long _diagSnapshotDropFrames;
    private long _diagSnapshotOutTimeUs;
    private DateTime _diagFfLogUtc = DateTime.MinValue;
    private DateTime _diagLastProgressFrameUtc = DateTime.MinValue;
    private long _diagMaxInterFrameGapMs;
    private long _diagInterFrameGapTotalMs;
    private int _diagInterFrameGapSamples;
    private DateTime _diagProcessLaunchUtc = DateTime.MinValue;
    private int _diagLaunchProcessEpoch;
    private bool _diagSeqFirstProgressFrameLogged;
    private bool _diagSeqWhipFlowLogged;
    // [PipelineDiag] FFmpeg internal: QSV / progress batch / stderr idle
    private DateTime _diagLastAnyStderrUtc = DateTime.MinValue;
    private long _diagMaxStderrIdleMs;
    private DateTime _diagLastProgressBatchUtc = DateTime.MinValue;
    private long _diagProgressBatchSamples;
    private long _diagProgressBatchTotalMs;
    private long _diagProgressBatchMaxMs;
    private double _diagLatestSpeed;
    private double _diagSpeedSum;
    private int _diagSpeedSamples;
    private double _diagLatestReportedFps;
    private double _diagLatestBitrateKbps;
    private long _diagMaxStream0Q;
    private int _diagHwStderrHits;
    private string? _diagLastHwStderrSnippet;

    public bool IsRemotePipeRestartInProgress => Volatile.Read(ref _remotePipeRestartInProgress) > 0;

    private TimeSpan WhipMediaReadyTimeout =>
        TimeSpan.FromMilliseconds(Math.Clamp(_config.WhipMediaReadyTimeoutMs, 5000, 60000));

    private int WhipHandshakeTimeoutMs =>
        Math.Clamp(_config.WhipHandshakeTimeoutMs, 5000, 60000);

    public RemoteViewService(
        ILogger<RemoteViewService> logger,
        IOptions<RemoteViewConfig> options,
        ICaptureCoordinator captureCoordinator)
    {
        _logger = logger;
        _config = options.Value;
        _captureCoordinator = captureCoordinator;
    }

    public event Func<string?, string, Task>? PublishFailed;

    public bool IsPublishing
    {
        get
        {
            lock (_gate)
            {
                return _ffmpegProcess is { HasExited: false };
            }
        }
    }

    public string? ActiveSessionId
    {
        get
        {
            lock (_gate)
            {
                return _activeParams?.SessionId;
            }
        }
    }

    public RemoteViewStats GetStats()
    {
        lock (_gate)
        {
            var elapsed = Math.Max((DateTime.UtcNow - _statsSinceUtc).TotalSeconds, 1);
            var measuredFps = (int)Math.Round(_frameCount / elapsed);
            var configuredFps = _activeParams?.Fps ?? _config.TargetFps;

            return new RemoteViewStats
            {
                Fps = measuredFps > 0 ? measuredFps : configuredFps,
                BitrateKbps = _activeBitrateKbps > 0 ? _activeBitrateKbps : _config.VideoBitrateKbps,
                Encoder = _encoder,
                IsPublishing = IsPublishing,
                SessionId = _activeParams?.SessionId,
            };
        }
    }

    public RemoteHealthStatus GetHealth()
    {
        lock (_gate)
        {
            var frameAge = _lastFrameUtc == DateTime.MinValue
                ? double.MaxValue
                : (DateTime.UtcNow - _lastFrameUtc).TotalSeconds;

            return new RemoteHealthStatus
            {
                IsPublishing = IsPublishing,
                ProcessAlive = IsPublishing,
                FrameRecent = frameAge < 30,
                FrameAgeSeconds = frameAge,
                RestartCount = _restartCount,
                SessionId = _activeParams?.SessionId,
                LastError = _lastError,
            };
        }
    }

    public bool TakeUserInitiatedStop()
    {
        lock (_gate)
        {
            if (!_userInitiatedStop)
                return false;
            _userInitiatedStop = false;
            return true;
        }
    }

    public async Task StartAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(parameters);
        if (string.IsNullOrWhiteSpace(parameters.ResolvePublishUrl()))
            throw new InvalidOperationException("Publish URL is required");

        await _publishLock.WaitAsync(cancellationToken);
        try
        {
            _userInitiatedStop = false;
            bool wasPublishing;
            string? previousSession;
            lock (_gate)
            {
                wasPublishing = _ffmpegProcess is { HasExited: false };
                previousSession = _activeParams?.SessionId;
            }

            await StopInternalAsync(notifyFailed: false, userInitiated: false, cancellationToken);
            _restartCount = 0;
            _networkDegradeSteps = 0;
            _lastError = null;
            if (string.Equals(parameters.ResolvePublishProtocol(), "rtmp", StringComparison.OrdinalIgnoreCase))
                _whipFallbackRequested = false;

            var inPlaceRepublish = wasPublishing || !string.IsNullOrWhiteSpace(previousSession);
            var sharedBridgeRepublish = inPlaceRepublish && _captureCoordinator.IsSharedCaptureActive;
            _logger.LogInformation(
                "[PipelineDiag] Seq StartAsync begin session={SessionId} inPlace={InPlace} sharedBridgeRepublish={SharedBridgeRepublish}",
                parameters.SessionId,
                inPlaceRepublish,
                sharedBridgeRepublish);
            if (sharedBridgeRepublish)
                Interlocked.Increment(ref _remotePipeRestartInProgress);

            try
            {
                // Drop the remote pipe server immediately so SharedBridge relay does not
                // keep writing to a client FFmpeg we just killed (quality-switch pipe broken).
                if (sharedBridgeRepublish)
                {
                    _captureCoordinator.ResetSharedBridgeConsumerFrameReader(
                        CaptureConsumer.RemoteView, snapToLatest: true);
                    await _captureCoordinator.RecreateSharedBridgeConsumerPipeAsync(
                        CaptureConsumer.RemoteView, cancellationToken);
                }

                // Same-ingress republish (quality switch or dead-ffmpeg restart).
                if (inPlaceRepublish)
                {
                    var settle = Math.Max(_config.QualitySwitchSettleMs, Math.Max(_config.IngressWarmupMs / 2, 400));
                    await Task.Delay(settle, cancellationToken);
                }

                await EnsureSharedRemotePipeBeforeLaunchAsync(cancellationToken);
                await LaunchInternalAsync(parameters, cancellationToken);
                _logger.LogInformation(
                    "[PipelineDiag] Seq StartAsync end session={SessionId} publishing={Publishing}",
                    parameters.SessionId,
                    IsPublishing);
            }
            finally
            {
                if (sharedBridgeRepublish)
                    Interlocked.Decrement(ref _remotePipeRestartInProgress);
            }
        }
        finally
        {
            _publishLock.Release();
        }
    }

    public async Task StopAsync(CancellationToken cancellationToken = default)
    {
        await _publishLock.WaitAsync(cancellationToken);
        try
        {
            _whipFallbackRequested = false;
            await StopInternalAsync(notifyFailed: false, userInitiated: true, cancellationToken);
        }
        finally
        {
            _publishLock.Release();
        }
    }

    public async Task WaitForPublishReadyAsync(CancellationToken cancellationToken = default)
    {
        Process? process;
        string protocol;
        lock (_gate)
        {
            process = _ffmpegProcess;
            protocol = _activeParams?.ResolvePublishProtocol() ?? "";
        }

        if (process == null || process.HasExited)
            throw new InvalidOperationException("Remote publish process is not running");

        if (!string.Equals(protocol, "whip", StringComparison.OrdinalIgnoreCase))
            return;

        // SharedBridge producer is flowing now — wait for real WHIP RTP before success.
        await WaitForWhipMediaReadyAsync(process, cancellationToken);

        if (process.HasExited && process.ExitCode != 0)
            throw new InvalidOperationException(BuildExitDetail(process.ExitCode));
    }

    public async Task<bool> RecoverSlowSharedBridgePublishIfNeededAsync(
        RemoteViewStartParams parameters,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(parameters);

        if (!string.Equals(parameters.ResolvePublishProtocol(), "whip", StringComparison.OrdinalIgnoreCase))
            return false;
        if (!_captureCoordinator.IsSharedCaptureActive)
            return false;

        var initialMs = Math.Clamp(_config.SlowPublishHealthInitialMs, 200, 5000);
        var pollMs = Math.Clamp(_config.SlowPublishHealthPollMs, 100, 2000);
        var maxMs = Math.Clamp(_config.SlowPublishHealthSampleMaxMs, initialMs, 8000);

        await Task.Delay(initialMs, cancellationToken);
        var elapsedMs = initialMs;

        while (true)
        {
            if (IsSharedBridgePublishHealthy())
                return false;

            if (IsSharedBridgePublishUnhealthy())
                break;

            if (elapsedMs >= maxMs)
                return false;

            await Task.Delay(pollMs, cancellationToken);
            elapsedMs += pollMs;
        }

        double speed;
        double fps;
        long batchMaxMs;
        lock (_gate)
        {
            speed = _diagLatestSpeed;
            fps = _diagLatestReportedFps;
            batchMaxMs = _diagProgressBatchMaxMs;
        }

        _logger.LogWarning(
            "[PipelineDiag] Seq SharedBridgeBootstrapRestart session={SessionId} reason=slow-first-publish speed={Speed}x fps={Fps} batchMaxMs={BatchMaxMs}",
            parameters.SessionId,
            speed,
            fps,
            batchMaxMs);

        await StartAsync(parameters, cancellationToken);
        return true;
    }

    private bool IsSharedBridgePublishHealthy()
    {
        lock (_gate)
        {
            if (!IsPublishing)
                return false;

            // Passthrough WHIP can show ~515ms inter-frame gaps while still realtime — trust speed/fps.
            if (_diagLatestSpeed >= 1.0 && _diagLatestReportedFps >= 10)
                return true;

            if (_diagLatestSpeed >= 1.2)
                return true;

            return false;
        }
    }

    private bool IsSharedBridgePublishUnhealthy()
    {
        lock (_gate)
        {
            if (!IsPublishing)
                return false;

            // Phase 2 signature: FFmpeg speed stuck well below realtime while WHIP is connected.
            if (_diagLatestSpeed > 0 && _diagLatestSpeed < 0.85)
                return true;

            if (_diagLatestReportedFps > 0 && _diagLatestReportedFps < 8)
                return true;

            return false;
        }
    }

    public string? TakePendingTransportError()
    {
        lock (_gate)
        {
            var error = _pendingTransportError;
            _pendingTransportError = null;
            return error;
        }
    }

    public async Task ReconnectAsync(string reason, CancellationToken cancellationToken = default)
    {
        await _publishLock.WaitAsync(cancellationToken);
        try
        {
            await ReconnectCoreAsync(reason, cancellationToken);
        }
        finally
        {
            _publishLock.Release();
        }
    }

    private async Task ReconnectCoreAsync(string reason, CancellationToken cancellationToken)
    {
        RemoteViewStartParams? parameters;
        lock (_gate)
        {
            parameters = _activeParams;
        }

        if (parameters == null)
            return;

        var maxRestarts = Math.Max(1, _config.RtmpMaxRestartsPerSession);
        // Loop here so a coalesced PublishFailed cannot drop the next attempt mid-session.
        while (!cancellationToken.IsCancellationRequested)
        {
            var isWhip = string.Equals(
                parameters.ResolvePublishProtocol(), "whip", StringComparison.OrdinalIgnoreCase);

            // WHIP media-path failures cannot be healed by reconnecting the same URL.
            // Only request RTMP fallback when the session actually has an RTMP URL (auto mode).
            var canFallbackRtmp = !string.IsNullOrWhiteSpace(parameters.RtmpUrl);
            if (isWhip && !_whipFallbackRequested && IsWhipUnrecoverableLocally(reason, _lastError))
            {
                var sessionId = parameters.SessionId;
                _whipFallbackRequested = true;
                await StopInternalAsync(notifyFailed: false, userInitiated: false, cancellationToken);
                lock (_gate)
                {
                    _activeParams = parameters;
                }

                if (canFallbackRtmp)
                {
                    _lastError = $"WHIP media path failed; requesting RTMP fallback: {reason}";
                    _logger.LogWarning(
                        "Remote view WHIP unrecoverable locally; requesting RTMP fallback session={SessionId} reason={Reason}",
                        sessionId, reason);
                    await RaisePublishFailedAsync(sessionId, "WHIP_FALLBACK_REQUEST:" + _lastError);
                }
                else
                {
                    _lastError = $"WHIP media path failed (whip-only): {reason}";
                    _logger.LogWarning(
                        "Remote view WHIP unrecoverable locally (no RTMP URL) session={SessionId} reason={Reason}",
                        sessionId, reason);
                    await RaisePublishFailedAsync(sessionId, _lastError);
                }

                return;
            }

            if (_restartCount >= maxRestarts)
            {
                var sessionId = parameters.SessionId;
                if (!_whipFallbackRequested && isWhip && canFallbackRtmp)
                {
                    _whipFallbackRequested = true;
                    _lastError = $"WHIP unstable after {maxRestarts} retries: {reason}";
                    _logger.LogWarning(
                        "Remote view WHIP exhausted ({Max}); requesting RTMP fallback session={SessionId}",
                        maxRestarts, sessionId);
                    await StopInternalAsync(notifyFailed: false, userInitiated: false, cancellationToken);
                    // Keep session latched so lifecycle does not ExitRemoteView while waiting for RTMP start.
                    lock (_gate)
                    {
                        _activeParams = parameters;
                    }

                    await RaisePublishFailedAsync(sessionId, "WHIP_FALLBACK_REQUEST:" + _lastError);
                    return;
                }

                _lastError = isWhip
                    ? $"WHIP unstable after {maxRestarts} retries: {reason}"
                    : $"RTMP unstable after {maxRestarts} retries: {reason}";
                _logger.LogError(
                    "Remote view exceeded max restarts ({Max}) session={SessionId} reason={Reason}",
                    maxRestarts, sessionId, reason);
                await StopInternalAsync(notifyFailed: false, userInitiated: false, cancellationToken);
                await RaisePublishFailedAsync(sessionId, _lastError);
                return;
            }

            _restartCount++;
            _networkDegradeSteps = Math.Min(_networkDegradeSteps + 1, 3);
            var serverKick = RemoteFailureClassifier.LooksLikeServerReject(reason) ||
                             RemoteFailureClassifier.LooksLikeServerReject(_lastError);
            var delay = Math.Min(800 * (1 << Math.Min(_restartCount - 1, 3)), 8000);
            delay += Math.Max(_config.IngressWarmupMs / 2, 400);
            if (serverKick)
                delay = Math.Max(delay, Math.Max(_config.IngressWarmupMs * 3, 2500));

            _logger.LogInformation(
                "Remote view reconnect in {Delay}ms attempt={Count}/{Max} degrade={Degrade} serverKick={ServerKick} reason={Reason}",
                delay, _restartCount, maxRestarts, _networkDegradeSteps, serverKick, reason);

            await Task.Delay(delay, cancellationToken);
            await StopInternalAsync(notifyFailed: false, userInitiated: false, cancellationToken);
            var settleMs = serverKick
                ? Math.Max(_config.IngressWarmupMs, 1500)
                : Math.Max(_config.IngressWarmupMs / 2, 400);
            await Task.Delay(settleMs, cancellationToken);

            try
            {
                await EnsureSharedRemotePipeBeforeLaunchAsync(cancellationToken);
                await LaunchInternalAsync(parameters, cancellationToken);
                return;
            }
            catch (Exception ex)
            {
                _lastError = ex.Message;
                _logger.LogWarning(ex, "Remote view reconnect failed session={SessionId}", parameters.SessionId);
            }
        }
    }

    Task IRemoteViewPublisher.StartPublishAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken) =>
        StartAsync(parameters, cancellationToken);

    Task IRemoteViewPublisher.StopPublishAsync(CancellationToken cancellationToken) =>
        StopAsync(cancellationToken);

    public void WarmupEncoderAsync(CancellationToken cancellationToken = default)
    {
        if (Interlocked.CompareExchange(ref _encoderWarmupRunning, 1, 0) != 0)
            return;

        _ = Task.Run(async () =>
        {
            try
            {
                await WarmupEncoderCoreAsync(cancellationToken);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                // work session or shutdown cancelled the warmup
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Remote view encoder warmup failed (non-fatal)");
            }
            finally
            {
                Interlocked.Exchange(ref _encoderWarmupRunning, 0);
            }
        }, cancellationToken);
    }

    private async Task WarmupEncoderCoreAsync(CancellationToken cancellationToken)
    {
        if (IsPublishing)
            return;

        if (_encoderVerified && !string.IsNullOrWhiteSpace(_encoder)
            && DateTime.UtcNow - _encoderCachedAtUtc < EncoderCacheLifetime)
        {
            return;
        }

        var ffmpeg = FindFfmpeg();
        if (string.IsNullOrWhiteSpace(ffmpeg))
            return;

        var profile = _captureCoordinator.GetProfile();
        var parameters = new RemoteViewStartParams
        {
            Width = _config.TargetWidth,
            Height = _config.TargetHeight,
            Fps = _config.TargetFps,
            NetworkProfile = _config.NetworkProfile ?? "auto",
        };
        var encode = ResolveEncodeSettings(parameters, profile);
        await DetectEncoderAsync(
            ffmpeg,
            encode.Width,
            encode.Height,
            encode.Fps,
            encode.BitrateKbps,
            cancellationToken);
        _logger.LogInformation(
            "Remote view encoder warmup complete: {Encoder} {Width}x{Height}@{Fps}",
            _encoder,
            encode.Width,
            encode.Height,
            encode.Fps);
    }

    private async Task EnsureSharedRemotePipeBeforeLaunchAsync(CancellationToken cancellationToken)
    {
        if (!_captureCoordinator.IsSharedCaptureActive)
        {
            if (_captureCoordinator.IsSharedBridgeOrchestrated)
            {
                throw new InvalidOperationException(
                    "SharedBridge pipe session is not active during EnterRemoteView");
            }

            return;
        }

        var health = _captureCoordinator.GetSharedBridgeHealth();
        if (health.RemotePipeConnected)
            return;

        // Pipe server listening but client not connected yet — wait for FFmpeg to attach.
        if (health.RemotePipeServerActive)
            return;

        if (health.State >= SharedBridgeState.PipesListening)
        {
            _logger.LogInformation(
                "Recreating remote pipe server before FFmpeg launch (state={State}, orchestrated={Orchestrated})",
                health.State,
                _captureCoordinator.IsSharedBridgeOrchestrated);
            await _captureCoordinator.RecreateSharedBridgeConsumerPipeAsync(
                CaptureConsumer.RemoteView, cancellationToken);
        }
    }

    private async Task LaunchInternalAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken)
    {
        var ffmpeg = FindFfmpeg();
        if (string.IsNullOrWhiteSpace(ffmpeg))
            throw new InvalidOperationException("ffmpeg.exe not found");

        await _captureCoordinator.NotifyConsumerStartingAsync(CaptureConsumer.RemoteView, cancellationToken);
        var profile = _captureCoordinator.GetProfile();

        var encode = ResolveEncodeSettings(parameters, profile);
        _activeBitrateKbps = encode.BitrateKbps;
        _encoder = await DetectEncoderAsync(
            ffmpeg, encode.Width, encode.Height, encode.Fps, encode.BitrateKbps, cancellationToken);

        var maxAttempts = Math.Max(1, _config.RtmpLaunchMaxAttempts);
        Exception? lastError = null;

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            try
            {
                await LaunchProcessOnceAsync(
                    parameters, profile, ffmpeg, _encoder,
                    encode.Width, encode.Height, encode.Fps, encode.BitrateKbps,
                    cancellationToken);

                if (_restartCount > 0 && attempt == 1)
                {
                    // keep degrade steps after successful reconnect until long-lived stability
                }

                return;
            }
            catch (Exception ex) when (attempt < maxAttempts && IsRetryableLaunchFailure(ex))
            {
                lastError = ex;
                _logger.LogWarning(
                    ex,
                    "Remote RTMP launch attempt {Attempt}/{Max} failed; retrying after ingress warmup",
                    attempt, maxAttempts);
                await StopInternalAsync(notifyFailed: false, userInitiated: false, cancellationToken);
                await Task.Delay(Math.Max(_config.IngressWarmupMs, 500) * attempt, cancellationToken);
                // Step down network profile on repeated open failures
                _networkDegradeSteps = Math.Min(_networkDegradeSteps + 1, 3);
                if (LooksLikeEncoderFailure(ex.Message))
                    InvalidateEncoderCache();
                encode = ResolveEncodeSettings(parameters, profile);
                _activeBitrateKbps = encode.BitrateKbps;
                if (!_encoderVerified)
                {
                    _encoder = await DetectEncoderAsync(
                        ffmpeg, encode.Width, encode.Height, encode.Fps, encode.BitrateKbps, cancellationToken);
                }
            }
        }

        throw lastError ?? new InvalidOperationException("Remote RTMP launch failed");
    }

    private async Task LaunchProcessOnceAsync(
        RemoteViewStartParams parameters,
        CaptureProfile profile,
        string ffmpeg,
        string encoder,
        int width,
        int height,
        int fps,
        int bitrateKbps,
        CancellationToken cancellationToken)
    {
        var args = BuildFfmpegArgs(profile, encoder, width, height, fps, bitrateKbps,
            parameters.ResolvePublishProtocol(), parameters.ResolvePublishUrl(), parameters.ResolveStreamKey());

        lock (_stderrLock)
            _recentStderr.Clear();

        _firstFrameTcs = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

        _logger.LogInformation(
            "Starting remote view session={SessionId} mode={Mode} encoder={Encoder} {Width}x{Height}@{Fps} bitrate={Bitrate}k profile={Profile} degrade={Degrade}",
            parameters.SessionId, profile.Mode, encoder, width, height, fps, bitrateKbps,
            string.IsNullOrWhiteSpace(parameters.NetworkProfile) ? _config.NetworkProfile : parameters.NetworkProfile,
            _networkDegradeSteps);
        _logger.LogInformation("Remote view FFmpeg args: {Args}", SensitiveDataFilter.FilterStatic(args));

        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = ffmpeg,
                Arguments = args,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true,
            },
            EnableRaisingEvents = true,
        };

        process.ErrorDataReceived += (_, e) => HandleStderrLine(e.Data);

        _frameCount = 0;
        _statsSinceUtc = DateTime.UtcNow;
        _lastFrameUtc = DateTime.UtcNow;
        Interlocked.Exchange(ref _lastOutTimeUs, 0);
        Interlocked.Exchange(ref _lastTotalSize, 0);
        ResetPipelineDiagFfProgress();

        if (!process.Start())
            throw new InvalidOperationException("Failed to start ffmpeg process");

        var launchEpoch = Volatile.Read(ref _processEpoch);
        _diagProcessLaunchUtc = DateTime.UtcNow;
        _diagLaunchProcessEpoch = launchEpoch;
        _diagSeqFirstProgressFrameLogged = false;
        _diagSeqWhipFlowLogged = false;
        _logger.LogInformation(
            "[PipelineDiag] Seq RemoteFfmpegLaunch pid={Pid} epoch={Epoch} session={SessionId} mode={Mode}",
            process.Id,
            launchEpoch,
            parameters.SessionId,
            profile.Mode);

        process.BeginErrorReadLine();

        lock (_gate)
        {
            _ffmpegProcess = process;
            _activeParams = parameters;
        }

        var processEpoch = Volatile.Read(ref _processEpoch);
        var isWhip = string.Equals(
            parameters.ResolvePublishProtocol(), "whip", StringComparison.OrdinalIgnoreCase);
        // SharedBridge enter order: StartAsync → consumers connect → StartSharedCapture → flowing.
        // Must NOT WaitForWhipMediaReady here or producer never starts (deadlock / no HTTP POST).
        var deferWhipMediaWait = isWhip &&
            profile.Mode == CaptureMode.SharedBridge &&
            _captureCoordinator.IsSharedBridgeOrchestrated;

        if (isWhip && !deferWhipMediaWait)
        {
            // DualGdigrab / standalone WHIP: frames available immediately from gdigrab.
            await WaitForWhipMediaReadyAsync(process, cancellationToken);
        }
        else if (profile.Mode == CaptureMode.SharedBridge && _captureCoordinator.IsSharedBridgeOrchestrated)
        {
            // Lifecycle waits for bridge flowing (+ WaitForPublishReadyAsync for WHIP).
            // Still probe early open failures for launch retries.
            for (var i = 0; i < 12 && !process.HasExited && !cancellationToken.IsCancellationRequested; i++)
                await Task.Delay(100, cancellationToken);
        }
        else if (profile.Mode == CaptureMode.SharedBridge)
        {
            await WaitForSharedBridgeReadyAsync(process, cancellationToken);
        }
        else
        {
            await WaitForRtmpReadyAsync(process, cancellationToken);
        }

        // Early exit after "ready" still means publish failed (e.g. RTMP open error ~1s later)
        if (process.HasExited && process.ExitCode != 0)
        {
            var detail = BuildExitDetail(process.ExitCode);
            throw new InvalidOperationException(detail);
        }

        _ = Task.Run(async () =>
        {
            string? sessionId;
            lock (_gate)
            {
                sessionId = _activeParams?.SessionId;
            }

            try
            {
                await process.WaitForExitAsync(CancellationToken.None);
                if (processEpoch != Volatile.Read(ref _processEpoch))
                    return;

                if (process.ExitCode != 0)
                {
                    var detail = BuildExitDetail(process.ExitCode);
                    _lastError = detail;
                    _logger.LogWarning("Remote view FFmpeg exited with code {Code}", process.ExitCode);
                    await RaisePublishFailedAsync(sessionId, detail);
                }
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Remote view exit watcher ended");
            }
            finally
            {
                lock (_gate)
                {
                    if (ReferenceEquals(_ffmpegProcess, process))
                    {
                        _ffmpegProcess = null;
                    }
                }
            }
        }, CancellationToken.None);
    }

    private string BuildExitDetail(int exitCode)
    {
        var stderr = GetRecentStderrSummary();
        return string.IsNullOrWhiteSpace(stderr)
            ? $"ffmpeg exited with code {exitCode}"
            : $"ffmpeg exited with code {exitCode}: {stderr}";
    }

    private static bool LooksLikeEncoderFailure(string? detail)
    {
        if (string.IsNullOrWhiteSpace(detail))
            return false;
        return detail.Contains("Encoder", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("nvenc", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("qsv", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("amf", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("libx264", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("Cannot load", StringComparison.OrdinalIgnoreCase) ||
               detail.Contains("OpenEncodeSession", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsRetryableLaunchFailure(Exception ex)
    {
        var msg = ex.Message ?? "";
        // WHIP media-path / ICE failures cannot be healed by relaunching the same stream key.
        if (msg.Contains("WHIP ICE/media timeout", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("ret=-11", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("Failed to connect udp", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("DTLS handshake timeout", StringComparison.OrdinalIgnoreCase))
            return false;

        return RemoteFailureClassifier.IsTransportHint(msg) ||
               RemoteFailureClassifier.LooksLikeServerReject(msg) ||
               msg.Contains("Timed out waiting", StringComparison.OrdinalIgnoreCase) ||
               msg.Contains("exited", StringComparison.OrdinalIgnoreCase);
    }

    private (int Width, int Height, int Fps, int BitrateKbps) ResolveEncodeSettings(
        RemoteViewStartParams parameters,
        CaptureProfile profile)
    {
        var width = parameters.Width > 0 ? parameters.Width : profile.RemoteWidth;
        var height = parameters.Height > 0 ? parameters.Height : profile.RemoteHeight;
        var fps = parameters.Fps > 0 ? parameters.Fps : profile.RemoteFps;
        var bitrate = parameters.VideoBitrateKbps > 0
            ? Math.Max(200, parameters.VideoBitrateKbps)
            : Math.Max(200, _config.VideoBitrateKbps);

        var profileName = !string.IsNullOrWhiteSpace(parameters.NetworkProfile)
            ? parameters.NetworkProfile.Trim().ToLowerInvariant()
            : (_config.NetworkProfile ?? "auto").Trim().ToLowerInvariant();

        // strong: full quality unless reconnect degrade kicked in
        // weak: always weak caps
        // auto: start at full/policy quality; step down only after launch/reconnect failures
        var useWeak = profileName == "weak"
            || _networkDegradeSteps > 0
            || (profileName == "auto" && _restartCount > 0);

        if (profileName == "strong" && _networkDegradeSteps == 0)
            useWeak = false;

        if (useWeak)
        {
            var weakW = Math.Max(320, _config.WeakWidth);
            var weakH = Math.Max(240, _config.WeakHeight);
            var weakFps = Math.Max(5, _config.WeakFps);
            var weakBr = Math.Max(200, _config.WeakVideoBitrateKbps);

            // Further step-down on repeated reconnects
            if (_networkDegradeSteps >= 2)
            {
                weakW = Math.Min(weakW, 640);
                weakH = Math.Min(weakH, 360);
                weakFps = Math.Min(weakFps, 6);
                weakBr = Math.Min(weakBr, 400);
            }

            width = Math.Min(width, weakW);
            height = Math.Min(height, weakH);
            fps = Math.Min(fps, weakFps);
            bitrate = Math.Min(bitrate, weakBr);
        }

        // Keep even dimensions for encoders
        width -= width % 2;
        height -= height % 2;
        if (width < 320) width = 320;
        if (height < 240) height = 240;

        // SharedBridge pipe is paced at RemoteFps; encoding faster only adds timestamp jitter.
        if (profile.Mode == CaptureMode.SharedBridge && profile.RemoteFps > 0)
            fps = Math.Min(fps, profile.RemoteFps);

        return (width, height, fps, bitrate);
    }

    private void HandleStderrLine(string? line)
    {
        if (string.IsNullOrWhiteSpace(line))
            return;

        RecordPipelineDiagStderrActivity(line);

        // -progress pipe:2 emits many key=value lines; keep them out of the error ring buffer
        // so WHIP/ICE/HTTP diagnostics are not overwritten within 5s.
        var isProgressKv =
            line.StartsWith("frame=", StringComparison.Ordinal) ||
            line.StartsWith("fps=", StringComparison.Ordinal) ||
            line.StartsWith("stream_", StringComparison.Ordinal) ||
            line.StartsWith("bitrate=", StringComparison.Ordinal) ||
            line.StartsWith("total_size=", StringComparison.Ordinal) ||
            line.StartsWith("out_time", StringComparison.Ordinal) ||
            line.StartsWith("dup_frames=", StringComparison.Ordinal) ||
            line.StartsWith("drop_frames=", StringComparison.Ordinal) ||
            line.StartsWith("speed=", StringComparison.Ordinal) ||
            line.StartsWith("progress=", StringComparison.Ordinal);

        if (!isProgressKv)
        {
            RecordPipelineDiagHwStderrLine(line);
            lock (_stderrLock)
            {
                _recentStderr.Add(line);
                if (_recentStderr.Count > 40)
                    _recentStderr.RemoveAt(0);
            }
        }

        if (line.Contains("frame=", StringComparison.Ordinal))
        {
            Interlocked.Increment(ref _frameCount);
            _lastFrameUtc = DateTime.UtcNow;
            var sharedBridge = _captureCoordinator.GetProfile().Mode == CaptureMode.SharedBridge;
            if (_frameCount == 1 || (sharedBridge && _captureCoordinator.NeedsConsumerFirstFrame(CaptureConsumer.RemoteView)))
            {
                _firstFrameTcs?.TrySetResult();
                if (sharedBridge)
                    _captureCoordinator.NotifyConsumerFirstFrame(CaptureConsumer.RemoteView);
            }
            if (_restartCount > 0 || _networkDegradeSteps > 0)
            {
                _restartCount = 0;
                // Keep one degrade step until long stability; clear fully after first stable frame burst
                if (_frameCount >= 30)
                    _networkDegradeSteps = 0;
                _logger.LogDebug("Remote view stable, restart counter reset");
            }
        }

        // FFmpeg -progress pipe:2 key=value lines (WHIP media confirmation).
        if (line.StartsWith("out_time_us=", StringComparison.Ordinal))
        {
            if (long.TryParse(line.AsSpan("out_time_us=".Length), out var us) && us > 0)
            {
                Interlocked.Exchange(ref _lastOutTimeUs, us);
                if (!_diagSeqWhipFlowLogged && us > 0)
                {
                    _diagSeqWhipFlowLogged = true;
                    var ageMs = _diagProcessLaunchUtc == DateTime.MinValue
                        ? -1
                        : (DateTime.UtcNow - _diagProcessLaunchUtc).TotalMilliseconds;
                    _logger.LogInformation(
                        "[PipelineDiag] Seq WhipMediaFlow ageMs={AgeMs:F0} out_time_us={OutUs} epoch={Epoch}",
                        ageMs,
                        us,
                        _diagLaunchProcessEpoch);
                }
            }
        }
        else if (line.StartsWith("total_size=", StringComparison.Ordinal))
        {
            if (long.TryParse(line.AsSpan("total_size=".Length), out var sz) && sz > 0)
                Interlocked.Exchange(ref _lastTotalSize, sz);
        }

        RecordPipelineDiagProgressLine(line);
        MaybeLogPipelineDiagFfProgress();

        if (IsRtmpTransportError(line))
        {
            var filtered = SensitiveDataFilter.FilterStatic(line);
            _logger.LogWarning("RTMP transport error: {Line}", filtered);
            lock (_gate)
            {
                _pendingTransportError = filtered;
            }
        }
        else if (RemoteFailureClassifier.IsWhipMuxerStatusInfo(line))
        {
            // Success/progress dump (includes dtls:/ice: timings) — log once, never fail the session.
            if (line.Contains("Muxer state=", StringComparison.OrdinalIgnoreCase))
                _logger.LogInformation("WHIP muxer ready: {Line}", SensitiveDataFilter.FilterStatic(line));
            else
                _logger.LogDebug("WHIP muxer: {Line}", SensitiveDataFilter.FilterStatic(line));
        }
        else if (!isProgressKv && (
                     line.Contains("error", StringComparison.OrdinalIgnoreCase) ||
                     line.Contains("whip", StringComparison.OrdinalIgnoreCase) ||
                     line.Contains("http", StringComparison.OrdinalIgnoreCase) ||
                     line.Contains("ice", StringComparison.OrdinalIgnoreCase) ||
                     line.Contains("dtls", StringComparison.OrdinalIgnoreCase) ||
                     line.Contains("candidate", StringComparison.OrdinalIgnoreCase) ||
                     line.Contains("failed", StringComparison.OrdinalIgnoreCase)))
        {
            _logger.LogWarning("Remote FFmpeg: {Line}", SensitiveDataFilter.FilterStatic(line));
        }
    }

    /// <summary>[PipelineDiag] temporary — parse FFmpeg -progress cumulative counters.</summary>
    private void RecordPipelineDiagProgressLine(string line)
    {
        if (line.StartsWith("frame=", StringComparison.Ordinal))
        {
            if (long.TryParse(line.AsSpan("frame=".Length), out var frame))
            {
                Interlocked.Exchange(ref _diagFfFrame, frame);
                RecordPipelineDiagInterFrameGap();
                if (!_diagSeqFirstProgressFrameLogged)
                {
                    _diagSeqFirstProgressFrameLogged = true;
                    var ageMs = _diagProcessLaunchUtc == DateTime.MinValue
                        ? -1
                        : (DateTime.UtcNow - _diagProcessLaunchUtc).TotalMilliseconds;
                    _logger.LogInformation(
                        "[PipelineDiag] Seq FirstProgressFrame ageMs={AgeMs:F0} frame={Frame} epoch={Epoch}",
                        ageMs,
                        frame,
                        _diagLaunchProcessEpoch);
                }
            }
        }
        else if (line.StartsWith("dup_frames=", StringComparison.Ordinal))
        {
            if (long.TryParse(line.AsSpan("dup_frames=".Length), out var dup))
                Interlocked.Exchange(ref _diagFfDupFrames, dup);
        }
        else if (line.StartsWith("drop_frames=", StringComparison.Ordinal))
        {
            if (long.TryParse(line.AsSpan("drop_frames=".Length), out var drop))
                Interlocked.Exchange(ref _diagFfDropFrames, drop);
        }
        else if (line.StartsWith("fps=", StringComparison.Ordinal))
        {
            if (TryParseProgressDouble(line.AsSpan("fps=".Length), out var fps))
                _diagLatestReportedFps = fps;
        }
        else if (line.StartsWith("bitrate=", StringComparison.Ordinal))
        {
            if (TryParseProgressBitrateKbps(line.AsSpan("bitrate=".Length), out var kbps))
                _diagLatestBitrateKbps = kbps;
        }
        else if (line.StartsWith("stream_", StringComparison.Ordinal) && line.Contains("_q=", StringComparison.Ordinal))
        {
            var qIdx = line.IndexOf("_q=", StringComparison.Ordinal);
            if (qIdx >= 0 && long.TryParse(line.AsSpan(qIdx + 3), out var q) && q > _diagMaxStream0Q)
                _diagMaxStream0Q = q;
        }
        else if (line.StartsWith("speed=", StringComparison.Ordinal))
        {
            if (line.Length > "speed=".Length
                && TryParseProgressDouble(line.AsSpan("speed=".Length).Trim().TrimEnd('x'), out var speed)
                && speed > 0)
            {
                _diagLatestSpeed = speed;
                _diagSpeedSum += speed;
                _diagSpeedSamples++;
                if (speed < 0.5)
                {
                    _logger.LogWarning(
                        "[PipelineDiag] Seq FfmpegSpeedSlow speed={Speed}x epoch={Epoch}",
                        speed,
                        _diagLaunchProcessEpoch);
                }
            }
        }
        else if (line.StartsWith("progress=continue", StringComparison.Ordinal))
        {
            RecordPipelineDiagProgressBatch();
        }
    }

    private static bool TryParseProgressDouble(ReadOnlySpan<char> text, out double value)
    {
        text = text.Trim();
        return double.TryParse(text, System.Globalization.NumberStyles.Float,
            System.Globalization.CultureInfo.InvariantCulture, out value);
    }

    private static bool TryParseProgressBitrateKbps(ReadOnlySpan<char> text, out double kbps)
    {
        kbps = 0;
        text = text.Trim();
        if (text.EndsWith("kbits/s", StringComparison.OrdinalIgnoreCase))
            text = text[..^7].Trim();

        return double.TryParse(text, System.Globalization.NumberStyles.Float,
            System.Globalization.CultureInfo.InvariantCulture, out kbps);
    }

    private void RecordPipelineDiagStderrActivity(string line)
    {
        var now = DateTime.UtcNow;
        if (_diagLastAnyStderrUtc != DateTime.MinValue)
        {
            var idleMs = (long)Math.Max((now - _diagLastAnyStderrUtc).TotalMilliseconds, 0);
            if (idleMs > _diagMaxStderrIdleMs)
                _diagMaxStderrIdleMs = idleMs;
        }

        _diagLastAnyStderrUtc = now;
    }

    private void RecordPipelineDiagProgressBatch()
    {
        var now = DateTime.UtcNow;
        if (_diagLastProgressBatchUtc != DateTime.MinValue)
        {
            var batchMs = (long)Math.Max((now - _diagLastProgressBatchUtc).TotalMilliseconds, 0);
            _diagProgressBatchSamples++;
            _diagProgressBatchTotalMs += batchMs;
            if (batchMs > _diagProgressBatchMaxMs)
                _diagProgressBatchMaxMs = batchMs;
        }

        _diagLastProgressBatchUtc = now;
    }

    private void RecordPipelineDiagHwStderrLine(string line)
    {
        if (!LooksLikeFfmpegInternalBlockHint(line))
            return;

        _diagHwStderrHits++;
        _diagLastHwStderrSnippet = line.Length > 160 ? line[..160] : line;
        _logger.LogInformation(
            "[PipelineDiag] FfmpegStderrHit epoch={Epoch} hit={Hit} line={Line}",
            _diagLaunchProcessEpoch,
            _diagHwStderrHits,
            SensitiveDataFilter.FilterStatic(line));
    }

    private static bool LooksLikeFfmpegInternalBlockHint(string line)
    {
        // Ignore startup banners (encoder name / stream mapping) — not runtime block signals.
        if (line.Contains("Stream #", StringComparison.Ordinal)
            || line.Contains("-> #", StringComparison.Ordinal)
            || line.Contains("encoder         : Lavc", StringComparison.Ordinal))
            return false;

        return line.Contains("EAGAIN", StringComparison.OrdinalIgnoreCase)
               || line.Contains("ret=-11", StringComparison.OrdinalIgnoreCase)
               || line.Contains("UDP send blocked", StringComparison.OrdinalIgnoreCase)
               || line.Contains("Queue input is backward", StringComparison.OrdinalIgnoreCase)
               || line.Contains("Cannot allocate memory", StringComparison.OrdinalIgnoreCase)
               || line.Contains("error", StringComparison.OrdinalIgnoreCase)
               && (line.Contains("qsv", StringComparison.OrdinalIgnoreCase)
                   || line.Contains("mfx", StringComparison.OrdinalIgnoreCase)
                   || line.Contains("hw_", StringComparison.OrdinalIgnoreCase)
                   || line.Contains("whip", StringComparison.OrdinalIgnoreCase))
               || (line.Contains("whip", StringComparison.OrdinalIgnoreCase)
                   && (line.Contains("blocked", StringComparison.OrdinalIgnoreCase)
                       || line.Contains("timeout", StringComparison.OrdinalIgnoreCase)));
    }

    private void RecordPipelineDiagInterFrameGap()
    {
        var now = DateTime.UtcNow;
        if (_diagLastProgressFrameUtc != DateTime.MinValue)
        {
            var gapMs = (long)Math.Max((now - _diagLastProgressFrameUtc).TotalMilliseconds, 0);
            _diagInterFrameGapSamples++;
            _diagInterFrameGapTotalMs += gapMs;
            if (gapMs > _diagMaxInterFrameGapMs)
                _diagMaxInterFrameGapMs = gapMs;
        }

        _diagLastProgressFrameUtc = now;
    }

    private void ResetPipelineDiagFfProgress()
    {
        Interlocked.Exchange(ref _diagFfFrame, 0);
        Interlocked.Exchange(ref _diagFfDupFrames, 0);
        Interlocked.Exchange(ref _diagFfDropFrames, 0);
        _diagSnapshotFrame = 0;
        _diagSnapshotDupFrames = 0;
        _diagSnapshotDropFrames = 0;
        _diagSnapshotOutTimeUs = 0;
        _diagFfLogUtc = DateTime.UtcNow;
        _diagLastProgressFrameUtc = DateTime.MinValue;
        _diagMaxInterFrameGapMs = 0;
        _diagInterFrameGapTotalMs = 0;
        _diagInterFrameGapSamples = 0;
        _diagLastAnyStderrUtc = DateTime.MinValue;
        _diagMaxStderrIdleMs = 0;
        _diagLastProgressBatchUtc = DateTime.MinValue;
        _diagProgressBatchSamples = 0;
        _diagProgressBatchTotalMs = 0;
        _diagProgressBatchMaxMs = 0;
        _diagLatestSpeed = 0;
        _diagSpeedSum = 0;
        _diagSpeedSamples = 0;
        _diagLatestReportedFps = 0;
        _diagLatestBitrateKbps = 0;
        _diagMaxStream0Q = 0;
        _diagHwStderrHits = 0;
        _diagLastHwStderrSnippet = null;
    }

    /// <summary>[PipelineDiag] temporary — log FFmpeg progress deltas every 5 seconds.</summary>
    private void MaybeLogPipelineDiagFfProgress()
    {
        var now = DateTime.UtcNow;
        if (_diagFfLogUtc != DateTime.MinValue && now - _diagFfLogUtc < TimeSpan.FromSeconds(5))
            return;

        var elapsedSec = _diagFfLogUtc == DateTime.MinValue
            ? 5.0
            : Math.Max((now - _diagFfLogUtc).TotalSeconds, 0.001);

        var frame = Interlocked.Read(ref _diagFfFrame);
        var dup = Interlocked.Read(ref _diagFfDupFrames);
        var drop = Interlocked.Read(ref _diagFfDropFrames);
        var outTimeUs = Interlocked.Read(ref _lastOutTimeUs);

        var deltaFrame = frame - _diagSnapshotFrame;
        var deltaDup = dup - _diagSnapshotDupFrames;
        var deltaDrop = drop - _diagSnapshotDropFrames;
        var deltaOutTimeUs = outTimeUs - _diagSnapshotOutTimeUs;

        var maxGapMs = _diagMaxInterFrameGapMs;
        var gapSamples = _diagInterFrameGapSamples;
        var avgGapMs = gapSamples > 0 ? _diagInterFrameGapTotalMs / (double)gapSamples : 0;
        var processAgeSec = _diagProcessLaunchUtc == DateTime.MinValue
            ? -1
            : (now - _diagProcessLaunchUtc).TotalSeconds;

        _diagSnapshotFrame = frame;
        _diagSnapshotDupFrames = dup;
        _diagSnapshotDropFrames = drop;
        _diagSnapshotOutTimeUs = outTimeUs;
        _diagFfLogUtc = now;
        _diagMaxInterFrameGapMs = 0;
        _diagInterFrameGapTotalMs = 0;
        _diagInterFrameGapSamples = 0;

        var encodeFps = deltaFrame / elapsedSec;
        var outTimeFps = deltaOutTimeUs / elapsedSec / 1_000_000.0;
        var blockHint = maxGapMs >= 500
            ? "ffmpeg-interframe-gap"
            : encodeFps < 5 && deltaDup == 0
                ? "ffmpeg-input-starvation"
                : encodeFps >= 10
                    ? "none"
                    : "ffmpeg-encode-slow";

        _logger.LogInformation(
            "[PipelineDiag] FFmpegProgress windowSec={Window:F1} processAgeSec={Age:F1} epoch={Epoch} Δframe={DeltaFrame} Δdup={DeltaDup} Δdrop={DeltaDrop} Δout_time_us={DeltaOutUs} encodeFps={EncodeFps:F1} outTimeFps={OutTimeFps:F1} interFrameGapAvgMs={GapAvg:F0} interFrameGapMaxMs={GapMax} cumulative frame={Frame} out_time_us={OutUs} blockHint={Hint}",
            elapsedSec,
            processAgeSec,
            _diagLaunchProcessEpoch,
            deltaFrame,
            deltaDup,
            deltaDrop,
            deltaOutTimeUs,
            encodeFps,
            outTimeFps,
            avgGapMs,
            maxGapMs,
            frame,
            outTimeUs,
            blockHint);

        LogPipelineDiagFfmpegInternal(elapsedSec, encodeFps, outTimeFps, maxGapMs);
    }

    /// <summary>[PipelineDiag] temporary — QSV / progress-batch / stderr-idle summary every 5s.</summary>
    private void LogPipelineDiagFfmpegInternal(
        double windowSec,
        double encodeFps,
        double outTimeFps,
        long interFrameGapMaxMs)
    {
        var batchSamples = _diagProgressBatchSamples;
        var batchAvgMs = batchSamples > 0 ? _diagProgressBatchTotalMs / (double)batchSamples : 0;
        var batchMaxMs = _diagProgressBatchMaxMs;
        var speedAvg = _diagSpeedSamples > 0 ? _diagSpeedSum / _diagSpeedSamples : 0;
        var maxStreamQ = _diagMaxStream0Q;
        var maxStderrIdleMs = _diagMaxStderrIdleMs;
        var hwHits = _diagHwStderrHits;

        _diagProgressBatchSamples = 0;
        _diagProgressBatchTotalMs = 0;
        _diagProgressBatchMaxMs = 0;
        _diagSpeedSum = 0;
        _diagSpeedSamples = 0;
        _diagMaxStream0Q = 0;
        _diagMaxStderrIdleMs = 0;
        _diagHwStderrHits = 0;
        _diagLastHwStderrSnippet = null;

        var internalHint = ResolveFfmpegInternalBlockHint(
            encodeFps,
            interFrameGapMaxMs,
            batchAvgMs,
            batchMaxMs,
            maxStreamQ,
            speedAvg,
            _diagLatestSpeed,
            hwHits,
            _diagLastHwStderrSnippet);

        _logger.LogInformation(
            "[PipelineDiag] FfmpegInternal epoch={Epoch} speedLast={SpeedLast:F3} speedAvg={SpeedAvg:F3} reportedFps={ReportedFps:F1} bitrateKbps={Bitrate:F0} maxStreamQ={StreamQ} progressBatchAvgMs={BatchAvg:F0} progressBatchMaxMs={BatchMax} maxStderrIdleMs={StderrIdleMax} hwStderrHits={HwHits} outTimeFps={OutTimeFps:F1} internalHint={Hint}",
            _diagLaunchProcessEpoch,
            _diagLatestSpeed,
            speedAvg,
            _diagLatestReportedFps,
            _diagLatestBitrateKbps,
            maxStreamQ,
            batchAvgMs,
            batchMaxMs,
            maxStderrIdleMs,
            hwHits,
            outTimeFps,
            internalHint);
    }

    private static string ResolveFfmpegInternalBlockHint(
        double encodeFps,
        long interFrameGapMaxMs,
        double progressBatchAvgMs,
        long progressBatchMaxMs,
        long maxStreamQ,
        double speedAvg,
        double speedLast,
        int hwStderrHits,
        string? lastHwSnippet)
    {
        if (maxStreamQ >= 3)
            return "encoder-queue-backlog";

        // progress batch ≈ full demux+encode+mux loop; ~500ms with q=0 → CFR/pipe pacing
        if (progressBatchMaxMs >= 450 || interFrameGapMaxMs >= 450)
        {
            if (maxStreamQ <= 1 && speedAvg > 0 && speedAvg < 0.5)
                return "pipe-read-or-cfr-loop";

            if (speedAvg > 0 && speedAvg < 0.5)
                return "qsv-encode-or-whip-mux";

            return "ffmpeg-main-loop-slow";
        }

        if (lastHwSnippet != null)
        {
            if (lastHwSnippet.Contains("EAGAIN", StringComparison.OrdinalIgnoreCase)
                || lastHwSnippet.Contains("UDP send blocked", StringComparison.OrdinalIgnoreCase)
                || lastHwSnippet.Contains("ret=-11", StringComparison.OrdinalIgnoreCase))
                return "whip-udp-send";

            if (lastHwSnippet.Contains("qsv", StringComparison.OrdinalIgnoreCase)
                || lastHwSnippet.Contains("mfx", StringComparison.OrdinalIgnoreCase))
                return "qsv-hw-error";
        }

        if (hwStderrHits > 0)
            return "ffmpeg-hw-stderr";

        if (encodeFps >= 10)
            return "none";

        if (speedLast > 0 && speedLast < 0.5)
            return "speed-below-realtime";

        return "unknown-slow";
    }

    private string GetRecentStderrSummary()
    {
        lock (_stderrLock)
        {
            if (_recentStderr.Count == 0)
                return "";

            return string.Join(" | ", _recentStderr.Select(SensitiveDataFilter.FilterStatic));
        }
    }

    private async Task StopInternalAsync(bool notifyFailed, bool userInitiated, CancellationToken cancellationToken)
    {
        Process? process;
        RemoteViewStartParams? parameters;
        lock (_gate)
        {
            process = _ffmpegProcess;
            parameters = _activeParams;
            _ffmpegProcess = null;
            // Always clear session params on stop. Permanent failures must not leave ActiveSessionId
            // latched or lifecycle will keep reconnecting / tray stays in remote mode.
            _activeParams = null;
            if (userInitiated)
                _userInitiatedStop = true;
        }

        if (process != null)
            Interlocked.Increment(ref _processEpoch);

        if (process != null)
        {
            try
            {
                if (!process.HasExited)
                {
                    try
                    {
                        if (!process.WaitForExit(2000))
                            process.Kill(entireProcessTree: true);
                    }
                    catch (InvalidOperationException)
                    {
                        // already exited
                    }

                    try
                    {
                        if (!process.HasExited)
                            process.Kill(entireProcessTree: true);
                    }
                    catch (InvalidOperationException)
                    {
                        // already exited
                    }

                    // Ensure OS releases the RTMP socket before a republish.
                    try { process.WaitForExit(5000); }
                    catch (InvalidOperationException) { }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to stop remote view FFmpeg");
            }
            finally
            {
                process.Dispose();
            }
        }

        if (parameters != null || notifyFailed)
            await _captureCoordinator.NotifyConsumerStoppingAsync(CaptureConsumer.RemoteView, cancellationToken);
    }

    private async Task WaitForSharedBridgeReadyAsync(Process process, CancellationToken cancellationToken)
    {
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(SharedBridgeReadyTimeout);

        try
        {
            if (_firstFrameTcs != null)
                await _firstFrameTcs.Task.WaitAsync(timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            if (process.HasExited)
            {
                var detail = GetRecentStderrSummary();
                throw new InvalidOperationException(
                    string.IsNullOrWhiteSpace(detail)
                        ? $"Remote SharedBridge encoder exited with code {process.ExitCode}"
                        : $"Remote SharedBridge encoder exited: {detail}");
            }

            throw new TimeoutException("Timed out waiting for remote SharedBridge first frame");
        }

        if (process.HasExited)
            throw new InvalidOperationException($"Remote SharedBridge encoder exited with code {process.ExitCode}");
    }

    private async Task WaitForWhipMediaReadyAsync(Process process, CancellationToken cancellationToken)
    {
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(WhipMediaReadyTimeout);
        var token = timeoutCts.Token;

        try
        {
            while (!token.IsCancellationRequested)
            {
                if (process.HasExited)
                {
                    var detail = BuildExitDetail(process.ExitCode);
                    throw new InvalidOperationException(detail);
                }

                var pending = TakePendingTransportError();
                if (!string.IsNullOrWhiteSpace(pending))
                    throw new InvalidOperationException(pending);

                if (Interlocked.Read(ref _lastOutTimeUs) > 0 || Interlocked.Read(ref _lastTotalSize) > 0)
                {
                    _logger.LogInformation(
                        "WHIP media flowing out_time_us={OutTime} total_size={Size}",
                        Interlocked.Read(ref _lastOutTimeUs),
                        Interlocked.Read(ref _lastTotalSize));
                    return;
                }

                await Task.Delay(150, token);
            }
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            if (process.HasExited)
                throw new InvalidOperationException(BuildExitDetail(process.ExitCode));

            try
            {
                if (!process.HasExited)
                    process.Kill(entireProcessTree: true);
            }
            catch (InvalidOperationException) { }

            var stderr = GetRecentStderrSummary();
            throw new TimeoutException(
                string.IsNullOrWhiteSpace(stderr)
                    ? "WHIP ICE/media timeout: no RTP within handshake window (check UDP 7893 to Ingress)"
                    : "WHIP ICE/media timeout: " + stderr);
        }
    }

    private async Task WaitForRtmpReadyAsync(Process process, CancellationToken cancellationToken)
    {
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(RtmpReadyTimeout);

        try
        {
            if (_firstFrameTcs != null)
                await _firstFrameTcs.Task.WaitAsync(timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            if (process.HasExited)
            {
                var detail = GetRecentStderrSummary();
                throw new InvalidOperationException(
                    string.IsNullOrWhiteSpace(detail)
                        ? $"Remote RTMP encoder exited with code {process.ExitCode}"
                        : $"Remote RTMP encoder exited: {detail}");
            }

            throw new TimeoutException("Timed out waiting for remote RTMP first frame");
        }

        if (process.HasExited)
            throw new InvalidOperationException($"Remote RTMP encoder exited with code {process.ExitCode}");
    }

    private async Task RaisePublishFailedAsync(string? sessionId, string detail)
    {
        lock (_gate)
        {
            if (_userInitiatedStop)
            {
                _logger.LogDebug("Suppressing PublishFailed after user-initiated stop: {Detail}", detail);
                return;
            }
        }

        var handler = PublishFailed;
        if (handler == null)
            return;

        try
        {
            await handler(sessionId, detail);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "PublishFailed handler error");
        }
    }

    private string BuildFfmpegArgs(
        CaptureProfile profile,
        string encoder,
        int width,
        int height,
        int fps,
        int bitrateKbps,
        string publishProtocol,
        string publishUrl,
        string streamKey = "")
    {
        var gop = Math.Max(fps, 5);
        var isWhip = string.Equals(publishProtocol, "whip", StringComparison.OrdinalIgnoreCase);
        if (isWhip)
        {
            var gopDivisor = Math.Clamp(_config.WhipGopDivisor, 2, 8);
            gop = Math.Max(fps / gopDivisor, 4);
        }

        var bufsizeDivisor = Math.Clamp(_config.WhipBufsizeDivisor, 4, 16);
        var bufsizeKbps = isWhip
            ? Math.Max(bitrateKbps / bufsizeDivisor, 250)
            : bitrateKbps;
        var qsvAsyncDepth = Math.Clamp(_config.QsvAsyncDepth, 1, 8);
        var encoderArgs = encoder switch
        {
            "h264_nvenc" => $"-c:v h264_nvenc -preset p1 -tune ll -profile:v baseline -rc cbr -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bufsizeKbps}k -bf 0 -forced-idr 1",
            "h264_qsv" => $"-c:v h264_qsv -profile:v baseline -look_ahead 0 -async_depth {qsvAsyncDepth} -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bufsizeKbps}k -bf 0",
            "h264_amf" => $"-c:v h264_amf -usage ultralowlatency -profile:v baseline -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bufsizeKbps}k -bf 0",
            _ => $"-c:v libx264 -preset ultrafast -tune zerolatency -profile:v baseline -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bufsizeKbps}k -bf 0",
        };

        var sb = new StringBuilder();
        // WHIP: info so ICE/HTTP failures appear in Agent logs (warning hides them).
        sb.Append(isWhip
            ? "-hide_banner -loglevel info -progress pipe:2 -nostats -fflags nobuffer -flags low_delay "
            : "-hide_banner -loglevel warning -progress pipe:2 -nostats ");

        if (profile.Mode == CaptureMode.SharedBridge && !string.IsNullOrWhiteSpace(profile.RemoteInputArgs))
        {
            sb.Append(profile.RemoteInputArgs).Append(' ');
            // Pipe is CFR at bridge fps; vf fps keeps encoder timebase aligned (backup 63 profile).
            if (width != profile.RemoteWidth || height != profile.RemoteHeight)
                sb.Append($"-vf \"fps={fps},scale={width}:{height}\" ");
            else
                sb.Append($"-vf \"fps={fps}\" ");
        }
        else
        {
            // DualGdigrab / standalone: dedicated gdigrab so WHIP can POST immediately (no pipe stall).
            sb.Append($"-f gdigrab -framerate {fps} -i desktop ");
            sb.Append($"-vf \"fps={fps},scale={width}:{height}:force_original_aspect_ratio=decrease," +
                      $"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2\" ");
        }

        sb.Append(encoderArgs).Append(' ');
        // QSV/NVENC prefer nv12; yuv420p triggers an auto-convert warning and extra work.
        var pixFmt = encoder is "h264_qsv" or "h264_nvenc" ? "nv12" : "yuv420p";
        // SharedBridge pipe is CFR at bridge fps; cfr matches backup 63 steady encode after WHIP ICE.
        if (isWhip)
        {
            if (profile.Mode == CaptureMode.SharedBridge)
                sb.Append("-fps_mode cfr ");
            sb.Append($"-an -pix_fmt {pixFmt} -g {gop} -keyint_min {gop} ");
        }
        else
            sb.Append($"-an -pix_fmt {pixFmt} -g {gop} -keyint_min {gop} -sc_threshold 0 ");

        var escapedUrl = publishUrl.Replace("\"", "\\\"");
        if (isWhip)
        {
            // FFmpeg WHIP muxer is experimental; only UDP ICE is supported (TCP candidates ignored).
            // Windows UDP SO_SNDBUF often defaults ~4KB (see muxer "buffer_size=4096"); first IDR
            // then hits EAGAIN → "UDP send blocked" / ret=-11. Explicit 8MB send buffer.
            const int whipTsBufferSize = 8 * 1024 * 1024;
            sb.Append("-flush_packets 1 -strict experimental -f whip ");
            sb.Append("-handshake_timeout ").Append(WhipHandshakeTimeoutMs).Append(' ');
            sb.Append("-ts_buffer_size ").Append(whipTsBufferSize).Append(' ');
            if (!string.IsNullOrWhiteSpace(streamKey))
            {
                var auth = streamKey.Replace("\"", "\\\"");
                sb.Append("-authorization \"").Append(auth).Append("\" ");
            }

            sb.Append('"').Append(escapedUrl).Append('"');
        }
        else
        {
            sb.Append("-f flv -flvflags no_duration_filesize -flush_packets 1 ");
            sb.Append('"').Append(escapedUrl).Append('"');
        }
        return sb.ToString();
    }

    private static bool IsRtmpTransportError(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return false;

        return RemoteFailureClassifier.IsTransportHint(text) ||
               RemoteFailureClassifier.LooksLikeServerReject(text);
    }

    /// <summary>
    /// WHIP failures that cannot be healed by relaunching FFmpeg against the same stream key.
    /// Typical when UDP ICE media is blocked (security group) or the Ingress resource was deleted.
    /// </summary>
    private static bool IsWhipUnrecoverableLocally(string? reason, string? lastError)
    {
        static bool Match(string? text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return false;

            return text.Contains("ret=-11", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("code -11", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("code -5", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("Resource temporarily unavailable", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("Failed to write packet", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("Could not write header", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("incorrect codec parameters", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("I/O error", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("404 Not Found", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("HTTP error 404", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("WHIP ICE/media timeout", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("Failed to connect udp", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("DTLS handshake timeout", StringComparison.OrdinalIgnoreCase) ||
                   text.Contains("No ice candidate", StringComparison.OrdinalIgnoreCase);
        }

        return Match(reason) || Match(lastError);
    }

    private static string? FindFfmpeg()
    {
        var paths = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "ffmpeg.exe"),
            Path.Combine(AppContext.BaseDirectory, "bin", "ffmpeg.exe"),
            @"C:\ffmpeg\bin\ffmpeg.exe",
        };

        foreach (var path in paths)
        {
            if (File.Exists(path))
                return path;
        }

        return null;
    }

    private async Task<string> DetectEncoderAsync(
        string ffmpeg,
        int width,
        int height,
        int fps,
        int bitrateKbps,
        CancellationToken cancellationToken)
    {
        // Reuse a recently verified encoder without re-probing hardware encoders.
        if (_encoderVerified && !string.IsNullOrWhiteSpace(_encoder)
            && DateTime.UtcNow - _encoderCachedAtUtc < EncoderCacheLifetime)
        {
            _logger.LogDebug("Remote view encoder reuse (skip probe): {Encoder}", _encoder);
            return _encoder;
        }

        if (_cachedProbeEncoder != null
            && _cachedProbeWidth == width
            && _cachedProbeHeight == height
            && _cachedProbeFps == fps
            && await ProbeEncoderAsync(ffmpeg, _cachedProbeEncoder, width, height, fps, bitrateKbps, cancellationToken))
        {
            _logger.LogDebug("Remote view encoder cache hit: {Encoder}", _cachedProbeEncoder);
            CacheProbeEncoder(_cachedProbeEncoder, width, height, fps);
            return _cachedProbeEncoder;
        }

        foreach (var encoder in new[] { "h264_nvenc", "h264_qsv", "h264_amf", "libx264" })
        {
            if (await ProbeEncoderAsync(ffmpeg, encoder, width, height, fps, bitrateKbps, cancellationToken))
            {
                _logger.LogInformation("Remote view encoder probe passed: {Encoder}", encoder);
                CacheProbeEncoder(encoder, width, height, fps);
                return encoder;
            }

            _logger.LogWarning("Remote view encoder probe failed: {Encoder}", encoder);
        }

        CacheProbeEncoder("libx264", width, height, fps);
        return "libx264";
    }

    private void CacheProbeEncoder(string encoder, int width, int height, int fps)
    {
        _encoder = encoder;
        _encoderVerified = true;
        _cachedProbeEncoder = encoder;
        _cachedProbeWidth = width;
        _cachedProbeHeight = height;
        _cachedProbeFps = fps;
        _encoderCachedAtUtc = DateTime.UtcNow;
    }

    private void InvalidateEncoderCache()
    {
        _encoderVerified = false;
        _encoderCachedAtUtc = DateTime.MinValue;
        _encoder = "";
    }

    private static async Task<bool> ProbeEncoderAsync(
        string ffmpeg,
        string encoder,
        int width,
        int height,
        int fps,
        int bitrateKbps,
        CancellationToken cancellationToken)
    {
        var alignedWidth = width & ~1;
        var alignedHeight = height & ~1;
        var testOutput = Path.GetTempFileName() + ".flv";

        try
        {
            var encoderArgs = encoder switch
            {
                "h264_nvenc" => $"-c:v h264_nvenc -preset p4 -profile:v baseline -rc cbr -b:v {bitrateKbps}k",
                "h264_qsv" => $"-c:v h264_qsv -profile:v baseline -b:v {bitrateKbps}k",
                "h264_amf" => $"-c:v h264_amf -profile:v baseline -b:v {bitrateKbps}k",
                _ => $"-c:v libx264 -preset veryfast -tune zerolatency -profile:v baseline -b:v {bitrateKbps}k",
            };

            var args =
                $"-hide_banner -f lavfi -i testsrc=duration=1:size={alignedWidth}x{alignedHeight}:rate={fps} " +
                $"{encoderArgs} -pix_fmt yuv420p -t 1 -f flv -y \"{testOutput}\"";

            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffmpeg,
                    Arguments = args,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardError = true,
                },
            };

            process.Start();
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(10));
            try
            {
                await process.WaitForExitAsync(cts.Token);
            }
            catch (OperationCanceledException)
            {
                try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { }
                return false;
            }

            return process.ExitCode == 0 && File.Exists(testOutput) && new FileInfo(testOutput).Length > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            try
            {
                if (File.Exists(testOutput))
                    File.Delete(testOutput);
            }
            catch
            {
                // ignore cleanup failures
            }
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        try
        {
            StopAsync().GetAwaiter().GetResult();
        }
        catch
        {
            // ignore dispose stop failures
        }
        _publishLock.Dispose();
    }
}

using System.Windows.Forms;

namespace EnterpriseAgent.Agent.UI;

/// <summary>
/// Shows a one-off toast from a short-lived process (e.g. blocked duplicate launch).
/// </summary>
internal static class StandaloneToast
{
    public static void ShowInfo(string title, string message, int durationSec = 8)
    {
        if (string.IsNullOrWhiteSpace(title) && string.IsNullOrWhiteSpace(message))
            return;

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.SetHighDpiMode(HighDpiMode.SystemAware);

        using var toast = new NotificationToastForm(title, message, "info", durationSec);
        toast.FormClosed += (_, _) => Application.ExitThread();

        var screen = Screen.PrimaryScreen;
        if (screen != null)
        {
            var workArea = screen.WorkingArea;
            toast.SetStackPosition(workArea.Right - toast.Width - 16, workArea.Bottom - toast.Height - 16);
        }

        toast.Show();
        Application.Run();
    }
}

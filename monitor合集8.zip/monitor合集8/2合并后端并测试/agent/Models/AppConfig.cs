using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Models;

/// <summary>
/// 全局常量定义 - 消除魔法数字
/// </summary>
public static class Constants
{
    // ========== 重试与超时配置 ==========
    
    /// <summary>最大重试次数</summary>
    public const int MaxRetryCount = 3;
    
    /// <summary>最大 WebSocket 重连尝试次数</summary>
    public const int MaxWebSocketReconnectAttempts = 10;
    
    /// <summary>默认 HTTP 超时（秒）</summary>
    public const int DefaultHttpTimeoutSeconds = 30;
    
    /// <summary>文件上传超时（秒）</summary>
    public const int UploadTimeoutSeconds = 300;
    
    // ========== 服务间隔配置 ==========
    
    /// <summary>活动监控间隔（毫秒）</summary>
    public const int ActivityMonitorIntervalMs = 2000;
    
    /// <summary>空闲判定阈值（毫秒）</summary>
    public const int IdleThresholdMs = 30000;
    
    /// <summary>上传队列轮询间隔（毫秒）</summary>
    public const int UploadQueuePollIntervalMs = 2000;
    
    /// <summary>健康检查间隔（毫秒）</summary>
    public const int HealthCheckIntervalMs = 30000;
    
    /// <summary>指标采集间隔（毫秒）</summary>
    public const int MetricsCollectionIntervalMs = 15000;
    
    /// <summary>清理服务执行时间（小时，UTC）</summary>
    public const int CleanupServiceHourUtc = 2;
    
    // ========== WebSocket 配置 ==========
    
    /// <summary>心跳间隔（秒）</summary>
    public const int WebSocketHeartbeatIntervalSeconds = 54;
    
    /// <summary>心跳超时（秒）</summary>
    public const int WebSocketHeartbeatTimeoutSeconds = 90;
    
    /// <summary>接收缓冲区大小（字节）</summary>
    public const int WebSocketReceiveBufferSize = 8192;

    /// <summary>单条 WebSocket 消息最大字节数（1 MB）</summary>
    public const int MaxWebSocketMessageSize = 1024 * 1024;
    
    // ========== 录屏配置 ==========
    
    /// <summary>默认录屏帧率</summary>
    public const int DefaultRecordingFps = 5;
    
    /// <summary>空闲时录屏帧率</summary>
    public const int IdleRecordingFps = 3;
    
    /// <summary>最小切片时长（秒）</summary>
    public const int MinSliceSeconds = 30;

    /// <summary>有效录屏文件最小字节数（与上传任务过滤一致）</summary>
    public const int MinRecordingFileBytes = 100;
    
    /// <summary>录屏健康检查间隔（秒）</summary>
    public const int RecordingHealthCheckIntervalSeconds = 30;
    
    /// <summary>录屏停滞判定时间（秒）</summary>
    public const int RecordingStallTimeoutSeconds = 120;
    
    /// <summary>FFmpeg 进程终止等待（毫秒）</summary>
    public const int FfmpegKillWaitMs = 3000;
    
    /// <summary>FFmpeg 最大退出等待尝试次数</summary>
    public const int FfmpegMaxExitWaitAttempts = 5;
    
    /// <summary>FFmpeg 优雅退出等待时间（秒）</summary>
    public const int FfmpegGracefulExitWaitSeconds = 3;
    
    /// <summary>文件就绪检查最大重试次数</summary>
    public const int FileReadyMaxRetries = 10;
    
    /// <summary>文件就绪检查重试间隔（毫秒）</summary>
    public const int FileReadyRetryIntervalMs = 500;
    
    /// <summary>软件编码器重启冷却时间（秒）</summary>
    public const int SoftwareEncoderRestartCooldownSeconds = 3;
    
    /// <summary>硬件编码器重启冷却时间（秒）</summary>
    public const int HardwareEncoderRestartCooldownSeconds = 10;
    
    /// <summary>硬件编码器最大连续失败次数</summary>
    public const int HardwareEncoderMaxConsecutiveFailures = 5;
    
    /// <summary>硬件编码器5分钟内最大重启次数</summary>
    public const int HardwareEncoderMaxRestartsPer5Minutes = 10;
    
    /// <summary>软件编码器最大连续失败次数</summary>
    public const int SoftwareEncoderMaxConsecutiveFailures = 10;
    
    /// <summary>硬件编码器失败后冷却时间（分钟）</summary>
    public const int HardwareEncoderCooldownMinutes = 30;
    
    /// <summary>系统恢复后等待时间（秒）</summary>
    public const int SystemResumeWaitSeconds = 5;
    
    /// <summary>重启后验证等待时间（秒）</summary>
    public const int PostRestartVerificationSeconds = 3;
    
    /// <summary>重启尝试之间的最小间隔（秒）</summary>
    public const int RestartAttemptMinIntervalSeconds = 60;
    
    /// <summary>编码器探测超时（秒）</summary>
    public const int EncoderProbeTimeoutSeconds = 10;
    
    /// <summary>编码器缓存时间（分钟）</summary>
    public const int EncoderCacheMinutes = 10;
    
    /// <summary>录屏主循环检查间隔（毫秒）</summary>
    public const int RecordingMainLoopIntervalMs = 5000;
    
    /// <summary>重启延迟基础时间（毫秒）</summary>
    public const int RestartDelayBaseMs = 2000;
    
    /// <summary>软件编码器切换额外延迟（毫秒）</summary>
    public const int SoftwareEncoderSwitchDelayMs = 2000;
    
    /// <summary>最大重启延迟（毫秒）</summary>
    public const int MaxRestartDelayMs = 30000;
    
    /// <summary>索引器检查间隔（毫秒）</summary>
    public const int IndexerCheckIntervalMs = 10000;
    
    /// <summary>睡眠前停止录制超时（秒）</summary>
    public const int SuspendStopTimeoutSeconds = 5;
    
    /// <summary>强制清理等待时间（毫秒）</summary>
    public const int ForceCleanupWaitMs = 1000;
    
    /// <summary>进程退出轮询间隔（毫秒）</summary>
    public const int ProcessExitPollingIntervalMs = 100;
    
    /// <summary>屏幕分辨率缓存时间（秒）</summary>
    public const int DisplaySizeCacheSeconds = 30;
    
    /// <summary>FFmpeg 路径缓存时间（分钟）</summary>
    public const int FfmpegPathCacheMinutes = 5;
    
    // ========== 截图配置 ==========
    
    /// <summary>默认截图间隔（秒）</summary>
    public const int DefaultScreenshotIntervalSeconds = 30;
    
    /// <summary>默认截图质量</summary>
    public const int DefaultScreenshotQuality = 75;
    
    /// <summary>GDI 泄漏警告阈值</summary>
    public const int GdiLeakWarningThreshold = 5000;
    
    // ========== 上传配置 ==========
    
    /// <summary>默认分块大小（KB）</summary>
    public const int DefaultChunkSizeKB = 1024;
    
    /// <summary>最小分块大小（KB）</summary>
    public const int MinChunkSizeKB = 64;
    
    /// <summary>默认上传限速（KB/s）</summary>
    public const int DefaultRateLimitKBps = 1024;
    
    /// <summary>默认最大并发上传数</summary>
    public const int DefaultMaxConcurrentUploads = 2;
    
    /// <summary>最小磁盘空间（字节）</summary>
    public const long MinDiskSpaceBytes = 100 * 1024 * 1024;  // 100MB
    
    // ========== 队列配置 ==========
    
    /// <summary>最大待上传队列长度</summary>
    public const int MaxPendingUploadQueue = 1000;
    
    /// <summary>批量写入阈值</summary>
    public const int BatchWriteThreshold = 100;
    
    /// <summary>批量写入间隔（秒）</summary>
    public const int BatchWriteIntervalSeconds = 5;
    
    // ========== 断路器配置 ==========
    
    /// <summary>断路器失败阈值</summary>
    public const int CircuitBreakerFailureThreshold = 5;
    
    /// <summary>断路器开启持续时间（秒）</summary>
    public const int CircuitBreakerOpenDurationSeconds = 30;
    
    /// <summary>断路器半开状态最大请求数</summary>
    public const int CircuitBreakerHalfOpenMaxRequests = 3;
    
    // ========== 降级配置 ==========
    
    /// <summary>轻度降级 CPU 阈值（%）</summary>
    public const int MildDegradationCpuThreshold = 50;
    
    /// <summary>中度降级 CPU 阈值（%）</summary>
    public const int ModerateDegradationCpuThreshold = 70;
    
    /// <summary>严重降级 CPU 阈值（%）</summary>
    public const int SevereDegradationCpuThreshold = 90;
    
    /// <summary>轻度降级内存阈值（%）</summary>
    public const int MildDegradationMemoryThreshold = 70;
    
    /// <summary>中度降级内存阈值（%）</summary>
    public const int ModerateDegradationMemoryThreshold = 80;
    
    /// <summary>严重降级内存阈值（%）</summary>
    public const int SevereDegradationMemoryThreshold = 90;
    
    // ========== 远程屏幕配置 ==========
    
    /// <summary>默认屏幕帧率</summary>
    public const int DefaultScreenFps = 5;
    
    /// <summary>最小屏幕帧率</summary>
    public const int MinScreenFps = 1;
    
    /// <summary>最大屏幕帧率</summary>
    public const int MaxScreenFps = 10;
    
    /// <summary>默认屏幕质量</summary>
    public const int DefaultScreenQuality = 70;
    
    /// <summary>最小屏幕质量</summary>
    public const int MinScreenQuality = 30;
    
    /// <summary>最大屏幕质量</summary>
    public const int MaxScreenQuality = 90;
    
    /// <summary>完整帧发送间隔（帧数）</summary>
    public const int FullFrameInterval = 60;
    
    /// <summary>完整帧变化阈值（0-1）</summary>
    public const double FullFrameChangeThreshold = 0.30;
    
    /// <summary>差异帧变化阈值（0-1）</summary>
    public const double DeltaFrameChangeThreshold = 0.10;
    
    /// <summary>最大区域数量</summary>
    public const int MaxRegions = 8;
    
    /// <summary>背景刷新间隔（帧数）</summary>
    public const int BackgroundRefreshInterval = 300;
    
    // ========== 运动检测配置 ==========
    
    /// <summary>运动检测下采样宽度</summary>
    public const int MotionDetectWidth = 320;
    
    /// <summary>运动检测下采样高度</summary>
    public const int MotionDetectHeight = 240;
    
    /// <summary>运动检测块大小（像素）</summary>
    public const int MotionDetectBlockSize = 16;
    
    /// <summary>运动检测变化阈值（0-1）</summary>
    public const double MotionDetectChangeThreshold = 0.15;
    
    /// <summary>运动检测洪水填充阈值</summary>
    public const double MotionDetectFloodThreshold = 0.15;
    
    // ========== 自适应控制配置 ==========
    
    /// <summary>自适应帧率调整系数</summary>
    public const double AdaptiveFpsUpThreshold = 0.5;
    
    /// <summary>自适应帧率降低系数</summary>
    public const double AdaptiveFpsDownThreshold = 1.2;
    
    /// <summary>自适应质量提升延迟阈值（毫秒）</summary>
    public const double AdaptiveQualityUpLatencyThreshold = 50;
    
    /// <summary>自适应质量降低延迟阈值（毫秒）</summary>
    public const double AdaptiveQualityDownLatencyThreshold = 200;
    
    /// <summary>自适应质量步进值</summary>
    public const int AdaptiveQualityStep = 5;
    
    /// <summary>自适应帧率步进值</summary>
    public const int AdaptiveFpsStep = 1;
    
    // ========== 空闲检测配置 ==========
    
    /// <summary>空闲判定时间（秒）</summary>
    public const int IdleTimeoutSeconds = 30;
    
    /// <summary>空闲时帧率</summary>
    public const int IdleScreenFps = 2;
    
    // ========== 默认值 ==========
    
    /// <summary>默认服务器地址（安装时必须配置）</summary>
    public const string DefaultServerUrl = "";

    /// <summary>默认代理版本</summary>
    public const string DefaultAgentVersion = "2.0.0";
    
    /// <summary>默认存储大小限制（GB）</summary>
    public const int DefaultMaxStorageGB = 100;
    
    /// <summary>日志默认级别</summary>
    public const string DefaultLogLevel = "Information";
    
    /// <summary>日志最大文件大小（MB）</summary>
    public const int DefaultLogMaxSizeMB = 100;

    /// <summary>默认 WebSocket 地址（安装时必须配置或由 ServerUrl 推导）</summary>
    public const string DefaultWsUrl = "";
    
    /// <summary>日志保留文件数</summary>
    public const int DefaultLogMaxFiles = 7;
}
/// <summary>
/// 代理配置 - 支持热重载
/// </summary>
public class AgentConfig
{
    // ========== 基础配置 ==========
    
    public int ConfigVersion { get; set; } = 2;
    public string ServerUrl { get; set; } = Constants.DefaultServerUrl;
    public string WsUrl { get; set; } = Constants.DefaultWsUrl;
    public string DeviceId { get; set; } = "";
    public string AgentVersion { get; set; } = Constants.DefaultAgentVersion;
    
    // ========== 子配置 ==========
    
    public AuthConfig Auth { get; set; } = new();
    public EmployeeInfo Employee { get; set; } = new();
    public PolicyConfig Policy { get; set; } = new();
    public StorageConfig Storage { get; set; } = new();
    public LoggingConfig Logging { get; set; } = new();
    
    // ========== 新增：可观测性配置 ==========
    
    public ObservabilityConfig Observability { get; set; } = new();
    
    // ========== 新增：弹性配置 ==========
    
    public ResilienceConfig Resilience { get; set; } = new();
    
    public RecordingHealthConfig RecordingHealth { get; set; } = new();

    /// <summary>
    /// 允许 HTTP/WS（由 deployment.json 或 AGENT_ALLOW_INSECURE_TRANSPORT 设置）
    /// </summary>
    public bool AllowInsecureTransport { get; set; }
    
    /// <summary>
    /// 验证配置有效性
    /// </summary>
    public (bool IsValid, List<string> Errors) Validate()
    {
        var errors = new List<string>();
        
        if (string.IsNullOrWhiteSpace(ServerUrl))
            errors.Add("ServerUrl is required");
        else if (!Uri.TryCreate(ServerUrl, UriKind.Absolute, out var serverUri))
            errors.Add("ServerUrl is not a valid absolute URI");
        else if (!IsInsecureTransportAllowed() &&
                 !string.Equals(serverUri.Scheme, "https", StringComparison.OrdinalIgnoreCase))
            errors.Add("ServerUrl must use https:// in production (deployment.json allowInsecureTransport or AGENT_ALLOW_INSECURE_TRANSPORT=1)");
        
        if (string.IsNullOrWhiteSpace(WsUrl))
            WsUrl = GetEffectiveWsUrl();

        if (!Uri.TryCreate(WsUrl, UriKind.Absolute, out var wsUri))
            errors.Add("WsUrl is not a valid absolute URI");
        else if (!IsInsecureTransportAllowed() &&
                 !string.Equals(wsUri.Scheme, "wss", StringComparison.OrdinalIgnoreCase))
            errors.Add("WsUrl must use wss:// in production (deployment.json allowInsecureTransport or AGENT_ALLOW_INSECURE_TRANSPORT=1)");

        if (Auth == null || string.IsNullOrWhiteSpace(Auth.PolicySignatureSecret))
            errors.Add("PolicySignatureSecret is required (deployment.json or AGENT_POLICY_SIGNATURE_SECRET)");
        
        if (Storage?.MaxSizeGB <= 0)
            errors.Add("Storage.MaxSizeGB must be greater than 0");
        
        if (Storage != null && string.IsNullOrWhiteSpace(Storage.Path))
            errors.Add("Storage.Path is required");
        
        return (errors.Count == 0, errors);
    }

    private bool IsInsecureTransportAllowed()
    {
        if (AllowInsecureTransport)
            return true;

        return string.Equals(
            Environment.GetEnvironmentVariable("AGENT_ALLOW_INSECURE_TRANSPORT"),
            "1",
            StringComparison.Ordinal);
    }
    
    /// <summary>
    /// 获取 WebSocket URL（自动补全）
    /// </summary>
    public string GetEffectiveWsUrl()
    {
        if (!string.IsNullOrWhiteSpace(WsUrl) && IsWsUrlAlignedWithServer())
            return WsUrl;
        
        return DeriveWsUrlFromServerUrl();
    }

    /// <summary>根据 ServerUrl 推导 WebSocket 地址</summary>
    public string DeriveWsUrlFromServerUrl()
    {
        if (string.IsNullOrWhiteSpace(ServerUrl))
            return "";

        var wsUrl = ServerUrl
            .Replace("http://", "ws://", StringComparison.OrdinalIgnoreCase)
            .Replace("https://", "wss://", StringComparison.OrdinalIgnoreCase);

        return $"{wsUrl.TrimEnd('/')}/ws/agent";
    }

    /// <summary>强制用 ServerUrl 覆盖 WsUrl（部署地址变更时使用）</summary>
    public void SyncWsUrlWithServer()
    {
        WsUrl = DeriveWsUrlFromServerUrl();
    }

    /// <summary>WsUrl 是否与 ServerUrl 指向同一主机/端口</summary>
    public bool IsWsUrlAlignedWithServer()
    {
        if (string.IsNullOrWhiteSpace(ServerUrl) || string.IsNullOrWhiteSpace(WsUrl))
            return string.IsNullOrWhiteSpace(WsUrl);

        try
        {
            var server = new Uri(ServerUrl);
            var ws = new Uri(WsUrl);
            return string.Equals(server.Host, ws.Host, StringComparison.OrdinalIgnoreCase)
                   && server.Port == ws.Port;
        }
        catch
        {
            return false;
        }
    }
    
    /// <summary>
    /// 获取存储路径（自动补全）
    /// </summary>
    public string GetEffectiveStoragePath()
    {
        if (!string.IsNullOrWhiteSpace(Storage?.Path))
            return Storage.Path;
        
        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "EnterpriseAgent",
            "data");
    }
}

/// <summary>
/// 认证配置
/// </summary>
public class AuthConfig
{
    public string Token { get; set; } = "";
    public string RefreshToken { get; set; } = "";
    public string SecretKey { get; set; } = "";
    public string EncryptionKey { get; set; } = "";
    
    /// <summary>
    /// API 签名密钥（用于上传等操作的签名验证）
    /// </summary>
    public string UploadSignatureSecret { get; set; } = "";

    /// <summary>
    /// 策略 HMAC 签名密钥（与后端 POLICY_SIGNATURE_SECRET 一致）
    /// </summary>
    public string PolicySignatureSecret { get; set; } = "";

    /// <summary>
    /// 设备注册密钥（与后端 DEVICE_REGISTRATION_SECRET 一致，可选）
    /// </summary>
    public string RegistrationSecret { get; set; } = "";
    /// <summary>
    /// 每台设备的签名密钥（DeviceSecret），由服务器在注册时生成并返回
    /// </summary>
    public string DeviceSecret { get; set; } = "";

    /// <summary>
    /// 设备审核状态：pending / approved / rejected
    /// </summary>
    public string DeviceStatus { get; set; } = "";
    
    /// <summary>
    /// 检查是否已认证
    /// </summary>
    public bool IsAuthenticated => !string.IsNullOrWhiteSpace(Token);
    
    /// <summary>
    /// 清空认证信息
    /// </summary>
    public void Clear()
    {
        Token = "";
        RefreshToken = "";
        DeviceStatus = "";
    }
}

/// <summary>
/// 员工信息
/// </summary>
public class EmployeeInfo
{
    public string Name { get; set; } = string.Empty;
    public string EmployeeNumber { get; set; } = string.Empty;
    
    public bool IsValid => !string.IsNullOrWhiteSpace(Name);
}

/// <summary>
/// 策略配置
/// </summary>
public class PolicyConfig
{
    public int SyncIntervalSeconds { get; set; } = 300;
    public bool LocalCache { get; set; } = true;

    public bool AllowEncoderFallback { get; set; } = true;

    public string ForceEncoder { get; set; } = "auto";

    public int GpuEncoderRetryMinutes { get; set; } = 30;
}

/// <summary>
/// 存储配置
/// </summary>
public class StorageConfig
{
    public string Path { get; set; } = "";
    public int MaxSizeGB { get; set; } = Constants.DefaultMaxStorageGB;
}

/// <summary>
/// 日志配置
/// </summary>
public class LoggingConfig
{
    public string Level { get; set; } = Constants.DefaultLogLevel;
    public int MaxSizeMB { get; set; } = Constants.DefaultLogMaxSizeMB;
    public int MaxFiles { get; set; } = Constants.DefaultLogMaxFiles;
}

/// <summary>
/// 可观测性配置（新增）
/// </summary>
public class ObservabilityConfig
{
    /// <summary>是否启用结构化日志</summary>
    public bool EnableStructuredLogging { get; set; } = true;
    
    /// <summary>是否启用 Metrics 采集</summary>
    public bool EnableMetrics { get; set; } = true;
    
    /// <summary>Metrics 暴露端口（0 表示禁用 HTTP 端点）</summary>
    public int MetricsPort { get; set; } = 0;
    
    /// <summary>健康检查端口（0 表示禁用）</summary>
    public int HealthPort { get; set; } = 0;
    
    /// <summary>是否启用审计日志</summary>
    public bool EnableAuditLog { get; set; } = true;
}

/// <summary>
/// 弹性配置（新增）
/// </summary>
public class ResilienceConfig
{
    /// <summary>是否启用断路器</summary>
    public bool EnableCircuitBreaker { get; set; } = true;
    
    /// <summary>是否启用幂等性</summary>
    public bool EnableIdempotency { get; set; } = true;
    
    /// <summary>是否启用优雅降级</summary>
    public bool EnableDegradation { get; set; } = true;
    
    /// <summary>是否启用故障自愈</summary>
    public bool EnableSelfHealing { get; set; } = true;

    /// <summary>是否允许执行服务端下发的 execute_command 任务（默认关闭）</summary>
    public bool AllowRemoteCommands { get; set; } = false;
    
    /// <summary>断路器失败阈值</summary>
    public int CircuitBreakerFailureThreshold { get; set; } = Constants.CircuitBreakerFailureThreshold;
    
    /// <summary>断路器开启时间（秒）</summary>
    public int CircuitBreakerOpenDurationSeconds { get; set; } = Constants.CircuitBreakerOpenDurationSeconds;
}

/// <summary>
/// 录屏健康检查相关配置
/// </summary>
public class RecordingHealthConfig
{
    /// <summary>编码器心跳认为活跃的阈值（秒）</summary>
    public int EncoderAliveThresholdSeconds { get; set; } = 120;

    /// <summary>编码器心跳被认为失效的阈值（秒）</summary>
    public int EncoderStaleThresholdSeconds { get; set; } = 120;

    /// <summary>文件被认为“最近写入”的时间窗口（秒）</summary>
    public int FileRecentSeconds { get; set; } = 120;

    /// <summary>文件被认为活跃的时间窗口（秒）</summary>
    public int FileAliveThresholdSeconds { get; set; } = 120;

    /// <summary>录屏停滞判定时间（秒）</summary>
    public int StallTimeoutSeconds { get; set; } = Constants.RecordingStallTimeoutSeconds;

    /// <summary>stderr 读取超时（秒）</summary>
    public int StderrReadTimeoutSeconds { get; set; } = 90;

    /// <summary>stderr 连续超时次数阈值，达到后尝试 Kill 进程</summary>
    public int StderrTimeoutKillThreshold { get; set; } = 3;

    /// <summary>健康检查间隔（秒）</summary>
    public int HealthCheckIntervalSeconds { get; set; } = Constants.RecordingHealthCheckIntervalSeconds;
}


public class Policy
{
    [JsonPropertyName("version")]
    public int Version { get; set; }
    
    [JsonPropertyName("rules")]
    public List<PolicyRule> Rules { get; set; } = new();
    
    [JsonPropertyName("config")]
    public JsonElement Config { get; set; }
    
    [JsonPropertyName("signature")]
    public string Signature { get; set; } = "";
    
    /// <summary>
    /// 检查策略签名是否有效
    /// </summary>
    public bool HasValidSignature => !string.IsNullOrWhiteSpace(Signature);
}

public class PolicyRule
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = "";
    
    [JsonPropertyName("action")]
    public string Action { get; set; } = "";
    
    [JsonPropertyName("match")]
    public string Match { get; set; } = "";
}

// 扩展方法：从 Config 中提取配置
public static class PolicyExtensions
{
    // Models/Policy.cs - PolicyExtensions 类

    public static RecordingConfig GetRecordingConfig(this Policy policy)
    {
        var config = new RecordingConfig();
        if (policy.Config.TryGetProperty("recording", out var recording))
        {
            if (recording.TryGetProperty("enabled", out var enabled))
                config.Enabled = enabled.GetBoolean();
            if (recording.TryGetProperty("fps", out var fps))
                config.Fps = fps.GetInt32();
            if (recording.TryGetProperty("idleFps", out var idleFps))
                config.IdleFps = idleFps.GetInt32();
            if (recording.TryGetProperty("resolution", out var resolution))
                config.Resolution = resolution.GetString() ?? "1280x720";
            if (recording.TryGetProperty("sliceMinutes", out var sliceMinutes))
                config.SliceMinutes = sliceMinutes.GetInt32();
            if (recording.TryGetProperty("enableGpu", out var enableGpu))
                config.EnableGpu = enableGpu.GetBoolean();
            if (recording.TryGetProperty("quality", out var quality))
                config.Quality = quality.GetInt32();

            // ✅ 新增：编码器高级配置解析
            if (recording.TryGetProperty("encoderPriority", out var encoderPriority))
                config.EncoderPriority = encoderPriority.GetString() ?? config.EncoderPriority;
            if (recording.TryGetProperty("hardwareEncoderPreset", out var hardwarePreset))
                config.HardwareEncoderPreset = hardwarePreset.GetString() ?? config.HardwareEncoderPreset;
            if (recording.TryGetProperty("softwareEncoderPreset", out var softwarePreset))
                config.SoftwareEncoderPreset = softwarePreset.GetString() ?? config.SoftwareEncoderPreset;
            if (recording.TryGetProperty("allowEncoderFallback", out var allowFallback))
                config.AllowEncoderFallback = allowFallback.GetBoolean();
            if (recording.TryGetProperty("gpuEncoderRetryMinutes", out var retryMinutes))
                config.GpuEncoderRetryMinutes = retryMinutes.GetInt32();
            if (recording.TryGetProperty("enableNvenc32Align", out var enable32Align))
                config.EnableNvenc32Align = enable32Align.GetBoolean();
            if (recording.TryGetProperty("useNvencHq", out var useNvencHq))
                config.UseNvencHq = useNvencHq.GetBoolean();
            if (recording.TryGetProperty("enableEncoderPreCheck", out var enablePreCheck))
                config.EnableEncoderPreCheck = enablePreCheck.GetBoolean();
        }

        // 边界值修正
        config.Fps = Math.Clamp(config.Fps, 1, 60);
        config.IdleFps = Math.Clamp(config.IdleFps, 1, 30);
        config.SliceMinutes = Math.Max(config.SliceMinutes, 1);
        config.Quality = Math.Clamp(config.Quality, 1, 100);
        config.GpuEncoderRetryMinutes = Math.Max(config.GpuEncoderRetryMinutes, 5);

        return config;
    }
    public static ScreenshotConfig GetScreenshotConfig(this Policy policy)
    {
        var config = new ScreenshotConfig();
        if (policy.Config.TryGetProperty("screenshot", out var screenshot))
        {
            if (screenshot.TryGetProperty("enabled", out var enabled))
                config.Enabled = enabled.GetBoolean();
            if (screenshot.TryGetProperty("intervalSeconds", out var interval))
                config.IntervalSeconds = interval.GetInt32();
            if (screenshot.TryGetProperty("quality", out var quality))
                config.Quality = quality.GetInt32();
            if (screenshot.TryGetProperty("format", out var format))
                config.Format = format.GetString() ?? "webp";
            if (screenshot.TryGetProperty("resolution", out var resolution))
                config.Resolution = resolution.GetString() ?? "1920x1080";
        }
        
        // 边界值修正
        config.IntervalSeconds = Math.Max(config.IntervalSeconds, 5);
        config.Quality = Math.Clamp(config.Quality, 10, 100);
        
        return config;
    }
    
    public static UploadConfig GetUploadConfig(this Policy policy)
    {
        var config = new UploadConfig();
        if (policy.Config.TryGetProperty("upload", out var upload))
        {
            if (upload.TryGetProperty("enabled", out var enabled))
                config.Enabled = enabled.GetBoolean();
            if (upload.TryGetProperty("rateLimitKBps", out var rateLimit))
                config.RateLimitKBps = rateLimit.GetInt32();
            if (upload.TryGetProperty("maxConcurrent", out var maxConcurrent))
                config.MaxConcurrent = maxConcurrent.GetInt32();
            if (upload.TryGetProperty("chunkSizeKB", out var chunkSize))
                config.ChunkSizeKB = chunkSize.GetInt32();
        }
        
        // 边界值修正
        config.RateLimitKBps = Math.Max(config.RateLimitKBps, 64);
        config.MaxConcurrent = Math.Clamp(config.MaxConcurrent, 1, 10);
        config.ChunkSizeKB = Math.Clamp(config.ChunkSizeKB, 64, 4096);
        
        return config;
    }
    
    public static CleanupPolicy GetCleanupConfig(this Policy policy)
    {
        var config = CleanupPolicy.CreateDefault();
        if (policy.Config.TryGetProperty("cleanup", out var cleanup))
        {
            if (cleanup.TryGetProperty("enabled", out var enabled))
                config.Enabled = enabled.GetBoolean();
            if (cleanup.TryGetProperty("recordingDays", out var recordingDays))
                config.RecordingDays = recordingDays.GetInt32();
            if (cleanup.TryGetProperty("screenshotDays", out var screenshotDays))
                config.ScreenshotDays = screenshotDays.GetInt32();
            if (cleanup.TryGetProperty("logDays", out var logDays))
                config.LogDays = logDays.GetInt32();
            if (cleanup.TryGetProperty("diskThresholdPercent", out var threshold))
                config.DiskThresholdPercent = threshold.GetInt32();
        }
        
        // 边界值修正
        config.RecordingDays = Math.Clamp(config.RecordingDays, 1, 365);
        config.ScreenshotDays = Math.Clamp(config.ScreenshotDays, 1, 365);
        config.LogDays = Math.Clamp(config.LogDays, 1, 365);
        config.DiskThresholdPercent = Math.Clamp(config.DiskThresholdPercent, 50, 95);
        
        return config;
    }

    public class SecurityConfig
    {
        public bool EnableEncryption { get; set; } = true;

        public bool EnableVPN { get; set; } = false;
    }

    // 在 PolicyExtensions 类中添加
    public static SecurityConfig GetSecurityConfig(
        this Policy policy)
    {
        var config = new SecurityConfig();

        if (policy.Config.TryGetProperty(
            "security",
            out var security))
        {
            if (security.TryGetProperty(
                "enableEncryption",
                out var enableEncryption))
            {
                config.EnableEncryption =
                    enableEncryption.GetBoolean();
            }

            if (security.TryGetProperty(
                "enableVPN",
                out var enableVPN))
            {
                config.EnableVPN =
                    enableVPN.GetBoolean();
            }
        }

        return config;
    }
}

// Models/Policy.cs - 完整 RecordingConfig 类

public class RecordingConfig
{
    // ========== 基础配置 ==========
    public bool Enabled { get; set; } = true;
    public int Fps { get; set; } = Constants.DefaultRecordingFps;
    public int IdleFps { get; set; } = Constants.IdleRecordingFps;
    public string Resolution { get; set; } = "1280x720";
    public int SliceMinutes { get; set; } = 1;
    public bool EnableGpu { get; set; } = true;
    public int Quality { get; set; } = 60;
    
    // ========== 编码器高级配置 ==========
    
    /// <summary>
    /// 编码器优先级顺序（逗号分隔）
    /// 例如: "h264_nvenc,h264_qsv,h264_amf,libx264"
    /// </summary>
    public string EncoderPriority { get; set; } = "h264_nvenc,h264_qsv,h264_amf,libx264";
    
    /// <summary>
    /// 硬件编码器预设
    /// NVENC: p1(最快)~p7(最慢), QSV: veryfast/medium/slow, AMF: speed/quality
    /// </summary>
    public string HardwareEncoderPreset { get; set; } = "p4";
    
    /// <summary>
    /// 软件编码器预设 (ultrafast, veryfast, fast, medium, slow, slower)
    /// </summary>
    public string SoftwareEncoderPreset { get; set; } = "veryfast";
    
    /// <summary>
    /// 是否允许硬件编码器失败后降级到软件编码
    /// </summary>
    public bool AllowEncoderFallback { get; set; } = true;
    
    /// <summary>
    /// 硬件编码器失败后重试间隔（分钟）
    /// </summary>
    public int GpuEncoderRetryMinutes { get; set; } = 30;
    
    /// <summary>
    /// 是否启用 NVENC 32 对齐（某些旧显卡需要，默认 false）
    /// </summary>
    public bool EnableNvenc32Align { get; set; } = false;
    
    /// <summary>
    /// 是否使用 NVENC 高质量模式 (vbr_hq)，默认 false（使用 vbr 更稳定）
    /// </summary>
    public bool UseNvencHq { get; set; } = false;
    
    /// <summary>
    /// 是否启用编码器预检测（启动前测试编码器是否可用）
    /// </summary>
    public bool EnableEncoderPreCheck { get; set; } = true;
    
    // ========== 辅助方法 ==========
    
    /// <summary>
    /// 获取切片秒数
    /// </summary>
    public int GetSliceSeconds() => Math.Max(SliceMinutes * 60, Constants.MinSliceSeconds);
    
    /// <summary>
    /// 获取编码器优先级列表
    /// </summary>
    public List<string> GetEncoderPriorityList()
    {
        if (string.IsNullOrWhiteSpace(EncoderPriority))
            return new List<string> { "h264_nvenc", "h264_qsv", "h264_amf", "libx264" };
        
        return EncoderPriority.Split(',', StringSplitOptions.RemoveEmptyEntries)
            .Select(e => e.Trim().ToLowerInvariant())
            .ToList();
    }
}

public class ScreenshotConfig
{
    public bool Enabled { get; set; } = true;
    public int IntervalSeconds { get; set; } = Constants.DefaultScreenshotIntervalSeconds;
    public int Quality { get; set; } = Constants.DefaultScreenshotQuality;
    public string Format { get; set; } = "webp";
    public string Resolution { get; set; } = "1920x1080";
    
    /// <summary>
    /// 获取截图格式（小写）
    /// </summary>
    public string GetNormalizedFormat() => Format?.ToLowerInvariant() ?? "jpeg";
}

public class UploadConfig
{
    public bool Enabled { get; set; } = true;
    public int RateLimitKBps { get; set; } = Constants.DefaultRateLimitKBps;
    public int MaxConcurrent { get; set; } = Constants.DefaultMaxConcurrentUploads;
    public int ChunkSizeKB { get; set; } = Constants.DefaultChunkSizeKB;
    
    /// <summary>
    /// 获取分块大小（字节）
    /// </summary>
    public int GetChunkSizeBytes() => ChunkSizeKB * 1024;
    
    /// <summary>
    /// 获取限速（字节/秒）
    /// </summary>
    public int GetRateLimitBytesPerSecond() => RateLimitKBps * 1024;
}

public class CleanupPolicy
{
    public bool Enabled { get; set; } = true;
    public int RecordingDays { get; set; } = 7;
    public int ScreenshotDays { get; set; } = 15;
    public int LogDays { get; set; } = 7;
    public int DiskThresholdPercent { get; set; } = 80;

    public static CleanupPolicy CreateDefault() => new();
}

/// <summary>本地清理触发来源</summary>
public enum CleanupTrigger
{
    Scheduled,
    DiskThreshold,
    DiskCritical,
    RemoteTask,
    Manual
}

/// <summary>磁盘压力等级</summary>
public enum DiskPressureLevel
{
    Warning,
    Critical
}

/// <summary>本地清理执行结果</summary>
public class LocalCleanupResult
{
    public int DeletedRecordingFiles { get; set; }
    public int DeletedScreenshotFiles { get; set; }
    public int DeletedScreenshotRows { get; set; }
    public int DeletedActivityRows { get; set; }
    public int DeletedFailedUploadRows { get; set; }
    public int DeletedAgentLogFiles { get; set; }
    public int CompressedAgentLogFiles { get; set; }

    public void Merge(LocalCleanupResult other)
    {
        DeletedRecordingFiles += other.DeletedRecordingFiles;
        DeletedScreenshotFiles += other.DeletedScreenshotFiles;
        DeletedScreenshotRows += other.DeletedScreenshotRows;
        DeletedActivityRows += other.DeletedActivityRows;
        DeletedFailedUploadRows += other.DeletedFailedUploadRows;
        DeletedAgentLogFiles += other.DeletedAgentLogFiles;
        CompressedAgentLogFiles += other.CompressedAgentLogFiles;
    }
}
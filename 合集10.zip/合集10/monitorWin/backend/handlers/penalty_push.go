package handlers

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

func (h *AdminHandler) GetPenaltyPushSettings(c *gin.Context) {
	if h.penaltyPush == nil {
		models.SendError(c, 500, 5000, "penalty push service unavailable")
		return
	}
	settings, err := h.penaltyPush.GetSettings(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", settings)
}

func (h *AdminHandler) SavePenaltyPushToken(c *gin.Context) {
	if h.penaltyPush == nil {
		models.SendError(c, 500, 5000, "penalty push service unavailable")
		return
	}
	var req struct {
		BotToken string `json:"botToken"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	settings, err := h.penaltyPush.SaveBotToken(c.Request.Context(), req.BotToken)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "PENALTY", "保存罚款 Telegram 推送 Bot Token", "", settings.BotUsername)
	models.Send(c, 200, 0, "Token 已保存", settings)
}

func (h *AdminHandler) SavePenaltyPushEnabled(c *gin.Context) {
	if h.penaltyPush == nil {
		models.SendError(c, 500, 5000, "penalty push service unavailable")
		return
	}
	var req struct {
		Enabled bool `json:"enabled"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	settings, err := h.penaltyPush.SetPushEnabled(c.Request.Context(), req.Enabled)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	action := "关闭罚款 Telegram 自动推送"
	if req.Enabled {
		action = "开启罚款 Telegram 自动推送"
	}
	Log(c, "UPDATE", "PENALTY", action, "", fmt.Sprintf("enabled=%v", req.Enabled))
	models.Send(c, 200, 0, "已保存", settings)
}

func (h *AdminHandler) DiscoverPenaltyPushChats(c *gin.Context) {
	if h.penaltyPush == nil {
		models.SendError(c, 500, 5000, "penalty push service unavailable")
		return
	}
	groups, err := h.penaltyPush.DiscoverChats(c.Request.Context())
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", groups)
}

func (h *AdminHandler) BindPenaltyPushChat(c *gin.Context) {
	if h.penaltyPush == nil {
		models.SendError(c, 500, 5000, "penalty push service unavailable")
		return
	}
	var req struct {
		ChatID    string `json:"chatId" binding:"required"`
		ChatTitle string `json:"chatTitle"`
		ChatType  string `json:"chatType"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	settings, err := h.penaltyPush.BindChat(c.Request.Context(), req.ChatID, req.ChatTitle, req.ChatType)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "PENALTY",
		fmt.Sprintf("绑定罚款推送频道/群组：%s", settings.ChatTitle),
		settings.ChatID, settings.ChatTitle)
	models.Send(c, 200, 0, "绑定成功", settings)
}

func (h *AdminHandler) UnbindPenaltyPushChat(c *gin.Context) {
	if h.penaltyPush == nil {
		models.SendError(c, 500, 5000, "penalty push service unavailable")
		return
	}
	settings, err := h.penaltyPush.UnbindChat(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "PENALTY", "解绑罚款推送频道/群组", "", "")
	models.Send(c, 200, 0, "已解绑", settings)
}

func (h *AdminHandler) TestPenaltyPush(c *gin.Context) {
	if h.penaltyPush == nil {
		models.SendError(c, 500, 5000, "penalty push service unavailable")
		return
	}
	if err := h.penaltyPush.TestPush(c.Request.Context()); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "PENALTY", "测试罚款 Telegram 推送", "", "")
	models.Send(c, 200, 0, "测试消息已发送", nil)
}

func (h *AdminHandler) NotifyPenaltyPush(c *gin.Context) {
	if h.penaltyPush == nil {
		models.Send(c, 200, 0, "skipped", gin.H{"sent": false})
		return
	}
	var req services.PenaltyPushRecord
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	sent, err := h.penaltyPush.PushPenaltyRecord(c.Request.Context(), req)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if sent {
		Log(c, "CREATE", "PENALTY",
			fmt.Sprintf("推送罚款：%s %s %s（%s）",
				req.Date, req.EmployeeName,
				services.FormatFineMoney(req.Amount, h.penaltyPush.FineCurrencyCode(c.Request.Context())),
				req.Reason),
			req.EmployeeName, req.EmployeeName)
		if h.agentNotify != nil {
			h.agentNotify.PushPenalty(uuid.Nil, req.Amount, req.Category, req.Reason, req.Date, req.EmployeeName)
		}
	}
	models.Send(c, 200, 0, "success", gin.H{"sent": sent})
}

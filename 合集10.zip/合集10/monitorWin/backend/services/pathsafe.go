package services

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// ResolveUnderRoot joins root with a relative path and ensures the result
// stays inside root (blocks ".." / absolute escape). Returns absolute path.
func ResolveUnderRoot(root, relOrAbs string) (string, error) {
	root = strings.TrimSpace(root)
	if root == "" {
		return "", fmt.Errorf("root path is empty")
	}
	absRoot, err := filepath.Abs(root)
	if err != nil {
		return "", err
	}
	absRoot = filepath.Clean(absRoot)

	candidate := strings.TrimSpace(relOrAbs)
	if candidate == "" {
		return "", fmt.Errorf("path is empty")
	}
	candidate = filepath.ToSlash(candidate)
	candidate = strings.TrimPrefix(candidate, "/uploads/")
	candidate = strings.TrimPrefix(candidate, "uploads/")
	if strings.Contains(candidate, "..") {
		return "", fmt.Errorf("path traversal is not allowed")
	}
	if filepath.IsAbs(filepath.FromSlash(candidate)) {
		// Allow absolute only when already under root.
		absCand, err := filepath.Abs(filepath.FromSlash(candidate))
		if err != nil {
			return "", err
		}
		rel, err := filepath.Rel(absRoot, filepath.Clean(absCand))
		if err != nil || strings.HasPrefix(rel, "..") || rel == ".." {
			return "", fmt.Errorf("path escapes root")
		}
		return filepath.Clean(absCand), nil
	}

	joined := filepath.Join(absRoot, filepath.FromSlash(candidate))
	absJoined, err := filepath.Abs(joined)
	if err != nil {
		return "", err
	}
	absJoined = filepath.Clean(absJoined)
	rel, err := filepath.Rel(absRoot, absJoined)
	if err != nil || strings.HasPrefix(rel, "..") || rel == ".." {
		return "", fmt.Errorf("path escapes root")
	}
	return absJoined, nil
}

// EnsureDirUnderRoot creates dirPath only when it resolves under root.
func EnsureDirUnderRoot(root, rel string) (string, error) {
	abs, err := ResolveUnderRoot(root, rel)
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(abs, 0o755); err != nil {
		return "", err
	}
	return abs, nil
}

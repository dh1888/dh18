package services

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

// Security event types persisted when burst thresholds are crossed.
const (
	SecEventSignatureFailBurst = "signature_fail_burst"
	SecEventAuthFailBurst      = "auth_fail_burst"
	SecEventLoginIPDenied      = "login_ip_denied"
	SecEventUploadRateLimited  = "upload_rate_limited"
	SecEventDeviceRegistered   = "device_registered"
)

// SecuritySignal is a single security observation (not necessarily persisted).
type SecuritySignal struct {
	EventType   string
	SubjectType string // device | ip | user
	SubjectID   string
	IP          string
	Reason      string
	Details     map[string]interface{}
}

type SecurityMonitor struct {
	db     *sql.DB
	redis  *redis.Client
	alerts *AlertService

	enabled bool
	// Persist + alert when Redis counter reaches threshold within window.
	sigFailThreshold    int
	sigFailWindow       time.Duration
	authFailThreshold   int
	authFailWindow      time.Duration
	ipDeniedThreshold   int
	ipDeniedWindow      time.Duration
	uploadRLThreshold   int
	uploadRLWindow      time.Duration
	alertCooldown       time.Duration
}

var GlobalSecurityMonitor *SecurityMonitor

func InitSecurityMonitor(db *sql.DB, redisClient *redis.Client, alerts *AlertService) *SecurityMonitor {
	enabled := true
	if v := strings.TrimSpace(os.Getenv("SECURITY_EVENTS_ENABLED")); v != "" {
		enabled = strings.EqualFold(v, "true") || v == "1"
	}

	m := &SecurityMonitor{
		db:                db,
		redis:             redisClient,
		alerts:            alerts,
		enabled:           enabled,
		sigFailThreshold:  envIntDefaultMin("SECURITY_SIG_FAIL_THRESHOLD", 15, 3),
		sigFailWindow:     time.Duration(envIntDefaultMin("SECURITY_SIG_FAIL_WINDOW_SEC", 300, 60)) * time.Second,
		authFailThreshold: envIntDefaultMin("SECURITY_AUTH_FAIL_THRESHOLD", 8, 3),
		authFailWindow:    time.Duration(envIntDefaultMin("SECURITY_AUTH_FAIL_WINDOW_SEC", 900, 60)) * time.Second,
		ipDeniedThreshold: envIntDefaultMin("SECURITY_LOGIN_IP_DENIED_THRESHOLD", 5, 1),
		ipDeniedWindow:    time.Duration(envIntDefaultMin("SECURITY_LOGIN_IP_DENIED_WINDOW_SEC", 3600, 60)) * time.Second,
		uploadRLThreshold: envIntDefaultMin("SECURITY_UPLOAD_RL_THRESHOLD", 20, 3),
		uploadRLWindow:    time.Duration(envIntDefaultMin("SECURITY_UPLOAD_RL_WINDOW_SEC", 600, 60)) * time.Second,
		alertCooldown:     time.Duration(envIntDefaultMin("SECURITY_ALERT_COOLDOWN_MINUTES", 30, 5)) * time.Minute,
	}
	GlobalSecurityMonitor = m
	if enabled {
		log.Printf("[Security] events enabled (sigFail=%d/%v authFail=%d/%v)",
			m.sigFailThreshold, m.sigFailWindow, m.authFailThreshold, m.authFailWindow)
	} else {
		log.Println("[Security] events disabled (SECURITY_EVENTS_ENABLED=false)")
	}
	return m
}

// Observe records a security signal asynchronously. Never blocks callers; failures are logged only.
func ObserveSecurity(signal SecuritySignal) {
	m := GlobalSecurityMonitor
	if m == nil || !m.enabled {
		return
	}
	go m.observe(signal)
}

// RecordSecurityEventImmediately persists a single security event (no burst gating) and may alert.
func RecordSecurityEventImmediately(signal SecuritySignal) {
	m := GlobalSecurityMonitor
	if m == nil || !m.enabled {
		return
	}
	go func() {
		defer func() {
			if r := recover(); r != nil {
				log.Printf("[Security] panic in RecordSecurityEventImmediately: %v", r)
			}
		}()
		eventType := strings.TrimSpace(signal.EventType)
		if eventType == "" {
			return
		}
		subjectType := strings.TrimSpace(signal.SubjectType)
		subjectID := strings.TrimSpace(signal.SubjectID)
		if subjectID == "" {
			subjectID = strings.TrimSpace(signal.IP)
			if subjectType == "" {
				subjectType = "ip"
			}
		}
		if subjectID == "" {
			subjectID = "unknown"
		}
		if subjectType == "" {
			subjectType = "unknown"
		}
		details := cloneDetails(signal.Details)
		if details == nil {
			details = map[string]interface{}{}
		}
		if signal.IP != "" {
			details["ip"] = signal.IP
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err := m.insertEvent(ctx, eventType, subjectType, subjectID, signal.IP, signal.Reason, 1, details); err != nil {
			log.Printf("[Security] insert immediate event failed: %v", err)
		}
		m.maybeAlert(ctx, eventType, subjectType, subjectID, signal.IP, signal.Reason, 1, details)
	}()
}

func (m *SecurityMonitor) observe(signal SecuritySignal) {
	defer func() {
		if r := recover(); r != nil {
			log.Printf("[Security] panic in observe: %v", r)
		}
	}()

	eventType := strings.TrimSpace(signal.EventType)
	if eventType == "" {
		return
	}
	subjectType := strings.TrimSpace(signal.SubjectType)
	subjectID := strings.TrimSpace(signal.SubjectID)
	if subjectID == "" {
		subjectID = strings.TrimSpace(signal.IP)
		if subjectType == "" {
			subjectType = "ip"
		}
	}
	if subjectID == "" {
		subjectID = "unknown"
	}
	if subjectType == "" {
		subjectType = "unknown"
	}

	threshold, window, burstType := m.burstConfig(eventType)
	if threshold <= 0 {
		return
	}

	count, err := m.incrBurst(burstType, subjectType, subjectID, window)
	if err != nil {
		log.Printf("[Security] burst counter failed type=%s subject=%s: %v", burstType, subjectID, err)
		// Still try a best-effort single persist without alert spam.
		_ = m.insertEvent(context.Background(), burstType, subjectType, subjectID, signal.IP, signal.Reason, 1, signal.Details)
		return
	}

	// Fire on first threshold hit and every subsequent multiple (e.g. 15, 30, 45…).
	if count < int64(threshold) || count%int64(threshold) != 0 {
		return
	}

	details := cloneDetails(signal.Details)
	if details == nil {
		details = map[string]interface{}{}
	}
	details["burstCount"] = count
	details["windowSec"] = int(window.Seconds())
	details["reason"] = signal.Reason
	if signal.IP != "" {
		details["ip"] = signal.IP
	}
	details["subjectKey"] = subjectType + ":" + subjectID

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := m.insertEvent(ctx, burstType, subjectType, subjectID, signal.IP, signal.Reason, int(count), details); err != nil {
		log.Printf("[Security] insert event failed: %v", err)
	}

	m.maybeAlert(ctx, burstType, subjectType, subjectID, signal.IP, signal.Reason, int(count), details)
}

func (m *SecurityMonitor) burstConfig(eventType string) (threshold int, window time.Duration, burstType string) {
	switch eventType {
	case "signature_fail", SecEventSignatureFailBurst:
		return m.sigFailThreshold, m.sigFailWindow, SecEventSignatureFailBurst
	case "auth_fail", SecEventAuthFailBurst:
		return m.authFailThreshold, m.authFailWindow, SecEventAuthFailBurst
	case SecEventLoginIPDenied:
		return m.ipDeniedThreshold, m.ipDeniedWindow, SecEventLoginIPDenied
	case SecEventUploadRateLimited:
		return m.uploadRLThreshold, m.uploadRLWindow, SecEventUploadRateLimited
	default:
		return 0, 0, eventType
	}
}

func (m *SecurityMonitor) incrBurst(burstType, subjectType, subjectID string, window time.Duration) (int64, error) {
	if m.redis == nil {
		return 0, fmt.Errorf("redis unavailable")
	}
	key := fmt.Sprintf("sec:burst:%s:%s:%s", burstType, subjectType, subjectID)
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	count, err := m.redis.Incr(ctx, key).Result()
	if err != nil {
		return 0, err
	}
	if count == 1 {
		_ = m.redis.Expire(ctx, key, window).Err()
	}
	return count, nil
}

func (m *SecurityMonitor) insertEvent(
	ctx context.Context,
	eventType, subjectType, subjectID, ip, reason string,
	count int,
	details map[string]interface{},
) error {
	if m.db == nil {
		return fmt.Errorf("db unavailable")
	}
	var payload []byte
	if details != nil {
		payload, _ = json.Marshal(details)
	}
	if payload == nil {
		payload = []byte("{}")
	}
	_, err := m.db.ExecContext(ctx, `
		INSERT INTO security_events (
			event_type, subject_type, subject_id, ip_address, reason, event_count, details
		) VALUES ($1, $2, $3, NULLIF($4, ''), NULLIF($5, ''), $6, $7::jsonb)
	`, eventType, subjectType, subjectID, ip, reason, count, string(payload))
	return err
}

func (m *SecurityMonitor) maybeAlert(
	ctx context.Context,
	eventType, subjectType, subjectID, ip, reason string,
	count int,
	details map[string]interface{},
) {
	if m.alerts == nil || !m.alerts.Enabled() {
		return
	}
	if m.redis != nil {
		coolKey := fmt.Sprintf("sec:alert:%s:%s:%s", eventType, subjectType, subjectID)
		ok, err := m.redis.SetNX(ctx, coolKey, "1", m.alertCooldown).Result()
		if err == nil && !ok {
			return
		}
	}

	title := "安全事件：" + eventType
	message := fmt.Sprintf("%s/%s 在窗口内累计 %d 次（%s）", subjectType, subjectID, count, reason)
	if ip != "" {
		message += " IP=" + ip
	}
	m.alerts.Notify(ctx, AlertEvent{
		Type:     "security_" + eventType,
		Severity: "warning",
		Title:    title,
		Message:  message,
		Details:  details,
	})
}

func cloneDetails(in map[string]interface{}) map[string]interface{} {
	if in == nil {
		return nil
	}
	out := make(map[string]interface{}, len(in))
	for k, v := range in {
		out[k] = v
	}
	return out
}

func envIntDefaultMin(key string, def, min int) int {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		if def < min {
			return min
		}
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return def
	}
	if n < min {
		return min
	}
	return n
}

// ListRecentSecurityEvents returns newest security events for admin API.
func (m *SecurityMonitor) ListRecentSecurityEvents(ctx context.Context, limit int) ([]map[string]interface{}, error) {
	if m == nil || m.db == nil {
		return nil, fmt.Errorf("security monitor unavailable")
	}
	if limit <= 0 || limit > 200 {
		limit = 50
	}
	rows, err := m.db.QueryContext(ctx, `
		SELECT id::text, event_type, subject_type, subject_id, COALESCE(ip_address, ''),
		       COALESCE(reason, ''), event_count, COALESCE(details::text, '{}'), created_at
		FROM security_events
		ORDER BY created_at DESC
		LIMIT $1
	`, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	out := make([]map[string]interface{}, 0, limit)
	for rows.Next() {
		var (
			id, et, st, sid, ip, reason, details string
			count                                int
			created                              time.Time
		)
		if err := rows.Scan(&id, &et, &st, &sid, &ip, &reason, &count, &details, &created); err != nil {
			return nil, err
		}
		out = append(out, map[string]interface{}{
			"id":          id,
			"eventType":   et,
			"subjectType": st,
			"subjectId":   sid,
			"ipAddress":   ip,
			"reason":      reason,
			"eventCount":  count,
			"details":     json.RawMessage(details),
			"createdAt":   created.UTC().Format(time.RFC3339),
		})
	}
	return out, rows.Err()
}

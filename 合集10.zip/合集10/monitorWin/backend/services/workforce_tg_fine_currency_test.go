package services

import "testing"

func TestNormalizeFineCurrency(t *testing.T) {
	cases := map[string]string{
		"":      "CNY",
		"cny":   "CNY",
		"元":     "CNY",
		"THB":   "THB",
		"฿":     "THB",
		"usd":   "USD",
		"weird": "CNY",
	}
	for in, want := range cases {
		if got := NormalizeFineCurrency(in); got != want {
			t.Fatalf("NormalizeFineCurrency(%q)=%q want %q", in, got, want)
		}
	}
}

func TestFineCurrencyDisplay(t *testing.T) {
	if FineCurrencySymbol("CNY") != "¥" || FineCurrencyUnit("CNY") != "元" {
		t.Fatal("CNY display mismatch")
	}
	if FineCurrencySymbol("THB") != "฿" || FineCurrencyUnit("THB") != "泰铢" {
		t.Fatal("THB display mismatch")
	}
	if FormatFineMoney(10, "CNY") != "¥10.00" {
		t.Fatalf("FormatFineMoney = %q", FormatFineMoney(10, "CNY"))
	}
	if FormatFineAmountWithUnit(10, "THB") != "10 泰铢" {
		t.Fatalf("FormatFineAmountWithUnit = %q", FormatFineAmountWithUnit(10, "THB"))
	}
}

// UI/AccountAvatarGallery.cs — fixed avatar gallery (custom files or built-in styles)
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Security.Cryptography;
using System.Text;

namespace EnterpriseAgent.Agent.UI;

/// <summary>
/// Avatar gallery for quick account select. Prefer PNG/JPG files under
/// <c>Resources/Avatars/</c> (next to the exe); otherwise use 8 built-in styles.
/// Same username always maps to the same image. Display-only.
/// </summary>
internal static class AccountAvatarGallery
{
    public const int ImageSize = 96;
    private const int BuiltInStyleCount = 8;

    private static readonly object Gate = new();
    private static Image[]? _styles;
    private static bool _usesCustomImages;

    private static readonly (Color Top, Color Bottom, Color Accent)[] Palettes =
    [
        (Color.FromArgb(96, 165, 250), Color.FromArgb(37, 99, 235), Color.FromArgb(219, 234, 254)),
        (Color.FromArgb(110, 231, 183), Color.FromArgb(5, 150, 105), Color.FromArgb(209, 250, 229)),
        (Color.FromArgb(167, 139, 250), Color.FromArgb(91, 33, 182), Color.FromArgb(237, 233, 254)),
        (Color.FromArgb(252, 165, 165), Color.FromArgb(220, 38, 38), Color.FromArgb(254, 226, 226)),
        (Color.FromArgb(253, 186, 116), Color.FromArgb(217, 119, 6), Color.FromArgb(255, 237, 213)),
        (Color.FromArgb(125, 211, 252), Color.FromArgb(2, 132, 199), Color.FromArgb(224, 242, 254)),
        (Color.FromArgb(148, 163, 184), Color.FromArgb(51, 65, 85), Color.FromArgb(226, 232, 240)),
        (Color.FromArgb(249, 168, 212), Color.FromArgb(190, 24, 93), Color.FromArgb(252, 231, 243)),
    ];

    public static int StyleCount
    {
        get
        {
            EnsureStyles();
            return _styles!.Length;
        }
    }

    /// <summary>True when avatars were loaded from Resources/Avatars (skip letter overlay).</summary>
    public static bool UsesCustomImages
    {
        get
        {
            EnsureStyles();
            return _usesCustomImages;
        }
    }

    public static int GetStyleIndex(string username)
    {
        EnsureStyles();
        var count = _styles!.Length;
        if (count <= 0)
            return 0;

        var key = (username ?? string.Empty).Trim().ToLowerInvariant();
        if (key.Length == 0)
            return 0;

        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(key));
        var value = BitConverter.ToUInt32(hash, 0);
        return (int)(value % (uint)count);
    }

    public static Image GetStyleImage(int index)
    {
        EnsureStyles();
        var count = _styles!.Length;
        var i = ((index % count) + count) % count;
        return _styles[i];
    }

    public static Image GetAvatar(string username) => GetStyleImage(GetStyleIndex(username));

    public static string GetInitial(string username)
    {
        var text = (username ?? string.Empty).Trim();
        if (text.Length == 0)
            return "?";

        var ch = text[0];
        if (char.IsLetter(ch))
            return char.ToUpperInvariant(ch).ToString();
        return text[..1];
    }

    private static void EnsureStyles()
    {
        if (_styles != null)
            return;

        lock (Gate)
        {
            if (_styles != null)
                return;

            var custom = TryLoadCustomAvatars();
            if (custom is { Length: > 0 })
            {
                _styles = custom;
                _usesCustomImages = true;
                return;
            }

            _usesCustomImages = false;
            _styles = new Image[BuiltInStyleCount];
            for (var i = 0; i < BuiltInStyleCount; i++)
                _styles[i] = CreateStyle(i);
        }
    }

    private static Image[]? TryLoadCustomAvatars()
    {
        try
        {
            var dir = Path.Combine(AppContext.BaseDirectory, "Resources", "Avatars");
            if (!Directory.Exists(dir))
                return null;

            var files = Directory.EnumerateFiles(dir)
                .Where(f =>
                {
                    var ext = Path.GetExtension(f);
                    return ext.Equals(".png", StringComparison.OrdinalIgnoreCase)
                        || ext.Equals(".jpg", StringComparison.OrdinalIgnoreCase)
                        || ext.Equals(".jpeg", StringComparison.OrdinalIgnoreCase)
                        || ext.Equals(".webp", StringComparison.OrdinalIgnoreCase)
                        || ext.Equals(".bmp", StringComparison.OrdinalIgnoreCase);
                })
                .OrderBy(f => f, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            if (files.Length == 0)
                return null;

            var images = new List<Image>(files.Length);
            foreach (var file in files)
            {
                try
                {
                    // Clone so file handles are not locked.
                    using var loaded = Image.FromFile(file);
                    images.Add(new Bitmap(loaded));
                }
                catch
                {
                    /* skip unreadable files */
                }
            }

            return images.Count > 0 ? images.ToArray() : null;
        }
        catch
        {
            return null;
        }
    }

    private static Image CreateStyle(int index)
    {
        var (top, bottom, accent) = Palettes[index];
        var bmp = new Bitmap(ImageSize, ImageSize, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(bmp);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.Clear(Color.Transparent);

        var bounds = new Rectangle(2, 2, ImageSize - 5, ImageSize - 5);
        using (var path = LoginUiChrome.CreateRoundedPath(bounds, ImageSize / 2))
        using (var brush = new LinearGradientBrush(bounds, top, bottom, 90f))
        {
            g.FillPath(brush, path);
        }

        using (var highlight = new SolidBrush(Color.FromArgb(55, Color.White)))
        {
            g.FillEllipse(highlight, 18, 12, 42, 28);
        }

        using (var motif = new SolidBrush(Color.FromArgb(70, accent)))
        {
            switch (index % 4)
            {
                case 0:
                    g.FillEllipse(motif, 52, 48, 28, 28);
                    break;
                case 1:
                    g.FillRectangle(motif, 48, 50, 26, 26);
                    break;
                case 2:
                    using (var tri = new GraphicsPath())
                    {
                        tri.AddPolygon(new[]
                        {
                            new Point(64, 46),
                            new Point(82, 78),
                            new Point(46, 78)
                        });
                        g.FillPath(motif, tri);
                    }
                    break;
                default:
                    g.FillEllipse(motif, 44, 54, 36, 18);
                    break;
            }
        }

        using (var ring = new Pen(Color.FromArgb(40, Color.White), 2.5f))
        {
            g.DrawEllipse(ring, bounds);
        }

        return bmp;
    }
}

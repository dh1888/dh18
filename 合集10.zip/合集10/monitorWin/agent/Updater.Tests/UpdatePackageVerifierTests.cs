using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Signers;
using Xunit;

namespace EnterpriseAgent.Updater.Tests;

public class UpdatePackageVerifierTests
{
    [Fact]
    public void AcceptsValidSignature()
    {
        var (pubB64, sha, sig) = GenerateLocalVector();
        var keys = new Dictionary<string, string> { ["2026-test"] = pubB64 };
        Assert.True(UpdatePackageVerifier.TryVerify(sha, sig, "2026-test", keys, out var err), err);
    }

    [Fact]
    public void RejectsTamperedHashKeepingOriginalSignature()
    {
        var (pubB64, sha, sig) = GenerateLocalVector();
        var keys = new Dictionary<string, string> { ["2026-test"] = pubB64 };
        Assert.True(UpdatePackageVerifier.TryVerify(sha, sig, "2026-test", keys, out _));

        var tampered = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
        Assert.False(UpdatePackageVerifier.TryVerify(tampered, sig, "2026-test", keys, out var err));
        Assert.Contains("failed", err ?? "", StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void RejectsForeignSelfSignedSignature()
    {
        var (pubA, sha, _) = GenerateLocalVector();
        var (_, _, sigB) = GenerateLocalVector(seedByte: 2);
        var keys = new Dictionary<string, string> { ["2026-test"] = pubA };
        Assert.False(UpdatePackageVerifier.TryVerify(sha, sigB, "2026-test", keys, out _));
    }

    [Fact]
    public void RejectsSha256ChangedWithStaleSignature_ServerCompromiseScenario()
    {
        var (pubB64, originalSha, originalSig) = GenerateLocalVector();
        var keys = new Dictionary<string, string> { ["2026-test"] = pubB64 };
        var attackerSha = "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
        Assert.False(UpdatePackageVerifier.TryVerify(attackerSha, originalSig, "2026-test", keys, out _));
        Assert.True(UpdatePackageVerifier.TryVerify(originalSha, originalSig, "2026-test", keys, out _));
    }

    /// <summary>
    /// Core isolation test: signature made with the policy private key must NOT
    /// verify under a dedicated updatePublicKey.
    /// </summary>
    [Fact]
    public void RejectsSignatureMadeWithPolicyKeyWhenUpdatePublicKeyDiffers()
    {
        var (policyPub, sha, policySig) = GenerateLocalVector(seedByte: 1);
        var (updatePub, _, _) = GenerateLocalVector(seedByte: 9);
        Assert.NotEqual(policyPub, updatePub);

        var updateKeysOnly = new Dictionary<string, string> { ["2026-update"] = updatePub };
        Assert.False(
            UpdatePackageVerifier.TryVerify(sha, policySig, "2026-update", updateKeysOnly, out var err),
            "policy-key signature must fail under dedicated update public key");
        Assert.Contains("failed", err ?? "", StringComparison.OrdinalIgnoreCase);

        // Positive control: same hash signed by the update private key succeeds.
        var (_, _, updateSig) = SignExistingSha(sha, seedByte: 9);
        Assert.True(UpdatePackageVerifier.TryVerify(sha, updateSig, "2026-update", updateKeysOnly, out var okErr), okErr);
    }

    [Fact]
    public void LoadPublicKeys_RequiresUpdatePublicKeys_NoPolicyFallback()
    {
        var dir = Path.Combine(Path.GetTempPath(), "updater-keys-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        try
        {
            File.WriteAllText(Path.Combine(dir, "deployment.json"), """
                {
                  "policyPublicKeys": { "2026-07": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" },
                  "serverUrl": "https://example.test"
                }
                """);
            var keys = UpdatePackageVerifier.LoadPublicKeys(dir);
            Assert.Empty(keys);
        }
        finally
        {
            try { Directory.Delete(dir, true); } catch { /* ignore */ }
        }
    }

    [Fact]
    public void LoadPublicKeys_ReadsUpdatePublicKeysOnly()
    {
        var dir = Path.Combine(Path.GetTempPath(), "updater-keys-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        try
        {
            File.WriteAllText(Path.Combine(dir, "deployment.json"), """
                {
                  "policyPublicKeys": { "2026-07": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" },
                  "updatePublicKeys": { "2026-07": "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=" },
                  "serverUrl": "https://example.test"
                }
                """);
            var keys = UpdatePackageVerifier.LoadPublicKeys(dir);
            Assert.Single(keys);
            Assert.Equal("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=", keys["2026-07"]);
        }
        finally
        {
            try { Directory.Delete(dir, true); } catch { /* ignore */ }
        }
    }

    private static (string pubB64, string sha, string sigB64) GenerateLocalVector(byte seedByte = 1)
    {
        var seed = new byte[32];
        seed[^1] = seedByte;
        var privateKey = new Ed25519PrivateKeyParameters(seed, 0);
        var publicKey = privateKey.GeneratePublicKey().GetEncoded();
        var sha = seedByte == 1
            ? "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
            : seedByte == 9
                ? "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
                : "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc";
        var msg = UpdatePackageVerifier.BuildSignMessage(sha);
        var signer = new Ed25519Signer();
        signer.Init(true, privateKey);
        signer.BlockUpdate(msg, 0, msg.Length);
        var sig = signer.GenerateSignature();
        return (Convert.ToBase64String(publicKey), sha, Convert.ToBase64String(sig));
    }

    private static (string pubB64, string sha, string sigB64) SignExistingSha(string sha, byte seedByte)
    {
        var seed = new byte[32];
        seed[^1] = seedByte;
        var privateKey = new Ed25519PrivateKeyParameters(seed, 0);
        var publicKey = privateKey.GeneratePublicKey().GetEncoded();
        var msg = UpdatePackageVerifier.BuildSignMessage(sha);
        var signer = new Ed25519Signer();
        signer.Init(true, privateKey);
        signer.BlockUpdate(msg, 0, msg.Length);
        var sig = signer.GenerateSignature();
        return (Convert.ToBase64String(publicKey), sha, Convert.ToBase64String(sig));
    }
}

using EnterpriseAgent.Agent.RecordingServices;
using Xunit;

namespace EnterpriseAgent.Agent.RecordingServices.Tests;

public sealed class RecordingDateDirectoryPolicyTests
{
    [Fact]
    public void ShouldPreservePattern_True_WhenSameLocalDate()
    {
        var today = new DateTime(2026, 8, 4);
        Assert.True(RecordingDateDirectoryPolicy.ShouldPreservePattern(
            orchestratorOwned: true,
            pattern: @"C:\data\recordings\2026-08-04\2026-08-04_10-00-00_%03d.mp4",
            patternDate: today,
            todayLocal: today));
    }

    [Fact]
    public void ShouldPreservePattern_False_WhenDateCrossedMidnight()
    {
        var patternDate = new DateTime(2026, 8, 3);
        var today = new DateTime(2026, 8, 4);
        Assert.False(RecordingDateDirectoryPolicy.ShouldPreservePattern(
            orchestratorOwned: true,
            pattern: @"C:\data\recordings\2026-08-03\2026-08-03_23-50-00_%03d.mp4",
            patternDate: patternDate,
            todayLocal: today));
    }

    [Fact]
    public void ShouldPreservePattern_False_WhenPatternDateMissing()
    {
        Assert.False(RecordingDateDirectoryPolicy.ShouldPreservePattern(
            orchestratorOwned: true,
            pattern: @"C:\data\recordings\2026-08-04\x_%03d.mp4",
            patternDate: null,
            todayLocal: new DateTime(2026, 8, 4)));
    }

    [Fact]
    public void NeedsRollover_True_WhenRunningAcrossLocalMidnight()
    {
        Assert.True(RecordingDateDirectoryPolicy.NeedsRollover(
            isRunning: true,
            workSessionActive: true,
            pattern: @"C:\data\recordings\2026-08-03\2026-08-03_23-50-00_%03d.mp4",
            patternDate: new DateTime(2026, 8, 3),
            todayLocal: new DateTime(2026, 8, 4)));
    }

    [Fact]
    public void NeedsRollover_False_WhenNotRunning()
    {
        Assert.False(RecordingDateDirectoryPolicy.NeedsRollover(
            isRunning: false,
            workSessionActive: true,
            pattern: @"C:\data\recordings\2026-08-03\x_%03d.mp4",
            patternDate: new DateTime(2026, 8, 3),
            todayLocal: new DateTime(2026, 8, 4)));
    }

    [Fact]
    public void NeedsRollover_False_WhenSameDay()
    {
        var day = new DateTime(2026, 8, 4);
        Assert.False(RecordingDateDirectoryPolicy.NeedsRollover(
            isRunning: true,
            workSessionActive: true,
            pattern: @"C:\data\recordings\2026-08-04\x_%03d.mp4",
            patternDate: day,
            todayLocal: day));
    }

    [Theory]
    [InlineData(@"C:\agent\recordings\2026-08-03\2026-08-03_12-00-00_%03d.mp4", 2026, 8, 3)]
    [InlineData(@"D:/data/recordings/2026-12-31/2026-12-31_23-59-59_%03d.mp4", 2026, 12, 31)]
    public void TryParseLocalDateFromPattern_ReadsDateFolder(string pattern, int y, int m, int d)
    {
        var parsed = RecordingDateDirectoryPolicy.TryParseLocalDateFromPattern(pattern);
        Assert.Equal(new DateTime(y, m, d), parsed);
    }

    [Fact]
    public void TryParseLocalDateFromPattern_ReturnsNull_ForBadPath()
    {
        Assert.Null(RecordingDateDirectoryPolicy.TryParseLocalDateFromPattern(@"C:\agent\recordings\not-a-date\file.mp4"));
        Assert.Null(RecordingDateDirectoryPolicy.TryParseLocalDateFromPattern(null));
    }
}

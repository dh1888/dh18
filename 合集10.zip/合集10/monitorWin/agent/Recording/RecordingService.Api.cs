using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Lifecycle;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Recorder;
using Microsoft.Extensions.Logging;

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.RecordingServices;

public sealed partial class RecordingService : IRecordingService
{
    bool IRecordingService.IsRunning => IsProcessAlive();

    bool IRecordingService.WorkSessionActive => _workSessionActive;

    string? IRecordingService.OutputPattern => _persistedOutputPattern;

    public void SetWorkSessionActive(bool active) => _workSessionActive = active;

    public void UpdatePolicy(AgentPolicy policy)
    {
        _currentPolicy = policy;
        NotifyPolicyForCapture(policy);

        var recordingConfig = policy.GetRecordingConfig();
        if (!recordingConfig.EnableGpu)
        {
            _forceSoftwareEncoder = false;
            _encoderFailureCount = 0;
            _logger.LogDebug("GPU encoding disabled in policy, resetting encoder force flag");
        }

        if (recordingConfig.EnableGpu && _forceSoftwareEncoder)
        {
            var timeSinceFallback = DateTime.UtcNow - _lastEncoderSwitchTime;
            if (timeSinceFallback > TimeSpan.FromMinutes(30))
            {
                _logger.LogInformation("Retrying hardware encoder after 30 minutes cooldown");
                _forceSoftwareEncoder = false;
                _encoderFailureCount = 0;
                _encoderCacheTime = DateTime.MinValue;
            }
        }
    }

    Task<bool> IRecordingService.TryStartAsync(CancellationToken cancellationToken) =>
        StartRecordingAsync(orchestratorOwned: true);

    async Task IRecordingService.WaitUntilQuiescentAsync(CancellationToken cancellationToken)
    {
        if (await WaitUntilQuiescentInternalAsync(cancellationToken))
            return;

        _logger.LogWarning("Timed out waiting for recording process quiescence; forcing cleanup");
        await ForceQuiescenceInternalAsync(cancellationToken);
    }

    private async Task<bool> WaitUntilQuiescentInternalAsync(CancellationToken cancellationToken)
    {
        // SharedBridge enter stops gdigrab while holding the lock (stderr drain). Block briefly
        // instead of polling with TryWait — the old 3s poll window false-failed too often.
        if (!await _processLock.WaitAsync(TimeSpan.FromSeconds(8), cancellationToken))
            return false;

        try
        {
            return !IsProcessAlive();
        }
        finally
        {
            _processLock.Release();
        }
    }

    private async Task ForceQuiescenceInternalAsync(CancellationToken cancellationToken)
    {
        if (!await _processLock.WaitAsync(TimeSpan.FromSeconds(8), cancellationToken))
        {
            // Do NOT blast-kill every agent ffmpeg here: that also kills SharedBridge producer
            // and remote-view publishers, which cascades into "no live consumer pipes" + tray stuck.
            _logger.LogWarning(
                "Force quiescence: could not acquire process lock; leaving remote/bridge ffmpeg alone");
            _isStopping = false;
            Volatile.Write(ref _intentionalProcessStop, 0);
            return;
        }

        try
        {
            await CleanupProcessAsync(forRemoteRestart: true);
        }
        finally
        {
            _isStopping = false;
            Volatile.Write(ref _intentionalProcessStop, 0);
            _processLock.Release();
        }
    }

    Task IRecordingService.StopAsync(bool fullShutdown, bool fastTransition, CancellationToken cancellationToken) =>
        StopRecordingAsync(fullShutdown, fastTransition);

    Task<bool> IRecordingService.RestoreGdigrabCaptureAsync(CancellationToken cancellationToken) =>
        RestoreGdigrabCaptureAsync(cancellationToken);

    public Task RestartAsync(string reason, CancellationToken cancellationToken = default)
    {
        if (reason.Contains("Retry encoder", StringComparison.OrdinalIgnoreCase))
            ApplyEncoderRetryFlags();

        var bucket = reason.Contains("Retry encoder", StringComparison.OrdinalIgnoreCase)
            ? RestartPolicyBucket.EncoderRetry
            : reason.Contains("Policy", StringComparison.OrdinalIgnoreCase) ||
              reason.Contains("System resume", StringComparison.OrdinalIgnoreCase)
                ? RestartPolicyBucket.UserInitiated
                : RestartPolicyBucket.LifecycleTransition;

        return RelaunchCaptureAsync(reason, bucket, cancellationToken);
    }

    Task<bool> IRecordingService.RecoverForHealthAsync(string reason, CancellationToken cancellationToken) =>
        RelaunchCaptureAsync(reason, RestartPolicyBucket.HealthRecovery, cancellationToken);

    public void RestoreOutputPattern(string? pattern)
    {
        if (string.IsNullOrWhiteSpace(pattern))
            return;

        _persistedOutputPattern = pattern;
        _persistedPatternDate = RecordingDateDirectoryPolicy.TryParseLocalDateFromPattern(pattern)
                                ?? DateTime.Now.Date;
        _logger.LogDebug(
            "Restored output pattern date={PatternDate:yyyy-MM-dd} pattern={Pattern}",
            _persistedPatternDate,
            _persistedOutputPattern);
    }

    public async Task<bool> TryRolloverDateDirectoryIfNeededAsync(CancellationToken cancellationToken = default)
    {
        // Hydrate date from path after upgrade / RestoreOutputPattern edge cases.
        if (!_persistedPatternDate.HasValue && !string.IsNullOrWhiteSpace(_persistedOutputPattern))
            _persistedPatternDate = RecordingDateDirectoryPolicy.TryParseLocalDateFromPattern(_persistedOutputPattern);

        var todayLocal = DateTime.Now.Date;
        if (!RecordingDateDirectoryPolicy.NeedsRollover(
                IsProcessAlive(),
                _workSessionActive,
                _persistedOutputPattern,
                _persistedPatternDate,
                todayLocal))
        {
            return false;
        }

        // Bound retries when relaunch is throttled / fails (pattern date still old).
        if (DateTime.UtcNow - _lastDateRolloverAttemptUtc < TimeSpan.FromMinutes(1))
        {
            _logger.LogDebug(
                "Date directory rollover deferred (retry cooldown): patternDate={PatternDate:yyyy-MM-dd} today={Today:yyyy-MM-dd}",
                _persistedPatternDate,
                todayLocal);
            return false;
        }

        _lastDateRolloverAttemptUtc = DateTime.UtcNow;

        var sharedBridge = _captureCoordinator?.IsSharedCaptureActive == true;
        _logger.LogInformation(
            "Date directory rollover triggered: patternDate={PatternDate:yyyy-MM-dd} today={Today:yyyy-MM-dd} sharedBridge={SharedBridge} (recording consumer relaunch only; remote producer/publisher not torn down)",
            _persistedPatternDate,
            todayLocal,
            sharedBridge);

        // RestartAsync → RelaunchCaptureAsync:
        // - SharedBridge: StopRecording(fast) + Start recording pipe consumer only
        // - Dual gdigrab: stop/start recording ffmpeg only (standalone remote process untouched)
        // Never route through RecoverRecording (that redirects to RecoverSharedBridge while remote is up).
        await RestartAsync("date directory rollover", cancellationToken);

        var stillNeeded = RecordingDateDirectoryPolicy.NeedsRollover(
            IsProcessAlive(),
            _workSessionActive,
            _persistedOutputPattern,
            _persistedPatternDate,
            DateTime.Now.Date);

        if (stillNeeded)
        {
            _logger.LogWarning(
                "Date directory rollover finished but pattern still on old date (restart may have been throttled or failed); patternDate={PatternDate:yyyy-MM-dd} pattern={Pattern}",
                _persistedPatternDate,
                _persistedOutputPattern);
            return false;
        }

        _logger.LogInformation(
            "Date directory rollover complete: patternDate={PatternDate:yyyy-MM-dd} pattern={Pattern} sharedBridge={SharedBridge}",
            _persistedPatternDate,
            _persistedOutputPattern,
            sharedBridge);
        return true;
    }

    public RecordingHealthSnapshot GetHealthSnapshot(RecorderState state, bool remoteViewActive) =>
        BuildRecordingHealthSnapshot(state, remoteViewActive);

    private void ApplyEncoderRetryFlags()
    {
        _forceSoftwareEncoder = false;
        _encoderFailureCount = 0;
        _needPixelFormatFallback = false;
        _encoderCacheTime = DateTime.MinValue;
        _lastEncoderSwitchTime = DateTime.MinValue;
    }

    private async Task<bool> RelaunchCaptureAsync(string reason, RestartPolicyBucket bucket, CancellationToken ct)
    {
        if (reason.Contains("Retry encoder", StringComparison.OrdinalIgnoreCase))
            ApplyEncoderRetryFlags();

        if (!_restartPolicies.TryAcquire(bucket, out var blockReason))
        {
            _logger.LogWarning(
                "Recording relaunch throttled bucket={Bucket}: {Reason} ({BlockReason})",
                bucket,
                reason,
                blockReason);
            return false;
        }

        _logger.LogWarning("Recording relaunch: {Reason} bucket={Bucket}", reason, bucket);

        if (_captureCoordinator?.IsSharedCaptureActive == true)
        {
            await StopRecordingAsync(fullShutdown: false, fastTransition: true);

            var health = _captureCoordinator.GetSharedBridgeHealth();
            if (!health.RecordingPipeConnected)
                await _captureCoordinator.ReconnectSharedBridgeConsumerAsync(CaptureConsumer.Recording, ct);

            ResetAllSignals();
            _isStopping = false;
            if (!_workSessionActive)
                return false;

            var started = await StartRecordingAsync(orchestratorOwned: true);
            if (started)
                _consecutiveFailures = 0;
            else
                Interlocked.Increment(ref _consecutiveFailures);

            return started && IsProcessAlive();
        }

        var skipPostStopDelay = reason.Contains("Restore gdigrab", StringComparison.OrdinalIgnoreCase);
        await StopRecordingAsync(fullShutdown: false, fastTransition: skipPostStopDelay);
        if (!skipPostStopDelay)
            await Task.Delay(2000, ct);

        if (!reason.Contains("Retry encoder", StringComparison.OrdinalIgnoreCase))
        {
            _forceSoftwareEncoder = false;
            _encoderFailureCount = 0;
            _needPixelFormatFallback = false;
            _encoderCacheTime = DateTime.MinValue;
        }

        ResetAllSignals();
        _isStopping = false;

        if (!_workSessionActive)
            return false;

        var ok = await StartRecordingAsync(orchestratorOwned: true);
        if (!skipPostStopDelay)
            await Task.Delay(3000, ct);

        if (ok && IsProcessAlive())
        {
            if (skipPostStopDelay)
            {
                ok = await WaitForRecordingOutputAsync(ct, TimeSpan.FromSeconds(8));
                if (!ok && IsProcessAlive())
                    ok = true;
            }

            if (ok && IsProcessAlive())
                _consecutiveFailures = 0;
            else
                Interlocked.Increment(ref _consecutiveFailures);
        }
        else
            Interlocked.Increment(ref _consecutiveFailures);

        return ok && IsProcessAlive();
    }

    private async Task<bool> RestoreGdigrabCaptureAsync(CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();

        if (_captureCoordinator != null)
            await _captureCoordinator.NotifyConsumerStoppingAsync(CaptureConsumer.Recording, ct);

        ResetAllSignals();
        _isStopping = false;

        if (!_workSessionActive)
            return false;

        _logger.LogInformation("Restoring gdigrab recording after SharedBridge (fast path)");
        var started = await StartRecordingAsync(orchestratorOwned: true);
        if (!started || !IsProcessAlive())
        {
            Interlocked.Increment(ref _consecutiveFailures);
            return false;
        }

        // Keep restore snappy for tray UX: wait briefly for frames/file growth, then accept
        // a live process (mp4 segment may not flush size for a long time without progress).
        var verified = await WaitForRecordingOutputAsync(ct, TimeSpan.FromSeconds(8));
        if (!verified && IsProcessAlive())
        {
            _logger.LogInformation(
                "Gdigrab restore: no output growth yet but FFmpeg alive (PID: {Pid}); accepting restore",
                _ffmpegProcess?.Id);
            verified = true;
        }
        if (!verified)
        {
            _logger.LogError("Gdigrab restore: FFmpeg started but no verified output; stopping capture");
            await StopRecordingAsync(fullShutdown: false, fastTransition: true);
            Interlocked.Increment(ref _consecutiveFailures);
            return false;
        }

        _consecutiveFailures = 0;
        var pid = _ffmpegProcess?.Id;
        _logger.LogInformation(
            "Gdigrab recording restored and verified (PID: {Pid}, pattern: {Pattern})",
            pid,
            _persistedOutputPattern);
        return true;
    }
}

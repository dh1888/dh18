using System.Globalization;

namespace EnterpriseAgent.Agent.RecordingServices;

/// <summary>
/// Pure helpers for recording output date-directory decisions (unit-testable, no process I/O).
/// </summary>
internal static class RecordingDateDirectoryPolicy
{
    public const string LocalDateDirectoryFormat = "yyyy-MM-dd";

    /// <summary>
    /// Whether an orchestrator-owned restart may keep the existing segment output pattern.
    /// Cross-midnight must return false so a new local date directory is allocated.
    /// </summary>
    public static bool ShouldPreservePattern(
        bool orchestratorOwned,
        string? pattern,
        DateTime? patternDate,
        DateTime todayLocal)
    {
        return orchestratorOwned
               && !string.IsNullOrWhiteSpace(pattern)
               && patternDate.HasValue
               && patternDate.Value.Date == todayLocal.Date;
    }

    /// <summary>
    /// True when an active recording session is still writing under a previous local calendar day.
    /// </summary>
    public static bool NeedsRollover(
        bool isRunning,
        bool workSessionActive,
        string? pattern,
        DateTime? patternDate,
        DateTime todayLocal)
    {
        if (!workSessionActive || !isRunning)
            return false;
        if (string.IsNullOrWhiteSpace(pattern) || !patternDate.HasValue)
            return false;
        return patternDate.Value.Date != todayLocal.Date;
    }

    /// <summary>
    /// Parses the local calendar date from a persisted pattern path
    /// (.../recordings/yyyy-MM-dd/yyyy-MM-dd_HH-mm-ss_%03d.mp4).
    /// </summary>
    public static DateTime? TryParseLocalDateFromPattern(string? pattern)
    {
        if (string.IsNullOrWhiteSpace(pattern))
            return null;

        var directory = Path.GetDirectoryName(pattern);
        if (string.IsNullOrWhiteSpace(directory))
            return null;

        var folderName = Path.GetFileName(directory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        if (string.IsNullOrWhiteSpace(folderName))
            return null;

        if (DateTime.TryParseExact(
                folderName,
                LocalDateDirectoryFormat,
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out var parsed))
        {
            return parsed.Date;
        }

        return null;
    }
}

using System.Data;
using System.IO;
using System.Text.Json;
using DHPG.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace DHPG.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<AppSettings> AppSettings => Set<AppSettings>();
    public DbSet<Site> Sites => Set<Site>();
    public DbSet<SiteColumnMapping> SiteColumnMappings => Set<SiteColumnMapping>();
    public DbSet<ActivityColumnMapping> ActivityColumnMappings => Set<ActivityColumnMapping>();
    public DbSet<Activity> Activities => Set<Activity>();
    public DbSet<ActivitySiteLink> ActivitySiteLinks => Set<ActivitySiteLink>();
    public DbSet<ProcessHistory> ProcessHistories => Set<ProcessHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        ConfigureAppSettings(modelBuilder);
        ConfigureSites(modelBuilder);
        ConfigureSiteColumnMappings(modelBuilder);
        ConfigureActivityColumnMappings(modelBuilder);
        ConfigureActivities(modelBuilder);
        ConfigureActivitySiteLinks(modelBuilder);
        ConfigureProcessHistories(modelBuilder);
    }

    private static void ConfigureAppSettings(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<AppSettings>();
        entity.ToTable("AppSettings");
        entity.HasKey(e => e.Id);
        entity.Property(e => e.ExportDirectory).HasMaxLength(500);
        entity.Property(e => e.DefaultWageringMultiplier).HasPrecision(18, 2);
        entity.Property(e => e.DefaultAppRemark).HasMaxLength(500);
        entity.Property(e => e.DefaultBackendRemark).HasMaxLength(500);
        entity.Property(e => e.Theme).HasMaxLength(20);
        entity.Property(e => e.LogLevel).HasMaxLength(20);
    }

    private static void ConfigureSites(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<Site>();
        entity.ToTable("Sites");
        entity.HasKey(e => e.Id);
        entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
        entity.Property(e => e.Code).HasMaxLength(50).IsRequired();
        entity.Property(e => e.Remark).HasMaxLength(500);
        entity.HasIndex(e => e.Code).IsUnique();
        entity.HasIndex(e => e.IsEnabled);
    }

    private static void ConfigureSiteColumnMappings(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<SiteColumnMapping>();
        entity.ToTable("SiteColumnMappings");
        entity.HasKey(e => e.Id);
        entity.HasIndex(e => e.SiteId).IsUnique();
        entity.HasOne(e => e.Site)
            .WithOne(s => s.ColumnMapping)
            .HasForeignKey<SiteColumnMapping>(e => e.SiteId)
            .OnDelete(DeleteBehavior.Cascade);
    }

    private static void ConfigureActivityColumnMappings(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<ActivityColumnMapping>();
        entity.ToTable("ActivityColumnMappings");
        entity.HasKey(e => e.Id);
        entity.HasIndex(e => e.ActivityId).IsUnique();
        entity.HasOne(e => e.Activity)
            .WithOne(a => a.ColumnMapping)
            .HasForeignKey<ActivityColumnMapping>(e => e.ActivityId)
            .OnDelete(DeleteBehavior.Cascade);
    }

    private static void ConfigureActivities(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<Activity>();
        entity.ToTable("Activities");
        entity.HasKey(e => e.Id);
        entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
        entity.Property(e => e.Rate).HasPrecision(18, 4);
        entity.Property(e => e.MinBonus).HasPrecision(18, 2);
        entity.Property(e => e.MaxBonus).HasPrecision(18, 2);
        entity.Property(e => e.DefaultWageringMultiplier).HasPrecision(18, 2);
        entity.Property(e => e.AppRemark).HasMaxLength(500);
        entity.Property(e => e.BackendRemark).HasMaxLength(500);
        entity.Property(e => e.FilterTierKeywords).IsRequired();
        entity.Property(e => e.WeeklyDayRatesJson).IsRequired();
        entity.Property(e => e.DefaultTimezone).HasMaxLength(20);
        entity.HasIndex(e => e.Name).IsUnique();
        entity.HasIndex(e => e.IsEnabled);
        entity.HasOne(e => e.Site)
            .WithMany(s => s.Activities)
            .HasForeignKey(e => e.SiteId)
            .OnDelete(DeleteBehavior.SetNull);
    }

    private static void ConfigureActivitySiteLinks(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<ActivitySiteLink>();
        entity.ToTable("ActivitySiteLinks");
        entity.HasKey(e => new { e.ActivityId, e.SiteId });
        entity.HasIndex(e => e.SiteId);
        entity.HasOne(e => e.Activity)
            .WithMany(a => a.SiteLinks)
            .HasForeignKey(e => e.ActivityId)
            .OnDelete(DeleteBehavior.Cascade);
        entity.HasOne(e => e.Site)
            .WithMany(s => s.ActivityLinks)
            .HasForeignKey(e => e.SiteId)
            .OnDelete(DeleteBehavior.Cascade);
    }

    private static void ConfigureProcessHistories(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<ProcessHistory>();
        entity.ToTable("ProcessHistories");
        entity.HasKey(e => e.Id);
        entity.Property(e => e.SiteName).HasMaxLength(100).IsRequired();
        entity.Property(e => e.ActivityName).HasMaxLength(100).IsRequired();
        entity.Property(e => e.TotalBonus).HasPrecision(18, 2);
        entity.Property(e => e.SnapshotJson).IsRequired();
        entity.Property(e => e.ExportFilePath).HasMaxLength(500);
        entity.HasIndex(e => e.ProcessedAt);
        entity.HasIndex(e => e.SiteId);
        entity.HasIndex(e => e.ActivityId);
        entity.HasOne(e => e.Site)
            .WithMany(s => s.ProcessHistories)
            .HasForeignKey(e => e.SiteId)
            .OnDelete(DeleteBehavior.SetNull);
        entity.HasOne(e => e.Activity)
            .WithMany(a => a.ProcessHistories)
            .HasForeignKey(e => e.ActivityId)
            .OnDelete(DeleteBehavior.SetNull);
    }

    public void SeedDefaultsIfEmpty()
    {
        if (!AppSettings.Any())
        {
            var exportDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "DHPG");
            AppSettings.Add(new AppSettings
            {
                Id = 1,
                ExportDirectory = exportDir,
                DefaultWageringMultiplier = 1m,
                Theme = "Light",
                LogLevel = "Information"
            });
        }

        if (Sites.Any())
            return;

        var now = DateTime.Now;
        var site = new Site
        {
            Name = "25S",
            Code = "25S",
            Remark = "默认站点",
            IsEnabled = true,
            CreatedAt = now,
            ColumnMapping = new SiteColumnMapping
            {
                UserIdColumn = 0,
                PayColumn = 5,
                WithdrawColumn = 7,
                PhoneColumn = 17,
                TierColumn = 21,
                HeaderRow = 0,
                CallbackUserIdColumn = 5,
                CallbackPayColumn = 8,
                CallbackWithdrawColumn = 9,
                CallbackPhoneColumn = 23,
                CallbackTierColumn = 24,
                CallbackHeaderRow = 0,
                UnclaimedUserIdColumn = 1
            }
        };
        Sites.Add(site);
        SaveChanges();

        var activityMapping = new ActivityColumnMapping
        {
            UserIdColumn = site.ColumnMapping.UserIdColumn,
            PayColumn = site.ColumnMapping.PayColumn,
            WithdrawColumn = site.ColumnMapping.WithdrawColumn,
            PhoneColumn = site.ColumnMapping.PhoneColumn,
            TierColumn = site.ColumnMapping.TierColumn,
            HeaderRow = site.ColumnMapping.HeaderRow,
            CallbackUserIdColumn = site.ColumnMapping.CallbackUserIdColumn,
            CallbackPayColumn = site.ColumnMapping.CallbackPayColumn,
            CallbackWithdrawColumn = site.ColumnMapping.CallbackWithdrawColumn,
            CallbackPhoneColumn = site.ColumnMapping.CallbackPhoneColumn,
            CallbackTierColumn = site.ColumnMapping.CallbackTierColumn,
            CallbackHeaderRow = site.ColumnMapping.CallbackHeaderRow,
            UnclaimedUserIdColumn = site.ColumnMapping.UnclaimedUserIdColumn
        };

        Activities.AddRange(
            new Activity
            {
                SiteId = site.Id,
                Name = "时段彩金",
                Rate = 0.02m,
                Divisor = 10,
                MinBonus = 1m,
                MaxBonus = 50m,
                DefaultWageringMultiplier = 1m,
                AllowProfitMember = false,
                IsEnabled = true,
                ApplyToAllSites = true,
                Kind = ActivityKind.Period,
                FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
                SortOrder = 1,
                CreatedAt = now,
                UpdatedAt = now,
                ColumnMapping = CloneActivityColumnMapping(activityMapping)
            },
            new Activity
            {
                SiteId = site.Id,
                Name = "回访彩金",
                Rate = 0.02m,
                Divisor = 2,
                MinBonus = 1m,
                MaxBonus = 0m,
                DefaultWageringMultiplier = 1m,
                AllowProfitMember = true,
                IsEnabled = true,
                ApplyToAllSites = true,
                Kind = ActivityKind.Callback,
                FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
                SortOrder = 2,
                CreatedAt = now,
                UpdatedAt = now,
                ColumnMapping = CloneActivityColumnMapping(activityMapping)
            },
            new Activity
            {
                SiteId = site.Id,
                Name = ActivityDefaults.Loss7dActivityName,
                Rate = 0m,
                Divisor = 1,
                MinBonus = 1m,
                MaxBonus = 0m,
                DefaultWageringMultiplier = 1m,
                AllowProfitMember = false,
                IsEnabled = true,
                ApplyToAllSites = true,
                Kind = ActivityKind.Loss7d,
                WeeklyDayRatesJson = WeeklyDayRates.CreateLoss7dDefaults().Serialize(),
                DefaultTimezone = "Beijing",
                FilterLossMember = false,
                FilterUnclaimedEnabled = true,
                FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
                SortOrder = 3,
                CreatedAt = now,
                UpdatedAt = now,
                ColumnMapping = CreateDefaultLoss7dActivityMapping()
            },
            new Activity
            {
                SiteId = site.Id,
                Name = ActivityDefaults.YesterdayLossActivityName,
                Rate = 0m,
                Divisor = 1,
                MinBonus = 1m,
                MaxBonus = 0m,
                DefaultWageringMultiplier = 1m,
                AllowProfitMember = false,
                IsEnabled = true,
                ApplyToAllSites = true,
                Kind = ActivityKind.YesterdayLoss,
                TieredAmountRatesJson = TieredAmountRates.CreateYesterdayLossDefaults().Serialize(),
                MinNetDiff = 20m,
                FilterLossMember = false,
                FilterUnclaimedEnabled = true,
                FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
                SortOrder = 4,
                CreatedAt = now,
                UpdatedAt = now,
                ColumnMapping = CreateDefaultYesterdayLossActivityMapping()
            },
            new Activity
            {
                SiteId = site.Id,
                Name = ActivityDefaults.OldCallback234ActivityName,
                Rate = 0m,
                Divisor = 1,
                MinBonus = 1m,
                MaxBonus = 0m,
                DefaultWageringMultiplier = 1m,
                AllowProfitMember = true,
                IsEnabled = true,
                ApplyToAllSites = true,
                Kind = ActivityKind.OldCallback234,
                TieredFixedBonusesJson = TieredFixedBonuses.CreateOldCallback234Defaults().Serialize(),
                InactiveDaysMax = 7,
                FilterRechargeEnabled = false,
                FilterUnclaimedEnabled = true,
                FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
                SortOrder = 5,
                CreatedAt = now,
                UpdatedAt = now,
                ColumnMapping = CreateDefaultOldCallback234ActivityMapping()
            },
            new Activity
            {
                SiteId = null,
                Name = ActivityDefaults.ComprehensiveCallbackActivityName,
                Rate = 0.02m,
                Divisor = 2,
                MinBonus = 1m,
                MaxBonus = 0m,
                DefaultWageringMultiplier = 1m,
                AllowProfitMember = true,
                IsEnabled = true,
                ApplyToAllSites = true,
                Kind = ActivityKind.ComprehensiveCallback,
                ComprehensiveFeaturesJson = ComprehensiveCallbackFeatures.CreateDefaults().Serialize(),
                WeeklyDayRatesJson = WeeklyDayRates.CreateLoss7dDefaults().Serialize(),
                DefaultTimezone = "Beijing",
                TieredAmountRatesJson = TieredAmountRates.CreateYesterdayLossDefaults().Serialize(),
                TieredFixedBonusesJson = TieredFixedBonuses.CreateOldCallback234Defaults().Serialize(),
                MinNetDiff = 20m,
                InactiveDaysMax = 7,
                FilterRechargeEnabled = false,
                FilterUnclaimedEnabled = true,
                FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
                SortOrder = 6,
                CreatedAt = now,
                UpdatedAt = now,
                ColumnMapping = CreateDefaultComprehensiveActivityMapping()
            });
        SaveChanges();
    }

    private static ActivityColumnMapping CreateDefaultLoss7dActivityMapping()
    {
        var loss7d = ColumnMappingInfo.CreateLoss7dDefaults();
        return new ActivityColumnMapping
        {
            UserIdColumn = 0,
            PayColumn = 5,
            WithdrawColumn = 7,
            PhoneColumn = 17,
            TierColumn = 21,
            CallbackUserIdColumn = 5,
            CallbackPayColumn = 8,
            CallbackWithdrawColumn = 9,
            CallbackPhoneColumn = 23,
            CallbackTierColumn = 24,
            UnclaimedUserIdColumn = 1,
            Loss7dUserIdColumn = loss7d.UserIdColumn,
            Loss7dDepositColumn = loss7d.PayColumn,
            Loss7dWithdrawColumn = loss7d.WithdrawColumn,
            Loss7dPhoneColumn = loss7d.PhoneColumn,
            Loss7dTierColumn = loss7d.TierColumn,
            Loss7dHeaderRow = loss7d.HeaderRow
        };
    }

    private static ActivityColumnMapping CreateDefaultYesterdayLossActivityMapping()
    {
        var mapping = ColumnMappingInfo.CreateYesterdayLossDefaults();
        return new ActivityColumnMapping
        {
            UserIdColumn = 0,
            PayColumn = 5,
            WithdrawColumn = 7,
            PhoneColumn = 17,
            TierColumn = 21,
            CallbackUserIdColumn = 5,
            CallbackPayColumn = 8,
            CallbackWithdrawColumn = 9,
            CallbackPhoneColumn = 23,
            CallbackTierColumn = 24,
            UnclaimedUserIdColumn = 1,
            Loss7dUserIdColumn = 5,
            Loss7dDepositColumn = 8,
            Loss7dWithdrawColumn = 9,
            Loss7dPhoneColumn = 23,
            Loss7dTierColumn = 24,
            YesterdayLossUserIdColumn = mapping.UserIdColumn,
            YesterdayLossPayColumn = mapping.PayColumn,
            YesterdayLossWithdrawColumn = mapping.WithdrawColumn,
            YesterdayLossNetDiffColumn = mapping.NetDiffColumn,
            YesterdayLossPhoneColumn = mapping.PhoneColumn,
            YesterdayLossTierColumn = mapping.TierColumn,
            YesterdayLossHeaderRow = mapping.HeaderRow
        };
    }

    private static ActivityColumnMapping CreateDefaultOldCallback234ActivityMapping()
    {
        var mapping = ColumnMappingInfo.CreateOldCallback234Defaults();
        var recharge = RechargeMappingConfig.CreateDefaults();
        return new ActivityColumnMapping
        {
            UserIdColumn = 0,
            PayColumn = 5,
            WithdrawColumn = 7,
            PhoneColumn = 17,
            TierColumn = 21,
            CallbackUserIdColumn = 5,
            CallbackPayColumn = 8,
            CallbackWithdrawColumn = 9,
            CallbackPhoneColumn = 23,
            CallbackTierColumn = 24,
            UnclaimedUserIdColumn = 1,
            Loss7dUserIdColumn = 5,
            Loss7dDepositColumn = 8,
            Loss7dWithdrawColumn = 9,
            Loss7dPhoneColumn = 23,
            Loss7dTierColumn = 24,
            YesterdayLossUserIdColumn = 1,
            YesterdayLossPayColumn = 11,
            YesterdayLossWithdrawColumn = 12,
            YesterdayLossNetDiffColumn = 18,
            YesterdayLossPhoneColumn = 19,
            YesterdayLossTierColumn = 20,
            OldCallback234UserIdColumn = mapping.UserIdColumn,
            OldCallback234PayColumn = mapping.PayColumn,
            OldCallback234WithdrawColumn = mapping.WithdrawColumn,
            OldCallback234NetDiffColumn = mapping.NetDiffColumn,
            OldCallback234InactiveDaysColumn = mapping.InactiveDaysColumn,
            OldCallback234PhoneColumn = mapping.PhoneColumn,
            OldCallback234TierColumn = mapping.TierColumn,
            OldCallback234HeaderRow = mapping.HeaderRow,
            RechargeUserIdColumn = recharge.UserIdColumn,
            RechargeAmountColumn = recharge.AmountColumn,
            RechargeHeaderRow = recharge.HeaderRow
        };
    }

    private static ActivityColumnMapping CreateDefaultComprehensiveActivityMapping()
    {
        var mapping = ColumnMappingInfo.CreateComprehensiveDefaults();
        var recharge = RechargeMappingConfig.CreateDefaults();
        var old234 = CreateDefaultOldCallback234ActivityMapping();
        return new ActivityColumnMapping
        {
            UserIdColumn = old234.UserIdColumn,
            PayColumn = old234.PayColumn,
            WithdrawColumn = old234.WithdrawColumn,
            PhoneColumn = old234.PhoneColumn,
            TierColumn = old234.TierColumn,
            HeaderRow = old234.HeaderRow,
            CallbackUserIdColumn = old234.CallbackUserIdColumn,
            CallbackPayColumn = old234.CallbackPayColumn,
            CallbackWithdrawColumn = old234.CallbackWithdrawColumn,
            CallbackPhoneColumn = old234.CallbackPhoneColumn,
            CallbackTierColumn = old234.CallbackTierColumn,
            CallbackHeaderRow = old234.CallbackHeaderRow,
            UnclaimedUserIdColumn = old234.UnclaimedUserIdColumn,
            Loss7dUserIdColumn = old234.Loss7dUserIdColumn,
            Loss7dDepositColumn = old234.Loss7dDepositColumn,
            Loss7dWithdrawColumn = old234.Loss7dWithdrawColumn,
            Loss7dPhoneColumn = old234.Loss7dPhoneColumn,
            Loss7dTierColumn = old234.Loss7dTierColumn,
            Loss7dHeaderRow = old234.Loss7dHeaderRow,
            YesterdayLossUserIdColumn = old234.YesterdayLossUserIdColumn,
            YesterdayLossPayColumn = old234.YesterdayLossPayColumn,
            YesterdayLossWithdrawColumn = old234.YesterdayLossWithdrawColumn,
            YesterdayLossNetDiffColumn = old234.YesterdayLossNetDiffColumn,
            YesterdayLossPhoneColumn = old234.YesterdayLossPhoneColumn,
            YesterdayLossTierColumn = old234.YesterdayLossTierColumn,
            YesterdayLossHeaderRow = old234.YesterdayLossHeaderRow,
            OldCallback234UserIdColumn = old234.OldCallback234UserIdColumn,
            OldCallback234PayColumn = old234.OldCallback234PayColumn,
            OldCallback234WithdrawColumn = old234.OldCallback234WithdrawColumn,
            OldCallback234NetDiffColumn = old234.OldCallback234NetDiffColumn,
            OldCallback234InactiveDaysColumn = old234.OldCallback234InactiveDaysColumn,
            OldCallback234PhoneColumn = old234.OldCallback234PhoneColumn,
            OldCallback234TierColumn = old234.OldCallback234TierColumn,
            OldCallback234HeaderRow = old234.OldCallback234HeaderRow,
            ComprehensiveUserIdColumn = mapping.UserIdColumn,
            ComprehensivePayColumn = mapping.PayColumn,
            ComprehensiveWithdrawColumn = mapping.WithdrawColumn,
            ComprehensiveNetDiffColumn = mapping.NetDiffColumn,
            ComprehensiveInactiveDaysColumn = mapping.InactiveDaysColumn,
            ComprehensivePhoneColumn = mapping.PhoneColumn,
            ComprehensiveTierColumn = mapping.TierColumn,
            ComprehensiveHeaderRow = mapping.HeaderRow,
            RechargeUserIdColumn = recharge.UserIdColumn,
            RechargeAmountColumn = recharge.AmountColumn,
            RechargeHeaderRow = recharge.HeaderRow
        };
    }

    private static ActivityColumnMapping CloneActivityColumnMapping(ActivityColumnMapping source) => new()
    {
        UserIdColumn = source.UserIdColumn,
        PayColumn = source.PayColumn,
        WithdrawColumn = source.WithdrawColumn,
        PhoneColumn = source.PhoneColumn,
        TierColumn = source.TierColumn,
        HeaderRow = source.HeaderRow,
        CallbackUserIdColumn = source.CallbackUserIdColumn,
        CallbackPayColumn = source.CallbackPayColumn,
        CallbackWithdrawColumn = source.CallbackWithdrawColumn,
        CallbackPhoneColumn = source.CallbackPhoneColumn,
        CallbackTierColumn = source.CallbackTierColumn,
        CallbackHeaderRow = source.CallbackHeaderRow,
        UnclaimedUserIdColumn = source.UnclaimedUserIdColumn,
        Loss7dUserIdColumn = source.Loss7dUserIdColumn > 0 ? source.Loss7dUserIdColumn : 5,
        Loss7dDepositColumn = source.Loss7dDepositColumn > 0 ? source.Loss7dDepositColumn : 8,
        Loss7dWithdrawColumn = source.Loss7dWithdrawColumn > 0 ? source.Loss7dWithdrawColumn : 9,
        Loss7dPhoneColumn = source.Loss7dPhoneColumn > 0 ? source.Loss7dPhoneColumn : 23,
        Loss7dTierColumn = source.Loss7dTierColumn > 0 ? source.Loss7dTierColumn : 24,
        Loss7dHeaderRow = source.Loss7dHeaderRow,
        YesterdayLossUserIdColumn = source.YesterdayLossUserIdColumn > 0 ? source.YesterdayLossUserIdColumn : 1,
        YesterdayLossPayColumn = source.YesterdayLossPayColumn > 0 ? source.YesterdayLossPayColumn : 11,
        YesterdayLossWithdrawColumn = source.YesterdayLossWithdrawColumn > 0 ? source.YesterdayLossWithdrawColumn : 12,
        YesterdayLossNetDiffColumn = source.YesterdayLossNetDiffColumn > 0 ? source.YesterdayLossNetDiffColumn : 18,
        YesterdayLossPhoneColumn = source.YesterdayLossPhoneColumn > 0 ? source.YesterdayLossPhoneColumn : 19,
        YesterdayLossTierColumn = source.YesterdayLossTierColumn > 0 ? source.YesterdayLossTierColumn : 20,
        YesterdayLossHeaderRow = source.YesterdayLossHeaderRow,
        OldCallback234UserIdColumn = source.OldCallback234NetDiffColumn > 0 ? source.OldCallback234UserIdColumn : 0,
        OldCallback234PayColumn = source.OldCallback234PayColumn > 0 ? source.OldCallback234PayColumn : 5,
        OldCallback234WithdrawColumn = source.OldCallback234WithdrawColumn > 0 ? source.OldCallback234WithdrawColumn : 7,
        OldCallback234NetDiffColumn = source.OldCallback234NetDiffColumn > 0 ? source.OldCallback234NetDiffColumn : 8,
        OldCallback234InactiveDaysColumn = source.OldCallback234InactiveDaysColumn > 0 ? source.OldCallback234InactiveDaysColumn : 16,
        OldCallback234PhoneColumn = source.OldCallback234NetDiffColumn > 0 ? source.OldCallback234PhoneColumn : 17,
        OldCallback234TierColumn = source.OldCallback234NetDiffColumn > 0 ? source.OldCallback234TierColumn : 21,
        OldCallback234HeaderRow = source.OldCallback234HeaderRow,
        RechargeUserIdColumn = source.RechargeUserIdColumn > 0 ? source.RechargeUserIdColumn : 1,
        RechargeAmountColumn = source.RechargeAmountColumn > 0 ? source.RechargeAmountColumn : 5,
        RechargeHeaderRow = source.RechargeHeaderRow,
        ComprehensiveUserIdColumn = source.ComprehensiveUserIdColumn > 0 ? source.ComprehensiveUserIdColumn : 0,
        ComprehensivePayColumn = source.ComprehensivePayColumn > 0 ? source.ComprehensivePayColumn : 5,
        ComprehensiveWithdrawColumn = source.ComprehensiveWithdrawColumn > 0 ? source.ComprehensiveWithdrawColumn : 7,
        ComprehensiveNetDiffColumn = source.ComprehensiveNetDiffColumn > 0 ? source.ComprehensiveNetDiffColumn : 8,
        ComprehensiveInactiveDaysColumn = source.ComprehensiveInactiveDaysColumn > 0 ? source.ComprehensiveInactiveDaysColumn : 16,
        ComprehensivePhoneColumn = source.ComprehensivePhoneColumn > 0 ? source.ComprehensivePhoneColumn : 17,
        ComprehensiveTierColumn = source.ComprehensiveTierColumn > 0 ? source.ComprehensiveTierColumn : 21,
        ComprehensiveHeaderRow = source.ComprehensiveHeaderRow
    };

    private static ActivityColumnMapping CloneActivityColumnMappingFromSite(SiteColumnMapping source) => new()
    {
        UserIdColumn = source.UserIdColumn,
        PayColumn = source.PayColumn,
        WithdrawColumn = source.WithdrawColumn,
        PhoneColumn = source.PhoneColumn,
        TierColumn = source.TierColumn,
        HeaderRow = source.HeaderRow,
        CallbackUserIdColumn = source.CallbackUserIdColumn,
        CallbackPayColumn = source.CallbackPayColumn,
        CallbackWithdrawColumn = source.CallbackWithdrawColumn,
        CallbackPhoneColumn = source.CallbackPhoneColumn,
        CallbackTierColumn = source.CallbackTierColumn,
        CallbackHeaderRow = source.CallbackHeaderRow,
        UnclaimedUserIdColumn = source.UnclaimedUserIdColumn,
        Loss7dUserIdColumn = 5,
        Loss7dDepositColumn = 8,
        Loss7dWithdrawColumn = 9,
        Loss7dPhoneColumn = 23,
        Loss7dTierColumn = 24,
        YesterdayLossUserIdColumn = 1,
        YesterdayLossPayColumn = 11,
        YesterdayLossWithdrawColumn = 12,
        YesterdayLossNetDiffColumn = 18,
        YesterdayLossPhoneColumn = 19,
        YesterdayLossTierColumn = 20
    };

    private bool EnsureActivityColumnMappings()
    {
        var template = SiteColumnMappings.AsNoTracking().FirstOrDefault()
            ?? new SiteColumnMapping();
        var patched = false;

        foreach (var activity in Activities.Include(a => a.ColumnMapping).Where(a => a.ColumnMapping == null))
        {
            activity.ColumnMapping = CloneActivityColumnMappingFromSite(template);
            patched = true;
        }

        return patched;
    }

    /// <summary>升级旧库：回访彩金参数、列映射默认值、活动适用全部站点。</summary>
    public void PatchLegacyDefaults()
    {
        var activityMappingPatched = EnsureActivityColumnMappings();
        var mappingPatched = false;
        foreach (var mapping in SiteColumnMappings)
        {
            if (IsCallbackMappingUninitialized(mapping))
            {
                mapping.CallbackUserIdColumn = 5;
                mapping.CallbackPayColumn = 8;
                mapping.CallbackWithdrawColumn = 9;
                mapping.CallbackPhoneColumn = 23;
                mapping.CallbackTierColumn = 24;
                mapping.CallbackHeaderRow = 0;
                mappingPatched = true;
            }

            if (mapping.UnclaimedUserIdColumn <= 0)
            {
                mapping.UnclaimedUserIdColumn = 1;
                mappingPatched = true;
            }
        }

        var activityPatched = false;
        foreach (var activity in Activities.Where(a =>
                     a.Name == "时段彩金" || a.Name == "回访彩金"))
        {
            if (!activity.ApplyToAllSites)
            {
                activity.ApplyToAllSites = true;
                activityPatched = true;
            }
        }

        var callback = Activities.FirstOrDefault(a => a.Name == "回访彩金");
        if (callback is not null && callback.Divisor == 10 && callback.MinBonus == 5m && callback.MaxBonus == 0m)
        {
            callback.Divisor = 2;
            callback.MinBonus = 1m;
            callback.UpdatedAt = DateTime.Now;
            activityPatched = true;
        }

        var tierPatched = false;
        var legacyTierSets = new HashSet<string>(StringComparer.Ordinal)
        {
            JsonSerializer.Serialize(new[] { "测试", "代理", "内部" }),
            JsonSerializer.Serialize(new[] { "测试", "代理" }),
            "[]"
        };
        var defaultTierJson = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords);

        foreach (var activity in Activities)
        {
            if (legacyTierSets.Contains(activity.FilterTierKeywords))
            {
                activity.FilterTierKeywords = defaultTierJson;
                activity.UpdatedAt = DateTime.Now;
                tierPatched = true;
            }

            if (activity.ApplyToAllSites && activity.SiteId is not null and not 0)
            {
                activity.SiteId = null;
                activityPatched = true;
            }
        }

        var sitePatched = false;
        var legacyDemo = Sites.FirstOrDefault(s => s.Code == "DEMO");
        if (legacyDemo is not null && !Sites.Any(s => s.Code == "25S"))
        {
            legacyDemo.Name = "25S";
            legacyDemo.Code = "25S";
            sitePatched = true;
        }

        foreach (var site in Sites.Include(s => s.ColumnMapping).Where(s => s.ColumnMapping == null))
        {
            site.ColumnMapping = new SiteColumnMapping
            {
                SiteId = site.Id,
                UnclaimedUserIdColumn = 1,
                CallbackUserIdColumn = 5,
                CallbackPayColumn = 8,
                CallbackWithdrawColumn = 9,
                CallbackPhoneColumn = 23,
                CallbackTierColumn = 24
            };
            sitePatched = true;
        }

        if (mappingPatched || activityPatched || tierPatched || sitePatched || activityMappingPatched || EnsureLoss7dDefaults() || EnsureYesterdayLossDefaults() || EnsureOldCallback234Defaults() || EnsureComprehensiveDefaults())
            SaveChanges();
    }

    private bool EnsureLoss7dDefaults()
    {
        var patched = false;
        var period = Activities.FirstOrDefault(a => a.Name == "时段彩金");
        if (period is not null && period.Kind != ActivityKind.Period)
        {
            period.Kind = ActivityKind.Period;
            patched = true;
        }

        var callback = Activities.FirstOrDefault(a => a.Name == "回访彩金");
        if (callback is not null && callback.Kind != ActivityKind.Callback)
        {
            callback.Kind = ActivityKind.Callback;
            patched = true;
        }

        foreach (var mapping in ActivityColumnMappings.Where(m => m.Loss7dDepositColumn == 0))
        {
            mapping.Loss7dUserIdColumn = 5;
            mapping.Loss7dDepositColumn = 8;
            mapping.Loss7dWithdrawColumn = 9;
            mapping.Loss7dPhoneColumn = 23;
            mapping.Loss7dTierColumn = 24;
            patched = true;
        }

        var legacyLoss7d = Activities.FirstOrDefault(a => a.Name == ActivityDefaults.Loss7dActivityLegacyName);
        if (legacyLoss7d is not null)
        {
            legacyLoss7d.Name = ActivityDefaults.Loss7dActivityName;
            patched = true;
        }

        if (Activities.Any(a => a.Kind == ActivityKind.Loss7d))
            return patched;

        var site = Sites.FirstOrDefault();
        if (site is null)
            return patched;

        var now = DateTime.Now;
        Activities.Add(new Activity
        {
            SiteId = site.Id,
            Name = ActivityDefaults.Loss7dActivityName,
            Rate = 0m,
            Divisor = 1,
            MinBonus = 1m,
            MaxBonus = 0m,
            DefaultWageringMultiplier = 1m,
            AllowProfitMember = false,
            IsEnabled = true,
            ApplyToAllSites = true,
            Kind = ActivityKind.Loss7d,
            WeeklyDayRatesJson = WeeklyDayRates.CreateLoss7dDefaults().Serialize(),
            DefaultTimezone = "Beijing",
            FilterLossMember = false,
            FilterUnclaimedEnabled = true,
            FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
            SortOrder = 3,
            CreatedAt = now,
            UpdatedAt = now,
            ColumnMapping = CreateDefaultLoss7dActivityMapping()
        });
        return true;
    }

    private bool EnsureYesterdayLossDefaults()
    {
        var patched = false;

        foreach (var mapping in ActivityColumnMappings.Where(m => m.YesterdayLossNetDiffColumn == 0))
        {
            var defaults = ColumnMappingInfo.CreateYesterdayLossDefaults();
            mapping.YesterdayLossUserIdColumn = defaults.UserIdColumn;
            mapping.YesterdayLossPayColumn = defaults.PayColumn;
            mapping.YesterdayLossWithdrawColumn = defaults.WithdrawColumn;
            mapping.YesterdayLossNetDiffColumn = defaults.NetDiffColumn;
            mapping.YesterdayLossPhoneColumn = defaults.PhoneColumn;
            mapping.YesterdayLossTierColumn = defaults.TierColumn;
            patched = true;
        }

        if (Activities.Any(a => a.Kind == ActivityKind.YesterdayLoss))
            return patched;

        var site = Sites.FirstOrDefault();
        if (site is null)
            return patched;

        var now = DateTime.Now;
        Activities.Add(new Activity
        {
            SiteId = site.Id,
            Name = ActivityDefaults.YesterdayLossActivityName,
            Rate = 0m,
            Divisor = 1,
            MinBonus = 1m,
            MaxBonus = 0m,
            DefaultWageringMultiplier = 1m,
            AllowProfitMember = false,
            IsEnabled = true,
            ApplyToAllSites = true,
            Kind = ActivityKind.YesterdayLoss,
            TieredAmountRatesJson = TieredAmountRates.CreateYesterdayLossDefaults().Serialize(),
            MinNetDiff = 20m,
            FilterLossMember = false,
            FilterUnclaimedEnabled = true,
            FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
            SortOrder = 4,
            CreatedAt = now,
            UpdatedAt = now,
            ColumnMapping = CreateDefaultYesterdayLossActivityMapping()
        });
        return true;
    }

    private bool EnsureOldCallback234Defaults()
    {
        var patched = false;
        var defaults = ColumnMappingInfo.CreateOldCallback234Defaults();

        foreach (var mapping in ActivityColumnMappings.Where(m => m.OldCallback234NetDiffColumn == 0))
        {
            var recharge = RechargeMappingConfig.CreateDefaults();
            mapping.OldCallback234UserIdColumn = defaults.UserIdColumn;
            mapping.OldCallback234PayColumn = defaults.PayColumn;
            mapping.OldCallback234WithdrawColumn = defaults.WithdrawColumn;
            mapping.OldCallback234NetDiffColumn = defaults.NetDiffColumn;
            mapping.OldCallback234InactiveDaysColumn = defaults.InactiveDaysColumn;
            mapping.OldCallback234PhoneColumn = defaults.PhoneColumn;
            mapping.OldCallback234TierColumn = defaults.TierColumn;
            mapping.RechargeUserIdColumn = recharge.UserIdColumn;
            mapping.RechargeAmountColumn = recharge.AmountColumn;
            patched = true;
        }

        foreach (var mapping in ActivityColumnMappings.Where(m =>
                     m.OldCallback234UserIdColumn == 1
                     && m.OldCallback234PhoneColumn == 19
                     && m.OldCallback234TierColumn == 20))
        {
            mapping.OldCallback234UserIdColumn = defaults.UserIdColumn;
            mapping.OldCallback234PhoneColumn = defaults.PhoneColumn;
            mapping.OldCallback234TierColumn = defaults.TierColumn;
            patched = true;
        }

        foreach (var activity in Activities.Where(a => a.Kind == ActivityKind.OldCallback234 && a.FilterRechargeEnabled))
        {
            activity.FilterRechargeEnabled = false;
            patched = true;
        }

        if (Activities.Any(a => a.Kind == ActivityKind.OldCallback234))
            return patched;

        var site = Sites.FirstOrDefault();
        if (site is null)
            return patched;

        var now = DateTime.Now;
        Activities.Add(new Activity
        {
            SiteId = site.Id,
            Name = ActivityDefaults.OldCallback234ActivityName,
            Rate = 0m,
            Divisor = 1,
            MinBonus = 1m,
            MaxBonus = 0m,
            DefaultWageringMultiplier = 1m,
            AllowProfitMember = true,
            IsEnabled = true,
            ApplyToAllSites = true,
            Kind = ActivityKind.OldCallback234,
            TieredFixedBonusesJson = TieredFixedBonuses.CreateOldCallback234Defaults().Serialize(),
            InactiveDaysMax = 7,
            FilterRechargeEnabled = false,
            FilterUnclaimedEnabled = true,
            FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
            SortOrder = 5,
            CreatedAt = now,
            UpdatedAt = now,
            ColumnMapping = CreateDefaultOldCallback234ActivityMapping()
        });
        return true;
    }

    private bool EnsureComprehensiveDefaults()
    {
        var patched = false;
        var defaults = ColumnMappingInfo.CreateComprehensiveDefaults();
        var defaultFeatures = ComprehensiveCallbackFeatures.CreateDefaults().Serialize();

        foreach (var mapping in ActivityColumnMappings.Where(m => m.ComprehensiveNetDiffColumn == 0))
        {
            mapping.ComprehensiveUserIdColumn = defaults.UserIdColumn;
            mapping.ComprehensivePayColumn = defaults.PayColumn;
            mapping.ComprehensiveWithdrawColumn = defaults.WithdrawColumn;
            mapping.ComprehensiveNetDiffColumn = defaults.NetDiffColumn;
            mapping.ComprehensiveInactiveDaysColumn = defaults.InactiveDaysColumn;
            mapping.ComprehensivePhoneColumn = defaults.PhoneColumn;
            mapping.ComprehensiveTierColumn = defaults.TierColumn;
            patched = true;
        }

        foreach (var activity in Activities.Where(a => a.Kind == ActivityKind.ComprehensiveCallback))
        {
            if (!activity.ApplyToAllSites)
            {
                activity.ApplyToAllSites = true;
                patched = true;
            }

            if (activity.SiteId is not null)
            {
                activity.SiteId = null;
                patched = true;
            }

            if (string.IsNullOrWhiteSpace(activity.ComprehensiveFeaturesJson)
                || activity.ComprehensiveFeaturesJson == "{}")
            {
                activity.ComprehensiveFeaturesJson = defaultFeatures;
                patched = true;
            }
        }

        if (Activities.Any(a => a.Kind == ActivityKind.ComprehensiveCallback))
            return patched;

        var existingByName = Activities.FirstOrDefault(a => a.Name == ActivityDefaults.ComprehensiveCallbackActivityName);
        if (existingByName is not null)
        {
            existingByName.Kind = ActivityKind.ComprehensiveCallback;
            existingByName.ApplyToAllSites = true;
            existingByName.SiteId = null;
            if (string.IsNullOrWhiteSpace(existingByName.ComprehensiveFeaturesJson)
                || existingByName.ComprehensiveFeaturesJson == "{}")
                existingByName.ComprehensiveFeaturesJson = defaultFeatures;
            return true;
        }

        var site = Sites.FirstOrDefault();
        if (site is null)
            return patched;

        var now = DateTime.Now;
        Activities.Add(new Activity
        {
            SiteId = null,
            Name = ActivityDefaults.ComprehensiveCallbackActivityName,
            Rate = 0.02m,
            Divisor = 2,
            MinBonus = 1m,
            MaxBonus = 0m,
            DefaultWageringMultiplier = 1m,
            AllowProfitMember = true,
            IsEnabled = true,
            ApplyToAllSites = true,
            Kind = ActivityKind.ComprehensiveCallback,
            ComprehensiveFeaturesJson = ComprehensiveCallbackFeatures.CreateDefaults().Serialize(),
            WeeklyDayRatesJson = WeeklyDayRates.CreateLoss7dDefaults().Serialize(),
            DefaultTimezone = "Beijing",
            TieredAmountRatesJson = TieredAmountRates.CreateYesterdayLossDefaults().Serialize(),
            TieredFixedBonusesJson = TieredFixedBonuses.CreateOldCallback234Defaults().Serialize(),
            MinNetDiff = 20m,
            InactiveDaysMax = 7,
            FilterRechargeEnabled = false,
            FilterUnclaimedEnabled = true,
            FilterTierKeywords = JsonSerializer.Serialize(ActivityDefaults.FilterTierKeywords),
            SortOrder = 6,
            CreatedAt = now,
            UpdatedAt = now,
            ColumnMapping = CreateDefaultComprehensiveActivityMapping()
        });
        return true;
    }

    private static bool IsCallbackMappingUninitialized(SiteColumnMapping mapping) =>
        mapping.CallbackPayColumn == 0 && mapping.CallbackWithdrawColumn == 0;

    public static void Initialize(string dbPath)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(dbPath)!);
        var options = AppDbContextFactory.CreateOptions(dbPath);
        using var context = new AppDbContext(options);
        RepairMigrationHistoryBeforeMigrate(context);
        context.Database.Migrate();
        context.SeedDefaultsIfEmpty();
        context.PatchLegacyDefaults();
    }

    /// <summary>
    /// 旧库升级：表已存在但 __EFMigrationsHistory 缺失对应记录时，补齐历史避免 Migrate 重复建表。
    /// </summary>
    private static void RepairMigrationHistoryBeforeMigrate(AppDbContext context)
    {
        var connection = context.Database.GetDbConnection();
        var shouldClose = connection.State != ConnectionState.Open;
        if (shouldClose)
            connection.Open();

        try
        {
            EnsureMigrationHistoryTable(connection);

            if (!SqliteTableExists(connection, "ActivityColumnMappings"))
                return;

            const string migrationId = "20260628121218_ActivityColumnMapping";
            if (MigrationHistoryContains(connection, migrationId))
                return;

            InsertMigrationHistory(connection, migrationId, GetEfProductVersion());
        }
        finally
        {
            if (shouldClose)
                connection.Close();
        }
    }

    private static void EnsureMigrationHistoryTable(IDbConnection connection)
    {
        using var command = connection.CreateCommand();
        command.CommandText = """
            CREATE TABLE IF NOT EXISTS "__EFMigrationsHistory" (
                "MigrationId" TEXT NOT NULL CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY,
                "ProductVersion" TEXT NOT NULL
            );
            """;
        command.ExecuteNonQuery();
    }

    private static bool SqliteTableExists(IDbConnection connection, string tableName)
    {
        using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT 1
            FROM sqlite_master
            WHERE type = 'table' AND name = $name
            LIMIT 1;
            """;
        var parameter = command.CreateParameter();
        parameter.ParameterName = "$name";
        parameter.Value = tableName;
        command.Parameters.Add(parameter);
        return command.ExecuteScalar() is not null;
    }

    private static bool MigrationHistoryContains(IDbConnection connection, string migrationId)
    {
        using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT 1
            FROM "__EFMigrationsHistory"
            WHERE "MigrationId" = $migrationId
            LIMIT 1;
            """;
        var parameter = command.CreateParameter();
        parameter.ParameterName = "$migrationId";
        parameter.Value = migrationId;
        command.Parameters.Add(parameter);
        return command.ExecuteScalar() is not null;
    }

    private static void InsertMigrationHistory(IDbConnection connection, string migrationId, string productVersion)
    {
        using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
            VALUES ($migrationId, $productVersion);
            """;
        var migrationIdParameter = command.CreateParameter();
        migrationIdParameter.ParameterName = "$migrationId";
        migrationIdParameter.Value = migrationId;
        command.Parameters.Add(migrationIdParameter);

        var productVersionParameter = command.CreateParameter();
        productVersionParameter.ParameterName = "$productVersion";
        productVersionParameter.Value = productVersion;
        command.Parameters.Add(productVersionParameter);

        command.ExecuteNonQuery();
    }

    private static string GetEfProductVersion() => ProductInfo.GetVersion();
}

public class AppDbContextFactory : IDbContextFactory<AppDbContext>, IDesignTimeDbContextFactory<AppDbContext>
{
    private readonly string _dbPath;

    public AppDbContextFactory() : this(GetDefaultDbPath())
    {
    }

    public AppDbContextFactory(string dbPath)
    {
        _dbPath = dbPath;
    }

    public AppDbContext CreateDbContext() => new(CreateOptions(_dbPath));

    public AppDbContext CreateDbContext(string[] args)
    {
        var dbPath = args.Length > 0 ? args[0] : GetDefaultDbPath();
        return new AppDbContext(CreateOptions(dbPath));
    }

    public static DbContextOptions<AppDbContext> CreateOptions(string dbPath)
    {
        return new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlite($"Data Source={dbPath}")
            .Options;
    }

    private static string GetDefaultDbPath()
    {
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DHPG");
        return Path.Combine(dir, "dhpg.db");
    }
}

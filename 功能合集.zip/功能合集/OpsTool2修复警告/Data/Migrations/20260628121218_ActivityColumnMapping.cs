﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DHPG.Data.Migrations
{
    /// <inheritdoc />
    public partial class ActivityColumnMapping : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // 旧库可能已有 ActivityColumnMappings（迁移历史丢失或中断），使用 IF NOT EXISTS 避免重复建表失败。
            migrationBuilder.Sql("""
                CREATE TABLE IF NOT EXISTS "ActivityColumnMappings" (
                    "Id" INTEGER NOT NULL CONSTRAINT "PK_ActivityColumnMappings" PRIMARY KEY AUTOINCREMENT,
                    "ActivityId" INTEGER NOT NULL,
                    "UserIdColumn" INTEGER NOT NULL,
                    "PayColumn" INTEGER NOT NULL,
                    "WithdrawColumn" INTEGER NOT NULL,
                    "PhoneColumn" INTEGER NOT NULL,
                    "TierColumn" INTEGER NOT NULL,
                    "HeaderRow" INTEGER NOT NULL,
                    "CallbackUserIdColumn" INTEGER NOT NULL,
                    "CallbackPayColumn" INTEGER NOT NULL,
                    "CallbackWithdrawColumn" INTEGER NOT NULL,
                    "CallbackPhoneColumn" INTEGER NOT NULL,
                    "CallbackTierColumn" INTEGER NOT NULL,
                    "CallbackHeaderRow" INTEGER NOT NULL,
                    "UnclaimedUserIdColumn" INTEGER NOT NULL,
                    CONSTRAINT "FK_ActivityColumnMappings_Activities_ActivityId"
                        FOREIGN KEY ("ActivityId") REFERENCES "Activities" ("Id") ON DELETE CASCADE
                );
                """);

            migrationBuilder.Sql("""
                CREATE UNIQUE INDEX IF NOT EXISTS "IX_ActivityColumnMappings_ActivityId"
                ON "ActivityColumnMappings" ("ActivityId");
                """);

            migrationBuilder.Sql("""
                INSERT INTO ActivityColumnMappings (
                    ActivityId,
                    UserIdColumn,
                    PayColumn,
                    WithdrawColumn,
                    PhoneColumn,
                    TierColumn,
                    HeaderRow,
                    CallbackUserIdColumn,
                    CallbackPayColumn,
                    CallbackWithdrawColumn,
                    CallbackPhoneColumn,
                    CallbackTierColumn,
                    CallbackHeaderRow,
                    UnclaimedUserIdColumn)
                SELECT
                    a.Id,
                    COALESCE(m.UserIdColumn, 0),
                    COALESCE(m.PayColumn, 5),
                    COALESCE(m.WithdrawColumn, 7),
                    COALESCE(m.PhoneColumn, 17),
                    COALESCE(m.TierColumn, 21),
                    COALESCE(m.HeaderRow, 0),
                    COALESCE(m.CallbackUserIdColumn, 5),
                    COALESCE(m.CallbackPayColumn, 8),
                    COALESCE(m.CallbackWithdrawColumn, 9),
                    COALESCE(m.CallbackPhoneColumn, 23),
                    COALESCE(m.CallbackTierColumn, 24),
                    COALESCE(m.CallbackHeaderRow, 0),
                    COALESCE(m.UnclaimedUserIdColumn, 1)
                FROM Activities a
                LEFT JOIN (
                    SELECT *
                    FROM SiteColumnMappings
                    ORDER BY Id
                    LIMIT 1
                ) m ON 1 = 1
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM ActivityColumnMappings existing
                    WHERE existing.ActivityId = a.Id);
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ActivityColumnMappings");
        }
    }
}

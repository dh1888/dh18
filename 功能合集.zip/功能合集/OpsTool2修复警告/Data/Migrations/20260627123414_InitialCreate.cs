﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DHPG.Data.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AppSettings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ExportDirectory = table.Column<string>(type: "TEXT", maxLength: 500, nullable: false),
                    DefaultWageringMultiplier = table.Column<decimal>(type: "TEXT", precision: 18, scale: 2, nullable: false),
                    DefaultAppRemark = table.Column<string>(type: "TEXT", maxLength: 500, nullable: false),
                    DefaultBackendRemark = table.Column<string>(type: "TEXT", maxLength: 500, nullable: false),
                    Theme = table.Column<string>(type: "TEXT", maxLength: 20, nullable: false),
                    LogLevel = table.Column<string>(type: "TEXT", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppSettings", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Sites",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false),
                    Code = table.Column<string>(type: "TEXT", maxLength: 50, nullable: false),
                    Remark = table.Column<string>(type: "TEXT", maxLength: 500, nullable: true),
                    IsEnabled = table.Column<bool>(type: "INTEGER", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sites", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Activities",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    SiteId = table.Column<int>(type: "INTEGER", nullable: false),
                    Name = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false),
                    Rate = table.Column<decimal>(type: "TEXT", precision: 18, scale: 4, nullable: false),
                    Divisor = table.Column<int>(type: "INTEGER", nullable: false),
                    MinBonus = table.Column<decimal>(type: "TEXT", precision: 18, scale: 2, nullable: false),
                    MaxBonus = table.Column<decimal>(type: "TEXT", precision: 18, scale: 2, nullable: false),
                    DefaultWageringMultiplier = table.Column<decimal>(type: "TEXT", precision: 18, scale: 2, nullable: false),
                    AppRemark = table.Column<string>(type: "TEXT", maxLength: 500, nullable: false),
                    BackendRemark = table.Column<string>(type: "TEXT", maxLength: 500, nullable: false),
                    AllowProfitMember = table.Column<bool>(type: "INTEGER", nullable: false),
                    IsEnabled = table.Column<bool>(type: "INTEGER", nullable: false),
                    FilterTierKeywords = table.Column<string>(type: "TEXT", nullable: false),
                    SortOrder = table.Column<int>(type: "INTEGER", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Activities", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Activities_Sites_SiteId",
                        column: x => x.SiteId,
                        principalTable: "Sites",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SiteColumnMappings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    SiteId = table.Column<int>(type: "INTEGER", nullable: false),
                    UserIdColumn = table.Column<int>(type: "INTEGER", nullable: false),
                    PayColumn = table.Column<int>(type: "INTEGER", nullable: false),
                    WithdrawColumn = table.Column<int>(type: "INTEGER", nullable: false),
                    PhoneColumn = table.Column<int>(type: "INTEGER", nullable: false),
                    TierColumn = table.Column<int>(type: "INTEGER", nullable: false),
                    HeaderRow = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SiteColumnMappings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SiteColumnMappings_Sites_SiteId",
                        column: x => x.SiteId,
                        principalTable: "Sites",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProcessHistories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ProcessedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    SiteId = table.Column<int>(type: "INTEGER", nullable: true),
                    SiteName = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false),
                    ActivityId = table.Column<int>(type: "INTEGER", nullable: true),
                    ActivityName = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false),
                    TotalCount = table.Column<int>(type: "INTEGER", nullable: false),
                    FilteredCount = table.Column<int>(type: "INTEGER", nullable: false),
                    RewardCount = table.Column<int>(type: "INTEGER", nullable: false),
                    TotalBonus = table.Column<decimal>(type: "TEXT", precision: 18, scale: 2, nullable: false),
                    SnapshotJson = table.Column<string>(type: "TEXT", nullable: false),
                    ExportFilePath = table.Column<string>(type: "TEXT", maxLength: 500, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProcessHistories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProcessHistories_Activities_ActivityId",
                        column: x => x.ActivityId,
                        principalTable: "Activities",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "FK_ProcessHistories_Sites_SiteId",
                        column: x => x.SiteId,
                        principalTable: "Sites",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Activities_SiteId",
                table: "Activities",
                column: "SiteId");

            migrationBuilder.CreateIndex(
                name: "IX_Activities_SiteId_IsEnabled",
                table: "Activities",
                columns: new[] { "SiteId", "IsEnabled" });

            migrationBuilder.CreateIndex(
                name: "IX_Activities_SiteId_Name",
                table: "Activities",
                columns: new[] { "SiteId", "Name" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProcessHistories_ActivityId",
                table: "ProcessHistories",
                column: "ActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_ProcessHistories_ProcessedAt",
                table: "ProcessHistories",
                column: "ProcessedAt");

            migrationBuilder.CreateIndex(
                name: "IX_ProcessHistories_SiteId",
                table: "ProcessHistories",
                column: "SiteId");

            migrationBuilder.CreateIndex(
                name: "IX_SiteColumnMappings_SiteId",
                table: "SiteColumnMappings",
                column: "SiteId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Sites_Code",
                table: "Sites",
                column: "Code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Sites_IsEnabled",
                table: "Sites",
                column: "IsEnabled");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AppSettings");

            migrationBuilder.DropTable(
                name: "ProcessHistories");

            migrationBuilder.DropTable(
                name: "SiteColumnMappings");

            migrationBuilder.DropTable(
                name: "Activities");

            migrationBuilder.DropTable(
                name: "Sites");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DHPG.Data.Migrations
{
    /// <inheritdoc />
    public partial class Loss7dActivity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Loss7dDepositColumn",
                table: "ActivityColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Loss7dHeaderRow",
                table: "ActivityColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Loss7dPhoneColumn",
                table: "ActivityColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Loss7dTierColumn",
                table: "ActivityColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Loss7dUserIdColumn",
                table: "ActivityColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Loss7dWithdrawColumn",
                table: "ActivityColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "DefaultTimezone",
                table: "Activities",
                type: "TEXT",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "FilterLossMember",
                table: "Activities",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "FilterUnclaimedEnabled",
                table: "Activities",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "Kind",
                table: "Activities",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "WeeklyDayRatesJson",
                table: "Activities",
                type: "TEXT",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Loss7dDepositColumn",
                table: "ActivityColumnMappings");

            migrationBuilder.DropColumn(
                name: "Loss7dHeaderRow",
                table: "ActivityColumnMappings");

            migrationBuilder.DropColumn(
                name: "Loss7dPhoneColumn",
                table: "ActivityColumnMappings");

            migrationBuilder.DropColumn(
                name: "Loss7dTierColumn",
                table: "ActivityColumnMappings");

            migrationBuilder.DropColumn(
                name: "Loss7dUserIdColumn",
                table: "ActivityColumnMappings");

            migrationBuilder.DropColumn(
                name: "Loss7dWithdrawColumn",
                table: "ActivityColumnMappings");

            migrationBuilder.DropColumn(
                name: "DefaultTimezone",
                table: "Activities");

            migrationBuilder.DropColumn(
                name: "FilterLossMember",
                table: "Activities");

            migrationBuilder.DropColumn(
                name: "FilterUnclaimedEnabled",
                table: "Activities");

            migrationBuilder.DropColumn(
                name: "Kind",
                table: "Activities");

            migrationBuilder.DropColumn(
                name: "WeeklyDayRatesJson",
                table: "Activities");
        }
    }
}

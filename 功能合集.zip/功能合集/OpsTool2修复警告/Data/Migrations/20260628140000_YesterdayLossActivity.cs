using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DHPG.Data.Migrations;

/// <inheritdoc />
public partial class YesterdayLossActivity : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<decimal>(
            name: "MinNetDiff",
            table: "Activities",
            type: "TEXT",
            nullable: false,
            defaultValue: 20m);

        migrationBuilder.AddColumn<string>(
            name: "TieredAmountRatesJson",
            table: "Activities",
            type: "TEXT",
            nullable: false,
            defaultValue: "{}");

        migrationBuilder.AddColumn<int>(
            name: "YesterdayLossHeaderRow",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 0);

        migrationBuilder.AddColumn<int>(
            name: "YesterdayLossNetDiffColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 18);

        migrationBuilder.AddColumn<int>(
            name: "YesterdayLossPayColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 11);

        migrationBuilder.AddColumn<int>(
            name: "YesterdayLossPhoneColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 19);

        migrationBuilder.AddColumn<int>(
            name: "YesterdayLossTierColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 20);

        migrationBuilder.AddColumn<int>(
            name: "YesterdayLossUserIdColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 1);

        migrationBuilder.AddColumn<int>(
            name: "YesterdayLossWithdrawColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 12);
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropColumn(name: "MinNetDiff", table: "Activities");
        migrationBuilder.DropColumn(name: "TieredAmountRatesJson", table: "Activities");
        migrationBuilder.DropColumn(name: "YesterdayLossHeaderRow", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "YesterdayLossNetDiffColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "YesterdayLossPayColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "YesterdayLossPhoneColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "YesterdayLossTierColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "YesterdayLossUserIdColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "YesterdayLossWithdrawColumn", table: "ActivityColumnMappings");
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DHPG.Data.Migrations
{
    /// <inheritdoc />
    public partial class SiteMappingAndActivitySites : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Activities_Sites_SiteId",
                table: "Activities");

            migrationBuilder.DropIndex(
                name: "IX_Activities_SiteId_IsEnabled",
                table: "Activities");

            migrationBuilder.DropIndex(
                name: "IX_Activities_SiteId_Name",
                table: "Activities");

            migrationBuilder.AddColumn<int>(
                name: "CallbackHeaderRow",
                table: "SiteColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CallbackPayColumn",
                table: "SiteColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CallbackPhoneColumn",
                table: "SiteColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CallbackTierColumn",
                table: "SiteColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CallbackUserIdColumn",
                table: "SiteColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CallbackWithdrawColumn",
                table: "SiteColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "UnclaimedUserIdColumn",
                table: "SiteColumnMappings",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<int>(
                name: "SiteId",
                table: "Activities",
                type: "INTEGER",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "INTEGER");

            migrationBuilder.AddColumn<bool>(
                name: "ApplyToAllSites",
                table: "Activities",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "ActivitySiteLinks",
                columns: table => new
                {
                    ActivityId = table.Column<int>(type: "INTEGER", nullable: false),
                    SiteId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActivitySiteLinks", x => new { x.ActivityId, x.SiteId });
                    table.ForeignKey(
                        name: "FK_ActivitySiteLinks_Activities_ActivityId",
                        column: x => x.ActivityId,
                        principalTable: "Activities",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ActivitySiteLinks_Sites_SiteId",
                        column: x => x.SiteId,
                        principalTable: "Sites",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Activities_IsEnabled",
                table: "Activities",
                column: "IsEnabled");

            migrationBuilder.CreateIndex(
                name: "IX_Activities_Name",
                table: "Activities",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ActivitySiteLinks_SiteId",
                table: "ActivitySiteLinks",
                column: "SiteId");

            migrationBuilder.AddForeignKey(
                name: "FK_Activities_Sites_SiteId",
                table: "Activities",
                column: "SiteId",
                principalTable: "Sites",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Activities_Sites_SiteId",
                table: "Activities");

            migrationBuilder.DropTable(
                name: "ActivitySiteLinks");

            migrationBuilder.DropIndex(
                name: "IX_Activities_IsEnabled",
                table: "Activities");

            migrationBuilder.DropIndex(
                name: "IX_Activities_Name",
                table: "Activities");

            migrationBuilder.DropColumn(
                name: "CallbackHeaderRow",
                table: "SiteColumnMappings");

            migrationBuilder.DropColumn(
                name: "CallbackPayColumn",
                table: "SiteColumnMappings");

            migrationBuilder.DropColumn(
                name: "CallbackPhoneColumn",
                table: "SiteColumnMappings");

            migrationBuilder.DropColumn(
                name: "CallbackTierColumn",
                table: "SiteColumnMappings");

            migrationBuilder.DropColumn(
                name: "CallbackUserIdColumn",
                table: "SiteColumnMappings");

            migrationBuilder.DropColumn(
                name: "CallbackWithdrawColumn",
                table: "SiteColumnMappings");

            migrationBuilder.DropColumn(
                name: "UnclaimedUserIdColumn",
                table: "SiteColumnMappings");

            migrationBuilder.DropColumn(
                name: "ApplyToAllSites",
                table: "Activities");

            migrationBuilder.AlterColumn<int>(
                name: "SiteId",
                table: "Activities",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "INTEGER",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Activities_SiteId_IsEnabled",
                table: "Activities",
                columns: new[] { "SiteId", "IsEnabled" });

            migrationBuilder.CreateIndex(
                name: "IX_Activities_SiteId_Name",
                table: "Activities",
                columns: new[] { "SiteId", "Name" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Activities_Sites_SiteId",
                table: "Activities",
                column: "SiteId",
                principalTable: "Sites",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}

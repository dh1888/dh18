using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DHPG.Data.Migrations;

/// <inheritdoc />
public partial class ComprehensiveCallbackActivity : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<string>(
            name: "ComprehensiveFeaturesJson",
            table: "Activities",
            type: "TEXT",
            nullable: false,
            defaultValue: "{}");

        migrationBuilder.AddColumn<int>(
            name: "ComprehensiveHeaderRow",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 0);

        migrationBuilder.AddColumn<int>(
            name: "ComprehensiveInactiveDaysColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 16);

        migrationBuilder.AddColumn<int>(
            name: "ComprehensiveNetDiffColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 8);

        migrationBuilder.AddColumn<int>(
            name: "ComprehensivePayColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 5);

        migrationBuilder.AddColumn<int>(
            name: "ComprehensivePhoneColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 17);

        migrationBuilder.AddColumn<int>(
            name: "ComprehensiveTierColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 21);

        migrationBuilder.AddColumn<int>(
            name: "ComprehensiveUserIdColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 0);

        migrationBuilder.AddColumn<int>(
            name: "ComprehensiveWithdrawColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 7);
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropColumn(name: "ComprehensiveFeaturesJson", table: "Activities");
        migrationBuilder.DropColumn(name: "ComprehensiveHeaderRow", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "ComprehensiveInactiveDaysColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "ComprehensiveNetDiffColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "ComprehensivePayColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "ComprehensivePhoneColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "ComprehensiveTierColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "ComprehensiveUserIdColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "ComprehensiveWithdrawColumn", table: "ActivityColumnMappings");
    }
}

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DHPG.Data.Migrations;

/// <inheritdoc />
public partial class OldCallback234Activity : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<bool>(
            name: "FilterRechargeEnabled",
            table: "Activities",
            type: "INTEGER",
            nullable: false,
            defaultValue: false);

        migrationBuilder.AddColumn<int>(
            name: "InactiveDaysMax",
            table: "Activities",
            type: "INTEGER",
            nullable: false,
            defaultValue: 7);

        migrationBuilder.AddColumn<string>(
            name: "TieredFixedBonusesJson",
            table: "Activities",
            type: "TEXT",
            nullable: false,
            defaultValue: "{}");

        migrationBuilder.AddColumn<bool>(
            name: "UseNetDiffColumn",
            table: "Activities",
            type: "INTEGER",
            nullable: false,
            defaultValue: false);

        migrationBuilder.AddColumn<int>(
            name: "OldCallback234HeaderRow",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 0);

        migrationBuilder.AddColumn<int>(
            name: "OldCallback234InactiveDaysColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 16);

        migrationBuilder.AddColumn<int>(
            name: "OldCallback234NetDiffColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 8);

        migrationBuilder.AddColumn<int>(
            name: "OldCallback234PayColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 5);

        migrationBuilder.AddColumn<int>(
            name: "OldCallback234PhoneColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 17);

        migrationBuilder.AddColumn<int>(
            name: "OldCallback234TierColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 21);

        migrationBuilder.AddColumn<int>(
            name: "OldCallback234UserIdColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 0);

        migrationBuilder.AddColumn<int>(
            name: "OldCallback234WithdrawColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 7);

        migrationBuilder.AddColumn<int>(
            name: "RechargeAmountColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 5);

        migrationBuilder.AddColumn<int>(
            name: "RechargeHeaderRow",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 0);

        migrationBuilder.AddColumn<int>(
            name: "RechargeUserIdColumn",
            table: "ActivityColumnMappings",
            type: "INTEGER",
            nullable: false,
            defaultValue: 1);
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropColumn(name: "FilterRechargeEnabled", table: "Activities");
        migrationBuilder.DropColumn(name: "InactiveDaysMax", table: "Activities");
        migrationBuilder.DropColumn(name: "TieredFixedBonusesJson", table: "Activities");
        migrationBuilder.DropColumn(name: "UseNetDiffColumn", table: "Activities");
        migrationBuilder.DropColumn(name: "OldCallback234HeaderRow", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "OldCallback234InactiveDaysColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "OldCallback234NetDiffColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "OldCallback234PayColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "OldCallback234PhoneColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "OldCallback234TierColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "OldCallback234UserIdColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "OldCallback234WithdrawColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "RechargeAmountColumn", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "RechargeHeaderRow", table: "ActivityColumnMappings");
        migrationBuilder.DropColumn(name: "RechargeUserIdColumn", table: "ActivityColumnMappings");
    }
}

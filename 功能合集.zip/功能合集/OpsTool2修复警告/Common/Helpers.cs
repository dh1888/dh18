using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace DHPG.Common;

public static class Helpers
{
    private static bool _encodingRegistered;

    public static string AppDataDir =>
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DHPG");

    public static void EnsureExcelEncoding()
    {
        if (_encodingRegistered)
            return;

        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        _encodingRegistered = true;
    }

    public static long? TryParseUserId(object? value)
    {
        if (value is null)
            return null;

        return value switch
        {
            long l => l,
            int i => i,
            double d when d >= 1 && Math.Abs(d - Math.Round(d)) < 0.000001 => (long)Math.Round(d),
            decimal m when m >= 1 && m == Math.Truncate(m) => (long)m,
            string s => TryParseUserIdFromString(s),
            _ => TryParseUserIdFromString(value.ToString())
        };
    }

    public static decimal ParseAmount(object? value)
    {
        if (value is null)
            return 0m;

        return value switch
        {
            decimal d => Math.Round(d, 2, MidpointRounding.AwayFromZero),
            double d => Math.Round((decimal)d, 2, MidpointRounding.AwayFromZero),
            float f => Math.Round((decimal)f, 2, MidpointRounding.AwayFromZero),
            int i => i,
            long l => l,
            string s => ParseAmountFromString(s),
            _ => ParseAmountFromString(value.ToString())
        };
    }

    public static string? TryParseString(object? value)
    {
        if (value is null)
            return null;

        var text = value.ToString()?.Trim();
        return string.IsNullOrEmpty(text) ? null : text;
    }

    public static string? GetField(IReadOnlyList<string?> fields, int index)
    {
        if (index < 0 || index >= fields.Count)
            return null;

        var text = fields[index]?.Trim();
        return string.IsNullOrEmpty(text) ? null : text;
    }

    public static string NormalizeDecimalString(string input)
    {
        var text = input.Trim();
        if (text.Length == 0)
            return text;

        text = text.Replace("\uFEFF", string.Empty).Replace(" ", string.Empty);

        var lastComma = text.LastIndexOf(',');
        var lastDot = text.LastIndexOf('.');

        if (lastComma >= 0 && lastDot >= 0)
        {
            if (lastComma > lastDot)
                text = text.Replace(".", string.Empty).Replace(',', '.');
            else
                text = text.Replace(",", string.Empty);
        }
        else if (lastComma >= 0)
        {
            var parts = text.Split(',');
            text = parts.Length > 1 && parts[^1].Length <= 2
                ? string.Join('.', parts)
                : text.Replace(",", string.Empty);
        }

        return text;
    }

    private static long? TryParseUserIdFromString(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return null;

        text = text.Trim().Replace("\uFEFF", string.Empty);
        text = Regex.Replace(text, @"[,\s]", string.Empty);
        if (text.EndsWith(".0", StringComparison.Ordinal))
            text = text[..^2];

        if (long.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var id))
            return id;

        if (decimal.TryParse(NormalizeDecimalString(text), NumberStyles.Number, CultureInfo.InvariantCulture, out var dec)
            && dec >= 1 && dec == Math.Truncate(dec))
            return (long)dec;

        return null;
    }

    private static decimal ParseAmountFromString(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return 0m;

        text = NormalizeDecimalString(text);
        return decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out var amount)
            ? Math.Round(amount, 2, MidpointRounding.AwayFromZero)
            : 0m;
    }
}

/// <summary>HandyControl 浅色/深色主题切换</summary>
public static class ThemeManager
{
    private const string LightSkinUri = "pack://application:,,,/HandyControl;component/Themes/SkinDefault.xaml";
    private const string DarkSkinUri = "pack://application:,,,/HandyControl;component/Themes/SkinDark.xaml";
    private const string LightModernThemeUri = "Themes/ModernTheme.xaml";
    private const string DarkModernThemeUri = "Themes/ModernThemeDark.xaml";
    private const int SkinDictionaryIndex = 0;
    private const int ModernThemeDictionaryIndex = 2;

    public static string CurrentTheme { get; private set; } = "Light";

    public static void Apply(string theme)
    {
        var isDark = string.Equals(theme, "Dark", StringComparison.OrdinalIgnoreCase);
        CurrentTheme = isDark ? "Dark" : "Light";

        if (Application.Current.Resources is not ResourceDictionary root)
            return;

        ReplaceMergedDictionary(root, SkinDictionaryIndex,
            new ResourceDictionary { Source = new Uri(isDark ? DarkSkinUri : LightSkinUri, UriKind.Absolute) });

        if (root.MergedDictionaries.Count > ModernThemeDictionaryIndex)
        {
            ReplaceMergedDictionary(root, ModernThemeDictionaryIndex,
                new ResourceDictionary
                {
                    Source = new Uri(isDark ? DarkModernThemeUri : LightModernThemeUri, UriKind.Relative)
                });
        }

        RefreshOpenWindows();
    }

    private static void ReplaceMergedDictionary(ResourceDictionary root, int index, ResourceDictionary dictionary)
    {
        if (root.MergedDictionaries.Count <= index)
            return;

        root.MergedDictionaries.RemoveAt(index);
        root.MergedDictionaries.Insert(index, dictionary);
    }

    private static void RefreshOpenWindows()
    {
        foreach (Window window in Application.Current.Windows)
        {
            if (window is null)
                continue;

            window.UpdateDefaultStyle();
            window.InvalidateProperty(Control.BackgroundProperty);
            window.InvalidateVisual();
        }
    }
}

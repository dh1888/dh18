using System.Text.Json;
using System.Text.Json.Serialization;

namespace DHPG.Common;

public enum ActivityKind
{
    Period = 0,
    Callback = 1,
    Loss7d = 2,
    YesterdayLoss = 3,
    OldCallback234 = 4,
    ComprehensiveCallback = 5
}

/// <summary>综合回访：彩金计算方式（五选一）</summary>
public enum ComprehensiveBonusMode
{
    StandardMerged = 0,
    StandardSplit = 1,
    Loss7dWeekly = 2,
    YesterdayLossTiered = 3,
    OldCallback234Fixed = 4
}

/// <summary>综合回访：可组合的过滤与计算开关</summary>
public class ComprehensiveCallbackFeatures
{
    public ComprehensiveBonusMode BonusMode { get; set; } = ComprehensiveBonusMode.StandardSplit;
    public bool EnableInactiveDaysFilter { get; set; }
    public bool EnableMinNetDiffGate { get; set; }

    public static ComprehensiveCallbackFeatures CreateDefaults() => new()
    {
        BonusMode = ComprehensiveBonusMode.StandardSplit,
        EnableInactiveDaysFilter = false,
        EnableMinNetDiffGate = false
    };

    public static ComprehensiveCallbackFeatures Deserialize(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return CreateDefaults();

        try
        {
            return JsonSerializer.Deserialize<ComprehensiveCallbackFeatures>(json, JsonOptions)
                ?? CreateDefaults();
        }
        catch
        {
            return CreateDefaults();
        }
    }

    public string Serialize() => JsonSerializer.Serialize(this, JsonOptions);

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };
}

public enum ActivityTimezone
{
    Beijing,
    Brazil
}

/// <summary>近7日亏损回访：周一～周日比例（null 表示未配置）</summary>
public class WeeklyDayRates
{
    public decimal? Monday { get; set; }
    public decimal? Tuesday { get; set; }
    public decimal? Wednesday { get; set; }
    public decimal? Thursday { get; set; }
    public decimal? Friday { get; set; }
    public decimal? Saturday { get; set; }
    public decimal? Sunday { get; set; }

    public static WeeklyDayRates CreateLoss7dDefaults() => new()
    {
        Monday = 0.001m,
        Friday = 0.005m,
        Saturday = 0.004m,
        Sunday = 0.003m
    };

    public decimal? GetRate(DayOfWeek dayOfWeek) => dayOfWeek switch
    {
        DayOfWeek.Monday => Monday,
        DayOfWeek.Tuesday => Tuesday,
        DayOfWeek.Wednesday => Wednesday,
        DayOfWeek.Thursday => Thursday,
        DayOfWeek.Friday => Friday,
        DayOfWeek.Saturday => Saturday,
        DayOfWeek.Sunday => Sunday,
        _ => null
    };

    public static WeeklyDayRates Deserialize(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return new WeeklyDayRates();

        try
        {
            return JsonSerializer.Deserialize<WeeklyDayRates>(json, JsonOptions) ?? new WeeklyDayRates();
        }
        catch
        {
            return new WeeklyDayRates();
        }
    }

    public string Serialize() => JsonSerializer.Serialize(this, JsonOptions);

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };
}

/// <summary>昨日亏损：按充提差区间派送比例</summary>
public class AmountRateTier
{
    public decimal MinAmount { get; set; }
    public decimal? MaxAmount { get; set; }
    public decimal Rate { get; set; }
}

public class TieredAmountRates
{
    public List<AmountRateTier> Tiers { get; set; } = new();

    public static TieredAmountRates CreateYesterdayLossDefaults() => new()
    {
        Tiers =
        [
            new AmountRateTier { MinAmount = 20m, MaxAmount = 500m, Rate = 0.015m },
            new AmountRateTier { MinAmount = 501m, MaxAmount = 2000m, Rate = 0.02m },
            new AmountRateTier { MinAmount = 2001m, MaxAmount = 5000m, Rate = 0.03m },
            new AmountRateTier { MinAmount = 5001m, MaxAmount = 20000m, Rate = 0.04m }
        ]
    };

    public decimal? ResolveRate(decimal amount)
    {
        foreach (var tier in Tiers.OrderBy(t => t.MinAmount))
        {
            if (amount < tier.MinAmount)
                continue;
            if (tier.MaxAmount is null || amount <= tier.MaxAmount.Value)
                return tier.Rate;
        }

        return null;
    }

    public static TieredAmountRates Deserialize(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return new TieredAmountRates();

        try
        {
            return JsonSerializer.Deserialize<TieredAmountRates>(json, JsonOptions) ?? new TieredAmountRates();
        }
        catch
        {
            return new TieredAmountRates();
        }
    }

    public string Serialize() => JsonSerializer.Serialize(this, JsonOptions);

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };
}

/// <summary>老回访234：按亏损金额区间派送固定彩金</summary>
public class FixedBonusTier
{
    public decimal MinAmount { get; set; }
    public decimal? MaxAmount { get; set; }
    public decimal Bonus { get; set; }
}

public class TieredFixedBonuses
{
    public List<FixedBonusTier> Tiers { get; set; } = new();

    public static TieredFixedBonuses CreateOldCallback234Defaults() => new()
    {
        Tiers =
        [
            new FixedBonusTier { MinAmount = 1m, MaxAmount = 19m, Bonus = 0.3m },
            new FixedBonusTier { MinAmount = 20m, MaxAmount = 99m, Bonus = 0.5m },
            new FixedBonusTier { MinAmount = 100m, MaxAmount = 199m, Bonus = 0.6m },
            new FixedBonusTier { MinAmount = 200m, MaxAmount = 499m, Bonus = 1m },
            new FixedBonusTier { MinAmount = 500m, MaxAmount = 999m, Bonus = 1.5m },
            new FixedBonusTier { MinAmount = 1000m, MaxAmount = 4999m, Bonus = 3m },
            new FixedBonusTier { MinAmount = 5000m, MaxAmount = 9999m, Bonus = 5m },
            new FixedBonusTier { MinAmount = 10000m, MaxAmount = 49999m, Bonus = 8m },
            new FixedBonusTier { MinAmount = 50000m, MaxAmount = 100000m, Bonus = 10m },
            new FixedBonusTier { MinAmount = 100000m, MaxAmount = null, Bonus = 30m }
        ]
    };

    public decimal? ResolveBonus(decimal lossAmount)
    {
        foreach (var tier in Tiers.OrderBy(t => t.MinAmount))
        {
            if (lossAmount < tier.MinAmount)
                continue;
            if (tier.MaxAmount is null || lossAmount <= tier.MaxAmount.Value)
                return tier.Bonus;
        }

        return null;
    }

    public static TieredFixedBonuses Deserialize(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return new TieredFixedBonuses();

        try
        {
            return JsonSerializer.Deserialize<TieredFixedBonuses>(json, JsonOptions) ?? new TieredFixedBonuses();
        }
        catch
        {
            return new TieredFixedBonuses();
        }
    }

    public string Serialize() => JsonSerializer.Serialize(this, JsonOptions);

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };
}

public static class ActivityTimezoneHelper
{
    private static readonly TimeZoneInfo BeijingZone =
        TimeZoneInfo.FindSystemTimeZoneById(
            OperatingSystem.IsWindows() ? "China Standard Time" : "Asia/Shanghai");

    private static readonly TimeZoneInfo BrazilZone =
        TimeZoneInfo.FindSystemTimeZoneById(
            OperatingSystem.IsWindows() ? "E. South America Standard Time" : "America/Sao_Paulo");

    public static DateOnly TodayInTimezone(ActivityTimezone timezone)
    {
        var zone = timezone == ActivityTimezone.Brazil ? BrazilZone : BeijingZone;
        var local = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, zone);
        return DateOnly.FromDateTime(local);
    }

    public static DateOnly ResolveCalculationDate(DateOnly? input, ActivityTimezone timezone) =>
        input ?? TodayInTimezone(timezone);

    public static string FormatTimezone(ActivityTimezone timezone) =>
        timezone == ActivityTimezone.Brazil ? "巴西时间" : "北京时间";

    public static string FormatWeekday(DayOfWeek day) => day switch
    {
        DayOfWeek.Monday => "周一",
        DayOfWeek.Tuesday => "周二",
        DayOfWeek.Wednesday => "周三",
        DayOfWeek.Thursday => "周四",
        DayOfWeek.Friday => "周五",
        DayOfWeek.Saturday => "周六",
        DayOfWeek.Sunday => "周日",
        _ => day.ToString()
    };
}

namespace DHPG.Common;

public enum BatchPageModeDto
{
    Period,
    Callback,
    Loss7d,
    YesterdayLoss,
    OldCallback234,
    ComprehensiveCallback
}

public sealed class BatchBootstrapDto
{
    public BatchPageModeDto Mode { get; set; }
    public int ActivityId { get; set; }
    public string ActivityName { get; set; } = string.Empty;
    public string RuleFormula { get; set; } = string.Empty;
    public ActivityRuleDto ActivityRule { get; set; } = new();
    public bool UsesSplitRewards { get; set; }
    public BatchDefaultsDto Defaults { get; set; } = new();
    public SiteMappingConfig ActivityMapping { get; set; } = new();
    public ActivityKind ActivityKind { get; set; }
    public WeeklyDayRates WeeklyDayRates { get; set; } = new();
    public ActivityTimezone DefaultTimezone { get; set; } = ActivityTimezone.Beijing;
    public string DefaultCalculationDate { get; set; } = string.Empty;
    public bool FilterLossMember { get; set; }
    public bool FilterUnclaimedEnabled { get; set; } = true;
    public decimal MinNetDiff { get; set; } = 20m;
    public TieredAmountRates TieredAmountRates { get; set; } = new();
    public int InactiveDaysMax { get; set; } = 7;
    public bool UseNetDiffColumn { get; set; }
    public bool FilterRechargeEnabled { get; set; }
    public TieredFixedBonuses TieredFixedBonuses { get; set; } = new();
    public ComprehensiveCallbackFeatures ComprehensiveFeatures { get; set; } = new();
    public List<SiteListItem> Sites { get; set; } = new();
}

public sealed class ActivityRuleDto
{
    public decimal Rate { get; set; }
    public int Divisor { get; set; }
    public decimal MinBonus { get; set; }
    public decimal MaxBonus { get; set; }
    public bool AllowProfitMember { get; set; }
}

public sealed class BatchDefaultsDto
{
    public bool FilterUnclaimed { get; set; }
    public bool FilterRecharge { get; set; }
    public bool IncludeProfitMember { get; set; }
    public decimal WageringMultiplier { get; set; }
    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;
    public string? CalculationDate { get; set; }
    public ActivityTimezone Timezone { get; set; } = ActivityTimezone.Beijing;
}

public sealed class BatchTaskInputDto
{
    public string Key { get; set; } = string.Empty;
    public int SiteId { get; set; }
    public string? MemberFilePath { get; set; }
    public string? UnclaimedFilePath { get; set; }
    public string? RechargeFilePath { get; set; }
    public SiteMappingConfig? MappingOverride { get; set; }
}

public sealed class BatchProcessInputDto
{
    public BatchPageModeDto Mode { get; set; }
    public int ActivityId { get; set; }
    public bool FilterUnclaimed { get; set; }
    public bool FilterRecharge { get; set; }
    public bool? IncludeProfitMember { get; set; }
    public decimal WageringMultiplier { get; set; }
    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;
    public bool SaveToHistory { get; set; } = true;
    public string? CalculationDate { get; set; }
    public ActivityTimezone Timezone { get; set; } = ActivityTimezone.Beijing;
    public List<BatchTaskInputDto> Tasks { get; set; } = new();
}

public sealed class BatchStatusDto
{
    public bool Running { get; set; }
    public BatchProcessProgress? Progress { get; set; }
    public BatchProcessResultDto? Result { get; set; }
    public string? Error { get; set; }
}

public sealed class BatchProcessResultDto
{
    public int ActivityId { get; set; }
    public string ActivityName { get; set; } = string.Empty;
    public DateTime StartedAt { get; set; }
    public DateTime FinishedAt { get; set; }
    public int SuccessCount { get; set; }
    public int FailedCount { get; set; }
    public decimal TotalBonusAllSites { get; set; }
    public List<BatchTaskResultDto> Tasks { get; set; } = new();
}

public sealed class BatchTaskResultDto
{
    public string Key { get; set; } = string.Empty;
    public int SiteId { get; set; }
    public string SiteName { get; set; } = string.Empty;
    public string SiteCode { get; set; } = string.Empty;
    public BatchTaskStatus Status { get; set; }
    public string StatusText { get; set; } = string.Empty;
    public string? ErrorMessage { get; set; }
    public string? ResultCacheKey { get; set; }
    public ProcessSummary? Summary { get; set; }
    public bool UsesSplitRewards { get; set; }
}

public sealed class FileUploadResultDto
{
    public string Path { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
}

public sealed class PagedDetailsDto
{
    public int Total { get; set; }
    public List<ProcessDetailItem> Items { get; set; } = new();
}

public sealed class PagedRewardsDto
{
    public int Total { get; set; }
    public List<RewardItem> Items { get; set; } = new();
}

public sealed class ResultSummaryDto
{
    public ProcessSummary Summary { get; set; } = new();
    public bool UsesSplitRewards { get; set; }
    public int DetailCount { get; set; }
    public int ExcludedCount { get; set; }
    public int MergedRewardCount { get; set; }
    public int LossRewardCount { get; set; }
    public int ProfitRewardCount { get; set; }
}

public sealed class RewardsTsvDto
{
    public string Text { get; set; } = string.Empty;
}

public sealed class ExportExcelInputDto
{
    public string CacheKey { get; set; } = string.Empty;
}

public sealed class ExportBatchAllInputDto
{
    public BatchProcessResultDto Result { get; set; } = new();
}

public sealed class CopyRewardsInputDto
{
    public string CacheKey { get; set; } = string.Empty;
    public string Kind { get; set; } = "merged";
}

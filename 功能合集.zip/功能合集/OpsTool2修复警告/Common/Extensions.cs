using System.Text.Json;
using DHPG.Data;

namespace DHPG.Common;

public static class Extensions
{
    private static readonly JsonSerializerOptions SnapshotJsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false
    };

    public static ColumnMappingInfo ToPeriodMapping(this SiteColumnMapping mapping) => new()
    {
        UserIdColumn = mapping.UserIdColumn,
        PayColumn = mapping.PayColumn,
        WithdrawColumn = mapping.WithdrawColumn,
        PhoneColumn = mapping.PhoneColumn,
        TierColumn = mapping.TierColumn,
        HeaderRow = mapping.HeaderRow
    };

    public static ColumnMappingInfo ToCallbackMapping(this SiteColumnMapping mapping) => new()
    {
        UserIdColumn = mapping.CallbackUserIdColumn,
        PayColumn = mapping.CallbackPayColumn,
        WithdrawColumn = mapping.CallbackWithdrawColumn,
        PhoneColumn = mapping.CallbackPhoneColumn,
        TierColumn = mapping.CallbackTierColumn,
        HeaderRow = mapping.CallbackHeaderRow
    };

    public static ColumnMappingInfo ToColumnMappingInfo(this SiteColumnMapping mapping) =>
        mapping.ToPeriodMapping();

    public static ColumnMappingInfo ResolveMemberMapping(this SiteColumnMapping mapping, MappingProfile profile) =>
        profile == MappingProfile.Callback ? mapping.ToCallbackMapping() : mapping.ToPeriodMapping();

    public static SiteMappingConfig ToSiteMappingConfig(this SiteColumnMapping mapping) => new()
    {
        Period = mapping.ToPeriodMapping(),
        Callback = mapping.ToCallbackMapping(),
        UnclaimedUserIdColumn = mapping.UnclaimedUserIdColumn
    };

    public static SiteMappingConfig ToSiteMappingConfig(this ActivityColumnMapping mapping) => new()
    {
        Period = mapping.ToPeriodMapping(),
        Callback = mapping.ToCallbackMapping(),
        Loss7d = mapping.ToLoss7dMapping(),
        YesterdayLoss = mapping.ToYesterdayLossMapping(),
        OldCallback234 = mapping.ToOldCallback234Mapping(),
        Comprehensive = mapping.ToComprehensiveMapping(),
        Recharge = mapping.ToRechargeMapping(),
        UnclaimedUserIdColumn = mapping.UnclaimedUserIdColumn
    };

    public static ColumnMappingInfo ToPeriodMapping(this ActivityColumnMapping mapping) => new()
    {
        UserIdColumn = mapping.UserIdColumn,
        PayColumn = mapping.PayColumn,
        WithdrawColumn = mapping.WithdrawColumn,
        PhoneColumn = mapping.PhoneColumn,
        TierColumn = mapping.TierColumn,
        HeaderRow = mapping.HeaderRow
    };

    public static ColumnMappingInfo ToCallbackMapping(this ActivityColumnMapping mapping) => new()
    {
        UserIdColumn = mapping.CallbackUserIdColumn,
        PayColumn = mapping.CallbackPayColumn,
        WithdrawColumn = mapping.CallbackWithdrawColumn,
        PhoneColumn = mapping.CallbackPhoneColumn,
        TierColumn = mapping.CallbackTierColumn,
        HeaderRow = mapping.CallbackHeaderRow
    };

    public static ColumnMappingInfo ToLoss7dMapping(this ActivityColumnMapping mapping) => new()
    {
        UserIdColumn = mapping.Loss7dUserIdColumn,
        PayColumn = mapping.Loss7dDepositColumn,
        WithdrawColumn = mapping.Loss7dWithdrawColumn,
        PhoneColumn = mapping.Loss7dPhoneColumn,
        TierColumn = mapping.Loss7dTierColumn,
        HeaderRow = mapping.Loss7dHeaderRow
    };

    public static ColumnMappingInfo ToYesterdayLossMapping(this ActivityColumnMapping mapping) => new()
    {
        UserIdColumn = mapping.YesterdayLossUserIdColumn,
        PayColumn = mapping.YesterdayLossPayColumn,
        WithdrawColumn = mapping.YesterdayLossWithdrawColumn,
        NetDiffColumn = mapping.YesterdayLossNetDiffColumn,
        PhoneColumn = mapping.YesterdayLossPhoneColumn,
        TierColumn = mapping.YesterdayLossTierColumn,
        HeaderRow = mapping.YesterdayLossHeaderRow
    };

    public static ColumnMappingInfo ToOldCallback234Mapping(this ActivityColumnMapping mapping) => new()
    {
        UserIdColumn = mapping.OldCallback234UserIdColumn,
        PayColumn = mapping.OldCallback234PayColumn,
        WithdrawColumn = mapping.OldCallback234WithdrawColumn,
        NetDiffColumn = mapping.OldCallback234NetDiffColumn,
        InactiveDaysColumn = mapping.OldCallback234InactiveDaysColumn,
        PhoneColumn = mapping.OldCallback234PhoneColumn,
        TierColumn = mapping.OldCallback234TierColumn,
        HeaderRow = mapping.OldCallback234HeaderRow
    };

    public static ColumnMappingInfo ToComprehensiveMapping(this ActivityColumnMapping mapping) => new()
    {
        UserIdColumn = mapping.ComprehensiveUserIdColumn,
        PayColumn = mapping.ComprehensivePayColumn,
        WithdrawColumn = mapping.ComprehensiveWithdrawColumn,
        NetDiffColumn = mapping.ComprehensiveNetDiffColumn,
        InactiveDaysColumn = mapping.ComprehensiveInactiveDaysColumn,
        PhoneColumn = mapping.ComprehensivePhoneColumn,
        TierColumn = mapping.ComprehensiveTierColumn,
        HeaderRow = mapping.ComprehensiveHeaderRow
    };

    public static RechargeMappingConfig ToRechargeMapping(this ActivityColumnMapping mapping) => new()
    {
        UserIdColumn = mapping.RechargeUserIdColumn,
        AmountColumn = mapping.RechargeAmountColumn,
        HeaderRow = mapping.RechargeHeaderRow
    };

    public static ColumnMappingInfo ResolveMemberMapping(this SiteMappingConfig config, MappingProfile profile) =>
        profile switch
        {
            MappingProfile.Callback => config.Callback,
            MappingProfile.Loss7d => config.Loss7d,
            MappingProfile.YesterdayLoss => config.YesterdayLoss,
            MappingProfile.OldCallback234 => config.OldCallback234,
            MappingProfile.ComprehensiveCallback => config.Comprehensive,
            _ => config.Period
        };

    public static string FormatMappingLetters(ColumnMappingInfo mapping)
    {
        var netDiff = mapping.NetDiffColumn >= 0 ? $"/{ColumnIndexToLetter(mapping.NetDiffColumn)}" : string.Empty;
        var inactive = mapping.InactiveDaysColumn >= 0 ? $"/{ColumnIndexToLetter(mapping.InactiveDaysColumn)}" : string.Empty;
        return $"{ColumnIndexToLetter(mapping.UserIdColumn)}/{ColumnIndexToLetter(mapping.PayColumn)}/" +
               $"{ColumnIndexToLetter(mapping.WithdrawColumn)}{netDiff}{inactive}/" +
               $"{(mapping.PhoneColumn >= 0 ? ColumnIndexToLetter(mapping.PhoneColumn) : "-")}/" +
               $"{(mapping.TierColumn >= 0 ? ColumnIndexToLetter(mapping.TierColumn) : "-")}";
    }

    public static AppSettingsModel ToModel(this AppSettings entity) => new()
    {
        ExportDirectory = entity.ExportDirectory,
        DefaultWageringMultiplier = entity.DefaultWageringMultiplier,
        DefaultAppRemark = entity.DefaultAppRemark,
        DefaultBackendRemark = entity.DefaultBackendRemark,
        Theme = entity.Theme,
        LogLevel = entity.LogLevel
    };

    public static SiteListItem ToListItem(this Site site, SiteColumnMapping? mapping = null)
    {
        var item = new SiteListItem
        {
            Id = site.Id,
            Name = site.Name,
            Code = site.Code,
            Remark = site.Remark,
            IsEnabled = site.IsEnabled,
            CreatedAt = site.CreatedAt
        };

        if (mapping is not null)
        {
            item.PeriodMappingText = FormatMappingLetters(mapping.ToPeriodMapping());
            item.CallbackMappingText = FormatMappingLetters(mapping.ToCallbackMapping());
            item.UnclaimedMappingText = ColumnIndexToLetter(mapping.UnclaimedUserIdColumn);
        }

        return item;
    }

    public static SiteEditModel ToEditModel(this Site site) => new()
    {
        Id = site.Id,
        Name = site.Name,
        Code = site.Code,
        Remark = site.Remark,
        IsEnabled = site.IsEnabled,
        Mapping = site.ColumnMapping?.ToSiteMappingConfig() ?? new SiteMappingConfig()
    };

    public static ActivityListItem ToListItem(this Activity activity, string siteScopeText, ActivityColumnMapping? mapping = null)
    {
        var item = new ActivityListItem
        {
            Id = activity.Id,
            SiteId = activity.SiteId,
            SiteScopeText = siteScopeText,
            Name = activity.Name,
            Rate = activity.Rate,
            AllowProfitMember = activity.AllowProfitMember,
            IsEnabled = activity.IsEnabled,
            SortOrder = activity.SortOrder,
            ApplyToAllSites = activity.ApplyToAllSites,
            Kind = activity.Kind,
            KindText = ActivityDefaults.FormatKindName(activity.Kind)
        };

        if (mapping is not null)
        {
            item.PeriodMappingText = FormatMappingLetters(mapping.ToPeriodMapping());
            item.CallbackMappingText = FormatMappingLetters(mapping.ToCallbackMapping());
            item.UnclaimedMappingText = ColumnIndexToLetter(mapping.UnclaimedUserIdColumn);
            if (activity.Kind == ActivityKind.Loss7d)
                item.PeriodMappingText = FormatMappingLetters(mapping.ToLoss7dMapping());
            else if (activity.Kind == ActivityKind.YesterdayLoss)
                item.PeriodMappingText = FormatMappingLetters(mapping.ToYesterdayLossMapping());
            else if (activity.Kind == ActivityKind.OldCallback234)
                item.PeriodMappingText = FormatMappingLetters(mapping.ToOldCallback234Mapping());
            else if (activity.Kind == ActivityKind.ComprehensiveCallback)
                item.PeriodMappingText = FormatMappingLetters(mapping.ToComprehensiveMapping());
        }

        return item;
    }

    public static ActivityEditModel ToEditModel(this Activity activity, IEnumerable<int>? linkedSiteIds = null) => new()
    {
        Id = activity.Id,
        SiteId = activity.SiteId,
        ApplyToAllSites = activity.ApplyToAllSites,
        LinkedSiteIds = linkedSiteIds?.ToList() ?? new List<int>(),
        Name = activity.Name,
        Rate = activity.Rate,
        Divisor = activity.Divisor,
        MinBonus = activity.MinBonus,
        MaxBonus = activity.MaxBonus,
        DefaultWageringMultiplier = activity.DefaultWageringMultiplier,
        AppRemark = activity.AppRemark,
        BackendRemark = activity.BackendRemark,
        AllowProfitMember = activity.AllowProfitMember,
        IsEnabled = activity.IsEnabled,
        FilterTierKeywords = ParseTierKeywords(activity.FilterTierKeywords).ToList(),
        SortOrder = activity.SortOrder,
        Mapping = activity.ColumnMapping?.ToSiteMappingConfig() ?? new SiteMappingConfig(),
        Kind = activity.Kind,
        WeeklyDayRates = WeeklyDayRates.Deserialize(activity.WeeklyDayRatesJson),
        DefaultTimezone = ParseTimezone(activity.DefaultTimezone),
        FilterLossMember = activity.FilterLossMember,
        FilterUnclaimedEnabled = activity.FilterUnclaimedEnabled,
        MinNetDiff = activity.MinNetDiff,
        TieredAmountRates = TieredAmountRates.Deserialize(activity.TieredAmountRatesJson),
        InactiveDaysMax = activity.InactiveDaysMax,
        UseNetDiffColumn = activity.UseNetDiffColumn,
        FilterRechargeEnabled = activity.FilterRechargeEnabled,
        TieredFixedBonuses = TieredFixedBonuses.Deserialize(activity.TieredFixedBonusesJson),
        ComprehensiveFeatures = ComprehensiveCallbackFeatures.Deserialize(activity.ComprehensiveFeaturesJson)
    };

    public static ActivityTimezone ParseTimezone(string? value) =>
        string.Equals(value, "Brazil", StringComparison.OrdinalIgnoreCase)
            ? ActivityTimezone.Brazil
            : ActivityTimezone.Beijing;

    public static string FormatTimezoneValue(ActivityTimezone timezone) =>
        timezone == ActivityTimezone.Brazil ? "Brazil" : "Beijing";

    public static HistoryListItem ToListItem(this ProcessHistory history) => new()
    {
        Id = history.Id,
        ProcessedAt = history.ProcessedAt,
        SiteName = history.SiteName,
        ActivityName = history.ActivityName,
        TotalCount = history.TotalCount,
        FilteredCount = history.FilteredCount,
        RewardCount = history.RewardCount,
        TotalBonus = history.TotalBonus
    };

    public static string SerializeTierKeywords(IEnumerable<string> keywords) =>
        JsonSerializer.Serialize(keywords.Where(k => !string.IsNullOrWhiteSpace(k)).Select(k => k.Trim()));

    public static string[] ParseTierKeywords(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return Array.Empty<string>();

        try
        {
            return JsonSerializer.Deserialize<string[]>(json) ?? Array.Empty<string>();
        }
        catch
        {
            return Array.Empty<string>();
        }
    }

    public static string[] ToLowerKeywords(IEnumerable<string> keywords) =>
        keywords.Where(k => !string.IsNullOrWhiteSpace(k))
            .Select(k => k.Trim().ToLowerInvariant())
            .Distinct()
            .ToArray();

    public static string SerializeSnapshot(ProcessSnapshot snapshot) =>
        JsonSerializer.Serialize(snapshot, SnapshotJsonOptions);

    public static ProcessSnapshot? DeserializeSnapshot(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return null;

        try
        {
            return JsonSerializer.Deserialize<ProcessSnapshot>(json, SnapshotJsonOptions);
        }
        catch
        {
            return null;
        }
    }

    /// <summary>0-based 列索引 → Excel 列字母（0=A, 25=Z, 26=AA）</summary>
    public static string ColumnIndexToLetter(int index)
    {
        if (index < 0)
            return string.Empty;

        var result = string.Empty;
        var n = index + 1;
        while (n > 0)
        {
            n--;
            result = (char)('A' + n % 26) + result;
            n /= 26;
        }
        return result;
    }

    /// <summary>Excel 列字母 → 0-based 列索引（A=0, AA=26）</summary>
    public static bool TryParseColumnLetter(string? input, out int index)
    {
        index = -1;
        if (string.IsNullOrWhiteSpace(input))
            return false;

        var value = 0;
        foreach (var ch in input.Trim().ToUpperInvariant())
        {
            if (ch is < 'A' or > 'Z')
                return false;

            value = value * 26 + (ch - 'A' + 1);
        }

        index = value - 1;
        return true;
    }

    /// <summary>列索引格式化为界面输入（-1 显示为 -）</summary>
    public static string FormatColumnInput(int index) =>
        index < 0 ? "-" : ColumnIndexToLetter(index);

    public static bool TryParseColumnInput(
        string? input,
        bool allowSkip,
        out int index,
        out string? errorMessage)
    {
        var text = input?.Trim() ?? string.Empty;
        if (allowSkip && IsSkipColumnInput(text))
        {
            index = -1;
            errorMessage = null;
            return true;
        }

        if (string.IsNullOrEmpty(text))
        {
            index = -1;
            errorMessage = allowSkip ? null : "列不能为空。";
            return allowSkip;
        }

        if (int.TryParse(text, out var numeric) && numeric >= 0)
        {
            index = numeric;
            errorMessage = null;
            return true;
        }

        if (TryParseColumnLetter(text, out index))
        {
            errorMessage = null;
            return true;
        }

        index = -1;
        errorMessage = $"无法识别列「{text}」，请填写 Excel 列字母（如 A、F、AA）。";
        return false;
    }

    public static int ParseColumnInput(string? input, bool allowSkip, string fieldLabel = "列")
    {
        if (!TryParseColumnInput(input, allowSkip, out var index, out var error))
            throw new InvalidOperationException(error ?? $"{fieldLabel}格式无效。");

        return index;
    }

    private static bool IsSkipColumnInput(string text) =>
        text is "-" or "—" or "不读" or "无" or "N/A" or "NA";

    /// <summary>合并派奖备注优先级：ProcessView/批量页当前值 &gt; 活动配置</summary>
    public static ActivityRuntimeParams MergeRuntimeParams(
        Activity activity,
        AppSettings settings,
        decimal? wageringMultiplier = null,
        string? appRemark = null,
        string? backendRemark = null) => new()
    {
        ActivityId = activity.Id,
        ActivityName = activity.Name,
        Rate = activity.Rate,
        Divisor = activity.Divisor,
        MinBonus = activity.MinBonus,
        MaxBonus = activity.MaxBonus,
        AllowProfitMember = activity.AllowProfitMember,
        FilterTierKeywords = ToLowerKeywords(ParseTierKeywords(activity.FilterTierKeywords)),
        WageringMultiplier = wageringMultiplier ?? activity.DefaultWageringMultiplier,
        AppRemark = !string.IsNullOrEmpty(appRemark) ? appRemark : activity.AppRemark,
        BackendRemark = !string.IsNullOrEmpty(backendRemark) ? backendRemark : activity.BackendRemark,
        Kind = activity.Kind,
        WeeklyDayRates = WeeklyDayRates.Deserialize(activity.WeeklyDayRatesJson),
        DefaultTimezone = ParseTimezone(activity.DefaultTimezone),
        FilterLossMember = activity.FilterLossMember,
        FilterUnclaimedEnabled = activity.FilterUnclaimedEnabled,
        MinNetDiff = activity.MinNetDiff,
        TieredAmountRates = TieredAmountRates.Deserialize(activity.TieredAmountRatesJson),
        InactiveDaysMax = activity.InactiveDaysMax,
        UseNetDiffColumn = activity.UseNetDiffColumn,
        FilterRechargeEnabled = activity.FilterRechargeEnabled,
        TieredFixedBonuses = TieredFixedBonuses.Deserialize(activity.TieredFixedBonusesJson),
        ComprehensiveFeatures = ComprehensiveCallbackFeatures.Deserialize(activity.ComprehensiveFeaturesJson)
    };

    /// <summary>刷新派奖表所有行的打码/备注（不重新计算彩金）</summary>
    public static void ApplyRewardSettings(
        IList<RewardItem> rewards,
        decimal wageringMultiplier,
        string appRemark,
        string backendRemark)
    {
        foreach (var item in rewards)
        {
            item.WageringMultiplier = wageringMultiplier;
            item.AppRemark = appRemark;
            item.BackendRemark = backendRemark;
        }
    }
}

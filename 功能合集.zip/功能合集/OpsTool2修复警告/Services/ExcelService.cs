using System.Globalization;
using System.IO;
using System.Text;
using CsvHelper;
using CsvHelper.Configuration;
using ExcelDataReader;
using DHPG.Common;

namespace DHPG.Services;

/// <summary>
/// 流式读取 Excel/CSV、列字母↔索引、未领名单 HashSet。
/// 禁止 DataTable 全量加载。
/// </summary>
public class ExcelService
{
    static ExcelService() => Helpers.EnsureExcelEncoding();

    private static readonly string[] SupportedExtensions = [".xlsx", ".xls", ".xlsm", ".csv"];

    /// <summary>按站点 ColumnMapping 流式解析会员文件</summary>
    public IEnumerable<MemberRow> ReadMembers(string filePath, ColumnMappingInfo mapping)
    {
        ValidateFile(filePath);
        ValidateMapping(mapping);

        return Path.GetExtension(filePath).ToLowerInvariant() switch
        {
            ".csv" => ReadMembersFromCsv(filePath, mapping),
            _ => ReadMembersFromExcel(filePath, mapping)
        };
    }

    /// <summary>读取未领名单，返回会员 ID 集合（指定列，默认 B 列 = 1）</summary>
    public HashSet<long> ReadUnclaimedIds(string filePath, int userIdColumn = 1)
    {
        ValidateFile(filePath);
        if (userIdColumn < 0)
            throw new ArgumentOutOfRangeException(nameof(userIdColumn), "未领名单会员 ID 列不能小于 0。");

        var ids = new HashSet<long>();
        foreach (var row in ReadIdRows(filePath, userIdColumn))
        {
            if (row.HasValue)
                ids.Add(row.Value);
        }
        return ids;
    }

    /// <summary>读取充值数据，返回会员 ID → 充值金额</summary>
    public Dictionary<long, decimal> ReadRechargeAmounts(string filePath, RechargeMappingConfig mapping)
    {
        ValidateFile(filePath);
        if (mapping.UserIdColumn < 0 || mapping.AmountColumn < 0)
            throw new ArgumentException("充值数据会员 ID 与金额列不能小于 0。");
        if (mapping.HeaderRow < 0)
            throw new ArgumentOutOfRangeException(nameof(mapping), "表头行号不能小于 0。");

        var amounts = new Dictionary<long, decimal>();
        foreach (var row in ReadRechargeRows(filePath, mapping))
        {
            if (row is null)
                continue;

            amounts[row.Value.UserId] = row.Value.Amount;
        }

        return amounts;
    }

    private IEnumerable<(long UserId, decimal Amount)?> ReadRechargeRows(string filePath, RechargeMappingConfig mapping)
    {
        return Path.GetExtension(filePath).ToLowerInvariant() switch
        {
            ".csv" => ReadRechargeRowsFromCsv(filePath, mapping),
            _ => ReadRechargeRowsFromExcel(filePath, mapping)
        };
    }

    private IEnumerable<(long UserId, decimal Amount)?> ReadRechargeRowsFromExcel(
        string filePath,
        RechargeMappingConfig mapping)
    {
        using var stream = OpenReadStream(filePath);
        using var reader = ExcelReaderFactory.CreateReader(stream);

        var rowBuffer = new List<string?>(16);
        var rowIndex = 0;
        do
        {
            while (reader.Read())
            {
                rowIndex++;
                if (rowIndex <= mapping.HeaderRow)
                    continue;

                FillExcelRow(reader, rowBuffer);
                yield return TryBuildRechargeRow(rowBuffer, mapping);
            }
        } while (reader.NextResult());
    }

    private IEnumerable<(long UserId, decimal Amount)?> ReadRechargeRowsFromCsv(
        string filePath,
        RechargeMappingConfig mapping)
    {
        using var stream = OpenReadStream(filePath);
        using var textReader = new StreamReader(stream, DetectCsvEncoding(filePath), detectEncodingFromByteOrderMarks: true);
        var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            HasHeaderRecord = false,
            DetectDelimiter = true,
            TrimOptions = TrimOptions.Trim,
            BadDataFound = null,
            MissingFieldFound = null
        };

        using var csv = new CsvReader(textReader, config);
        var rowIndex = 0;
        while (csv.Read())
        {
            rowIndex++;
            if (rowIndex <= mapping.HeaderRow)
                continue;

            var fields = csv.Parser.Record ?? Array.Empty<string>();
            yield return TryBuildRechargeRow(fields, mapping);
        }
    }

    private static (long UserId, decimal Amount)? TryBuildRechargeRow(
        IReadOnlyList<string?> fields,
        RechargeMappingConfig mapping)
    {
        var userId = Helpers.TryParseUserId(Helpers.GetField(fields, mapping.UserIdColumn));
        if (!userId.HasValue)
            return null;

        var amount = Helpers.ParseAmount(Helpers.GetField(fields, mapping.AmountColumn));
        return (userId.Value, amount);
    }

    /// <summary>预览文件表头（供列映射配置参考）</summary>
    public Task<IReadOnlyList<string>> PreviewHeadersAsync(
        string filePath,
        int headerRow,
        CancellationToken cancellationToken = default)
    {
        ValidateFile(filePath);
        if (headerRow < 0)
            throw new ArgumentOutOfRangeException(nameof(headerRow), "表头行号不能小于 0。");

        cancellationToken.ThrowIfCancellationRequested();

        IReadOnlyList<string> headers = Path.GetExtension(filePath).ToLowerInvariant() switch
        {
            ".csv" => PreviewCsvHeaders(filePath, headerRow),
            _ => PreviewExcelHeaders(filePath, headerRow)
        };

        return Task.FromResult(headers);
    }

    public string ColumnIndexToLetter(int index) => Extensions.ColumnIndexToLetter(index);

    private static void ValidateFile(string filePath)
    {
        if (string.IsNullOrWhiteSpace(filePath))
            throw new ArgumentException("文件路径不能为空。", nameof(filePath));

        if (!File.Exists(filePath))
            throw new FileNotFoundException("找不到文件。", filePath);

        var ext = Path.GetExtension(filePath).ToLowerInvariant();
        if (!SupportedExtensions.Contains(ext))
            throw new NotSupportedException($"不支持的文件格式：{ext}，请使用 .xlsx / .xls / .xlsm / .csv。");
    }

    private static void ValidateMapping(ColumnMappingInfo mapping)
    {
        if (mapping.UserIdColumn < 0 || mapping.PayColumn < 0 || mapping.WithdrawColumn < 0)
            throw new ArgumentException("会员 ID、充值、提现列索引不能小于 0。");

        if (mapping.HeaderRow < 0)
            throw new ArgumentOutOfRangeException(nameof(mapping), "表头行号不能小于 0。");
    }

    private IEnumerable<MemberRow> ReadMembersFromExcel(string filePath, ColumnMappingInfo mapping)
    {
        using var stream = OpenReadStream(filePath);
        using var reader = ExcelReaderFactory.CreateReader(stream);

        var rowBuffer = new List<string?>(32);
        var rowIndex = 0;
        do
        {
            while (reader.Read())
            {
                rowIndex++;
                if (rowIndex <= mapping.HeaderRow)
                    continue;

                FillExcelRow(reader, rowBuffer);
                if (TryBuildMemberRow(rowBuffer, mapping, rowIndex, out var member))
                    yield return member;
            }
        } while (reader.NextResult());
    }

    private IEnumerable<MemberRow> ReadMembersFromCsv(string filePath, ColumnMappingInfo mapping)
    {
        using var stream = OpenReadStream(filePath);
        using var textReader = new StreamReader(stream, DetectCsvEncoding(filePath), detectEncodingFromByteOrderMarks: true);
        var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            HasHeaderRecord = false,
            DetectDelimiter = true,
            TrimOptions = TrimOptions.Trim,
            BadDataFound = null,
            MissingFieldFound = null
        };

        using var csv = new CsvReader(textReader, config);
        var rowIndex = 0;
        while (csv.Read())
        {
            rowIndex++;
            if (rowIndex <= mapping.HeaderRow)
                continue;

            var fields = csv.Parser.Record ?? Array.Empty<string>();
            if (TryBuildMemberRow(fields, mapping, rowIndex, out var member))
                yield return member;
        }
    }

    private IEnumerable<long?> ReadIdRows(string filePath, int userIdColumn)
    {
        return Path.GetExtension(filePath).ToLowerInvariant() switch
        {
            ".csv" => ReadIdRowsFromCsv(filePath, userIdColumn),
            _ => ReadIdRowsFromExcel(filePath, userIdColumn)
        };
    }

    private IEnumerable<long?> ReadIdRowsFromExcel(string filePath, int userIdColumn)
    {
        using var stream = OpenReadStream(filePath);
        using var reader = ExcelReaderFactory.CreateReader(stream);

        do
        {
            while (reader.Read())
            {
                if (userIdColumn >= reader.FieldCount)
                {
                    yield return null;
                    continue;
                }

                yield return Helpers.TryParseUserId(reader.GetValue(userIdColumn));
            }
        } while (reader.NextResult());
    }

    private IEnumerable<long?> ReadIdRowsFromCsv(string filePath, int userIdColumn)
    {
        using var stream = OpenReadStream(filePath);
        using var textReader = new StreamReader(stream, DetectCsvEncoding(filePath), detectEncodingFromByteOrderMarks: true);
        var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            HasHeaderRecord = false,
            DetectDelimiter = true,
            TrimOptions = TrimOptions.Trim,
            BadDataFound = null,
            MissingFieldFound = null
        };

        using var csv = new CsvReader(textReader, config);
        while (csv.Read())
        {
            var fields = csv.Parser.Record ?? Array.Empty<string>();
            yield return Helpers.TryParseUserId(Helpers.GetField(fields, userIdColumn));
        }
    }

    private static IReadOnlyList<string> PreviewExcelHeaders(string filePath, int headerRow)
    {
        using var stream = OpenReadStream(filePath);
        using var reader = ExcelReaderFactory.CreateReader(stream);

        var rowIndex = 0;
        do
        {
            while (reader.Read())
            {
                if (rowIndex == headerRow)
                {
                    var headers = new List<string>(reader.FieldCount);
                    for (var i = 0; i < reader.FieldCount; i++)
                        headers.Add(Helpers.TryParseString(reader.GetValue(i)) ?? Extensions.ColumnIndexToLetter(i));
                    return headers;
                }
                rowIndex++;
            }
        } while (reader.NextResult());

        return Array.Empty<string>();
    }

    private static IReadOnlyList<string> PreviewCsvHeaders(string filePath, int headerRow)
    {
        using var stream = OpenReadStream(filePath);
        using var textReader = new StreamReader(stream, DetectCsvEncoding(filePath), detectEncodingFromByteOrderMarks: true);
        var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            HasHeaderRecord = false,
            DetectDelimiter = true,
            TrimOptions = TrimOptions.Trim,
            BadDataFound = null,
            MissingFieldFound = null
        };

        using var csv = new CsvReader(textReader, config);
        var rowIndex = 0;
        while (csv.Read())
        {
            if (rowIndex == headerRow)
            {
                var fields = csv.Parser.Record ?? Array.Empty<string>();
                return fields.Select((value, index) =>
                    string.IsNullOrWhiteSpace(value) ? Extensions.ColumnIndexToLetter(index) : value.Trim()).ToArray();
            }
            rowIndex++;
        }

        return Array.Empty<string>();
    }

    private static bool TryBuildMemberRow(
        IReadOnlyList<string?> fields,
        ColumnMappingInfo mapping,
        int rowNumber,
        out MemberRow member)
    {
        member = null!;

        var userIdText = Helpers.GetField(fields, mapping.UserIdColumn);
        var userId = Helpers.TryParseUserId(userIdText);
        if (!userId.HasValue)
            return false;

        member = new MemberRow
        {
            RowNumber = rowNumber,
            UserId = userId.Value,
            Pay = Helpers.ParseAmount(Helpers.GetField(fields, mapping.PayColumn)),
            Withdraw = Helpers.ParseAmount(Helpers.GetField(fields, mapping.WithdrawColumn)),
            NetDiff = mapping.NetDiffColumn >= 0
                ? Helpers.ParseAmount(Helpers.GetField(fields, mapping.NetDiffColumn))
                : Helpers.ParseAmount(Helpers.GetField(fields, mapping.PayColumn))
                  - Helpers.ParseAmount(Helpers.GetField(fields, mapping.WithdrawColumn)),
            Phone = mapping.PhoneColumn >= 0 ? Helpers.GetField(fields, mapping.PhoneColumn) : null,
            Tier = mapping.TierColumn >= 0 ? Helpers.GetField(fields, mapping.TierColumn) : null,
            InactiveDaysText = mapping.InactiveDaysColumn >= 0
                ? Helpers.GetField(fields, mapping.InactiveDaysColumn)
                : null
        };
        return true;
    }

    private static void FillExcelRow(IExcelDataReader reader, List<string?> buffer)
    {
        buffer.Clear();
        buffer.EnsureCapacity(reader.FieldCount);
        for (var i = 0; i < reader.FieldCount; i++)
            buffer.Add(Helpers.TryParseString(reader.GetValue(i)));
    }

    private static FileStream OpenReadStream(string filePath) =>
        new(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);

    private static Encoding DetectCsvEncoding(string filePath)
    {
        using var stream = OpenReadStream(filePath);
        var buffer = new byte[4];
        var read = stream.Read(buffer, 0, buffer.Length);
        if (read >= 3 && buffer[0] == 0xEF && buffer[1] == 0xBB && buffer[2] == 0xBF)
            return Encoding.UTF8;
        if (read >= 2 && buffer[0] == 0xFF && buffer[1] == 0xFE)
            return Encoding.Unicode;
        return Encoding.UTF8;
    }
}

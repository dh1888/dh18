using Microsoft.EntityFrameworkCore;
using DHPG.Common;
using DHPG.Data;

namespace DHPG.Services;

/// <summary>
/// 站点 CRUD、活动 CRUD、按站点查询、复制活动。
/// </summary>
public class ActivityService
{
    private readonly IDbContextFactory<AppDbContext> _dbFactory;

    public ActivityService(IDbContextFactory<AppDbContext> dbFactory)
    {
        _dbFactory = dbFactory;
    }

    /// <summary>补齐内置活动（含综合回访）与列映射，供启动与批量页 bootstrap 调用。</summary>
    public async Task EnsureBuiltInActivitiesAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        db.PatchLegacyDefaults();
    }

    // --- 站点 ---

    public async Task<List<SiteListItem>> GetSitesAsync(bool enabledOnly = false, CancellationToken cancellationToken = default)
    {
        var (sites, _) = await GetSitesBundleAsync(enabledOnly, cancellationToken);
        return sites;
    }

    /// <summary>一次查询返回站点列表与编辑模型，避免批量页 N+1 加载。</summary>
    public async Task<(List<SiteListItem> Sites, Dictionary<int, SiteEditModel> EditModels)> GetSitesBundleAsync(
        bool enabledOnly = false,
        CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var query = db.Sites.AsNoTracking()
            .Include(s => s.ColumnMapping)
            .AsQueryable();
        if (enabledOnly)
            query = query.Where(s => s.IsEnabled);

        var entities = await query.OrderBy(s => s.Name).ToListAsync(cancellationToken);
        var sites = entities.Select(s => s.ToListItem(s.ColumnMapping)).ToList();
        var editModels = entities.ToDictionary(s => s.Id, s => s.ToEditModel());
        return (sites, editModels);
    }

    public async Task<SiteEditModel?> GetSiteAsync(int siteId, CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var site = await db.Sites.AsNoTracking()
            .Include(s => s.ColumnMapping)
            .FirstOrDefaultAsync(s => s.Id == siteId, cancellationToken);
        return site?.ToEditModel();
    }

    public async Task<int> SaveSiteAsync(SiteEditModel model, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(model.Name))
            throw new InvalidOperationException("站点名称不能为空。");
        if (string.IsNullOrWhiteSpace(model.Code))
            throw new InvalidOperationException("站点代码不能为空。");

        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var code = model.Code.Trim();
        var codeExists = await db.Sites.AnyAsync(
            s => s.Code == code && s.Id != model.Id,
            cancellationToken);
        if (codeExists)
            throw new InvalidOperationException($"站点代码「{code}」已存在。");

        if (model.Id == 0)
        {
            var site = new Site
            {
                Name = model.Name.Trim(),
                Code = code,
                Remark = model.Remark?.Trim(),
                IsEnabled = model.IsEnabled,
                CreatedAt = DateTime.Now,
                ColumnMapping = MapColumnMapping(model.Mapping)
            };
            db.Sites.Add(site);
            await db.SaveChangesAsync(cancellationToken);
            return site.Id;
        }

        var existing = await db.Sites
            .Include(s => s.ColumnMapping)
            .FirstOrDefaultAsync(s => s.Id == model.Id, cancellationToken)
            ?? throw new InvalidOperationException("站点不存在。");

        existing.Name = model.Name.Trim();
        existing.Code = code;
        existing.Remark = model.Remark?.Trim();
        existing.IsEnabled = model.IsEnabled;

        await db.SaveChangesAsync(cancellationToken);
        return existing.Id;
    }

    public async Task DeleteSiteAsync(int siteId, CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var site = await db.Sites.FirstOrDefaultAsync(s => s.Id == siteId, cancellationToken)
            ?? throw new InvalidOperationException("站点不存在。");

        if (await db.ActivitySiteLinks.AnyAsync(l => l.SiteId == siteId, cancellationToken))
            throw new InvalidOperationException("该站点仍被活动引用，无法删除。请先调整活动适用站点。");

        if (await db.Activities.AnyAsync(a => a.SiteId == siteId, cancellationToken))
            throw new InvalidOperationException("该站点下仍有活动，无法删除。请先删除或迁移相关活动。");

        db.Sites.Remove(site);
        await db.SaveChangesAsync(cancellationToken);
    }

    // --- 活动 ---

    public async Task<List<ActivityListItem>> GetActivitiesAsync(
        int? siteId = null,
        bool enabledOnly = false,
        CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var query = db.Activities.AsNoTracking()
            .Include(a => a.SiteLinks)
            .ThenInclude(l => l.Site)
            .Include(a => a.ColumnMapping)
            .AsQueryable();

        if (enabledOnly)
            query = query.Where(a => a.IsEnabled);

        if (siteId.HasValue)
        {
            query = query.Where(a =>
                a.ApplyToAllSites || a.SiteLinks.Any(l => l.SiteId == siteId.Value));
        }

        var activities = await query
            .OrderBy(a => a.SortOrder)
            .ThenBy(a => a.Name)
            .ToListAsync(cancellationToken);

        return activities.Select(a => BuildActivityListItem(a, a.ColumnMapping)).ToList();
    }

    public async Task<ActivityEditModel?> GetActivityAsync(int activityId, CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var activity = await db.Activities.AsNoTracking()
            .Include(a => a.SiteLinks)
            .Include(a => a.ColumnMapping)
            .FirstOrDefaultAsync(a => a.Id == activityId, cancellationToken);
        if (activity is null)
            return null;

        return activity.ToEditModel(activity.SiteLinks.Select(l => l.SiteId));
    }

    public async Task<int> SaveActivityAsync(ActivityEditModel model, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(model.Name))
            throw new InvalidOperationException("活动名称不能为空。");
        if (model.Divisor <= 0)
            throw new InvalidOperationException("除数必须大于等于 1。");

        if (!model.ApplyToAllSites && model.LinkedSiteIds.Count == 0)
            throw new InvalidOperationException("未勾选「全部站点」时，请至少选择一个适用站点。");

        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var name = model.Name.Trim();
        var nameExists = await db.Activities.AnyAsync(
            a => a.Name == name && a.Id != model.Id,
            cancellationToken);
        if (nameExists)
            throw new InvalidOperationException($"已存在活动「{name}」。");

        var linkedSiteIds = model.ApplyToAllSites
            ? new List<int>()
            : model.LinkedSiteIds.Distinct().ToList();

        if (model.Kind == ActivityKind.ComprehensiveCallback)
        {
            model.ApplyToAllSites = true;
            linkedSiteIds = new List<int>();
        }

        if (linkedSiteIds.Count > 0)
        {
            var existingCount = await db.Sites.CountAsync(s => linkedSiteIds.Contains(s.Id), cancellationToken);
            if (existingCount != linkedSiteIds.Count)
                throw new InvalidOperationException("部分适用站点不存在。");
        }

        if (model.Id == 0)
        {
            var now = DateTime.Now;
            var activity = MapActivity(model, now, now);
            activity.SiteId = ResolveActivitySiteId(linkedSiteIds);
            activity.ColumnMapping = MapActivityColumnMapping(model.Mapping);
            foreach (var siteId in linkedSiteIds)
            {
                activity.SiteLinks.Add(new ActivitySiteLink { SiteId = siteId });
            }

            db.Activities.Add(activity);
            await db.SaveChangesAsync(cancellationToken);
            return activity.Id;
        }

        var existing = await db.Activities
            .Include(a => a.SiteLinks)
            .Include(a => a.ColumnMapping)
            .FirstOrDefaultAsync(a => a.Id == model.Id, cancellationToken)
            ?? throw new InvalidOperationException("活动不存在。");

        ApplyActivity(existing, model);
        if (existing.ColumnMapping is null)
        {
            existing.ColumnMapping = MapActivityColumnMapping(model.Mapping);
            existing.ColumnMapping.ActivityId = existing.Id;
        }
        else
        {
            ApplyActivityColumnMapping(existing.ColumnMapping, model.Mapping);
        }
        existing.SiteId = ResolveActivitySiteId(linkedSiteIds);
        existing.UpdatedAt = DateTime.Now;
        await ReplaceActivitySiteLinksAsync(db, existing.Id, linkedSiteIds, cancellationToken);
        await db.SaveChangesAsync(cancellationToken);
        return existing.Id;
    }

    public async Task<int> CopyActivityAsync(int sourceActivityId, CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var source = await db.Activities.AsNoTracking()
            .Include(a => a.SiteLinks)
            .Include(a => a.ColumnMapping)
            .FirstOrDefaultAsync(a => a.Id == sourceActivityId, cancellationToken)
            ?? throw new InvalidOperationException("源活动不存在。");

        var now = DateTime.Now;
        var copyName = await GenerateCopyNameAsync(db, source.Name, cancellationToken);
        var copy = new Activity
        {
            SiteId = source.SiteId,
            Name = copyName,
            Rate = source.Rate,
            Divisor = source.Divisor,
            MinBonus = source.MinBonus,
            MaxBonus = source.MaxBonus,
            DefaultWageringMultiplier = source.DefaultWageringMultiplier,
            AppRemark = source.AppRemark,
            BackendRemark = source.BackendRemark,
            AllowProfitMember = source.AllowProfitMember,
            IsEnabled = source.IsEnabled,
            FilterTierKeywords = source.FilterTierKeywords,
            SortOrder = source.SortOrder + 1,
            ApplyToAllSites = source.ApplyToAllSites,
            Kind = source.Kind,
            WeeklyDayRatesJson = source.WeeklyDayRatesJson,
            DefaultTimezone = source.DefaultTimezone,
            FilterLossMember = source.FilterLossMember,
            FilterUnclaimedEnabled = source.FilterUnclaimedEnabled,
            MinNetDiff = source.MinNetDiff,
            TieredAmountRatesJson = source.TieredAmountRatesJson,
            InactiveDaysMax = source.InactiveDaysMax,
            UseNetDiffColumn = source.UseNetDiffColumn,
            FilterRechargeEnabled = source.FilterRechargeEnabled,
            TieredFixedBonusesJson = source.TieredFixedBonusesJson,
            ComprehensiveFeaturesJson = source.ComprehensiveFeaturesJson,
            CreatedAt = now,
            UpdatedAt = now
        };
        if (source.ColumnMapping is not null)
            copy.ColumnMapping = MapActivityColumnMapping(source.ColumnMapping.ToSiteMappingConfig());

        db.Activities.Add(copy);
        if (!source.ApplyToAllSites)
        {
            foreach (var link in source.SiteLinks)
            {
                copy.SiteLinks.Add(new ActivitySiteLink { SiteId = link.SiteId });
            }
        }

        await db.SaveChangesAsync(cancellationToken);
        return copy.Id;
    }

    public async Task DeleteActivityAsync(int activityId, CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var activity = await db.Activities
            .Include(a => a.SiteLinks)
            .Include(a => a.ColumnMapping)
            .FirstOrDefaultAsync(a => a.Id == activityId, cancellationToken)
            ?? throw new InvalidOperationException("活动不存在。");

        db.ActivitySiteLinks.RemoveRange(activity.SiteLinks);
        db.Activities.Remove(activity);
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task SaveActivityMappingAsync(
        int activityId,
        SiteMappingConfig mapping,
        CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var activity = await db.Activities
            .Include(a => a.ColumnMapping)
            .FirstOrDefaultAsync(a => a.Id == activityId, cancellationToken)
            ?? throw new InvalidOperationException("活动不存在。");

        if (activity.ColumnMapping is null)
        {
            activity.ColumnMapping = MapActivityColumnMapping(mapping);
            activity.ColumnMapping.ActivityId = activity.Id;
        }
        else
        {
            ApplyActivityColumnMapping(activity.ColumnMapping, mapping);
        }

        activity.UpdatedAt = DateTime.Now;
        await db.SaveChangesAsync(cancellationToken);
    }

    private static ActivityListItem BuildActivityListItem(Activity activity, ActivityColumnMapping? mapping)
    {
        string scopeText;
        if (activity.ApplyToAllSites)
        {
            scopeText = "全部站点";
        }
        else
        {
            var names = activity.SiteLinks
                .Select(l => l.Site?.Name)
                .Where(n => !string.IsNullOrWhiteSpace(n))
                .ToList();
            scopeText = names.Count > 0 ? string.Join("、", names) : "未指定站点";
        }

        return activity.ToListItem(scopeText, mapping);
    }

    private static ActivityColumnMapping MapActivityColumnMapping(SiteMappingConfig mapping) => new()
    {
        UserIdColumn = mapping.Period.UserIdColumn,
        PayColumn = mapping.Period.PayColumn,
        WithdrawColumn = mapping.Period.WithdrawColumn,
        PhoneColumn = mapping.Period.PhoneColumn,
        TierColumn = mapping.Period.TierColumn,
        HeaderRow = mapping.Period.HeaderRow,
        CallbackUserIdColumn = mapping.Callback.UserIdColumn,
        CallbackPayColumn = mapping.Callback.PayColumn,
        CallbackWithdrawColumn = mapping.Callback.WithdrawColumn,
        CallbackPhoneColumn = mapping.Callback.PhoneColumn,
        CallbackTierColumn = mapping.Callback.TierColumn,
        CallbackHeaderRow = mapping.Callback.HeaderRow,
        UnclaimedUserIdColumn = mapping.UnclaimedUserIdColumn,
        Loss7dUserIdColumn = mapping.Loss7d.UserIdColumn,
        Loss7dDepositColumn = mapping.Loss7d.PayColumn,
        Loss7dWithdrawColumn = mapping.Loss7d.WithdrawColumn,
        Loss7dPhoneColumn = mapping.Loss7d.PhoneColumn,
        Loss7dTierColumn = mapping.Loss7d.TierColumn,
        Loss7dHeaderRow = mapping.Loss7d.HeaderRow,
        YesterdayLossUserIdColumn = mapping.YesterdayLoss.UserIdColumn,
        YesterdayLossPayColumn = mapping.YesterdayLoss.PayColumn,
        YesterdayLossWithdrawColumn = mapping.YesterdayLoss.WithdrawColumn,
        YesterdayLossNetDiffColumn = mapping.YesterdayLoss.NetDiffColumn,
        YesterdayLossPhoneColumn = mapping.YesterdayLoss.PhoneColumn,
        YesterdayLossTierColumn = mapping.YesterdayLoss.TierColumn,
        YesterdayLossHeaderRow = mapping.YesterdayLoss.HeaderRow,
        OldCallback234UserIdColumn = mapping.OldCallback234.UserIdColumn,
        OldCallback234PayColumn = mapping.OldCallback234.PayColumn,
        OldCallback234WithdrawColumn = mapping.OldCallback234.WithdrawColumn,
        OldCallback234NetDiffColumn = mapping.OldCallback234.NetDiffColumn,
        OldCallback234InactiveDaysColumn = mapping.OldCallback234.InactiveDaysColumn,
        OldCallback234PhoneColumn = mapping.OldCallback234.PhoneColumn,
        OldCallback234TierColumn = mapping.OldCallback234.TierColumn,
        OldCallback234HeaderRow = mapping.OldCallback234.HeaderRow,
        ComprehensiveUserIdColumn = mapping.Comprehensive.UserIdColumn,
        ComprehensivePayColumn = mapping.Comprehensive.PayColumn,
        ComprehensiveWithdrawColumn = mapping.Comprehensive.WithdrawColumn,
        ComprehensiveNetDiffColumn = mapping.Comprehensive.NetDiffColumn,
        ComprehensiveInactiveDaysColumn = mapping.Comprehensive.InactiveDaysColumn,
        ComprehensivePhoneColumn = mapping.Comprehensive.PhoneColumn,
        ComprehensiveTierColumn = mapping.Comprehensive.TierColumn,
        ComprehensiveHeaderRow = mapping.Comprehensive.HeaderRow,
        RechargeUserIdColumn = mapping.Recharge.UserIdColumn,
        RechargeAmountColumn = mapping.Recharge.AmountColumn,
        RechargeHeaderRow = mapping.Recharge.HeaderRow
    };

    private static void ApplyActivityColumnMapping(ActivityColumnMapping entity, SiteMappingConfig mapping)
    {
        entity.UserIdColumn = mapping.Period.UserIdColumn;
        entity.PayColumn = mapping.Period.PayColumn;
        entity.WithdrawColumn = mapping.Period.WithdrawColumn;
        entity.PhoneColumn = mapping.Period.PhoneColumn;
        entity.TierColumn = mapping.Period.TierColumn;
        entity.HeaderRow = mapping.Period.HeaderRow;
        entity.CallbackUserIdColumn = mapping.Callback.UserIdColumn;
        entity.CallbackPayColumn = mapping.Callback.PayColumn;
        entity.CallbackWithdrawColumn = mapping.Callback.WithdrawColumn;
        entity.CallbackPhoneColumn = mapping.Callback.PhoneColumn;
        entity.CallbackTierColumn = mapping.Callback.TierColumn;
        entity.CallbackHeaderRow = mapping.Callback.HeaderRow;
        entity.UnclaimedUserIdColumn = mapping.UnclaimedUserIdColumn;
        entity.Loss7dUserIdColumn = mapping.Loss7d.UserIdColumn;
        entity.Loss7dDepositColumn = mapping.Loss7d.PayColumn;
        entity.Loss7dWithdrawColumn = mapping.Loss7d.WithdrawColumn;
        entity.Loss7dPhoneColumn = mapping.Loss7d.PhoneColumn;
        entity.Loss7dTierColumn = mapping.Loss7d.TierColumn;
        entity.Loss7dHeaderRow = mapping.Loss7d.HeaderRow;
        entity.YesterdayLossUserIdColumn = mapping.YesterdayLoss.UserIdColumn;
        entity.YesterdayLossPayColumn = mapping.YesterdayLoss.PayColumn;
        entity.YesterdayLossWithdrawColumn = mapping.YesterdayLoss.WithdrawColumn;
        entity.YesterdayLossNetDiffColumn = mapping.YesterdayLoss.NetDiffColumn;
        entity.YesterdayLossPhoneColumn = mapping.YesterdayLoss.PhoneColumn;
        entity.YesterdayLossTierColumn = mapping.YesterdayLoss.TierColumn;
        entity.YesterdayLossHeaderRow = mapping.YesterdayLoss.HeaderRow;
        entity.OldCallback234UserIdColumn = mapping.OldCallback234.UserIdColumn;
        entity.OldCallback234PayColumn = mapping.OldCallback234.PayColumn;
        entity.OldCallback234WithdrawColumn = mapping.OldCallback234.WithdrawColumn;
        entity.OldCallback234NetDiffColumn = mapping.OldCallback234.NetDiffColumn;
        entity.OldCallback234InactiveDaysColumn = mapping.OldCallback234.InactiveDaysColumn;
        entity.OldCallback234PhoneColumn = mapping.OldCallback234.PhoneColumn;
        entity.OldCallback234TierColumn = mapping.OldCallback234.TierColumn;
        entity.OldCallback234HeaderRow = mapping.OldCallback234.HeaderRow;
        entity.ComprehensiveUserIdColumn = mapping.Comprehensive.UserIdColumn;
        entity.ComprehensivePayColumn = mapping.Comprehensive.PayColumn;
        entity.ComprehensiveWithdrawColumn = mapping.Comprehensive.WithdrawColumn;
        entity.ComprehensiveNetDiffColumn = mapping.Comprehensive.NetDiffColumn;
        entity.ComprehensiveInactiveDaysColumn = mapping.Comprehensive.InactiveDaysColumn;
        entity.ComprehensivePhoneColumn = mapping.Comprehensive.PhoneColumn;
        entity.ComprehensiveTierColumn = mapping.Comprehensive.TierColumn;
        entity.ComprehensiveHeaderRow = mapping.Comprehensive.HeaderRow;
        entity.RechargeUserIdColumn = mapping.Recharge.UserIdColumn;
        entity.RechargeAmountColumn = mapping.Recharge.AmountColumn;
        entity.RechargeHeaderRow = mapping.Recharge.HeaderRow;
    }

    private static async Task ReplaceActivitySiteLinksAsync(
        AppDbContext db,
        int activityId,
        IReadOnlyList<int> linkedSiteIds,
        CancellationToken cancellationToken)
    {
        var existing = await db.ActivitySiteLinks
            .Where(l => l.ActivityId == activityId)
            .ToListAsync(cancellationToken);
        db.ActivitySiteLinks.RemoveRange(existing);

        foreach (var siteId in linkedSiteIds)
        {
            db.ActivitySiteLinks.Add(new ActivitySiteLink
            {
                ActivityId = activityId,
                SiteId = siteId
            });
        }
    }

    private static int? ResolveActivitySiteId(IReadOnlyList<int> linkedSiteIds) =>
        linkedSiteIds.Count > 0 ? linkedSiteIds[0] : null;

    private static SiteColumnMapping MapColumnMapping(SiteMappingConfig mapping) => new()
    {
        UserIdColumn = mapping.Period.UserIdColumn,
        PayColumn = mapping.Period.PayColumn,
        WithdrawColumn = mapping.Period.WithdrawColumn,
        PhoneColumn = mapping.Period.PhoneColumn,
        TierColumn = mapping.Period.TierColumn,
        HeaderRow = mapping.Period.HeaderRow,
        CallbackUserIdColumn = mapping.Callback.UserIdColumn,
        CallbackPayColumn = mapping.Callback.PayColumn,
        CallbackWithdrawColumn = mapping.Callback.WithdrawColumn,
        CallbackPhoneColumn = mapping.Callback.PhoneColumn,
        CallbackTierColumn = mapping.Callback.TierColumn,
        CallbackHeaderRow = mapping.Callback.HeaderRow,
        UnclaimedUserIdColumn = mapping.UnclaimedUserIdColumn
    };

    private static void ApplyColumnMapping(SiteColumnMapping entity, SiteMappingConfig mapping)
    {
        entity.UserIdColumn = mapping.Period.UserIdColumn;
        entity.PayColumn = mapping.Period.PayColumn;
        entity.WithdrawColumn = mapping.Period.WithdrawColumn;
        entity.PhoneColumn = mapping.Period.PhoneColumn;
        entity.TierColumn = mapping.Period.TierColumn;
        entity.HeaderRow = mapping.Period.HeaderRow;
        entity.CallbackUserIdColumn = mapping.Callback.UserIdColumn;
        entity.CallbackPayColumn = mapping.Callback.PayColumn;
        entity.CallbackWithdrawColumn = mapping.Callback.WithdrawColumn;
        entity.CallbackPhoneColumn = mapping.Callback.PhoneColumn;
        entity.CallbackTierColumn = mapping.Callback.TierColumn;
        entity.CallbackHeaderRow = mapping.Callback.HeaderRow;
        entity.UnclaimedUserIdColumn = mapping.UnclaimedUserIdColumn;
    }

    private static Activity MapActivity(ActivityEditModel model, DateTime createdAt, DateTime updatedAt) => new()
    {
        SiteId = model.SiteId,
        Name = model.Name.Trim(),
        Rate = model.Rate,
        Divisor = model.Divisor,
        MinBonus = model.MinBonus,
        MaxBonus = model.MaxBonus,
        DefaultWageringMultiplier = model.DefaultWageringMultiplier,
        AppRemark = model.AppRemark ?? string.Empty,
        BackendRemark = model.BackendRemark ?? string.Empty,
        AllowProfitMember = model.AllowProfitMember,
        IsEnabled = model.IsEnabled,
        FilterTierKeywords = Extensions.SerializeTierKeywords(model.FilterTierKeywords),
        SortOrder = model.SortOrder,
        ApplyToAllSites = model.ApplyToAllSites,
        Kind = model.Kind,
        WeeklyDayRatesJson = model.WeeklyDayRates.Serialize(),
        DefaultTimezone = Extensions.FormatTimezoneValue(model.DefaultTimezone),
        FilterLossMember = model.FilterLossMember,
        FilterUnclaimedEnabled = model.FilterUnclaimedEnabled,
        MinNetDiff = model.MinNetDiff,
        TieredAmountRatesJson = model.TieredAmountRates.Serialize(),
        InactiveDaysMax = model.InactiveDaysMax,
        UseNetDiffColumn = model.UseNetDiffColumn,
        FilterRechargeEnabled = model.FilterRechargeEnabled,
        TieredFixedBonusesJson = model.TieredFixedBonuses.Serialize(),
        ComprehensiveFeaturesJson = model.ComprehensiveFeatures.Serialize(),
        CreatedAt = createdAt,
        UpdatedAt = updatedAt
    };

    private static void ApplyActivity(Activity entity, ActivityEditModel model)
    {
        entity.Name = model.Name.Trim();
        entity.Rate = model.Rate;
        entity.Divisor = model.Divisor;
        entity.MinBonus = model.MinBonus;
        entity.MaxBonus = model.MaxBonus;
        entity.DefaultWageringMultiplier = model.DefaultWageringMultiplier;
        entity.AppRemark = model.AppRemark ?? string.Empty;
        entity.BackendRemark = model.BackendRemark ?? string.Empty;
        entity.AllowProfitMember = model.AllowProfitMember;
        entity.IsEnabled = model.IsEnabled;
        entity.FilterTierKeywords = Extensions.SerializeTierKeywords(model.FilterTierKeywords);
        entity.SortOrder = model.SortOrder;
        entity.ApplyToAllSites = model.ApplyToAllSites;
        entity.Kind = model.Kind;
        entity.WeeklyDayRatesJson = model.WeeklyDayRates.Serialize();
        entity.DefaultTimezone = Extensions.FormatTimezoneValue(model.DefaultTimezone);
        entity.FilterLossMember = model.FilterLossMember;
        entity.FilterUnclaimedEnabled = model.FilterUnclaimedEnabled;
        entity.MinNetDiff = model.MinNetDiff;
        entity.TieredAmountRatesJson = model.TieredAmountRates.Serialize();
        entity.InactiveDaysMax = model.InactiveDaysMax;
        entity.UseNetDiffColumn = model.UseNetDiffColumn;
        entity.FilterRechargeEnabled = model.FilterRechargeEnabled;
        entity.TieredFixedBonusesJson = model.TieredFixedBonuses.Serialize();
        entity.ComprehensiveFeaturesJson = model.ComprehensiveFeatures.Serialize();
        if (model.Kind == ActivityKind.ComprehensiveCallback)
        {
            entity.ApplyToAllSites = true;
            entity.SiteId = null;
        }
    }

    private static async Task<string> GenerateCopyNameAsync(
        AppDbContext db,
        string sourceName,
        CancellationToken cancellationToken)
    {
        var baseName = sourceName.Trim();
        var candidate = $"{baseName} 副本";
        var index = 2;
        while (await db.Activities.AnyAsync(a => a.Name == candidate, cancellationToken))
        {
            candidate = $"{baseName} 副本{index}";
            index++;
        }
        return candidate;
    }

    /// <summary>加载活动 + 合并系统默认，供 ProcessView 初始化派奖字段</summary>
    public async Task<ActivityRuntimeParams?> GetRuntimeParamsAsync(
        int activityId,
        CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var activity = await db.Activities.AsNoTracking()
            .FirstOrDefaultAsync(a => a.Id == activityId, cancellationToken);
        if (activity is null)
            return null;

        var settings = await db.AppSettings.AsNoTracking().FirstAsync(cancellationToken);
        return Extensions.MergeRuntimeParams(activity, settings);
    }
}

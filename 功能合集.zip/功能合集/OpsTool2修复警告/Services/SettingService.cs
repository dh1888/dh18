using Microsoft.EntityFrameworkCore;
using DHPG.Common;
using DHPG.Data;

namespace DHPG.Services;

/// <summary>
/// 系统设置读写、主题切换、日志等级。
/// 不存储活动参数。
/// </summary>
public class SettingService
{
    private readonly IDbContextFactory<AppDbContext> _dbFactory;

    public SettingService(IDbContextFactory<AppDbContext> dbFactory)
    {
        _dbFactory = dbFactory;
    }

    public async Task<AppSettingsModel> GetAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var entity = await db.AppSettings.AsNoTracking().FirstOrDefaultAsync(cancellationToken)
            ?? throw new InvalidOperationException("系统设置未初始化，请重启应用。");
        return entity.ToModel();
    }

    public async Task SaveAsync(AppSettingsModel model, CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var entity = await db.AppSettings.FirstOrDefaultAsync(cancellationToken)
            ?? throw new InvalidOperationException("系统设置未初始化，请重启应用。");

        entity.ExportDirectory = model.ExportDirectory;
        entity.DefaultWageringMultiplier = model.DefaultWageringMultiplier;
        entity.DefaultAppRemark = model.DefaultAppRemark;
        entity.DefaultBackendRemark = model.DefaultBackendRemark;
        entity.Theme = model.Theme;
        entity.LogLevel = model.LogLevel;
        await db.SaveChangesAsync(cancellationToken);
    }

    /// <summary>切换 HandyControl 浅色/深色主题</summary>
    public void ApplyTheme(string theme) => ThemeManager.Apply(theme);
}

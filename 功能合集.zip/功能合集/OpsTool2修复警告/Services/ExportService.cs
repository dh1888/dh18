using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using DHPG.Common;
using DHPG.Data;

namespace DHPG.Services;

/// <summary>
/// 导出 Excel（三 Sheet）、JSON、派奖表复制到剪贴板。
/// </summary>
public class ExportService
{
    private const int AutoFitSampleRowLimit = 500;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false
    };

    private readonly IDbContextFactory<AppDbContext>? _dbFactory;
    private readonly ResultRepository _resultRepository;

    static ExportService()
    {
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
    }

    public ExportService(
        IDbContextFactory<AppDbContext>? dbFactory = null,
        ResultRepository? resultRepository = null)
    {
        _dbFactory = dbFactory;
        _resultRepository = resultRepository ?? new ResultRepository();
    }

    /// <summary>
    /// 导出 Excel：派奖 Sheet + 明细 Sheet + 汇总 Sheet。
    /// 默认文件名：{站点Code}_{活动Name}_{yyyyMMdd_HHmmss}.xlsx
    /// </summary>
    public async Task<ExportResult> ExportExcelAsync(
        ProcessResult result,
        ExportOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var directory = await ResolveDirectoryAsync(options, cancellationToken);
            Directory.CreateDirectory(directory);

            var fileName = options?.FileName;
            if (string.IsNullOrWhiteSpace(fileName))
            {
                var stamp = result.ProcessedAt.ToString("yyyyMMdd_HHmmss");
                fileName = $"{SanitizeFileName(result.SiteCode)}_{SanitizeFileName(result.ActivityName)}_{stamp}.xlsx";
            }

            var filePath = Path.Combine(directory, fileName);
            cancellationToken.ThrowIfCancellationRequested();

            await Task.Run(() => WriteExcelWorkbook(result, filePath), cancellationToken);

            return new ExportResult
            {
                Success = true,
                FilePath = filePath,
                Message = "Excel 导出成功。"
            };
        }
        catch (Exception ex)
        {
            return new ExportResult
            {
                Success = false,
                Message = $"Excel 导出失败：{ex.Message}"
            };
        }
    }

    public async Task<ExportResult> ExportJsonAsync(
        ProcessResult result,
        ExportOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var directory = await ResolveDirectoryAsync(options, cancellationToken);
            Directory.CreateDirectory(directory);

            var fileName = options?.FileName;
            if (string.IsNullOrWhiteSpace(fileName))
            {
                var stamp = result.ProcessedAt.ToString("yyyyMMdd_HHmmss");
                fileName = $"{SanitizeFileName(result.SiteCode)}_{SanitizeFileName(result.ActivityName)}_{stamp}.json";
            }

            var filePath = Path.Combine(directory, fileName);
            cancellationToken.ThrowIfCancellationRequested();

            await Task.Run(
                () =>
                {
                    if (!string.IsNullOrEmpty(result.ResultCacheKey))
                        WriteJsonFromCache(result, filePath);
                    else
                        File.WriteAllText(filePath, JsonSerializer.Serialize(result, JsonOptions), Encoding.UTF8);
                },
                cancellationToken);

            return new ExportResult
            {
                Success = true,
                FilePath = filePath,
                Message = "JSON 导出成功。"
            };
        }
        catch (Exception ex)
        {
            return new ExportResult
            {
                Success = false,
                Message = $"JSON 导出失败：{ex.Message}"
            };
        }
    }

    /// <summary>派奖表 TSV 复制到剪贴板</summary>
    public void CopyRewardsToClipboard(ProcessResult result)
    {
        if (!string.IsNullOrEmpty(result.ResultCacheKey))
        {
            if (result.UsesSplitRewards)
            {
                var text = BuildSplitRewardTsv(
                    _resultRepository.StreamRewards(result.ResultCacheKey, RewardStreamKind.Loss),
                    _resultRepository.StreamRewards(result.ResultCacheKey, RewardStreamKind.Profit));
                Clipboard.SetText(text);
            }
            else
            {
                Clipboard.SetText(BuildRewardTsv(
                    _resultRepository.StreamRewards(result.ResultCacheKey, RewardStreamKind.Merged)));
            }

            return;
        }

        var textLegacy = result.UsesSplitRewards
            ? BuildSplitRewardTsv(result.LossRewards, result.ProfitRewards)
            : BuildRewardTsv(result.Rewards);
        Clipboard.SetText(textLegacy);
    }

    public void CopyRewardsToClipboard(IEnumerable<RewardItem> rewards) =>
        CopyRewardsToClipboardAsync(rewards).GetAwaiter().GetResult();

    /// <summary>后台构建 TSV，回到 UI 线程写入剪贴板。</summary>
    public async Task CopyRewardsToClipboardAsync(IEnumerable<RewardItem> rewards)
    {
        var text = await Task.Run(() => BuildRewardTsv(rewards)).ConfigureAwait(true);
        Clipboard.SetText(text);
    }

    public async Task CopySplitRewardsToClipboardAsync(
        IEnumerable<RewardItem> lossRewards,
        IEnumerable<RewardItem> profitRewards)
    {
        var text = await Task.Run(() => BuildSplitRewardTsv(lossRewards, profitRewards)).ConfigureAwait(true);
        Clipboard.SetText(text);
    }

    /// <summary>从历史快照重新导出 Excel（优先返回原导出文件路径）</summary>
    public async Task<ExportResult> ExportHistoryExcelAsync(
        HistoryDetailModel history,
        ExportOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        if (!string.IsNullOrWhiteSpace(history.ExportFilePath) && File.Exists(history.ExportFilePath))
        {
            return new ExportResult
            {
                Success = true,
                FilePath = history.ExportFilePath,
                Message = "已定位到原导出文件。"
            };
        }

        var snapshot = history.Snapshot;
        if (!string.IsNullOrEmpty(snapshot.ResultCacheKey)
            && _resultRepository.Exists(snapshot.ResultCacheKey))
        {
            var cached = _resultRepository.LoadSummary(snapshot.ResultCacheKey);
            cached.ProcessedAt = history.ProcessedAt;
            cached.SiteName = history.SiteName;
            cached.ActivityName = history.ActivityName;
            cached.Snapshot = snapshot;

            var cacheExportOptions = options ?? new ExportOptions();
            if (string.IsNullOrWhiteSpace(cacheExportOptions.FileName))
            {
                var stamp = history.ProcessedAt.ToString("yyyyMMdd_HHmmss");
                cacheExportOptions.FileName =
                    $"历史_{SanitizeFileName(snapshot.Site.Code)}_{SanitizeFileName(history.ActivityName)}_{stamp}.xlsx";
            }

            var cacheResult = await ExportExcelAsync(cached, cacheExportOptions, cancellationToken);
            if (cacheResult.Success)
                cacheResult.Message = "历史记录已从缓存导出全量 Excel。";

            return cacheResult;
        }

        var preview = snapshot.ResultPreview;
        var usesSplit = preview?.UsesSplitRewards == true;
        var result = new ProcessResult
        {
            ProcessedAt = history.ProcessedAt,
            SiteId = snapshot.Site.Id,
            SiteName = history.SiteName,
            SiteCode = snapshot.Site.Code,
            ActivityId = snapshot.Activity.Id,
            ActivityName = history.ActivityName,
            Summary = snapshot.Summary.TotalCount > 0 ? snapshot.Summary : history.Summary,
            UsesSplitRewards = usesSplit,
            Details = preview?.DetailSample ?? new List<ProcessDetailItem>(),
            Rewards = usesSplit ? new List<RewardItem>() : preview?.RewardSample ?? new List<RewardItem>(),
            LossRewards = usesSplit ? preview?.LossRewardSample ?? new List<RewardItem>() : new List<RewardItem>(),
            ProfitRewards = usesSplit ? preview?.ProfitRewardSample ?? new List<RewardItem>() : new List<RewardItem>(),
            Snapshot = snapshot
        };

        var exportOptions = options ?? new ExportOptions();
        if (string.IsNullOrWhiteSpace(exportOptions.FileName))
        {
            var stamp = history.ProcessedAt.ToString("yyyyMMdd_HHmmss");
            exportOptions.FileName =
                $"历史_{SanitizeFileName(snapshot.Site.Code)}_{SanitizeFileName(history.ActivityName)}_{stamp}.xlsx";
        }

        var exportResult = await ExportExcelAsync(result, exportOptions, cancellationToken);
        if (exportResult.Success)
            exportResult.Message = "历史记录已导出（明细/派奖为快照样本，非全量行）。";

        return exportResult;
    }

    /// <summary>
    /// 批量导出：每个成功站点各生成 Excel；多文件时额外打包 ZIP。
    /// ZIP 文件名：{活动Name}_批量_{yyyyMMdd_HHmmss}.zip
    /// </summary>
    public async Task<ExportResult> ExportBatchAllAsync(
        BatchProcessResult batch,
        ExportOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var successTasks = batch.Tasks
                .Where(t => t.Status == BatchTaskStatus.Success && t.HasOutcome)
                .ToList();

            if (successTasks.Count == 0)
            {
                return new ExportResult
                {
                    Success = false,
                    Message = "没有可导出的成功站点。"
                };
            }

            var directory = await ResolveDirectoryAsync(options, cancellationToken);
            Directory.CreateDirectory(directory);

            var stamp = batch.FinishedAt == default
                ? DateTime.Now.ToString("yyyyMMdd_HHmmss")
                : batch.FinishedAt.ToString("yyyyMMdd_HHmmss");

            var exportedPaths = new List<string>();
            var usedNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var task in successTasks)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var result = task.ResolveResult(_resultRepository)!;
                var fileName = BuildUniqueExcelFileName(result, stamp, usedNames);
                var export = await ExportExcelAsync(result, new ExportOptions
                {
                    OutputDirectory = directory,
                    FileName = fileName
                }, cancellationToken);

                if (!export.Success)
                {
                    return new ExportResult
                    {
                        Success = false,
                        Message = $"导出 {result.SiteName} 失败：{export.Message}"
                    };
                }

                exportedPaths.Add(export.FilePath);
            }

            if (exportedPaths.Count == 1)
            {
                return new ExportResult
                {
                    Success = true,
                    FilePath = exportedPaths[0],
                    Message = "已导出 1 个站点的 Excel。"
                };
            }

            var zipName = $"{SanitizeFileName(batch.ActivityName)}_批量_{stamp}.zip";
            var zipPath = Path.Combine(directory, zipName);
            if (File.Exists(zipPath))
                File.Delete(zipPath);

            using (var archive = ZipFile.Open(zipPath, ZipArchiveMode.Create))
            {
                foreach (var path in exportedPaths)
                {
                    archive.CreateEntryFromFile(
                        path,
                        Path.GetFileName(path),
                        System.IO.Compression.CompressionLevel.Optimal);
                }
            }

            return new ExportResult
            {
                Success = true,
                FilePath = zipPath,
                Message = $"已导出 {exportedPaths.Count} 个站点 Excel，并打包为 ZIP。"
            };
        }
        catch (Exception ex)
        {
            return new ExportResult
            {
                Success = false,
                Message = $"批量导出失败：{ex.Message}"
            };
        }
    }

    public static string BuildSplitRewardTsv(
        IEnumerable<RewardItem> lossRewards,
        IEnumerable<RewardItem> profitRewards)
    {
        var sb = new StringBuilder();
        sb.AppendLine("【亏损派奖】");
        sb.Append(BuildRewardTsv(lossRewards));
        sb.AppendLine();
        sb.AppendLine("【盈利派奖】");
        sb.Append(BuildRewardTsv(profitRewards));
        return sb.ToString();
    }

    public static string BuildRewardTsv(IEnumerable<RewardItem> rewards)
    {
        var sb = new StringBuilder();
        sb.AppendLine("会员ID\t优惠金额\t打码倍数\tAPP端备注\t后台备注");
        foreach (var item in rewards)
        {
            sb.Append(item.UserId).Append('\t')
                .Append(item.Bonus.ToString("0.00")).Append('\t')
                .Append(item.WageringMultiplier.ToString("0.##")).Append('\t')
                .Append(EscapeTsv(item.AppRemark)).Append('\t')
                .Append(EscapeTsv(item.BackendRemark)).AppendLine();
        }
        return sb.ToString();
    }

    private void WriteExcelWorkbook(ProcessResult result, string filePath)
    {
        using var package = new ExcelPackage();
        if (!string.IsNullOrEmpty(result.ResultCacheKey))
        {
            WriteCachedExcelWorkbook(package, result);
        }
        else if (result.UsesSplitRewards)
        {
            WriteRewardSheet(package, result.LossRewards, "派奖-亏损");
            WriteRewardSheet(package, result.ProfitRewards, "派奖-盈利");
            WriteDetailSheet(package, result.Details);
            WriteSummarySheet(package, result);
        }
        else
        {
            WriteRewardSheet(package, result.Rewards, "派奖结果");
            WriteDetailSheet(package, result.Details);
            WriteSummarySheet(package, result);
        }

        package.SaveAs(new FileInfo(filePath));
    }

    private void WriteCachedExcelWorkbook(ExcelPackage package, ProcessResult result)
    {
        var cacheKey = result.ResultCacheKey;
        if (result.UsesSplitRewards)
        {
            WriteRewardSheetStreaming(package, cacheKey, RewardStreamKind.Loss, "派奖-亏损");
            WriteRewardSheetStreaming(package, cacheKey, RewardStreamKind.Profit, "派奖-盈利");
        }
        else
        {
            WriteRewardSheetStreaming(package, cacheKey, RewardStreamKind.Merged, "派奖结果");
        }

        WriteDetailSheetStreaming(package, cacheKey);
        WriteSummarySheet(package, result);
    }

    private void WriteRewardSheetStreaming(
        ExcelPackage package,
        string cacheKey,
        RewardStreamKind kind,
        string sheetName)
    {
        var count = _resultRepository.CountRewards(cacheKey, kind);
        var sheet = package.Workbook.Worksheets.Add(sheetName);
        sheet.Cells[1, 1].Value = "会员ID";
        sheet.Cells[1, 2].Value = "优惠金额";
        sheet.Cells[1, 3].Value = "打码倍数";
        sheet.Cells[1, 4].Value = "APP端备注";
        sheet.Cells[1, 5].Value = "后台备注";
        StyleHeaderRow(sheet, 1, 5);

        var row = 2;
        foreach (var item in _resultRepository.StreamRewards(cacheKey, kind))
        {
            sheet.Cells[row, 1].Value = item.UserId;
            sheet.Cells[row, 2].Value = item.Bonus;
            sheet.Cells[row, 3].Value = item.WageringMultiplier;
            sheet.Cells[row, 4].Value = item.AppRemark;
            sheet.Cells[row, 5].Value = item.BackendRemark;
            row++;
        }

        ApplyDataSheetColumnWidths(sheet, colCount: 5, dataRowCount: count);
    }

    private void WriteDetailSheetStreaming(ExcelPackage package, string cacheKey)
    {
        var count = _resultRepository.CountDetails(cacheKey, excludedOnly: false);
        var sheet = package.Workbook.Worksheets.Add("处理明细");
        sheet.Cells[1, 1].Value = "会员ID";
        sheet.Cells[1, 2].Value = "手机号";
        sheet.Cells[1, 3].Value = "充值";
        sheet.Cells[1, 4].Value = "提现";
        sheet.Cells[1, 5].Value = "盈亏";
        sheet.Cells[1, 6].Value = "彩金";
        sheet.Cells[1, 7].Value = "层级";
        sheet.Cells[1, 8].Value = "剔除原因";
        StyleHeaderRow(sheet, 1, 8);

        var row = 2;
        foreach (var item in _resultRepository.StreamDetails(cacheKey))
        {
            sheet.Cells[row, 1].Value = item.UserId;
            sheet.Cells[row, 2].Value = item.Phone ?? string.Empty;
            sheet.Cells[row, 3].Value = item.Pay;
            sheet.Cells[row, 4].Value = item.Withdraw;
            sheet.Cells[row, 5].Value = item.Profit;
            sheet.Cells[row, 6].Value = item.Bonus;
            sheet.Cells[row, 7].Value = item.Tier ?? string.Empty;
            sheet.Cells[row, 8].Value = item.ExcludeReason ?? string.Empty;
            row++;
        }

        ApplyDataSheetColumnWidths(sheet, colCount: 8, dataRowCount: count);
    }

    private void WriteJsonFromCache(ProcessResult result, string filePath)
    {
        using var stream = File.Create(filePath);
        using var writer = new Utf8JsonWriter(stream, new JsonWriterOptions { Indented = false });

        writer.WriteStartObject();
        writer.WriteString("processedAt", result.ProcessedAt);
        writer.WriteNumber("siteId", result.SiteId);
        writer.WriteString("siteName", result.SiteName);
        writer.WriteString("siteCode", result.SiteCode);
        writer.WriteNumber("activityId", result.ActivityId);
        writer.WriteString("activityName", result.ActivityName);
        writer.WriteBoolean("usesSplitRewards", result.UsesSplitRewards);
        writer.WriteString("resultCacheKey", result.ResultCacheKey);

        writer.WritePropertyName("summary");
        JsonSerializer.Serialize(writer, result.Summary, JsonOptions);

        writer.WritePropertyName("snapshot");
        JsonSerializer.Serialize(writer, result.Snapshot, JsonOptions);

        writer.WritePropertyName("details");
        writer.WriteStartArray();
        foreach (var item in _resultRepository.StreamDetails(result.ResultCacheKey))
            JsonSerializer.Serialize(writer, item, JsonOptions);
        writer.WriteEndArray();

        if (result.UsesSplitRewards)
        {
            writer.WritePropertyName("lossRewards");
            writer.WriteStartArray();
            foreach (var item in _resultRepository.StreamRewards(result.ResultCacheKey, RewardStreamKind.Loss))
                JsonSerializer.Serialize(writer, item, JsonOptions);
            writer.WriteEndArray();

            writer.WritePropertyName("profitRewards");
            writer.WriteStartArray();
            foreach (var item in _resultRepository.StreamRewards(result.ResultCacheKey, RewardStreamKind.Profit))
                JsonSerializer.Serialize(writer, item, JsonOptions);
            writer.WriteEndArray();

            writer.WritePropertyName("rewards");
            writer.WriteStartArray();
            writer.WriteEndArray();
        }
        else
        {
            writer.WritePropertyName("rewards");
            writer.WriteStartArray();
            foreach (var item in _resultRepository.StreamRewards(result.ResultCacheKey, RewardStreamKind.Merged))
                JsonSerializer.Serialize(writer, item, JsonOptions);
            writer.WriteEndArray();

            writer.WritePropertyName("lossRewards");
            writer.WriteStartArray();
            writer.WriteEndArray();

            writer.WritePropertyName("profitRewards");
            writer.WriteStartArray();
            writer.WriteEndArray();
        }

        writer.WriteEndObject();
    }

    private static void WriteRewardSheet(ExcelPackage package, IList<RewardItem> rewards, string sheetName)
    {
        var sheet = package.Workbook.Worksheets.Add(sheetName);
        sheet.Cells[1, 1].Value = "会员ID";
        sheet.Cells[1, 2].Value = "优惠金额";
        sheet.Cells[1, 3].Value = "打码倍数";
        sheet.Cells[1, 4].Value = "APP端备注";
        sheet.Cells[1, 5].Value = "后台备注";
        StyleHeaderRow(sheet, 1, 5);

        if (rewards.Count > 0)
        {
            var rows = new object[rewards.Count][];
            for (var i = 0; i < rewards.Count; i++)
            {
                var item = rewards[i];
                rows[i] =
                [
                    item.UserId,
                    item.Bonus,
                    item.WageringMultiplier,
                    item.AppRemark,
                    item.BackendRemark
                ];
            }

            sheet.Cells[2, 1].LoadFromArrays(rows);
        }

        ApplyDataSheetColumnWidths(sheet, colCount: 5, dataRowCount: rewards.Count);
    }

    private static void WriteDetailSheet(ExcelPackage package, IList<ProcessDetailItem> details)
    {
        var sheet = package.Workbook.Worksheets.Add("处理明细");
        sheet.Cells[1, 1].Value = "会员ID";
        sheet.Cells[1, 2].Value = "手机号";
        sheet.Cells[1, 3].Value = "充值";
        sheet.Cells[1, 4].Value = "提现";
        sheet.Cells[1, 5].Value = "盈亏";
        sheet.Cells[1, 6].Value = "彩金";
        sheet.Cells[1, 7].Value = "层级";
        sheet.Cells[1, 8].Value = "剔除原因";
        StyleHeaderRow(sheet, 1, 8);

        if (details.Count > 0)
        {
            var rows = new object[details.Count][];
            for (var i = 0; i < details.Count; i++)
            {
                var item = details[i];
                rows[i] =
                [
                    item.UserId,
                    item.Phone ?? string.Empty,
                    item.Pay,
                    item.Withdraw,
                    item.Profit,
                    item.Bonus,
                    item.Tier ?? string.Empty,
                    item.ExcludeReason ?? string.Empty
                ];
            }

            sheet.Cells[2, 1].LoadFromArrays(rows);
        }

        ApplyDataSheetColumnWidths(sheet, colCount: 8, dataRowCount: details.Count);
    }

    private static void WriteSummarySheet(ExcelPackage package, ProcessResult result)
    {
        var sheet = package.Workbook.Worksheets.Add("汇总");
        var s = result.Snapshot;
        var rows = new (string Key, object? Value)[]
        {
            ("处理时间", result.ProcessedAt.ToString("yyyy-MM-dd HH:mm:ss")),
            ("站点", $"{result.SiteName} ({result.SiteCode})"),
            ("活动", result.ActivityName),
            ("上传会员行数", result.Summary.TotalCount),
            ("过滤人数", result.Summary.FilteredCount),
            ("派奖人数", result.Summary.RewardCount),
            ("总彩金", result.Summary.TotalBonus),
            ("亏损派奖人数", result.UsesSplitRewards ? result.Summary.LossRewardCount : null),
            ("亏损总彩金", result.UsesSplitRewards ? result.Summary.LossTotalBonus : null),
            ("盈利派奖人数", result.UsesSplitRewards ? result.Summary.ProfitRewardCount : null),
            ("盈利总彩金", result.UsesSplitRewards ? result.Summary.ProfitTotalBonus : null),
            ("彩金比例", s.Activity.Rate),
            ("除数", s.Activity.Divisor),
            ("最低彩金", s.Activity.MinBonus),
            ("最高彩金", s.Activity.MaxBonus),
            ("允许盈利会员", s.ProcessOptions.IncludeProfitMember ? "是" : "否"),
            ("过滤未领", s.ProcessOptions.FilterUnclaimed ? "是" : "否"),
            ("打码倍数", s.RewardSettings.WageringMultiplier),
            ("APP备注", s.RewardSettings.AppRemark),
            ("后台备注", s.RewardSettings.BackendRemark),
            ("层级关键字", string.Join(", ", s.Activity.FilterTierKeywords)),
            ("参数快照 JSON", Extensions.SerializeSnapshot(s))
        };

        sheet.Cells[1, 1].Value = "项目";
        sheet.Cells[1, 2].Value = "值";
        StyleHeaderRow(sheet, 1, 2);

        var summaryRows = new object[rows.Length][];
        for (var i = 0; i < rows.Length; i++)
            summaryRows[i] = new object[] { rows[i].Key, rows[i].Value! };

        sheet.Cells[2, 1].LoadFromArrays(summaryRows);
        ApplyDataSheetColumnWidths(sheet, colCount: 2, dataRowCount: rows.Length);
        sheet.Column(2).Width = Math.Max(sheet.Column(2).Width, 40);
    }

    private static void ApplyDataSheetColumnWidths(OfficeOpenXml.ExcelWorksheet sheet, int colCount, int dataRowCount)
    {
        var fitEndRow = dataRowCount == 0
            ? 1
            : Math.Min(dataRowCount + 1, AutoFitSampleRowLimit + 1);

        sheet.Cells[1, 1, fitEndRow, colCount].AutoFitColumns();
    }

    private static void StyleHeaderRow(OfficeOpenXml.ExcelWorksheet sheet, int row, int colCount)
    {
        using var range = sheet.Cells[row, 1, row, colCount];
        range.Style.Font.Bold = true;
        range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
        range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.FromArgb(236, 245, 255));
    }

    private async Task<string> ResolveDirectoryAsync(ExportOptions? options, CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(options?.OutputDirectory))
            return options.OutputDirectory.Trim();

        if (_dbFactory is not null)
        {
            await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
            var settings = await db.AppSettings.AsNoTracking().FirstAsync(cancellationToken);
            if (!string.IsNullOrWhiteSpace(settings.ExportDirectory))
                return settings.ExportDirectory;
        }

        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "DHPG");
    }

    private static string SanitizeFileName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            return "未命名";

        var invalid = Path.GetInvalidFileNameChars();
        var sanitized = string.Concat(name.Trim().Select(ch => invalid.Contains(ch) ? '_' : ch));
        return string.IsNullOrWhiteSpace(sanitized) ? "未命名" : sanitized;
    }

    private static string BuildUniqueExcelFileName(
        ProcessResult result,
        string stamp,
        ISet<string> usedNames)
    {
        var baseName =
            $"{SanitizeFileName(result.SiteCode)}_{SanitizeFileName(result.ActivityName)}_{stamp}.xlsx";
        var fileName = baseName;
        var counter = 1;

        while (!usedNames.Add(fileName))
        {
            var nameWithoutExt = Path.GetFileNameWithoutExtension(baseName);
            fileName = $"{nameWithoutExt}_{counter}.xlsx";
            counter++;
        }

        return fileName;
    }

    private static string EscapeTsv(string? value)
    {
        if (string.IsNullOrEmpty(value))
            return string.Empty;

        return value.Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
    }
}

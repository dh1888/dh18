using DHPG.Common;

namespace DHPG.Services;

/// <summary>单例批量任务协调：进度轮询、取消、结果缓存。</summary>
public sealed class BatchRunCoordinator
{
    private readonly object _gate = new();
    private CancellationTokenSource? _cts;
    private BatchProcessProgress? _progress;
    private BatchProcessResult? _result;
    private string? _error;
    private bool _running;

    public BatchStatusDto GetStatus()
    {
        lock (_gate)
        {
            return new BatchStatusDto
            {
                Running = _running,
                Progress = _progress,
                Result = _result is null ? null : BatchApiMapper.ToResultDto(_result),
                Error = _error
            };
        }
    }

    public void Cancel()
    {
        lock (_gate)
            _cts?.Cancel();
    }

    public async Task StartAsync(BatchProcessRequest request, ProcessService processService)
    {
        lock (_gate)
        {
            if (_running)
                throw new InvalidOperationException("已有批量任务正在运行。");

            _running = true;
            _result = null;
            _error = null;
            _progress = new BatchProcessProgress { Phase = "准备", Message = "正在启动批量处理..." };
            _cts = new CancellationTokenSource();
        }

        var token = _cts!.Token;
        try
        {
            var result = await processService.ProcessBatchAsync(
                request,
                new Progress<BatchProcessProgress>(p =>
                {
                    lock (_gate)
                        _progress = p;
                }),
                new Progress<ProcessProgress>(p =>
                {
                    if (string.IsNullOrEmpty(p.Message))
                        return;

                    lock (_gate)
                    {
                        _progress ??= new BatchProcessProgress();
                        _progress.Message = p.Message;
                    }
                }),
                token).ConfigureAwait(false);

            lock (_gate)
            {
                _result = result;
                _running = false;
            }
        }
        catch (OperationCanceledException)
        {
            lock (_gate)
            {
                _error = "已取消";
                _running = false;
            }
        }
        catch (Exception ex)
        {
            lock (_gate)
            {
                _error = ex.Message;
                _running = false;
            }
        }
    }
}

using System.Collections.Concurrent;
using System.IO;
using System.Text;
using System.Text.Json;
using DHPG.Common;

namespace DHPG.Services;

public enum RewardStreamKind
{
    Merged = 0,
    Loss = 1,
    Profit = 2
}

/// <summary>流式写入处理结果到磁盘缓存（NDJSON + 偏移索引）。</summary>
public sealed class ResultWriteSession : IDisposable
{
    internal readonly string CacheKey;
    internal readonly string Directory;
    internal readonly FileStream DetailsStream;
    internal readonly StreamWriter DetailsWriter;
    internal readonly Dictionary<RewardStreamKind, FileStream> RewardStreams = new();
    internal readonly Dictionary<RewardStreamKind, StreamWriter> RewardWriters = new();
    internal readonly List<long> DetailOffsets = new();
    internal readonly List<int> ExcludedDetailSeq = new();
    internal readonly List<ProcessDetailItem> DetailSample = new();
    internal readonly List<RewardItem> RewardSample = new();
    internal readonly List<RewardItem> LossRewardSample = new();
    internal readonly List<RewardItem> ProfitRewardSample = new();

    internal readonly Dictionary<RewardStreamKind, List<long>> RewardOffsets = new()
    {
        [RewardStreamKind.Merged] = new(),
        [RewardStreamKind.Loss] = new(),
        [RewardStreamKind.Profit] = new()
    };

    internal int DetailSeq;
    internal int FilteredCount;
    internal int MergedRewardCount;
    internal int LossRewardCount;
    internal int ProfitRewardCount;
    internal decimal MergedBonusTotal;
    internal decimal LossBonusTotal;
    internal decimal ProfitBonusTotal;

    internal ResultWriteSession(string cacheKey, string directory)
    {
        CacheKey = cacheKey;
        Directory = directory;
        DetailsStream = OpenStream("details.ndjson");
        DetailsWriter = CreateWriter(DetailsStream);

        foreach (var kind in new[] { RewardStreamKind.Merged, RewardStreamKind.Loss, RewardStreamKind.Profit })
        {
            var stream = OpenStream(GetRewardFileName(kind));
            RewardStreams[kind] = stream;
            RewardWriters[kind] = CreateWriter(stream);
        }
    }

    private FileStream OpenStream(string fileName) =>
        new(Path.Combine(Directory, fileName), FileMode.Create, FileAccess.Write, FileShare.Read);

    private static StreamWriter CreateWriter(FileStream stream) =>
        new(stream, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false), bufferSize: 65536, leaveOpen: true)
        {
            AutoFlush = true
        };

    public void Dispose()
    {
        DetailsWriter.Dispose();
        DetailsStream.Dispose();
        foreach (var writer in RewardWriters.Values)
            writer.Dispose();
        foreach (var stream in RewardStreams.Values)
            stream.Dispose();
    }

    internal static string GetRewardFileName(RewardStreamKind kind) => kind switch
    {
        RewardStreamKind.Loss => "loss_rewards.ndjson",
        RewardStreamKind.Profit => "profit_rewards.ndjson",
        _ => "rewards.ndjson"
    };

    internal static string GetRewardOffsetFileName(RewardStreamKind kind) => kind switch
    {
        RewardStreamKind.Loss => "loss_rewards.offsets",
        RewardStreamKind.Profit => "profit_rewards.offsets",
        _ => "rewards.offsets"
    };
}

public sealed class CachedResultMeta
{
    public string CacheKey { get; set; } = string.Empty;
    public DateTime ProcessedAt { get; set; }
    public int SiteId { get; set; }
    public string SiteName { get; set; } = string.Empty;
    public string SiteCode { get; set; } = string.Empty;
    public int ActivityId { get; set; }
    public string ActivityName { get; set; } = string.Empty;
    public bool UsesSplitRewards { get; set; }
    public ProcessSummary Summary { get; set; } = new();
    public ProcessSnapshot Snapshot { get; set; } = new();
    public string? ExportFilePath { get; set; }
    public int DetailCount { get; set; }
    public int ExcludedCount { get; set; }
    public int MergedRewardCount { get; set; }
    public int LossRewardCount { get; set; }
    public int ProfitRewardCount { get; set; }
}

/// <summary>处理结果磁盘缓存：流式写入、按页读取、流式导出。</summary>
public class ResultRepository
{
    private const int SampleSize = 20;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false
    };

    private readonly string _rootDirectory;
    private readonly ConcurrentDictionary<string, long[]> _detailOffsetCache = new();
    private readonly ConcurrentDictionary<string, int[]> _excludedIndexCache = new();
    private readonly ConcurrentDictionary<string, long[]> _rewardOffsetCache = new();
    private readonly ConcurrentDictionary<string, CachedResultMeta> _metaCache = new();

    public ResultRepository(string? rootDirectory = null)
    {
        _rootDirectory = rootDirectory ?? Path.Combine(Helpers.AppDataDir, "results");
        Directory.CreateDirectory(_rootDirectory);
    }

    public string CreateCacheKey() => Guid.NewGuid().ToString("N");

    public ResultWriteSession BeginWrite(string cacheKey)
    {
        var directory = GetCacheDirectory(cacheKey);
        if (Directory.Exists(directory))
            Directory.Delete(directory, recursive: true);

        Directory.CreateDirectory(directory);
        return new ResultWriteSession(cacheKey, directory);
    }

    public void AppendDetail(ResultWriteSession session, ProcessDetailItem detail)
    {
        session.DetailOffsets.Add(session.DetailsStream.Position);
        WriteLine(session.DetailsWriter, detail);

        if (detail.IsExcluded)
        {
            session.ExcludedDetailSeq.Add(session.DetailSeq);
            session.FilteredCount++;
        }

        if (session.DetailSample.Count < SampleSize)
            session.DetailSample.Add(detail);

        session.DetailSeq++;
    }

    public void AppendReward(ResultWriteSession session, RewardStreamKind kind, RewardItem reward)
    {
        var stream = session.RewardStreams[kind];
        session.RewardOffsets[kind].Add(stream.Position);
        WriteLine(session.RewardWriters[kind], reward);
        var roundedBonus = Math.Round(reward.Bonus, 2, MidpointRounding.AwayFromZero);

        switch (kind)
        {
            case RewardStreamKind.Loss:
                session.LossRewardCount++;
                session.LossBonusTotal += roundedBonus;
                if (session.LossRewardSample.Count < SampleSize)
                    session.LossRewardSample.Add(reward);
                break;
            case RewardStreamKind.Profit:
                session.ProfitRewardCount++;
                session.ProfitBonusTotal += roundedBonus;
                if (session.ProfitRewardSample.Count < SampleSize)
                    session.ProfitRewardSample.Add(reward);
                break;
            default:
                session.MergedRewardCount++;
                session.MergedBonusTotal += roundedBonus;
                if (session.RewardSample.Count < SampleSize)
                    session.RewardSample.Add(reward);
                break;
        }
    }

    public ProcessResult Complete(
        ResultWriteSession session,
        ProcessSummary summary,
        ProcessSnapshot snapshot,
        bool usesSplitRewards,
        int siteId,
        string siteName,
        string siteCode,
        int activityId,
        string activityName)
    {
        session.DetailsWriter.Flush();
        foreach (var writer in session.RewardWriters.Values)
            writer.Flush();

        WriteOffsetIndex(session.Directory, "details.offsets", session.DetailOffsets);
        WriteIntIndex(session.Directory, "excluded.idx", session.ExcludedDetailSeq);
        foreach (var pair in session.RewardOffsets)
            WriteOffsetIndex(session.Directory, ResultWriteSession.GetRewardOffsetFileName(pair.Key), pair.Value);

        snapshot.Summary = summary;
        snapshot.ResultPreview = new SnapshotResultPreview
        {
            UsesSplitRewards = usesSplitRewards,
            DetailSample = session.DetailSample,
            RewardSample = usesSplitRewards ? new List<RewardItem>() : session.RewardSample,
            LossRewardSample = usesSplitRewards ? session.LossRewardSample : new List<RewardItem>(),
            ProfitRewardSample = usesSplitRewards ? session.ProfitRewardSample : new List<RewardItem>()
        };
        snapshot.ResultCacheKey = session.CacheKey;

        var meta = new CachedResultMeta
        {
            CacheKey = session.CacheKey,
            ProcessedAt = snapshot.ProcessedAt,
            SiteId = siteId,
            SiteName = siteName,
            SiteCode = siteCode,
            ActivityId = activityId,
            ActivityName = activityName,
            UsesSplitRewards = usesSplitRewards,
            Summary = summary,
            Snapshot = snapshot,
            DetailCount = session.DetailSeq,
            ExcludedCount = session.FilteredCount,
            MergedRewardCount = session.MergedRewardCount,
            LossRewardCount = session.LossRewardCount,
            ProfitRewardCount = session.ProfitRewardCount
        };

        WriteMeta(session.Directory, meta);
        CacheMeta(session.CacheKey, meta);
        session.Dispose();

        return ToSummaryResult(meta);
    }

    public bool Exists(string cacheKey) => File.Exists(GetMetaPath(cacheKey));

    public CachedResultMeta? TryGetMeta(string cacheKey)
    {
        if (_metaCache.TryGetValue(cacheKey, out var cached))
            return cached;

        var path = GetMetaPath(cacheKey);
        if (!File.Exists(path))
            return null;

        var json = File.ReadAllText(path, Encoding.UTF8);
        var meta = JsonSerializer.Deserialize<CachedResultMeta>(json, JsonOptions);
        if (meta is not null)
            _metaCache[cacheKey] = meta;

        return meta;
    }

    public ProcessResult LoadSummary(string cacheKey)
    {
        var meta = TryGetMeta(cacheKey)
            ?? throw new FileNotFoundException("找不到处理结果缓存。", cacheKey);
        return ToSummaryResult(meta);
    }

    public int CountDetails(string cacheKey, bool excludedOnly)
    {
        var meta = TryGetMeta(cacheKey);
        if (meta is null)
            return 0;

        return excludedOnly ? meta.ExcludedCount : meta.DetailCount;
    }

    public int CountRewards(string cacheKey, RewardStreamKind kind)
    {
        var meta = TryGetMeta(cacheKey);
        if (meta is null)
            return 0;

        return kind switch
        {
            RewardStreamKind.Loss => meta.LossRewardCount,
            RewardStreamKind.Profit => meta.ProfitRewardCount,
            _ => meta.MergedRewardCount
        };
    }

    public List<ProcessDetailItem> ReadDetailPage(string cacheKey, int skip, int take, bool excludedOnly)
    {
        if (take <= 0)
            return new List<ProcessDetailItem>();

        var directory = GetCacheDirectory(cacheKey);
        var offsets = GetCachedDetailOffsets(cacheKey, directory);
        if (offsets.Length == 0)
            return new List<ProcessDetailItem>();

        IEnumerable<int> seqs;
        if (excludedOnly)
        {
            var excluded = GetCachedExcludedIndices(cacheKey, directory);
            seqs = excluded.Skip(skip).Take(take);
        }
        else
        {
            var end = Math.Min(skip + take, offsets.Length);
            seqs = Enumerable.Range(skip, Math.Max(0, end - skip));
        }

        var page = new List<ProcessDetailItem>(take);
        var path = Path.Combine(directory, "details.ndjson");
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        foreach (var seq in seqs)
        {
            if (seq < 0 || seq >= offsets.Length)
                continue;

            if (TryReadJsonAtOffset(stream, offsets[seq], out ProcessDetailItem item))
                page.Add(item);
        }

        return page;
    }

    public List<RewardItem> ReadRewardPage(string cacheKey, RewardStreamKind kind, int skip, int take)
    {
        if (take <= 0)
            return new List<RewardItem>();

        var directory = GetCacheDirectory(cacheKey);
        var path = Path.Combine(directory, ResultWriteSession.GetRewardFileName(kind));
        if (!File.Exists(path))
            return new List<RewardItem>();

        var offsets = GetCachedRewardOffsets(cacheKey, kind, directory);
        if (offsets.Length > 0)
        {
            var page = new List<RewardItem>(take);
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            var end = Math.Min(skip + take, offsets.Length);
            for (var i = skip; i < end; i++)
            {
                if (TryReadJsonAtOffset(stream, offsets[i], out RewardItem item))
                    page.Add(item);
            }

            return page;
        }

        var fallbackPage = new List<RewardItem>(take);
        var index = 0;
        foreach (var item in ReadLines<RewardItem>(path))
        {
            if (index >= skip && fallbackPage.Count < take)
                fallbackPage.Add(item);
            if (fallbackPage.Count >= take)
                break;
            index++;
        }

        return fallbackPage;
    }

    public void UpdateRewardSettings(
        string cacheKey,
        decimal wageringMultiplier,
        string appRemark,
        string backendRemark)
    {
        var meta = TryGetMeta(cacheKey)
            ?? throw new FileNotFoundException("找不到处理结果缓存。", cacheKey);

        meta.Snapshot.RewardSettings.WageringMultiplier = wageringMultiplier;
        meta.Snapshot.RewardSettings.AppRemark = appRemark;
        meta.Snapshot.RewardSettings.BackendRemark = backendRemark;
        WriteMeta(GetCacheDirectory(cacheKey), meta);
        CacheMeta(cacheKey, meta);

        if (meta.UsesSplitRewards)
        {
            RewriteRewardSettings(cacheKey, RewardStreamKind.Loss, wageringMultiplier, appRemark, backendRemark);
            RewriteRewardSettings(cacheKey, RewardStreamKind.Profit, wageringMultiplier, appRemark, backendRemark);
        }
        else
        {
            RewriteRewardSettings(cacheKey, RewardStreamKind.Merged, wageringMultiplier, appRemark, backendRemark);
        }
    }

    public IEnumerable<ProcessDetailItem> StreamDetails(string cacheKey)
    {
        var path = Path.Combine(GetCacheDirectory(cacheKey), "details.ndjson");
        if (!File.Exists(path))
            yield break;

        foreach (var item in ReadLines<ProcessDetailItem>(path))
            yield return item;
    }

    public IEnumerable<RewardItem> StreamRewards(string cacheKey, RewardStreamKind kind)
    {
        var path = Path.Combine(GetCacheDirectory(cacheKey), ResultWriteSession.GetRewardFileName(kind));
        if (!File.Exists(path))
            yield break;

        foreach (var item in ReadLines<RewardItem>(path))
            yield return item;
    }

    public void Delete(string cacheKey)
    {
        InvalidateCache(cacheKey);
        var directory = GetCacheDirectory(cacheKey);
        if (Directory.Exists(directory))
            Directory.Delete(directory, recursive: true);
    }

    /// <summary>默认保留 7 天；可被历史快照引用的 cacheKey 不会被删除。</summary>
    public static readonly TimeSpan DefaultRetention = TimeSpan.FromDays(7);

    /// <summary>删除超过保留期且未被保护的缓存目录。</summary>
    public int CleanupExpired(TimeSpan? maxAge = null, IEnumerable<string>? protectedKeys = null)
    {
        maxAge ??= DefaultRetention;
        var protectedSet = protectedKeys?.Where(k => !string.IsNullOrWhiteSpace(k))
            .ToHashSet(StringComparer.OrdinalIgnoreCase)
            ?? new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var cutoff = DateTime.Now - maxAge.Value;

        if (!Directory.Exists(_rootDirectory))
            return 0;

        var deleted = 0;
        foreach (var directory in Directory.EnumerateDirectories(_rootDirectory))
        {
            var cacheKey = Path.GetFileName(directory);
            if (string.IsNullOrEmpty(cacheKey) || protectedSet.Contains(cacheKey))
                continue;

            var meta = TryGetMeta(cacheKey);
            var processedAt = meta?.ProcessedAt ?? Directory.GetCreationTime(directory);
            if (processedAt >= cutoff)
                continue;

            Delete(cacheKey);
            deleted++;
        }

        return deleted;
    }

    public IReadOnlyList<string> ListCacheKeys()
    {
        if (!Directory.Exists(_rootDirectory))
            return Array.Empty<string>();

        return Directory.EnumerateDirectories(_rootDirectory)
            .Select(Path.GetFileName)
            .Where(key => !string.IsNullOrEmpty(key))
            .Cast<string>()
            .ToList();
    }

    private void RewriteRewardSettings(
        string cacheKey,
        RewardStreamKind kind,
        decimal wageringMultiplier,
        string appRemark,
        string backendRemark)
    {
        var path = Path.Combine(GetCacheDirectory(cacheKey), ResultWriteSession.GetRewardFileName(kind));
        if (!File.Exists(path))
            return;

        var tempPath = path + ".tmp";
        using (var reader = new StreamReader(path, Encoding.UTF8))
        using (var writer = new StreamWriter(tempPath, false, new UTF8Encoding(false)))
        {
            string? line;
            while ((line = reader.ReadLine()) is not null)
            {
                if (string.IsNullOrWhiteSpace(line))
                    continue;

                var item = JsonSerializer.Deserialize<RewardItem>(line, JsonOptions);
                if (item is null)
                    continue;

                item.WageringMultiplier = wageringMultiplier;
                item.AppRemark = appRemark;
                item.BackendRemark = backendRemark;
                WriteLine(writer, item);
            }
        }

        File.Delete(path);
        File.Move(tempPath, path);
    }

    private string GetCacheDirectory(string cacheKey) => Path.Combine(_rootDirectory, cacheKey);

    private string GetMetaPath(string cacheKey) => Path.Combine(GetCacheDirectory(cacheKey), "meta.json");

    private static ProcessResult ToSummaryResult(CachedResultMeta meta) => new()
    {
        ProcessedAt = meta.ProcessedAt,
        SiteId = meta.SiteId,
        SiteName = meta.SiteName,
        SiteCode = meta.SiteCode,
        ActivityId = meta.ActivityId,
        ActivityName = meta.ActivityName,
        Summary = meta.Summary,
        UsesSplitRewards = meta.UsesSplitRewards,
        Snapshot = meta.Snapshot,
        ExportFilePath = meta.ExportFilePath,
        ResultCacheKey = meta.CacheKey,
        Details = new List<ProcessDetailItem>(),
        Rewards = new List<RewardItem>(),
        LossRewards = new List<RewardItem>(),
        ProfitRewards = new List<RewardItem>()
    };

    private static void WriteMeta(string directory, CachedResultMeta meta)
    {
        var json = JsonSerializer.Serialize(meta, JsonOptions);
        File.WriteAllText(Path.Combine(directory, "meta.json"), json, new UTF8Encoding(false));
    }

    private static void WriteLine<T>(TextWriter writer, T value) =>
        writer.WriteLine(JsonSerializer.Serialize(value, JsonOptions));

    private static void WriteOffsetIndex(string directory, string fileName, IReadOnlyList<long> offsets)
    {
        using var stream = new FileStream(Path.Combine(directory, fileName), FileMode.Create, FileAccess.Write);
        using var writer = new BinaryWriter(stream);
        writer.Write(offsets.Count);
        for (var i = 0; i < offsets.Count; i++)
            writer.Write(offsets[i]);
    }

    private static long[] LoadOffsetIndex(string directory, string fileName)
    {
        var path = Path.Combine(directory, fileName);
        if (!File.Exists(path))
            return Array.Empty<long>();

        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using var reader = new BinaryReader(stream);
        var count = reader.ReadInt32();
        var offsets = new long[count];
        for (var i = 0; i < count; i++)
            offsets[i] = reader.ReadInt64();
        return offsets;
    }

    private static void WriteIntIndex(string directory, string fileName, IReadOnlyList<int> values)
    {
        using var stream = new FileStream(Path.Combine(directory, fileName), FileMode.Create, FileAccess.Write);
        using var writer = new BinaryWriter(stream);
        writer.Write(values.Count);
        for (var i = 0; i < values.Count; i++)
            writer.Write(values[i]);
    }

    private static int[] LoadIntIndex(string directory, string fileName)
    {
        var path = Path.Combine(directory, fileName);
        if (!File.Exists(path))
            return Array.Empty<int>();

        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using var reader = new BinaryReader(stream);
        var count = reader.ReadInt32();
        var values = new int[count];
        for (var i = 0; i < count; i++)
            values[i] = reader.ReadInt32();
        return values;
    }

    private static bool TryReadJsonAtOffset<T>(FileStream stream, long offset, out T item)
    {
        item = default!;
        var line = ReadLineAtOffset(stream, offset);
        if (string.IsNullOrWhiteSpace(line))
            return false;

        if (line[0] != '{')
            return false;

        try
        {
            item = JsonSerializer.Deserialize<T>(line, JsonOptions)!;
            return item is not null;
        }
        catch (JsonException)
        {
            return false;
        }
    }

    private static string? ReadLineAtOffset(FileStream stream, long offset)
    {
        stream.Seek(offset, SeekOrigin.Begin);
        using var buffer = new MemoryStream(capacity: 256);
        int value;
        while ((value = stream.ReadByte()) >= 0)
        {
            if (value == '\n')
                break;

            if (value != '\r')
                buffer.WriteByte((byte)value);
        }

        return buffer.Length == 0 ? null : Encoding.UTF8.GetString(buffer.ToArray());
    }

    private long[] GetCachedDetailOffsets(string cacheKey, string directory) =>
        _detailOffsetCache.GetOrAdd(
            cacheKey,
            _ => LoadOrRebuildOffsetIndex(
                directory,
                "details.ndjson",
                "details.offsets",
                validateOffset: offset => IsJsonLineAtOffset(Path.Combine(directory, "details.ndjson"), offset)));

    private int[] GetCachedExcludedIndices(string cacheKey, string directory) =>
        _excludedIndexCache.GetOrAdd(
            cacheKey,
            _ => LoadIntIndex(directory, "excluded.idx"));

    private long[] GetCachedRewardOffsets(string cacheKey, RewardStreamKind kind, string directory)
    {
        var cacheEntryKey = $"{cacheKey}|{(int)kind}";
        var dataFile = ResultWriteSession.GetRewardFileName(kind);
        var offsetFile = ResultWriteSession.GetRewardOffsetFileName(kind);
        return _rewardOffsetCache.GetOrAdd(
            cacheEntryKey,
            _ => LoadOrRebuildOffsetIndex(
                directory,
                dataFile,
                offsetFile,
                validateOffset: offset =>
                {
                    var path = Path.Combine(directory, dataFile);
                    return File.Exists(path) && IsJsonLineAtOffset(path, offset);
                }));
    }

    private static bool IsJsonLineAtOffset(string path, long offset)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        var line = ReadLineAtOffset(stream, offset);
        return !string.IsNullOrWhiteSpace(line) && line[0] == '{';
    }

    private long[] LoadOrRebuildOffsetIndex(
        string directory,
        string dataFileName,
        string offsetFileName,
        Func<long, bool> validateOffset)
    {
        var dataPath = Path.Combine(directory, dataFileName);
        if (!File.Exists(dataPath))
            return Array.Empty<long>();

        var offsets = LoadOffsetIndex(directory, offsetFileName);
        if (IsOffsetIndexUsable(dataPath, offsets, validateOffset))
            return offsets;

        offsets = RebuildLineOffsets(dataPath);
        if (offsets.Length > 0)
            WriteOffsetIndex(directory, offsetFileName, offsets);

        return offsets;
    }

    private static bool IsOffsetIndexUsable(string dataPath, long[] offsets, Func<long, bool> validateOffset)
    {
        if (offsets.Length == 0)
            return false;

        if (offsets.Length > 1 && offsets[0] == offsets[1])
            return false;

        var fileLength = new FileInfo(dataPath).Length;
        if (offsets[0] < 0 || offsets[0] >= fileLength)
            return false;

        return validateOffset(offsets[0]);
    }

    private static long[] RebuildLineOffsets(string path)
    {
        if (!File.Exists(path))
            return Array.Empty<long>();

        var offsets = new List<long>();
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        if (stream.Length == 0)
            return Array.Empty<long>();

        offsets.Add(0);
        int value;
        while ((value = stream.ReadByte()) >= 0)
        {
            if (value != '\n')
                continue;

            if (stream.Position < stream.Length)
                offsets.Add(stream.Position);
        }

        return offsets.ToArray();
    }

    private void CacheMeta(string cacheKey, CachedResultMeta meta) => _metaCache[cacheKey] = meta;

    private void InvalidateCache(string cacheKey)
    {
        _metaCache.TryRemove(cacheKey, out _);
        _detailOffsetCache.TryRemove(cacheKey, out _);
        _excludedIndexCache.TryRemove(cacheKey, out _);

        foreach (var kind in new[] { RewardStreamKind.Merged, RewardStreamKind.Loss, RewardStreamKind.Profit })
            _rewardOffsetCache.TryRemove($"{cacheKey}|{(int)kind}", out _);
    }

    private static bool TryReadDetailAtOffset(FileStream stream, long offset, out ProcessDetailItem item) =>
        TryReadJsonAtOffset(stream, offset, out item);

    private static IEnumerable<T> ReadLines<T>(string path)
    {
        using var reader = new StreamReader(path, Encoding.UTF8);
        string? line;
        while ((line = reader.ReadLine()) is not null)
        {
            if (string.IsNullOrWhiteSpace(line) || line[0] != '{')
                continue;

            T? item;
            try
            {
                item = JsonSerializer.Deserialize<T>(line, JsonOptions);
            }
            catch (JsonException)
            {
                continue;
            }

            if (item is not null)
                yield return item;
        }
    }
}

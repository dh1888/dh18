using DHPG.Common;

namespace DHPG.Services;

public static class BatchSiteTaskExtensions
{
    public static bool HasOutcome(this BatchSiteTask task) =>
        !string.IsNullOrEmpty(task.ResultCacheKey) || task.Result is not null;

    public static ProcessResult? ResolveResult(this BatchSiteTask task, ResultRepository repository)
    {
        if (!string.IsNullOrEmpty(task.ResultCacheKey))
        {
            if (!repository.Exists(task.ResultCacheKey))
                return null;

            return repository.LoadSummary(task.ResultCacheKey);
        }

        return task.Result;
    }
}

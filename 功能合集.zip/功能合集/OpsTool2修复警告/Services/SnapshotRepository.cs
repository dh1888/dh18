using DHPG.Common;

namespace DHPG.Services;

/// <summary>处理快照读写，关联 ResultRepository 缓存键。</summary>
public class SnapshotRepository
{
    private readonly ResultRepository _resultRepository;

    public SnapshotRepository(ResultRepository? resultRepository = null)
    {
        _resultRepository = resultRepository ?? new ResultRepository();
    }

    public ProcessSnapshot Deserialize(string json) =>
        Extensions.DeserializeSnapshot(json) ?? new ProcessSnapshot();

    public string Serialize(ProcessSnapshot snapshot) => Extensions.SerializeSnapshot(snapshot);

    public ProcessResult? TryHydrateFromCache(ProcessSnapshot snapshot)
    {
        if (string.IsNullOrEmpty(snapshot.ResultCacheKey))
            return null;

        if (!_resultRepository.Exists(snapshot.ResultCacheKey))
            return null;

        return _resultRepository.LoadSummary(snapshot.ResultCacheKey);
    }
}

# DHPG publish script (Release / win-x64 / self-contained)
# Usage: .\scripts\publish.ps1
# Optional: .\scripts\publish.ps1 -SkipNpmBuild

param(
    [switch]$SkipNpmBuild,
    [string]$Configuration = "Release",
    [string]$Runtime = "win-x64",
    [string]$OutputDir = "publish\DHPG-win-x64",
    [switch]$NoZip
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root

Write-Host "==> DHPG publish" -ForegroundColor Cyan
Write-Host "    Root: $Root"

if (-not $SkipNpmBuild) {
    Write-Host "`n[1/3] Build Vue batch UI (web/batch-ui)..." -ForegroundColor Yellow
    Push-Location "web\batch-ui"
    if (-not (Test-Path "node_modules")) {
        Write-Host "    Running npm install (first time)..."
        npm install
    }
    npm run build
    Pop-Location
} else {
    Write-Host "`n[1/3] Skip npm build (-SkipNpmBuild)" -ForegroundColor DarkGray
}

$iconPath = Join-Path $Root "app.ico"
if (-not (Test-Path $iconPath)) {
    throw "app.ico not found at project root: $iconPath"
}

Write-Host "`n[2/3] dotnet publish ($Configuration / $Runtime / self-contained)..." -ForegroundColor Yellow
dotnet publish DHPG.csproj `
    -c $Configuration `
    -r $Runtime `
    --self-contained true `
    -p:PublishReadyToRun=true `
    -o $OutputDir

$publishPath = Join-Path $Root $OutputDir
$exePath = Join-Path $publishPath "DHPG.exe"
if (-not (Test-Path $exePath)) {
    throw "DHPG.exe not found at $exePath"
}

Copy-Item (Join-Path $Root "scripts\user-guide.txt") (Join-Path $publishPath "USER-GUIDE.txt") -Force

Write-Host "`n[3/3] Done" -ForegroundColor Green
Write-Host "    Folder: $publishPath"
Write-Host "    Entry:  $exePath"

if (-not $NoZip) {
    $version = (Select-Xml -Path "DHPG.csproj" -XPath "//Version" -ErrorAction SilentlyContinue).Node.InnerText
    if (-not $version) { $version = "0.1.0" }
    $zipName = "DHPG-v$version-$Runtime.zip"
    $zipPath = Join-Path (Split-Path $publishPath -Parent) $zipName
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
    Compress-Archive -Path $publishPath -DestinationPath $zipPath -CompressionLevel Optimal
    Write-Host "    Zip:    $zipPath" -ForegroundColor Green
}

Write-Host "`nShip the zip; user extracts and runs DHPG.exe." -ForegroundColor Cyan

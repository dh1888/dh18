# DHPG 运维工具

个人使用的 Windows 桌面工具，用于 Excel/CSV 会员数据处理、彩金计算、过滤与派奖导出。

**技术栈：** C# · .NET 8 · WPF · HandyControl · SQLite · EF Core · EPPlus · CsvHelper · Serilog

---

## 环境要求

| 项目 | 说明 |
|------|------|
| 操作系统 | Windows 10/11 |
| SDK | [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)（本机 .NET 10 SDK 也可编译 `net8.0-windows` 目标） |
| IDE | Visual Studio 2022 / Rider / VS Code + C# Dev Kit（可选） |

---

## 构建与运行

```powershell
cd C:\Users\Admin\Desktop\OpsTool

# 编译
dotnet build

# 运行
dotnet run

# 单元测试
dotnet test tests\DHPG.Tests\DHPG.Tests.csproj
```

---

## 打包分发（给用户双击使用）

一键打包（会先构建 Vue 批量页，再发布自包含 Windows 程序）：

```powershell
cd C:\Users\Admin\Desktop\OpsTool
.\scripts\publish.ps1
```

输出：

| 路径 | 说明 |
|------|------|
| `publish\DHPG-win-x64\` | 完整运行目录，**双击 `DHPG.exe`** |
| `publish\DHPG-v0.1.0-win-x64.zip` | 可发给用户的压缩包（解压后同上） |

若本次只改了 C#、未改 `web/batch-ui`，可跳过前端构建：

```powershell
.\scripts\publish.ps1 -SkipNpmBuild
```

### 给用户的说明

1. 解压 ZIP 到任意目录（例如 `D:\Tools\DHPG`），**不要只复制 exe**，需保留整个文件夹。
2. 双击 **`DHPG.exe`** 启动，**无需安装 .NET**（已自包含运行时）。
3. 个人数据在 `%AppData%\DHPG\`（数据库、日志、导出文件等），与程序目录无关，升级覆盖程序不会丢数据。
4. **批量页**（时段/回访彩金）依赖 [Microsoft Edge WebView2 运行时](https://developer.microsoft.com/microsoft-edge/webview2/)。Win10/11 多数已预装；若批量页空白，安装 WebView2 即可。

手动分步（等价于脚本内部步骤）：

```powershell
cd web\batch-ui
npm install   # 首次
npm run build

cd ..\..
dotnet publish DHPG.csproj -c Release -r win-x64 --self-contained true -p:PublishReadyToRun=true -o publish\DHPG-win-x64
```

首次启动会自动：

1. 创建 `%AppData%\DHPG\` 目录
2. 执行 EF Core 迁移，生成 `dhpg.db`
3. 写入种子数据：示例站点 `DEMO` + 两个活动（时段彩金、回访彩金）

---

## 数据与日志路径

| 路径 | 内容 |
|------|------|
| `%AppData%\DHPG\dhpg.db` | SQLite 数据库 |
| `%AppData%\DHPG\logs\dhpg-*.log` | Serilog 滚动日志（保留 14 天） |
| `文档\DHPG\` | 默认导出目录（可在「系统设置」修改） |

---

## 项目结构

```
DHPG/
├── App.xaml.cs              启动、日志、数据库、主题
├── Common/
│   ├── Models.cs            请求/结果/快照等 DTO
│   ├── RuleEngine.cs        唯一彩金计算引擎（静态）
│   ├── Extensions.cs        实体映射、快照 JSON、参数合并
│   └── Helpers.cs           解析工具、ThemeManager
├── Data/
│   ├── Entities.cs          5 张表实体
│   ├── AppDbContext.cs      DbContext + 种子 + 迁移入口
│   └── Migrations/
├── Services/
│   ├── SettingService.cs    系统设置
│   ├── ActivityService.cs   站点/活动 CRUD
│   ├── ExcelService.cs      流式读取 Excel/CSV
│   ├── ProcessService.cs    处理编排（ProcessView 唯一后端）
│   └── ExportService.cs     Excel/JSON/剪贴板导出
├── Views/                   7 个页面 + MainWindow 导航壳
├── Themes/ModernTheme.xaml
├── fixtures/sample-demo.csv 验收用示例数据（匹配 DEMO 列映射）
└── tests/DHPG.Tests/        单元测试
```

业务 `.cs` 约 19 个（不含 XAML、Migrations、测试），无 DI 容器，View 内按需 `new Service(...)`。

---

## 处理流程

```
选站点/活动 → 拖入文件 → 可选勾选（未领取过滤、盈利会员）
    → ExcelService 流式读取
    → 层级关键字过滤 → 未领取过滤
    → RuleEngine：profit = 充值 - 提现
    → 彩金计算 / 剔除
    → 明细 + 派奖列表（UI 分页 500 行/页）
    → 可选导出 Excel/JSON/复制 TSV
    → 写入 ProcessHistories（SnapshotJson 快照，只读）
```

### 彩金规则（RuleEngine）

| 条件 | 行为 |
|------|------|
| profit ≥ 0（亏损） | `profit × rate ÷ divisor`，再 clamp 到 `[MinBonus, MaxBonus]`；**MaxBonus=0 表示不封顶** |
| profit < 0（盈利）且不允许盈利会员 | 剔除，原因「过滤盈利会员」 |
| profit < 0 且允许盈利会员 | 固定 `MinBonus` |

**种子活动默认：**

| 活动 | Divisor | MinBonus | MaxBonus | 盈利会员 |
|------|---------|----------|----------|----------|
| 时段彩金 | 10 | 1 | 50 | 否 |
| 回访彩金 | 2 | 1 | 0（不封顶） | 是 |

### 配置优先级

派奖字段（打码倍数、APP/后台备注）：**ProcessView 输入 > Activity > AppSettings**

历史快照使用处理当时的参数，不受后续配置修改影响。

---

## 批量站点处理

**入口：** 左侧导航 **「时段彩金」** / **「回访彩金」**（独立菜单页，布局对齐 Web 批量页）

| 菜单 | 说明 |
|------|------|
| 单站点处理 | 原单站流程（选 1 站点 + 1 活动 + 1 文件） |
| 时段彩金 | 批量站点，固定使用「时段彩金」活动规则 |
| 回访彩金 | 批量站点，固定使用「回访彩金」活动，默认勾选过滤未领 |

### 操作步骤

1. 选择 **1 个活动**（时段彩金或回访彩金，整批共用规则）
2. 按需勾选「过滤未领取」「获取盈利会员」，填写打码/备注（整批共用）
3. 点击 **「+ 添加站点」**，每行选择站点并上传 **会员文件**（勾选过滤未领时每行还需 **未领文件**）
4. 点击 **「批量计算彩金（N 个站点）」**，顺序处理，进度条显示当前站点
5. 完成后在 **按站点 Tab** 查看明细/派奖，可 **导出本站** 或 **批量导出全部**

### 时段 vs 回访

| 类型 | 识别 | 批量建议 |
|------|------|----------|
| 时段彩金 | `AllowProfitMember=false` 或名称含「时段」 | 盈利会员默认剔除；通常不需未领名单 |
| 回访彩金 | `AllowProfitMember=true` 或名称含「回访」 | 选活动后 **默认勾选过滤未领**；每行需会员 + 未领文件；亏损侧 **除数 2、不封顶** |

### 列映射

每行使用 **该站点在「站点管理」中保存的 ColumnMapping**，批量页不共用一套映射（回访与时段列布局可能不同）。

### 活动跨站点

同一活动参数可应用于多个站点文件（对齐 Web 批量逻辑）；处理时 `activity.SiteId` 与任务站点不必相同。

### 批量导出

| 操作 | 输出 |
|------|------|
| 导出本站 Excel | `{SiteCode}_{ActivityName}_{timestamp}.xlsx` → 默认导出目录 |
| 批量导出全部 | 各站 xlsx + **`{ActivityName}_批量_{timestamp}.zip`**（含全部成功站点） |

默认导出目录：`文档\DHPG\`（可在「系统设置」修改）。

### 健壮性

- 同一批次 **站点不可重复**
- 某站失败 **不中断** 后续站点
- 支持 **中途取消**
- 每站成功各写 **1 条 ProcessHistory**

---

## 性能说明

本工具面向日常运维量级（万～数十万行），采用以下策略：

| 策略 | 位置 | 说明 |
|------|------|------|
| 流式读取 | `ExcelService` | `ExcelDataReader` / `CsvHelper` 逐行 `yield`，不全量加载到内存 |
| 后台处理 | `ProcessService` | `Task.Run` + `CancellationToken`，UI 线程不阻塞 |
| 进度节流 | `ProcessService` | 每 1000 行报告一次进度，避免频繁 UI 刷新 |
| UI 分页 | `ProcessView` | 明细/派奖各 500 行/页，DataGrid 不绑定全量 |
| 快照采样 | `ProcessService` | 历史 `SnapshotJson` 仅保留前 20 条样例行 + 汇总 |
| 未领取 HashSet | `ProcessService` | 未领取 ID 集合 O(1) 查找 |
| 视图缓存 | `MainWindow` | 页面实例缓存，切换导航不重复创建 |
| 首页/历史刷新 | `DashboardView` / `HistoryView` | `IsVisibleChanged` 时重新加载，处理完成后切回可见即更新 |

**建议：** 单文件超过 50 万行时关注内存与耗时；超大文件可先在外部按站点拆分。

---

## 手动验收清单

使用 `fixtures/sample-demo.csv`（列位置与种子站点 DEMO 一致）：

### 1. 启动与首页

- [ ] 应用正常启动，无数据库错误弹窗
- [ ] 首页显示版本号、站点数 ≥ 1、活动数 ≥ 2
- [ ] 深色/浅色主题在「系统设置」保存后立即生效

### 2. 站点与活动

- [ ] 「站点管理」可查看 DEMO 站点及列映射（0/5/7/17/21）
- [ ] 「活动管理」可编辑、复制、禁用活动
- [ ] 新建站点 + 列映射后可被活动引用

### 3. 数据处理 — 单站点

- [ ] 「单站点」Tab：选择 DEMO +「时段彩金」，拖入 `sample-demo.csv`
- [ ] 处理完成：汇总数字合理，明细 Tab 有剔除原因
- [ ] 派奖 Tab 打码/备注修改后列表实时刷新
- [ ] 导出 Excel（3 Sheet：派奖/明细/汇总）成功
- [ ] 复制 TSV 到剪贴板可用
- [ ] 「取消」按钮在处理中途可中止

### 4. 数据处理 — 批量站点

- [ ] 「批量站点」Tab：选「时段彩金」，添加 2+ 站点，各传 `sample-demo.csv`，批量计算成功
- [ ] 每站独立 ProcessHistory；结果 Tab 按站点切换
- [ ] 「导出本站」「批量导出全部（ZIP）」成功
- [ ] 选「回访彩金」默认勾选过滤未领；盈利会员得 MinBonus，亏损按除数 2 且无封顶

### 5. 历史记录

- [ ] 本次处理出现在「历史记录」列表
- [ ] 双击打开快照详情（只读）
- [ ] 从历史记录导出 Excel 成功
- [ ] 返回首页，「今日处理」计数 +1

### 6. 规则边界（可选）

- [ ] 勾选「包含盈利会员」后，profit < 0 的会员获得 MinBonus
- [ ] 层级含「测试/代理/内部」关键字的行被过滤
- [ ] 「回访彩金」活动 AllowProfitMember=true 时盈利会员得 MinBonus=1；亏损 `profit×2%÷2` 且不封顶

---

## 示例数据说明

`fixtures/sample-demo.csv` 列布局（0-based）：

| 列 | 字段 |
|----|------|
| 0 | 会员 ID |
| 5 | 充值 |
| 7 | 提现 |
| 17 | 手机 |
| 21 | 层级 |

若使用自有文件，请在「站点管理 → 列映射」中按实际表头调整。

---

## 数据库迁移

```powershell
# 新增迁移（模型变更后）
dotnet ef migrations add <Name> --project DHPG.csproj

# 应用会在启动时自动 Migrate()
```

---

## 许可证说明

- **EPPlus** 使用 `LicenseContext.NonCommercial`（非商业）
- **HandyControl** 3.5.1 — MIT

---

## 版本

当前版本：**0.1.0**

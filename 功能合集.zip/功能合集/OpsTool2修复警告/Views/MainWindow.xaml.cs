using System.Windows;
using System.Windows.Controls;
using DHPG.Common;

namespace DHPG.Views;

public partial class MainWindow : System.Windows.Window
{
    private readonly Dictionary<string, UserControl> _viewCache = new(StringComparer.OrdinalIgnoreCase);
    private string _currentNavKey = "Dashboard";

    public MainWindow()
    {
        InitializeComponent();
        Navigate("Dashboard");
    }
    private void NavButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: string tag })
            Navigate(tag);
    }

    public void Navigate(string key)
    {
        _currentNavKey = key;

        var (title, breadcrumb) = key switch
        {
            "Dashboard" => ("首页", "DHPG 运维工具 / 首页"),
            "Settings" => ("系统设置", "DHPG 运维工具 / 系统设置"),
            "Site" => ("站点管理", "DHPG 运维工具 / 站点管理"),
            "Activity" => ("活动管理", "DHPG 运维工具 / 活动管理"),
            "PeriodBatch" => ("时段彩金", "DHPG 运维工具 / 时段彩金"),
            "CallbackBatch" => ("回访彩金", "DHPG 运维工具 / 回访彩金"),
            "Loss7dBatch" => (ActivityDefaults.Loss7dActivityName, $"DHPG 运维工具 / {ActivityDefaults.Loss7dActivityName}"),
            "YesterdayLossBatch" => (ActivityDefaults.YesterdayLossActivityName, $"DHPG 运维工具 / {ActivityDefaults.YesterdayLossActivityName}"),
            "OldCallback234Batch" => (ActivityDefaults.OldCallback234ActivityName, $"DHPG 运维工具 / {ActivityDefaults.OldCallback234ActivityName}"),
            "ComprehensiveCallbackBatch" => (ActivityDefaults.ComprehensiveCallbackActivityName, $"DHPG 运维工具 / {ActivityDefaults.ComprehensiveCallbackActivityName}"),
            _ => (key, $"DHPG 运维工具 / {key}")
        };

        PageTitleText.Text = title;
        PageTitleText.Visibility = key is "PeriodBatch" or "CallbackBatch" or "Loss7dBatch" or "YesterdayLossBatch" or "OldCallback234Batch" or "ComprehensiveCallbackBatch"
            ? Visibility.Collapsed
            : Visibility.Visible;
        BreadcrumbText.Text = breadcrumb;
        UpdateNavSelection(key);

        if (MainContent.Content is ProcessView leavingProcessView)
            leavingProcessView.OnNavigatedAway();
        else if (MainContent.Content is BatchWebView leavingBatchView)
            leavingBatchView.OnNavigatedAway();

        if (!_viewCache.TryGetValue(key, out var view))
        {
            view = key switch
            {
                "Dashboard" => new DashboardView(),
                "Settings" => new SettingsView(),
                "Site" => new SiteView(),
                "Activity" => new ActivityView(),
                "PeriodBatch" => new BatchWebView(ProcessPageMode.PeriodBatch),
                "CallbackBatch" => new BatchWebView(ProcessPageMode.CallbackBatch),
                "Loss7dBatch" => new BatchWebView(ProcessPageMode.Loss7dBatch),
                "YesterdayLossBatch" => new BatchWebView(ProcessPageMode.YesterdayLossBatch),
                "OldCallback234Batch" => new BatchWebView(ProcessPageMode.OldCallback234Batch),
                "ComprehensiveCallbackBatch" => new BatchWebView(ProcessPageMode.ComprehensiveCallbackBatch),
                _ => new DashboardView()
            };
            _viewCache[key] = view;
        }

        MainContent.Content = view;

        if (view is ProcessView enteringProcessView)
            enteringProcessView.OnNavigatedTo();
        else if (view is BatchWebView enteringBatchView)
            enteringBatchView.OnNavigatedTo();
    }

    private void UpdateNavSelection(string key)
    {
        foreach (var child in NavPanel.Children)
        {
            if (child is not Button button)
                continue;

            button.Style = string.Equals(button.Tag as string, key, StringComparison.OrdinalIgnoreCase)
                ? (Style)FindResource("NavButtonActive")
                : (Style)FindResource("NavButton");
        }
    }
}

using System.Windows;
using DHPG.Common;

namespace DHPG.Views.Controls;

public partial class MemberMappingFields
{
    public static readonly DependencyProperty ProfileProperty = DependencyProperty.Register(
        nameof(Profile),
        typeof(MappingProfile),
        typeof(MemberMappingFields),
        new PropertyMetadata(MappingProfile.Period, OnProfileChanged));

    public MemberMappingFields()
    {
        InitializeComponent();
        ApplyProfileHints();
        UserIdPicker.SetHeaders(null);
        PayPicker.SetHeaders(null);
        WithdrawPicker.SetHeaders(null);
        NetDiffPicker.SetHeaders(null);
        InactiveDaysPicker.SetHeaders(null);
        PhonePicker.SetHeaders(null);
        TierPicker.SetHeaders(null);
    }

    public MappingProfile Profile
    {
        get => (MappingProfile)GetValue(ProfileProperty);
        set => SetValue(ProfileProperty, value);
    }

    public int HeaderRow => Convert.ToInt32(HeaderRowBox.Value);

    public event EventHandler? HeaderRowChanged;

    private IReadOnlyList<string>? _cachedHeaders;

    private static void OnProfileChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is MemberMappingFields editor)
            editor.ApplyProfileHints();
    }

    private void ApplyProfileHints()
    {
        var showNetDiff = Profile is MappingProfile.YesterdayLoss or MappingProfile.OldCallback234 or MappingProfile.ComprehensiveCallback;
        var showInactiveDays = Profile is MappingProfile.OldCallback234 or MappingProfile.ComprehensiveCallback;
        NetDiffPicker.Visibility = showNetDiff ? Visibility.Visible : Visibility.Collapsed;
        InactiveDaysPicker.Visibility = showInactiveDays ? Visibility.Visible : Visibility.Collapsed;

        switch (Profile)
        {
            case MappingProfile.Callback:
                UserIdPicker.Label = "会员 ID（默认 F）";
                PayPicker.Label = "充值（默认 I）";
                WithdrawPicker.Label = "提现（默认 J）";
                break;
            case MappingProfile.Loss7d:
                UserIdPicker.Label = "会员 ID（默认 F）";
                PayPicker.Label = "累计充值（默认 I）";
                WithdrawPicker.Label = "累计提现（默认 J）";
                break;
            case MappingProfile.YesterdayLoss:
                UserIdPicker.Label = "会员 ID（默认 B）";
                PayPicker.Label = "当日充值（默认 L）";
                WithdrawPicker.Label = "当日提款（默认 M）";
                NetDiffPicker.Label = "当日充提差（默认 S）";
                break;
            case MappingProfile.OldCallback234:
                UserIdPicker.Label = "会员 ID（默认 A）";
                PayPicker.Label = "订单充值（默认 F）";
                WithdrawPicker.Label = "订单提现（默认 H）";
                NetDiffPicker.Label = "充提差（默认 I）";
                InactiveDaysPicker.Label = "未登录（默认 Q）";
                break;
            case MappingProfile.ComprehensiveCallback:
                UserIdPicker.Label = "会员 ID（默认 A）";
                PayPicker.Label = "订单充值（默认 F）";
                WithdrawPicker.Label = "订单提现（默认 H）";
                NetDiffPicker.Label = "充提差（默认 I）";
                InactiveDaysPicker.Label = "未登录（默认 Q）";
                break;
            default:
                UserIdPicker.Label = "会员 ID（默认 A）";
                PayPicker.Label = "充值（默认 F）";
                WithdrawPicker.Label = "提现（默认 H）";
                break;
        }
    }

    public void SetHeaders(IReadOnlyList<string>? headers)
    {
        if (HeadersEquivalent(_cachedHeaders, headers))
            return;

        _cachedHeaders = headers;
        UserIdPicker.SetHeaders(headers);
        PayPicker.SetHeaders(headers);
        WithdrawPicker.SetHeaders(headers);
        NetDiffPicker.SetHeaders(headers);
        InactiveDaysPicker.SetHeaders(headers);
        PhonePicker.SetHeaders(headers);
        TierPicker.SetHeaders(headers);
    }

    private static bool HeadersEquivalent(IReadOnlyList<string>? left, IReadOnlyList<string>? right)
    {
        if (ReferenceEquals(left, right))
            return true;

        if (left is null || right is null)
            return left is null && right is null;

        if (left.Count != right.Count)
            return false;

        for (var i = 0; i < left.Count; i++)
        {
            if (!string.Equals(left[i], right[i], StringComparison.Ordinal))
                return false;
        }

        return true;
    }

    public void LoadFrom(ColumnMappingInfo mapping)
    {
        HeaderRowBox.Value = mapping.HeaderRow;
        UserIdPicker.LoadColumn(mapping.UserIdColumn);
        PayPicker.LoadColumn(mapping.PayColumn);
        WithdrawPicker.LoadColumn(mapping.WithdrawColumn);
        NetDiffPicker.LoadColumn(mapping.NetDiffColumn);
        InactiveDaysPicker.LoadColumn(mapping.InactiveDaysColumn);
        PhonePicker.LoadColumn(mapping.PhoneColumn);
        TierPicker.LoadColumn(mapping.TierColumn);
    }

    public ColumnMappingInfo ReadMapping()
    {
        var mapping = new ColumnMappingInfo
        {
            HeaderRow = HeaderRow,
            UserIdColumn = UserIdPicker.ReadColumn(false, "会员 ID 列"),
            PayColumn = PayPicker.ReadColumn(false, Profile switch
            {
                MappingProfile.Loss7d => "累计充值列",
                MappingProfile.YesterdayLoss => "当日充值列",
                MappingProfile.OldCallback234 => "订单充值列",
                MappingProfile.ComprehensiveCallback => "订单充值列",
                _ => "充值列"
            }),
            WithdrawColumn = WithdrawPicker.ReadColumn(false, Profile switch
            {
                MappingProfile.Loss7d => "累计提现列",
                MappingProfile.YesterdayLoss => "当日提款列",
                MappingProfile.OldCallback234 => "订单提现列",
                MappingProfile.ComprehensiveCallback => "订单提现列",
                _ => "提现列"
            }),
            PhoneColumn = PhonePicker.ReadColumn(true, "手机列"),
            TierColumn = TierPicker.ReadColumn(true, "层级列")
        };

        if (Profile is MappingProfile.YesterdayLoss or MappingProfile.OldCallback234 or MappingProfile.ComprehensiveCallback)
            mapping.NetDiffColumn = NetDiffPicker.ReadColumn(false, "充提差列");

        if (Profile is MappingProfile.OldCallback234 or MappingProfile.ComprehensiveCallback)
            mapping.InactiveDaysColumn = InactiveDaysPicker.ReadColumn(false, "未登录列");

        return mapping;
    }

    private void HeaderRowBox_ValueChanged(object sender, HandyControl.Data.FunctionEventArgs<double> e) =>
        HeaderRowChanged?.Invoke(this, EventArgs.Empty);
}

using DHPG.Common;

namespace DHPG.Views.Controls;

public partial class UnclaimedColumnField
{
    public UnclaimedColumnField()
    {
        InitializeComponent();
        UserIdPicker.SetHeaders(null);
    }

    public void SetHeaders(IReadOnlyList<string>? headers) => UserIdPicker.SetHeaders(headers);

    public void LoadFrom(int columnIndex) => UserIdPicker.LoadColumn(columnIndex);

    public int ReadColumn() => UserIdPicker.ReadColumn(false, "未领名单会员 ID 列");
}

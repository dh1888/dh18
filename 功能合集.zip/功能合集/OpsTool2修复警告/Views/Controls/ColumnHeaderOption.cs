using DHPG.Common;

namespace DHPG.Views.Controls;

public sealed class ColumnHeaderOption
{
    public int Index { get; init; } = -1;

    public string Letter { get; init; } = string.Empty;

    public string HeaderText { get; init; } = string.Empty;

    public string DisplayText { get; init; } = string.Empty;

    public static ColumnHeaderOption Skip { get; } = new()
    {
        Index = -1,
        DisplayText = "- 不读"
    };

    public static ColumnHeaderOption FromIndex(int index) => new()
    {
        Index = index,
        Letter = Extensions.ColumnIndexToLetter(index),
        DisplayText = Extensions.ColumnIndexToLetter(index)
    };

    public static ColumnHeaderOption FromHeader(int index, string? headerText)
    {
        var letter = Extensions.ColumnIndexToLetter(index);
        var text = headerText?.Trim() ?? string.Empty;
        return new ColumnHeaderOption
        {
            Index = index,
            Letter = letter,
            HeaderText = text,
            DisplayText = string.IsNullOrEmpty(text) ? letter : $"{letter} · {text}"
        };
    }
}

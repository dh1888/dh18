using DHPG.Common;

namespace DHPG.Views.Controls;

public partial class RechargeMappingFields
{
    public RechargeMappingFields()
    {
        InitializeComponent();
        UserIdPicker.SetHeaders(null);
        AmountPicker.SetHeaders(null);
    }

    public int HeaderRow => Convert.ToInt32(HeaderRowBox.Value);

    public void LoadFrom(RechargeMappingConfig mapping)
    {
        HeaderRowBox.Value = mapping.HeaderRow;
        UserIdPicker.LoadColumn(mapping.UserIdColumn);
        AmountPicker.LoadColumn(mapping.AmountColumn);
    }

    public RechargeMappingConfig ReadMapping() => new()
    {
        HeaderRow = HeaderRow,
        UserIdColumn = UserIdPicker.ReadColumn(false, "充值数据会员 ID 列"),
        AmountColumn = AmountPicker.ReadColumn(false, "充值金额列")
    };
}

using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using DHPG.Common;
using ComboBox = HandyControl.Controls.ComboBox;

namespace DHPG.Views.Controls;

public partial class MappingColumnPicker
{
    public static readonly DependencyProperty LabelProperty = DependencyProperty.Register(
        nameof(Label),
        typeof(string),
        typeof(MappingColumnPicker),
        new PropertyMetadata(string.Empty, (d, e) =>
        {
            if (d is MappingColumnPicker picker && e.NewValue is string label)
                picker.LabelText.Text = label;
        }));

    public static readonly DependencyProperty AllowSkipProperty = DependencyProperty.Register(
        nameof(AllowSkip),
        typeof(bool),
        typeof(MappingColumnPicker),
        new PropertyMetadata(false));

    private readonly ObservableCollection<ColumnHeaderOption> _options = new();
    private bool _suppressSelection;
    private HeaderSignature? _appliedHeaders;

    public MappingColumnPicker()
    {
        InitializeComponent();
        LabelText.Text = Label;
        ColumnCombo.ItemsSource = _options;
        ColumnCombo.SelectionChanged += (_, _) =>
        {
            if (!_suppressSelection)
                SelectionChanged?.Invoke(this, EventArgs.Empty);
        };
    }

    public string Label
    {
        get => (string)GetValue(LabelProperty);
        set => SetValue(LabelProperty, value);
    }

    public bool AllowSkip
    {
        get => (bool)GetValue(AllowSkipProperty);
        set => SetValue(AllowSkipProperty, value);
    }

    public event EventHandler? SelectionChanged;

    public void SetHeaders(IReadOnlyList<string>? headers)
    {
        var signature = HeaderSignature.From(headers);
        if (_appliedHeaders == signature)
            return;

        _appliedHeaders = signature;
        _suppressSelection = true;
        var selectedIndex = ReadColumnIndexOrNull();
        _options.Clear();

        if (AllowSkip)
            _options.Add(ColumnHeaderOption.Skip);

        if (headers is { Count: > 0 })
        {
            for (var i = 0; i < headers.Count; i++)
                _options.Add(ColumnHeaderOption.FromHeader(i, headers[i]));
        }
        else
        {
            for (var i = 0; i < 52; i++)
                _options.Add(ColumnHeaderOption.FromIndex(i));
        }

        ApplySelection(selectedIndex);
        _suppressSelection = false;
    }

    public void LoadColumn(int columnIndex)
    {
        _suppressSelection = true;
        ApplySelection(columnIndex);
        _suppressSelection = false;
    }

    public int ReadColumn(bool allowSkip, string fieldName)
    {
        if (ColumnCombo.SelectedItem is ColumnHeaderOption option)
            return option.Index;

        var text = ColumnCombo.Text?.Trim() ?? string.Empty;
        return Extensions.ParseColumnInput(text, allowSkip, fieldName);
    }

    private int? ReadColumnIndexOrNull()
    {
        if (ColumnCombo.SelectedItem is ColumnHeaderOption option)
            return option.Index;

        var text = ColumnCombo.Text?.Trim() ?? string.Empty;
        if (AllowSkip && Extensions.TryParseColumnInput(text, true, out var index, out _))
            return index;

        if (Extensions.TryParseColumnInput(text, false, out index, out _))
            return index;

        return null;
    }

    private void ApplySelection(int? columnIndex)
    {
        if (columnIndex is int index)
        {
            var match = _options.FirstOrDefault(o => o.Index == index);
            if (match is not null)
            {
                ColumnCombo.SelectedItem = match;
                ColumnCombo.Text = match.DisplayText;
                return;
            }

            ColumnCombo.SelectedItem = null;
            ColumnCombo.Text = Extensions.FormatColumnInput(index);
            return;
        }

        ColumnCombo.SelectedItem = null;
        ColumnCombo.Text = string.Empty;
    }

    private sealed record HeaderSignature(bool HasHeaders, int Count, string? First, string? Last)
    {
        public static HeaderSignature From(IReadOnlyList<string>? headers)
        {
            if (headers is not { Count: > 0 })
                return new HeaderSignature(false, 0, null, null);

            return new HeaderSignature(true, headers.Count, headers[0], headers[^1]);
        }
    }
}

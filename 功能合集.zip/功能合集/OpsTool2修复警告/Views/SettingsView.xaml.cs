using System.Windows;
using System.Windows.Controls;
using DHPG.Common;
using DHPG.Services;
using Growl = HandyControl.Controls.Growl;
using OpenFolderDialog = Microsoft.Win32.OpenFolderDialog;

namespace DHPG.Views;

public partial class SettingsView
{
    private readonly SettingService _settingService = new(App.DbContextFactory);

    public SettingsView() => InitializeComponent();

    private async void SettingsView_Loaded(object sender, RoutedEventArgs e)
    {
        ThemeCombo.ItemsSource = new[] { "Light", "Dark" };
        LogLevelCombo.ItemsSource = new[] { "Debug", "Information", "Warning", "Error" };

        try
        {
            var settings = await _settingService.GetAsync();
            ExportDirectoryBox.Text = settings.ExportDirectory;
            ThemeCombo.SelectedItem = settings.Theme;
            LogLevelCombo.SelectedItem = settings.LogLevel;
        }
        catch (Exception ex)
        {
            Growl.Error($"加载设置失败：{ex.Message}");
        }
    }

    private void BrowseExportDirectory_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog
        {
            Title = "选择默认导出目录",
            InitialDirectory = string.IsNullOrWhiteSpace(ExportDirectoryBox.Text)
                ? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
                : ExportDirectoryBox.Text
        };

        if (dialog.ShowDialog() == true)
            ExportDirectoryBox.Text = dialog.FolderName;
    }

    private async void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var current = await _settingService.GetAsync();
            var model = new AppSettingsModel
            {
                ExportDirectory = ExportDirectoryBox.Text.Trim(),
                DefaultWageringMultiplier = current.DefaultWageringMultiplier,
                DefaultAppRemark = current.DefaultAppRemark,
                DefaultBackendRemark = current.DefaultBackendRemark,
                Theme = ThemeCombo.SelectedItem?.ToString() ?? "Light",
                LogLevel = LogLevelCombo.SelectedItem?.ToString() ?? "Information"
            };

            await _settingService.SaveAsync(model);
            _settingService.ApplyTheme(model.Theme);
            Growl.Success("系统设置已保存。");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }
}

using System.Windows;
using System.Windows.Controls;
using DHPG.Common;
using DHPG.Services;

namespace DHPG.Views;

public partial class BatchWebView : UserControl
{
    private readonly ProcessPageMode _pageMode;
    private bool _initialized;
    private string? _pendingUrl;

    public BatchWebView(ProcessPageMode pageMode)
    {
        _pageMode = pageMode;
        InitializeComponent();
        Loaded += BatchWebView_Loaded;
    }

    private string ModeQuery => _pageMode switch
    {
        ProcessPageMode.CallbackBatch => "callback",
        ProcessPageMode.Loss7dBatch => "loss7d",
        ProcessPageMode.YesterdayLossBatch => "yesterdayloss",
        ProcessPageMode.OldCallback234Batch => "oldcallback234",
        ProcessPageMode.ComprehensiveCallbackBatch => "comprehensive",
        _ => "period"
    };

    private async void BatchWebView_Loaded(object sender, RoutedEventArgs e)
    {
        if (_initialized)
            return;

        try
        {
            if (!LocalApiHost.Instance.IsRunning)
                await LocalApiHost.Instance.StartAsync();

            await WebView.EnsureCoreWebView2Async();
            WebView.CoreWebView2.Settings.AreDevToolsEnabled = false;
            WebView.CoreWebView2.Settings.IsStatusBarEnabled = false;
            WebView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;

            _initialized = true;
            NavigateToBatchPage();
        }
        catch (Exception ex)
        {
            HandyControl.Controls.Growl.Error($"批量页面加载失败：{ex.Message}");
        }
    }

    public void OnNavigatedTo()
    {
        if (!_initialized)
        {
            _pendingUrl ??= BuildUrl();
            return;
        }

        _ = RefreshBatchPageAsync();
    }

    private async Task RefreshBatchPageAsync()
    {
        try
        {
            if (WebView.CoreWebView2 is null)
                return;

            await WebView.CoreWebView2.ExecuteScriptAsync(
                "window.__dhpgRefreshBootstrap && window.__dhpgRefreshBootstrap()");
        }
        catch
        {
            // WebView 尚未就绪时忽略
        }
    }

    public void OnNavigatedAway()
    {
        // 保持 WebView 文档，便于切菜单后恢复页面状态。
    }

    private void NavigateToBatchPage()
    {
        var url = _pendingUrl ?? BuildUrl();
        _pendingUrl = null;
        WebView.Source = new Uri(url);
    }

    private string BuildUrl() => $"{LocalApiHost.Instance.BaseUrl}/?mode={ModeQuery}";
}

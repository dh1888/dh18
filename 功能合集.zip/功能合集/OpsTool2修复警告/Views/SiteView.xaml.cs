using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DHPG.Common;
using DHPG.Services;
using Growl = HandyControl.Controls.Growl;

namespace DHPG.Views;

public partial class SiteView
{
    private readonly ActivityService _activityService = new(App.DbContextFactory);
    private SiteEditModel _editing = new();
    private List<SiteListItem> _sites = new();

    public SiteView() => InitializeComponent();

    private async void SiteView_Loaded(object sender, RoutedEventArgs e) => await ReloadAsync();

    private async Task ReloadAsync()
    {
        try
        {
            _sites = await _activityService.GetSitesAsync();
            SiteGrid.ItemsSource = null;
            SiteGrid.ItemsSource = _sites;
        }
        catch (Exception ex)
        {
            Growl.Error($"加载站点失败：{ex.Message}");
        }
    }

    private void AddSite_Click(object sender, RoutedEventArgs e)
    {
        _editing = new SiteEditModel { IsEnabled = true };
        ShowEditDialog("新增站点");
    }

    private async void EditSite_Click(object sender, RoutedEventArgs e)
    {
        if (SiteGrid.SelectedItem is not SiteListItem selected)
        {
            Growl.Warning("请先选择要编辑的站点。");
            return;
        }

        await OpenEditAsync(selected.Id);
    }

    private async void SiteGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (SiteGrid.SelectedItem is not SiteListItem selected)
            return;

        await OpenEditAsync(selected.Id);
    }

    private async Task OpenEditAsync(int siteId)
    {
        try
        {
            _editing = await _activityService.GetSiteAsync(siteId) ?? new SiteEditModel();
            ShowEditDialog("编辑站点");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private async void DeleteSite_Click(object sender, RoutedEventArgs e)
    {
        if (SiteGrid.SelectedItem is not SiteListItem selected)
        {
            Growl.Warning("请先选择要删除的站点。");
            return;
        }

        if (MessageBox.Show($"确定删除站点「{selected.Name}」？", "确认删除", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        try
        {
            await _activityService.DeleteSiteAsync(selected.Id);
            Growl.Success("站点已删除。");
            await ReloadAsync();
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private void ShowEditDialog(string title)
    {
        EditTitleText.Text = title;
        NameBox.Text = _editing.Name;
        CodeBox.Text = _editing.Code;
        RemarkBox.Text = _editing.Remark ?? string.Empty;
        EnabledSwitch.IsChecked = _editing.IsEnabled;
        EditOverlay.Visibility = Visibility.Visible;
    }

    private void CancelEdit_Click(object sender, RoutedEventArgs e) =>
        EditOverlay.Visibility = Visibility.Collapsed;

    private async void SaveSite_Click(object sender, RoutedEventArgs e)
    {
        _editing.Name = NameBox.Text.Trim();
        _editing.Code = CodeBox.Text.Trim();
        _editing.Remark = RemarkBox.Text.Trim();
        _editing.IsEnabled = EnabledSwitch.IsChecked == true;

        try
        {
            await _activityService.SaveSiteAsync(_editing);
            EditOverlay.Visibility = Visibility.Collapsed;
            Growl.Success("站点已保存。");
            await ReloadAsync();
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }
}

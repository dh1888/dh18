using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using DHPG.Common;
using DHPG.Services;
using Growl = HandyControl.Controls.Growl;

namespace DHPG.Views;

public partial class ActivityView
{
    private sealed class KindComboItem
    {
        public string Label { get; init; } = string.Empty;
        public ActivityKind Kind { get; init; }
    }

    private readonly ActivityService _activityService = new(App.DbContextFactory);
    private ActivityEditModel _editing = new();
    private List<SiteListItem> _sites = new();
    private readonly Dictionary<int, CheckBox> _siteCheckBoxes = new();
    private readonly List<(HandyControl.Controls.NumericUpDown Min, HandyControl.Controls.NumericUpDown Max, HandyControl.Controls.NumericUpDown Bonus)> _fixedTierRows = new();
    private bool _suppressKindEvents;
    private bool _kindComboInitialized;

    public ActivityView() => InitializeComponent();

    private void EnsureFixedTierEditors()
    {
        if (_fixedTierRows.Count > 0)
            return;

        FixedTierPanel.Children.Add(new TextBlock
        {
            Text = "下限        上限(0=不限)        彩金",
            FontSize = 12,
            Opacity = 0.8,
            Margin = new Thickness(0, 0, 0, 6)
        });

        for (var i = 0; i < 10; i++)
        {
            var grid = new Grid { Margin = new Thickness(0, 0, 0, 6) };
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());

            var minBox = CreateTierNumericBox();
            var maxBox = CreateTierNumericBox();
            var bonusBox = CreateTierNumericBox();
            Grid.SetColumn(minBox, 0);
            Grid.SetColumn(maxBox, 1);
            Grid.SetColumn(bonusBox, 2);
            grid.Children.Add(minBox);
            grid.Children.Add(maxBox);
            grid.Children.Add(bonusBox);
            FixedTierPanel.Children.Add(grid);
            _fixedTierRows.Add((minBox, maxBox, bonusBox));
        }
    }

    private static HandyControl.Controls.NumericUpDown CreateTierNumericBox() => new()
    {
        Minimum = 0,
        Maximum = 9999999,
        Increment = 0.1,
        DecimalPlaces = 2,
        Margin = new Thickness(0, 0, 8, 0)
    };

    private async void ActivityView_Loaded(object sender, RoutedEventArgs e)
    {
        EnsureKindComboItems();
        await LoadSitesAsync();
        await ReloadActivitiesAsync();
    }

    private void EnsureKindComboItems()
    {
        if (_kindComboInitialized)
            return;

        KindCombo.ItemsSource = new[]
        {
            new KindComboItem { Label = "时段彩金", Kind = ActivityKind.Period },
            new KindComboItem { Label = "回访彩金", Kind = ActivityKind.Callback },
            new KindComboItem { Label = ActivityDefaults.Loss7dActivityName, Kind = ActivityKind.Loss7d },
            new KindComboItem { Label = ActivityDefaults.YesterdayLossActivityName, Kind = ActivityKind.YesterdayLoss },
            new KindComboItem { Label = ActivityDefaults.OldCallback234ActivityName, Kind = ActivityKind.OldCallback234 },
            new KindComboItem { Label = ActivityDefaults.ComprehensiveCallbackActivityName, Kind = ActivityKind.ComprehensiveCallback }
        };
        _kindComboInitialized = true;
    }

    private async Task LoadSitesAsync()
    {
        _sites = await _activityService.GetSitesAsync();
        SiteFilterCombo.ItemsSource = new List<SiteListItem> { new() { Id = 0, Name = "全部站点" } }.Concat(_sites).ToList();
        SiteFilterCombo.SelectedIndex = 0;
        BuildSiteCheckList();
    }

    private void BuildSiteCheckList()
    {
        _siteCheckBoxes.Clear();
        SiteCheckList.Items.Clear();

        foreach (var site in _sites)
        {
            var checkBox = new CheckBox
            {
                Content = $"{site.Name} ({site.Code})",
                Tag = site.Id,
                Margin = new Thickness(0, 0, 0, 6)
            };
            _siteCheckBoxes[site.Id] = checkBox;
            SiteCheckList.Items.Add(checkBox);
        }
    }

    private async void SiteFilterCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (IsLoaded)
            await ReloadActivitiesAsync();
    }

    private async Task ReloadActivitiesAsync()
    {
        try
        {
            int? siteId = SiteFilterCombo.SelectedItem is SiteListItem { Id: > 0 } site ? site.Id : null;
            var activities = await _activityService.GetActivitiesAsync(siteId);
            ActivityGrid.ItemsSource = null;
            ActivityGrid.ItemsSource = activities;
        }
        catch (Exception ex)
        {
            Growl.Error($"加载活动失败：{ex.Message}");
        }
    }

    private void AddActivity_Click(object sender, RoutedEventArgs e)
    {
        if (_sites.Count == 0)
        {
            Growl.Warning("请先创建站点。");
            return;
        }

        _editing = new ActivityEditModel
        {
            ApplyToAllSites = true,
            LinkedSiteIds = _sites.Select(s => s.Id).ToList(),
            Divisor = 1,
            DefaultWageringMultiplier = 1m,
            IsEnabled = true,
            Rate = 0.02m,
            MinBonus = 1m,
            Mapping = SiteMappingConfig.CreateActivityMappingDefaults(),
            FilterTierKeywords = ActivityDefaults.CreateFilterTierKeywords()
        };
        ShowEditDialog("新增活动");
    }

    private void AddComprehensiveActivity_Click(object sender, RoutedEventArgs e)
    {
        if (_sites.Count == 0)
        {
            Growl.Warning("请先创建站点。");
            return;
        }

        _editing = ActivityEditModelFactory.CreateComprehensiveTemplate();
        _editing.LinkedSiteIds = _sites.Select(s => s.Id).ToList();
        ShowEditDialog("新增综合回访");
    }

    private async void EditActivity_Click(object sender, RoutedEventArgs e)
    {
        if (ActivityGrid.SelectedItem is not ActivityListItem selected)
        {
            Growl.Warning("请先选择要编辑的活动。");
            return;
        }

        await OpenEditAsync(selected.Id);
    }

    private async void ActivityGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (ActivityGrid.SelectedItem is not ActivityListItem selected)
            return;

        await OpenEditAsync(selected.Id);
    }

    private async Task OpenEditAsync(int activityId)
    {
        try
        {
            _editing = await _activityService.GetActivityAsync(activityId) ?? new ActivityEditModel();
            ShowEditDialog("编辑活动");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private async void CopyActivity_Click(object sender, RoutedEventArgs e)
    {
        if (ActivityGrid.SelectedItem is not ActivityListItem selected)
        {
            Growl.Warning("请先选择要复制的活动。");
            return;
        }

        try
        {
            await _activityService.CopyActivityAsync(selected.Id);
            Growl.Success("活动已复制。");
            await ReloadActivitiesAsync();
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private async void DeleteActivity_Click(object sender, RoutedEventArgs e)
    {
        if (ActivityGrid.SelectedItem is not ActivityListItem selected)
        {
            Growl.Warning("请先选择要删除的活动。");
            return;
        }

        if (MessageBox.Show($"确定删除活动「{selected.Name}」？", "确认删除", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        try
        {
            await _activityService.DeleteActivityAsync(selected.Id);
            Growl.Success("活动已删除。");
            await ReloadActivitiesAsync();
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private void ShowEditDialog(string title)
    {
        EditTitleText.Text = title;
        NameBox.Text = _editing.Name;
        RateBox.Value = (double)_editing.Rate;
        DivisorBox.Value = _editing.Divisor;
        MinBonusBox.Value = (double)_editing.MinBonus;
        MaxBonusBox.Value = (double)_editing.MaxBonus;
        TierKeywordsBox.Text = string.Join(", ", _editing.FilterTierKeywords);
        AllowProfitSwitch.IsChecked = _editing.AllowProfitMember;
        EnabledSwitch.IsChecked = _editing.IsEnabled;
        SortOrderBox.Value = _editing.SortOrder;

        ApplyAllSitesCheck.IsChecked = _editing.ApplyToAllSites;
        foreach (var pair in _siteCheckBoxes)
        {
            pair.Value.IsChecked = _editing.ApplyToAllSites || _editing.LinkedSiteIds.Contains(pair.Key);
        }

        UpdateSiteCheckListEnabled();
        EditOverlay.Visibility = Visibility.Visible;
        Dispatcher.BeginInvoke(DispatcherPriority.Loaded, () =>
        {
            EnsureKindComboItems();
            _suppressKindEvents = true;
            try
            {
                SelectKindCombo(_editing.Kind);
                UpdateKindPanels();
                LoadWeeklyRates(_editing.WeeklyDayRates);
                Loss7dMinBonusBox.Value = (double)_editing.MinBonus;
                FilterLossSwitch.IsChecked = _editing.FilterLossMember;
                FilterUnclaimedSwitch.IsChecked = _editing.FilterUnclaimedEnabled;
                MinNetDiffBox.Value = (double)_editing.MinNetDiff;
                YesterdayMinBonusBox.Value = (double)_editing.MinBonus;
                YesterdayFilterUnclaimedSwitch.IsChecked = _editing.FilterUnclaimedEnabled;
                LoadTierRates(_editing.TieredAmountRates);
                LoadFixedTierBonuses(_editing.TieredFixedBonuses);
                InactiveDaysMaxBox.Value = _editing.InactiveDaysMax;
                OldCallback234MinBonusBox.Value = (double)_editing.MinBonus;
                UseNetDiffColumnSwitch.IsChecked = _editing.UseNetDiffColumn;
                OldCallback234FilterUnclaimedSwitch.IsChecked = _editing.FilterUnclaimedEnabled;
                OldCallback234FilterRechargeSwitch.IsChecked = _editing.FilterRechargeEnabled;
                LoadComprehensiveFeatures(_editing.ComprehensiveFeatures);
                ComprehensiveFilterLossSwitch.IsChecked = _editing.FilterLossMember;
                ComprehensiveFilterUnclaimedSwitch.IsChecked = _editing.FilterUnclaimedEnabled;
                ComprehensiveFilterRechargeSwitch.IsChecked = _editing.FilterRechargeEnabled;
                SelectTimezoneCombo(_editing.DefaultTimezone);
                EnsureMappingTabsInitialized();
                LoadMappingForm(_editing.Mapping);
            }
            finally
            {
                _suppressKindEvents = false;
            }
        });
    }

    private void KindCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressKindEvents || !IsLoaded || EditOverlay.Visibility != Visibility.Visible)
            return;

        UpdateKindPanels();
        if (ReadSelectedKind() == ActivityKind.ComprehensiveCallback)
            ApplyComprehensiveDefaultsToForm();
    }

    private void ApplyComprehensiveDefaultsToForm()
    {
        ApplyAllSitesCheck.IsChecked = true;
        foreach (var checkBox in _siteCheckBoxes.Values)
            checkBox.IsChecked = true;
        UpdateSiteCheckListEnabled();

        if (ComprehensiveBonusModeCombo.SelectedItem is null && ComprehensiveBonusModeCombo.Items.Count > 0)
            ComprehensiveBonusModeCombo.SelectedIndex = 1;

        if (RateBox.Value <= 0)
            RateBox.Value = 0.02;
        if (DivisorBox.Value <= 0)
            DivisorBox.Value = 2;
        if (MinBonusBox.Value <= 0)
            MinBonusBox.Value = 1;

        var weekly = _editing.WeeklyDayRates;
        if (weekly.Monday is null && weekly.Friday is null && weekly.Saturday is null && weekly.Sunday is null)
            weekly = WeeklyDayRates.CreateLoss7dDefaults();
        LoadWeeklyRates(weekly);

        LoadTierRates(_editing.TieredAmountRates.Tiers.Count > 0
            ? _editing.TieredAmountRates
            : TieredAmountRates.CreateYesterdayLossDefaults());
        LoadFixedTierBonuses(_editing.TieredFixedBonuses.Tiers.Count > 0
            ? _editing.TieredFixedBonuses
            : TieredFixedBonuses.CreateOldCallback234Defaults());
        InactiveDaysMaxBox.Value = _editing.InactiveDaysMax > 0 ? _editing.InactiveDaysMax : 7;
        MinNetDiffBox.Value = (double)(_editing.MinNetDiff > 0 ? _editing.MinNetDiff : 20m);
        AllowProfitSwitch.IsChecked = true;
        EnsureFixedTierEditors();
    }

    private void UpdateKindPanels()
    {
        var kind = ReadSelectedKind();
        var isLoss7d = kind == ActivityKind.Loss7d;
        var isYesterdayLoss = kind == ActivityKind.YesterdayLoss;
        var isOldCallback234 = kind == ActivityKind.OldCallback234;
        var isComprehensive = kind == ActivityKind.ComprehensiveCallback;
        var isSpecial = isLoss7d || isYesterdayLoss || isOldCallback234;

        ComprehensiveConfigPanel.Visibility = isComprehensive ? Visibility.Visible : Visibility.Collapsed;
        StandardConfigPanel.Visibility = isSpecial && !isComprehensive ? Visibility.Collapsed : Visibility.Visible;
        Loss7dConfigPanel.Visibility = isLoss7d || isComprehensive ? Visibility.Visible : Visibility.Collapsed;
        YesterdayLossConfigPanel.Visibility = isYesterdayLoss || isComprehensive ? Visibility.Visible : Visibility.Collapsed;
        OldCallback234ConfigPanel.Visibility = isOldCallback234 || isComprehensive ? Visibility.Visible : Visibility.Collapsed;
        AllowProfitSwitch.Visibility = isSpecial && !isOldCallback234 && !isComprehensive ? Visibility.Collapsed : Visibility.Visible;
        PeriodMappingTab.Visibility = isComprehensive ? Visibility.Collapsed : (isSpecial ? Visibility.Collapsed : Visibility.Visible);
        CallbackMappingTab.Visibility = isComprehensive ? Visibility.Collapsed : (isSpecial ? Visibility.Collapsed : Visibility.Visible);
        Loss7dMappingTab.Visibility = isLoss7d ? Visibility.Visible : Visibility.Collapsed;
        YesterdayLossMappingTab.Visibility = isYesterdayLoss ? Visibility.Visible : Visibility.Collapsed;
        OldCallback234MappingTab.Visibility = isOldCallback234 ? Visibility.Visible : Visibility.Collapsed;
        ComprehensiveMappingTab.Visibility = isComprehensive ? Visibility.Visible : Visibility.Collapsed;
        RechargeMappingTab.Visibility = isOldCallback234 || isComprehensive ? Visibility.Visible : Visibility.Collapsed;

        FilterLossSwitch.Visibility = isComprehensive ? Visibility.Collapsed : Visibility.Visible;
        FilterUnclaimedSwitch.Visibility = isComprehensive ? Visibility.Collapsed : Visibility.Visible;
        YesterdayFilterUnclaimedSwitch.Visibility = isComprehensive ? Visibility.Collapsed : Visibility.Visible;
        OldCallback234FilterUnclaimedSwitch.Visibility = isComprehensive ? Visibility.Collapsed : Visibility.Visible;
        OldCallback234FilterRechargeSwitch.Visibility = isComprehensive ? Visibility.Collapsed : Visibility.Visible;

        if (isOldCallback234 || isComprehensive)
            EnsureFixedTierEditors();

        if (isComprehensive)
            MappingTabControl.SelectedItem = ComprehensiveMappingTab;
        else if (isLoss7d)
            MappingTabControl.SelectedItem = Loss7dMappingTab;
        else if (isYesterdayLoss)
            MappingTabControl.SelectedItem = YesterdayLossMappingTab;
        else if (isOldCallback234)
            MappingTabControl.SelectedItem = OldCallback234MappingTab;
    }

    private ActivityKind ReadSelectedKind() =>
        KindCombo.SelectedValue is ActivityKind kind ? kind : ActivityKind.Period;

    private void SelectKindCombo(ActivityKind kind)
    {
        EnsureKindComboItems();
        KindCombo.SelectedValue = kind;
        if (KindCombo.SelectedValue is not ActivityKind)
            KindCombo.SelectedIndex = kind switch
            {
                ActivityKind.Callback => 1,
                ActivityKind.Loss7d => 2,
                ActivityKind.YesterdayLoss => 3,
                ActivityKind.OldCallback234 => 4,
                ActivityKind.ComprehensiveCallback => 5,
                _ => 0
            };
    }

    private void SelectTimezoneCombo(ActivityTimezone timezone)
    {
        var tag = timezone == ActivityTimezone.Brazil ? "Brazil" : "Beijing";
        foreach (ComboBoxItem item in TimezoneCombo.Items)
        {
            if (string.Equals(item.Tag as string, tag, StringComparison.Ordinal))
            {
                TimezoneCombo.SelectedItem = item;
                return;
            }
        }
    }

    private ActivityTimezone ReadSelectedTimezone()
    {
        if (TimezoneCombo.SelectedItem is ComboBoxItem { Tag: string tag }
            && string.Equals(tag, "Brazil", StringComparison.OrdinalIgnoreCase))
            return ActivityTimezone.Brazil;

        return ActivityTimezone.Beijing;
    }

    private void LoadWeeklyRates(WeeklyDayRates rates)
    {
        RateMondayBox.Value = (double)(rates.Monday ?? 0m);
        RateTuesdayBox.Value = (double)(rates.Tuesday ?? 0m);
        RateWednesdayBox.Value = (double)(rates.Wednesday ?? 0m);
        RateThursdayBox.Value = (double)(rates.Thursday ?? 0m);
        RateFridayBox.Value = (double)(rates.Friday ?? 0m);
        RateSaturdayBox.Value = (double)(rates.Saturday ?? 0m);
        RateSundayBox.Value = (double)(rates.Sunday ?? 0m);
    }

    private WeeklyDayRates ReadWeeklyRates() => new()
    {
        Monday = ReadOptionalRate(RateMondayBox),
        Tuesday = ReadOptionalRate(RateTuesdayBox),
        Wednesday = ReadOptionalRate(RateWednesdayBox),
        Thursday = ReadOptionalRate(RateThursdayBox),
        Friday = ReadOptionalRate(RateFridayBox),
        Saturday = ReadOptionalRate(RateSaturdayBox),
        Sunday = ReadOptionalRate(RateSundayBox)
    };

    private static decimal? ReadOptionalRate(HandyControl.Controls.NumericUpDown box)
    {
        var value = Convert.ToDecimal(box.Value);
        return value <= 0m ? null : value;
    }

    private void LoadTierRates(TieredAmountRates rates)
    {
        var tiers = rates.Tiers.Count > 0
            ? rates.Tiers
            : TieredAmountRates.CreateYesterdayLossDefaults().Tiers;
        LoadTierRow(Tier1MinBox, Tier1MaxBox, Tier1RateBox, tiers, 0);
        LoadTierRow(Tier2MinBox, Tier2MaxBox, Tier2RateBox, tiers, 1);
        LoadTierRow(Tier3MinBox, Tier3MaxBox, Tier3RateBox, tiers, 2);
        LoadTierRow(Tier4MinBox, Tier4MaxBox, Tier4RateBox, tiers, 3);
    }

    private static void LoadTierRow(
        HandyControl.Controls.NumericUpDown minBox,
        HandyControl.Controls.NumericUpDown maxBox,
        HandyControl.Controls.NumericUpDown rateBox,
        IReadOnlyList<AmountRateTier> tiers,
        int index)
    {
        if (index >= tiers.Count)
        {
            minBox.Value = 0;
            maxBox.Value = 0;
            rateBox.Value = 0;
            return;
        }

        var tier = tiers[index];
        minBox.Value = (double)tier.MinAmount;
        maxBox.Value = (double)(tier.MaxAmount ?? 0m);
        rateBox.Value = (double)tier.Rate;
    }

    private TieredAmountRates ReadTierRates()
    {
        var tiers = new List<AmountRateTier>
        {
            ReadTierRow(Tier1MinBox, Tier1MaxBox, Tier1RateBox),
            ReadTierRow(Tier2MinBox, Tier2MaxBox, Tier2RateBox),
            ReadTierRow(Tier3MinBox, Tier3MaxBox, Tier3RateBox),
            ReadTierRow(Tier4MinBox, Tier4MaxBox, Tier4RateBox)
        };

        return new TieredAmountRates
        {
            Tiers = tiers
                .Where(t => t.Rate > 0m && t.MinAmount > 0m)
                .OrderBy(t => t.MinAmount)
                .ToList()
        };
    }

    private static AmountRateTier ReadTierRow(
        HandyControl.Controls.NumericUpDown minBox,
        HandyControl.Controls.NumericUpDown maxBox,
        HandyControl.Controls.NumericUpDown rateBox)
    {
        var min = ReadDecimal(minBox);
        var max = ReadDecimal(maxBox);
        var rate = ReadDecimal(rateBox);
        return new AmountRateTier
        {
            MinAmount = min,
            MaxAmount = max <= 0m ? null : max,
            Rate = rate
        };
    }

    private void LoadFixedTierBonuses(TieredFixedBonuses bonuses)
    {
        EnsureFixedTierEditors();
        var tiers = bonuses.Tiers.Count > 0
            ? bonuses.Tiers
            : TieredFixedBonuses.CreateOldCallback234Defaults().Tiers;

        for (var i = 0; i < _fixedTierRows.Count; i++)
        {
            if (i >= tiers.Count)
            {
                _fixedTierRows[i].Min.Value = 0;
                _fixedTierRows[i].Max.Value = 0;
                _fixedTierRows[i].Bonus.Value = 0;
                continue;
            }

            var tier = tiers[i];
            _fixedTierRows[i].Min.Value = (double)tier.MinAmount;
            _fixedTierRows[i].Max.Value = (double)(tier.MaxAmount ?? 0m);
            _fixedTierRows[i].Bonus.Value = (double)tier.Bonus;
        }
    }

    private TieredFixedBonuses ReadFixedTierBonuses()
    {
        EnsureFixedTierEditors();
        var tiers = _fixedTierRows
            .Select(row => new FixedBonusTier
            {
                MinAmount = ReadDecimal(row.Min),
                MaxAmount = ReadDecimal(row.Max) <= 0m ? null : ReadDecimal(row.Max),
                Bonus = ReadDecimal(row.Bonus)
            })
            .Where(t => t.Bonus > 0m && t.MinAmount > 0m)
            .OrderBy(t => t.MinAmount)
            .ToList();

        return new TieredFixedBonuses { Tiers = tiers };
    }

    /// <summary>TabControl 未选中的页签可能尚未布局，需逐个激活后再读写映射。</summary>
    private void EnsureMappingTabsInitialized()
    {
        if (MappingTabControl.Items.Count == 0)
            return;

        EditOverlay.UpdateLayout();
        MappingTabControl.UpdateLayout();

        var selected = MappingTabControl.SelectedIndex;
        for (var i = 0; i < MappingTabControl.Items.Count; i++)
        {
            MappingTabControl.SelectedIndex = i;
            MappingTabControl.UpdateLayout();
            if (MappingTabControl.SelectedContent is FrameworkElement content)
                content.UpdateLayout();
        }

        MappingTabControl.SelectedIndex = selected >= 0 ? selected : 0;
        MappingTabControl.UpdateLayout();
    }

    private void LoadMappingForm(SiteMappingConfig mapping)
    {
        PeriodMappingFields.LoadFrom(mapping.Period);
        CallbackMappingFields.LoadFrom(mapping.Callback);
        Loss7dMappingFields.LoadFrom(mapping.Loss7d);
        YesterdayLossMappingFields.LoadFrom(mapping.YesterdayLoss);
        OldCallback234MappingFields.LoadFrom(mapping.OldCallback234);
        ComprehensiveMappingFields.LoadFrom(mapping.Comprehensive);
        RechargeMappingFields.LoadFrom(mapping.Recharge);
        UnclaimedMappingField.LoadFrom(mapping.UnclaimedUserIdColumn);
    }

    private SiteMappingConfig ReadMappingForm()
    {
        EnsureMappingTabsInitialized();
        return new SiteMappingConfig
        {
            Period = PeriodMappingFields.ReadMapping(),
            Callback = CallbackMappingFields.ReadMapping(),
            Loss7d = Loss7dMappingFields.ReadMapping(),
            YesterdayLoss = YesterdayLossMappingFields.ReadMapping(),
            OldCallback234 = OldCallback234MappingFields.ReadMapping(),
            Comprehensive = ComprehensiveMappingFields.ReadMapping(),
            Recharge = RechargeMappingFields.ReadMapping(),
            UnclaimedUserIdColumn = UnclaimedMappingField.ReadColumn()
        };
    }

    private void ApplyAllSitesCheck_Changed(object sender, RoutedEventArgs e)
    {
        if (!IsLoaded)
            return;

        if (ApplyAllSitesCheck.IsChecked == true)
        {
            foreach (var checkBox in _siteCheckBoxes.Values)
                checkBox.IsChecked = true;
        }

        UpdateSiteCheckListEnabled();
    }

    private void UpdateSiteCheckListEnabled()
    {
        var allSites = ApplyAllSitesCheck.IsChecked == true;
        foreach (var checkBox in _siteCheckBoxes.Values)
            checkBox.IsEnabled = !allSites;
    }

    private void CancelEdit_Click(object sender, RoutedEventArgs e) =>
        EditOverlay.Visibility = Visibility.Collapsed;

    private async void SaveActivity_Click(object sender, RoutedEventArgs e)
    {
        _editing.Name = NameBox.Text.Trim();
        _editing.Rate = ReadDecimal(RateBox);
        _editing.Divisor = ReadInt(DivisorBox);
        _editing.MinBonus = ReadDecimal(MinBonusBox);
        _editing.MaxBonus = ReadDecimal(MaxBonusBox);
        _editing.FilterTierKeywords = ParseKeywords(TierKeywordsBox.Text);
        _editing.AllowProfitMember = AllowProfitSwitch.IsChecked == true;
        _editing.IsEnabled = EnabledSwitch.IsChecked == true;
        _editing.SortOrder = ReadInt(SortOrderBox);
        _editing.ApplyToAllSites = ApplyAllSitesCheck.IsChecked == true;
        _editing.LinkedSiteIds = _editing.ApplyToAllSites
            ? new List<int>()
            : _siteCheckBoxes.Where(p => p.Value.IsChecked == true).Select(p => p.Key).ToList();
        _editing.Kind = ReadSelectedKind();
        _editing.WeeklyDayRates = ReadWeeklyRates();
        _editing.DefaultTimezone = ReadSelectedTimezone();
        _editing.FilterLossMember = FilterLossSwitch.IsChecked == true;
        _editing.FilterUnclaimedEnabled = FilterUnclaimedSwitch.IsChecked == true;
        if (_editing.Kind == ActivityKind.Loss7d)
        {
            _editing.MinBonus = ReadDecimal(Loss7dMinBonusBox);
            _editing.AllowProfitMember = false;
            _editing.Rate = 0m;
            _editing.MaxBonus = 0m;
        }
        else if (_editing.Kind == ActivityKind.YesterdayLoss)
        {
            _editing.MinNetDiff = ReadDecimal(MinNetDiffBox);
            _editing.MinBonus = ReadDecimal(YesterdayMinBonusBox);
            _editing.TieredAmountRates = ReadTierRates();
            _editing.FilterUnclaimedEnabled = YesterdayFilterUnclaimedSwitch.IsChecked == true;
            _editing.AllowProfitMember = false;
            _editing.Rate = 0m;
            _editing.MaxBonus = 0m;
        }
        else if (_editing.Kind == ActivityKind.OldCallback234)
        {
            _editing.InactiveDaysMax = ReadInt(InactiveDaysMaxBox);
            _editing.MinBonus = ReadDecimal(OldCallback234MinBonusBox);
            _editing.UseNetDiffColumn = UseNetDiffColumnSwitch.IsChecked == true;
            _editing.FilterUnclaimedEnabled = OldCallback234FilterUnclaimedSwitch.IsChecked == true;
            _editing.FilterRechargeEnabled = OldCallback234FilterRechargeSwitch.IsChecked == true;
            _editing.TieredFixedBonuses = ReadFixedTierBonuses();
            _editing.AllowProfitMember = AllowProfitSwitch.IsChecked == true;
            _editing.Rate = 0m;
            _editing.MaxBonus = 0m;
        }
        else if (_editing.Kind == ActivityKind.ComprehensiveCallback)
        {
            _editing.Rate = ReadDecimal(RateBox);
            _editing.Divisor = ReadInt(DivisorBox);
            _editing.MaxBonus = ReadDecimal(MaxBonusBox);
            _editing.WeeklyDayRates = ReadWeeklyRates();
            _editing.DefaultTimezone = ReadSelectedTimezone();
            _editing.MinNetDiff = ReadDecimal(MinNetDiffBox);
            _editing.TieredAmountRates = ReadTierRates();
            _editing.InactiveDaysMax = ReadInt(InactiveDaysMaxBox);
            _editing.UseNetDiffColumn = UseNetDiffColumnSwitch.IsChecked == true;
            _editing.TieredFixedBonuses = ReadFixedTierBonuses();
            _editing.ComprehensiveFeatures = ReadComprehensiveFeatures();
            _editing.FilterLossMember = ComprehensiveFilterLossSwitch.IsChecked == true;
            _editing.FilterUnclaimedEnabled = ComprehensiveFilterUnclaimedSwitch.IsChecked == true;
            _editing.FilterRechargeEnabled = ComprehensiveFilterRechargeSwitch.IsChecked == true;
            _editing.AllowProfitMember = AllowProfitSwitch.IsChecked == true;
            _editing.ApplyToAllSites = true;
            _editing.LinkedSiteIds = new List<int>();
            _editing.SiteId = null;
            _editing.MinBonus = _editing.ComprehensiveFeatures.BonusMode switch
            {
                ComprehensiveBonusMode.Loss7dWeekly => ReadDecimal(Loss7dMinBonusBox),
                ComprehensiveBonusMode.YesterdayLossTiered => ReadDecimal(YesterdayMinBonusBox),
                ComprehensiveBonusMode.OldCallback234Fixed => ReadDecimal(OldCallback234MinBonusBox),
                _ => ReadDecimal(MinBonusBox)
            };
        }

        try
        {
            _editing.Mapping = ReadMappingForm();
            await _activityService.SaveActivityAsync(_editing);
            EditOverlay.Visibility = Visibility.Collapsed;
            Growl.Success("活动已保存。");
            await ReloadActivitiesAsync();
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private void LoadComprehensiveFeatures(ComprehensiveCallbackFeatures features)
    {
        ComprehensiveBonusModeCombo.SelectedIndex = features.BonusMode switch
        {
            ComprehensiveBonusMode.StandardMerged => 0,
            ComprehensiveBonusMode.Loss7dWeekly => 2,
            ComprehensiveBonusMode.YesterdayLossTiered => 3,
            ComprehensiveBonusMode.OldCallback234Fixed => 4,
            _ => 1
        };

        ComprehensiveInactiveDaysSwitch.IsChecked = features.EnableInactiveDaysFilter;
        ComprehensiveMinNetDiffSwitch.IsChecked = features.EnableMinNetDiffGate;
    }

    private ComprehensiveCallbackFeatures ReadComprehensiveFeatures()
    {
        var bonusMode = ComprehensiveBonusModeCombo.SelectedIndex switch
        {
            0 => ComprehensiveBonusMode.StandardMerged,
            2 => ComprehensiveBonusMode.Loss7dWeekly,
            3 => ComprehensiveBonusMode.YesterdayLossTiered,
            4 => ComprehensiveBonusMode.OldCallback234Fixed,
            _ => ComprehensiveBonusMode.StandardSplit
        };

        return new ComprehensiveCallbackFeatures
        {
            BonusMode = bonusMode,
            EnableInactiveDaysFilter = ComprehensiveInactiveDaysSwitch.IsChecked == true,
            EnableMinNetDiffGate = ComprehensiveMinNetDiffSwitch.IsChecked == true
        };
    }

    private static decimal ReadDecimal(HandyControl.Controls.NumericUpDown box) => Convert.ToDecimal(box.Value);

    private static int ReadInt(HandyControl.Controls.NumericUpDown box) =>
        Convert.ToInt32(box.Value);

    private static List<string> ParseKeywords(string text) =>
        text.Split(new[] { ',', '，', '\r', '\n', ';', '；' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(k => k.Trim())
            .Where(k => k.Length > 0)
            .Distinct()
            .ToList();
}

using System.Windows;
using System.Windows.Controls;
using DHPG.Common;
using DHPG.Services;
using Growl = HandyControl.Controls.Growl;

namespace DHPG.Views;

public partial class DashboardView
{
    private static readonly ExcelService SharedExcelService = new();
    private readonly ProcessService _processService = new(App.DbContextFactory, SharedExcelService);
    private readonly ExportService _exportService = new(App.DbContextFactory);

    private HistoryDetailModel? _currentDetail;
    private bool _initialized;
    private DateTime _lastReloadUtc = DateTime.MinValue;
    private static readonly TimeSpan ReloadCooldown = TimeSpan.FromSeconds(3);
    private List<HistoryListItem> _allRecentHistories = new();

    public DashboardView() => InitializeComponent();

    private async void DashboardView_Loaded(object sender, RoutedEventArgs e) => await EnsureInitializedAsync();

    private async void DashboardView_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (!IsVisible || !IsLoaded || !_initialized)
            return;

        if (DateTime.UtcNow - _lastReloadUtc < ReloadCooldown)
            return;

        await ReloadAsync();
    }

    private async Task EnsureInitializedAsync()
    {
        if (_initialized)
            return;

        _initialized = true;
        await ReloadAsync();
    }

    private async Task ReloadAsync()
    {
        try
        {
            var stats = await _processService.GetDashboardStatsAsync();
            VersionValue.Text = $"v{stats.Version}";
            SiteCountValue.Text = stats.SiteCount.ToString();
            ActivityCountValue.Text = stats.ActivityCount.ToString();
            TodayCountValue.Text = stats.TodayProcessCount.ToString();
            _allRecentHistories = await _processService.GetHistoriesAsync(take: 200);
            ApplyRecentFilter();
            _lastReloadUtc = DateTime.UtcNow;
        }
        catch (Exception ex)
        {
            Growl.Error($"加载首页数据失败：{ex.Message}");
        }
    }

    private void RecentSearchBox_TextChanged(object sender, TextChangedEventArgs e) => ApplyRecentFilter();

    private void ApplyRecentFilter()
    {
        var keyword = RecentSearchBox.Text.Trim();
        if (string.IsNullOrEmpty(keyword))
        {
            RecentGrid.ItemsSource = _allRecentHistories;
            return;
        }

        RecentGrid.ItemsSource = _allRecentHistories
            .Where(h => MatchesRecentSearch(h, keyword))
            .ToList();
    }

    private static bool MatchesRecentSearch(HistoryListItem item, string keyword)
    {
        if (item.SiteName.Contains(keyword, StringComparison.OrdinalIgnoreCase))
            return true;

        if (item.ActivityName.Contains(keyword, StringComparison.OrdinalIgnoreCase))
            return true;

        if (item.ProcessedAt.ToString("yyyy-MM-dd HH:mm:ss").Contains(keyword, StringComparison.OrdinalIgnoreCase))
            return true;

        if (item.Id.ToString().Contains(keyword, StringComparison.OrdinalIgnoreCase))
            return true;

        return false;
    }

    private async void RecentGrid_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (RecentGrid.SelectedItem is not HistoryListItem selected)
            return;

        try
        {
            _currentDetail = await _processService.GetHistoryDetailAsync(selected.Id);
            if (_currentDetail is null)
            {
                Growl.Warning("找不到历史记录。");
                return;
            }

            RenderDetail(_currentDetail);
            DetailOverlay.Visibility = Visibility.Visible;
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private void RenderDetail(HistoryDetailModel detail)
    {
        DetailPanel.Children.Clear();
        var snap = detail.Snapshot;

        AddLine($"处理时间：{detail.ProcessedAt:yyyy-MM-dd HH:mm:ss}");
        AddLine($"站点 / 活动：{detail.SiteName} / {detail.ActivityName}");
        if (snap.ResultPreview?.UsesSplitRewards == true)
        {
            AddLine($"上传 {detail.Summary.TotalCount} · 过滤 {detail.Summary.FilteredCount} · " +
                    $"亏损派发 {detail.Summary.LossRewardCount} · 盈利派发 {detail.Summary.ProfitRewardCount} · " +
                    $"总彩金 {detail.Summary.TotalBonus:N2}");
        }
        else
        {
            AddLine($"上传 {detail.Summary.TotalCount} · 过滤 {detail.Summary.FilteredCount} · 派奖 {detail.Summary.RewardCount} · 总彩金 {detail.Summary.TotalBonus:N2}");
        }
        AddSeparator();

        AddLine("【活动参数（快照）】");
        AddLine($"比例={snap.Activity.Rate:P2}  除数={snap.Activity.Divisor}  最低={snap.Activity.MinBonus:N2}  最高={(snap.Activity.MaxBonus > 0 ? snap.Activity.MaxBonus.ToString("N2") : "不封顶")}");
        AddLine($"允许盈利会员={YesNo(snap.ProcessOptions.IncludeProfitMember)}  过滤未领={YesNo(snap.ProcessOptions.FilterUnclaimed)}");
        AddLine($"层级关键字：{string.Join(", ", snap.Activity.FilterTierKeywords)}");
        AddSeparator();

        AddLine("【列映射（快照）】");
        var m = snap.ColumnMapping;
        AddLine($"会员ID={Col(m.UserIdColumn)} 充值={Col(m.PayColumn)} 提现={Col(m.WithdrawColumn)} 手机={(m.PhoneColumn >= 0 ? Col(m.PhoneColumn) : "不读")} 层级={(m.TierColumn >= 0 ? Col(m.TierColumn) : "不读")} 表头行={m.HeaderRow}");
        AddSeparator();

        AddLine("【派奖设置（快照）】");
        AddLine($"打码={snap.RewardSettings.WageringMultiplier:N2}  APP={snap.RewardSettings.AppRemark}  后台={snap.RewardSettings.BackendRemark}");

        if (!string.IsNullOrWhiteSpace(detail.ExportFilePath))
            AddLine($"原导出文件：{detail.ExportFilePath}");

        if (snap.ResultPreview?.UsesSplitRewards == true)
        {
            if (snap.ResultPreview.LossRewardSample.Count > 0)
            {
                AddSeparator();
                AddLine($"【亏损派奖样本（前 {snap.ResultPreview.LossRewardSample.Count} 条）】");
                foreach (var row in snap.ResultPreview.LossRewardSample.Take(10))
                    AddLine($"{row.UserId} · 彩金 {row.Bonus:N2} · 打码 {row.WageringMultiplier:N2}");
            }

            if (snap.ResultPreview.ProfitRewardSample.Count > 0)
            {
                AddSeparator();
                AddLine($"【盈利派奖样本（前 {snap.ResultPreview.ProfitRewardSample.Count} 条）】");
                foreach (var row in snap.ResultPreview.ProfitRewardSample.Take(10))
                    AddLine($"{row.UserId} · 彩金 {row.Bonus:N2} · 打码 {row.WageringMultiplier:N2}");
            }
        }
        else if (snap.ResultPreview?.RewardSample.Count > 0)
        {
            AddSeparator();
            AddLine($"【派奖样本（前 {snap.ResultPreview.RewardSample.Count} 条）】");
            foreach (var row in snap.ResultPreview.RewardSample.Take(10))
                AddLine($"{row.UserId} · 彩金 {row.Bonus:N2} · 打码 {row.WageringMultiplier:N2}");
        }
    }

    private void AddLine(string text) =>
        DetailPanel.Children.Add(new TextBlock
        {
            Text = text,
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(0, 0, 0, 6)
        });

    private void AddSeparator() =>
        DetailPanel.Children.Add(new Border
        {
            Height = 1,
            Background = System.Windows.Media.Brushes.LightGray,
            Opacity = 0.4,
            Margin = new Thickness(0, 4, 0, 10)
        });

    private static string YesNo(bool value) => value ? "是" : "否";
    private static string Col(int index) => Extensions.FormatColumnInput(index);

    private async void ExportHistory_Click(object sender, RoutedEventArgs e)
    {
        if (_currentDetail is null)
            return;

        var export = await _exportService.ExportHistoryExcelAsync(_currentDetail);
        if (export.Success)
            Growl.Success(export.Message ?? $"已导出：{export.FilePath}");
        else
            Growl.Error(export.Message ?? "导出失败");
    }

    private void CloseDetail_Click(object sender, RoutedEventArgs e)
    {
        DetailOverlay.Visibility = Visibility.Collapsed;
        _currentDetail = null;
    }
}

using System.Windows;

using System.Windows.Controls;

using DHPG.Common;

using DHPG.Services;

using Growl = HandyControl.Controls.Growl;



namespace DHPG.Views;



public partial class HistoryView

{

    private enum HistoryCacheViewKind

    {

        Details,

        MergedRewards,

        LossRewards,

        ProfitRewards

    }



    private readonly ProcessService _processService = new(App.DbContextFactory, new ExcelService());

    private readonly ExportService _exportService = new(App.DbContextFactory);

    private readonly ActivityService _activityService = new(App.DbContextFactory);

    private readonly ResultRepository _resultRepository = new();



    private HistoryDetailModel? _currentDetail;

    private int? _loadedSiteFilterId;

    private DateTime _lastReloadUtc = DateTime.MinValue;

    private static readonly TimeSpan ReloadCooldown = TimeSpan.FromSeconds(2);

    private const int HistoryPageSize = 500;

    private string? _historyCacheKey;

    private HistoryCacheViewKind _historyCacheView = HistoryCacheViewKind.Details;

    private int _historyCachePage;

    private bool _suppressHistoryCacheViewChange;



    public HistoryView() => InitializeComponent();



    private async void HistoryView_Loaded(object sender, RoutedEventArgs e)

    {

        await LoadSiteFilterAsync();

        await ReloadHistoriesAsync(force: true);

    }



    private async void HistoryView_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)

    {

        if (!IsVisible || !IsLoaded)

            return;



        if (DateTime.UtcNow - _lastReloadUtc < ReloadCooldown)

            return;



        await ReloadHistoriesAsync(force: false);

    }



    private async Task LoadSiteFilterAsync()

    {

        var sites = await _activityService.GetSitesAsync();

        SiteFilterCombo.ItemsSource = new List<SiteListItem> { new() { Id = 0, Name = "全部站点" } }.Concat(sites).ToList();

        SiteFilterCombo.SelectedIndex = 0;

    }



    private async void SiteFilterCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)

    {

        if (IsLoaded)

            await ReloadHistoriesAsync(force: true);

    }



    private async void Refresh_Click(object sender, RoutedEventArgs e) => await ReloadHistoriesAsync(force: true);



    private async Task ReloadHistoriesAsync(bool force = true)

    {

        try

        {

            int? siteId = SiteFilterCombo.SelectedItem is SiteListItem { Id: > 0 } site ? site.Id : null;



            if (!force

                && _loadedSiteFilterId == siteId

                && HistoryGrid.ItemsSource is List<HistoryListItem> { Count: > 0 })

            {

                return;

            }



            var items = await _processService.GetHistoriesAsync(siteId, take: 200);

            if (!ReferenceEquals(HistoryGrid.ItemsSource, items))

                HistoryGrid.ItemsSource = items;



            _loadedSiteFilterId = siteId;

            _lastReloadUtc = DateTime.UtcNow;

        }

        catch (Exception ex)

        {

            Growl.Error($"加载历史失败：{ex.Message}");

        }

    }



    private async void HistoryGrid_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)

    {

        if (HistoryGrid.SelectedItem is not HistoryListItem selected)

            return;



        try

        {

            _currentDetail = await _processService.GetHistoryDetailAsync(selected.Id);

            if (_currentDetail is null)

            {

                Growl.Warning("找不到历史记录。");

                return;

            }



            RenderDetail(_currentDetail);

            DetailOverlay.Visibility = Visibility.Visible;

        }

        catch (Exception ex)

        {

            Growl.Error(ex.Message);

        }

    }



    private void RenderDetail(HistoryDetailModel detail, bool preservePage = false)

    {

        DetailPanel.Children.Clear();

        var snap = detail.Snapshot;

        _historyCacheKey = !string.IsNullOrEmpty(snap.ResultCacheKey)

                           && _resultRepository.Exists(snap.ResultCacheKey)

            ? snap.ResultCacheKey

            : null;



        if (!preservePage)

        {

            _historyCachePage = 0;

            _historyCacheView = HistoryCacheViewKind.Details;

        }



        ConfigureHistoryCachePaging();

        CachePagingPanel.Visibility = _historyCacheKey is not null

            ? Visibility.Visible

            : Visibility.Collapsed;



        AddLine($"处理时间：{detail.ProcessedAt:yyyy-MM-dd HH:mm:ss}");

        AddLine($"站点 / 活动：{detail.SiteName} / {detail.ActivityName}");

        if (snap.ResultPreview?.UsesSplitRewards == true || UsesSplitRewardsFromCache())

        {

            AddLine($"上传 {detail.Summary.TotalCount} · 过滤 {detail.Summary.FilteredCount} · " +

                    $"亏损派发 {detail.Summary.LossRewardCount} · 盈利派发 {detail.Summary.ProfitRewardCount} · " +

                    $"总彩金 {detail.Summary.TotalBonus:N2}");

        }

        else

        {

            AddLine($"上传 {detail.Summary.TotalCount} · 过滤 {detail.Summary.FilteredCount} · 派奖 {detail.Summary.RewardCount} · 总彩金 {detail.Summary.TotalBonus:N2}");

        }

        AddSeparator();



        AddLine("【活动参数（快照）】");

        AddLine($"比例={snap.Activity.Rate:P2}  除数={snap.Activity.Divisor}  最低={snap.Activity.MinBonus:N2}  最高={(snap.Activity.MaxBonus > 0 ? snap.Activity.MaxBonus.ToString("N2") : "不封顶")}");

        AddLine($"允许盈利会员={YesNo(snap.ProcessOptions.IncludeProfitMember)}  过滤未领={YesNo(snap.ProcessOptions.FilterUnclaimed)}");

        AddLine($"层级关键字：{string.Join(", ", snap.Activity.FilterTierKeywords)}");

        AddSeparator();



        AddLine("【列映射（快照）】");

        var m = snap.ColumnMapping;

        AddLine($"会员ID={Col(m.UserIdColumn)} 充值={Col(m.PayColumn)} 提现={Col(m.WithdrawColumn)} 手机={(m.PhoneColumn >= 0 ? Col(m.PhoneColumn) : "不读")} 层级={(m.TierColumn >= 0 ? Col(m.TierColumn) : "不读")} 表头行={m.HeaderRow}");

        AddSeparator();



        AddLine("【派奖设置（快照）】");

        AddLine($"打码={snap.RewardSettings.WageringMultiplier:N2}  APP={snap.RewardSettings.AppRemark}  后台={snap.RewardSettings.BackendRemark}");



        if (!string.IsNullOrWhiteSpace(detail.ExportFilePath))

            AddLine($"原导出文件：{detail.ExportFilePath}");



        if (_historyCacheKey is not null)

        {

            AddSeparator();

            AddCachedPage();

            return;

        }



        if (snap.ResultPreview?.UsesSplitRewards == true)

        {

            if (snap.ResultPreview.LossRewardSample.Count > 0)

            {

                AddSeparator();

                AddLine($"【亏损派奖样本（前 {snap.ResultPreview.LossRewardSample.Count} 条）】");

                foreach (var row in snap.ResultPreview.LossRewardSample.Take(10))

                    AddLine($"{row.UserId} · 彩金 {row.Bonus:N2} · 打码 {row.WageringMultiplier:N2}");

            }



            if (snap.ResultPreview.ProfitRewardSample.Count > 0)

            {

                AddSeparator();

                AddLine($"【盈利派奖样本（前 {snap.ResultPreview.ProfitRewardSample.Count} 条）】");

                foreach (var row in snap.ResultPreview.ProfitRewardSample.Take(10))

                    AddLine($"{row.UserId} · 彩金 {row.Bonus:N2} · 打码 {row.WageringMultiplier:N2}");

            }

        }

        else if (snap.ResultPreview?.RewardSample.Count > 0)

        {

            AddSeparator();

            AddLine($"【派奖样本（前 {snap.ResultPreview.RewardSample.Count} 条）】");

            foreach (var row in snap.ResultPreview.RewardSample.Take(10))

                AddLine($"{row.UserId} · 彩金 {row.Bonus:N2} · 打码 {row.WageringMultiplier:N2}");

        }

    }



    private void ConfigureHistoryCachePaging()

    {

        _suppressHistoryCacheViewChange = true;

        try

        {

            HistoryCacheViewCombo.Items.Clear();

            if (_historyCacheKey is null)

                return;



            HistoryCacheViewCombo.Items.Add(CreateViewItem("处理明细", HistoryCacheViewKind.Details));

            if (UsesSplitRewardsFromCache())

            {

                HistoryCacheViewCombo.Items.Add(CreateViewItem("亏损派奖", HistoryCacheViewKind.LossRewards));

                HistoryCacheViewCombo.Items.Add(CreateViewItem("盈利派奖", HistoryCacheViewKind.ProfitRewards));

            }

            else

            {

                HistoryCacheViewCombo.Items.Add(CreateViewItem("派奖", HistoryCacheViewKind.MergedRewards));

            }



            var selectedIndex = 0;

            for (var i = 0; i < HistoryCacheViewCombo.Items.Count; i++)

            {

                if (HistoryCacheViewCombo.Items[i] is ComboBoxItem { Tag: HistoryCacheViewKind kind }

                    && kind == _historyCacheView)

                {

                    selectedIndex = i;

                    break;

                }

            }



            HistoryCacheViewCombo.SelectedIndex = selectedIndex;

        }

        finally

        {

            _suppressHistoryCacheViewChange = false;

        }

    }



    private static ComboBoxItem CreateViewItem(string label, HistoryCacheViewKind kind) => new()

    {

        Content = label,

        Tag = kind

    };



    private bool UsesSplitRewardsFromCache()

    {

        if (_historyCacheKey is null)

            return _currentDetail?.Snapshot.ResultPreview?.UsesSplitRewards == true;



        return _resultRepository.TryGetMeta(_historyCacheKey)?.UsesSplitRewards == true;

    }



    private void AddCachedPage()

    {

        if (_historyCacheKey is null)

            return;



        switch (_historyCacheView)

        {

            case HistoryCacheViewKind.MergedRewards:

                AddCachedRewardPage(RewardStreamKind.Merged, "派奖");

                break;

            case HistoryCacheViewKind.LossRewards:

                AddCachedRewardPage(RewardStreamKind.Loss, "亏损派奖");

                break;

            case HistoryCacheViewKind.ProfitRewards:

                AddCachedRewardPage(RewardStreamKind.Profit, "盈利派奖");

                break;

            default:

                AddCachedDetailPage();

                break;

        }

    }



    private void AddCachedDetailPage()

    {

        if (_historyCacheKey is null)

            return;



        var total = _resultRepository.CountDetails(_historyCacheKey, excludedOnly: false);

        if (total == 0)

        {

            HistoryCachePageText.Text = "无明细数据";

            AddLine("缓存中无处理明细。");

            return;

        }



        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)HistoryPageSize));

        _historyCachePage = Math.Clamp(_historyCachePage, 0, totalPages - 1);

        var skip = _historyCachePage * HistoryPageSize;

        var page = _resultRepository.ReadDetailPage(_historyCacheKey, skip, HistoryPageSize, excludedOnly: false);



        HistoryCachePageText.Text = $"第 {_historyCachePage + 1} / {totalPages} 页，共 {total} 条";

        AddLine($"【处理明细（缓存分页，每页 {HistoryPageSize} 条）】");

        foreach (var row in page)

        {

            var suffix = string.IsNullOrEmpty(row.ExcludeReason)

                ? $"彩金 {row.Bonus:N2}"

                : $"剔除：{row.ExcludeReason}";

            AddLine($"{row.UserId} · 盈亏 {row.Profit:N2} · {suffix}");

        }

    }



    private void AddCachedRewardPage(RewardStreamKind kind, string title)

    {

        if (_historyCacheKey is null)

            return;



        var total = _resultRepository.CountRewards(_historyCacheKey, kind);

        if (total == 0)

        {

            HistoryCachePageText.Text = $"无{title}数据";

            AddLine($"缓存中无{title}记录。");

            return;

        }



        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)HistoryPageSize));

        _historyCachePage = Math.Clamp(_historyCachePage, 0, totalPages - 1);

        var skip = _historyCachePage * HistoryPageSize;

        var page = _resultRepository.ReadRewardPage(_historyCacheKey, kind, skip, HistoryPageSize);



        HistoryCachePageText.Text = $"第 {_historyCachePage + 1} / {totalPages} 页，共 {total} 条";

        AddLine($"【{title}（缓存分页，每页 {HistoryPageSize} 条）】");

        foreach (var row in page)

            AddLine($"{row.UserId} · 彩金 {row.Bonus:N2} · 打码 {row.WageringMultiplier:N2}");

    }



    private void HistoryCacheViewCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)

    {

        if (_suppressHistoryCacheViewChange

            || _currentDetail is null

            || HistoryCacheViewCombo.SelectedItem is not ComboBoxItem { Tag: HistoryCacheViewKind kind })

        {

            return;

        }



        _historyCacheView = kind;

        _historyCachePage = 0;

        RenderDetail(_currentDetail, preservePage: true);

    }



    private void HistoryCachePrev_Click(object sender, RoutedEventArgs e)

    {

        if (_historyCacheKey is null || _currentDetail is null || _historyCachePage <= 0)

            return;



        _historyCachePage--;

        RenderDetail(_currentDetail, preservePage: true);

    }



    private void HistoryCacheNext_Click(object sender, RoutedEventArgs e)

    {

        if (_historyCacheKey is null || _currentDetail is null)

            return;



        var total = GetCurrentCacheViewCount();

        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)HistoryPageSize));

        if (_historyCachePage >= totalPages - 1)

            return;



        _historyCachePage++;

        RenderDetail(_currentDetail, preservePage: true);

    }



    private int GetCurrentCacheViewCount()

    {

        if (_historyCacheKey is null)

            return 0;



        return _historyCacheView switch

        {

            HistoryCacheViewKind.MergedRewards => _resultRepository.CountRewards(_historyCacheKey, RewardStreamKind.Merged),

            HistoryCacheViewKind.LossRewards => _resultRepository.CountRewards(_historyCacheKey, RewardStreamKind.Loss),

            HistoryCacheViewKind.ProfitRewards => _resultRepository.CountRewards(_historyCacheKey, RewardStreamKind.Profit),

            _ => _resultRepository.CountDetails(_historyCacheKey, excludedOnly: false)

        };

    }



    private void AddLine(string text) =>

        DetailPanel.Children.Add(new TextBlock

        {

            Text = text,

            TextWrapping = TextWrapping.Wrap,

            Margin = new Thickness(0, 0, 0, 6)

        });



    private void AddSeparator() =>

        DetailPanel.Children.Add(new Border

        {

            Height = 1,

            Background = System.Windows.Media.Brushes.LightGray,

            Opacity = 0.4,

            Margin = new Thickness(0, 4, 0, 10)

        });



    private static string YesNo(bool value) => value ? "是" : "否";

    private static string Col(int index) => $"{Extensions.ColumnIndexToLetter(index)}({index})";



    private async void ExportHistory_Click(object sender, RoutedEventArgs e)

    {

        if (_currentDetail is null)

            return;



        var export = await _exportService.ExportHistoryExcelAsync(_currentDetail);

        if (export.Success)

            Growl.Success(export.Message ?? $"已导出：{export.FilePath}");

        else

            Growl.Error(export.Message ?? "导出失败");

    }



    private void CloseDetail_Click(object sender, RoutedEventArgs e)

    {

        DetailOverlay.Visibility = Visibility.Collapsed;

        _currentDetail = null;

        _historyCacheKey = null;

    }

}



using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using DHPG.Common;
using DHPG.Services;
using DHPG.Views.Controls;
using Growl = HandyControl.Controls.Growl;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;
using SaveFileDialog = Microsoft.Win32.SaveFileDialog;

namespace DHPG.Views;

public partial class ProcessView
{
    private const int PageSize = 500;
    private const int BatchPageSize = 50;
    private const string BatchPreviewHint = "预览每页 50 条；导出/复制为全量。";

    private readonly ActivityService _activityService = new(App.DbContextFactory);
    private readonly ExcelService _excelService = new();
    private readonly ProcessService _processService;
    private readonly ExportService _exportService = new(App.DbContextFactory);
    private readonly ResultRepository _resultRepository = new();

    private CancellationTokenSource? _headerRefreshCts;
    private bool _pageInitialized;

    private ProcessResult? _result;
    private CancellationTokenSource? _cts;
    private string? _memberFilePath;
    private string? _unclaimedFilePath;
    private int _detailPage;
    private int _rewardPage;
    private int _lossRewardPage;
    private int _profitRewardPage;

    private readonly ObservableCollection<BatchSiteTask> _batchTasks = new();
    private readonly ObservableCollection<SiteListItem> _allSites = new();
    private readonly Dictionary<int, SiteEditModel> _siteDetailCache = new();
    private readonly HashSet<int> _batchAssignedSiteIds = new();
    private bool _suppressBatchSiteSelection;
    private int _batchReadyCount;
    private CancellationTokenSource? _batchMappingLoadCts;
    private string? _lastLoadedBatchMappingTaskKey;
    private string? _cachedMemberHeaderKey;
    private IReadOnlyList<string>? _cachedMemberHeaders;
    private string? _cachedUnclaimedHeaderKey;
    private IReadOnlyList<string>? _cachedUnclaimedHeaders;
    private BatchProcessResult? _batchResult;
    private CancellationTokenSource? _batchCts;
    private int _batchDetailPage;
    private int _batchRewardPage;
    private int _batchLossRewardPage;
    private int _batchProfitRewardPage;
    private BatchSiteTask? _selectedBatchTask;

    private readonly ProcessPageMode _pageMode;
    private int _batchActivityId;
    private int _singleMappingSiteId;
    private int _batchMappingSiteId;
    private readonly Dictionary<int, SiteMappingConfig> _mappingOverrides = new();
    private readonly Dictionary<string, ResultBindCache> _resultBindCaches = new();
    private readonly ObservableCollection<ProcessDetailItem> _detailPageItems = new();
    private readonly ObservableCollection<RewardItem> _rewardPageItems = new();
    private readonly ObservableCollection<RewardItem> _lossRewardPageItems = new();
    private readonly ObservableCollection<RewardItem> _profitRewardPageItems = new();
    private readonly ObservableCollection<ProcessDetailItem> _batchDetailPageItems = new();
    private readonly ObservableCollection<RewardItem> _batchRewardPageItems = new();
    private readonly ObservableCollection<RewardItem> _batchLossRewardPageItems = new();
    private readonly ObservableCollection<RewardItem> _batchProfitRewardPageItems = new();
    private bool _suppressBatchTabSelection;
    private bool _suppressBatchResultTabSelection;
    private bool _suppressSingleResultTabSelection;
    private int _batchBindGeneration;
    private int _singleBindGeneration;
    private bool _batchGridsDetached;
    private bool _singleGridsDetached;
    private ProcessResult? _cachedBatchSummary;
    private string? _cachedBatchSummaryTaskKey;

    private enum ActiveRewardTab
    {
        None,
        Merged,
        Loss,
        Profit
    }

    private sealed class ResultBindCache
    {
        public int ExcludedCount = -1;
        public int[]? ExcludedIndices;
    }

    public ObservableCollection<SiteListItem> AllSites => _allSites;

    public ProcessView() : this(ProcessPageMode.Single)
    {
    }

    public ProcessView(ProcessPageMode pageMode)
    {
        _pageMode = pageMode;
        _processService = new ProcessService(App.DbContextFactory, _excelService);
        InitializeComponent();
        DataContext = this;
        BatchTaskGrid.ItemsSource = _batchTasks;
        DetailGrid.ItemsSource = _detailPageItems;
        RewardGrid.ItemsSource = _rewardPageItems;
        LossRewardGrid.ItemsSource = _lossRewardPageItems;
        ProfitRewardGrid.ItemsSource = _profitRewardPageItems;
        BatchDetailGrid.ItemsSource = _batchDetailPageItems;
        BatchRewardGrid.ItemsSource = _batchRewardPageItems;
        BatchLossRewardGrid.ItemsSource = _batchLossRewardPageItems;
        BatchProfitRewardGrid.ItemsSource = _batchProfitRewardPageItems;
        AttachDataGridMouseWheel(
            DetailGrid, RewardGrid, LossRewardGrid, ProfitRewardGrid,
            BatchDetailGrid, BatchRewardGrid, BatchLossRewardGrid, BatchProfitRewardGrid);

        if (_pageMode == ProcessPageMode.Single)
        {
            SinglePagePanel.Visibility = Visibility.Visible;
            BatchPagePanel.Visibility = Visibility.Collapsed;
        }
        else
        {
            SinglePagePanel.Visibility = Visibility.Collapsed;
            BatchPagePanel.Visibility = Visibility.Visible;
            BatchRowSiteCombo.ItemsSource = _allSites;
        }

        IsVisibleChanged += ProcessView_IsVisibleChanged;
        WireMappingHeaderEvents();
    }

    private void WireMappingHeaderEvents()
    {
        WireMemberMappingHeaderRefresh(MapPeriodFields);
        WireMemberMappingHeaderRefresh(MapCallbackFields);
        WireMemberMappingHeaderRefresh(BatchMapPeriodFields);
        WireMemberMappingHeaderRefresh(BatchMapCallbackFields);
        SingleMappingTabs.SelectionChanged += (_, _) => _ = RefreshActiveMappingHeadersAsync();
        BatchMappingTabs.SelectionChanged += (_, _) => _ = RefreshActiveMappingHeadersAsync();
    }

    private void WireMemberMappingHeaderRefresh(MemberMappingFields fields) =>
        fields.HeaderRowChanged += (_, _) => _ = RefreshActiveMappingHeadersAsync();

    private static void AttachDataGridMouseWheel(params DataGrid[] grids)
    {
        foreach (var grid in grids)
            grid.PreviewMouseWheel += DataGrid_PreviewMouseWheel;
    }

    private static void DataGrid_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
    {
        if (sender is not DataGrid grid)
            return;

        var scrollViewer = FindVisualChild<ScrollViewer>(grid);
        if (scrollViewer is not null && scrollViewer.ScrollableHeight > 0)
        {
            scrollViewer.ScrollToVerticalOffset(
                Math.Clamp(scrollViewer.VerticalOffset - e.Delta, 0, scrollViewer.ScrollableHeight));
            e.Handled = true;
            return;
        }

        var parentScrollViewer = FindVisualParent<ScrollViewer>(grid);
        if (parentScrollViewer is null || parentScrollViewer.ScrollableHeight <= 0)
            return;

        parentScrollViewer.ScrollToVerticalOffset(
            Math.Clamp(parentScrollViewer.VerticalOffset - e.Delta, 0, parentScrollViewer.ScrollableHeight));
        e.Handled = true;
    }

    private static T? FindVisualParent<T>(DependencyObject child) where T : DependencyObject
    {
        var parent = VisualTreeHelper.GetParent(child);
        while (parent is not null)
        {
            if (parent is T match)
                return match;

            parent = VisualTreeHelper.GetParent(parent);
        }

        return null;
    }

    private static T? FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
    {
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is T match)
                return match;

            var nested = FindVisualChild<T>(child);
            if (nested is not null)
                return nested;
        }

        return null;
    }

    private async void ProcessView_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (IsVisible)
        {
            RestorePageGridBindings();
            if (!IsLoaded || _pageInitialized)
                return;

            await InitializePageAsync();
            return;
        }
    }

    /// <summary>离开导航页面前调用，释放批量/单站 UI 绑定，减轻 Content 切换时的 Visual Tree 拆除成本。</summary>
    public void OnNavigatedAway()
    {
        if (_pageMode == ProcessPageMode.Single)
        {
            _singleBindGeneration++;
            ReleaseSinglePageUi();
            return;
        }

        _batchBindGeneration++;
        ReleaseBatchPageUi();
    }

    /// <summary>重新进入 Process 页时恢复 Grid 绑定。</summary>
    public void OnNavigatedTo()
    {
        RestorePageGridBindings();

        if (_pageMode == ProcessPageMode.Single)
        {
            if (_result is not null)
                BindSingleResults();
            return;
        }

        if (_batchResult is null)
            return;

        if (BatchSiteResultTabs.Items.Count == 0)
            BuildBatchResultTabs();
    }

    private void RestorePageGridBindings()
    {
        if (_pageMode == ProcessPageMode.Single)
            EnsureSingleGridBindings();
        else
            EnsureBatchGridBindings();
    }

    private void ReleaseBatchPageUi()
    {
        _batchMappingLoadCts?.Cancel();
        _batchMappingLoadCts?.Dispose();
        _batchMappingLoadCts = null;
        _lastLoadedBatchMappingTaskKey = null;

        BatchSiteResultTabs.Items.Clear();
        ClearBatchRewardGrids();
        InvalidateBatchSummaryCache();
        _selectedBatchTask = null;
        SetBatchResultExpanded(false, showToggle: ToggleBatchResultButton.Visibility == Visibility.Visible);

        if (_batchGridsDetached)
            return;

        BatchTaskGrid.ItemsSource = null;
        BatchDetailGrid.ItemsSource = null;
        BatchRewardGrid.ItemsSource = null;
        BatchLossRewardGrid.ItemsSource = null;
        BatchProfitRewardGrid.ItemsSource = null;
        _batchGridsDetached = true;
    }

    private void ReleaseSinglePageUi()
    {
        if (_singleGridsDetached)
            return;

        DetailGrid.ItemsSource = null;
        RewardGrid.ItemsSource = null;
        LossRewardGrid.ItemsSource = null;
        ProfitRewardGrid.ItemsSource = null;
        _singleGridsDetached = true;
    }

    private void EnsureBatchGridBindings()
    {
        if (!_batchGridsDetached)
            return;

        BatchTaskGrid.ItemsSource = _batchTasks;
        BatchDetailGrid.ItemsSource = _batchDetailPageItems;
        BatchRewardGrid.ItemsSource = _batchRewardPageItems;
        BatchLossRewardGrid.ItemsSource = _batchLossRewardPageItems;
        BatchProfitRewardGrid.ItemsSource = _batchProfitRewardPageItems;
        _batchGridsDetached = false;
    }

    private void EnsureSingleGridBindings()
    {
        if (!_singleGridsDetached)
            return;

        DetailGrid.ItemsSource = _detailPageItems;
        RewardGrid.ItemsSource = _rewardPageItems;
        LossRewardGrid.ItemsSource = _lossRewardPageItems;
        ProfitRewardGrid.ItemsSource = _profitRewardPageItems;
        _singleGridsDetached = false;
    }

    private bool CanUpdateProcessUi() => IsVisible && IsLoaded;

    private async void ProcessView_Loaded(object sender, RoutedEventArgs e)
    {
        if (_pageInitialized)
            return;

        await InitializePageAsync();
    }

    private async Task InitializePageAsync()
    {
        if (_pageInitialized)
            return;

        _pageInitialized = true;
        if (_pageMode == ProcessPageMode.Single)
            await LoadSitesAsync();
        else
            await LoadBatchPageAsync();
    }

    private async Task LoadBatchPageAsync()
    {
        try
        {
            await RefreshAllSitesAsync();
            var activityName = _pageMode == ProcessPageMode.PeriodBatch ? "时段彩金" : "回访彩金";
            await LoadFixedBatchActivityAsync(activityName);
            RebuildBatchAssignedSites();
            RebuildBatchReadyCount();
            UpdateBatchUnclaimedColumnVisibility();
        }
        catch (Exception ex)
        {
            Growl.Error($"加载批量页面失败：{ex.Message}");
        }
    }

    private async Task RefreshAllSitesAsync()
    {
        var (sites, editModels) = await _activityService.GetSitesBundleAsync(enabledOnly: true);
        _allSites.Clear();
        _siteDetailCache.Clear();

        foreach (var site in sites)
            _allSites.Add(site);

        foreach (var pair in editModels)
            _siteDetailCache[pair.Key] = pair.Value;

        if (_pageMode != ProcessPageMode.Single)
            BatchRowSiteCombo.ItemsSource = _allSites;
    }

    private async Task LoadFixedBatchActivityAsync(string activityName)
    {
        var activities = await _activityService.GetActivitiesAsync(enabledOnly: true);
        var activity = activities.FirstOrDefault(a => a.Name == activityName)
            ?? activities.FirstOrDefault(a =>
                activityName == "时段彩金" ? !a.AllowProfitMember : a.AllowProfitMember);

        if (activity is null)
        {
            Growl.Warning($"未找到活动「{activityName}」，请先在活动管理中创建。");
            BatchRuleFormulaText.Text = "未找到对应活动，请前往「活动管理」配置。";
            return;
        }

        _batchActivityId = activity.Id;
        await ApplyBatchActivityDefaultsAsync(activity.Id);
    }

    private async Task LoadSitesAsync()
    {
        try
        {
            await RefreshAllSitesAsync();
            SiteCombo.ItemsSource = _allSites;
            if (_allSites.Count > 0)
                SiteCombo.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            Growl.Error($"加载站点失败：{ex.Message}");
        }
    }

    private async void SiteCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!IsLoaded || SiteCombo.SelectedItem is not SiteListItem site)
            return;

        try
        {
            var activities = await _activityService.GetActivitiesAsync(site.Id, enabledOnly: true);
            ActivityCombo.ItemsSource = activities;
            ActivityCombo.SelectedIndex = activities.Count > 0 ? 0 : -1;
            LoadSingleMappingForm(site.Id);
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private async void ActivityCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!IsLoaded || ActivityCombo.SelectedItem is not ActivityListItem activity)
            return;

        try
        {
            await ApplySingleActivityDefaultsAsync(activity.Id);
            var profile = ResolveMappingProfile(activity);
            SingleMappingTabs.SelectedIndex = profile == MappingProfile.Callback ? 1 : 0;
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private async Task ApplySingleActivityDefaultsAsync(int activityId)
    {
        var model = await _activityService.GetActivityAsync(activityId);
        if (model is null)
            return;

        IncludeProfitCheck.IsChecked = model.AllowProfitMember;
    }

    private async Task ApplyBatchActivityDefaultsAsync(int activityId)
    {
        var model = await _activityService.GetActivityAsync(activityId);
        if (model is null)
            return;

        BatchIncludeProfitCheck.IsChecked = model.AllowProfitMember;
        BatchFilterUnclaimedCheck.IsChecked = _pageMode switch
        {
            ProcessPageMode.CallbackBatch => true,
            ProcessPageMode.PeriodBatch => false,
            _ => IsCallbackActivity(model)
        };

        var runtime = await _activityService.GetRuntimeParamsAsync(activityId);
        if (runtime is not null)
        {
            BatchRewardWageringBox.Value = (double)runtime.WageringMultiplier;
            BatchRewardAppRemarkBox.Text = runtime.AppRemark;
            BatchRewardBackendRemarkBox.Text = runtime.BackendRemark;
        }

        BatchRuleFormulaText.Text = BuildRuleFormulaText(model, runtime?.WageringMultiplier ?? model.DefaultWageringMultiplier);
        UpdateBatchUnclaimedColumnVisibility();
    }

    private static string BuildRuleFormulaText(ActivityEditModel model, decimal wageringMultiplier)
    {
        var maxText = model.MaxBonus > 0 ? $"最高 {model.MaxBonus:N2}" : "最高不限";
        var profitText = model.AllowProfitMember
            ? $"盈利会员（充值-提现<0）固定 {model.MinBonus:N2}"
            : "盈利会员默认剔除";

        return $"用户亏损/持平（充值-提现≥0）：(充值-提现)×{model.Rate:P2}÷{model.Divisor}，" +
               $"最低 {model.MinBonus:N2}，{maxText}；{profitText}；打码 {wageringMultiplier:N2}。";
    }

    private static bool IsCallbackActivity(ActivityEditModel model) =>
        model.AllowProfitMember || model.Name.Contains("回访", StringComparison.Ordinal);

    private void BatchTaskGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        SyncBatchRowSiteComboFromSelection();
        ScheduleBatchMappingLoad();
    }

    private void GoActivityConfig_Click(object sender, RoutedEventArgs e)
    {
        if (Window.GetWindow(this) is MainWindow mainWindow)
            mainWindow.Navigate("Activity");
    }

    private void DownloadTemplate_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var source = FindFixturePath("sample-demo.csv");
            var dialog = new SaveFileDialog
            {
                Filter = "CSV 文件|*.csv",
                FileName = "会员数据模板.csv",
                Title = "保存会员数据模板"
            };

            if (dialog.ShowDialog() != true)
                return;

            File.Copy(source, dialog.FileName, overwrite: true);
            Growl.Success($"模板已保存：{dialog.FileName}");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private static string FindFixturePath(string fileName)
    {
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "fixtures", fileName),
            Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "fixtures", fileName)
        };

        foreach (var path in candidates.Select(Path.GetFullPath))
        {
            if (File.Exists(path))
                return path;
        }

        throw new FileNotFoundException($"找不到模板文件 fixtures/{fileName}。");
    }

    private static ColumnMappingInfo CloneMapping(ColumnMappingInfo source) => new()
    {
        HeaderRow = source.HeaderRow,
        UserIdColumn = source.UserIdColumn,
        PayColumn = source.PayColumn,
        WithdrawColumn = source.WithdrawColumn,
        PhoneColumn = source.PhoneColumn,
        TierColumn = source.TierColumn
    };

    private static SiteMappingConfig CloneSiteMapping(SiteMappingConfig source) => new()
    {
        Period = CloneMapping(source.Period),
        Callback = CloneMapping(source.Callback),
        UnclaimedUserIdColumn = source.UnclaimedUserIdColumn
    };

    private SiteMappingConfig? GetEffectiveSiteMapping(int siteId)
    {
        if (_mappingOverrides.TryGetValue(siteId, out var overridden))
            return CloneSiteMapping(overridden);

        if (_siteDetailCache.TryGetValue(siteId, out var site))
            return CloneSiteMapping(site.Mapping);

        return null;
    }

    private ColumnMappingInfo? GetEffectiveMemberMapping(int siteId, MappingProfile profile)
    {
        var config = GetEffectiveSiteMapping(siteId);
        if (config is null)
            return null;

        return profile == MappingProfile.Callback
            ? CloneMapping(config.Callback)
            : CloneMapping(config.Period);
    }

    private int? GetEffectiveUnclaimedColumn(int siteId) =>
        GetEffectiveSiteMapping(siteId)?.UnclaimedUserIdColumn;

    private async Task RefreshSiteMappingCacheAsync(IEnumerable<int> siteIds)
    {
        foreach (var siteId in siteIds.Distinct())
        {
            if (siteId <= 0)
                continue;

            var detail = await _activityService.GetSiteAsync(siteId);
            if (detail is not null)
                _siteDetailCache[siteId] = detail;
        }
    }

    private ColumnMappingInfo? ResolveProcessMappingOverride(int siteId, MappingProfile profile) =>
        _mappingOverrides.ContainsKey(siteId) ? GetEffectiveMemberMapping(siteId, profile) : null;

    private int? ResolveProcessUnclaimedOverride(int siteId) =>
        _mappingOverrides.ContainsKey(siteId) ? GetEffectiveUnclaimedColumn(siteId) : null;

    private ResultBindCache GetResultBindCache(string key)
    {
        if (!_resultBindCaches.TryGetValue(key, out var cache))
        {
            cache = new ResultBindCache();
            _resultBindCaches[key] = cache;
        }

        return cache;
    }

    private void WarmDetailBindCache(IList<ProcessDetailItem>? details, string cacheKey)
    {
        if (details is null || details.Count == 0)
            return;

        EnsureExcludedIndices(details, GetResultBindCache(cacheKey));
    }

    private static void EnsureExcludedIndices(IList<ProcessDetailItem> allDetails, ResultBindCache cache)
    {
        if (cache.ExcludedIndices is not null)
            return;

        var indices = new List<int>();
        for (var i = 0; i < allDetails.Count; i++)
        {
            if (allDetails[i].IsExcluded)
                indices.Add(i);
        }

        cache.ExcludedIndices = indices.ToArray();
        cache.ExcludedCount = indices.Count;
    }

    private static MappingProfile ResolveMappingProfile(ActivityListItem activity) =>
        activity.AllowProfitMember || activity.Name.Contains("回访", StringComparison.Ordinal)
            ? MappingProfile.Callback
            : MappingProfile.Period;

    private MappingProfile GetBatchMappingProfile() =>
        _pageMode == ProcessPageMode.CallbackBatch ? MappingProfile.Callback : MappingProfile.Period;

    private void CommitSingleMappingForm()
    {
        if (_singleMappingSiteId <= 0)
            return;

        _mappingOverrides[_singleMappingSiteId] = ReadSingleSiteMappingForm();
    }

    private void CommitBatchMappingForm()
    {
        if (_batchMappingSiteId <= 0)
            return;

        _mappingOverrides[_batchMappingSiteId] = ReadBatchSiteMappingForm();
    }

    private void LoadSingleMappingForm(int siteId)
    {
        _singleMappingSiteId = siteId;
        if (!_siteDetailCache.TryGetValue(siteId, out var site))
        {
            SingleMappingSiteLabel.Text = "列映射：站点不存在";
            return;
        }

        SingleMappingSiteLabel.Text = $"列映射 · {site.Name}（{site.Code}）";
        var mapping = _mappingOverrides.TryGetValue(siteId, out var overridden)
            ? overridden
            : site.Mapping;
        LoadSiteMappingForm(mapping, false);
    }

    private void LoadBatchMappingForm(int siteId)
    {
        _batchMappingSiteId = siteId;
        if (!_siteDetailCache.TryGetValue(siteId, out var site))
        {
            BatchMappingSiteLabel.Text = "列映射：站点不存在";
            return;
        }

        BatchMappingSiteLabel.Text = $"列映射 · {site.Name}（{site.Code}）";
        var mapping = _mappingOverrides.TryGetValue(siteId, out var overridden)
            ? overridden
            : site.Mapping;
        LoadSiteMappingForm(mapping, true, refreshHeaders: false);

        if (_pageMode == ProcessPageMode.CallbackBatch)
            BatchMappingTabs.SelectedIndex = 1;
        else if (_pageMode == ProcessPageMode.PeriodBatch)
            BatchMappingTabs.SelectedIndex = 0;

        _ = RefreshActiveMappingHeadersAsync();
    }

    private void LoadSiteMappingForm(SiteMappingConfig mapping, bool batch, bool refreshHeaders = true)
    {
        if (batch)
        {
            BatchMapPeriodFields.LoadFrom(mapping.Period);
            BatchMapCallbackFields.LoadFrom(mapping.Callback);
            BatchMapUnclaimedField.LoadFrom(mapping.UnclaimedUserIdColumn);
        }
        else
        {
            MapPeriodFields.LoadFrom(mapping.Period);
            MapCallbackFields.LoadFrom(mapping.Callback);
            MapUnclaimedField.LoadFrom(mapping.UnclaimedUserIdColumn);
        }

        if (refreshHeaders)
            _ = RefreshActiveMappingHeadersAsync();
    }

    private SiteMappingConfig ReadSingleSiteMappingForm() => new()
    {
        Period = MapPeriodFields.ReadMapping(),
        Callback = MapCallbackFields.ReadMapping(),
        UnclaimedUserIdColumn = MapUnclaimedField.ReadColumn()
    };

    private SiteMappingConfig ReadBatchSiteMappingForm() => new()
    {
        Period = BatchMapPeriodFields.ReadMapping(),
        Callback = BatchMapCallbackFields.ReadMapping(),
        UnclaimedUserIdColumn = BatchMapUnclaimedField.ReadColumn()
    };

    private async Task RefreshActiveMappingHeadersAsync()
    {
        _headerRefreshCts?.Cancel();
        _headerRefreshCts?.Dispose();
        _headerRefreshCts = new CancellationTokenSource();
        var token = _headerRefreshCts.Token;

        try
        {
            await Task.Delay(150, token);

            if (_pageMode == ProcessPageMode.Single)
            {
                if (SingleMappingTabs.SelectedIndex == 2)
                {
                    await RefreshUnclaimedMappingHeadersAsync(_unclaimedFilePath, MapUnclaimedField, token);
                    return;
                }

                var fields = SingleMappingTabs.SelectedIndex == 1 ? MapCallbackFields : MapPeriodFields;
                await RefreshMemberMappingHeadersAsync(_memberFilePath, fields, token);
                return;
            }

            if (BatchMappingTabs.SelectedIndex == 2)
            {
                var unclaimedPath = ResolveBatchUnclaimedFilePath();
                await RefreshUnclaimedMappingHeadersAsync(unclaimedPath, BatchMapUnclaimedField, token);
                return;
            }

            var batchFields = BatchMappingTabs.SelectedIndex == 1 ? BatchMapCallbackFields : BatchMapPeriodFields;
            var memberPath = ResolveSelectedBatchMemberFilePath();
            await RefreshMemberMappingHeadersAsync(memberPath, batchFields, token);
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception ex)
        {
            Growl.Warning($"读取表头失败：{ex.Message}");
        }
    }

    private string? ResolveSelectedBatchMemberFilePath()
    {
        if (BatchTaskGrid.SelectedItem is BatchSiteTask task && !string.IsNullOrWhiteSpace(task.MemberFilePath))
            return task.MemberFilePath;

        return _batchTasks.FirstOrDefault(t => !string.IsNullOrWhiteSpace(t.MemberFilePath))?.MemberFilePath;
    }

    private string? ResolveBatchUnclaimedFilePath()
    {
        if (BatchTaskGrid.SelectedItem is BatchSiteTask task && !string.IsNullOrWhiteSpace(task.UnclaimedFilePath))
            return task.UnclaimedFilePath;

        return _batchTasks.FirstOrDefault(t => !string.IsNullOrWhiteSpace(t.UnclaimedFilePath))?.UnclaimedFilePath;
    }

    private async Task RefreshMemberMappingHeadersAsync(
        string? filePath,
        MemberMappingFields fields,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (string.IsNullOrWhiteSpace(filePath))
        {
            fields.SetHeaders(null);
            return;
        }

        var cacheKey = $"{filePath}|{fields.HeaderRow}";
        if (string.Equals(_cachedMemberHeaderKey, cacheKey, StringComparison.OrdinalIgnoreCase)
            && _cachedMemberHeaders is not null)
        {
            fields.SetHeaders(_cachedMemberHeaders);
            return;
        }

        var headers = await _excelService.PreviewHeadersAsync(filePath, fields.HeaderRow, cancellationToken);
        _cachedMemberHeaderKey = cacheKey;
        _cachedMemberHeaders = headers;
        fields.SetHeaders(headers);
    }

    private async Task RefreshUnclaimedMappingHeadersAsync(
        string? filePath,
        UnclaimedColumnField field,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (string.IsNullOrWhiteSpace(filePath))
        {
            field.SetHeaders(null);
            return;
        }

        if (string.Equals(_cachedUnclaimedHeaderKey, filePath, StringComparison.OrdinalIgnoreCase)
            && _cachedUnclaimedHeaders is not null)
        {
            field.SetHeaders(_cachedUnclaimedHeaders);
            return;
        }

        var headers = await _excelService.PreviewHeadersAsync(filePath, 0, cancellationToken);
        _cachedUnclaimedHeaderKey = filePath;
        _cachedUnclaimedHeaders = headers;
        field.SetHeaders(headers);
    }

    private async void SaveSingleMapping_Click(object sender, RoutedEventArgs e)
    {
        if (_singleMappingSiteId <= 0)
        {
            Growl.Warning("请先选择站点。");
            return;
        }

        try
        {
            var mapping = ReadSingleSiteMappingForm();
            if (!_siteDetailCache.TryGetValue(_singleMappingSiteId, out var model))
            {
                model = await _activityService.GetSiteAsync(_singleMappingSiteId);
                if (model is null)
                {
                    Growl.Error("站点不存在。");
                    return;
                }
            }

            model.Mapping = mapping;
            await _activityService.SaveSiteAsync(model);
            _siteDetailCache[_singleMappingSiteId] = model;
            _mappingOverrides.Remove(_singleMappingSiteId);
            Growl.Success("列映射已保存到站点。");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private async void SaveBatchMapping_Click(object sender, RoutedEventArgs e)
    {
        if (_batchMappingSiteId <= 0)
        {
            Growl.Warning("请先在队列中选择站点。");
            return;
        }

        try
        {
            var mapping = ReadBatchSiteMappingForm();
            if (!_siteDetailCache.TryGetValue(_batchMappingSiteId, out var model))
            {
                model = await _activityService.GetSiteAsync(_batchMappingSiteId);
                if (model is null)
                {
                    Growl.Error("站点不存在。");
                    return;
                }
            }

            model.Mapping = mapping;
            await _activityService.SaveSiteAsync(model);
            _siteDetailCache[_batchMappingSiteId] = model;
            _mappingOverrides.Remove(_batchMappingSiteId);
            Growl.Success("列映射已保存到站点。");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private void FilterUnclaimedCheck_Changed(object sender, RoutedEventArgs e)
    {
        UnclaimedPanel.Visibility = FilterUnclaimedCheck.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
        _ = RefreshActiveMappingHeadersAsync();
    }

    private void BatchFilterUnclaimedCheck_Changed(object sender, RoutedEventArgs e)
    {
        UpdateBatchUnclaimedColumnVisibility();
        RebuildBatchReadyCount();
        _ = RefreshActiveMappingHeadersAsync();
    }

    private void UpdateBatchUnclaimedColumnVisibility()
    {
        var show = BatchFilterUnclaimedCheck.IsChecked == true;
        BatchUnclaimedColumn.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
    }

    private void File_DragOver(object sender, DragEventArgs e)
    {
        e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }

    private void MemberFile_Drop(object sender, DragEventArgs e) => SetMemberFile(GetDroppedFile(e));

    private void UnclaimedFile_Drop(object sender, DragEventArgs e) => SetUnclaimedFile(GetDroppedFile(e));

    private static string? GetDroppedFile(DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DataFormats.FileDrop))
            return null;
        var files = (string[])e.Data.GetData(DataFormats.FileDrop)!;
        return files.Length > 0 ? files[0] : null;
    }

    private void SetMemberFile(string? path)
    {
        _memberFilePath = path;
        MemberFileHint.Text = string.IsNullOrWhiteSpace(path) ? "拖拽文件到此处，或点击右侧浏览..." : path;
        _ = RefreshActiveMappingHeadersAsync();
    }

    private void SetUnclaimedFile(string? path)
    {
        _unclaimedFilePath = path;
        UnclaimedFileHint.Text = string.IsNullOrWhiteSpace(path) ? "未领名单文件（拖拽或浏览）" : path;
        _ = RefreshActiveMappingHeadersAsync();
    }

    private void BrowseMemberFile_Click(object sender, RoutedEventArgs e) =>
        SetMemberFile(PickDataFile());

    private void BrowseUnclaimedFile_Click(object sender, RoutedEventArgs e) =>
        SetUnclaimedFile(PickDataFile());

    private static string? PickDataFile()
    {
        var dialog = new OpenFileDialog
        {
            Filter = "数据文件|*.xlsx;*.xls;*.xlsm;*.csv|所有文件|*.*",
            Title = "选择数据文件"
        };
        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    private async void StartProcess_Click(object sender, RoutedEventArgs e)
    {
        if (SiteCombo.SelectedItem is not SiteListItem site)
        {
            Growl.Warning("请选择站点。");
            return;
        }
        if (ActivityCombo.SelectedItem is not ActivityListItem activity)
        {
            Growl.Warning("请选择活动。");
            return;
        }
        if (string.IsNullOrWhiteSpace(_memberFilePath))
        {
            Growl.Warning("请先上传会员文件。");
            return;
        }
        if (FilterUnclaimedCheck.IsChecked == true && string.IsNullOrWhiteSpace(_unclaimedFilePath))
        {
            Growl.Warning("已勾选过滤未领，请上传未领名单。");
            return;
        }

        CommitSingleMappingForm();
        var mappingProfile = ResolveMappingProfile(activity);
        await RefreshSiteMappingCacheAsync([site.Id]);

        var request = new ProcessRequest
        {
            SiteId = site.Id,
            ActivityId = activity.Id,
            MemberFilePath = _memberFilePath,
            FilterUnclaimed = FilterUnclaimedCheck.IsChecked == true,
            UnclaimedFilePath = _unclaimedFilePath,
            IncludeProfitMember = IncludeProfitCheck.IsChecked,
            SaveToHistory = true,
            MappingProfile = mappingProfile,
            ColumnMappingOverride = ResolveProcessMappingOverride(site.Id, mappingProfile),
            UnclaimedUserIdColumnOverride = ResolveProcessUnclaimedOverride(site.Id)
        };

        _cts = new CancellationTokenSource();
        SetSingleProcessingState(true);
        ProcessProgressBar.IsIndeterminate = true;
        ProcessStatusText.Text = "正在处理...";

        try
        {
            var progress = new Progress<ProcessProgress>(p =>
            {
                ProcessStatusText.Text = p.Message ?? p.Phase;
                if (p.TotalRows > 0)
                {
                    ProcessProgressBar.IsIndeterminate = false;
                    ProcessProgressBar.Value = p.Percent;
                }
            });

            _result = await _processService.ProcessAsync(request, progress, _cts.Token);
            _detailPage = 0;
            _rewardPage = 0;
            _lossRewardPage = 0;
            _profitRewardPage = 0;
            _resultBindCaches.Clear();
            var bindGeneration = ++_singleBindGeneration;
            _ = Dispatcher.BeginInvoke(() =>
            {
                if (bindGeneration != _singleBindGeneration || !CanUpdateProcessUi())
                    return;

                BindSingleResults();
            }, DispatcherPriority.Background);
            Growl.Success(_result.UsesSplitRewards
                ? $"处理完成：亏损派奖 {_result.Summary.LossRewardCount} 人（{_result.Summary.LossTotalBonus:N2}），盈利派奖 {_result.Summary.ProfitRewardCount} 人（{_result.Summary.ProfitTotalBonus:N2}）"
                : $"处理完成：派奖 {_result.Summary.RewardCount} 人，总彩金 {_result.Summary.TotalBonus:N2}");
        }
        catch (OperationCanceledException)
        {
            Growl.Warning("处理已取消。");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
        finally
        {
            SetSingleProcessingState(false);
            ProcessProgressBar.IsIndeterminate = false;
            ProcessStatusText.Text = "就绪";
        }
    }

    private void CancelProcess_Click(object sender, RoutedEventArgs e) => _cts?.Cancel();

    private void SetSingleProcessingState(bool processing)
    {
        StartButton.IsEnabled = !processing;
        CancelButton.IsEnabled = processing;
    }

    private void BindSingleResults(bool forceRewardRefresh = false)
    {
        var split = _result?.UsesSplitRewards == true;
        ApplySingleResultTabVisibility(split);

        if (_result is null)
        {
            ClearSingleResultGrids();
            return;
        }

        if (string.IsNullOrEmpty(_result.ResultCacheKey))
            WarmDetailBindCache(_result.Details, "single");

        BindActiveSingleResultTab(forceRewardRefresh);
    }

    private void ClearSingleResultGrids()
    {
        FillPageItems(_detailPageItems, Array.Empty<ProcessDetailItem>());
        FillPageItems(_rewardPageItems, Array.Empty<RewardItem>());
        FillPageItems(_lossRewardPageItems, Array.Empty<RewardItem>());
        FillPageItems(_profitRewardPageItems, Array.Empty<RewardItem>());
        DetailPageText.Text = string.Empty;
        RewardPageText.Text = string.Empty;
        RewardSummaryText.Text = string.Empty;
        LossRewardPageText.Text = string.Empty;
        LossRewardSummaryText.Text = string.Empty;
        ProfitRewardPageText.Text = string.Empty;
        ProfitRewardSummaryText.Text = string.Empty;
    }

    private bool IsSingleDetailTabActive() =>
        SingleResultTabs.SelectedItem != SingleLossRewardTab
        && SingleResultTabs.SelectedItem != SingleProfitRewardTab
        && SingleResultTabs.SelectedItem != SingleMergedRewardTab;

    private void BindActiveSingleResultTab(bool forceRewardRefresh = false)
    {
        if (_result is null)
            return;

        if (IsSingleDetailTabActive())
        {
            var detail = BuildDetailPage(
                _result,
                ShowExcludedOnlyCheck.IsChecked == true,
                ref _detailPage,
                GetResultBindCache("single"));
            FillPageItems(_detailPageItems, detail.Page);
            DetailPageText.Text = detail.PageText;
            return;
        }

        BindActiveSingleRewardTab(forceRewardRefresh);
    }

    private void BindActiveSingleRewardTab(bool forceRewardRefresh = false)
    {
        if (_result is null)
            return;

        if (_result.UsesSplitRewards)
        {
            var activeTab = GetSingleActiveRewardTab();
            if (activeTab == ActiveRewardTab.Loss)
            {
                var loss = BuildRewardPage(_result, RewardStreamKind.Loss, ref _lossRewardPage);
                FillPageItems(_lossRewardPageItems, loss.Page, forceRewardRefresh);
                LossRewardPageText.Text = loss.PageText;
                LossRewardSummaryText.Text =
                    $"{_result.Summary.LossRewardCount} 人 / {_result.Summary.LossTotalBonus:N2}";
                return;
            }

            if (activeTab == ActiveRewardTab.Profit)
            {
                var profit = BuildRewardPage(_result, RewardStreamKind.Profit, ref _profitRewardPage);
                FillPageItems(_profitRewardPageItems, profit.Page, forceRewardRefresh);
                ProfitRewardPageText.Text = profit.PageText;
                ProfitRewardSummaryText.Text =
                    $"{_result.Summary.ProfitRewardCount} 人 / {_result.Summary.ProfitTotalBonus:N2}";
            }

            return;
        }

        if (GetSingleActiveRewardTab() != ActiveRewardTab.Merged)
            return;

        var reward = BuildRewardPage(_result, RewardStreamKind.Merged, ref _rewardPage);
        FillPageItems(_rewardPageItems, reward.Page, forceRewardRefresh);
        RewardPageText.Text = reward.PageText;
        RewardSummaryText.Text = $"总 {_result.Summary.RewardCount} 人 / 彩金 {_result.Summary.TotalBonus:N2}";
    }

    private void ApplySingleResultTabVisibility(bool split)
    {
        _suppressSingleResultTabSelection = true;
        try
        {
            SingleLossRewardTab.Visibility = split ? Visibility.Visible : Visibility.Collapsed;
            SingleProfitRewardTab.Visibility = split ? Visibility.Visible : Visibility.Collapsed;
            SingleMergedRewardTab.Visibility = split ? Visibility.Collapsed : Visibility.Visible;

            if (split)
            {
                if (SingleResultTabs.SelectedItem == SingleMergedRewardTab
                    || SingleResultTabs.SelectedItem is not TabItem)
                    SingleResultTabs.SelectedItem = SingleLossRewardTab;
            }
            else if (SingleResultTabs.SelectedItem == SingleLossRewardTab
                     || SingleResultTabs.SelectedItem == SingleProfitRewardTab)
            {
                SingleResultTabs.SelectedItem = SingleMergedRewardTab;
            }
        }
        finally
        {
            _suppressSingleResultTabSelection = false;
        }
    }

    private ActiveRewardTab GetSingleActiveRewardTab()
    {
        if (SingleResultTabs.SelectedItem == SingleLossRewardTab)
            return ActiveRewardTab.Loss;
        if (SingleResultTabs.SelectedItem == SingleProfitRewardTab)
            return ActiveRewardTab.Profit;
        if (SingleResultTabs.SelectedItem == SingleMergedRewardTab)
            return ActiveRewardTab.Merged;
        return ActiveRewardTab.None;
    }

    private ActiveRewardTab GetBatchActiveRewardTab()
    {
        if (BatchResultTabs.SelectedItem == BatchLossRewardTab)
            return ActiveRewardTab.Loss;
        if (BatchResultTabs.SelectedItem == BatchProfitRewardTab)
            return ActiveRewardTab.Profit;
        if (BatchResultTabs.SelectedItem == BatchMergedRewardTab)
            return ActiveRewardTab.Merged;
        return ActiveRewardTab.None;
    }

    private static IList<RewardItem>? GetRewardsForActiveTab(ProcessResult result, ActiveRewardTab activeTab)
    {
        if (activeTab == ActiveRewardTab.None)
            return null;

        if (result.UsesSplitRewards)
        {
            return activeTab switch
            {
                ActiveRewardTab.Loss => result.LossRewards,
                ActiveRewardTab.Profit => result.ProfitRewards,
                _ => null
            };
        }

        return activeTab == ActiveRewardTab.Merged ? result.Rewards : null;
    }

    private void SingleResultTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSingleResultTabSelection || _result is null)
            return;

        BindActiveSingleResultTab();
    }

    private BatchSiteTask? GetSelectedBatchTask()
    {
        if (BatchSiteResultTabs.SelectedItem is TabItem { Tag: BatchSiteTask tabTask })
            return tabTask;

        return _selectedBatchTask;
    }

    private ProcessResult? GetSelectedBatchResult(bool forceReload = false)
    {
        var task = GetSelectedBatchTask();
        if (task is null)
            return null;

        _selectedBatchTask = task;

        if (!forceReload
            && _cachedBatchSummaryTaskKey == task.Key
            && string.Equals(_cachedBatchSummary?.ResultCacheKey, task.ResultCacheKey, StringComparison.OrdinalIgnoreCase)
            && _cachedBatchSummary is not null)
            return _cachedBatchSummary;

        _cachedBatchSummary = task.ResolveResult(_resultRepository);
        _cachedBatchSummaryTaskKey = task.Key;
        return _cachedBatchSummary;
    }

    private void InvalidateBatchSummaryCache()
    {
        _cachedBatchSummary = null;
        _cachedBatchSummaryTaskKey = null;
    }

    private void BatchResultTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressBatchResultTabSelection)
            return;

        ScheduleBatchResultBind();
    }

    private bool IsBatchDetailTabActive() => BatchResultTabs.SelectedItem == BatchDetailTab;

    private void RefreshActiveBatchResultTab() => ScheduleBatchResultBind();

    private static void FillPageItems<T>(ObservableCollection<T> target, IReadOnlyList<T> items, bool forceRefresh = false)
    {
        if (items.Count == 0)
        {
            if (target.Count > 0)
                target.Clear();
            return;
        }

        if (!forceRefresh && target.Count == items.Count)
        {
            var unchanged = true;
            for (var i = 0; i < items.Count; i++)
            {
                if (!ReferenceEquals(target[i], items[i]))
                {
                    unchanged = false;
                    break;
                }
            }

            if (unchanged)
                return;
        }

        while (target.Count > items.Count)
            target.RemoveAt(target.Count - 1);

        var rebuildFrom = 0;
        var shared = Math.Min(target.Count, items.Count);
        for (var i = 0; i < shared; i++)
        {
            if (ReferenceEquals(target[i], items[i]))
                continue;

            rebuildFrom = i;
            break;
        }

        if (rebuildFrom == 0 && shared == items.Count && target.Count == items.Count)
        {
            target.Clear();
            for (var i = 0; i < items.Count; i++)
                target.Add(items[i]);
            return;
        }

        while (target.Count > rebuildFrom)
            target.RemoveAt(target.Count - 1);

        for (var i = rebuildFrom; i < items.Count; i++)
            target.Add(items[i]);
    }

    private static (List<ProcessDetailItem> Page, string PageText) BuildDetailPageSlice(
        IList<ProcessDetailItem>? allDetails,
        bool excludedOnly,
        ref int pageIndex,
        ResultBindCache? cache,
        int pageSize)
    {
        if (allDetails is null || allDetails.Count == 0)
            return ([], string.Empty);

        int filteredCount;
        if (!excludedOnly)
        {
            filteredCount = allDetails.Count;
        }
        else if (cache is not null)
        {
            EnsureExcludedIndices(allDetails, cache);
            filteredCount = cache.ExcludedCount;
        }
        else
        {
            filteredCount = 0;
            for (var i = 0; i < allDetails.Count; i++)
            {
                if (allDetails[i].IsExcluded)
                    filteredCount++;
            }
        }

        if (filteredCount == 0)
            return ([], "无数据");

        var totalPages = Math.Max(1, (int)Math.Ceiling(filteredCount / (double)pageSize));
        pageIndex = Math.Clamp(pageIndex, 0, totalPages - 1);
        var skip = pageIndex * pageSize;
        var page = new List<ProcessDetailItem>(Math.Min(pageSize, filteredCount - skip));

        if (!excludedOnly)
        {
            var start = skip;
            var end = Math.Min(start + pageSize, allDetails.Count);
            for (var i = start; i < end; i++)
                page.Add(allDetails[i]);
        }
        else if (cache?.ExcludedIndices is { Length: > 0 } indices)
        {
            var end = Math.Min(skip + pageSize, indices.Length);
            for (var i = skip; i < end; i++)
                page.Add(allDetails[indices[i]]);
        }
        else
        {
            var skipped = 0;
            foreach (var item in allDetails)
            {
                if (!item.IsExcluded)
                    continue;

                if (skipped < skip)
                {
                    skipped++;
                    continue;
                }

                page.Add(item);
                if (page.Count >= pageSize)
                    break;
            }
        }

        var pageText = FormatPageText(pageIndex + 1, totalPages, filteredCount, pageSize);
        return (page, pageText);
    }

    private static (List<RewardItem> Page, string PageText) BuildRewardPageSlice(
        IList<RewardItem>? rewards,
        ref int pageIndex,
        int pageSize)
    {
        if (rewards is null || rewards.Count == 0)
            return ([], string.Empty);

        var totalPages = Math.Max(1, (int)Math.Ceiling(rewards.Count / (double)pageSize));
        pageIndex = Math.Clamp(pageIndex, 0, totalPages - 1);
        var start = pageIndex * pageSize;
        var end = Math.Min(start + pageSize, rewards.Count);
        var page = new List<RewardItem>(end - start);
        for (var i = start; i < end; i++)
            page.Add(rewards[i]);

        var pageText = FormatPageText(pageIndex + 1, totalPages, rewards.Count, pageSize);
        return (page, pageText);
    }

    private static string FormatPageText(int pageNumber, int totalPages, int totalCount, int pageSize)
    {
        var text = $"第 {pageNumber} / {totalPages} 页，共 {totalCount} 条";
        return pageSize < PageSize ? $"{text}（{BatchPreviewHint}）" : text;
    }

    private (List<ProcessDetailItem> Page, string PageText) BuildDetailPage(
        ProcessResult result,
        bool excludedOnly,
        ref int pageIndex,
        ResultBindCache? cache,
        int pageSize = PageSize)
    {
        if (!string.IsNullOrEmpty(result.ResultCacheKey))
            return BuildDetailPageFromCache(result.ResultCacheKey, excludedOnly, ref pageIndex, pageSize);

        return BuildDetailPageSlice(result.Details, excludedOnly, ref pageIndex, cache, pageSize);
    }

    private (List<ProcessDetailItem> Page, string PageText) BuildDetailPageFromCache(
        string cacheKey,
        bool excludedOnly,
        ref int pageIndex,
        int pageSize)
    {
        var filteredCount = _resultRepository.CountDetails(cacheKey, excludedOnly);
        if (filteredCount == 0)
            return ([], excludedOnly ? "无数据" : string.Empty);

        var totalPages = Math.Max(1, (int)Math.Ceiling(filteredCount / (double)pageSize));
        pageIndex = Math.Clamp(pageIndex, 0, totalPages - 1);
        var skip = pageIndex * pageSize;
        var page = _resultRepository.ReadDetailPage(cacheKey, skip, pageSize, excludedOnly);
        var pageText = FormatPageText(pageIndex + 1, totalPages, filteredCount, pageSize);
        return (page, pageText);
    }

    private (List<RewardItem> Page, string PageText) BuildRewardPage(
        ProcessResult result,
        RewardStreamKind kind,
        ref int pageIndex,
        int pageSize = PageSize)
    {
        if (!string.IsNullOrEmpty(result.ResultCacheKey))
            return BuildRewardPageFromCache(result.ResultCacheKey, kind, ref pageIndex, pageSize);

        return BuildRewardPageSlice(GetRewardList(result, kind), ref pageIndex, pageSize);
    }

    private static IList<RewardItem>? GetRewardList(ProcessResult result, RewardStreamKind kind) => kind switch
    {
        RewardStreamKind.Loss => result.LossRewards,
        RewardStreamKind.Profit => result.ProfitRewards,
        _ => result.Rewards
    };

    private (List<RewardItem> Page, string PageText) BuildRewardPageFromCache(
        string cacheKey,
        RewardStreamKind kind,
        ref int pageIndex,
        int pageSize)
    {
        var total = _resultRepository.CountRewards(cacheKey, kind);
        if (total == 0)
            return ([], string.Empty);

        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)pageSize));
        pageIndex = Math.Clamp(pageIndex, 0, totalPages - 1);
        var skip = pageIndex * pageSize;
        var page = _resultRepository.ReadRewardPage(cacheKey, kind, skip, pageSize);
        var pageText = FormatPageText(pageIndex + 1, totalPages, total, pageSize);
        return (page, pageText);
    }

    private bool HasActiveTabRewards(ProcessResult result, ActiveRewardTab activeTab)
    {
        if (activeTab == ActiveRewardTab.None)
            return false;

        if (!string.IsNullOrEmpty(result.ResultCacheKey))
        {
            return activeTab switch
            {
                ActiveRewardTab.Loss =>
                    _resultRepository.CountRewards(result.ResultCacheKey, RewardStreamKind.Loss) > 0,
                ActiveRewardTab.Profit =>
                    _resultRepository.CountRewards(result.ResultCacheKey, RewardStreamKind.Profit) > 0,
                ActiveRewardTab.Merged =>
                    _resultRepository.CountRewards(result.ResultCacheKey, RewardStreamKind.Merged) > 0,
                _ => false
            };
        }

        var rewards = GetRewardsForActiveTab(result, activeTab);
        return rewards is { Count: > 0 };
    }

    private bool HasActiveTabRewards(BatchSiteTask task, ActiveRewardTab activeTab)
    {
        if (activeTab == ActiveRewardTab.None)
            return false;

        if (!string.IsNullOrEmpty(task.ResultCacheKey))
        {
            return activeTab switch
            {
                ActiveRewardTab.Loss =>
                    _resultRepository.CountRewards(task.ResultCacheKey, RewardStreamKind.Loss) > 0,
                ActiveRewardTab.Profit =>
                    _resultRepository.CountRewards(task.ResultCacheKey, RewardStreamKind.Profit) > 0,
                ActiveRewardTab.Merged =>
                    _resultRepository.CountRewards(task.ResultCacheKey, RewardStreamKind.Merged) > 0,
                _ => false
            };
        }

        return task.Result is not null && HasActiveTabRewards(task.Result, activeTab);
    }

    private IEnumerable<RewardItem> GetActiveTabRewardStream(
        string? cacheKey,
        ProcessResult? result,
        ActiveRewardTab activeTab)
    {
        if (!string.IsNullOrEmpty(cacheKey))
        {
            var kind = activeTab switch
            {
                ActiveRewardTab.Loss => RewardStreamKind.Loss,
                ActiveRewardTab.Profit => RewardStreamKind.Profit,
                ActiveRewardTab.Merged => RewardStreamKind.Merged,
                _ => (RewardStreamKind?)null
            };

            if (kind is null)
                return Array.Empty<RewardItem>();

            return _resultRepository.StreamRewards(cacheKey, kind.Value);
        }

        if (result is null)
            return Array.Empty<RewardItem>();

        return GetRewardsForActiveTab(result, activeTab) ?? Array.Empty<RewardItem>();
    }

    private void ResultFilter_Changed(object sender, RoutedEventArgs e)
    {
        _detailPage = 0;
        BindActiveSingleResultTab();
    }

    private void DetailPrevPage_Click(object sender, RoutedEventArgs e)
    {
        _detailPage--;
        BindActiveSingleResultTab();
    }

    private void DetailNextPage_Click(object sender, RoutedEventArgs e)
    {
        _detailPage++;
        BindActiveSingleResultTab();
    }

    private void RewardPrevPage_Click(object sender, RoutedEventArgs e)
    {
        _rewardPage--;
        BindActiveSingleRewardTab();
    }

    private void RewardNextPage_Click(object sender, RoutedEventArgs e)
    {
        _rewardPage++;
        BindActiveSingleRewardTab();
    }

    private void LossRewardPrevPage_Click(object sender, RoutedEventArgs e)
    {
        _lossRewardPage--;
        BindActiveSingleRewardTab();
    }

    private void LossRewardNextPage_Click(object sender, RoutedEventArgs e)
    {
        _lossRewardPage++;
        BindActiveSingleRewardTab();
    }

    private void ProfitRewardPrevPage_Click(object sender, RoutedEventArgs e)
    {
        _profitRewardPage--;
        BindActiveSingleRewardTab();
    }

    private void ProfitRewardNextPage_Click(object sender, RoutedEventArgs e)
    {
        _profitRewardPage++;
        BindActiveSingleRewardTab();
    }

    private async void ExportExcel_Click(object sender, RoutedEventArgs e)
    {
        if (_result is null) { Growl.Warning("暂无处理结果。"); return; }
        var export = await _exportService.ExportExcelAsync(_result);
        if (export.Success) Growl.Success($"已导出：{export.FilePath}");
        else Growl.Error(export.Message ?? "导出失败");
    }

    private async void ExportJson_Click(object sender, RoutedEventArgs e)
    {
        if (_result is null) { Growl.Warning("暂无处理结果。"); return; }
        var export = await _exportService.ExportJsonAsync(_result);
        if (export.Success) Growl.Success($"已导出：{export.FilePath}");
        else Growl.Error(export.Message ?? "导出失败");
    }

    private async void CopyRewards_Click(object sender, RoutedEventArgs e)
    {
        if (_result is null)
        {
            Growl.Warning("暂无派奖数据。");
            return;
        }

        var activeTab = GetSingleActiveRewardTab();
        if (!HasActiveTabRewards(_result, activeTab))
        {
            Growl.Warning(activeTab == ActiveRewardTab.None
                ? "请先切换到派奖 Tab。"
                : "当前 Tab 暂无派奖数据。");
            return;
        }

        try
        {
            await _exportService.CopyRewardsToClipboardAsync(
                GetActiveTabRewardStream(_result.ResultCacheKey, _result, activeTab));
            Growl.Success("派奖表已复制到剪贴板。");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private static bool HasRewardData(ProcessResult result) =>
        result.UsesSplitRewards
            ? result.Summary.LossRewardCount > 0 || result.Summary.ProfitRewardCount > 0
            : result.Summary.RewardCount > 0;

    // =========================================================================
    // 批量站点
    // =========================================================================

    private void AddBatchTask_Click(object sender, RoutedEventArgs e)
    {
        var task = new BatchSiteTask();
        _batchTasks.Add(task);
        BatchTaskGrid.SelectedItem = task;
        BatchTaskGrid.ScrollIntoView(task);
        SyncBatchRowSiteComboFromSelection();
        ApplyBatchReadyButtonText();
    }

    private void RemoveBatchTask_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: string key })
            return;

        var task = _batchTasks.FirstOrDefault(t => t.Key == key);
        if (task is null)
            return;

        var wasReady = IsBatchTaskReady(task);
        if (task.SiteId > 0)
            _batchAssignedSiteIds.Remove(task.SiteId);

        _batchTasks.Remove(task);

        if (wasReady)
            _batchReadyCount = Math.Max(0, _batchReadyCount - 1);

        if (string.Equals(_lastLoadedBatchMappingTaskKey, task.Key, StringComparison.Ordinal))
            _lastLoadedBatchMappingTaskKey = null;

        ApplyBatchReadyButtonText();
        SyncBatchRowSiteComboFromSelection();
    }

    private void SyncBatchRowSiteComboFromSelection()
    {
        if (BatchTaskGrid.SelectedItem is not BatchSiteTask task)
        {
            BatchRowSiteCombo.IsEnabled = false;
            _suppressBatchSiteSelection = true;
            try
            {
                BatchRowSiteCombo.SelectedIndex = -1;
            }
            finally
            {
                _suppressBatchSiteSelection = false;
            }

            return;
        }

        BatchRowSiteCombo.IsEnabled = true;
        _suppressBatchSiteSelection = true;
        try
        {
            BatchRowSiteCombo.SelectedValue = task.SiteId > 0 ? task.SiteId : null;
        }
        finally
        {
            _suppressBatchSiteSelection = false;
        }
    }

    private void BatchRowSiteCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressBatchSiteSelection || e.AddedItems.Count == 0)
            return;

        if (BatchTaskGrid.SelectedItem is not BatchSiteTask task)
            return;

        if (BatchRowSiteCombo.SelectedValue is not int siteId || siteId <= 0)
        {
            var wasReady = IsBatchTaskReady(task);
            UnassignBatchTaskSite(task);
            NotifyBatchTaskReadinessChanged(wasReady, task);
            ScheduleBatchMappingLoad();
            return;
        }

        var wasReadyBefore = IsBatchTaskReady(task);
        if (!TryAssignBatchTaskSite(task, siteId))
        {
            _suppressBatchSiteSelection = true;
            try
            {
                BatchRowSiteCombo.SelectedValue = task.SiteId > 0 ? task.SiteId : null;
            }
            finally
            {
                _suppressBatchSiteSelection = false;
            }

            return;
        }

        NotifyBatchTaskReadinessChanged(wasReadyBefore, task);
        _lastLoadedBatchMappingTaskKey = null;
        ScheduleBatchMappingLoad();
    }

    private void UnassignBatchTaskSite(BatchSiteTask task)
    {
        if (task.SiteId > 0)
            _batchAssignedSiteIds.Remove(task.SiteId);

        task.SiteName = string.Empty;
        task.SiteCode = string.Empty;
        task.SiteId = 0;
    }

    private void ScheduleBatchMappingLoad()
    {
        _batchMappingLoadCts?.Cancel();
        _batchMappingLoadCts?.Dispose();
        _batchMappingLoadCts = new CancellationTokenSource();
        var token = _batchMappingLoadCts.Token;

        _ = Task.Run(async () =>
        {
            try
            {
                await Task.Delay(200, token).ConfigureAwait(false);
                await Dispatcher.InvokeAsync(() =>
                {
                    if (token.IsCancellationRequested)
                        return;

                    if (BatchTaskGrid.SelectedItem is not BatchSiteTask task || task.SiteId <= 0)
                        return;

                    if (string.Equals(task.Key, _lastLoadedBatchMappingTaskKey, StringComparison.Ordinal)
                        && task.SiteId == _batchMappingSiteId)
                        return;

                    LoadBatchMappingForm(task.SiteId);
                    _lastLoadedBatchMappingTaskKey = task.Key;
                }, DispatcherPriority.Background);
            }
            catch (OperationCanceledException)
            {
            }
        });
    }

    private bool IsBatchTaskReady(BatchSiteTask task) =>
        task.SiteId > 0
        && !string.IsNullOrWhiteSpace(task.MemberFilePath)
        && (BatchFilterUnclaimedCheck.IsChecked != true || !string.IsNullOrWhiteSpace(task.UnclaimedFilePath));

    private void NotifyBatchTaskReadinessChanged(bool wasReady, BatchSiteTask task)
    {
        var isReady = IsBatchTaskReady(task);
        if (wasReady == isReady)
            return;

        _batchReadyCount += isReady ? 1 : -1;
        if (_batchReadyCount < 0)
            _batchReadyCount = 0;

        ApplyBatchReadyButtonText();
    }

    private void RebuildBatchAssignedSites()
    {
        _batchAssignedSiteIds.Clear();
        foreach (var task in _batchTasks)
        {
            if (task.SiteId > 0)
                _batchAssignedSiteIds.Add(task.SiteId);
        }
    }

    private void RebuildBatchReadyCount()
    {
        _batchReadyCount = 0;
        foreach (var task in _batchTasks)
        {
            if (IsBatchTaskReady(task))
                _batchReadyCount++;
        }

        ApplyBatchReadyButtonText();
    }

    private void ApplyBatchReadyButtonText() =>
        BatchStartButton.Content = $"批量计算彩金（{_batchReadyCount} 个站点）";

    private void UpdateBatchReadyButton() => RebuildBatchReadyCount();

    private int GetBatchReadyCount() => _batchReadyCount;

    private bool TryAssignBatchTaskSite(BatchSiteTask task, int siteId)
    {
        if (siteId <= 0)
        {
            UnassignBatchTaskSite(task);
            return true;
        }

        if (_batchAssignedSiteIds.Contains(siteId) && task.SiteId != siteId)
        {
            Growl.Warning("该站点已在队列中，请选择其他站点。");
            return false;
        }

        if (task.SiteId > 0 && task.SiteId != siteId)
            _batchAssignedSiteIds.Remove(task.SiteId);

        if (_siteDetailCache.TryGetValue(siteId, out var site))
        {
            task.SiteName = site.Name;
            task.SiteCode = site.Code;
        }
        else
        {
            var listItem = _allSites.FirstOrDefault(s => s.Id == siteId);
            if (listItem is not null)
            {
                task.SiteName = listItem.Name;
                task.SiteCode = listItem.Code;
            }
        }

        task.SiteId = siteId;
        _batchAssignedSiteIds.Add(siteId);
        return true;
    }

    private void BatchBrowseMember_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: string key })
            return;

        var task = _batchTasks.FirstOrDefault(t => t.Key == key);
        if (task is null)
            return;

        var path = PickDataFile();
        if (path is null)
            return;

        var wasReady = IsBatchTaskReady(task);
        task.MemberFilePath = path;
        _cachedMemberHeaderKey = null;
        _cachedMemberHeaders = null;
        NotifyBatchTaskReadinessChanged(wasReady, task);
        if (BatchTaskGrid.SelectedItem == task)
            _ = RefreshActiveMappingHeadersAsync();
    }

    private void BatchBrowseUnclaimed_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: string key })
            return;

        var task = _batchTasks.FirstOrDefault(t => t.Key == key);
        if (task is null)
            return;

        var path = PickDataFile();
        if (path is null)
            return;

        var wasReady = IsBatchTaskReady(task);
        task.UnclaimedFilePath = path;
        _cachedUnclaimedHeaderKey = null;
        _cachedUnclaimedHeaders = null;
        NotifyBatchTaskReadinessChanged(wasReady, task);
        if (BatchTaskGrid.SelectedItem == task)
            _ = RefreshActiveMappingHeadersAsync();
    }

    private async void BatchStart_Click(object sender, RoutedEventArgs e)
    {
        if (_batchActivityId <= 0)
        {
            Growl.Warning("活动未加载，请检查活动管理中是否已创建对应活动。");
            return;
        }

        if (GetBatchReadyCount() == 0)
        {
            Growl.Warning("请至少添加一行有效站点任务（站点 + 会员文件）。");
            return;
        }

        CommitBatchMappingForm();

        var request = new BatchProcessRequest
        {
            ActivityId = _batchActivityId,
            FilterUnclaimed = BatchFilterUnclaimedCheck.IsChecked == true,
            IncludeProfitMember = BatchIncludeProfitCheck.IsChecked,
            WageringMultiplier = (decimal)BatchRewardWageringBox.Value,
            AppRemark = BatchRewardAppRemarkBox.Text.Trim(),
            BackendRemark = BatchRewardBackendRemarkBox.Text.Trim(),
            SaveToHistory = true,
            Tasks = _batchTasks.ToList()
        };

        var taskSiteIds = request.Tasks.Where(t => t.SiteId > 0).Select(t => t.SiteId);
        await RefreshSiteMappingCacheAsync(taskSiteIds);

        var profile = GetBatchMappingProfile();
        foreach (var task in request.Tasks)
        {
            task.BeginBatchUpdate();
            if (task.SiteId > 0)
            {
                task.MappingProfile = profile;
                task.ColumnMappingOverride = ResolveProcessMappingOverride(task.SiteId, profile);
                task.UnclaimedUserIdColumnOverride = ResolveProcessUnclaimedOverride(task.SiteId);
            }
        }

        _batchCts = new CancellationTokenSource();
        SetBatchProcessingState(true);
        SetBatchResultExpanded(false, showToggle: false);
        BatchProgressBar.IsIndeterminate = false;
        BatchProgressBar.Value = 0;
        BatchStatusText.Text = "正在批量处理...";

        try
        {
            var batchProgress = new Progress<BatchProcessProgress>(p =>
            {
                BatchStatusText.Text = p.Message ?? p.Phase;
                BatchProgressBar.Value = p.Percent;
            });

            var siteProgress = new Progress<ProcessProgress>(p =>
            {
                if (string.IsNullOrEmpty(p.Message))
                    return;

                BatchStatusText.Text = p.Message;
            });

            _batchResult = await _processService.ProcessBatchAsync(
                request,
                batchProgress,
                siteProgress,
                _batchCts.Token);

            _resultBindCaches.Clear();
            InvalidateBatchSummaryCache();
            var buildGeneration = _batchBindGeneration;
            _ = Dispatcher.BeginInvoke(() =>
            {
                if (buildGeneration != _batchBindGeneration || !CanUpdateProcessUi())
                    return;

                BuildBatchResultTabs();
            }, DispatcherPriority.Background);
            Growl.Success(
                $"批量完成：成功 {_batchResult.SuccessCount}，失败 {_batchResult.FailedCount}，" +
                $"总彩金 {_batchResult.TotalBonusAllSites:N2}");
        }
        catch (OperationCanceledException)
        {
            Growl.Warning("批量处理已取消。");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
        finally
        {
            foreach (var task in _batchTasks)
                task.EndBatchUpdate();

            SetBatchProcessingState(false);
            BatchStatusText.Text = "就绪";
        }
    }

    private void ToggleBatchResult_Click(object sender, RoutedEventArgs e)
    {
        var expanded = BatchResultPanel.Visibility == Visibility.Visible;
        SetBatchResultExpanded(!expanded);

        if (!expanded
            && BatchSiteResultTabs.Items.Count > 0
            && BatchSiteResultTabs.SelectedIndex < 0)
        {
            BatchSiteResultTabs.SelectedIndex = 0;
        }

        if (!expanded)
        {
            _ = Dispatcher.BeginInvoke(ScheduleBatchResultBind, DispatcherPriority.Loaded);
        }
    }

    private void SetBatchResultExpanded(bool expanded, bool showToggle = true)
    {
        ToggleBatchResultButton.Visibility = showToggle ? Visibility.Visible : Visibility.Collapsed;
        BatchResultPanel.Visibility = expanded ? Visibility.Visible : Visibility.Collapsed;
        ToggleBatchResultButton.Content = expanded
            ? "▲ 收起批量处理结果"
            : "▼ 查看批量处理结果";

        if (!expanded)
            return;

        Dispatcher.BeginInvoke(() => BatchResultPanel.BringIntoView(), DispatcherPriority.Loaded);
    }

    private void BatchCancel_Click(object sender, RoutedEventArgs e) => _batchCts?.Cancel();

    private void SetBatchProcessingState(bool processing)
    {
        AddBatchTaskButton.IsEnabled = !processing;
        BatchStartButton.IsEnabled = !processing;
        BatchCancelButton.IsEnabled = processing;
        BatchExportAllButton.IsEnabled = !processing && _batchResult?.SuccessCount > 0;
        if (processing)
            BatchCopyRewardsButton.IsEnabled = false;
        else
            UpdateBatchCopyButtonState();
    }

    private void BuildBatchResultTabs()
    {
        if (_batchResult is null)
            return;

        _suppressBatchTabSelection = true;
        try
        {
            BatchSiteResultTabs.Items.Clear();
            foreach (var task in _batchResult.Tasks)
            {
                var header = task.Status == BatchTaskStatus.Success
                    ? task.SiteName
                    : $"{task.SiteName} ({task.StatusText})";

                BatchSiteResultTabs.Items.Add(new TabItem
                {
                    Header = header,
                    Tag = task
                });
            }

            if (BatchSiteResultTabs.Items.Count > 0)
            {
                BatchSiteResultTabs.SelectedIndex = 0;
                _selectedBatchTask = _batchResult.Tasks[0];
                SetBatchResultExpanded(false, showToggle: true);
            }
        }
        finally
        {
            _suppressBatchTabSelection = false;
        }

        BatchExportAllButton.IsEnabled = _batchResult.SuccessCount > 0;
        UpdateBatchCopyButtonState();
    }

    private void BatchSiteResultTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressBatchTabSelection)
            return;

        if (BatchSiteResultTabs.SelectedItem is not TabItem { Tag: BatchSiteTask task })
            return;

        if (BatchResultPanel.Visibility != Visibility.Visible)
        {
            _selectedBatchTask = task;
            InvalidateBatchSummaryCache();
            return;
        }

        _selectedBatchTask = task;
        InvalidateBatchSummaryCache();
        _batchDetailPage = 0;
        _batchRewardPage = 0;
        _batchLossRewardPage = 0;
        _batchProfitRewardPage = 0;
        ScheduleBatchResultBind();
    }

    private sealed class BatchPageBindResult
    {
        public List<ProcessDetailItem>? DetailPage;
        public string DetailPageText = string.Empty;
        public List<RewardItem>? RewardPage;
        public string RewardPageText = string.Empty;
        public string RewardSummaryText = string.Empty;
        public bool IsDetailTab;
        public ActiveRewardTab RewardTab;
        public int DetailPageIndex;
        public int RewardPageIndex;
        public int LossRewardPageIndex;
        public int ProfitRewardPageIndex;
    }

    private void ScheduleBatchResultBind()
    {
        if (_selectedBatchTask is null
            || BatchResultPanel.Visibility != Visibility.Visible
            || !CanUpdateProcessUi())
            return;

        var generation = ++_batchBindGeneration;
        var task = _selectedBatchTask;

        if (task.Status == BatchTaskStatus.Failed)
        {
            ApplyBatchFailedUi(task);
            UpdateBatchCopyButtonState();
            return;
        }

        if (!task.HasOutcome)
        {
            ApplyBatchEmptyUi();
            UpdateBatchCopyButtonState();
            return;
        }

        var result = GetSelectedBatchResult();
        if (result is null)
        {
            ApplyBatchMissingCacheUi(task);
            UpdateBatchCopyButtonState();
            return;
        }

        ApplyBatchSummaryUi(result);

        var excludedOnly = BatchShowExcludedOnlyCheck.IsChecked == true;
        var isDetailTab = IsBatchDetailTabActive();
        var activeRewardTab = GetBatchActiveRewardTab();
        var detailPage = _batchDetailPage;
        var rewardPage = _batchRewardPage;
        var lossPage = _batchLossRewardPage;
        var profitPage = _batchProfitRewardPage;

        _ = Task.Run(() =>
        {
            if (generation != _batchBindGeneration)
                return null!;

            var bind = new BatchPageBindResult
            {
                IsDetailTab = isDetailTab,
                RewardTab = activeRewardTab
            };

            if (isDetailTab)
            {
                var pageIndex = detailPage;
                var slice = BuildDetailPage(result, excludedOnly, ref pageIndex, cache: null, BatchPageSize);
                bind.DetailPage = slice.Page;
                bind.DetailPageText = slice.PageText;
                bind.DetailPageIndex = pageIndex;
            }
            else if (result.UsesSplitRewards)
            {
                if (activeRewardTab == ActiveRewardTab.Loss)
                {
                    var pageIndex = lossPage;
                    var slice = BuildRewardPage(result, RewardStreamKind.Loss, ref pageIndex, BatchPageSize);
                    bind.RewardPage = slice.Page;
                    bind.RewardPageText = slice.PageText;
                    bind.RewardSummaryText =
                        $"{result.Summary.LossRewardCount} 人 / {result.Summary.LossTotalBonus:N2}";
                    bind.LossRewardPageIndex = pageIndex;
                }
                else if (activeRewardTab == ActiveRewardTab.Profit)
                {
                    var pageIndex = profitPage;
                    var slice = BuildRewardPage(result, RewardStreamKind.Profit, ref pageIndex, BatchPageSize);
                    bind.RewardPage = slice.Page;
                    bind.RewardPageText = slice.PageText;
                    bind.RewardSummaryText =
                        $"{result.Summary.ProfitRewardCount} 人 / {result.Summary.ProfitTotalBonus:N2}";
                    bind.ProfitRewardPageIndex = pageIndex;
                }
            }
            else if (activeRewardTab == ActiveRewardTab.Merged)
            {
                var pageIndex = rewardPage;
                var slice = BuildRewardPage(result, RewardStreamKind.Merged, ref pageIndex, BatchPageSize);
                bind.RewardPage = slice.Page;
                bind.RewardPageText = slice.PageText;
                bind.RewardSummaryText =
                    $"总 {result.Summary.RewardCount} 人 / 彩金 {result.Summary.TotalBonus:N2}";
                bind.RewardPageIndex = pageIndex;
            }

            return bind;
        }).ContinueWith(t =>
        {
            if (t.IsFaulted)
            {
                Dispatcher.BeginInvoke(() =>
                {
                    if (generation != _batchBindGeneration || !CanUpdateProcessUi())
                        return;

                    Growl.Error(t.Exception?.GetBaseException().Message ?? "加载批量结果失败。");
                });
                return;
            }

            Dispatcher.BeginInvoke(() =>
            {
                if (generation != _batchBindGeneration || !CanUpdateProcessUi())
                    return;

                if (t.Result is null)
                    return;

                ApplyBatchPageUi(t.Result);
                UpdateBatchCopyButtonState();
            }, DispatcherPriority.Background);
        }, TaskScheduler.Default);
    }

    private void ApplyBatchFailedUi(BatchSiteTask task)
    {
        BatchStatTotalText.Text = "-";
        BatchStatFilteredText.Text = "-";
        BatchStatRewardText.Text = "-";
        BatchStatLossRewardText.Text = "-";
        BatchStatProfitRewardText.Text = "-";
        BatchStatBonusText.Text = "-";
        ClearBatchRewardGrids();
        BatchDetailPageText.Text = task.ErrorMessage ?? "处理失败";
        ApplyBatchResultTabVisibility(false);
    }

    private void ApplyBatchEmptyUi()
    {
        ResetBatchStatCards();
        ClearBatchRewardGrids();
        ApplyBatchResultTabVisibility(false);
    }

    private void ApplyBatchMissingCacheUi(BatchSiteTask task)
    {
        ResetBatchStatCards();
        ClearBatchRewardGrids();
        ApplyBatchResultTabVisibility(false);
        BatchDetailPageText.Text = $"{task.SiteName} 的结果缓存不可用，请重新处理。";
    }

    private void ApplyBatchSummaryUi(ProcessResult result)
    {
        BatchStatTotalText.Text = result.Summary.TotalCount.ToString();
        BatchStatFilteredText.Text = result.Summary.FilteredCount.ToString();
        BatchStatBonusText.Text = result.Summary.TotalBonus.ToString("N2");
        ApplyBatchStatCards(result);
        ApplyBatchResultTabVisibility(result.UsesSplitRewards);
    }

    private void ApplyBatchPageUi(BatchPageBindResult bind)
    {
        if (bind.IsDetailTab)
        {
            _batchDetailPage = bind.DetailPageIndex;
            FillPageItems(_batchDetailPageItems, bind.DetailPage ?? []);
            BatchDetailPageText.Text = bind.DetailPageText;
            return;
        }

        if (bind.RewardTab == ActiveRewardTab.Loss)
            _batchLossRewardPage = bind.LossRewardPageIndex;
        else if (bind.RewardTab == ActiveRewardTab.Profit)
            _batchProfitRewardPage = bind.ProfitRewardPageIndex;
        else if (bind.RewardTab == ActiveRewardTab.Merged)
            _batchRewardPage = bind.RewardPageIndex;

        if (bind.RewardTab == ActiveRewardTab.Loss)
        {
            FillPageItems(_batchLossRewardPageItems, bind.RewardPage ?? []);
            BatchLossRewardPageText.Text = bind.RewardPageText;
            BatchLossRewardSummaryText.Text = bind.RewardSummaryText;
            return;
        }

        if (bind.RewardTab == ActiveRewardTab.Profit)
        {
            FillPageItems(_batchProfitRewardPageItems, bind.RewardPage ?? []);
            BatchProfitRewardPageText.Text = bind.RewardPageText;
            BatchProfitRewardSummaryText.Text = bind.RewardSummaryText;
            return;
        }

        if (bind.RewardTab == ActiveRewardTab.Merged)
        {
            FillPageItems(_batchRewardPageItems, bind.RewardPage ?? []);
            BatchRewardPageText.Text = bind.RewardPageText;
            BatchRewardSummaryText.Text = bind.RewardSummaryText;
        }
    }

    private void UpdateBatchCopyButtonState()
    {
        if (GetSelectedBatchTask() is not { HasOutcome: true } task
            || task.Status != BatchTaskStatus.Success)
        {
            BatchCopyRewardsButton.IsEnabled = false;
            return;
        }

        BatchCopyRewardsButton.IsEnabled = HasActiveTabRewards(task, GetBatchActiveRewardTab());
    }

    private void ResetBatchStatCards()
    {
        BatchStatTotalText.Text = "0";
        BatchStatFilteredText.Text = "0";
        BatchStatRewardText.Text = "0";
        BatchStatLossRewardText.Text = "0";
        BatchStatProfitRewardText.Text = "0";
        BatchStatBonusText.Text = "0";
        BatchStatRewardCard.Visibility = Visibility.Visible;
        BatchStatLossCard.Visibility = Visibility.Collapsed;
        BatchStatProfitCard.Visibility = Visibility.Collapsed;
    }

    private void ApplyBatchStatCards(ProcessResult result)
    {
        var split = result.UsesSplitRewards;
        BatchStatRewardCard.Visibility = split ? Visibility.Collapsed : Visibility.Visible;
        BatchStatLossCard.Visibility = split ? Visibility.Visible : Visibility.Collapsed;
        BatchStatProfitCard.Visibility = split ? Visibility.Visible : Visibility.Collapsed;

        if (split)
        {
            BatchStatLossRewardText.Text = result.Summary.LossRewardCount.ToString();
            BatchStatProfitRewardText.Text = result.Summary.ProfitRewardCount.ToString();
            BatchStatRewardText.Text = "0";
            return;
        }

        BatchStatRewardText.Text = result.Summary.RewardCount.ToString();
        BatchStatLossRewardText.Text = "0";
        BatchStatProfitRewardText.Text = "0";
    }

    private void ClearBatchRewardGrids()
    {
        _batchRewardPageItems.Clear();
        _batchLossRewardPageItems.Clear();
        _batchProfitRewardPageItems.Clear();
        _batchDetailPageItems.Clear();
        BatchRewardPageText.Text = string.Empty;
        BatchRewardSummaryText.Text = string.Empty;
        BatchLossRewardPageText.Text = string.Empty;
        BatchLossRewardSummaryText.Text = string.Empty;
        BatchProfitRewardPageText.Text = string.Empty;
        BatchProfitRewardSummaryText.Text = string.Empty;
        BatchDetailPageText.Text = string.Empty;
        ApplyBatchResultTabVisibility(false);
    }

    private void ApplyBatchResultTabVisibility(bool split)
    {
        _suppressBatchResultTabSelection = true;
        try
        {
            BatchLossRewardTab.Visibility = split ? Visibility.Visible : Visibility.Collapsed;
            BatchProfitRewardTab.Visibility = split ? Visibility.Visible : Visibility.Collapsed;
            BatchMergedRewardTab.Visibility = split ? Visibility.Collapsed : Visibility.Visible;

            if (split)
            {
                if (BatchResultTabs.SelectedItem == BatchMergedRewardTab
                    || BatchResultTabs.SelectedItem is not TabItem)
                    BatchResultTabs.SelectedItem = BatchLossRewardTab;
            }
            else if (BatchResultTabs.SelectedItem == BatchLossRewardTab
                     || BatchResultTabs.SelectedItem == BatchProfitRewardTab)
            {
                BatchResultTabs.SelectedItem = BatchMergedRewardTab;
            }
        }
        finally
        {
            _suppressBatchResultTabSelection = false;
        }
    }

    private void BatchResultFilter_Changed(object sender, RoutedEventArgs e)
    {
        if (!IsLoaded)
            return;

        _batchDetailPage = 0;
        ScheduleBatchResultBind();
    }

    private void BatchDetailPrevPage_Click(object sender, RoutedEventArgs e)
    {
        _batchDetailPage--;
        RefreshActiveBatchResultTab();
    }

    private void BatchDetailNextPage_Click(object sender, RoutedEventArgs e)
    {
        _batchDetailPage++;
        RefreshActiveBatchResultTab();
    }

    private void BatchRewardPrevPage_Click(object sender, RoutedEventArgs e)
    {
        _batchRewardPage--;
        RefreshActiveBatchResultTab();
    }

    private void BatchRewardNextPage_Click(object sender, RoutedEventArgs e)
    {
        _batchRewardPage++;
        RefreshActiveBatchResultTab();
    }

    private void BatchLossRewardPrevPage_Click(object sender, RoutedEventArgs e)
    {
        _batchLossRewardPage--;
        RefreshActiveBatchResultTab();
    }

    private void BatchLossRewardNextPage_Click(object sender, RoutedEventArgs e)
    {
        _batchLossRewardPage++;
        RefreshActiveBatchResultTab();
    }

    private void BatchProfitRewardPrevPage_Click(object sender, RoutedEventArgs e)
    {
        _batchProfitRewardPage--;
        RefreshActiveBatchResultTab();
    }

    private void BatchProfitRewardNextPage_Click(object sender, RoutedEventArgs e)
    {
        _batchProfitRewardPage++;
        RefreshActiveBatchResultTab();
    }

    private async void BatchExportSite_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedBatchTask?.HasOutcome != true)
        {
            Growl.Warning("当前站点无可导出结果。");
            return;
        }

        if (GetSelectedBatchResult() is not ProcessResult result)
        {
            Growl.Warning("当前站点结果缓存不可用。");
            return;
        }

        var export = await _exportService.ExportExcelAsync(result);
        if (export.Success) Growl.Success($"已导出：{export.FilePath}");
        else Growl.Error(export.Message ?? "导出失败");
    }

    private async void BatchCopyRewards_Click(object sender, RoutedEventArgs e)
    {
        var task = GetSelectedBatchTask();
        if (task is not { HasOutcome: true } || task.Status != BatchTaskStatus.Success)
        {
            Growl.Warning("当前站点暂无派奖数据。");
            return;
        }

        var activeTab = GetBatchActiveRewardTab();
        if (!HasActiveTabRewards(task, activeTab))
        {
            Growl.Warning(activeTab == ActiveRewardTab.None
                ? "请先切换到派奖 Tab。"
                : "当前 Tab 暂无派奖数据。");
            return;
        }

        try
        {
            await _exportService.CopyRewardsToClipboardAsync(
                GetActiveTabRewardStream(task.ResultCacheKey, task.Result, activeTab));
            Growl.Success($"已复制 {task.SiteName} 的派奖表。");
        }
        catch (Exception ex)
        {
            Growl.Error(ex.Message);
        }
    }

    private async void BatchExportAll_Click(object sender, RoutedEventArgs e)
    {
        if (_batchResult is null || _batchResult.SuccessCount == 0)
        {
            Growl.Warning("暂无成功站点可导出。");
            return;
        }

        var export = await _exportService.ExportBatchAllAsync(_batchResult);
        if (export.Success) Growl.Success(export.Message ?? $"已导出：{export.FilePath}");
        else Growl.Error(export.Message ?? "导出失败");
    }
}

<script setup>
import { ref, watch } from 'vue'
import { ElMessage } from 'element-plus'

const props = defineProps({
  modelValue: { type: Number, required: true },
  total: { type: Number, default: 0 },
  pageSize: { type: Number, default: 50 }
})

const emit = defineEmits(['update:modelValue'])

const jumpInput = ref('')

watch(
  () => props.modelValue,
  (page) => {
    jumpInput.value = String(page)
  },
  { immediate: true }
)

function onJump() {
  const raw = jumpInput.value.trim()
  if (!raw) return

  const page = Number.parseInt(raw, 10)
  const maxPage = Math.max(1, Math.ceil(props.total / props.pageSize) || 1)

  if (!Number.isFinite(page) || page < 1 || page > maxPage) {
    ElMessage.warning(`请输入 1 到 ${maxPage} 之间的页码。`)
    jumpInput.value = String(props.modelValue)
    return
  }

  emit('update:modelValue', page)
}
</script>

<template>
  <div class="page-jump">
    <el-pagination
      :current-page="modelValue"
      :page-size="pageSize"
      layout="total, prev, pager, next"
      :total="total"
      @update:current-page="(p) => emit('update:modelValue', p)"
    />
    <span class="jump-label">跳至</span>
    <el-input
      v-model="jumpInput"
      size="small"
      class="jump-input"
      @keyup.enter="onJump"
    />
    <span class="jump-label">页</span>
    <el-button size="small" link type="primary" @click="onJump">确定</el-button>
  </div>
</template>

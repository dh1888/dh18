<script setup>
import { computed, ref, watch } from 'vue'
import { buildColumnOptions } from '../api'

const props = defineProps({
  mapping: { type: Object, required: true },
  memberHeaders: { type: Array, default: () => [] },
  unclaimedHeaders: { type: Array, default: () => [] },
  profile: { type: String, default: 'period' }
})

const emit = defineEmits(['update:mapping', 'header-row-change'])

const activeTab = ref(
  props.profile === 'callback'
    ? 'callback'
    : props.profile === 'loss7d'
      ? 'loss7d'
      : props.profile === 'yesterdayloss'
        ? 'yesterdayloss'
        : props.profile === 'oldcallback234'
          ? 'oldcallback234'
          : props.profile === 'comprehensive'
            ? 'comprehensive'
            : 'period'
)

watch(
  () => props.profile,
  (p) => {
    activeTab.value =
      p === 'callback'
        ? 'callback'
        : p === 'loss7d'
          ? 'loss7d'
          : p === 'yesterdayloss'
            ? 'yesterdayloss'
            : p === 'oldcallback234'
              ? 'oldcallback234'
              : p === 'comprehensive'
                ? 'comprehensive'
                : 'period'
  }
)

const memberOptions = computed(() => buildColumnOptions(props.memberHeaders))
const unclaimedOptions = computed(() => buildColumnOptions(props.unclaimedHeaders))

const periodFields = [
  { key: 'userIdColumn', label: '会员 ID（A）' },
  { key: 'payColumn', label: '充值（F）' },
  { key: 'withdrawColumn', label: '提现（H）' },
  { key: 'phoneColumn', label: '手机' },
  { key: 'tierColumn', label: '层级' }
]

const callbackFields = [
  { key: 'userIdColumn', label: '会员 ID（F）' },
  { key: 'payColumn', label: '充值（I）' },
  { key: 'withdrawColumn', label: '提现（J）' },
  { key: 'phoneColumn', label: '手机' },
  { key: 'tierColumn', label: '层级' }
]

const loss7dFields = [
  { key: 'userIdColumn', label: '会员 ID（F）' },
  { key: 'payColumn', label: '累计充值（I）' },
  { key: 'withdrawColumn', label: '累计提现（J）' },
  { key: 'phoneColumn', label: '手机（X）' },
  { key: 'tierColumn', label: '层级（Y）' }
]

const yesterdayLossFields = [
  { key: 'userIdColumn', label: '会员 ID（B）' },
  { key: 'payColumn', label: '当日充值（L）' },
  { key: 'withdrawColumn', label: '当日提款（M）' },
  { key: 'netDiffColumn', label: '当日充提差（S）' },
  { key: 'phoneColumn', label: '手机（T）' },
  { key: 'tierColumn', label: '层级（U）' }
]

const oldCallback234Fields = [
  { key: 'userIdColumn', label: '会员 ID（A）' },
  { key: 'payColumn', label: '订单充值（F）' },
  { key: 'withdrawColumn', label: '订单提现（H）' },
  { key: 'netDiffColumn', label: '充提差（I）' },
  { key: 'inactiveDaysColumn', label: '未登录（Q）' },
  { key: 'phoneColumn', label: '手机（R）' },
  { key: 'tierColumn', label: '层级（V）' }
]

const comprehensiveFields = oldCallback234Fields

const rechargeFields = [
  { key: 'userIdColumn', label: '会员 ID（B）' },
  { key: 'amountColumn', label: '充值金额（F）' }
]

function patchSection(section, field, value) {
  emit('update:mapping', {
    ...props.mapping,
    [section]: { ...props.mapping[section], [field]: value }
  })
}

function patchUnclaimed(value) {
  emit('update:mapping', { ...props.mapping, unclaimedUserIdColumn: value })
}

function patchRecharge(field, value) {
  emit('update:mapping', {
    ...props.mapping,
    recharge: { ...props.mapping.recharge, [field]: value }
  })
}

function onHeaderRowChange() {
  emit('header-row-change')
}
</script>

<template>
  <el-tabs v-model="activeTab" class="mapping-tabs">
    <el-tab-pane v-if="profile !== 'loss7d' && profile !== 'yesterdayloss' && profile !== 'oldcallback234' && profile !== 'comprehensive'" label="时段彩金" name="period">
      <el-form label-width="88px" size="small" class="mapping-compact-form">
        <div class="mapping-grid">
          <el-form-item label="表头行号" class="mapping-grid-span-2">
            <el-input-number
              :model-value="mapping.period.headerRow"
              :min="0"
              :max="50"
              controls-position="right"
              @update:model-value="(v) => { patchSection('period', 'headerRow', v); onHeaderRowChange() }"
            />
          </el-form-item>
          <el-form-item v-for="field in periodFields" :key="'p-' + field.key" :label="field.label">
            <el-select
              :model-value="mapping.period[field.key]"
              filterable
              @update:model-value="(v) => patchSection('period', field.key, v)"
            >
              <el-option v-for="opt in memberOptions" :key="'p-' + field.key + opt.value" :label="opt.label" :value="opt.value" />
            </el-select>
          </el-form-item>
        </div>
      </el-form>
    </el-tab-pane>

    <el-tab-pane v-if="profile !== 'loss7d' && profile !== 'yesterdayloss' && profile !== 'oldcallback234' && profile !== 'comprehensive'" label="回访彩金" name="callback">
      <el-form label-width="88px" size="small" class="mapping-compact-form">
        <div class="mapping-grid">
          <el-form-item label="表头行号" class="mapping-grid-span-2">
            <el-input-number
              :model-value="mapping.callback.headerRow"
              :min="0"
              :max="50"
              controls-position="right"
              @update:model-value="(v) => { patchSection('callback', 'headerRow', v); onHeaderRowChange() }"
            />
          </el-form-item>
          <el-form-item v-for="field in callbackFields" :key="'c-' + field.key" :label="field.label">
            <el-select
              :model-value="mapping.callback[field.key]"
              filterable
              @update:model-value="(v) => patchSection('callback', field.key, v)"
            >
              <el-option v-for="opt in memberOptions" :key="'c-' + field.key + opt.value" :label="opt.label" :value="opt.value" />
            </el-select>
          </el-form-item>
        </div>
      </el-form>
    </el-tab-pane>

    <el-tab-pane v-if="profile === 'loss7d'" label="老回访1567" name="loss7d">
      <el-form label-width="108px" size="small" class="mapping-compact-form">
        <div class="mapping-grid">
          <el-form-item label="表头行号" class="mapping-grid-span-2">
            <el-input-number
              :model-value="mapping.loss7d.headerRow"
              :min="0"
              :max="50"
              controls-position="right"
              @update:model-value="(v) => { patchSection('loss7d', 'headerRow', v); onHeaderRowChange() }"
            />
          </el-form-item>
          <el-form-item v-for="field in loss7dFields" :key="'l-' + field.key" :label="field.label">
            <el-select
              :model-value="mapping.loss7d[field.key]"
              filterable
              @update:model-value="(v) => patchSection('loss7d', field.key, v)"
            >
              <el-option v-for="opt in memberOptions" :key="'l-' + field.key + opt.value" :label="opt.label" :value="opt.value" />
            </el-select>
          </el-form-item>
        </div>
      </el-form>
    </el-tab-pane>

    <el-tab-pane v-if="profile === 'yesterdayloss'" label="昨日亏损" name="yesterdayloss">
      <el-form label-width="120px" size="small" class="mapping-compact-form">
        <div class="mapping-grid">
          <el-form-item label="表头行号" class="mapping-grid-span-2">
            <el-input-number
              :model-value="mapping.yesterdayLoss.headerRow"
              :min="0"
              :max="50"
              controls-position="right"
              @update:model-value="(v) => { patchSection('yesterdayLoss', 'headerRow', v); onHeaderRowChange() }"
            />
          </el-form-item>
          <el-form-item v-for="field in yesterdayLossFields" :key="'y-' + field.key" :label="field.label">
            <el-select
              :model-value="mapping.yesterdayLoss[field.key]"
              filterable
              @update:model-value="(v) => patchSection('yesterdayLoss', field.key, v)"
            >
              <el-option v-for="opt in memberOptions" :key="'y-' + field.key + opt.value" :label="opt.label" :value="opt.value" />
            </el-select>
          </el-form-item>
        </div>
      </el-form>
    </el-tab-pane>

    <el-tab-pane v-if="profile === 'oldcallback234'" label="老回访234" name="oldcallback234">
      <el-form label-width="120px" size="small" class="mapping-compact-form">
        <div class="mapping-grid">
          <el-form-item label="表头行号" class="mapping-grid-span-2">
            <el-input-number
              :model-value="mapping.oldCallback234.headerRow"
              :min="0"
              :max="50"
              controls-position="right"
              @update:model-value="(v) => { patchSection('oldCallback234', 'headerRow', v); onHeaderRowChange() }"
            />
          </el-form-item>
          <el-form-item v-for="field in oldCallback234Fields" :key="'o-' + field.key" :label="field.label">
            <el-select
              :model-value="mapping.oldCallback234[field.key]"
              filterable
              @update:model-value="(v) => patchSection('oldCallback234', field.key, v)"
            >
              <el-option v-for="opt in memberOptions" :key="'o-' + field.key + opt.value" :label="opt.label" :value="opt.value" />
            </el-select>
          </el-form-item>
        </div>
      </el-form>
    </el-tab-pane>

    <el-tab-pane v-if="profile === 'comprehensive'" label="综合回访" name="comprehensive">
      <el-form label-width="120px" size="small" class="mapping-compact-form">
        <div class="mapping-grid">
          <el-form-item label="表头行号" class="mapping-grid-span-2">
            <el-input-number
              :model-value="mapping.comprehensive.headerRow"
              :min="0"
              :max="50"
              controls-position="right"
              @update:model-value="(v) => { patchSection('comprehensive', 'headerRow', v); onHeaderRowChange() }"
            />
          </el-form-item>
          <el-form-item v-for="field in comprehensiveFields" :key="'x-' + field.key" :label="field.label">
            <el-select
              :model-value="mapping.comprehensive[field.key]"
              filterable
              @update:model-value="(v) => patchSection('comprehensive', field.key, v)"
            >
              <el-option v-for="opt in memberOptions" :key="'x-' + field.key + opt.value" :label="opt.label" :value="opt.value" />
            </el-select>
          </el-form-item>
        </div>
      </el-form>
    </el-tab-pane>

    <el-tab-pane v-if="profile === 'oldcallback234' || profile === 'comprehensive'" label="充值数据" name="recharge">
      <el-form label-width="120px" size="small" class="mapping-compact-form">
        <div class="mapping-grid">
          <el-form-item label="表头行号" class="mapping-grid-span-2">
            <el-input-number
              :model-value="mapping.recharge.headerRow"
              :min="0"
              :max="50"
              controls-position="right"
              @update:model-value="(v) => patchRecharge('headerRow', v)"
            />
          </el-form-item>
          <el-form-item v-for="field in rechargeFields" :key="'r-' + field.key" :label="field.label">
            <el-select
              :model-value="mapping.recharge[field.key]"
              filterable
              @update:model-value="(v) => patchRecharge(field.key, v)"
            >
              <el-option v-for="opt in memberOptions" :key="'r-' + field.key + opt.value" :label="opt.label" :value="opt.value" />
            </el-select>
          </el-form-item>
        </div>
      </el-form>
    </el-tab-pane>

    <el-tab-pane label="未领名单" name="unclaimed">
      <el-form label-width="88px" size="small" class="mapping-compact-form">
        <div class="mapping-grid mapping-grid-single">
          <el-form-item label="会员 ID（B）">
            <el-select
              :model-value="mapping.unclaimedUserIdColumn"
              filterable
              @update:model-value="patchUnclaimed"
            >
              <el-option v-for="opt in unclaimedOptions" :key="'u-' + opt.value" :label="opt.label" :value="opt.value" />
            </el-select>
          </el-form-item>
        </div>
      </el-form>
    </el-tab-pane>
  </el-tabs>
</template>

<style scoped>
.mapping-tabs :deep(.el-tabs__header) {
  margin-bottom: 8px;
}

.mapping-compact-form :deep(.el-form-item) {
  margin-bottom: 8px;
}

.mapping-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 4px 12px;
  align-items: start;
}

.mapping-grid-single {
  grid-template-columns: repeat(2, minmax(0, 1fr));
  max-width: 520px;
}

.mapping-grid-span-2 {
  grid-column: span 1;
}

.mapping-compact-form :deep(.el-select),
.mapping-compact-form :deep(.el-input-number) {
  width: 100%;
}

@media (max-width: 960px) {
  .mapping-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
</style>

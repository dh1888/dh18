// Signature parity test as standalone C# program
// Can be compiled as: csc.exe SignatureParity.cs

using System;
using System.Security.Cryptography;
using System.Text;

public class SignatureParityTest
{
    public class MockSignatureInput
    {
        public string Timestamp { get; set; } = string.Empty;
        public string Method { get; set; } = string.Empty;
        public string Path { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        public string Secret { get; set; } = string.Empty; // 64-char hex string (32 bytes)
    }

    /// <summary>
    /// 使用 C# 的逻辑计算签名（模拟 Signatures.cs::AddSignatureHeaders）
    /// </summary>
    public static string ComputeCSharpSignature(MockSignatureInput input)
    {
        // 计算 bodyHash
        using (var sha = SHA256.Create())
        {
            var bodyHash = sha.ComputeHash(Encoding.UTF8.GetBytes(input.Body));
            var bodyHashHex = Convert.ToHexString(bodyHash).ToLowerInvariant();

            // 构造 message
            var message = input.Timestamp + input.Method + input.Path + bodyHashHex;

            // 计算 HMAC
            var key = Encoding.UTF8.GetBytes(input.Secret);
            using (var hmac = new HMACSHA256(key))
            {
                var sig = hmac.ComputeHash(Encoding.UTF8.GetBytes(message));
                var signature = Convert.ToHexString(sig).ToLowerInvariant();
                return signature;
            }
        }
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("=== C# Agent Signature Test (Parity with Go Backend) ===");

        var mockInputs = new MockSignatureInput[]
        {
            new MockSignatureInput
            {
                Timestamp = "2026-06-13T14:30:45Z",
                Method = "POST",
                Path = "/api/v1/upload/chunk",
                Body = @"{""uploadId"":""550e8400-e29b-41d4-a716-446655440000"",""chunkIndex"":0,""totalChunks"":5}",
                Secret = "a1b2c3d4e5f6789012345678901234567890123456789012345678901234567"
            },
            new MockSignatureInput
            {
                Timestamp = "2026-06-13T14:30:50Z",
                Method = "POST",
                Path = "/api/v1/upload/complete",
                Body = @"{""uploadId"":""550e8400-e29b-41d4-a716-446655440000"",""deviceId"":""e8c7b3f9-4d3e-4c5a-8a2c-5d5d5d5d5d5d""}",
                Secret = "f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a698"
            },
            new MockSignatureInput
            {
                Timestamp = "2026-06-13T14:31:00Z",
                Method = "GET",
                Path = "/api/v1/devices/verify",
                Body = "",
                Secret = "0102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f20"
            }
        };

        // Go backend expected results from previous run
        string[] expectedGoSignatures = {
            "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
            "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
            "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d"
        };

        bool allMatch = true;
        for (int i = 0; i < mockInputs.Length; i++)
        {
            var input = mockInputs[i];
            var csharpSig = ComputeCSharpSignature(input);
            var goSig = expectedGoSignatures[i];
            bool matches = string.Equals(csharpSig, goSig, StringComparison.OrdinalIgnoreCase);
            allMatch = allMatch && matches;

            Console.WriteLine($"\n=== Test Case {i + 1} ===");
            Console.WriteLine($"Input:");
            Console.WriteLine($"  Timestamp: {input.Timestamp}");
            Console.WriteLine($"  Method: {input.Method}");
            Console.WriteLine($"  Path: {input.Path}");
            Console.WriteLine($"  Body: {input.Body}");
            Console.WriteLine($"  Secret: {input.Secret}");
            Console.WriteLine($"\nGo Signature:    {goSig}");
            Console.WriteLine($"C# Signature:    {csharpSig}");
            Console.WriteLine($"Match: {(matches ? "✓ YES" : "✗ NO")}");

            // 计算中间步骤
            using (var sha = SHA256.Create())
            {
                var bodyHash = sha.ComputeHash(Encoding.UTF8.GetBytes(input.Body));
                var bodyHashHex = Convert.ToHexString(bodyHash).ToLowerInvariant();
                var message = input.Timestamp + input.Method + input.Path + bodyHashHex;
                Console.WriteLine($"\nIntermediate:");
                Console.WriteLine($"  Body Hash (hex): {bodyHashHex}");
                Console.WriteLine($"  Message: {message}");
            }
        }

        Console.WriteLine($"\n=== Summary ===");
        Console.WriteLine($"All signatures match: {(allMatch ? "✓ YES - CONVERGED!" : "✗ NO - DIVERGENCE DETECTED!")}");
    }
}

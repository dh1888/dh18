// agent/Security/SignatureMonitoring.cs
// Signature generation monitoring and drift detection

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Security;

/// <summary>
/// 签名生成指标（线程安全）
/// </summary>
public class SignatureGenerationMetrics
{
    private long _successCount;
    private long _failureCount;
    private long _missingSecretCount;
    private DateTime _lastUpdateTime;
    private readonly object _lock = new();

    public long SuccessCount => Interlocked.Read(ref _successCount);
    public long FailureCount => Interlocked.Read(ref _failureCount);
    public long MissingSecretCount => Interlocked.Read(ref _missingSecretCount);
    public DateTime LastUpdateTime
    {
        get
        {
            lock (_lock)
            {
                return _lastUpdateTime;
            }
        }
    }

    public void RecordSuccess()
    {
        Interlocked.Increment(ref _successCount);
        lock (_lock)
        {
            _lastUpdateTime = DateTime.UtcNow;
        }
    }

    public void RecordFailure()
    {
        Interlocked.Increment(ref _failureCount);
        lock (_lock)
        {
            _lastUpdateTime = DateTime.UtcNow;
        }
    }

    public void RecordMissingSecret()
    {
        Interlocked.Increment(ref _missingSecretCount);
    }

    public bool IsHealthy()
    {
        long total = SuccessCount + FailureCount;
        if (total == 0) return true; // No samples yet

        double failureRate = (double)FailureCount / total;
        return failureRate < 0.05; // 5% threshold
    }

    public void Reset()
    {
        Interlocked.Exchange(ref _successCount, 0);
        Interlocked.Exchange(ref _failureCount, 0);
        Interlocked.Exchange(ref _missingSecretCount, 0);
    }
}

/// <summary>
/// 签名生成漂移检测器
/// </summary>
public static class SignatureDriftDetector
{
    /// <summary>
    /// 在应用启动时执行漂移检测
    /// 如果检测到漂移，将抛出异常阻止启动
    /// </summary>
    public static void DetectDriftOnStartup(ILogger? logger = null)
    {
        logger?.LogInformation("[STARTUP] Running v1 signature drift detection...");

        var vectors = SignatureV1RegressionTest.GetV1TestVectors();
        var diffs = new List<string>();

        var expectedGoOutputs = new Dictionary<string, string>
        {
            ["POST upload chunk with JSON"] = "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
            ["POST upload complete"] = "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
            ["GET device verify with empty body"] = "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d",
        };

        foreach (var vec in vectors.Take(3))
        {
            var computed = SignatureV1RegressionTest.ComputeSignatureV1(
                vec.Timestamp, vec.Method, vec.Path, vec.Body, vec.DeviceSecret);
            var expected = expectedGoOutputs[vec.Name];

            if (computed != expected)
            {
                diffs.Add($"DRIFT DETECTED: {vec.Name}\n  Expected (Go): {expected}\n  Got (C#):    {computed}");
            }
        }

        if (diffs.Any())
        {
            var errorMsg = $"CRITICAL: Signature drift detected on {diffs.Count} test vectors:\n{string.Join("\n", diffs)}";
            logger?.LogError(errorMsg);
            throw new InvalidOperationException(errorMsg);
        }

        logger?.LogInformation("[STARTUP] ✓ Signature drift detection PASSED (3/3 vectors match)");
    }

    /// <summary>
    /// 周期性检查漂移（后台任务）
    /// </summary>
    public static void CheckPeriodicDrift(ILogger logger)
    {
        _ = Task.Run(async () =>
        {
            while (true)
            {
                try
                {
                    await Task.Delay(TimeSpan.FromHours(1)); // 每小时检查一次

                    var vectors = SignatureV1RegressionTest.GetV1TestVectors();
                    var diffs = new List<string>();

                    var expectedGoOutputs = new Dictionary<string, string>
                    {
                        ["POST upload chunk with JSON"] = "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
                        ["POST upload complete"] = "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
                        ["GET device verify with empty body"] = "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d",
                    };

                    foreach (var vec in vectors.Take(3))
                    {
                        var computed = SignatureV1RegressionTest.ComputeSignatureV1(
                            vec.Timestamp, vec.Method, vec.Path, vec.Body, vec.DeviceSecret);
                        var expected = expectedGoOutputs[vec.Name];

                        if (computed != expected)
                        {
                            diffs.Add($"DRIFT: {vec.Name}");
                        }
                    }

                    if (diffs.Any())
                    {
                        logger.LogCritical("[PERIODIC] ALERT: Signature drift detected: {Diffs}",
                            string.Join(", ", diffs));
                        // TODO: 发送到监控系统/告警系统
                    }
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "[PERIODIC] Error during drift check");
                }
            }
        });
    }
}

/// <summary>
/// C# Agent 签名拦截器增强（用于监控）
/// </summary>
public interface ISignatureInterceptor
{
    void OnBeforeSignatureGeneration(string method, string path, int contentLength);
    void OnSignatureGenerationSuccess(string signature, double durationMs);
    void OnSignatureGenerationFailure(string error);
}

/// <summary>
/// 默认拦截器实现
/// </summary>
public class DefaultSignatureInterceptor : ISignatureInterceptor
{
    private readonly ILogger<DefaultSignatureInterceptor> _logger;
    private readonly SignatureGenerationMetrics _metrics = new();

    public DefaultSignatureInterceptor(ILogger<DefaultSignatureInterceptor> logger)
    {
        _logger = logger;
    }

    public void OnBeforeSignatureGeneration(string method, string path, int contentLength)
    {
        _logger.LogDebug("[SIG] Generating signature for {Method} {Path} (content: {ContentLength} bytes)",
            method, path, contentLength);
    }

    public void OnSignatureGenerationSuccess(string signature, double durationMs)
    {
        _metrics.RecordSuccess();
        _logger.LogDebug("[SIG] ✓ Signature generated: {SignaturePrefix}... (took {Duration}ms)",
            signature.Substring(0, Math.Min(8, signature.Length)), durationMs);
    }

    public void OnSignatureGenerationFailure(string error)
    {
        _metrics.RecordFailure();
        _logger.LogError("[SIG] ✗ Signature generation failed: {Error}", error);
    }

    public SignatureGenerationMetrics GetMetrics() => _metrics;
}

// agent/Security/SignatureV1RegressionTest.cs
// v1 Protocol Regression Test Suite (C#)
// These tests must match Go implementation exactly

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace EnterpriseAgent.Agent.Security;

public class SignatureTestVector
{
    public string Name { get; set; } = string.Empty;
    public string Timestamp { get; set; } = string.Empty;
    public string Method { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;
    public string DeviceSecret { get; set; } = string.Empty;
    public string ExpectedSignature { get; set; } = string.Empty;
}

public static class SignatureV1RegressionTest
{
    /// <summary>
    /// Gets all frozen test vectors for protocol v1
    /// These MUST NOT change and must match Go implementation exactly
    /// </summary>
    public static List<SignatureTestVector> GetV1TestVectors()
    {
        return new List<SignatureTestVector>
        {
            new()
            {
                Name = "POST upload chunk with JSON",
                Timestamp = "2026-06-13T14:30:45Z",
                Method = "POST",
                Path = "/api/v1/upload/chunk",
                Body = @"{""uploadId"":""550e8400-e29b-41d4-a716-446655440000"",""chunkIndex"":0,""totalChunks"":5}",
                DeviceSecret = "a1b2c3d4e5f6789012345678901234567890123456789012345678901234567",
                ExpectedSignature = "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01"
            },
            new()
            {
                Name = "POST upload complete",
                Timestamp = "2026-06-13T14:30:50Z",
                Method = "POST",
                Path = "/api/v1/upload/complete",
                Body = @"{""uploadId"":""550e8400-e29b-41d4-a716-446655440000"",""deviceId"":""e8c7b3f9-4d3e-4c5a-8a2c-5d5d5d5d5d5d""}",
                DeviceSecret = "f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a698",
                ExpectedSignature = "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5"
            },
            new()
            {
                Name = "GET device verify with empty body",
                Timestamp = "2026-06-13T14:31:00Z",
                Method = "GET",
                Path = "/api/v1/devices/verify",
                Body = "",
                DeviceSecret = "0102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f20",
                ExpectedSignature = "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d"
            },
            new()
            {
                Name = "DELETE with different method",
                Timestamp = "2026-06-13T14:31:05Z",
                Method = "DELETE",
                Path = "/api/v1/devices/abc-123",
                Body = "",
                DeviceSecret = "aaaabbbbccccddddeeeeffffgggghhhh11112222333344445555666677778888",
                ExpectedSignature = ""
            },
            new()
            {
                Name = "PUT with patch body",
                Timestamp = "2026-06-13T14:31:10Z",
                Method = "PUT",
                Path = "/api/v1/settings/config",
                Body = @"{""enabled"":true,""timeout"":30}",
                DeviceSecret = "88887777666655554444333322221111ffffeeeeddddcccbbbbaaa99998888777",
                ExpectedSignature = ""
            }
        };
    }

    /// <summary>
    /// Computes a v1 signature from inputs
    /// </summary>
    public static string ComputeSignatureV1(string timestamp, string method, string path, string body, string deviceSecret)
    {
        var bodyBytes = Encoding.UTF8.GetBytes(body ?? string.Empty);
        var cr = CanonicalRequest.BuildCanonical(timestamp, method, path, bodyBytes);
        var message = cr.GetMessage();

        return CanonicalRequest.ComputeSignature(message, deviceSecret);
    }

    /// <summary>
    /// Runs all regression tests
    /// </summary>
    public static void RunRegressionTests()
    {
        var vectors = GetV1TestVectors();
        var allPass = true;

        Console.WriteLine("=== v1 Protocol Regression Test Suite ===\n");

        for (int i = 0; i < vectors.Count; i++)
        {
            var vec = vectors[i];
            var computed = ComputeSignatureV1(vec.Timestamp, vec.Method, vec.Path, vec.Body, vec.DeviceSecret);

            if (!string.IsNullOrEmpty(vec.ExpectedSignature))
            {
                if (computed == vec.ExpectedSignature)
                {
                    Console.WriteLine($"✓ Test {i + 1} PASS: {vec.Name}");
                    Console.WriteLine($"  Signature: {computed}");
                }
                else
                {
                    Console.WriteLine($"✗ Test {i + 1} FAIL: {vec.Name}");
                    Console.WriteLine($"  Expected: {vec.ExpectedSignature}");
                    Console.WriteLine($"  Got:      {computed}");
                    allPass = false;
                }
            }
            else
            {
                Console.WriteLine($"? Test {i + 1} NEW: {vec.Name}");
                Console.WriteLine($"  Signature: {computed}");
            }

            Console.WriteLine();
        }

        Console.WriteLine("=== Parity Check (Go vs C#) ===\n");

        var firstThreeVectors = vectors.Take(3).ToList();
        var goSignatures = new[]
        {
            "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
            "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
            "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d"
        };

        for (int i = 0; i < firstThreeVectors.Count; i++)
        {
            var vec = firstThreeVectors[i];
            var computed = ComputeSignatureV1(vec.Timestamp, vec.Method, vec.Path, vec.Body, vec.DeviceSecret);
            var goSig = goSignatures[i];

            if (computed == goSig)
            {
                Console.WriteLine($"✓ Parity OK: {vec.Name}");
            }
            else
            {
                Console.WriteLine($"✗ Parity FAIL: {vec.Name}");
                Console.WriteLine($"  Go (expected): {goSig}");
                Console.WriteLine($"  C# (got):      {computed}");
                allPass = false;
            }
        }

        Console.WriteLine($"\n{'='} Overall Result: {(allPass ? "✓ ALL TESTS PASS" : "✗ SOME TESTS FAILED")}");
    }

    /// <summary>
    /// Prints all test vectors in readable format
    /// </summary>
    public static void PrintV1TestVectors()
    {
        var vectors = GetV1TestVectors();

        Console.WriteLine("=== v1 Protocol Test Vectors (FROZEN) ===\n");

        for (int i = 0; i < vectors.Count; i++)
        {
            var vec = vectors[i];
            var sig = ComputeSignatureV1(vec.Timestamp, vec.Method, vec.Path, vec.Body, vec.DeviceSecret);

            Console.WriteLine($"Vector {i + 1}: {vec.Name}");
            Console.WriteLine($"  Timestamp: {vec.Timestamp}");
            Console.WriteLine($"  Method:    {vec.Method}");
            Console.WriteLine($"  Path:      {vec.Path}");
            Console.WriteLine($"  Body:      {vec.Body}");
            Console.WriteLine($"  Secret:    {vec.DeviceSecret}");
            Console.WriteLine($"  Signature: {sig}\n");
        }
    }
}

// Security/DeviceFingerprinter.cs - 保持不变

using System.Management;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Security;

[SupportedOSPlatform("windows")]
public class DeviceFingerprinter
{
    private readonly ILogger<DeviceFingerprinter> _logger;
    
    private const int BIOS_WEIGHT = 40;
    private const int CPU_WEIGHT = 20;
    private const int DISK_WEIGHT = 20;
    private const int MAC_WEIGHT = 10;
    private const int OS_WEIGHT = 10;

    public DeviceFingerprinter(ILogger<DeviceFingerprinter> logger)
    {
        _logger = logger;
    }

    public Dictionary<string, string> Collect()
    {
        var result = new Dictionary<string, string>();
        
        result["bios_uuid"] = GetBiosUuid();
        result["cpu_id"] = GetCpuId();
        result["disk_serial"] = GetDiskSerial();
        result["mac_address"] = GetMacAddress();
        result["os_uuid"] = GetOsUuid();
        result["hostname"] = Environment.MachineName;
        result["os_version"] = RuntimeInformation.OSDescription;
        
        return result;
    }

    private string GetBiosUuid()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT UUID FROM Win32_ComputerSystemProduct");
            foreach (var obj in searcher.Get())
            {
                return obj["UUID"]?.ToString() ?? "";
            }
        }
        catch (Exception ex) { _logger.LogWarning($"BIOS UUID failed: {ex.Message}"); }
        return "";
    }

    private string GetCpuId()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor");
            foreach (var obj in searcher.Get())
            {
                return obj["ProcessorId"]?.ToString() ?? "";
            }
        }
        catch (Exception ex) { _logger.LogWarning($"CPU ID failed: {ex.Message}"); }
        return "";
    }

    private string GetDiskSerial()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_DiskDrive WHERE Index=0");
            foreach (var obj in searcher.Get())
            {
                return obj["SerialNumber"]?.ToString()?.Trim() ?? "";
            }
        }
        catch (Exception ex) { _logger.LogWarning($"Disk serial failed: {ex.Message}"); }
        return "";
    }

    private string GetMacAddress()
    {
        try
        {
            var nics = NetworkInterface.GetAllNetworkInterfaces();
            foreach (var nic in nics)
            {
                if (nic.OperationalStatus == OperationalStatus.Up && 
                    nic.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                {
                    var mac = nic.GetPhysicalAddress().ToString();
                    if (!string.IsNullOrEmpty(mac)) return mac;
                }
            }
        }
        catch (Exception ex) { _logger.LogWarning($"MAC address failed: {ex.Message}"); }
        return "";
    }

    private string GetOsUuid()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT UUID FROM Win32_ComputerSystemProduct");
            foreach (var obj in searcher.Get())
            {
                var uuid = obj["UUID"]?.ToString();
                if (!string.IsNullOrEmpty(uuid)) return uuid;
            }
        }
        catch (Exception ex) { _logger.LogWarning($"OS UUID failed: {ex.Message}"); }
        return Guid.NewGuid().ToString();
    }

    public double CalculateSimilarity(Dictionary<string, string> a, Dictionary<string, string> b)
    {
        double score = 0;
        
        if (CompareField(a, b, "bios_uuid")) score += BIOS_WEIGHT;
        if (CompareField(a, b, "cpu_id")) score += CPU_WEIGHT;
        if (CompareField(a, b, "disk_serial")) score += DISK_WEIGHT;
        if (CompareField(a, b, "mac_address")) score += MAC_WEIGHT;
        if (CompareField(a, b, "os_uuid")) score += OS_WEIGHT;
        
        return score;
    }

    private bool CompareField(Dictionary<string, string> a, Dictionary<string, string> b, string field)
    {
        a.TryGetValue(field, out var av);
        b.TryGetValue(field, out var bv);
        return !string.IsNullOrEmpty(av) && av.Equals(bv, StringComparison.OrdinalIgnoreCase);
    }

    public string GenerateDeviceId(Dictionary<string, string> fingerprint)
    {
        var combined = $"{fingerprint["bios_uuid"]}|{fingerprint["cpu_id"]}|{fingerprint["disk_serial"]}";
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(combined));
        return Convert.ToBase64String(hash).Replace("/", "_").Replace("+", "-")[..32];
    }
}
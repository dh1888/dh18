using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.CircuitBreaker;
using Polly.Retry;
using Polly.Timeout;
using Polly.Wrap;
using EnterpriseAgent.Agent.Models;

namespace EnterpriseAgent.Agent.Resilience;

/// <summary>
/// 断路器状态
/// </summary>
public enum CircuitBreakerState
{
    /// <summary>关闭状态 - 正常调用</summary>
    Closed,
    /// <summary>开启状态 - 拒绝调用，快速失败</summary>
    Open,
    /// <summary>半开状态 - 限流尝试恢复</summary>
    HalfOpen
}

/// <summary>
/// 断路器 - 防止级联故障
/// </summary>
public class CircuitBreaker
{
    private readonly string _name;
    private readonly ILogger _logger;
    private readonly int _failureThreshold;
    private readonly TimeSpan _openDuration;
    private readonly int _halfOpenMaxRequests;
    
    private int _failureCount;
    private DateTime? _openUntil;
    private int _halfOpenRequests;
    private CircuitBreakerState _state = CircuitBreakerState.Closed;
    private readonly object _lock = new();
    
    /// <summary>
    /// 当前断路器状态
    /// </summary>
    public CircuitBreakerState State => _state;
    
    /// <summary>
    /// 失败次数
    /// </summary>
    public int FailureCount => _failureCount;
    
    /// <summary>
    /// 创建断路器实例
    /// </summary>
    /// <param name="name">断路器名称（用于日志）</param>
    /// <param name="logger">日志记录器</param>
    /// <param name="failureThreshold">失败阈值（连续失败次数）</param>
    /// <param name="openDuration">开启持续时间</param>
    /// <param name="halfOpenMaxRequests">半开状态最大请求数</param>
    public CircuitBreaker(
        string name,
        ILogger logger,
        int failureThreshold = Constants.CircuitBreakerFailureThreshold,
        TimeSpan? openDuration = null,
        int halfOpenMaxRequests = Constants.CircuitBreakerHalfOpenMaxRequests)
    {
        _name = name;
        _logger = logger;
        _failureThreshold = failureThreshold;
        _openDuration = openDuration ?? TimeSpan.FromSeconds(Constants.CircuitBreakerOpenDurationSeconds);
        _halfOpenMaxRequests = halfOpenMaxRequests;
    }
    
    /// <summary>
    /// 执行操作（带断路器保护）
    /// </summary>
    public async Task<T> ExecuteAsync<T>(
        Func<Task<T>> action,
        T fallbackValue,
        CancellationToken cancellationToken = default)
    {
        // 检查断路器状态
        if (IsOpen())
        {
            _logger.LogWarning("CircuitBreaker '{Name}' is OPEN, using fallback", _name);
            return fallbackValue;
        }
        
        try
        {
            var result = await action();
            RecordSuccess();
            return result;
        }
        catch (Exception ex)
        {
            RecordFailure(ex);
            throw;
        }
    }
    
    /// <summary>
    /// 执行操作（带断路器保护，无返回值）
    /// </summary>
    public async Task ExecuteAsync(
        Func<Task> action,
        CancellationToken cancellationToken = default)
    {
        if (IsOpen())
        {
            _logger.LogWarning("CircuitBreaker '{Name}' is OPEN, skipping action", _name);
            return;
        }
        
        try
        {
            await action();
            RecordSuccess();
        }
        catch (Exception ex)
        {
            RecordFailure(ex);
            throw;
        }
    }
    
    /// <summary>
    /// 检查断路器是否开启
    /// </summary>
    private bool IsOpen()
    {
        lock (_lock)
        {
            if (_state == CircuitBreakerState.Open)
            {
                if (DateTime.UtcNow > _openUntil)
                {
                    // 进入半开状态
                    _state = CircuitBreakerState.HalfOpen;
                    _halfOpenRequests = 0;
                    _logger.LogInformation("CircuitBreaker '{Name}' transitioned from OPEN to HALF_OPEN", _name);
                    return false;
                }
                return true;
            }
            
            return false;
        }
    }
    
    /// <summary>
    /// 记录成功
    /// </summary>
    private void RecordSuccess()
    {
        lock (_lock)
        {
            if (_state == CircuitBreakerState.HalfOpen)
            {
                _halfOpenRequests++;
                if (_halfOpenRequests >= _halfOpenMaxRequests)
                {
                    // 恢复关闭状态
                    _state = CircuitBreakerState.Closed;
                    _failureCount = 0;
                    _logger.LogInformation("CircuitBreaker '{Name}' transitioned from HALF_OPEN to CLOSED", _name);
                }
            }
            else if (_state == CircuitBreakerState.Closed)
            {
                _failureCount = 0;
            }
        }
    }
    
    /// <summary>
    /// 记录失败
    /// </summary>
    private void RecordFailure(Exception ex)
    {
        lock (_lock)
        {
            if (_state == CircuitBreakerState.HalfOpen)
            {
                // 半开状态下失败，立即重新开启
                _state = CircuitBreakerState.Open;
                _openUntil = DateTime.UtcNow.Add(_openDuration);
                _logger.LogWarning(ex, "CircuitBreaker '{Name}' transitioned from HALF_OPEN to OPEN (failure detected)", _name);
                return;
            }
            
            if (_state == CircuitBreakerState.Closed)
            {
                _failureCount++;
                
                if (_failureCount >= _failureThreshold)
                {
                    // 开启断路器
                    _state = CircuitBreakerState.Open;
                    _openUntil = DateTime.UtcNow.Add(_openDuration);
                    _logger.LogWarning(ex, "CircuitBreaker '{Name}' transitioned from CLOSED to OPEN after {FailureCount} failures", 
                        _name, _failureCount);
                }
            }
        }
    }
    
    /// <summary>
    /// 手动关闭断路器
    /// </summary>
    public void Close()
    {
        lock (_lock)
        {
            _state = CircuitBreakerState.Closed;
            _failureCount = 0;
            _openUntil = null;
            _halfOpenRequests = 0;
            _logger.LogInformation("CircuitBreaker '{Name}' manually closed", _name);
        }
    }
    
    /// <summary>
    /// 尝试自动恢复（检查冷却期后进入半开状态）
    /// </summary>
    public async Task TryAutoRecoverAsync()
    {
        if (_state != CircuitBreakerState.Open)
        {
            return;
        }

        // 检查是否已过冷却期
        if (DateTime.UtcNow > _openUntil)
        {
            lock (_lock)
            {
                _state = CircuitBreakerState.HalfOpen;
                _halfOpenRequests = 0;

                _logger.LogInformation(
                    "CircuitBreaker '{Name}' auto-recovering to HALF_OPEN",
                    _name);
            }
        }

        await Task.CompletedTask;
    }
    
    /// <summary>
    /// 手动开启断路器
    /// </summary>
    public void Open()
    {
        lock (_lock)
        {
            _state = CircuitBreakerState.Open;
            _openUntil = DateTime.UtcNow.Add(_openDuration);
            _logger.LogInformation("CircuitBreaker '{Name}' manually opened", _name);
        }
    }
    
    /// <summary>
    /// 获取诊断信息
    /// </summary>
    public CircuitBreakerDiagnostics GetDiagnostics()
    {
        lock (_lock)
        {
            return new CircuitBreakerDiagnostics
            {
                Name = _name,
                State = _state,
                FailureCount = _failureCount,
                FailureThreshold = _failureThreshold,
                OpenUntil = _openUntil,
                HalfOpenRequests = _halfOpenRequests,
                HalfOpenMaxRequests = _halfOpenMaxRequests
            };
        }
    }
}

/// <summary>
/// 断路器诊断信息
/// </summary>
public class CircuitBreakerDiagnostics
{
    public string Name { get; set; } = "";
    public CircuitBreakerState State { get; set; }
    public int FailureCount { get; set; }
    public int FailureThreshold { get; set; }
    public DateTime? OpenUntil { get; set; }
    public int HalfOpenRequests { get; set; }
    public int HalfOpenMaxRequests { get; set; }
    
    public bool IsOpen => State == CircuitBreakerState.Open;
    public bool IsHalfOpen => State == CircuitBreakerState.HalfOpen;
    public bool IsClosed => State == CircuitBreakerState.Closed;
}
/// <summary>
/// 降级级别
/// </summary>
public enum DegradationLevel
{
    /// <summary>正常 - 全功能运行</summary>
    None = 0,
    /// <summary>轻度降级 - 降低非核心功能频率</summary>
    Mild = 1,
    /// <summary>中度降级 - 暂停部分非核心功能</summary>
    Moderate = 2,
    /// <summary>严重降级 - 仅保留核心功能</summary>
    Severe = 3
}

/// <summary>
/// 系统资源指标
/// </summary>
public class SystemResourceMetrics
{
    public double CpuUsagePercent { get; set; }
    public double MemoryUsagePercent { get; set; }
    public long MemoryUsedBytes { get; set; }
    public long DiskFreeBytes { get; set; }
    public int ThreadCount { get; set; }
    public int HandleCount { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// 降级配置
/// </summary>
public class DegradationConfig
{
    public double MildCpuThreshold { get; set; } = Constants.MildDegradationCpuThreshold;
    public double ModerateCpuThreshold { get; set; } = Constants.ModerateDegradationCpuThreshold;
    public double SevereCpuThreshold { get; set; } = Constants.SevereDegradationCpuThreshold;
    
    public double MildMemoryThreshold { get; set; } = Constants.MildDegradationMemoryThreshold;
    public double ModerateMemoryThreshold { get; set; } = Constants.ModerateDegradationMemoryThreshold;
    public double SevereMemoryThreshold { get; set; } = Constants.SevereDegradationMemoryThreshold;
    
    public TimeSpan CheckInterval { get; set; } = TimeSpan.FromSeconds(30);
    public TimeSpan RecoveryCooldown { get; set; } = TimeSpan.FromMinutes(2);
}

/// <summary>
/// 优雅降级管理器 - 资源紧张时自动降级服务
/// </summary>
public class DegradationManager : IDisposable
{
    private readonly ILogger<DegradationManager> _logger;
    private readonly DegradationConfig _config;
    private readonly PerformanceCounter? _cpuCounter;
    
    private DegradationLevel _currentLevel = DegradationLevel.None;
    private DateTime _lastRecoveryAttempt = DateTime.MinValue;
    private readonly object _lock = new();
    private System.Threading.Timer? _checkTimer;
    private bool _disposed;
    
    /// <summary>
    /// 降级级别变化事件
    /// </summary>
    public event EventHandler<DegradationLevelChangedEventArgs>? LevelChanged;
    
    /// <summary>
    /// 当前降级级别
    /// </summary>
    public DegradationLevel CurrentLevel => _currentLevel;
    
    /// <summary>
    /// 创建降级管理器
    /// </summary>
    public DegradationManager(
        ILogger<DegradationManager> logger,
        DegradationConfig? config = null)
    {
        _logger = logger;
        _config = config ?? new DegradationConfig();
        
        // 初始化性能计数器（仅Windows）
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            try
            {
                _cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                _cpuCounter.NextValue(); // 首次调用返回0，需要预热
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to initialize CPU performance counter");
            }
        }
        
        // 启动监控
        StartMonitoring();
    }
    
    /// <summary>
    /// 开始监控
    /// </summary>
    private void StartMonitoring()
    {
        _checkTimer = new System.Threading.Timer(_ => CheckAndUpdateLevel(), null, 
            TimeSpan.FromSeconds(5), _config.CheckInterval);
        _logger.LogInformation("Degradation manager started with check interval {Interval}s", 
            _config.CheckInterval.TotalSeconds);
    }
    
    /// <summary>
    /// 检查并更新降级级别
    /// </summary>
    private void CheckAndUpdateLevel()
    {
        try
        {
            var metrics = GetCurrentMetrics();
            var newLevel = CalculateLevel(metrics);
            
            if (newLevel != _currentLevel)
            {
                var now = DateTime.UtcNow;
                
                // 降级：立即执行
                if (newLevel > _currentLevel)
                {
                    UpdateLevel(newLevel, metrics);
                }
                // 恢复：需要冷却时间
                else if (newLevel < _currentLevel && now - _lastRecoveryAttempt > _config.RecoveryCooldown)
                {
                    _lastRecoveryAttempt = now;
                    UpdateLevel(newLevel, metrics);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to check degradation level");
        }
    }
    
    /// <summary>
    /// 获取当前系统资源指标
    /// </summary>
    private SystemResourceMetrics GetCurrentMetrics()
    {
        var metrics = new SystemResourceMetrics();
        
        // CPU 使用率
        if (_cpuCounter != null)
        {
            try
            {
                metrics.CpuUsagePercent = _cpuCounter.NextValue();
            }
            catch
            {
                metrics.CpuUsagePercent = GetCpuUsageByProcess();
            }
        }
        else
        {
            metrics.CpuUsagePercent = GetCpuUsageByProcess();
        }
        
        // 内存使用率
        var process = Process.GetCurrentProcess();
        metrics.MemoryUsedBytes = process.WorkingSet64;
        metrics.MemoryUsagePercent = (double)process.WorkingSet64 / GC.GetTotalMemory(false) * 100;
        
        // 线程数
        metrics.ThreadCount = process.Threads.Count;
        
        // 句柄数
        metrics.HandleCount = process.HandleCount;
        
        // 磁盘空间
        try
        {
            var drive = Path.GetPathRoot(AppDomain.CurrentDomain.BaseDirectory);
            if (drive != null)
            {
                var driveInfo = new DriveInfo(drive);
                metrics.DiskFreeBytes = driveInfo.AvailableFreeSpace;
            }
        }
        catch
        {
            metrics.DiskFreeBytes = long.MaxValue;
        }
        
        metrics.Timestamp = DateTime.UtcNow;
        
        return metrics;
    }
    
    /// <summary>
    /// 通过进程获取 CPU 使用率
    /// </summary>
    private static double GetCpuUsageByProcess()
    {
        try
        {
            var process = Process.GetCurrentProcess();
            var startTime = DateTime.UtcNow;
            var startCpu = process.TotalProcessorTime;
            
            Thread.Sleep(100);
            
            var endTime = DateTime.UtcNow;
            var endCpu = process.TotalProcessorTime;
            
            var cpuUsed = (endCpu - startCpu).TotalMilliseconds;
            var total = (endTime - startTime).TotalMilliseconds;
            
            return (cpuUsed / (total * Environment.ProcessorCount)) * 100;
        }
        catch
        {
            return 0;
        }
    }
    
    /// <summary>
    /// 根据资源指标计算降级级别
    /// </summary>
    private DegradationLevel CalculateLevel(SystemResourceMetrics metrics)
    {
        var cpuExceeded = metrics.CpuUsagePercent > _config.SevereCpuThreshold;
        var memoryExceeded = metrics.MemoryUsagePercent > _config.SevereMemoryThreshold;
        
        if (cpuExceeded || memoryExceeded)
            return DegradationLevel.Severe;
        
        cpuExceeded = metrics.CpuUsagePercent > _config.ModerateCpuThreshold;
        memoryExceeded = metrics.MemoryUsagePercent > _config.ModerateMemoryThreshold;
        
        if (cpuExceeded || memoryExceeded)
            return DegradationLevel.Moderate;
        
        cpuExceeded = metrics.CpuUsagePercent > _config.MildCpuThreshold;
        memoryExceeded = metrics.MemoryUsagePercent > _config.MildMemoryThreshold;
        
        if (cpuExceeded || memoryExceeded)
            return DegradationLevel.Mild;
        
        return DegradationLevel.None;
    }
    
    /// <summary>
    /// 更新降级级别
    /// </summary>
    private void UpdateLevel(DegradationLevel newLevel, SystemResourceMetrics metrics)
    {
        var oldLevel = _currentLevel;
        _currentLevel = newLevel;
        
        _logger.LogWarning(
            "Degradation level changed from {OldLevel} to {NewLevel} | CPU: {Cpu:F1}%, Memory: {Memory:F1}%, Handles: {Handles}",
            oldLevel, newLevel, metrics.CpuUsagePercent, metrics.MemoryUsagePercent, metrics.HandleCount);
        
        LevelChanged?.Invoke(this, new DegradationLevelChangedEventArgs
        {
            OldLevel = oldLevel,
            NewLevel = newLevel,
            Metrics = metrics
        });
    }
    
    /// <summary>
    /// 强制设置降级级别（手动干预）
    /// </summary>
    public void ForceLevel(DegradationLevel level)
    {
        lock (_lock)
        {
            if (level != _currentLevel)
            {
                _logger.LogWarning("Forcing degradation level from {OldLevel} to {NewLevel}", 
                    _currentLevel, level);
                _currentLevel = level;
            }
        }
    }
    
    /// <summary>
    /// 检查是否应该降级某项功能
    /// </summary>
    public bool ShouldDegrade(string feature, DegradationLevel requiredLevel)
    {
        return _currentLevel >= requiredLevel;
    }
    
    /// <summary>
    /// 获取当前降级建议
    /// </summary>
    public DegradationSuggestions GetSuggestions()
    {
        return new DegradationSuggestions
        {
            Level = _currentLevel,
            ReduceRecordingFps = _currentLevel >= DegradationLevel.Mild,
            ReduceScreenshotFrequency = _currentLevel >= DegradationLevel.Moderate,
            PauseScreenshots = _currentLevel >= DegradationLevel.Moderate,
            ReduceUploadConcurrency = _currentLevel >= DegradationLevel.Mild,
            PauseActivityMonitoring = _currentLevel >= DegradationLevel.Severe,
            PauseScreenshotsCompletely = _currentLevel >= DegradationLevel.Severe
        };
    }
    
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        
        _checkTimer?.Dispose();
        _cpuCounter?.Dispose();
        
        _logger.LogInformation("Degradation manager disposed");
    }
}

/// <summary>
/// 降级级别变化事件参数
/// </summary>
public class DegradationLevelChangedEventArgs : EventArgs
{
    public DegradationLevel OldLevel { get; set; }
    public DegradationLevel NewLevel { get; set; }
    public SystemResourceMetrics Metrics { get; set; } = null!;
}

/// <summary>
/// 降级建议
/// </summary>
public class DegradationSuggestions
{
    public DegradationLevel Level { get; set; }
    public bool ReduceRecordingFps { get; set; }
    public bool ReduceScreenshotFrequency { get; set; }
    public bool PauseScreenshots { get; set; }
    public bool ReduceUploadConcurrency { get; set; }
    public bool PauseActivityMonitoring { get; set; }
    public bool PauseScreenshotsCompletely { get; set; }
}
/// <summary>
/// 幂等性服务 - 防止重复执行
/// </summary>
public class IdempotencyService : IDisposable
{
    private readonly IMemoryCache _cache;
    private readonly ILogger<IdempotencyService> _logger;
    private readonly TimeSpan _defaultTtl;
    private readonly SemaphoreSlim _lock = new(1, 1);
    private bool _disposed;
    private int _approximateCount;
    
    /// <summary>
    /// 创建幂等性服务实例
    /// </summary>
    public IdempotencyService(
        ILogger<IdempotencyService> logger,
        TimeSpan? defaultTtl = null)
    {
        _logger = logger;
        _defaultTtl = defaultTtl ?? TimeSpan.FromMinutes(5);
        _cache = new MemoryCache(new MemoryCacheOptions
        {
            SizeLimit = 10000,
            ExpirationScanFrequency = TimeSpan.FromMinutes(1)
        });
    }
    
    /// <summary>
    /// 幂等执行（带缓存结果）
    /// </summary>
    public async Task<T> ExecuteAsync<T>(
        string operationId,
        Func<Task<T>> action,
        T? fallback = default,
        TimeSpan? ttl = null)
    {
        if (string.IsNullOrWhiteSpace(operationId))
        {
            _logger.LogWarning("OperationId is null or empty, skipping idempotency");
            return await action();
        }
        
        var cacheKey = $"idempotent:{operationId}";
        
        // 检查是否已执行
        if (_cache.TryGetValue(cacheKey, out CacheEntry<T>? cached) && cached != null)
        {
            _logger.LogDebug("Idempotent operation {OperationId} already executed, returning cached result", operationId);
            return cached.Result;
        }
        
        // 执行操作
        T result;
        try
        {
            result = await action();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Idempotent operation {OperationId} failed", operationId);
            if (fallback != null)
            {
                return fallback;
            }
            throw;
        }
        
        // 缓存结果
        var cacheOptions = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = ttl ?? _defaultTtl,
            Size = 1,
            Priority = CacheItemPriority.Normal
        };
        
        _cache.Set(cacheKey, new CacheEntry<T> { Result = result, ExecutedAt = DateTime.UtcNow }, cacheOptions);
        Interlocked.Increment(ref _approximateCount);
        
        _logger.LogDebug("Idempotent operation {OperationId} executed and cached", operationId);
        return result;
    }
    
    /// <summary>
    /// 幂等执行（无返回值）
    /// </summary>
    public async Task ExecuteAsync(
        string operationId,
        Func<Task> action,
        TimeSpan? ttl = null)
    {
        if (string.IsNullOrWhiteSpace(operationId))
        {
            _logger.LogWarning("OperationId is null or empty, skipping idempotency");
            await action();
            return;
        }
        
        var cacheKey = $"idempotent:{operationId}";
        
        // 检查是否已执行
        if (_cache.TryGetValue(cacheKey, out _))
        {
            _logger.LogDebug("Idempotent operation {OperationId} already executed, skipping", operationId);
            return;
        }
        
        // 执行操作
        try
        {
            await action();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Idempotent operation {OperationId} failed", operationId);
            throw;
        }
        
        // 标记已执行
        var cacheOptions = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = ttl ?? _defaultTtl,
            Size = 1
        };
        
        _cache.Set(cacheKey, true, cacheOptions);
        _logger.LogDebug("Idempotent operation {OperationId} executed and marked", operationId);
    }
    
    /// <summary>
    /// 检查操作是否已执行
    /// </summary>
    public bool IsExecuted(string operationId)
    {
        if (string.IsNullOrWhiteSpace(operationId))
            return false;
        
        var cacheKey = $"idempotent:{operationId}";
        return _cache.TryGetValue(cacheKey, out _);
    }
    
    /// <summary>
    /// 清除指定操作的缓存
    /// </summary>
    public void Clear(string operationId)
    {
        if (string.IsNullOrWhiteSpace(operationId))
            return;
        
        var cacheKey = $"idempotent:{operationId}";
        _cache.Remove(cacheKey);
        _logger.LogDebug("Cleared idempotent cache for {OperationId}", operationId);
    }
    
    /// <summary>
    /// 清除所有缓存
    /// </summary>
    public void ClearAll()
    {
        if (_cache is MemoryCache memoryCache)
        {
            memoryCache.Compact(1.0);
            _logger.LogInformation("Cleared all idempotent cache");
        }
    }
    
    /// <summary>
    /// 获取缓存统计
    /// </summary>
    public IdempotencyStats GetStats()
    {
        return new IdempotencyStats
        {
            ApproximateCount = _approximateCount,
            DefaultTtl = _defaultTtl
        };
    }
    
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _cache.Dispose();
        _lock.Dispose();
    }
    
    private class CacheEntry<T>
    {
        public T Result { get; set; } = default!;
        public DateTime ExecutedAt { get; set; }
    }
}

/// <summary>
/// 幂等性统计信息
/// </summary>
public class IdempotencyStats
{
    public int ApproximateCount { get; set; }
    public TimeSpan DefaultTtl { get; set; }
}
/// <summary>
/// 重试策略工厂 - 提供统一的重试配置
/// </summary>
public static class RetryPolicies
{
    /// <summary>
    /// 判断 HTTP 响应是否应触发 Polly 重试（401/403 不重试，交由业务层 refresh）
    /// </summary>
    public static bool ShouldRetryHttpResponse(HttpResponseMessage response)
    {
        if (response.IsSuccessStatusCode)
            return false;

        if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            return false;

        return true;
    }

    /// <summary>
    /// 获取 HTTP 请求重试策略（指数退避）
    /// </summary>
    public static AsyncRetryPolicy<HttpResponseMessage> GetHttpRetryPolicy(
        int retryCount = Constants.MaxRetryCount,
        ILogger? logger = null)
    {
        return Polly.Policy
            .HandleResult<HttpResponseMessage>(ShouldRetryHttpResponse)
            .Or<HttpRequestException>()
            .Or<TaskCanceledException>()
            .WaitAndRetryAsync(
                retryCount,
                retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    if (logger != null)
                    {
                        var exception = outcome.Exception;
                        var errorMsg = outcome.Exception?.Message ??
                                       outcome.Result?.StatusCode.ToString() ??
                                       "Unknown error";
                        
                        LogHttpRetry(logger, exception, retryCount, timespan.TotalMilliseconds, errorMsg);
                    }
                });
    }
    
    private static void LogHttpRetry(ILogger logger, Exception? exception, int retryCount, double delayMs, string errorMsg)
    {
        logger.LogWarning(
            exception,
            "HTTP request failed (retry {RetryCount}/{MaxRetries}) after {Delay}ms: {Error}",
            retryCount, Constants.MaxRetryCount, delayMs, errorMsg);
    }
    
    /// <summary>
    /// 获取数据库操作重试策略（固定间隔）
    /// </summary>
    public static AsyncRetryPolicy GetDatabaseRetryPolicy(
        int retryCount = 3,
        ILogger? logger = null)
    {
        return Polly.Policy
            .Handle<Microsoft.Data.Sqlite.SqliteException>(ex => ex.SqliteErrorCode == 5)
            .Or<TimeoutException>()
            .WaitAndRetryAsync(
                retryCount,
                retryAttempt => TimeSpan.FromMilliseconds(100 * retryAttempt),
                onRetry: (ex, timespan, retryCount, context) =>
                {
                    if (logger != null)
                    {
                        LogDatabaseRetry(logger, ex, retryCount);
                    }
                });
    }
    
    private static void LogDatabaseRetry(ILogger logger, Exception ex, int retryCount)
    {
        logger.LogWarning(
            ex,
            "Database operation failed (retry {RetryCount}/{MaxRetries})",
            retryCount, Constants.MaxRetryCount);
    }
    
    /// <summary>
    /// 获取文件操作重试策略
    /// </summary>
    public static AsyncRetryPolicy GetFileOperationRetryPolicy(
        int retryCount = 3,
        ILogger? logger = null)
    {
        return Polly.Policy
            .Handle<IOException>()
            .Or<UnauthorizedAccessException>()
            .WaitAndRetryAsync(
                retryCount,
                retryAttempt => TimeSpan.FromMilliseconds(50 * retryAttempt),
                onRetry: (ex, timespan, retryCount, context) =>
                {
                    if (logger != null)
                    {
                        LogFileRetry(logger, ex, retryCount);
                    }
                });
    }
    
    private static void LogFileRetry(ILogger logger, Exception ex, int retryCount)
    {
        logger.LogDebug(
            ex,
            "File operation failed (retry {RetryCount}/{MaxRetries})",
            retryCount, Constants.MaxRetryCount);
    }
    
    /// <summary>
    /// 获取 WebSocket 重连策略（指数退避，有限次数）
    /// </summary>
    public static AsyncRetryPolicy GetWebSocketReconnectPolicy(
        int maxAttempts = Constants.MaxWebSocketReconnectAttempts,
        ILogger? logger = null)
    {
        return Polly.Policy
            .Handle<Exception>()
            .WaitAndRetryAsync(
                maxAttempts,
                retryAttempt => TimeSpan.FromSeconds(Math.Min(Math.Pow(2, retryAttempt), 60)),
                onRetry: (ex, timespan, retryCount, context) =>
                {
                    if (logger != null)
                    {
                        LogWebSocketRetry(logger, ex, retryCount, maxAttempts, timespan.TotalSeconds);
                    }
                });
    }
    
    private static void LogWebSocketRetry(ILogger logger, Exception ex, int retryCount, int maxAttempts, double delaySec)
    {
        logger.LogWarning(
            ex,
            "WebSocket reconnection attempt {RetryCount}/{MaxAttempts} after {Delay}s",
            retryCount, maxAttempts, delaySec);
    }
    
    /// <summary>
    /// 获取带超时的复合策略
    /// </summary>
    public static IAsyncPolicy<HttpResponseMessage> GetTimeoutRetryWrap(
        TimeSpan timeout,
        int retryCount = Constants.MaxRetryCount,
        ILogger? logger = null)
    {
        var timeoutPolicy = Polly.Policy.TimeoutAsync<HttpResponseMessage>(timeout, TimeoutStrategy.Pessimistic);
        var retryPolicy = GetHttpRetryPolicy(retryCount, logger);
        
        return retryPolicy.WrapAsync(timeoutPolicy);
    }
    
    /// <summary>
    /// 获取断路器包装的重试策略
    /// </summary>
    public static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerRetryWrap(
        int retryCount = Constants.MaxRetryCount,
        ILogger? logger = null)
    {
        var retryPolicy = GetHttpRetryPolicy(retryCount, logger);
        
        var circuitBreakerPolicy = Polly.Policy
            .Handle<Exception>()
            .CircuitBreakerAsync(
                exceptionsAllowedBeforeBreaking: Constants.CircuitBreakerFailureThreshold,
                durationOfBreak: TimeSpan.FromSeconds(Constants.CircuitBreakerOpenDurationSeconds),
                onBreak: (ex, duration) =>
                {
                    if (logger != null)
                    {
                        LogCircuitBreakerOpen(logger, ex, duration.TotalSeconds);
                    }
                },
                onReset: () =>
                {
                    if (logger != null)
                    {
                        logger.LogInformation("Circuit breaker reset");
                    }
                },
                onHalfOpen: () =>
                {
                    if (logger != null)
                    {
                        logger.LogDebug("Circuit breaker half-open");
                    }
                });
        
        return retryPolicy.WrapAsync(circuitBreakerPolicy);
    }
    
    private static void LogCircuitBreakerOpen(ILogger logger, Exception ex, double durationSec)
    {
        logger.LogWarning(
            ex,
            "Circuit breaker opened for {Duration}s",
            durationSec);
    }
    
    /// <summary>
    /// 获取带熔断的批量操作策略
    /// </summary>
    public static AsyncPolicy GetBulkheadPolicy(
        int maxParallelization = 5,
        int maxQueuingActions = 100)
    {
        return Polly.Policy.BulkheadAsync(maxParallelization, maxQueuingActions);
    }
    
    /// <summary>
    /// 获取兜底策略（Fallback）
    /// </summary>
    public static AsyncPolicy<T> GetFallbackPolicy<T>(
        T fallbackValue,
        Func<Exception, bool>? shouldFallback = null,
        ILogger? logger = null)
    {
        return Polly.Policy<T>
            .Handle<Exception>(ex => shouldFallback?.Invoke(ex) ?? true)
            .FallbackAsync(
                fallbackValue,
                onFallbackAsync: (outcome, ct) =>
                {
                    if (logger != null)
                    {
                        // ✅ 修复：从 outcome 中提取 Exception
                        var exception = outcome.Exception;
                        LogFallbackTriggered(logger, exception);
                    }
                    return Task.CompletedTask;
                });
    }
    
    private static void LogFallbackTriggered(ILogger logger, Exception? exception)
    {
        logger.LogWarning(
            exception,
            "Fallback triggered, returning default value");
    }
}

/// <summary>
/// 重试上下文扩展
/// </summary>
public static class RetryContextExtensions
{
    private const string RetryCountKey = "RetryCount";
    
    public static void IncrementRetryCount(this Polly.Context context)
    {
        if (context == null) return;
        
        if (context.TryGetValue(RetryCountKey, out var value) && value is int count)
        {
            context[RetryCountKey] = count + 1;
        }
        else
        {
            context[RetryCountKey] = 1;
        }
    }
    
    public static int GetRetryCount(this Polly.Context context)
    {
        if (context == null) return 0;
        
        if (context.TryGetValue(RetryCountKey, out var value) && value is int count)
        {
            return count;
        }
        return 0;
    }
}

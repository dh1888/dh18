using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EnterpriseAgent.Agent.RemoteView;

public interface IRemoteViewPublisher
{
    bool IsPublishing { get; }
    string? ActiveSessionId { get; }
    RemoteViewStats GetStats();
    Task StartPublishAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default);
    Task StopPublishAsync(CancellationToken cancellationToken = default);
}

public sealed class RemoteViewConfig
{
    public bool Enabled { get; set; } = true;
    public int TargetWidth { get; set; } = 1920;
    public int TargetHeight { get; set; } = 1080;
    public int TargetFps { get; set; } = 15;
    public int VideoBitrateKbps { get; set; } = 2500;
}

public sealed class RemoteViewStartParams
{
    public string SessionId { get; init; } = "";
    public string RoomName { get; init; } = "";
    public string LiveKitUrl { get; init; } = "";
    public string RtmpUrl { get; init; } = "";
    public int Width { get; init; } = 1920;
    public int Height { get; init; } = 1080;
    public int Fps { get; init; } = 15;
}

public sealed class RemoteViewStats
{
    public int Fps { get; set; }
    public int BitrateKbps { get; set; }
    public string Encoder { get; set; } = "libx264";
    public bool IsPublishing { get; set; }
    public string? SessionId { get; set; }
}

/// <summary>
/// 通过 FFmpeg gdigrab + H264 推流到 LiveKit RTMP Ingress。
/// </summary>
public sealed class FfmpegRtmpPublisher : IRemoteViewPublisher, IDisposable
{
    private static readonly TimeSpan PublishReadyMinStable = TimeSpan.FromSeconds(2);
    private static readonly TimeSpan PublishReadyMaxWait = TimeSpan.FromSeconds(8);

    private readonly ILogger<FfmpegRtmpPublisher> _logger;
    private readonly RemoteViewConfig _config;
    private readonly object _gate = new();
    private Process? _ffmpegProcess;
    private RemoteViewStartParams? _activeParams;
    private string _encoder = "libx264";
    private int _frameCount;
    private DateTime _statsSinceUtc = DateTime.UtcNow;
    private bool _disposed;

    public event Func<string?, string, Task>? PublishFailed;

    public FfmpegRtmpPublisher(
        ILogger<FfmpegRtmpPublisher> logger,
        IOptions<RemoteViewConfig> options)
    {
        _logger = logger;
        _config = options.Value;
    }

    public bool IsPublishing
    {
        get
        {
            lock (_gate)
            {
                return _ffmpegProcess is { HasExited: false };
            }
        }
    }

    public string? ActiveSessionId
    {
        get
        {
            lock (_gate)
            {
                return _activeParams?.SessionId;
            }
        }
    }

    public RemoteViewStats GetStats()
    {
        lock (_gate)
        {
            var elapsed = Math.Max((DateTime.UtcNow - _statsSinceUtc).TotalSeconds, 1);
            var measuredFps = (int)Math.Round(_frameCount / elapsed);
            var configuredFps = _activeParams?.Fps ?? _config.TargetFps;

            return new RemoteViewStats
            {
                Fps = measuredFps > 0 ? measuredFps : configuredFps,
                BitrateKbps = _config.VideoBitrateKbps,
                Encoder = _encoder,
                IsPublishing = IsPublishing,
                SessionId = _activeParams?.SessionId,
            };
        }
    }

    public async Task StartPublishAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(parameters);
        if (string.IsNullOrWhiteSpace(parameters.RtmpUrl))
            throw new InvalidOperationException("RTMP URL is required");

        await StopPublishAsync(cancellationToken);

        var ffmpeg = FindFfmpeg();
        if (string.IsNullOrWhiteSpace(ffmpeg))
            throw new InvalidOperationException("ffmpeg.exe not found");

        _encoder = DetectEncoder(ffmpeg);
        var width = parameters.Width > 0 ? parameters.Width : _config.TargetWidth;
        var height = parameters.Height > 0 ? parameters.Height : _config.TargetHeight;
        var fps = parameters.Fps > 0 ? parameters.Fps : _config.TargetFps;
        var bitrate = _config.VideoBitrateKbps;

        var args = BuildFfmpegArgs(ffmpeg, _encoder, width, height, fps, bitrate, parameters.RtmpUrl);
        _logger.LogInformation(
            "Starting remote view publish session={SessionId} room={Room} encoder={Encoder} {Width}x{Height}@{Fps}",
            parameters.SessionId, parameters.RoomName, _encoder, width, height, fps);

        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = ffmpeg,
                Arguments = args,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true,
            },
            EnableRaisingEvents = true,
        };

        process.ErrorDataReceived += (_, e) =>
        {
            if (string.IsNullOrWhiteSpace(e.Data))
                return;
            if (e.Data.Contains("frame=", StringComparison.Ordinal))
                Interlocked.Increment(ref _frameCount);
            _logger.LogDebug("ffmpeg: {Line}", e.Data);
        };

        _frameCount = 0;
        _statsSinceUtc = DateTime.UtcNow;

        if (!process.Start())
            throw new InvalidOperationException("Failed to start ffmpeg process");

        process.BeginErrorReadLine();

        lock (_gate)
        {
            _ffmpegProcess = process;
            _activeParams = parameters;
        }

        await WaitForPublishReadyAsync(process, cancellationToken);

        _ = Task.Run(async () =>
        {
            string? sessionId;
            lock (_gate)
            {
                sessionId = _activeParams?.SessionId;
            }

            try
            {
                await process.WaitForExitAsync(cancellationToken);
                if (process.ExitCode != 0)
                {
                    _logger.LogWarning("FFmpeg remote view exited with code {Code}", process.ExitCode);
                    await RaisePublishFailedAsync(sessionId, $"ffmpeg exited with code {process.ExitCode}");
                }
            }
            catch (OperationCanceledException)
            {
                // ignore
            }
            finally
            {
                lock (_gate)
                {
                    if (ReferenceEquals(_ffmpegProcess, process))
                    {
                        _ffmpegProcess = null;
                        _activeParams = null;
                    }
                }
            }
        }, CancellationToken.None);
    }

    public Task StopPublishAsync(CancellationToken cancellationToken = default)
    {
        Process? process;
        lock (_gate)
        {
            process = _ffmpegProcess;
            _ffmpegProcess = null;
            _activeParams = null;
        }

        if (process == null)
            return Task.CompletedTask;

        try
        {
            if (!process.HasExited)
            {
                try
                {
                    if (process.StartInfo.RedirectStandardInput)
                        process.StandardInput.Close();
                }
                catch
                {
                    // ignore when stdin not redirected
                }

                if (!process.WaitForExit(3000))
                {
                    process.Kill(entireProcessTree: true);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to stop ffmpeg remote view process");
        }
        finally
        {
            process.Dispose();
        }

        return Task.CompletedTask;
    }

    private static async Task WaitForPublishReadyAsync(Process process, CancellationToken cancellationToken)
    {
        var started = DateTime.UtcNow;
        while (DateTime.UtcNow - started < PublishReadyMaxWait)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (process.HasExited)
                throw new InvalidOperationException($"ffmpeg exited early with code {process.ExitCode}");

            if (DateTime.UtcNow - started >= PublishReadyMinStable)
                return;

            await Task.Delay(200, cancellationToken);
        }

        throw new TimeoutException("ffmpeg did not become ready for RTMP publish in time");
    }

    private async Task RaisePublishFailedAsync(string? sessionId, string detail)
    {
        var handler = PublishFailed;
        if (handler == null)
            return;

        try
        {
            await handler(sessionId, detail);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "PublishFailed handler error");
        }
    }

    private static string BuildFfmpegArgs(
        string ffmpeg,
        string encoder,
        int width,
        int height,
        int fps,
        int bitrateKbps,
        string rtmpUrl)
    {
        _ = ffmpeg;
        var gop = Math.Max(fps * 2, 30);
        var encoderArgs = encoder switch
        {
            "h264_nvenc" => $"-c:v h264_nvenc -preset p4 -profile:v baseline -rc cbr -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bitrateKbps * 2}k",
            "h264_qsv" => $"-c:v h264_qsv -profile:v baseline -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bitrateKbps * 2}k",
            "h264_amf" => $"-c:v h264_amf -profile:v baseline -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bitrateKbps * 2}k",
            _ => $"-c:v libx264 -preset veryfast -tune zerolatency -profile:v baseline -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bitrateKbps * 2}k",
        };

        var sb = new StringBuilder();
        sb.Append("-hide_banner -loglevel warning ");
        sb.Append($"-f gdigrab -framerate {fps} -offset_x 0 -offset_y 0 -video_size {width}x{height} -i desktop ");
        sb.Append(encoderArgs).Append(' ');
        sb.Append($"-pix_fmt yuv420p -g {gop} -keyint_min {gop} ");
        sb.Append("-f flv ");
        sb.Append('"').Append(rtmpUrl.Replace("\"", "\\\"")).Append('"');
        return sb.ToString();
    }

    private static string? FindFfmpeg()
    {
        var paths = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "ffmpeg.exe"),
            Path.Combine(AppContext.BaseDirectory, "bin", "ffmpeg.exe"),
            @"C:\ffmpeg\bin\ffmpeg.exe",
            @"C:\Program Files\ffmpeg\bin\ffmpeg.exe",
        };

        foreach (var path in paths)
        {
            try
            {
                if (File.Exists(path))
                    return path;
            }
            catch
            {
                // ignore invalid paths
            }
        }

        var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (var dir in pathEnv.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var candidate = Path.Combine(dir, "ffmpeg.exe");
            try
            {
                if (File.Exists(candidate))
                    return candidate;
            }
            catch
            {
                // ignore
            }
        }

        return null;
    }

    private string DetectEncoder(string ffmpeg)
    {
        try
        {
            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffmpeg,
                    Arguments = "-hide_banner -encoders",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                }
            };
            process.Start();
            var output = process.StandardOutput.ReadToEnd();
            process.WaitForExit(5000);

            if (output.Contains("h264_nvenc", StringComparison.OrdinalIgnoreCase))
                return "h264_nvenc";
            if (output.Contains("h264_qsv", StringComparison.OrdinalIgnoreCase))
                return "h264_qsv";
            if (output.Contains("h264_amf", StringComparison.OrdinalIgnoreCase))
                return "h264_amf";
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Encoder detection failed");
        }

        return "libx264";
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        StopPublishAsync().GetAwaiter().GetResult();
    }
}

public sealed class RemoteViewSessionController
{
    private readonly ILogger<RemoteViewSessionController> _logger;
    private readonly IRemoteViewPublisher _publisher;
    private readonly RemoteViewConfig _config;
    private readonly IServiceProvider _serviceProvider;
    private readonly TimeSpan _statsInterval = TimeSpan.FromSeconds(5);
    private CancellationTokenSource? _statsCts;
    private Task? _statsTask;

    public RemoteViewSessionController(
        ILogger<RemoteViewSessionController> logger,
        IRemoteViewPublisher publisher,
        IOptions<RemoteViewConfig> options,
        IServiceProvider serviceProvider)
    {
        _logger = logger;
        _publisher = publisher;
        _config = options.Value;
        _serviceProvider = serviceProvider;

        if (publisher is FfmpegRtmpPublisher ffmpegPublisher)
        {
            ffmpegPublisher.PublishFailed += OnPublishFailedAsync;
        }
    }

    public async Task HandleStartAsync(JsonElement paramsElement, CancellationToken cancellationToken = default)
    {
        if (!_config.Enabled)
        {
            _logger.LogInformation("Remote view is disabled by configuration");
            return;
        }

        if (_publisher.IsPublishing)
        {
            _logger.LogInformation("Remote view already publishing, ignoring duplicate start");
            return;
        }

        EnsureDesktopCaptureAvailable();

        var startParams = ParseStartParams(paramsElement);
        try
        {
            await _publisher.StartPublishAsync(startParams, cancellationToken);
            await SendEventAsync(startParams.SessionId, "published");
            StartStatsLoop();
            _logger.LogInformation("Remote view publishing started for session {SessionId}", startParams.SessionId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to start remote view for session {SessionId}", startParams.SessionId);
            await _publisher.StopPublishAsync(cancellationToken);
            await SendEventAsync(startParams.SessionId, "failed", ex.Message);
        }
    }

    public async Task HandleStopAsync(JsonElement paramsElement = default, CancellationToken cancellationToken = default)
    {
        string? requestedSessionId = null;
        if (paramsElement.ValueKind == JsonValueKind.Object &&
            paramsElement.TryGetProperty("sessionId", out var sidProp))
        {
            requestedSessionId = sidProp.GetString();
        }

        var activeSessionId = _publisher.ActiveSessionId;
        if (!string.IsNullOrWhiteSpace(requestedSessionId) &&
            !string.IsNullOrWhiteSpace(activeSessionId) &&
            !string.Equals(requestedSessionId, activeSessionId, StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogInformation(
                "Ignoring stop for session {Requested} (active {Active})",
                requestedSessionId, activeSessionId);
            return;
        }

        var sessionId = activeSessionId ?? requestedSessionId;
        StopStatsLoop();
        await _publisher.StopPublishAsync(cancellationToken);
        await SendEventAsync(sessionId, "stopped");
        _logger.LogInformation("Remote view publishing stopped");
    }

    private void EnsureDesktopCaptureAvailable()
    {
        var recorder = _serviceProvider.GetService<Services.ScreenRecorderService>();
        if (recorder?.GetRecordingHealthSnapshot().ProcessAlive == true)
        {
            throw new InvalidOperationException(
                "Screen recording is active; remote view cannot share desktop capture");
        }
    }

    private async Task OnPublishFailedAsync(string? sessionId, string detail)
    {
        StopStatsLoop();
        await SendEventAsync(sessionId, "failed", detail);
    }

    private RemoteViewStartParams ParseStartParams(JsonElement element)
    {
        string GetString(string name) =>
            element.TryGetProperty(name, out var prop) ? prop.GetString() ?? "" : "";

        int GetInt(string name, int fallback) =>
            element.TryGetProperty(name, out var prop) && prop.TryGetInt32(out var value) ? value : fallback;

        return new RemoteViewStartParams
        {
            SessionId = GetString("sessionId"),
            RoomName = GetString("roomName"),
            LiveKitUrl = GetString("livekitUrl"),
            RtmpUrl = GetString("rtmpUrl"),
            Width = GetInt("width", 1920),
            Height = GetInt("height", 1080),
            Fps = GetInt("fps", 15),
        };
    }

    private void StartStatsLoop()
    {
        StopStatsLoop();
        _statsCts = new CancellationTokenSource();
        var token = _statsCts.Token;
        _statsTask = Task.Run(async () =>
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    if (_publisher.IsPublishing)
                    {
                        var stats = _publisher.GetStats();
                        await SendStatsAsync(stats, token);
                    }
                    await Task.Delay(_statsInterval, token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogDebug(ex, "Remote view stats loop error");
                }
            }
        }, token);
    }

    private void StopStatsLoop()
    {
        try
        {
            _statsCts?.Cancel();
        }
        catch
        {
            // ignore
        }
        finally
        {
            _statsCts?.Dispose();
            _statsCts = null;
            _statsTask = null;
        }
    }

    private Task SendStatsAsync(RemoteViewStats stats, CancellationToken cancellationToken)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "remote_view_stats",
            sessionId = stats.SessionId,
            fps = stats.Fps,
            bitrateKbps = stats.BitrateKbps,
            encoder = stats.Encoder,
        });
        return GetWebSocketService().SendMessageAsync(payload, cancellationToken);
    }

    private Task SendEventAsync(string? sessionId, string eventName, string? detail = null)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "remote_view_event",
            sessionId,
            @event = eventName,
            detail,
        });
        return GetWebSocketService().SendMessageAsync(payload);
    }

    private Services.WebSocketService GetWebSocketService() =>
        _serviceProvider.GetRequiredService<Services.WebSocketService>();
}


// agent/SignatureParityTest.cs
// 对拍测试：验证 C# Agent 与 Go 后端的签名一致

using System;
using System.Security.Cryptography;
using System.Text;

namespace EnterpriseAgent.Agent.Tests;

public class SignatureParityTest
{
    public class MockSignatureInput
    {
        public string Timestamp { get; set; } = string.Empty;
        public string Method { get; set; } = string.Empty;
        public string Path { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        public string Secret { get; set; } = string.Empty; // 64-char hex string (32 bytes)
    }

    /// <summary>
    /// 使用 C# 的逻辑计算签名（模拟 Signatures.cs::AddSignatureHeaders）
    /// </summary>
    public static string ComputeCSharpSignature(MockSignatureInput input)
    {
        // 计算 bodyHash
        using var sha = SHA256.Create();
        var bodyHash = sha.ComputeHash(Encoding.UTF8.GetBytes(input.Body));
        var bodyHashHex = Convert.ToHexString(bodyHash).ToLowerInvariant();

        // 构造 message
        var message = input.Timestamp + input.Method + input.Path + bodyHashHex;

        // 计算 HMAC
        var key = Encoding.UTF8.GetBytes(input.Secret);
        using var hmac = new HMACSHA256(key);
        var sig = hmac.ComputeHash(Encoding.UTF8.GetBytes(message));
        var signature = Convert.ToHexString(sig).ToLowerInvariant();

        return signature;
    }

    /// <summary>
    /// 输出详细的签名计算步骤
    /// </summary>
    public static void ComputeSignatureSteps()
    {
        var input = new MockSignatureInput
        {
            Timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ"),
            Method = "POST",
            Path = "/api/v1/upload/chunk",
            Body = @"{""uploadId"":""550e8400-e29b-41d4-a716-446655440000"",""chunkIndex"":0}",
            Secret = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
        };

        using var sha = SHA256.Create();
        var bodyHash = sha.ComputeHash(Encoding.UTF8.GetBytes(input.Body));
        var bodyHashHex = Convert.ToHexString(bodyHash).ToLowerInvariant();
        var message = input.Timestamp + input.Method + input.Path + bodyHashHex;

        var key = Encoding.UTF8.GetBytes(input.Secret);
        using var hmac = new HMACSHA256(key);
        var sig = hmac.ComputeHash(Encoding.UTF8.GetBytes(message));
        var signature = Convert.ToHexString(sig).ToLowerInvariant();

        Console.WriteLine("\n=== Detailed C# Signature Calculation ===");
        Console.WriteLine($"Timestamp: {input.Timestamp}");
        Console.WriteLine($"Method: {input.Method}");
        Console.WriteLine($"Path: {input.Path}");
        Console.WriteLine($"Body: {input.Body}");
        Console.WriteLine($"Secret (hex): {input.Secret}");
        Console.WriteLine("\n--- Step 1: Calculate Body Hash ---");
        Console.WriteLine($"SHA256(body) = {bodyHashHex}");
        Console.WriteLine("\n--- Step 2: Build Message ---");
        Console.WriteLine("Message = timestamp + method + path + bodyHash");
        Console.WriteLine($"Message = {message}");
        Console.WriteLine("\n--- Step 3: Calculate HMAC ---");
        Console.WriteLine($"HMAC-SHA256(message, secret) = {signature}");
        Console.WriteLine("\n--- Step 4: Convert to Lowercase Hex ---");
        Console.WriteLine($"Signature (lowercase) = {signature}");
    }

    /// <summary>
    /// 运行对拍测试
    /// </summary>
    public static void RunParityTests()
    {
        var mockInputs = new[]
        {
            new MockSignatureInput
            {
                Timestamp = "2026-06-13T14:30:45Z",
                Method = "POST",
                Path = "/api/v1/upload/chunk",
                Body = @"{""uploadId"":""550e8400-e29b-41d4-a716-446655440000"",""chunkIndex"":0,""totalChunks"":5}",
                Secret = "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1f2"
            },
            new MockSignatureInput
            {
                Timestamp = "2026-06-13T14:30:50Z",
                Method = "POST",
                Path = "/api/v1/upload/complete",
                Body = @"{""uploadId"":""550e8400-e29b-41d4-a716-446655440000"",""deviceId"":""e8c7b3f9-4d3e-4c5a-8a2c-5d5d5d5d5d5d""}",
                Secret = "f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a698"
            },
            new MockSignatureInput
            {
                Timestamp = "2026-06-13T14:31:00Z",
                Method = "GET",
                Path = "/api/v1/devices/verify",
                Body = "",
                Secret = "0102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f20"
            }
        };

        for (int i = 0; i < mockInputs.Length; i++)
        {
            var input = mockInputs[i];
            var csharpSig = ComputeCSharpSignature(input);
            Console.WriteLine($"\n=== Test Case {i + 1} ===");
            Console.WriteLine("Input:");
            Console.WriteLine($"  Timestamp: {input.Timestamp}");
            Console.WriteLine($"  Method: {input.Method}");
            Console.WriteLine($"  Path: {input.Path}");
            Console.WriteLine($"  Body: {input.Body}");
            Console.WriteLine($"  Secret: {input.Secret}");
            Console.WriteLine("\nC# Signature:");
            Console.WriteLine($"  {csharpSig}");

            // 计算中间步骤
            using var sha = SHA256.Create();
            var bodyHash = sha.ComputeHash(Encoding.UTF8.GetBytes(input.Body));
            var bodyHashHex = Convert.ToHexString(bodyHash).ToLowerInvariant();
            var message = input.Timestamp + input.Method + input.Path + bodyHashHex;
            Console.WriteLine("\nIntermediate:");
            Console.WriteLine($"  Body Hash (hex): {bodyHashHex}");
            Console.WriteLine($"  Message: {message}");
        }
    }

    public static void Main()
    {
        Console.WriteLine("=== C# Agent Signature Test ===");
        RunParityTests();
        ComputeSignatureSteps();
    }
}

// Storage/ScreenshotRepository.cs - 优化版

using EnterpriseAgent.Agent.Models;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Storage;

public class ScreenshotRepository
{
    private readonly SqliteDbContext _db;
    private readonly ILogger<ScreenshotRepository> _logger;

    public ScreenshotRepository(SqliteDbContext db, ILogger<ScreenshotRepository> logger)
    {
        _db = db;
        _logger = logger;
    }

    /// <summary>
    /// 按本地文件路径查找已有截图记录（入库幂等）。
    /// </summary>
    public async Task<Screenshot?> GetByFilePathAsync(string filePath)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT id, device_id, captured_at, file_path, file_size, uploaded, encrypted, upload_id 
            FROM screenshots 
            WHERE file_path = @fp
            ORDER BY created_at DESC
            LIMIT 1", conn);

        cmd.Parameters.AddWithValue("@fp", filePath);

        using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync())
            return null;

        return new Screenshot
        {
            Id = reader.GetString(0),
            DeviceId = reader.GetString(1),
            CapturedAt = DateTimeExtensions.FromIso8601String(reader.GetString(2)),
            FilePath = reader.GetString(3),
            FileSize = reader.GetInt64(4),
            Uploaded = reader.GetInt32(5) == 1,
            Encrypted = reader.GetInt32(6) == 1,
            UploadId = reader.IsDBNull(7) ? "" : reader.GetString(7)
        };
    }

    /// <summary>
    /// 添加截图记录
    /// </summary>
    public async Task AddAsync(Screenshot screenshot)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            INSERT INTO screenshots (id, device_id, captured_at, file_path, file_size, uploaded, encrypted, upload_id, created_at, updated_at)
            VALUES (@id, @did, @ca, @fp, @fs, @up, @enc, @uid, @created, @updated)", conn);
        
        cmd.Parameters.AddWithValue("@id", screenshot.Id);
        cmd.Parameters.AddWithValue("@did", screenshot.DeviceId);
        cmd.Parameters.AddWithValue("@ca", screenshot.CapturedAt.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@fp", screenshot.FilePath);
        cmd.Parameters.AddWithValue("@fs", screenshot.FileSize);
        cmd.Parameters.AddWithValue("@up", screenshot.Uploaded ? 1 : 0);
        cmd.Parameters.AddWithValue("@enc", screenshot.Encrypted ? 1 : 0);
        cmd.Parameters.AddWithValue("@uid", screenshot.UploadId ?? "");
        cmd.Parameters.AddWithValue("@created", DateTime.UtcNow.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
        
        await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 批量添加截图记录
    /// </summary>
    public async Task AddBatchAsync(IEnumerable<Screenshot> screenshots)
    {
        foreach (var screenshot in screenshots)
        {
            await _db.AddBatchOperationAsync(conn =>
            {
                using var cmd = new SqliteCommand(@"
                    INSERT OR REPLACE INTO screenshots (id, device_id, captured_at, file_path, file_size, uploaded, encrypted, upload_id, updated_at)
                    VALUES (@id, @did, @ca, @fp, @fs, @up, @enc, @uid, @updated)", conn);
                
                cmd.Parameters.AddWithValue("@id", screenshot.Id);
                cmd.Parameters.AddWithValue("@did", screenshot.DeviceId);
                cmd.Parameters.AddWithValue("@ca", screenshot.CapturedAt.ToIso8601StringBasic());
                cmd.Parameters.AddWithValue("@fp", screenshot.FilePath);
                cmd.Parameters.AddWithValue("@fs", screenshot.FileSize);
                cmd.Parameters.AddWithValue("@up", screenshot.Uploaded ? 1 : 0);
                cmd.Parameters.AddWithValue("@enc", screenshot.Encrypted ? 1 : 0);
                cmd.Parameters.AddWithValue("@uid", screenshot.UploadId ?? "");
                cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
                
                cmd.ExecuteNonQuery();
            });
        }
    }

    /// <summary>
    /// 更新上传状态
    /// </summary>
    public async Task UpdateUploadStatusAsync(string id, bool uploaded)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE screenshots 
            SET uploaded = @up, updated_at = @updated 
            WHERE id = @id", conn);
        
        cmd.Parameters.AddWithValue("@up", uploaded ? 1 : 0);
        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 更新上传 ID
    /// </summary>
    public async Task UpdateUploadIdAsync(string id, string uploadId)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE screenshots 
            SET upload_id = @uid, updated_at = @updated 
            WHERE id = @id", conn);
        
        cmd.Parameters.AddWithValue("@uid", uploadId);
        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// ✅ 获取未上传的截图记录（优化版：增加时间过滤，防止无限增长）
    /// </summary>
    public async Task<List<Screenshot>> GetUnuploadedAsync(int limit = 100)
    {
        var result = new List<Screenshot>();
        using var conn = _db.GetConnection();
        
        // ✅ 只查询最近7天的未上传记录，避免返回几年前的失败记录
        var sevenDaysAgo = DateTime.UtcNow.AddDays(-7).ToIso8601StringBasic();
        
        using var cmd = new SqliteCommand(@"
            SELECT id, device_id, captured_at, file_path, file_size, uploaded, encrypted, upload_id 
            FROM screenshots 
            WHERE uploaded = 0 
              AND captured_at > @cutoff
            ORDER BY captured_at ASC
            LIMIT @limit", conn);
        
        cmd.Parameters.AddWithValue("@cutoff", sevenDaysAgo);
        cmd.Parameters.AddWithValue("@limit", limit);
        
        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new Screenshot
            {
                Id = reader.GetString(0),
                DeviceId = reader.GetString(1),
                CapturedAt = DateTimeExtensions.FromIso8601String(reader.GetString(2)),
                FilePath = reader.GetString(3),
                FileSize = reader.GetInt64(4),
                Uploaded = reader.GetInt32(5) == 1,
                Encrypted = reader.GetInt32(6) == 1,
                UploadId = reader.IsDBNull(7) ? "" : reader.GetString(7)
            });
        }
        return result;
    }

    /// <summary>
    /// ✅ 获取指定设备的今日截图数量
    /// </summary>
    public async Task<int> GetTodayCountAsync(string deviceId)
    {
        var todayStart = DateTime.UtcNow.Date.ToIso8601StringBasic();
        
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT COUNT(*) FROM screenshots 
            WHERE device_id = @did AND captured_at >= @today", conn);
        
        cmd.Parameters.AddWithValue("@did", deviceId);
        cmd.Parameters.AddWithValue("@today", todayStart);
        
        return Convert.ToInt32(await cmd.ExecuteScalarAsync());
    }

    /// <summary>
    /// ✅ 删除指定日期前的截图记录
    /// </summary>
    public async Task<int> DeleteOlderThanAsync(DateTime cutoff)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand("DELETE FROM screenshots WHERE captured_at < @cut", conn);
        cmd.Parameters.AddWithValue("@cut", cutoff.ToIso8601StringBasic());
        var deleted = await cmd.ExecuteNonQueryAsync();
        
        if (deleted > 0)
        {
            _logger.LogDebug("Deleted {Count} old screenshot records older than {Cutoff}", 
                deleted, cutoff.ToIso8601StringBasic());
        }
        
        return deleted;
    }

    /// <summary>
    /// ✅ 获取统计信息
    /// </summary>
    public async Task<(int total, int uploaded, int pending)> GetStatsAsync(string deviceId)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN uploaded = 1 THEN 1 ELSE 0 END) as uploaded,
                SUM(CASE WHEN uploaded = 0 THEN 1 ELSE 0 END) as pending
            FROM screenshots 
            WHERE device_id = @did", conn);
        
        cmd.Parameters.AddWithValue("@did", deviceId);
        
        using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            return (
                reader.GetInt32(0),
                reader.GetInt32(1),
                reader.GetInt32(2)
            );
        }
        return (0, 0, 0);
    }
    
    /// <summary>
    /// ✅ 清理超旧的未上传记录（超过30天未上传的标记为失败）
    /// </summary>
    public async Task<int> MarkStalePendingAsFailedAsync()
    {
        var thirtyDaysAgo = DateTime.UtcNow.AddDays(-30).ToIso8601StringBasic();
        
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE screenshots 
            SET uploaded = 1, updated_at = @updated 
            WHERE uploaded = 0 
              AND captured_at < @cutoff", conn);
        
        cmd.Parameters.AddWithValue("@cutoff", thirtyDaysAgo);
        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601StringBasic());
        
        var updated = await cmd.ExecuteNonQueryAsync();
        
        if (updated > 0)
        {
            _logger.LogWarning("Marked {Count} stale screenshot records as failed (older than 30 days)", updated);
        }
        
        return updated;
    }
}
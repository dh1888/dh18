// Extensions/Common.cs - 扩展方法合并（ServiceExtensions、LoggerExtensions、EncryptedConfigServiceExtensions）

using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Resilience;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Services;
using EnterpriseAgent.Agent.Storage;
using Polly;

namespace EnterpriseAgent.Agent.Extensions;

#region ServiceExtensions

/// <summary>
/// 服务注册扩展方法
/// </summary>
public static class ServiceExtensions
{
    /// <summary>
    /// 添加所有仓储服务
    /// </summary>
    public static IServiceCollection AddRepositories(this IServiceCollection services)
    {
        services.AddScoped<RecordingRepository>();
        services.AddScoped<ScreenshotRepository>();
        services.AddScoped<ActivityRepository>();
        services.AddScoped<UploadQueueRepository>();
        services.AddScoped<PolicyRepository>();
        
        return services;
    }
    
    /// <summary>
    /// 添加所有后台服务
    /// </summary>
    public static IServiceCollection AddBackgroundServices(this IServiceCollection services)
    {
        // 注意：FileUploadService 需要先注册为 Singleton，再注册为 HostedService
        services.AddSingleton<FileUploadService>();
        services.AddHostedService(sp => sp.GetRequiredService<FileUploadService>());
        
        services.AddSingleton<DeviceRegistrationService>();
        services.AddHostedService(sp => sp.GetRequiredService<DeviceRegistrationService>());
        
        services.AddSingleton<ScreenRecorderService>();
        services.AddHostedService(sp => sp.GetRequiredService<ScreenRecorderService>());
        
        services.AddSingleton<ScreenshotService>();
        services.AddHostedService(sp => sp.GetRequiredService<ScreenshotService>());
        
        services.AddSingleton<ActivityMonitorService>();
        services.AddHostedService(sp => sp.GetRequiredService<ActivityMonitorService>());
        
        services.AddSingleton<CleanupService>();
        services.AddHostedService(sp => sp.GetRequiredService<CleanupService>());
        
        services.AddSingleton<WebSocketService>();
        services.AddHostedService(sp => sp.GetRequiredService<WebSocketService>());
        
        services.AddSingleton<TaskSchedulerService>();
        services.AddHostedService(sp => sp.GetRequiredService<TaskSchedulerService>());
        
        services.AddSingleton<PolicySyncService>();
        services.AddHostedService(sp => sp.GetRequiredService<PolicySyncService>());
        
        // 新增服务
        services.AddSingleton<HealthService>();
        services.AddHostedService(sp => sp.GetRequiredService<HealthService>());
        
        services.AddSingleton<MetricsService>();
        services.AddHostedService(sp => sp.GetRequiredService<MetricsService>());
        
        services.AddSingleton<SelfHealingService>();
        services.AddHostedService(sp => sp.GetRequiredService<SelfHealingService>());
        services.AddHostedService<UiHeartbeatService>();
        services.AddSingleton<ActivityReportService>();
        services.AddHostedService(sp => sp.GetRequiredService<ActivityReportService>());

        services.AddHostedService<TokenProactiveRefreshService>();
        
        return services;
    }
    
    /// <summary>
    /// 添加弹性服务
    /// </summary>
    public static IServiceCollection AddResilienceServices(this IServiceCollection services)
    {
        services.AddSingleton<IdempotencyService>();
        services.AddSingleton<DegradationManager>();
        
        // 注册断路器工厂
        services.AddSingleton(sp =>
        {
            var logger = sp.GetRequiredService<ILogger<CircuitBreaker>>();
            return new CircuitBreaker("HttpClient", logger);
        });
        
        return services;
    }
    
    /// <summary>
    /// 添加 HttpClient 带重试策略
    /// </summary>
    public static IServiceCollection AddHttpClientWithRetry(this IServiceCollection services, string name, string userAgent)
    {
        services.AddHttpClient(name, client =>
        {
            client.Timeout = TimeSpan.FromSeconds(Constants.DefaultHttpTimeoutSeconds);
            client.DefaultRequestHeaders.Add("User-Agent", userAgent);
        })
        .AddPolicyHandler(GetRetryPolicy())
        .AddPolicyHandler(GetTimeoutPolicy());

        // 上传专用：更长超时，避免分片+完成被 30s Polly 截断
        services.AddHttpClient("UploadClient", client =>
        {
            client.Timeout = TimeSpan.FromSeconds(Constants.UploadTimeoutSeconds);
            client.DefaultRequestHeaders.Add("User-Agent", userAgent);
        })
        .AddPolicyHandler(GetRetryPolicy())
        .AddPolicyHandler(Polly.Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(Constants.UploadTimeoutSeconds)));
        
        // 同时注册默认 HttpClient
        services.AddHttpClient("AgentClient", client =>
        {
            client.Timeout = TimeSpan.FromSeconds(Constants.DefaultHttpTimeoutSeconds);
            client.DefaultRequestHeaders.Add("User-Agent", userAgent);
        })
        .AddPolicyHandler(GetRetryPolicy())
        .AddPolicyHandler(GetTimeoutPolicy());
        
        return services;
    }
    
    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
    {
        return Polly.Policy
            .HandleResult<HttpResponseMessage>(RetryPolicies.ShouldRetryHttpResponse)
            .Or<HttpRequestException>()
            .Or<TaskCanceledException>()
            .WaitAndRetryAsync(
                Constants.MaxRetryCount,
                retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    // 日志在调用方处理
                });
    }
    
    private static IAsyncPolicy<HttpResponseMessage> GetTimeoutPolicy()
    {
        return Polly.Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(30));
    }
    
    /// <summary>
    /// 添加远程查看服务（LiveKit）
    /// </summary>
    public static IServiceCollection AddRemoteViewService(this IServiceCollection services, IConfiguration? configuration = null)
    {
        if (configuration != null)
        {
            services.Configure<RemoteView.RemoteViewConfig>(configuration.GetSection("RemoteView"));
        }
        else
        {
            services.Configure<RemoteView.RemoteViewConfig>(_ => { });
        }

        services.AddSingleton<RemoteView.IRemoteViewPublisher, RemoteView.FfmpegRtmpPublisher>();
        services.AddSingleton<RemoteView.RemoteViewSessionController>();
        return services;
    }
    
    /// <summary>
    /// 添加所有服务（包括远程屏幕服务）
    /// </summary>
    public static IServiceCollection AddAllServices(this IServiceCollection services, IConfiguration? configuration = null, string? remoteScreenSection = null)
    {
        // 添加基础服务
        services.AddRepositories();
        services.AddResilienceServices();
        
        // 添加后台服务
        services.AddBackgroundServices();
        
        // 添加消息总线
        services.AddSingleton<IMessageBus, MessageBus>();
        
        // 添加敏感数据过滤器
        services.AddSingleton<ISensitiveDataFilter, SensitiveDataFilter>();
        
        // 添加远程查看服务
        services.AddRemoteViewService(configuration);
        
        return services;
    }
    
    /// <summary>
    /// 验证服务配置
    /// </summary>
    public static async Task ValidateServicesAsync(this IServiceProvider services)
    {
        using var scope = services.CreateScope();
        
        // 验证数据库连接
        var db = scope.ServiceProvider.GetRequiredService<SqliteDbContext>();
        using var conn = db.GetConnection();
        
        // 验证加密服务
        var encryption = scope.ServiceProvider.GetRequiredService<WindowsDataProtection>();
        var isEncryptionWorking = await encryption.TestEncryptionAsync();
        
        if (!isEncryptionWorking)
        {
            throw new InvalidOperationException("Encryption service validation failed");
        }
        
        // 可选：验证远程查看服务（如果已注册）
        _ = scope.ServiceProvider.GetService<RemoteView.IRemoteViewPublisher>();
    }
}

#endregion

#region HttpAuthExtensions

/// <summary>
/// 在 HttpRequestMessage 级别设置 Bearer Token（线程安全，避免污染 DefaultRequestHeaders）
/// </summary>
public static class HttpAuthExtensions
{
    public static bool TryApplyBearerToken(HttpRequestMessage request, IAuthTokenProvider provider)
    {
        var snapshot = provider.GetSnapshot();
        if (!snapshot.IsAuthenticated)
            return false;

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
        return true;
    }
}

#endregion

#region LoggerExtensions

/// <summary>
/// 日志扩展方法 - 结构化日志辅助
/// </summary>
public static class LoggerExtensions
{
    // 定义事件 ID
    public static class EventIds
    {
        public static readonly EventId ServiceStart = new(1000, "ServiceStart");
        public static readonly EventId ServiceStop = new(1001, "ServiceStop");
        public static readonly EventId ServiceError = new(1002, "ServiceError");
        
        public static readonly EventId RecordingStart = new(2000, "RecordingStart");
        public static readonly EventId RecordingStop = new(2001, "RecordingStop");
        public static readonly EventId RecordingError = new(2002, "RecordingError");
        
        public static readonly EventId UploadStart = new(3000, "UploadStart");
        public static readonly EventId UploadComplete = new(3001, "UploadComplete");
        public static readonly EventId UploadError = new(3002, "UploadError");
        
        public static readonly EventId WebSocketConnected = new(4000, "WebSocketConnected");
        public static readonly EventId WebSocketDisconnected = new(4001, "WebSocketDisconnected");
        public static readonly EventId WebSocketError = new(4002, "WebSocketError");
        
        public static readonly EventId PolicyUpdate = new(5000, "PolicyUpdate");
        public static readonly EventId TaskExecuted = new(6000, "TaskExecuted");
        public static readonly EventId TaskFailed = new(6001, "TaskFailed");
        
        public static readonly EventId HealthCheck = new(7000, "HealthCheck");
        public static readonly EventId CircuitBreaker = new(8000, "CircuitBreaker");
        public static readonly EventId Degradation = new(9000, "Degradation");
    }
    
    /// <summary>
    /// 记录服务启动
    /// </summary>
    public static void LogServiceStart(this ILogger logger, string serviceName, string deviceId)
    {
        logger.LogInformation(EventIds.ServiceStart, 
            "Service {ServiceName} started | DeviceId: {DeviceId}", 
            serviceName, SensitiveDataFilter.SafeDeviceId(deviceId));
    }
    
    /// <summary>
    /// 记录服务停止
    /// </summary>
    public static void LogServiceStop(this ILogger logger, string serviceName)
    {
        logger.LogInformation(EventIds.ServiceStop, "Service {ServiceName} stopped", serviceName);
    }
    
    /// <summary>
    /// 记录录屏启动
    /// </summary>
    public static void LogRecordingStart(this ILogger logger, int fps, string encoder, string resolution)
    {
        logger.LogInformation(EventIds.RecordingStart, 
            "Recording started | FPS: {Fps}, Encoder: {Encoder}, Resolution: {Resolution}", 
            fps, encoder, resolution);
    }
    
    /// <summary>
    /// 记录录屏停止
    /// </summary>
    public static void LogRecordingStop(this ILogger logger, string reason)
    {
        logger.LogInformation(EventIds.RecordingStop, "Recording stopped | Reason: {Reason}", reason);
    }
    
    /// <summary>
    /// 记录上传完成
    /// </summary>
    public static void LogUploadComplete(this ILogger logger, string fileName, long sizeBytes, TimeSpan duration)
    {
        logger.LogInformation(EventIds.UploadComplete, 
            "Upload completed | File: {FileName}, Size: {SizeKB}KB, Duration: {DurationMs}ms", 
            SensitiveDataFilter.SafeFilePath(fileName), 
            sizeBytes / 1024, 
            duration.TotalMilliseconds);
    }
    
    /// <summary>
    /// 记录 WebSocket 连接状态
    /// </summary>
    public static void LogWebSocketConnected(this ILogger logger, string url)
    {
        logger.LogInformation(EventIds.WebSocketConnected, 
            "WebSocket connected | URL: {Url}", 
            SensitiveDataFilter.FilterStatic(url));
    }
    
    /// <summary>
    /// 记录策略更新
    /// </summary>
    public static void LogPolicyUpdate(this ILogger logger, int oldVersion, int newVersion)
    {
        logger.LogInformation(EventIds.PolicyUpdate, 
            "Policy updated | Version: {OldVersion} -> {NewVersion}", 
            oldVersion, newVersion);
    }
    
    /// <summary>
    /// 记录断路器状态变化
    /// </summary>
    public static void LogCircuitBreakerState(this ILogger logger, string name, string state, int failureCount)
    {
        logger.LogWarning(EventIds.CircuitBreaker, 
            "CircuitBreaker {Name} state changed to {State} | FailureCount: {FailureCount}", 
            name, state, failureCount);
    }
    
    /// <summary>
    /// 记录降级状态变化
    /// </summary>
    public static void LogDegradationLevel(this ILogger logger, string oldLevel, string newLevel, double cpuUsage, double memoryUsage)
    {
        logger.LogWarning(EventIds.Degradation, 
            "Degradation level changed | {OldLevel} -> {NewLevel} | CPU: {CpuUsage:F1}%, Memory: {MemoryUsage:F1}%", 
            oldLevel, newLevel, cpuUsage, memoryUsage);
    }
    
    /// <summary>
    /// 记录健康检查结果
    /// </summary>
    public static void LogHealthCheck(this ILogger logger, string status, int passedCount, int totalCount)
    {
        logger.LogDebug(EventIds.HealthCheck, 
            "Health check completed | Status: {Status}, Passed: {PassedCount}/{TotalCount}", 
            status, passedCount, totalCount);
    }
    
    /// <summary>
    /// 记录性能指标
    /// </summary>
    public static void LogPerformance(this ILogger logger, string metric, double value, string unit)
    {
        logger.LogDebug("Performance metric: {Metric} = {Value:F2} {Unit}", metric, value, unit);
    }
}

#endregion

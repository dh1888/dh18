using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text.Json;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Extensions;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Services;
using EnterpriseAgent.Agent.Storage;
using EnterpriseAgent.Agent.UI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Serilog;
using Serilog.Core;
using Serilog.Events;

using AppConstants = EnterpriseAgent.Agent.Models.Constants;

[assembly: SupportedOSPlatform("windows")]

namespace EnterpriseAgent.Agent;

public sealed class Program
{
    private const string ServiceName = "Enterprise Agent";
    private const string AppDataFolder = "EnterpriseAgent";
    private const string ConfigFileName = "config.json";
    private const string LogsFolder = "logs";
    private const string DataFolder = "data";

    [STAThread]
    public static void Main(string[] args)
    {
        ConsoleWindowSuppressor.Suppress();
        Environment.CurrentDirectory = AppDomain.CurrentDomain.BaseDirectory;
        SetupGlobalExceptionHandlers();

        if (args.Contains("--watchdog", StringComparer.OrdinalIgnoreCase))
        {
            RunWatchdogMode();
            return;
        }

        if (args.Contains(HiddenLauncherFiles.GuardianLaunchArgument, StringComparer.OrdinalIgnoreCase))
        {
            RunGuardianMode();
            return;
        }

        // 用户直接双击/命令行启动：同进程进入 --ui，避免引导进程经 VBS 二次拉起后立刻退出（闪退）
        if (!args.Contains(HiddenLauncherFiles.UiLaunchArgument, StringComparer.OrdinalIgnoreCase)
            && !args.Contains("--service", StringComparer.OrdinalIgnoreCase))
        {
            args = new[] { HiddenLauncherFiles.UiLaunchArgument }.Concat(args).ToArray();
        }

        if (!SingleInstanceManager.TryAcquire())
            return;

        VoluntaryShutdownMarker.Clear();
        UiPresence.ClearHeartbeat();

        try
        {
            MainAsync(args)
                .GetAwaiter()
                .GetResult();
        }
        finally
        {
            SingleInstanceManager.Release();
        }
    }

    private static void SetupGlobalExceptionHandlers()
    {
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            var ex = e.ExceptionObject as Exception;
            WriteCrashLog($"Unhandled domain exception (terminating={e.IsTerminating})", ex);
        };

        TaskScheduler.UnobservedTaskException += (_, e) =>
        {
            WriteCrashLog("Unobserved task exception", e.Exception);
            e.SetObserved();
        };
    }

    private static void WriteCrashLog(string message, Exception? ex)
    {
        try
        {
            if (Log.Logger != null)
            {
                Log.Fatal(ex, message);
                return;
            }
        }
        catch
        {
            // Serilog not ready
        }

        try
        {
            var logDir = AppPaths.GetLogsPath();
            var path = Path.Combine(logDir, "crash.log");
            var line = $"{DateTime.UtcNow:O} {message}{Environment.NewLine}{ex}{Environment.NewLine}";
            File.AppendAllText(path, line);
        }
        catch
        {
            // last resort: ignore
        }
    }

    private static void RunWatchdogMode()
    {
        var logDirectory = AppPaths.GetLogsPath();

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.File(
                Path.Combine(logDirectory, "watchdog-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 7,
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
            .CreateLogger();

        try
        {
            var result = AgentProcessLauncher.EnsureRunning("watchdog-cli", CreateWatchdogLogger());
            Log.Information("Watchdog check finished: {Result}", result);
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Watchdog check failed");
        }
        finally
        {
            Log.CloseAndFlush();
        }
    }

    private static void RunGuardianMode()
    {
        var logDirectory = AppPaths.GetLogsPath();

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.File(
                Path.Combine(logDirectory, "guardian-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 7,
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
            .CreateLogger();

        try
        {
            if (!AgentGuardianManager.TryAcquire())
            {
                Log.Debug("Guardian already running, exiting duplicate");
                return;
            }

            // 新登录会话的守护进程：清除上次「主动退出」标记，否则自启动会永久失效
            VoluntaryShutdownMarker.Clear();

            var logger = CreateGuardianLogger();
            if (!AutoStartManager.EnsureEnabled(logger))
                Log.Warning("Auto-start repair failed during guardian startup");

            using var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (_, e) =>
            {
                e.Cancel = true;
                cts.Cancel();
            };

            AgentGuardianManager.RunAsync(logger, cts.Token).GetAwaiter().GetResult();
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Guardian failed");
        }
        finally
        {
            AgentGuardianManager.Release();
            Log.CloseAndFlush();
        }
    }

    private static Microsoft.Extensions.Logging.ILogger CreateGuardianLogger()
        => LoggerFactory.Create(builder => builder.AddSerilog(dispose: false))
            .CreateLogger("Guardian");

    private static Microsoft.Extensions.Logging.ILogger CreateWatchdogLogger()
        => LoggerFactory.Create(builder => builder.AddSerilog(dispose: false))
            .CreateLogger("Watchdog");

    private static async Task MainAsync(string[] args)
    {
        try
        {
            
            var isWindowsService = args.Contains("--service") || Environment.GetEnvironmentVariable("RUNNING_AS_SERVICE") == "1";
            
            var appDataPath = GetAppDataPath();
            var logDirectory = AppPaths.GetLogsPath();

            // 配置 Logger（增强版）
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                .MinimumLevel.Override("System", LogEventLevel.Warning)
                .MinimumLevel.Override("Microsoft.Hosting.Lifetime", LogEventLevel.Information)
                .WriteTo.File(
                    Path.Combine(logDirectory, "agent-.log"),
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 15,
                    fileSizeLimitBytes: 100 * 1024 * 1024,
                    rollOnFileSizeLimit: true,
                    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
                .CreateLogger();

            Log.Information("Starting Enterprise Agent v{Version}", AppConstants.DefaultAgentVersion);
            Log.Information("OS: {OS}", RuntimeInformation.OSDescription);
            Log.Information("App Data Path: {Path}", appDataPath);
            Log.Information("Running as Windows Service: {IsService}", isWindowsService);

            var host = CreateHostBuilder(args, appDataPath).Build();

            if (!isWindowsService)
            {
                var configService = host.Services.GetRequiredService<EncryptedConfigService>();
                var config = host.Services.GetRequiredService<AgentConfig>();
                
                ApplicationConfiguration.Initialize();
                var localization = host.Services.GetRequiredService<ILocalizationService>();
                
                await EnsureEmployeeInfoAsync(configService, config,localization);

                if (!config.IsWsUrlAlignedWithServer())
                {
                    config.SyncWsUrlWithServer();
                    await configService.SaveConfigAsync(ConfigFileName, config);
                    Log.Information("Persisted corrected WebSocket URL: {WsUrl}", config.WsUrl);
                }

                if (AutoStartManager.EnsureEnabled())
                    Log.Information("Auto-start configured for: {Path}", AutoStartManager.GetExecutablePath());
                else
                    Log.Warning("Auto-start setup failed; use tray menu to retry");

                await ValidateStartupAsync(host.Services);

                AgentWatchdogManager.RemoveLegacyWatchdogTask(CreateWatchdogLogger());
                AgentGuardianManager.EnsureRunning(CreateGuardianLogger());
                Log.Information("In-session guardian active (crash recovery, no periodic flash)");

                var webSocketService = host.Services.GetRequiredService<WebSocketService>();
                
                using var trayIcon = new TrayIcon(
                    host.Services.GetRequiredService<ILogger<TrayIcon>>(),
                    () =>
                    {
                        VoluntaryShutdownMarker.Mark();
                        AgentWatchdogManager.DisableWatchdogTask(CreateWatchdogLogger());
                        Log.Information("User voluntary exit: guardian will stop after UI exits");
                        Application.Exit();
                    },
                    () => webSocketService.IsConnected,
                    () => config.DeviceId,
                    () => config.ServerUrl,
                    localization);

                SingleInstanceManager.SetActivateHandler(() => trayIcon.NotifyAlreadyRunning());

                await host.StartAsync();
                Application.Run();
                
                try
                {
                    using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(15));
                    await host.StopAsync(cts.Token);
                    Log.Information("Host stopped cleanly");
                }
                catch (OperationCanceledException)
                {
                    Log.Warning("Host stop timed out after 15s, forcing exit");
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Error stopping host");
                }
                finally
                {
                    UiPresence.ClearHeartbeat();
                    Log.CloseAndFlush();
                    SingleInstanceManager.Release();
                    Environment.Exit(0);
                }
            }
            else
            {
                await ValidateStartupAsync(host.Services);

                AgentWatchdogManager.RemoveLegacyWatchdogTask(CreateWatchdogLogger());
                AgentGuardianManager.EnsureRunning(CreateGuardianLogger());

                await host.RunAsync();
            }
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Application start failed");
            if (!args.Contains("--service") && Environment.GetEnvironmentVariable("RUNNING_AS_SERVICE") != "1")
            {
                try
                {
                    ApplicationConfiguration.Initialize();
                    MessageBox.Show(
                        BuildStartupErrorMessage(ex),
                        "Enterprise Agent 启动失败",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
                catch
                {
                    // 忽略 UI 初始化失败
                }
            }
            await Task.Delay(3000);
        }
        finally
        {
            await Log.CloseAndFlushAsync();
        }
    }

    private static string BuildStartupErrorMessage(Exception ex)
    {
        var lines = new List<string> { ex.Message, "" };

        if (ex.Message.Contains("deployment.json", StringComparison.OrdinalIgnoreCase) ||
            ex.Message.Contains("AGENT_POLICY_SIGNATURE_SECRET", StringComparison.OrdinalIgnoreCase))
        {
            lines.Add("打包前请编辑配置文件（无需命令行）：");
            lines.Add("");
            lines.Add("  1. 复制 deployment.json.example → deployment.json");
            lines.Add("  2. 用记事本填写 policySignatureSecret（及可选 registrationSecret）");
            lines.Add("  3. dotnet publish 后 deployment.json 与 DHPG.exe 同目录");
            lines.Add("");
            lines.Add("本地 HTTP 调试：allowInsecureTransport 设为 true");
        }
        else if (ex.Message.Contains("https", StringComparison.OrdinalIgnoreCase) ||
                 ex.Message.Contains("wss", StringComparison.OrdinalIgnoreCase))
        {
            lines.Add("生产环境 defaultServerUrl 请使用 https://；");
            lines.Add("本地调试请在 deployment.json 中设置 allowInsecureTransport: true");
        }

        lines.Add("");
        lines.Add($"日志: {AppPaths.GetLogsPath()}");

        return string.Join(Environment.NewLine, lines);
    }

    private static IHostBuilder CreateHostBuilder(string[] args, string appDataPath)
    {
        var isWindowsService = args.Contains("--service") || Environment.GetEnvironmentVariable("RUNNING_AS_SERVICE") == "1";
        var loggerFactory = LoggerFactory.Create(builder => builder.AddSerilog());
        var dpapiScope = isWindowsService
            ? System.Security.Cryptography.DataProtectionScope.LocalMachine
            : System.Security.Cryptography.DataProtectionScope.CurrentUser;
        var dataProtection = new WindowsDataProtection(
            loggerFactory.CreateLogger<WindowsDataProtection>(),
            scope: dpapiScope);
        
        var configDirectory = Path.Combine(appDataPath, "config");
        var legacyConfigPath = Path.Combine(appDataPath, ConfigFileName);
        
        Directory.CreateDirectory(configDirectory);
        
        var configService = new EncryptedConfigService(
            loggerFactory.CreateLogger<EncryptedConfigService>(), 
            dataProtection, 
            configDirectory);
        
        var config = LoadConfigurationAsync(configService, legacyConfigPath, appDataPath).GetAwaiter().GetResult();

        NormalizeAgentConfig(config);

        var dbPath = Path.Combine(appDataPath, DataFolder, "agent.db");

        return Host.CreateDefaultBuilder(args)
            .UseWindowsService(options => options.ServiceName = ServiceName)
            .UseSerilog()
            .ConfigureServices((context, services) =>
            {
                services.Configure<HostOptions>(options =>
                {
                    options.ShutdownTimeout = TimeSpan.FromSeconds(10);
                });

                // ✅ 基础服务
                services.AddSingleton(dataProtection);
                services.AddSingleton<EncryptedConfigService>(configService);
                services.AddSingleton(config);
                services.AddSingleton<ILocalizationService, LocalizationService>();
                
                // ✅ 数据库
                services.AddSingleton(sp => new SqliteDbContext(dbPath, sp.GetRequiredService<ILogger<SqliteDbContext>>()));
                
                // ✅ 安全服务
                services.AddSingleton<DeviceFingerprinter>();
                services.AddSingleton<ISensitiveDataFilter, SensitiveDataFilter>();
                
                // ✅ 【关键】AuthTokenProvider 必须注册为 Singleton
                services.AddSingleton<IAuthTokenProvider, AuthTokenProvider>();
                
                // ✅ API 签名
                services.AddSingleton<ApiSigner>(sp => new ApiSigner(
                    sp.GetRequiredService<AgentConfig>(),
                    sp.GetService<IAuthTokenProvider>(),  // ✅ 传入 Provider（可能为 null）
                    sp.GetRequiredService<ILogger<ApiSigner>>()));
                services.AddSingleton<ISignatureService>(sp => sp.GetRequiredService<ApiSigner>());
                
                // ✅ 仓储
                services.AddRepositories();
                
                // ✅ HTTP 客户端
                services.AddHttpClientWithRetry("AgentClient", $"EnterpriseAgent/{config.AgentVersion}");
                services.AddHttpClient();
                
                // ✅ 弹性服务
                services.AddResilienceServices();
                
                // ✅ 消息总线
                services.AddSingleton<IMessageBus, MessageBus>();
                
                // ✅ 后台服务
                services.AddBackgroundServices();
                
                // ✅ ScreenCapture Logger
                services.AddSingleton(sp => sp.GetRequiredService<ILoggerFactory>().CreateLogger<ScreenCapture>());
                
                // ✅ 远程查看（LiveKit）
                services.Configure<RemoteView.RemoteViewConfig>(context.Configuration.GetSection("RemoteView"));
                services.AddSingleton<RemoteView.IRemoteViewPublisher, RemoteView.FfmpegRtmpPublisher>();
                services.AddSingleton<RemoteView.RemoteViewSessionController>();
                
                // ✅ 其他后台服务
                services.AddHostedService<ActivityRealTimeReporter>();
                services.AddHostedService<MemoryManagementService>();
                services.AddHostedService<LogCleanupService>();
                
                // ✅ 健康检查
                if (config.Observability?.HealthPort > 0)
                {
                    services.AddHealthChecks()
                        .AddCheck<DatabaseHealthCheck>("database")
                        .AddCheck<RemoteViewHealthCheck>("remote_view");
                }
            });
    }
    private static void NormalizeAgentConfig(AgentConfig config)
    {
        ArgumentNullException.ThrowIfNull(config);

        config.Storage ??= new StorageConfig();
        if (string.IsNullOrWhiteSpace(config.Storage.Path))
            config.Storage.Path = config.GetEffectiveStoragePath();

        if (config.Storage.MaxSizeGB <= 0)
            config.Storage.MaxSizeGB = AppConstants.DefaultMaxStorageGB;

        config.AgentVersion = AppConstants.DefaultAgentVersion;

        config.Auth ??= new AuthConfig();
        config.Policy ??= new PolicyConfig();
        config.Observability ??= new ObservabilityConfig();
        config.Resilience ??= new ResilienceConfig();

        if (!string.IsNullOrWhiteSpace(config.ServerUrl)
            && !config.IsWsUrlAlignedWithServer())
        {
            config.SyncWsUrlWithServer();
            Log.Information("WebSocket URL synced with ServerUrl: {WsUrl}", config.WsUrl);
        }
        else if (string.IsNullOrWhiteSpace(config.WsUrl) && !string.IsNullOrWhiteSpace(config.ServerUrl))
        {
            config.WsUrl = config.GetEffectiveWsUrl();
            Log.Information("Auto-configured WebSocket URL: {WsUrl}", config.WsUrl);
        }
    }

    private static void ValidateAgentConfig(AgentConfig config)
    {
        ArgumentNullException.ThrowIfNull(config);

        if (string.IsNullOrWhiteSpace(config.ServerUrl))
        {
            throw new InvalidOperationException(
                "ServerUrl is not configured. Set it during installation or in the startup form.");
        }

        if (string.IsNullOrWhiteSpace(config.WsUrl))
        {
            config.WsUrl = config.GetEffectiveWsUrl();
            Log.Information("Auto-configured WebSocket URL: {WsUrl}", config.WsUrl);
        }
        else if (!config.IsWsUrlAlignedWithServer())
        {
            config.SyncWsUrlWithServer();
            Log.Information("WebSocket URL re-aligned with ServerUrl: {WsUrl}", config.WsUrl);
        }

        config.Storage ??= new StorageConfig();
        if (string.IsNullOrWhiteSpace(config.Storage.Path))
            config.Storage.Path = config.GetEffectiveStoragePath();

        if (config.Storage.MaxSizeGB <= 0)
            config.Storage.MaxSizeGB = AppConstants.DefaultMaxStorageGB;

        config.AgentVersion = AppConstants.DefaultAgentVersion;

        config.Auth ??= new AuthConfig();
        config.Policy ??= new PolicyConfig();
        config.Observability ??= new ObservabilityConfig();
        config.Resilience ??= new ResilienceConfig();

        EnsurePolicySignatureSecret(config);

        var (isValid, errors) = config.Validate();
        if (!isValid)
        {
            throw new InvalidOperationException(
                "Agent configuration validation failed: " + string.Join("; ", errors));
        }

        try
        {
            var storagePath = config.Storage.Path;
            Directory.CreateDirectory(storagePath);
            var testFile = Path.Combine(storagePath, ".write_test");
            File.WriteAllText(testFile, "test");
            File.Delete(testFile);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Storage path is not writable: {Path}", config.Storage.Path);
            throw;
        }
    }

    private static void ApplyDeploymentSecrets(AgentConfig config)
    {
        var bundle = DeploymentConfigLoader.TryLoad();

        var needsPolicy = string.IsNullOrWhiteSpace(config.Auth?.PolicySignatureSecret)
            && string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET"));

        if (needsPolicy)
        {
            var (valid, errors) = DeploymentConfigLoader.Validate(bundle);
            if (!valid)
            {
                var path = DeploymentConfigLoader.GetExpectedPath();
                throw new InvalidOperationException(
                    $"deployment.json 配置无效（{path}）：{string.Join("; ", errors)}");
            }
        }

        DeploymentConfigLoader.ApplyTo(config, bundle);

        if (bundle != null)
            Log.Information("Deployment secrets applied from {Path}", DeploymentConfigLoader.GetExpectedPath());
    }

    private static void EnsurePolicySignatureSecret(AgentConfig config)
    {
        if (config.Auth == null)
            return;

        if (!string.IsNullOrWhiteSpace(config.Auth.PolicySignatureSecret))
            return;

        var policySecret = Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET");
        if (!string.IsNullOrWhiteSpace(policySecret))
        {
            config.Auth.PolicySignatureSecret = policySecret;
            return;
        }

        throw new InvalidOperationException(
            "PolicySignatureSecret is required. Place policySignatureSecret in deployment.json next to the exe, or set AGENT_POLICY_SIGNATURE_SECRET.");
    }

    private static async Task ValidateStartupAsync(IServiceProvider services)
    {
        var config = services.GetRequiredService<AgentConfig>();
        ValidateAgentConfig(config);
        await services.ValidateServicesAsync();
        Log.Information("Startup validation completed");
    }

    private static async Task<AgentConfig> LoadConfigurationAsync(
        EncryptedConfigService configService, 
        string legacyConfigPath,
        string appDataPath)
    {
        var config = await configService.LoadConfigAsync<AgentConfig>(ConfigFileName);
        if (config != null)
        {
            Log.Information("Encrypted configuration loaded successfully");
            
            // 策略签名密钥
            if (config.Auth != null && string.IsNullOrEmpty(config.Auth.PolicySignatureSecret))
            {
                var policySecret = Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET");
                if (!string.IsNullOrWhiteSpace(policySecret))
                {
                    config.Auth.PolicySignatureSecret = policySecret;
                    await configService.SaveConfigAsync(ConfigFileName, config);
                    Log.Information("PolicySignatureSecret loaded from AGENT_POLICY_SIGNATURE_SECRET");
                }
            }
            
            return ApplyDeploymentSecretsToConfig(config);
        }

        if (File.Exists(legacyConfigPath))
        {
            try
            {
                var json = await File.ReadAllTextAsync(legacyConfigPath);
                var legacyConfig = JsonSerializer.Deserialize<AgentConfig>(json);
                if (legacyConfig != null)
                {
                    Log.Information("Migrating legacy configuration to encrypted format");
                    
                    if (legacyConfig.Auth != null && string.IsNullOrEmpty(legacyConfig.Auth.PolicySignatureSecret))
                    {
                        var policySecret = Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET");
                        if (!string.IsNullOrWhiteSpace(policySecret))
                            legacyConfig.Auth.PolicySignatureSecret = policySecret;
                    }

                    if (legacyConfig.Auth != null && string.IsNullOrEmpty(legacyConfig.Auth.UploadSignatureSecret))
                    {
                        var uploadSecret = Environment.GetEnvironmentVariable("AGENT_UPLOAD_SIGNATURE_SECRET");
                        if (!string.IsNullOrWhiteSpace(uploadSecret))
                        {
                            legacyConfig.Auth.UploadSignatureSecret = uploadSecret;
                        }
                    }
                    
                    try
                    {
                        await configService.SaveConfigAsync(ConfigFileName, legacyConfig);
                        var backupPath = legacyConfigPath + ".bak";
                        if (File.Exists(backupPath))
                            File.Delete(backupPath);
                        File.Move(legacyConfigPath, backupPath);
                        Log.Information("Legacy configuration migrated and backed up");
                    }
                    catch (Exception saveEx)
                    {
                        Log.Error(saveEx, "Failed to save migrated config, continuing with legacy config");
                    }
                    return ApplyDeploymentSecretsToConfig(legacyConfig);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Failed to load legacy configuration");
            }
        }

        Log.Warning("Configuration file not found, creating default configuration");
        var defaultConfig = CreateDefaultConfig(appDataPath);
        
        try
        {
            await configService.SaveConfigAsync(ConfigFileName, defaultConfig);
            Log.Information("Default configuration created and saved");
        }
        catch (Exception saveEx)
        {
            Log.Error(saveEx, "Failed to save default config, but continuing with in-memory config");
        }
        
        return ApplyDeploymentSecretsToConfig(defaultConfig);
    }

    private static AgentConfig ApplyDeploymentSecretsToConfig(AgentConfig config)
    {
        ApplyDeploymentSecrets(config);
        return config;
    }

    private static AgentConfig CreateDefaultConfig(string appDataPath)
    {
        var storagePath = Path.Combine(appDataPath, DataFolder);

        return new AgentConfig
        {
            ConfigVersion = 2,
            ServerUrl = "",
            WsUrl = "",
            DeviceId = "",
            AgentVersion = AppConstants.DefaultAgentVersion,

            Auth = new AuthConfig
            {
                PolicySignatureSecret = Environment.GetEnvironmentVariable("AGENT_POLICY_SIGNATURE_SECRET") ?? "",
                RegistrationSecret = Environment.GetEnvironmentVariable("AGENT_REGISTRATION_SECRET") ?? "",
                UploadSignatureSecret = Environment.GetEnvironmentVariable("AGENT_UPLOAD_SIGNATURE_SECRET") ?? ""
            },

            Employee = new EmployeeInfo(),

            Policy = new PolicyConfig
            {
                SyncIntervalSeconds = 300,
                LocalCache = true
            },

            Storage = new StorageConfig
            {
                Path = storagePath,
                MaxSizeGB = AppConstants.DefaultMaxStorageGB
            },

            Logging = new LoggingConfig
            {
                Level = AppConstants.DefaultLogLevel,
                MaxSizeMB = AppConstants.DefaultLogMaxSizeMB,
                MaxFiles = AppConstants.DefaultLogMaxFiles
            },

            Observability = new ObservabilityConfig
            {
                EnableMetrics = false,
                EnableStructuredLogging = true,
                MetricsPort = 0,
                HealthPort = 0
            },

            Resilience = new ResilienceConfig
            {
                EnableCircuitBreaker = true,
                EnableIdempotency = true
            }
        };
    }

    private static string GetAppDataPath()
    {
        var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), AppDataFolder);
        
        Directory.CreateDirectory(path);
        Directory.CreateDirectory(Path.Combine(path, LogsFolder));
        Directory.CreateDirectory(Path.Combine(path, DataFolder));
        Directory.CreateDirectory(Path.Combine(path, "config"));
        
        return path;
    }

    private static async Task EnsureEmployeeInfoAsync(
        EncryptedConfigService configService, 
        AgentConfig config,
        ILocalizationService? localization = null)
    {
        if (config.Employee != null &&
            !string.IsNullOrWhiteSpace(config.Employee.Name) &&
            !string.IsNullOrWhiteSpace(config.ServerUrl))
        {
            Log.Information("Agent already configured: {Name}, ServerUrl: {ServerUrl}",
                config.Employee.Name, config.ServerUrl);
            return;
        }

        Log.Information("Showing startup configuration form...");

        var deploymentBundle = DeploymentConfigLoader.TryLoad();
        var lockedServerUrl = DeploymentConfigLoader.TryGetLockedServerUrl(deploymentBundle);
        if (lockedServerUrl != null)
        {
            config.ServerUrl = lockedServerUrl;
            config.WsUrl = config.GetEffectiveWsUrl();
            Log.Information("Server URL locked by deployment.json: {ServerUrl}", lockedServerUrl);
        }

        using var form = new EmployeeSetupForm(
            null,
            localization,
            serverUrl: lockedServerUrl ?? config.ServerUrl,
            lockedServerUrl: lockedServerUrl);
        form.StartPosition = FormStartPosition.CenterScreen;
        form.TopMost = true;

        var result = form.ShowDialog();

        if (result == DialogResult.OK)
        {
            config.Employee = form.EmployeeInfo ?? new EmployeeInfo();
            ApplyDeploymentSecrets(config);
            if (lockedServerUrl == null)
                config.ServerUrl = form.ServerUrl;
            config.WsUrl = config.GetEffectiveWsUrl();
            await configService.SaveConfigAsync(ConfigFileName, config);
            Log.Information("Initial configuration saved: {EmployeeName}, ServerUrl: {ServerUrl}",
                config.Employee.Name, config.ServerUrl);

            if (AutoStartManager.EnsureEnabled())
                Log.Information("Auto-start enabled after initial setup");
        }
        else
        {
            Log.Error("Startup configuration cancelled by user");
            throw new InvalidOperationException("Agent configuration is required to start.");
        }
    }
}
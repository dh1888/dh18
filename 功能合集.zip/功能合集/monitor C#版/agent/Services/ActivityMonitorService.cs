// Services/ActivityMonitorService.cs - 修复版（添加锁保护，消除死锁风险）

using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using System.Text.Json;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 活动监控服务 - 监控用户活动状态和应用使用情况
/// </summary>
[SupportedOSPlatform("windows")]
public class ActivityMonitorService : BackgroundService
{
    private readonly ILogger<ActivityMonitorService> _logger;
    private readonly string _deviceId;
    
    // ✅ 锁保护 _currentActivity
    private readonly object _activityLock = new();
    private ActivityLog? _currentActivity;

    // 性能优化：缓存进程名称
    private readonly HashSet<string> _browserProcesses = new(
        StringComparer.OrdinalIgnoreCase)
    {
        "chrome", "msedge", "firefox", "opera", "brave", "edge", "browser"
    };

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();
    
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
    
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowTextLength(IntPtr hWnd);
    
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll")]
    private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

    private struct LASTINPUTINFO
    {
        public uint cbSize;
        public uint dwTime;
    }

    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IMessageBus _messageBus;

    public ActivityMonitorService(
        ILogger<ActivityMonitorService> logger,
        IServiceScopeFactory scopeFactory,
        AgentConfig config,
        IMessageBus messageBus)
    {
        _logger = logger;
        _scopeFactory = scopeFactory;
        _deviceId = config.DeviceId;
        _messageBus = messageBus;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Activity monitor started for device: {DeviceId}", 
            SensitiveDataFilter.SafeDeviceId(_deviceId));
        
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var info = GetActiveWindowInfo();
                var isIdle = IsUserIdle();

                // ✅ 安全复制当前活动
                ActivityLog? currentActivityCopy;
                lock (_activityLock)
                {
                    currentActivityCopy = _currentActivity;
                }

                var needNewActivity = currentActivityCopy == null ||
                    currentActivityCopy.WindowTitle != info.windowTitle ||
                    currentActivityCopy.ProcessName != info.processName ||
                    currentActivityCopy.IsIdle != isIdle;

                if (needNewActivity)
                {
                    // 结束当前活动
                    if (currentActivityCopy != null)
                    {
                        currentActivityCopy.EndedAt = DateTime.UtcNow;
                        currentActivityCopy.DurationSeconds = (int)(DateTime.UtcNow - currentActivityCopy.StartedAt).TotalSeconds;
                        await FinalizeActivityAsync(currentActivityCopy);
                        
                        _logger.LogDebug("Activity ended: {ProcessName} - Duration: {Duration}s",
                            currentActivityCopy.ProcessName, currentActivityCopy.DurationSeconds);
                    }

                    // 空闲或系统噪音：不记录新活动
                    if (!ActivityCaptureHelper.ShouldStartCapture(
                            info.processName, info.windowTitle, info.browserTitle, isIdle))
                    {
                        lock (_activityLock)
                        {
                            _currentActivity = null;
                        }
                    }
                    else
                    {
                        var newActivity = new ActivityLog
                        {
                            DeviceId = _deviceId,
                            ProcessName = info.processName,
                            WindowTitle = info.windowTitle,
                            BrowserTitle = info.browserTitle,
                            StartedAt = DateTime.UtcNow,
                            IsIdle = false
                        };
                        
                        await AddActivityAsync(newActivity);
                        
                        lock (_activityLock)
                        {
                            _currentActivity = newActivity;
                        }
                        
                        _logger.LogDebug("Activity started: {ProcessName} - {WindowTitle}", 
                            info.processName, TruncateString(info.windowTitle, 50));
                    }
                }
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error monitoring activity");
            }
            
            await Task.Delay(Constants.ActivityMonitorIntervalMs, stoppingToken);
        }
        
        // 服务停止时，结束当前活动
        await EndCurrentActivityAsync();
        
        _logger.LogInformation("Activity monitor stopped");
    }

    private async Task EndCurrentActivityAsync()
    {
        ActivityLog? activityToUpdate = null;
        
        lock (_activityLock)
        {
            if (_currentActivity != null && _currentActivity.EndedAt == null)
            {
                _currentActivity.EndedAt = DateTime.UtcNow;
                _currentActivity.DurationSeconds = (int)(DateTime.UtcNow - _currentActivity.StartedAt).TotalSeconds;
                activityToUpdate = _currentActivity;
                _currentActivity = null;
            }
        }
        
        if (activityToUpdate != null)
        {
            await FinalizeActivityAsync(activityToUpdate);
            _logger.LogDebug("Final activity saved on stop: {ProcessName}", activityToUpdate.ProcessName);
        }
    }

    private async Task FinalizeActivityAsync(ActivityLog activity)
    {
        if (ActivityCaptureHelper.ShouldPersist(activity))
        {
            await UpdateActivityAsync(activity);
            return;
        }

        if (!string.IsNullOrEmpty(activity.Id))
        {
            await DeleteActivityAsync(activity.Id);
        }
    }

    private async Task DeleteActivityAsync(string activityId)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<ActivityRepository>();
        await repo.DeleteAsync(activityId);
    }

    /// <summary>
    /// 通过 WebSocket 实时上报活动日志
    /// </summary>
    private async Task RealTimeReportAsync(ActivityLog activity)
    {
        if (string.IsNullOrEmpty(_deviceId))
            return;

        try
        {
            var reportData = new
            {
                id = activity.Id,
                deviceId = _deviceId,
                processName = activity.ProcessName ?? "",
                windowTitle = activity.WindowTitle ?? "",
                browserTitle = activity.BrowserTitle ?? "",
                startedAt = activity.StartedAt.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                endedAt = activity.EndedAt?.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                isIdle = activity.IsIdle,
                durationSeconds = activity.DurationSeconds
            };

            var json = JsonSerializer.Serialize(reportData, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            var element = JsonSerializer.Deserialize<JsonElement>(json);

            await _messageBus.PublishAsync("activity.real_time", element);

            _logger.LogDebug(
                "Real-time activity reported via WebSocket: {ProcessName} ({Duration}s)",
                activity.ProcessName,
                activity.DurationSeconds);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to send real-time activity report");
        }
    }

    private async Task UpdateActivityAsync(ActivityLog activity)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<ActivityRepository>();
        await repo.UpdateAsync(activity);
        await RealTimeReportAsync(activity);
    }

    private async Task AddActivityAsync(ActivityLog activity)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<ActivityRepository>();
        await repo.AddAsync(activity);
    }

    private (string processName, string windowTitle, string browserTitle) GetActiveWindowInfo()
    {
        try
        {
            var hWnd = GetForegroundWindow();
            if (hWnd == IntPtr.Zero)
                return ("", "", "");
            
            var length = GetWindowTextLength(hWnd);
            var windowTitle = "";
            if (length > 0)
            {
                var title = new StringBuilder(length + 1);
                _ = GetWindowText(hWnd, title, title.Capacity);
                windowTitle = ActivityCaptureHelper.SanitizeWindowText(title.ToString());
            }
            
            GetWindowThreadProcessId(hWnd, out var processId);
            var processName = GetProcessNameSafe((int)processId) ?? "";
            
            var browserTitle = "";
            if (!string.IsNullOrEmpty(processName) && IsBrowser(processName))
            {
                browserTitle = ActivityCaptureHelper.SanitizeWindowText(windowTitle);
                var parts = windowTitle.Split(new[] { " - " }, StringSplitOptions.None);
                if (parts.Length > 0 && !string.IsNullOrEmpty(parts[0]))
                    browserTitle = ActivityCaptureHelper.SanitizeWindowText(parts[0]);
            }
            
            return (processName, windowTitle, browserTitle);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to get active window info");
            return ("", "", "");
        }
    }

    private string? GetProcessNameSafe(int processId)
    {
        try
        {
            using var process = Process.GetProcessById(processId);
            return process.ProcessName;
        }
        catch (ArgumentException)
        {
            return null;
        }
        catch (InvalidOperationException)
        {
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to get process name for PID: {ProcessId}", processId);
            return null;
        }
    }

    private bool IsBrowser(string processName)
    {
        if (string.IsNullOrEmpty(processName))
            return false;
        return _browserProcesses.Contains(processName);
    }

    private bool IsUserIdle()
    {
        try
        {
            var info = new LASTINPUTINFO { cbSize = (uint)Marshal.SizeOf<LASTINPUTINFO>() };
            if (!GetLastInputInfo(ref info))
            {
                return false;
            }
            
            var idleMs = (uint)Environment.TickCount - info.dwTime;
            return idleMs > Constants.IdleThresholdMs;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to check user idle state");
            return false;
        }
    }

    private static string TruncateString(string? input, int maxLength)
    {
        if (string.IsNullOrEmpty(input))
            return "";
        return input.Length <= maxLength ? input : input[..maxLength];
    }
}

/// <summary>
/// 活动日志仓储
/// </summary>
public class ActivityRepository
{
    private readonly SqliteDbContext _db;

    public ActivityRepository(SqliteDbContext db)
    {
        _db = db;
    }

    public async Task AddAsync(ActivityLog log)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            INSERT INTO activity_logs (id, device_id, process_name, window_title, browser_title, started_at, is_idle, created_at)
            VALUES (@id, @did, @pn, @wt, @bt, @st, @idle, @created)", conn);

        cmd.Parameters.AddWithValue("@id", log.Id);
        cmd.Parameters.AddWithValue("@did", log.DeviceId);
        cmd.Parameters.AddWithValue("@pn", log.ProcessName ?? "");
        cmd.Parameters.AddWithValue("@wt", log.WindowTitle ?? "");
        cmd.Parameters.AddWithValue("@bt", log.BrowserTitle ?? "");
        cmd.Parameters.AddWithValue("@st", log.StartedAt.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@idle", log.IsIdle ? 1 : 0);
        cmd.Parameters.AddWithValue("@created", DateTime.UtcNow.ToIso8601StringBasic());

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UpdateAsync(ActivityLog log)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE activity_logs
            SET ended_at = @et, duration_seconds = @dur, updated_at = @up,
                window_title = @wt, browser_title = @bt
            WHERE id = @id", conn);

        cmd.Parameters.AddWithValue("@et", log.EndedAt?.ToIso8601StringBasic() ?? "");
        cmd.Parameters.AddWithValue("@dur", log.DurationSeconds);
        cmd.Parameters.AddWithValue("@up", DateTime.UtcNow.ToIso8601StringBasic());
        cmd.Parameters.AddWithValue("@wt", log.WindowTitle ?? "");
        cmd.Parameters.AddWithValue("@bt", log.BrowserTitle ?? "");
        cmd.Parameters.AddWithValue("@id", log.Id);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeleteAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            return;

        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand("DELETE FROM activity_logs WHERE id = @id", conn);
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<int> DeleteOlderThanAsync(DateTime cutoff)
    {
        if (cutoff == default) return 0;
        
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand("DELETE FROM activity_logs WHERE started_at < @cut", conn);
        cmd.Parameters.AddWithValue("@cut", cutoff.ToIso8601StringBasic());
        return await cmd.ExecuteNonQueryAsync();
    }

    // Services/ActivityMonitorService.cs - 在 ActivityRepository 类中添加以下方法

    /// <summary>
    /// 获取未上报的活动日志
    /// </summary>
    /// <summary>
    /// 获取未上报的活动日志
    /// </summary>
    /// <summary>
    /// 获取未上报的活动日志（优先新数据，限制重试次数，只上报最近7天）
    /// </summary>
    public async Task<List<ActivityLog>> GetUnreportedAsync(int limit = 500)
    {
        var result = new List<ActivityLog>();
        var maxRetries = 3;
        var cutoff = DateTime.UtcNow.AddDays(-7);

        using var conn = _db.GetConnection();

        using var cmd = new SqliteCommand(
            @"
        SELECT id, device_id, process_name, window_title, browser_title, 
               started_at, ended_at, is_idle, duration_seconds, created_at, 
               COALESCE(retry_count, 0) as retry_count
        FROM activity_logs 
        WHERE (reported = 0 OR reported IS NULL) 
        AND COALESCE(retry_count, 0) < @maxRetries
        AND started_at > @cutoff
        AND ended_at IS NOT NULL AND ended_at != ''
        AND duration_seconds >= @minDuration
        AND is_idle = 0
        ORDER BY started_at DESC
        LIMIT @limit",
            conn);

        cmd.Parameters.AddWithValue("@maxRetries", maxRetries);
        cmd.Parameters.AddWithValue("@cutoff", cutoff.ToIso8601String());
        cmd.Parameters.AddWithValue("@minDuration", ActivityCaptureHelper.MinUserActivityDurationSeconds);
        cmd.Parameters.AddWithValue("@limit", limit);

        using var reader = await cmd.ExecuteReaderAsync();

        while (await reader.ReadAsync())
        {
            var activity = new ActivityLog
            {
                Id = reader.GetString(0),
                DeviceId = reader.GetString(1),
                ProcessName = reader.GetString(2),
                WindowTitle = ActivityCaptureHelper.SanitizeWindowText(reader.GetString(3)),
                BrowserTitle = ActivityCaptureHelper.SanitizeWindowText(reader.GetString(4)),
                StartedAt = DateTimeExtensions.FromIso8601String(
                    reader.GetString(5)),
                IsIdle = reader.GetInt32(7) == 1,
                DurationSeconds = reader.GetInt32(8),
                CreatedAt = DateTimeExtensions.FromIso8601String(
                    reader.GetString(9)),
            };

            if (!reader.IsDBNull(6))
            {
                var endedAtStr = reader.GetString(6);

                if (!string.IsNullOrEmpty(endedAtStr))
                {
                    activity.EndedAt =
                        DateTimeExtensions.FromIso8601String(endedAtStr);
                }
            }

            result.Add(activity);
        }

        return result
            .Where(ActivityCaptureHelper.ShouldPersist)
            .ToList();
    }

    /// <summary>
    /// 标记活动日志为已上报
    /// </summary>
    public async Task<int> MarkAsReportedAsync(List<string> ids)
    {
        if (ids == null || ids.Count == 0)
            return 0;

        using var conn = _db.GetConnection();

        var placeholders = string.Join(",", ids.Select((_, i) => $"@id{i}"));
        var query = $"UPDATE activity_logs SET reported = 1, reported_at = @reported_at WHERE id IN ({placeholders})";

        using var cmd = new SqliteCommand(query, conn);
        cmd.Parameters.AddWithValue("@reported_at", DateTime.UtcNow.ToIso8601String());

        for (int i = 0; i < ids.Count; i++)
        {
            cmd.Parameters.AddWithValue($"@id{i}", ids[i]);
        }

        return await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 标记单条活动日志为已上报
    /// </summary>
    public async Task<bool> MarkAsReportedAsync(string id)
    {
        var result = await MarkAsReportedAsync(new List<string> { id });
        return result > 0;
    }

    /// <summary>
    /// 获取待上报的活动日志数量
    /// </summary>
    public async Task<int> GetPendingReportCountAsync()
    {
        using var conn = _db.GetConnection();

        using var cmd = new SqliteCommand(
            @"
        SELECT COUNT(*) FROM activity_logs 
        WHERE (reported = 0 OR reported IS NULL) 
        AND COALESCE(retry_count, 0) < 3
        AND started_at > datetime('now', '-7 days')",
            conn);

        var result = await cmd.ExecuteScalarAsync();

        return Convert.ToInt32(result);
    }

    /// <summary>
    /// 获取活动的重试次数
    /// </summary>
    public async Task<int> GetRetryCountAsync(string id)
    {
        using var conn = _db.GetConnection();

        using var cmd = new SqliteCommand(
            "SELECT COALESCE(retry_count, 0) FROM activity_logs WHERE id = @id",
            conn);

        cmd.Parameters.AddWithValue("@id", id);

        var result = await cmd.ExecuteScalarAsync();

        return result != null
            ? Convert.ToInt32(result)
            : 0;
    }

    /// <summary>
    /// 增加重试计数
    /// </summary>
    public async Task<int> IncrementRetryCountAsync(List<string> ids)
    {
        if (ids == null || ids.Count == 0)
            return 0;

        using var conn = _db.GetConnection();

        var placeholders = string.Join(
            ",",
            ids.Select((_, i) => $"@id{i}"));

        var query =
            $@"
        UPDATE activity_logs 
        SET retry_count = COALESCE(retry_count, 0) + 1,
            updated_at = @updated_at
        WHERE id IN ({placeholders})";

        using var cmd = new SqliteCommand(query, conn);

        cmd.Parameters.AddWithValue(
            "@updated_at",
            DateTime.UtcNow.ToIso8601String());

        for (int i = 0; i < ids.Count; i++)
        {
            cmd.Parameters.AddWithValue(
                $"@id{i}",
                ids[i]);
        }

        return await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 标记活动日志为最终失败（不再重试）
    /// </summary>
    public async Task<int> MarkAsFailedAsync(
        List<string> ids,
        string error)
    {
        if (ids == null || ids.Count == 0)
            return 0;

        using var conn = _db.GetConnection();

        var placeholders = string.Join(
            ",",
            ids.Select((_, i) => $"@id{i}"));

        var query =
            $@"
        UPDATE activity_logs 
        SET reported = -1, 
            error_message = @error,
            retry_count = COALESCE(retry_count, 0) + 1,
            updated_at = @updated_at
        WHERE id IN ({placeholders})";

        using var cmd = new SqliteCommand(query, conn);

        cmd.Parameters.AddWithValue("@error", error);

        cmd.Parameters.AddWithValue(
            "@updated_at",
            DateTime.UtcNow.ToIso8601String());

        for (int i = 0; i < ids.Count; i++)
        {
            cmd.Parameters.AddWithValue(
                $"@id{i}",
                ids[i]);
        }

        return await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 删除已上报且超过指定天数的活动日志
    /// </summary>
    public async Task<int> DeleteReportedOlderThanAsync(DateTime cutoff)
    {
        using var conn = _db.GetConnection();

        using var cmd = new SqliteCommand(
            "DELETE FROM activity_logs WHERE reported = 1 AND created_at < @cutoff",
            conn);

        cmd.Parameters.AddWithValue("@cutoff", cutoff.ToIso8601String());

        return await cmd.ExecuteNonQueryAsync();
    }
}

/// <summary>
/// 活动采集辅助：修复乱码、过滤系统噪音，仅保留用户真实操作。
/// </summary>
internal static class ActivityCaptureHelper
{
    public const int MinUserActivityDurationSeconds = 3;

    private static readonly HashSet<string> IgnoredProcesses = new(StringComparer.OrdinalIgnoreCase)
    {
        "ApplicationFrameHost", "SearchHost", "SearchUI", "ShellExperienceHost",
        "StartMenuExperienceHost", "TextInputHost", "LockApp", "SystemSettings",
        "RuntimeBroker", "backgroundTaskHost", "SecurityHealthSystray", "sihost",
        "ctfmon", "dwm", "csrss", "fontdrvhost", "WidgetBoard", "PhoneExperienceHost", "DHPG",
    };

    public static string SanitizeWindowText(string? input, int maxLength = 200)
    {
        if (string.IsNullOrWhiteSpace(input))
            return string.Empty;

        var sb = new StringBuilder(input.Length);
        foreach (var ch in input.Trim())
        {
            if (char.IsControl(ch) && ch is not '\t') continue;
            if (char.IsSurrogate(ch)) continue;
            if (ch == '\uFFFD') continue;
            sb.Append(ch);
        }

        var cleaned = sb.ToString().Trim();
        if (cleaned.Length == 0 || LooksGarbled(cleaned))
            return string.Empty;

        return cleaned.Length <= maxLength ? cleaned : cleaned[..maxLength];
    }

    public static bool IsNoiseProcess(string? processName)
        => string.IsNullOrWhiteSpace(processName) || IgnoredProcesses.Contains(processName.Trim());

    public static bool HasMeaningfulTitle(string windowTitle, string browserTitle)
        => !string.IsNullOrWhiteSpace(windowTitle) || !string.IsNullOrWhiteSpace(browserTitle);

    public static bool ShouldStartCapture(string processName, string windowTitle, string browserTitle, bool isIdle)
    {
        if (isIdle || IsNoiseProcess(processName)) return false;
        return HasMeaningfulTitle(windowTitle, browserTitle);
    }

    public static bool ShouldPersist(ActivityLog activity)
    {
        if (activity.IsIdle || IsNoiseProcess(activity.ProcessName)) return false;
        if (activity.DurationSeconds < MinUserActivityDurationSeconds) return false;

        activity.WindowTitle = SanitizeWindowText(activity.WindowTitle);
        activity.BrowserTitle = SanitizeWindowText(activity.BrowserTitle);
        return HasMeaningfulTitle(activity.WindowTitle, activity.BrowserTitle);
    }

    private static bool LooksGarbled(string text)
    {
        if (text.Length < 2) return false;
        var suspicious = 0;
        foreach (var ch in text)
        {
            if (ch == '\uFFFD' || ch < 0x20 || ch is >= '\uE000' and <= '\uF8FF')
                suspicious++;
        }
        return suspicious * 3 >= text.Length;
    }
}
// Services/ActivityReportService.cs - 完整修改版（集成 AuthTokenProvider）

using System.Text;
using System.Text.Json;
using EnterpriseAgent.Agent.Extensions;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 活动日志上报服务 - 定期将本地活动日志通过 HTTP 批量上报到后端
/// </summary>
public class ActivityReportService : BackgroundService
{
    private readonly ILogger<ActivityReportService> _logger;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly AgentConfig _config;
    private readonly IMessageBus _messageBus;
    private readonly IAuthTokenProvider _authTokenProvider;  // ✅ 新增
    
    // ✅ 修改：提高上报效率的配置参数
    private readonly int _batchSize = 50;               // 每批上报数量（从10改为50）
    private readonly int _batchCount = 2;               // 每次上报的批次数（最多2批，共100条）
    private readonly TimeSpan _reportInterval = TimeSpan.FromMinutes(2);  // 上报间隔（从5分钟改为2分钟）
    private readonly TimeSpan _retryDelay = TimeSpan.FromSeconds(30);     // 重试延迟
    
    // ✅ 新增：重试配置
    private const int MaxRetryCount = 3;                // 最大重试次数
    
    private readonly SemaphoreSlim _reportLock = new(1, 1);
    private bool _isStopping;
    private DateTime _lastSuccessfulReport = DateTime.UtcNow;

    private readonly HttpClient _httpClient;

    public ActivityReportService(
        ILogger<ActivityReportService> logger,
        IServiceScopeFactory scopeFactory,
        IHttpClientFactory httpClientFactory,
        AgentConfig config,
        IMessageBus messageBus,
        IAuthTokenProvider authTokenProvider)  // ✅ 新增参数
    {
        _logger = logger;
        _scopeFactory = scopeFactory;
        _httpClientFactory = httpClientFactory;
        _config = config;
        _messageBus = messageBus;
        _authTokenProvider = authTokenProvider;  // ✅ 保存引用

        _httpClient = httpClientFactory.CreateClient("AgentClient");
        _httpClient.Timeout = TimeSpan.FromMinutes(2);
    }

    #region ========== Token 辅助方法 ==========

    /// <summary>
    /// ✅ 获取当前 DeviceId（从 Provider）
    /// </summary>
    private string GetCurrentDeviceId()
    {
        return _authTokenProvider.GetSnapshot().DeviceId;
    }

    /// <summary>
    /// ✅ 检查是否已认证
    /// </summary>
    private bool IsAuthenticated()
    {
        return _authTokenProvider.GetSnapshot().IsAuthenticated;
    }

    #endregion

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Activity report service started (HTTP batch mode)");
        _logger.LogInformation("Config: BatchSize={BatchSize}, Interval={Interval}min, MaxRetries={MaxRetries}", 
            _batchSize, _reportInterval.TotalMinutes, MaxRetryCount);
        
        // 延迟启动，等待设备注册完成
        await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
        
        while (!stoppingToken.IsCancellationRequested && !_isStopping)
        {
            try
            {
                // ✅ 从 Provider 检查 Token
                if (IsAuthenticated())
                {
                    await ReportPendingActivitiesAsync(stoppingToken);
                }
                else
                {
                    _logger.LogDebug("No token available, waiting for device registration");
                }
                
                await Task.Delay(_reportInterval, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Activity report service error");
                await Task.Delay(_retryDelay, stoppingToken);
            }
        }
        
        // 服务停止前上报剩余数据（有界等待，服从宿主停机令牌）
        try
        {
            using var shutdownCts = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken);
            shutdownCts.CancelAfter(TimeSpan.FromSeconds(8));
            await ReportPendingActivitiesAsync(shutdownCts.Token);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Shutdown activity flush cancelled or timed out");
        }
        
        _logger.LogInformation("Activity report service stopped");
    }

    private async Task ReportPendingActivitiesAsync(CancellationToken ct)
    {
        if (!await _reportLock.WaitAsync(0, ct))
        {
            _logger.LogDebug("Activity report already in progress");
            return;
        }
        
        try
        {
            List<ActivityLog> activities;
            using (var scope = _scopeFactory.CreateScope())
            {
                var repo = scope.ServiceProvider.GetRequiredService<ActivityRepository>();
                // ✅ 获取更多待上报数据（优先新数据，限制重试次数）
                activities = await repo.GetUnreportedAsync(_batchSize * _batchCount);
            }
            
            if (activities.Count == 0)
            {
                return;
            }

            activities = activities
                .Where(ActivityCaptureHelper.ShouldPersist)
                .ToList();

            if (activities.Count == 0)
            {
                return;
            }
            
            _logger.LogInformation("Reporting {Count} pending activities to server", activities.Count);
            
            // ✅ 记录成功和失败的ID
            var successIds = new List<string>();
            var failedActivities = new List<ActivityLog>();
            
            // 分批上报
            for (int i = 0; i < activities.Count; i += _batchSize)
            {
                ct.ThrowIfCancellationRequested();
                
                var batch = activities.Skip(i).Take(_batchSize).ToList();
                var batchIds = batch.Select(a => a.Id).ToList();
                var success = await ReportBatchAsync(batch, ct);
                
                if (success)
                {
                    successIds.AddRange(batchIds);
                    _logger.LogDebug("Reported batch {BatchNumber}, {Count} activities", 
                        i / _batchSize + 1, batch.Count);
                }
                else
                {
                    // ✅ 上报失败，记录失败的活动（不中断，继续尝试其他批次）
                    failedActivities.AddRange(batch);
                    _logger.LogWarning("Failed to report batch {BatchNumber}, will retry later", 
                        i / _batchSize + 1);
                }
            }
            
            // ✅ 处理上报结果
            using (var scope = _scopeFactory.CreateScope())
            {
                var repo = scope.ServiceProvider.GetRequiredService<ActivityRepository>();
                
                // 标记成功上报的
                if (successIds.Count > 0)
                {
                    var marked = await repo.MarkAsReportedAsync(successIds);
                    _logger.LogInformation("Marked {Marked}/{Total} activities as reported", 
                        marked, successIds.Count);
                }
                
                // ✅ 处理失败的活动（增加重试计数，超过最大重试次数的标记为失败）
                if (failedActivities.Count > 0)
                {
                    await ProcessFailedActivitiesAsync(repo, failedActivities);
                }
            }
            
            _lastSuccessfulReport = DateTime.UtcNow;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to report activities");
        }
        finally
        {
            _reportLock.Release();
        }
    }

    /// <summary>
    /// ✅ 处理上报失败的活动（增加重试计数，超过最大重试次数的标记为失败）
    /// </summary>
    private async Task ProcessFailedActivitiesAsync(ActivityRepository repo, List<ActivityLog> failedActivities)
    {
        var toRetry = new List<string>();
        var toMarkFailed = new List<string>();
        
        foreach (var activity in failedActivities)
        {
            // 获取当前重试次数（从数据库读取最新值）
            var currentRetryCount = await repo.GetRetryCountAsync(activity.Id);
            
            if (currentRetryCount >= MaxRetryCount - 1)
            {
                // 已达到最大重试次数，标记为失败
                toMarkFailed.Add(activity.Id);
                _logger.LogWarning("Activity {Id} failed after {RetryCount} retries, marking as failed", 
                    activity.Id, currentRetryCount + 1);
            }
            else
            {
                // 增加重试计数
                toRetry.Add(activity.Id);
                _logger.LogDebug("Activity {Id} will retry (retry count: {RetryCount}/{MaxRetries})", 
                    activity.Id, currentRetryCount + 1, MaxRetryCount);
            }
        }
        
        // 增加重试计数
        if (toRetry.Count > 0)
        {
            await repo.IncrementRetryCountAsync(toRetry);
        }
        
        // 标记为最终失败（不再重试）
        if (toMarkFailed.Count > 0)
        {
            await repo.MarkAsFailedAsync(toMarkFailed, $"Failed after {MaxRetryCount} retries");
        }
    }

    private async Task<bool> ReportBatchAsync(
        List<ActivityLog> activities,
        CancellationToken ct)
    {
        try
        {
            _logger.LogDebug("Reporting batch of {Count} activities", activities.Count);
                
            var httpClient = _httpClient;

            // ✅ 从 Provider 获取当前 DeviceId
            var deviceId = GetCurrentDeviceId();

            var requestBody = new
            {
                deviceId = deviceId,
                activities = activities.Select(a => new
                {
                    id = a.Id,
                    processName = a.ProcessName ?? string.Empty,
                    windowTitle = a.WindowTitle ?? string.Empty,
                    browserTitle = a.BrowserTitle ?? string.Empty,
                    startedAt = a.StartedAt.ToUniversalTime().ToString("O"),
                    endedAt = a.EndedAt?.ToUniversalTime().ToString("O"),
                    isIdle = a.IsIdle,
                    durationSeconds = a.DurationSeconds
                })
            };

            var json = JsonSerializer.Serialize(
                requestBody,
                new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

            using var request = new HttpRequestMessage(
                HttpMethod.Post,
                $"{_config.ServerUrl}/api/v1/activities/report");

            if (!HttpAuthExtensions.TryApplyBearerToken(request, _authTokenProvider))
            {
                _logger.LogWarning("No token available for activity report");
                return false;
            }

            request.Content = new StringContent(
                json,
                Encoding.UTF8,
                "application/json");

            // 单独控制本次请求超时
            using var timeoutCts =
                CancellationTokenSource.CreateLinkedTokenSource(ct);

            timeoutCts.CancelAfter(TimeSpan.FromSeconds(120));

            using var response = await httpClient.SendAsync(
                request,
                HttpCompletionOption.ResponseHeadersRead,
                timeoutCts.Token);

            if (response.IsSuccessStatusCode)
            {
                _logger.LogDebug(
                    "Successfully reported {Count} activities",
                    activities.Count);

                return true;
            }

            var responseBody = await response.Content.ReadAsStringAsync(
                timeoutCts.Token);

            // 如果是 401，尝试刷新 Token 并立即重试
            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                _logger.LogWarning("Activity report returned 401, attempting token refresh...");
                var refreshed = await TryRefreshAuthTokenAsync();
                if (refreshed)
                {
                    using var retryRequest = new HttpRequestMessage(
                        HttpMethod.Post,
                        $"{_config.ServerUrl}/api/v1/activities/report");

                    if (HttpAuthExtensions.TryApplyBearerToken(retryRequest, _authTokenProvider))
                    {
                        retryRequest.Content = new StringContent(
                            json,
                            Encoding.UTF8,
                            "application/json");

                        using var retryTimeoutCts =
                            CancellationTokenSource.CreateLinkedTokenSource(ct);
                        retryTimeoutCts.CancelAfter(TimeSpan.FromSeconds(120));

                        using var retryResponse = await httpClient.SendAsync(
                            retryRequest,
                            HttpCompletionOption.ResponseHeadersRead,
                            retryTimeoutCts.Token);

                        if (retryResponse.IsSuccessStatusCode)
                        {
                            _logger.LogInformation(
                                "Successfully reported {Count} activities after token refresh",
                                activities.Count);
                            return true;
                        }
                    }
                }
            }

            _logger.LogWarning(
                "Failed to report activities. StatusCode={StatusCode}, Response={Response}",
                (int)response.StatusCode,
                responseBody.Length > 500
                    ? responseBody[..500]
                    : responseBody);

            return false;
        }
        catch (OperationCanceledException ex)
        {
            if (ct.IsCancellationRequested)
            {
                _logger.LogInformation(
                    ex,
                    "Activity reporting was cancelled");
            }
            else
            {
                _logger.LogWarning(
                    ex,
                    "Activity reporting timed out");
            }

            return false;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogWarning(
                ex,
                "HTTP error while reporting activities");

            return false;
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Unexpected error while reporting activities");

            return false;
        }
    }

    #region ========== Token 刷新 ==========

    /// <summary>
    /// ✅ 尝试刷新 Token
    /// </summary>
    private async Task<bool> TryRefreshAuthTokenAsync()
    {
        try
        {
            var newToken = await _authTokenProvider.RefreshTokenAsync();
            if (!string.IsNullOrEmpty(newToken))
            {
                _logger.LogInformation("Auth token refreshed successfully");
                return true;
            }

            _logger.LogWarning("Token refresh returned empty token");
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to refresh auth token");
            return false;
        }
    }

    #endregion

    /// <summary>
    /// 强制立即上报（供外部调用）
    /// </summary>
    public async Task ForceReportAsync()
    {
        _logger.LogInformation("Forcing activity report");
        await ReportPendingActivitiesAsync(CancellationToken.None);
    }

    /// <summary>
    /// 获取待上报数量
    /// </summary>
    public async Task<int> GetPendingCountAsync()
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<ActivityRepository>();
        return await repo.GetPendingReportCountAsync();
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Stopping activity report service...");
        _isStopping = true;

        await base.StopAsync(cancellationToken);
    }

    public override void Dispose()
    {
        _reportLock?.Dispose();
        base.Dispose();
    }
}
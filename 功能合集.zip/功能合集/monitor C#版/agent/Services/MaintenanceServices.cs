// Services/MaintenanceServices.cs - 清理和健康检查合并
using System.Diagnostics;
using System.IO.Compression;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace EnterpriseAgent.Agent.Services;

#region 清理服务

/// <summary>
/// 本地清理统一入口：保留期清理、磁盘压力清理、Agent 日志清理均由此服务执行。
/// 策略未从服务器同步时使用 <see cref="CleanupPolicy.CreateDefault"/>，不会因 policy 为空而跳过。
/// </summary>
public class CleanupService : BackgroundService
{
    private readonly ILogger<CleanupService> _logger;
    private readonly AgentConfig _config;
    private CleanupPolicy _currentPolicy;
    private readonly IServiceScopeFactory _scopeFactory;
    private DateTime _lastDiskPressureCleanup = DateTime.MinValue;

    private const int DiskPressureCooldownMinutes = 5;
    private const int EmergencyBatchSize = 100;
    private const int MaxEmergencyBatches = 10;

    public CleanupService(
        ILogger<CleanupService> logger,
        IServiceScopeFactory scopeFactory,
        AgentConfig config)
    {
        _logger = logger;
        _scopeFactory = scopeFactory;
        _config = config;
        _currentPolicy = CleanupPolicy.CreateDefault();
    }

    public CleanupPolicy GetEffectivePolicy() => _currentPolicy;

    public void UpdatePolicy(CleanupPolicy policy)
    {
        _currentPolicy = policy;
        _logger.LogInformation(
            "Cleanup policy updated: enabled={Enabled}, recordings={RecordingDays}d, screenshots={ScreenshotDays}d, logs={LogDays}d, threshold={Threshold}%",
            policy.Enabled, policy.RecordingDays, policy.ScreenshotDays, policy.LogDays, policy.DiskThresholdPercent);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Cleanup service started (default policy active until server sync)");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var now = DateTime.UtcNow;
                var nextRun = now.Date.AddDays(1).AddHours(Constants.CleanupServiceHourUtc);
                var delay = nextRun - now;
                if (delay < TimeSpan.Zero)
                    delay = delay.Add(TimeSpan.FromDays(1));

                await Task.Delay(delay, stoppingToken);
                await RunRetentionCleanupAsync(CleanupTrigger.Scheduled, stoppingToken);
                await RunAgentLogCleanupAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Scheduled cleanup failed");
                await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
            }
        }
    }

    /// <summary>按保留天数清理录屏/截图/活动日志（统一逻辑）</summary>
    public async Task<LocalCleanupResult> RunRetentionCleanupAsync(
        CleanupTrigger trigger,
        CancellationToken ct = default,
        int? recordingDaysOverride = null,
        int? screenshotDaysOverride = null,
        int? logDaysOverride = null,
        bool skipDiskPressurePass = false)
    {
        var policy = GetEffectivePolicy();
        if (!policy.Enabled && trigger is not (CleanupTrigger.Manual or CleanupTrigger.RemoteTask))
        {
            _logger.LogDebug("Retention cleanup skipped: disabled by policy (trigger={Trigger})", trigger);
            return new LocalCleanupResult();
        }

        var recordingDays = recordingDaysOverride ?? policy.RecordingDays;
        var screenshotDays = screenshotDaysOverride ?? policy.ScreenshotDays;
        var logDays = logDaysOverride ?? policy.LogDays;

        var storagePath = GetStoragePath();
        var now = DateTime.UtcNow;
        var recordingCutoff = now.AddDays(-recordingDays);
        var screenshotCutoff = now.AddDays(-screenshotDays);
        var activityCutoff = now.AddDays(-logDays);

        var result = new LocalCleanupResult();
        var status = "success";
        var message = $"cleanup completed ({trigger})";

        try
        {
            _logger.LogInformation(
                "Starting retention cleanup ({Trigger}): recordings={RecDays}d, screenshots={ScrDays}d, logs={LogDays}d",
                trigger, recordingDays, screenshotDays, logDays);

            var recordingsPath = Path.Combine(storagePath, "recordings");
            result.DeletedRecordingFiles = await CleanupOldFilesAsync(recordingsPath, recordingCutoff, "*.mp4");

            var screenshotsPath = Path.Combine(storagePath, "screenshots");
            result.DeletedScreenshotFiles = await CleanupOldFilesAsync(
                screenshotsPath, screenshotCutoff, "*.webp", "*.jpg", "*.jpeg");

            using (var scope = _scopeFactory.CreateScope())
            {
                var recordingRepo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();
                await recordingRepo.DeleteOlderThanAsync(recordingCutoff);

                var screenshotRepo = scope.ServiceProvider.GetRequiredService<ScreenshotRepository>();
                result.DeletedScreenshotRows = await screenshotRepo.DeleteOlderThanAsync(screenshotCutoff);

                var activityRepo = scope.ServiceProvider.GetRequiredService<ActivityRepository>();
                result.DeletedActivityRows = await activityRepo.DeleteOlderThanAsync(activityCutoff);

                var uploadRepo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
                result.DeletedFailedUploadRows = await uploadRepo.DeleteFailedAsync();
            }

            if (!skipDiskPressurePass && TryGetDiskUsagePercent(storagePath, out var usagePercent)
                && usagePercent > policy.DiskThresholdPercent)
            {
                _logger.LogWarning(
                    "Disk usage {UsagePercent:F1}% exceeds threshold {Threshold}% after retention cleanup",
                    usagePercent, policy.DiskThresholdPercent);
                var pressureResult = await RunDiskPressureCleanupAsync(DiskPressureLevel.Warning, ct, skipRetentionPass: true);
                result.Merge(pressureResult);
            }

            _logger.LogInformation(
                "Retention cleanup done ({Trigger}): recordings={RecFiles}, screenshots={ScrFiles}, activity={ActRows}",
                trigger, result.DeletedRecordingFiles, result.DeletedScreenshotFiles, result.DeletedActivityRows);
        }
        catch (Exception ex)
        {
            status = "failed";
            message = ex.Message;
            _logger.LogError(ex, "Retention cleanup failed ({Trigger})", trigger);
            throw;
        }
        finally
        {
            if (trigger is CleanupTrigger.Scheduled or CleanupTrigger.Manual or CleanupTrigger.RemoteTask)
            {
                await SaveCleanupLogAsync(status, message, result);
            }
        }

        return result;
    }

    /// <summary>磁盘压力清理：先缩短保留期，再按最旧文件批量删除</summary>
    public async Task<LocalCleanupResult> RunDiskPressureCleanupAsync(
        DiskPressureLevel level,
        CancellationToken ct = default,
        bool skipRetentionPass = false)
    {
        var result = new LocalCleanupResult();
        var policy = GetEffectivePolicy();

        if (!policy.Enabled)
            return result;

        if ((DateTime.UtcNow - _lastDiskPressureCleanup).TotalMinutes < DiskPressureCooldownMinutes)
        {
            _logger.LogDebug("Skipping disk pressure cleanup (cooldown {Minutes}m)",
                DiskPressureCooldownMinutes);
            return result;
        }

        _lastDiskPressureCleanup = DateTime.UtcNow;
        var storagePath = GetStoragePath();

        _logger.LogWarning("Running disk pressure cleanup ({Level})", level);

        if (!skipRetentionPass)
        {
            int recDays = policy.RecordingDays;
            int scrDays = policy.ScreenshotDays;
            if (level == DiskPressureLevel.Critical)
            {
                recDays = Math.Max(1, recDays / 2);
                scrDays = Math.Max(1, scrDays / 2);
            }

            var retentionResult = await RunRetentionCleanupAsync(
                level == DiskPressureLevel.Critical ? CleanupTrigger.DiskCritical : CleanupTrigger.DiskThreshold,
                ct,
                recordingDaysOverride: recDays,
                screenshotDaysOverride: scrDays,
                skipDiskPressurePass: true);
            result.Merge(retentionResult);
        }

        var batches = 0;
        while (batches < MaxEmergencyBatches
               && TryGetDiskUsagePercent(storagePath, out var usage)
               && usage > policy.DiskThresholdPercent)
        {
            ct.ThrowIfCancellationRequested();
            var deleted = await DeleteOldestFilesBatchAsync(storagePath, EmergencyBatchSize);
            result.DeletedRecordingFiles += deleted.recordings;
            result.DeletedScreenshotFiles += deleted.screenshots;
            if (deleted.recordings + deleted.screenshots == 0)
                break;
            batches++;
        }

        if (level == DiskPressureLevel.Critical)
        {
            await CleanupEmptyDirectoriesAsync(Path.Combine(storagePath, "recordings"));
            await CleanupEmptyDirectoriesAsync(Path.Combine(storagePath, "screenshots"));
        }

        return result;
    }

    /// <summary>清理 Agent 文本日志（按策略 logDays + 文件数上限）</summary>
    public async Task<LocalCleanupResult> RunAgentLogCleanupAsync(CancellationToken ct = default)
    {
        var result = new LocalCleanupResult();
        var logDirectory = AppPaths.GetLogsPath();
        if (!Directory.Exists(logDirectory))
            return result;

        var retentionDays = GetEffectivePolicy().LogDays;
        var cutoff = DateTime.UtcNow.AddDays(-retentionDays);
        var compressCutoff = DateTime.UtcNow.AddDays(-Math.Max(1, retentionDays / 2));

        foreach (var file in Directory.GetFiles(logDirectory, "*.log*"))
        {
            if (file.EndsWith(".gz", StringComparison.OrdinalIgnoreCase))
                continue;

            try
            {
                var info = new FileInfo(file);
                if (info.LastWriteTimeUtc < cutoff)
                {
                    File.Delete(file);
                    result.DeletedAgentLogFiles++;
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to delete old log: {File}", file);
            }
        }

        foreach (var file in Directory.GetFiles(logDirectory, "*.log")
                     .Where(f => !File.Exists(f + ".gz")))
        {
            try
            {
                if (new FileInfo(file).LastWriteTimeUtc < compressCutoff)
                {
                    await CompressLogFileAsync(file);
                    result.CompressedAgentLogFiles++;
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to compress log: {File}", file);
            }
        }

        var logFiles = Directory.GetFiles(logDirectory, "*.log")
            .Select(f => new FileInfo(f))
            .OrderByDescending(f => f.LastWriteTimeUtc)
            .Skip(Constants.DefaultLogMaxFiles)
            .ToList();

        foreach (var file in logFiles)
        {
            try
            {
                file.Delete();
                result.DeletedAgentLogFiles++;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to delete excess log: {File}", file.Name);
            }
        }

        if (result.DeletedAgentLogFiles > 0 || result.CompressedAgentLogFiles > 0)
        {
            _logger.LogInformation(
                "Agent log cleanup: deleted={Deleted}, compressed={Compressed}, retention={Days}d",
                result.DeletedAgentLogFiles, result.CompressedAgentLogFiles, retentionDays);
        }

        return result;
    }

    private async Task<int> CleanupOldFilesAsync(string path, DateTime cutoff, params string[] patterns)
    {
        var deleted = 0;
        if (!Directory.Exists(path))
            return deleted;

        foreach (var pattern in patterns)
        {
            foreach (var file in Directory.GetFiles(path, pattern, SearchOption.AllDirectories))
            {
                try
                {
                    var info = new FileInfo(file);
                    if (info.Length <= Constants.MinRecordingFileBytes && pattern.Contains("mp4"))
                        continue;
                    if (info.LastWriteTimeUtc < cutoff)
                    {
                        File.Delete(file);
                        deleted++;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to delete {File}", Path.GetFileName(file));
                }
            }
        }

        return deleted;
    }

    private async Task<(int recordings, int screenshots)> DeleteOldestFilesBatchAsync(string storagePath, int batchSize)
    {
        var recordingsPath = Path.Combine(storagePath, "recordings");
        var screenshotsPath = Path.Combine(storagePath, "screenshots");
        var deletedRecordings = 0;
        var deletedScreenshots = 0;

        if (Directory.Exists(recordingsPath))
        {
            foreach (var file in Directory.GetFiles(recordingsPath, "*.mp4", SearchOption.AllDirectories)
                         .Select(f => new FileInfo(f))
                         .Where(f => f.Length > Constants.MinRecordingFileBytes)
                         .OrderBy(f => f.CreationTimeUtc)
                         .Take(batchSize))
            {
                try
                {
                    file.Delete();
                    deletedRecordings++;
                }
                catch (Exception ex)
                {
                    _logger.LogDebug(ex, "Emergency delete failed: {File}", file.Name);
                }
            }
        }

        if (Directory.Exists(screenshotsPath))
        {
            foreach (var file in Directory.GetFiles(screenshotsPath, "*.*", SearchOption.AllDirectories)
                         .Where(f => f.EndsWith(".webp", StringComparison.OrdinalIgnoreCase)
                                  || f.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase)
                                  || f.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase))
                         .Select(f => new FileInfo(f))
                         .OrderBy(f => f.CreationTimeUtc)
                         .Take(batchSize))
            {
                try
                {
                    file.Delete();
                    deletedScreenshots++;
                }
                catch (Exception ex)
                {
                    _logger.LogDebug(ex, "Emergency delete failed: {File}", file.Name);
                }
            }
        }

        if (deletedRecordings + deletedScreenshots > 0)
        {
            _logger.LogWarning(
                "Emergency batch deleted {Recordings} recordings and {Screenshots} screenshots",
                deletedRecordings, deletedScreenshots);
        }

        return (deletedRecordings, deletedScreenshots);
    }

    private static async Task CleanupEmptyDirectoriesAsync(string rootPath)
    {
        if (!Directory.Exists(rootPath))
            return;

        await Task.Run(() =>
        {
            var emptyDirs = Directory.GetDirectories(rootPath, "*", SearchOption.AllDirectories)
                .Where(dir => !Directory.EnumerateFileSystemEntries(dir).Any())
                .OrderByDescending(dir => dir.Length);

            foreach (var dir in emptyDirs)
            {
                try { Directory.Delete(dir); }
                catch { /* ignore */ }
            }
        });
    }

    private static async Task CompressLogFileAsync(string filePath)
    {
        await using var originalStream = File.OpenRead(filePath);
        await using var compressedStream = File.Create(filePath + ".gz");
        await using var gzipStream = new GZipStream(compressedStream, CompressionLevel.Optimal);
        await originalStream.CopyToAsync(gzipStream);
        await gzipStream.FlushAsync();
        File.Delete(filePath);
    }

    private bool TryGetDiskUsagePercent(string storagePath, out double usagePercent)
    {
        usagePercent = 0;
        var drive = Path.GetPathRoot(storagePath);
        if (drive == null)
            return false;

        var info = new DriveInfo(drive);
        if (info.TotalSize <= 0)
            return false;

        usagePercent = (1 - info.AvailableFreeSpace / (double)info.TotalSize) * 100;
        return true;
    }

    private async Task SaveCleanupLogAsync(string status, string message, LocalCleanupResult result)
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<SqliteDbContext>();
        using var conn = db.GetConnection();
        using var cmd = new SqliteCommand(@"
            INSERT INTO cleanup_logs (id, status, message, recording_file_deletes, screenshot_file_deletes, 
                screenshot_row_deletes, activity_log_deletes, failed_upload_queue_deletes, created_at)
            VALUES (@id, @status, @message, @rfd, @sfd, @srd, @ald, @fuqd, @created)", conn);

        cmd.Parameters.AddWithValue("@id", Guid.NewGuid().ToString());
        cmd.Parameters.AddWithValue("@status", status);
        cmd.Parameters.AddWithValue("@message", SensitiveDataFilter.FilterStatic(message));
        cmd.Parameters.AddWithValue("@rfd", result.DeletedRecordingFiles);
        cmd.Parameters.AddWithValue("@sfd", result.DeletedScreenshotFiles);
        cmd.Parameters.AddWithValue("@srd", result.DeletedScreenshotRows);
        cmd.Parameters.AddWithValue("@ald", result.DeletedActivityRows);
        cmd.Parameters.AddWithValue("@fuqd", result.DeletedFailedUploadRows);
        cmd.Parameters.AddWithValue("@created", DateTime.UtcNow.ToIso8601String());

        await cmd.ExecuteNonQueryAsync();
    }

    private string GetStoragePath() => _config.GetEffectiveStoragePath();
}

#endregion

#region 健康检查服务

/// <summary>
/// 健康检查服务 - 提供存活和就绪检查端点
/// </summary>
public class HealthService : BackgroundService
{
    private readonly ILogger<HealthService> _logger;
    private readonly AgentConfig _config;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly WebSocketService _webSocketService;
    private readonly ScreenRecorderService _recorderService;
    private readonly PolicySyncService? _policySyncService;
    
    private HealthStatus _currentStatus = HealthStatus.Starting;
    private string _lastMessage = "Service starting";
    private readonly List<HealthCheckItem> _checkResults = new();

    public HealthService(
        ILogger<HealthService> logger,
        AgentConfig config,
        IServiceScopeFactory scopeFactory,
        WebSocketService webSocketService,
        ScreenRecorderService recorderService,
        PolicySyncService? policySyncService = null)
    {
        _logger = logger;
        _config = config;
        _scopeFactory = scopeFactory;
        _webSocketService = webSocketService;
        _recorderService = recorderService;
        _policySyncService = policySyncService;
    }

    /// <summary>
    /// 获取当前健康报告
    /// </summary>
    public Models.HealthReport GetHealthReport()
    {
        return new Models.HealthReport
        {
            Status = _currentStatus.ToString(),
            Timestamp = DateTime.UtcNow,
            Checks = _checkResults.Select(r => new HealthCheck 
            { 
                Name = r.Name, 
                Healthy = r.IsHealthy, 
                Message = r.Message, 
                Duration = r.Duration,
                CheckedAt = r.CheckedAt
            }).ToList(),
            Details = _lastMessage
        };
    }

    /// <summary>
    /// 存活检查（进程是否存活）
    /// </summary>
    public bool IsAlive() => _currentStatus != HealthStatus.Stopped;

    /// <summary>
    /// 就绪检查（服务是否可用）
    /// </summary>
    public bool IsReady() => _currentStatus == HealthStatus.Healthy;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Health check service started");
        
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await PerformHealthCheckAsync(stoppingToken);
                await Task.Delay(TimeSpan.FromSeconds(Constants.HealthCheckIntervalMs / 1000), stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Health check failed");
                await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
            }
        }
        
        _currentStatus = HealthStatus.Stopped;
        _logger.LogInformation("Health check service stopped");
    }

    private async Task PerformHealthCheckAsync(CancellationToken ct)
    {
        var results = new List<HealthCheckItem>();
        var allHealthy = true;
        var messages = new List<string>();

        // 1. 数据库检查
        var dbResult = await CheckDatabaseAsync(ct);
        results.Add(dbResult);
        if (!dbResult.IsHealthy) allHealthy = false;
        messages.Add(dbResult.Message ?? "OK");

        // 2. 磁盘空间检查
        var diskResult = CheckDiskSpace();
        results.Add(diskResult);
        if (!diskResult.IsHealthy) allHealthy = false;
        messages.Add(diskResult.Message ?? "OK");

        // 3. WebSocket 连接检查
        var wsResult = CheckWebSocket();
        results.Add(wsResult);
        if (!wsResult.IsHealthy) allHealthy = false;
        messages.Add(wsResult.Message ?? "OK");

        // 4. 录屏进程检查
        var recordingResult = CheckRecording();
        results.Add(recordingResult);
        if (!recordingResult.IsHealthy) allHealthy = false;
        messages.Add(recordingResult.Message ?? "OK");

        // 5. 上传队列检查
        var uploadResult = await CheckUploadQueueAsync(ct);
        results.Add(uploadResult);
        if (!uploadResult.IsHealthy) allHealthy = false;
        messages.Add(uploadResult.Message ?? "OK");

        _checkResults.Clear();
        _checkResults.AddRange(results);

        var newStatus = allHealthy ? HealthStatus.Healthy : HealthStatus.Degraded;
        var newMessage = string.Join("; ", messages.Where(m => !string.IsNullOrEmpty(m) && m != "OK"));

        if (newStatus != _currentStatus)
        {
            _logger.LogInformation("Health status changed: {OldStatus} -> {NewStatus}, Message: {Message}", 
                _currentStatus, newStatus, newMessage);
        }
        else
        {
            // ✅ 添加健康时的 Debug 日志（可选）
            _logger.LogDebug("Health status unchanged: {Status}, Message: {Message}", _currentStatus, newMessage);
        }

        _currentStatus = newStatus;
        _lastMessage = string.IsNullOrEmpty(newMessage) ? "All systems operational" : newMessage;
    }

    private async Task<HealthCheckItem> CheckDatabaseAsync(CancellationToken ct)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<SqliteDbContext>();
            using var conn = db.GetConnection();
            
            using var cmd = new SqliteCommand("SELECT 1", conn);
            await cmd.ExecuteScalarAsync(ct);
            
            stopwatch.Stop();
            return HealthCheckItem.Healthy("Database", duration: stopwatch.Elapsed);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            return HealthCheckItem.Unhealthy("Database", ex.Message, duration: stopwatch.Elapsed);
        }
    }

    private HealthCheckItem CheckDiskSpace()
    {
        try
        {
            var storagePath = _config.GetEffectiveStoragePath();
            var drive = Path.GetPathRoot(storagePath);
            if (drive != null)
            {
                var info = new DriveInfo(drive);
                var freeGB = info.AvailableFreeSpace / 1024.0 / 1024 / 1024;
                
                if (freeGB < 1)
                    return HealthCheckItem.Unhealthy("Disk", $"Free space: {freeGB:F1}GB (< 1GB)");
                if (freeGB < 5)
                    return HealthCheckItem.Degraded("Disk", $"Free space: {freeGB:F1}GB (< 5GB)");
                
                return HealthCheckItem.Healthy("Disk", $"Free space: {freeGB:F1}GB");
            }
            return HealthCheckItem.Healthy("Disk", "OK");
        }
        catch (Exception ex)
        {
            return HealthCheckItem.Unhealthy("Disk", ex.Message);
        }
    }

    private HealthCheckItem CheckWebSocket()
    {
        if (_webSocketService.IsConnected)
            return HealthCheckItem.Healthy("WebSocket", "Connected");
        return HealthCheckItem.Degraded("WebSocket", "Disconnected");
    }

    private HealthCheckItem CheckRecording()
    {
        try
        {
            RecordingConfig policy = new RecordingConfig();
            
            if (_policySyncService != null)
            {
                var currentPolicy = _policySyncService.GetCurrentPolicy();
                if (currentPolicy != null)
                {
                    policy = currentPolicy.GetRecordingConfig();
                }
            }
            
            if (!policy.Enabled)
                return HealthCheckItem.Healthy("Recording", "Disabled by policy");
            
            return HealthCheckItem.Healthy("Recording", "Running");
        }
        catch (Exception ex)
        {
            return HealthCheckItem.Degraded("Recording", ex.Message);
        }
    }

    private async Task<HealthCheckItem> CheckUploadQueueAsync(CancellationToken ct)
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();

            var repo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();

            // ✅ 注意：GetQueueStatsAsync 目前不支持 CancellationToken
            // 这里传递 ct 是为了在 Repository 方法支持时使用
            // 当前保持原样，但标记了 ct 参数已考虑

            var stats = await repo.GetQueueStatsAsync();

            if (stats.failed > 50)
            {
                return HealthCheckItem.Degraded(
                    "UploadQueue",
                    $"Failed: {stats.failed}");
            }

            if (stats.pending > 500)
            {
                return HealthCheckItem.Degraded(
                    "UploadQueue",
                    $"Pending: {stats.pending}");
            }

            return HealthCheckItem.Healthy(
                "UploadQueue",
                $"Pending: {stats.pending}, Failed: {stats.failed}");
        }
        catch (OperationCanceledException)
        {
            return HealthCheckItem.Degraded(
                "UploadQueue",
                "Operation cancelled");
        }
        catch (Exception ex)
        {
            return HealthCheckItem.Unhealthy(
                "UploadQueue",
                ex.Message);
        }
    }
}

/// <summary>
/// 健康状态枚举
/// </summary>
public enum HealthStatus
{
    Starting,
    Healthy,
    Degraded,
    Unhealthy,
    Stopped
}

/// <summary>
/// 健康检查结果项（自定义，避免与 Microsoft 命名冲突）
/// </summary>
public class HealthCheckItem
{
    public string Name { get; set; } = "";
    public bool IsHealthy { get; set; }
    public string? Message { get; set; }
    public TimeSpan Duration { get; set; }
    public DateTime CheckedAt { get; set; } = DateTime.UtcNow;

    public static HealthCheckItem Healthy(string name, string? message = null, TimeSpan? duration = null)
    {
        return new HealthCheckItem 
        { 
            Name = name, 
            IsHealthy = true, 
            Message = message, 
            Duration = duration ?? TimeSpan.Zero 
        };
    }

    public static HealthCheckItem Degraded(string name, string? message = null, TimeSpan? duration = null)
    {
        return new HealthCheckItem 
        { 
            Name = name, 
            IsHealthy = false, 
            Message = message, 
            Duration = duration ?? TimeSpan.Zero 
        };
    }

    public static HealthCheckItem Unhealthy(string name, string? message = null, TimeSpan? duration = null)
    {
        return new HealthCheckItem 
        { 
            Name = name, 
            IsHealthy = false, 
            Message = message, 
            Duration = duration ?? TimeSpan.Zero 
        };
    }
}

/// <summary>
/// 远程查看健康检查
/// </summary>
public class RemoteViewHealthCheck : IHealthCheck
{
    private readonly RemoteView.IRemoteViewPublisher _publisher;

    public RemoteViewHealthCheck(RemoteView.IRemoteViewPublisher publisher)
    {
        _publisher = publisher;
    }

    public Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (_publisher.IsPublishing)
            {
                return Task.FromResult(HealthCheckResult.Healthy("远程查看发布中"));
            }

            return Task.FromResult(HealthCheckResult.Healthy("远程查看服务就绪"));
        }
        catch (Exception ex)
        {
            return Task.FromResult(HealthCheckResult.Unhealthy(ex.Message, ex));
        }
    }
}

/// <summary>
/// 数据库健康检查
/// </summary>
public class DatabaseHealthCheck : IHealthCheck
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<DatabaseHealthCheck> _logger;

    public DatabaseHealthCheck(IServiceProvider serviceProvider, ILogger<DatabaseHealthCheck> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        try
        {
            using var scope = _serviceProvider.CreateScope();
            var dbContext = scope.ServiceProvider.GetRequiredService<SqliteDbContext>();
            
            using var conn = dbContext.GetConnection();
            using var cmd = new SqliteCommand("SELECT 1", conn);
            var result = await cmd.ExecuteScalarAsync(cancellationToken);
            
            if (result != null && result.ToString() == "1")
            {
                return HealthCheckResult.Healthy("Database is operational");
            }
            
            return HealthCheckResult.Unhealthy("Database query returned unexpected result");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Database health check failed");
            return HealthCheckResult.Unhealthy("Database connection failed", ex);
        }
    }
}

#endregion

#region 日志清理服务

/// <summary>
/// 日志清理调度器 — 实际清理逻辑由 <see cref="CleanupService"/> 统一执行。
/// </summary>
public class LogCleanupService : BackgroundService
{
    private readonly ILogger<LogCleanupService> _logger;
    private readonly CleanupService _cleanupService;

    public LogCleanupService(ILogger<LogCleanupService> logger, CleanupService cleanupService)
    {
        _logger = logger;
        _cleanupService = cleanupService;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var policy = _cleanupService.GetEffectivePolicy();
        _logger.LogInformation("日志清理调度已启动，保留天数: {Days}", policy.LogDays);
        await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await _cleanupService.RunAgentLogCleanupAsync(stoppingToken);
                await Task.Delay(TimeSpan.FromDays(1), stoppingToken);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                _logger.LogError(ex, "日志清理失败");
                await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
            }
        }
    }

    public Task ForceCleanupAsync() => _cleanupService.RunAgentLogCleanupAsync();
}

#endregion

#region 内存管理服务

public class MemoryManagementService : BackgroundService
{
    private readonly ILogger<MemoryManagementService> _logger;
    private const long MemoryWarningThreshold = 400 * 1024 * 1024;
    private const long MemoryCriticalThreshold = 600 * 1024 * 1024;
    private int _highMemoryCount;
    private DateTime _lastGcTime = DateTime.UtcNow;
    private readonly List<long> _memoryHistory = new();
    private Process? _cachedProcess;
    private DateTime _processCacheTime;
    private readonly object _processLock = new();

    public MemoryManagementService(ILogger<MemoryManagementService> logger) => _logger = logger;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("内存管理服务已启动");
        TriggerGC("服务启动");
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await MonitorAndManageMemoryAsync();
                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                _logger.LogError(ex, "内存管理服务异常");
                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }
        _logger.LogInformation("内存管理服务已停止");
    }

    private Process GetCurrentProcessCached()
    {
        lock (_processLock)
        {
            if (_cachedProcess == null || DateTime.UtcNow - _processCacheTime > TimeSpan.FromMinutes(5))
            {
                _cachedProcess?.Dispose();
                _cachedProcess = Process.GetCurrentProcess();
                _processCacheTime = DateTime.UtcNow;
            }
            return _cachedProcess;
        }
    }

    private async Task MonitorAndManageMemoryAsync()
    {
        var process = GetCurrentProcessCached();
        lock (_memoryHistory)
        {
            _memoryHistory.Add(process.WorkingSet64);
            while (_memoryHistory.Count > 10) _memoryHistory.RemoveAt(0);
        }

        if (process.WorkingSet64 > MemoryCriticalThreshold)
        {
            TriggerGC("内存使用过高");
            if (++_highMemoryCount >= 3)
            {
                await LogMemoryDiagnosticsAsync(process);
                _highMemoryCount = 0;
            }
        }
        else if (process.WorkingSet64 > MemoryWarningThreshold)
        {
            if (DateTime.UtcNow - _lastGcTime > TimeSpan.FromMinutes(10)) TriggerGC("定期清理");
        }
        else if (DateTime.UtcNow - _lastGcTime > TimeSpan.FromMinutes(30))
        {
            TriggerGC("定期维护");
        }
    }

    private void TriggerGC(string reason, bool forceFullGC = false)
    {
        if (forceFullGC)
        {
            GC.Collect(2, GCCollectionMode.Forced, blocking: true, compacting: true);
            GC.WaitForPendingFinalizers();
            GC.Collect(2, GCCollectionMode.Forced, blocking: true, compacting: true);
        }
        else
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
        _lastGcTime = DateTime.UtcNow;
        _logger.LogDebug("GC 完成 - 原因: {Reason}", reason);
    }

    private static async Task LogMemoryDiagnosticsAsync(Process process)
    {
        var diagPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs", "memory_diagnostics.log");
        var diagDir = Path.GetDirectoryName(diagPath);
        if (!string.IsNullOrEmpty(diagDir)) Directory.CreateDirectory(diagDir);
        await File.AppendAllTextAsync(diagPath,
            $"[{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss}] Memory: {process.WorkingSet64 / 1024 / 1024}MB\n");
    }

    public void ForceCleanup() => TriggerGC("手动强制清理", forceFullGC: true);

    public MemoryStats GetMemoryStats()
    {
        var process = GetCurrentProcessCached();
        return new MemoryStats
        {
            WorkingSetMB = process.WorkingSet64 / 1024 / 1024,
            PrivateMemoryMB = process.PrivateMemorySize64 / 1024 / 1024,
            GCMemoryMB = GC.GetTotalMemory(false) / 1024 / 1024,
            ThreadCount = process.Threads.Count,
            HandleCount = process.HandleCount,
            LastGCTime = _lastGcTime
        };
    }

    public override void Dispose()
    {
        lock (_processLock) { _cachedProcess?.Dispose(); _cachedProcess = null; }
        base.Dispose();
    }
}

public class MemoryStats
{
    public long WorkingSetMB { get; set; }
    public long PrivateMemoryMB { get; set; }
    public long GCMemoryMB { get; set; }
    public int ThreadCount { get; set; }
    public int HandleCount { get; set; }
    public DateTime LastGCTime { get; set; }
}

#endregion

// Services/ScreenCapture.cs - 修复 BitBlt failed 错误

using System.Buffers;
using System.Runtime.InteropServices;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing; 
using Microsoft.Extensions.Logging;
using Rectangle = SixLabors.ImageSharp.Rectangle;
using ImageSharpColor = SixLabors.ImageSharp.Color;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 纯 ImageSharp 屏幕捕获器 - 支持对象池
/// </summary>
public sealed class ScreenCapture : IDisposable
{
    private readonly ILogger<ScreenCapture> _logger;
    private nint _screenDC;
    private nint _memoryDC;
    private nint _bitmap;
    private nint _oldBitmap;
    private int _lastWidth;
    private int _lastHeight;
    private bool _disposed;
    private readonly object _lock = new();
    
    // 对象池
    private static readonly ArrayPool<byte> _bytePool = ArrayPool<byte>.Shared;
    private static readonly object _poolLock = new();
    private static readonly Stack<Image<Rgba32>> _imagePool = new();
    private static int _poolSize = 0;
    private const int MaxPoolSize = 10;

    // ✅ 添加 GetDesktopWindow 声明
    [DllImport("user32.dll")]
    private static extern nint GetDesktopWindow();

    [DllImport("user32.dll")]
    private static extern nint GetDC(nint hWnd);

    [DllImport("user32.dll")]
    private static extern int ReleaseDC(nint hWnd, nint hDC);

    [DllImport("gdi32.dll")]
    private static extern nint CreateCompatibleDC(nint hdc);

    [DllImport("gdi32.dll")]
    private static extern nint CreateCompatibleBitmap(nint hdc, int nWidth, int nHeight);

    [DllImport("gdi32.dll")]
    private static extern nint SelectObject(nint hdc, nint hgdiobj);

    [DllImport("gdi32.dll")]
    private static extern bool DeleteDC(nint hdc);

    [DllImport("gdi32.dll")]
    private static extern bool DeleteObject(nint hObject);

    [DllImport("gdi32.dll")]
    private static extern bool BitBlt(nint hdcDest, int nXDest, int nYDest, int nWidth, int nHeight,
        nint hdcSrc, int nXSrc, int nYSrc, uint dwRop);

    [DllImport("gdi32.dll")]
    private static extern int GetDIBits(nint hdc, nint hbm, uint start, uint cLines, 
        byte[] lpvBits, ref BITMAPINFO lpbmi, uint fuUsage);

    private const uint SRCCOPY = 0x00CC0020;
    private const int BI_RGB = 0;

    [StructLayout(LayoutKind.Sequential)]
    private struct BITMAPINFOHEADER
    {
        public uint biSize;
        public int biWidth;
        public int biHeight;
        public ushort biPlanes;
        public ushort biBitCount;
        public uint biCompression;
        public uint biSizeImage;
        public int biXPelsPerMeter;
        public int biYPelsPerMeter;
        public uint biClrUsed;
        public uint biClrImportant;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct BITMAPINFO
    {
        public BITMAPINFOHEADER bmiHeader;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
        public uint[] bmiColors;
    }

    public ScreenCapture(ILogger<ScreenCapture> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// 从池中获取图像
    /// </summary>
    public static Image<Rgba32> RentImage(int width, int height)
    {
        lock (_poolLock)
        {
            while (_imagePool.Count > 0)
            {
                var img = _imagePool.Pop();
                _poolSize--;
                if (img.Width == width && img.Height == height)
                {
                    return img;
                }
                img.Dispose();
            }
        }
        return new Image<Rgba32>(width, height);
    }

    /// <summary>
    /// 归还图像到池中
    /// </summary>
    public static void ReturnImage(Image<Rgba32> image)
    {
        if (image == null) return;
        
        lock (_poolLock)
        {
            if (_poolSize < MaxPoolSize)
            {
                _imagePool.Push(image);
                _poolSize++;
                return;
            }
        }
        image.Dispose();
    }

    /// <summary>
    /// 捕获屏幕为 Image{Rgba32}
    /// </summary>
    public Image<Rgba32> Capture(Rectangle bounds)
    {
        if (_disposed) throw new ObjectDisposedException(nameof(ScreenCapture));

        lock (_lock)
        {
            try
            {
                var width = bounds.Width;
                var height = bounds.Height;
                
                if (width <= 0 || height <= 0)
                    throw new ArgumentException("Invalid bounds");

                InitializeResources(width, height);

                // ✅ 修复：重试 BitBlt 3 次
                bool bitBltSuccess = false;
                for (int retry = 0; retry < 3; retry++)
                {
                    if (BitBlt(_memoryDC, 0, 0, width, height, _screenDC, bounds.X, bounds.Y, SRCCOPY))
                    {
                        bitBltSuccess = true;
                        break;
                    }
                    if (retry < 2)
                    {
                        Thread.Sleep(50);
                    }
                }

                if (!bitBltSuccess)
                {
                    var errorCode = Marshal.GetLastWin32Error();
                    _logger.LogWarning("BitBlt failed after retries, error code: {ErrorCode}, returning blank image", errorCode);
                    // ✅ 返回空白图像而不是抛出异常
                    return new Image<Rgba32>(width, height);
                }

                var stride = width * 4;
                var buffer = _bytePool.Rent(height * stride);
                
                try
                {
                    var bmi = new BITMAPINFO();
                    bmi.bmiHeader.biSize = (uint)Marshal.SizeOf<BITMAPINFOHEADER>();
                    bmi.bmiHeader.biWidth = width;
                    bmi.bmiHeader.biHeight = -height;
                    bmi.bmiHeader.biPlanes = 1;
                    bmi.bmiHeader.biBitCount = 32;
                    bmi.bmiHeader.biCompression = BI_RGB;

                    var result = GetDIBits(_memoryDC, _bitmap, 0, (uint)height, buffer, ref bmi, 0);
                    
                    if (result == 0)
                    {
                        _logger.LogWarning("GetDIBits failed, returning blank image");
                        return new Image<Rgba32>(width, height);
                    }

                    // BGRA -> RGBA 转换
                    for (int i = 0; i < buffer.Length; i += 4)
                    {
                        (buffer[i + 2], buffer[i]) = (buffer[i], buffer[i + 2]);
                    }
                    
                    var image = RentImage(width, height);
                    image.ProcessPixelRows(accessor =>
                    {
                        for (int y = 0; y < height; y++)
                        {
                            var row = accessor.GetRowSpan(y);
                            var offset = y * stride;
                            for (int x = 0; x < width; x++)
                            {
                                var pixelOffset = offset + x * 4;
                                row[x] = new Rgba32(
                                    buffer[pixelOffset],
                                    buffer[pixelOffset + 1],
                                    buffer[pixelOffset + 2],
                                    buffer[pixelOffset + 3]
                                );
                            }
                        }
                    });
                    
                    return image;
                }
                finally
                {
                    _bytePool.Return(buffer);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Screen capture failed, returning blank image");
                // ✅ 返回空白图像而不是抛出异常
                return new Image<Rgba32>(bounds.Width, bounds.Height);
            }
        }
    }

    private void InitializeResources(int width, int height)
    {
        if (_screenDC != nint.Zero && width == _lastWidth && height == _lastHeight)
            return;

        CleanupResources();

        // ✅ 修复：尝试获取屏幕 DC，失败时使用桌面 DC
        _screenDC = GetDC(nint.Zero);
        if (_screenDC == nint.Zero)
        {
            _logger.LogWarning("GetDC(null) failed, trying GetDesktopWindow");
            var desktopWnd = GetDesktopWindow();
            _screenDC = GetDC(desktopWnd);
            if (_screenDC == nint.Zero)
            {
                throw new InvalidOperationException("Failed to get screen DC");
            }
        }

        _memoryDC = CreateCompatibleDC(_screenDC);
        if (_memoryDC == nint.Zero)
            throw new InvalidOperationException("Failed to create compatible DC");

        _bitmap = CreateCompatibleBitmap(_screenDC, width, height);
        if (_bitmap == nint.Zero)
            throw new InvalidOperationException($"Failed to create compatible bitmap for size {width}x{height}");

        _oldBitmap = SelectObject(_memoryDC, _bitmap);
        
        _lastWidth = width;
        _lastHeight = height;
        
        _logger.LogDebug("Screen capture resources initialized: {Width}x{Height}", width, height);
    }

    private void CleanupResources()
    {
        if (_oldBitmap != nint.Zero)
        {
            SelectObject(_memoryDC, _oldBitmap);
            _oldBitmap = nint.Zero;
        }

        if (_bitmap != nint.Zero)
        {
            DeleteObject(_bitmap);
            _bitmap = nint.Zero;
        }

        if (_memoryDC != nint.Zero)
        {
            DeleteDC(_memoryDC);
            _memoryDC = nint.Zero;
        }

        if (_screenDC != nint.Zero)
        {
            ReleaseDC(nint.Zero, _screenDC);
            _screenDC = nint.Zero;
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        
        lock (_lock)
        {
            CleanupResources();
        }
        
        _logger.LogDebug("ScreenCapture disposed");
    }
}
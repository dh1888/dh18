using System.Diagnostics;
using System.Management;
using System.Text;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 主界面进程存活检测：互斥锁 + 心跳文件 + WMI 进程扫描（互补，降低误判/漏判）。
/// </summary>
internal static class UiPresence
{
    private const string HeartbeatFileName = "ui.presence";

    public static readonly TimeSpan HeartbeatInterval = TimeSpan.FromSeconds(15);
    public static readonly TimeSpan HeartbeatStaleThreshold = TimeSpan.FromSeconds(45);
    public static readonly TimeSpan HungThreshold = TimeSpan.FromSeconds(90);

    private static readonly string[] AuxiliaryModes =
    {
        HiddenLauncherFiles.GuardianLaunchArgument,
        AgentProcessLauncher.EnsureRunningArgument,
        "--service"
    };

    public static string HeartbeatPath
        => Path.Combine(AppPaths.GetAppDataPath(), HeartbeatFileName);

    public static void WriteHeartbeat()
    {
        try
        {
            var line = $"{Environment.ProcessId}|{DateTime.UtcNow:O}";
            File.WriteAllText(HeartbeatPath, line, Encoding.UTF8);
        }
        catch
        {
            // 心跳写入失败不阻断主进程
        }
    }

    public static void ClearHeartbeat()
    {
        try
        {
            if (File.Exists(HeartbeatPath))
                File.Delete(HeartbeatPath);
        }
        catch
        {
            // ignore
        }
    }

    public static bool IsMainUiRunning()
    {
        if (SingleInstanceManager.IsAnotherInstanceRunning())
            return true;

        if (TryReadHeartbeat(out _, out var heartbeatAt)
            && DateTime.UtcNow - heartbeatAt < HeartbeatStaleThreshold)
        {
            return true;
        }

        return IsMainUiProcessRunningViaWmi();
    }

    public static bool TryGetHungUiPid(out int pid)
    {
        pid = 0;

        if (VoluntaryShutdownMarker.IsActive())
            return false;

        if (!SingleInstanceManager.IsAnotherInstanceRunning())
            return false;

        if (!TryReadHeartbeat(out var recordedPid, out var heartbeatAt))
            return false;

        if (DateTime.UtcNow - heartbeatAt < HungThreshold)
            return false;

        if (!IsProcessAlive(recordedPid))
            return false;

        pid = recordedPid;
        return true;
    }

    public static bool TryTerminateHungProcess(int pid, ILogger? logger = null)
    {
        try
        {
            using var process = Process.GetProcessById(pid);
            if (!string.Equals(process.ProcessName, "DHPG", StringComparison.OrdinalIgnoreCase))
            {
                logger?.LogWarning("Refusing to kill non-DHPG pid={Pid} ({Name})", pid, process.ProcessName);
                return false;
            }

            process.Kill(entireProcessTree: true);
            logger?.LogWarning("Terminated hung UI process pid={Pid}", pid);
            return true;
        }
        catch (Exception ex)
        {
            logger?.LogWarning(ex, "Failed to terminate hung UI pid={Pid}", pid);
            return false;
        }
    }

    private static bool TryReadHeartbeat(out int pid, out DateTime heartbeatAt)
    {
        pid = 0;
        heartbeatAt = default;

        try
        {
            if (!File.Exists(HeartbeatPath))
                return false;

            var parts = File.ReadAllText(HeartbeatPath).Trim().Split('|');
            if (parts.Length < 2)
                return false;

            if (!int.TryParse(parts[0], out pid))
                return false;

            return DateTime.TryParse(
                parts[1],
                null,
                System.Globalization.DateTimeStyles.RoundtripKind,
                out heartbeatAt);
        }
        catch
        {
            return false;
        }
    }

    private static bool IsProcessAlive(int pid)
    {
        try
        {
            using var process = Process.GetProcessById(pid);
            return !process.HasExited;
        }
        catch
        {
            return false;
        }
    }

    private static bool IsMainUiProcessRunningViaWmi()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher(
                "SELECT ProcessId, CommandLine FROM Win32_Process WHERE Name = 'DHPG.exe'");

            foreach (var obj in searcher.Get())
            {
                var commandLine = obj["CommandLine"]?.ToString() ?? "";
                if (string.IsNullOrWhiteSpace(commandLine))
                    continue;

                if (IsAuxiliaryMode(commandLine))
                    continue;

                return true;
            }
        }
        catch
        {
            // WMI 不可用时忽略
        }

        return false;
    }

    private static bool IsAuxiliaryMode(string commandLine)
    {
        foreach (var mode in AuxiliaryModes)
        {
            if (commandLine.Contains(mode, StringComparison.OrdinalIgnoreCase))
                return true;
        }

        return false;
    }
}

/// <summary>
/// 主界面进程定期写入心跳，供守护进程判断 UI 是否存活/僵死。
/// </summary>
public sealed class UiHeartbeatService : BackgroundService
{
    private readonly ILogger<UiHeartbeatService> _logger;

    public UiHeartbeatService(ILogger<UiHeartbeatService> logger)
    {
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogDebug("UI heartbeat service started (interval={Seconds}s)",
            UiPresence.HeartbeatInterval.TotalSeconds);

        while (!stoppingToken.IsCancellationRequested)
        {
            UiPresence.WriteHeartbeat();

            try
            {
                await Task.Delay(UiPresence.HeartbeatInterval, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }

        UiPresence.ClearHeartbeat();
        _logger.LogDebug("UI heartbeat service stopped");
    }
}

// Services/SelfHealingService.cs - 增强版（添加紧急清理和空目录清理）

using System.Diagnostics;
using System.Text.Json;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 故障自愈服务 - 自动检测并修复常见故障
/// </summary>
public class SelfHealingService : BackgroundService
{
    private readonly ILogger<SelfHealingService> _logger;
    private readonly AgentConfig _config;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ScreenRecorderService _recorderService;
    private readonly WebSocketService _webSocketService;
    private readonly FileUploadService _uploadService;
    private readonly CleanupService _cleanupService;
    
    private readonly Dictionary<string, HealingState> _healingStates = new();
    private readonly object _stateLock = new();

    public SelfHealingService(
        ILogger<SelfHealingService> logger,
        AgentConfig config,
        IServiceScopeFactory scopeFactory,
        ScreenRecorderService recorderService,
        WebSocketService webSocketService,
        FileUploadService uploadService,
        CleanupService cleanupService)
    {
        _logger = logger;
        _config = config;
        _scopeFactory = scopeFactory;
        _recorderService = recorderService;
        _webSocketService = webSocketService;
        _uploadService = uploadService;
        _cleanupService = cleanupService;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Self-healing service started");
        
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await PerformHealingChecksAsync(stoppingToken);
                await Task.Delay(TimeSpan.FromSeconds(60), stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Self-healing check failed");
                await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
            }
        }
        
        _logger.LogInformation("Self-healing service stopped");
    }

    private async Task PerformHealingChecksAsync(CancellationToken ct)
    {
        // 1. 检查数据库完整性
        await CheckAndRepairDatabaseAsync(ct);
        
        // 2. 检查录屏进程
        await CheckAndRestartRecordingAsync(ct);
        
        // 3. 检查 WebSocket 连接
        await CheckAndReconnectWebSocketAsync(ct);
        
        // 4. 检查卡住的上传任务
        await CheckAndResetStuckUploadsAsync(ct);

        // 5. 重新入队可恢复的失败上传
        await CheckAndRequeueFailedUploadsAsync(ct);
        
        // 6. 检查磁盘空间并清理（委托 CleanupService 统一逻辑）
        await CheckAndCleanupDiskSpaceAsync(ct);

        // 7. 确保会话守护进程存活（守护进程崩溃时由主进程静默拉起）
        AgentGuardianManager.EnsureRunning(_logger);
    }

    private async Task CheckAndRepairDatabaseAsync(CancellationToken ct)
    {
        var state = GetHealingState("database");
        
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<SqliteDbContext>();
            
            var isIntegrityOk = await db.IntegrityCheckAsync();
            
            if (!isIntegrityOk && state.CanHeal())
            {
                _logger.LogWarning("Database integrity check failed, attempting repair...");
                state.RecordHealingAttempt();
                
                await db.VacuumAsync();
                
                isIntegrityOk = await db.IntegrityCheckAsync();
                if (isIntegrityOk)
                {
                    _logger.LogInformation("Database repair successful");
                    state.RecordHealingSuccess();
                }
                else
                {
                    _logger.LogError("Database repair failed");
                    state.RecordHealingFailure();
                }
            }
            else if (isIntegrityOk)
            {
                state.RecordSuccess();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Database check failed");
            state.RecordFailure(ex.Message);
        }
    }

    private async Task CheckAndRestartRecordingAsync(CancellationToken ct)
    {
        var state = GetHealingState("recording");
        
        try
        {
            RecordingConfig? recordingConfig = null;
            using (var scope = _scopeFactory.CreateScope())
            {
                var policySync = scope.ServiceProvider.GetRequiredService<PolicySyncService>();
                recordingConfig = policySync.GetCurrentPolicy()?.GetRecordingConfig();
            }

            if (recordingConfig is not { Enabled: true })
            {
                state.Reset();
                return;
            }

            var snapshot = _recorderService.GetRecordingHealthSnapshot();

            if (snapshot.IsHealthy)
            {
                state.RecordSuccess();
                return;
            }

            if (!snapshot.ShouldBeRecording || !state.CanHeal())
                return;

            _logger.LogWarning(
                "Recording unhealthy (process={ProcessAlive}, encoder={EncoderAlive}, fileRecent={FileRecent}, stall={Stall:F0}s), attempting self-healing restart...",
                snapshot.ProcessAlive,
                snapshot.EncoderAlive,
                snapshot.FileRecent,
                snapshot.StallSeconds);

            state.RecordHealingAttempt();

            var recovered = await _recorderService.RequestSelfHealingRestartAsync(ct);
            if (recovered)
            {
                _logger.LogInformation("Recording self-healing restart successful");
                state.RecordHealingSuccess();
            }
            else
            {
                _logger.LogError("Recording self-healing restart failed");
                state.RecordHealingFailure();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Recording check failed");
            state.RecordFailure(ex.Message);
        }
    }

    private async Task CheckAndReconnectWebSocketAsync(CancellationToken ct)
    {
        var state = GetHealingState("websocket");
        
        try
        {
            if (!_webSocketService.IsConnected && state.CanHeal())
            {
                _logger.LogWarning("WebSocket disconnected, attempting reconnect...");
                state.RecordHealingAttempt();
                
                await _webSocketService.ReconnectAsync();
                
                await Task.Delay(3000, ct);
                
                if (_webSocketService.IsConnected)
                {
                    _logger.LogInformation("WebSocket reconnect successful");
                    state.RecordHealingSuccess();
                }
                else
                {
                    _logger.LogWarning("WebSocket reconnect failed");
                    state.RecordHealingFailure();
                }
            }
            else if (_webSocketService.IsConnected)
            {
                state.RecordSuccess();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "WebSocket check failed");
            state.RecordFailure(ex.Message);
        }
    }

    private async Task CheckAndResetStuckUploadsAsync(CancellationToken ct)
    {
        var state = GetHealingState("upload_stuck");
        
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var uploadRepo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
            
            var resetCount = await uploadRepo.ResetStuckTasksAsync(TimeSpan.FromMinutes(30));
            
            if (resetCount > 0)
            {
                _logger.LogInformation("Reset {Count} stuck upload tasks", resetCount);
                state.RecordHealingAttempt();
                state.RecordHealingSuccess();
            }
            else
            {
                state.RecordSuccess();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Stuck upload check failed");
            state.RecordFailure(ex.Message);
        }
    }

    private async Task CheckAndRequeueFailedUploadsAsync(CancellationToken ct)
    {
        var state = GetHealingState("upload_failed_retry");
        if (!state.CanHeal())
            return;

        try
        {
            using var scope = _scopeFactory.CreateScope();
            var uploadRepo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();

            var failedCount = await uploadRepo.GetFailedCountAsync();
            if (failedCount == 0)
            {
                state.RecordSuccess();
                return;
            }

            state.RecordHealingAttempt();
            var requeued = await uploadRepo.RequeueRetryableFailedAsync(limit: 20, minAgeMinutes: 30);

            if (requeued > 0)
            {
                _logger.LogInformation("Self-healing requeued {Count} failed uploads (total failed: {Failed})",
                    requeued, failedCount);
                state.RecordHealingSuccess();
            }
            else
            {
                state.RecordSuccess();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed upload requeue check failed");
            state.RecordFailure(ex.Message);
        }
    }

    private async Task CheckAndCleanupDiskSpaceAsync(CancellationToken ct)
    {
        var state = GetHealingState("disk_space");
        
        try
        {
            var storagePath = _config.GetEffectiveStoragePath();
            var drive = Path.GetPathRoot(storagePath);
            if (drive != null)
            {
                var driveInfo = new DriveInfo(drive);
                var freePercent = driveInfo.AvailableFreeSpace / (double)driveInfo.TotalSize * 100;
                var freeGB = driveInfo.AvailableFreeSpace / 1024.0 / 1024 / 1024;
                
                // ✅ 严重告警：立即执行紧急清理
                if (freePercent < 5)
                {
                    _logger.LogCritical("⚠️ CRITICAL: Disk space critically low! Free: {FreeGB:F1}GB ({FreePercent:F1}%)", 
                        freeGB, freePercent);
                    await _cleanupService.RunDiskPressureCleanupAsync(DiskPressureLevel.Critical, ct);
                    await NotifyDiskSpaceCriticalAsync(freeGB);
                    state.RecordHealingAttempt();
                    state.RecordHealingSuccess();
                }
                else if (freePercent < 10 && state.CanHeal())
                {
                    _logger.LogWarning("⚠️ WARNING: Low disk space: {FreeGB:F1}GB ({FreePercent:F1}%)", 
                        freeGB, freePercent);
                    await NotifyDiskSpaceWarningAsync(freePercent, freeGB);
                    state.RecordHealingAttempt();
                    
                    await _cleanupService.RunDiskPressureCleanupAsync(DiskPressureLevel.Warning, ct);
                    
                    var newFreePercent = new DriveInfo(drive).AvailableFreeSpace / (double)driveInfo.TotalSize * 100;
                    _logger.LogInformation("Disk cleanup completed, free space: {NewFreePercent:F1}%", newFreePercent);
                    
                    state.RecordHealingSuccess();
                }
                else if (freePercent < 20)
                {
                    _logger.LogInformation("Disk space: {FreeGB:F1}GB ({FreePercent:F1}%) free", 
                        freeGB, freePercent);
                    state.RecordSuccess();
                }
                else
                {
                    state.RecordSuccess();
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Disk space check failed");
            state.RecordFailure(ex.Message);
        }
    }

    #region 辅助方法

    private async Task NotifyDiskSpaceWarningAsync(double freePercent, double freeGB)
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var messageBus = scope.ServiceProvider.GetRequiredService<IMessageBus>();

            var usedPercent = 100 - freePercent;
            var alert = new
            {
                type = "disk_warning",
                usedPercent,
                freeGB,
                timestamp = DateTime.UtcNow,
                message = $"磁盘使用率约 {usedPercent:F1}%，剩余 {freeGB:F1}GB"
            };

            var json = JsonSerializer.Serialize(alert);
            var element = JsonSerializer.Deserialize<JsonElement>(json);
            await messageBus.PublishAsync("system.alert", element);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to send disk warning alert");
        }
    }

    /// <summary>
    /// 发送磁盘空间告警通知
    /// </summary>
    private async Task NotifyDiskSpaceCriticalAsync(double freeGB)
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var messageBus = scope.ServiceProvider.GetRequiredService<IMessageBus>();
            
            var alert = new
            {
                type = "disk_critical",
                freeGB = freeGB,
                timestamp = DateTime.UtcNow,
                message = $"磁盘空间严重不足，仅剩 {freeGB:F1}GB，已执行紧急清理"
            };
            
            var json = JsonSerializer.Serialize(alert);
            var element = JsonSerializer.Deserialize<JsonElement>(json);
            await messageBus.PublishAsync("system.alert", element);
            
            _logger.LogWarning("Disk space alert sent via WebSocket");
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to send disk alert");
        }
    }

    #endregion

    private HealingState GetHealingState(string component)
    {
        lock (_stateLock)
        {
            if (!_healingStates.ContainsKey(component))
                _healingStates[component] = new HealingState();
            return _healingStates[component];
        }
    }

    private class HealingState
    {
        private int _consecutiveFailures;
        private DateTime _lastHealingAttempt;
        private DateTime _lastSuccess;
        
        public bool CanHeal()
        {
            // 最多连续失败 3 次
            if (_consecutiveFailures >= 3)
                return false;
            
            // 冷却时间：上次修复尝试后至少等待 30 秒
            if (DateTime.UtcNow - _lastHealingAttempt < TimeSpan.FromSeconds(30))
                return false;
            
            return true;
        }
        
        public void RecordSuccess()
        {
            _consecutiveFailures = 0;
            _lastSuccess = DateTime.UtcNow;
        }
        
        public void RecordFailure(string? error = null)
        {
            _consecutiveFailures++;
        }
        
        public void RecordHealingAttempt()
        {
            _lastHealingAttempt = DateTime.UtcNow;
        }
        
        public void RecordHealingSuccess()
        {
            _consecutiveFailures = 0;
        }
        
        public void RecordHealingFailure()
        {
            _consecutiveFailures++;
        }
        
        public void Reset()
        {
            _consecutiveFailures = 0;
        }
    }
}
// Services/MetricsService.cs - 指标采集服务

using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Text;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 指标采集服务 - 收集和暴露 Metrics 指标
/// </summary>
public class MetricsService : BackgroundService
{
    private readonly ILogger<MetricsService> _logger;
    private readonly AgentConfig _config;
    private readonly IServiceScopeFactory _scopeFactory;
    
    // 计数器
    private long _recordingsCreated;
    private long _screenshotsCaptured;
    private long _uploadsSucceeded;
    private long _uploadsFailed;
    private long _webSocketReconnects;
    private long _ffmpegRestarts;
    
    // 计量器
    private double _currentCpuUsage;
    private double _currentMemoryUsageMb;
    private long _currentDiskFreeBytes;
    private int _currentPendingUploads;
    private int _currentFailedUploads;
    private bool _isWebSocketConnected;
    private bool _isRecordingRunning;
    
    // 时间戳
    private DateTime _lastMetricsCollection = DateTime.UtcNow;
    private DateTime _processStartTime = DateTime.UtcNow;

    public MetricsService(
        ILogger<MetricsService> logger,
        AgentConfig config,
        IServiceScopeFactory scopeFactory)
    {
        _logger = logger;
        _config = config;
        _scopeFactory = scopeFactory;
    }

    /// <summary>
    /// 记录录屏创建
    /// </summary>
    public void RecordRecordingCreated() => Interlocked.Increment(ref _recordingsCreated);

    /// <summary>
    /// 记录截图捕获
    /// </summary>
    public void RecordScreenshotCaptured() => Interlocked.Increment(ref _screenshotsCaptured);

    /// <summary>
    /// 记录上传成功
    /// </summary>
    public void RecordUploadSucceeded() => Interlocked.Increment(ref _uploadsSucceeded);

    /// <summary>
    /// 记录上传失败
    /// </summary>
    public void RecordUploadFailed() => Interlocked.Increment(ref _uploadsFailed);

    /// <summary>
    /// 记录 WebSocket 重连
    /// </summary>
    public void RecordWebSocketReconnect() => Interlocked.Increment(ref _webSocketReconnects);

    /// <summary>
    /// 记录 FFmpeg 重启
    /// </summary>
    public void RecordFfmpegRestart() => Interlocked.Increment(ref _ffmpegRestarts);

    /// <summary>
    /// 设置 WebSocket 连接状态
    /// </summary>
    public void SetWebSocketConnected(bool connected) => _isWebSocketConnected = connected;

    /// <summary>
    /// 设置录屏运行状态
    /// </summary>
    public void SetRecordingRunning(bool running) => _isRecordingRunning = running;

    /// <summary>
    /// 获取当前指标快照
    /// </summary>
    public MetricsSnapshot GetSnapshot()
    {
        return new MetricsSnapshot
        {
            Timestamp = DateTime.UtcNow,
            Counters = new Dictionary<string, long>
            {
                ["recordings_created_total"] = _recordingsCreated,
                ["screenshots_captured_total"] = _screenshotsCaptured,
                ["uploads_succeeded_total"] = _uploadsSucceeded,
                ["uploads_failed_total"] = _uploadsFailed,
                ["websocket_reconnects_total"] = _webSocketReconnects,
                ["ffmpeg_restarts_total"] = _ffmpegRestarts
            },
            Gauges = new Dictionary<string, double>
            {
                ["cpu_usage_percent"] = _currentCpuUsage,
                ["memory_usage_mb"] = _currentMemoryUsageMb,
                ["disk_free_bytes"] = _currentDiskFreeBytes,
                ["pending_uploads"] = _currentPendingUploads,
                ["failed_uploads"] = _currentFailedUploads,
                ["uptime_seconds"] = (DateTime.UtcNow - _processStartTime).TotalSeconds,
                ["websocket_connected"] = _isWebSocketConnected ? 1 : 0,
                ["recording_running"] = _isRecordingRunning ? 1 : 0
            }
        };
    }

    /// <summary>
    /// 获取 Prometheus 格式的指标文本
    /// </summary>
    public string GetPrometheusMetrics()
    {
        var snapshot = GetSnapshot();
        var sb = new StringBuilder();
        
        sb.AppendLine("# HELP enterprise_agent_build_info Build information");
        sb.AppendLine("# TYPE enterprise_agent_build_info gauge");
        sb.AppendLine($"enterprise_agent_build_info{{version=\"{_config.AgentVersion}\"}} 1");
        
        foreach (var counter in snapshot.Counters)
        {
            sb.AppendLine($"# HELP enterprise_agent_{counter.Key} Total count");
            sb.AppendLine($"# TYPE enterprise_agent_{counter.Key} counter");
            sb.AppendLine($"enterprise_agent_{counter.Key} {counter.Value}");
        }
        
        foreach (var gauge in snapshot.Gauges)
        {
            sb.AppendLine($"# HELP enterprise_agent_{gauge.Key} Current value");
            sb.AppendLine($"# TYPE enterprise_agent_{gauge.Key} gauge");
            sb.AppendLine($"enterprise_agent_{gauge.Key} {gauge.Value.ToString(CultureInfo.InvariantCulture)}");
        }
        
        return sb.ToString();
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Metrics service started");
        
        // 如果配置了 Metrics 端口，启动 HTTP 服务器
        if (_config.Observability?.MetricsPort > 0)
        {
            _ = Task.Run(() => StartMetricsServer(_config.Observability.MetricsPort, stoppingToken), stoppingToken);
        }
        
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await CollectSystemMetricsAsync();
                await CollectQueueMetricsAsync();
                
                _lastMetricsCollection = DateTime.UtcNow;
                
                if (_config.Observability?.EnableMetrics == true)
                {
                    _logger.LogDebug("Metrics collected: CPU={Cpu:F1}%, Memory={Memory:F1}MB, Pending={Pending}",
                        _currentCpuUsage, _currentMemoryUsageMb, _currentPendingUploads);
                }
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to collect metrics");
            }
            
            await Task.Delay(Constants.MetricsCollectionIntervalMs, stoppingToken);
        }
        
        _logger.LogInformation("Metrics service stopped");
    }

    private async Task CollectSystemMetricsAsync()
    {
        try
        {
            var process = Process.GetCurrentProcess();
            
            // CPU 使用率
            var startTime = DateTime.UtcNow;
            var startCpu = process.TotalProcessorTime;
            await Task.Delay(100);
            var endTime = DateTime.UtcNow;
            var endCpu = process.TotalProcessorTime;
            
            var cpuUsed = (endCpu - startCpu).TotalMilliseconds;
            var total = (endTime - startTime).TotalMilliseconds;
            _currentCpuUsage = (cpuUsed / (total * Environment.ProcessorCount)) * 100;
            
            // 内存使用
            _currentMemoryUsageMb = process.WorkingSet64 / 1024.0 / 1024;
            
            // 磁盘空间
            var storagePath = _config.GetEffectiveStoragePath();
            var drive = Path.GetPathRoot(storagePath);
            if (drive != null)
            {
                var driveInfo = new DriveInfo(drive);
                _currentDiskFreeBytes = driveInfo.AvailableFreeSpace;
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to collect system metrics");
        }
    }

    private async Task CollectQueueMetricsAsync()
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var uploadRepo = scope.ServiceProvider.GetRequiredService<UploadQueueRepository>();
            var stats = await uploadRepo.GetQueueStatsAsync();
            
            _currentPendingUploads = stats.pending + stats.uploading;
            _currentFailedUploads = stats.failed;
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to collect queue metrics");
        }
    }

    private async Task StartMetricsServer(int port, CancellationToken ct)
    {
        var url = $"http://localhost:{port}/metrics";
        _logger.LogInformation("Starting metrics server at {Url}", url);
        
        using var listener = new HttpListener();
        listener.Prefixes.Add(url + "/");
        
        try
        {
            listener.Start();
            
            while (!ct.IsCancellationRequested)
            {
                var context = await listener.GetContextAsync();
                var response = context.Response;
                
                var metricsText = GetPrometheusMetrics();
                var buffer = Encoding.UTF8.GetBytes(metricsText);
                
                response.ContentType = "text/plain; charset=utf-8";
                response.ContentLength64 = buffer.Length;
                await response.OutputStream.WriteAsync(buffer, 0, buffer.Length, ct);
                response.Close();
            }
        }
        catch (HttpListenerException ex) when (ex.ErrorCode == 5)
        {
            _logger.LogWarning("Failed to start metrics server: Access denied. Run as administrator or use a different port.");
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("Metrics server stopped");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Metrics server error");
        }
        finally
        {
            listener.Stop();
        }
    }
}
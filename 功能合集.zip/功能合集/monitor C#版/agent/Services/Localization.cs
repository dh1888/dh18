// Services/Localization.cs - 添加系统语言自动检测（支持中文、英文、越南语）

using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using System.Globalization;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 本地化服务接口
/// </summary>
public interface ILocalizationService
{
    /// <summary>
    /// 获取本地化字符串
    /// </summary>
    /// <param name="key">资源键</param>
    /// <returns>本地化文本</returns>
    string GetString(string key);

    /// <summary>
    /// 获取本地化字符串，带参数
    /// </summary>
    /// <param name="key">资源键</param>
    /// <param name="args">格式化参数</param>
    /// <returns>本地化文本</returns>
    string GetString(string key, params object[] args);

    /// <summary>
    /// 获取本地化字符串（简洁方法名，同 GetString）
    /// </summary>
    /// <param name="key">资源键</param>
    /// <param name="defaultValue">默认值</param>
    /// <returns>本地化文本</returns>
    string Get(string key, string? defaultValue = null);

    /// <summary>
    /// 设置当前语言
    /// </summary>
    /// <param name="language">语言代码（如 "zh-CN"）</param>
    void SetLanguage(string language);

    /// <summary>
    /// 获取当前语言
    /// </summary>
    /// <returns>语言代码</returns>
    string GetCurrentLanguage();
    
    /// <summary>
    /// 获取支持的语言列表
    /// </summary>
    List<string> GetSupportedLanguages();
}

/// <summary>
/// 本地化服务实现
/// </summary>
public class LocalizationService : ILocalizationService
{
    private string _currentLanguage;
    private Dictionary<string, string> _resources = new();
    private readonly string _resourcePath;
    private readonly ILogger<LocalizationService> _logger;
    private readonly object _lock = new();

    public LocalizationService(ILogger<LocalizationService> logger)
    {
        _logger = logger;
        _resourcePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources");
        
        if (!Directory.Exists(_resourcePath))
        {
            Directory.CreateDirectory(_resourcePath);
        }
        
        // 自动检测系统语言
        _currentLanguage = DetectSystemLanguage();
        LoadResources();
        
        _logger.LogInformation("Localization service initialized with language: {Language}", _currentLanguage);
    }
    
    /// <summary>
    /// 检测系统语言
    /// </summary>
    private string DetectSystemLanguage()
    {
        try
        {
            var culture = CultureInfo.CurrentCulture;
            var languageCode = culture.Name;
            
            _logger.LogInformation("Detected system language: {LanguageCode}", languageCode);
            
            // 支持的语言列表
            var supportedLanguages = new[] { "zh-CN", "en-US", "zh-TW", "vi-VN" };
            
            // 1. 精确匹配
            if (supportedLanguages.Contains(languageCode))
            {
                return languageCode;
            }
            
            // 2. 模糊匹配 - 中文
            if (languageCode.StartsWith("zh"))
            {
                if (languageCode.Contains("TW") || languageCode.Contains("HK") || languageCode.Contains("MO"))
                    return "zh-TW";
                return "zh-CN";
            }
            
            // 3. 模糊匹配 - 英文
            if (languageCode.StartsWith("en"))
            {
                return "en-US";
            }
            
            // 4. 模糊匹配 - 越南语
            if (languageCode.StartsWith("vi"))
            {
                return "vi-VN";
            }
            
            // 5. 默认中文
            _logger.LogInformation("Language {LanguageCode} not supported, falling back to zh-CN", languageCode);
            return "zh-CN";
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to detect system language, using default zh-CN");
            return "zh-CN";
        }
    }

    private void LoadResources()
    {
        lock (_lock)
        {
            var filePath = Path.Combine(_resourcePath, $"{_currentLanguage}.json");
            
            if (!File.Exists(filePath))
            {
                var availableFiles = Directory.GetFiles(_resourcePath, "*.json");
                if (availableFiles.Length > 0)
                {
                    filePath = availableFiles[0];
                    _currentLanguage = Path.GetFileNameWithoutExtension(filePath);
                    _logger.LogInformation("Using available language file: {Language}", _currentLanguage);
                }
                else
                {
                    _resources = GetDefaultResources();
                    _logger.LogInformation("Using built-in default resources");
                    return;
                }
            }

            try
            {
                var json = File.ReadAllText(filePath);
                var loaded = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
                if (loaded != null && loaded.Count > 0)
                {
                    _resources = loaded;
                    _logger.LogInformation("Loaded {Count} localization strings for {Language}", 
                        _resources.Count, _currentLanguage);
                }
                else
                {
                    _resources = GetDefaultResources();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load localization resources from {FilePath}", filePath);
                _resources = GetDefaultResources();
            }
        }
    }

    /// <summary>
    /// 根据当前语言获取默认资源
    /// </summary>
    private Dictionary<string, string> GetDefaultResources()
    {
        if (_currentLanguage == "vi-VN")
        {
            return GetVietnameseDefaultResources();
        }
        
        if (_currentLanguage == "en-US")
        {
            return GetEnglishDefaultResources();
        }
        
        // 默认中文
        return GetChineseDefaultResources();
    }

    /// <summary>
    /// 越南语默认资源
    /// </summary>
    private Dictionary<string, string> GetVietnameseDefaultResources()
    {
        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            // ========== 通用 ==========
            ["AppName"] = "DHPG",
            ["Status"] = "Trạng thái",
            ["Connected"] = "Đã kết nối",
            ["Disconnected"] = "Chưa kết nối",
            ["Device"] = "Thiết bị",
            ["NotRegistered"] = "Chưa đăng ký",
            ["Exit"] = "Thoát",
            ["Cancel"] = "Hủy",
            ["Confirm"] = "Xác nhận",
            ["OK"] = "Đồng ý",
            ["Close"] = "Đóng",
            ["Refresh"] = "Làm mới",
            ["Copy"] = "Sao chép",
            ["Save"] = "Lưu",
            ["Error"] = "Lỗi",
            ["Warning"] = "Cảnh báo",
            ["Information"] = "Thông tin",
            
            // ========== 服务状态 ==========
            ["Recording"] = "Đang ghi màn hình",
            ["Screenshot"] = "Đang chụp ảnh",
            ["Uploading"] = "Đang tải lên",
            ["Idle"] = "Chờ",
            ["Running"] = "Đang chạy",
            ["Stopped"] = "Đã dừng",
            ["Pending"] = "Đang chờ",
            ["Failed"] = "Thất bại",
            ["Completed"] = "Hoàn thành",
            ["Active"] = "Hoạt động",
            ["Inactive"] = "Không hoạt động",
            
            // ========== 窗口和菜单 ==========
            ["SetupTitle"] = "Thiết lập ban đầu",
            ["AgentStatus"] = "Trạng thái Agent",
            ["ShowStatusWindow"] = "Hiển thị cửa sổ trạng thái",
            ["OpenLog"] = "Mở thư mục log",
            ["OpenLogFailed"] = "Không thể mở thư mục log",
            ["CopyDeviceId"] = "Sao chép ID thiết bị",
            ["CopyServerUrl"] = "Sao chép URL máy chủ",
            ["ExitApplication"] = "Thoát",
            ["AutoStart"] = "Tự động khởi động",
            
            // ========== 设备信息 ==========
            ["DeviceInformation"] = "Thông tin thiết bị",
            ["DeviceId"] = "ID thiết bị:",
            ["AgentVersion"] = "Phiên bản Agent:",
            ["FullName"] = "Họ và tên:",
            ["EmployeeId"] = "Mã nhân viên:",
            
            // ========== 连接 ==========
            ["Connection"] = "Kết nối",
            ["ServerURL"] = "URL máy chủ:",
            ["Connecting"] = "Đang kết nối...",
            ["Reconnecting"] = "Đang kết nối lại...",
            
            // ========== 员工设置 ==========
            ["NamePlaceholder"] = "Nhập họ và tên của bạn",
            ["ServerUrlPlaceholder"] = "Nhập URL máy chủ",
            ["SetupHint"] = "Thông tin này sẽ được sử dụng để xác định thiết bị của bạn.\nKhông thể thay đổi nếu không có sự chấp thuận của quản trị viên.",
            ["NameRequired"] = "Vui lòng nhập họ và tên của bạn",
            ["ServerUrlRequired"] = "Vui lòng nhập URL máy chủ",
            ["ValidationError"] = "Lỗi xác thực",
            ["ExitConfirm"] = "Bạn có chắc chắn muốn thoát không?",
            ["ConfirmExit"] = "Xác nhận thoát",
            
            // ========== 服务状态显示 ==========
            ["RecordingStatus"] = "Ghi màn hình:",
            ["ScreenshotStatus"] = "Chụp ảnh:",
            ["UploadStatus"] = "Tải lên:",
            
            // ========== 提示消息 ==========
            ["Copied"] = "Đã sao chép",
            ["DeviceIdCopied"] = "ID thiết bị đã được sao chép",
            ["ServerUrlCopied"] = "URL máy chủ đã được sao chép",
            ["CopyFailed"] = "Sao chép thất bại",
            ["CopyFailedMessage"] = "Không thể sao chép",
            ["DeviceNotRegistered"] = "Thiết bị chưa được đăng ký",
            ["NotAvailable"] = "Không có sẵn",
            
            // ========== 开机自启动 ==========
            ["AutoStartEnabled"] = "Đã bật tự động khởi động, sẽ chạy khi khởi động máy",
            ["AutoStartDisabled"] = "Đã tắt tự động khởi động",
            ["AutoStartFailed"] = "Không thể bật tự động khởi động, vui lòng kiểm tra quyền",
            ["AlreadyRunning"] = "Chương trình đang chạy, vui lòng không mở lại.",
            ["SettingSaved"] = "Đã lưu cài đặt"
        };
    }

    /// <summary>
    /// 英文默认资源
    /// </summary>
    private Dictionary<string, string> GetEnglishDefaultResources()
    {
        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            // ========== 通用 ==========
            ["AppName"] = "DHPG",
            ["Status"] = "Status",
            ["Connected"] = "Connected",
            ["Disconnected"] = "Disconnected",
            ["Device"] = "Device",
            ["NotRegistered"] = "Not Registered",
            ["Exit"] = "Exit",
            ["Cancel"] = "Cancel",
            ["Confirm"] = "Confirm",
            ["OK"] = "OK",
            ["Close"] = "Close",
            ["Refresh"] = "Refresh",
            ["Copy"] = "Copy",
            ["Save"] = "Save",
            ["Error"] = "Error",
            ["Warning"] = "Warning",
            ["Information"] = "Information",
            
            // ========== 服务状态 ==========
            ["Recording"] = "Recording",
            ["Screenshot"] = "Screenshot",
            ["Uploading"] = "Uploading",
            ["Idle"] = "Idle",
            ["Running"] = "Running",
            ["Stopped"] = "Stopped",
            ["Pending"] = "Pending",
            ["Failed"] = "Failed",
            ["Completed"] = "Completed",
            ["Active"] = "Active",
            ["Inactive"] = "Inactive",
            
            // ========== 窗口和菜单 ==========
            ["SetupTitle"] = "Initial Configuration",
            ["AgentStatus"] = "Agent Status",
            ["ShowStatusWindow"] = "Show Status Window",
            ["OpenLog"] = "Open Log",
            ["OpenLogFailed"] = "Cannot open log folder",
            ["CopyDeviceId"] = "Copy Device ID",
            ["CopyServerUrl"] = "Copy Server URL",
            ["ExitApplication"] = "Exit",
            ["AutoStart"] = "Auto Start",
            
            // ========== 设备信息 ==========
            ["DeviceInformation"] = "Device Information",
            ["DeviceId"] = "Device ID:",
            ["AgentVersion"] = "Agent Version:",
            ["FullName"] = "Full Name:",
            ["EmployeeId"] = "Employee ID:",
            
            // ========== 连接 ==========
            ["Connection"] = "Connection",
            ["ServerURL"] = "Server URL:",
            ["Connecting"] = "Connecting...",
            ["Reconnecting"] = "Reconnecting...",
            
            // ========== 员工设置 ==========
            ["NamePlaceholder"] = "Enter your full name",
            ["ServerUrlPlaceholder"] = "Enter the server URL",
            ["SetupHint"] = "This information will be used to identify your device.\nIt cannot be changed without administrator approval.",
            ["NameRequired"] = "Please enter your full name",
            ["ServerUrlRequired"] = "Please enter the server URL",
            ["ValidationError"] = "Validation Error",
            ["ExitConfirm"] = "Are you sure you want to exit?",
            ["ConfirmExit"] = "Confirm Exit",
            
            // ========== 服务状态显示 ==========
            ["RecordingStatus"] = "Recording:",
            ["ScreenshotStatus"] = "Screenshot:",
            ["UploadStatus"] = "Upload:",
            
            // ========== 提示消息 ==========
            ["Copied"] = "Copied",
            ["DeviceIdCopied"] = "Device ID copied to clipboard",
            ["ServerUrlCopied"] = "Server URL copied to clipboard",
            ["CopyFailed"] = "Copy Failed",
            ["CopyFailedMessage"] = "Unable to copy to clipboard",
            ["DeviceNotRegistered"] = "Device not yet registered",
            ["NotAvailable"] = "Not Available",
            
            // ========== 开机自启动 ==========
            ["AutoStartEnabled"] = "Auto start enabled, will run on next sign-in",
            ["AutoStartDisabled"] = "Auto start disabled",
            ["AutoStartFailed"] = "Failed to set auto start, please check permission",
            ["AlreadyRunning"] = "The program is already running.",
            ["SettingSaved"] = "Setting saved"
        };
    }

    /// <summary>
    /// 中文默认资源
    /// </summary>
    private Dictionary<string, string> GetChineseDefaultResources()
    {
        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            // ========== 通用 ==========
            ["AppName"] = "DHPG",
            ["Status"] = "状态",
            ["Connected"] = "已连接",
            ["Disconnected"] = "未连接",
            ["Device"] = "设备",
            ["NotRegistered"] = "未注册",
            ["Exit"] = "退出",
            ["Cancel"] = "取消",
            ["Confirm"] = "确认",
            ["OK"] = "确定",
            ["Close"] = "关闭",
            ["Refresh"] = "刷新",
            ["Copy"] = "复制",
            ["Save"] = "保存",
            ["Error"] = "错误",
            ["Warning"] = "警告",
            ["Information"] = "信息",
            
            // ========== 服务状态 ==========
            ["Recording"] = "录屏中",
            ["Screenshot"] = "截图中",
            ["Uploading"] = "上传中",
            ["Idle"] = "空闲",
            ["Running"] = "运行中",
            ["Stopped"] = "已停止",
            ["Pending"] = "等待中",
            ["Failed"] = "失败",
            ["Completed"] = "已完成",
            ["Active"] = "活动中",
            ["Inactive"] = "非活动",
            
            // ========== 窗口和菜单 ==========
            ["SetupTitle"] = "DHPG",
            ["AppTitle"] = "DHPG",
            ["SetupWelcome"] = "欢迎使用！未来的工作，我们并肩前行。🚀",
            ["SetupHint"] = "使用前，请在下方填写您的姓名与服务器地址。",
            ["ServerUrlLockedHint"] = "欢迎使用！未来的工作，我们并肩前行。🚀\n服务器地址已预配置，请填写您的姓名后保存。",
            ["AgentStatus"] = "代理状态",
            ["ShowStatusWindow"] = "显示状态窗口",
            ["OpenLog"] = "打开日志",
            ["OpenLogFailed"] = "无法打开日志文件夹",
            ["CopyDeviceId"] = "复制设备ID",
            ["CopyServerUrl"] = "复制服务器地址",
            ["ExitApplication"] = "退出",
            ["AutoStart"] = "开机自启动",
            
            // ========== 设备信息 ==========
            ["DeviceInformation"] = "设备信息",
            ["DeviceId"] = "设备ID:",
            ["AgentVersion"] = "代理版本:",
            ["FullName"] = "姓名:",
            ["EmployeeId"] = "工号:",
            
            // ========== 连接 ==========
            ["Connection"] = "连接",
            ["ServerURL"] = "服务器地址:",
            ["Connecting"] = "连接中...",
            ["Reconnecting"] = "重连中...",
            
            // ========== 员工设置 ==========
            ["NamePlaceholder"] = "请输入您的姓名",
            ["ServerUrlPlaceholder"] = "请输入服务器地址",
            ["SetupHint"] = "使用前，请在下方填写您的姓名与服务器地址。",
            ["NameRequired"] = "请输入您的姓名",
            ["ServerUrlRequired"] = "请输入服务器地址",
            ["ValidationError"] = "验证错误",
            ["ExitConfirm"] = "确定要退出吗？",
            ["ConfirmExit"] = "确认退出",
            
            // ========== 服务状态显示 ==========
            ["RecordingStatus"] = "录屏:",
            ["ScreenshotStatus"] = "截图:",
            ["UploadStatus"] = "上传:",
            
            // ========== 提示消息 ==========
            ["Copied"] = "已复制",
            ["DeviceIdCopied"] = "设备ID已复制到剪贴板",
            ["ServerUrlCopied"] = "服务器地址已复制到剪贴板",
            ["CopyFailed"] = "复制失败",
            ["CopyFailedMessage"] = "无法复制到剪贴板",
            ["DeviceNotRegistered"] = "设备尚未注册",
            ["NotAvailable"] = "不可用",
            
            // ========== 开机自启动 ==========
            ["AutoStartEnabled"] = "已开启登录自启动，下次登录将自动运行",
            ["AutoStartDisabled"] = "已关闭开机自启动",
            ["AutoStartFailed"] = "设置开机自启动失败，请检查权限",
            ["AlreadyRunning"] = "程序已在运行中，请勿重复打开。",
            ["SettingSaved"] = "设置已保存"
        };
    }

    public string GetString(string key)
    {
        lock (_lock)
        {
            return _resources.GetValueOrDefault(key, key);
        }
    }

    public string GetString(string key, params object[] args)
    {
        var value = GetString(key);
        try
        {
            return string.Format(value, args);
        }
        catch (FormatException)
        {
            _logger?.LogWarning("Failed to format string for key: {Key}", key);
            return value;
        }
    }

    public string Get(string key, string? defaultValue = null)
    {
        var value = GetString(key);
        return value != key ? value : (defaultValue ?? key);
    }

    public void SetLanguage(string language)
    {
        if (string.IsNullOrWhiteSpace(language))
            return;
        
        lock (_lock)
        {
            if (_currentLanguage != language)
            {
                _currentLanguage = language;
                LoadResources();
                _logger.LogInformation("Language changed to: {Language}", language);
            }
        }
    }

    public string GetCurrentLanguage()
    {
        lock (_lock)
        {
            return _currentLanguage;
        }
    }

    public List<string> GetSupportedLanguages()
    {
        var languages = new List<string>();
        
        if (Directory.Exists(_resourcePath))
        {
            foreach (var file in Directory.GetFiles(_resourcePath, "*.json"))
            {
                var lang = Path.GetFileNameWithoutExtension(file);
                if (!string.IsNullOrEmpty(lang))
                    languages.Add(lang);
            }
        }
        
        if (languages.Count == 0)
        {
            languages.Add("zh-CN");
            languages.Add("en-US");
            languages.Add("vi-VN");
        }
        
        return languages;
    }
}
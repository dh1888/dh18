// UI/Forms.cs - UI 表单合并（EmployeeSetupForm 和 StatusForm）支持多语言

using System.Drawing;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Services;
using Microsoft.Extensions.Logging;
using DrawingImage = System.Drawing.Image;
using DrawingSize = System.Drawing.Size;
using DrawingColor = System.Drawing.Color;
using DrawingPoint = System.Drawing.Point;
using DrawingPointF = System.Drawing.PointF;

namespace EnterpriseAgent.Agent.UI;

#region EmployeeSetupForm

public class EmployeeSetupForm : Form
{
    private TextBox txtName = null!;
    private TextBox txtServerUrl = null!;
    private Button btnSave = null!;
    private Button btnCancel = null!;
    private Label lblTitle = null!;
    private Label lblName = null!;
    private Label lblServerUrl = null!;
    private Label lblHint = null!;
    private PictureBox pictLogo = null!;
    
    private readonly ILogger<EmployeeSetupForm>? _logger;
    private readonly ILocalizationService? _localization;
    private readonly string? _lockedServerUrl;
    
    public EmployeeInfo? EmployeeInfo { get; private set; }
    public string ServerUrl { get; private set; } = string.Empty;
    
    public EmployeeSetupForm(
        ILogger<EmployeeSetupForm>? logger = null,
        ILocalizationService? localization = null,
        string? serverUrl = null,
        string? lockedServerUrl = null)
    {
        _logger = logger;
        _localization = localization;
        _lockedServerUrl = string.IsNullOrWhiteSpace(lockedServerUrl) ? null : lockedServerUrl.Trim();
        
        InitializeComponent();
        ApplyLocalization();
        ConfigureServerUrlField(serverUrl);
        CenterToScreen();
    }

    private void ConfigureServerUrlField(string? serverUrl)
    {
        if (!string.IsNullOrWhiteSpace(_lockedServerUrl))
        {
            txtServerUrl.Text = _lockedServerUrl;
            txtServerUrl.ReadOnly = true;
            txtServerUrl.TabStop = false;
            txtServerUrl.BackColor = SystemColors.Control;
            lblHint.Text = _localization?.GetString(
                "ServerUrlLockedHint",
                "欢迎使用！未来的工作，我们并肩前行。🚀\n服务器地址已预配置，请填写您的姓名后保存。")
                ?? "欢迎使用！未来的工作，我们并肩前行。🚀\n服务器地址已预配置，请填写您的姓名后保存。";
            return;
        }

        txtServerUrl.Text = serverUrl ?? string.Empty;
    }
    
    public EmployeeSetupForm(ILogger<EmployeeSetupForm>? logger = null, ILocalizationService? localization = null, string? serverUrl = null)
        : this(logger, localization, serverUrl, lockedServerUrl: null)
    {
    }
    
    private void InitializeComponent()
    {
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.StartPosition = FormStartPosition.CenterScreen;
        this.Size = new DrawingSize(450, 480);
        this.BackColor = DrawingColor.White;
        this.Font = new Font("Segoe UI", 10F);
        
        pictLogo = new PictureBox
        {
            Size = new DrawingSize(64, 64),
            Location = new DrawingPoint(193, 20),
            BackColor = DrawingColor.Transparent,
            SizeMode = PictureBoxSizeMode.Zoom,
            Image = LoadAppLogo()
        };
        
        lblTitle = new Label
        {
            Text = "DHPG",
            Font = new Font("Segoe UI", 18F, FontStyle.Bold),
            ForeColor = DrawingColor.FromArgb(0, 120, 212),
            Location = new DrawingPoint(25, 92),
            Size = new DrawingSize(400, 32),
            TextAlign = ContentAlignment.MiddleCenter
        };
        
        lblName = new Label { Text = "姓名:", Location = new DrawingPoint(50, 210), Size = new DrawingSize(100, 25), TextAlign = ContentAlignment.MiddleRight };
        txtName = new TextBox { Location = new DrawingPoint(160, 210), Size = new DrawingSize(230, 27), PlaceholderText = "请输入您的姓名" };
        
        lblServerUrl = new Label { Text = "服务器地址:", Location = new DrawingPoint(50, 255), Size = new DrawingSize(100, 25), TextAlign = ContentAlignment.MiddleRight };
        txtServerUrl = new TextBox { Location = new DrawingPoint(160, 255), Size = new DrawingSize(230, 27), PlaceholderText = "请输入服务器地址" };
        
        lblHint = new Label
        {
            Text = GetDefaultWelcomeText(),
            Location = new DrawingPoint(35, 128),
            Size = new DrawingSize(380, 72),
            ForeColor = DrawingColor.FromArgb(80, 80, 80),
            Font = new Font("Segoe UI", 9.5F),
            TextAlign = ContentAlignment.TopCenter
        };
        
        btnSave = new Button { Text = "保存", Location = new DrawingPoint(160, 340), Size = new DrawingSize(100, 35), BackColor = DrawingColor.FromArgb(0, 120, 212), ForeColor = DrawingColor.White, FlatStyle = FlatStyle.Flat };
        btnSave.FlatAppearance.BorderSize = 0;
        btnSave.Click += BtnSave_Click;
        
        btnCancel = new Button { Text = "退出", Location = new DrawingPoint(290, 340), Size = new DrawingSize(100, 35), BackColor = DrawingColor.LightGray, ForeColor = DrawingColor.Black, FlatStyle = FlatStyle.Flat };
        btnCancel.FlatAppearance.BorderSize = 0;
        btnCancel.Click += (s, e) => { _logger?.LogWarning("Startup configuration cancelled, exiting application"); Application.Exit(); };
        
        this.Controls.AddRange(new Control[] { pictLogo, lblTitle, lblName, txtName, lblServerUrl, txtServerUrl, lblHint, btnSave, btnCancel });
        this.FormClosing += EmployeeSetupForm_FormClosing;
    }
    
    private void ApplyLocalization()
    {
        if (_localization == null) return;
        
        this.Text = _localization.GetString("SetupTitle", "DHPG");
        lblTitle.Text = _localization.GetString("AppTitle", "DHPG");
        lblName.Text = _localization.GetString("FullName", "姓名:");
        lblServerUrl.Text = _localization.GetString("ServerURL", "服务器地址:");
        if (string.IsNullOrWhiteSpace(_lockedServerUrl))
            lblHint.Text = BuildWelcomeText(_localization);
        btnSave.Text = _localization.GetString("Save", "保存");
        btnCancel.Text = _localization.GetString("Exit", "退出");
        
        if (txtName != null)
            txtName.PlaceholderText = _localization.GetString("NamePlaceholder", "请输入您的姓名");
        if (txtServerUrl != null)
            txtServerUrl.PlaceholderText = _localization.GetString("ServerUrlPlaceholder", "请输入服务器地址");
    }

    private static string GetDefaultWelcomeText()
        => "欢迎使用！未来的工作，我们并肩前行。🚀\n使用前，请在下方填写您的姓名与服务器地址。";

    private static string BuildWelcomeText(ILocalizationService localization)
    {
        var welcome = localization.GetString("SetupWelcome", "欢迎使用！未来的工作，我们并肩前行。🚀");
        var hint = localization.GetString("SetupHint", "使用前，请在下方填写您的姓名与服务器地址。");
        return $"{welcome}\n{hint}";
    }
    
    private DrawingImage LoadAppLogo()
    {
        var iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
        if (File.Exists(iconPath))
        {
            try
            {
                using var icon = new Icon(iconPath, 64, 64);
                return icon.ToBitmap();
            }
            catch (Exception ex)
            {
                _logger?.LogWarning(ex, "Failed to load logo from {Path}", iconPath);
            }
        }

        return CreateDefaultIcon();
    }

    private DrawingImage CreateDefaultIcon()
    {
        var bitmap = new Bitmap(64, 64);
        using var g = Graphics.FromImage(bitmap);
        g.Clear(DrawingColor.FromArgb(0, 120, 212));
        using var font = new Font("Segoe UI", 28, FontStyle.Bold);
        var appShortName = _localization?.GetString("AppShortName", "EA") ?? "EA";
        g.DrawString(appShortName, font, Brushes.White, new DrawingPointF(12, 12));
        return bitmap;
    }
    
    private void BtnSave_Click(object? sender, EventArgs e)
    {
        var name = txtName.Text.Trim();
        var serverUrl = _lockedServerUrl ?? txtServerUrl.Text.Trim();
        
        if (string.IsNullOrWhiteSpace(name))
        {
            var title = _localization?.GetString("ValidationError", "Validation Error") ?? "Validation Error";
            var message = _localization?.GetString("NameRequired", "Please enter your full name") ?? "Please enter your full name";
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtName.Focus();
            return;
        }
        
        if (string.IsNullOrWhiteSpace(serverUrl))
        {
            var title = _localization?.GetString("ValidationError", "Validation Error") ?? "Validation Error";
            var message = _localization?.GetString("ServerUrlRequired", "Please enter the server URL") ?? "Please enter the server URL";
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            if (_lockedServerUrl == null)
                txtServerUrl.Focus();
            return;
        }
        
        EmployeeInfo = new EmployeeInfo { Name = name };
        ServerUrl = serverUrl;
        _logger?.LogInformation(
            "Startup configuration saved: {Name}, {ServerUrl}, LockedServerUrl={Locked}",
            name, serverUrl, _lockedServerUrl != null);
        DialogResult = DialogResult.OK;
        Close();
    }
    
    private void EmployeeSetupForm_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (EmployeeInfo == null && DialogResult != DialogResult.OK)
        {
            var title = _localization?.GetString("ConfirmExit", "Confirm Exit") ?? "Confirm Exit";
            var message = _localization?.GetString("ExitConfirm", "Are you sure you want to exit? The agent will not run without configuration.") ?? "Are you sure you want to exit?";
            var result = MessageBox.Show(message, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result != DialogResult.Yes) e.Cancel = true;
        }
    }
}

#endregion

#region StatusForm

public class StatusForm : Form
{
    private readonly Func<string> _getDeviceId;
    private readonly Func<string> _getServerUrl;
    private readonly Func<bool> _isConnected;
    private readonly ILocalizationService? _localization;
    
    // 控件
    private Label lblDeviceId = null!;
    private Label lblServerUrl = null!;
    private Label lblConnectionStatus = null!;
    private Label lblVersion = null!;
    private Label lblRecordingStatus = null!;
    private Button btnCopyDeviceId = null!;
    private Button btnRefresh = null!;
    private GroupBox groupDevice = null!;
    private GroupBox groupConnection = null!;
    private GroupBox groupServices = null!;
    private System.Windows.Forms.Timer? _refreshTimer;
    
    public StatusForm(
        Func<string> getDeviceId, 
        Func<string> getServerUrl, 
        Func<bool> isConnected,
        ILocalizationService? localization = null)
    {
        _getDeviceId = getDeviceId;
        _getServerUrl = getServerUrl;
        _isConnected = isConnected;
        _localization = localization;
        
        InitializeComponent();
        ApplyLocalization();
        UpdateStatus();
        
        _refreshTimer = new System.Windows.Forms.Timer { Interval = 2000 };
        _refreshTimer.Tick += (s, e) => UpdateStatus();
        _refreshTimer.Start();
    }
    
    private void InitializeComponent()
    {
        this.Text = "Agent Status";
        this.Size = new DrawingSize(450, 380);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.MinimizeBox = true;
        this.BackColor = DrawingColor.White;
        this.Font = new Font("Segoe UI", 10F);
        
        var appName = _localization?.GetString("AppTitle", "Enterprise Agent") ?? "Enterprise Agent";
        var lblTitle = new Label { Text = $"{appName} Status", Font = new Font("Segoe UI", 14F, FontStyle.Bold), Location = new DrawingPoint(15, 15), Size = new DrawingSize(400, 30), ForeColor = DrawingColor.FromArgb(0, 120, 212) };
        
        // 设备信息组
        groupDevice = new GroupBox { Text = "Device Information", Location = new DrawingPoint(15, 55), Size = new DrawingSize(410, 95) };
        var lblDeviceIdLabel = new Label { Text = "Device ID:", Location = new DrawingPoint(15, 28), Size = new DrawingSize(80, 25) };
        lblDeviceId = new Label { Location = new DrawingPoint(100, 28), Size = new DrawingSize(220, 25), Font = new Font("Consolas", 9F), ForeColor = DrawingColor.DarkGray };
        btnCopyDeviceId = new Button { Text = "Copy", Location = new DrawingPoint(325, 26), Size = new DrawingSize(65, 27), FlatStyle = FlatStyle.Flat, BackColor = DrawingColor.FromArgb(0, 120, 212), ForeColor = DrawingColor.White };
        btnCopyDeviceId.FlatAppearance.BorderSize = 0;
        btnCopyDeviceId.Click += (s, e) => CopyDeviceId();
        var lblVersionLabel = new Label { Text = "Agent Version:", Location = new DrawingPoint(15, 58), Size = new DrawingSize(80, 25) };
        lblVersion = new Label { Text = Constants.DefaultAgentVersion, Location = new DrawingPoint(100, 58), Size = new DrawingSize(150, 25) };
        groupDevice.Controls.AddRange(new Control[] { lblDeviceIdLabel, lblDeviceId, btnCopyDeviceId, lblVersionLabel, lblVersion });
        
        // 连接信息组
        groupConnection = new GroupBox { Text = "Connection", Location = new DrawingPoint(15, 160), Size = new DrawingSize(410, 85) };
        var lblServerLabel = new Label { Text = "Server URL:", Location = new DrawingPoint(15, 28), Size = new DrawingSize(80, 25) };
        lblServerUrl = new Label { Location = new DrawingPoint(100, 28), Size = new DrawingSize(290, 25), Font = new Font("Consolas", 9F), ForeColor = DrawingColor.DarkGray };
        var lblStatusLabel = new Label { Text = "Status:", Location = new DrawingPoint(15, 55), Size = new DrawingSize(80, 25) };
        lblConnectionStatus = new Label { Location = new DrawingPoint(100, 55), Size = new DrawingSize(150, 25), Font = new Font("Segoe UI", 9F, FontStyle.Bold) };
        groupConnection.Controls.AddRange(new Control[] { lblServerLabel, lblServerUrl, lblStatusLabel, lblConnectionStatus });
        
        // 服务状态组
        groupServices = new GroupBox { Text = "Services", Location = new DrawingPoint(15, 255), Size = new DrawingSize(410, 60) };
        var lblRecording = new Label { Text = "Recording:", Location = new DrawingPoint(15, 28), Size = new DrawingSize(70, 25) };
        lblRecordingStatus = new Label { Name = "lblRecordingStatus", Text = "● Idle", Location = new DrawingPoint(90, 28), Size = new DrawingSize(100, 25), ForeColor = DrawingColor.Gray };
        groupServices.Controls.AddRange(new Control[] { lblRecording, lblRecordingStatus });
        
        // 刷新按钮
        btnRefresh = new Button { Text = "Refresh", Location = new DrawingPoint(340, 325), Size = new DrawingSize(85, 30), FlatStyle = FlatStyle.Flat, BackColor = DrawingColor.LightGray };
        btnRefresh.Click += (s, e) => UpdateStatus();
        
        this.Controls.AddRange(new Control[] { lblTitle, groupDevice, groupConnection, groupServices, btnRefresh });
    }
    
    private void ApplyLocalization()
    {
        if (_localization == null) return;
        
        this.Text = _localization.GetString("AgentStatus", "Agent Status");
        groupDevice.Text = _localization.GetString("DeviceInformation", "Device Information");
        groupConnection.Text = _localization.GetString("Connection", "Connection");
        groupServices.Text = _localization.GetString("Services", "Services");
        btnRefresh.Text = _localization.GetString("Refresh", "Refresh");
        btnCopyDeviceId.Text = _localization.GetString("Copy", "Copy");
        
        // 更新标签文本
        foreach (Control ctrl in groupDevice.Controls)
        {
            if (ctrl is Label label && label.Text == "Device ID:")
                label.Text = _localization.GetString("DeviceId", "Device ID:") + ":";
            if (ctrl is Label label2 && label2.Text == "Agent Version:")
                label2.Text = _localization.GetString("AgentVersion", "Agent Version:") + ":";
        }
        
        foreach (Control ctrl in groupConnection.Controls)
        {
            if (ctrl is Label label && label.Text == "Server URL:")
                label.Text = _localization.GetString("ServerURL", "Server URL:") + ":";
            if (ctrl is Label label2 && label2.Text == "Status:")
                label2.Text = _localization.GetString("Status", "Status:") + ":";
        }
        
        foreach (Control ctrl in groupServices.Controls)
        {
            if (ctrl is Label label && label.Text == "Recording:")
                label.Text = _localization.GetString("Recording", "Recording:") + ":";
        }
    }
    
    public void UpdateServiceStatus(string status, bool isActive)
    {
        if (lblRecordingStatus == null) return;
        
        if (isActive)
        {
            lblRecordingStatus.Text = $"● {status}";
            lblRecordingStatus.ForeColor = DrawingColor.Green;
        }
        else
        {
            lblRecordingStatus.Text = $"○ {status}";
            lblRecordingStatus.ForeColor = DrawingColor.Gray;
        }
    }
    
    private void UpdateStatus()
    {
        if (this.IsDisposed) return;
        try
        {
            var deviceId = _getDeviceId();
            var notRegistered = _localization?.GetString("NotRegistered", "Not registered") ?? "Not registered";
            lblDeviceId.Text = string.IsNullOrEmpty(deviceId) ? notRegistered : deviceId;
            lblServerUrl.Text = _getServerUrl();
            
            var isConnected = _isConnected();
            var connectedText = isConnected ? 
                (_localization?.GetString("Connected", "Connected") ?? "Connected") : 
                (_localization?.GetString("Disconnected", "Disconnected") ?? "Disconnected");
            lblConnectionStatus.Text = isConnected ? $"● {connectedText}" : $"○ {connectedText}";
            lblConnectionStatus.ForeColor = isConnected ? DrawingColor.Green : DrawingColor.Red;
        }
        catch { }
    }
    
    private void CopyDeviceId()
    {
        try
        {
            var deviceId = _getDeviceId();
            if (!string.IsNullOrEmpty(deviceId))
            {
                Clipboard.SetText(deviceId);
                var title = _localization?.GetString("Copied", "Copied") ?? "Copied";
                var message = _localization?.GetString("DeviceIdCopied", "Device ID copied to clipboard") ?? "Device ID copied to clipboard";
                MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        catch (Exception ex)
        {
            var title = _localization?.GetString("Error", "Error") ?? "Error";
            MessageBox.Show($"Failed to copy: {ex.Message}", title, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (e.CloseReason == CloseReason.UserClosing)
        {
            e.Cancel = true;
            this.Hide();
        }
        base.OnFormClosing(e);
    }
    
    protected override void Dispose(bool disposing)
    {
        if (disposing) _refreshTimer?.Dispose();
        base.Dispose(disposing);
    }
}

#endregion
import { ref, shallowRef } from "vue";
import {
  Room,
  RoomEvent,
  Track,
  ConnectionState,
  type RemoteParticipant,
  type RemoteTrack,
  type RemoteTrackPublication,
} from "livekit-client";
import { remoteViewApi } from "@api/index";
import type { RemoteViewStartSession } from "@api/types";
import { ElMessage } from "element-plus";

export function useRemoteView() {
  const room = shallowRef<Room | null>(null);
  const connectionState = ref<ConnectionState>(ConnectionState.Disconnected);
  const sessionInfo = ref<RemoteViewStartSession | null>(null);
  const sessionStatus = ref("");
  const stats = ref({
    fps: 0,
    bitrateKbps: 0,
    encoder: "",
  });

  let reconnectAttempts = 0;
  let reconnectTimer: number | null = null;
  let viewGeneration = 0;
  const MAX_RECONNECT = 5;

  const clearReconnectTimer = () => {
    if (reconnectTimer != null) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
  };

  const attachVideo = (container: HTMLElement, track: RemoteTrack) => {
    const element = track.attach();
    element.style.width = "100%";
    element.style.height = "100%";
    element.style.objectFit = "contain";
    container.replaceChildren(element);
  };

  const attachExistingVideoTracks = (
    lkRoom: Room,
    container: HTMLElement,
  ) => {
    for (const participant of lkRoom.remoteParticipants.values()) {
      attachParticipantVideo(participant, container);
    }
  };

  const attachParticipantVideo = (
    participant: RemoteParticipant,
    container: HTMLElement,
  ) => {
    for (const publication of participant.trackPublications.values()) {
      const pub = publication as RemoteTrackPublication;
      if (pub.track && pub.kind === Track.Kind.Video) {
        attachVideo(container, pub.track as RemoteTrack);
      }
    }
  };

  const bindRoomEvents = (
    lkRoom: Room,
    deviceId: string,
    videoContainer: HTMLElement,
    generation: number,
  ) => {
    lkRoom.on(RoomEvent.TrackSubscribed, (track) => {
      if (track.kind === Track.Kind.Video) {
        attachVideo(videoContainer, track as RemoteTrack);
      }
    });

    lkRoom.on(RoomEvent.TrackUnsubscribed, (track) => {
      if (track.kind === Track.Kind.Video) {
        track.detach();
        videoContainer.replaceChildren();
      }
    });

    lkRoom.on(RoomEvent.ConnectionStateChanged, (state) => {
      connectionState.value = state;
      if (state === ConnectionState.Connected) {
        reconnectAttempts = 0;
        attachExistingVideoTracks(lkRoom, videoContainer);
      }
    });

    lkRoom.on(RoomEvent.Disconnected, () => {
      if (generation !== viewGeneration) return;
      if (reconnectAttempts >= MAX_RECONNECT) {
        ElMessage.error("远程查看连接已断开，请手动重新开始");
        return;
      }

      reconnectAttempts += 1;
      const delay = Math.min(1000 * 2 ** (reconnectAttempts - 1), 30000);
      const sessionId = sessionInfo.value?.sessionId;
      room.value = null;
      clearReconnectTimer();
      reconnectTimer = window.setTimeout(async () => {
        if (generation !== viewGeneration) return;
        try {
          if (sessionId) {
            await remoteViewApi.stop(deviceId, sessionId);
          }
          sessionInfo.value = null;
          await startView(deviceId, videoContainer);
        } catch (error) {
          console.error(error);
          ElMessage.error("远程查看重连失败，请手动重新开始");
        }
      }, delay);
    });
  };

  const startView = async (deviceId: string, videoContainer: HTMLElement) => {
    let startedSessionId: string | undefined;
    const generation = ++viewGeneration;

    try {
      const { data } = await remoteViewApi.start(deviceId);
      if (generation !== viewGeneration) {
        await remoteViewApi.stop(deviceId, data.sessionId);
        return data;
      }

      sessionInfo.value = data;
      sessionStatus.value = "starting";
      startedSessionId = data.sessionId;

      const lkRoom = new Room({
        adaptiveStream: true,
        dynacast: false,
      });

      bindRoomEvents(lkRoom, deviceId, videoContainer, generation);

      await lkRoom.connect(data.livekitUrl, data.viewerToken);
      if (generation !== viewGeneration) {
        await lkRoom.disconnect();
        return data;
      }

      room.value = lkRoom;
      sessionStatus.value = "active";
      attachExistingVideoTracks(lkRoom, videoContainer);
      return data;
    } catch (error) {
      if (startedSessionId) {
        try {
          await remoteViewApi.stop(deviceId, startedSessionId);
        } catch {
          // ignore cleanup errors
        }
      }
      sessionInfo.value = null;
      sessionStatus.value = "";
      throw error;
    }
  };

  const stopView = async (deviceId: string) => {
    viewGeneration += 1;
    reconnectAttempts = MAX_RECONNECT;
    clearReconnectTimer();
    if (room.value) {
      await room.value.disconnect();
      room.value = null;
    }
    if (sessionInfo.value?.sessionId) {
      await remoteViewApi.stop(deviceId, sessionInfo.value.sessionId);
    }
    sessionInfo.value = null;
    sessionStatus.value = "";
    connectionState.value = ConnectionState.Disconnected;
  };

  const refreshStatus = async (deviceId: string) => {
    const { data } = await remoteViewApi.getStatus(deviceId);
    sessionStatus.value = data.status || (data.isActive ? "active" : "");
    if (data.stats) {
      stats.value = {
        fps: data.stats.fps,
        bitrateKbps: data.stats.bitrateKbps,
        encoder: data.stats.encoder,
      };
    }
    return data;
  };

  return {
    room,
    connectionState,
    sessionInfo,
    sessionStatus,
    stats,
    startView,
    stopView,
    refreshStatus,
  };
}

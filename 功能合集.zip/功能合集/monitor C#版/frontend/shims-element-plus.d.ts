// frontend/shims-element-plus.d.ts
declare module "element-plus/dist/locale/zh-cn.mjs" {
  const lang: any;
  export default lang;
}

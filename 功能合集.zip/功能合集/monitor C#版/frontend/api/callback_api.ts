import request from "./request";

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface CallbackPlatform {
  id: string;
  name: string;
  baseUrl: string;
  tenantId: string;
  enabled: boolean;
  remark?: string;
  createdBy?: string;
  createdAt?: string;
  updatedAt?: string;
  tokenMasked?: string;
}

export interface CallbackAPIEndpoint {
  id?: string;
  platformId?: string | null;
  code: string;
  name: string;
  path: string;
  httpMethod: string;
  requestParamsTemplate: string;
  responseMapping: string;
  paginationConfig: string;
  enabled: boolean;
  sortOrder?: number;
  remark?: string;
}

export interface ManualDispatchRuleSet {
  enabledFilters: string[];
}

export interface CallbackActivity {
  id?: string;
  days: number;
  rate: number;
  divisor: number;
  minBonus: number;
  maxBonus: number;
  excludeRewarded: boolean;
  healthMin: number;
  healthMax: number;
  periodFilteredTiers?: string[];
  periodWageringMultiplier: number;
  periodAppRemark: string;
  periodBackendRemark: string;
  callbackMinBonus: number;
  callbackRate: number;
  callbackDivisor: number;
  callbackFilteredTiers?: string[];
  callbackWageringMultiplier: number;
  callbackAppRemark: string;
  callbackBackendRemark: string;
  periodManualRules?: ManualDispatchRuleSet;
  callbackManualRules?: ManualDispatchRuleSet;
  updatedAt?: string;
}

export interface CallbackTask {
  id: string;
  platformId: string;
  dateFrom: string;
  dateTo: string;
  activitySnapshot?: string;
  status: string;
  memberCount: number;
  totalBonus: number;
  healthLevel?: string | null;
  errorMessage?: string;
  createdBy?: string;
  startedAt?: string;
  finishedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface CallbackResult {
  id: string;
  taskId: string;
  userId: number;
  phoneNumber?: string;
  vipLevel: number;
  historicalPay: number;
  historyWithdrawals: number;
  historicalReward: number;
  profit: number;
  bonus: number;
  createdAt?: string;
}

export interface CallbackRequestLog {
  id: string;
  platformId?: string;
  taskId?: string;
  endpointCode?: string;
  requestUrl: string;
  requestParams?: string;
  responseStatus?: number;
  durationMs: number;
  errorMessage?: string;
  createdAt?: string;
}

export interface CallbackTaskEstimate {
  memberCount: number;
  totalBonus: number;
  healthLevel: string;
  fetchedCount: number;
  dateFrom: string;
  dateTo: string;
  platformId: string;
  endpointCode: string;
}

export type ManualDispatchType = "period_bonus" | "callback_bonus";

export interface ManualMemberColumnMapping {
  userId: number;
  historicalPay: number;
  historyWithdrawals: number;
  phoneNumber: number;
  tierLevel?: number;
  excludedTiers?: string[];
  headerRow: number;
}

export interface ManualUnclaimedColumnMapping {
  userId: number;
  phoneNumber: number;
  headerRow: number;
}

export interface ManualColumnPreview {
  index: number;
  letter: string;
  header: string;
}

export const DEFAULT_UNCLAIMED_COLUMN_MAPPING: ManualUnclaimedColumnMapping = {
  userId: 0,
  phoneNumber: 1,
  headerRow: 0,
};

export interface ManualBonusConfig {
  rate: number;
  divisor: number;
  minBonus: number;
  maxBonus: number;
  callbackMinBonus: number;
  wageringMultiplier: number;
  appRemark: string;
  backendRemark: string;
}

export interface ManualRow {
  rowIndex?: number;
  userId: number;
  phoneNumber: string;
  historicalPay: number;
  historyWithdrawals: number;
  tierLevel?: string;
  profit: number;
  bonus?: number;
  excludeReason?: string;
}

export interface ManualSummary {
  totalRows: number;
  unclaimedFileRows: number;
  unclaimedMatchedCount: number;
  bonusCount: number;
  otherCount: number;
  excludedCount: number;
  totalBonus: number;
}

export interface ManualProcessResult {
  resultId?: string;
  truncated?: boolean;
  dispatchType: ManualDispatchType;
  bonusConfig: ManualBonusConfig;
  summary: ManualSummary;
  bonusRows: ManualRow[];
  otherRows: ManualRow[];
  excludedRows: ManualRow[];
  unclaimedRewardRows: ManualRow[];
}

export interface CallbackPlatformTestResult {
  success: boolean;
  statusCode: number;
  durationMs: number;
  message: string;
  endpointCode: string;
  sampleCount: number;
}

const callbackApi = {
  listPlatforms: (params?: {
    keyword?: string;
    enabled?: boolean;
    page?: number;
    pageSize?: number;
  }) => request.get<Paginated<CallbackPlatform>>("/callback/platforms", { params }),

  getPlatform: (id: string) =>
    request.get<CallbackPlatform>(`/callback/platforms/${id}`),

  createPlatform: (data: {
    name: string;
    baseUrl: string;
    tenantId: string;
    token: string;
    enabled?: boolean;
    remark?: string;
  }) => request.post<CallbackPlatform>("/callback/platforms", data),

  updatePlatform: (
    id: string,
    data: {
      name: string;
      baseUrl: string;
      tenantId: string;
      token?: string;
      enabled?: boolean;
      remark?: string;
    },
  ) => request.put<CallbackPlatform>(`/callback/platforms/${id}`, data),

  deletePlatform: (id: string) => request.delete(`/callback/platforms/${id}`),

  testPlatform: (id: string, data?: { endpointCode?: string }) =>
    request.post<CallbackPlatformTestResult>(`/callback/platforms/${id}/test`, data ?? {}),

  listEndpoints: (params?: { platformId?: string; code?: string }) =>
    request.get<CallbackAPIEndpoint[]>("/callback/endpoints", { params }),

  createEndpoint: (data: CallbackAPIEndpoint) =>
    request.post<CallbackAPIEndpoint>("/callback/endpoints", data),

  updateEndpoint: (id: string, data: CallbackAPIEndpoint) =>
    request.put<CallbackAPIEndpoint>(`/callback/endpoints/${id}`, data),

  deleteEndpoint: (id: string) => request.delete(`/callback/endpoints/${id}`),

  getActivity: () => request.get<CallbackActivity>("/callback/activity"),

  updateActivity: (data: CallbackActivity) =>
    request.put<CallbackActivity>("/callback/activity", data),

  generateTask: (data: {
    platformId: string;
    dateFrom?: string;
    dateTo?: string;
    endpointCode?: string;
  }) =>
    request.post<CallbackTask>("/callback/tasks/generate", data, {
      timeout: 300000,
    }),

  estimateTask: (data: {
    platformId: string;
    dateFrom?: string;
    dateTo?: string;
    endpointCode?: string;
  }) =>
    request.post<CallbackTaskEstimate>("/callback/tasks/estimate", data, {
      timeout: 300000,
    }),

  listTasks: (params?: {
    platformId?: string;
    status?: string;
    page?: number;
    pageSize?: number;
  }) => request.get<Paginated<CallbackTask>>("/callback/tasks", { params }),

  getTask: (id: string) => request.get<CallbackTask>(`/callback/tasks/${id}`),

  listTaskResults: (
    taskId: string,
    params?: { page?: number; pageSize?: number },
  ) =>
    request.get<Paginated<CallbackResult>>(`/callback/tasks/${taskId}/results`, {
      params,
    }),

  exportTask: (taskId: string) =>
    request.get<Blob>(`/callback/tasks/${taskId}/export`, {
      responseType: "blob",
    }),

  listRequestLogs: (params?: {
    platformId?: string;
    taskId?: string;
    endpointCode?: string;
    page?: number;
    pageSize?: number;
  }) =>
    request.get<Paginated<CallbackRequestLog>>("/callback/request-logs", {
      params,
    }),

  downloadManualTemplate: (type: "member" | "unclaimed" = "member") =>
    request.get<Blob>("/callback/manual/template", {
      params: { type },
      responseType: "blob",
    }),

  previewManualColumns: (file: File, headerRow = 0) => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("headerRow", String(headerRow));
    return request.post<ManualColumnPreview[]>("/callback/manual/preview", formData, {
      timeout: 60000,
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  previewManualTierValues: (file: File, headerRow: number, tierColumn: number) => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("headerRow", String(headerRow));
    formData.append("tierColumn", String(tierColumn));
    return request.post<string[]>("/callback/manual/preview-tiers", formData, {
      timeout: 60000,
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  processManualImport: (payload: {
    dispatchType: ManualDispatchType;
    memberFile: File;
    unclaimedFile?: File;
    memberMapping: ManualMemberColumnMapping;
    unclaimedMapping?: ManualUnclaimedColumnMapping;
  }) => {
    const formData = new FormData();
    formData.append("dispatchType", payload.dispatchType);
    formData.append("memberFile", payload.memberFile);
    formData.append("memberMapping", JSON.stringify(payload.memberMapping));
    formData.append(
      "unclaimedMapping",
      JSON.stringify(payload.unclaimedMapping ?? DEFAULT_UNCLAIMED_COLUMN_MAPPING),
    );
    if (payload.unclaimedFile) {
      formData.append("unclaimedFile", payload.unclaimedFile);
    }
    return request.post<ManualProcessResult>("/callback/manual/process", formData, {
      timeout: 300000,
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  exportManualResult: (exportType: string, result: ManualProcessResult) =>
    request.post<Blob>(
      "/callback/manual/export",
      {
        exportType,
        resultId: result.resultId,
        result: result.truncated ? { dispatchType: result.dispatchType } : result,
      },
      { responseType: "blob", timeout: 300000 },
    ),
};

export default callbackApi;

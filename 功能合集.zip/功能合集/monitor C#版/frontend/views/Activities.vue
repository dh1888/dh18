<template>
  <div class="activities-page">
    <!-- ========== 统计卡片区 ========== -->
    <el-row :gutter="20" class="stats-row">
      <el-col :xs="12" :sm="6">
        <el-card class="stat-card card-hover" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-title">今日活跃时长</div>
              <div class="stat-value">
                {{ formatDuration(stats?.totalDuration || 0) }}
              </div>
              <div class="stat-subtitle">活跃占比 {{ activePercent }}%</div>
            </div>
            <div class="stat-icon" style="background-color: #e6f7ff">
              <el-icon :size="28" color="#1890ff"><Timer /></el-icon>
            </div>
          </div>
        </el-card>
      </el-col>

      <el-col :xs="12" :sm="6">
        <el-card class="stat-card card-hover" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-title">空闲时长</div>
              <div class="stat-value">
                {{ formatDuration(stats?.idleDuration || 0) }}
              </div>
              <div class="stat-subtitle">空闲占比 {{ idlePercent }}%</div>
            </div>
            <div class="stat-icon" style="background-color: #fff7e6">
              <el-icon :size="28" color="#faad14"><Coffee /></el-icon>
            </div>
          </div>
        </el-card>
      </el-col>

      <el-col :xs="12" :sm="6">
        <el-card class="stat-card card-hover" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-title">工作效率</div>
              <div class="stat-value">
                {{ stats?.productivityRate?.toFixed(1) || 0 }}%
              </div>
              <div class="stat-subtitle">
                {{ getProductivityLabel(stats?.productivityRate || 0) }}
              </div>
            </div>
            <div
              class="stat-icon"
              :style="{
                backgroundColor: getProductivityColor(
                  stats?.productivityRate || 0,
                ),
              }"
            >
              <el-icon :size="28" color="#fff"><TrendCharts /></el-icon>
            </div>
          </div>
        </el-card>
      </el-col>

      <el-col :xs="12" :sm="6">
        <el-card class="stat-card card-hover" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-title">应用总数</div>
              <div class="stat-value">{{ stats?.topApps?.length || 0 }}</div>
              <div class="stat-subtitle">今日使用应用数</div>
            </div>
            <div class="stat-icon" style="background-color: #f6ffed">
              <el-icon :size="28" color="#52c41a"><Grid /></el-icon>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- ========== 筛选区域 ========== -->
    <el-card class="filter-card card-hover" shadow="hover">
      <el-form :inline="true" :model="filters" class="filter-form">
        <el-form-item label="员工">
          <el-select
            v-model="filters.deviceId"
            placeholder="选择员工查看活动"
            clearable
            filterable
            style="width: 220px"
            @change="handleSearch"
          >
            <el-option
              v-for="device in devices"
              :key="device.id"
              :label="
                device.employeeName
                  ? `${device.employeeName} (${device.employeeNumber || '未设置'})`
                  : device.hostname
              "
              :value="device.id"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="日期">
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="YYYY-MM-DD"
            :shortcuts="dateShortcuts"
            @change="handleDateRangeChange"
            style="width: 280px"
          />
        </el-form-item>

        <el-form-item label="应用名称">
          <el-input
            v-model="filters.processName"
            placeholder="请输入应用名称"
            clearable
            style="width: 180px"
            @clear="handleSearch"
            @keyup.enter="handleSearch"
          />
        </el-form-item>

        <el-form-item label="状态">
          <el-select
            v-model="filters.status"
            placeholder="仅用户操作"
            clearable
            style="width: 120px"
            @change="handleSearch"
          >
            <el-option label="用户操作" value="active" />
            <el-option label="空闲" value="idle" />
            <el-option label="全部" value="" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleSearch">
            <el-icon><Search /></el-icon>
            搜索
          </el-button>
          <el-button @click="handleReset">
            <el-icon><Refresh /></el-icon>
            重置
          </el-button>
          <el-button type="success" @click="handleExport" :loading="exporting">
            <el-icon><Download /></el-icon>
            导出
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- ========== 活动日志表格 ========== -->
    <el-card class="table-card card-hover" shadow="hover">
      <template #header>
        <div class="card-header">
          <div class="header-title">
            <el-icon><Document /></el-icon>
            <span>活动记录明细</span>
            <el-badge
              :value="pagination.total"
              :hidden="pagination.total === 0"
              class="total-badge"
            />
          </div>
          <div class="header-actions">
            <el-button size="small" @click="loadActivities" :loading="loading">
              <el-icon><RefreshRight /></el-icon>
              刷新
            </el-button>
          </div>
        </div>
      </template>

      <el-table
        :data="activities"
        v-loading="loading"
        stripe
        border
        :default-sort="{ prop: 'startedAt', order: 'descending' }"
      >
        <el-table-column
          prop="employeeName"
          label="员工姓名"
          width="120"
          fixed="left"
        >
          <template #default="{ row }">
            <div class="employee-cell">
              <el-icon><User /></el-icon>
              <span>{{ getEmployeeName(row) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column
          prop="processName"
          label="应用名称"
          width="150"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            <div class="app-cell">
              <el-icon><Monitor /></el-icon>
              <span>{{ row.processName || "-" }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column
          prop="windowTitle"
          label="窗口标题"
          min-width="250"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            <span class="window-title">{{ formatDisplayTitle(row) }}</span>
          </template>
        </el-table-column>

        <el-table-column
          prop="browserTitle"
          label="浏览器标题"
          width="200"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            <span class="browser-title">{{ formatBrowserTitle(row) }}</span>
          </template>
        </el-table-column>

        <el-table-column prop="startedAt" label="开始时间" width="170" sortable>
          <template #default="{ row }">
            <div class="time-cell">
              <el-icon><Clock /></el-icon>
              <span>{{ formatDateTime(row.startedAt) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="endedAt" label="结束时间" width="170">
          <template #default="{ row }">
            <span>{{ formatDateTime(row.endedAt) }}</span>
          </template>
        </el-table-column>

        <el-table-column
          prop="durationSeconds"
          label="持续时间"
          width="110"
          sortable
        >
          <template #default="{ row }">
            <el-tag
              :type="getDurationType(row.durationSeconds)"
              size="small"
              effect="light"
            >
              {{ formatDuration(row.durationSeconds) }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="isIdle" label="状态" width="80" align="center">
          <template #default="{ row }">
            <el-tag
              :type="row.isIdle ? 'info' : 'success'"
              size="small"
              effect="dark"
            >
              {{ row.isIdle ? "空闲" : "活跃" }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="pagination.total"
          :page-sizes="[15, 30, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from "vue";
import { useRoute } from "vue-router";
import { ElMessage } from "element-plus";
import {
  Search,
  Refresh,
  Download,
  Timer,
  Coffee,
  TrendCharts,
  Grid,
  Monitor,
  User,
  Document,
  RefreshRight,
  Clock,
} from "@element-plus/icons-vue";
import { activityApi, deviceApi } from "@api/index";
import {
  sanitizeDisplayText,
  formatActivityTitle,
} from "@api/format";
import type { ActivityLog, ActivityStats, Device } from "@api/types";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);

// ========== 状态定义 ==========
const route = useRoute();
const loading = ref(false);
const exporting = ref(false);
const activities = ref<ActivityLog[]>([]);
const devices = ref<Device[]>([]);
const stats = ref<ActivityStats | null>(null);

// 日期范围
const dateRange = ref<[string, string] | null>(null);

// 快捷日期选项
const dateShortcuts = [
  {
    text: "今日",
    value: () => {
      const d = new Date();
      return [d, d];
    },
  },
  {
    text: "昨日",
    value: () => {
      const d = new Date();
      d.setDate(d.getDate() - 1);
      return [d, d];
    },
  },
  {
    text: "本周",
    value: () => {
      const d = new Date();
      const start = new Date(d);
      start.setDate(d.getDate() - d.getDay() + 1);
      return [start, d];
    },
  },
  {
    text: "本月",
    value: () => {
      const d = new Date();
      return [new Date(d.getFullYear(), d.getMonth(), 1), d];
    },
  },
];

const filters = reactive({
  deviceId: "",
  startDate: "",
  endDate: "",
  processName: "",
  status: "active",
});

const pagination = reactive({
  page: 1,
  pageSize: 15,
  total: 0,
});

// ========== 计算属性 ==========
// 活跃占比
const activePercent = computed(() => {
  const total =
    (stats.value?.totalDuration || 0) + (stats.value?.idleDuration || 0);
  if (total === 0) return 0;
  return (((stats.value?.activeDuration || 0) / total) * 100).toFixed(1);
});

// 空闲占比
const idlePercent = computed(() => {
  const total =
    (stats.value?.totalDuration || 0) + (stats.value?.idleDuration || 0);
  if (total === 0) return 0;
  return (((stats.value?.idleDuration || 0) / total) * 100).toFixed(1);
});

// ========== 辅助函数 ==========
const formatDuration = (seconds: number): string => {
  if (seconds <= 0) return "0秒";
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  const parts: string[] = [];
  if (hours > 0) parts.push(`${hours}小时`);
  if (minutes > 0) parts.push(`${minutes}分钟`);
  if (secs > 0 || parts.length === 0) parts.push(`${secs}秒`);
  return parts.join("");
};

const formatDateTime = (time: string | null | undefined) => {
  if (!time) return "-";
  return new Date(time).toLocaleString("zh-CN");
};

const getProductivityColor = (rate: number): string => {
  if (rate >= 70) return "#52c41a";
  if (rate >= 50) return "#faad14";
  return "#f5222d";
};

const getProductivityLabel = (rate: number): string => {
  if (rate >= 70) return "高效";
  if (rate >= 50) return "中等";
  return "待提升";
};

const getDurationType = (seconds: number): string => {
  if (seconds > 3600) return "danger";
  if (seconds > 1800) return "warning";
  if (seconds > 60) return "primary";
  return "info";
};

// ========== 数据加载 ==========
const loadDevices = async () => {
  try {
    const { data } = await deviceApi.list({ page: 1, pageSize: 1000 });
    devices.value = data.items || [];
  } catch (error) {
    console.error("加载设备列表失败:", error);
  }
};

const getEmployeeName = (row: ActivityLog) => {
  if (!row?.deviceId) return "-";
  const device = devices.value.find((d) => d.id === row.deviceId);
  if (device?.employeeName) {
    return device.employeeName;
  }
  // 降级显示：显示设备ID后8位
  return row.deviceId.slice(-8) || "-";
};

const formatDisplayTitle = (row: ActivityLog): string => formatActivityTitle(row);

const formatBrowserTitle = (row: ActivityLog): string => {
  const title = sanitizeDisplayText(row.browserTitle);
  return title || "-";
};

const isMeaningfulActivity = (row: ActivityLog): boolean => {
  if (row.isIdle) return false;
  const processName = sanitizeDisplayText(row.processName);
  if (!processName) return false;
  const title = formatDisplayTitle(row);
  return title !== "-" && title !== "无标题" && (row.durationSeconds ?? 0) >= 3;
};

const loadActivities = async () => {
  loading.value = true;
  try {
    const params: any = {
      page: pagination.page,
      pageSize: pagination.pageSize,
    };

    if (filters.deviceId) params.deviceId = filters.deviceId;
    if (filters.startDate) params.startDate = filters.startDate;
    if (filters.endDate) params.endDate = filters.endDate;
    if (filters.processName) params.processName = filters.processName;

    const { data } = await activityApi.list(params);
    let items = data.items || [];

    // 前端状态与质量筛选：默认仅展示用户真实操作
    if (filters.status === "active" || filters.status === "") {
      items = items.filter(
        (a: ActivityLog) => !a.isIdle && isMeaningfulActivity(a),
      );
    } else if (filters.status === "idle") {
      items = items.filter((a: ActivityLog) => a.isIdle);
    }

    activities.value = items;
    pagination.total = data.total;
  } catch (error: any) {
    ElMessage.error(error.message || "加载活动日志失败");
  } finally {
    loading.value = false;
  }
};

const loadStats = async () => {
  try {
    const response = await activityApi.getStats(
      filters.deviceId || undefined,
      filters.startDate || undefined,
      filters.endDate || undefined,
    );

    // 响应数据在 response.data 中
    const rawData = response.data || {};

    // 确保所有字段都有默认值
    stats.value = {
      totalDuration: rawData.totalDuration ?? 0,
      idleDuration: rawData.idleDuration ?? 0,
      activeDuration: rawData.activeDuration ?? 0,
      topApps: rawData.topApps ?? [],
      dailyActivity: rawData.dailyActivity ?? [],
      productivityRate: rawData.productivityRate ?? 0,
      hourlyActivity: rawData.hourlyActivity ?? {},
    };
  } catch (error) {
    console.error("加载统计数据失败:", error);
    // 设置默认值避免页面报错
    stats.value = {
      totalDuration: 0,
      idleDuration: 0,
      activeDuration: 0,
      topApps: [],
      dailyActivity: [],
      productivityRate: 0,
      hourlyActivity: {},
    };
  }
};

// ========== 事件处理 ==========
const handleSearch = () => {
  pagination.page = 1;
  loadActivities();
  loadStats();
};

const handleReset = () => {
  filters.deviceId = "";
  filters.processName = "";
  filters.status = "active";
  dateRange.value = null;
  filters.startDate = "";
  filters.endDate = "";
  handleSearch();
};

const handleDateRangeChange = (range: [string, string] | null) => {
  if (range && range[0] && range[1]) {
    filters.startDate = range[0];
    filters.endDate = range[1];
  } else {
    filters.startDate = "";
    filters.endDate = "";
  }
  handleSearch();
};

const handleSizeChange = () => {
  pagination.page = 1;
  loadActivities();
};

const handleCurrentChange = () => {
  loadActivities();
};

const handleExport = async () => {
  exporting.value = true;
  try {
    const response = await activityApi.export({
      deviceId: filters.deviceId || undefined,
      startDate: filters.startDate || undefined,
      endDate: filters.endDate || undefined,
    });
    const blob = response.data as Blob;
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `activities_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    ElMessage.success("导出成功");
  } catch (error: any) {
    ElMessage.error(error.message || "导出失败");
  } finally {
    exporting.value = false;
  }
};

// ========== 生命周期 ==========
onMounted(() => {
  const deviceId = route.query.deviceId as string;
  if (deviceId) {
    filters.deviceId = deviceId;
  }

  loadDevices();
  loadActivities();
  loadStats();
});
</script>

<style scoped>
.activities-page {
  min-height: 100%;
}

/* 统计卡片行 */
.stats-row {
  margin-bottom: 20px;
}

.stat-card {
  border-radius: 12px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}

.stat-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.stat-info {
  flex: 1;
}

.stat-title {
  color: #8c8c8c;
  font-size: 14px;
  margin-bottom: 8px;
}

.stat-value {
  font-size: 28px;
  font-weight: bold;
  color: #262626;
  line-height: 1.2;
}

.stat-subtitle {
  font-size: 12px;
  color: #bfbfbf;
  margin-top: 4px;
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 筛选卡片 */
.filter-card {
  margin-bottom: 20px;
  border-radius: 12px;
}

.filter-form {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
}

.filter-form .el-form-item {
  margin-bottom: 0;
}

/* 表格卡片 */
.table-card {
  border-radius: 12px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
}

.header-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
  font-size: 16px;
}

.header-tip {
  font-size: 12px;
  color: #999;
  font-weight: normal;
  margin-left: 12px;
}

.total-badge :deep(.el-badge__content) {
  background-color: #409eff;
}

/* 表格单元格样式 */
.employee-cell {
  display: flex;
  align-items: center;
  gap: 6px;
}

.app-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.time-cell {
  display: flex;
  align-items: center;
  gap: 6px;
}

.window-title {
  color: #333;
}

.browser-title {
  color: #666;
  font-size: 13px;
}

/* 分页 */
.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

/* 响应式 */
@media (max-width: 768px) {
  .filter-form {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }

  .filter-form .el-form-item {
    width: 100%;
  }

  .filter-form .el-form-item .el-select,
  .filter-form .el-form-item .el-date-editor,
  .filter-form .el-form-item .el-input {
    width: 100% !important;
  }

  .el-date-editor--daterange {
    width: 100% !important;
  }

  .stat-value {
    font-size: 20px;
  }

  .stat-icon {
    width: 44px;
    height: 44px;
  }

  .stat-icon .el-icon {
    font-size: 22px !important;
  }
}
</style>

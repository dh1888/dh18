<template>
  <div v-if="result" class="batch-result-panel">
    <el-alert
      v-if="result.truncated"
      type="warning"
      :closable="false"
      show-icon
      class="preview-alert"
    >
      数据量较大，各分类仅预览前 500 条。完整结果请导出（服务端已缓存，45 分钟内有效）。
    </el-alert>

    <el-row :gutter="12" class="stat-row">
      <el-col :span="4"><el-statistic title="会员数据" :value="result.summary.totalRows" /></el-col>
      <el-col v-if="needsUnclaimedFile" :span="4">
        <el-statistic title="未领名单" :value="result.summary.unclaimedFileRows" />
      </el-col>
      <el-col v-if="needsUnclaimedFile" :span="4">
        <el-statistic title="未领剔除" :value="result.summary.unclaimedMatchedCount" />
      </el-col>
      <el-col :span="4"><el-statistic title="彩金派发" :value="result.summary.bonusCount" /></el-col>
      <el-col :span="4"><el-statistic title="用户盈利" :value="result.summary.otherCount" /></el-col>
      <el-col :span="4"><el-statistic title="已剔除" :value="result.summary.excludedCount" /></el-col>
      <el-col :span="4">
        <el-statistic title="总彩金">
          <template #default>{{ formatMoney(result.summary.totalBonus) }}</template>
        </el-statistic>
      </el-col>
    </el-row>

    <div class="export-bar">
      <el-button size="small" @click="$emit('export', 'dispatch_bonus')">导出彩金派发表</el-button>
      <el-button size="small" @click="$emit('export', 'other')">导出用户盈利</el-button>
      <el-button size="small" @click="$emit('export', 'excluded')">导出已剔除</el-button>
      <el-button v-if="needsUnclaimedFile" size="small" @click="$emit('export', 'unclaimed')">
        导出未领匹配
      </el-button>
      <el-button size="small" type="primary" @click="$emit('export', 'all')">导出全部</el-button>
    </div>

    <el-tabs :model-value="activeTab" @update:model-value="$emit('update:activeTab', $event)">
      <el-tab-pane :label="`彩金派发表 (${result.summary.bonusCount})`" name="dispatch_bonus">
        <manual-dispatch-table :rows="result.bonusRows" :config="result.bonusConfig" />
      </el-tab-pane>
      <el-tab-pane :label="`用户盈利 (${result.summary.otherCount})`" name="other">
        <manual-table
          :rows="result.otherRows"
          pay-label="订单充值"
          withdraw-label="订单提现"
        />
      </el-tab-pane>
      <el-tab-pane :label="`已剔除 (${result.summary.excludedCount})`" name="excluded">
        <manual-table
          :rows="result.excludedRows"
          show-reason
          show-tier
          pay-label="订单充值"
          withdraw-label="订单提现"
        />
      </el-tab-pane>
      <el-tab-pane
        v-if="needsUnclaimedFile"
        :label="`未领匹配 (${result.summary.unclaimedMatchedCount})`"
        name="unclaimed"
      >
        <manual-table
          :rows="result.unclaimedRewardRows"
          show-tier
          pay-label="订单充值"
          withdraw-label="订单提现"
        />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup lang="ts">
import type { ManualProcessResult } from "@api/callback_api";
import ManualDispatchTable from "./ManualDispatchTable.vue";
import ManualTable from "./ManualTable.vue";
import { formatMoney } from "./helpers";

defineProps<{
  result: ManualProcessResult | null;
  needsUnclaimedFile: boolean;
  activeTab: string;
}>();

defineEmits<{
  export: [exportType: string];
  "update:activeTab": [value: string];
}>();
</script>

<style scoped>
.preview-alert {
  margin-bottom: 16px;
}
.stat-row {
  margin-bottom: 16px;
}
.export-bar {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-bottom: 16px;
}
</style>

<template>
  <div class="callback-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
    </div>

    <el-card shadow="hover" class="main-card">
      <!-- ===== 卡片头部美化 ===== -->
      <template #header>
        <div class="card-header-custom">
          <div class="header-title">
            <span class="title-icon">
              <el-icon><Present /></el-icon>
            </span>
            <span class="title-text">{{ pageTitle }}</span>
            <el-tag size="small" type="info" effect="plain" class="title-tag">
              {{ isCallback ? '回访彩金' : '时段彩金' }}
            </el-tag>
          </div>
          <div class="header-actions">
            <el-button
              v-if="ws.result"
              size="small"
              type="success"
              plain
              @click="ws.result = null; saveManualWorkspace(dispatchType)"
            >
              <el-icon><RefreshRight /></el-icon>
              清空结果
            </el-button>
          </div>
        </div>
      </template>

      <!-- ===== 彩金规则 ===== -->
      <el-form label-width="100px" class="form-row">
        <el-form-item v-if="bonusConfigText" label="彩金规则">
          <div class="rule-display">
            <el-icon class="rule-icon"><Tickets /></el-icon>
            <span class="config-text">{{ bonusConfigText }}</span>
            <el-button link type="primary" class="rule-link" @click="$router.push('/callback/activity')">
              活动配置
              <el-icon><ArrowRight /></el-icon>
            </el-button>
          </div>
        </el-form-item>
      </el-form>

      <!-- ===== 上传区域 ===== -->
      <el-row :gutter="20" class="upload-row">
        <!-- 会员数据 -->
        <el-col :span="needsUnclaimedFile ? 12 : 24">
          <el-card shadow="never" class="upload-card" :class="{ 'upload-card-full': !needsUnclaimedFile }">
            <template #header>
              <div class="upload-card-header">
                <div class="header-left">
                  <span class="card-icon"><User /></span>
                  <span class="card-title-text">会员数据</span>
                  <el-tag size="small" type="primary" effect="plain" v-if="memberFile">已上传</el-tag>
                </div>
                <el-button link type="primary" size="small" @click="downloadTemplate('member')">
                  <el-icon><Download /></el-icon>
                  下载模板
                </el-button>
              </div>
            </template>

            <!-- 拖拽上传区域 -->
            <el-upload
              ref="memberUploadRef"
              :auto-upload="false"
              :limit="1"
              :accept="SPREADSHEET_ACCEPT"
              :show-file-list="true"
              :on-change="onMemberFileChange"
              :on-remove="onMemberFileRemove"
              :on-exceed="onMemberFileExceed"
              drag
              class="upload-drag"
            >
              <el-icon class="upload-icon"><UploadFilled /></el-icon>
              <div class="upload-text">
                拖拽文件至此，或 <em>点击选择</em>
              </div>
              <template #tip>
                <div class="upload-tip">支持 .xlsx, .xls, .csv</div>
              </template>
            </el-upload>

            <div v-if="memberFile || ws.memberFileName" class="file-name">
              <el-icon><Document /></el-icon>
              {{ memberFile?.name || ws.memberFileName }}
            </div>

            <div v-if="memberFile" class="mapping-tip">
              <el-icon><InfoFilled /></el-icon>
              上传后可预览表头并调整列映射；默认
              {{
                isCallback
                  ? "F会员ID / I累计充值 / J累计提款 / X手机号 / Y层级"
                  : "A会员ID / F订单充值 / H订单提现 / R手机号 / V层级"
              }}
            </div>

            <column-mapping-form
              title="会员数据列映射"
              v-model="memberMappingFields"
              v-model:header-row="ws.memberMapping.headerRow"
              v-model:multi-select-value="memberExcludedTiers"
              :columns="ws.memberColumns"
              :fields="memberMappingFieldDefs"
              :multi-select-field="tierMultiSelect"
              :show-preview-header="!!memberFile"
              :preview-loading="memberPreviewLoading"
              :show-scan-tiers="!!memberFile && ws.memberMapping.tierLevel >= 0"
              :scan-tiers-loading="tierScanLoading"
              :show-sync-from-activity="!!activityFilteredTiers().length"
              :default-hint="defaultMemberMappingLabel(dispatchType)"
              @reset-default="resetMemberMapping"
              @preview-header="previewMemberHeaders"
              @scan-tiers="scanTierOptionsFromFile"
              @sync-from-activity="syncExcludedTiersFromActivity"
              @header-row-change="onMemberHeaderRowChange"
            />
          </el-card>
        </el-col>

        <!-- 未领彩金名单 -->
        <el-col v-if="needsUnclaimedFile" :span="12">
          <el-card shadow="never" class="upload-card">
            <template #header>
              <div class="upload-card-header">
                <div class="header-left">
                  <span class="card-icon"><Files /></span>
                  <span class="card-title-text">未领彩金名单</span>
                  <el-tag size="small" type="warning" effect="plain" v-if="unclaimedFile">已上传</el-tag>
                </div>
                <el-button link type="primary" size="small" @click="downloadTemplate('unclaimed')">
                  <el-icon><Download /></el-icon>
                  下载模板
                </el-button>
              </div>
            </template>

            <el-upload
              ref="unclaimedUploadRef"
              :auto-upload="false"
              :limit="1"
              :accept="SPREADSHEET_ACCEPT"
              :show-file-list="true"
              :on-change="onUnclaimedFileChange"
              :on-remove="onUnclaimedFileRemove"
              :on-exceed="onUnclaimedFileExceed"
              drag
              class="upload-drag"
            >
              <el-icon class="upload-icon"><UploadFilled /></el-icon>
              <div class="upload-text">
                拖拽文件至此，或 <em>点击选择</em>
              </div>
              <template #tip>
                <div class="upload-tip">支持 .xlsx, .xls, .csv</div>
              </template>
            </el-upload>

            <div v-if="unclaimedFile || ws.unclaimedFileName" class="file-name">
              <el-icon><Document /></el-icon>
              {{ unclaimedFile?.name || ws.unclaimedFileName }}
            </div>

            <column-mapping-form
              title="未领名单列映射"
              v-model="unclaimedMappingFields"
              v-model:header-row="ws.unclaimedMapping.headerRow"
              :columns="ws.unclaimedColumns"
              :fields="unclaimedMappingFieldDefs"
              :show-preview-header="!!unclaimedFile"
              :preview-loading="unclaimedPreviewLoading"
              :default-hint="defaultUnclaimedMappingLabel()"
              @reset-default="resetUnclaimedMapping"
              @preview-header="previewUnclaimedHeaders"
              @header-row-change="onUnclaimedHeaderRowChange"
            />
          </el-card>
        </el-col>
      </el-row>

      <!-- ===== 操作按钮 ===== -->
      <div class="action-bar">
        <el-button
          type="success"
          size="large"
          :loading="processing"
          :disabled="!canProcess"
          @click="handleProcess"
          class="process-btn"
        >
          <el-icon v-if="!processing"><Coin /></el-icon>
          <span>{{ processing ? '计算中...' : '计算彩金' }}</span>
        </el-button>
        <span v-if="!canProcess && !processing" class="action-hint">
          <el-icon><Warning /></el-icon>
          {{ !memberFile ? '请上传会员数据' : needsUnclaimedFile && !unclaimedFile ? '请上传未领名单' : '请检查列映射配置' }}
        </span>
      </div>

      <!-- ===== 结果展示 ===== -->
      <template v-if="ws.result">
        <el-divider>
          <el-icon><Trophy /></el-icon>
          计算结果
        </el-divider>

        <el-alert
          v-if="ws.result.truncated"
          type="warning"
          :closable="false"
          show-icon
          class="preview-alert"
        >
          数据量较大，各分类页面仅预览前 500 条。完整结果请使用导出（服务端已缓存，45 分钟内有效）。
        </el-alert>

        <!-- 统计卡片行 -->
        <el-row :gutter="12" class="stat-row">
          <el-col :span="4">
            <div class="stat-card-mini">
              <div class="stat-label">会员数据</div>
              <div class="stat-number">{{ ws.result.summary.totalRows }}</div>
            </div>
          </el-col>
          <el-col v-if="needsUnclaimedFile" :span="4">
            <div class="stat-card-mini">
              <div class="stat-label">未领名单</div>
              <div class="stat-number">{{ ws.result.summary.unclaimedFileRows }}</div>
            </div>
          </el-col>
          <el-col v-if="needsUnclaimedFile" :span="4">
            <div class="stat-card-mini">
              <div class="stat-label">未领剔除</div>
              <div class="stat-number">{{ ws.result.summary.unclaimedMatchedCount }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-card-mini stat-highlight">
              <div class="stat-label">{{ dispatchStatTitle }}</div>
              <div class="stat-number">{{ ws.result.summary.bonusCount }}</div>
            </div>
          </el-col>
          <el-col v-if="isCallback" :span="4">
            <div class="stat-card-mini">
              <div class="stat-label">亏损派发表</div>
              <div class="stat-number">{{ ws.result.summary.otherCount }}</div>
            </div>
          </el-col>
          <el-col v-if="!isCallback" :span="4">
            <div class="stat-card-mini">
              <div class="stat-label">用户盈利</div>
              <div class="stat-number">{{ ws.result.summary.otherCount }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-card-mini">
              <div class="stat-label">已剔除</div>
              <div class="stat-number">{{ ws.result.summary.excludedCount }}</div>
            </div>
          </el-col>
          <el-col :span="4">
            <div class="stat-card-mini stat-total">
              <div class="stat-label">总彩金</div>
              <div class="stat-number total-money">¥{{ formatMoney(ws.result.summary.totalBonus) }}</div>
            </div>
          </el-col>
        </el-row>

        <!-- 导出按钮 -->
        <div class="export-bar">
          <span class="export-label"><el-icon><Download /></el-icon> 导出：</span>
          <template v-if="isCallback">
            <el-button size="small" type="primary" plain @click="exportResult('dispatch_bonus')">盈利派发表</el-button>
            <el-button size="small" type="success" plain @click="exportResult('bonus')">盈利回访</el-button>
            <el-button size="small" type="warning" plain @click="exportResult('dispatch_other')">亏损派发表</el-button>
            <el-button size="small" type="danger" plain @click="exportResult('other')">亏损回访</el-button>
          </template>
          <template v-else>
            <el-button size="small" type="primary" plain @click="exportResult('dispatch_bonus')">彩金派发表</el-button>
            <el-button size="small" type="success" plain @click="exportResult('other')">用户盈利</el-button>
          </template>
          <el-button size="small" type="info" plain @click="exportResult('excluded')">已剔除</el-button>
          <el-button v-if="needsUnclaimedFile" size="small" type="warning" plain @click="exportResult('unclaimed')">
            未领匹配
          </el-button>
          <el-button size="small" type="primary" @click="exportResult('all')">导出全部</el-button>
        </div>

        <!-- 选项卡 -->
        <el-tabs v-model="ws.activeTab" class="result-tabs">
          <template v-if="isCallback">
            <el-tab-pane
              :label="`盈利派发表 (${ws.result.summary.bonusCount})`"
              name="dispatch_bonus"
            >
              <div class="tab-toolbar">
                <el-button size="small" type="primary" plain @click="exportResult('dispatch_bonus')">
                  <el-icon><Download /></el-icon>
                  导出盈利派发表
                </el-button>
              </div>
              <manual-dispatch-table :rows="ws.result.bonusRows" :config="ws.result.bonusConfig" />
            </el-tab-pane>

            <el-tab-pane
              :label="`盈利回访 (${ws.result.summary.bonusCount})`"
              name="bonus"
            >
              <div class="tab-toolbar">
                <el-button size="small" type="success" plain @click="exportResult('bonus')">
                  <el-icon><Download /></el-icon>
                  导出盈利回访
                </el-button>
              </div>
              <manual-table
                :rows="ws.result.bonusRows"
                show-bonus
                :pay-label="detailPayLabel"
                :withdraw-label="detailWithdrawLabel"
              />
            </el-tab-pane>

            <el-tab-pane
              :label="`亏损派发表 (${ws.result.summary.otherCount})`"
              name="dispatch_other"
            >
              <div class="tab-toolbar">
                <el-button size="small" type="warning" plain @click="exportResult('dispatch_other')">
                  <el-icon><Download /></el-icon>
                  导出亏损派发表
                </el-button>
              </div>
              <manual-dispatch-table :rows="ws.result.otherRows" :config="ws.result.bonusConfig" />
            </el-tab-pane>

            <el-tab-pane
              :label="`亏损回访 (${ws.result.summary.otherCount})`"
              name="other"
            >
              <div class="tab-toolbar">
                <el-button size="small" type="danger" plain @click="exportResult('other')">
                  <el-icon><Download /></el-icon>
                  导出亏损回访
                </el-button>
              </div>
              <manual-table
                :rows="ws.result.otherRows"
                show-bonus
                :pay-label="detailPayLabel"
                :withdraw-label="detailWithdrawLabel"
              />
            </el-tab-pane>
          </template>

          <template v-else>
            <el-tab-pane
              :label="`彩金派发表 (${ws.result.summary.bonusCount})`"
              name="dispatch_bonus"
            >
              <div class="tab-toolbar">
                <el-button size="small" type="primary" plain @click="exportResult('dispatch_bonus')">
                  <el-icon><Download /></el-icon>
                  导出彩金派发表
                </el-button>
              </div>
              <manual-dispatch-table :rows="ws.result.bonusRows" :config="ws.result.bonusConfig" />
            </el-tab-pane>

            <el-tab-pane
              :label="`用户盈利 (${ws.result.summary.otherCount})`"
              name="other"
            >
              <div class="tab-toolbar">
                <el-button size="small" type="success" plain @click="exportResult('other')">
                  <el-icon><Download /></el-icon>
                  导出用户盈利
                </el-button>
              </div>
              <manual-table
                :rows="ws.result.otherRows"
                :pay-label="detailPayLabel"
                :withdraw-label="detailWithdrawLabel"
              />
            </el-tab-pane>
          </template>

          <el-tab-pane
            :label="`已剔除 (${ws.result.summary.excludedCount})`"
            name="excluded"
          >
            <div class="tab-toolbar">
              <el-button size="small" type="info" plain @click="exportResult('excluded')">
                <el-icon><Download /></el-icon>
                导出已剔除
              </el-button>
            </div>
            <manual-table
              :rows="ws.result.excludedRows"
              show-reason
              show-tier
              :pay-label="detailPayLabel"
              :withdraw-label="detailWithdrawLabel"
            />
          </el-tab-pane>

          <el-tab-pane
            v-if="needsUnclaimedFile"
            :label="`未领匹配 (${ws.result.summary.unclaimedMatchedCount})`"
            name="unclaimed"
          >
            <div class="tab-toolbar">
              <el-button size="small" type="warning" plain @click="exportResult('unclaimed')">
                <el-icon><Download /></el-icon>
                导出未领匹配
              </el-button>
            </div>
            <manual-table
              :rows="ws.result.unclaimedRewardRows"
              show-tier
              :pay-label="detailPayLabel"
              :withdraw-label="detailWithdrawLabel"
            />
          </el-tab-pane>
        </el-tabs>
      </template>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import { ElMessage, genFileId } from "element-plus";
import {
  Upload,
  UploadFilled,
  Document,
  Download,
  InfoFilled,
  User,
  Files,
  Present,
  Tickets,
  ArrowRight,
  RefreshRight,
  Coin,
  Warning,
  Trophy,
} from "@element-plus/icons-vue";
import type { UploadFile, UploadInstance, UploadProps, UploadRawFile } from "element-plus";
import callbackApi, { type CallbackActivity, type ManualDispatchType } from "@api/callback_api";
import ManualTable from "./ManualTable.vue";
import ManualDispatchTable from "./ManualDispatchTable.vue";
import ColumnMappingForm from "./ColumnMappingForm.vue";
import {
  buildFallbackColumns,
  DEFAULT_FILTERED_TIERS,
  DEFAULT_UNCLAIMED_COLUMN_MAPPING,
  defaultMemberMappingForDispatch,
  defaultMemberMappingLabel,
  defaultUnclaimedMappingLabel,
  expandColumnsForMapping,
  mappingColumnCount,
  normalizeMemberMapping,
  previewLocalCSVColumns,
  SPREADSHEET_ACCEPT,
  suggestMemberMappingFromColumns,
  type ManualColumnPreview,
} from "./columnMapping";
import { downloadBlob, formatMoney } from "./helpers";
import {
  ensureActivityManualRules,
  isManualFilterEnabled,
  MANUAL_FILTER_TIER,
  MANUAL_FILTER_UNCLAIMED,
} from "./manualRules";
import {
  getManualWorkspace,
  getMemberFile,
  getUnclaimedFile,
  saveManualWorkspace,
  setMemberFile,
  setUnclaimedFile,
} from "./manualWorkspace";
import "./styles.css";

const props = defineProps<{
  dispatchType: ManualDispatchType;
  pageTitle: string;
}>();

const activity = ref<CallbackActivity | null>(null);
const processing = ref(false);
const memberPreviewLoading = ref(false);
const unclaimedPreviewLoading = ref(false);
const tierScanLoading = ref(false);
const memberUploadRef = ref<UploadInstance>();
const unclaimedUploadRef = ref<UploadInstance>();

const ws = computed(() => getManualWorkspace(props.dispatchType));
const memberFile = computed(() => getMemberFile(props.dispatchType));
const unclaimedFile = computed(() => getUnclaimedFile(props.dispatchType));
const isCallback = computed(() => props.dispatchType === "callback_bonus");

const needsUnclaimedFile = computed(() => {
  const a = activity.value;
  const rules = isCallback.value ? a?.callbackManualRules : a?.periodManualRules;
  return isManualFilterEnabled(rules, MANUAL_FILTER_UNCLAIMED, props.dispatchType);
});

const memberMappingFieldDefs = computed(() => [
  { key: "userId", label: "会员ID" },
  {
    key: "historicalPay",
    label: isCallback.value ? "累计充值" : "订单充值",
  },
  {
    key: "historyWithdrawals",
    label: isCallback.value ? "累计提款" : "订单提现",
  },
  { key: "phoneNumber", label: "手机号码" },
  { key: "tierLevel", label: "层级" },
]);
const unclaimedMappingFieldDefs = [{ key: "userId", label: "会员ID" }];

const memberMappingFields = computed({
  get: () => ({
    userId: ws.value.memberMapping.userId,
    historicalPay: ws.value.memberMapping.historicalPay,
    historyWithdrawals: ws.value.memberMapping.historyWithdrawals,
    phoneNumber: ws.value.memberMapping.phoneNumber,
    tierLevel: ws.value.memberMapping.tierLevel,
  }),
  set: (v: Record<string, number>) => {
    const m = ws.value.memberMapping;
    m.userId = v.userId;
    m.historicalPay = v.historicalPay;
    m.historyWithdrawals = v.historyWithdrawals;
    m.phoneNumber = v.phoneNumber;
    if (v.tierLevel != null) m.tierLevel = v.tierLevel;
    saveManualWorkspace(props.dispatchType);
  },
});

const unclaimedMappingFields = computed({
  get: () => ({ userId: ws.value.unclaimedMapping.userId }),
  set: (v: Record<string, number>) => {
    ws.value.unclaimedMapping.userId = v.userId;
    saveManualWorkspace(props.dispatchType);
  },
});

const memberExcludedTiers = computed({
  get: () => ws.value.memberMapping.excludedTiers ?? [],
  set: (v: string[]) => {
    ws.value.memberMapping.excludedTiers = v;
    saveManualWorkspace(props.dispatchType);
  },
});

const tierMultiSelect = computed(() => ({
  label: "过滤层级",
  placeholder: "多选需剔除的层级",
  options: ws.value.tierOptions,
}));

const bonusConfigText = computed(() => {
  const a = activity.value;
  if (!a) return "";
  if (isCallback.value) {
    const min = a.callbackMinBonus ?? a.minBonus ?? 0;
    const rate = a.callbackRate ?? 0.02;
    const divisor = a.callbackDivisor ?? 2;
    const wm = a.callbackWageringMultiplier ?? 1;
    return `盈利（充提差<0）送 ${min}；亏损 充提差×${rate}÷${divisor}（低于 ${min} 取 ${min}）· 打码 ${wm}`;
  }
  return `用户亏损/持平（充提差≥0）：充提差×${a.rate ?? 0.02}÷${a.divisor ?? 2}，低于 ${a.minBonus} 取 ${a.minBonus}，最高 ${a.maxBonus} · 打码 ${a.periodWageringMultiplier ?? 1}`;
});

const dispatchStatTitle = computed(() => (isCallback.value ? "盈利派发表" : "彩金派发"));
const detailPayLabel = computed(() => (isCallback.value ? "累计充值" : "订单充值"));
const detailWithdrawLabel = computed(() => (isCallback.value ? "累计提款" : "订单提现"));

const EXPORT_FILENAMES: Record<string, string> = {
  dispatch: "callback_manual_dispatch.xlsx",
  dispatch_all: "callback_manual_dispatch.xlsx",
  dispatch_bonus: "callback_manual_profit_dispatch.xlsx",
  dispatch_other: "callback_manual_loss_dispatch.xlsx",
  bonus: "callback_manual_profit_detail.xlsx",
  other: "callback_manual_loss_detail.xlsx",
  excluded: "callback_manual_excluded.xlsx",
  unclaimed: "callback_manual_unclaimed.xlsx",
  all: "callback_manual_all.xlsx",
};

const needsTierColumn = computed(() => {
  const a = activity.value;
  const rules = isCallback.value ? a?.callbackManualRules : a?.periodManualRules;
  return isManualFilterEnabled(rules, MANUAL_FILTER_TIER, props.dispatchType);
});

const canProcess = computed(() => {
  if (!memberFile.value) return false;
  if (needsUnclaimedFile.value && !unclaimedFile.value) return false;
  if (needsTierColumn.value && ws.value.memberMapping.tierLevel < 0) return false;
  return true;
});

function activityFilteredTiers(): string[] {
  const a = activity.value;
  if (!a) return [...DEFAULT_FILTERED_TIERS];
  const tiers = isCallback.value ? (a.callbackFilteredTiers ?? []) : (a.periodFilteredTiers ?? []);
  return tiers.length ? tiers : [...DEFAULT_FILTERED_TIERS];
}

function syncExcludedTiersFromActivity() {
  ws.value.memberMapping.excludedTiers = [...activityFilteredTiers()];
  saveManualWorkspace(props.dispatchType);
}

function applyDefaultMemberColumns() {
  ws.value.memberColumns = buildFallbackColumns(mappingColumnCount(props.dispatchType));
  saveManualWorkspace(props.dispatchType);
}

function applyDefaultUnclaimedColumns() {
  ws.value.unclaimedColumns = buildFallbackColumns(10);
  saveManualWorkspace(props.dispatchType);
}

function refreshTierOptionsFromActivity() {
  const w = ws.value;
  w.tierOptions = Array.from(new Set([...DEFAULT_FILTERED_TIERS, ...activityFilteredTiers()]));
  const current = w.memberMapping.excludedTiers ?? [];
  const kept = current.filter((t) => w.tierOptions.includes(t));
  w.memberMapping.excludedTiers = kept.length ? kept : [...activityFilteredTiers()];
  saveManualWorkspace(props.dispatchType);
}

async function scanTierOptionsFromFile() {
  const w = ws.value;
  const file = memberFile.value;
  if (!file || w.memberMapping.tierLevel < 0) {
    refreshTierOptionsFromActivity();
    return;
  }
  tierScanLoading.value = true;
  try {
    const { data } = await callbackApi.previewManualTierValues(
      file,
      w.memberMapping.headerRow,
      w.memberMapping.tierLevel,
    );
    w.tierOptions = Array.from(new Set([...DEFAULT_FILTERED_TIERS, ...activityFilteredTiers(), ...data]));
    const current = w.memberMapping.excludedTiers ?? [];
    w.memberMapping.excludedTiers = current.filter((t) => w.tierOptions.includes(t));
    saveManualWorkspace(props.dispatchType);
    ElMessage.success(`已扫描层级选项 ${data.length} 个`);
  } catch {
    refreshTierOptionsFromActivity();
    ElMessage.warning("层级扫描失败");
  } finally {
    tierScanLoading.value = false;
  }
}

function onMemberHeaderRowChange() {
  if (memberFile.value) {
    void previewMemberHeaders();
    return;
  }
  applyDefaultMemberColumns();
}

function onUnclaimedHeaderRowChange() {
  if (unclaimedFile.value) {
    void previewUnclaimedHeaders();
    return;
  }
  applyDefaultUnclaimedColumns();
}

function resetMemberMapping() {
  Object.assign(ws.value.memberMapping, defaultMemberMappingForDispatch(props.dispatchType));
  syncExcludedTiersFromActivity();
  if (memberFile.value) {
    void previewMemberHeaders();
  } else {
    applyDefaultMemberColumns();
  }
  refreshTierOptionsFromActivity();
}

function resetUnclaimedMapping() {
  Object.assign(ws.value.unclaimedMapping, { ...DEFAULT_UNCLAIMED_COLUMN_MAPPING, phoneNumber: -1 });
  applyDefaultUnclaimedColumns();
}

function applySuggestedMemberMapping(cols: ManualColumnPreview[]) {
  const suggested = suggestMemberMappingFromColumns(cols, props.dispatchType);
  if (!suggested) return;
  Object.assign(ws.value.memberMapping, suggested);
}

async function loadMemberColumnPreview(file: File): Promise<ManualColumnPreview[]> {
  const headerRow = ws.value.memberMapping.headerRow;
  const local = await previewLocalCSVColumns(file, headerRow);
  if (local?.length) {
    return expandColumnsForMapping(local, props.dispatchType);
  }
  const { data } = await callbackApi.previewManualColumns(file, headerRow);
  if (data.length) {
    return expandColumnsForMapping(data, props.dispatchType);
  }
  return buildFallbackColumns(mappingColumnCount(props.dispatchType));
}

async function previewMemberHeaders() {
  const file = memberFile.value;
  if (!file) return;
  memberPreviewLoading.value = true;
  try {
    const cols = await loadMemberColumnPreview(file);
    ws.value.memberColumns = cols;
    applySuggestedMemberMapping(cols);
    saveManualWorkspace(props.dispatchType);
    ElMessage.success("表头已加载，请确认列映射");
  } catch {
    applyDefaultMemberColumns();
    ElMessage.warning("表头预览失败");
  } finally {
    memberPreviewLoading.value = false;
  }
}

async function previewUnclaimedHeaders() {
  const file = unclaimedFile.value;
  if (!file) return;
  unclaimedPreviewLoading.value = true;
  try {
    const local = await previewLocalCSVColumns(file, ws.value.unclaimedMapping.headerRow);
    if (local?.length) {
      ws.value.unclaimedColumns = local;
      saveManualWorkspace(props.dispatchType);
      return;
    }
    const { data } = await callbackApi.previewManualColumns(file, ws.value.unclaimedMapping.headerRow);
    ws.value.unclaimedColumns = data.length ? data : buildFallbackColumns(10);
    saveManualWorkspace(props.dispatchType);
  } catch {
    applyDefaultUnclaimedColumns();
  } finally {
    unclaimedPreviewLoading.value = false;
  }
}

function replaceUploadFile(uploadRef: UploadInstance | undefined, file: UploadRawFile) {
  uploadRef?.clearFiles();
  file.uid = genFileId();
  uploadRef?.handleStart(file);
}

const onMemberFileExceed: UploadProps["onExceed"] = (files) => {
  replaceUploadFile(memberUploadRef.value, files[0] as UploadRawFile);
};

const onUnclaimedFileExceed: UploadProps["onExceed"] = (files) => {
  replaceUploadFile(unclaimedUploadRef.value, files[0] as UploadRawFile);
};

function onMemberFileChange(file: UploadFile) {
  if (file.status !== "ready" || !file.raw) return;
  setMemberFile(props.dispatchType, file.raw);
  ws.value.result = null;
  refreshTierOptionsFromActivity();
  void autoPreviewMemberHeaders(file.raw);
}

async function autoPreviewMemberHeaders(file: File | null) {
  if (!file) return;
  memberPreviewLoading.value = true;
  try {
    const cols = await loadMemberColumnPreview(file);
    ws.value.memberColumns = cols;
    applySuggestedMemberMapping(cols);
    saveManualWorkspace(props.dispatchType);
  } catch {
    applyDefaultMemberColumns();
  } finally {
    memberPreviewLoading.value = false;
  }
}

function onMemberFileRemove() {
  setMemberFile(props.dispatchType, null);
  ws.value.result = null;
  applyDefaultMemberColumns();
}

function onUnclaimedFileChange(file: UploadFile) {
  if (file.status !== "ready" || !file.raw) return;
  setUnclaimedFile(props.dispatchType, file.raw);
  ws.value.result = null;
  void previewUnclaimedHeaders();
}

function onUnclaimedFileRemove() {
  setUnclaimedFile(props.dispatchType, null);
  ws.value.result = null;
  applyDefaultUnclaimedColumns();
}

async function downloadTemplate(type: "member" | "unclaimed") {
  try {
    const res = await callbackApi.downloadManualTemplate(type);
    const name =
      type === "unclaimed" ? "callback_unclaimed_template.xlsx" : "callback_member_template.xlsx";
    downloadBlob(res.data as Blob, name);
  } catch (e: any) {
    ElMessage.error(e.message || "下载失败");
  }
}

async function handleProcess() {
  const w = ws.value;
  const file = memberFile.value;
  if (!canProcess.value || !file) {
    ElMessage.warning(
      needsUnclaimedFile.value ? "请上传会员数据和未领名单" : "请上传会员数据",
    );
    return;
  }
  processing.value = true;
  try {
    const { data } = await callbackApi.processManualImport({
      dispatchType: props.dispatchType,
      memberFile: file,
      unclaimedFile: unclaimedFile.value ?? undefined,
      memberMapping: normalizeMemberMapping(w.memberMapping, props.dispatchType),
      unclaimedMapping: { ...w.unclaimedMapping },
    });
    w.result = data;
    w.activeTab = "dispatch_bonus";
    saveManualWorkspace(props.dispatchType);
    if (isCallback.value) {
      ElMessage.success(
        `完成：盈利 ${data.summary.bonusCount}，亏损 ${data.summary.otherCount}，总彩金 ${formatMoney(data.summary.totalBonus)}`,
      );
    } else {
      ElMessage.success(
        `完成：亏损派发 ${data.summary.bonusCount} 人，总彩金 ${formatMoney(data.summary.totalBonus)}`,
      );
    }
  } catch (e: any) {
    ElMessage.error(e.message || "处理失败");
  } finally {
    processing.value = false;
  }
}

async function exportResult(exportType: string) {
  if (!ws.value.result) return;
  try {
    const res = await callbackApi.exportManualResult(exportType, ws.value.result);
    const filename = EXPORT_FILENAMES[exportType] ?? `callback_manual_${exportType}.xlsx`;
    downloadBlob(res.data as Blob, filename);
  } catch (e: any) {
    ElMessage.error(e.message || "导出失败");
  }
}

onMounted(async () => {
  try {
    const { data } = await callbackApi.getActivity();
    if (data) {
      ensureActivityManualRules(data);
      activity.value = data;
    }
  } catch {
    /* ignore */
  }
  refreshTierOptionsFromActivity();
});

watch(
  () => ws.value.activeTab,
  () => saveManualWorkspace(props.dispatchType),
);
</script>

<style scoped>
/* ========== 卡片头部 ========== */
.card-header-custom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.header-title {
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.title-text {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}

.title-tag {
  margin-left: 8px;
}

/* ========== 彩金规则 ========== */
.form-row {
  margin-bottom: 16px;
  max-width: 100%;
}

.rule-display {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px 16px;
  padding: 12px 16px;
  background: linear-gradient(135deg, #f8f9fc 0%, #f0f2f6 100%);
  border-radius: 10px;
  border: 1px solid #e8ecf1;
  width: 100%;
}

.rule-icon {
  color: #667eea;
  font-size: 18px;
}

.config-text {
  color: var(--el-text-color-regular);
  font-size: 14px;
  flex: 1;
}

.rule-link {
  font-size: 13px;
  white-space: nowrap;
}

/* ========== 上传卡片 ========== */
.upload-row {
  margin-bottom: 16px;
}

.upload-card {
  border-radius: 12px;
  border: 1px solid #e8ecf1;
  transition: all 0.3s ease;
  height: 100%;
}

.upload-card:hover {
  border-color: #c0c4cc;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
}

.upload-card-full :deep(.el-card__body) {
  padding-bottom: 8px;
}

.upload-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.card-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: white;
}

.upload-card:nth-child(1) .card-icon {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.upload-card:nth-child(2) .card-icon {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.card-title-text {
  font-weight: 600;
  font-size: 15px;
  color: #303133;
}

/* ========== 拖拽上传 ========== */
.upload-drag :deep(.el-upload-dragger) {
  border: 2px dashed #d9d9d9;
  border-radius: 10px;
  padding: 28px 20px;
  transition: all 0.3s ease;
  background: #fafbfc;
}

.upload-drag :deep(.el-upload-dragger:hover) {
  border-color: #667eea;
  background: #f5f7ff;
}

.upload-drag :deep(.el-upload-dragger.is-dragover) {
  border-color: #667eea;
  background: #f0f3ff;
}

.upload-icon {
  font-size: 40px;
  color: #c0c4cc;
  margin-bottom: 8px;
}

.upload-text {
  font-size: 14px;
  color: #606266;
}

.upload-text em {
  color: #667eea;
  font-style: normal;
  font-weight: 500;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 6px;
}

.file-name {
  margin-top: 10px;
  padding: 8px 12px;
  background: #f5f7fa;
  border-radius: 6px;
  font-size: 13px;
  color: var(--el-text-color-secondary);
  display: flex;
  align-items: center;
  gap: 6px;
}

.mapping-tip {
  margin-top: 8px;
  padding: 8px 12px;
  background: #f0f7ff;
  border-radius: 6px;
  font-size: 12px;
  color: #409eff;
  display: flex;
  align-items: flex-start;
  gap: 6px;
  line-height: 1.5;
}

.mapping-tip .el-icon {
  margin-top: 2px;
  flex-shrink: 0;
}

/* ========== 操作按钮 ========== */
.action-bar {
  display: flex;
  align-items: center;
  gap: 16px;
  margin: 8px 0 12px;
  padding: 16px 20px;
  background: linear-gradient(135deg, #f8f9fc 0%, #f0f2f6 100%);
  border-radius: 12px;
  border: 1px solid #e8ecf1;
}

.process-btn {
  padding: 12px 40px;
  border-radius: 10px;
  font-size: 16px;
  font-weight: 600;
  background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
  border: none;
  color: #1a1a2e;
  transition: all 0.3s ease;
}

.process-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(67, 233, 123, 0.4);
}

.process-btn:active:not(:disabled) {
  transform: translateY(0);
}

.process-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.action-hint {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  color: #e6a23c;
}

/* ========== 统计卡片 ========== */
.stat-row {
  margin-bottom: 16px;
}

.stat-card-mini {
  padding: 12px 16px;
  background: #f8f9fc;
  border-radius: 10px;
  text-align: center;
  border: 1px solid #e8ecf1;
  transition: all 0.2s ease;
}

.stat-card-mini:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
}

.stat-card-mini .stat-label {
  font-size: 12px;
  color: #909399;
  margin-bottom: 4px;
}

.stat-card-mini .stat-number {
  font-size: 22px;
  font-weight: 700;
  color: #303133;
}

.stat-card-mini.stat-highlight {
  background: linear-gradient(135deg, #e6f7ff 0%, #bae7ff 100%);
  border-color: #91d5ff;
}

.stat-card-mini.stat-highlight .stat-number {
  color: #1890ff;
}

.stat-card-mini.stat-total {
  background: linear-gradient(135deg, #f6ffed 0%, #d9f7be 100%);
  border-color: #b7eb8f;
}

.stat-card-mini.stat-total .stat-number.total-money {
  color: #52c41a;
  font-size: 20px;
}

/* ========== 导出栏 ========== */
.export-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  margin-bottom: 16px;
  padding: 12px 16px;
  background: #f8f9fc;
  border-radius: 10px;
  border: 1px solid #e8ecf1;
}

.export-label {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  color: #606266;
  font-weight: 500;
  margin-right: 4px;
}

/* ========== 选项卡 ========== */
.result-tabs :deep(.el-tabs__item) {
  font-weight: 500;
}

.result-tabs :deep(.el-tabs__item.is-active) {
  color: #667eea;
}

.result-tabs :deep(.el-tabs__active-bar) {
  background: linear-gradient(90deg, #667eea, #764ba2);
}

.tab-toolbar {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-bottom: 12px;
  padding: 8px 12px;
  background: #f8f9fc;
  border-radius: 8px;
}

.preview-alert {
  margin-bottom: 16px;
}

/* ========== 分割线 ========== */
.el-divider {
  margin: 24px 0 20px;
}

.el-divider .el-icon {
  margin-right: 8px;
  color: #667eea;
}

/* ========== 响应式 ========== */
@media (max-width: 768px) {
  .card-header-custom {
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }

  .header-title {
    flex-wrap: wrap;
  }

  .title-text {
    font-size: 16px;
  }

  .stat-card-mini .stat-number {
    font-size: 18px;
  }

  .stat-card-mini.stat-total .stat-number.total-money {
    font-size: 17px;
  }

  .rule-display {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }

  .action-bar {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }

  .process-btn {
    width: 100%;
    justify-content: center;
  }

  .export-bar {
    flex-direction: column;
    align-items: stretch;
  }

  .export-label {
    margin-bottom: 4px;
  }

  .upload-card-header {
    flex-wrap: wrap;
    gap: 8px;
  }

  .tab-toolbar {
    flex-direction: column;
  }
}

@media (max-width: 480px) {
  .stat-row .el-col {
    flex: 0 0 50%;
    max-width: 50%;
    margin-bottom: 8px;
  }

  .stat-card-mini {
    padding: 8px 12px;
  }

  .stat-card-mini .stat-number {
    font-size: 16px;
  }

  .stat-card-mini.stat-total .stat-number.total-money {
    font-size: 15px;
  }
}
</style>
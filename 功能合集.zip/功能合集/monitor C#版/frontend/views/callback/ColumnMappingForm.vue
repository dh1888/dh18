<template>
  <el-card shadow="never" class="mapping-card">
    <template #header>
      <div class="mapping-header">
        <span>{{ title }}</span>
        <el-button link type="primary" @click="$emit('reset-default')">恢复默认</el-button>
        <el-button v-if="showPreviewHeader" link type="primary" :loading="previewLoading" @click="$emit('preview-header')">
          预览表头
        </el-button>
        <el-button v-if="showScanTiers" link type="primary" :loading="scanTiersLoading" @click="$emit('scan-tiers')">
          扫描层级
        </el-button>
        <el-button v-if="showSyncFromActivity" link type="primary" @click="$emit('sync-from-activity')">
          从活动配置同步
        </el-button>
      </div>
    </template>
    <div class="mapping-row">
      <div class="mapping-item">
        <span class="field-label">表头行</span>
        <el-input-number
          :model-value="headerRow + 1"
          :min="1"
          :max="20"
          size="small"
          controls-position="right"
          @update:model-value="onHeaderRowChange"
        />
      </div>
      <div v-for="field in fields" :key="field.key" class="mapping-item">
        <span class="field-label">{{ field.label }}</span>
        <el-select
          :model-value="columnSelectValue(field.key)"
          filterable
          size="small"
          class="field-select"
          @update:model-value="(v: string) => updateField(field.key, v)"
        >
          <el-option
            v-for="col in columns"
            :key="col.index"
            :label="columnOptionLabel(col)"
            :value="String(col.index)"
          />
        </el-select>
      </div>
      <div v-if="multiSelectField" class="mapping-item mapping-item-wide">
        <span class="field-label">{{ multiSelectField.label }}</span>
        <el-select
          :model-value="multiSelectValue"
          multiple
          filterable
          collapse-tags
          collapse-tags-tooltip
          size="small"
          class="field-select-wide"
          :placeholder="multiSelectField.placeholder"
          @update:model-value="onMultiSelectChange"
        >
          <el-option v-for="opt in multiSelectField.options" :key="opt" :label="opt" :value="opt" />
        </el-select>
      </div>
    </div>
    <div v-if="defaultHint" class="default-hint">默认：{{ defaultHint }}</div>
  </el-card>
</template>

<script setup lang="ts">
import { columnOptionLabel, type ManualColumnPreview } from "./columnMapping";

const props = defineProps<{
  title: string;
  modelValue: Record<string, number>;
  headerRow: number;
  columns: ManualColumnPreview[];
  fields: { key: string; label: string }[];
  defaultHint?: string;
  showPreviewHeader?: boolean;
  previewLoading?: boolean;
  showScanTiers?: boolean;
  scanTiersLoading?: boolean;
  showSyncFromActivity?: boolean;
  multiSelectField?: {
    label: string;
    placeholder?: string;
    options: string[];
  };
  multiSelectValue?: string[];
}>();

const emit = defineEmits<{
  "update:modelValue": [value: Record<string, number>];
  "update:headerRow": [value: number];
  "update:multiSelectValue": [value: string[]];
  "reset-default": [];
  "preview-header": [];
  "scan-tiers": [];
  "sync-from-activity": [];
  "header-row-change": [value: number];
  "field-change": [key: string, value: number];
}>();

function columnSelectValue(key: string): string {
  const v = props.modelValue[key];
  if (v === undefined || v === null || v < 0) return "";
  return String(v);
}

function updateField(key: string, value: string) {
  const index = Number.parseInt(value, 10);
  if (Number.isNaN(index) || index < 0) return;
  emit("update:modelValue", { ...props.modelValue, [key]: index });
  emit("field-change", key, index);
}

function onMultiSelectChange(v: string[]) {
  emit("update:multiSelectValue", v);
}

function onHeaderRowChange(v: number | undefined) {
  const row = Math.max(0, (v ?? 1) - 1);
  emit("update:headerRow", row);
  emit("header-row-change", row);
}
</script>

<style scoped>
.mapping-card {
  margin-top: 12px;
}
.mapping-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.mapping-row {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  gap: 12px 16px;
}
.mapping-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 120px;
}
.mapping-item-wide {
  min-width: 220px;
  flex: 1;
}
.field-label {
  font-size: 12px;
  color: var(--el-text-color-secondary);
  white-space: nowrap;
}
.field-select {
  width: 140px;
}
.field-select-wide {
  width: 100%;
  min-width: 200px;
  max-width: 360px;
}
.default-hint {
  font-size: 12px;
  color: var(--el-text-color-secondary);
  margin-top: 8px;
}
</style>

<template>
  <div class="callback-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
    </div>
    <el-card shadow="hover" class="main-card">
      <template #header>
        <div class="card-head">
          <span>接口配置</span>
          <span class="head-actions">
            <el-button type="success" @click="importVisible = true">从网络提取</el-button>
            <el-button type="primary" @click="openDialog()">新增接口</el-button>
          </span>
        </div>
      </template>

      <div class="toolbar">
        <el-select
          v-model="filterPlatformId"
          placeholder="全部平台"
          clearable
          filterable
          style="width: 220px"
          @change="load"
        >
          <el-option label="全局模板" value="__global__" />
          <el-option v-for="p in platforms" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-input
          v-model="filterCode"
          placeholder="接口编码"
          clearable
          style="width: 160px"
          @keyup.enter="load"
        />
        <el-button @click="load" :loading="loading">查询</el-button>
      </div>

      <el-table :data="endpoints" v-loading="loading" stripe>
        <el-table-column prop="code" label="编码" width="140" />
        <el-table-column prop="name" label="名称" width="140" />
        <el-table-column prop="path" label="路径" show-overflow-tooltip />
        <el-table-column prop="httpMethod" label="方法" width="80" />
        <el-table-column label="平台" width="120">
          <template #default="{ row }">{{ row.platformId || "全局" }}</template>
        </el-table-column>
        <el-table-column label="启用" width="80">
          <template #default="{ row }">
            <el-tag size="small" :type="row.enabled ? 'success' : 'info'">
              {{ row.enabled ? "是" : "否" }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="140" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openDialog(row)">编辑</el-button>
            <el-button link type="danger" @click="remove(row.id!)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog
      v-model="dialogVisible"
      :title="form.id ? '编辑接口' : '新增接口'"
      width="680px"
    >
      <el-form :model="form" label-width="120px">
        <el-form-item label="编码" required>
          <el-input v-model="form.code" placeholder="vip.list" />
        </el-form-item>
        <el-form-item label="名称" required>
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="路径" required>
          <el-input v-model="form.path" />
        </el-form-item>
        <el-form-item label="HTTP 方法">
          <el-select v-model="form.httpMethod" style="width: 120px">
            <el-option label="GET" value="GET" />
            <el-option label="POST" value="POST" />
          </el-select>
        </el-form-item>
        <el-form-item label="平台 ID">
          <el-select v-model="form.platformId" clearable filterable placeholder="留空=全局">
            <el-option v-for="p in platforms" :key="p.id" :label="p.name" :value="p.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="请求参数模板">
          <el-input v-model="form.requestParamsTemplate" type="textarea" :rows="4" />
        </el-form-item>
        <el-form-item label="响应映射">
          <el-input v-model="form.responseMapping" type="textarea" :rows="5" />
        </el-form-item>
        <el-form-item label="分页配置">
          <el-input v-model="form.paginationConfig" type="textarea" :rows="4" />
        </el-form-item>
        <el-form-item label="启用">
          <el-switch v-model="form.enabled" />
        </el-form-item>
        <el-form-item label="排序">
          <el-input-number v-model="form.sortOrder" :min="0" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>

    <NetworkImportDialog
      v-model="importVisible"
      mode="endpoint"
      @apply-endpoint="applyNetworkEndpoint"
    />
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import callbackApi, { type CallbackAPIEndpoint } from "@api/callback_api";
import NetworkImportDialog, {
  type EndpointImportPayload,
} from "./NetworkImportDialog.vue";
import { useCallbackPlatforms } from "./useCallbackPlatforms";
import "./styles.css";

const { platforms, loadAll } = useCallbackPlatforms();

const endpoints = ref<CallbackAPIEndpoint[]>([]);
const loading = ref(false);
const filterPlatformId = ref("");
const filterCode = ref("");

const dialogVisible = ref(false);
const importVisible = ref(false);
const saving = ref(false);

const form = reactive<CallbackAPIEndpoint>({
  code: "",
  name: "",
  path: "",
  httpMethod: "GET",
  platformId: "",
  requestParamsTemplate: "{}",
  responseMapping: "{}",
  paginationConfig: "{}",
  enabled: true,
  sortOrder: 0,
  remark: "",
});

async function load() {
  loading.value = true;
  try {
    const params: { platformId?: string; code?: string } = {
      code: filterCode.value || undefined,
    };
    if (filterPlatformId.value && filterPlatformId.value !== "__global__") {
      params.platformId = filterPlatformId.value;
    }
    const { data } = await callbackApi.listEndpoints(params);
    endpoints.value = (data || []).filter((e) => {
      if (filterPlatformId.value === "__global__") return !e.platformId;
      return true;
    });
  } catch (e: any) {
    ElMessage.error(e.message || "加载失败");
  } finally {
    loading.value = false;
  }
}

function openDialog(row?: CallbackAPIEndpoint) {
  form.id = row?.id;
  form.code = row?.code || "";
  form.name = row?.name || "";
  form.path = row?.path || "";
  form.httpMethod = row?.httpMethod || "GET";
  form.platformId = (row?.platformId as string) || "";
  form.requestParamsTemplate = row?.requestParamsTemplate || "{}";
  form.responseMapping = row?.responseMapping || "{}";
  form.paginationConfig = row?.paginationConfig || "{}";
  form.enabled = row?.enabled ?? true;
  form.sortOrder = row?.sortOrder ?? 0;
  form.remark = row?.remark || "";
  dialogVisible.value = true;
}

function applyNetworkEndpoint(payload: EndpointImportPayload) {
  form.code = payload.code;
  form.name = payload.name;
  form.path = payload.path;
  form.httpMethod = payload.httpMethod;
  form.requestParamsTemplate = payload.requestParamsTemplate;
  form.responseMapping = payload.responseMapping;
  form.paginationConfig = payload.paginationConfig;
  dialogVisible.value = true;
  ElMessage.success("已从网络请求填入接口配置");
}

async function save() {
  saving.value = true;
  try {
    const payload: CallbackAPIEndpoint = {
      ...form,
      platformId: form.platformId?.trim() || null,
    };
    if (form.id) {
      await callbackApi.updateEndpoint(form.id, payload);
    } else {
      await callbackApi.createEndpoint(payload);
    }
    dialogVisible.value = false;
    ElMessage.success("保存成功");
    load();
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    saving.value = false;
  }
}

async function remove(id: string) {
  await ElMessageBox.confirm("确定删除？", "提示", { type: "warning" });
  try {
    await callbackApi.deleteEndpoint(id);
    ElMessage.success("已删除");
    load();
  } catch (e: any) {
    ElMessage.error(e.message || "删除失败");
  }
}

onMounted(async () => {
  await loadAll();
  load();
});
</script>

<style scoped>
.card-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.head-actions {
  display: flex;
  gap: 8px;
}
</style>

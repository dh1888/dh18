export interface ManualMemberColumnMapping {
  userId: number;
  historicalPay: number;
  historyWithdrawals: number;
  phoneNumber: number;
  tierLevel: number;
  excludedTiers?: string[];
  headerRow: number;
}

export interface ManualUnclaimedColumnMapping {
  userId: number;
  phoneNumber: number;
  headerRow: number;
}

export interface ManualColumnPreview {
  index: number;
  letter: string;
  header: string;
}

export const DEFAULT_FILTERED_TIERS = ["新-无优惠", "洗水套利", "黑名单"];

/** 时段彩金默认层级列 V */
export const PERIOD_TIER_COLUMN = 21;

/** 回访彩金默认层级列 Y */
export const CALLBACK_TIER_COLUMN = 24;

export const CALLBACK_MAPPING_COLUMN_COUNT = 40;
export const PERIOD_MAPPING_COLUMN_COUNT = 30;

export const SPREADSHEET_ACCEPT =
  ".csv,.xlsx,.xls,.xlsm,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv";

export function defaultMemberMappingForDispatch(
  dispatchType: "period_bonus" | "callback_bonus",
): ManualMemberColumnMapping {
  if (dispatchType === "callback_bonus") {
    return {
      userId: 5, // F
      historicalPay: 8, // I 累计充值
      historyWithdrawals: 9, // J 累计提款
      phoneNumber: 23, // X
      tierLevel: CALLBACK_TIER_COLUMN,
      excludedTiers: [...DEFAULT_FILTERED_TIERS],
      headerRow: 0,
    };
  }
  return {
    userId: 0, // A
    historicalPay: 5, // F 订单充值
    historyWithdrawals: 7, // H 订单提现
    phoneNumber: 17, // R
    tierLevel: PERIOD_TIER_COLUMN, // V
    excludedTiers: [...DEFAULT_FILTERED_TIERS],
    headerRow: 0,
  };
}

export const DEFAULT_MEMBER_COLUMN_MAPPING: ManualMemberColumnMapping =
  defaultMemberMappingForDispatch("period_bonus");

export const DEFAULT_UNCLAIMED_COLUMN_MAPPING: ManualUnclaimedColumnMapping = {
  userId: 1, // B
  phoneNumber: -1,
  headerRow: 0,
};

export function indexToColumnLetter(index: number): string {
  if (index < 0) return "";
  let n = index + 1;
  let s = "";
  while (n > 0) {
    n--;
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26);
  }
  return s;
}

export function columnOptionLabel(col: ManualColumnPreview): string {
  const title = col.header && col.header !== "(空)" ? col.header : "空";
  return `${col.letter}列 · ${title}`;
}

export function buildFallbackColumns(maxIndex = 30): ManualColumnPreview[] {
  return Array.from({ length: maxIndex + 1 }, (_, index) => ({
    index,
    letter: indexToColumnLetter(index),
    header: "(未预览)",
  }));
}

export function defaultMemberMappingLabel(dispatchType: "period_bonus" | "callback_bonus"): string {
  const cols =
    dispatchType === "callback_bonus"
      ? "会员ID=F，累计充值=I，累计提款=J，手机号=X，层级=Y"
      : "会员ID=A，订单充值=F，订单提现=H，手机号=R，层级=V";
  return `${cols}；可自由调整；默认过滤：${DEFAULT_FILTERED_TIERS.join("、")}`;
}

function normalizeHeaderText(s: string): string {
  return s.trim().toLowerCase().replace(/\s+/g, "");
}

/** 优先精确匹配表头，避免「充值」误匹配到其他列 */
function matchColumnByHeader(cols: ManualColumnPreview[], names: string[]): number {
  const normalized = names.map(normalizeHeaderText).filter(Boolean);
  for (const col of cols) {
    const h = normalizeHeaderText(col.header === "(空)" ? "" : col.header);
    if (!h) continue;
    if (normalized.includes(h)) return col.index;
  }
  for (const name of normalized) {
    if (name.length < 3) continue;
    for (const col of cols) {
      const h = normalizeHeaderText(col.header === "(空)" ? "" : col.header);
      if (h && h.includes(name)) return col.index;
    }
  }
  return -1;
}

function matchColumnByLetter(cols: ManualColumnPreview[], letter: string): number {
  return cols.find((c) => c.letter === letter)?.index ?? -1;
}

function pickColumn(
  cols: ManualColumnPreview[],
  matched: number,
  letter: string,
  fallback: number,
): number {
  if (matched >= 0) return matched;
  const byLetter = matchColumnByLetter(cols, letter);
  return byLetter >= 0 ? byLetter : fallback;
}

/** 根据表头推荐列映射（推荐值，用户可自由修改） */
export function suggestMemberMappingFromColumns(
  cols: ManualColumnPreview[],
  dispatchType: "period_bonus" | "callback_bonus",
): Partial<ManualMemberColumnMapping> | null {
  if (!cols.length) return null;
  const defaults = defaultMemberMappingForDispatch(dispatchType);

  if (dispatchType === "period_bonus") {
    return {
      userId: pickColumn(
        cols,
        matchColumnByHeader(cols, ["会员id", "会员ID", "用户id", "会员号"]),
        "A",
        defaults.userId,
      ),
      historicalPay: pickColumn(
        cols,
        matchColumnByHeader(cols, ["订单充值", "充值金额", "历史充值"]),
        "F",
        defaults.historicalPay,
      ),
      historyWithdrawals: pickColumn(
        cols,
        matchColumnByHeader(cols, ["订单提现", "提现金额", "历史提现"]),
        "H",
        defaults.historyWithdrawals,
      ),
      phoneNumber: pickColumn(
        cols,
        matchColumnByHeader(cols, ["手机号码", "手机号", "电话"]),
        "R",
        defaults.phoneNumber,
      ),
      tierLevel: pickColumn(
        cols,
        matchColumnByHeader(cols, ["层级", "会员层级", "用户层级"]),
        "V",
        defaults.tierLevel,
      ),
    };
  }

  return {
    userId: pickColumn(
      cols,
      matchColumnByHeader(cols, ["会员id", "会员ID", "用户id", "会员号"]),
      "F",
      defaults.userId,
    ),
    historicalPay: pickColumn(
      cols,
      matchColumnByHeader(cols, ["累计充值", "历史充值", "订单充值", "充值金额"]),
      "I",
      defaults.historicalPay,
    ),
    historyWithdrawals: pickColumn(
      cols,
      matchColumnByHeader(cols, ["累计提款", "累计提现", "历史提现", "订单提现", "提现金额"]),
      "J",
      defaults.historyWithdrawals,
    ),
    phoneNumber: pickColumn(
      cols,
      matchColumnByHeader(cols, ["手机号码", "手机号", "电话"]),
      "X",
      defaults.phoneNumber,
    ),
    tierLevel: pickColumn(
      cols,
      matchColumnByHeader(cols, ["层级", "会员层级", "用户层级"]),
      "Y",
      defaults.tierLevel,
    ),
  };
}

export function repairStaleMemberMapping(
  m: ManualMemberColumnMapping,
  dispatchType: "period_bonus" | "callback_bonus",
): ManualMemberColumnMapping {
  if (dispatchType === "callback_bonus") {
    if (m.historicalPay === 16 && m.historyWithdrawals === 17) {
      return { ...m, historicalPay: 8, historyWithdrawals: 9 };
    }
    return m;
  }
  if (m.historicalPay === 10 && m.historyWithdrawals === 11) {
    return { ...m, historicalPay: 5, historyWithdrawals: 7, userId: m.userId === 10 ? 0 : m.userId };
  }
  return m;
}

export function defaultUnclaimedMappingLabel(): string {
  return "会员ID=B（第 1 行表头）";
}

function detectLocalCSVDelimiter(line: string): string {
  const candidates = [",", ";", "\t"];
  let best = ",";
  let bestCount = -1;
  for (const d of candidates) {
    const count = line.split(d).length - 1;
    if (count > bestCount) {
      bestCount = count;
      best = d;
    }
  }
  return best;
}

function parseCSVLine(line: string, delimiter: string): string[] {
  const out: string[] = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }
    if (!inQuotes && ch === delimiter) {
      out.push(cur.trim());
      cur = "";
      continue;
    }
    cur += ch;
  }
  out.push(cur.trim());
  return out;
}

/** 本地读取 CSV 表头 */
export async function previewLocalCSVColumns(
  file: File,
  headerRow: number,
): Promise<ManualColumnPreview[] | null> {
  if (!file.name.toLowerCase().endsWith(".csv")) return null;
  const chunk = file.slice(0, 256 * 1024);
  const text = (await chunk.text()).replace(/^\uFEFF/, "");
  const lines = text.split(/\r?\n/).filter((l) => l.length > 0);
  if (headerRow >= lines.length) return null;
  const delimiter = detectLocalCSVDelimiter(lines[0]);
  const header = parseCSVLine(lines[headerRow], delimiter);
  if (!header.length) return null;
  return header.map((h, index) => ({
    index,
    letter: indexToColumnLetter(index),
    header: h || "(空)",
  }));
}

export function normalizeMemberMapping(
  m: Partial<ManualMemberColumnMapping> | null | undefined,
  dispatchType: "period_bonus" | "callback_bonus",
): ManualMemberColumnMapping {
  const defaults = defaultMemberMappingForDispatch(dispatchType);
  const num = (v: unknown, fallback: number) =>
    typeof v === "number" && Number.isFinite(v) ? v : fallback;
  const headerRow = num(m?.headerRow, defaults.headerRow);
  const normalized: ManualMemberColumnMapping = {
    userId: num(m?.userId, defaults.userId),
    historicalPay: num(m?.historicalPay, defaults.historicalPay),
    historyWithdrawals: num(m?.historyWithdrawals, defaults.historyWithdrawals),
    phoneNumber: num(m?.phoneNumber, defaults.phoneNumber),
    tierLevel: num(m?.tierLevel, defaults.tierLevel),
    headerRow: headerRow >= 0 ? headerRow : 0,
    excludedTiers: Array.isArray(m?.excludedTiers) ? [...m!.excludedTiers!] : defaults.excludedTiers,
  };
  return repairStaleMemberMapping(normalized, dispatchType);
}

export function normalizeUnclaimedMapping(
  m: Partial<ManualUnclaimedColumnMapping> | null | undefined,
): ManualUnclaimedColumnMapping {
  const num = (v: unknown, fallback: number) =>
    typeof v === "number" && Number.isFinite(v) ? v : fallback;
  const headerRow = num(m?.headerRow, DEFAULT_UNCLAIMED_COLUMN_MAPPING.headerRow);
  return {
    userId: num(m?.userId, DEFAULT_UNCLAIMED_COLUMN_MAPPING.userId),
    phoneNumber: num(m?.phoneNumber, -1),
    headerRow: headerRow >= 0 ? headerRow : 0,
  };
}

export function mappingColumnCount(dispatchType: "period_bonus" | "callback_bonus"): number {
  return dispatchType === "callback_bonus"
    ? CALLBACK_MAPPING_COLUMN_COUNT
    : PERIOD_MAPPING_COLUMN_COUNT;
}

/** 预览表头后扩展下拉列数，避免表头列数超过默认上限 */
export function expandColumnsForMapping(
  cols: ManualColumnPreview[],
  dispatchType: "period_bonus" | "callback_bonus",
): ManualColumnPreview[] {
  if (!cols.length) return buildFallbackColumns(mappingColumnCount(dispatchType));
  const maxIndex = Math.max(...cols.map((c) => c.index), mappingColumnCount(dispatchType));
  if (cols.length >= maxIndex + 1) return cols;
  const byIndex = new Map(cols.map((c) => [c.index, c]));
  return Array.from({ length: maxIndex + 1 }, (_, index) =>
    byIndex.get(index) ?? {
      index,
      letter: indexToColumnLetter(index),
      header: "(空)",
    },
  );
}

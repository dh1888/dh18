<template>
  <el-table :data="rows" stripe max-height="480" empty-text="暂无数据">
    <el-table-column prop="userId" label="会员ID" width="120" />
    <el-table-column label="优惠金额" width="120">
      <template #default="{ row }">{{ formatMoney(row.bonus) }}</template>
    </el-table-column>
    <el-table-column label="打码倍数" width="100">
      <template #default>{{ formatMultiplier(config.wageringMultiplier) }}</template>
    </el-table-column>
    <el-table-column prop="appRemark" label="APP端备注" min-width="160">
      <template #default>{{ config.appRemark || "—" }}</template>
    </el-table-column>
    <el-table-column prop="backendRemark" label="后台备注" min-width="160">
      <template #default>{{ config.backendRemark || "—" }}</template>
    </el-table-column>
  </el-table>
</template>

<script setup lang="ts">
import type { ManualBonusConfig, ManualRow } from "@api/callback_api";
import { formatMoney } from "./helpers";

defineProps<{
  rows: ManualRow[];
  config: ManualBonusConfig;
}>();

function formatMultiplier(v: number | undefined): string {
  if (v == null || Number.isNaN(v)) return "0";
  const n = Number(v);
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}
</script>

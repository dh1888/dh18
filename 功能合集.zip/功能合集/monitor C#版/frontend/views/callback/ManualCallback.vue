<template>
  <ManualDispatchPage dispatch-type="callback_bonus" page-title="回访彩金" />
</template>

<script setup lang="ts">
import ManualDispatchPage from "./ManualDispatchPage.vue";

defineOptions({ name: "CallbackManualCallback" });
</script>

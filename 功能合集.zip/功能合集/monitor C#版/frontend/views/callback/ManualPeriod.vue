<template>
  <div class="period-mode-page">
    <!-- 页面头部 -->
  

    <!-- 模式切换 - 卡片式设计 -->
    <div class="mode-selector">
      <div
        v-for="option in modeOptions"
        :key="option.value"
        class="mode-card"
        :class="{
          'mode-card-active': mode === option.value,
          'mode-card-single': option.value === 'single',
          'mode-card-batch': option.value === 'batch',
        }"
        @click="mode = option.value"
      >
        <div class="mode-card-icon">
          <el-icon :size="32">
            <component :is="option.icon" />
          </el-icon>
        </div>
        <div class="mode-card-content">
          <div class="mode-card-title">{{ option.label }}</div>
          <div class="mode-card-desc">{{ option.description }}</div>
        </div>
        <div class="mode-card-check" v-if="mode === option.value">
          <el-icon><Check /></el-icon>
        </div>
        <div class="mode-card-badge" v-if="option.recommended">
          <el-tag size="small" type="danger" effect="dark">推荐</el-tag>
        </div>
      </div>
    </div>

    <!-- 内容区域 -->
    <div class="mode-content">
      <transition name="fade-slide" mode="out-in">
        <ManualDispatchPage
          v-if="mode === 'single'"
          key="single"
          dispatch-type="period_bonus"
          page-title="时段彩金"
        />
        <ManualPeriodBatch v-else key="batch" />
      </transition>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { Present, InfoFilled, Check, Coin, Connection } from "@element-plus/icons-vue";
import ManualDispatchPage from "./ManualDispatchPage.vue";
import ManualPeriodBatch from "./ManualPeriodBatch.vue";

defineOptions({ name: "CallbackManualPeriod" });

const mode = ref<"single" | "batch">("batch");

const modeOptions = [
  {
    label: "单站点",
    value: "single",
    icon: "Coin",
    description: "为单个站点上传数据，生成时段彩金派发表",
    recommended: false,
  },
  {
    label: "批量站点",
    value: "batch",
    icon: "Connection",
    description: "同时为多个站点处理数据，批量生成派发表",
    recommended: true,
  },
];
</script>

<style scoped>
.period-mode-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 4px 0;
}

/* ===== 页面头部 ===== */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 24px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 16px;
  color: white;
  flex-wrap: wrap;
  gap: 12px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.header-icon {
  width: 48px;
  height: 48px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.page-title {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  letter-spacing: 1px;
}

.page-subtitle {
  margin: 4px 0 0;
  font-size: 14px;
  opacity: 0.85;
}

.header-right :deep(.el-tag) {
  background: rgba(255, 255, 255, 0.15);
  border-color: rgba(255, 255, 255, 0.2);
  color: white;
  font-size: 14px;
  padding: 8px 16px;
  border-radius: 20px;
  backdrop-filter: blur(4px);
}

.header-right .el-icon {
  margin-right: 6px;
}

/* ===== 模式选择卡片 ===== */
.mode-selector {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

.mode-card {
  position: relative;
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 18px 24px;
  background: white;
  border-radius: 16px;
  border: 2px solid #e8ecf1;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
}

.mode-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
  border-color: #c0c4cc;
}

.mode-card-active {
  border-color: #667eea;
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.25);
}

.mode-card-active:hover {
  border-color: #667eea;
  box-shadow: 0 8px 24px rgba(102, 126, 234, 0.3);
}

.mode-card-single.mode-card-active {
  border-color: #4facfe;
  box-shadow: 0 4px 16px rgba(79, 172, 254, 0.25);
}

.mode-card-batch.mode-card-active {
  border-color: #43e97b;
  box-shadow: 0 4px 16px rgba(67, 233, 123, 0.25);
}

.mode-card-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: white;
  transition: all 0.3s ease;
}

.mode-card-single .mode-card-icon {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}

.mode-card-batch .mode-card-icon {
  background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
}

.mode-card-active .mode-card-icon {
  transform: scale(1.05);
}

.mode-card-content {
  flex: 1;
}

.mode-card-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.mode-card-desc {
  font-size: 13px;
  color: #909399;
  margin-top: 2px;
}

.mode-card-check {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  font-size: 16px;
}

.mode-card-single.mode-card-active .mode-card-check {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}

.mode-card-batch.mode-card-active .mode-card-check {
  background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
}

.mode-card-badge {
  position: absolute;
  top: 10px;
  right: 16px;
}

.mode-card-badge :deep(.el-tag) {
  border-radius: 12px;
  font-size: 11px;
  padding: 0 10px;
  height: 22px;
  line-height: 22px;
}

/* ===== 内容切换动画 ===== */
.mode-content {
  min-height: 400px;
}

.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: all 0.3s ease;
}

.fade-slide-enter-from {
  opacity: 0;
  transform: translateY(12px);
}

.fade-slide-leave-to {
  opacity: 0;
  transform: translateY(-12px);
}

/* ===== 响应式 ===== */
@media (max-width: 768px) {
  .mode-selector {
    grid-template-columns: 1fr;
  }

  .page-header {
    flex-direction: column;
    align-items: flex-start;
    padding: 16px 20px;
  }

  .header-left {
    width: 100%;
  }

  .header-right {
    width: 100%;
  }

  .header-right :deep(.el-tag) {
    width: 100%;
    justify-content: center;
  }

  .page-title {
    font-size: 18px;
  }

  .mode-card {
    padding: 14px 18px;
  }

  .mode-card-icon {
    width: 40px;
    height: 40px;
  }

  .mode-card-icon .el-icon {
    font-size: 24px !important;
  }

  .mode-card-title {
    font-size: 14px;
  }

  .mode-card-desc {
    font-size: 12px;
  }
}

@media (max-width: 480px) {
  .page-header {
    padding: 12px 16px;
    border-radius: 12px;
  }

  .header-icon {
    width: 40px;
    height: 40px;
  }

  .page-title {
    font-size: 16px;
  }

  .page-subtitle {
    font-size: 12px;
  }

  .mode-card {
    padding: 12px 14px;
    gap: 12px;
  }

  .mode-card-icon {
    width: 36px;
    height: 36px;
  }

  .mode-card-badge {
    display: none;
  }
}
</style>
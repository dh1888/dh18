<template>

  <div class="callback-page">

    <div class="bg-decoration">

      <div class="blob blob-1"></div>

      <div class="blob blob-2"></div>

    </div>

    <el-card shadow="hover" class="main-card">

      <template #header>生成回访名单</template>



      <el-alert

        v-if="activity"

        type="info"

        :closable="false"

        show-icon

        class="activity-alert"

      >

        <template #title>当前活动规则</template>

        <div>{{ formatActivitySummary(activity) }}</div>

        <div class="activity-actions">

          <el-button link type="primary" @click="$router.push('/callback/activity')">修改配置</el-button>

        </div>

      </el-alert>



      <el-form :model="form" label-width="100px" class="form-narrow">

        <el-form-item label="平台">

          <el-select

            v-model="form.platformId"

            placeholder="选择平台"

            filterable

            style="width: 100%; max-width: 400px"

          >

            <el-option

              v-for="p in enabledPlatforms"

              :key="p.id"

              :label="`${p.name} (${p.tenantId})`"

              :value="p.id"

            />

          </el-select>

          <el-button link type="primary" class="link-btn" @click="$router.push('/callback/platforms')">

            管理平台

          </el-button>

        </el-form-item>

        <el-form-item label="日期范围">

          <el-date-picker

            v-model="form.dateRange"

            type="daterange"

            range-separator="至"

            start-placeholder="开始"

            end-placeholder="结束"

            value-format="YYYY-MM-DD"

          />

          <el-button link type="primary" class="link-btn" @click="resetDateRange">

            按统计天数重置

          </el-button>

          <span v-if="activity" class="field-hint">默认最近 {{ activity.days }} 天</span>

        </el-form-item>

        <el-form-item label="接口编码">

          <el-input v-model="form.endpointCode" placeholder="默认 vip.list" style="max-width: 400px" />

        </el-form-item>

        <el-form-item>

          <el-button type="primary" :loading="generating" @click="handleGenerate">

            生成名单

          </el-button>

          <el-button :loading="estimating" @click="handleEstimate">预估</el-button>

        </el-form-item>

      </el-form>



      <el-alert

        v-if="estimate"

        type="info"

        :closable="false"

        show-icon

        class="estimate-alert"

        :title="`预估（${estimate.dateFrom} ~ ${estimate.dateTo}）：${estimate.memberCount} 人，总彩金 ${formatMoney(estimate.totalBonus)}，健康值 ${healthLevelLabel(estimate.healthLevel)}（拉取 ${estimate.fetchedCount} 条原始会员）`"

      />



      <el-card v-if="lastTask" shadow="never" class="result-card">

        <template #header>生成结果</template>

        <el-descriptions :column="3" border>

          <el-descriptions-item label="回访人数">{{ lastTask.memberCount }}</el-descriptions-item>

          <el-descriptions-item label="总彩金">{{ formatMoney(lastTask.totalBonus) }}</el-descriptions-item>

          <el-descriptions-item label="健康值">

            <el-tag :type="healthLevelTagType(lastTask.healthLevel)">

              {{ healthLevelLabel(lastTask.healthLevel) }}

            </el-tag>

          </el-descriptions-item>

        </el-descriptions>

        <div class="actions">

          <el-button @click="$router.push('/callback/tasks')">查看历史</el-button>

          <el-button @click="exportTask(lastTask.id)">导出 Excel</el-button>

        </div>

      </el-card>

    </el-card>

  </div>

</template>



<script setup lang="ts">

import { onMounted, reactive, ref } from "vue";

import { ElMessage } from "element-plus";

import callbackApi, {

  type CallbackActivity,

  type CallbackTask,

  type CallbackTaskEstimate,

} from "@api/callback_api";

import {

  defaultDateRange,

  downloadBlob,

  formatActivitySummary,

  formatMoney,

  healthLevelLabel,

  healthLevelTagType,

} from "./helpers";

import { useCallbackPlatforms } from "./useCallbackPlatforms";

import "./styles.css";



const { enabledPlatforms, loadAll } = useCallbackPlatforms();



const activity = ref<CallbackActivity | null>(null);

const form = reactive({

  platformId: "",

  dateRange: defaultDateRange(7) as [string, string] | null,

  endpointCode: "vip.list",

});

const generating = ref(false);

const estimating = ref(false);

const lastTask = ref<CallbackTask | null>(null);

const estimate = ref<CallbackTaskEstimate | null>(null);



function resetDateRange() {

  const days = activity.value?.days ?? 7;

  form.dateRange = defaultDateRange(days);

}



function buildTaskPayload() {

  const payload: {

    platformId: string;

    dateFrom?: string;

    dateTo?: string;

    endpointCode?: string;

  } = {

    platformId: form.platformId,

    endpointCode: form.endpointCode || undefined,

  };

  if (form.dateRange?.length === 2) {

    payload.dateFrom = form.dateRange[0];

    payload.dateTo = form.dateRange[1];

  }

  return payload;

}



async function handleEstimate() {

  if (!form.platformId) {

    ElMessage.warning("请选择平台");

    return;

  }

  estimating.value = true;

  estimate.value = null;

  try {

    const { data } = await callbackApi.estimateTask(buildTaskPayload());

    estimate.value = data;

    if (data.dateFrom && data.dateTo) {

      form.dateRange = [data.dateFrom, data.dateTo];

    }

  } catch (e: any) {

    ElMessage.error(e.message || "预估失败");

  } finally {

    estimating.value = false;

  }

}



async function handleGenerate() {

  if (!form.platformId) {

    ElMessage.warning("请选择平台");

    return;

  }

  generating.value = true;

  try {

    const { data: task } = await callbackApi.generateTask(buildTaskPayload());

    lastTask.value = task;

    ElMessage.success(`生成完成，共 ${task.memberCount} 人`);

  } catch (e: any) {

    ElMessage.error(e.message || "生成失败");

  } finally {

    generating.value = false;

  }

}



async function exportTask(taskId: string) {

  try {

    const res = await callbackApi.exportTask(taskId);

    downloadBlob(res.data as Blob, `callback_${taskId}.xlsx`);

  } catch (e: any) {

    ElMessage.error(e.message || "导出失败");

  }

}



async function loadActivity() {

  try {

    const { data } = await callbackApi.getActivity();

    activity.value = data ?? null;

    if (data?.days) {

      form.dateRange = defaultDateRange(data.days);

    }

  } catch {

    /* ignore */

  }

}



onMounted(async () => {

  await Promise.all([loadAll(), loadActivity()]);

  if (enabledPlatforms.value.length) {

    form.platformId = enabledPlatforms.value[0].id;

  }

});

</script>



<style scoped>

.activity-alert {

  margin-bottom: 16px;

  max-width: 800px;

}

.activity-actions {

  margin-top: 4px;

}

.link-btn {

  margin-left: 12px;

}

.field-hint {

  margin-left: 12px;

  color: var(--el-text-color-secondary);

  font-size: 13px;

}

.estimate-alert {

  margin-bottom: 16px;

  max-width: 800px;

}

.result-card {

  margin-top: 24px;

  max-width: 800px;

}

.actions {

  margin-top: 16px;

  display: flex;

  gap: 12px;

}

</style>


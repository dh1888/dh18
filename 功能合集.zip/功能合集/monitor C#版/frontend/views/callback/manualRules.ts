import type { ManualDispatchRuleSet } from "@api/callback_api";

export type { ManualDispatchRuleSet };

export const MANUAL_FILTER_TIER = "tier_exclude";
export const MANUAL_FILTER_UNCLAIMED = "unclaimed_exclude";
export interface ManualFilterDefinition {
  id: string;
  label: string;
  description: string;
}

export const MANUAL_FILTER_CATALOG: ManualFilterDefinition[] = [
  {
    id: MANUAL_FILTER_TIER,
    label: "层级过滤",
    description: "剔除映射表中选定的层级会员",
  },
  {
    id: MANUAL_FILTER_UNCLAIMED,
    label: "未领彩金剔除",
    description: "会员ID 在未领彩金名单中则剔除（需上传未领名单）",
  },
];

export function defaultManualRules(
  dispatchType: "period_bonus" | "callback_bonus",
): ManualDispatchRuleSet {
  if (dispatchType === "callback_bonus") {
    return { enabledFilters: [MANUAL_FILTER_TIER, MANUAL_FILTER_UNCLAIMED] };
  }
  return { enabledFilters: [MANUAL_FILTER_TIER] };
}

export function normalizeManualRules(rules?: ManualDispatchRuleSet | null): ManualDispatchRuleSet {
  const allowed = new Set(MANUAL_FILTER_CATALOG.map((f) => f.id));
  const seen = new Set<string>();
  const enabledFilters: string[] = [];
  for (const id of rules?.enabledFilters ?? []) {
    if (!allowed.has(id) || seen.has(id)) continue;
    seen.add(id);
    enabledFilters.push(id);
  }
  return { enabledFilters };
}

export function manualRulesForDispatch(
  rules: ManualDispatchRuleSet | undefined,
  dispatchType: "period_bonus" | "callback_bonus",
): ManualDispatchRuleSet {
  const normalized = normalizeManualRules(rules);
  if (normalized.enabledFilters.length) return normalized;
  return defaultManualRules(dispatchType);
}

export function isManualFilterEnabled(
  rules: ManualDispatchRuleSet | undefined,
  filterId: string,
  dispatchType: "period_bonus" | "callback_bonus",
): boolean {
  return manualRulesForDispatch(rules, dispatchType).enabledFilters.includes(filterId);
}

export function ensureActivityManualRules(activity: {
  periodManualRules?: ManualDispatchRuleSet;
  callbackManualRules?: ManualDispatchRuleSet;
}) {
  activity.periodManualRules = manualRulesForDispatch(activity.periodManualRules, "period_bonus");
  activity.callbackManualRules = manualRulesForDispatch(activity.callbackManualRules, "callback_bonus");
}

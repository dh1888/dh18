<template>
  <div class="callback-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
    </div>
    <el-card shadow="hover" class="main-card">
      <template #header>请求日志</template>
      <div class="toolbar">
        <el-select
          v-model="filter.platformId"
          placeholder="全部平台"
          clearable
          filterable
          style="width: 200px"
        >
          <el-option v-for="p in platforms" :key="p.id" :label="p.name" :value="p.id" />
        </el-select>
        <el-input
          v-model="filter.endpointCode"
          placeholder="接口编码"
          clearable
          style="width: 160px"
          @keyup.enter="search"
        />
        <el-button @click="search" :loading="loading">查询</el-button>
      </div>
      <el-table :data="logs" v-loading="loading" stripe>
        <el-table-column prop="createdAt" label="时间" width="170" />
        <el-table-column prop="endpointCode" label="接口" width="120" />
        <el-table-column label="平台" width="120">
          <template #default="{ row }">
            {{ row.platformId ? platformName(row.platformId) : "-" }}
          </template>
        </el-table-column>
        <el-table-column prop="requestUrl" label="URL" show-overflow-tooltip />
        <el-table-column prop="responseStatus" label="状态码" width="80" />
        <el-table-column prop="durationMs" label="耗时(ms)" width="100" />
        <el-table-column prop="errorMessage" label="错误" show-overflow-tooltip />
      </el-table>
      <el-pagination
        class="pager"
        v-model:current-page="page"
        v-model:page-size="pageSize"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="load"
      />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from "vue";
import { ElMessage } from "element-plus";
import callbackApi, { type CallbackRequestLog } from "@api/callback_api";
import { useCallbackPlatforms } from "./useCallbackPlatforms";
import "./styles.css";

const { platforms, loadAll, platformName } = useCallbackPlatforms();

const logs = ref<CallbackRequestLog[]>([]);
const loading = ref(false);
const page = ref(1);
const pageSize = ref(20);
const total = ref(0);
const filter = reactive({ platformId: "", endpointCode: "" });

async function load() {
  loading.value = true;
  try {
    const { data } = await callbackApi.listRequestLogs({
      platformId: filter.platformId || undefined,
      endpointCode: filter.endpointCode || undefined,
      page: page.value,
      pageSize: pageSize.value,
    });
    logs.value = data.items || [];
    total.value = data.total || 0;
  } catch (e: any) {
    ElMessage.error(e.message || "加载失败");
  } finally {
    loading.value = false;
  }
}

function search() {
  page.value = 1;
  load();
}

onMounted(async () => {
  await loadAll();
  load();
});
</script>

<template>
  <div class="callback-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
    </div>
    <el-card shadow="hover" class="main-card">
      <template #header>
        <div class="card-head">
          <span>平台管理</span>
          <span class="head-actions">
            <el-button type="success" @click="importVisible = true">
              从网络导入
            </el-button>
            <el-button type="primary" @click="openDialog()">新增平台</el-button>
          </span>
        </div>
      </template>

      <div class="toolbar">
        <el-input
          v-model="keyword"
          placeholder="搜索平台名称"
          clearable
          style="width: 240px"
          @keyup.enter="search"
          @clear="search"
        />
        <el-button @click="search" :loading="loading">搜索</el-button>
      </div>

      <el-table :data="platforms" v-loading="loading" stripe>
        <el-table-column prop="name" label="名称" width="160" />
        <el-table-column prop="baseUrl" label="Base URL" show-overflow-tooltip min-width="200" />
        <el-table-column prop="tenantId" label="Tenant ID" width="120" />
        <el-table-column prop="tokenMasked" label="Token" width="160" />
        <el-table-column label="启用" width="80">
          <template #default="{ row }">
            <el-tag size="small" :type="row.enabled ? 'success' : 'info'">
              {{ row.enabled ? "是" : "否" }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="remark" label="备注" show-overflow-tooltip />
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button link type="success" :loading="testingId === row.id" @click="testConnection(row.id)">
              测试
            </el-button>
            <el-button link type="primary" @click="openDialog(row)">编辑</el-button>
            <el-button link type="danger" @click="remove(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        class="pager"
        v-model:current-page="page"
        v-model:page-size="pageSize"
        :total="total"
        :page-sizes="[20, 50, 100, 200]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </el-card>

    <el-dialog
      v-model="dialogVisible"
      :title="form.id ? '编辑平台' : '新增平台'"
      width="560px"
    >
      <el-button
        link
        type="primary"
        class="paste-link"
        @click="importSingleVisible = true"
      >
        从网络请求粘贴自动填充
      </el-button>
      <el-form :model="form" label-width="100px">
        <el-form-item label="名称" required>
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="Base URL" required>
          <el-input v-model="form.baseUrl" placeholder="https://api.example.com" />
        </el-form-item>
        <el-form-item label="Tenant ID" required>
          <el-input v-model="form.tenantId" />
        </el-form-item>
        <el-form-item label="Token" :required="!form.id">
          <el-input
            v-model="form.token"
            type="password"
            show-password
            :placeholder="form.id ? '留空不修改' : 'Bearer Token'"
          />
        </el-form-item>
        <el-form-item label="启用">
          <el-switch v-model="form.enabled" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>

    <NetworkImportDialog
      v-model="importVisible"
      mode="platform"
      @apply-platform="batchCreate"
    />
    <NetworkImportDialog
      v-model="importSingleVisible"
      mode="platform"
      @apply-platform="applySingleImport"
    />
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import callbackApi, { type CallbackPlatform } from "@api/callback_api";
import NetworkImportDialog, {
  type PlatformImportRow,
} from "./NetworkImportDialog.vue";
import { useCallbackPlatforms } from "./useCallbackPlatforms";
import "./styles.css";

const { platforms, loading, total, loadPage } = useCallbackPlatforms();

const page = ref(1);
const pageSize = ref(50);
const keyword = ref("");

const dialogVisible = ref(false);
const importVisible = ref(false);
const importSingleVisible = ref(false);
const saving = ref(false);
const testingId = ref("");

const form = reactive({
  id: "",
  name: "",
  baseUrl: "",
  tenantId: "",
  token: "",
  enabled: true,
  remark: "",
});

function load() {
  loadPage(page.value, pageSize.value, keyword.value);
}

function search() {
  page.value = 1;
  load();
}

async function testConnection(id: string) {
  testingId.value = id;
  try {
    const { data } = await callbackApi.testPlatform(id, { endpointCode: "vip.list" });
    if (data.success) {
      ElMessage.success(
        `连接成功 HTTP ${data.statusCode}，${data.durationMs}ms，首屏 ${data.sampleCount} 条`,
      );
    } else {
      ElMessage.error(data.message || "连接失败");
    }
  } catch (e: any) {
    ElMessage.error(e.message || "测试失败");
  } finally {
    testingId.value = "";
  }
}

function openDialog(row?: CallbackPlatform) {
  form.id = row?.id || "";
  form.name = row?.name || "";
  form.baseUrl = row?.baseUrl || "";
  form.tenantId = row?.tenantId || "";
  form.token = "";
  form.enabled = row?.enabled ?? true;
  form.remark = row?.remark || "";
  dialogVisible.value = true;
}

function applySingleImport(rows: PlatformImportRow[]) {
  const row = rows[0];
  if (!row) return;
  form.name = row.name || row.suggestedName;
  form.baseUrl = row.baseUrl;
  form.tenantId = row.tenantId || "";
  form.token = row.token || "";
  importSingleVisible.value = false;
  if (!dialogVisible.value) dialogVisible.value = true;
  ElMessage.success("已从网络请求填充表单");
}

async function batchCreate(rows: PlatformImportRow[]) {
  let ok = 0;
  let fail = 0;
  for (const row of rows) {
    try {
      await callbackApi.createPlatform({
        name: row.name.trim(),
        baseUrl: row.baseUrl,
        tenantId: row.tenantId!,
        token: row.token!,
        enabled: row.enabled,
        remark: `从网络导入 ${row.path}`,
      });
      ok++;
    } catch {
      fail++;
    }
  }
  ElMessage.success(`批量导入完成：成功 ${ok}，失败 ${fail}`);
  load();
}

async function save() {
  saving.value = true;
  try {
    if (form.id) {
      await callbackApi.updatePlatform(form.id, {
        name: form.name,
        baseUrl: form.baseUrl,
        tenantId: form.tenantId,
        token: form.token || undefined,
        enabled: form.enabled,
        remark: form.remark,
      });
    } else {
      if (!form.token) {
        ElMessage.warning("请填写 Token");
        return;
      }
      await callbackApi.createPlatform({
        name: form.name,
        baseUrl: form.baseUrl,
        tenantId: form.tenantId,
        token: form.token,
        enabled: form.enabled,
        remark: form.remark,
      });
    }
    dialogVisible.value = false;
    ElMessage.success("保存成功");
    load();
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    saving.value = false;
  }
}

async function remove(id: string) {
  await ElMessageBox.confirm("确定删除该平台？", "提示", { type: "warning" });
  try {
    await callbackApi.deletePlatform(id);
    ElMessage.success("已删除");
    load();
  } catch (e: any) {
    ElMessage.error(e.message || "删除失败");
  }
}

onMounted(load);
</script>

<style scoped>
.card-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.head-actions {
  display: flex;
  gap: 8px;
}
.paste-link {
  margin-bottom: 12px;
}
</style>

import { reactive } from "vue";

import type { ManualDispatchType, ManualProcessResult } from "@api/callback_api";

import {

  buildFallbackColumns,

  DEFAULT_FILTERED_TIERS,

  DEFAULT_UNCLAIMED_COLUMN_MAPPING,

  defaultMemberMappingForDispatch,

  mappingColumnCount,

  normalizeMemberMapping,

  normalizeUnclaimedMapping,

  type ManualColumnPreview,

  type ManualMemberColumnMapping,

  type ManualUnclaimedColumnMapping,

} from "./columnMapping";



const STORAGE_PREFIX = "callback_manual_ws_v3_";



export interface ManualDispatchWorkspace {

  memberMapping: ManualMemberColumnMapping;

  memberColumns: ManualColumnPreview[];

  memberFileName: string;

  unclaimedMapping: ManualUnclaimedColumnMapping;

  unclaimedColumns: ManualColumnPreview[];

  unclaimedFileName: string;

  result: ManualProcessResult | null;

  activeTab: string;

  tierOptions: string[];

}



interface PersistedWorkspace {

  memberMapping: ManualMemberColumnMapping;

  memberColumns: ManualColumnPreview[];

  memberFileName: string;

  unclaimedMapping: ManualUnclaimedColumnMapping;

  unclaimedColumns: ManualColumnPreview[];

  unclaimedFileName: string;

  result: ManualProcessResult | null;

  activeTab: string;

  tierOptions: string[];

}



function createWorkspace(type: ManualDispatchType): ManualDispatchWorkspace {

  const saved = loadPersisted(type);

  if (saved) {

    return {

      memberMapping: normalizeMemberMapping(saved.memberMapping, type),

      memberColumns: saved.memberColumns?.length

        ? saved.memberColumns

        : buildFallbackColumns(mappingColumnCount(type)),

      memberFileName: saved.memberFileName ?? "",

      unclaimedMapping: normalizeUnclaimedMapping(saved.unclaimedMapping),

      unclaimedColumns: saved.unclaimedColumns?.length

        ? saved.unclaimedColumns

        : buildFallbackColumns(10),

      unclaimedFileName: saved.unclaimedFileName ?? "",

      result: saved.result ?? null,

      activeTab: saved.activeTab === "dispatch" ? "dispatch_bonus" : (saved.activeTab ?? "dispatch_bonus"),

      tierOptions: saved.tierOptions?.length ? saved.tierOptions : [...DEFAULT_FILTERED_TIERS],

    };

  }

  return {

    memberMapping: defaultMemberMappingForDispatch(type),

    memberColumns: buildFallbackColumns(mappingColumnCount(type)),

    memberFileName: "",

    unclaimedMapping: { ...DEFAULT_UNCLAIMED_COLUMN_MAPPING, phoneNumber: -1 },

    unclaimedColumns: buildFallbackColumns(10),

    unclaimedFileName: "",

    result: null,

    activeTab: "dispatch_bonus",

    tierOptions: [...DEFAULT_FILTERED_TIERS],

  };

}



function loadPersisted(type: ManualDispatchType): PersistedWorkspace | null {

  try {

    const raw = sessionStorage.getItem(STORAGE_PREFIX + type);

    if (!raw) return null;

    return JSON.parse(raw) as PersistedWorkspace;

  } catch {

    return null;

  }

}



function persistWorkspace(type: ManualDispatchType, ws: ManualDispatchWorkspace) {

  const payload: PersistedWorkspace = {

    memberMapping: ws.memberMapping,

    memberColumns: ws.memberColumns,

    memberFileName: ws.memberFileName,

    unclaimedMapping: ws.unclaimedMapping,

    unclaimedColumns: ws.unclaimedColumns,

    unclaimedFileName: ws.unclaimedFileName,

    result: ws.result,

    activeTab: ws.activeTab,

    tierOptions: ws.tierOptions,

  };

  try {

    sessionStorage.setItem(STORAGE_PREFIX + type, JSON.stringify(payload));

  } catch {

    /* 结果过大时忽略持久化，内存仍保留 */

  }

}



const workspaces = reactive<Record<ManualDispatchType, ManualDispatchWorkspace>>({

  period_bonus: createWorkspace("period_bonus"),

  callback_bonus: createWorkspace("callback_bonus"),

});



const memberFiles = reactive<Record<ManualDispatchType, File | null>>({

  period_bonus: null,

  callback_bonus: null,

});



const unclaimedFiles = reactive<Record<ManualDispatchType, File | null>>({

  period_bonus: null,

  callback_bonus: null,

});



export function getManualWorkspace(type: ManualDispatchType): ManualDispatchWorkspace {

  return workspaces[type];

}



export function getMemberFile(type: ManualDispatchType): File | null {

  return memberFiles[type];

}



export function setMemberFile(type: ManualDispatchType, file: File | null) {

  memberFiles[type] = file;

  workspaces[type].memberFileName = file?.name ?? "";

  persistWorkspace(type, workspaces[type]);

}



export function getUnclaimedFile(type: ManualDispatchType): File | null {

  return unclaimedFiles[type];

}



export function setUnclaimedFile(type: ManualDispatchType, file: File | null) {

  unclaimedFiles[type] = file;

  workspaces[type].unclaimedFileName = file?.name ?? "";

  persistWorkspace(type, workspaces[type]);

}



export function saveManualWorkspace(type: ManualDispatchType) {

  persistWorkspace(type, workspaces[type]);

}



export function useManualWorkspaces() {

  return { workspaces, memberFiles, unclaimedFiles, getManualWorkspace, saveManualWorkspace };

}



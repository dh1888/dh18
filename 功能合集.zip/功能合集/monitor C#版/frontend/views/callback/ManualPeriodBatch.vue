<template>
  <div class="callback-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
    </div>
    <el-card shadow="hover" class="main-card">
      <template #header>
        <div class="card-header">
          <span>时段彩金 · 批量站点</span>
          <el-button link type="primary" @click="$router.push('/callback/activity')">活动配置</el-button>
        </div>
      </template> 

      <el-form label-width="100px" class="form-row">
        <el-form-item v-if="bonusConfigText" label="彩金规则">
          <span class="config-text">{{ bonusConfigText }}</span>
        </el-form-item>
      </el-form>

      <div class="queue-toolbar">
        <el-button type="primary" @click="addSiteRow">
          <el-icon><Plus /></el-icon>
          添加站点
        </el-button>
        <el-button @click="downloadTemplate('member')">下载会员模板</el-button>
        <el-button v-if="needsUnclaimedFile" @click="downloadTemplate('unclaimed')">
          下载未领模板
        </el-button>
      </div>

      <el-table :data="siteTasks" stripe class="site-table" empty-text="请点击「添加站点」">
        <el-table-column label="站点" min-width="180">
          <template #default="{ row }">
            <el-select
              v-model="row.platformId"
              filterable
              placeholder="选择平台"
              style="width: 100%"
              @change="onPlatformChange(row)"
            >
              <el-option
                v-for="p in enabledPlatforms"
                :key="p.id"
                :label="p.name"
                :value="p.id"
                :disabled="isPlatformUsed(p.id, row.key)"
              />
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="会员数据" min-width="200">
          <template #default="{ row }">
            <el-upload
              :auto-upload="false"
              :limit="1"
              :accept="SPREADSHEET_ACCEPT"
              :show-file-list="true"
              :file-list="row.memberFileList"
              @change="(f, list) => onSiteMemberChange(row, f, list)"
              @remove="() => onSiteMemberRemove(row)"
              @exceed="(files) => onSiteMemberExceed(row, files)"
            >
              <el-button size="small">选择文件</el-button>
            </el-upload>
          </template>
        </el-table-column>
        <el-table-column v-if="needsUnclaimedFile" label="未领名单" min-width="200">
          <template #default="{ row }">
            <el-upload
              :auto-upload="false"
              :limit="1"
              :accept="SPREADSHEET_ACCEPT"
              :show-file-list="true"
              :file-list="row.unclaimedFileList"
              @change="(f, list) => onSiteUnclaimedChange(row, f, list)"
              @remove="() => onSiteUnclaimedRemove(row)"
              @exceed="(files) => onSiteUnclaimedExceed(row, files)"
            >
              <el-button size="small" type="warning">选择文件</el-button>
            </el-upload>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="120">
          <template #default="{ row }">
            <el-tag v-if="row.status === 'pending'" type="info">待处理</el-tag>
            <el-tag v-else-if="row.status === 'processing'" type="warning">处理中</el-tag>
            <el-tag v-else-if="row.status === 'success'" type="success">已完成</el-tag>
            <el-tooltip v-else :content="row.errorMessage || '失败'" placement="top">
              <el-tag type="danger">失败</el-tag>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column label="派发人数" width="100">
          <template #default="{ row }">
            {{ row.result?.summary.bonusCount ?? "—" }}
          </template>
        </el-table-column>
        <el-table-column label="总彩金" width="110">
          <template #default="{ row }">
            {{ row.result ? formatMoney(row.result.summary.totalBonus) : "—" }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="80" fixed="right">
          <template #default="{ row }">
            <el-button link type="danger" @click="removeSiteRow(row.key)">移除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-card shadow="never" class="mapping-card">
        <template #header>共用列映射（全部站点统一）</template>
        <div class="mapping-tip">
          默认 A会员ID / F订单充值 / H订单提现 / R手机号 / V层级；可在首个会员文件上传后预览表头调整
        </div>
        <column-mapping-form
          title="会员数据列映射"
          v-model="memberMappingFields"
          v-model:header-row="memberMapping.headerRow"
          v-model:multi-select-value="memberExcludedTiers"
          :columns="memberColumns"
          :fields="memberMappingFieldDefs"
          :multi-select-field="tierMultiSelect"
          :show-preview-header="!!previewMemberFile"
          :preview-loading="memberPreviewLoading"
          :show-scan-tiers="!!previewMemberFile && memberMapping.tierLevel >= 0"
          :scan-tiers-loading="tierScanLoading"
          :show-sync-from-activity="!!activityFilteredTiers().length"
          :default-hint="defaultMemberMappingLabel('period_bonus')"
          @reset-default="resetMemberMapping"
          @preview-header="previewMemberHeaders"
          @scan-tiers="scanTierOptionsFromFile"
          @sync-from-activity="syncExcludedTiersFromActivity"
          @header-row-change="onMemberHeaderRowChange"
        />
        <column-mapping-form
          v-if="needsUnclaimedFile"
          title="未领名单列映射"
          v-model="unclaimedMappingFields"
          v-model:header-row="unclaimedMapping.headerRow"
          :columns="unclaimedColumns"
          :fields="unclaimedMappingFieldDefs"
          :show-preview-header="!!previewUnclaimedFile"
          :preview-loading="unclaimedPreviewLoading"
          :default-hint="defaultUnclaimedMappingLabel()"
          @reset-default="resetUnclaimedMapping"
          @preview-header="previewUnclaimedHeaders"
          @header-row-change="onUnclaimedHeaderRowChange"
        />
      </el-card>

      <div class="action-bar">
        <el-button
          type="success"
          size="large"
          :loading="batchProcessing"
          :disabled="!canBatchProcess"
          @click="handleBatchProcess"
        >
          批量计算彩金（{{ readyTaskCount }} 个站点）
        </el-button>
        <el-button
          size="large"
          :disabled="!completedTasks.length"
          :loading="batchExporting"
          @click="handleBatchExportAll"
        >
          批量导出全部
        </el-button>
      </div>

      <template v-if="completedTasks.length">
        <el-divider />
        <div class="results-header">批量处理结果</div>
        <el-tabs v-model="activeResultKey">
          <el-tab-pane
            v-for="task in completedTasks"
            :key="task.key"
            :label="resultTabLabel(task)"
            :name="task.key"
          >
            <manual-period-batch-result
              :result="task.result"
              :needs-unclaimed-file="needsUnclaimedFile"
              v-model:active-tab="task.activeTab"
              @export="(type) => exportSiteResult(task, type)"
            />
          </el-tab-pane>
        </el-tabs>
      </template>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from "vue";
import { ElMessage, genFileId } from "element-plus";
import { Plus } from "@element-plus/icons-vue";
import type { UploadFile, UploadRawFile, UploadUserFile } from "element-plus";
import callbackApi, { type CallbackActivity, type ManualProcessResult } from "@api/callback_api";
import ColumnMappingForm from "./ColumnMappingForm.vue";
import ManualPeriodBatchResult from "./ManualPeriodBatchResult.vue";
import {
  buildFallbackColumns,
  DEFAULT_FILTERED_TIERS,
  DEFAULT_UNCLAIMED_COLUMN_MAPPING,
  defaultMemberMappingForDispatch,
  defaultMemberMappingLabel,
  defaultUnclaimedMappingLabel,
  expandColumnsForMapping,
  mappingColumnCount,
  normalizeMemberMapping,
  previewLocalCSVColumns,
  SPREADSHEET_ACCEPT,
  suggestMemberMappingFromColumns,
  type ManualColumnPreview,
  type ManualMemberColumnMapping,
  type ManualUnclaimedColumnMapping,
} from "./columnMapping";
import { downloadBlob, formatMoney } from "./helpers";
import {
  ensureActivityManualRules,
  isManualFilterEnabled,
  MANUAL_FILTER_TIER,
  MANUAL_FILTER_UNCLAIMED,
} from "./manualRules";
import { useCallbackPlatforms } from "./useCallbackPlatforms";
import "./styles.css";

defineOptions({ name: "ManualPeriodBatch" });

type SiteTaskStatus = "pending" | "processing" | "success" | "error";

interface BatchSiteTask {
  key: string;
  platformId: string;
  memberFile: File | null;
  unclaimedFile: File | null;
  memberFileList: UploadUserFile[];
  unclaimedFileList: UploadUserFile[];
  status: SiteTaskStatus;
  errorMessage?: string;
  result: ManualProcessResult | null;
  activeTab: string;
}

const { enabledPlatforms, loadAll, platformName } = useCallbackPlatforms();

const activity = ref<CallbackActivity | null>(null);
const batchProcessing = ref(false);
const batchExporting = ref(false);
const memberPreviewLoading = ref(false);
const unclaimedPreviewLoading = ref(false);
const tierScanLoading = ref(false);
const activeResultKey = ref("");

let taskSeq = 0;

const siteTasks = ref<BatchSiteTask[]>([]);

const memberMapping = reactive<ManualMemberColumnMapping>(
  defaultMemberMappingForDispatch("period_bonus"),
);
const unclaimedMapping = reactive<ManualUnclaimedColumnMapping>({
  ...DEFAULT_UNCLAIMED_COLUMN_MAPPING,
  phoneNumber: -1,
});
const memberColumns = ref<ManualColumnPreview[]>(
  buildFallbackColumns(mappingColumnCount("period_bonus")),
);
const unclaimedColumns = ref<ManualColumnPreview[]>(buildFallbackColumns(10));
const tierOptions = ref<string[]>([...DEFAULT_FILTERED_TIERS]);

const needsUnclaimedFile = computed(() =>
  isManualFilterEnabled(activity.value?.periodManualRules, MANUAL_FILTER_UNCLAIMED, "period_bonus"),
);

const needsTierColumn = computed(() =>
  isManualFilterEnabled(activity.value?.periodManualRules, MANUAL_FILTER_TIER, "period_bonus"),
);

const previewMemberFile = computed(() => siteTasks.value.find((t) => t.memberFile)?.memberFile ?? null);
const previewUnclaimedFile = computed(
  () => siteTasks.value.find((t) => t.unclaimedFile)?.unclaimedFile ?? null,
);

const memberMappingFieldDefs = [
  { key: "userId", label: "会员ID" },
  { key: "historicalPay", label: "订单充值" },
  { key: "historyWithdrawals", label: "订单提现" },
  { key: "phoneNumber", label: "手机号码" },
  { key: "tierLevel", label: "层级" },
];
const unclaimedMappingFieldDefs = [{ key: "userId", label: "会员ID" }];

const memberMappingFields = computed({
  get: () => ({
    userId: memberMapping.userId,
    historicalPay: memberMapping.historicalPay,
    historyWithdrawals: memberMapping.historyWithdrawals,
    phoneNumber: memberMapping.phoneNumber,
    tierLevel: memberMapping.tierLevel,
  }),
  set: (v: Record<string, number>) => {
    memberMapping.userId = v.userId;
    memberMapping.historicalPay = v.historicalPay;
    memberMapping.historyWithdrawals = v.historyWithdrawals;
    memberMapping.phoneNumber = v.phoneNumber;
    if (v.tierLevel != null) memberMapping.tierLevel = v.tierLevel;
  },
});

const unclaimedMappingFields = computed({
  get: () => ({ userId: unclaimedMapping.userId }),
  set: (v: Record<string, number>) => {
    unclaimedMapping.userId = v.userId;
  },
});

const memberExcludedTiers = computed({
  get: () => memberMapping.excludedTiers ?? [],
  set: (v: string[]) => {
    memberMapping.excludedTiers = v;
  },
});

const tierMultiSelect = computed(() => ({
  label: "过滤层级",
  placeholder: "多选需剔除的层级",
  options: tierOptions.value,
}));

const bonusConfigText = computed(() => {
  const a = activity.value;
  if (!a) return "";
  return `用户亏损/持平（充提差≥0）：充提差×${a.rate ?? 0.02}÷${a.divisor ?? 2}，低于 ${a.minBonus} 取 ${a.minBonus}，最高 ${a.maxBonus} · 打码 ${a.periodWageringMultiplier ?? 1}`;
});

function isTaskReady(task: BatchSiteTask): boolean {
  if (!task.platformId || !task.memberFile) return false;
  if (needsUnclaimedFile.value && !task.unclaimedFile) return false;
  return true;
}

const readyTasks = computed(() => siteTasks.value.filter(isTaskReady));
const readyTaskCount = computed(() => readyTasks.value.length);

const canBatchProcess = computed(() => {
  if (!readyTaskCount.value) return false;
  if (needsTierColumn.value && memberMapping.tierLevel < 0) return false;
  return true;
});

const completedTasks = computed(() =>
  siteTasks.value.filter((t) => t.status === "success" && t.result),
);

function newTaskKey() {
  taskSeq += 1;
  return `site-${taskSeq}-${Date.now()}`;
}

function createSiteRow(platformId = ""): BatchSiteTask {
  return {
    key: newTaskKey(),
    platformId,
    memberFile: null,
    unclaimedFile: null,
    memberFileList: [],
    unclaimedFileList: [],
    status: "pending",
    result: null,
    activeTab: "dispatch_bonus",
  };
}

function addSiteRow() {
  const unused = enabledPlatforms.value.find(
    (p) => !siteTasks.value.some((t) => t.platformId === p.id),
  );
  siteTasks.value.push(createSiteRow(unused?.id ?? ""));
}

function removeSiteRow(key: string) {
  siteTasks.value = siteTasks.value.filter((t) => t.key !== key);
  if (activeResultKey.value === key) {
    activeResultKey.value = completedTasks.value[0]?.key ?? "";
  }
}

function isPlatformUsed(platformId: string, currentKey: string) {
  return siteTasks.value.some((t) => t.platformId === platformId && t.key !== currentKey);
}

function onPlatformChange(task: BatchSiteTask) {
  task.status = "pending";
  task.result = null;
  task.errorMessage = undefined;
}

function resetTaskFiles(task: BatchSiteTask) {
  task.status = "pending";
  task.result = null;
  task.errorMessage = undefined;
}

function toUploadFile(file: File): UploadUserFile {
  return { name: file.name, uid: genFileId() };
}

function onSiteMemberChange(task: BatchSiteTask, file: UploadFile, fileList: UploadUserFile[]) {
  if (file.status !== "ready" || !file.raw) return;
  task.memberFile = file.raw;
  task.memberFileList = fileList.slice(-1);
  resetTaskFiles(task);
  void autoPreviewFromFirstFiles();
}

function onSiteMemberRemove(task: BatchSiteTask) {
  task.memberFile = null;
  task.memberFileList = [];
  resetTaskFiles(task);
}

function onSiteMemberExceed(task: BatchSiteTask, files: File[]) {
  const raw = files[0] as UploadRawFile;
  raw.uid = genFileId();
  task.memberFile = raw;
  task.memberFileList = [toUploadFile(raw)];
  resetTaskFiles(task);
  void autoPreviewFromFirstFiles();
}

function onSiteUnclaimedChange(task: BatchSiteTask, file: UploadFile, fileList: UploadUserFile[]) {
  if (file.status !== "ready" || !file.raw) return;
  task.unclaimedFile = file.raw;
  task.unclaimedFileList = fileList.slice(-1);
  resetTaskFiles(task);
  void previewUnclaimedFromFirst();
}

function onSiteUnclaimedRemove(task: BatchSiteTask) {
  task.unclaimedFile = null;
  task.unclaimedFileList = [];
  resetTaskFiles(task);
}

function onSiteUnclaimedExceed(task: BatchSiteTask, files: File[]) {
  const raw = files[0] as UploadRawFile;
  raw.uid = genFileId();
  task.unclaimedFile = raw;
  task.unclaimedFileList = [toUploadFile(raw)];
  resetTaskFiles(task);
}

function activityFilteredTiers(): string[] {
  const a = activity.value;
  const tiers = a?.periodFilteredTiers ?? [];
  return tiers.length ? tiers : [...DEFAULT_FILTERED_TIERS];
}

function syncExcludedTiersFromActivity() {
  memberMapping.excludedTiers = [...activityFilteredTiers()];
}

function refreshTierOptionsFromActivity() {
  tierOptions.value = Array.from(new Set([...DEFAULT_FILTERED_TIERS, ...activityFilteredTiers()]));
  const current = memberMapping.excludedTiers ?? [];
  const kept = current.filter((t) => tierOptions.value.includes(t));
  memberMapping.excludedTiers = kept.length ? kept : [...activityFilteredTiers()];
}

async function scanTierOptionsFromFile() {
  const file = previewMemberFile.value;
  if (!file || memberMapping.tierLevel < 0) {
    refreshTierOptionsFromActivity();
    return;
  }
  tierScanLoading.value = true;
  try {
    const { data } = await callbackApi.previewManualTierValues(
      file,
      memberMapping.headerRow,
      memberMapping.tierLevel,
    );
    tierOptions.value = Array.from(
      new Set([...DEFAULT_FILTERED_TIERS, ...activityFilteredTiers(), ...data]),
    );
    const current = memberMapping.excludedTiers ?? [];
    memberMapping.excludedTiers = current.filter((t) => tierOptions.value.includes(t));
    ElMessage.success(`已扫描层级选项 ${data.length} 个`);
  } catch {
    refreshTierOptionsFromActivity();
    ElMessage.warning("层级扫描失败");
  } finally {
    tierScanLoading.value = false;
  }
}

function resetMemberMapping() {
  Object.assign(memberMapping, defaultMemberMappingForDispatch("period_bonus"));
  syncExcludedTiersFromActivity();
  memberColumns.value = buildFallbackColumns(mappingColumnCount("period_bonus"));
  if (previewMemberFile.value) void previewMemberHeaders();
}

function resetUnclaimedMapping() {
  Object.assign(unclaimedMapping, { ...DEFAULT_UNCLAIMED_COLUMN_MAPPING, phoneNumber: -1 });
  unclaimedColumns.value = buildFallbackColumns(10);
}

function applySuggestedMemberMapping(cols: ManualColumnPreview[]) {
  const suggested = suggestMemberMappingFromColumns(cols, "period_bonus");
  if (suggested) Object.assign(memberMapping, suggested);
}

async function loadMemberColumnPreview(file: File): Promise<ManualColumnPreview[]> {
  const local = await previewLocalCSVColumns(file, memberMapping.headerRow);
  if (local?.length) return expandColumnsForMapping(local, "period_bonus");
  const { data } = await callbackApi.previewManualColumns(file, memberMapping.headerRow);
  if (data.length) return expandColumnsForMapping(data, "period_bonus");
  return buildFallbackColumns(mappingColumnCount("period_bonus"));
}

async function previewMemberHeaders() {
  const file = previewMemberFile.value;
  if (!file) return;
  memberPreviewLoading.value = true;
  try {
    const cols = await loadMemberColumnPreview(file);
    memberColumns.value = cols;
    applySuggestedMemberMapping(cols);
    ElMessage.success("表头已加载，请确认列映射");
  } catch {
    memberColumns.value = buildFallbackColumns(mappingColumnCount("period_bonus"));
    ElMessage.warning("表头预览失败");
  } finally {
    memberPreviewLoading.value = false;
  }
}

async function autoPreviewFromFirstFiles() {
  const file = previewMemberFile.value;
  if (!file) return;
  memberPreviewLoading.value = true;
  try {
    const cols = await loadMemberColumnPreview(file);
    memberColumns.value = cols;
    applySuggestedMemberMapping(cols);
  } catch {
    memberColumns.value = buildFallbackColumns(mappingColumnCount("period_bonus"));
  } finally {
    memberPreviewLoading.value = false;
  }
}

async function previewUnclaimedHeaders() {
  const file = previewUnclaimedFile.value;
  if (!file) return;
  unclaimedPreviewLoading.value = true;
  try {
    const local = await previewLocalCSVColumns(file, unclaimedMapping.headerRow);
    if (local?.length) {
      unclaimedColumns.value = local;
      return;
    }
    const { data } = await callbackApi.previewManualColumns(file, unclaimedMapping.headerRow);
    unclaimedColumns.value = data.length ? data : buildFallbackColumns(10);
  } catch {
    unclaimedColumns.value = buildFallbackColumns(10);
  } finally {
    unclaimedPreviewLoading.value = false;
  }
}

async function previewUnclaimedFromFirst() {
  if (previewUnclaimedFile.value) await previewUnclaimedHeaders();
}

function onMemberHeaderRowChange() {
  if (previewMemberFile.value) void previewMemberHeaders();
  else memberColumns.value = buildFallbackColumns(mappingColumnCount("period_bonus"));
}

function onUnclaimedHeaderRowChange() {
  if (previewUnclaimedFile.value) void previewUnclaimedHeaders();
  else unclaimedColumns.value = buildFallbackColumns(10);
}

async function downloadTemplate(type: "member" | "unclaimed") {
  try {
    const res = await callbackApi.downloadManualTemplate(type);
    const name =
      type === "unclaimed" ? "callback_unclaimed_template.xlsx" : "callback_member_template.xlsx";
    downloadBlob(res.data as Blob, name);
  } catch (e: any) {
    ElMessage.error(e.message || "下载失败");
  }
}

function resultTabLabel(task: BatchSiteTask) {
  const name = platformName(task.platformId) || "未命名站点";
  const n = task.result?.summary.bonusCount ?? 0;
  const bonus = task.result ? formatMoney(task.result.summary.totalBonus) : "0.00";
  return `${name}（派发 ${n} · ${bonus}）`;
}

function sanitizeFilename(name: string) {
  return name.replace(/[\\/:*?"<>|]/g, "_").trim() || "site";
}

const EXPORT_FILENAMES: Record<string, string> = {
  dispatch_bonus: "period_dispatch.xlsx",
  other: "period_profit.xlsx",
  excluded: "period_excluded.xlsx",
  unclaimed: "period_unclaimed.xlsx",
  all: "period_all.xlsx",
};

async function exportSiteResult(task: BatchSiteTask, exportType: string) {
  if (!task.result) return;
  try {
    const res = await callbackApi.exportManualResult(exportType, task.result);
    const site = sanitizeFilename(platformName(task.platformId));
    const base = EXPORT_FILENAMES[exportType] ?? `period_${exportType}.xlsx`;
    downloadBlob(res.data as Blob, `${site}_${base}`);
  } catch (e: any) {
    ElMessage.error(e.message || "导出失败");
  }
}

async function handleBatchProcess() {
  if (!canBatchProcess.value) {
    ElMessage.warning(
      needsUnclaimedFile.value
        ? "请为每个站点选择平台，并上传会员数据与未领名单"
        : "请为每个站点选择平台并上传会员数据",
    );
    return;
  }

  const dup = new Set<string>();
  for (const t of readyTasks.value) {
    if (dup.has(t.platformId)) {
      ElMessage.warning("存在重复站点，请每个平台只保留一行");
      return;
    }
    dup.add(t.platformId);
  }

  batchProcessing.value = true;
  let ok = 0;
  let fail = 0;

  const mapping = normalizeMemberMapping(memberMapping, "period_bonus");
  const unclaimedMap = { ...unclaimedMapping };

  for (const task of readyTasks.value) {
    task.status = "processing";
    task.errorMessage = undefined;
    try {
      const { data } = await callbackApi.processManualImport({
        dispatchType: "period_bonus",
        memberFile: task.memberFile!,
        unclaimedFile: task.unclaimedFile ?? undefined,
        memberMapping: mapping,
        unclaimedMapping: unclaimedMap,
      });
      task.result = data;
      task.status = "success";
      task.activeTab = "dispatch_bonus";
      ok++;
    } catch (e: any) {
      task.status = "error";
      task.errorMessage = e.message || "处理失败";
      task.result = null;
      fail++;
    }
  }

  batchProcessing.value = false;

  if (completedTasks.value.length) {
    activeResultKey.value = completedTasks.value[completedTasks.value.length - 1]!.key;
  }

  if (fail === 0) {
    ElMessage.success(`批量完成：${ok} 个站点全部成功`);
  } else {
    ElMessage.warning(`批量完成：成功 ${ok}，失败 ${fail}`);
  }
}

async function handleBatchExportAll() {
  const tasks = completedTasks.value;
  if (!tasks.length) return;
  batchExporting.value = true;
  try {
    for (const task of tasks) {
      await exportSiteResult(task, "all");
      await new Promise((r) => setTimeout(r, 300));
    }
    ElMessage.success(`已导出 ${tasks.length} 个站点的全部结果`);
  } finally {
    batchExporting.value = false;
  }
}

onMounted(async () => {
  await loadAll();
  try {
    const { data } = await callbackApi.getActivity();
    if (data) {
      ensureActivityManualRules(data);
      activity.value = data;
    }
  } catch {
    /* ignore */
  }
  refreshTierOptionsFromActivity();
  syncExcludedTiersFromActivity();
  if (enabledPlatforms.value.length && siteTasks.value.length === 0) {
    addSiteRow();
  }
});
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.form-row {
  margin-bottom: 8px;
  max-width: 720px;
}
.config-text {
  color: var(--el-text-color-regular);
}
.mapping-card {
  margin-top: 16px;
  margin-bottom: 16px;
}
.mapping-tip {
  margin-bottom: 12px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
  line-height: 1.5;
}
.queue-toolbar {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-bottom: 12px;
}
.site-table {
  margin-bottom: 16px;
}
.action-bar {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 8px;
}
.results-header {
  margin-bottom: 12px;
  font-size: 15px;
  font-weight: 600;
}
</style>

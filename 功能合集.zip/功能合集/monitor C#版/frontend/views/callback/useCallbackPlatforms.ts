import { computed, ref } from "vue";
import callbackApi, { type CallbackPlatform } from "@api/callback_api";

export function useCallbackPlatforms() {
  const platforms = ref<CallbackPlatform[]>([]);
  const loading = ref(false);
  const total = ref(0);

  const enabledPlatforms = computed(() =>
    platforms.value.filter((p) => p.enabled),
  );

  async function loadAll() {
    loading.value = true;
    try {
      const all: CallbackPlatform[] = [];
      let page = 1;
      while (true) {
        const { data } = await callbackApi.listPlatforms({
          page,
          pageSize: 200,
        });
        all.push(...(data.items || []));
        total.value = data.total || all.length;
        if (all.length >= total.value || !(data.items?.length)) break;
        page++;
      }
      platforms.value = all;
    } finally {
      loading.value = false;
    }
  }

  async function loadPage(page: number, pageSize: number, keyword?: string) {
    loading.value = true;
    try {
      const { data } = await callbackApi.listPlatforms({
        page,
        pageSize,
        keyword: keyword || undefined,
      });
      platforms.value = data.items || [];
      total.value = data.total || 0;
    } finally {
      loading.value = false;
    }
  }

  function platformName(id: string): string {
    return platforms.value.find((p) => p.id === id)?.name || id;
  }

  return {
    platforms,
    loading,
    total,
    enabledPlatforms,
    loadAll,
    loadPage,
    platformName,
  };
}

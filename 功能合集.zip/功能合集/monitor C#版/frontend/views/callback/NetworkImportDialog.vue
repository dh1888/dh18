<template>
  <el-dialog
    v-model="visible"
    :title="title"
    width="720px"
    destroy-on-close
    @closed="onClosed"
  >
    <el-alert
      type="info"
      :closable="false"
      show-icon
      class="import-tip"
      title="支持粘贴：Chrome「Copy as cURL」、Fetch 代码、完整请求 URL（可含 Authorization 头）"
    />
    <el-input
      v-model="pasteText"
      type="textarea"
      :rows="10"
      placeholder="粘贴浏览器 Network 面板复制的内容…"
      class="paste-area"
    />
    <div class="parse-actions">
      <el-button type="primary" @click="handleParse">自动提取</el-button>
      <span v-if="parsedList.length" class="parse-count">
        识别到 {{ parsedList.length }} 条请求
      </span>
    </div>

    <el-table v-if="parsedList.length" :data="parsedList" stripe max-height="320" class="preview-table">
      <el-table-column v-if="mode === 'platform'" label="站点名称" width="140">
        <template #default="{ row }">
          <el-input v-model="row.name" size="small" />
        </template>
      </el-table-column>
      <el-table-column prop="baseUrl" label="Base URL" show-overflow-tooltip min-width="160" />
      <el-table-column prop="tenantId" label="Tenant ID" width="100">
        <template #default="{ row }">
          <el-input v-model="row.tenantId" size="small" />
        </template>
      </el-table-column>
      <el-table-column prop="path" label="路径" show-overflow-tooltip width="140" />
      <el-table-column label="Token" width="80">
        <template #default="{ row }">
          <el-tag size="small" :type="row.token ? 'success' : 'info'">
            {{ row.token ? "已提取" : "无" }}
          </el-tag>
        </template>
      </el-table-column>
    </el-table>

    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button
        type="primary"
        :disabled="!parsedList.length"
        :loading="applying"
        @click="handleApply"
      >
        {{ applyLabel }}
      </el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { computed, ref, watch } from "vue";
import { ElMessage } from "element-plus";
import {
  parseNetworkPaste,
  type ParsedNetworkRequest,
  buildRequestParamsTemplate,
  defaultPaginationConfig,
  defaultResponseMapping,
} from "./networkParser";

export type PlatformImportRow = ParsedNetworkRequest & {
  name: string;
  enabled: boolean;
};

export type EndpointImportPayload = {
  path: string;
  httpMethod: string;
  code: string;
  name: string;
  requestParamsTemplate: string;
  responseMapping: string;
  paginationConfig: string;
  token?: string;
  baseUrl?: string;
  tenantId?: string;
};

const props = defineProps<{
  modelValue: boolean;
  mode: "platform" | "endpoint";
}>();

const emit = defineEmits<{
  "update:modelValue": [boolean];
  applyPlatform: [PlatformImportRow[]];
  applyEndpoint: [EndpointImportPayload];
}>();

const visible = computed({
  get: () => props.modelValue,
  set: (v) => emit("update:modelValue", v),
});

const title = computed(() =>
  props.mode === "platform" ? "从网络请求批量导入平台" : "从网络请求提取接口配置",
);

const applyLabel = computed(() =>
  props.mode === "platform" ? "批量创建平台" : "填入表单",
);

const pasteText = ref("");
const parsedList = ref<PlatformImportRow[]>([]);
const applying = ref(false);

watch(
  () => props.modelValue,
  (open) => {
    if (open) {
      pasteText.value = "";
      parsedList.value = [];
    }
  },
);

function handleParse() {
  if (!pasteText.value.trim()) {
    ElMessage.warning("请先粘贴内容");
    return;
  }
  const items = parseNetworkPaste(pasteText.value);
  if (!items.length) {
    ElMessage.warning("未能识别有效请求，请确认粘贴的是 cURL 或 URL");
    return;
  }
  parsedList.value = items.map((item) => ({
    ...item,
    name: item.suggestedName,
    enabled: true,
  }));
}

function handleApply() {
  if (!parsedList.value.length) return;
  applying.value = true;
  try {
    if (props.mode === "platform") {
      const invalid = parsedList.value.find(
        (r) => !r.name?.trim() || !r.baseUrl || !r.tenantId || !r.token,
      );
      if (invalid) {
        ElMessage.warning("每条平台需有名称、Base URL、Tenant ID 和 Token");
        return;
      }
      emit("applyPlatform", parsedList.value);
    } else {
      const first = parsedList.value[0];
      const code = first.suggestedEndpointCode || "vip.list";
      emit("applyEndpoint", {
        path: first.path,
        httpMethod: first.method,
        code,
        name: code,
        requestParamsTemplate: buildRequestParamsTemplate(first),
        responseMapping: defaultResponseMapping(code),
        paginationConfig: defaultPaginationConfig(),
        token: first.token,
        baseUrl: first.baseUrl,
        tenantId: first.tenantId,
      });
    }
    visible.value = false;
  } finally {
    applying.value = false;
  }
}

function onClosed() {
  pasteText.value = "";
  parsedList.value = [];
}
</script>

<style scoped>
.import-tip {
  margin-bottom: 12px;
}
.paste-area {
  margin-bottom: 12px;
}
.parse-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
.parse-count {
  color: var(--el-text-color-secondary);
  font-size: 13px;
}
.preview-table {
  width: 100%;
}
</style>

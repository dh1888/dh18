<template>
  <div class="recordings-page">
    <!-- ========== 统计卡片区 ========== -->
    <el-row :gutter="20" class="stats-row">
      <el-col :xs="12" :sm="6" v-for="stat in statsCards" :key="stat.title">
        <el-card class="stat-card" shadow="hover" @click="stat.onClick">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-title">{{ stat.title }}</div>
              <div class="stat-value">{{ stat.value }}</div>
              <div class="stat-trend">
                <el-icon><component :is="stat.icon" /></el-icon>
                <span>{{ stat.subText }}</span>
              </div>
            </div>
            <div class="stat-icon" :style="{ background: stat.gradient }">
              <el-icon :size="28" color="#fff"
                ><component :is="stat.iconBg"
              /></el-icon>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 录屏按需查看说明 / 上传进度（同一区域） -->
    <div class="workflow-hint">
      <el-alert
        v-if="!showUploadProgress"
        type="info"
        :closable="false"
        show-icon
      >
        <template #title>录屏按需查看</template>
        <div class="workflow-hint-text">
          录屏默认保存在员工电脑本地。请先选择<strong>员工</strong>和<strong>时间范围</strong>，点击「搜索」查看已上传片段；若无数据，点击「请求上传视频」由客户端自动上传后再刷新。
        </div>
      </el-alert>

      <el-alert
        v-else
        :type="uploadAlertType"
        :closable="false"
        show-icon
      >
        <template #title>录屏上传任务</template>
        <div class="upload-hint-line">
          <el-tag :type="uploadTaskTagType" size="small" class="upload-hint-tag">
            {{ uploadTaskStatusLabel }}
          </el-tag>
          <span class="upload-hint-progress-text">
            {{ activeUploadTask?.progress ?? 0 }}%
          </span>
          <el-progress
            class="upload-hint-progress"
            :percentage="activeUploadTask?.progress ?? 0"
            :status="uploadProgressStatus"
            :stroke-width="8"
            :show-text="false"
            striped
            striped-flow
          />
          <span class="upload-hint-result" :title="uploadResultText">
            {{ uploadResultText }}
          </span>
        </div>
      </el-alert>
    </div>

    <!-- ========== 筛选卡片 ========== -->
    <el-card class="filter-card card-hover" shadow="hover">
      <el-form :inline="true" :model="filters" class="filter-form">
        <el-form-item label="员工">
          <el-select
            v-model="filters.deviceId"
            placeholder="选择员工查看录屏"
            clearable
            filterable
            style="width: 240px"
          >
            <el-option
              v-for="device in devices"
              :key="device.id"
              :label="getDeviceLabel(device)"
              :value="device.id"
            >
              <div class="employee-option">
                <div class="info">
                  <span class="name">{{
                    device.employeeName || "未绑定员工"
                  }}</span>
                  <span class="detail">{{
                    device.employeeNumber || device.hostname
                  }}</span>
                </div>
              </div>
            </el-option>
          </el-select>
        </el-form-item>

        <!-- ✅ 日期时间范围选择器（手动控制，不自动搜索） -->
        <el-form-item label="时间范围">
          <el-date-picker
            v-model="dateTimeRange"
            type="datetimerange"
            range-separator="至"
            start-placeholder="开始时间"
            end-placeholder="结束时间"
            format="YYYY-MM-DD HH:mm:ss"
            value-format="YYYY-MM-DD HH:mm:ss"
            :shortcuts="dateTimeShortcuts"
            style="width: 500px"
          />
        </el-form-item>

        <el-select
          v-model="filters.uploadStatus"
          placeholder="状态筛选"
          clearable
          style="width: 110px"
        >
          <el-option label="已上传" value="uploaded" />
          <el-option label="未上传" value="pending" />
        </el-select>

        <el-form-item>
          <el-button
            type="primary"
            @click="handleSearch"
            :loading="searchLoading"
            class="search-btn"
          >
            <el-icon><Search /></el-icon>
            搜索
          </el-button>
          <el-button
            type="warning"
            @click="requestUpload"
            :loading="requestUploading"
            :disabled="!filters.deviceId || !dateTimeRange"
          >
            <el-icon><Upload /></el-icon>
            请求上传视频
          </el-button>
          <el-button
            @click="handleRefresh"
            :loading="loading"
            class="refresh-btn"
          >
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
          <el-button @click="handleReset" class="reset-btn">
            <el-icon><RefreshLeft /></el-icon>
            重置筛选
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- ========== 表格卡片 ========== -->
    <el-card class="table-card card-hover" shadow="hover">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <el-icon><List /></el-icon>
            <span>录制文件列表</span>
            <el-tag
              v-if="pagination.total"
              type="info"
              size="small"
              class="total-tag"
            >
              共 {{ formatNumber(pagination.total) }} 条
            </el-tag>
          </div>
          <div class="header-right">
            <div class="selection-area">
              <el-checkbox
                v-model="selectAll"
                @change="handleSelectAllChange"
                :indeterminate="isIndeterminate"
                class="select-all"
              >
                全选 ({{ displayRecordings.length }})
              </el-checkbox>
              <el-badge
                :value="selectedRows.length"
                :hidden="selectedRows.length === 0"
                type="danger"
              >
                <el-button
                  type="danger"
                  plain
                  size="small"
                  :disabled="selectedRows.length === 0"
                  @click="handleBatchDelete"
                  :loading="batchDeleteLoading"
                  v-permission="'recording:delete'"
                >
                  <el-icon><Delete /></el-icon>
                  批量删除
                </el-button>
              </el-badge>
              <el-tooltip content="导出当前数据" placement="top">
                <el-button
                  type="success"
                  plain
                  size="small"
                  @click="handleExport"
                  :loading="exportLoading"
                >
                  <el-icon><Download /></el-icon>
                  导出CSV
                </el-button>
              </el-tooltip>
            </div>
          </div>
        </div>
      </template>

      <el-table
        :data="displayRecordings"
        v-loading="loading"
        stripe
        :row-class-name="tableRowClassName"
        class="custom-table"
        style="width: 100%"
        @selection-change="handleSelectionChange"
        ref="tableRef"
      >
        <el-table-column type="selection" width="55" fixed="left" />

        <el-table-column
          prop="employeeName"
          label="员工信息"
          min-width="180"
          fixed="left"
        >
          <template #default="{ row }">
            <div class="employee-cell">
              <el-avatar
                :size="36"
                :src="getEmployeeAvatar(row.deviceId)"
                class="employee-avatar"
              />
              <div class="employee-info">
                <div class="employee-name">
                  {{ getEmployeeName(row.deviceId) }}
                </div>
                <div class="employee-dept">
                  {{ getEmployeeDept(row.deviceId) }}
                </div>
              </div>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="deviceId" label="设备ID" width="130">
          <template #default="{ row }">
            <div class="device-cell">
              <el-icon><Monitor /></el-icon>
              <el-tooltip :content="row.deviceId" placement="top">
                <span class="device-id"
                  >{{ row.deviceId?.slice(0, 8) || "--" }}...</span
                >
              </el-tooltip>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="startTime" label="开始时间" min-width="160">
          <template #default="{ row }">
            <div class="time-cell">
              <div class="time-date">{{ formatDate(row.startTime) }}</div>
              <div class="time-range">{{ formatTimeOnly(row.startTime) }}</div>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="endTime" label="结束时间" min-width="160">
          <template #default="{ row }">
            <div class="time-cell" v-if="row.endTime">
              <div class="time-date">{{ formatDate(row.endTime) }}</div>
              <div class="time-range">{{ formatTimeOnly(row.endTime) }}</div>
            </div>
            <el-tag v-else type="info" size="small" effect="light"
              >录制中</el-tag
            >
          </template>
        </el-table-column>

        <el-table-column
          prop="duration"
          label="时长"
          width="100"
          align="center"
        >
          <template #default="{ row }">
            <div class="duration-cell">
              <el-icon><Timer /></el-icon>
              <span :class="getDurationClass(row.duration)">{{
                formatDuration(row.duration)
              }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column
          prop="fileSize"
          label="文件大小"
          width="110"
          align="right"
        >
          <template #default="{ row }">
            <div class="size-cell">
              <span class="size-value">{{ formatBytes(row.fileSize) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="status" label="状态" width="90" align="center">
          <template #default="{ row }">
            <div class="status-cell">
              <span
                class="status-dot"
                :class="getStatusClass(row.status)"
              ></span>
              <span>{{ getStatusText(row.status) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="操作" fixed="right" width="260" align="center">
          <template #default="{ row }">
            <div class="action-buttons">
              <el-tooltip content="播放" placement="top">
                <el-button
                  v-permission="'recording:play'"
                  link
                  type="primary"
                  @click="handlePlayWithContinuity(row, false)"
                  class="action-btn"
                >
                  <el-icon><VideoPlay /></el-icon>
                  <span>播放</span>
                </el-button>
              </el-tooltip>

              <el-tooltip content="连续播放" placement="top">
                <el-button
                  v-permission="'recording:play'"
                  link
                  type="success"
                  @click="handlePlayWithContinuity(row, true)"
                  class="action-btn"
                >
                  <el-icon><Connection /></el-icon>
                  <span>连续播放</span>
                </el-button>
              </el-tooltip>

              <el-tooltip content="下载" placement="top">
                <el-button
                  v-permission="'recording:export'"
                  link
                  type="primary"
                  @click="handleDownload(row)"
                  class="action-btn"
                >
                  <el-icon><Download /></el-icon>
                  <span>下载</span>
                </el-button>
              </el-tooltip>

              <el-button
                link
                type="danger"
                class="action-btn"
                v-permission="'recording:delete'"
                :disabled="!row.uploaded"
                @click="confirmDelete(row)"
              >
                <el-icon><Delete /></el-icon>
                <span>删除</span>
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页组件 -->
      <div class="pagination-wrapper" v-if="pagination.total > 0">
        <el-pagination
          :current-page="pagination.page"
          :page-size="pagination.pageSize"
          :total="pagination.total"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          background
          @current-change="handlePageChange"
          @size-change="handlePageSizeChange"
        />
      </div>

      <!-- 空状态 -->
      <el-empty
        v-if="!loading && displayRecordings.length === 0"
        :description="emptyDescription"
        :image-size="120"
      >
        <template #image>
          <el-icon :size="80" color="#c0c4cc"><VideoCamera /></el-icon>
        </template>
        <div class="empty-actions">
          <el-button
            v-if="filters.deviceId && dateTimeRange"
            type="warning"
            @click="requestUpload"
            :loading="requestUploading"
          >
            <el-icon><Upload /></el-icon>
            请求上传视频
          </el-button>
          <el-button type="primary" @click="handleReset">重置筛选</el-button>
        </div>
      </el-empty>
    </el-card>

    <!-- ========== 播放器对话框 ========== -->
    <el-dialog
      v-model="playerVisible"
      title="录屏播放"
      width="920px"
      @close="handleDialogClose"
      class="player-dialog"
      destroy-on-close
    >
      <div class="player-toolbar" v-if="isPlaylistMode">
        <div class="playlist-info">
          <el-tag type="info" size="small" effect="dark">
            <el-icon><VideoCamera /></el-icon>
            连续播放模式
          </el-tag>
          <el-tag type="primary" size="small" class="playlist-progress">
            {{ currentPlayIndex + 1 }} / {{ playlist.length }}
          </el-tag>
          <el-progress
            :percentage="((currentPlayIndex + 1) / playlist.length) * 100"
            :show-text="false"
            :stroke-width="4"
            class="playlist-progress-bar"
          />
        </div>
        <div class="player-controls">
          <el-switch
            v-model="autoPlayNext"
            active-text="自动连播"
            inactive-text="单曲播放"
            @change="onAutoPlayChange"
          />
          <el-button
            v-if="playlist.length > 1"
            size="small"
            @click="playPrevious"
            :disabled="currentPlayIndex === 0"
          >
            <el-icon><ArrowLeft /></el-icon>
            上一个
          </el-button>
          <el-button
            v-if="playlist.length > 1"
            size="small"
            type="primary"
            @click="playNext"
            :disabled="currentPlayIndex >= playlist.length - 1"
          >
            下一个
            <el-icon><ArrowRight /></el-icon>
          </el-button>
        </div>
      </div>

      <div class="player-info" v-if="currentPlaying">
        <el-row :gutter="16">
          <el-col :span="6">
            <div class="info-item">
              <div class="info-label">员工姓名</div>
              <div class="info-value">
                {{ getEmployeeName(currentPlaying.deviceId) }}
              </div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="info-item">
              <div class="info-label">开始时间</div>
              <div class="info-value">
                {{ formatDateTime(currentPlaying.startTime) }}
              </div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="info-item">
              <div class="info-label">结束时间</div>
              <div class="info-value">
                {{
                  currentPlaying.endTime
                    ? formatDateTime(currentPlaying.endTime)
                    : "录制中"
                }}
              </div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="info-item">
              <div class="info-label">时长 / 大小</div>
              <div class="info-value">
                {{ formatDuration(currentPlaying.duration) }} ·
                {{ formatBytes(currentPlaying.fileSize) }}
              </div>
            </div>
          </el-col>
        </el-row>
      </div>

      <div class="video-container">
        <div v-if="videoLoading" class="video-loading">
          <el-icon class="is-loading" :size="32"><Refresh /></el-icon>
          <span>正在加载视频...</span>
        </div>
        <div v-else-if="videoError" class="video-error">
          <el-icon :size="40" color="#f56c6c"><VideoCamera /></el-icon>
          <p>{{ videoError }}</p>
          <el-button type="primary" size="small" @click="retryPlayback">
            重新加载
          </el-button>
        </div>
        <video
          v-show="playerVisible && playUrl && !videoError"
          ref="videoRef"
          class="video-player"
          controls
          autoplay
          preload="metadata"
          :src="playUrl"
          @ended="onVideoEnded"
          @error="onVideoError"
          @loadeddata="onVideoLoaded"
          @waiting="videoLoading = true"
          @canplay="videoLoading = false"
        />
      </div>

      <template #footer>
        <div class="dialog-footer">
          <el-button @click="playerVisible = false">关闭</el-button>
          <el-button
            v-if="isPlaylistMode && playlist.length > 1"
            v-permission="'recording:export'"
            type="primary"
            @click="downloadAllVideos"
            :loading="downloadingAll"
          >
            <el-icon><Download /></el-icon>
            下载全部 ({{ playlist.length }}个)
          </el-button>
          <el-button
            v-permission="'recording:export'"
            type="primary"
            @click="downloadCurrentVideo"
            v-else-if="currentPlaying"
          >
            <el-icon><Download /></el-icon>
            下载视频
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, onUnmounted } from "vue";
import { useRoute } from "vue-router";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Refresh,
  Search,
  Delete,
  Download,
  VideoPlay,
  VideoCamera,
  Monitor,
  List,
  Timer,
  RefreshLeft,
  Connection,
  ArrowLeft,
  ArrowRight,
  Upload,
} from "@element-plus/icons-vue";
import { recordingApi, deviceApi, taskApi, getRecordingStreamUrl, getRecordingDownloadUrl } from "@api/index";
import type { Recording, Device, DeviceTask } from "@api/types";
import { useUserStore } from "@store/user";
import {
  formatDate,
  formatTime as formatTimeOnly,
  formatDateTime,
  localToUTC,
} from "@api/format";
import dayjs from "dayjs";

const route = useRoute();
const userStore = useUserStore();
const loading = ref(false);
const searchLoading = ref(false);
const exportLoading = ref(false);
const batchDeleteLoading = ref(false);
const recordings = ref<Recording[]>([]);
const devices = ref<Device[]>([]);
const playerVisible = ref(false);
const playUrl = ref("");
const videoRef = ref<HTMLVideoElement>();
const currentPlaying = ref<Recording | null>(null);
const tableRef = ref();
const requestUploading = ref(false);
const uploadStatusText = ref("");
const activeUploadTask = ref<DeviceTask | null>(null);
const videoLoading = ref(false);
const videoError = ref("");

const recordingStats = ref({
  total: 0,
  totalSize: 0,
  avgSize: 0,
  todayCount: 0,
});

let uploadPollTimer: ReturnType<typeof setInterval> | null = null;
let uploadPollAttempts = 0;
let finishedUploadTaskId: string | null = null;
const UPLOAD_POLL_MAX_ATTEMPTS = 2000;

const TASK_STATUS_LABELS: Record<string, string> = {
  pending: "等待客户端",
  running: "上传中",
  completed: "已完成",
  failed: "失败",
  cancelled: "已取消",
};

const uploadTaskStatusLabel = computed(() => {
  if (!activeUploadTask.value) return "准备中";
  return TASK_STATUS_LABELS[activeUploadTask.value.status] || activeUploadTask.value.status;
});

const uploadTaskTagType = computed(() => {
  const status = activeUploadTask.value?.status;
  if (!status) return "info";
  if (status === "completed") return "success";
  if (status === "failed") return "danger";
  if (status === "cancelled") return "info";
  if (status === "running") return "warning";
  return "info";
});

const uploadProgressStatus = computed(() => {
  const status = activeUploadTask.value?.status;
  if (status === "completed") return "success";
  if (status === "failed") return "exception";
  return undefined;
});

const showUploadProgress = computed(
  () => requestUploading.value || activeUploadTask.value !== null,
);

const uploadAlertType = computed(() => {
  const status = activeUploadTask.value?.status;
  if (status === "completed") return "success";
  if (status === "failed") return "error";
  if (status === "running") return "warning";
  return "info";
});

const uploadResultText = computed(
  () =>
    activeUploadTask.value?.result ||
    uploadStatusText.value ||
    "正在创建上传任务，请稍候...",
);

// ========== 连续播放相关变量 ==========
const playlist = ref<Recording[]>([]);
const currentPlayIndex = ref(0);
const isPlaylistMode = ref(false);
const autoPlayNext = ref(true);
const downloadingAll = ref(false);

let isPlayerClosing = false;

// 多选相关
const selectedRows = ref<Recording[]>([]);
const selectAll = ref(false);
const isIndeterminate = ref(false);

// ✅ 日期时间范围选择器
const dateTimeRange = ref<[string, string] | null>(null);

// 筛选条件
const filters = reactive({
  deviceId: (route.query.deviceId as string) || "",
  startTime: "",
  endTime: "",
  uploadStatus: "",
});

const pagination = reactive({
  page: 1,
  pageSize: 20,
  total: 0,
});

// ========== 状态判断函数 ==========
const isUploaded = (status?: string): boolean => {
  return (
    status === "completed" || status === "uploaded" || status === "success"
  );
};

const getStatusClass = (status?: string): string => {
  return isUploaded(status) ? "uploaded" : "pending";
};

const getStatusText = (status?: string): string => {
  if (isUploaded(status)) return "已上传";
  if (status === "uploading") return "上传中";
  if (status === "failed") return "失败";
  return "未上传";
};

// ========== 统计卡片数据 ==========
const statsCards = computed(() => [
  {
    title: "总录制数",
    value: formatNumber(recordingStats.value.total || pagination.total),
    subText: filters.deviceId ? "当前筛选范围" : "全部录制",
    icon: "Monitor",
    iconBg: "VideoCamera",
    gradient: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    onClick: () => handleSearch(),
  },
  {
    title: "总存储量",
    value: formatBytes(recordingStats.value.totalSize),
    subText: "占用空间",
    icon: "Monitor",
    iconBg: "Monitor",
    gradient: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
    onClick: () => {},
  },
  {
    title: "今日新增",
    value: formatNumber(recordingStats.value.todayCount),
    subText: "今天上传",
    icon: "Monitor",
    iconBg: "Monitor",
    gradient: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
    onClick: () => {},
  },
  {
    title: "平均大小",
    value: formatBytes(Math.round(recordingStats.value.avgSize || 0)),
    subText: "单段录屏",
    icon: "Monitor",
    iconBg: "Monitor",
    gradient: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
    onClick: () => {},
  },
]);

const emptyDescription = computed(() => {
  if (!filters.deviceId) {
    return "请先选择员工，再选择时间范围进行搜索";
  }
  if (!dateTimeRange.value) {
    return "请选择时间范围后搜索，或请求客户端上传该时段录屏";
  }
  return "该时段暂无已上传录屏，可点击「请求上传视频」从员工电脑拉取";
});

// ========== 计算属性 ==========
// displayRecordings 计算属性
const displayRecordings = computed(() => {
  let result = recordings.value.map((r) => ({
    ...r,
    // 使用 uploaded 字段（布尔值）生成 status
    status: r.uploaded ? "uploaded" : "pending",
  }));

  if (filters.uploadStatus === "uploaded") {
    result = result.filter((r) => r.status === "uploaded");
  } else if (filters.uploadStatus === "pending") {
    result = result.filter((r) => r.status === "pending");
  }
  return result;
});

const clearUploadPoll = () => {
  if (uploadPollTimer) {
    clearInterval(uploadPollTimer);
    uploadPollTimer = null;
  }
  uploadPollAttempts = 0;
};

const formatTaskStatusText = (task: DeviceTask) => {
  const label = TASK_STATUS_LABELS[task.status] || task.status;
  return `${label} · ${task.progress}%${task.result ? ` · ${task.result}` : ""}`;
};

const isTerminalTaskStatus = (status: string) =>
  ["completed", "failed", "cancelled"].includes(status);

const finishUploadTask = async (task: DeviceTask) => {
  if (finishedUploadTaskId === task.id) {
    applyTaskUpdate(task);
    return;
  }
  finishedUploadTaskId = task.id;

  clearUploadPoll();
  requestUploading.value = false;
  activeUploadTask.value = { ...task };
  uploadStatusText.value = formatTaskStatusText(task);

  await Promise.all([loadRecordings(), loadStats()]);

  if (task.status === "completed") {
    ElMessage.success(task.result || "录屏上传完成，可以播放查看");
    window.setTimeout(() => {
      if (activeUploadTask.value?.id === task.id) {
        uploadStatusText.value = "";
        activeUploadTask.value = null;
      }
    }, 8000);
  } else if (task.status === "failed") {
    ElMessage.error(task.result || "录屏上传失败");
  } else if (task.status === "cancelled") {
    ElMessage.info(task.result || "上传任务已取消");
  }
};

const applyTaskUpdate = (task: DeviceTask) => {
  activeUploadTask.value = task;
  uploadStatusText.value = formatTaskStatusText(task);
};

const pollUploadTask = async (taskId: string): Promise<boolean> => {
  try {
    const { data } = await taskApi.get(taskId);
    applyTaskUpdate(data);

    if (isTerminalTaskStatus(data.status)) {
      await finishUploadTask(data);
      return true;
    }
    return false;
  } catch (error: any) {
    uploadStatusText.value = error.message || "查询任务状态失败";
    return false;
  }
};

const startUploadTaskPolling = (taskId: string) => {
  clearUploadPoll();
  uploadPollAttempts = 0;

  uploadPollTimer = window.setInterval(async () => {
    uploadPollAttempts += 1;

    const done = await pollUploadTask(taskId);
    if (done) return;

    if (uploadPollAttempts >= UPLOAD_POLL_MAX_ATTEMPTS) {
      clearUploadPoll();
      requestUploading.value = false;
      uploadStatusText.value =
        "任务轮询超时，请确认员工电脑在线后手动刷新";
      ElMessage.info("任务等待超时，请稍后手动刷新");
    }
  }, 2000);
};

const onTaskNotification = (event: Event) => {
  const detail = (event as CustomEvent).detail as {
    type?: string;
    taskId?: string;
    status?: string;
    progress?: number;
    result?: string;
  };

  if (!activeUploadTask.value || detail.taskId !== activeUploadTask.value.id) {
    return;
  }

  const nextTask: DeviceTask = {
    ...activeUploadTask.value,
    status: detail.status || activeUploadTask.value.status,
    progress:
      typeof detail.progress === "number"
        ? detail.progress
        : activeUploadTask.value.progress,
    result:
      detail.result !== undefined ? detail.result : activeUploadTask.value.result,
  };

  applyTaskUpdate(nextTask);

  if (detail.status && isTerminalTaskStatus(detail.status)) {
    void finishUploadTask(nextTask);
  }
};

const loadStats = async () => {
  try {
    const params: Record<string, string> = {};
    if (filters.deviceId) params.deviceId = filters.deviceId;
    if (filters.startTime) params.startTime = filters.startTime;
    if (filters.endTime) params.endTime = filters.endTime;

    const { data } = await recordingApi.getStats(params);
    recordingStats.value = {
      total: data.total ?? 0,
      totalSize: data.totalSize ?? 0,
      avgSize: data.avgSize ?? 0,
      todayCount: data.todayCount ?? 0,
    };
  } catch {
    // 统计失败不影响列表展示
  }
};

// ========== 快捷选项（日期时间） ==========
const dateTimeShortcuts = [
  {
    text: "今日",
    value: () => {
      const start = dayjs().startOf("day").format("YYYY-MM-DD HH:mm:ss");
      const end = dayjs().endOf("day").format("YYYY-MM-DD HH:mm:ss");
      return [start, end];
    },
  },
  {
    text: "昨日",
    value: () => {
      const start = dayjs()
        .subtract(1, "day")
        .startOf("day")
        .format("YYYY-MM-DD HH:mm:ss");
      const end = dayjs()
        .subtract(1, "day")
        .endOf("day")
        .format("YYYY-MM-DD HH:mm:ss");
      return [start, end];
    },
  },
  {
    text: "本周",
    value: () => {
      const start = dayjs().startOf("week").format("YYYY-MM-DD HH:mm:ss");
      const end = dayjs().endOf("day").format("YYYY-MM-DD HH:mm:ss");
      return [start, end];
    },
  },
  {
    text: "本月",
    value: () => {
      const start = dayjs().startOf("month").format("YYYY-MM-DD HH:mm:ss");
      const end = dayjs().endOf("day").format("YYYY-MM-DD HH:mm:ss");
      return [start, end];
    },
  },
  {
    text: "近7天",
    value: () => {
      const start = dayjs()
        .subtract(6, "day")
        .startOf("day")
        .format("YYYY-MM-DD HH:mm:ss");
      const end = dayjs().endOf("day").format("YYYY-MM-DD HH:mm:ss");
      return [start, end];
    },
  },
  {
    text: "近30天",
    value: () => {
      const start = dayjs()
        .subtract(29, "day")
        .startOf("day")
        .format("YYYY-MM-DD HH:mm:ss");
      const end = dayjs().endOf("day").format("YYYY-MM-DD HH:mm:ss");
      return [start, end];
    },
  },
];

// ========== 工具函数 ==========
const formatNumber = (num: number) => {
  if (num >= 10000) return (num / 10000).toFixed(1) + "w";
  return num.toString();
};

const formatBytes = (bytes: number) => {
  if (!bytes || bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
};

const formatDuration = (seconds?: number) => {
  if (!seconds) return "--";
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m ${secs}s`;
  return `${secs}s`;
};

const getDurationClass = (seconds?: number) => {
  if (!seconds) return "";
  if (seconds > 3600) return "duration-long";
  if (seconds > 1800) return "duration-medium";
  return "duration-short";
};

const tableRowClassName = ({ row }: { row: Recording }) => {
  if (!isUploaded(row.status)) return "pending-row";
  return "";
};

const getDeviceLabel = (device: Device) => {
  if (device.employeeName) {
    return `${device.employeeName} (${device.employeeNumber || "未设置工号"})`;
  }
  return device.hostname;
};

const getEmployeeName = (deviceId: string) => {
  const device = devices.value.find((d) => d.id === deviceId);
  if (device?.employeeName) return device.employeeName;
  return device?.hostname?.slice(0, 12) || "未知设备";
};

const getEmployeeDept = (deviceId: string) => {
  const device = devices.value.find((d) => d.id === deviceId);
  return device?.employeeNumber || deviceId?.slice(0, 8) || "--";
};

const getEmployeeAvatar = (deviceId: string) => {
  const name = getEmployeeName(deviceId);
  return `https://ui-avatars.com/api/?background=409eff&color=fff&size=36&rounded=true&bold=true&length=1&name=${encodeURIComponent(name.charAt(0))}`;
};

// ========== 多选处理 ==========
const handleSelectionChange = (rows: Recording[]) => {
  selectedRows.value = rows;
  selectAll.value =
    rows.length === displayRecordings.value.length &&
    displayRecordings.value.length > 0;
  isIndeterminate.value =
    rows.length > 0 && rows.length < displayRecordings.value.length;
};

const handleSelectAllChange = (val: boolean) => {
  if (tableRef.value) {
    if (val) {
      displayRecordings.value.forEach((row: Recording) => {
        tableRef.value.toggleRowSelection(row, true);
      });
    } else {
      tableRef.value.clearSelection();
    }
  }
};

// ========== ✅ 核心方法：手动搜索（点击搜索按钮时调用） ==========
const handleSearch = async () => {
  if (dateTimeRange.value && dateTimeRange.value[0] && dateTimeRange.value[1]) {
    filters.startTime = localToUTC(dateTimeRange.value[0]);
    filters.endTime = localToUTC(dateTimeRange.value[1]);
  } else {
    filters.startTime = "";
    filters.endTime = "";
  }
  pagination.page = 1;
  await Promise.all([loadRecordings(), loadStats()]);
};

// ========== ✅ 核心方法：请求上传视频（点击请求上传按钮时调用） ==========
const requestUpload = async () => {
  if (!filters.deviceId) {
    ElMessage.warning("请先选择员工");
    return;
  }

  if (
    !dateTimeRange.value ||
    !dateTimeRange.value[0] ||
    !dateTimeRange.value[1]
  ) {
    ElMessage.warning("请先选择时间范围");
    return;
  }

  requestUploading.value = true;
  uploadStatusText.value = "正在创建上传任务...";
  clearUploadPoll();
  activeUploadTask.value = null;
  finishedUploadTaskId = null;

  try {
    const startTimeUTC = localToUTC(dateTimeRange.value[0]);
    const endTimeUTC = localToUTC(dateTimeRange.value[1]);

    const { data: task } = await taskApi.create({
      deviceId: filters.deviceId,
      type: "upload_recordings",
      startTime: startTimeUTC,
      endTime: endTimeUTC,
    });

    applyTaskUpdate(task);
    ElMessage.success("已创建上传任务，正在等待客户端处理");

    const done = await pollUploadTask(task.id);
    if (!done) {
      startUploadTaskPolling(task.id);
    }
  } catch (error: any) {
    uploadStatusText.value = "";
    activeUploadTask.value = null;
    ElMessage.error(error.message || "请求上传失败");
    requestUploading.value = false;
  }
};

// ========== 数据加载 ==========
const loadDevices = async () => {
  try {
    const { data } = await deviceApi.list({ page: 1, pageSize: 1000 });
    devices.value = data.items || [];
  } catch (error) {
    console.error("Load devices error:", error);
  }
};

const loadRecordings = async () => {
  loading.value = true;
  try {
    const params: any = {
      page: pagination.page,
      pageSize: pagination.pageSize,
    };
    if (filters.deviceId) params.deviceId = filters.deviceId;
    if (filters.startTime) params.startTime = filters.startTime;
    if (filters.endTime) params.endTime = filters.endTime;

    const { data } = await recordingApi.list(params);

    recordings.value = (data.items || []).map((r: Recording) => {
      let duration = 0;
      if (r.startTime && r.endTime) {
        const start = new Date(r.startTime).getTime();
        const end = new Date(r.endTime).getTime();
        duration = Math.floor((end - start) / 1000);
      }
      return {
        ...r,
        duration,
        status: r.uploaded ? "uploaded" : "pending",
      };
    });

    pagination.total = data.total || 0;

    // 重置选中状态
    selectedRows.value = [];
    selectAll.value = false;
    isIndeterminate.value = false;
    if (tableRef.value) {
      tableRef.value.clearSelection();
    }
  } catch (error: any) {
    ElMessage.error(error.message || "加载录制列表失败");
  } finally {
    loading.value = false;
  }
};

const handleReset = () => {
  clearUploadPoll();
  activeUploadTask.value = null;
  uploadStatusText.value = "";
  requestUploading.value = false;
  finishedUploadTaskId = null;
  filters.deviceId = "";
  filters.uploadStatus = "";
  dateTimeRange.value = null;
  filters.startTime = "";
  filters.endTime = "";
  pagination.page = 1;
  loadRecordings();
  ElMessage.success("已重置筛选条件");
};

const handleRefresh = async () => {
  await Promise.all([loadRecordings(), loadStats()]);
};

// 分页处理
const handlePageChange = (page: number) => {
  pagination.page = page;
  loadRecordings();
};

const handlePageSizeChange = (size: number) => {
  pagination.pageSize = size;
  pagination.page = 1;
  loadRecordings();
};

// ========== 连续播放核心方法 ==========
const getAllRecordingsForPlaylist = async (): Promise<Recording[]> => {
  try {
    const params: any = {
      page: 1,
      pageSize: 1000,
    };
    if (filters.deviceId) params.deviceId = filters.deviceId;
    if (filters.startTime) params.startTime = filters.startTime;
    if (filters.endTime) params.endTime = filters.endTime;

    const { data } = await recordingApi.list(params);

    // ✅ 计算 duration
    let items = (data.items || []).map((r: Recording) => {
      let duration = 0;
      if (r.startTime && r.endTime) {
        const start = new Date(r.startTime).getTime();
        const end = new Date(r.endTime).getTime();
        duration = Math.floor((end - start) / 1000);
      }
      return {
        ...r,
        duration,
        status: r.uploaded ? "uploaded" : "pending",
      };
    });

    items.sort(
      (a: Recording, b: Recording) =>
        new Date(a.startTime).getTime() - new Date(b.startTime).getTime(),
    );

    return items;
  } catch (error) {
    console.error("获取播放列表失败:", error);
    return [];
  }
};

const setPlaybackSource = async (recording: Recording) => {
  videoError.value = "";
  videoLoading.value = true;
  try {
    playUrl.value = await getRecordingStreamUrl(recording.id);
  } catch (error: any) {
    videoLoading.value = false;
    videoError.value = error.message || "获取播放地址失败";
  }
};

const onVideoLoaded = () => {
  videoLoading.value = false;
  videoError.value = "";
};

const retryPlayback = async () => {
  if (!currentPlaying.value) return;
  await setPlaybackSource(currentPlaying.value);
  if (videoRef.value) {
    videoRef.value.load();
  }
};

const playAtIndex = async (index: number) => {
  // 如果对话框正在关闭，不处理
  if (isPlayerClosing) return;

  if (index >= playlist.value.length) {
    if (autoPlayNext.value) {
      ElMessage.success("播放列表播放完毕");
    }
    playerVisible.value = false;
    return;
  }

  currentPlayIndex.value = index;
  const recording = playlist.value[index];
  currentPlaying.value = recording;

  if (videoRef.value) {
    videoRef.value.pause();
    videoRef.value.src = "";
  }

  await setPlaybackSource(recording);
};

const playNext = () => {
  if (currentPlayIndex.value < playlist.value.length - 1) {
    playAtIndex(currentPlayIndex.value + 1);
  } else {
    ElMessage.info("已经是最后一个视频了");
  }
};

const playPrevious = () => {
  if (currentPlayIndex.value > 0) {
    playAtIndex(currentPlayIndex.value - 1);
  } else {
    ElMessage.info("已经是第一个视频了");
  }
};

const onVideoEnded = () => {
  // 如果正在关闭对话框，不处理
  if (isPlayerClosing || !playerVisible.value) return;

  if (isPlaylistMode.value && autoPlayNext.value) {
    if (currentPlayIndex.value < playlist.value.length - 1) {
      playNext();
    } else {
      ElMessage.success("播放列表播放完毕");
      playerVisible.value = false;
    }
  }
};

const onVideoError = () => {
  if (isPlayerClosing || !playerVisible.value) {
    return;
  }

  videoLoading.value = false;
  videoError.value = "视频加载失败，可能是文件尚未上传完成或网络不稳定";

  if (isPlaylistMode.value && autoPlayNext.value) {
    ElMessage.warning("当前视频播放失败，正在播放下一个...");
    playNext();
  }
};

const onAutoPlayChange = (value: boolean) => {
  autoPlayNext.value = value;
};

const ensurePlayPermission = () => {
  if (!userStore.hasPermission("recording:play")) {
    ElMessage.warning("您没有播放录屏的权限");
    return false;
  }
  return true;
};

const ensureExportPermission = () => {
  if (!userStore.hasPermission("recording:export")) {
    ElMessage.warning("您没有导出录屏的权限");
    return false;
  }
  return true;
};

const handlePlayWithContinuity = async (
  row: Recording,
  isContinuous: boolean,
) => {
  if (!ensurePlayPermission()) return;

  try {
    if (isContinuous) {
      ElMessage.info("正在获取播放列表...");
      const allRecordings = await getAllRecordingsForPlaylist();

      if (allRecordings.length === 0) {
        ElMessage.warning("没有找到可播放的视频");
        return;
      }

      const index = allRecordings.findIndex((r) => r.id === row.id);
      if (index === -1) {
        await handlePlaySingle(row);
        return;
      }

      playlist.value = allRecordings;
      currentPlayIndex.value = index;
      isPlaylistMode.value = true;
      playerVisible.value = true;
      playAtIndex(index);
      ElMessage.success(`连续播放模式，共 ${allRecordings.length} 个视频`);
    } else {
      await handlePlaySingle(row);
    }
  } catch (error: any) {
    ElMessage.error(error.message || "播放失败");
  }
};

const handlePlaySingle = async (row: Recording) => {
  isPlaylistMode.value = false;
  playlist.value = [];
  currentPlaying.value = row;
  await setPlaybackSource(row);
  playerVisible.value = true;
};

const downloadAllVideos = async () => {
  if (!ensureExportPermission()) return;
  if (playlist.value.length === 0) return;

  downloadingAll.value = true;
  try {
    for (let i = 0; i < playlist.value.length; i++) {
      const recording = playlist.value[i];
      await handleDownload(recording, true);
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
    ElMessage.success(`已开始下载 ${playlist.value.length} 个视频文件`);
  } catch (error: any) {
    ElMessage.error(error.message || "批量下载失败");
  } finally {
    downloadingAll.value = false;
  }
};

// ========== 操作处理 ==========
const stopPlayer = () => {
  // 设置关闭标志，防止错误提示
  isPlayerClosing = true;

  try {
    if (videoRef.value) {
      // 移除事件监听
      videoRef.value.onended = null;
      videoRef.value.onerror = null;
      // 暂停播放
      videoRef.value.pause();
      // 清空 src，释放资源
      videoRef.value.src = "";
      videoRef.value.load();
    }
  } catch (error) {
    console.warn("停止播放器时出错:", error);
  }

  // 清空状态
  playUrl.value = "";
  videoLoading.value = false;
  videoError.value = "";
  currentPlaying.value = null;
  isPlaylistMode.value = false;
  playlist.value = [];
  currentPlayIndex.value = 0;

  // 延迟重置标志，避免与 DOM 销毁冲突
  setTimeout(() => {
    isPlayerClosing = false;
  }, 200);
};

// 新增：对话框关闭统一处理
const handleDialogClose = () => {
  stopPlayer();
};

const downloadCurrentVideo = () => {
  if (currentPlaying.value) {
    handleDownload(currentPlaying.value);
  }
};

const handleDownload = async (row: Recording, silent = false) => {
  if (!ensureExportPermission()) return;

  try {
    const downloadUrl = await getRecordingDownloadUrl(row.id);
    const a = document.createElement("a");
    a.href = downloadUrl;
    a.download = `${getEmployeeName(row.deviceId)}_${new Date(row.startTime).toISOString().slice(0, 19).replace(/:/g, "-")}.mp4`;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    if (!silent) ElMessage.success("下载已开始");
  } catch (error: any) {
    if (!silent) ElMessage.error(error.message || "下载失败");
    throw error;
  }
};

const confirmDelete = async (row: Recording) => {
  if (!row.uploaded) {
    ElMessage.warning("仅可删除已上传至服务器的录屏");
    return;
  }

  try {
    await ElMessageBox.confirm(
      `确定删除 ${getEmployeeName(row.deviceId)} 在 ${formatDateTime(row.startTime)} 的录制文件吗？此操作不可恢复。`,
      "删除确认",
      { confirmButtonText: "确定", cancelButtonText: "取消", type: "warning" },
    );
  } catch {
    return;
  }

  await handleDelete(row);
};

const handleDelete = async (row: Recording) => {
  try {
    await recordingApi.delete(row.id);
    ElMessage.success("删除成功");
    // ✅ 刷新列表，状态会自动更新
    await loadRecordings();
  } catch (error: any) {
    ElMessage.error(error.message || "删除失败");
  }
};

const handleBatchDelete = async () => {
  if (selectedRows.value.length === 0) {
    ElMessage.warning("请先选择要删除的录制文件");
    return;
  }

  try {
    await ElMessageBox.confirm(
      `确定要删除选中的 ${selectedRows.value.length} 个录制文件吗？此操作不可恢复。`,
      "批量删除确认",
      { confirmButtonText: "确定", cancelButtonText: "取消", type: "warning" },
    );
  } catch {
    return;
  }

  batchDeleteLoading.value = true;
  try {
    const ids = selectedRows.value.map((row) => row.id);
    await recordingApi.batchDelete(ids);
    ElMessage.success(`成功删除 ${ids.length} 个录制文件`);

    // 清空选中状态
    selectedRows.value = [];
    selectAll.value = false;
    isIndeterminate.value = false;
    if (tableRef.value) {
      tableRef.value.clearSelection();
    }

    // ✅ 刷新列表
    await loadRecordings();
  } catch (error: any) {
    ElMessage.error(error.message || "批量删除失败");
  } finally {
    batchDeleteLoading.value = false;
  }
};

const handleExport = () => {
  if (displayRecordings.value.length === 0) {
    ElMessage.warning("没有数据可导出");
    return;
  }

  exportLoading.value = true;
  try {
    const exportData = displayRecordings.value.map((row) => ({
      员工姓名: getEmployeeName(row.deviceId),
      设备ID: row.deviceId,
      开始时间: formatDateTime(row.startTime),
      结束时间: row.endTime ? formatDateTime(row.endTime) : "录制中",
      时长: formatDuration(row.duration),
      文件大小: formatBytes(row.fileSize),
      状态: getStatusText(row.status),
    }));

    const headers = Object.keys(exportData[0]);
    const csvRows = [];
    csvRows.push(headers.join(","));

    for (const row of exportData) {
      const values = headers.map((header) => {
        let value = row[header as keyof typeof row];
        if (
          typeof value === "string" &&
          (value.includes(",") || value.includes('"'))
        ) {
          value = `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      });
      csvRows.push(values.join(","));
    }

    const csvContent = "\uFEFF" + csvRows.join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `recordings_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    ElMessage.success("导出成功");
  } catch (error: any) {
    ElMessage.error(error.message || "导出失败");
  } finally {
    exportLoading.value = false;
  }
};

// ========== 生命周期 ==========
onMounted(() => {
  loadDevices();
  loadRecordings();
  loadStats();
  window.addEventListener("task-notification", onTaskNotification);
});

onUnmounted(() => {
  clearUploadPoll();
  window.removeEventListener("task-notification", onTaskNotification);
  // 组件卸载时清理播放器
  if (videoRef.value) {
    videoRef.value.pause();
    videoRef.value.src = "";
    videoRef.value.onended = null;
    videoRef.value.onerror = null;
  }
  isPlayerClosing = false;
});
</script>

<style scoped>
/* 所有样式保持不变（从您的原始代码中保留） */
.recordings-page {
  min-height: 100%;
  padding: 10px;
  background: #f5f7fb;
}

.stats-row {
  margin-bottom: 10px;
}

.workflow-hint {
  margin-bottom: 12px;
}

.workflow-hint :deep(.el-alert) {
  border-radius: 12px;
  align-items: flex-start;
}

.workflow-hint :deep(.el-alert__content) {
  flex: 1;
  min-width: 0;
  width: 100%;
}

.workflow-hint :deep(.el-alert__description) {
  width: 100%;
  margin: 4px 0 0;
  line-height: 1.6;
}

.workflow-hint :deep(.el-alert__title) {
  font-weight: 600;
  line-height: 1.4;
}

.workflow-hint-text,
.upload-hint-line {
  min-height: calc(1.6em * 2);
}

.workflow-hint-text {
  width: 100%;
  line-height: 1.6;
  font-size: 13px;
}

.upload-hint-line {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  line-height: 1.6;
  font-size: 13px;
}

.upload-hint-tag {
  flex-shrink: 0;
}

.upload-hint-progress-text {
  flex-shrink: 0;
  color: #606266;
  font-size: 13px;
  min-width: 36px;
}

.upload-hint-progress {
  flex: 1 1 180px;
  min-width: 120px;
}

.workflow-hint :deep(.upload-hint-progress.el-progress) {
  width: 100%;
  max-width: 100%;
  margin: 0;
}

.workflow-hint :deep(.upload-hint-progress .el-progress-bar) {
  width: 100%;
}

.workflow-hint :deep(.upload-hint-progress .el-progress-bar__outer) {
  width: 100% !important;
}

.upload-hint-result {
  flex: 1 1 auto;
  min-width: 0;
  color: #606266;
  font-size: 13px;
  line-height: 1.6;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.empty-actions {
  display: flex;
  gap: 12px;
  justify-content: center;
  flex-wrap: wrap;
}

.stat-card {
  border-radius: 16px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  cursor: pointer;
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 28px rgba(0, 0, 0, 0.12);
}

.stat-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.stat-info {
  flex: 1;
}

.stat-title {
  color: #8c8c8c;
  font-size: 13px;
  margin-bottom: 8px;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #1a1a2e;
  line-height: 1.2;
}

.stat-trend {
  font-size: 12px;
  margin-top: 8px;
  display: flex;
  align-items: center;
  gap: 4px;
  color: #909399;
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.filter-card {
  border-radius: 16px;
  margin-bottom: 10px;
  overflow: hidden;
  transition: all 0.3s ease;
}

.card-hover:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}

.filter-form {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
}

.filter-form .el-form-item {
  margin-bottom: 0;
}

.reset-btn {
  margin-left: 0;
}

.table-card {
  border-radius: 16px;
  overflow: hidden;
  transition: all 0.3s ease;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 600;
  font-size: 16px;
}

.header-right {
  display: flex;
  align-items: center;
}

.selection-area {
  display: flex;
  align-items: center;
  gap: 16px;
}

.select-all {
  font-weight: 500;
}

.total-tag {
  margin-left: 8px;
}

.custom-table {
  width: 100%;
}

.custom-table :deep(.el-table__row) {
  transition: all 0.2s ease;
}

.custom-table :deep(.el-table__row:hover) {
  background: #f4f8ff;
}

.custom-table :deep(.pending-row) {
  background: #f5f5f5;
}

.employee-cell {
  display: flex;
  align-items: center;
  gap: 12px;
}

.employee-avatar {
  flex-shrink: 0;
}

.employee-info {
  display: flex;
  flex-direction: column;
}

.employee-name {
  font-weight: 600;
  color: #303133;
  font-size: 14px;
}

.employee-dept {
  font-size: 11px;
  color: #909399;
  margin-top: 2px;
}

.device-cell {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #606266;
}

.device-id {
  font-family: monospace;
  font-size: 12px;
}

.time-cell {
  display: flex;
  flex-direction: column;
}

.time-date {
  font-weight: 500;
  color: #303133;
  font-size: 13px;
}

.time-range {
  font-size: 11px;
  color: #909399;
  margin-top: 2px;
}

.duration-cell {
  display: flex;
  align-items: center;
  gap: 6px;
  justify-content: center;
}

.duration-cell .duration-long {
  color: #f56c6c;
  font-weight: 500;
}

.duration-cell .duration-medium {
  color: #e6a23c;
}

.duration-short {
  color: #67c23a;
}

.size-cell {
  font-family: monospace;
}

.size-value {
  font-weight: 500;
  color: #409eff;
}

.status-cell {
  display: flex;
  align-items: center;
  gap: 6px;
  justify-content: center;
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
}

.status-dot.uploaded {
  background: #67c23a;
  box-shadow: 0 0 6px rgba(103, 194, 58, 0.5);
}

.status-dot.pending {
  background: #e6a23c;
}

.action-buttons {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-wrap: wrap;
  justify-content: center;
}

.action-btn {
  padding: 4px 8px;
}

.action-btn span {
  margin-left: 4px;
}

.pagination-wrapper {
  margin-top: 20px;
  padding-top: 16px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  justify-content: flex-end;
}

.employee-option {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 4px 0;
}

.employee-option .info {
  display: flex;
  flex-direction: column;
}

.employee-option .info .name {
  font-weight: 500;
  font-size: 14px;
}

.employee-option .info .detail {
  font-size: 12px;
  color: #909399;
}

.player-dialog :deep(.el-dialog__body) {
  padding: 16px 20px;
}

.player-info {
  background: #f5f7fa;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 20px;
}

.info-item {
  margin-bottom: 8px;
}

.info-label {
  font-size: 12px;
  color: #909399;
  margin-bottom: 4px;
}

.info-value {
  font-weight: 500;
  color: #303133;
}

.video-container {
  position: relative;
  min-height: 280px;
  background: #0f0f0f;
  border-radius: 12px;
  overflow: hidden;
}

.video-loading,
.video-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  min-height: 280px;
  color: #c0c4cc;
}

.video-error p {
  margin: 0;
  color: #909399;
  font-size: 14px;
}

.video-player {
  width: 100%;
  max-height: 480px;
  display: block;
  background: #000;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}

@media (max-width: 1200px) {
  .custom-table {
    overflow-x: auto;
  }
  .custom-table :deep(.el-table__body-wrapper) {
    overflow-x: auto;
  }
}

@media (max-width: 768px) {
  .recordings-page {
    padding: 12px;
  }
  .stat-value {
    font-size: 20px;
  }
  .stat-icon {
    width: 44px;
    height: 44px;
  }
  .filter-form {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }
  .filter-form .el-form-item {
    width: 100%;
  }
  .filter-form .el-form-item .el-select,
  .filter-form .el-form-item .el-date-editor {
    width: 100% !important;
  }
  .card-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }
  .selection-area {
    flex-wrap: wrap;
  }
  .pagination-wrapper {
    overflow-x: auto;
  }
  .pagination-wrapper :deep(.el-pagination) {
    justify-content: center;
  }
  .action-btn span {
    display: none;
  }
  .action-btn .el-icon {
    margin-right: 0;
    font-size: 18px;
  }
}

.player-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding: 12px;
  background: #f5f7fa;
  border-radius: 8px;
  flex-wrap: wrap;
  gap: 12px;
}

.playlist-info {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.playlist-progress {
  font-weight: 500;
}

.playlist-progress-bar {
  width: 120px;
  margin-left: 8px;
}

.player-controls {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}
</style>

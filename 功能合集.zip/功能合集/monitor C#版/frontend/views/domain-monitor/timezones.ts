export interface ReportTimezoneOption {
  value: string;
  label: string;
}

export const REPORT_TIMEZONE_OPTIONS: ReportTimezoneOption[] = [
  { value: "UTC", label: "协调世界时 (UTC+0)" },
  { value: "UTC-12", label: "UTC-12" },
  { value: "UTC-11", label: "UTC-11" },
  { value: "UTC-10", label: "UTC-10" },
  { value: "UTC-9", label: "UTC-9" },
  { value: "UTC-8", label: "UTC-8" },
  { value: "UTC-7", label: "UTC-7" },
  { value: "UTC-6", label: "UTC-6" },
  { value: "UTC-5", label: "UTC-5" },
  { value: "UTC-4", label: "UTC-4" },
  { value: "UTC-3", label: "UTC-3" },
  { value: "UTC-2", label: "UTC-2" },
  { value: "UTC-1", label: "UTC-1" },
  { value: "UTC+1", label: "UTC+1" },
  { value: "UTC+2", label: "UTC+2" },
  { value: "UTC+3", label: "UTC+3" },
  { value: "UTC+4", label: "UTC+4" },
  { value: "UTC+5", label: "UTC+5" },
  { value: "UTC+6", label: "UTC+6" },
  { value: "UTC+7", label: "UTC+7" },
  { value: "UTC+8", label: "UTC+8" },
  { value: "UTC+9", label: "UTC+9" },
  { value: "UTC+10", label: "UTC+10" },
  { value: "UTC+11", label: "UTC+11" },
  { value: "UTC+12", label: "UTC+12" },
  { value: "Asia/Shanghai", label: "中国标准时间 (UTC+8)" },
  { value: "Asia/Hong_Kong", label: "香港时间 (UTC+8)" },
  { value: "Asia/Taipei", label: "台北时间 (UTC+8)" },
  { value: "Asia/Singapore", label: "新加坡时间 (UTC+8)" },
  { value: "Asia/Kuala_Lumpur", label: "马来西亚时间 (UTC+8)" },
  { value: "Asia/Manila", label: "菲律宾时间 (UTC+8)" },
  { value: "Asia/Tokyo", label: "日本标准时间 (UTC+9)" },
  { value: "Asia/Seoul", label: "韩国标准时间 (UTC+9)" },
  { value: "Asia/Bangkok", label: "中南半岛时间 (UTC+7)" },
  { value: "Asia/Jakarta", label: "印尼西部时间 (UTC+7)" },
  { value: "Asia/Ho_Chi_Minh", label: "越南时间 (UTC+7)" },
  { value: "Asia/Dubai", label: "海湾标准时间 (UTC+4)" },
  { value: "Asia/Kolkata", label: "印度标准时间 (UTC+5:30)" },
  { value: "Asia/Karachi", label: "巴基斯坦时间 (UTC+5)" },
  { value: "Europe/London", label: "英国时间 (UTC+0/+1)" },
  { value: "Europe/Berlin", label: "中欧时间 (UTC+1/+2)" },
  { value: "Europe/Paris", label: "中欧时间 (UTC+1/+2)" },
  { value: "Europe/Moscow", label: "莫斯科时间 (UTC+3)" },
  { value: "America/New_York", label: "美国东部时间 (UTC-5/-4)" },
  { value: "America/Chicago", label: "美国中部时间 (UTC-6/-5)" },
  { value: "America/Denver", label: "美国山地时间 (UTC-7/-6)" },
  { value: "America/Los_Angeles", label: "美国太平洋时间 (UTC-8/-7)" },
  { value: "America/Sao_Paulo", label: "巴西利亚时间 (UTC-3)" },
  { value: "America/Argentina/Buenos_Aires", label: "阿根廷时间 (UTC-3)" },
  { value: "America/Mexico_City", label: "墨西哥中部时间 (UTC-6/-5)" },
  { value: "Australia/Sydney", label: "澳大利亚东部时间 (UTC+10/+11)" },
  { value: "Pacific/Auckland", label: "新西兰时间 (UTC+12/+13)" },
];

export function buildTimezoneOptions(current?: string): ReportTimezoneOption[] {
  const options = [...REPORT_TIMEZONE_OPTIONS];
  const value = (current || "").trim();
  if (value && !options.some((item) => item.value === value)) {
    options.unshift({ value, label: `${value}（自定义）` });
  }
  return options;
}

<template>
  <div class="dm-page">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <el-card shadow="hover" class="main-card">
      <!-- ===== 卡片头部 ===== -->
      <template #header>
        <div class="card-header-custom">
          <div class="header-left">
            <div class="header-icon-wrapper">
              <el-icon class="header-icon"><Document /></el-icon>
            </div>
            <div class="header-info">
              <span class="header-title">监控报告</span>
              <span class="header-subtitle">生成并下载域名健康报告</span>
            </div>
          </div>
          <div class="header-right">
            <el-tag type="info" effect="plain" size="large" class="count-tag">
              <el-icon><Document /></el-icon>
              共 {{ reports.length }} 份报告
            </el-tag>
          </div>
        </div>
      </template>

      <!-- ===== 工具栏 ===== -->
      <div class="toolbar">
        <div class="toolbar-left">
          <el-button type="primary" v-permission="'domain_monitor:manage'" @click="genDaily" class="action-btn daily-btn">
            <el-icon><Sunny /></el-icon>
            生成日报
          </el-button>
          <el-button v-permission="'domain_monitor:manage'" @click="genWeekly" class="action-btn weekly-btn">
            <el-icon><Moon /></el-icon>
            生成周报
          </el-button>
        </div>
        <div class="toolbar-right">
          <el-button @click="loadReports" :loading="loading" class="action-btn refresh-btn">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
        </div>
      </div>

      <!-- ===== 报告列表 ===== -->
      <el-table :data="reports" stripe v-loading="loading" class="modern-table" :header-cell-style="headerCellStyle">
        <el-table-column label="类型" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.reportType === 'weekly' ? 'warning' : 'primary'" size="large" effect="light">
              <el-icon v-if="row.reportType === 'weekly'"><Calendar /></el-icon>
              <el-icon v-else><Sunrise /></el-icon>
              {{ row.reportType === "weekly" ? "周报" : "日报" }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column label="周期" min-width="260">
          <template #default="{ row }">
            <div class="period-cell">
              <span class="period-range">
                <span class="period-date">{{ formatDateTime(row.periodStart) }}</span>
                <el-icon class="period-arrow"><ArrowRight /></el-icon>
                <span class="period-date">{{ formatDateTime(row.periodEnd) }}</span>
              </span>
              <el-tag size="small" type="info" effect="plain" class="period-days">
                {{ calculateDays(row.periodStart, row.periodEnd) }} 天
              </el-tag>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="生成时间" width="180" align="center">
          <template #default="{ row }">
            <div class="created-cell">
              <el-icon><Clock /></el-icon>
              <span class="created-time">{{ formatDateTime(row.createdAt) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag type="success" size="small" effect="light">
              <el-icon><CircleCheck /></el-icon>
              已生成
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column label="操作" width="140" fixed="right" align="center">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="download(row)" class="action-btn download-btn">
              <el-icon><Download /></el-icon>
              下载 PDF
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- ===== 空状态 ===== -->
      <el-empty v-if="!reports.length && !loading" description="暂无报告" class="empty-table">
        <template #image>
          <el-icon :size="64" color="#c0c4cc"><Document /></el-icon>
        </template>
        <div class="empty-content">
          <span class="empty-hint">点击「生成日报」或「生成周报」创建第一份报告</span>
          <div class="empty-actions">
            <el-button type="primary" v-permission="'domain_monitor:manage'" @click="genDaily" class="action-btn daily-btn">
              <el-icon><Sunny /></el-icon>
              生成日报
            </el-button>
            <el-button v-permission="'domain_monitor:manage'" @click="genWeekly" class="action-btn weekly-btn">
              <el-icon><Moon /></el-icon>
              生成周报
            </el-button>
          </div>
        </div>
      </el-empty>
    </el-card>

    <!-- ===== 提示信息 ===== -->
    <el-alert class="tip-alert" type="info" :closable="false" show-icon>
      <template #title>
        <span class="tip-title">自动生成机制</span>
      </template>
      <template #default>
        <div class="tip-content">
          <span>系统也会在每天 <strong>01:00 UTC</strong> 自动生成日报，</span>
          <span>周一 <strong>02:00 UTC</strong> 自动生成周报（DM_REPORTS_ENABLED 未禁用时）。</span>
        </div>
      </template>
    </el-alert>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from "vue";
import { ElMessage } from "element-plus";
import {
  Document,
  Sunny,
  Moon,
  Refresh,
  Download,
  Calendar,
  Sunrise,
  ArrowRight,
  Clock,
  CircleCheck,
} from "@element-plus/icons-vue";
import domainMonitorApi, { type DmReport } from "@api/domain_monitor_api";
import { formatDateTime, downloadBlob } from "./helpers";

const loading = ref(false);
const reports = ref<DmReport[]>([]);

const headerCellStyle = {
  background: "linear-gradient(135deg, #f8fafc 0%, #eef2f6 100%)",
  color: "#1e293b",
  fontWeight: "600",
  fontSize: "13px",
  borderBottom: "2px solid #e2e8f0",
};

function calculateDays(start: string, end: string): number {
  const startDate = new Date(start);
  const endDate = new Date(end);
  const diff = endDate.getTime() - startDate.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24)) + 1;
}

async function loadReports() {
  loading.value = true;
  try {
    const { data } = await domainMonitorApi.listReports();
    reports.value = data || [];
  } catch (e: any) {
    ElMessage.error(e.message || "加载失败");
  } finally {
    loading.value = false;
  }
}

async function genDaily() {
  try {
    await domainMonitorApi.generateReport("daily");
    ElMessage.success("日报已生成");
    loadReports();
  } catch (e: any) {
    ElMessage.error(e.message || "生成失败");
  }
}

async function genWeekly() {
  try {
    await domainMonitorApi.generateReport("weekly");
    ElMessage.success("周报已生成");
    loadReports();
  } catch (e: any) {
    ElMessage.error(e.message || "生成失败");
  }
}

async function download(row: DmReport) {
  try {
    const res = await domainMonitorApi.downloadReport(row.id);
    downloadBlob(res.data as Blob, `${row.reportType}_${row.id.slice(0, 8)}.pdf`);
  } catch (e: any) {
    ElMessage.error(e.message || "下载失败");
  }
}

onMounted(loadReports);
</script>

<style scoped>
/* ========== 页面背景 ========== */
.dm-page {
  position: relative;
  padding: 4px;
  min-height: 100vh;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.3;
  animation: floatBlob 25s ease-in-out infinite;
}

.blob-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -150px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -200px;
  left: -150px;
  animation-delay: -8s;
}

.blob-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 20%;
  animation-delay: -16s;
}

@keyframes floatBlob {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(40px, -40px) scale(1.05); }
  66% { transform: translate(-30px, 30px) scale(0.95); }
}

/* ========== 主卡片 ========== */
.main-card {
  position: relative;
  z-index: 1;
  border-radius: 20px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.08);
  overflow: hidden;
}

.main-card :deep(.el-card__header) {
  padding: 20px 24px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  background: transparent;
}

.main-card :deep(.el-card__body) {
  padding: 24px;
}

/* ========== 卡片头部 ========== */
.card-header-custom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  flex-wrap: wrap;
  gap: 12px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.header-icon-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  border-radius: 12px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.header-icon {
  font-size: 22px;
}

.header-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.header-title {
  font-size: 20px;
  font-weight: 700;
  color: #1a1a2e;
  letter-spacing: 0.5px;
}

.header-subtitle {
  font-size: 13px;
  color: #909399;
}

.header-right {
  display: flex;
  align-items: center;
}

.count-tag {
  font-size: 13px;
  padding: 6px 16px;
  border-radius: 20px;
  background: #f5f7fa;
  border-color: #e4e7ed;
}

.count-tag .el-icon {
  margin-right: 6px;
}

/* ========== 工具栏 ========== */
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 20px;
}

.toolbar-left,
.toolbar-right {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.action-btn {
  border-radius: 10px;
  padding: 8px 20px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.action-btn:hover {
  transform: translateY(-2px);
}

.daily-btn {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
  border: none;
  color: white;
  box-shadow: 0 4px 12px rgba(245, 87, 108, 0.25);
}

.daily-btn:hover {
  box-shadow: 0 6px 20px rgba(245, 87, 108, 0.35);
  color: white;
}

.weekly-btn {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
  border: none;
  color: white;
  box-shadow: 0 4px 12px rgba(79, 172, 254, 0.25);
}

.weekly-btn:hover {
  box-shadow: 0 6px 20px rgba(79, 172, 254, 0.35);
  color: white;
}

.refresh-btn {
  border: 1px solid #e8ecf1;
  transition: all 0.2s ease;
}

.refresh-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
  border-color: #c0c4cc;
}

/* ========== 表格 ========== */
.modern-table {
  width: 100%;
}

.modern-table :deep(.el-table__header th) {
  padding: 12px 0;
}

.modern-table :deep(.el-table__row td) {
  padding: 12px 0;
}

.modern-table :deep(.el-table__row) {
  transition: background 0.2s ease;
}

.modern-table :deep(.el-table__row:hover) {
  background: rgba(102, 126, 234, 0.04);
}

/* ========== 表格单元格 ========== */
.period-cell {
  display: flex;
  align-items: center;
  gap: 12px;
}

.period-range {
  display: flex;
  align-items: center;
  gap: 8px;
}

.period-date {
  font-weight: 500;
  color: #1a1a2e;
  font-size: 14px;
}

.period-arrow {
  color: #909399;
  font-size: 14px;
}

.period-days {
  font-size: 11px;
  padding: 0 10px;
  height: 22px;
  line-height: 22px;
}

.created-cell {
  display: flex;
  align-items: center;
  gap: 6px;
  justify-content: center;
}

.created-cell .el-icon {
  color: #909399;
  font-size: 14px;
}

.created-time {
  color: #606266;
  font-size: 14px;
}

/* ========== 下载按钮 ========== */
.download-btn {
  padding: 4px 12px;
  border-radius: 20px;
  transition: all 0.2s ease;
  color: #409eff;
}

.download-btn:hover {
  background: rgba(64, 158, 255, 0.08);
  transform: scale(1.05);
}

.download-btn .el-icon {
  margin-right: 4px;
}

/* ========== 空状态 ========== */
.empty-table {
  padding: 30px 0;
}

.empty-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
}

.empty-hint {
  color: #909399;
  font-size: 14px;
}

.empty-actions {
  display: flex;
  gap: 12px;
}

/* ========== 提示信息 ========== */
.tip-alert {
  position: relative;
  z-index: 1;
  margin-top: 16px;
  border-radius: 12px;
}

.tip-alert :deep(.el-alert__title) {
  font-weight: 600;
  font-size: 15px;
}

.tip-content {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 8px;
  font-size: 14px;
  color: #606266;
  line-height: 1.6;
}

.tip-content strong {
  color: #409eff;
  font-weight: 600;
}

/* ========== 响应式 ========== */
@media (max-width: 768px) {
  .main-card :deep(.el-card__header) {
    padding: 16px;
  }

  .main-card :deep(.el-card__body) {
    padding: 16px;
  }

  .card-header-custom {
    flex-direction: column;
    align-items: flex-start;
  }

  .header-left {
    width: 100%;
  }

  .header-title {
    font-size: 17px;
  }

  .header-right {
    width: 100%;
  }

  .count-tag {
    width: 100%;
    justify-content: center;
  }

  .toolbar {
    flex-direction: column;
    align-items: stretch;
  }

  .toolbar-left,
  .toolbar-right {
    justify-content: center;
  }

  .toolbar .action-btn {
    flex: 1;
    min-width: 100px;
    justify-content: center;
  }

  .period-cell {
    flex-direction: column;
    align-items: flex-start;
    gap: 4px;
  }

  .period-range {
    flex-wrap: wrap;
  }

  .empty-actions {
    flex-direction: column;
    width: 100%;
  }

  .empty-actions .action-btn {
    width: 100%;
    justify-content: center;
  }

  .tip-content {
    flex-direction: column;
    gap: 2px;
  }
}

@media (max-width: 480px) {
  .header-icon-wrapper {
    width: 36px;
    height: 36px;
  }

  .header-icon {
    font-size: 18px;
  }

  .header-title {
    font-size: 15px;
  }

  .header-subtitle {
    font-size: 12px;
  }

  .toolbar .action-btn {
    flex: 1 1 100%;
    min-width: auto;
  }

  .period-date {
    font-size: 13px;
  }

  .created-time {
    font-size: 13px;
  }

  .modern-table :deep(.el-table) {
    font-size: 13px;
  }

  .download-btn span {
    display: none;
  }

  .download-btn .el-icon {
    margin-right: 0;
    font-size: 18px;
  }
}
</style>
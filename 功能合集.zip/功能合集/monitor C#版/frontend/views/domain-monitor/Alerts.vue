<template>
  <div class="dm-page">
    <el-card shadow="never" class="filter-card">
      <el-form :inline="true">
        <el-form-item label="状态">
          <el-select
            v-model="filters.status"
            clearable
            placeholder="全部"
            style="width: 130px"
            @change="loadAlerts"
          >
            <el-option label="待处理" value="open" />
            <el-option label="已确认" value="ack" />
            <el-option label="已解决" value="resolved" />
          </el-select>
        </el-form-item>
        <el-form-item label="级别">
          <el-select
            v-model="filters.severity"
            clearable
            placeholder="全部"
            style="width: 130px"
            @change="loadAlerts"
          >
            <el-option
              v-for="s in SEVERITY_OPTIONS"
              :key="s.value"
              :label="s.label"
              :value="s.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="loadAlerts">刷新</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card shadow="never" v-loading="loading">
      <el-table :data="alerts" stripe>
        <el-table-column label="类型" width="120">
          <template #default="{ row }">
            {{ alertTypeLabel(row.alertType) }}
          </template>
        </el-table-column>
        <el-table-column label="级别" width="100">
          <template #default="{ row }">
            <el-tag :type="severityTagType(row.severity)" size="small">
              {{ row.severity }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="title" label="标题" min-width="200" show-overflow-tooltip />
        <el-table-column prop="message" label="内容" min-width="240" show-overflow-tooltip />
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag
              :type="
                row.status === 'resolved'
                  ? 'success'
                  : row.status === 'ack'
                    ? 'warning'
                    : 'danger'
              "
              size="small"
            >
              {{
                row.status === "resolved"
                  ? "已解决"
                  : row.status === "ack"
                    ? "已确认"
                    : "待处理"
              }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="首次" width="170">
          <template #default="{ row }">
            {{ formatDateTime(row.firstAt) }}
          </template>
        </el-table-column>
        <el-table-column label="最近" width="170">
          <template #default="{ row }">
            {{ formatDateTime(row.lastAt) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button
              v-if="row.status === 'open'"
              link
              type="primary"
              v-permission="'domain_monitor:manage'"
              @click="ack(row)"
            >
              确认
            </el-button>
            <el-button
              v-if="row.status !== 'resolved'"
              link
              type="success"
              v-permission="'domain_monitor:manage'"
              @click="resolve(row)"
            >
              解决
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="pagination.total"
          layout="total, prev, pager, next"
          @current-change="loadAlerts"
          @size-change="loadAlerts"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from "vue";
import { ElMessage } from "element-plus";
import domainMonitorApi, { type DmAlert } from "@api/domain_monitor_api";
import {
  alertTypeLabel,
  severityTagType,
  formatDateTime,
  SEVERITY_OPTIONS,
} from "./helpers";

const loading = ref(false);
const alerts = ref<DmAlert[]>([]);
const filters = reactive({ status: "", severity: "" });
const pagination = reactive({ page: 1, pageSize: 20, total: 0 });

async function loadAlerts() {
  loading.value = true;
  try {
    const { data } = await domainMonitorApi.listAlerts({
      page: pagination.page,
      pageSize: pagination.pageSize,
      status: filters.status || undefined,
      severity: filters.severity || undefined,
    });
    alerts.value = data?.items || [];
    pagination.total = data?.total || 0;
  } catch (e: any) {
    ElMessage.error(e.message || "加载告警失败");
  } finally {
    loading.value = false;
  }
}

async function ack(row: DmAlert) {
  try {
    await domainMonitorApi.ackAlert(row.id);
    ElMessage.success("已确认");
    loadAlerts();
  } catch (e: any) {
    ElMessage.error(e.message || "操作失败");
  }
}

async function resolve(row: DmAlert) {
  try {
    await domainMonitorApi.resolveAlert(row.id);
    ElMessage.success("已解决");
    loadAlerts();
  } catch (e: any) {
    ElMessage.error(e.message || "操作失败");
  }
}

onMounted(loadAlerts);
</script>

<style scoped>
.dm-page {
  padding: 4px;
}
.filter-card {
  margin-bottom: 16px;
}
.pagination {
  margin-top: 16px;
  display: flex;
  justify-content: flex-end;
}
</style>

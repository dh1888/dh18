import domainMonitorApi, {
  type DmCheckBatchStatus,
  type DmCheckResult,
  type DmDomain,
} from "@api/domain_monitor_api";

export function statusTagType(
  status: string,
): "success" | "warning" | "danger" | "info" {
  const s = (status || "unknown").toLowerCase();
  if (s === "ok") return "success";
  if (s === "warning") return "warning";
  if (s === "error" || s === "critical") return "danger";
  return "info";
}

export function statusLabel(status: string): string {
  const map: Record<string, string> = {
    ok: "正常",
    warning: "警告",
    error: "异常",
    critical: "严重",
    unknown: "未知",
  };
  return map[(status || "unknown").toLowerCase()] || status;
}

export function severityTagType(
  severity: string,
): "success" | "warning" | "danger" | "info" {
  const s = (severity || "").toUpperCase();
  if (s === "CRITICAL") return "danger";
  if (s === "ERROR") return "warning";
  if (s === "WARNING") return "info";
  return "info";
}

export function alertTypeLabel(type: string): string {
  const map: Record<string, string> = {
    dns_fail: "DNS 故障",
    http_fail: "HTTP 不可达",
    ssl_expire: "SSL 证书",
    ssl_mismatch: "SSL 域名不匹配",
    whois_expire: "WHOIS 到期",
    content_change: "页面内容变更",
    screenshot_fail: "截图失败",
    monitor_report: "监控检测报告",
    ip_change: "IP 变更",
    dns_change: "DNS 记录变更",
    http_redirect: "HTTP 跳转异常",
    blacklist_hit: "黑名单命中",
    user_sim_fail: "用户模拟异常",
    dns_hijack: "DNS 劫持",
    cdn_change: "CDN 变更",
    ssl_chain_fail: "SSL 证书链",
    ssl_weak: "SSL 弱算法/TLS",
  };
  return map[type] || type;
}

export function formatDateTime(value?: string | null): string {
  if (!value) return "-";
  return new Date(value).toLocaleString("zh-CN");
}

export function formatInterval(seconds: number): string {
  if (!seconds) return "-";
  if (seconds < 60) return `${seconds} 秒`;
  if (seconds < 3600) return `${Math.round(seconds / 60)} 分钟`;
  return `${Math.round(seconds / 3600)} 小时`;
}

export function formatDurationMs(ms?: number | null): string {
  if (ms == null || ms <= 0) return "-";
  if (ms < 1000) return `${ms} ms`;
  return `${(ms / 1000).toFixed(2)} s`;
}

export function parseJsonField<T = unknown>(
  value?: string | T | null,
): T | null {
  if (value == null || value === "") return null;
  if (typeof value === "object") return value as T;
  try {
    return JSON.parse(value as string) as T;
  } catch {
    return null;
  }
}

export function parseStringArray(value?: string | string[]): string[] {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export const ALERT_TYPE_OPTIONS = [
  { value: "dns_fail", label: "DNS 故障" },
  { value: "http_fail", label: "HTTP 不可达" },
  { value: "ssl_expire", label: "SSL 证书到期" },
  { value: "ssl_mismatch", label: "SSL 域名不匹配" },
  { value: "whois_expire", label: "WHOIS 到期" },
  { value: "content_change", label: "页面内容变更" },
  { value: "screenshot_fail", label: "截图失败" },
  { value: "ip_change", label: "IP 变更" },
  { value: "dns_change", label: "DNS 记录变更" },
  { value: "http_redirect", label: "HTTP 跳转异常" },
  { value: "blacklist_hit", label: "黑名单命中" },
  { value: "user_sim_fail", label: "用户模拟异常" },
  { value: "dns_hijack", label: "DNS 劫持" },
  { value: "cdn_change", label: "CDN 变更" },
  { value: "ssl_chain_fail", label: "SSL 证书链" },
  { value: "ssl_weak", label: "SSL 弱算法/TLS" },
  { value: "monitor_report", label: "监控检测报告" },
];

export function healthLevelLabel(level?: string): string {
  const map: Record<string, string> = {
    normal: "正常",
    partial: "部分地区异常",
    abnormal: "异常",
    critical: "高危",
  };
  return map[(level || "").toLowerCase()] || level || "-";
}

export function healthLevelTagType(
  level?: string,
): "success" | "warning" | "danger" | "info" {
  const s = (level || "").toLowerCase();
  if (s === "normal") return "success";
  if (s === "partial") return "warning";
  if (s === "abnormal") return "warning";
  if (s === "critical") return "danger";
  return "info";
}

export function nodeReachIcon(ok: boolean): string {
  return ok ? "✅" : "❌";
}

export const SEVERITY_OPTIONS = [
  { value: "CRITICAL", label: "严重" },
  { value: "ERROR", label: "错误" },
  { value: "WARNING", label: "警告" },
  { value: "INFO", label: "信息" },
];

export function allAlertTypeValues(): string[] {
  return ALERT_TYPE_OPTIONS.map((o) => o.value);
}

export function allSeverityValues(): string[] {
  return SEVERITY_OPTIONS.map((o) => o.value);
}

export interface CheckDetailView {
  title: string;
  rows: { label: string; value: string }[];
  hint?: string;
  rawJson?: string;
}

export function checkTypeLabel(type: string): string {
  const map: Record<string, string> = {
    dns: "DNS",
    http: "HTTP",
    ssl: "SSL/TLS",
    whois: "WHOIS",
    content: "页面内容",
    screenshot: "截图",
    userSimulation: "用户模拟",
  };
  return map[type] || type;
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (value == null) return null;
  if (typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  return null;
}

function str(value: unknown): string {
  if (value == null || value === "") return "";
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return JSON.stringify(value);
}

function boolLabel(value: unknown, yes = "是", no = "否"): string {
  if (value === true) return yes;
  if (value === false) return no;
  return str(value);
}

function humanizeDetailError(raw: Record<string, unknown>): string {
  if (str(raw.summary)) return str(raw.summary);
  const err = str(raw.error);
  if (!err) return "";
  if (err.includes("malformed HTTP response")) {
    return "HTTP 协议不匹配（代理或站点返回了 HTTP/2 二进制帧，非标准 HTTP 响应）";
  }
  if (err.includes("no such host") || err.toLowerCase().includes("nxdomain")) {
    return "DNS 解析失败";
  }
  if (err.toLowerCase().includes("timeout") || err.toLowerCase().includes("deadline exceeded")) {
    return "连接超时";
  }
  return err.length > 120 ? err.slice(0, 120) + "…" : err;
}

function formatDNSDetail(rec: Record<string, unknown> | null): CheckDetailView {
  const rows: { label: string; value: string }[] = [];
  let hint: string | undefined;
  if (!rec || Object.keys(rec).length === 0) {
    return { title: "DNS 检测", rows: [{ label: "结果", value: "无记录" }] };
  }
  if (rec.lookupError) {
    rows.push({ label: "结果", value: humanizeDetailError({ error: rec.lookupError }) || "DNS 解析失败" });
  }
  const ips = rec.A_AAAA;
  if (Array.isArray(ips) && ips.length) {
    rows.push({ label: "A/AAAA", value: ips.map(String).join(", ") });
  }
  for (const key of ["CNAME", "NS", "MX", "TXT"]) {
    if (rec[key]) rows.push({ label: key, value: str(rec[key]) });
  }
  if (rec.changeSummary) rows.push({ label: "变更", value: str(rec.changeSummary) });
  if (Array.isArray(rec.blacklistHits) && rec.blacklistHits.length) {
    rows.push({ label: "黑名单", value: rec.blacklistHits.map(String).join("；") });
  }
  if (!rows.length) rows.push({ label: "结果", value: "正常" });
  return { title: "DNS 检测", rows, hint };
}

function formatSSLDetail(info: Record<string, unknown> | null): CheckDetailView {
  if (!info || Object.keys(info).length === 0) {
    return { title: "SSL/TLS 检测", rows: [{ label: "结果", value: "无数据" }] };
  }
  const rows: { label: string; value: string }[] = [];
  let hint = str(info.hint) || undefined;
  if (info.summary && !info.daysLeft && !info.tlsVersion) {
    rows.push({ label: "结果", value: str(info.summary) });
    if (info.error) rows.push({ label: "原因", value: str(info.error) });
    return { title: "SSL/TLS 检测", rows, hint };
  }
  if (info.tlsVersion) rows.push({ label: "TLS 版本", value: str(info.tlsVersion) });
  if (info.daysLeft != null) rows.push({ label: "剩余天数", value: `${info.daysLeft} 天` });
  if (info.commonName) rows.push({ label: "证书 CN", value: str(info.commonName) });
  if (info.hostnameMatch != null) {
    rows.push({
      label: "域名匹配",
      value: info.hostnameMatch ? "匹配" : "不匹配",
    });
  }
  if (info.issuer) rows.push({ label: "颁发者", value: str(info.issuer) });
  if (info.notAfter) rows.push({ label: "到期时间", value: str(info.notAfter) });
  if (info.selfSigned === true) rows.push({ label: "自签名", value: "是" });
  if (info.chainValid === false) rows.push({ label: "证书链", value: "验证失败" });
  if (Array.isArray(info.sslIssues) && info.sslIssues.length) {
    rows.push({ label: "问题", value: info.sslIssues.map(String).join("；") });
  }
  if (!rows.length) rows.push({ label: "结果", value: "正常" });
  hint =
    hint ||
    (info.tlsVersion
      ? "SSL 检测为监控中心直连 443 端口（不经 HTTP 代理），与浏览器走代理的路径可能不同。"
      : undefined);
  return { title: "SSL/TLS 检测", rows, hint };
}

function formatRawDetail(
  raw: Record<string, unknown> | null,
  row: DmCheckResult,
): CheckDetailView {
  const rows: { label: string; value: string }[] = [];
  const hint = str(raw?.hint) || undefined;
  const summary = raw ? humanizeDetailError(raw) : "";
  if (summary) rows.push({ label: "结果", value: summary });
  if (raw?.issue) rows.push({ label: "类型", value: str(raw.issue) });
  if (row.httpStatus) rows.push({ label: "HTTP 状态码", value: String(row.httpStatus) });
  if (row.finalUrl || raw?.finalUrl) {
    rows.push({ label: "最终 URL", value: str(row.finalUrl || raw?.finalUrl) });
  }
  if (raw?.proxy) {
    rows.push({
      label: "检测路径",
      value: str(raw.proxy) ? `代理 ${str(raw.proxy)}` : "本机直连",
    });
  }
  if (Array.isArray(raw?.issues) && raw.issues.length) {
    rows.push({
      label: "发现问题",
      value: raw.issues.map((i) => String(i)).join("；"),
    });
  }
  if (raw?.redirectMessage) rows.push({ label: "跳转", value: str(raw.redirectMessage) });
  if (raw?.statusCode != null && !row.httpStatus) {
    rows.push({ label: "HTTP 状态码", value: str(raw.statusCode) });
  }
  if (!rows.length) rows.push({ label: "结果", value: statusLabel(row.status) });
  return {
    title: checkTypeLabel(row.checkType) + " 检测",
    rows,
    hint,
  };
}

export function formatCheckDetail(row: DmCheckResult): CheckDetailView {
  const dns = asRecord(parseJsonField(row.dnsRecords));
  const ssl = asRecord(parseJsonField(row.sslInfo));
  const raw = asRecord(parseJsonField(row.rawDetail));
  const chain = parseJsonField<string[]>(row.redirectChain);

  let view: CheckDetailView;
  switch (row.checkType) {
    case "dns":
      view = formatDNSDetail(dns);
      break;
    case "ssl":
      view = formatSSLDetail(ssl);
      break;
    default:
      view = formatRawDetail(raw, row);
  }

  const extra: { label: string; value: string }[] = [
    { label: "节点", value: row.nodeName || row.nodeId || "-" },
    { label: "状态", value: statusLabel(row.status) },
  ];
  if (row.durationMs != null) extra.push({ label: "耗时", value: `${row.durationMs} ms` });
  if (row.checkedAt) extra.push({ label: "检测时间", value: formatDateTime(row.checkedAt) });
  view.rows = [...extra, ...view.rows];

  if (Array.isArray(chain) && chain.length > 1) {
    view.rows.push({ label: "跳转链", value: chain.join(" → ") });
  }

  view.rawJson = JSON.stringify(
    {
      dnsRecords: dns,
      sslInfo: ssl,
      rawDetail: raw,
      redirectChain: chain,
    },
    null,
    2,
  );
  return view;
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export async function pollCheckBatch(
  batchId: string,
  onProgress: (status: DmCheckBatchStatus) => void,
  intervalMs = 1000,
): Promise<DmCheckBatchStatus> {
  for (;;) {
    const { data } = await domainMonitorApi.getCheckBatchStatus(batchId);
    if (!data) {
      throw new Error("无法获取检测进度");
    }
    onProgress(data);
    if (!data.running) {
      return data;
    }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
}

export async function waitDomainCheckDone(
  domainId: string,
  previousLastCheckAt?: string | null,
  timeoutMs = 120000,
): Promise<DmDomain | null> {
  const start = Date.now();
  const sinceTs = previousLastCheckAt
    ? new Date(previousLastCheckAt).getTime()
    : 0;
  while (Date.now() - start < timeoutMs) {
    await new Promise((r) => setTimeout(r, 1000));
    const { data } = await domainMonitorApi.getDomain(domainId);
    const domain = data?.domain;
    if (!domain?.lastCheckAt) continue;
    const ts = new Date(domain.lastCheckAt).getTime();
    if (!sinceTs || ts > sinceTs + 500) {
      return domain;
    }
  }
  return null;
}

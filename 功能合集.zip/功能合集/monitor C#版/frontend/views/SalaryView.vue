<template>
  <div class="salary-view">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <div class="salary-container">
      <div class="salary-header">
        <h1 class="page-title">
          <el-icon><Money /></el-icon>
          工资单
        </h1>
        <div class="month-selector">
          <el-select
            v-model="selectedMonth"
            @change="loadMySalary"
            placeholder="选择月份"
            size="large"
          >
            <el-option
              v-for="month in availableMonths"
              :key="month"
              :label="formatMonth(month)"
              :value="month"
            />
          </el-select>
        </div>
      </div>

      <div v-if="loading" class="loading-container">
        <el-icon class="is-loading" :size="40"><Loading /></el-icon>
        <span>加载中...</span>
      </div>

      <div v-else-if="mySalary" class="salary-card">
        <!-- 员工信息 -->
        <div class="employee-info">
          <div class="avatar-wrapper">
            <el-avatar
              :size="80"
              :style="{
                backgroundColor: getAvatarColor(mySalary.employeeName),
              }"
            >
              {{ mySalary.employeeName?.charAt(0) }}
            </el-avatar>
          </div>
          <div class="info-details">
            <h2 class="employee-name">{{ mySalary.employeeName }}</h2>
            <div class="employee-meta">
              <el-tag type="primary" size="large">{{
                mySalary.position || "员工"
              }}</el-tag>
              <el-tag type="info" size="large">{{
                formatMonth(selectedMonth)
              }}</el-tag>
            </div>
          </div>
        </div>

        <!-- 工资明细 -->
        <div class="salary-details">
          <!-- 基本信息 -->
          <div class="detail-section">
            <h3 class="section-title">基本信息</h3>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">职务</span>
                <span class="detail-value">{{ mySalary.position || "-" }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">入职日期-部门</span>
                <span class="detail-value">{{
                  mySalary.hireDateDept || "-"
                }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">在职月数</span>
                <span class="detail-value"
                  >{{ mySalary.monthsEmployed || 0 }}个月</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">汇率</span>
                <span class="detail-value">{{
                  mySalary.exchangeRate || 0
                }}</span>
              </div>
            </div>
          </div>

          <!-- 工资构成 -->
          <div class="detail-section">
            <h3 class="section-title">工资构成</h3>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">上月底薪</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.lastMonthBase) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">递增总额</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.totalIncrease) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">底薪(RMB)</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.baseSalary) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">出勤</span>
                <span class="detail-value"
                  >{{ mySalary.attendanceDays }}天</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">实际底薪</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.actualBaseSalary) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">调勤</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.attendanceAdjustment) }}</span
                >
              </div>
            </div>
          </div>

          <!-- 绩效与奖励 -->
          <div class="detail-section">
            <h3 class="section-title">绩效与奖励</h3>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">绩效分数</span>
                <span class="detail-value"
                  >{{ mySalary.performanceScore || 0 }}分</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">绩效奖励B</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.performanceBonusB) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">奖励</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.reward) }}</span
                >
              </div>
            </div>
          </div>

          <!-- 扣款项目 -->
          <div class="detail-section deduction-section">
            <h3 class="section-title">扣款项目</h3>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">罚款</span>
                <span class="detail-value penalty"
                  >-¥{{ formatNumber(mySalary.penalty) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">预支15-15</span>
                <span class="detail-value deduction"
                  >-¥{{ formatNumber(mySalary.advance) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">其他扣款</span>
                <span class="detail-value deduction"
                  >-¥{{ formatNumber(mySalary.otherDeduction) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">保护费</span>
                <span class="detail-value deduction"
                  >-¥{{ formatNumber(mySalary.protectionFee) }}</span
                >
              </div>
            </div>
          </div>

          <!-- 保护费返还 -->
          <div class="detail-section">
            <h3 class="section-title">保护费返还</h3>
            <div class="detail-item">
              <span class="detail-label">保护费返还</span>
              <span class="detail-value"
                >+¥{{ formatNumber(mySalary.protectionReturn) }}</span
              >
            </div>
          </div>

          <!-- 合计 -->
          <div class="detail-section total-section">
            <div class="total-item">
              <span class="total-label">实发合计</span>
              <span class="total-value"
                >¥{{ formatNumber(mySalary.totalSalary) }}</span
              >
            </div>
            <div class="total-item" v-if="mySalary.remark">
              <span class="total-label">备注</span>
              <span class="total-remark">{{ mySalary.remark }}</span>
            </div>
          </div>
        </div>

        <!-- 打印按钮 -->
        <div class="print-btn-wrapper">
          <el-button type="primary" size="large" @click="printSalary">
            <el-icon><Printer /></el-icon>
            打印工资条
          </el-button>
        </div>
      </div>

      <div v-else-if="!loading" class="empty-state">
        <el-empty description="暂无工资数据">
          <template #image>
            <el-icon :size="80" color="#c0c4cc"><Money /></el-icon>
          </template>
          <el-button type="primary" @click="loadMySalary">刷新</el-button>
        </el-empty>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { Money, Loading, Printer } from "@element-plus/icons-vue";
import adminApi from "@api/admin_api";

const loading = ref(false);
const mySalary = ref<any>(null);
const selectedMonth = ref(getLastMonth());
const availableMonths = ref<string[]>([]);

function getLastMonth() {
  const now = new Date();
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${lastMonth.getFullYear()}-${String(lastMonth.getMonth() + 1).padStart(2, "0")}`;
}

function formatMonth(month: string) {
  if (!month) return "-";
  const [year, m] = month.split("-");
  return `${year}年${parseInt(m)}月`;
}

function formatNumber(num: number) {
  if (num === undefined || num === null) return "0";
  return num.toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function getAvatarColor(name: string) {
  const colors = [
    "#667eea",
    "#764ba2",
    "#f093fb",
    "#4facfe",
    "#43e97b",
    "#fa709a",
  ];
  const index = (name?.charCodeAt(0) || 0) % colors.length;
  return colors[index];
}

async function loadAvailableMonths() {
  try {
    const response = await adminApi.getSalaryMonths();
    availableMonths.value = response.data || [];
    if (availableMonths.value.length > 0 && !selectedMonth.value) {
      selectedMonth.value = availableMonths.value[0];
    }
  } catch (error) {
    console.error("加载月份列表失败:", error);
  }
}

async function loadMySalary() {
  loading.value = true;
  try {
    const params: any = {};
    if (selectedMonth.value) params.yearMonth = selectedMonth.value;
    const response = await adminApi.getSalaryRecords(params);
    const records = response.data?.items || [];
    mySalary.value = records[0] || null;
  } catch (error: any) {
    ElMessage.error(error.message || "加载工资数据失败");
    mySalary.value = null;
  } finally {
    loading.value = false;
  }
}

function printSalary() {
  const printContent = document
    .querySelector(".salary-card")
    ?.cloneNode(true) as HTMLElement;
  if (!printContent) return;

  const printWindow = window.open("", "_blank");
  if (!printWindow) return;

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"><title>工资条 - ${mySalary.value?.employeeName}</title>
    <style>
      body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; padding: 40px; margin: 0; }
      .salary-card { max-width: 800px; margin: 0 auto; border: 1px solid #e4e7ed; border-radius: 16px; padding: 24px; }
      .employee-info { display: flex; align-items: center; gap: 24px; margin-bottom: 32px; padding-bottom: 24px; border-bottom: 2px solid #f0f2f6; }
      .employee-name { margin: 0 0 8px 0; font-size: 24px; }
      .detail-section { margin-bottom: 24px; }
      .section-title { margin-bottom: 16px; font-size: 18px; color: #303133; }
      .detail-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
      .detail-item { display: flex; justify-content: space-between; padding: 12px; background: #f5f7fa; border-radius: 8px; }
      .detail-label { color: #909399; }
      .detail-value { font-weight: 600; color: #303133; }
      .penalty, .deduction { color: #f56c6c; }
      .total-section { margin-top: 24px; padding-top: 24px; border-top: 2px solid #f0f2f6; }
      .total-item { display: flex; justify-content: space-between; padding: 16px; background: linear-gradient(135deg, #667eea10, #764ba210); border-radius: 12px; }
      .total-label { font-size: 18px; font-weight: 600; }
      .total-value { font-size: 28px; font-weight: 700; color: #67c23a; }
      .print-btn-wrapper { display: none; }
    </style>
    </head>
    <body>${printContent.outerHTML}</body>
    </html>
  `);
  printWindow.document.close();
  printWindow.print();
}

onMounted(() => {
  loadAvailableMonths();
  loadMySalary();
});
</script>

<style scoped>
.salary-view {
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
  padding: 20px;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}
.blob-1 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -200px;
  right: -100px;
}
.blob-2 {
  width: 600px;
  height: 600px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -250px;
  left: -150px;
}
.blob-3 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 30%;
}

@keyframes float {
  0%,
  100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -30px) scale(1.05);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.95);
  }
}

.salary-container {
  max-width: 1000px;
  margin: 0 auto;
  position: relative;
  z-index: 1;
}
.salary-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  flex-wrap: wrap;
  gap: 16px;
}
.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 28px;
  font-weight: 700;
  color: #1a1a2e;
  margin: 0;
}
.month-selector {
  min-width: 160px;
}
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 400px;
  gap: 16px;
  color: #909399;
}
.salary-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  padding: 32px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
}
.employee-info {
  display: flex;
  align-items: center;
  gap: 24px;
  margin-bottom: 32px;
  padding-bottom: 24px;
  border-bottom: 2px solid #f0f2f6;
}
.avatar-wrapper {
  flex-shrink: 0;
}
.employee-name {
  margin: 0 0 12px 0;
  font-size: 28px;
  font-weight: 700;
  color: #1a1a2e;
}
.employee-meta {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.salary-details {
  display: flex;
  flex-direction: column;
  gap: 28px;
}
.detail-section {
  background: rgba(248, 250, 252, 0.6);
  border-radius: 16px;
  padding: 20px;
}
.section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 16px 0;
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}
.detail-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}
.detail-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 16px;
  background: white;
  border-radius: 12px;
  transition: all 0.2s;
}
.detail-item:hover {
  transform: translateX(4px);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}
.detail-label {
  color: #909399;
  font-size: 14px;
}
.detail-value {
  font-weight: 600;
  color: #303133;
  font-size: 16px;
}
.detail-value.penalty,
.detail-value.deduction {
  color: #f56c6c;
}
.total-section {
  background: linear-gradient(135deg, #667eea08, #764ba208);
  border: 1px solid #e8ecf1;
}
.total-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
}
.total-item:first-child {
  border-bottom: 1px solid #e8ecf1;
}
.total-label {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}
.total-value {
  font-size: 32px;
  font-weight: 700;
  color: #67c23a;
}
.total-remark {
  color: #909399;
  font-size: 14px;
}
.print-btn-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 32px;
  padding-top: 24px;
  border-top: 1px solid #f0f2f6;
}
.print-btn-wrapper .el-button {
  padding: 12px 40px;
  border-radius: 40px;
}
.empty-state {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  padding: 60px;
  text-align: center;
}

@media (max-width: 768px) {
  .salary-container {
    padding: 0;
  }
  .salary-card {
    padding: 20px;
  }
  .employee-info {
    flex-direction: column;
    text-align: center;
  }
  .detail-grid {
    grid-template-columns: 1fr;
  }
  .detail-item {
    flex-direction: column;
    text-align: center;
    gap: 8px;
  }
  .total-value {
    font-size: 24px;
  }
  .salary-header {
    flex-direction: column;
    text-align: center;
  }
}
</style>

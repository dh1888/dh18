<template>
  <div class="salary-management">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <div class="stat-card-modern">
        <div class="stat-card-inner">
          <div
            class="stat-icon-wrapper"
            style="
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            "
          >
            <el-icon :size="28"><Money /></el-icon>
          </div>
          <div class="stat-details">
            <div class="stat-value">¥{{ formatNumber(totalAmount) }}</div>
            <div class="stat-label">总实发金额</div>
          </div>
        </div>
      </div>
      <div class="stat-card-modern">
        <div class="stat-card-inner">
          <div
            class="stat-icon-wrapper"
            style="
              background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            "
          >
            <el-icon :size="28"><User /></el-icon>
          </div>
          <div class="stat-details">
            <div class="stat-value">{{ salaryRecords.length }}</div>
            <div class="stat-label">发放人数</div>
          </div>
        </div>
      </div>
      <div class="stat-card-modern">
        <div class="stat-card-inner">
          <div
            class="stat-icon-wrapper"
            style="
              background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            "
          >
            <el-icon :size="28"><TrendCharts /></el-icon>
          </div>
          <div class="stat-details">
            <div class="stat-value">{{ formatNumber(avgSalary) }}</div>
            <div class="stat-label">人均实发</div>
          </div>
        </div>
      </div>
      <div class="stat-card-modern">
        <div class="stat-card-inner">
          <div
            class="stat-icon-wrapper"
            style="
              background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            "
          >
            <el-icon :size="28"><Calendar /></el-icon>
          </div>
          <div class="stat-details">
            <div class="stat-value">{{ currentMonth }}</div>
            <div class="stat-label">当前月份</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 工具栏 -->
    <el-card class="toolbar-card" shadow="hover">
      <div class="toolbar-container">
        <div class="toolbar-filters">
          <div class="filter-item">
            <el-date-picker
              v-model="selectedMonth"
              type="month"
              placeholder="选择月份"
              format="YYYY年MM月"
              value-format="YYYY-MM"
              @change="loadSalaryRecords"
              size="large"
              class="month-picker"
            />
          </div>
          <div class="filter-item">
            <el-input
              v-model="searchKeyword"
              placeholder="搜索员工姓名"
              clearable
              :prefix-icon="Search"
              @input="handleSearch"
              size="large"
              class="search-input"
            />
          </div>
        </div>
        <div class="toolbar-actions">
          <el-button
            class="action-btn primary-btn"
            @click="showUploadDialog"
            v-permission="'salary:upload'"
          >
            <el-icon><Upload /></el-icon>
            上传工资表
          </el-button>
          <el-button
            class="action-btn"
            @click="loadSalaryRecords"
            :loading="loading"
          >
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
          <el-button
            class="action-btn"
            @click="exportData"
            :disabled="salaryRecords.length === 0"
          >
            <el-icon><Download /></el-icon>
            导出
          </el-button>
        </div>
      </div>
    </el-card>

    <!-- 工资表格 -->
    <el-card class="table-card-modern" shadow="hover">
      <el-table
        v-loading="loading"
        :data="filteredRecords"
        stripe
        border
        style="width: 100%"
        :header-cell-style="headerCellStyle"
      >
        <el-table-column type="index" width="50" label="序号" fixed="left" />
        <el-table-column
          prop="employeeName"
          label="姓名"
          width="100"
          fixed="left"
        >
          <template #default="{ row }">
            <div class="employee-cell">
              <el-avatar
                :size="32"
                :style="{ backgroundColor: getAvatarColor(row.employeeName) }"
              >
                {{ row.employeeName?.charAt(0) }}
              </el-avatar>
              <span>{{ row.employeeName }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="position" label="职务" width="100" />
        <el-table-column
          prop="hireDateDept"
          label="入职日期-部门"
          width="150"
          show-overflow-tooltip
        />
        <el-table-column
          prop="monthsEmployed"
          label="在职月数"
          width="90"
          align="center"
        />
        <el-table-column
          prop="lastMonthBase"
          label="上月底薪"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.lastMonthBase) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="totalIncrease"
          label="递增总额"
          width="100"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.totalIncrease) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="baseSalary"
          label="底薪(RMB)"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.baseSalary) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="attendanceDays"
          label="出勤"
          width="80"
          align="center"
        >
          <template #default="{ row }">{{ row.attendanceDays }}天</template>
        </el-table-column>
        <el-table-column
          prop="actualBaseSalary"
          label="实际底薪"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.actualBaseSalary) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="attendanceAdjustment"
          label="调勤"
          width="80"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.attendanceAdjustment) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="halfYearUnpaidLeave"
          label="半年未休"
          width="100"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.halfYearUnpaidLeave) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="exchangeRate"
          label="汇率"
          width="80"
          align="right"
        >
          <template #default="{ row }">{{ row.exchangeRate }}</template>
        </el-table-column>
        <el-table-column
          prop="performanceScore"
          label="绩效分数"
          width="90"
          align="center"
        />
        <el-table-column
          prop="performanceBonusB"
          label="绩效奖励B"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.performanceBonusB) }}</template
          >
        </el-table-column>
        <el-table-column prop="reward" label="奖励" width="100" align="right">
          <template #default="{ row }"
            >¥{{ formatNumber(row.reward) }}</template
          >
        </el-table-column>
        <el-table-column prop="penalty" label="罚款" width="100" align="right">
          <template #default="{ row }">
            <span class="penalty-amount">¥{{ formatNumber(row.penalty) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="advance"
          label="预支15-15"
          width="100"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.advance) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="otherDeduction"
          label="其他扣款"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.otherDeduction) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="protectionReturn"
          label="保护费返还"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.protectionReturn) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="protectionFee"
          label="保护费"
          width="100"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.protectionFee) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="totalSalary"
          label="实发合计"
          width="120"
          align="right"
          fixed="right"
        >
          <template #default="{ row }">
            <span class="total-salary"
              >¥{{ formatNumber(row.totalSalary) }}</span
            >
          </template>
        </el-table-column>
        <el-table-column
          prop="remark"
          label="备注"
          min-width="150"
          show-overflow-tooltip
        />
        <el-table-column label="操作" width="150" fixed="right" align="center">
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              size="small"
              @click="editRecord(row)"
              v-permission="'salary:edit'"
            >
              <el-icon><Edit /></el-icon>编辑
            </el-button>
            <el-button
              link
              type="danger"
              size="small"
              @click="deleteRecord(row)"
              v-permission="'salary:delete'"
            >
              <el-icon><Delete /></el-icon>删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 上传对话框 -->
    <el-dialog
      v-model="uploadVisible"
      title="上传工资表"
      width="600px"
      class="modern-dialog"
    >
      <el-form :model="uploadForm" label-width="100px">
        <el-form-item label="选择月份" required>
          <el-date-picker
            v-model="uploadForm.yearMonth"
            type="month"
            placeholder="选择工资月份"
            format="YYYY年MM月"
            value-format="YYYY-MM"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="上传文件" required>
          <el-upload
            ref="uploadRef"
            :auto-upload="false"
            :on-change="handleFileChange"
            :limit="1"
            accept=".xlsx,.xls"
            drag
          >
            <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
            <div class="el-upload__text">拖拽文件到此或<em>点击选择</em></div>
            <template #tip>
              <div class="el-upload__tip">
                支持 .xlsx, .xls 格式，请确保Excel中包含所有工资列
              </div>
            </template>
          </el-upload>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="uploadVisible = false">取消</el-button>
        <el-button type="primary" @click="uploadSalary" :loading="uploading"
          >开始上传</el-button
        >
      </template>
    </el-dialog>

    <!-- 编辑对话框 -->
    <el-dialog
      v-model="editVisible"
      title="编辑工资记录"
      width="800px"
      class="modern-dialog"
    >
      <el-form :model="editForm" label-width="120px" class="edit-form">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="员工姓名">
              <el-input v-model="editForm.employeeName" disabled />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="职务">
              <el-input v-model="editForm.position" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="入职日期-部门">
              <el-input v-model="editForm.hireDateDept" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="在职月数">
              <el-input-number
                v-model="editForm.monthsEmployed"
                :min="0"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="上月底薪">
              <el-input-number
                v-model="editForm.lastMonthBase"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="递增总额">
              <el-input-number
                v-model="editForm.totalIncrease"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="底薪(RMB)">
              <el-input-number
                v-model="editForm.baseSalary"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="出勤">
              <el-input-number
                v-model="editForm.attendanceDays"
                :min="0"
                :step="0.5"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="实际底薪">
              <el-input-number
                v-model="editForm.actualBaseSalary"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="调勤">
              <el-input-number
                v-model="editForm.attendanceAdjustment"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="半年未休">
              <el-input-number
                v-model="editForm.halfYearUnpaidLeave"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="汇率">
              <el-input-number
                v-model="editForm.exchangeRate"
                :min="0"
                :step="0.1"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="绩效分数">
              <el-input-number
                v-model="editForm.performanceScore"
                :min="0"
                :max="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="绩效奖励B">
              <el-input-number
                v-model="editForm.performanceBonusB"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="奖励">
              <el-input-number
                v-model="editForm.reward"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="罚款">
              <el-input-number
                v-model="editForm.penalty"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="预支15-15">
              <el-input-number
                v-model="editForm.advance"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="其他扣款">
              <el-input-number
                v-model="editForm.otherDeduction"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保护费返还">
              <el-input-number
                v-model="editForm.protectionReturn"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="保护费">
              <el-input-number
                v-model="editForm.protectionFee"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="实发合计">
              <el-input-number
                v-model="editForm.totalSalary"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="备注">
          <el-input
            v-model="editForm.remark"
            type="textarea"
            :rows="2"
            placeholder="请输入备注"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="editVisible = false">取消</el-button>
        <el-button type="primary" @click="saveEdit" :loading="saving"
          >保存修改</el-button
        >
      </template>
    </el-dialog>

    <!-- 上传结果对话框 -->
    <el-dialog v-model="resultVisible" title="上传结果" width="500px">
      <el-alert
        :type="resultData.failCount === 0 ? 'success' : 'warning'"
        :closable="false"
        show-icon
      >
        <template #title>
          成功 {{ resultData.successCount }} 条，失败
          {{ resultData.failCount }} 条
        </template>
      </el-alert>
      <div v-if="resultData.failedRecords?.length" class="failed-records">
        <el-divider />
        <h4>失败记录：</h4>
        <el-table :data="resultData.failedRecords" size="small">
          <el-table-column prop="row" label="行号" width="80" />
          <el-table-column prop="name" label="姓名" width="120" />
          <el-table-column prop="reason" label="原因" />
        </el-table>
      </div>
      <template #footer>
        <el-button type="primary" @click="resultVisible = false"
          >确定</el-button
        >
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Search,
  Refresh,
  Upload,
  Download,
  Edit,
  Delete,
  UploadFilled,
  Money,
  User,
  TrendCharts,
  Calendar,
} from "@element-plus/icons-vue";
import adminApi from "@api/admin_api";

const loading = ref(false);
const uploading = ref(false);
const saving = ref(false);
const uploadVisible = ref(false);
const editVisible = ref(false);
const resultVisible = ref(false);
const salaryRecords = ref<any[]>([]);
const searchKeyword = ref("");
const selectedMonth = ref(getLastMonth());
const uploadRef = ref();

const uploadForm = ref({
  yearMonth: getLastMonth(),
  file: null,
});

const editForm = ref<any>({});

const resultData = ref({
  successCount: 0,
  failCount: 0,
  failedRecords: [] as any[],
});

const headerCellStyle = {
  background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
  color: "#ffffff",
  fontWeight: "600",
  fontSize: "14px",
  textAlign: "center",
};

const filteredRecords = computed(() => {
  if (!searchKeyword.value) return salaryRecords.value;
  const keyword = searchKeyword.value.toLowerCase();
  return salaryRecords.value.filter((r) =>
    r.employeeName?.toLowerCase().includes(keyword),
  );
});

const totalAmount = computed(() => {
  return salaryRecords.value.reduce((sum, r) => sum + (r.totalSalary || 0), 0);
});

const avgSalary = computed(() => {
  if (salaryRecords.value.length === 0) return 0;
  return totalAmount.value / salaryRecords.value.length;
});

const currentMonth = computed(() => {
  if (!selectedMonth.value) return "-";
  const [year, month] = selectedMonth.value.split("-");
  return `${year}年${parseInt(month)}月`;
});

function getLastMonth() {
  const now = new Date();
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${lastMonth.getFullYear()}-${String(lastMonth.getMonth() + 1).padStart(2, "0")}`;
}

function formatNumber(num: number) {
  if (num === undefined || num === null) return "0";
  return num.toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function getAvatarColor(name: string) {
  const colors = [
    "#667eea",
    "#764ba2",
    "#f093fb",
    "#4facfe",
    "#43e97b",
    "#fa709a",
  ];
  const index = (name?.charCodeAt(0) || 0) % colors.length;
  return colors[index];
}

async function loadSalaryRecords() {
  loading.value = true;
  try {
    const params: any = {};
    if (selectedMonth.value) params.yearMonth = selectedMonth.value;
    const response = await adminApi.getSalaryRecords(params);
    salaryRecords.value = response.data?.items || [];
  } catch (error: any) {
    ElMessage.error(error.message || "加载数据失败");
  } finally {
    loading.value = false;
  }
}

function handleSearch() {}

function showUploadDialog() {
  uploadForm.value = {
    yearMonth: selectedMonth.value || getLastMonth(),
    file: null,
  };
  if (uploadRef.value) uploadRef.value.clearFiles();
  uploadVisible.value = true;
}

function handleFileChange(file: any) {
  uploadForm.value.file = file.raw;
}

async function uploadSalary() {
  if (!uploadForm.value.yearMonth) {
    ElMessage.warning("请选择月份");
    return;
  }
  if (!uploadForm.value.file) {
    ElMessage.warning("请选择文件");
    return;
  }

  uploading.value = true;
  try {
    const formData = new FormData();
    formData.append("file", uploadForm.value.file);
    formData.append("yearMonth", uploadForm.value.yearMonth);

    const response = await adminApi.uploadSalary(formData);
    const data = response.data;

    resultData.value = {
      successCount: data.successCount || 0,
      failCount: data.failCount || 0,
      failedRecords: data.failedRecords || [],
    };

    resultVisible.value = true;
    uploadVisible.value = false;

    if (data.successCount > 0) {
      ElMessage.success(`成功上传 ${data.successCount} 条记录`);
      await loadSalaryRecords();
    }
  } catch (error: any) {
    ElMessage.error(error.message || "上传失败");
  } finally {
    uploading.value = false;
  }
}

function editRecord(row: any) {
  editForm.value = { ...row };
  editVisible.value = true;
}

async function saveEdit() {
  saving.value = true;
  try {
    await adminApi.updateSalaryRecord(editForm.value.id, editForm.value);
    ElMessage.success("保存成功");
    editVisible.value = false;
    await loadSalaryRecords();
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    saving.value = false;
  }
}

async function deleteRecord(row: any) {
  try {
    await ElMessageBox.confirm(
      `确定要删除员工 "${row.employeeName}" 的工资记录吗？`,
      "警告",
      {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      },
    );
    await adminApi.deleteSalaryRecord(row.id);
    ElMessage.success("删除成功");
    await loadSalaryRecords();
  } catch (error: any) {
    if (error !== "cancel") {
      ElMessage.error(error.message || "删除失败");
    }
  }
}

function exportData() {
  if (filteredRecords.value.length === 0) {
    ElMessage.warning("没有数据可导出");
    return;
  }

  const headers = [
    "姓名",
    "职务",
    "入职日期-部门",
    "在职月数",
    "上月底薪",
    "递增总额",
    "底薪(RMB)",
    "出勤",
    "实际底薪",
    "调勤",
    "半年未休",
    "汇率",
    "绩效分数",
    "绩效奖励B",
    "奖励",
    "罚款",
    "预支15-15",
    "其他扣款",
    "保护费返还",
    "保护费",
    "实发合计",
    "备注",
  ];
  const rows = filteredRecords.value.map((r) => [
    r.employeeName,
    r.position,
    r.hireDateDept,
    r.monthsEmployed,
    r.lastMonthBase,
    r.totalIncrease,
    r.baseSalary,
    r.attendanceDays,
    r.actualBaseSalary,
    r.attendanceAdjustment,
    r.halfYearUnpaidLeave,
    r.exchangeRate,
    r.performanceScore,
    r.performanceBonusB,
    r.reward,
    r.penalty,
    r.advance,
    r.otherDeduction,
    r.protectionReturn,
    r.protectionFee,
    r.totalSalary,
    r.remark || "",
  ]);

  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
  ].join("\n");
  const blob = new Blob(["\uFEFF" + csvContent], {
    type: "text/csv;charset=utf-8;",
  });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `工资表_${selectedMonth.value}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
  ElMessage.success("导出成功");
}

onMounted(() => {
  loadSalaryRecords();
});
</script>

<style scoped>
.salary-management {
  padding: 0px;
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}

.blob-1 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -200px;
  right: -100px;
}
.blob-2 {
  width: 600px;
  height: 600px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -250px;
  left: -150px;
}
.blob-3 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 30%;
}

@keyframes float {
  0%,
  100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -30px) scale(1.05);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.95);
  }
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 24px;
  position: relative;
  z-index: 1;
}

.stat-card-modern {
  background: #ffffff;
  border-radius: 20px;
  overflow: hidden;
  position: relative;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
  transition: all 0.3s ease;
}

.stat-card-modern:hover {
  transform: translateY(-6px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
}

.stat-card-inner {
  padding: 20px 24px;
  display: flex;
  align-items: center;
  gap: 16px;
  position: relative;
  z-index: 2;
}

.stat-icon-wrapper {
  width: 56px;
  height: 56px;
  border-radius: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
}

.stat-details {
  flex: 1;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #1a1a2e;
  line-height: 1.2;
  margin-bottom: 6px;
}

.stat-label {
  font-size: 13px;
  color: #666;
  font-weight: 500;
}

.toolbar-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  margin-bottom: 20px;
  position: relative;
  z-index: 1;
}

.toolbar-card :deep(.el-card__body) {
  padding: 16px 20px;
}

.toolbar-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 16px;
}

.toolbar-filters {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.filter-item {
  min-width: 160px;
}
.toolbar-actions {
  display: flex;
  gap: 12px;
}

.action-btn {
  border-radius: 12px;
  padding: 10px 20px;
  font-weight: 500;
  transition: all 0.3s ease;
  background: #f5f5f5;
  border-color: #e0e0e0;
  color: #666;
}
.action-btn:hover {
  transform: translateY(-2px);
}
.primary-btn {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border: none;
  color: white;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}
.primary-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(102, 126, 234, 0.4);
  color: white;
}

.table-card-modern {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  overflow: hidden;
  position: relative;
  z-index: 1;
}

.penalty-amount {
  color: #f56c6c;
  font-weight: 600;
}
.total-salary {
  color: #67c23a;
  font-weight: 700;
  font-size: 16px;
}
.employee-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.modern-dialog :deep(.el-dialog) {
  border-radius: 20px;
  overflow: hidden;
}
.modern-dialog :deep(.el-dialog__header) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  padding: 16px 20px;
  margin: 0;
}
.modern-dialog :deep(.el-dialog__title) {
  color: white;
  font-weight: 600;
  font-size: 18px;
}
.modern-dialog :deep(.el-dialog__body) {
  padding: 20px;
}

.failed-records {
  margin-top: 16px;
}
.edit-form :deep(.el-input-number) {
  width: 100%;
}

@media (max-width: 1200px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }
  .toolbar-container {
    flex-direction: column;
    align-items: stretch;
  }
  .toolbar-filters {
    flex-direction: column;
  }
  .filter-item {
    width: 100%;
  }
  .toolbar-actions {
    justify-content: flex-end;
  }
}
</style>

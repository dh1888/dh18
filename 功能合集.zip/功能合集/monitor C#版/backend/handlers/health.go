package handlers

import (
	"context"
	"database/sql"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"github.com/shirou/gopsutil/v3/disk"

	"enterprise-agent/backend/models"
)

const (
	healthCheckTimeout   = 2 * time.Second
	diskNotReadyPercent  = 95.0
	diskWritableProbeFile = ".health_probe"
)

type HealthHandler struct {
	db            *sql.DB
	redis         *redis.Client
	uploadsDir    string
	liveKitPing   func(context.Context) error
}

func NewHealthHandler(db *sql.DB, redisClient *redis.Client, uploadsDir string) *HealthHandler {
	return &HealthHandler{
		db:         db,
		redis:      redisClient,
		uploadsDir: uploadsDir,
	}
}

func (h *HealthHandler) SetLiveKitPing(fn func(context.Context) error) {
	h.liveKitPing = fn
}

// Live 进程存活探针（不检查依赖）
func (h *HealthHandler) Live(c *gin.Context) {
	models.Send(c, http.StatusOK, 0, "ok", gin.H{"status": "ok"})
}

// Ready 就绪探针：检查 DB / Redis / 磁盘
func (h *HealthHandler) Ready(c *gin.Context) {
	ctx, cancel := context.WithTimeout(c.Request.Context(), healthCheckTimeout)
	defer cancel()

	checks := gin.H{}
	ready := true

	if h.db == nil {
		checks["database"] = gin.H{"status": "down", "error": "not configured"}
		ready = false
	} else if err := h.db.PingContext(ctx); err != nil {
		checks["database"] = gin.H{"status": "down", "error": err.Error()}
		ready = false
	} else {
		checks["database"] = gin.H{"status": "up"}
	}

	if h.redis == nil {
		checks["redis"] = gin.H{"status": "down", "error": "not configured"}
		ready = false
	} else if err := h.redis.Ping(ctx).Err(); err != nil {
		checks["redis"] = gin.H{"status": "down", "error": err.Error()}
		ready = false
	} else {
		checks["redis"] = gin.H{"status": "up"}
	}

	diskStatus, diskReady := h.checkDisk(ctx)
	checks["disk"] = diskStatus
	if !diskReady {
		ready = false
	}

	checks["livekit"] = h.checkLiveKit(ctx)

	status := "ready"
	httpStatus := http.StatusOK
	if !ready {
		status = "not_ready"
		httpStatus = http.StatusServiceUnavailable
	}

	c.JSON(httpStatus, gin.H{
		"code":    0,
		"message": status,
		"data": gin.H{
			"status": status,
			"checks": checks,
		},
	})
}

func (h *HealthHandler) checkDisk(ctx context.Context) (gin.H, bool) {
	if h.uploadsDir == "" {
		return gin.H{"status": "down", "error": "uploads dir not configured"}, false
	}

	if err := os.MkdirAll(h.uploadsDir, 0755); err != nil {
		return gin.H{"status": "down", "error": err.Error()}, false
	}

	probe := filepath.Join(h.uploadsDir, diskWritableProbeFile)
	if err := os.WriteFile(probe, []byte("ok"), 0644); err != nil {
		return gin.H{"status": "down", "error": "not writable: " + err.Error()}, false
	}
	_ = os.Remove(probe)

	absPath, err := filepath.Abs(h.uploadsDir)
	if err != nil {
		return gin.H{"status": "degraded", "error": err.Error(), "writable": true}, true
	}

	usageStat, err := disk.Usage(healthDiskRoot(absPath))
	if err != nil {
		return gin.H{
			"status":    "degraded",
			"writable":  true,
			"error":     err.Error(),
		}, true
	}

	usedPercent := usageStat.UsedPercent
	result := gin.H{
		"status":       "up",
		"writable":     true,
		"usedPercent":  usedPercent,
		"freeGb":       float64(usageStat.Free) / (1024 * 1024 * 1024),
		"totalGb":      float64(usageStat.Total) / (1024 * 1024 * 1024),
	}

	if usedPercent >= diskNotReadyPercent {
		result["status"] = "down"
		result["error"] = "disk usage critical"
		return result, false
	}

	_ = ctx
	return result, true
}

func (h *HealthHandler) checkLiveKit(ctx context.Context) gin.H {
	if h.liveKitPing == nil {
		return gin.H{"status": "not_configured"}
	}
	if err := h.liveKitPing(ctx); err != nil {
		return gin.H{"status": "down", "error": err.Error()}
	}
	return gin.H{"status": "up"}
}

func healthDiskRoot(path string) string {
	if runtime.GOOS == "windows" {
		vol := filepath.VolumeName(path)
		if vol != "" {
			return vol + string(filepath.Separator)
		}
		return "C:\\"
	}
	return "/"
}

// backend/handlers/recording.go
// 完整替换文件内容

package handlers

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// 批量删除最大数量限制
const maxRecordingBatchDelete = 50

type RecordingHandler struct {
	repo *services.RecordingRepository
	DeviceRepo *services.DeviceRepository
}

func NewRecordingHandler(repo *services.RecordingRepository, deviceRepo *services.DeviceRepository) *RecordingHandler {
	return &RecordingHandler{
		repo:       repo,
		DeviceRepo: deviceRepo,
	}
}
// List 获取录制列表（分页）
func (h *RecordingHandler) List(c *gin.Context) {
	deviceID := c.Query("deviceId")
	startTime := c.Query("startTime")
	endTime := c.Query("endTime")
	page := c.DefaultQuery("page", "1")
	pageSize := c.DefaultQuery("pageSize", "20")

	// 验证分页参数
	pageNum, _ := strconv.Atoi(page)
	pageSizeNum, _ := strconv.Atoi(pageSize)
	if pageNum < 1 {
		pageNum = 1
	}
	if pageSizeNum < 1 {
		pageSizeNum = 20
	}
	if pageSizeNum > 100 {
		pageSizeNum = 100
	}

	recordings, total, err := h.repo.List(c.Request.Context(), deviceID, startTime, endTime, page, pageSize)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items":    recordings,
		"total":    total,
		"page":     pageNum,
		"pageSize": pageSizeNum,
	})
}

// Get 获取单个录制详情
func (h *RecordingHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid recording ID")
		return
	}

	recording, err := h.repo.GetByID(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Recording not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", recording)
}
// Play 获取播放地址
func (h *RecordingHandler) Play(c *gin.Context) {
	// ✅ 记录开始时间
	startTime := time.Now()
	
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid recording ID")
		return
	}

	// 提取用户信息
	username := c.GetString("username")
	userID := c.GetString("userID")

	// ✅ 使用 defer 确保日志一定会被记录（无论成功或失败）
	defer func() {
		if username == "" && userID == "" {
			return
		}
		executionTimeMs := int(time.Since(startTime).Milliseconds())
		logUser := username
		if logUser == "" {
			logUser = userID
		}
		Log(c, "VIEW", "RECORDING",
			fmt.Sprintf("用户 %s 查看了录屏 %s (耗时 %dms)", logUser, id.String(), executionTimeMs),
			id.String(), logUser)
	}()

	// 先检查录制是否存在
	_, err = h.repo.GetByID(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Recording not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	url, err := h.repo.GetPlayURL(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 3001, "File not found")
		return
	}

	streamURL := fmt.Sprintf("/api/v1/recordings/%s/stream", id.String())

	models.Send(c, 200, 0, "success", gin.H{
		"url":         url,
		"streamUrl":   streamURL,
		"recordingId": id.String(),
	})
}
// Stream 流式播放（支持视频拖拽）
func (h *RecordingHandler) Stream(c *gin.Context) {
	// ✅ 记录开始时间
	startTime := time.Now()
	
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid recording ID")
		return
	}
	
	username := c.GetString("username")
	userID := c.GetString("userID")

	// ✅ 使用 defer 确保日志一定会被记录
	defer func() {
		if username == "" && userID == "" {
			return
		}
		executionTimeMs := int(time.Since(startTime).Milliseconds())
		logUsername := username
		if logUsername == "" {
			logUsername = userID
		}
		
		// 获取录制信息和关联的员工姓名
		recording, _ := h.repo.GetByID(context.Background(), id)
		
		employeeName := ""
		if h.DeviceRepo != nil && recording != nil {
			device, _ := h.DeviceRepo.Get(context.Background(), recording.DeviceID)
			if device != nil {
				employeeName = device.EmployeeName
				if employeeName == "" {
					employeeName = device.Hostname
				}
			}
		}
		
		// 如果没有获取到员工姓名，使用设备ID
		if employeeName == "" && recording != nil {
			employeeName = recording.DeviceID.String()[:8] + "..."
		}
		
		Log(c, "VIEW", "RECORDING",
			fmt.Sprintf("用户 %s 流式播放员工 %s 的录屏 %s (耗时 %dms)", 
				logUsername, employeeName, id.String(), executionTimeMs),
			id.String(), logUsername)
	}()

	filePath, err := h.repo.GetFilePath(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Recording not found")
		return
	}
	if errors.Is(err, services.ErrRecordingRemoteStorage) {
		url, urlErr := h.repo.GetPlayURL(c.Request.Context(), id)
		if urlErr != nil {
			models.SendError(c, 404, 3001, "File not found")
			return
		}
		c.Redirect(302, url)
		return
	}
	if err != nil {
		models.SendError(c, 404, 3001, "File not found")
		return
	}

	c.Header("Content-Type", "video/mp4")
	c.Header("Accept-Ranges", "bytes")
	c.File(filePath)
}

// Download 下载录制文件（直接流式输出，支持 Range）
func (h *RecordingHandler) Download(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid recording ID")
		return
	}

	go func() {
		username := c.GetString("username")
		if username == "" {
			return
		}

		Log(c, "DOWNLOAD", "RECORDING",
			fmt.Sprintf("用户 %s 下载录屏 %s", username, id.String()),
			id.String(), username)
	}()

	recording, err := h.repo.GetByID(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Recording not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	filePath, err := h.repo.GetFilePath(c.Request.Context(), id)
	if errors.Is(err, services.ErrRecordingRemoteStorage) {
		url, urlErr := h.repo.GetDownloadURL(c.Request.Context(), id)
		if urlErr != nil {
			models.SendError(c, 404, 3001, "File not found")
			return
		}
		c.Header("Content-Disposition", "attachment; filename="+recording.ID.String()+".mp4")
		c.Redirect(302, url)
		return
	}
	if err != nil {
		models.SendError(c, 404, 3001, "File not found")
		return
	}

	filename := recording.ID.String() + ".mp4"
	c.Header("Content-Type", "video/mp4")
	c.Header("Content-Disposition", "attachment; filename="+filename)
	c.Header("Accept-Ranges", "bytes")
	c.File(filePath)
}

// Delete 删除录制文件
func (h *RecordingHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid recording ID")
		return
	}

	// 先检查录制是否存在
	_, err = h.repo.GetByID(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Recording not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	if err := h.repo.Delete(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	username := c.GetString("username")
	if username != "" {
		Log(c, "DELETE", "RECORDING",
			fmt.Sprintf("用户 %s 删除录屏 %s", username, id.String()),
			id.String(), username)
	}

	models.Send(c, 200, 0, "Recording deleted successfully", nil)
}

// BatchDelete 批量删除录制文件
func (h *RecordingHandler) BatchDelete(c *gin.Context) {
	var req struct {
		IDs []string `json:"ids" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: "+err.Error())
		return
	}

	if len(req.IDs) == 0 {
		models.SendError(c, 400, 1001, "No IDs provided")
		return
	}

	if len(req.IDs) > maxRecordingBatchDelete {
		models.SendError(c, 400, 1001, "Maximum 50 recordings can be deleted at once")
		return
	}

	var uuids []uuid.UUID
	for _, idStr := range req.IDs {
		id, err := uuid.Parse(idStr)
		if err != nil {
			models.SendError(c, 400, 1001, "Invalid ID format: "+idStr)
			return
		}
		uuids = append(uuids, id)
	}

	deleted, err := h.repo.BatchDelete(c.Request.Context(), uuids)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "Recordings deleted", gin.H{
		"deleted": deleted,
		"total":   len(req.IDs),
	})
}

// GetStats 获取录制统计信息
func (h *RecordingHandler) GetStats(c *gin.Context) {
	deviceID := c.Query("deviceId")
	startTime := c.Query("startTime")
	endTime := c.Query("endTime")

	stats, err := h.repo.GetStats(c.Request.Context(), deviceID, startTime, endTime)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", stats)
}

// GetByDevice 获取指定设备的所有录制
func (h *RecordingHandler) GetByDevice(c *gin.Context) {
	deviceID := c.Param("deviceId")
	if deviceID == "" {
		models.SendError(c, 400, 1001, "Device ID is required")
		return
	}

	if _, err := uuid.Parse(deviceID); err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID format")
		return
	}

	startTime := c.Query("startTime")
	endTime := c.Query("endTime")
	limit := 1000

	recordings, err := h.repo.ListByDevice(c.Request.Context(), deviceID, startTime, endTime, limit)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", recordings)
}

// GetPlaybackInfo 获取播放信息（时长、大小等）
func (h *RecordingHandler) GetPlaybackInfo(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid recording ID")
		return
	}

	info, err := h.repo.GetPlaybackInfo(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Recording not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", info)
}

// ExportRecordings 导出录制列表为CSV
func (h *RecordingHandler) ExportRecordings(c *gin.Context) {
	deviceID := c.Query("deviceId")
	startTime := c.Query("startTime")
	endTime := c.Query("endTime")

	csv, err := h.repo.ExportCSV(c.Request.Context(), deviceID, startTime, endTime)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	c.Header("Content-Type", "text/csv; charset=utf-8")
	c.Header("Content-Disposition", "attachment; filename=recordings_"+time.Now().Format("20060102")+".csv")
	c.String(200, csv)
}

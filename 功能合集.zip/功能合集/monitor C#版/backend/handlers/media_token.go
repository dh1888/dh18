package handlers

import (
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type MediaTokenHandler struct {
	svc *services.MediaTokenService
}

func NewMediaTokenHandler(svc *services.MediaTokenService) *MediaTokenHandler {
	return &MediaTokenHandler{svc: svc}
}

func (h *MediaTokenHandler) Issue(c *gin.Context) {
	var req struct {
		ResourceType string `json:"resourceType" binding:"required"`
		ResourceID   string `json:"resourceId" binding:"required"`
		Action       string `json:"action" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	resourceType := strings.ToLower(strings.TrimSpace(req.ResourceType))
	action := strings.ToLower(strings.TrimSpace(req.Action))
	resourceID := strings.TrimSpace(req.ResourceID)

	if _, err := uuid.Parse(resourceID); err != nil {
		models.SendError(c, 400, 1001, "Invalid resource ID")
		return
	}

	permission, err := mediaPermissionFor(resourceType, action)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	userID := c.GetString("userID")
	if userID == "" {
		models.SendError(c, 401, 1002, "User not authenticated")
		return
	}

	if !hasContextPermission(c, permission) {
		models.SendError(c, 403, 1003, "Permission denied: "+permission)
		return
	}

	token, ttl, err := h.svc.Issue(c.Request.Context(), services.MediaAccessGrant{
		UserID:       userID,
		Username:     c.GetString("username"),
		ResourceType: resourceType,
		ResourceID:   resourceID,
		Action:       action,
	})
	if err != nil {
		models.SendError(c, 503, 5003, "Media token service unavailable")
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"mediaToken": token,
		"expiresIn":  int(ttl.Seconds()),
	})
}

func mediaPermissionFor(resourceType, action string) (string, error) {
	switch resourceType {
	case "recording":
		switch action {
		case "stream":
			return models.PermRecordingPlay, nil
		case "download":
			return models.PermRecordingExport, nil
		default:
			return "", errInvalidMediaAction
		}
	case "screenshot":
		if action == "view" {
			return models.PermScreenshotView, nil
		}
		return "", errInvalidMediaAction
	default:
		return "", errInvalidMediaResource
	}
}

var (
	errInvalidMediaAction   = &mediaRequestError{"unsupported media action"}
	errInvalidMediaResource = &mediaRequestError{"unsupported resource type"}
)

type mediaRequestError struct {
	msg string
}

func (e *mediaRequestError) Error() string { return e.msg }

func hasContextPermission(c *gin.Context, permission string) bool {
	role := c.GetString("role")
	if role == "admin" {
		return true
	}
	perms, ok := c.Get("permissions")
	if !ok {
		return false
	}
	userPermissions, ok := perms.([]string)
	if !ok {
		return false
	}
	for _, p := range userPermissions {
		if p == permission {
			return true
		}
	}
	return false
}

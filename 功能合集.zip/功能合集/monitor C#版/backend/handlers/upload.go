// backend/handlers/upload.go
// 生产就绪最终版本 - 统一使用 models 包签名

package handlers

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"github.com/google/uuid"
	"golang.org/x/time/rate"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// ========== 常量定义 ==========
const (
	maxChunkSize               = 5 * 1024 * 1024    // 5MB
	maxTotalFileSize           = 1024 * 1024 * 1024 // 1GB
	maxUploadSessions          = 10000              // 最大上传会话数
	sessionTTL                 = 1 * time.Hour      // 会话过期时间
	sessionCleanupInterval     = 10 * time.Minute
	nonceCacheTTL              = 10 * time.Minute
	timestampTolerance         = 5 * time.Minute
	maxConcurrentUploadsPerIP  = 5               // 每IP最大并发上传
	rateLimitRequestsPerSecond = 10              // 限流请求数/秒
	rateLimitBurst             = 20              // 限流突发容量
	rateLimiterCleanupInterval = 5 * time.Minute // 限流器清理间隔

	headerUploadID      = "X-Upload-Id"
	headerFileName      = "X-File-Name"
	headerFileType      = "X-File-Type"
	headerFileID        = "X-File-Id"
	headerChunkIndex    = "X-Chunk-Index"
	headerTotalChunks   = "X-Total-Chunks"
	headerChunkChecksum = "X-Chunk-Checksum"
)

// ========== 上传会话结构 ==========
type uploadSession struct {
	UploadID       string
	FileName       string
	FileType       string
	FileID         string
	TotalChunks    int
	Received       map[int]bool
	ChunkChecksums map[int]string
	LastActive     time.Time
	TotalSize      int64
	mu             sync.RWMutex
    Completed     bool          // 是否已完成
    Completing    bool          // 是否正在完成中（防并发）
    CompletedAt   time.Time     // 完成时间（响应返回）
    // CompletedOnce sync.Once     // 确保只执行一次（双重保险）
}

// ========== 会话管理器 ==========
type uploadSessionManager struct {
	sessions map[string]*uploadSession
	mu       sync.RWMutex
	stopCh   chan struct{}
	once     sync.Once
}

var sessionManager = &uploadSessionManager{
	sessions: make(map[string]*uploadSession),
	stopCh:   make(chan struct{}),
}

// startSessionManager 启动会话管理器（单个 init）
func startSessionManager() {
	go sessionManager.cleanupLoop()
}

func init() {
	startSessionManager()
	startNonceCache()
	startRateLimiterCleanup()
}

func (m *uploadSessionManager) cleanupLoop() {
	ticker := time.NewTicker(sessionCleanupInterval)
	defer ticker.Stop()

	for {
		select {
		case <-m.stopCh:
			return
		case <-ticker.C:
			m.cleanup()
		}
	}
}

func (m *uploadSessionManager) cleanup() {
    m.mu.Lock()
    defer m.mu.Unlock()

    now := time.Now()
    for id, session := range m.sessions {
        // 安全读取状态
        session.mu.RLock()
        completed := session.Completed
        completing := session.Completing
        lastActive := session.LastActive
        completedAt := session.CompletedAt
        session.mu.RUnlock()
        
        // ⭐⭐⭐ 最关键：正在完成的不删
        if completing {
            continue
        }
        
        // ✅ 活跃 session 过期清理（默认 1 小时）
        if !completed && now.Sub(lastActive) > sessionTTL {
            log.Printf("[Cleanup] Removing expired session: %s (last active: %v)", 
                id, lastActive.Format("2006-01-02 15:04:05"))
            delete(m.sessions, id)
            tempDir := filepath.Join(os.TempDir(), "uploads", id)
            os.RemoveAll(tempDir)
            m.removeSessionFromRedis(id)
            continue
        }
        
        // ✅ 已完成 session 兜底清理（60分钟，远超 Complete 的 30 分钟）
        if completed && !completedAt.IsZero() && now.Sub(completedAt) > 60*time.Minute {
            log.Printf("[Cleanup] Removing stale completed session: %s (completed at %v)", 
                id, completedAt.Format("2006-01-02 15:04:05"))
            delete(m.sessions, id)
            tempDir := filepath.Join(os.TempDir(), "uploads", id)
            os.RemoveAll(tempDir)
            m.removeSessionFromRedis(id)
        }
    }
}

func (m *uploadSessionManager) getOrCreate(req *chunkUpload) *uploadSession {
	m.mu.RLock()
	session, exists := m.sessions[req.UploadID]
	m.mu.RUnlock()

	if exists {
		session.mu.Lock()
		session.LastActive = time.Now()
		session.mu.Unlock()
		m.persistSession(session)
		return session
	}

	m.mu.Lock()
	defer m.mu.Unlock()

	if session, exists = m.sessions[req.UploadID]; exists {
		session.mu.Lock()
		session.LastActive = time.Now()
		session.mu.Unlock()
		m.persistSession(session)
		return session
	}

	if session, ok := m.loadSessionFromRedis(req.UploadID); ok {
		session.mu.Lock()
		session.LastActive = time.Now()
		session.mu.Unlock()
		m.sessions[req.UploadID] = session
		m.persistSession(session)
		return session
	}

	// LRU 淘汰（跳过正在完成或活跃的会话）
	if len(m.sessions) >= maxUploadSessions {
		var oldestID string
		var oldestTime time.Time
		for id, s := range m.sessions {
			s.mu.RLock()
			completing := s.Completing
			completed := s.Completed
			lastActive := s.LastActive
			s.mu.RUnlock()

			if completing || (!completed && time.Since(lastActive) < 5*time.Minute) {
				continue
			}

			if oldestID == "" || lastActive.Before(oldestTime) {
				oldestID = id
				oldestTime = lastActive
			}
		}
		if oldestID != "" {
			delete(m.sessions, oldestID)
			os.RemoveAll(filepath.Join(os.TempDir(), "uploads", oldestID))
		}
	}

	session = &uploadSession{
		UploadID:       req.UploadID,
		FileName:       req.FileName,
		FileType:       req.FileType,
		FileID:         req.FileID,
		TotalChunks:    req.TotalChunks,
		Received:       make(map[int]bool),
		ChunkChecksums: make(map[int]string),
		LastActive:     time.Now(),
		TotalSize:      0,
	}
	m.sessions[req.UploadID] = session
	m.persistSession(session)
	return session
}

func (m *uploadSessionManager) get(uploadID string) (*uploadSession, bool) {
	m.mu.RLock()
	session, exists := m.sessions[uploadID]
	m.mu.RUnlock()
	if exists {
		return session, true
	}

	if session, ok := m.loadSessionFromRedis(uploadID); ok {
		m.mu.Lock()
		m.sessions[uploadID] = session
		m.mu.Unlock()
		return session, true
	}

	return nil, false
}

func (m *uploadSessionManager) remove(uploadID string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, exists := m.sessions[uploadID]; exists {
		delete(m.sessions, uploadID)
		os.RemoveAll(filepath.Join(os.TempDir(), "uploads", uploadID))
	}
	m.removeSessionFromRedis(uploadID)
}

func (m *uploadSessionManager) stop() {
	m.once.Do(func() {
		close(m.stopCh)
	})
}

// ========== Nonce 缓存（防重放攻击） ==========
type nonceCache struct {
	items  map[string]time.Time
	mu     sync.RWMutex
	stopCh chan struct{}
	once   sync.Once
}

var nonceCacheInstance = &nonceCache{
	items:  make(map[string]time.Time),
	stopCh: make(chan struct{}),
}

func startNonceCache() {
	go nonceCacheInstance.cleanupLoop()
}

func (c *nonceCache) cleanupLoop() {
	ticker := time.NewTicker(nonceCacheTTL)
	defer ticker.Stop()

	for {
		select {
		case <-c.stopCh:
			return
		case <-ticker.C:
			c.cleanup()
		}
	}
}

func (c *nonceCache) cleanup() {
	c.mu.Lock()
	defer c.mu.Unlock()

	now := time.Now()
	for nonce, createdAt := range c.items {
		if now.Sub(createdAt) > nonceCacheTTL {
			delete(c.items, nonce)
		}
	}
}

func (c *nonceCache) checkAndStore(nonce string) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	if _, exists := c.items[nonce]; exists {
		return fmt.Errorf("nonce already used")
	}

	// 限制 nonce 缓存大小
	if len(c.items) > maxUploadSessions*2 {
		count := 0
		for n := range c.items {
			if count > len(c.items)/10 {
				break
			}
			delete(c.items, n)
			count++
		}
	}

	c.items[nonce] = time.Now()
	return nil
}

func (c *nonceCache) stop() {
	c.once.Do(func() {
		close(c.stopCh)
	})
}

// ========== IP 限流器（带最后使用时间） ==========
type rateLimiterEntry struct {
	*rate.Limiter
	lastUsed time.Time
}

type ipRateLimiter struct {
	limiters map[string]*rateLimiterEntry
	mu       sync.RWMutex
	stopCh   chan struct{}
	once     sync.Once
}

var globalRateLimiter = &ipRateLimiter{
	limiters: make(map[string]*rateLimiterEntry),
	stopCh:   make(chan struct{}),
}

func startRateLimiterCleanup() {
	go globalRateLimiter.cleanupLoop()
}

func (l *ipRateLimiter) cleanupLoop() {
	ticker := time.NewTicker(rateLimiterCleanupInterval)
	defer ticker.Stop()

	for {
		select {
		case <-l.stopCh:
			return
		case <-ticker.C:
			l.cleanup()
		}
	}
}

func (l *ipRateLimiter) cleanup() {
	l.mu.Lock()
	defer l.mu.Unlock()

	now := time.Now()
	for ip, entry := range l.limiters {
		if now.Sub(entry.lastUsed) > 1*time.Hour {
			delete(l.limiters, ip)
		}
	}
}

func (l *ipRateLimiter) getLimiter(ip string) *rate.Limiter {
	l.mu.Lock()
	defer l.mu.Unlock()

	entry, exists := l.limiters[ip]
	if !exists {
		entry = &rateLimiterEntry{
			Limiter:  rate.NewLimiter(rate.Limit(rateLimitRequestsPerSecond), rateLimitBurst),
			lastUsed: time.Now(),
		}
		l.limiters[ip] = entry
	}
	entry.lastUsed = time.Now()
	return entry.Limiter
}

func (l *ipRateLimiter) stop() {
	l.once.Do(func() {
		close(l.stopCh)
	})
}

// ========== 上传并发控制器 ==========
type uploadConcurrencyController struct {
	uploads map[string]int
	mu      sync.RWMutex
}

var concurrencyController = &uploadConcurrencyController{
	uploads: make(map[string]int),
}

func (c *uploadConcurrencyController) acquire(ip string) bool {
	c.mu.Lock()
	defer c.mu.Unlock()

	if c.uploads[ip] >= maxConcurrentUploadsPerIP {
		return false
	}
	c.uploads[ip]++
	return true
}

func (c *uploadConcurrencyController) release(ip string) {
	c.mu.Lock()
	defer c.mu.Unlock()

	if count, exists := c.uploads[ip]; exists && count > 0 {
		c.uploads[ip]--
		if c.uploads[ip] == 0 {
			delete(c.uploads, ip)
		}
	}
}

// ========== 请求结构 ==========
type chunkUpload struct {
	UploadID      string `json:"uploadId"`
	FileName      string `json:"fileName"`
	FileType      string `json:"fileType"`
	FileID        string `json:"fileId"`
	ChunkIndex    int    `json:"chunkIndex"`
	TotalChunks   int    `json:"totalChunks"`
	Data          string `json:"data"`
	ChunkChecksum string `json:"chunkChecksum"`
	Timestamp     string `json:"timestamp"`
	Nonce         string `json:"nonce"`
	Signature     string `json:"signature"`
}

type completeUploadRequest struct {
	UploadID  string `json:"uploadId"`
	DeviceID  string `json:"deviceId,omitempty"`
	Timestamp string `json:"timestamp,omitempty"`
	Nonce     string `json:"nonce,omitempty"`
	Signature string `json:"signature,omitempty"`
	TotalSize int64  `json:"totalSize,omitempty"`
	StartTime string `json:"startTime,omitempty"`
    EndTime   string `json:"endTime,omitempty"`
}

func isBinaryChunkUpload(c *gin.Context) bool {
	contentType := strings.ToLower(strings.TrimSpace(c.GetHeader("Content-Type")))
	return strings.HasPrefix(contentType, "application/octet-stream")
}

func parseChunkUpload(c *gin.Context, rawBody []byte) (chunkUpload, []byte, error) {
	if isBinaryChunkUpload(c) {
		uploadID := strings.TrimSpace(c.GetHeader(headerUploadID))
		fileName := strings.TrimSpace(c.GetHeader(headerFileName))
		if uploadID == "" || fileName == "" {
			return chunkUpload{}, nil, fmt.Errorf("missing required headers")
		}

		chunkIndex, err := strconv.Atoi(strings.TrimSpace(c.GetHeader(headerChunkIndex)))
		if err != nil {
			return chunkUpload{}, nil, fmt.Errorf("invalid chunk index")
		}
		totalChunks, err := strconv.Atoi(strings.TrimSpace(c.GetHeader(headerTotalChunks)))
		if err != nil {
			return chunkUpload{}, nil, fmt.Errorf("invalid total chunks")
		}

		req := chunkUpload{
			UploadID:      uploadID,
			FileName:      fileName,
			FileType:      strings.TrimSpace(c.GetHeader(headerFileType)),
			FileID:        strings.TrimSpace(c.GetHeader(headerFileID)),
			ChunkIndex:    chunkIndex,
			TotalChunks:   totalChunks,
			ChunkChecksum: strings.TrimSpace(c.GetHeader(headerChunkChecksum)),
		}
		return req, rawBody, nil
	}

	var req chunkUpload
	if err := json.Unmarshal(rawBody, &req); err != nil {
		return chunkUpload{}, nil, fmt.Errorf("invalid request format")
	}
	if req.UploadID == "" || req.FileName == "" || req.Data == "" {
		return chunkUpload{}, nil, fmt.Errorf("missing required fields")
	}
	data, err := base64.StdEncoding.DecodeString(req.Data)
	if err != nil {
		return chunkUpload{}, nil, fmt.Errorf("invalid data encoding")
	}
	return req, data, nil
}

// ========== 上传处理器 ==========
type UploadHandler struct {
	repo       *services.RecordingRepository
	screenshotRepo *services.ScreenshotRepository
	minio      *services.MinIOClient
	taskRepo   *services.TaskRepository
	DeviceRepo *services.DeviceRepository
	stopCh     chan struct{}
	once       sync.Once
}

// NewUploadHandler 创建上传处理器
func NewUploadHandler(
	repo *services.RecordingRepository,
	screenshotRepo *services.ScreenshotRepository,  // ✅ 添加这个参数
	minio *services.MinIOClient,
	taskRepo *services.TaskRepository,
	deviceRepo *services.DeviceRepository,
) *UploadHandler {
	return &UploadHandler{
		repo:           repo,
		screenshotRepo: screenshotRepo,  // ✅ 添加这行
		minio:          minio,
		taskRepo:       taskRepo,
		DeviceRepo:     deviceRepo,
		stopCh:         make(chan struct{}),
	}
}

func (h *UploadHandler) isUploadAlreadyStored(ctx context.Context, pathPattern string) bool {
	if h.repo != nil {
		if exists, err := h.repo.ExistsByFilePathPattern(ctx, pathPattern); err == nil && exists {
			return true
		}
	}
	if h.screenshotRepo != nil {
		if exists, err := h.screenshotRepo.ExistsByFilePathPattern(ctx, pathPattern); err == nil && exists {
			return true
		}
	}
	return false
}

// UploadChunk 上传分块
func (h *UploadHandler) UploadChunk(c *gin.Context) {
	log.Printf("[DEBUG] UploadChunk called - DeviceID from context: %v", c.GetString("deviceID"))
	
	if h.DeviceRepo == nil {
		log.Printf("[ERROR] DeviceRepo is nil in UploadChunk")
		models.SendError(c, 500, 5000, "Device repository not initialized")
		return
	}

	if os.Getenv("ENV") != "production" {
		log.Printf("=== UploadChunk reached ===")
	}
	
	clientIP := c.ClientIP()

	// 限流检查
	if !globalRateLimiter.getLimiter(clientIP).Allow() {
		models.SendError(c, 429, 2001, "Rate limit exceeded")
		return
	}

	// 并发控制
	if !concurrencyController.acquire(clientIP) {
		models.SendError(c, 429, 2002, fmt.Sprintf("Too many concurrent uploads (max %d)", maxConcurrentUploadsPerIP))
		return
	}
	defer concurrencyController.release(clientIP)

	rawBody, err := io.ReadAll(c.Request.Body)
	if err != nil {
		log.Printf("[ERROR] UploadChunk failed: %v", err)
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	maxBodySize := maxChunkSize
	if !isBinaryChunkUpload(c) {
		maxBodySize += 10240
	}
	if len(rawBody) > maxBodySize {
		models.SendError(c, 413, 1001, "Request body too large")
		return
	}

	req, data, err := parseChunkUpload(c, rawBody)
	if err != nil {
		log.Printf("[ERROR] Failed to parse chunk upload: %v", err)
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	// 验证文件名安全性
	if err := validateFileName(req.FileName); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	// 验证分块索引
	if req.ChunkIndex < 0 || req.ChunkIndex >= req.TotalChunks {
		models.SendError(c, 400, 1001, fmt.Sprintf("Invalid chunk index: %d", req.ChunkIndex))
		return
	}
	if req.TotalChunks <= 0 || req.TotalChunks > 10000 {
		models.SendError(c, 400, 1001, fmt.Sprintf("Invalid total chunks: %d", req.TotalChunks))
		return
	}

	if err := validateUploadID(req.UploadID); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if req.FileID != "" {
		if err := validateIdentifier(req.FileID, "fileId"); err != nil {
			models.SendError(c, 400, 1001, err.Error())
			return
		}
	}

	// 验证数据大小
	if len(data) == 0 {
		models.SendError(c, 400, 1001, "Empty chunk data")
		return
	}
	if len(data) > maxChunkSize {
		models.SendError(c, 400, 1001, fmt.Sprintf("Chunk size exceeds %dMB", maxChunkSize/(1024*1024)))
		return
	}

	// 验证分块校验和
	if req.ChunkChecksum != "" {
		actualChecksum := computeChecksum(data)
		if actualChecksum != req.ChunkChecksum {
			models.SendError(c, 400, 1001, "Chunk checksum mismatch")
			return
		}
	}

	// ========== ✅ 核心改进：状态检查（来自版本2） ==========
	session := sessionManager.getOrCreate(&req)

	// 第一次检查（读锁）
	session.mu.RLock()
	if session.Completed {
		session.mu.RUnlock()
		log.Printf("[WARN] Chunk rejected: upload already completed (UploadID: %s)", req.UploadID)
		models.SendError(c, 409, 1001, "Upload already completed")
		return
	}
	if session.Completing {
		session.mu.RUnlock()
		log.Printf("[WARN] Chunk rejected: upload is completing (UploadID: %s)", req.UploadID)
		models.SendError(c, 409, 1001, "Upload completion in progress")
		return
	}
	session.mu.RUnlock()

	// 第二次检查（写锁）- 双重检查锁
	session.mu.Lock()

	// 双重检查（防止在 RLock 和 Lock 之间状态变化）
	if session.Completed {
		session.mu.Unlock()
		log.Printf("[WARN] Chunk rejected: upload already completed (double-check, UploadID: %s)", req.UploadID)
		models.SendError(c, 409, 1001, "Upload already completed")
		return
	}
	if session.Completing {
		session.mu.Unlock()
		log.Printf("[WARN] Chunk rejected: upload is completing (double-check, UploadID: %s)", req.UploadID)
		models.SendError(c, 409, 1001, "Upload completion in progress")
		return
	}

	// 如果已存在会话，则确保总分块数一致
	if session.TotalChunks > 0 && session.TotalChunks != req.TotalChunks {
		session.mu.Unlock()
		models.SendError(c, 400, 1001, "Total chunks mismatch with existing upload session")
		return
	}

	// 检查是否已接收过该分块
	if session.Received[req.ChunkIndex] {
		session.mu.Unlock()
		models.Send(c, 200, 0, "Chunk already uploaded", gin.H{
			"uploadId":   req.UploadID,
			"chunkIndex": req.ChunkIndex,
			"status":     "duplicate",
		})
		return
	}

	// 检查总大小限制
	session.TotalSize += int64(len(data))
	if session.TotalSize > maxTotalFileSize {
		session.mu.Unlock()
		models.SendError(c, 413, 1001, fmt.Sprintf("Total file size exceeds %dMB", maxTotalFileSize/(1024*1024)))
		return
	}

	// 保存分块（磁盘 IO 不持锁）
	session.mu.Unlock()

	tempDir := filepath.Join(os.TempDir(), "uploads", req.UploadID)
	if err := os.MkdirAll(tempDir, 0755); err != nil {
		models.SendError(c, 500, 5000, fmt.Sprintf("Failed to create temp dir: %v", err))
		return
	}

	chunkPath := filepath.Join(tempDir, chunkFilename(req.ChunkIndex))
	if err := os.WriteFile(chunkPath, data, 0644); err != nil {
		models.SendError(c, 500, 5000, fmt.Sprintf("Failed to write chunk: %v", err))
		return
	}

	// 标记已接收
	session.mu.Lock()
	if session.Completed || session.Completing {
		session.mu.Unlock()
		models.SendError(c, 409, 1001, "Upload session state changed during chunk write")
		return
	}
	session.Received[req.ChunkIndex] = true
	if req.ChunkChecksum != "" {
		session.ChunkChecksums[req.ChunkIndex] = req.ChunkChecksum
	}
	session.LastActive = time.Now()

	progress := len(session.Received) * 100 / req.TotalChunks
	receivedCount := len(session.Received)
	totalSize := session.TotalSize
	session.mu.Unlock()

	log.Printf("[DEBUG] Chunk %d/%d uploaded (progress: %d%%)",
		req.ChunkIndex+1, req.TotalChunks, progress)

	// persistSession 内部会 RLock，必须在释放写锁后调用
	sessionManager.persistSession(session)

	// ✅ 响应参数完整保留
	models.Send(c, 200, 0, "Chunk uploaded", gin.H{
		"uploadId":   req.UploadID,
		"chunkIndex": req.ChunkIndex,
		"received":   receivedCount,
		"total":      req.TotalChunks,
		"progress":   progress,
		"totalSize":  totalSize,
	})
}

// Complete 完成上传
func (h *UploadHandler) Complete(c *gin.Context) {
	rawBody, err := io.ReadAll(c.Request.Body)
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	var req completeUploadRequest
	if err := json.Unmarshal(rawBody, &req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request format")
		return
	}

	if req.UploadID == "" {
		models.SendError(c, 400, 1001, "Upload ID is required")
		return
	}
	if err := validateUploadID(req.UploadID); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	// 获取会话
	session, exists := sessionManager.get(req.UploadID)
	if !exists {
		uploadPattern := "%/" + req.UploadID + ".%"
		if h.isUploadAlreadyStored(c.Request.Context(), uploadPattern) {
			models.Send(c, 200, 0, "Upload already completed", gin.H{
				"uploadId":  req.UploadID,
				"completed": true,
			})
			return
		}

		log.Printf("[WARN] Complete rejected: upload session expired (UploadID: %s)", req.UploadID)
		models.Send(c, 404, 3002, "Upload session expired, please re-upload", gin.H{
			"uploadId":       req.UploadID,
			"sessionExpired": true,
		})
		return
	}

	// ========== 单入口锁 + 状态检查 ==========
	session.mu.Lock()
	
	if session.Completed {
		completedAtStr := session.CompletedAt.Format(time.RFC3339)
		session.mu.Unlock()
		models.Send(c, 200, 0, "Upload already completed", gin.H{
			"uploadId":    req.UploadID,
			"completed":   true,
			"completedAt": completedAtStr,
		})
		return
	}
	
	if session.Completing {
		session.mu.Unlock()
		models.SendError(c, 409, 1001, "Upload completion already in progress")
		return
	}
	
	// 标记正在完成
	session.Completing = true
	session.mu.Unlock()
	
	// 统一错误处理 defer
	var processErr error
	defer func() {
		if processErr != nil {
			session.mu.Lock()
			session.Completing = false
			session.mu.Unlock()
			log.Printf("[ERROR] Complete failed for %s: %v", req.UploadID, processErr)
		}
	}()

	// 检查分块状态
	session.mu.RLock()
	receivedCount := len(session.Received)
	totalChunks := session.TotalChunks
	fileType := session.FileType
	clientFileID := session.FileID
	session.mu.RUnlock()

	if receivedCount != totalChunks {
		missing := totalChunks - receivedCount
		processErr = fmt.Errorf("missing %d chunks", missing)
		models.SendError(c, 400, 1001, processErr.Error())
		return
	}

	tempDir := filepath.Join(os.TempDir(), "uploads", req.UploadID)

	// 收集所有分块文件
	files, err := filepath.Glob(filepath.Join(tempDir, "chunk_*"))
	if err != nil {
		processErr = fmt.Errorf("failed to list chunks: %w", err)
		models.SendError(c, 500, 5000, processErr.Error())
		return
	}
	sort.Strings(files)

	if len(files) != totalChunks {
		processErr = fmt.Errorf("chunk count mismatch: expected %d, got %d", totalChunks, len(files))
		models.SendError(c, 500, 5000, processErr.Error())
		return
	}

	// 根据文件类型确定扩展名
	fileExt := ".webp"
	if fileType == "recording" {
		fileExt = ".mp4"
	}
	outputPath := filepath.Join(tempDir, "combined"+fileExt)

	// 流式合并（替代 os.ReadFile）
	out, err := os.Create(outputPath)
	if err != nil {
		processErr = fmt.Errorf("failed to create output: %w", err)
		models.SendError(c, 500, 5000, processErr.Error())
		return
	}

	var totalSize int64
	combinedHash := sha256.New()

	for _, chunkPath := range files {
		chunkFile, err := os.Open(chunkPath)
		if err != nil {
			out.Close()
			processErr = fmt.Errorf("failed to open chunk: %w", err)
			models.SendError(c, 500, 5000, processErr.Error())
			return
		}
		
		mw := io.MultiWriter(out, combinedHash)
		written, err := io.Copy(mw, chunkFile)
		chunkFile.Close()
		
		if err != nil {
			out.Close()
			processErr = fmt.Errorf("failed to write chunk: %w", err)
			models.SendError(c, 500, 5000, processErr.Error())
			return
		}
		totalSize += written
	}
	out.Close() // 显式关闭，确保数据完全落盘

	// 验证客户端上报的总大小
	if req.TotalSize > 0 && totalSize != req.TotalSize {
		processErr = fmt.Errorf("size mismatch: expected %d, got %d", req.TotalSize, totalSize)
		models.SendError(c, 400, 1001, processErr.Error())
		return
	}

	if totalSize == 0 {
		processErr = fmt.Errorf("combined file is empty")
		models.SendError(c, 500, 5000, processErr.Error())
		return
	}

	// 流式验证 MP4（只读头部）
	if fileType == "recording" {
		checkFile, err := os.Open(outputPath)
		if err != nil {
			processErr = fmt.Errorf("failed to open for validation: %w", err)
			models.SendError(c, 500, 5000, processErr.Error())
			return
		}
		headBuf := make([]byte, 32)
		n, _ := checkFile.Read(headBuf)
		checkFile.Close()

		if n < 8 || !isValidMP4(headBuf[:n]) {
			processErr = fmt.Errorf("invalid file format: not a valid MP4 file")
			models.SendError(c, 400, 1001, processErr.Error())
			return
		}
	}

	// 从 JWT 获取 DeviceID
	deviceIDFromJWT := c.GetString("deviceID")
	if deviceIDFromJWT == "" {
		deviceIDFromJWT = c.GetString("deviceId")
	}
	
	deviceIDToUse := deviceIDFromJWT
	if deviceIDToUse == "" {
		deviceIDToUse = req.DeviceID
		log.Printf("[WARN] DeviceID not found in JWT, using request body: %s", req.DeviceID)
	}
	
	if deviceIDToUse == "" {
		processErr = fmt.Errorf("device not authenticated")
		models.SendError(c, 401, 1002, processErr.Error())
		return
	}
	
	resolvedDeviceID, err := h.resolveDeviceID(c.Request.Context(), deviceIDToUse)
	if err != nil {
		processErr = fmt.Errorf("failed to resolve device: %w", err)
		models.SendError(c, 500, 5000, processErr.Error())
		return
	}

	// ✅ 安全修复 1：显式参数传值，避免协程 Data Race 竞态风险
	if h.DeviceRepo != nil {
		go func(id uuid.UUID) {
			_ = h.DeviceRepo.UpdateLastSeen(context.Background(), id)
		}(resolvedDeviceID)
	}

	// 解析时间
	var startTime, endTime time.Time
	if fileType == "recording" {
		if req.StartTime == "" || req.EndTime == "" {
			processErr = fmt.Errorf("startTime and endTime are required for recordings")
			models.SendError(c, 400, 1001, processErr.Error())
			return
		}

		parsedStart, err := models.ParseFlexibleUTC(req.StartTime)
		if err != nil {
			processErr = fmt.Errorf("invalid startTime: %w", err)
			models.SendError(c, 400, 1001, processErr.Error())
			return
		}
		parsedEnd, err := models.ParseFlexibleUTC(req.EndTime)
		if err != nil {
			processErr = fmt.Errorf("invalid endTime: %w", err)
			models.SendError(c, 400, 1001, processErr.Error())
			return
		}
		if parsedEnd.Before(parsedStart) {
			processErr = fmt.Errorf("endTime must not be before startTime")
			models.SendError(c, 400, 1001, processErr.Error())
			return
		}
		startTime = parsedStart
		endTime = parsedEnd
	} else {
		if req.StartTime != "" {
			if parsed, err := models.ParseFlexibleUTC(req.StartTime); err == nil {
				startTime = parsed
			} else {
				startTime = models.UTCNow()
			}
		} else {
			startTime = models.UTCNow()
		}

		if req.EndTime != "" {
			if parsed, err := models.ParseFlexibleUTC(req.EndTime); err == nil {
				endTime = parsed
			} else {
				endTime = models.UTCNow()
			}
		} else {
			endTime = models.UTCNow()
		}
	}

	// 生成存储路径
	dateDir := startTime.UTC().Format("2006-01-02")
	var objectName string
	var accessPath string

	if fileType == "recording" {
		objectName = filepath.ToSlash(filepath.Join("recordings", resolvedDeviceID.String(), dateDir, fmt.Sprintf("%s.mp4", req.UploadID)))
		accessPath = "/uploads/" + objectName
	} else {
		objectName = filepath.ToSlash(filepath.Join("screenshots", resolvedDeviceID.String(), dateDir, fmt.Sprintf("%s.webp", req.UploadID)))
		accessPath = "/uploads/" + objectName
	}

	// 流式上传到 MinIO
	if h.minio != nil {
		uploadReader, err := os.Open(outputPath)
		if err != nil {
			processErr = fmt.Errorf("failed to open combined file: %w", err)
			models.SendError(c, 500, 5000, processErr.Error())
			return
		}
		
		// ✅ 安全修复 2：立刻手动关闭，防止后续 os.RemoveAll 因文件被锁占用而报错失败
		err = h.minio.SaveStream(c.Request.Context(), objectName, uploadReader)
		uploadReader.Close() 
		
		if err != nil {
			processErr = fmt.Errorf("failed to save to storage: %w", err)
			models.SendError(c, 500, 5000, processErr.Error())
			return
		}
	}

	// 保存数据库记录
	finalHash := combinedHash.Sum(nil)
	var saveErr error

	if fileType == "recording" && h.repo != nil {
		recording := &models.Recording{
			ID:        uuid.New(),
			DeviceID:  resolvedDeviceID,
			StartTime: startTime,
			EndTime:   endTime,
			FilePath:  objectName,
			FileSize:  totalSize,
			SHA256:    hex.EncodeToString(finalHash),
			Uploaded:  true,
			CreatedAt: models.UTCNow(),
		}
		saveErr = h.repo.Add(c.Request.Context(), recording)
	} else if fileType == "screenshot" && h.screenshotRepo != nil {
		screenshotID := uuid.New().String()
		if clientFileID != "" {
			if parsed, parseErr := uuid.Parse(clientFileID); parseErr == nil {
				screenshotID = parsed.String()
			} else {
				log.Printf("[WARN] Invalid screenshot fileId %q, generating new id", clientFileID)
			}
		}

		screenshot := &models.Screenshot{
			ID:         screenshotID,
			DeviceID:   resolvedDeviceID.String(),
			CapturedAt: startTime,
			FilePath:   accessPath,
			FileSize:   totalSize,
			Uploaded:   true,
			CreatedAt:  models.UTCNow(),
		}
		saveErr = h.screenshotRepo.Add(c.Request.Context(), screenshot)
	}

	if saveErr != nil {
		processErr = fmt.Errorf("database save failed: %w", saveErr)
		models.SendError(c, 500, 5000, processErr.Error())
		return
	}

	// 保存上传任务（非关键业务）
	if h.taskRepo != nil {
		task := &models.UploadTask{
			ID:        uuid.New(),
			DeviceID:  resolvedDeviceID,
			StartTime: startTime,
			EndTime:   endTime,
			Status:    "completed",
			Progress:  100,
			Result:    "stored",
			CreatedAt: models.UTCNow(),
		}
		_ = h.taskRepo.Create(c.Request.Context(), task)
	}

	// 清理临时文件
	os.RemoveAll(tempDir)

	// 标记完成
	session.mu.Lock()
	session.Completed = true
	session.CompletedAt = time.Now()
	session.Completing = false
	completedAt := session.CompletedAt
	session.mu.Unlock()

	sessionManager.persistSession(session)

	// 延迟销毁缓存记录
	time.AfterFunc(30*time.Minute, func() {
		sessionManager.remove(req.UploadID)
	})

	// 返回完整结果
	models.Send(c, 200, 0, "Upload completed", gin.H{
		"uploadId":    req.UploadID,
		"deviceId":    resolvedDeviceID.String(),
		"fileType":    fileType,
		"filePath":    objectName,
		"fileSize":    totalSize,
		"fileSizeMB":  float64(totalSize) / 1024 / 1024,
		"sha256":      hex.EncodeToString(finalHash),
		"recordedAt":  models.FormatUTC(models.UTCNow()),
		"startTime":   models.FormatUTC(startTime),
		"endTime":     models.FormatUTC(endTime),
		"completed":   true,
		"completedAt": completedAt.Format(time.RFC3339),
	})
}


// GetUploadProgress 获取上传进度
func (h *UploadHandler) GetUploadProgress(c *gin.Context) {
	uploadID := c.Param("uploadId")
	if uploadID == "" {
		models.SendError(c, 400, 1001, "Upload ID is required")
		return
	}
	if err := validateUploadID(uploadID); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	session, exists := sessionManager.get(uploadID)
	if !exists {
		models.SendError(c, 404, 3001, "Upload session not found")
		return
	}

	session.mu.RLock()
	defer session.mu.RUnlock()

	progress := 0
	if session.TotalChunks > 0 {
		progress = len(session.Received) * 100 / session.TotalChunks
	}

	models.Send(c, 200, 0, "success", gin.H{
		"uploadId":   uploadID,
		"fileName":   session.FileName,
		"received":   len(session.Received),
		"total":      session.TotalChunks,
		"progress":   progress,
		"totalSize":  session.TotalSize,
		"lastActive": session.LastActive,
		"completed":  session.Completed,   // ✅ 新增
        "completing": session.Completing, 
	})
}

// CancelUpload 取消上传
func (h *UploadHandler) CancelUpload(c *gin.Context) {
	uploadID := c.Param("uploadId")
	if uploadID == "" {
		models.SendError(c, 400, 1001, "Upload ID is required")
		return
	}
	if err := validateUploadID(uploadID); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	// ✅ 获取会话，检查状态
	session, exists := sessionManager.get(uploadID)
	if !exists {
		models.Send(c, 200, 0, "Upload already cancelled or completed", gin.H{
			"uploadId":  uploadID,
			"cancelled": true,
		})
		return
	}

	// ✅ 检查是否已完成或正在完成
	session.mu.RLock()
	completed := session.Completed
	completing := session.Completing
	session.mu.RUnlock()

	if completed {
		models.SendError(c, 409, 1001, "Cannot cancel: upload already completed")
		return
	}

	if completing {
		models.SendError(c, 409, 1001, "Cannot cancel: upload completion in progress")
		return
	}

	// ✅ 执行取消
	sessionManager.remove(uploadID)
	
	models.Send(c, 200, 0, "Upload cancelled", gin.H{
		"uploadId":  uploadID,
		"cancelled": true,
	})
}

// ListTasks 列出上传任务
func (h *UploadHandler) ListTasks(c *gin.Context) {
	if h.taskRepo == nil {
		models.Send(c, 200, 0, "success", []interface{}{})
		return
	}
	tasks, err := h.taskRepo.List(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", tasks)
}

// GetUploadStats 获取上传统计
func (h *UploadHandler) GetUploadStats(c *gin.Context) {
	sessionManager.mu.RLock()
	totalSessions := len(sessionManager.sessions)
	sessionManager.mu.RUnlock()

	models.Send(c, 200, 0, "success", gin.H{
		"totalSessions": totalSessions,
		"maxSessions":   maxUploadSessions,
	})
}

// Stop 优雅关闭
func (h *UploadHandler) Stop() {
	h.once.Do(func() {
		close(h.stopCh)
		sessionManager.stop()
		nonceCacheInstance.stop()
		globalRateLimiter.stop()
	})
}

// ========== 辅助函数 ==========

func (h *UploadHandler) resolveDeviceID(ctx context.Context, deviceID string) (uuid.UUID, error) {
	log.Printf("[DEBUG] resolveDeviceID called with deviceID: %s", deviceID)
	if deviceID == "" {
		log.Printf("[ERROR] resolveDeviceID: empty deviceID") 
		return uuid.Nil, fmt.Errorf("device ID is required")
	}

	if parsed, err := uuid.Parse(deviceID); err == nil {
		log.Printf("[DEBUG] resolveDeviceID: parsed as UUID: %v", parsed)
		return parsed, nil
	}

	if h.DeviceRepo == nil {
		log.Printf("[ERROR] resolveDeviceID: DeviceRepo is nil")
		return uuid.Nil, fmt.Errorf("device repository not available")
	}

	existing, err := h.DeviceRepo.GetByDeviceId(ctx, deviceID)
	if err != nil {
		log.Printf("[ERROR] resolveDeviceID: GetByDeviceId failed: %v", err)
		return uuid.Nil, err
	}
	if existing != nil {
		return existing.ID, nil
	}

	// 生成随机 device_secret，避免留下空 secret
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		// 回退到不包含 secret（会在迁移/ensureDeviceSecrets 修复）
		return h.DeviceRepo.Create(ctx, &models.Device{
			DeviceFingerprint: deviceID,
			Hostname:          "unknown",
			OSVersion:         "unknown",
			AgentVersion:      "1.0.0",
			Status:            "pending",
		})
	}
	secret := hex.EncodeToString(b)
	return h.DeviceRepo.Create(ctx, &models.Device{
		DeviceFingerprint: deviceID,
		Hostname:          "unknown",
		OSVersion:         "unknown",
		AgentVersion:      "1.0.0",
		Status:            "pending",
		DeviceSecret:      secret,
	})
}

// Signature verification is performed by middleware VerifyDeviceSignature

// computeChecksum 计算数据校验和
func computeChecksum(data []byte) string {
	hash := sha256.Sum256(data)
	return hex.EncodeToString(hash[:])
}

// chunkFilename 生成分块文件名
func chunkFilename(index int) string {
	return fmt.Sprintf("chunk_%05d", index)
}

// validateFileName 验证文件名安全性
func validateFileName(fileName string) error {
	if fileName == "" {
		return fmt.Errorf("file name cannot be empty")
	}
	if strings.ContainsAny(fileName, "/\\") {
		return fmt.Errorf("file name contains invalid characters")
	}
	if len(fileName) > 255 {
		return fmt.Errorf("file name too long")
	}
	return nil
}

func validateUploadID(uploadID string) error {
	if uploadID == "" {
		return fmt.Errorf("upload ID cannot be empty")
	}
	if len(uploadID) > 64 {
		return fmt.Errorf("upload ID too long")
	}
	if strings.ContainsAny(uploadID, "/\\") {
		return fmt.Errorf("upload ID contains invalid characters")
	}
	if strings.Contains(uploadID, "..") {
		return fmt.Errorf("upload ID contains invalid traversal sequence")
	}
	if _, err := uuid.Parse(uploadID); err != nil {
		return fmt.Errorf("upload ID must be a valid UUID")
	}
	return nil
}

func validateIdentifier(value string, label string) error {
	if strings.TrimSpace(value) == "" {
		return fmt.Errorf("%s cannot be empty", label)
	}
	if len(value) > 128 {
		return fmt.Errorf("%s too long", label)
	}
	if strings.ContainsAny(value, "/\\") {
		return fmt.Errorf("%s contains invalid characters", label)
	}
	if strings.Contains(value, "..") {
		return fmt.Errorf("%s contains invalid traversal sequence", label)
	}
	return nil
}

// isValidMP4 验证 MP4 文件头
func isValidMP4(data []byte) bool {
	if len(data) < 12 {
		return false
	}
	// MP4 文件头: ftyp box
	return data[4] == 'f' && data[5] == 't' && data[6] == 'y' && data[7] == 'p'
}

const uploadSessionRedisPrefix = "upload:session:"

// uploadSessionData 可序列化的会话元数据（分块文件仍存本地临时目录）。
type uploadSessionData struct {
	UploadID       string         `json:"uploadId"`
	FileName       string         `json:"fileName"`
	FileType       string         `json:"fileType"`
	FileID         string         `json:"fileId"`
	TotalChunks    int            `json:"totalChunks"`
	Received       map[int]bool   `json:"received"`
	ChunkChecksums map[int]string `json:"chunkChecksums"`
	LastActive     time.Time      `json:"lastActive"`
	TotalSize      int64          `json:"totalSize"`
	Completed      bool           `json:"completed"`
	Completing     bool           `json:"completing"`
	CompletedAt    time.Time      `json:"completedAt,omitempty"`
}

var uploadSessionRedis *redis.Client

// InitUploadSessionStore 注入 Redis；为 nil 时仅使用进程内内存（单实例模式）。
func InitUploadSessionStore(client *redis.Client) {
	uploadSessionRedis = client
	if client != nil {
		log.Println("[UploadSession] Redis-backed session metadata enabled")
	} else {
		log.Println("[UploadSession] In-memory session store only (single instance)")
	}
}

func uploadSessionRedisKey(uploadID string) string {
	return uploadSessionRedisPrefix + uploadID
}

func (s *uploadSession) toData() *uploadSessionData {
	s.mu.RLock()
	defer s.mu.RUnlock()

	received := make(map[int]bool, len(s.Received))
	for k, v := range s.Received {
		received[k] = v
	}
	checksums := make(map[int]string, len(s.ChunkChecksums))
	for k, v := range s.ChunkChecksums {
		checksums[k] = v
	}

	return &uploadSessionData{
		UploadID:       s.UploadID,
		FileName:       s.FileName,
		FileType:       s.FileType,
		FileID:         s.FileID,
		TotalChunks:    s.TotalChunks,
		Received:       received,
		ChunkChecksums: checksums,
		LastActive:     s.LastActive,
		TotalSize:      s.TotalSize,
		Completed:      s.Completed,
		Completing:     s.Completing,
		CompletedAt:    s.CompletedAt,
	}
}

func uploadSessionFromData(d *uploadSessionData) *uploadSession {
	if d == nil {
		return nil
	}
	received := d.Received
	if received == nil {
		received = make(map[int]bool)
	}
	checksums := d.ChunkChecksums
	if checksums == nil {
		checksums = make(map[int]string)
	}
	return &uploadSession{
		UploadID:       d.UploadID,
		FileName:       d.FileName,
		FileType:       d.FileType,
		FileID:         d.FileID,
		TotalChunks:    d.TotalChunks,
		Received:       received,
		ChunkChecksums: checksums,
		LastActive:     d.LastActive,
		TotalSize:      d.TotalSize,
		Completed:      d.Completed,
		Completing:     d.Completing,
		CompletedAt:    d.CompletedAt,
	}
}

func (m *uploadSessionManager) persistSession(session *uploadSession) {
	if uploadSessionRedis == nil || session == nil {
		return
	}

	data := session.toData()
	payload, err := json.Marshal(data)
	if err != nil {
		log.Printf("[UploadSession] Failed to marshal session %s: %v", session.UploadID, err)
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	key := uploadSessionRedisKey(session.UploadID)
	if err := uploadSessionRedis.Set(ctx, key, payload, sessionTTL).Err(); err != nil {
		log.Printf("[UploadSession] Failed to persist session %s to Redis: %v", session.UploadID, err)
	}
}

func (m *uploadSessionManager) loadSessionFromRedis(uploadID string) (*uploadSession, bool) {
	if uploadSessionRedis == nil {
		return nil, false
	}

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	payload, err := uploadSessionRedis.Get(ctx, uploadSessionRedisKey(uploadID)).Bytes()
	if err != nil {
		return nil, false
	}

	var data uploadSessionData
	if err := json.Unmarshal(payload, &data); err != nil {
		log.Printf("[UploadSession] Failed to unmarshal session %s: %v", uploadID, err)
		return nil, false
	}

	return uploadSessionFromData(&data), true
}

func (m *uploadSessionManager) removeSessionFromRedis(uploadID string) {
	if uploadSessionRedis == nil {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	if err := uploadSessionRedis.Del(ctx, uploadSessionRedisKey(uploadID)).Err(); err != nil {
		log.Printf("[UploadSession] Failed to delete session %s from Redis: %v", uploadID, err)
	}
}

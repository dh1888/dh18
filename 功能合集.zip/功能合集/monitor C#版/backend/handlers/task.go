// backend/handlers/task.go
package handlers

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// 任务状态常量
const (
	TaskStatusPending   = "pending"
	TaskStatusRunning   = "running"
	TaskStatusCompleted = "completed"
	TaskStatusFailed    = "failed"
	TaskStatusCancelled = "cancelled"
)

// 有效任务状态列表
var validTaskStatuses = map[string]bool{
	TaskStatusPending:   true,
	TaskStatusRunning:   true,
	TaskStatusCompleted: true,
	TaskStatusFailed:    true,
	TaskStatusCancelled: true,
	"skipped":           true,
}

type TaskHandler struct {
	repo         *services.TaskRepository
	wsHub        *services.WebSocketHub
	DeviceRepo   *services.DeviceRepository
	alertService *services.AlertService
}

func NewTaskHandler(
	repo *services.TaskRepository,
	wsHub *services.WebSocketHub,
	deviceRepo *services.DeviceRepository,
	alertService *services.AlertService,
) *TaskHandler {
	return &TaskHandler{
		repo:         repo,
		wsHub:        wsHub,
		DeviceRepo:   deviceRepo,
		alertService: alertService,
	}
}

// GetPendingTasks 获取待处理任务列表
func (h *TaskHandler) GetPendingTasks(c *gin.Context) {
	deviceID := c.Query("deviceId")

	log.Printf("GetPendingTasks called with deviceId: %s", deviceID)

	if deviceID == "" {
		models.SendError(c, 400, 1001, "deviceId is required")
		return
	}

	authDeviceID := strings.TrimSpace(c.GetString("deviceID"))
	if authDeviceID == "" {
		authDeviceID = strings.TrimSpace(c.GetString("deviceId"))
	}
	if authDeviceID == "" {
		models.SendError(c, 401, 1002, "Device not authenticated")
		return
	}

	// 验证 UUID 格式
	deviceUUID, err := uuid.Parse(deviceID)
	if err != nil {
		log.Printf("Invalid device ID format: %s, error: %v", deviceID, err)
		models.SendError(c, 400, 1001, "Invalid device ID format")
		return
	}

	if !strings.EqualFold(authDeviceID, deviceUUID.String()) {
		log.Printf("GetPendingTasks forbidden: token device=%s query device=%s", authDeviceID, deviceUUID.String())
		models.SendError(c, 403, 1003, "Forbidden: device ID mismatch")
		return
	}
	
	log.Printf("Parsed device UUID: %s", deviceUUID.String())

	// 调用 repository
	tasks, err := h.repo.GetPendingByDevice(c.Request.Context(), deviceUUID.String())
	if err != nil {
		// ✅ 打印详细错误信息
		log.Printf("GetPendingByDevice failed for device %s: %v", deviceID, err)
		models.SendError(c, 500, 5000, "Failed to load pending tasks")
		return
	}

	log.Printf("Found %d pending tasks for device %s", len(tasks), deviceID)

	models.Send(c, 200, 0, "success", gin.H{
		"items": tasks,
		"total": len(tasks),
	})
}

// UpdateTaskStatus 更新任务状态
func (h *TaskHandler) UpdateTaskStatus(c *gin.Context) {
    taskID := c.Param("id")
    if taskID == "" {
        models.SendError(c, 400, 1001, "Task ID is required")
        return
    }

    var req struct {
        Status      string  `json:"status"`
        Result      string  `json:"result"`
        Progress    int     `json:"progress"`
        CompletedAt *string `json:"completedAt,omitempty"`
    }
    if err := c.ShouldBindJSON(&req); err != nil {
        models.SendError(c, 400, 1001, "Invalid request: "+err.Error())
        return
    }

    // 验证状态值
    if req.Status == "" {
        models.SendError(c, 400, 1001, "Status is required")
        return
    }
    if !validTaskStatuses[req.Status] {
        models.SendError(c, 400, 1001, "Invalid status: "+req.Status)
        return
    }

    // 验证进度值
    if req.Progress < 0 || req.Progress > 100 {
        models.SendError(c, 400, 1001, "Progress must be between 0 and 100")
        return
    }

    authDeviceID := strings.TrimSpace(c.GetString("deviceID"))
    if authDeviceID == "" {
        authDeviceID = strings.TrimSpace(c.GetString("deviceId"))
    }
    if authDeviceID == "" {
        models.SendError(c, 401, 1002, "Device not authenticated")
        return
    }

    existingTask, err := h.repo.GetByID(c.Request.Context(), taskID)
    if err != nil {
        models.SendError(c, 500, 5000, "Failed to load task")
        return
    }
    if existingTask == nil {
        models.SendError(c, 404, 2001, "Task not found")
        return
    }
    if !strings.EqualFold(authDeviceID, existingTask.DeviceID.String()) {
        log.Printf("UpdateTaskStatus forbidden: token device=%s task device=%s task=%s",
            authDeviceID, existingTask.DeviceID.String(), taskID)
        models.SendError(c, 403, 1003, "Forbidden: task does not belong to this device")
        return
    }

    // 解析完成时间
    var completedAt *time.Time
    if req.CompletedAt != nil && *req.CompletedAt != "" {
        parsed, err := models.ParseUTC(*req.CompletedAt)
        if err != nil {
            models.SendError(c, 400, 1001, "Invalid completedAt format, expected RFC3339")
            return
        }
        completedAt = &parsed
    } else if req.Status == TaskStatusCompleted || req.Status == TaskStatusFailed {
        now := models.UTCNow()
        completedAt = &now
    }

    // ✅ 在更新前获取原任务信息（用于通知）
    var oldStatus string
    if h.wsHub != nil {
        oldTask, _ := h.getTaskByID(c.Request.Context(), taskID)
        if oldTask != nil {
            oldStatus = oldTask.Status
        }
    }

    // 更新状态
    if err := h.repo.UpdateStatus(c.Request.Context(), taskID, req.Status, req.Result, req.Progress, completedAt); err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // ========== ✅ 新增：WebSocket 通知 ==========
    if h.wsHub != nil {
        // 构建通知消息
        notifyMsg := gin.H{
            "type":        "task_status_update",
            "taskId":      taskID,
            "status":      req.Status,
            "progress":    req.Progress,
            "result":      req.Result,
            "oldStatus":   oldStatus,  // 可选：便于前端判断状态变化
            "timestamp":   models.FormatUTC(models.UTCNow()),
        }
        
        // 如果有完成时间，添加到消息中
        if completedAt != nil {
            notifyMsg["completedAt"] = models.FormatUTC(*completedAt)
        }
        
        // 广播给所有 Admin（管理员和操作员）
        h.wsHub.BroadcastToAdmins(notifyMsg)
        
        log.Printf("[Task] Broadcasted status update: taskId=%s, status=%s, progress=%d", 
            taskID, req.Status, req.Progress)
    }
    // ========== WebSocket 通知结束 ==========

    if req.Status == TaskStatusFailed && h.alertService != nil && h.alertService.Enabled() {
        task, _ := h.getTaskByID(c.Request.Context(), taskID)
        deviceID := ""
        taskType := "upload_recordings"
        if task != nil {
            deviceID = task.DeviceID.String()
            taskType = task.Type
        }
        h.alertService.NotifyTaskFailed(c.Request.Context(), taskID, deviceID, taskType, req.Result)
    }

    models.Send(c, 200, 0, "Task status updated successfully", gin.H{
        "taskId":      taskID,
        "status":      req.Status,
        "progress":    req.Progress,
        "completedAt": completedAt,
    })
}

// GetTask 获取单个任务详情
func (h *TaskHandler) GetTask(c *gin.Context) {
	taskID := c.Param("id")
	if taskID == "" {
		models.SendError(c, 400, 1001, "Task ID is required")
		return
	}

	task, err := h.repo.GetByID(c.Request.Context(), taskID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if task == nil {
		models.SendError(c, 404, 2001, "Task not found")
		return
	}

	models.Send(c, 200, 0, "success", task)
}

// ListTasks 获取任务列表（支持分页和筛选）
func (h *TaskHandler) ListTasks(c *gin.Context) {
	tasks, err := h.repo.List(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items": tasks,
		"total": len(tasks),
	})
}

// CreateTask 创建新任务
func (h *TaskHandler) CreateTask(c *gin.Context) {
    var req struct {
        DeviceID  string `json:"deviceId" binding:"required"`
        Type      string `json:"type" binding:"required"`
        StartTime string `json:"startTime"`
        EndTime   string `json:"endTime"`
    }
    if err := c.ShouldBindJSON(&req); err != nil {
        models.SendError(c, 400, 1001, "Invalid request: "+err.Error())
        return
    }

    deviceID, err := uuid.Parse(req.DeviceID)
    if err != nil {
        models.SendError(c, 400, 1001, "Invalid device ID format")
        return
    }

    var startTime, endTime time.Time
    if req.StartTime != "" {
        startTime, err = models.ParseUTC(req.StartTime)
        if err != nil {
            models.SendError(c, 400, 1001, "Invalid startTime format")
            return
        }
    }
    if req.EndTime != "" {
        endTime, err = models.ParseUTC(req.EndTime)
        if err != nil {
            models.SendError(c, 400, 1001, "Invalid endTime format")
            return
        }
    }

    task := &models.UploadTask{
        ID:        uuid.New(),
        DeviceID:  deviceID,
        Type:      req.Type,
        StartTime: startTime,
        EndTime:   endTime,
        Status:    TaskStatusPending,
        Progress:  0,
        CreatedAt: models.UTCNow(),
    }

    if err := h.repo.Create(c.Request.Context(), task); err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // ✅ 添加操作日志：记录谁请求了上传
    username := c.GetString("username")
    userID := c.GetString("userID")
    if username != "" || userID != "" {
        logUser := username
        if logUser == "" {
            logUser = userID
        }
        
        // 获取设备对应的员工姓名
        employeeName := ""
        if h.DeviceRepo != nil {
            device, err := h.DeviceRepo.Get(c.Request.Context(), deviceID)
            if err == nil && device != nil {
                employeeName = device.EmployeeName
                if employeeName == "" {
                    employeeName = device.Hostname
                }
            }
        }
        if employeeName == "" {
            employeeName = deviceID.String()[:8] + "..."
        }
        
        taskTypeDesc := ""
        switch req.Type {
        case "upload_recordings":
            taskTypeDesc = "录屏文件"
        case "upload_screenshots":
            taskTypeDesc = "截图文件"
        default:
            taskTypeDesc = req.Type
        }
        
        timeRange := ""
        if !startTime.IsZero() && !endTime.IsZero() {
            timeRange = fmt.Sprintf(" (时间段: %s 至 %s)", 
                startTime.Format("2006-01-02 15:04:05"), 
                endTime.Format("2006-01-02 15:04:05"))
        } else if !startTime.IsZero() {
            timeRange = fmt.Sprintf(" (开始时间: %s)", startTime.Format("2006-01-02 15:04:05"))
        } else if !endTime.IsZero() {
            timeRange = fmt.Sprintf(" (结束时间: %s)", endTime.Format("2006-01-02 15:04:05"))
        }
        
        Log(c, "CREATE", "TASK",
            fmt.Sprintf("用户 %s 请求设备 %s 上传%s%s", 
                logUser, employeeName, taskTypeDesc, timeRange),
            deviceID.String(), logUser)
    }

    // ✅ 修复：只传递 params，不传递完整消息
    if h.wsHub != nil {
        params := gin.H{
            "startTime": req.StartTime,
            "endTime":   req.EndTime,
        }
        h.wsHub.SendTask(deviceID.String(), task.ID.String(), req.Type, params)
    }

    if h.wsHub != nil {
        h.wsHub.BroadcastToAdmins(gin.H{
            "type":      "task_created",
            "taskId":    task.ID.String(),
            "deviceId":  req.DeviceID,
            "status":    TaskStatusPending,
            "createdAt": models.FormatUTC(task.CreatedAt),
            "timestamp": models.FormatUTC(models.UTCNow()),
        })
        log.Printf("[Task] Broadcasted task creation: taskId=%s, deviceId=%s", 
            task.ID.String(), req.DeviceID)
    }

    models.Send(c, 200, 0, "Task created successfully", task)
}

// CancelTask 取消任务
func (h *TaskHandler) CancelTask(c *gin.Context) {
	taskID := c.Param("id")
	if taskID == "" {
		models.SendError(c, 400, 1001, "Task ID is required")
		return
	}

	now := models.UTCNow()
	if err := h.repo.UpdateStatus(c.Request.Context(), taskID, TaskStatusCancelled, "cancelled by user", 0, &now); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

    if h.wsHub != nil {
        h.wsHub.BroadcastToAdmins(gin.H{
            "type":      "task_cancelled",
            "taskId":    taskID,
            "status":    TaskStatusCancelled,
            "timestamp": models.FormatUTC(models.UTCNow()),
        })
        log.Printf("[Task] Broadcasted task cancellation: taskId=%s", taskID)
    }

	models.Send(c, 200, 0, "Task cancelled successfully", gin.H{
		"taskId": taskID,
		"status": TaskStatusCancelled,
	})
}

// RetryTask 重试失败的任务
func (h *TaskHandler) RetryTask(c *gin.Context) {
	taskID := c.Param("id")
	if taskID == "" {
		models.SendError(c, 400, 1001, "Task ID is required")
		return
	}

	// 重置为 pending 状态
	now := models.UTCNow()
	if err := h.repo.UpdateStatus(c.Request.Context(), taskID, TaskStatusPending, "retry", 0, &now); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "Task queued for retry", gin.H{
		"taskId": taskID,
		"status": TaskStatusPending,
	})
}

// BatchUpdateStatus 批量更新任务状态
func (h *TaskHandler) BatchUpdateStatus(c *gin.Context) {
	var req struct {
		TaskIDs []string `json:"taskIds" binding:"required"`
		Status  string   `json:"status" binding:"required"`
		Result  string   `json:"result"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: "+err.Error())
		return
	}

	// 验证状态
	if !validTaskStatuses[req.Status] {
		models.SendError(c, 400, 1001, "Invalid status: "+req.Status)
		return
	}

	if len(req.TaskIDs) == 0 {
		models.SendError(c, 400, 1001, "No task IDs provided")
		return
	}

	if len(req.TaskIDs) > 100 {
		models.SendError(c, 400, 1001, "Maximum 100 tasks per batch")
		return
	}

	now := models.UTCNow()
	updated := 0
	for _, taskID := range req.TaskIDs {
		if err := h.repo.UpdateStatus(c.Request.Context(), taskID, req.Status, req.Result, 0, &now); err == nil {
			updated++
		}
	}

	models.Send(c, 200, 0, "Tasks updated successfully", gin.H{
		"updated": updated,
		"total":   len(req.TaskIDs),
	})
}

// DeleteTask 删除任务
func (h *TaskHandler) DeleteTask(c *gin.Context) {
	taskID := c.Param("id")
	if taskID == "" {
		models.SendError(c, 400, 1001, "Task ID is required")
		return
	}

	// 通过更新状态为 cancelled 来标记删除
	now := models.UTCNow()
	if err := h.repo.UpdateStatus(c.Request.Context(), taskID, TaskStatusCancelled, "deleted by user", 0, &now); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "Task deleted successfully", nil)
}

// getTaskByID 根据ID获取任务（内部辅助函数）
func (h *TaskHandler) getTaskByID(ctx context.Context, taskID string) (*models.UploadTask, error) {
	return h.repo.GetByID(ctx, taskID)
}

package handlers

import (
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type ActivityHandler struct {
	repo *services.ActivityRepository
	deviceRepo *services.DeviceRepository
}

func NewActivityHandler(repo *services.ActivityRepository, deviceRepo *services.DeviceRepository) *ActivityHandler {
    return &ActivityHandler{
        repo:       repo,
        deviceRepo: deviceRepo,
    }
}

// ListActivities 获取活动日志列表
func (h *ActivityHandler) ListActivities(c *gin.Context) {
	deviceID := c.Query("deviceId")
	startDate := c.Query("startDate")
	endDate := c.Query("endDate")
	processName := c.Query("processName")

	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "20"))

	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 20
	}
	if pageSize > 100 {
		pageSize = 100
	}

	activities, total, err := h.repo.List(c.Request.Context(), deviceID, startDate, endDate, processName, page, pageSize)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items":    activities,
		"total":    total,
		"page":     page,
		"pageSize": pageSize,
	})
}

// GetActivityStats 获取活动统计
func (h *ActivityHandler) GetActivityStats(c *gin.Context) {
	deviceID := c.Query("deviceId")
	startDate := c.Query("startDate")
	endDate := c.Query("endDate")

	stats, err := h.repo.GetStats(c.Request.Context(), deviceID, startDate, endDate)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", stats)
}

// ExportActivities 导出活动日志
func (h *ActivityHandler) ExportActivities(c *gin.Context) {
	deviceID := c.Query("deviceId")
	startDate := c.Query("startDate")
	endDate := c.Query("endDate")

	csv, err := h.repo.ExportCSV(c.Request.Context(), deviceID, startDate, endDate)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	c.Header("Content-Type", "text/csv; charset=utf-8")
	c.Header("Content-Disposition", "attachment; filename=activities.csv")
	c.String(200, csv)
}

// DeleteActivities 批量删除活动日志
func (h *ActivityHandler) DeleteActivities(c *gin.Context) {
	var req struct {
		IDs []string `json:"ids"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	if len(req.IDs) == 0 {
		models.SendError(c, 400, 1002, "IDs cannot be empty")
		return
	}

	deleted, err := h.repo.DeleteActivities(c.Request.Context(), req.IDs)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "Activities deleted", gin.H{
		"deleted": deleted,
	})
}

// GetProcessNames 获取进程名称列表（用于筛选）
func (h *ActivityHandler) GetProcessNames(c *gin.Context) {
	deviceID := c.Query("deviceId")
	// 获取所有不重复的进程名
	processes, err := h.repo.GetDistinctProcesses(c.Request.Context(), deviceID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", processes)
}
// 第一个版本的改进版（最佳实践）
// ✅ 修复：正确处理 Reported 和 ReportedAt 字段
func (h *ActivityHandler) ReportActivities(c *gin.Context) {
    var req struct {
        Activities []models.ActivityLog `json:"activities"`
    }
    
    if err := c.ShouldBindJSON(&req); err != nil {
        models.SendError(c, 400, 1001, "Invalid request")
        return
    }

    // ✅ 从认证中间件获取（已验证）
    deviceID := c.GetString("deviceID")
    if deviceID == "" {
        models.SendError(c, 401, 1002, "Device not authenticated")
        return
    }

    // ✅ 验证格式（轻量级）
    deviceUUID, err := uuid.Parse(deviceID)
    if err != nil {
        // 如果是旧的 fingerprint 格式，可能需要转换
        models.SendError(c, 400, 1001, "Invalid device ID format")
        return
    }

    now := time.Now()

    // ✅ 批量设置设备ID和报告状态
    for i := range req.Activities {
        req.Activities[i].DeviceID = deviceUUID.String()
        req.Activities[i].Reported = true      // ✅ 标记为已报告
        req.Activities[i].ReportedAt = &now    // ✅ 记录报告时间
        req.Activities[i].RetryCount = 0       // ✅ 初始重试次数为 0
        req.Activities[i].ErrorMessage = ""    // ✅ 初始化错误信息
    }

    // ✅ 批量保存
    if err := h.repo.BatchAdd(c.Request.Context(), req.Activities); err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    models.Send(c, 200, 0, "Activities reported", gin.H{
        "count": len(req.Activities),
    })
}

// GetDailySummary 获取每日活动汇总
func (h *ActivityHandler) GetDailySummary(c *gin.Context) {
	deviceID := c.Query("deviceId")
	days, _ := strconv.Atoi(c.DefaultQuery("days", "7"))

	summary, err := h.repo.GetDailySummary(c.Request.Context(), deviceID, days)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", summary)
}

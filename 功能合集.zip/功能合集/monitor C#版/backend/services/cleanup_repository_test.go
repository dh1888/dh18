package services

import (
	"context"
	"database/sql"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
	"testing"
	"time"

	"enterprise-agent/backend/models"

	_ "github.com/lib/pq"
	"github.com/stretchr/testify/assert"
	tc "github.com/testcontainers/testcontainers-go"
	"github.com/testcontainers/testcontainers-go/wait"
)

// setupTestContainerPostgres 启动一个临时 Postgres 容器并返回 container 与 *sql.DB
func setupTestContainerPostgres(ctx context.Context, t *testing.T) (tc.Container, *sql.DB, func()) {
    t.Helper()

    req := tc.ContainerRequest{
        Image:        "postgres:15-alpine",
        ExposedPorts: []string{"5432/tcp"},
        Env: map[string]string{
            "POSTGRES_USER":     "test",
            "POSTGRES_PASSWORD": "secret",
            "POSTGRES_DB":       "testdb",
        },
        WaitingFor: wait.ForListeningPort("5432/tcp").WithStartupTimeout(60 * time.Second),
    }

    container, err := tc.GenericContainer(ctx, tc.GenericContainerRequest{ContainerRequest: req, Started: true})
    if err != nil {
        t.Fatalf("failed to start container: %v", err)
    }

    host, err := container.Host(ctx)
    if err != nil {
        container.Terminate(ctx)
        t.Fatalf("failed to get container host: %v", err)
    }
    mappedPort, err := container.MappedPort(ctx, "5432")
    if err != nil {
        container.Terminate(ctx)
        t.Fatalf("failed to get mapped port: %v", err)
    }

    dsn := fmt.Sprintf("postgres://test:secret@%s:%s/testdb?sslmode=disable", host, mappedPort.Port())

    var db *sql.DB
    for i := 0; i < 20; i++ {
        db, err = sql.Open("postgres", dsn)
        if err == nil {
            if err = db.Ping(); err == nil {
                break
            }
            db.Close()
        }
        time.Sleep(500 * time.Millisecond)
    }
    if err != nil {
        container.Terminate(ctx)
        t.Fatalf("failed to connect to postgres: %v", err)
    }

    teardown := func() {
        db.Close()
        container.Terminate(ctx)
    }
    return container, db, teardown
}

// setupTestDB 初始化必要的表结构
func setupTestDB(t *testing.T, db *sql.DB) {
    t.Helper()
    stmts := []string{
        `CREATE TABLE IF NOT EXISTS recordings (id TEXT PRIMARY KEY, file_path TEXT, file_size BIGINT, start_time TIMESTAMPTZ)`,
        `CREATE TABLE IF NOT EXISTS screenshots (id TEXT PRIMARY KEY, file_path TEXT, file_size BIGINT, captured_at TIMESTAMPTZ)`,
        `CREATE TABLE IF NOT EXISTS activity_logs (id TEXT PRIMARY KEY, started_at TIMESTAMPTZ)` ,
        `CREATE TABLE IF NOT EXISTS cleanup_logs (id TEXT PRIMARY KEY, trigger_type TEXT, status TEXT, deleted_recordings INT, deleted_screenshots INT, deleted_logs INT, deleted_bytes BIGINT, message TEXT, started_at TIMESTAMPTZ, completed_at TIMESTAMPTZ)` ,
        `CREATE TABLE IF NOT EXISTS cleanup_policy (id TEXT PRIMARY KEY, auto_cleanup_enabled BOOLEAN, recording_retention_days INT, screenshot_retention_days INT, log_retention_days INT, disk_usage_threshold_percent INT, cleanup_interval_minutes INT, last_run_at TIMESTAMPTZ, updated_at TIMESTAMPTZ)` ,
    }
    for _, s := range stmts {
        if _, err := db.Exec(s); err != nil {
            t.Fatalf("failed init schema: %v, stmt: %s", err, s)
        }
    }
}

// Case 1: 正常清理
func TestRunCleanup_Integration_Normal(t *testing.T) {
    ctx := context.Background()
    _, db, teardown := setupTestContainerPostgres(ctx, t)
    defer teardown()

    setupTestDB(t, db)

    uploads := t.TempDir()
    os.Setenv("UPLOADS_DIR", uploads)

    // 插入记录（过期）
    startTime := time.Now().AddDate(0, 0, -10)
    if _, err := db.Exec(`INSERT INTO recordings (id, file_path, file_size, start_time) VALUES ($1,$2,$3,$4)`, "r1", "rec1.mp4", 10, startTime); err != nil {
        t.Fatalf("insert recording failed: %v", err)
    }
    if _, err := db.Exec(`INSERT INTO screenshots (id, file_path, file_size, captured_at) VALUES ($1,$2,$3,$4)`, "s1", "scr1.png", 6, startTime); err != nil {
        t.Fatalf("insert screenshot failed: %v", err)
    }

    // 创建对应文件
    if err := ioutil.WriteFile(filepath.Join(uploads, "rec1.mp4"), []byte("0123456789"), 0644); err != nil {
        t.Fatalf("write file failed: %v", err)
    }
    if err := ioutil.WriteFile(filepath.Join(uploads, "scr1.png"), []byte("abcdef"), 0644); err != nil {
        t.Fatalf("write file failed: %v", err)
    }

    repo := &CleanupRepository{db: db, stopChan: make(chan struct{}), policy: &models.CleanupPolicy{RecordingRetentionDays: 1, ScreenshotRetentionDays: 1, LogRetentionDays: 1}}

    logEntry, err := repo.RunCleanup(ctx, "manual")
    if err != nil {
        t.Fatalf("RunCleanup failed: %v", err)
    }

    // 验证 DB 记录被删除
    var cnt int
    if err := db.QueryRow(`SELECT COUNT(*) FROM recordings WHERE id = $1`, "r1").Scan(&cnt); err != nil {
        t.Fatalf("query failed: %v", err)
    }
    assert.Equal(t, 0, cnt, "recording should be deleted")

    if err := db.QueryRow(`SELECT COUNT(*) FROM screenshots WHERE id = $1`, "s1").Scan(&cnt); err != nil {
        t.Fatalf("query failed: %v", err)
    }
    assert.Equal(t, 0, cnt, "screenshot should be deleted")

    // 文件应被删除
    if _, err := os.Stat(filepath.Join(uploads, "rec1.mp4")); !os.IsNotExist(err) {
        t.Fatalf("recording file still exists: %v", err)
    }
    if _, err := os.Stat(filepath.Join(uploads, "scr1.png")); !os.IsNotExist(err) {
        t.Fatalf("screenshot file still exists: %v", err)
    }

    assert.Greater(t, logEntry.DeletedBytes, int64(0), "deleted bytes should be > 0")
}

// Case 2: 文件不存在
func TestRunCleanup_Integration_FileMissing(t *testing.T) {
    ctx := context.Background()
    _, db, teardown := setupTestContainerPostgres(ctx, t)
    defer teardown()

    setupTestDB(t, db)

    uploads := t.TempDir()
    os.Setenv("UPLOADS_DIR", uploads)

    startTime := time.Now().AddDate(0, 0, -10)
    if _, err := db.Exec(`INSERT INTO recordings (id, file_path, file_size, start_time) VALUES ($1,$2,$3,$4)`, "r2", "missing.mp4", 123, startTime); err != nil {
        t.Fatalf("insert recording failed: %v", err)
    }

    repo := &CleanupRepository{db: db, stopChan: make(chan struct{}), policy: &models.CleanupPolicy{RecordingRetentionDays: 1, ScreenshotRetentionDays: 1, LogRetentionDays: 1}}

    logEntry, err := repo.RunCleanup(ctx, "manual")
    if err != nil {
        t.Fatalf("RunCleanup failed: %v", err)
    }

    // DB 记录应被删除
    var cnt int
    if err := db.QueryRow(`SELECT COUNT(*) FROM recordings WHERE id = $1`, "r2").Scan(&cnt); err != nil {
        t.Fatalf("query failed: %v", err)
    }
    assert.Equal(t, 0, cnt, "recording should be deleted even if file missing")

    // deleted bytes should be 0 since file missing
    assert.Equal(t, int64(0), logEntry.DeletedBytes)
}

// Case 3: 文件删除失败模拟（通过非法路径使 safeJoin 失败）
func TestRunCleanup_Integration_DeleteFail(t *testing.T) {
    ctx := context.Background()
    _, db, teardown := setupTestContainerPostgres(ctx, t)
    defer teardown()

    setupTestDB(t, db)

    uploads := t.TempDir()
    os.Setenv("UPLOADS_DIR", uploads)

    startTime := time.Now().AddDate(0, 0, -10)
    // 在 DB 中插入一个包含路径穿越的文件路径，safeJoin 会报错，导致 failedFiles
    if _, err := db.Exec(`INSERT INTO recordings (id, file_path, file_size, start_time) VALUES ($1,$2,$3,$4)`, "r3", "../outside/evil.mp4", 999, startTime); err != nil {
        t.Fatalf("insert recording failed: %v", err)
    }

    repo := &CleanupRepository{db: db, stopChan: make(chan struct{}), policy: &models.CleanupPolicy{RecordingRetentionDays: 1, ScreenshotRetentionDays: 1, LogRetentionDays: 1}}

    logEntry, err := repo.RunCleanup(ctx, "manual")
    if err != nil {
        t.Fatalf("RunCleanup failed: %v", err)
    }

    // DB 删除应成功
    var cnt int
    if err := db.QueryRow(`SELECT COUNT(*) FROM recordings WHERE id = $1`, "r3").Scan(&cnt); err != nil {
        t.Fatalf("query failed: %v", err)
    }
    assert.Equal(t, 0, cnt, "recording should be deleted in DB")

    // 由于删除失败，返回日志应为 partial
    assert.Equal(t, "partial", logEntry.Status)
}


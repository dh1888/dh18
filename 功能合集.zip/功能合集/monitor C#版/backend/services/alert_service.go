package services

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"path/filepath"

	"github.com/shirou/gopsutil/v3/disk"
)

const (
	alertHTTPTimeout     = 10 * time.Second
	alertDefaultCooldown = 30 * time.Minute
	alertMonitorInterval = 5 * time.Minute
	deviceOfflineAfter   = 10 * time.Minute
	diskAlertPercent     = 90.0
)

// AlertEvent 运维告警事件
type AlertEvent struct {
	Type     string
	Severity string // info, warning, critical
	Title    string
	Message  string
	Details  map[string]interface{}
}

// AlertService 通过 Webhook 发送运维告警（支持 generic / dingtalk）
type AlertService struct {
	enabled     bool
	webhookURL  string
	webhookType string
	client      *http.Client

	cooldown   time.Duration
	sentAt     map[string]time.Time
	sentAtLock sync.Mutex

	deviceRepo *DeviceRepository
	taskRepo   *TaskRepository
	uploadsDir string
}

func NewAlertService(deviceRepo *DeviceRepository, taskRepo *TaskRepository, uploadsDir string) *AlertService {
	enabled := strings.EqualFold(os.Getenv("ALERT_ENABLED"), "true")
	url := strings.TrimSpace(os.Getenv("ALERT_WEBHOOK_URL"))
	if enabled && url == "" {
		log.Println("[Alert] ALERT_ENABLED=true but ALERT_WEBHOOK_URL is empty, alerts disabled")
		enabled = false
	}

	cooldown := alertDefaultCooldown
	if v := strings.TrimSpace(os.Getenv("ALERT_COOLDOWN_MINUTES")); v != "" {
		if minutes, err := strconv.Atoi(v); err == nil && minutes > 0 {
			cooldown = time.Duration(minutes) * time.Minute
		}
	}

	webhookType := strings.ToLower(strings.TrimSpace(os.Getenv("ALERT_WEBHOOK_TYPE")))
	if webhookType == "" {
		webhookType = "generic"
	}

	svc := &AlertService{
		enabled:     enabled,
		webhookURL:  url,
		webhookType: webhookType,
		client:      &http.Client{Timeout: alertHTTPTimeout},
		cooldown:    cooldown,
		sentAt:      make(map[string]time.Time),
		deviceRepo:  deviceRepo,
		taskRepo:    taskRepo,
		uploadsDir:  uploadsDir,
	}

	if enabled {
		log.Printf("[Alert] Webhook alerts enabled (type=%s, cooldown=%v)", webhookType, cooldown)
	} else {
		log.Println("[Alert] Webhook alerts disabled")
	}

	return svc
}

func (s *AlertService) Enabled() bool {
	return s != nil && s.enabled
}

func (s *AlertService) Notify(ctx context.Context, event AlertEvent) {
	if s == nil || !s.enabled {
		return
	}

	key := s.cooldownKey(event)
	if s.isCoolingDown(key) {
		return
	}

	body, contentType, err := s.buildPayload(event)
	if err != nil {
		log.Printf("[Alert] Failed to build payload (%s): %v", event.Type, err)
		return
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, s.webhookURL, bytes.NewReader(body))
	if err != nil {
		log.Printf("[Alert] Failed to create request (%s): %v", event.Type, err)
		return
	}
	req.Header.Set("Content-Type", contentType)

	resp, err := s.client.Do(req)
	if err != nil {
		log.Printf("[Alert] Webhook request failed (%s): %v", event.Type, err)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		respBody, _ := io.ReadAll(io.LimitReader(resp.Body, 512))
		log.Printf("[Alert] Webhook returned %d (%s): %s", resp.StatusCode, event.Type, strings.TrimSpace(string(respBody)))
		return
	}

	s.markSent(key)
	log.Printf("[Alert] Sent %s: %s", event.Type, event.Title)
}

func (s *AlertService) NotifyTaskFailed(ctx context.Context, taskID, deviceID, taskType, result string) {
	s.Notify(ctx, AlertEvent{
		Type:     "task_failed",
		Severity: "warning",
		Title:    "上传任务失败",
		Message:  fmt.Sprintf("任务 %s 已失败", taskID),
		Details: map[string]interface{}{
			"taskId":   taskID,
			"deviceId": deviceID,
			"taskType": taskType,
			"result":   result,
		},
	})
}

func (s *AlertService) StartMonitor(ctx context.Context) {
	if s == nil || !s.enabled {
		return
	}

	ticker := time.NewTicker(alertMonitorInterval)
	defer ticker.Stop()

	log.Printf("[Alert] Monitor started (interval=%v)", alertMonitorInterval)

	for {
		select {
		case <-ctx.Done():
			log.Println("[Alert] Monitor stopped")
			return
		case <-ticker.C:
			s.checkDeviceOffline(ctx)
			s.checkDiskUsage(ctx)
			s.checkRecentFailedTasks(ctx)
		}
	}
}

func (s *AlertService) checkDeviceOffline(ctx context.Context) {
	if s.deviceRepo == nil {
		return
	}

	devices, _, err := s.deviceRepo.List(ctx, DeviceListOptions{
		Page:     1,
		PageSize: 500,
		Status:   "approved",
	})
	if err != nil {
		log.Printf("[Alert] Failed to list devices: %v", err)
		return
	}

	cutoff := time.Now().Add(-deviceOfflineAfter)
	for _, device := range devices {
		if device.LastSeenAt == nil || device.LastSeenAt.After(cutoff) {
			continue
		}

		name := device.EmployeeName
		if name == "" {
			name = device.Hostname
		}
		if name == "" {
			name = device.ID.String()
		}

		offlineFor := time.Since(*device.LastSeenAt).Round(time.Minute)
		s.Notify(ctx, AlertEvent{
			Type:     "device_offline",
			Severity: "warning",
			Title:    "设备离线",
			Message:  fmt.Sprintf("设备 %s 已离线约 %v", name, offlineFor),
			Details: map[string]interface{}{
				"deviceId":     device.ID.String(),
				"employeeName": device.EmployeeName,
				"hostname":     device.Hostname,
				"lastSeenAt":   device.LastSeenAt.UTC().Format(time.RFC3339),
				"offlineFor":   offlineFor.String(),
			},
		})
	}
}

func (s *AlertService) checkDiskUsage(ctx context.Context) {
	usage, err := getUploadsDiskUsagePercent(s.uploadsDir)
	if err != nil {
		log.Printf("[Alert] Disk usage check failed: %v", err)
		return
	}

	if usage < diskAlertPercent {
		return
	}

	severity := "warning"
	if usage >= 95 {
		severity = "critical"
	}

	s.Notify(ctx, AlertEvent{
		Type:     "disk_high",
		Severity: severity,
		Title:    "磁盘使用率过高",
		Message:  fmt.Sprintf("上传目录磁盘使用率 %.1f%%（阈值 %.0f%%）", usage, diskAlertPercent),
		Details: map[string]interface{}{
			"usagePercent": usage,
			"path":         s.uploadsDir,
			"threshold":    diskAlertPercent,
		},
	})
}

func (s *AlertService) checkRecentFailedTasks(ctx context.Context) {
	if s.taskRepo == nil {
		return
	}

	tasks, err := s.taskRepo.ListRecentlyFailed(ctx, alertMonitorInterval+time.Minute)
	if err != nil {
		log.Printf("[Alert] Failed to list recent failed tasks: %v", err)
		return
	}

	for _, task := range tasks {
		s.NotifyTaskFailed(ctx, task.ID.String(), task.DeviceID.String(), task.Type, task.Result)
	}
}

func (s *AlertService) buildPayload(event AlertEvent) ([]byte, string, error) {
	text := fmt.Sprintf("[%s] %s\n%s", strings.ToUpper(event.Severity), event.Title, event.Message)
	if len(event.Details) > 0 {
		if detailsJSON, err := json.Marshal(event.Details); err == nil {
			text += "\n" + string(detailsJSON)
		}
	}

	switch s.webhookType {
	case "dingtalk":
		payload := map[string]interface{}{
			"msgtype": "text",
			"text": map[string]string{
				"content": text,
			},
		}
		body, err := json.Marshal(payload)
		return body, "application/json", err
	default:
		payload := map[string]interface{}{
			"event":     event.Type,
			"severity":  event.Severity,
			"title":     event.Title,
			"message":   event.Message,
			"timestamp": time.Now().UTC().Format(time.RFC3339),
			"details":   event.Details,
		}
		body, err := json.Marshal(payload)
		return body, "application/json", err
	}
}

func (s *AlertService) cooldownKey(event AlertEvent) string {
	key := event.Type
	if event.Details != nil {
		for _, field := range []string{"deviceId", "taskId", "path"} {
			if v, ok := event.Details[field].(string); ok && v != "" {
				key += ":" + v
				break
			}
		}
	}
	return key
}

func (s *AlertService) isCoolingDown(key string) bool {
	s.sentAtLock.Lock()
	defer s.sentAtLock.Unlock()

	last, ok := s.sentAt[key]
	return ok && time.Since(last) < s.cooldown
}

func (s *AlertService) markSent(key string) {
	s.sentAtLock.Lock()
	defer s.sentAtLock.Unlock()
	s.sentAt[key] = time.Now()
}

func getUploadsDiskUsagePercent(path string) (float64, error) {
	root := path
	if abs, err := filepath.Abs(path); err == nil {
		root = healthDiskRoot(abs)
	}

	usage, err := disk.Usage(root)
	if err == nil {
		return usage.UsedPercent, nil
	}
	return 0, err
}

func healthDiskRoot(absPath string) string {
	if runtime.GOOS == "windows" {
		vol := filepath.VolumeName(absPath)
		if vol != "" {
			return vol + string(filepath.Separator)
		}
		return `C:\`
	}
	return absPath
}

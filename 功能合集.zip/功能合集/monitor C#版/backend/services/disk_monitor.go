// backend/services/disk_monitor.go
package services

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"sync"
	"time"

	"github.com/shirou/gopsutil/v3/disk"
)

// DiskMonitor 磁盘监控服务
type DiskMonitor struct {
    repo       *CleanupRepository
    uploadsDir string
    stopChan   chan struct{}
    stopOnce   sync.Once
    interval   time.Duration
    threshold  float64

    cachedUsage     float64
    cachedUsageTime time.Time
    cacheMu         sync.RWMutex
    cacheDuration   time.Duration

    fallbackActive bool
    fallbackReason string
    fallbackMu     sync.RWMutex
}

// NewDiskMonitor 创建磁盘监控器
func NewDiskMonitor(repo *CleanupRepository, uploadsDir string) *DiskMonitor {
    if err := os.MkdirAll(uploadsDir, 0755); err != nil {
        log.Printf("[DiskMonitor] Warning: failed to create uploads dir: %v", err)
    }

    return &DiskMonitor{
        repo:          repo,
        uploadsDir:    uploadsDir,
        stopChan:      make(chan struct{}),
        interval:      10 * time.Minute,
        threshold:     80,
        cacheDuration: 30 * time.Second,
    }
}

// Start 启动磁盘监控
func (m *DiskMonitor) Start(ctx context.Context) {
    log.Printf("[DiskMonitor] Started - interval=%v, threshold=%.0f%%, path=%s, cache=%v",
        m.interval, m.threshold, m.uploadsDir, m.cacheDuration)

    m.checkAndCleanup(ctx)

    ticker := time.NewTicker(m.interval)
    defer ticker.Stop()

    for {
        select {
        case <-m.stopChan:
            log.Printf("[DiskMonitor] Stopped")
            return
        case <-ctx.Done():
            log.Printf("[DiskMonitor] Context cancelled")
            return
        case <-ticker.C:
            m.checkAndCleanup(ctx)
        }
    }
}

// checkAndCleanup 检查磁盘并触发清理
func (m *DiskMonitor) checkAndCleanup(ctx context.Context) {
    policy, err := m.repo.GetPolicy(ctx)
    if err != nil {
        log.Printf("[DiskMonitor] Failed to get policy: %v", err)
        return
    }

    threshold := m.threshold
    if policy.DiskUsageThresholdPercent > 0 {
        threshold = float64(policy.DiskUsageThresholdPercent)
    }

    usage, err := m.getDiskUsageWithFallback()
    if err != nil {
        log.Printf("[DiskMonitor] Failed to get disk usage: %v", err)
        return
    }

    var cleanupTrigger string
    var tempRetentionMultiplier int

    switch {
    case usage >= 95:
        cleanupTrigger = "auto_disk_critical"
        tempRetentionMultiplier = 2
        log.Printf("[DiskMonitor] 🔴 CRITICAL: disk usage %.2f%% >= 95%%", usage)
    case usage >= threshold:
        cleanupTrigger = "auto_disk_threshold"
        tempRetentionMultiplier = 1
        log.Printf("[DiskMonitor] ⚠️ Disk usage %.2f%% exceeds threshold %.0f%%", usage, threshold)
    default:
        if m.isFallbackActive() {
            m.clearFallback()
            log.Printf("[DiskMonitor] ✅ Fallback mode cleared")
        }
        log.Printf("[DiskMonitor] ✅ Disk usage %.2f%% below threshold %.0f%%", usage, threshold)
        return
    }

    originalRetention := policy.RecordingRetentionDays
    if tempRetentionMultiplier > 1 {
        policy.RecordingRetentionDays = maxInt(1, originalRetention/tempRetentionMultiplier)
        if err := m.repo.UpdatePolicy(ctx, policy); err != nil {
            log.Printf("[DiskMonitor] Failed to update policy: %v", err)
        }
        defer func() {
            policy.RecordingRetentionDays = originalRetention
            _ = m.repo.UpdatePolicy(ctx, policy)
            log.Printf("[DiskMonitor] Restored retention to %d days", originalRetention)
        }()
    }

    // ✅ 修复：使用 ManualCleanup 而不是 RunCleanup
    logEntry, err := m.repo.ManualCleanup(ctx, cleanupTrigger)
    if err != nil {
        log.Printf("[DiskMonitor] Cleanup failed: %v", err)
        return
    }

    freedMB := float64(logEntry.DeletedBytes) / 1024 / 1024
    log.Printf("[DiskMonitor] ✅ Cleanup completed: freed %.2f MB, deleted %d recordings, %d screenshots",
        freedMB, logEntry.DeletedRecordings, logEntry.DeletedScreenshots)

    m.invalidateCache()

    newUsage, _ := m.getDiskUsageWithFallback()
    if newUsage >= threshold {
        log.Printf("[DiskMonitor] ⚠️ Disk usage still at %.2f%% after cleanup", newUsage)
        if tempRetentionMultiplier == 1 {
            log.Printf("[DiskMonitor] 🔔 Consider reducing retention days or increasing cleanup frequency")
        }
    }
}

// getDiskUsageWithFallback 获取磁盘使用率（主方案 + 降级）
func (m *DiskMonitor) getDiskUsageWithFallback() (float64, error) {
    if usage, ok := m.getFromCache(); ok {
        return usage, nil
    }

    usage, err := m.getDiskUsage()
    if err == nil {
        m.setCache(usage)
        m.clearFallback()
        return usage, nil
    }

    log.Printf("[DiskMonitor] gopsutil failed: %v", err)
    m.setFallback("gopsutil failed: " + err.Error())

    usage, err = m.estimateDiskUsageFromStats(context.Background())
    if err == nil {
        log.Printf("[DiskMonitor] Using storage stats estimation (fallback)")
        return usage, nil
    }

    return 0, fmt.Errorf("all disk usage methods failed: %w", err)
}

// getDiskUsage 获取真实磁盘使用率
func (m *DiskMonitor) getDiskUsage() (float64, error) {
    absPath, err := filepath.Abs(m.uploadsDir)
    if err != nil {
        return 0, fmt.Errorf("failed to get absolute path: %w", err)
    }

    diskRoot := getDiskRoot(absPath)

    usageStat, err := disk.Usage(diskRoot)
    if err != nil {
        return 0, fmt.Errorf("disk usage failed for %s: %w", diskRoot, err)
    }

    return usageStat.UsedPercent, nil
}

// estimateDiskUsageFromStats 降级方案：从存储统计估算
func (m *DiskMonitor) estimateDiskUsageFromStats(ctx context.Context) (float64, error) {
    stats, err := m.repo.GetStorageStats(ctx)
    if err != nil {
        return 0, fmt.Errorf("failed to get storage stats: %w", err)
    }

    if stats.TotalBytes == 0 {
        return 0, fmt.Errorf("total bytes is zero")
    }

    estimated := float64(stats.UsedBytes) / float64(stats.TotalBytes) * 100
    if estimated < 0 {
        estimated = 0
    }
    if estimated > 100 {
        estimated = 100
    }

    return estimated, nil
}

// ========== 缓存方法 ==========

func (m *DiskMonitor) getFromCache() (float64, bool) {
    m.cacheMu.RLock()
    defer m.cacheMu.RUnlock()

    if !m.cachedUsageTime.IsZero() && time.Since(m.cachedUsageTime) < m.cacheDuration && m.cachedUsage > 0 {
        return m.cachedUsage, true
    }
    return 0, false
}

func (m *DiskMonitor) setCache(usage float64) {
    m.cacheMu.Lock()
    defer m.cacheMu.Unlock()
    m.cachedUsage = usage
    m.cachedUsageTime = time.Now()
}

func (m *DiskMonitor) invalidateCache() {
    m.cacheMu.Lock()
    defer m.cacheMu.Unlock()
    m.cachedUsage = 0
    m.cachedUsageTime = time.Time{}
    log.Printf("[DiskMonitor] Cache invalidated")
}

func (m *DiskMonitor) SetCacheDuration(duration time.Duration) {
    if duration < 5*time.Second {
        duration = 5 * time.Second
    }
    m.cacheDuration = duration
    log.Printf("[DiskMonitor] Cache duration set to %v", duration)
}

// ========== 降级状态方法 ==========

func (m *DiskMonitor) setFallback(reason string) {
    m.fallbackMu.Lock()
    defer m.fallbackMu.Unlock()
    if !m.fallbackActive {
        m.fallbackActive = true
        m.fallbackReason = reason
        log.Printf("[DiskMonitor] ⚠️ Entering fallback mode: %s", reason)
    }
}

func (m *DiskMonitor) clearFallback() {
    m.fallbackMu.Lock()
    defer m.fallbackMu.Unlock()
    if m.fallbackActive {
        m.fallbackActive = false
        m.fallbackReason = ""
        log.Printf("[DiskMonitor] ✅ Exited fallback mode")
    }
}

func (m *DiskMonitor) isFallbackActive() bool {
    m.fallbackMu.RLock()
    defer m.fallbackMu.RUnlock()
    return m.fallbackActive
}

func (m *DiskMonitor) GetFallbackStatus() map[string]interface{} {
    m.fallbackMu.RLock()
    defer m.fallbackMu.RUnlock()
    return map[string]interface{}{
        "active": m.fallbackActive,
        "reason": m.fallbackReason,
    }
}

func (m *DiskMonitor) GetDiskUsage() (float64, error) {
    return m.getDiskUsageWithFallback()
}

func (m *DiskMonitor) Stop() {
    m.stopOnce.Do(func() {
        close(m.stopChan)
    })
}

func (m *DiskMonitor) SetThreshold(threshold float64) {
    if threshold < 0 {
        threshold = 0
    }
    if threshold > 100 {
        threshold = 100
    }
    m.threshold = threshold
    log.Printf("[DiskMonitor] Threshold updated to %.0f%%", threshold)
}

func (m *DiskMonitor) SetInterval(interval time.Duration) {
    if interval < time.Minute {
        interval = time.Minute
    }
    m.interval = interval
    log.Printf("[DiskMonitor] Check interval updated to %v", interval)
}

func (m *DiskMonitor) GetStatus() map[string]interface{} {
    usage, _ := m.getDiskUsageWithFallback()
    return map[string]interface{}{
        "enabled":        true,
        "interval":       m.interval.String(),
        "threshold":      m.threshold,
        "currentUsage":   usage,
        "needCleanup":    usage >= m.threshold,
        "uploadsDir":     m.uploadsDir,
        "cacheDuration":  m.cacheDuration.String(),
        "fallbackActive": m.isFallbackActive(),
    }
}

func getDiskRoot(path string) string {
    if runtime.GOOS == "windows" {
        vol := filepath.VolumeName(path)
        if vol != "" {
            return vol + string(filepath.Separator)
        }
        return "C:\\"
    }
    return "/"
}

func maxInt(a, b int) int {
    if a > b {
        return a
    }
    return b
}

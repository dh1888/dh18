// backend/services/policy_repository.go
package services

import (
	"context"
	"database/sql"
	"fmt"
	"log"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

// PolicyRepository 策略仓库
type PolicyRepository struct {
	db *sql.DB
}

// NewPolicyRepository 创建策略仓库
func NewPolicyRepository(db *sql.DB) *PolicyRepository {
	return &PolicyRepository{db: db}
}

// List 获取所有策略
// List 获取所有策略
func (r *PolicyRepository) List(ctx context.Context) ([]models.Policy, error) {
    // ✅ 修复：SELECT 中添加 is_current
    rows, err := r.db.QueryContext(ctx, `SELECT id, name, version, content, signature, status, is_current, created_at, updated_at FROM policies ORDER BY created_at DESC`)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    var policies []models.Policy
    for rows.Next() {
        var p models.Policy
        var updatedAt sql.NullTime
        // ✅ 现在 SELECT 有 9 个字段，Scan 也对应 9 个
        if err := rows.Scan(
            &p.ID, 
            &p.Name, 
            &p.Version, 
            &p.Content, 
            &p.Signature, 
            &p.Status, 
            &p.IsCurrent,  // 第7个字段
            &p.CreatedAt,   // 第8个字段
            &updatedAt,     // 第9个字段
        ); err != nil {
            return nil, err
        }
        if updatedAt.Valid {
            p.UpdatedAt = updatedAt.Time
        }
        policies = append(policies, p)
    }
    return policies, nil
}

// Get 根据ID获取策略
func (r *PolicyRepository) Get(ctx context.Context, id uuid.UUID) (*models.Policy, error) {
    var p models.Policy
    var updatedAt sql.NullTime
    query := `SELECT id, name, version, content, signature, status, is_current, created_at, updated_at FROM policies WHERE id = $1`
    err := r.db.QueryRowContext(ctx, query, id).Scan(
        &p.ID, &p.Name, &p.Version, &p.Content, &p.Signature, &p.Status, &p.IsCurrent, &p.CreatedAt, &updatedAt)
    if err != nil {
        if err == sql.ErrNoRows {
            return nil, err
        }
        return nil, err
    }
    if updatedAt.Valid {
        p.UpdatedAt = updatedAt.Time
    }
    return &p, nil
}

// GetCurrent 获取当前生效的策略
func (r *PolicyRepository) GetCurrent(ctx context.Context) (*models.Policy, error) {
    var p models.Policy
    var updatedAt sql.NullTime
    query := `SELECT id, name, version, content, signature, status, is_current, created_at, updated_at FROM policies WHERE is_current = true LIMIT 1`
    err := r.db.QueryRowContext(ctx, query).Scan(
        &p.ID, &p.Name, &p.Version, &p.Content, &p.Signature, &p.Status, &p.IsCurrent, &p.CreatedAt, &updatedAt)
    if err != nil {
        if err == sql.ErrNoRows {
            return nil, err
        }
        return nil, err
    }
    if updatedAt.Valid {
        p.UpdatedAt = updatedAt.Time
    }
    return &p, nil
}

// Create 创建策略
func (r *PolicyRepository) Create(ctx context.Context, policy *models.Policy) error {
    if policy.ID == uuid.Nil {
        policy.ID = uuid.New()
    }
    if policy.CreatedAt.IsZero() {
        policy.CreatedAt = models.UTCNow()
    }
    query := `INSERT INTO policies (id, name, version, content, signature, status, is_current, created_at)
              VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`
    _, err := r.db.ExecContext(ctx, query,
        policy.ID, policy.Name, policy.Version, policy.Content,
        policy.Signature, policy.Status, false, policy.CreatedAt)
    return err
}

// Update 更新策略
func (r *PolicyRepository) Update(ctx context.Context, policy *models.Policy) error {
	query := `UPDATE policies SET name = $1, version = $2, content = $3, signature = $4, updated_at = $5 WHERE id = $6`
	_, err := r.db.ExecContext(ctx, query, policy.Name, policy.Version, policy.Content, policy.Signature, models.UTCNow(), policy.ID)
	return err
}

// UpdateSignature 仅更新策略签名
func (r *PolicyRepository) UpdateSignature(ctx context.Context, id uuid.UUID, signature string) error {
	_, err := r.db.ExecContext(ctx,
		`UPDATE policies SET signature = $1, updated_at = $2 WHERE id = $3`,
		signature, models.UTCNow(), id)
	return err
}

// Delete 删除策略
func (r *PolicyRepository) Delete(ctx context.Context, id uuid.UUID) error {
	// 检查是否还有策略
	var count int
	err := r.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM policies`).Scan(&count)
	if err != nil {
		return err
	}
	if count <= 1 {
		return fmt.Errorf("cannot delete the last policy")
	}

	// 如果要删除的是当前策略，先将其他策略设为当前
	var isCurrent bool
	err = r.db.QueryRowContext(ctx, `SELECT is_current FROM policies WHERE id = $1`, id).Scan(&isCurrent)
	if err != nil {
		return err
	}

	if isCurrent {
		// 找到另一个策略设为当前
		var anotherID uuid.UUID
		err = r.db.QueryRowContext(ctx, `SELECT id FROM policies WHERE id != $1 LIMIT 1`, id).Scan(&anotherID)
		if err != nil {
			return err
		}
		if err := r.SetCurrent(ctx, &models.Policy{ID: anotherID}); err != nil {
			return err
		}
	}

	_, err = r.db.ExecContext(ctx, `DELETE FROM policies WHERE id = $1`, id)
	return err
}

// SetCurrent 设置当前策略
func (r *PolicyRepository) SetCurrent(ctx context.Context, policy *models.Policy) error {
    log.Printf("🔵 SetCurrent called: policy.ID=%s, policy.Name=%s", policy.ID, policy.Name)
    
    tx, err := r.db.BeginTx(ctx, nil)
    if err != nil {
        log.Printf("❌ BeginTx error: %v", err)
        return err
    }
    defer tx.Rollback()

    // 清除当前策略标记
    result1, err := tx.ExecContext(ctx, `UPDATE policies SET is_current = false`)
    if err != nil {
        log.Printf("❌ Clear current error: %v", err)
        return err
    }
    rows1, _ := result1.RowsAffected()
    log.Printf("✅ Cleared is_current for %d policies", rows1)

    // 设置新策略为当前
    result2, err := tx.ExecContext(ctx, `UPDATE policies SET is_current = true, status = 1 WHERE id = $1`, policy.ID)
    if err != nil {
        log.Printf("❌ Set current error: %v", err)
        return err
    }
    rows2, _ := result2.RowsAffected()
    log.Printf("✅ Set is_current=true for %d rows (expected 1)", rows2)

    if err := tx.Commit(); err != nil {
        log.Printf("❌ Commit error: %v", err)
        return err
    }
    
    log.Printf("✅ SetCurrent completed successfully")
    return nil
}
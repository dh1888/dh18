// backend/services/cleanup_repository.go
// 完整替换文件内容

package services

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

const defaultCleanupPolicyID = "default"

// 仅统计/展示有实际删除内容的清理记录
const cleanupLogsWithDataWhere = `WHERE (deleted_recordings + deleted_screenshots + deleted_logs) > 0 OR deleted_bytes > 0`

// CleanupRepository 清理仓库
// 主存储：PostgreSQL，内存作为一级缓存
type CleanupRepository struct {
	db             *sql.DB
	mu             sync.RWMutex
	policy         *models.CleanupPolicy
	logs           []models.CleanupLog
	recordingRepo  *RecordingRepository
	screenshotRepo *ScreenshotRepository
	activityRepo   *ActivityRepository
	minio          *MinIOClient
	stopChan       chan struct{}
	stopOnce       sync.Once
}

// NewCleanupRepository 创建清理仓库
func NewCleanupRepository(db *sql.DB, recordingRepo *RecordingRepository, minio *MinIOClient) *CleanupRepository {
	return NewCleanupRepositoryWithAll(db, recordingRepo, nil, nil, minio)
}

// NewCleanupRepositoryWithAll 创建完整的清理仓库（包含所有子仓库）
func NewCleanupRepositoryWithAll(db *sql.DB, recordingRepo *RecordingRepository,
	screenshotRepo *ScreenshotRepository, activityRepo *ActivityRepository, minio *MinIOClient) *CleanupRepository {

	repo := &CleanupRepository{
		db:             db,
		policy:         defaultCleanupPolicy(),
		logs:           make([]models.CleanupLog, 0),
		recordingRepo:  recordingRepo,
		screenshotRepo: screenshotRepo,
		activityRepo:   activityRepo,
		minio:          minio,
		stopChan:       make(chan struct{}),
	}

	if err := repo.loadPolicy(); err != nil {
		log.Printf("[Cleanup] Warning: failed to load policy from DB, using defaults: %v", err)
	}

	return repo
}

// GetStorageStats 返回存储统计信息（磁盘与 DB 项）
func (r *CleanupRepository) GetStorageStats(ctx context.Context) (*models.StorageStats, error) {
	var recordingCount int
	var recordingSize int64
	var screenshotCount int
	var screenshotSize int64
	var logCount int

	// 优先从主 DB 查询统计
	if r.db != nil {
		if err := r.db.QueryRowContext(ctx, `SELECT COALESCE(COUNT(*), 0), COALESCE(SUM(file_size), 0) FROM recordings`).Scan(&recordingCount, &recordingSize); err != nil {
			recordingCount = 0
			recordingSize = 0
		}
		if err := r.db.QueryRowContext(ctx, `SELECT COALESCE(COUNT(*), 0), COALESCE(SUM(file_size), 0) FROM screenshots`).Scan(&screenshotCount, &screenshotSize); err != nil {
			screenshotCount = 0
			screenshotSize = 0
		}
		if err := r.db.QueryRowContext(ctx, `SELECT COALESCE(COUNT(*), 0) FROM activity_logs`).Scan(&logCount); err != nil {
			logCount = 0
		}
	} else {
		// 降级方案：尝试通过子仓库查询
		if r.recordingRepo != nil {
			if err := r.recordingRepo.db.QueryRowContext(ctx, `SELECT COALESCE(COUNT(*), 0) FROM recordings`).Scan(&recordingCount); err == nil {
				// ok
			}
			if err := r.recordingRepo.db.QueryRowContext(ctx, `SELECT COALESCE(SUM(file_size), 0) FROM recordings`).Scan(&recordingSize); err == nil {
				// ok
			}
		}
		if r.screenshotRepo != nil && r.screenshotRepo.db != nil {
			if err := r.screenshotRepo.db.QueryRowContext(ctx, `SELECT COALESCE(COUNT(*), 0) FROM screenshots`).Scan(&screenshotCount); err == nil {
			}
			if err := r.screenshotRepo.db.QueryRowContext(ctx, `SELECT COALESCE(SUM(file_size), 0) FROM screenshots`).Scan(&screenshotSize); err == nil {
			}
		}
		if r.activityRepo != nil && r.activityRepo.db != nil {
			if err := r.activityRepo.db.QueryRowContext(ctx, `SELECT COALESCE(COUNT(*), 0) FROM activity_logs`).Scan(&logCount); err == nil {
			}
		}
	}

	usedBytes := recordingSize + screenshotSize
	uploadsBytes := usedBytes

	uploadsDir := os.Getenv("UPLOADS_DIR")
	if uploadsDir == "" {
		uploadsDir = "./uploads"
	}
	// MinIO 场景以数据库登记的文件大小为准；本地存储则扫描 uploads 目录
	if r.minio != nil && r.minio.enabled {
		uploadsBytes = usedBytes
	} else if actualBytes, err := getDirectorySize(uploadsDir); err == nil {
		uploadsBytes = actualBytes
	}

	var totalBytes int64
	var freeBytes int64
	var diskUsedBytes int64
	var diskUsagePercent int

	if realTotal, realFree, err := getDiskStats(uploadsDir); err == nil && realTotal > 0 {
		totalBytes = realTotal
		freeBytes = realFree
		diskUsedBytes = realTotal - realFree
		if diskUsedBytes < 0 {
			diskUsedBytes = 0
		}
		if totalBytes > 0 {
			diskUsagePercent = int(float64(diskUsedBytes) * 100.0 / float64(totalBytes))
			if diskUsagePercent > 100 {
				diskUsagePercent = 100
			}
		}
	} else {
		policy, err := r.GetPolicy(ctx)
		if err != nil {
			return nil, err
		}
		totalBytes = uploadsBytes
		if policy.DiskUsageThresholdPercent > 0 && policy.DiskUsageThresholdPercent < 100 && uploadsBytes > 0 {
			totalBytes = int64(float64(uploadsBytes) * 100.0 / float64(policy.DiskUsageThresholdPercent))
			if totalBytes < uploadsBytes {
				totalBytes = uploadsBytes
			}
		}
		if totalBytes == 0 {
			totalBytes = 1 << 30
		}
		diskUsedBytes = uploadsBytes
		freeBytes = totalBytes - diskUsedBytes
		if freeBytes < 0 {
			freeBytes = 0
		}
		if totalBytes > 0 {
			diskUsagePercent = int(float64(diskUsedBytes) * 100.0 / float64(totalBytes))
			if diskUsagePercent > 100 {
				diskUsagePercent = 100
			}
		}
	}

	lastCleanupAt := r.latestCleanupTime()

	return &models.StorageStats{
		TotalBytes:       totalBytes,
		UsedBytes:        diskUsedBytes,
		FreeBytes:        freeBytes,
		DiskUsagePercent: diskUsagePercent,
		UploadsBytes:     uploadsBytes,
		RecordingCount:   recordingCount,
		ScreenshotCount:  screenshotCount,
		LogCount:         logCount,
		LastCleanupAt:    lastCleanupAt,
	}, nil
}

func getDirectorySize(path string) (int64, error) {
	var total int64

	err := filepath.Walk(path, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.Mode().IsRegular() {
			total += info.Size()
		}
		return nil
	})
	if err != nil {
		return 0, err
	}

	return total, nil
}

// ManualCleanup 手动触发清理
func (r *CleanupRepository) ManualCleanup(ctx context.Context, trigger string) (*models.CleanupLog, error) {
	return r.RunCleanup(ctx, trigger)
}

// GetLogs 获取清理日志（不分页，最多100条，保持向后兼容）
func (r *CleanupRepository) GetLogs(ctx context.Context) ([]models.CleanupLog, error) {
	// 优先从数据库读取
	if r.db != nil {
		rows, err := r.db.QueryContext(ctx, `
			SELECT id, trigger_type, status, deleted_recordings, deleted_screenshots, 
			       deleted_logs, deleted_bytes, message, started_at, completed_at
			FROM cleanup_logs 
			`+cleanupLogsWithDataWhere+`
			ORDER BY started_at DESC 
			LIMIT 100`)
		if err != nil {
			return nil, err
		}
		defer rows.Close()

		var logs []models.CleanupLog
		for rows.Next() {
			var log models.CleanupLog
			if err := rows.Scan(&log.ID, &log.TriggerType, &log.Status,
				&log.DeletedRecordings, &log.DeletedScreenshots, &log.DeletedLogs,
				&log.DeletedBytes, &log.Message, &log.StartedAt, &log.CompletedAt); err != nil {
				return nil, err
			}
			logs = append(logs, log)
		}
		return logs, nil
	}

	// 降级：从内存读取
	r.mu.RLock()
	defer r.mu.RUnlock()

	logs := make([]models.CleanupLog, 0, len(r.logs))
	for _, entry := range r.logs {
		if hasCleanupData(entry) {
			logs = append(logs, entry)
		}
	}

	// 按时间倒序排序
	for i := 0; i < len(logs)-1; i++ {
		for j := i + 1; j < len(logs); j++ {
			if logs[j].StartedAt.After(logs[i].StartedAt) {
				logs[i], logs[j] = logs[j], logs[i]
			}
		}
	}
	return logs, nil
}

// GetLogsWithPagination 获取清理日志（分页）
func (r *CleanupRepository) GetLogsWithPagination(ctx context.Context, page, pageSize int) ([]models.CleanupLog, int, error) {
	if r.db == nil {
		return nil, 0, fmt.Errorf("database not available")
	}

	// 参数验证
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 20
	}
	if pageSize > 100 {
		pageSize = 100
	}

	offset := (page - 1) * pageSize

	// 查询总数（仅含实际清理记录）
	var total int
	countQuery := `SELECT COUNT(*) FROM cleanup_logs ` + cleanupLogsWithDataWhere
	if err := r.db.QueryRowContext(ctx, countQuery).Scan(&total); err != nil {
		return nil, 0, fmt.Errorf("count query failed: %w", err)
	}

	// 查询数据
	query := `
		SELECT id, trigger_type, status, deleted_recordings, deleted_screenshots, 
		       deleted_logs, deleted_bytes, message, started_at, completed_at
		FROM cleanup_logs 
		` + cleanupLogsWithDataWhere + `
		ORDER BY started_at DESC 
		LIMIT $1 OFFSET $2
	`

	rows, err := r.db.QueryContext(ctx, query, pageSize, offset)
	if err != nil {
		return nil, 0, fmt.Errorf("query failed: %w", err)
	}
	defer rows.Close()

	var logs []models.CleanupLog
	for rows.Next() {
		var log models.CleanupLog
		if err := rows.Scan(
			&log.ID,
			&log.TriggerType,
			&log.Status,
			&log.DeletedRecordings,
			&log.DeletedScreenshots,
			&log.DeletedLogs,
			&log.DeletedBytes,
			&log.Message,
			&log.StartedAt,
			&log.CompletedAt,
		); err != nil {
			return nil, 0, fmt.Errorf("scan row failed: %w", err)
		}
		logs = append(logs, log)
	}

	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("rows iteration failed: %w", err)
	}

	return logs, total, nil
}

// StartAutoCleanup 启动自动清理循环（公开方法）
func (r *CleanupRepository) StartAutoCleanup() {
	go r.startAutoCleanup()
}

// startAutoCleanup 启动自动清理循环（内部方法）
func (r *CleanupRepository) startAutoCleanup() {
	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()

	for {
		select {
		case <-r.stopChan:
			return
		case <-ticker.C:
			policy, err := r.GetPolicy(context.Background())
			if err != nil {
				policy = defaultCleanupPolicy()
			}

			if policy.AutoCleanupEnabled {
				interval := time.Duration(policy.CleanupIntervalMinutes) * time.Minute
				if interval < time.Minute {
					interval = time.Minute
				}
				ticker.Reset(interval)

				_, _ = r.RunCleanup(context.Background(), "auto")
			}
		}
	}
}

// Stop 停止自动清理
func (r *CleanupRepository) Stop() {
	r.stopOnce.Do(func() {
		close(r.stopChan)
	})
}

// capitalizeFirst 将字符串首字母大写
func capitalizeFirst(s string) string {
	if s == "" {
		return s
	}
	runes := []rune(s)
	first := strings.ToUpper(string(runes[0]))
	if len(runes) > 1 {
		return first + string(runes[1:])
	}
	return first
}

func hasCleanupData(entry models.CleanupLog) bool {
	return entry.DeletedRecordings+entry.DeletedScreenshots+entry.DeletedLogs > 0 || entry.DeletedBytes > 0
}

// getCleanupMessage 生成清理完成消息（中文单行摘要）
func getCleanupMessage(trigger string, deletedRecordings, deletedScreenshots, deletedLogs int, deletedBytes int64) string {
	triggerName := getCleanupTriggerName(trigger)
	totalDeleted := deletedRecordings + deletedScreenshots + deletedLogs

	if totalDeleted == 0 && deletedBytes == 0 {
		return fmt.Sprintf("%s完成，无过期文件需清理", triggerName)
	}

	var parts []string
	if deletedRecordings > 0 {
		parts = append(parts, fmt.Sprintf("录制 %d 个", deletedRecordings))
	}
	if deletedScreenshots > 0 {
		parts = append(parts, fmt.Sprintf("截图 %d 个", deletedScreenshots))
	}
	if deletedLogs > 0 {
		parts = append(parts, fmt.Sprintf("日志 %d 条", deletedLogs))
	}

	summary := strings.Join(parts, "、")
	if deletedBytes > 0 {
		return fmt.Sprintf("%s完成，删除 %s，释放 %.2f MB", triggerName, summary, float64(deletedBytes)/(1024*1024))
	}
	return fmt.Sprintf("%s完成，删除 %s", triggerName, summary)
}

func getCleanupTriggerName(trigger string) string {
	switch trigger {
	case "manual":
		return "手动清理"
	case "auto":
		return "定时清理"
	case "auto_disk_threshold":
		return "磁盘阈值清理"
	case "auto_disk_critical":
		return "磁盘临界清理"
	default:
		return capitalizeFirst(trigger) + "清理"
	}
}

// runCleanup 执行清理操作（完整修复版）
func (r *CleanupRepository) RunCleanup(ctx context.Context, trigger string) (*models.CleanupLog, error) {
    policy, err := r.GetPolicy(ctx)
    if err != nil {
        return nil, fmt.Errorf("get policy failed: %w", err)
    }

    startedAt := models.UTCNow()
    var deletedRecordings, deletedScreenshots, deletedLogs int
    var deletedBytes int64
    var failedFiles []string

    uploadsDir := os.Getenv("UPLOADS_DIR")
    if uploadsDir == "" {
        uploadsDir = "./uploads"
    }

    // 批次大小配置
    recordingBatchSize := 500
    screenshotBatchSize := 500
    logBatchSize := 5000

    // ========== 1. 清理过期的录制文件 ==========
    if policy.RecordingRetentionDays > 0 && r.db != nil {
        cutoff := startedAt.AddDate(0, 0, -policy.RecordingRetentionDays)
        batchNum := 0
        
        for {
            batchNum++
            rows, err := r.db.QueryContext(ctx, 
                `SELECT id, file_path, file_size FROM recordings 
                 WHERE start_time < $1 
                 ORDER BY start_time 
                 LIMIT $2`, cutoff, recordingBatchSize)
            if err != nil {
                return nil, fmt.Errorf("query recordings failed: %w", err)
            }
            
            var recordingIDs []string
            var recordingFiles []string
            var batchBytes int64
            
            for rows.Next() {
                var id string
                var filePath string
                var fileSize int64
                if err := rows.Scan(&id, &filePath, &fileSize); err != nil {
                    continue
                }
                recordingIDs = append(recordingIDs, id)
                recordingFiles = append(recordingFiles, filePath)
                batchBytes += fileSize
            }
            rows.Close()
            
            if len(recordingIDs) == 0 {
                break
            }
            
			// 开始事务，先删除 DB 记录并使用 RETURNING 获取实际被删除的 id
			tx, err := r.db.BeginTx(ctx, nil)
			if err != nil {
				return nil, fmt.Errorf("begin transaction failed: %w", err)
			}

			// 构建 PostgreSQL 风格的占位符 $1,$2,...
			var ph []string
			args := make([]interface{}, len(recordingIDs))
			for i, id := range recordingIDs {
				ph = append(ph, fmt.Sprintf("$%d", i+1))
				args[i] = id
			}
			placeholders := strings.Join(ph, ",")

			// 使用 RETURNING 获取实际删除的 id 列表
			delQuery := fmt.Sprintf("DELETE FROM recordings WHERE id IN (%s) RETURNING id, file_size", placeholders)
			rowsDel, err := tx.QueryContext(ctx, delQuery, args...)
			if err != nil {
				tx.Rollback()
				return nil, fmt.Errorf("delete recordings failed: %w", err)
			}

			deletedIDSet := make(map[string]int64) // id -> size
			for rowsDel.Next() {
				var did string
				var fsize sql.NullInt64
				if err := rowsDel.Scan(&did, &fsize); err == nil {
					if fsize.Valid {
						deletedIDSet[did] = fsize.Int64
					} else {
						deletedIDSet[did] = 0
					}
				}
			}
			rowsDel.Close()

			rowsAffected := int64(len(deletedIDSet))
			deletedRecordings += int(rowsAffected)

			if err := tx.Commit(); err != nil {
				return nil, fmt.Errorf("commit transaction failed: %w", err)
			}

			// 提交后删除对应文件（只删除已在 DB 中被删除的记录对应的文件），并仅统计成功删除的字节数
			for i, id := range recordingIDs {
				size, ok := deletedIDSet[id]
				if !ok {
					continue
				}
				filePath := recordingFiles[i]
				if err := r.deleteStoredFile(ctx, uploadsDir, filePath); err != nil {
					failedFiles = append(failedFiles, filePath)
					continue
				}
				deletedBytes += size
			}
            
            // 批次日志
            log.Printf("[Cleanup] Recordings batch %d: deleted %d records, %.2f MB", 
                batchNum, rowsAffected, float64(batchBytes)/1024/1024)
            
            // 批次间隔
            if len(recordingIDs) == recordingBatchSize {
                time.Sleep(50 * time.Millisecond)
            }
        }
    }

    // ========== 2. 清理过期的截图 ==========
    if policy.ScreenshotRetentionDays > 0 && r.db != nil {
        cutoff := startedAt.AddDate(0, 0, -policy.ScreenshotRetentionDays)
        batchNum := 0
        
        for {
            batchNum++
            rows, err := r.db.QueryContext(ctx, 
                `SELECT id, file_path, file_size FROM screenshots 
                 WHERE captured_at < $1 
                 ORDER BY captured_at 
                 LIMIT $2`, cutoff, screenshotBatchSize)
            if err != nil {
                return nil, fmt.Errorf("query screenshots failed: %w", err)
            }
            
            var screenshotIDs []string
            var screenshotFiles []string
            var batchBytes int64
            
            for rows.Next() {
                var id string
                var filePath string
                var fileSize int64
                if err := rows.Scan(&id, &filePath, &fileSize); err != nil {
                    continue
                }
                screenshotIDs = append(screenshotIDs, id)
                screenshotFiles = append(screenshotFiles, filePath)
                batchBytes += fileSize
            }
            rows.Close()
            
            if len(screenshotIDs) == 0 {
                break
            }
            
            tx, err := r.db.BeginTx(ctx, nil)
            if err != nil {
                return nil, fmt.Errorf("begin transaction failed: %w", err)
            }
            
			// 删除数据库记录并收集实际删除 id
			var ph []string
			args := make([]interface{}, len(screenshotIDs))
			for i, id := range screenshotIDs {
				ph = append(ph, fmt.Sprintf("$%d", i+1))
				args[i] = id
			}
			placeholders := strings.Join(ph, ",")

			delQuery := fmt.Sprintf("DELETE FROM screenshots WHERE id IN (%s) RETURNING id, file_size", placeholders)
			rowsDel, err := tx.QueryContext(ctx, delQuery, args...)
			if err != nil {
				tx.Rollback()
				return nil, fmt.Errorf("delete screenshots failed: %w", err)
			}

			deletedIDSet := make(map[string]int64)
			for rowsDel.Next() {
				var did string
				var fsize sql.NullInt64
				if err := rowsDel.Scan(&did, &fsize); err == nil {
					if fsize.Valid {
						deletedIDSet[did] = fsize.Int64
					} else {
						deletedIDSet[did] = 0
					}
				}
			}
			rowsDel.Close()

			rowsAffected := int64(len(deletedIDSet))
			deletedScreenshots += int(rowsAffected)

			if err := tx.Commit(); err != nil {
				return nil, fmt.Errorf("commit transaction failed: %w", err)
			}

			// 提交后删除文件（仅删除已删除记录对应的文件），并仅在删除成功时计入已释放字节
			for i, id := range screenshotIDs {
				size, ok := deletedIDSet[id]
				if !ok {
					continue
				}
				filePath := screenshotFiles[i]
				if err := r.deleteStoredFile(ctx, uploadsDir, filePath); err != nil {
					failedFiles = append(failedFiles, filePath)
					continue
				}
				deletedBytes += size
			}
            
            log.Printf("[Cleanup] Screenshots batch %d: deleted %d records, %.2f MB", 
                batchNum, rowsAffected, float64(batchBytes)/1024/1024)
            
            if len(screenshotIDs) == screenshotBatchSize {
                time.Sleep(50 * time.Millisecond)
            }
        }
    }

    // ========== 3. 清理过期的活动日志 ==========
    // 清理过期的活动日志
    if policy.LogRetentionDays > 0 && r.db != nil {
        cutoff := startedAt.AddDate(
            0,
            0,
            -policy.LogRetentionDays)

        batchNum := 0

        for {
            batchNum++

            // ✅ PostgreSQL 使用子查询实现 LIMIT
            result, err := r.db.ExecContext(
                ctx,
                `DELETE FROM activity_logs WHERE id IN (
                    SELECT id FROM activity_logs WHERE started_at < $1 LIMIT $2
                )`,
                cutoff,
                logBatchSize)

            if err != nil {
                // 如果子查询方式也失败，使用简单删除（没有 LIMIT）
                result, err = r.db.ExecContext(
                    ctx,
                    `DELETE FROM activity_logs WHERE started_at < $1`,
                    cutoff)

                if err != nil {
                    return nil, fmt.Errorf(
                        "delete activity logs failed: %w",
                        err)
                }

                rowsAffected, _ := result.RowsAffected()
                deletedLogs += int(rowsAffected)

                log.Printf(
                    "[Cleanup] Activity logs: deleted %d records (no batch limit)",
                    rowsAffected)

                break
            }

            rowsAffected, _ := result.RowsAffected()

            if rowsAffected == 0 {
                break
            }

            deletedLogs += int(rowsAffected)

            log.Printf(
                "[Cleanup] Activity logs batch %d: deleted %d records",
                batchNum,
                rowsAffected)

            if rowsAffected == int64(logBatchSize) {
                time.Sleep(50 * time.Millisecond)
            }
        }
    }
	
    // ========== 4. 可选：VACUUM 优化 ==========
    totalDeleted := deletedRecordings + deletedScreenshots + deletedLogs
    if totalDeleted > 50000 {
        go func() {
            time.Sleep(5 * time.Second)
            hour := time.Now().Hour()
            if hour >= 1 && hour <= 5 { // 只在凌晨执行
                if _, err := r.db.ExecContext(context.Background(), "VACUUM"); err != nil {
                    log.Printf("[Cleanup] VACUUM failed: %v", err)
                } else {
                    log.Printf("[Cleanup] VACUUM completed")
                }
            }
        }()
    }

    // ========== 5. 生成清理日志 ==========
    completedAt := models.UTCNow()
    message := getCleanupMessage(trigger, deletedRecordings, deletedScreenshots, deletedLogs, deletedBytes)

    policy.LastRunAt = &startedAt
    _ = r.UpdatePolicy(ctx, policy)

    if totalDeleted == 0 && deletedBytes == 0 {
        log.Printf("[Cleanup] Completed: nothing to delete (trigger=%s)", trigger)
        return &models.CleanupLog{
            TriggerType: trigger,
            Status:      "success",
            Message:     message,
            StartedAt:   startedAt,
            CompletedAt: completedAt,
        }, nil
    }

    status := "success"
    
    if len(failedFiles) > 0 {
        status = "partial"
        failedSummary := failedFiles
        if len(failedFiles) > 5 {
            failedSummary = failedFiles[:5]
        }
        message = fmt.Sprintf("%s (failed to delete %d files: %v)", 
            message, len(failedFiles), failedSummary)
    }
	// 异步重试删除失败的文件并在多次重试后记录告警
	r.retryDeleteFiles(failedFiles, uploadsDir)
    
    logEntry := models.CleanupLog{
        ID:                 uuid.New().String(),
        TriggerType:        trigger,
        Status:             status,
        DeletedRecordings:  deletedRecordings,
        DeletedScreenshots: deletedScreenshots,
        DeletedLogs:        deletedLogs,
        DeletedBytes:       deletedBytes,
        Message:            message,
        StartedAt:          startedAt,
        CompletedAt:        completedAt,
    }

    if err := r.appendLog(logEntry); err != nil {
        return nil, fmt.Errorf("append log failed: %w", err)
    }

    log.Printf("[Cleanup] Completed: deleted %d recordings, %d screenshots, %d logs, freed %.2f MB", 
        deletedRecordings, deletedScreenshots, deletedLogs, float64(deletedBytes)/1024/1024)

    return &logEntry, nil
}

// normalizeStoragePath 将 DB 中的 file_path 规范化为 uploads 下的相对对象路径
func normalizeStoragePath(filePath string) string {
	clean := strings.TrimPrefix(filepath.ToSlash(filepath.Clean(filePath)), "/")
	return strings.TrimPrefix(clean, "uploads/")
}

// deleteStoredFile 删除本地文件或 MinIO 对象
func (r *CleanupRepository) deleteStoredFile(ctx context.Context, uploadsDir, filePath string) error {
	objectName := normalizeStoragePath(filePath)
	if objectName == "" {
		return fmt.Errorf("empty file path")
	}
	if strings.Contains(objectName, "..") {
		return fmt.Errorf("path traversal detected: %s", filePath)
	}

	if r.minio != nil && r.minio.enabled {
		return r.minio.RemoveObject(ctx, objectName)
	}

	localPath := filepath.Join(uploadsDir, filepath.FromSlash(objectName))
	if err := os.Remove(localPath); err != nil && !os.IsNotExist(err) {
		return err
	}
	return nil
}

// safeJoin 安全路径拼接
func safeJoin(baseDir, filePath string) (string, error) {
	if filePath == "" {
		return "", fmt.Errorf("empty file path")
	}

	rel := normalizeStoragePath(filePath)
	if rel == "" {
		return "", fmt.Errorf("empty file path")
	}

	if strings.Contains(rel, "..") {
		return "", fmt.Errorf("path traversal detected: %s", filePath)
	}

	fullPath := filepath.Join(baseDir, filepath.FromSlash(rel))

	absBase, _ := filepath.Abs(baseDir)
	absPath, _ := filepath.Abs(fullPath)

	if !strings.HasPrefix(absPath, absBase) {
		return "", fmt.Errorf("path outside allowed directory: %s", filePath)
	}

	return fullPath, nil
}

// retryDeleteFiles 异步重试删除失败的文件，最多重试 3 次并记录告警
func (r *CleanupRepository) retryDeleteFiles(files []string, uploadsDir string) {
	if len(files) == 0 {
		return
	}

	go func() {
		maxAttempts := 3
		retryDelay := 2 * time.Second
		remaining := make([]string, len(files))
		copy(remaining, files)

		for attempt := 1; attempt <= maxAttempts && len(remaining) > 0; attempt++ {
			var nextRound []string
			for _, rel := range remaining {
				safePath, err := safeJoin(uploadsDir, rel)
				if err != nil {
					nextRound = append(nextRound, rel)
					continue
				}
				if err := os.Remove(safePath); err != nil {
					if os.IsNotExist(err) {
						// 已不存在，视为成功
						continue
					}
					nextRound = append(nextRound, rel)
				}
			}

			if len(nextRound) == 0 {
				return
			}

			// 等待后重试
			time.Sleep(retryDelay)
			retryDelay *= 2
			remaining = nextRound
		}

		// 若仍有未删除项，记录警告以供人工干预
		if len(remaining) > 0 {
			log.Printf("[Cleanup] Warning: failed to delete files after retries: %v", remaining)
		}
	}()
}

// appendLog 添加清理日志
func (r *CleanupRepository) appendLog(logEntry models.CleanupLog) error {
	// 保存到数据库
	if r.db != nil {
		if err := r.saveLogToDB(logEntry); err != nil {
			return err
		}
	}

	// 更新内存缓存
	r.mu.Lock()
	defer r.mu.Unlock()

	r.logs = append([]models.CleanupLog{logEntry}, r.logs...)
	// 只保留最近 1000 条日志
	if len(r.logs) > 1000 {
		r.logs = r.logs[:1000]
	}

	return nil
}

// latestCleanupTime 获取最近一次清理时间
func (r *CleanupRepository) latestCleanupTime() *time.Time {
	if r.db != nil {
		var lastRunAt sql.NullTime
		err := r.db.QueryRow(`SELECT MAX(completed_at) FROM cleanup_logs WHERE status = 'success' AND ((deleted_recordings + deleted_screenshots + deleted_logs) > 0 OR deleted_bytes > 0)`).Scan(&lastRunAt)
		if err == nil && lastRunAt.Valid {
			return &lastRunAt.Time
		}
	}

	r.mu.RLock()
	defer r.mu.RUnlock()

	for _, entry := range r.logs {
		if entry.Status == "success" && hasCleanupData(entry) && !entry.CompletedAt.IsZero() {
			return &entry.CompletedAt
		}
	}
	return nil
}

// loadPolicy 从数据库加载策略
func (r *CleanupRepository) loadPolicy() error {
	if r.db == nil {
		return nil
	}

	row := r.db.QueryRow(`
		SELECT auto_cleanup_enabled, recording_retention_days, screenshot_retention_days, 
		       log_retention_days, disk_usage_threshold_percent, cleanup_interval_minutes, 
		       last_run_at, updated_at 
		FROM cleanup_policy WHERE id = $1`, defaultCleanupPolicyID)

	var lastRun sql.NullTime
	var updatedAt time.Time
	var autoEnabled bool
	var recordingDays, screenshotDays, logDays, threshold, interval int

	if err := row.Scan(&autoEnabled, &recordingDays, &screenshotDays, &logDays, &threshold, &interval, &lastRun, &updatedAt); err != nil {
		if err == sql.ErrNoRows {
			// 如果没有策略记录，创建默认策略
			return r.savePolicyToDB(r.policy)
		}
		return err
	}

	policy := defaultCleanupPolicy()
	policy.AutoCleanupEnabled = autoEnabled
	policy.RecordingRetentionDays = recordingDays
	policy.ScreenshotRetentionDays = screenshotDays
	policy.LogRetentionDays = logDays
	policy.DiskUsageThresholdPercent = threshold
	policy.CleanupIntervalMinutes = interval
	policy.UpdatedAt = updatedAt

	if lastRun.Valid {
		policy.LastRunAt = &lastRun.Time
	}

	r.mu.Lock()
	r.policy = policy
	r.mu.Unlock()

	return nil
}

// loadLogs 从数据库加载日志
func (r *CleanupRepository) loadLogs() error {
	if r.db == nil {
		return nil
	}

	rows, err := r.db.Query(`
		SELECT id, trigger_type, status, deleted_recordings, deleted_screenshots, 
		       deleted_logs, deleted_bytes, message, started_at, completed_at 
		FROM cleanup_logs ORDER BY started_at DESC LIMIT 1000`)
	if err != nil {
		return err
	}
	defer rows.Close()

	var logs []models.CleanupLog
	for rows.Next() {
		var log models.CleanupLog
		if err := rows.Scan(&log.ID, &log.TriggerType, &log.Status,
			&log.DeletedRecordings, &log.DeletedScreenshots, &log.DeletedLogs,
			&log.DeletedBytes, &log.Message, &log.StartedAt, &log.CompletedAt); err != nil {
			return err
		}
		logs = append(logs, log)
	}

	r.mu.Lock()
	r.logs = logs
	r.mu.Unlock()

	return rows.Err()
}

// savePolicyToDB 保存策略到数据库
func (r *CleanupRepository) savePolicyToDB(policy *models.CleanupPolicy) error {
	if r.db == nil {
		return nil
	}

	var lastRun interface{}
	if policy.LastRunAt != nil {
		lastRun = *policy.LastRunAt
	} else {
		lastRun = nil
	}

	_, err := r.db.Exec(`
		INSERT INTO cleanup_policy (
			id, auto_cleanup_enabled, recording_retention_days, 
			screenshot_retention_days, log_retention_days, 
			disk_usage_threshold_percent, cleanup_interval_minutes, 
			last_run_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
		ON CONFLICT(id) DO UPDATE SET
			auto_cleanup_enabled = EXCLUDED.auto_cleanup_enabled,
			recording_retention_days = EXCLUDED.recording_retention_days,
			screenshot_retention_days = EXCLUDED.screenshot_retention_days,
			log_retention_days = EXCLUDED.log_retention_days,
			disk_usage_threshold_percent = EXCLUDED.disk_usage_threshold_percent,
			cleanup_interval_minutes = EXCLUDED.cleanup_interval_minutes,
			last_run_at = EXCLUDED.last_run_at,
			updated_at = EXCLUDED.updated_at`,
		defaultCleanupPolicyID,
		policy.AutoCleanupEnabled,
		policy.RecordingRetentionDays,
		policy.ScreenshotRetentionDays,
		policy.LogRetentionDays,
		policy.DiskUsageThresholdPercent,
		policy.CleanupIntervalMinutes,
		lastRun,
		policy.UpdatedAt,
	)
	return err
}

// defaultCleanupPolicy 返回默认策略
func defaultCleanupPolicy() *models.CleanupPolicy {
	return &models.CleanupPolicy{
		AutoCleanupEnabled:        true,
		RecordingRetentionDays:    5,
		ScreenshotRetentionDays:   5,
		LogRetentionDays:          5,
		DiskUsageThresholdPercent: 80,
		CleanupIntervalMinutes:    60,
		UpdatedAt:                 time.Now(),
	}
}

// GetPolicy 返回当前策略，优先返回内存缓存，必要时从 DB 加载
func (r *CleanupRepository) GetPolicy(ctx context.Context) (*models.CleanupPolicy, error) {
	r.mu.RLock()
	if r.policy != nil {
		p := r.policy
		r.mu.RUnlock()
		return p, nil
	}
	r.mu.RUnlock()

	if err := r.loadPolicy(); err != nil {
		return defaultCleanupPolicy(), nil
	}

	r.mu.RLock()
	defer r.mu.RUnlock()
	if r.policy == nil {
		r.policy = defaultCleanupPolicy()
	}
	return r.policy, nil
}

// UpdatePolicy 更新策略并持久化
func (r *CleanupRepository) UpdatePolicy(ctx context.Context, p *models.CleanupPolicy) error {
	r.mu.Lock()
	r.policy = p
	r.mu.Unlock()
	return r.savePolicyToDB(p)
}

// saveLogToDB 保存日志到数据库
func (r *CleanupRepository) saveLogToDB(logEntry models.CleanupLog) error {
	if r.db == nil {
		return nil
	}

	_, err := r.db.Exec(`
		INSERT INTO cleanup_logs (
			id, trigger_type, status, deleted_recordings, 
			deleted_screenshots, deleted_logs, deleted_bytes, 
			message, started_at, completed_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
		logEntry.ID,
		logEntry.TriggerType,
		logEntry.Status,
		logEntry.DeletedRecordings,
		logEntry.DeletedScreenshots,
		logEntry.DeletedLogs,
		logEntry.DeletedBytes,
		logEntry.Message,
		logEntry.StartedAt,
		logEntry.CompletedAt,
	)
	return err
}

// DeleteExpiredRecordings 删除过期的录制文件（独立调用）
func (r *CleanupRepository) DeleteExpiredRecordings(ctx context.Context, days int) (int64, error) {
	if r.db == nil || days <= 0 {
		return 0, nil
	}

	cutoff := models.UTCNow().AddDate(0, 0, -days)
	result, err := r.db.ExecContext(ctx, `DELETE FROM recordings WHERE start_time < $1`, cutoff)
	if err != nil {
		return 0, err
	}
	return result.RowsAffected()
}

// DeleteExpiredScreenshots 删除过期的截图（独立调用）
func (r *CleanupRepository) DeleteExpiredScreenshots(ctx context.Context, days int) (int64, error) {
	if r.db == nil || days <= 0 {
		return 0, nil
	}

	cutoff := models.UTCNow().AddDate(0, 0, -days)
	result, err := r.db.ExecContext(ctx, `DELETE FROM screenshots WHERE captured_at < $1`, cutoff)
	if err != nil {
		return 0, err
	}
	return result.RowsAffected()
}

// DeleteExpiredActivityLogs 删除过期的活动日志（独立调用）
func (r *CleanupRepository) DeleteExpiredActivityLogs(ctx context.Context, days int) (int64, error) {
	if r.db == nil || days <= 0 {
		return 0, nil
	}

	cutoff := models.UTCNow().AddDate(0, 0, -days)
	result, err := r.db.ExecContext(ctx, `DELETE FROM activity_logs WHERE started_at < $1`, cutoff)
	if err != nil {
		return 0, err
	}
	return result.RowsAffected()
}



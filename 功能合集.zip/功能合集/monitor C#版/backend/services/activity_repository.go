// backend/services/activity_repository.go
// 修复版本 - 保持原有功能，添加缓存淘汰机制

package services

import (
	"context"
	"database/sql"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

// maxCacheSize 缓存最大条目数
const maxCacheSize = 10000

// ActivityRepository 活动日志仓库
type ActivityRepository struct {
	db *sql.DB
	mu sync.RWMutex
	activities map[string]*models.ActivityLog
	// cacheKeys 用于 LRU 淘汰（简单 FIFO）
	cacheKeys []string
}

// NewActivityRepository 创建活动日志仓库
func NewActivityRepository(db *sql.DB) *ActivityRepository {
	repo := &ActivityRepository{
		db:         db,
		activities: make(map[string]*models.ActivityLog),
		cacheKeys:  make([]string, 0, maxCacheSize),
	}
	if db != nil {
		repo.createTable()
		repo.loadActivities() // 加载最近数据到缓存
	}
	return repo
}

// createTable 创建 PostgreSQL 兼容的表结构
func (r *ActivityRepository) createTable() {
	// PostgreSQL 原生建表语句
	createTableSQL := `
		CREATE TABLE IF NOT EXISTS activity_logs (
			id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
			device_id VARCHAR(255) NOT NULL,
			process_name VARCHAR(255),
			window_title TEXT,
			browser_title TEXT,
			started_at TIMESTAMP WITH TIME ZONE NOT NULL,
			ended_at TIMESTAMP WITH TIME ZONE,
			is_idle BOOLEAN DEFAULT FALSE,
			duration_seconds INTEGER DEFAULT 0,
			created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
		)
	`

	// 创建索引
	indexes := []string{
		`CREATE INDEX IF NOT EXISTS idx_activity_device_id ON activity_logs(device_id)`,
		`CREATE INDEX IF NOT EXISTS idx_activity_started_at ON activity_logs(started_at)`,
		`CREATE INDEX IF NOT EXISTS idx_activity_process_name ON activity_logs(process_name)`,
		`CREATE INDEX IF NOT EXISTS idx_activity_device_started ON activity_logs(device_id, started_at DESC)`,
		`CREATE INDEX IF NOT EXISTS idx_activity_created_at ON activity_logs(created_at)`,
	}

	if _, err := r.db.Exec(createTableSQL); err != nil {
		// 如果表已存在但结构不同，尝试迁移
		if strings.Contains(err.Error(), "already exists") {
			r.migrateTable()
		}
	}

	for _, idx := range indexes {
		_, _ = r.db.Exec(idx)
	}
}

// migrateTable 迁移旧表结构（如果存在 TEXT 类型的列）
func (r *ActivityRepository) migrateTable() {
	// 检查列类型并转换
	migrations := []string{
		`ALTER TABLE activity_logs ALTER COLUMN id TYPE UUID USING id::UUID`,
		`ALTER TABLE activity_logs ALTER COLUMN started_at TYPE TIMESTAMP WITH TIME ZONE USING started_at::TIMESTAMP WITH TIME ZONE`,
		`ALTER TABLE activity_logs ALTER COLUMN ended_at TYPE TIMESTAMP WITH TIME ZONE USING ended_at::TIMESTAMP WITH TIME ZONE`,
		`ALTER TABLE activity_logs ALTER COLUMN created_at TYPE TIMESTAMP WITH TIME ZONE USING created_at::TIMESTAMP WITH TIME ZONE`,
		`ALTER TABLE activity_logs ALTER COLUMN is_idle TYPE BOOLEAN USING is_idle::BOOLEAN`,
	}

	for _, migration := range migrations {
		_, _ = r.db.Exec(migration)
	}
}

// loadActivities 从数据库加载最近的活动日志到内存缓存
func (r *ActivityRepository) loadActivities() {
	rows, err := r.db.Query(`
		SELECT id, device_id, process_name, window_title, browser_title, 
		       started_at, ended_at, is_idle, duration_seconds, created_at
		FROM activity_logs
		ORDER BY started_at DESC
		LIMIT $1
	`, maxCacheSize)
	if err != nil {
		return
	}
	defer rows.Close()

	r.mu.Lock()
	defer r.mu.Unlock()

	// 清空现有缓存
	r.activities = make(map[string]*models.ActivityLog)
	r.cacheKeys = make([]string, 0, maxCacheSize)

	for rows.Next() {
		var a models.ActivityLog
		var id uuid.UUID
		var deviceID string
		var startedAt, createdAt time.Time
		var endedAt sql.NullTime

		if err := rows.Scan(&id, &deviceID, &a.ProcessName, &a.WindowTitle, &a.BrowserTitle,
			&startedAt, &endedAt, &a.IsIdle, &a.DurationSeconds, &createdAt); err != nil {
			continue
		}
		a.ID = id.String()
		a.DeviceID = deviceID
		a.StartedAt = startedAt
		a.CreatedAt = createdAt
		if endedAt.Valid {
			a.EndedAt = &endedAt.Time
		}
		r.activities[a.ID] = &a
		r.cacheKeys = append(r.cacheKeys, a.ID)
	}
}

// addToCache 添加条目到缓存，并处理淘汰
func (r *ActivityRepository) addToCache(id string, log *models.ActivityLog) {
	r.mu.Lock()
	defer r.mu.Unlock()

	// 如果已存在，更新
	if _, exists := r.activities[id]; exists {
		r.activities[id] = log
		return
	}

	// 检查是否需要淘汰
	if len(r.activities) >= maxCacheSize {
		// 淘汰最早的条目（FIFO）
		if len(r.cacheKeys) > 0 {
			oldestID := r.cacheKeys[0]
			delete(r.activities, oldestID)
			r.cacheKeys = r.cacheKeys[1:]
		}
	}

	// 添加新条目
	r.activities[id] = log
	r.cacheKeys = append(r.cacheKeys, id)
}

// removeFromCache 从缓存中删除条目
func (r *ActivityRepository) removeFromCache(id string) {
	r.mu.Lock()
	defer r.mu.Unlock()

	delete(r.activities, id)

	// 从 keys 列表中移除
	for i, key := range r.cacheKeys {
		if key == id {
			r.cacheKeys = append(r.cacheKeys[:i], r.cacheKeys[i+1:]...)
			break
		}
	}
}

// removeFromCacheByDevice 从缓存中删除指定设备的所有条目
func (r *ActivityRepository) removeFromCacheByDevice(deviceID string) {
	r.mu.Lock()
	defer r.mu.Unlock()

	var newKeys []string
	for _, id := range r.cacheKeys {
		if a, exists := r.activities[id]; exists && a.DeviceID == deviceID {
			delete(r.activities, id)
			continue
		}
		newKeys = append(newKeys, id)
	}
	r.cacheKeys = newKeys
}

// List 获取活动日志列表（分页）- 直接从数据库查询
func (r *ActivityRepository) List(ctx context.Context, deviceID, startDate, endDate, processName string, page, pageSize int) ([]models.ActivityLog, int, error) {
	offset := (page - 1) * pageSize
	args := []interface{}{}
	where := []string{"1=1"}
	argIdx := 1

	if deviceID != "" {
		where = append(where, fmt.Sprintf("device_id = $%d", argIdx))
		args = append(args, deviceID)
		argIdx++
	}
	if startDate != "" {
		where = append(where, fmt.Sprintf("started_at >= $%d", argIdx))
		args = append(args, startDate)
		argIdx++
	}
	if endDate != "" {
		where = append(where, fmt.Sprintf("started_at <= $%d", argIdx))
		args = append(args, endDate+" 23:59:59")
		argIdx++
	}
	if processName != "" {
		where = append(where, fmt.Sprintf("process_name ILIKE $%d", argIdx))
		args = append(args, "%"+processName+"%")
		argIdx++
	}

	whereClause := strings.Join(where, " AND ")

	// 查询总数
	countQuery := `SELECT COUNT(*) FROM activity_logs WHERE ` + whereClause
	var total int
	if err := r.db.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
		return nil, 0, err
	}

	// 查询数据
	dataQuery := `SELECT id, device_id, process_name, window_title, browser_title, 
	                 started_at, ended_at, is_idle, duration_seconds, created_at
	              FROM activity_logs 
	              WHERE ` + whereClause + `
	              ORDER BY started_at DESC
	              LIMIT $` + fmt.Sprintf("%d", argIdx) + ` OFFSET $` + fmt.Sprintf("%d", argIdx+1)
	args = append(args, pageSize, offset)

	rows, err := r.db.QueryContext(ctx, dataQuery, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	var activities []models.ActivityLog
	for rows.Next() {
		var a models.ActivityLog
		var id uuid.UUID
		var deviceID string
		var startedAt, createdAt time.Time
		var endedAt sql.NullTime

		if err := rows.Scan(&id, &deviceID, &a.ProcessName, &a.WindowTitle, &a.BrowserTitle,
			&startedAt, &endedAt, &a.IsIdle, &a.DurationSeconds, &createdAt); err != nil {
			return nil, 0, err
		}
		a.ID = id.String()
		a.DeviceID = deviceID
		a.StartedAt = startedAt
		a.CreatedAt = createdAt
		if endedAt.Valid {
			a.EndedAt = &endedAt.Time
		}
		activities = append(activities, a)
	}

	return activities, total, nil
}

// GetStats 获取活动统计 - 直接从数据库聚合查询
func (r *ActivityRepository) GetStats(ctx context.Context, deviceID, startDate, endDate string) (*models.ActivityStats, error) {
	args := []interface{}{}
	where := []string{"1=1"}
	argIdx := 1

	if deviceID != "" {
		where = append(where, fmt.Sprintf("device_id = $%d", argIdx))
		args = append(args, deviceID)
		argIdx++
	}
	if startDate != "" {
		where = append(where, fmt.Sprintf("started_at >= $%d", argIdx))
		args = append(args, startDate)
		argIdx++
	}
	if endDate != "" {
		where = append(where, fmt.Sprintf("started_at <= $%d", argIdx))
		args = append(args, endDate+" 23:59:59")
		argIdx++
	}

	whereClause := strings.Join(where, " AND ")

	// 总时长统计
	var totalDuration, idleDuration, activeDuration int64
	err := r.db.QueryRowContext(ctx, `
		SELECT COALESCE(SUM(duration_seconds), 0) as total,
		       COALESCE(SUM(CASE WHEN is_idle = true THEN duration_seconds ELSE 0 END), 0) as idle,
		       COALESCE(SUM(CASE WHEN is_idle = false THEN duration_seconds ELSE 0 END), 0) as active
		FROM activity_logs WHERE `+whereClause, args...).Scan(&totalDuration, &idleDuration, &activeDuration)
	if err != nil {
		return nil, err
	}

	// Top应用
	appQuery := `
		SELECT process_name, SUM(duration_seconds) as duration
		FROM activity_logs 
		WHERE ` + whereClause + ` AND is_idle = false AND process_name != ''
		GROUP BY process_name 
		ORDER BY duration DESC 
		LIMIT 10`
	appRows, err := r.db.QueryContext(ctx, appQuery, args...)
	if err != nil {
		return nil, err
	}
	defer appRows.Close()

	var topApps []models.AppUsage
	for appRows.Next() {
		var app models.AppUsage
		if err := appRows.Scan(&app.ProcessName, &app.Duration); err != nil {
			continue
		}
		if activeDuration > 0 {
			app.Percentage = float64(app.Duration) / float64(activeDuration) * 100
		}
		topApps = append(topApps, app)
	}

	// 每小时分布
	hourlyQuery := `
		SELECT EXTRACT(HOUR FROM started_at)::int as hour,
		       COALESCE(SUM(duration_seconds), 0) as duration
		FROM activity_logs
		WHERE ` + whereClause + `
		GROUP BY hour
		ORDER BY hour ASC`
	hourlyRows, err := r.db.QueryContext(ctx, hourlyQuery, args...)
	if err != nil {
		return nil, err
	}
	defer hourlyRows.Close()

	hourlyActivity := make(map[string]int64)
	for hourlyRows.Next() {
		var hour int
		var duration int64
		if err := hourlyRows.Scan(&hour, &duration); err != nil {
			continue
		}
		hourlyActivity[strconv.Itoa(hour)] = duration
	}

	// 每日活动
	dailyQuery := `
		SELECT DATE(started_at) as date,
		       SUM(CASE WHEN is_idle = false THEN duration_seconds ELSE 0 END) as active,
		       SUM(CASE WHEN is_idle = true THEN duration_seconds ELSE 0 END) as idle
		FROM activity_logs 
		WHERE ` + whereClause + `
		GROUP BY DATE(started_at) 
		ORDER BY date DESC 
		LIMIT 30`
	dailyRows, err := r.db.QueryContext(ctx, dailyQuery, args...)
	if err != nil {
		return nil, err
	}
	defer dailyRows.Close()

	var dailyActivity []models.DailyActivity
	for dailyRows.Next() {
		var date string
		var active, idle int64
		if err := dailyRows.Scan(&date, &active, &idle); err != nil {
			continue
		}
		dailyActivity = append([]models.DailyActivity{{
			Date:   date,
			Hours:  float64(active+idle) / 3600.0,
			Idle:   float64(idle) / 3600.0,
			Active: float64(active) / 3600.0,
		}}, dailyActivity...)
	}

	productivityRate := 0.0
	if totalDuration > 0 {
		productivityRate = float64(activeDuration) / float64(totalDuration) * 100
	}

	return &models.ActivityStats{
		TotalDuration:    totalDuration,
		IdleDuration:     idleDuration,
		ActiveDuration:   activeDuration,
		TopApps:          topApps,
		DailyActivity:    dailyActivity,
		HourlyActivity:   hourlyActivity,
		ProductivityRate: productivityRate,
	}, nil
}

// Add 添加单条活动日志
func (r *ActivityRepository) Add(ctx context.Context, log *models.ActivityLog) error {
	if log.ID == "" {
		log.ID = uuid.New().String()
	}
	if log.CreatedAt.IsZero() {
		log.CreatedAt = time.Now().UTC()
	}

	// 先写入数据库
	query := `
		INSERT INTO activity_logs (id, device_id, process_name, window_title, browser_title, 
		                           started_at, ended_at, is_idle, duration_seconds, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
		ON CONFLICT (id) DO UPDATE SET
			ended_at = EXCLUDED.ended_at,
			duration_seconds = EXCLUDED.duration_seconds
	`
	_, err := r.db.ExecContext(ctx, query,
		log.ID, log.DeviceID, log.ProcessName, log.WindowTitle, log.BrowserTitle,
		log.StartedAt, log.EndedAt, log.IsIdle, log.DurationSeconds, log.CreatedAt)
	if err != nil {
		return err
	}

	// 更新内存缓存
	r.addToCache(log.ID, log)

	return nil
}

func (r *ActivityRepository) BatchAdd(ctx context.Context, logs []models.ActivityLog) error {
	// ✅ 补充：空切片检查（保持与第一个版本一致）
	if len(logs) == 0 {
		return nil
	}

	now := time.Now().UTC()

	// 1. 预处理数据（与第一个版本完全一致）
	for i := range logs {
		if logs[i].ID == "" {
			logs[i].ID = uuid.New().String()
		}
		if logs[i].CreatedAt.IsZero() {
			logs[i].CreatedAt = now
		}
	}

	// 2. 开启事务
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	// 3. 构建批量 SQL（性能优化点，但功能等价）
	valueArgs := make([]any, 0, len(logs)*14)
	valueStrings := make([]string, 0, len(logs))

	for i, log := range logs {
		base := i * 14

		valueStrings = append(valueStrings,
			fmt.Sprintf("($%d,$%d,$%d,$%d,$%d,$%d,$%d,$%d,$%d,$%d,$%d,$%d,$%d,$%d)",
				base+1, base+2, base+3, base+4, base+5,
				base+6, base+7, base+8, base+9, base+10,
				base+11, base+12, base+13, base+14,
			),
		)

		valueArgs = append(valueArgs,
			log.ID,
			log.DeviceID,
			log.ProcessName,
			log.WindowTitle,
			log.BrowserTitle,
			log.StartedAt,
			log.EndedAt,
			log.IsIdle,
			log.DurationSeconds,
			log.CreatedAt,
			log.Reported,
			log.ReportedAt,
			log.RetryCount,
			log.ErrorMessage,
		)
	}

	query := fmt.Sprintf(`
		INSERT INTO activity_logs (
			id, device_id, process_name, window_title, browser_title,
			started_at, ended_at, is_idle, duration_seconds, created_at,
			reported, reported_at, retry_count, error_message
		)
		VALUES %s
		ON CONFLICT (id) DO UPDATE SET
			ended_at = EXCLUDED.ended_at,
			duration_seconds = EXCLUDED.duration_seconds,
			reported = EXCLUDED.reported,
			reported_at = EXCLUDED.reported_at,
			retry_count = EXCLUDED.retry_count,
			error_message = EXCLUDED.error_message
	`, strings.Join(valueStrings, ","))

	// 4. 执行批量插入
	_, err = tx.ExecContext(ctx, query, valueArgs...)
	if err != nil {
		return err
	}

	// 5. 提交事务
	if err := tx.Commit(); err != nil {
		return err
	}

	// 6. 更新缓存（与第一个版本一致）
	for i := range logs {
		r.addToCache(logs[i].ID, &logs[i])
	}

	return nil
}

// DeleteOlderThan 删除指定天数前的数据
func (r *ActivityRepository) DeleteOlderThan(ctx context.Context, days int) (int64, error) {
	// 防止误删：如果 days <= 0，返回错误
	if days <= 0 {
		return 0, fmt.Errorf("invalid retention days: %d, must be positive", days)
	}

	cutoff := time.Now().UTC().AddDate(0, 0, -days)

	// 从数据库删除
	result, err := r.db.ExecContext(ctx, "DELETE FROM activity_logs WHERE started_at < $1", cutoff)
	if err != nil {
		return 0, err
	}
	deletedCount, _ := result.RowsAffected()

	// 同时从缓存中删除
	r.mu.Lock()
	for id, a := range r.activities {
		if a.StartedAt.Before(cutoff) {
			delete(r.activities, id)
			// 从 keys 中移除
			for i, key := range r.cacheKeys {
				if key == id {
					r.cacheKeys = append(r.cacheKeys[:i], r.cacheKeys[i+1:]...)
					break
				}
			}
		}
	}
	r.mu.Unlock()

	return deletedCount, nil
}

// DeleteByDeviceID 删除指定设备的所有活动日志
func (r *ActivityRepository) DeleteByDeviceID(ctx context.Context, deviceID string) (int64, error) {
	if deviceID == "" {
		return 0, fmt.Errorf("device_id is required")
	}

	result, err := r.db.ExecContext(ctx, "DELETE FROM activity_logs WHERE device_id = $1", deviceID)
	if err != nil {
		return 0, err
	}
	deletedCount, _ := result.RowsAffected()

	// 从缓存中删除
	r.removeFromCacheByDevice(deviceID)

	return deletedCount, nil
}

// ExportCSV 导出为CSV格式
func (r *ActivityRepository) ExportCSV(ctx context.Context, deviceID, startDate, endDate string) (string, error) {
	logs, _, err := r.List(ctx, deviceID, startDate, endDate, "", 1, 10000)
	if err != nil {
		return "", err
	}

	var builder strings.Builder
	builder.WriteString("ID,设备ID,进程名称,窗口标题,浏览器标题,开始时间,结束时间,空闲状态,持续时长(秒),创建时间\n")

	for _, l := range logs {
		endedAt := ""
		if l.EndedAt != nil {
			endedAt = l.EndedAt.Format(time.RFC3339)
		}
		isIdle := "否"
		if l.IsIdle {
			isIdle = "是"
		}
		builder.WriteString(fmt.Sprintf("%s,%s,%s,%s,%s,%s,%s,%s,%d,%s\n",
			l.ID, l.DeviceID, escapeCSV(l.ProcessName), escapeCSV(l.WindowTitle), escapeCSV(l.BrowserTitle),
			l.StartedAt.Format(time.RFC3339), endedAt, isIdle, l.DurationSeconds, l.CreatedAt.Format(time.RFC3339)))
	}
	return builder.String(), nil
}

// GetDistinctProcesses 获取不重复的进程名列表
func (r *ActivityRepository) GetDistinctProcesses(ctx context.Context, deviceID string) ([]string, error) {
	query := `SELECT DISTINCT process_name FROM activity_logs WHERE process_name != ''`
	args := []interface{}{}

	if deviceID != "" {
		query += " AND device_id = $1"
		args = append(args, deviceID)
	}
	query += " ORDER BY process_name"

	rows, err := r.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var processes []string
	for rows.Next() {
		var p string
		if err := rows.Scan(&p); err != nil {
			continue
		}
		processes = append(processes, p)
	}
	return processes, nil
}

// GetByID 根据ID获取单条活动日志
func (r *ActivityRepository) GetByID(ctx context.Context, id string) (*models.ActivityLog, error) {
	// 先查缓存
	r.mu.RLock()
	if a, ok := r.activities[id]; ok {
		aCopy := *a
		r.mu.RUnlock()
		return &aCopy, nil
	}
	r.mu.RUnlock()

	// 缓存未命中，查询数据库
	var a models.ActivityLog
	var uid uuid.UUID
	var deviceID string
	var startedAt, createdAt time.Time
	var endedAt sql.NullTime

	query := `SELECT id, device_id, process_name, window_title, browser_title, 
	                 started_at, ended_at, is_idle, duration_seconds, created_at
	          FROM activity_logs WHERE id = $1`

	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&uid, &deviceID, &a.ProcessName, &a.WindowTitle, &a.BrowserTitle,
		&startedAt, &endedAt, &a.IsIdle, &a.DurationSeconds, &createdAt)
	if err != nil {
		return nil, err
	}

	a.ID = uid.String()
	a.DeviceID = deviceID
	a.StartedAt = startedAt
	a.CreatedAt = createdAt
	if endedAt.Valid {
		a.EndedAt = &endedAt.Time
	}

	// 更新缓存
	r.addToCache(a.ID, &a)

	return &a, nil
}

// Count 统计活动日志数量
func (r *ActivityRepository) Count(ctx context.Context, deviceID string, startDate, endDate string) (int, error) {
	args := []interface{}{}
	where := []string{"1=1"}
	argIdx := 1

	if deviceID != "" {
		where = append(where, fmt.Sprintf("device_id = $%d", argIdx))
		args = append(args, deviceID)
		argIdx++
	}
	if startDate != "" {
		where = append(where, fmt.Sprintf("started_at >= $%d", argIdx))
		args = append(args, startDate)
		argIdx++
	}
	if endDate != "" {
		where = append(where, fmt.Sprintf("started_at <= $%d", argIdx))
		args = append(args, endDate+" 23:59:59")
		argIdx++
	}

	whereClause := strings.Join(where, " AND ")
	query := `SELECT COUNT(*) FROM activity_logs WHERE ` + whereClause

	var count int
	err := r.db.QueryRowContext(ctx, query, args...).Scan(&count)
	return count, err
}

// InvalidateCache 清除指定设备的缓存
func (r *ActivityRepository) InvalidateCache(deviceID string) {
	r.removeFromCacheByDevice(deviceID)
}

// ClearCache 清除所有缓存
func (r *ActivityRepository) ClearCache() {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.activities = make(map[string]*models.ActivityLog)
	r.cacheKeys = make([]string, 0, maxCacheSize)
}

// GetCacheSize 获取当前缓存大小（用于调试）
func (r *ActivityRepository) GetCacheSize() int {
	r.mu.RLock()
	defer r.mu.RUnlock()
	return len(r.activities)
}

// GetDailySummary 获取每日活动汇总
func (r *ActivityRepository) GetDailySummary(ctx context.Context, deviceID string, days int) ([]models.DailyActivitySummary, error) {
	if days < 1 || days > 365 {
		days = 7
	}

	startDate := time.Now().UTC().AddDate(0, 0, -days)

	args := []interface{}{startDate}
	query := `
		SELECT 
			DATE(started_at) as date,
			COUNT(DISTINCT id) as total_activities,
			SUM(CASE WHEN is_idle = 0 THEN 1 ELSE 0 END) as active_count,
			SUM(CASE WHEN is_idle = 1 THEN 1 ELSE 0 END) as idle_count,
			SUM(duration_seconds) as total_duration,
			SUM(CASE WHEN is_idle = 0 THEN duration_seconds ELSE 0 END) as active_duration,
			SUM(CASE WHEN is_idle = 1 THEN duration_seconds ELSE 0 END) as idle_duration
		FROM activity_logs
		WHERE started_at >= $1`

	if deviceID != "" {
		query += " AND device_id = $2"
		args = append(args, deviceID)
	}

	query += ` GROUP BY DATE(started_at) ORDER BY date DESC`

	rows, err := r.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var results []models.DailyActivitySummary
	for rows.Next() {
		var date string
		var totalActivities, activeCount, idleCount int64
		var totalDuration, activeDuration, idleDuration sql.NullInt64

		if err := rows.Scan(&date, &totalActivities, &activeCount, &idleCount, &totalDuration, &activeDuration, &idleDuration); err != nil {
			continue
		}

		activeMinutes := int64(0)
		if activeDuration.Valid {
			activeMinutes = activeDuration.Int64 / 60
		}
		idleMinutes := int64(0)
		if idleDuration.Valid {
			idleMinutes = idleDuration.Int64 / 60
		}

		total := int64(0)
		if totalDuration.Valid {
			total = totalDuration.Int64
		}

		productivity := 0.0
		if total > 0 {
			productivity = float64(activeDuration.Int64) / float64(total) * 100
		}

		results = append(results, models.DailyActivitySummary{
			Date:          date,
			ActiveMinutes: activeMinutes,
			IdleMinutes:   idleMinutes,
			AppCount:      totalActivities,
			Productivity:  productivity,
		})
	}

	return results, nil
}

// DeleteActivities 删除指定ID的活动日志
func (r *ActivityRepository) DeleteActivities(ctx context.Context, ids []string) (int64, error) {
	if len(ids) == 0 {
		return 0, fmt.Errorf("ids list is empty")
	}

	// 生成占位符
	placeholders := make([]string, len(ids))
	args := make([]interface{}, len(ids))
	for i, id := range ids {
		placeholders[i] = fmt.Sprintf("$%d", i+1)
		args[i] = id
	}
	placeholderStr := strings.Join(placeholders, ",")

	query := fmt.Sprintf("DELETE FROM activity_logs WHERE id IN (%s)", placeholderStr)
	result, err := r.db.ExecContext(ctx, query, args...)
	if err != nil {
		return 0, err
	}

	deletedCount, _ := result.RowsAffected()

	// 从缓存中删除
	r.mu.Lock()
	for _, id := range ids {
		delete(r.activities, id)
		for i, key := range r.cacheKeys {
			if key == id {
				r.cacheKeys = append(r.cacheKeys[:i], r.cacheKeys[i+1:]...)
				break
			}
		}
	}
	r.mu.Unlock()

	return deletedCount, nil
}

// escapeCSV 转义 CSV 字段中的特殊字符
func escapeCSV(s string) string {
	if s == "" {
		return ""
	}

	// 如果字段包含逗号、换行符或双引号，需要用双引号包围并转义内部双引号
	needsQuoting := strings.ContainsAny(s, ",\"\n\r")

	if needsQuoting {
		// 将双引号替换为两个双引号
		escaped := strings.ReplaceAll(s, "\"", "\"\"")
		return fmt.Sprintf("\"%s\"", escaped)
	}

	return s
}

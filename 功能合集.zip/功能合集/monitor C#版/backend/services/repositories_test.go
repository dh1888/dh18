package services

import (
	"testing"

	"golang.org/x/crypto/bcrypt"
)

func TestNewDatabaseSeedsAdminUser(t *testing.T) {
	defer func() {
		if r := recover(); r != nil {
			t.Skipf("Skipping test because database is unavailable: %v", r)
		}
	}()

	db := NewDatabase()
	if db == nil {
		t.Fatal("expected database handle")
	}
	defer db.Close()

	var username, passwordHash string
	var status int
	if err := db.QueryRow(`SELECT username, password_hash, status FROM users WHERE username = $1`, "admin").Scan(&username, &passwordHash, &status); err != nil {
		t.Fatalf("expected seeded admin user: %v", err)
	}
	if username != "admin" {
		t.Fatalf("expected admin username, got %s", username)
	}
	if status != 1 {
		t.Fatalf("expected admin user status 1, got %d", status)
	}
	if err := bcrypt.CompareHashAndPassword([]byte(passwordHash), []byte("admin123")); err != nil {
		t.Fatalf("expected seeded admin password to be valid: %v", err)
	}
}

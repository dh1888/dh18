package middleware

import (
	"context"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
)

// WebSocketAuth WebSocket 专用认证中间件
func WebSocketAuth(redisClient *redis.Client) gin.HandlerFunc {
	return func(c *gin.Context) {
		token := strings.TrimSpace(c.Query("token"))

		if token == "" {
			authHeader := c.GetHeader("Authorization")
			if strings.HasPrefix(authHeader, "Bearer ") {
				token = strings.TrimSpace(strings.TrimPrefix(authHeader, "Bearer "))
			}
		}

		if token == "" {
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Missing token"})
			return
		}

		secret := models.JWTSecret()
		if len(secret) == 0 {
			c.AbortWithStatusJSON(500, gin.H{"code": 5000, "message": "JWT secret not configured"})
			return
		}

		userClaims := &models.Claims{}
		parsedToken, err := jwt.ParseWithClaims(token, userClaims, func(t *jwt.Token) (interface{}, error) {
			if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, jwt.ErrSignatureInvalid
			}
			return secret, nil
		}, jwt.WithValidMethods([]string{jwt.SigningMethodHS256.Name}))

		if err == nil && parsedToken.Valid && userClaims.UserID != "" {
			if revoked, unavailable := checkTokenBlacklist(context.Background(), redisClient, token); unavailable {
				c.AbortWithStatusJSON(503, gin.H{"code": 5003, "message": "Authentication service temporarily unavailable"})
				return
			} else if revoked {
				c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Token revoked"})
				return
			}
			c.Set("userID", userClaims.UserID)
			c.Set("username", userClaims.Username)
			c.Set("role", normalizeRoleNameWebSocket(userClaims.Role))
			c.Set("permissions", userClaims.Permissions)
			c.Next()
			return
		}

		deviceClaims := &models.DeviceClaims{}
		parsedToken, err = jwt.ParseWithClaims(token, deviceClaims, func(t *jwt.Token) (interface{}, error) {
			if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, jwt.ErrSignatureInvalid
			}
			return secret, nil
		}, jwt.WithValidMethods([]string{jwt.SigningMethodHS256.Name}))

		if err == nil && parsedToken.Valid && deviceClaims.DeviceID != "" {
			if revoked, unavailable := checkTokenBlacklist(context.Background(), redisClient, token); unavailable {
				c.AbortWithStatusJSON(503, gin.H{"code": 5003, "message": "Authentication service temporarily unavailable"})
				return
			} else if revoked {
				c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Token revoked"})
				return
			}
			c.Set("deviceID", deviceClaims.DeviceID)
			c.Next()
			return
		}

		c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Invalid token"})
	}
}

// normalizeRoleNameWebSocket 规范化角色名称
func normalizeRoleNameWebSocket(roleName string) string {
	switch strings.TrimSpace(strings.ToLower(roleName)) {
	case "管理员", "admin", "administrator", "超级管理员", "superadmin":
		return "admin"
	case "审计员", "auditor":
		return "auditor"
	case "操作员", "operator", "ops":
		return "operator"
	case "查看员", "viewer":
		return "viewer"
	default:
		return "auditor"
	}
}

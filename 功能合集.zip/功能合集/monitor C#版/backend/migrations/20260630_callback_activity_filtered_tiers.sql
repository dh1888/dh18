-- 活动配置：手动回访过滤层级（默认剔除 新-无优惠、洗水套利、黑名单）
ALTER TABLE callback_activity
    ADD COLUMN IF NOT EXISTS filtered_tiers JSONB NOT NULL DEFAULT '["新-无优惠","洗水套利","黑名单"]'::jsonb;

COMMENT ON COLUMN callback_activity.filtered_tiers IS '手动回访需过滤的层级列表';

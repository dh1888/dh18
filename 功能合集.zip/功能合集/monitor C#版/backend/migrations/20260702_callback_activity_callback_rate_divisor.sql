-- 回访彩金：独立比例与除数
ALTER TABLE callback_activity
    ADD COLUMN IF NOT EXISTS callback_rate NUMERIC(10, 6) NOT NULL DEFAULT 0.02,
    ADD COLUMN IF NOT EXISTS callback_divisor INTEGER NOT NULL DEFAULT 2;

UPDATE callback_activity
SET
    callback_rate = COALESCE(callback_rate, 0.02),
    callback_divisor = COALESCE(NULLIF(callback_divisor, 0), 2)
WHERE TRUE;

COMMENT ON COLUMN callback_activity.callback_rate IS '回访彩金：亏损计算比例';
COMMENT ON COLUMN callback_activity.callback_divisor IS '回访彩金：亏损计算除数';

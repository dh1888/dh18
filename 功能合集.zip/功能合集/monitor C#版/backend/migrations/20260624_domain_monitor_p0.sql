-- Domain Monitor P0：仅新增表，不修改现有表
-- 执行：psql -U postgres -d enterprise_agent -f backend/migrations/20260624_domain_monitor_p0.sql

CREATE TABLE IF NOT EXISTS dm_groups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(64) NOT NULL UNIQUE,
    description TEXT,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS dm_domains (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    group_id UUID REFERENCES dm_groups(id) ON DELETE SET NULL,
    domain VARCHAR(255) NOT NULL UNIQUE,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    check_interval INT NOT NULL DEFAULT 300,
    remark TEXT,
    enable_dns BOOLEAN NOT NULL DEFAULT TRUE,
    enable_http BOOLEAN NOT NULL DEFAULT TRUE,
    enable_ssl BOOLEAN NOT NULL DEFAULT TRUE,
    last_check_at TIMESTAMPTZ,
    last_dns_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
    last_http_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
    last_ssl_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_dm_domains_group ON dm_domains(group_id);
CREATE INDEX IF NOT EXISTS idx_dm_domains_enabled ON dm_domains(enabled);

CREATE TABLE IF NOT EXISTS dm_check_results (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    domain_id UUID NOT NULL REFERENCES dm_domains(id) ON DELETE CASCADE,
    node_id VARCHAR(64) NOT NULL DEFAULT 'local',
    node_name VARCHAR(128) NOT NULL DEFAULT 'Local Center',
    country VARCHAR(8) NOT NULL DEFAULT 'CN',
    city VARCHAR(64) DEFAULT '',
    check_type VARCHAR(32) NOT NULL,
    status VARCHAR(16) NOT NULL,
    duration_ms INT DEFAULT 0,
    http_status INT DEFAULT 0,
    final_url TEXT,
    redirect_chain JSONB,
    dns_records JSONB,
    ssl_info JSONB,
    raw_detail JSONB,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_dm_check_results_domain_time ON dm_check_results(domain_id, checked_at DESC);
CREATE INDEX IF NOT EXISTS idx_dm_check_results_checked_at ON dm_check_results(checked_at);

CREATE TABLE IF NOT EXISTS dm_alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    domain_id UUID REFERENCES dm_domains(id) ON DELETE SET NULL,
    alert_type VARCHAR(64) NOT NULL,
    severity VARCHAR(16) NOT NULL,
    title VARCHAR(256) NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'open',
    node_id VARCHAR(64),
    first_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_dm_alerts_status ON dm_alerts(status);
CREATE INDEX IF NOT EXISTS idx_dm_alerts_domain ON dm_alerts(domain_id);

CREATE TABLE IF NOT EXISTS dm_telegram_bots (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bot_name VARCHAR(128) NOT NULL,
    bot_token_enc TEXT NOT NULL,
    bot_username VARCHAR(64),
    bot_id BIGINT,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    remark TEXT,
    verified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS dm_telegram_groups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bot_id UUID NOT NULL REFERENCES dm_telegram_bots(id) ON DELETE CASCADE,
    group_name VARCHAR(256) NOT NULL,
    chat_id VARCHAR(64) NOT NULL,
    chat_type VARCHAR(32),
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(bot_id, chat_id)
);

CREATE TABLE IF NOT EXISTS dm_alert_routes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(128) NOT NULL,
    alert_types JSONB NOT NULL DEFAULT '[]',
    severities JSONB NOT NULL DEFAULT '[]',
    group_id UUID NOT NULL REFERENCES dm_telegram_groups(id) ON DELETE CASCADE,
    send_mode VARCHAR(16) NOT NULL DEFAULT 'realtime',
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 权限说明（需在角色管理 UI 中为管理员角色添加）：
-- domain_monitor:view, domain_monitor:manage, domain_monitor:settings

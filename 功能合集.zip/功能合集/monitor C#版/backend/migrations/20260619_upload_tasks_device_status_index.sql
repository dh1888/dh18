-- Composite index for pending task lookup: WHERE device_id = $1 AND status = 'pending'
CREATE INDEX IF NOT EXISTS idx_upload_tasks_device_status ON upload_tasks(device_id, status);

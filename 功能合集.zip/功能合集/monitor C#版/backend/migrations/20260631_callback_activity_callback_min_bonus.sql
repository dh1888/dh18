-- 活动配置：回访彩金最低彩金
ALTER TABLE callback_activity
    ADD COLUMN IF NOT EXISTS callback_min_bonus NUMERIC(18, 2) NOT NULL DEFAULT 1.00;

COMMENT ON COLUMN callback_activity.callback_min_bonus IS '回访彩金最低派发金额';

-- Domain Monitor P2：探针节点 / 截图 / 报告
-- 执行：psql -U postgres -d enterprise_agent -f backend/migrations/20260626_domain_monitor_p2.sql

ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_screenshot BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS screenshot_url TEXT DEFAULT '';
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_screenshot_status VARCHAR(16) NOT NULL DEFAULT 'unknown';

ALTER TABLE dm_check_results ADD COLUMN IF NOT EXISTS screenshot_path TEXT DEFAULT '';

CREATE TABLE IF NOT EXISTS dm_nodes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(128) NOT NULL,
    api_key_hash VARCHAR(64) NOT NULL UNIQUE,
    country VARCHAR(8) NOT NULL DEFAULT 'CN',
    city VARCHAR(64) DEFAULT '',
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    last_seen_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS dm_probe_tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    domain_id UUID NOT NULL REFERENCES dm_domains(id) ON DELETE CASCADE,
    node_id UUID NOT NULL REFERENCES dm_nodes(id) ON DELETE CASCADE,
    status VARCHAR(16) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_dm_probe_tasks_pending ON dm_probe_tasks(node_id, status);
CREATE UNIQUE INDEX IF NOT EXISTS idx_dm_probe_tasks_unique ON dm_probe_tasks(domain_id, node_id) WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS dm_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_type VARCHAR(16) NOT NULL,
    period_start TIMESTAMPTZ NOT NULL,
    period_end TIMESTAMPTZ NOT NULL,
    file_path TEXT NOT NULL,
    summary JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_dm_reports_type_time ON dm_reports(report_type, created_at DESC);

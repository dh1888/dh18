-- 活动配置：时段彩金 / 回访彩金分项设置
ALTER TABLE callback_activity
    ADD COLUMN IF NOT EXISTS period_filtered_tiers JSONB NOT NULL DEFAULT '["新-无优惠","洗水套利","黑名单"]'::jsonb,
    ADD COLUMN IF NOT EXISTS callback_filtered_tiers JSONB NOT NULL DEFAULT '["新-无优惠","洗水套利","黑名单"]'::jsonb,
    ADD COLUMN IF NOT EXISTS period_wagering_multiplier NUMERIC(10, 2) NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS callback_wagering_multiplier NUMERIC(10, 2) NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS period_app_remark TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS period_backend_remark TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS callback_app_remark TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS callback_backend_remark TEXT NOT NULL DEFAULT '';

UPDATE callback_activity
SET
    period_filtered_tiers = COALESCE(filtered_tiers, period_filtered_tiers),
    callback_filtered_tiers = COALESCE(filtered_tiers, callback_filtered_tiers),
    period_wagering_multiplier = COALESCE(wagering_multiplier, period_wagering_multiplier),
    callback_wagering_multiplier = COALESCE(wagering_multiplier, callback_wagering_multiplier),
    period_app_remark = COALESCE(NULLIF(app_remark, ''), period_app_remark),
    period_backend_remark = COALESCE(NULLIF(backend_remark, ''), period_backend_remark),
    callback_app_remark = COALESCE(NULLIF(app_remark, ''), callback_app_remark),
    callback_backend_remark = COALESCE(NULLIF(backend_remark, ''), callback_backend_remark)
WHERE TRUE;

COMMENT ON COLUMN callback_activity.period_filtered_tiers IS '时段彩金：过滤层级';
COMMENT ON COLUMN callback_activity.callback_filtered_tiers IS '回访彩金：过滤层级';

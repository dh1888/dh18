-- Migration: add device_secret to devices and populate for existing rows
-- Run in a maintenance window. Requires pgcrypto for gen_random_bytes.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

ALTER TABLE devices ADD COLUMN IF NOT EXISTS device_secret VARCHAR(128);

UPDATE devices
SET device_secret = encode(gen_random_bytes(32), 'hex')
WHERE device_secret IS NULL OR device_secret = '';

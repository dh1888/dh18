package domainmonitor

import (
	"context"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"net"
	"net/url"
	"sort"
	"strings"
)

type dnsChangeInfo struct {
	IPChanged     bool   `json:"ipChanged"`
	DNSChanged    bool   `json:"dnsChanged"`
	ChangeSummary string `json:"changeSummary,omitempty"`
}

func compareDNSRecords(prevJSON, currJSON string) dnsChangeInfo {
	var prev, curr map[string]interface{}
	_ = json.Unmarshal([]byte(prevJSON), &prev)
	_ = json.Unmarshal([]byte(currJSON), &curr)
	if prev == nil {
		prev = map[string]interface{}{}
	}
	if curr == nil {
		curr = map[string]interface{}{}
	}
	prevIPs := sortedStrings(extractIPList(prev))
	currIPs := sortedStrings(extractIPList(curr))
	ipChanged := len(prevIPs) > 0 && !stringSlicesEqual(prevIPs, currIPs)

	var changes []string
	if ipChanged {
		changes = append(changes, fmt.Sprintf("IP: %s → %s", strings.Join(prevIPs, ", "), strings.Join(currIPs, ", ")))
	}
	otherChanged := false
	for _, key := range []string{"CNAME", "NS", "MX", "TXT"} {
		if recordFieldChanged(prev[key], curr[key]) {
			otherChanged = true
			changes = append(changes, key+" 记录变更")
		}
	}
	return dnsChangeInfo{
		IPChanged:     ipChanged,
		DNSChanged:    otherChanged,
		ChangeSummary: strings.Join(changes, "；"),
	}
}

func extractIPList(rec map[string]interface{}) []string {
	raw, ok := rec["A_AAAA"]
	if !ok {
		return nil
	}
	switch v := raw.(type) {
	case []interface{}:
		out := make([]string, 0, len(v))
		for _, item := range v {
			if s, ok := item.(string); ok && s != "" {
				out = append(out, s)
			}
		}
		return out
	case []string:
		return v
	default:
		return nil
	}
}

func recordFieldChanged(a, b interface{}) bool {
	return normalizeRecordJSON(a) != normalizeRecordJSON(b) && (a != nil || b != nil)
}

func normalizeRecordJSON(v interface{}) string {
	if v == nil {
		return ""
	}
	b, err := json.Marshal(v)
	if err != nil {
		return fmt.Sprint(v)
	}
	return string(b)
}

func sortedStrings(in []string) []string {
	out := append([]string(nil), in...)
	sort.Strings(out)
	return out
}

func stringSlicesEqual(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func annotateDNSChanges(prev *DmCheckResult, res *DmCheckResult) dnsChangeInfo {
	info := compareDNSRecords(prev.DNSRecords, res.DNSRecords)
	if !info.IPChanged && !info.DNSChanged {
		return info
	}
	var rec map[string]interface{}
	_ = json.Unmarshal([]byte(res.DNSRecords), &rec)
	if rec == nil {
		rec = map[string]interface{}{}
	}
	rec["ipChanged"] = info.IPChanged
	rec["dnsChanged"] = info.DNSChanged
	if info.ChangeSummary != "" {
		rec["changeSummary"] = info.ChangeSummary
	}
	res.DNSRecords = mustJSON(rec)
	if res.Status == statusOK {
		res.Status = statusWarning
	}
	return info
}

func certMatchesDomain(domain string, cert *x509.Certificate) bool {
	if cert == nil {
		return false
	}
	domain = strings.TrimSpace(strings.ToLower(domain))
	if domain == "" {
		return false
	}
	if err := cert.VerifyHostname(domain); err == nil {
		return true
	}
	if strings.HasPrefix(domain, "www.") {
		return cert.VerifyHostname(strings.TrimPrefix(domain, "www.")) == nil
	}
	return cert.VerifyHostname("www."+domain) == nil
}

type redirectInfo struct {
	Anomaly bool   `json:"redirectAnomaly"`
	Message string `json:"redirectMessage,omitempty"`
	Hops    int    `json:"redirectHops,omitempty"`
}

func analyzeRedirect(domain, finalURL string, chain []string) redirectInfo {
	if len(chain) <= 1 {
		return redirectInfo{}
	}
	expected := normalizeHost(domain)
	finalHost := normalizeHost(hostFromURL(finalURL))
	if finalHost == "" {
		return redirectInfo{}
	}
	if hostsEquivalent(expected, finalHost) {
		return redirectInfo{Hops: len(chain) - 1}
	}
	return redirectInfo{
		Anomaly: true,
		Message: fmt.Sprintf("从 %s 跳转到 %s（%d 次跳转）", expected, finalHost, len(chain)-1),
		Hops:    len(chain) - 1,
	}
}

func hostFromURL(raw string) string {
	u, err := url.Parse(raw)
	if err != nil || u.Host == "" {
		return ""
	}
	host := u.Host
	if h, _, err := net.SplitHostPort(host); err == nil {
		return h
	}
	return host
}

func normalizeHost(host string) string {
	host = strings.TrimSpace(strings.ToLower(host))
	host = strings.TrimSuffix(host, ".")
	if strings.HasPrefix(host, "www.") {
		host = strings.TrimPrefix(host, "www.")
	}
	return host
}

func hostsEquivalent(a, b string) bool {
	a = normalizeHost(a)
	b = normalizeHost(b)
	return a != "" && a == b
}

var dnsblZones = []string{
	"zen.spamhaus.org",
	"bl.spamcop.net",
	"dnsbl.sorbs.net",
}

func checkIPsAgainstDNSBL(ctx context.Context, ips []string) []string {
	if len(ips) == 0 {
		return nil
	}
	listed := make([]string, 0)
	seen := map[string]struct{}{}
	for _, ipStr := range ips {
		ip := net.ParseIP(ipStr)
		if ip == nil || ip.To4() == nil {
			continue
		}
		for _, zone := range dnsblZones {
			query := reverseIPv4(ip) + "." + zone
			addrs, err := monitorDNSResolver.LookupHost(ctx, query)
			if err != nil || len(addrs) == 0 {
				continue
			}
			for _, a := range addrs {
				if strings.HasPrefix(a, "127.0.0.") {
					key := ipStr + "@" + zone
					if _, ok := seen[key]; ok {
						continue
					}
					seen[key] = struct{}{}
					listed = append(listed, fmt.Sprintf("%s (%s)", ipStr, zone))
					break
				}
			}
		}
	}
	sort.Strings(listed)
	return listed
}

func reverseIPv4(ip net.IP) string {
	ip = ip.To4()
	if ip == nil {
		return ""
	}
	return fmt.Sprintf("%d.%d.%d.%d", ip[3], ip[2], ip[1], ip[0])
}

func appendBlacklistToDNSRecords(res *DmCheckResult, listed []string) {
	if len(listed) == 0 {
		return
	}
	var rec map[string]interface{}
	_ = json.Unmarshal([]byte(res.DNSRecords), &rec)
	if rec == nil {
		rec = map[string]interface{}{}
	}
	rec["blacklistHits"] = listed
	res.DNSRecords = mustJSON(rec)
}

package domainmonitor

import "testing"

func TestDetectDomainImportColumns(t *testing.T) {
	rows := [][]string{
		{"domain", "group", "enabled", "checkInterval", "remark"},
		{"example.com", "默认", "true", "600", "test"},
	}
	cols := detectDomainImportColumns(rows)
	if cols.startRow != 1 || cols.domainCol != 0 || cols.groupCol != 1 || cols.enabledCol != 2 || cols.intervalCol != 3 || cols.remarkCol != 4 {
		t.Fatalf("unexpected columns: %+v", cols)
	}
}

func TestDetectDomainImportColumnsChineseHeader(t *testing.T) {
	rows := [][]string{
		{"域名", "分组"},
		{"a.example.com", "A组"},
	}
	cols := detectDomainImportColumns(rows)
	if cols.startRow != 1 || cols.domainCol != 0 || cols.groupCol != 1 {
		t.Fatalf("unexpected columns: %+v", cols)
	}
}

func TestNormalizeDomainDefaultsJSONB(t *testing.T) {
	d := &DmDomain{Domain: "example.com"}
	normalizeDomainDefaults(d)
	if d.CheckStrategy != "{}" || d.ProbeNodeIDs != "[]" || d.ExpectedIPs != "[]" {
		t.Fatalf("json defaults not applied: %+v", d)
	}
	if d.LastDNSStatus != "unknown" || d.ProbeNodeScope != "all" {
		t.Fatalf("status defaults not applied: %+v", d)
	}
}

func TestStripImportBOM(t *testing.T) {
	rows := [][]string{{"\ufeffdomain", "group"}}
	stripImportBOM(rows)
	if rows[0][0] != "domain" {
		t.Fatalf("bom not stripped: %q", rows[0][0])
	}
}

package domainmonitor

import (
	"strconv"
	"strings"
)

type domainImportColumns struct {
	startRow    int
	domainCol   int
	groupCol    int
	enabledCol  int
	intervalCol int
	remarkCol   int
}

func detectDomainImportColumns(rows [][]string) domainImportColumns {
	cols := domainImportColumns{
		startRow:    0,
		domainCol:   0,
		groupCol:    1,
		enabledCol:  -1,
		intervalCol: -1,
		remarkCol:   -1,
	}
	if len(rows) == 0 {
		return cols
	}
	header := rows[0]
	if len(header) == 0 {
		return cols
	}
	first := normalizeImportHeaderCell(header[0])
	if !isDomainImportHeader(first) {
		return cols
	}
	cols.startRow = 1
	for i, raw := range header {
		h := strings.ToLower(strings.TrimSpace(normalizeImportHeaderCell(raw)))
		switch h {
		case "domain", "域名":
			cols.domainCol = i
		case "group", "分组":
			cols.groupCol = i
		case "enabled", "启用":
			cols.enabledCol = i
		case "checkinterval", "check_interval", "检测间隔":
			cols.intervalCol = i
		case "remark", "备注":
			cols.remarkCol = i
		}
	}
	return cols
}

func isDomainImportHeader(cell string) bool {
	h := strings.ToLower(strings.TrimSpace(cell))
	return h == "domain" || h == "域名"
}

func normalizeImportHeaderCell(s string) string {
	return strings.TrimPrefix(strings.TrimSpace(s), "\ufeff")
}

func importCellValue(row []string, col int) string {
	if col < 0 || col >= len(row) {
		return ""
	}
	return strings.TrimSpace(row[col])
}

func parseImportEnabled(raw string, fallback bool) bool {
	if raw == "" {
		return fallback
	}
	v, err := strconv.ParseBool(raw)
	if err != nil {
		switch strings.ToLower(raw) {
		case "1", "yes", "y", "是", "启用", "true":
			return true
		case "0", "no", "n", "否", "禁用", "false":
			return false
		}
		return fallback
	}
	return v
}

func parseImportInterval(raw string, fallback int) int {
	if raw == "" {
		return fallback
	}
	v, err := strconv.Atoi(raw)
	if err != nil || v <= 0 {
		return fallback
	}
	return v
}

func stripImportBOM(rows [][]string) {
	if len(rows) == 0 || len(rows[0]) == 0 {
		return
	}
	rows[0][0] = normalizeImportHeaderCell(rows[0][0])
}

package domainmonitor

import "testing"

func TestFormatReportTimezoneLabel(t *testing.T) {
	cases := []struct {
		tz   string
		want string
	}{
		{"UTC", "协调世界时 (UTC+0)"},
		{"Asia/Shanghai", "中国标准时间 (UTC+8)"},
		{"UTC-3", "UTC-3"},
		{"America/Sao_Paulo", "巴西利亚时间 (UTC-3)"},
	}
	for _, tc := range cases {
		loc := parseReportTimezone(tc.tz)
		got := formatReportTimezoneLabel(tc.tz, loc)
		if got != tc.want {
			t.Fatalf("tz=%s got %q want %q", tc.tz, got, tc.want)
		}
	}
}

func TestFormatSecondsUTCOffset(t *testing.T) {
	if got := formatSecondsUTCOffset(8 * 3600); got != "UTC+8" {
		t.Fatalf("got %q", got)
	}
	if got := formatSecondsUTCOffset(-3 * 3600); got != "UTC-3" {
		t.Fatalf("got %q", got)
	}
	if got := formatSecondsUTCOffset(5*3600 + 30*60); got != "UTC+5:30" {
		t.Fatalf("got %q", got)
	}
}

package domainmonitor

import "testing"

func TestIsLegacyXLSSpreadsheet(t *testing.T) {
	data := []byte{0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1}
	if !isLegacyXLSSpreadsheet(data) {
		t.Fatal("expected legacy xls header")
	}
}

func TestIsModernExcelSpreadsheet(t *testing.T) {
	data := []byte{'P', 'K', 0x03, 0x04}
	if !isModernExcelSpreadsheet(data) {
		t.Fatal("expected xlsx zip header")
	}
}

func TestIsCSVSpreadsheetByContent(t *testing.T) {
	data := []byte("domain,group\nexample.com,默认\n")
	if !isCSVSpreadsheet("upload.txt", data) {
		t.Fatal("expected csv detection")
	}
}

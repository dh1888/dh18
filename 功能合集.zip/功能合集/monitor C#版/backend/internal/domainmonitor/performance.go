package domainmonitor

import (
	"context"
	"net"
	"net/http"
	"sync"
	"time"

	"enterprise-agent/backend/internal/proxytransport"

	"github.com/google/uuid"
)

const dnsLookupTimeout = 4 * time.Second

var monitorDNSResolver = &net.Resolver{
	PreferGo: true,
	Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
		d := net.Dialer{Timeout: dnsLookupTimeout}
		return d.DialContext(ctx, network, address)
	},
}

func waitGroupWithContext(wg *sync.WaitGroup, ctx context.Context) {
	done := make(chan struct{})
	go func() {
		wg.Wait()
		close(done)
	}()
	select {
	case <-done:
	case <-ctx.Done():
	}
}

type perfSnapshot struct {
	fastDnsCheck       bool
	domainCheckTimeout time.Duration
	scheduleBatchLimit int
	probeOnBatchCheck  bool
	httpProxyUrl       string
}

func newMonitorHTTPClient(timeout time.Duration, proxyURL string) *http.Client {
	return proxytransport.NewHTTPClient(timeout, proxyURL)
}

func (e *Engine) perf() perfSnapshot {
	e.perfMu.RLock()
	defer e.perfMu.RUnlock()
	return e.perfSnap
}

func (e *Engine) applyPerformanceSettings(ctx context.Context) {
	settings, err := e.repo.GetCheckSettings(ctx)
	if err != nil || settings == nil {
		return
	}
	if settings.WorkerPoolSize > 0 {
		e.cfg.WorkerPool = settings.WorkerPoolSize
	}
	if settings.HttpTimeoutSeconds > 0 {
		e.cfg.HTTPTimeout = time.Duration(settings.HttpTimeoutSeconds) * time.Second
	}
	e.client = proxytransport.NewHTTPClient(e.cfg.HTTPTimeout, settings.HttpProxyUrl)
	snap := perfSnapshot{
		fastDnsCheck:       settings.FastDnsCheck,
		scheduleBatchLimit: settings.ScheduleBatchLimit,
		probeOnBatchCheck:  settings.ProbeOnBatchCheck,
		httpProxyUrl:       settings.HttpProxyUrl,
	}
	if settings.DomainCheckTimeoutSeconds > 0 {
		snap.domainCheckTimeout = time.Duration(settings.DomainCheckTimeoutSeconds) * time.Second
	} else {
		snap.domainCheckTimeout = 25 * time.Second
	}
	if snap.scheduleBatchLimit <= 0 {
		snap.scheduleBatchLimit = 1000
	}
	e.perfMu.Lock()
	e.perfSnap = snap
	e.perfMu.Unlock()
}

func (e *Engine) ensureWorkers(n int) {
	e.workerMu.Lock()
	defer e.workerMu.Unlock()
	for e.workerCount < n {
		idx := e.workerCount
		e.workerCount++
		e.wg.Add(1)
		go e.workerLoop(e.workerCtx, idx)
	}
}

func (e *Engine) ApplyPerformanceSettings(ctx context.Context) {
	prevPool := e.cfg.WorkerPool
	e.applyPerformanceSettings(ctx)
	if e.cfg.WorkerPool > prevPool {
		e.ensureWorkers(e.cfg.WorkerPool)
	}
}

func (e *Engine) maybeEnqueueProbe(domainID uuid.UUID, batch bool) {
	snap := e.perf()
	if batch && !snap.probeOnBatchCheck {
		return
	}
	go e.enqueueProbeTasks(context.Background(), domainID)
}

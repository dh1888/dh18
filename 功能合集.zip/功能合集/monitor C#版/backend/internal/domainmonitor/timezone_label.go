package domainmonitor

import (
	"fmt"
	"strings"
	"time"
)

var reportTimezoneLabelsCN = map[string]string{
	"UTC":                      "协调世界时 (UTC+0)",
	"UTC+0":                    "协调世界时 (UTC+0)",
	"UTC-0":                    "协调世界时 (UTC+0)",
	"UTC+1":                    "UTC+1",
	"UTC+2":                    "UTC+2",
	"UTC+3":                    "UTC+3",
	"UTC+4":                    "UTC+4",
	"UTC+5":                    "UTC+5",
	"UTC+6":                    "UTC+6",
	"UTC+7":                    "UTC+7",
	"UTC+8":                    "UTC+8",
	"UTC+9":                    "UTC+9",
	"UTC+10":                   "UTC+10",
	"UTC+11":                   "UTC+11",
	"UTC+12":                   "UTC+12",
	"UTC-1":                    "UTC-1",
	"UTC-2":                    "UTC-2",
	"UTC-3":                    "UTC-3",
	"UTC-4":                    "UTC-4",
	"UTC-5":                    "UTC-5",
	"UTC-6":                    "UTC-6",
	"UTC-7":                    "UTC-7",
	"UTC-8":                    "UTC-8",
	"UTC-9":                    "UTC-9",
	"UTC-10":                   "UTC-10",
	"UTC-11":                   "UTC-11",
	"UTC-12":                   "UTC-12",
	"Asia/Shanghai":            "中国标准时间 (UTC+8)",
	"Asia/Hong_Kong":           "香港时间 (UTC+8)",
	"Asia/Taipei":              "台北时间 (UTC+8)",
	"Asia/Singapore":           "新加坡时间 (UTC+8)",
	"Asia/Kuala_Lumpur":        "马来西亚时间 (UTC+8)",
	"Asia/Manila":              "菲律宾时间 (UTC+8)",
	"Asia/Tokyo":               "日本标准时间 (UTC+9)",
	"Asia/Seoul":               "韩国标准时间 (UTC+9)",
	"Asia/Bangkok":             "中南半岛时间 (UTC+7)",
	"Asia/Jakarta":             "印尼西部时间 (UTC+7)",
	"Asia/Ho_Chi_Minh":         "越南时间 (UTC+7)",
	"Asia/Dubai":               "海湾标准时间 (UTC+4)",
	"Asia/Kolkata":             "印度标准时间 (UTC+5:30)",
	"Asia/Karachi":             "巴基斯坦时间 (UTC+5)",
	"Europe/London":            "英国时间 (UTC+0/+1)",
	"Europe/Berlin":            "中欧时间 (UTC+1/+2)",
	"Europe/Paris":             "中欧时间 (UTC+1/+2)",
	"Europe/Moscow":            "莫斯科时间 (UTC+3)",
	"America/New_York":         "美国东部时间 (UTC-5/-4)",
	"America/Chicago":          "美国中部时间 (UTC-6/-5)",
	"America/Denver":           "美国山地时间 (UTC-7/-6)",
	"America/Los_Angeles":      "美国太平洋时间 (UTC-8/-7)",
	"America/Sao_Paulo":        "巴西利亚时间 (UTC-3)",
	"America/Argentina/Buenos_Aires": "阿根廷时间 (UTC-3)",
	"America/Mexico_City":      "墨西哥中部时间 (UTC-6/-5)",
	"Australia/Sydney":         "澳大利亚东部时间 (UTC+10/+11)",
	"Pacific/Auckland":         "新西兰时间 (UTC+12/+13)",
}

func formatReportTimezoneLabel(tz string, loc *time.Location) string {
	tz = strings.TrimSpace(tz)
	if tz == "" {
		tz = "UTC"
	}
	if label, ok := lookupTimezoneLabelCN(tz); ok {
		return label
	}
	offset := formatLocationUTCOffset(loc)
	if strings.EqualFold(tz, "UTC") {
		return "协调世界时 " + offset
	}
	upper := strings.ToUpper(tz)
	if strings.HasPrefix(upper, "UTC") {
		return "协调世界时 " + offset
	}
	return fmt.Sprintf("%s (%s)", tz, offset)
}

func lookupTimezoneLabelCN(tz string) (string, bool) {
	if label, ok := reportTimezoneLabelsCN[tz]; ok {
		return label, true
	}
	upper := strings.ToUpper(strings.TrimSpace(tz))
	if label, ok := reportTimezoneLabelsCN[upper]; ok {
		return label, true
	}
	return "", false
}

func formatLocationUTCOffset(loc *time.Location) string {
	if loc == nil {
		return "UTC+0"
	}
	_, offset := time.Now().In(loc).Zone()
	return formatSecondsUTCOffset(offset)
}

func formatSecondsUTCOffset(offsetSec int) string {
	sign := "+"
	if offsetSec < 0 {
		sign = "-"
		offsetSec = -offsetSec
	}
	hours := offsetSec / 3600
	mins := (offsetSec % 3600) / 60
	if mins == 0 {
		return fmt.Sprintf("UTC%s%d", sign, hours)
	}
	return fmt.Sprintf("UTC%s%d:%02d", sign, hours, mins)
}

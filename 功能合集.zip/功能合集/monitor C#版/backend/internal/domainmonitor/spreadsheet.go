package domainmonitor

import (
	"bytes"
	"encoding/csv"
	"fmt"
	"io"
	"strings"
	"unicode/utf8"

	"github.com/extrame/xls"
	"github.com/xuri/excelize/v2"
)

func readImportSpreadsheetRows(r io.Reader, filename string) ([][]string, error) {
	data, err := io.ReadAll(r)
	if err != nil {
		return nil, fmt.Errorf("read file: %w", err)
	}
	if len(data) == 0 {
		return nil, fmt.Errorf("empty file")
	}
	if isCSVSpreadsheet(filename, data) {
		return parseImportCSVRows(data)
	}
	if isLegacyXLSSpreadsheet(data) {
		return readLegacyXLSRows(data)
	}
	return readModernExcelRows(data)
}

func isCSVSpreadsheet(filename string, data []byte) bool {
	if strings.HasSuffix(strings.ToLower(strings.TrimSpace(filename)), ".csv") {
		return true
	}
	if isModernExcelSpreadsheet(data) || isLegacyXLSSpreadsheet(data) {
		return false
	}
	sample := data
	if len(sample) > 512 {
		sample = sample[:512]
	}
	if !utf8.Valid(sample) {
		return false
	}
	text := string(sample)
	return strings.Count(text, ",")+strings.Count(text, ";")+strings.Count(text, "\t") > 0
}

func isModernExcelSpreadsheet(data []byte) bool {
	return len(data) >= 2 && data[0] == 'P' && data[1] == 'K'
}

func isLegacyXLSSpreadsheet(data []byte) bool {
	return len(data) >= 8 && data[0] == 0xD0 && data[1] == 0xCF && data[2] == 0x11 && data[3] == 0xE0
}

func parseImportCSVRows(data []byte) ([][]string, error) {
	data = bytes.TrimPrefix(data, []byte{0xEF, 0xBB, 0xBF})
	delimiter := detectImportCSVDelimiter(data)
	reader := csv.NewReader(bytes.NewReader(data))
	reader.Comma = delimiter
	reader.LazyQuotes = true
	reader.TrimLeadingSpace = true
	reader.FieldsPerRecord = -1
	rows, err := reader.ReadAll()
	if err != nil {
		return nil, fmt.Errorf("parse csv: %w", err)
	}
	if len(rows) == 0 {
		return nil, fmt.Errorf("empty csv file")
	}
	stripImportBOM(rows)
	return rows, nil
}

func detectImportCSVDelimiter(data []byte) rune {
	firstLine := data
	if idx := bytes.IndexByte(data, '\n'); idx >= 0 {
		firstLine = data[:idx]
	}
	firstLine = bytes.TrimSpace(firstLine)
	if len(firstLine) == 0 {
		return ','
	}
	best := ','
	bestCount := -1
	for _, d := range []rune{',', ';', '\t'} {
		count := strings.Count(string(firstLine), string(d))
		if count > bestCount {
			bestCount = count
			best = d
		}
	}
	if bestCount <= 0 {
		return ','
	}
	return best
}

func readModernExcelRows(data []byte) ([][]string, error) {
	f, err := excelize.OpenReader(bytes.NewReader(data))
	if err != nil {
		if isLegacyXLSSpreadsheet(data) {
			return readLegacyXLSRows(data)
		}
		if isCSVSpreadsheet("", data) {
			return parseImportCSVRows(data)
		}
		return nil, fmt.Errorf("无法识别 Excel 格式，请使用 .xlsx 或 .csv 文件")
	}
	defer f.Close()
	sheet := f.GetSheetName(0)
	if sheet == "" {
		return nil, fmt.Errorf("excel has no sheets")
	}
	rows, err := f.GetRows(sheet)
	if err != nil {
		return nil, fmt.Errorf("read excel rows: %w", err)
	}
	if len(rows) == 0 {
		return nil, fmt.Errorf("empty excel file")
	}
	stripImportBOM(rows)
	return rows, nil
}

func readLegacyXLSRows(data []byte) ([][]string, error) {
	for _, charset := range []string{"utf-8", "gb18030", "gbk"} {
		rows, err := readLegacyXLSRowsWithCharset(data, charset)
		if err == nil && len(rows) > 0 {
			stripImportBOM(rows)
			return rows, nil
		}
	}
	return nil, fmt.Errorf("无法读取旧版 .xls 文件，请另存为 .xlsx 或 .csv 后重试")
}

func readLegacyXLSRowsWithCharset(data []byte, charset string) ([][]string, error) {
	reader := bytes.NewReader(data)
	wb, err := xls.OpenReader(reader, charset)
	if err != nil {
		return nil, err
	}
	if wb.NumSheets() == 0 {
		return nil, fmt.Errorf("xls has no sheets")
	}
	sheet := wb.GetSheet(0)
	if sheet == nil {
		return nil, fmt.Errorf("xls sheet missing")
	}
	maxRow := int(sheet.MaxRow)
	if maxRow < 0 {
		return nil, fmt.Errorf("empty xls file")
	}
	rows := make([][]string, 0, maxRow+1)
	for rowIdx := 0; rowIdx <= maxRow; rowIdx++ {
		row := sheet.Row(rowIdx)
		if row == nil {
			rows = append(rows, nil)
			continue
		}
		lastCol := row.LastCol()
		if lastCol < 0 {
			rows = append(rows, []string{})
			continue
		}
		cols := make([]string, 0, lastCol+1)
		for colIdx := row.FirstCol(); colIdx <= lastCol; colIdx++ {
			cols = append(cols, strings.TrimSpace(row.Col(colIdx)))
		}
		rows = append(rows, cols)
	}
	if len(rows) == 0 {
		return nil, fmt.Errorf("empty xls file")
	}
	return rows, nil
}

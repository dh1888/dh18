package domainmonitor

import "gorm.io/gorm"

// bootstrapDomainMonitorSchema 使用 SQL 迁移脚本建表/补列，避免 GORM AutoMigrate
// 在 default:'...' 等标签上生成错误占位符（pq: got 2 parameters but the statement requires 1）。
func bootstrapDomainMonitorSchema(db *gorm.DB) error {
	// 不依赖 uuid-ossp；主键 UUID 由应用层 BeforeCreate 生成
	for _, stmt := range domainMonitorBootstrapSQL {
		if err := db.Exec(stmt).Error; err != nil {
			return err
		}
	}
	return nil
}

var domainMonitorBootstrapSQL = []string{
	`CREATE TABLE IF NOT EXISTS dm_groups (
		id UUID PRIMARY KEY,
		name VARCHAR(64) NOT NULL UNIQUE,
		description TEXT,
		sort_order INT NOT NULL DEFAULT 0,
		created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
	)`,
	`CREATE TABLE IF NOT EXISTS dm_domains (
		id UUID PRIMARY KEY,
		group_id UUID REFERENCES dm_groups(id) ON DELETE SET NULL,
		domain VARCHAR(255) NOT NULL UNIQUE,
		enabled BOOLEAN NOT NULL DEFAULT TRUE,
		check_interval INT NOT NULL DEFAULT 300,
		remark TEXT,
		enable_dns BOOLEAN NOT NULL DEFAULT TRUE,
		enable_http BOOLEAN NOT NULL DEFAULT TRUE,
		enable_ssl BOOLEAN NOT NULL DEFAULT TRUE,
		last_check_at TIMESTAMPTZ,
		last_dns_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
		last_http_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
		last_ssl_status VARCHAR(16) NOT NULL DEFAULT 'unknown',
		created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
	)`,
	`CREATE INDEX IF NOT EXISTS idx_dm_domains_group ON dm_domains(group_id)`,
	`CREATE INDEX IF NOT EXISTS idx_dm_domains_enabled ON dm_domains(enabled)`,
	`CREATE TABLE IF NOT EXISTS dm_check_results (
		id UUID PRIMARY KEY,
		domain_id UUID NOT NULL REFERENCES dm_domains(id) ON DELETE CASCADE,
		node_id VARCHAR(64) NOT NULL DEFAULT 'local',
		node_name VARCHAR(128) NOT NULL DEFAULT 'Local Center',
		country VARCHAR(8) NOT NULL DEFAULT 'CN',
		city VARCHAR(64) DEFAULT '',
		check_type VARCHAR(32) NOT NULL,
		status VARCHAR(16) NOT NULL,
		duration_ms INT DEFAULT 0,
		http_status INT DEFAULT 0,
		final_url TEXT,
		redirect_chain JSONB,
		dns_records JSONB,
		ssl_info JSONB,
		raw_detail JSONB,
		checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
	)`,
	`CREATE INDEX IF NOT EXISTS idx_dm_check_results_domain_time ON dm_check_results(domain_id, checked_at DESC)`,
	`CREATE INDEX IF NOT EXISTS idx_dm_check_results_checked_at ON dm_check_results(checked_at)`,
	`CREATE TABLE IF NOT EXISTS dm_alerts (
		id UUID PRIMARY KEY,
		domain_id UUID REFERENCES dm_domains(id) ON DELETE SET NULL,
		alert_type VARCHAR(64) NOT NULL,
		severity VARCHAR(16) NOT NULL,
		title VARCHAR(256) NOT NULL,
		message TEXT NOT NULL,
		status VARCHAR(16) NOT NULL DEFAULT 'open',
		node_id VARCHAR(64),
		first_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		last_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		resolved_at TIMESTAMPTZ
	)`,
	`CREATE INDEX IF NOT EXISTS idx_dm_alerts_status ON dm_alerts(status)`,
	`CREATE INDEX IF NOT EXISTS idx_dm_alerts_domain ON dm_alerts(domain_id)`,
	`CREATE TABLE IF NOT EXISTS dm_telegram_bots (
		id UUID PRIMARY KEY,
		bot_name VARCHAR(128) NOT NULL,
		bot_token_enc TEXT NOT NULL,
		bot_username VARCHAR(64),
		bot_id BIGINT,
		enabled BOOLEAN NOT NULL DEFAULT TRUE,
		remark TEXT,
		verified_at TIMESTAMPTZ,
		created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
	)`,
	`CREATE TABLE IF NOT EXISTS dm_telegram_groups (
		id UUID PRIMARY KEY,
		bot_id UUID NOT NULL REFERENCES dm_telegram_bots(id) ON DELETE CASCADE,
		group_name VARCHAR(256) NOT NULL,
		chat_id VARCHAR(64) NOT NULL,
		chat_type VARCHAR(32),
		enabled BOOLEAN NOT NULL DEFAULT TRUE,
		created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		UNIQUE(bot_id, chat_id)
	)`,
	`CREATE TABLE IF NOT EXISTS dm_alert_routes (
		id UUID PRIMARY KEY,
		name VARCHAR(128) NOT NULL,
		alert_types JSONB NOT NULL DEFAULT '[]',
		severities JSONB NOT NULL DEFAULT '[]',
		group_id UUID NOT NULL REFERENCES dm_telegram_groups(id) ON DELETE CASCADE,
		send_mode VARCHAR(16) NOT NULL DEFAULT 'realtime',
		enabled BOOLEAN NOT NULL DEFAULT TRUE,
		created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
	)`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_whois BOOLEAN NOT NULL DEFAULT FALSE`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_content BOOLEAN NOT NULL DEFAULT FALSE`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS content_url TEXT DEFAULT ''`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS content_hash_baseline VARCHAR(64) DEFAULT ''`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS content_keywords JSONB NOT NULL DEFAULT '[]'`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_whois_status VARCHAR(16) NOT NULL DEFAULT 'unknown'`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_content_status VARCHAR(16) NOT NULL DEFAULT 'unknown'`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS whois_expire_at TIMESTAMPTZ`,
	`CREATE INDEX IF NOT EXISTS idx_dm_domains_whois_expire ON dm_domains(whois_expire_at)`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_screenshot BOOLEAN NOT NULL DEFAULT FALSE`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS screenshot_url TEXT DEFAULT ''`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_screenshot_status VARCHAR(16) NOT NULL DEFAULT 'unknown'`,
	`ALTER TABLE dm_check_results ADD COLUMN IF NOT EXISTS screenshot_path TEXT DEFAULT ''`,
	`CREATE TABLE IF NOT EXISTS dm_nodes (
		id UUID PRIMARY KEY,
		name VARCHAR(128) NOT NULL,
		api_key_hash VARCHAR(64) NOT NULL UNIQUE,
		country VARCHAR(8) NOT NULL DEFAULT 'CN',
		city VARCHAR(64) DEFAULT '',
		enabled BOOLEAN NOT NULL DEFAULT TRUE,
		last_seen_at TIMESTAMPTZ,
		created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
	)`,
	`CREATE TABLE IF NOT EXISTS dm_probe_tasks (
		id UUID PRIMARY KEY,
		domain_id UUID NOT NULL REFERENCES dm_domains(id) ON DELETE CASCADE,
		node_id UUID NOT NULL REFERENCES dm_nodes(id) ON DELETE CASCADE,
		status VARCHAR(16) NOT NULL DEFAULT 'pending',
		created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
		completed_at TIMESTAMPTZ
	)`,
	`CREATE INDEX IF NOT EXISTS idx_dm_probe_tasks_pending ON dm_probe_tasks(node_id, status)`,
	`CREATE UNIQUE INDEX IF NOT EXISTS idx_dm_probe_tasks_unique ON dm_probe_tasks(domain_id, node_id) WHERE status = 'pending'`,
	`CREATE TABLE IF NOT EXISTS dm_reports (
		id UUID PRIMARY KEY,
		report_type VARCHAR(16) NOT NULL,
		period_start TIMESTAMPTZ NOT NULL,
		period_end TIMESTAMPTZ NOT NULL,
		file_path TEXT NOT NULL,
		summary JSONB,
		created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
	)`,
	`CREATE INDEX IF NOT EXISTS idx_dm_reports_type_time ON dm_reports(report_type, created_at DESC)`,
	`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_http_duration_ms INT NOT NULL DEFAULT 0`,
	`CREATE TABLE IF NOT EXISTS dm_settings (
		key VARCHAR(64) PRIMARY KEY,
		value TEXT NOT NULL,
		updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
	)`,
	`CREATE TABLE IF NOT EXISTS dm_cdn_history (
		id UUID PRIMARY KEY,
		domain_id UUID NOT NULL REFERENCES dm_domains(id) ON DELETE CASCADE,
		previous_provider VARCHAR(64),
		current_provider VARCHAR(64) NOT NULL,
		detected_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
	)`,
	`CREATE INDEX IF NOT EXISTS idx_dm_cdn_history_domain ON dm_cdn_history(domain_id, detected_at DESC)`,
}

package proxytransport

import (
	"crypto/tls"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"golang.org/x/net/proxy"
)

var nonStandardSOCKS = regexp.MustCompile(`(?i)^(socks5?|sock5)://([^:/@]+):(\d+):([^:@/]+):([^:@/]+)$`)

// NormalizeProxyURL 规范代理 URL，支持标准格式与 sock5://host:port:user:pass 写法。
func NormalizeProxyURL(raw string) (string, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", nil
	}
	lower := strings.ToLower(raw)
	if strings.HasPrefix(lower, "sock5://") {
		raw = "socks5://" + raw[len("sock5://"):]
	}
	if m := nonStandardSOCKS.FindStringSubmatch(raw); len(m) == 6 {
		user := url.QueryEscape(m[4])
		pass := url.QueryEscape(m[5])
		return fmt.Sprintf("socks5://%s:%s@%s:%s", user, pass, m[2], m[3]), nil
	}
	u, err := url.Parse(raw)
	if err != nil {
		return "", fmt.Errorf("invalid proxy URL: %w", err)
	}
	scheme := strings.ToLower(strings.TrimSpace(u.Scheme))
	switch scheme {
	case "sock5":
		u.Scheme = "socks5"
	case "http", "https", "socks5", "socks5h", "socks4":
	default:
		return "", fmt.Errorf("unsupported proxy scheme: %s", u.Scheme)
	}
	if u.Host == "" {
		return "", fmt.Errorf("proxy URL missing host")
	}
	return u.String(), nil
}

func IsSOCKS(scheme string) bool {
	switch strings.ToLower(scheme) {
	case "socks5", "socks5h", "socks4", "sock5":
		return true
	default:
		return false
	}
}

func ProxyScheme(raw string) string {
	normalized, err := NormalizeProxyURL(raw)
	if err != nil || normalized == "" {
		return ""
	}
	u, err := url.Parse(normalized)
	if err != nil {
		return ""
	}
	return strings.ToLower(u.Scheme)
}

// ConfigureTransport 为 Transport 配置 HTTP 或 SOCKS 代理。
func ConfigureTransport(tr *http.Transport, proxyURL string, dialTimeout time.Duration) error {
	if tr == nil {
		return fmt.Errorf("transport is nil")
	}
	proxyURL, err := NormalizeProxyURL(proxyURL)
	if err != nil {
		return err
	}
	if proxyURL == "" {
		return nil
	}
	u, err := url.Parse(proxyURL)
	if err != nil {
		return err
	}
	baseDialer := &net.Dialer{
		Timeout:   dialTimeout,
		KeepAlive: 30 * time.Second,
	}
	scheme := strings.ToLower(u.Scheme)
	switch scheme {
	case "http", "https":
		tr.Proxy = http.ProxyURL(u)
		if tr.DialContext == nil {
			tr.DialContext = baseDialer.DialContext
		}
		return nil
	case "socks5", "socks5h", "socks4":
		dialer, err := proxy.FromURL(u, baseDialer)
		if err != nil {
			return err
		}
		contextDialer, ok := dialer.(proxy.ContextDialer)
		if !ok {
			return fmt.Errorf("SOCKS proxy dialer does not support context")
		}
		tr.Proxy = nil
		tr.DialContext = contextDialer.DialContext
		return nil
	default:
		return fmt.Errorf("unsupported proxy scheme: %s", u.Scheme)
	}
}

// NewHTTPClient 创建带 HTTP/SOCKS 代理的客户端（与域名监控检测逻辑一致）。
func NewHTTPClient(timeout time.Duration, proxyURL string) *http.Client {
	if timeout <= 0 {
		timeout = 8 * time.Second
	}
	dialTimeout := timeout
	if dialTimeout > 5*time.Second {
		dialTimeout = 5 * time.Second
	}
	useProxy := strings.TrimSpace(proxyURL) != ""
	tr := &http.Transport{
		MaxIdleConns:          1000,
		MaxIdleConnsPerHost:   100,
		MaxConnsPerHost:       200,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   10 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
		ForceAttemptHTTP2:     !useProxy,
	}
	if useProxy {
		tr.ForceAttemptHTTP2 = false
		tr.TLSNextProto = make(map[string]func(string, *tls.Conn) http.RoundTripper)
		_ = ConfigureTransport(tr, proxyURL, dialTimeout)
	} else {
		tr.DialContext = (&net.Dialer{
			Timeout:   dialTimeout,
			KeepAlive: 30 * time.Second,
		}).DialContext
	}
	return &http.Client{
		Timeout:   timeout,
		Transport: tr,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			if len(via) >= 10 {
				return fmt.Errorf("too many redirects")
			}
			return nil
		},
	}
}

// MaskProxyURL 隐藏代理 URL 中的密码。
func MaskProxyURL(raw string) string {
	normalized, err := NormalizeProxyURL(raw)
	if err != nil || normalized == "" {
		return raw
	}
	u, err := url.Parse(normalized)
	if err != nil || u.Host == "" {
		return raw
	}
	if u.User != nil {
		u.User = url.UserPassword("***", "***")
	}
	return u.String()
}

// ModeLabel 返回代理类型中文标签。
func ModeLabel(raw string) string {
	scheme := ProxyScheme(raw)
	switch scheme {
	case "socks5", "socks5h", "socks4":
		return "SOCKS5 代理"
	case "http", "https":
		return "HTTP 代理"
	default:
		return "本机直连"
	}
}

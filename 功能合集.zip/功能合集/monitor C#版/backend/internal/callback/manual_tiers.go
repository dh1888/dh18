package callback

import "strings"

const (
	ManualPeriodTierColumnIndex      = 21 // V
	ManualCallbackTierColumnIndex    = 24 // Y
	ManualCallbackPayColumnIndex     = 8  // I 累计充值
	ManualCallbackWithdrawColumnIndex = 9 // J 累计提款
)

func DefaultMemberColumnMappingForDispatch(dispatchType string) ManualMemberColumnMapping {
	m := ManualMemberColumnMapping{
		HeaderRow:     0,
		ExcludedTiers: append([]string(nil), DefaultFilteredTierValues()...),
	}
	if normalizeManualDispatchType(dispatchType) == ManualDispatchCallbackBonus {
		m.UserID = 5 // F
		m.HistoricalPay = ManualCallbackPayColumnIndex
		m.HistoryWithdrawals = ManualCallbackWithdrawColumnIndex
		m.PhoneNumber = 23 // X
		m.TierLevel = ManualCallbackTierColumnIndex
	} else {
		m.UserID = 0             // A
		m.HistoricalPay = 5      // F
		m.HistoryWithdrawals = 7 // H
		m.PhoneNumber = 17       // R
		m.TierLevel = ManualPeriodTierColumnIndex
	}
	return m
}

func resolveExcludedTiers(mappingExcluded, activityExcluded []string) []string {
	if len(normalizeTierList(mappingExcluded)) > 0 {
		return normalizeTierList(mappingExcluded)
	}
	return normalizeTierList(activityExcluded)
}

func normalizeTierList(tiers []string) []string {
	seen := make(map[string]struct{})
	out := make([]string, 0, len(tiers))
	for _, t := range tiers {
		t = normalizeTierValue(t)
		if t == "" {
			continue
		}
		if _, ok := seen[t]; ok {
			continue
		}
		seen[t] = struct{}{}
		out = append(out, t)
	}
	return out
}

func normalizeTierValue(s string) string {
	return strings.TrimSpace(s)
}

func buildTierExcludedSet(tiers []string) map[string]struct{} {
	if len(tiers) == 0 {
		return nil
	}
	set := make(map[string]struct{}, len(tiers))
	for _, t := range tiers {
		t = normalizeTierValue(t)
		if t != "" {
			set[t] = struct{}{}
		}
	}
	return set
}

func tierInExcludedSet(tier string, set map[string]struct{}) bool {
	if len(set) == 0 {
		return false
	}
	tier = normalizeTierValue(tier)
	if tier == "" {
		return false
	}
	_, ok := set[tier]
	return ok
}

func tierExcluded(tier string, excluded []string) bool {
	tier = normalizeTierValue(tier)
	if tier == "" {
		return false
	}
	for _, e := range excluded {
		if tier == normalizeTierValue(e) {
			return true
		}
	}
	return false
}

func applyTierExclusion(out *ManualProcessResult, parsed ManualRow, excluded []string) (ManualRow, bool) {
	if len(excluded) == 0 {
		return parsed, false
	}
	if !tierExcluded(parsed.TierLevel, excluded) {
		return parsed, false
	}
	label := strings.TrimSpace(parsed.TierLevel)
	if label == "" {
		label = "(空)"
	}
	parsed.ExcludeReason = "层级已过滤: " + label
	out.ExcludedRows = append(out.ExcludedRows, parsed)
	out.Summary.ExcludedCount++
	return parsed, true
}

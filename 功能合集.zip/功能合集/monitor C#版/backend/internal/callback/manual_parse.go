package callback

import (
	"bytes"
	"encoding/csv"
	"fmt"
	"io"

	"github.com/xuri/excelize/v2"
)

type memberColumnIndices struct {
	userID    int
	pay       int
	withdraw  int
	phone     int
	tier      int
	hasPhone  bool
	hasTier   bool
}

func minColsForMemberIndices(idx memberColumnIndices) int {
	max := idx.userID
	if idx.pay > max {
		max = idx.pay
	}
	if idx.withdraw > max {
		max = idx.withdraw
	}
	if idx.hasPhone && idx.phone > max {
		max = idx.phone
	}
	if idx.hasTier && idx.tier > max {
		max = idx.tier
	}
	return max + 1
}

func padManualRow(row []string, minCols int) []string {
	if len(row) >= minCols {
		return row
	}
	out := make([]string, minCols)
	copy(out, row)
	return out
}

func memberIndicesFromMapping(m ManualMemberColumnMapping) memberColumnIndices {
	idx := memberColumnIndices{
		userID:   m.UserID,
		pay:      m.HistoricalPay,
		withdraw: m.HistoryWithdrawals,
		hasTier:  m.TierLevel >= 0,
		tier:     m.TierLevel,
	}
	if m.PhoneNumber >= 0 {
		idx.hasPhone = true
		idx.phone = m.PhoneNumber
	}
	return idx
}

func parseManualMemberSheetWithMapping(r io.Reader, filename string, mapping ManualMemberColumnMapping) ([]ManualRow, error) {
	data, err := io.ReadAll(r)
	if err != nil {
		return nil, fmt.Errorf("read file: %w", err)
	}
	return parseManualMemberSheetFromData(data, filename, mapping)
}

func parseManualMemberSheetFromData(data []byte, filename string, mapping ManualMemberColumnMapping) ([]ManualRow, error) {
	if len(data) == 0 {
		return nil, fmt.Errorf("empty file")
	}
	idx := memberIndicesFromMapping(mapping)
	startRow := mapping.HeaderRow + 1

	if isCSVFile(filename, data) {
		return parseManualMemberCSV(data, startRow, idx)
	}
	return parseManualMemberExcel(data, startRow, idx)
}

func parseManualMemberCSV(data []byte, startRow int, idx memberColumnIndices) ([]ManualRow, error) {
	data = bytes.TrimPrefix(data, []byte{0xEF, 0xBB, 0xBF})
	delimiter, err := detectCSVDelimiter(data)
	if err != nil {
		return nil, err
	}
	reader := csv.NewReader(bytes.NewReader(data))
	reader.Comma = delimiter
	reader.LazyQuotes = true
	reader.TrimLeadingSpace = true
	reader.FieldsPerRecord = -1

	est := bytes.Count(data, []byte{'\n'})
	if est < 1 {
		est = 1
	}
	out := make([]ManualRow, 0, est)
	minCols := minColsForMemberIndices(idx)

	rowNum := 0
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, fmt.Errorf("parse csv: %w", err)
		}
		rowNum++
		if rowNum <= startRow {
			continue
		}
		row = padManualRow(row, minCols)
		if manualRowEmpty(row) {
			continue
		}
		parsed, err := parseManualDataRowFast(rowNum, row, idx.userID, idx.pay, idx.withdraw, idx.phone, idx.hasPhone, idx.tier, idx.hasTier)
		if err != nil {
			return nil, fmt.Errorf("row %d: %w", rowNum, err)
		}
		out = append(out, parsed)
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("no data rows after header row %d", startRow)
	}
	return out, nil
}

func parseManualMemberExcel(data []byte, startRow int, idx memberColumnIndices) ([]ManualRow, error) {
	f, err := excelize.OpenReader(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("open excel: %w", err)
	}
	defer f.Close()
	sheet := f.GetSheetName(0)
	if sheet == "" {
		return nil, fmt.Errorf("excel has no sheets")
	}
	iter, err := f.Rows(sheet)
	if err != nil {
		return nil, fmt.Errorf("read rows: %w", err)
	}
	defer iter.Close()

	out := make([]ManualRow, 0, 4096)
	minCols := minColsForMemberIndices(idx)
	rowNum := 0
	for iter.Next() {
		rowNum++
		if rowNum <= startRow {
			continue
		}
		cols, err := iter.Columns()
		if err != nil {
			return nil, fmt.Errorf("read row %d: %w", rowNum, err)
		}
		cols = padManualRow(cols, minCols)
		if manualRowEmpty(cols) {
			continue
		}
		parsed, err := parseManualDataRowFast(rowNum, cols, idx.userID, idx.pay, idx.withdraw, idx.phone, idx.hasPhone, idx.tier, idx.hasTier)
		if err != nil {
			return nil, fmt.Errorf("row %d: %w", rowNum, err)
		}
		out = append(out, parsed)
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("no data rows after header row %d", startRow)
	}
	return out, nil
}

func parseUnclaimedWhitelistWithMapping(r io.Reader, filename string, mapping ManualUnclaimedColumnMapping) (*unclaimedWhitelist, int, error) {
	data, err := io.ReadAll(r)
	if err != nil {
		return nil, 0, fmt.Errorf("read file: %w", err)
	}
	return parseUnclaimedWhitelistFromData(data, filename, mapping)
}

func parseUnclaimedWhitelistFromData(data []byte, filename string, mapping ManualUnclaimedColumnMapping) (*unclaimedWhitelist, int, error) {
	if len(data) == 0 {
		return nil, 0, fmt.Errorf("empty file")
	}
	startRow := mapping.HeaderRow + 1
	if mapping.UserID < 0 {
		return nil, 0, fmt.Errorf("unclaimed member id column is required")
	}
	if isCSVFile(filename, data) {
		return parseUnclaimedWhitelistCSV(data, startRow, mapping.UserID)
	}
	return parseUnclaimedWhitelistExcel(data, startRow, mapping.UserID)
}

func parseUnclaimedWhitelistCSV(data []byte, startRow, userIDCol int) (*unclaimedWhitelist, int, error) {
	data = bytes.TrimPrefix(data, []byte{0xEF, 0xBB, 0xBF})
	delimiter, err := detectCSVDelimiter(data)
	if err != nil {
		return nil, 0, err
	}
	reader := csv.NewReader(bytes.NewReader(data))
	reader.Comma = delimiter
	reader.LazyQuotes = true
	reader.TrimLeadingSpace = true
	reader.FieldsPerRecord = -1

	wl := &unclaimedWhitelist{byUserID: make(map[int64]struct{}, 4096)}
	count := 0
	rowNum := 0
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, 0, fmt.Errorf("parse csv: %w", err)
		}
		rowNum++
		if rowNum <= startRow {
			continue
		}
		if manualRowEmpty(row) {
			continue
		}
		count++
		if id, err := parseInt64Cell(cellAt(row, userIDCol)); err == nil && id > 0 {
			wl.byUserID[id] = struct{}{}
		}
	}
	return finalizeUnclaimedWhitelist(wl, count, startRow)
}

func parseUnclaimedWhitelistExcel(data []byte, startRow, userIDCol int) (*unclaimedWhitelist, int, error) {
	f, err := excelize.OpenReader(bytes.NewReader(data))
	if err != nil {
		return nil, 0, fmt.Errorf("open excel: %w", err)
	}
	defer f.Close()
	sheet := f.GetSheetName(0)
	if sheet == "" {
		return nil, 0, fmt.Errorf("excel has no sheets")
	}
	iter, err := f.Rows(sheet)
	if err != nil {
		return nil, 0, fmt.Errorf("read rows: %w", err)
	}
	defer iter.Close()

	wl := &unclaimedWhitelist{byUserID: make(map[int64]struct{}, 4096)}
	count := 0
	rowNum := 0
	for iter.Next() {
		rowNum++
		if rowNum <= startRow {
			continue
		}
		cols, err := iter.Columns()
		if err != nil {
			return nil, 0, fmt.Errorf("read row %d: %w", rowNum, err)
		}
		if manualRowEmpty(cols) {
			continue
		}
		count++
		if id, err := parseInt64Cell(cellAt(cols, userIDCol)); err == nil && id > 0 {
			wl.byUserID[id] = struct{}{}
		}
	}
	return finalizeUnclaimedWhitelist(wl, count, startRow)
}

func finalizeUnclaimedWhitelist(wl *unclaimedWhitelist, count, startRow int) (*unclaimedWhitelist, int, error) {
	if count == 0 {
		return nil, 0, fmt.Errorf("no data rows after header row %d", startRow)
	}
	if len(wl.byUserID) == 0 {
		return nil, 0, fmt.Errorf("no valid member id in mapped column")
	}
	return wl, count, nil
}

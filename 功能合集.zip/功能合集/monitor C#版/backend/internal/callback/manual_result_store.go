package callback

import (
	"sync"
	"time"
)

const (
	manualResultPreviewLimit = 500
	manualResultCacheTTL     = 45 * time.Minute
)

type manualResultStore struct {
	mu    sync.RWMutex
	items map[string]manualResultEntry
}

type manualResultEntry struct {
	result    ManualProcessResult
	expiresAt time.Time
}

func newManualResultStore() *manualResultStore {
	return &manualResultStore{items: make(map[string]manualResultEntry)}
}

func (st *manualResultStore) put(id string, result ManualProcessResult) {
	st.mu.Lock()
	defer st.mu.Unlock()
	st.items[id] = manualResultEntry{
		result:    result,
		expiresAt: time.Now().Add(manualResultCacheTTL),
	}
	st.purgeExpiredLocked()
}

func (st *manualResultStore) get(id string) (ManualProcessResult, bool) {
	st.mu.RLock()
	entry, ok := st.items[id]
	st.mu.RUnlock()
	if !ok {
		return ManualProcessResult{}, false
	}
	if time.Now().After(entry.expiresAt) {
		st.mu.Lock()
		delete(st.items, id)
		st.mu.Unlock()
		return ManualProcessResult{}, false
	}
	return entry.result, true
}

func (st *manualResultStore) purgeExpiredLocked() {
	now := time.Now()
	for id, entry := range st.items {
		if now.After(entry.expiresAt) {
			delete(st.items, id)
		}
	}
}

func truncateManualResultForAPI(full ManualProcessResult, resultID string, limit int) ManualProcessResult {
	if limit <= 0 {
		limit = manualResultPreviewLimit
	}
	truncated :=
		len(full.BonusRows) > limit ||
			len(full.OtherRows) > limit ||
			len(full.ExcludedRows) > limit ||
			len(full.UnclaimedRewardRows) > limit

	out := full
	out.ResultID = resultID
	out.Truncated = truncated
	out.BonusRows = truncateManualRows(full.BonusRows, limit)
	out.OtherRows = truncateManualRows(full.OtherRows, limit)
	out.ExcludedRows = truncateManualRows(full.ExcludedRows, limit)
	out.UnclaimedRewardRows = truncateManualRows(full.UnclaimedRewardRows, limit)
	return out
}

func truncateManualRows(rows []ManualRow, limit int) []ManualRow {
	if len(rows) <= limit {
		return rows
	}
	dup := make([]ManualRow, limit)
	copy(dup, rows[:limit])
	return dup
}

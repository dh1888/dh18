package callback

import (
	"bytes"
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
)

type Service struct {
	repo        *Repository
	client      *Client
	crypto      *Crypto
	manualStore *manualResultStore
}

func NewService(repo *Repository, client *Client, crypto *Crypto) *Service {
	return &Service{
		repo:        repo,
		client:      client,
		crypto:      crypto,
		manualStore: newManualResultStore(),
	}
}

type PlatformView struct {
	CallbackPlatform
	TokenMasked string `json:"tokenMasked"`
}

type GenerateTaskInput struct {
	PlatformID   uuid.UUID
	DateFrom     time.Time
	DateTo       time.Time
	EndpointCode string
	CreatedBy    *uuid.UUID
}

type PagedResult struct {
	Items    interface{} `json:"items"`
	Total    int64       `json:"total"`
	Page     int         `json:"page"`
	PageSize int         `json:"pageSize"`
}

func (s *Service) ListPlatforms(ctx context.Context, f PlatformListFilter) (*PagedResult, error) {
	items, total, err := s.repo.ListPlatforms(ctx, f)
	if err != nil {
		return nil, err
	}
	views := make([]PlatformView, len(items))
	for i := range items {
		views[i] = s.toPlatformView(&items[i])
	}
	return &PagedResult{Items: views, Total: total, Page: f.Page, PageSize: f.PageSize}, nil
}

func (s *Service) GetPlatform(ctx context.Context, id uuid.UUID) (*PlatformView, error) {
	p, err := s.repo.GetPlatform(ctx, id)
	if err != nil {
		return nil, err
	}
	if p == nil {
		return nil, nil
	}
	v := s.toPlatformView(p)
	return &v, nil
}

type CreatePlatformInput struct {
	Name     string
	BaseURL  string
	TenantID string
	Token    string
	Enabled  bool
	Remark   string
	CreatedBy *uuid.UUID
}

func (s *Service) CreatePlatform(ctx context.Context, in CreatePlatformInput) (*PlatformView, error) {
	token := strings.TrimSpace(in.Token)
	if token == "" {
		return nil, fmt.Errorf("token is required")
	}
	enc, err := s.crypto.EncryptToken(token)
	if err != nil {
		return nil, err
	}
	p := &CallbackPlatform{
		Name:      strings.TrimSpace(in.Name),
		BaseURL:   strings.TrimRight(strings.TrimSpace(in.BaseURL), "/"),
		TenantID:  strings.TrimSpace(in.TenantID),
		TokenEnc:  enc,
		Enabled:   in.Enabled,
		Remark:    in.Remark,
		CreatedBy: in.CreatedBy,
	}
	if err := s.repo.CreatePlatform(ctx, p); err != nil {
		return nil, err
	}
	v := s.toPlatformView(p)
	return &v, nil
}

type UpdatePlatformInput struct {
	ID       uuid.UUID
	Name     string
	BaseURL  string
	TenantID string
	Token    string
	Enabled  bool
	Remark   string
}

func (s *Service) UpdatePlatform(ctx context.Context, in UpdatePlatformInput) (*PlatformView, error) {
	p, err := s.repo.GetPlatform(ctx, in.ID)
	if err != nil {
		return nil, err
	}
	if p == nil {
		return nil, fmt.Errorf("platform not found")
	}
	p.Name = strings.TrimSpace(in.Name)
	p.BaseURL = strings.TrimRight(strings.TrimSpace(in.BaseURL), "/")
	p.TenantID = strings.TrimSpace(in.TenantID)
	p.Enabled = in.Enabled
	p.Remark = in.Remark
	if token := strings.TrimSpace(in.Token); token != "" {
		enc, err := s.crypto.EncryptToken(token)
		if err != nil {
			return nil, err
		}
		p.TokenEnc = enc
	}
	if err := s.repo.UpdatePlatform(ctx, p); err != nil {
		return nil, err
	}
	v := s.toPlatformView(p)
	return &v, nil
}

func (s *Service) DeletePlatform(ctx context.Context, id uuid.UUID) error {
	return s.repo.DeletePlatform(ctx, id)
}

func (s *Service) ListEndpoints(ctx context.Context, f EndpointListFilter) ([]CallbackAPIEndpoint, error) {
	return s.repo.ListEndpoints(ctx, f)
}

func (s *Service) GetEndpoint(ctx context.Context, id uuid.UUID) (*CallbackAPIEndpoint, error) {
	return s.repo.GetEndpoint(ctx, id)
}

func (s *Service) CreateEndpoint(ctx context.Context, e *CallbackAPIEndpoint) error {
	return s.repo.CreateEndpoint(ctx, e)
}

func (s *Service) UpdateEndpoint(ctx context.Context, e *CallbackAPIEndpoint) error {
	return s.repo.UpdateEndpoint(ctx, e)
}

func (s *Service) DeleteEndpoint(ctx context.Context, id uuid.UUID) error {
	return s.repo.DeleteEndpoint(ctx, id)
}

func (s *Service) GetActivity(ctx context.Context) (*CallbackActivity, error) {
	a, err := s.repo.GetActivity(ctx)
	if err != nil {
		return nil, err
	}
	if a != nil {
		normalizeActivityDefaults(a)
		normalizeActivityManualRules(a)
		return a, nil
	}
	def := DefaultActivityConfig()
	if err := s.repo.CreateActivity(ctx, def); err != nil {
		return nil, fmt.Errorf("init default activity: %w", err)
	}
	return def, nil
}

func (s *Service) UpdateActivity(ctx context.Context, a *CallbackActivity) error {
	normalizeActivityDefaults(a)
	normalizeActivityManualRules(a)
	if err := ValidateActivityConfig(a); err != nil {
		return err
	}
	return s.repo.UpdateActivity(ctx, a)
}

func (s *Service) resolveTaskDates(ctx context.Context, in GenerateTaskInput) (*CallbackActivity, time.Time, time.Time, error) {
	activity, err := s.GetActivity(ctx)
	if err != nil {
		return nil, time.Time{}, time.Time{}, err
	}
	dateFrom, dateTo, err := ResolveDateRange(in.DateFrom, in.DateTo, activity.Days)
	if err != nil {
		return nil, time.Time{}, time.Time{}, err
	}
	return activity, dateFrom, dateTo, nil
}

func (s *Service) ListTasks(ctx context.Context, f TaskListFilter) (*PagedResult, error) {
	items, total, err := s.repo.ListTasks(ctx, f)
	if err != nil {
		return nil, err
	}
	return &PagedResult{Items: items, Total: total, Page: f.Page, PageSize: f.PageSize}, nil
}

func (s *Service) GetTask(ctx context.Context, id uuid.UUID) (*CallbackTask, error) {
	return s.repo.GetTask(ctx, id)
}

func (s *Service) ListTaskResults(ctx context.Context, f ResultListFilter) (*PagedResult, error) {
	items, total, err := s.repo.ListResultsByTask(ctx, f)
	if err != nil {
		return nil, err
	}
	return &PagedResult{Items: items, Total: total, Page: f.Page, PageSize: f.PageSize}, nil
}

func (s *Service) ListRequestLogs(ctx context.Context, f RequestLogListFilter) (*PagedResult, error) {
	items, total, err := s.repo.ListRequestLogs(ctx, f)
	if err != nil {
		return nil, err
	}
	return &PagedResult{Items: items, Total: total, Page: f.Page, PageSize: f.PageSize}, nil
}

func (s *Service) ExportTaskResults(ctx context.Context, taskID uuid.UUID) (*bytes.Buffer, *CallbackTask, error) {
	task, err := s.repo.GetTask(ctx, taskID)
	if err != nil {
		return nil, nil, err
	}
	if task == nil {
		return nil, nil, fmt.Errorf("task not found")
	}
	results, err := s.repo.ListAllResultsByTask(ctx, taskID)
	if err != nil {
		return nil, nil, err
	}
	buf, err := BuildResultsExcel(task, results)
	return buf, task, err
}

func (s *Service) GenerateTask(ctx context.Context, in GenerateTaskInput) (*CallbackTask, error) {
	activity, dateFrom, dateTo, err := s.resolveTaskDates(ctx, in)
	if err != nil {
		return nil, err
	}
	in.DateFrom = dateFrom
	in.DateTo = dateTo

	platform, err := s.repo.GetEnabledPlatform(ctx, in.PlatformID)
	if err != nil {
		return nil, err
	}
	if platform == nil {
		return nil, fmt.Errorf("platform not found or disabled")
	}

	endpointCode := strings.TrimSpace(in.EndpointCode)
	if endpointCode == "" {
		endpointCode = EndpointCodeVIPList
	}

	endpoint, err := s.GetEndpointByCode(ctx, platform.ID, endpointCode)
	if err != nil {
		return nil, err
	}
	if endpoint == nil {
		return nil, fmt.Errorf("endpoint %q not configured", endpointCode)
	}
	if err := endpoint.Row.ValidateMemberMapping(); err != nil {
		return nil, err
	}

	snapshot := ActivitySnapshotFromConfig(activity)
	snapshotJSON, err := MarshalActivitySnapshot(snapshot)
	if err != nil {
		return nil, err
	}

	now := time.Now()
	task := &CallbackTask{
		PlatformID:       platform.ID,
		DateFrom:         in.DateFrom,
		DateTo:           in.DateTo,
		ActivitySnapshot: snapshotJSON,
		Status:           TaskStatusRunning,
		CreatedBy:        in.CreatedBy,
		StartedAt:        &now,
	}
	if err := s.repo.CreateTask(ctx, task); err != nil {
		return nil, err
	}

	tokenPlain, err := s.crypto.DecryptToken(platform.TokenEnc)
	if err != nil {
		s.markTaskFailed(ctx, task.ID, err, now)
		return nil, fmt.Errorf("decrypt platform token: %w", err)
	}

	members, fetchErr := s.client.FetchMembers(ctx, FetchRequest{
		Platform:   platform,
		Endpoint:   endpoint,
		TaskID:     &task.ID,
		DateFrom:   in.DateFrom,
		DateTo:     in.DateTo,
		TokenPlain: tokenPlain,
	})
	if fetchErr != nil {
		s.markTaskFailed(ctx, task.ID, fetchErr, now)
		return nil, fetchErr
	}

	results, totalBonus := s.buildResults(task.ID, members, snapshot)
	health := CalcHealthLevel(totalBonus, snapshot.HealthMin, snapshot.HealthMax)
	finished := time.Now()

	stats := TaskStatsUpdate{
		Status:      TaskStatusCompleted,
		MemberCount: len(results),
		TotalBonus:  totalBonus,
		HealthLevel: &health,
		StartedAt:   &now,
		FinishedAt:  &finished,
	}
	if err := s.repo.SaveTaskWithResults(ctx, task.ID, stats, results); err != nil {
		s.markTaskFailed(ctx, task.ID, err, now)
		return nil, err
	}

	task, err = s.repo.GetTask(ctx, task.ID)
	return task, err
}

func (s *Service) buildResults(taskID uuid.UUID, members []MappedMember, snap ActivitySnapshot) ([]CallbackResult, float64) {
	results := make([]CallbackResult, 0)
	var totalBonus float64
	for _, m := range members {
		profit := CalcProfit(m.HistoricalPay, m.HistoryWithdrawals)
		if !ShouldIncludeMember(profit, m.HistoricalReward, snap.ExcludeRewarded) {
			continue
		}
		bonus := CalcBonus(profit, snap.Rate, snap.Divisor, snap.MinBonus, snap.MaxBonus)
		res, err := MappedMemberToResult(taskID, m)
		if err != nil {
			continue
		}
		res.Profit = roundMoney(profit)
		res.Bonus = bonus
		results = append(results, *res)
		totalBonus += bonus
	}
	return results, roundMoney(totalBonus)
}

func (s *Service) markTaskFailed(ctx context.Context, taskID uuid.UUID, err error, started time.Time) {
	finished := time.Now()
	msg := err.Error()
	_ = s.repo.UpdateTaskStats(ctx, taskID, TaskStatsUpdate{
		Status:       TaskStatusFailed,
		ErrorMessage: msg,
		StartedAt:    &started,
		FinishedAt:   &finished,
	})
}

func (s *Service) toPlatformView(p *CallbackPlatform) PlatformView {
	return PlatformView{
		CallbackPlatform: *p,
		TokenMasked:      s.crypto.MaskEncryptedToken(p.TokenEnc),
	}
}

package callback

import (
	"fmt"
	"time"
)

func DefaultActivityConfig() *CallbackActivity {
	return &CallbackActivity{
		Days:            7,
		Rate:            0.02,
		Divisor:         10,
		MinBonus:        1,
		MaxBonus:        50,
		ExcludeRewarded: true,
		HealthMin:                  20000,
		HealthMax:                  30000,
		PeriodFilteredTiers:        DefaultFilteredTierValues(),
		PeriodWageringMultiplier:   1,
		PeriodAppRemark:            "",
		PeriodBackendRemark:        "",
		CallbackMinBonus:           1,
		CallbackRate:               0.02,
		CallbackDivisor:            2,
		CallbackFilteredTiers:      DefaultFilteredTierValues(),
		CallbackWageringMultiplier: 1,
		CallbackAppRemark:          "",
		CallbackBackendRemark:      "",
		PeriodManualRules:          DefaultManualRulesForDispatch(ManualDispatchPeriodBonus),
		CallbackManualRules:        DefaultManualRulesForDispatch(ManualDispatchCallbackBonus),
	}
}

func DefaultFilteredTierValues() []string {
	return []string{"新-无优惠", "洗水套利", "黑名单"}
}

func ValidateActivityConfig(a *CallbackActivity) error {
	if a == nil {
		return fmt.Errorf("activity config is required")
	}
	if a.Days < 1 || a.Days > 365 {
		return fmt.Errorf("days must be between 1 and 365")
	}
	if a.Rate < 0 || a.Rate > 1 {
		return fmt.Errorf("rate must be between 0 and 1")
	}
	if a.Divisor < 1 {
		return fmt.Errorf("divisor must be >= 1")
	}
	if a.MinBonus < 0 || a.MaxBonus < 0 {
		return fmt.Errorf("minBonus and maxBonus must be >= 0")
	}
	if a.MinBonus > a.MaxBonus {
		return fmt.Errorf("minBonus must be <= maxBonus")
	}
	if a.HealthMin < 0 || a.HealthMax < 0 {
		return fmt.Errorf("healthMin and healthMax must be >= 0")
	}
	if a.HealthMin > a.HealthMax {
		return fmt.Errorf("healthMin must be <= healthMax")
	}
	if a.PeriodWageringMultiplier < 0 {
		return fmt.Errorf("periodWageringMultiplier must be >= 0")
	}
	if a.CallbackWageringMultiplier < 0 {
		return fmt.Errorf("callbackWageringMultiplier must be >= 0")
	}
	if a.CallbackMinBonus < 0 {
		return fmt.Errorf("callbackMinBonus must be >= 0")
	}
	if a.CallbackRate < 0 || a.CallbackRate > 1 {
		return fmt.Errorf("callbackRate must be between 0 and 1")
	}
	if a.CallbackDivisor < 1 {
		return fmt.Errorf("callbackDivisor must be >= 1")
	}
	return nil
}

// ResolveDateRange 若未传日期则按 activity.days 计算「含今天共 N 天」的范围。
func ResolveDateRange(dateFrom, dateTo time.Time, days int) (time.Time, time.Time, error) {
	if days <= 0 {
		days = 7
	}
	hasFrom := !dateFrom.IsZero()
	hasTo := !dateTo.IsZero()
	if hasFrom && hasTo {
		if dateTo.Before(dateFrom) {
			return time.Time{}, time.Time{}, fmt.Errorf("dateTo must be >= dateFrom")
		}
		return dateFrom, dateTo, nil
	}
	if hasFrom != hasTo {
		return time.Time{}, time.Time{}, fmt.Errorf("dateFrom and dateTo must both be provided or both omitted")
	}
	now := time.Now()
	end := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())
	start := end.AddDate(0, 0, -(days - 1))
	return start, end, nil
}

package callback

import (
	"context"

	"github.com/google/uuid"
)

func DefaultVIPListEndpoint() *CallbackAPIEndpoint {
	return &CallbackAPIEndpoint{
		Code:       EndpointCodeVIPList,
		Name:       "VIP会员列表",
		Path:       "/api/backend/trpc/vip.list",
		HTTPMethod: "GET",
		RequestParamsTemplate: `{
			"tenantId": "{{tenantId}}",
			"page": 1,
			"pageSize": 99
		}`,
		ResponseMapping: `{
			"listPath": "data.list",
			"totalPath": "data.total",
			"fields": {
				"userId": "userId",
				"phoneNumber": "phoneNumber",
				"historicalPay": "historicalPay",
				"historyWithdrawals": "historyWithdrawals",
				"historicalReward": "historicalReward",
				"vipLevel": "vipLevel"
			}
		}`,
		PaginationConfig: `{
			"enabled": true,
			"pageField": "page",
			"pageSizeField": "pageSize",
			"pageSize": 99,
			"startPage": 1,
			"stopWhenEmpty": true
		}`,
		Enabled:   true,
		SortOrder: 10,
		Remark:    "默认会员列表接口；tenantId 由平台配置自动替换",
	}
}

func defaultGlobalEndpoints() []*CallbackAPIEndpoint {
	return []*CallbackAPIEndpoint{
		DefaultVIPListEndpoint(),
	}
}

func (s *Service) EnsureDefaultEndpoints(ctx context.Context) error {
	for _, ep := range defaultGlobalEndpoints() {
		if err := s.repo.EnsureGlobalEndpoint(ctx, ep); err != nil {
			return err
		}
	}
	return nil
}

func (s *Service) GetEndpointByCode(ctx context.Context, platformID uuid.UUID, code string) (*ParsedEndpoint, error) {
	ep, err := s.repo.GetEndpointByCode(ctx, platformID, code)
	if err != nil {
		return nil, err
	}
	if ep != nil {
		return ep, nil
	}
	for _, def := range defaultGlobalEndpoints() {
		if def.Code == code {
			if err := s.repo.EnsureGlobalEndpoint(ctx, def); err != nil {
				return nil, err
			}
			return s.repo.GetEndpointByCode(ctx, platformID, code)
		}
	}
	return nil, nil
}

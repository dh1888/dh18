package callback

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// 运营回访模块数据模型（仅 callback_* 表，GORM 仅在本模块使用）

// ---------- 业务常量 ----------

const (
	TaskStatusPending   = "pending"
	TaskStatusRunning   = "running"
	TaskStatusCompleted = "completed"
	TaskStatusFailed    = "failed"

	HealthLevelLow    = "low"
	HealthLevelNormal = "normal"
	HealthLevelHigh   = "high"
)

// 第三方接口业务编码（存于 callback_api_endpoint.code，路径与字段映射由 DB 配置）
const (
	EndpointCodeVIPList         = "vip.list"
	EndpointCodeRechargeList    = "recharge.list"
	EndpointCodeWithdrawalList  = "withdrawal.list"
	EndpointCodeRewardList      = "reward.list"
	EndpointCodeMemberList      = "member.list"
)

// 内部标准字段标识（response_mapping.fields 的 key，对应 callback_result 列语义）。
// value 为第三方 JSON 路径，由 callback_api_endpoint.response_mapping 配置，不在代码中写死。
const (
	InternalFieldUserID             = "userId"
	InternalFieldPhoneNumber        = "phoneNumber"
	InternalFieldVIPLevel           = "vipLevel"
	InternalFieldHistoricalPay      = "historicalPay"
	InternalFieldHistoryWithdrawals = "historyWithdrawals"
	InternalFieldHistoricalReward   = "historicalReward"
)

// RequiredMemberFields 名单生成所需的最小内部字段集合（用于校验 endpoint 配置完整性）
var RequiredMemberFields = []string{
	InternalFieldUserID,
	InternalFieldHistoricalPay,
	InternalFieldHistoryWithdrawals,
	InternalFieldHistoricalReward,
}

// ---------- JSON 配置结构（存于 JSONB 列，解析后供 client/service 使用） ----------

// ResponseMapping 第三方响应 → 内部字段映射配置
type ResponseMapping struct {
	ListPath  string            `json:"listPath"`
	TotalPath string            `json:"totalPath,omitempty"`
	Fields    map[string]string `json:"fields"` // key=内部字段标识, value=第三方 JSON 路径（如 data.list.0.pay）
}

// PaginationConfig 分页拉取配置
type PaginationConfig struct {
	Enabled       bool   `json:"enabled"`
	PageField     string `json:"pageField"`
	PageSizeField string `json:"pageSizeField"`
	PageSize      int    `json:"pageSize"`
	StartPage     int    `json:"startPage"`
	StopWhenEmpty bool   `json:"stopWhenEmpty"`
}

// ActivitySnapshot 任务执行时的活动配置快照（写入 callback_task.activity_snapshot）
type ActivitySnapshot struct {
	Days            int     `json:"days"`
	Rate            float64 `json:"rate"`
	Divisor         int     `json:"divisor"`
	MinBonus        float64 `json:"minBonus"`
	MaxBonus        float64 `json:"maxBonus"`
	ExcludeRewarded bool    `json:"excludeRewarded"`
	HealthMin       float64 `json:"healthMin"`
	HealthMax       float64 `json:"healthMax"`
}

// MappedMember 经 response_mapping 解析后的内部标准会员记录（非 DB 表）
type MappedMember struct {
	UserID             int64
	PhoneNumber        string
	VIPLevel           int
	HistoricalPay      float64
	HistoryWithdrawals float64
	HistoricalReward   float64
	Raw                map[string]interface{}
}

// ---------- 表模型 ----------

type CallbackPlatform struct {
	ID        uuid.UUID      `gorm:"type:uuid;primaryKey" json:"id"`
	Name      string         `gorm:"size:128;not null" json:"name"`
	BaseURL   string         `gorm:"size:512;not null" json:"baseUrl"`
	TenantID  string         `gorm:"size:64;not null" json:"tenantId"`
	TokenEnc  string         `gorm:"type:text;not null" json:"-"`
	Enabled   bool           `gorm:"not null;default:true" json:"enabled"`
	Remark    string         `gorm:"type:text" json:"remark,omitempty"`
	CreatedBy *uuid.UUID     `gorm:"type:uuid" json:"createdBy,omitempty"`
	CreatedAt time.Time      `json:"createdAt"`
	UpdatedAt time.Time      `json:"updatedAt"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (CallbackPlatform) TableName() string { return "callback_platform" }

type CallbackAPIEndpoint struct {
	ID                    uuid.UUID      `gorm:"type:uuid;primaryKey" json:"id"`
	PlatformID            *uuid.UUID     `gorm:"type:uuid;index" json:"platformId,omitempty"`
	Code                  string         `gorm:"size:64;not null" json:"code"`
	Name                  string         `gorm:"size:128;not null" json:"name"`
	Path                  string         `gorm:"size:512;not null" json:"path"`
	HTTPMethod            string         `gorm:"size:16;not null;default:GET" json:"httpMethod"`
	RequestParamsTemplate string         `gorm:"type:jsonb;not null;default:'{}'" json:"requestParamsTemplate"`
	ResponseMapping       string         `gorm:"type:jsonb;not null;default:'{}'" json:"responseMapping"`
	PaginationConfig      string         `gorm:"type:jsonb;not null;default:'{}'" json:"paginationConfig"`
	Enabled               bool           `gorm:"not null;default:true" json:"enabled"`
	SortOrder             int            `gorm:"not null;default:0" json:"sortOrder"`
	Remark                string         `gorm:"type:text" json:"remark,omitempty"`
	CreatedAt             time.Time      `json:"createdAt"`
	UpdatedAt             time.Time      `json:"updatedAt"`
	DeletedAt             gorm.DeletedAt `gorm:"index" json:"-"`
}

func (CallbackAPIEndpoint) TableName() string { return "callback_api_endpoint" }

type CallbackActivity struct {
	ID              uuid.UUID  `gorm:"type:uuid;primaryKey" json:"id"`
	Days            int        `gorm:"not null;default:7" json:"days"`
	Rate            float64    `gorm:"type:numeric(10,6);not null;default:0.02" json:"rate"`
	Divisor         int        `gorm:"not null;default:10" json:"divisor"`
	MinBonus        float64    `gorm:"type:numeric(18,2);not null;default:1" json:"minBonus"`
	MaxBonus        float64    `gorm:"type:numeric(18,2);not null;default:50" json:"maxBonus"`
	ExcludeRewarded bool       `gorm:"not null;default:true" json:"excludeRewarded"`
	HealthMin                  float64    `gorm:"type:numeric(18,2);not null;default:20000" json:"healthMin"`
	HealthMax                  float64    `gorm:"type:numeric(18,2);not null;default:30000" json:"healthMax"`
	PeriodFilteredTiers        []string   `gorm:"type:jsonb;serializer:json;not null;default:'[\"新-无优惠\",\"洗水套利\",\"黑名单\"]'" json:"periodFilteredTiers"`
	PeriodWageringMultiplier   float64    `gorm:"type:numeric(10,2);not null;default:1" json:"periodWageringMultiplier"`
	PeriodAppRemark            string     `gorm:"type:text;not null;default:''" json:"periodAppRemark"`
	PeriodBackendRemark        string     `gorm:"type:text;not null;default:''" json:"periodBackendRemark"`
	CallbackMinBonus           float64    `gorm:"type:numeric(18,2);not null;default:1" json:"callbackMinBonus"`
	CallbackRate               float64    `gorm:"type:numeric(10,6);not null;default:0.02" json:"callbackRate"`
	CallbackDivisor            int        `gorm:"not null;default:2" json:"callbackDivisor"`
	CallbackFilteredTiers      []string   `gorm:"type:jsonb;serializer:json;not null;default:'[\"新-无优惠\",\"洗水套利\",\"黑名单\"]'" json:"callbackFilteredTiers"`
	CallbackWageringMultiplier float64    `gorm:"type:numeric(10,2);not null;default:1" json:"callbackWageringMultiplier"`
	CallbackAppRemark          string     `gorm:"type:text;not null;default:''" json:"callbackAppRemark"`
	CallbackBackendRemark      string     `gorm:"type:text;not null;default:''" json:"callbackBackendRemark"`
	PeriodManualRules          ManualDispatchRuleSet `gorm:"type:jsonb;serializer:json;not null;default:'{\"enabledFilters\":[\"tier_exclude\"]}'" json:"periodManualRules"`
	CallbackManualRules        ManualDispatchRuleSet `gorm:"type:jsonb;serializer:json;not null;default:'{\"enabledFilters\":[\"tier_exclude\",\"unclaimed_exclude\"]}'" json:"callbackManualRules"`
	UpdatedBy                  *uuid.UUID `gorm:"type:uuid" json:"updatedBy,omitempty"`
	CreatedAt       time.Time  `json:"createdAt"`
	UpdatedAt       time.Time  `json:"updatedAt"`
}

func (CallbackActivity) TableName() string { return "callback_activity" }

type CallbackTask struct {
	ID               uuid.UUID  `gorm:"type:uuid;primaryKey" json:"id"`
	PlatformID       uuid.UUID  `gorm:"type:uuid;not null;index" json:"platformId"`
	DateFrom         time.Time  `gorm:"type:date;not null" json:"dateFrom"`
	DateTo           time.Time  `gorm:"type:date;not null" json:"dateTo"`
	ActivitySnapshot string     `gorm:"type:jsonb;not null;default:'{}'" json:"activitySnapshot"`
	Status           string     `gorm:"size:32;not null;default:pending" json:"status"`
	MemberCount      int        `gorm:"not null;default:0" json:"memberCount"`
	TotalBonus       float64    `gorm:"type:numeric(18,2);not null;default:0" json:"totalBonus"`
	HealthLevel      *string    `gorm:"size:16" json:"healthLevel,omitempty"`
	ErrorMessage     string     `gorm:"type:text" json:"errorMessage,omitempty"`
	CreatedBy        *uuid.UUID `gorm:"type:uuid" json:"createdBy,omitempty"`
	StartedAt        *time.Time `json:"startedAt,omitempty"`
	FinishedAt       *time.Time `json:"finishedAt,omitempty"`
	CreatedAt        time.Time  `json:"createdAt"`
	UpdatedAt        time.Time  `json:"updatedAt"`
}

func (CallbackTask) TableName() string { return "callback_task" }

type CallbackResult struct {
	ID                  uuid.UUID `gorm:"type:uuid;primaryKey" json:"id"`
	TaskID              uuid.UUID `gorm:"type:uuid;not null;index" json:"taskId"`
	UserID              int64     `gorm:"not null" json:"userId"`
	PhoneNumber         string    `gorm:"size:32" json:"phoneNumber,omitempty"`
	VIPLevel            int       `gorm:"not null;default:0" json:"vipLevel"`
	HistoricalPay       float64   `gorm:"type:numeric(18,2);not null;default:0" json:"historicalPay"`
	HistoryWithdrawals  float64   `gorm:"type:numeric(18,2);not null;default:0" json:"historyWithdrawals"`
	HistoricalReward    float64   `gorm:"type:numeric(18,2);not null;default:0" json:"historicalReward"`
	Profit              float64   `gorm:"type:numeric(18,2);not null;default:0" json:"profit"`
	Bonus               float64   `gorm:"type:numeric(18,2);not null;default:0" json:"bonus"`
	RawData             string    `gorm:"type:jsonb" json:"rawData,omitempty"`
	CreatedAt           time.Time `json:"createdAt"`
}

func (CallbackResult) TableName() string { return "callback_result" }

type CallbackRequestLog struct {
	ID             uuid.UUID  `gorm:"type:uuid;primaryKey" json:"id"`
	PlatformID     *uuid.UUID `gorm:"type:uuid;index" json:"platformId,omitempty"`
	TaskID         *uuid.UUID `gorm:"type:uuid;index" json:"taskId,omitempty"`
	EndpointCode   string     `gorm:"size:64" json:"endpointCode,omitempty"`
	RequestURL     string     `gorm:"type:text;not null" json:"requestUrl"`
	RequestParams  string     `gorm:"type:jsonb;not null;default:'{}'" json:"requestParams"`
	ResponseStatus *int       `json:"responseStatus,omitempty"`
	ResponseBody   string     `gorm:"type:text" json:"responseBody,omitempty"`
	DurationMs     int        `gorm:"not null;default:0" json:"durationMs"`
	ErrorMessage   string     `gorm:"type:text" json:"errorMessage,omitempty"`
	CreatedAt      time.Time  `json:"createdAt"`
}

func (CallbackRequestLog) TableName() string { return "callback_request_log" }

// ---------- UUID 钩子 ----------

func assignUUIDIfEmpty(id *uuid.UUID) {
	if id != nil && *id == uuid.Nil {
		*id = uuid.New()
	}
}

func (m *CallbackPlatform) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *CallbackAPIEndpoint) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *CallbackActivity) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *CallbackTask) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *CallbackResult) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *CallbackRequestLog) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

// ---------- JSONB 辅助 ----------

func jsonbStringOrDefault(s, fallback string) string {
	s = trimJSON(s)
	if s == "" {
		return fallback
	}
	return s
}

func trimJSON(s string) string {
	for len(s) > 0 && (s[0] == ' ' || s[0] == '\n' || s[0] == '\t') {
		s = s[1:]
	}
	return s
}

func (e *CallbackAPIEndpoint) ParsedResponseMapping() (ResponseMapping, error) {
	raw := jsonbStringOrDefault(e.ResponseMapping, "{}")
	var m ResponseMapping
	if err := json.Unmarshal([]byte(raw), &m); err != nil {
		return ResponseMapping{}, fmt.Errorf("parse response_mapping: %w", err)
	}
	return m, nil
}

func (e *CallbackAPIEndpoint) ParsedPaginationConfig() (PaginationConfig, error) {
	raw := jsonbStringOrDefault(e.PaginationConfig, "{}")
	var c PaginationConfig
	if err := json.Unmarshal([]byte(raw), &c); err != nil {
		return PaginationConfig{}, fmt.Errorf("parse pagination_config: %w", err)
	}
	return c, nil
}

func (e *CallbackAPIEndpoint) ParsedRequestParamsTemplate() (map[string]interface{}, error) {
	raw := jsonbStringOrDefault(e.RequestParamsTemplate, "{}")
	var m map[string]interface{}
	if err := json.Unmarshal([]byte(raw), &m); err != nil {
		return nil, fmt.Errorf("parse request_params_template: %w", err)
	}
	return m, nil
}

func (e *CallbackAPIEndpoint) ValidateMemberMapping() error {
	m, err := e.ParsedResponseMapping()
	if err != nil {
		return err
	}
	if m.ListPath == "" {
		return fmt.Errorf("response_mapping.listPath is required")
	}
	if len(m.Fields) == 0 {
		return fmt.Errorf("response_mapping.fields is required")
	}
	for _, key := range RequiredMemberFields {
		if path, ok := m.Fields[key]; !ok || path == "" {
			return fmt.Errorf("response_mapping.fields missing internal field %q", key)
		}
	}
	return nil
}

func (t *CallbackTask) ParsedActivitySnapshot() (ActivitySnapshot, error) {
	raw := jsonbStringOrDefault(t.ActivitySnapshot, "{}")
	var s ActivitySnapshot
	if err := json.Unmarshal([]byte(raw), &s); err != nil {
		return ActivitySnapshot{}, fmt.Errorf("parse activity_snapshot: %w", err)
	}
	return s, nil
}

func ActivitySnapshotFromConfig(a *CallbackActivity) ActivitySnapshot {
	return ActivitySnapshot{
		Days:            a.Days,
		Rate:            a.Rate,
		Divisor:         a.Divisor,
		MinBonus:        a.MinBonus,
		MaxBonus:        a.MaxBonus,
		ExcludeRewarded: a.ExcludeRewarded,
		HealthMin:       a.HealthMin,
		HealthMax:       a.HealthMax,
	}
}

func MarshalActivitySnapshot(s ActivitySnapshot) (string, error) {
	b, err := json.Marshal(s)
	if err != nil {
		return "", err
	}
	return string(b), nil
}

func MarshalRawData(raw map[string]interface{}) (string, error) {
	if len(raw) == 0 {
		return "{}", nil
	}
	b, err := json.Marshal(raw)
	if err != nil {
		return "", err
	}
	return string(b), nil
}

func MappedMemberToResult(taskID uuid.UUID, m MappedMember) (*CallbackResult, error) {
	raw, err := MarshalRawData(m.Raw)
	if err != nil {
		return nil, err
	}
	return &CallbackResult{
		TaskID:             taskID,
		UserID:             m.UserID,
		PhoneNumber:        m.PhoneNumber,
		VIPLevel:           m.VIPLevel,
		HistoricalPay:      m.HistoricalPay,
		HistoryWithdrawals: m.HistoryWithdrawals,
		HistoricalReward:   m.HistoricalReward,
		RawData:            raw,
	}, nil
}

// ---------- AutoMigrate（仅 callback 模块 6 张表，不修改已有表） ----------

func autoMigrate(db *gorm.DB) error {
	models := []interface{}{
		&CallbackPlatform{},
		&CallbackAPIEndpoint{},
		&CallbackActivity{},
		&CallbackTask{},
		&CallbackResult{},
		&CallbackRequestLog{},
	}
	migrator := db.Migrator()
	for _, m := range models {
		if migrator.HasTable(m) {
			continue
		}
		if err := db.AutoMigrate(m); err != nil {
			return fmt.Errorf("%T: %w", m, err)
		}
	}
	return nil
}

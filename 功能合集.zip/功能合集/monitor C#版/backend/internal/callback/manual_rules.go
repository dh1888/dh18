package callback

import "strings"

// 手动派彩规则 ID（可扩展，新增规则只需在此注册并在 applyManualRowFilters 中实现）
const (
	ManualFilterTierExclude      = "tier_exclude"
	ManualFilterUnclaimedExclude = "unclaimed_exclude"
)

// ManualDispatchRuleSet 活动配置中的可开关规则集合
type ManualDispatchRuleSet struct {
	EnabledFilters []string `json:"enabledFilters"`
}

func (r ManualDispatchRuleSet) IsEnabled(filterID string) bool {
	for _, id := range r.EnabledFilters {
		if id == filterID {
			return true
		}
	}
	return false
}

// ManualFilterDefinition 供前端展示的可选规则
type ManualFilterDefinition struct {
	ID          string `json:"id"`
	Label       string `json:"label"`
	Description string `json:"description"`
}

var ManualFilterCatalog = []ManualFilterDefinition{
	{
		ID:          ManualFilterTierExclude,
		Label:       "层级过滤",
		Description: "剔除映射表中选定的层级会员",
	},
	{
		ID:          ManualFilterUnclaimedExclude,
		Label:       "未领彩金剔除",
		Description: "会员ID 在未领彩金名单中则剔除（需上传未领名单）",
	},
}

func DefaultManualRulesForDispatch(dispatchType string) ManualDispatchRuleSet {
	if normalizeManualDispatchType(dispatchType) == ManualDispatchCallbackBonus {
		return ManualDispatchRuleSet{
			EnabledFilters: []string{ManualFilterTierExclude, ManualFilterUnclaimedExclude},
		}
	}
	return ManualDispatchRuleSet{
		EnabledFilters: []string{ManualFilterTierExclude},
	}
}

func manualRulesFromActivity(a *CallbackActivity, dispatchType string) ManualDispatchRuleSet {
	defaults := DefaultManualRulesForDispatch(dispatchType)
	if a == nil {
		return defaults
	}
	var rules ManualDispatchRuleSet
	if normalizeManualDispatchType(dispatchType) == ManualDispatchCallbackBonus {
		rules = a.CallbackManualRules
	} else {
		rules = a.PeriodManualRules
	}
	if len(rules.EnabledFilters) == 0 {
		return defaults
	}
	return normalizeManualRules(rules)
}

func normalizeManualRules(rules ManualDispatchRuleSet) ManualDispatchRuleSet {
	allowed := make(map[string]struct{}, len(ManualFilterCatalog))
	for _, def := range ManualFilterCatalog {
		allowed[def.ID] = struct{}{}
	}
	seen := make(map[string]struct{})
	out := make([]string, 0, len(rules.EnabledFilters))
	for _, id := range rules.EnabledFilters {
		id = strings.TrimSpace(id)
		if id == "" {
			continue
		}
		if _, ok := allowed[id]; !ok {
			continue
		}
		if _, dup := seen[id]; dup {
			continue
		}
		seen[id] = struct{}{}
		out = append(out, id)
	}
	return ManualDispatchRuleSet{EnabledFilters: out}
}

type manualFilterEnv struct {
	rules         ManualDispatchRuleSet
	excludedTiers map[string]struct{}
	unclaimed     *unclaimedWhitelist
}

type manualFilterResult struct {
	excluded        bool
	unclaimedMatch  bool
	excludeReason   string
}

func newManualFilterEnv(rules ManualDispatchRuleSet, excludedTiers []string, unclaimed *unclaimedWhitelist) manualFilterEnv {
	return manualFilterEnv{
		rules:         rules,
		excludedTiers: buildTierExcludedSet(excludedTiers),
		unclaimed:     unclaimed,
	}
}

func (e manualFilterEnv) apply(row ManualRow) manualFilterResult {
	if e.rules.IsEnabled(ManualFilterTierExclude) && tierInExcludedSet(row.TierLevel, e.excludedTiers) {
		label := strings.TrimSpace(row.TierLevel)
		if label == "" {
			label = "(空)"
		}
		return manualFilterResult{
			excluded:      true,
			excludeReason: "层级已过滤: " + label,
		}
	}
	if e.rules.IsEnabled(ManualFilterUnclaimedExclude) && e.unclaimed != nil && e.unclaimed.containsUserID(row.UserID) {
		return manualFilterResult{
			excluded:       true,
			unclaimedMatch: true,
			excludeReason:  "在未领彩金名单",
		}
	}
	return manualFilterResult{}
}

func normalizeActivityManualRules(a *CallbackActivity) {
	if a == nil {
		return
	}
	a.PeriodManualRules = normalizeManualRules(a.PeriodManualRules)
	if len(a.PeriodManualRules.EnabledFilters) == 0 {
		a.PeriodManualRules = DefaultManualRulesForDispatch(ManualDispatchPeriodBonus)
	}
	a.CallbackManualRules = normalizeManualRules(a.CallbackManualRules)
	if len(a.CallbackManualRules.EnabledFilters) == 0 {
		a.CallbackManualRules = DefaultManualRulesForDispatch(ManualDispatchCallbackBonus)
	}
}

package callback

import (
	"fmt"
	"strings"
)

func (s *Service) ResolveManualExportResult(req ManualExportRequest) (ManualProcessResult, error) {
	if id := strings.TrimSpace(req.ResultID); id != "" {
		full, ok := s.manualStore.get(id)
		if !ok {
			return ManualProcessResult{}, fmt.Errorf("export result expired or not found, please process again")
		}
		return full, nil
	}
	if req.Result.DispatchType != "" {
		return req.Result, nil
	}
	return ManualProcessResult{}, fmt.Errorf("resultId or result is required")
}

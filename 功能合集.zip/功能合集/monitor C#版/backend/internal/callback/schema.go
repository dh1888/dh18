package callback

import "gorm.io/gorm"

// ensureCallbackSchema 用原生 SQL 补齐字段，避免 GORM AutoMigrate 与 callback_activity 单例索引冲突。
func ensureCallbackSchema(db *gorm.DB) error {
	return db.Exec(`
		ALTER TABLE callback_activity
			ADD COLUMN IF NOT EXISTS wagering_multiplier NUMERIC(10, 2) NOT NULL DEFAULT 1,
			ADD COLUMN IF NOT EXISTS app_remark TEXT NOT NULL DEFAULT '',
			ADD COLUMN IF NOT EXISTS backend_remark TEXT NOT NULL DEFAULT '',
			ADD COLUMN IF NOT EXISTS filtered_tiers JSONB NOT NULL DEFAULT '["新-无优惠","洗水套利","黑名单"]'::jsonb,
			ADD COLUMN IF NOT EXISTS callback_min_bonus NUMERIC(18, 2) NOT NULL DEFAULT 1.00,
			ADD COLUMN IF NOT EXISTS period_filtered_tiers JSONB NOT NULL DEFAULT '["新-无优惠","洗水套利","黑名单"]'::jsonb,
			ADD COLUMN IF NOT EXISTS callback_filtered_tiers JSONB NOT NULL DEFAULT '["新-无优惠","洗水套利","黑名单"]'::jsonb,
			ADD COLUMN IF NOT EXISTS period_wagering_multiplier NUMERIC(10, 2) NOT NULL DEFAULT 1,
			ADD COLUMN IF NOT EXISTS callback_wagering_multiplier NUMERIC(10, 2) NOT NULL DEFAULT 1,
			ADD COLUMN IF NOT EXISTS period_app_remark TEXT NOT NULL DEFAULT '',
			ADD COLUMN IF NOT EXISTS period_backend_remark TEXT NOT NULL DEFAULT '',
			ADD COLUMN IF NOT EXISTS callback_app_remark TEXT NOT NULL DEFAULT '',
			ADD COLUMN IF NOT EXISTS callback_backend_remark TEXT NOT NULL DEFAULT '',
			ADD COLUMN IF NOT EXISTS callback_rate NUMERIC(10, 6) NOT NULL DEFAULT 0.02,
			ADD COLUMN IF NOT EXISTS callback_divisor INTEGER NOT NULL DEFAULT 2,
			ADD COLUMN IF NOT EXISTS period_manual_rules JSONB NOT NULL DEFAULT '{"enabledFilters":["tier_exclude"]}'::jsonb,
			ADD COLUMN IF NOT EXISTS callback_manual_rules JSONB NOT NULL DEFAULT '{"enabledFilters":["tier_exclude","unclaimed_exclude"]}'::jsonb
	`).Error
}

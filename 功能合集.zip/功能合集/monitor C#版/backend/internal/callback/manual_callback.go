package callback

func (s *Service) processCallbackBonus(out *ManualProcessResult, memberRows []ManualRow, filters manualFilterEnv, cfg ManualBonusConfig) {
	callbackMin := cfg.CallbackMinBonus
	if callbackMin <= 0 {
		callbackMin = cfg.MinBonus
	}
	if callbackMin <= 0 {
		callbackMin = 1
	}
	rate := cfg.Rate
	divisor := cfg.Divisor
	if divisor <= 0 {
		divisor = 1
	}

	out.BonusRows = make([]ManualRow, 0, len(memberRows)/3)
	out.OtherRows = make([]ManualRow, 0, len(memberRows)/3)
	out.ExcludedRows = make([]ManualRow, 0, len(memberRows)/8)

	for i := range memberRows {
		row := &memberRows[i]
		if fr := filters.apply(*row); fr.excluded {
			row.ExcludeReason = fr.excludeReason
			if fr.unclaimedMatch {
				out.UnclaimedRewardRows = append(out.UnclaimedRewardRows, *row)
				out.Summary.UnclaimedMatchedCount++
			}
			out.ExcludedRows = append(out.ExcludedRows, *row)
			out.Summary.ExcludedCount++
			continue
		}

		row.Profit = roundMoney(CalcProfit(row.HistoricalPay, row.HistoryWithdrawals))
		if row.Profit < 0 {
			row.Bonus = roundMoney(callbackMin)
			out.BonusRows = append(out.BonusRows, *row)
			out.Summary.BonusCount++
		} else {
			row.Bonus = CalcCallbackManualBonus(row.Profit, rate, divisor, callbackMin)
			out.OtherRows = append(out.OtherRows, *row)
			out.Summary.OtherCount++
		}
		out.Summary.TotalBonus += row.Bonus
	}
}

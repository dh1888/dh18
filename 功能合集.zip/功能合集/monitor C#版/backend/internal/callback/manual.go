package callback

import (
	"context"
	"fmt"
	"io"
	"strconv"
	"strings"
	"sync"

	"github.com/google/uuid"
)

const (
	ManualDispatchPeriodBonus   = "period_bonus"
	ManualDispatchCallbackBonus = "callback_bonus"
)

type ManualBonusConfig struct {
	Rate               float64 `json:"rate"`
	Divisor            int     `json:"divisor"`
	MinBonus           float64 `json:"minBonus"`
	MaxBonus           float64 `json:"maxBonus"`
	CallbackMinBonus   float64 `json:"callbackMinBonus"`
	WageringMultiplier float64 `json:"wageringMultiplier"`
	AppRemark          string  `json:"appRemark"`
	BackendRemark      string  `json:"backendRemark"`
}

type ManualRow struct {
	RowIndex           int     `json:"rowIndex"`
	UserID             int64   `json:"userId"`
	PhoneNumber        string  `json:"phoneNumber"`
	HistoricalPay      float64 `json:"historicalPay"`
	HistoryWithdrawals float64 `json:"historyWithdrawals"`
	TierLevel          string  `json:"tierLevel,omitempty"`
	Profit             float64 `json:"profit"`
	Bonus              float64 `json:"bonus,omitempty"`
	ExcludeReason      string  `json:"excludeReason,omitempty"`
}

type ManualSummary struct {
	TotalRows             int     `json:"totalRows"`
	UnclaimedFileRows     int     `json:"unclaimedFileRows"`
	UnclaimedMatchedCount int     `json:"unclaimedMatchedCount"`
	BonusCount            int     `json:"bonusCount"`
	OtherCount            int     `json:"otherCount"`
	ExcludedCount         int     `json:"excludedCount"`
	TotalBonus            float64 `json:"totalBonus"`
}

type ManualProcessResult struct {
	ResultID            string            `json:"resultId,omitempty"`
	Truncated           bool              `json:"truncated,omitempty"`
	DispatchType        string            `json:"dispatchType"`
	BonusConfig         ManualBonusConfig `json:"bonusConfig"`
	Summary             ManualSummary     `json:"summary"`
	BonusRows           []ManualRow       `json:"bonusRows"`
	OtherRows           []ManualRow       `json:"otherRows"`
	ExcludedRows        []ManualRow       `json:"excludedRows"`
	UnclaimedRewardRows []ManualRow       `json:"unclaimedRewardRows"`
}

type ManualExportRequest struct {
	ExportType string              `json:"exportType"`
	ResultID   string              `json:"resultId,omitempty"`
	Result     ManualProcessResult `json:"result"`
}

type unclaimedWhitelist struct {
	byUserID map[int64]struct{}
}

func (w *unclaimedWhitelist) containsUserID(userID int64) bool {
	if userID <= 0 || w == nil {
		return false
	}
	_, ok := w.byUserID[userID]
	return ok
}

func normalizeManualDispatchType(s string) string {
	s = strings.TrimSpace(strings.ToLower(s))
	switch s {
	case ManualDispatchCallbackBonus, "callback", "回访彩金", "回访":
		return ManualDispatchCallbackBonus
	default:
		return ManualDispatchPeriodBonus
	}
}

func (s *Service) ProcessManualImport(
	ctx context.Context,
	dispatchType string,
	memberR io.Reader,
	memberFilename string,
	unclaimedR io.Reader,
	unclaimedFilename string,
	memberMapping ManualMemberColumnMapping,
	unclaimedMapping ManualUnclaimedColumnMapping,
) (*ManualProcessResult, error) {
	activity, err := s.GetActivity(ctx)
	if err != nil {
		return nil, err
	}
	cfg := manualBonusConfigFromActivity(activity, dispatchType)
	dispatchType = normalizeManualDispatchType(dispatchType)
	rules := manualRulesFromActivity(activity, dispatchType)

	if err := validateManualMemberMapping(memberMapping, rules); err != nil {
		return nil, err
	}
	excludedTiers := resolveExcludedTiers(memberMapping.ExcludedTiers, activityFilteredTiersForDispatch(activity, dispatchType))

	memberData, err := io.ReadAll(memberR)
	if err != nil {
		return nil, fmt.Errorf("read member file: %w", err)
	}

	needUnclaimed := rules.IsEnabled(ManualFilterUnclaimedExclude)
	if needUnclaimed && unclaimedR == nil {
		return nil, fmt.Errorf("活动配置已启用「未领彩金剔除」，请上传未领彩金名单")
	}
	if needUnclaimed && unclaimedMapping.UserID < 0 {
		return nil, fmt.Errorf("unclaimed member id column is required")
	}

	var (
		memberRows       []ManualRow
		memberParseErr   error
		whitelist        *unclaimedWhitelist
		unclaimedFileRows int
		unclaimedParseErr error
	)

	if needUnclaimed {
		unclaimedData, err := io.ReadAll(unclaimedR)
		if err != nil {
			return nil, fmt.Errorf("read unclaimed file: %w", err)
		}
		var wg sync.WaitGroup
		wg.Add(2)
		go func() {
			defer wg.Done()
			memberRows, memberParseErr = parseManualMemberSheetFromData(memberData, memberFilename, memberMapping)
		}()
		go func() {
			defer wg.Done()
			whitelist, unclaimedFileRows, unclaimedParseErr = parseUnclaimedWhitelistFromData(unclaimedData, unclaimedFilename, unclaimedMapping)
		}()
		wg.Wait()
		if memberParseErr != nil {
			return nil, fmt.Errorf("member file: %w", memberParseErr)
		}
		if unclaimedParseErr != nil {
			return nil, fmt.Errorf("unclaimed file: %w", unclaimedParseErr)
		}
	} else {
		memberRows, memberParseErr = parseManualMemberSheetFromData(memberData, memberFilename, memberMapping)
		if memberParseErr != nil {
			return nil, fmt.Errorf("member file: %w", memberParseErr)
		}
	}
	if len(memberRows) == 0 {
		return nil, fmt.Errorf("member file has no data rows")
	}

	out := &ManualProcessResult{
		DispatchType:        dispatchType,
		BonusConfig:         cfg,
		BonusRows:           make([]ManualRow, 0),
		OtherRows:           make([]ManualRow, 0),
		ExcludedRows:        make([]ManualRow, 0),
		UnclaimedRewardRows: make([]ManualRow, 0),
	}
	out.Summary.TotalRows = len(memberRows)
	out.Summary.UnclaimedFileRows = unclaimedFileRows

	filters := newManualFilterEnv(rules, excludedTiers, whitelist)

	switch dispatchType {
	case ManualDispatchCallbackBonus:
		s.processCallbackBonus(out, memberRows, filters, cfg)
	default:
		s.processPeriodBonus(out, memberRows, filters, cfg)
	}

	out.Summary.TotalBonus = roundMoney(out.Summary.TotalBonus)

	resultID := uuid.New().String()
	s.manualStore.put(resultID, *out)
	preview := truncateManualResultForAPI(*out, resultID, manualResultPreviewLimit)
	return &preview, nil
}

func (w *unclaimedWhitelist) contains(userID int64, phone string) bool {
	return w.containsUserID(userID)
}

func normalizePhone(s string) string {
	s = strings.TrimSpace(s)
	s = strings.ReplaceAll(s, " ", "")
	s = strings.ReplaceAll(s, "-", "")
	return s
}

func manualRowEmpty(row []string) bool {
	for _, c := range row {
		if strings.TrimSpace(c) != "" {
			return false
		}
	}
	return true
}

func cellAt(row []string, idx int) string {
	if idx < 0 || idx >= len(row) {
		return ""
	}
	return strings.TrimSpace(row[idx])
}

func parseManualDataRow(rowIndex int, row []string, colMap map[string]int) (ManualRow, error) {
	colPhone, hasPhone := colMap["phoneNumber"]
	colTier, hasTier := colMap["tierLevel"]
	return parseManualDataRowFast(
		rowIndex,
		row,
		colMap["userId"],
		colMap["historicalPay"],
		colMap["historyWithdrawals"],
		colPhone,
		hasPhone,
		colTier,
		hasTier,
	)
}

func parseManualDataRowFast(
	rowIndex int,
	row []string,
	colUserID, colPay, colWithdraw, colPhone int,
	hasPhone bool,
	colTier int,
	hasTier bool,
) (ManualRow, error) {
	userID, err := parseInt64Cell(cellAt(row, colUserID))
	if err != nil {
		return ManualRow{}, fmt.Errorf("invalid userId: %w", err)
	}
	if userID <= 0 {
		return ManualRow{}, fmt.Errorf("userId must be > 0")
	}
	pay, err := parseFloatCell(cellAt(row, colPay))
	if err != nil {
		return ManualRow{}, fmt.Errorf("invalid historicalPay: %w", err)
	}
	withdrawals, err := parseFloatCell(cellAt(row, colWithdraw))
	if err != nil {
		return ManualRow{}, fmt.Errorf("invalid historyWithdrawals: %w", err)
	}
	parsed := ManualRow{
		RowIndex:           rowIndex,
		UserID:             userID,
		HistoricalPay:      roundMoney(pay),
		HistoryWithdrawals: roundMoney(withdrawals),
	}
	if hasPhone {
		parsed.PhoneNumber = cellAt(row, colPhone)
	}
	if hasTier {
		parsed.TierLevel = normalizeTierValue(cellAt(row, colTier))
	}
	return parsed, nil
}

func tierFromRow(row []string, colMap map[string]int) string {
	idx, ok := colMap["tierLevel"]
	if !ok {
		return ""
	}
	return normalizeTierValue(cellAt(row, idx))
}

func phoneFromRow(row []string, colMap map[string]int) string {
	idx, ok := colMap["phoneNumber"]
	if !ok {
		return ""
	}
	return cellAt(row, idx)
}

func parseFloatCell(s string) (float64, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, nil
	}
	s = strings.ReplaceAll(s, ",", "")
	return strconv.ParseFloat(s, 64)
}

func parseInt64Cell(s string) (int64, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, fmt.Errorf("empty")
	}
	s = strings.ReplaceAll(s, ",", "")
	if f, err := strconv.ParseFloat(s, 64); err == nil {
		return int64(f), nil
	}
	return strconv.ParseInt(s, 10, 64)
}

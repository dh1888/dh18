package callback

func activityFilteredTiersForDispatch(a *CallbackActivity, dispatchType string) []string {
	if a == nil {
		return DefaultFilteredTierValues()
	}
	if normalizeManualDispatchType(dispatchType) == ManualDispatchCallbackBonus {
		if len(a.CallbackFilteredTiers) > 0 {
			return a.CallbackFilteredTiers
		}
		return DefaultFilteredTierValues()
	}
	if len(a.PeriodFilteredTiers) > 0 {
		return a.PeriodFilteredTiers
	}
	return DefaultFilteredTierValues()
}

func manualBonusConfigFromActivity(a *CallbackActivity, dispatchType string) ManualBonusConfig {
	if normalizeManualDispatchType(dispatchType) == ManualDispatchCallbackBonus {
		minBonus := a.CallbackMinBonus
		if minBonus <= 0 {
			minBonus = a.MinBonus
		}
		return ManualBonusConfig{
			Rate:               a.CallbackRate,
			Divisor:            a.CallbackDivisor,
			MinBonus:           minBonus,
			CallbackMinBonus:   a.CallbackMinBonus,
			WageringMultiplier: a.CallbackWageringMultiplier,
			AppRemark:          a.CallbackAppRemark,
			BackendRemark:      a.CallbackBackendRemark,
		}
	}
	return ManualBonusConfig{
		Rate:               a.Rate,
		Divisor:            a.Divisor,
		MinBonus:           a.MinBonus,
		MaxBonus:           a.MaxBonus,
		WageringMultiplier: a.PeriodWageringMultiplier,
		AppRemark:          a.PeriodAppRemark,
		BackendRemark:      a.PeriodBackendRemark,
	}
}

func normalizeActivityDefaults(a *CallbackActivity) {
	if a == nil {
		return
	}
	if len(a.PeriodFilteredTiers) == 0 {
		a.PeriodFilteredTiers = DefaultFilteredTierValues()
	}
	if len(a.CallbackFilteredTiers) == 0 {
		a.CallbackFilteredTiers = DefaultFilteredTierValues()
	}
	if a.PeriodWageringMultiplier <= 0 {
		a.PeriodWageringMultiplier = 1
	}
	if a.CallbackWageringMultiplier <= 0 {
		a.CallbackWageringMultiplier = 1
	}
	if a.CallbackMinBonus <= 0 {
		a.CallbackMinBonus = a.MinBonus
		if a.CallbackMinBonus <= 0 {
			a.CallbackMinBonus = 1
		}
	}
	if a.CallbackRate <= 0 {
		a.CallbackRate = 0.02
	}
	if a.CallbackDivisor <= 0 {
		a.CallbackDivisor = 2
	}
}

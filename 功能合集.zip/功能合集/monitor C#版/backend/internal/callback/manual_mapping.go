package callback

import (
	"encoding/json"
	"fmt"
	"io"
	"strings"
)

// ManualMemberColumnMapping 会员 Excel 列映射（0-based 列索引）
type ManualMemberColumnMapping struct {
	UserID             int      `json:"userId"`
	HistoricalPay      int      `json:"historicalPay"`
	HistoryWithdrawals int      `json:"historyWithdrawals"`
	PhoneNumber        int      `json:"phoneNumber"` // -1 表示不映射
	TierLevel          int      `json:"tierLevel"` // -1 表示不映射
	ExcludedTiers      []string `json:"excludedTiers,omitempty"`
	HeaderRow          int      `json:"headerRow"` // 0-based 表头行，数据从 HeaderRow+1 开始
}

// ManualUnclaimedColumnMapping 未领彩金名单列映射
type ManualUnclaimedColumnMapping struct {
	UserID      int `json:"userId"`
	PhoneNumber int `json:"phoneNumber"` // -1 表示不映射
	HeaderRow   int `json:"headerRow"`
}

type ManualColumnPreview struct {
	Index  int    `json:"index"`
	Letter string `json:"letter"`
	Header string `json:"header"`
}

func DefaultMemberColumnMapping() ManualMemberColumnMapping {
	return DefaultMemberColumnMappingForDispatch(ManualDispatchPeriodBonus)
}

func DefaultUnclaimedColumnMapping() ManualUnclaimedColumnMapping {
	return ManualUnclaimedColumnMapping{
		UserID:      1, // B
		PhoneNumber: -1,
		HeaderRow:   0,
	}
}

func ParseMemberColumnMappingJSON(raw string) (ManualMemberColumnMapping, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return DefaultMemberColumnMapping(), nil
	}
	var m ManualMemberColumnMapping
	if err := json.Unmarshal([]byte(raw), &m); err != nil {
		return ManualMemberColumnMapping{}, fmt.Errorf("invalid memberMapping json: %w", err)
	}
	if err := validateMemberColumnMapping(m); err != nil {
		return ManualMemberColumnMapping{}, err
	}
	return m, nil
}

func ParseUnclaimedColumnMappingJSON(raw string) (ManualUnclaimedColumnMapping, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return DefaultUnclaimedColumnMapping(), nil
	}
	var m ManualUnclaimedColumnMapping
	if err := json.Unmarshal([]byte(raw), &m); err != nil {
		return ManualUnclaimedColumnMapping{}, fmt.Errorf("invalid unclaimedMapping json: %w", err)
	}
	if err := validateUnclaimedColumnMapping(m); err != nil {
		return ManualUnclaimedColumnMapping{}, err
	}
	return m, nil
}

func validateMemberColumnMapping(m ManualMemberColumnMapping) error {
	if m.UserID < 0 || m.HistoricalPay < 0 || m.HistoryWithdrawals < 0 {
		return fmt.Errorf("column index must be >= 0")
	}
	if m.HeaderRow < 0 {
		return fmt.Errorf("headerRow must be >= 0")
	}
	return nil
}

func validateManualMemberMapping(m ManualMemberColumnMapping, rules ManualDispatchRuleSet) error {
	if err := validateMemberColumnMapping(m); err != nil {
		return err
	}
	if rules.IsEnabled(ManualFilterTierExclude) && m.TierLevel < 0 {
		return fmt.Errorf("tierLevel column is required when tier filter is enabled")
	}
	return nil
}

func validateManualMemberMappingWithTier(m ManualMemberColumnMapping) error {
	if err := validateMemberColumnMapping(m); err != nil {
		return err
	}
	if m.TierLevel < 0 {
		return fmt.Errorf("tierLevel column is required")
	}
	return nil
}

func validateUnclaimedColumnMapping(m ManualUnclaimedColumnMapping) error {
	if m.UserID < 0 && m.PhoneNumber < 0 {
		return fmt.Errorf("at least one of userId or phoneNumber column is required")
	}
	if m.HeaderRow < 0 {
		return fmt.Errorf("headerRow must be >= 0")
	}
	return nil
}

const (
	tierPreviewMaxRows    = 3000
	tierPreviewMaxUnique  = 200
)

func PreviewSpreadsheetColumns(r io.Reader, filename string, headerRow int) ([]ManualColumnPreview, error) {
	if headerRow < 0 {
		headerRow = 0
	}
	rows, err := readSpreadsheetRowsPreview(r, filename, spreadsheetPreviewMaxRows)
	if err != nil {
		return nil, err
	}
	if headerRow >= len(rows) {
		return nil, fmt.Errorf("headerRow %d out of range (file has %d rows)", headerRow+1, len(rows))
	}
	header := rows[headerRow]
	out := make([]ManualColumnPreview, 0, len(header))
	for i, h := range header {
		title := strings.TrimSpace(h)
		if title == "" {
			title = "(空)"
		}
		out = append(out, ManualColumnPreview{
			Index:  i,
			Letter: columnIndexToLetter(i),
			Header: title,
		})
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("no columns found in header row")
	}
	return out, nil
}

func columnIndexToLetter(idx int) string {
	if idx < 0 {
		return ""
	}
	n := idx + 1
	var b []byte
	for n > 0 {
		n--
		b = append([]byte{byte('A' + n%26)}, b...)
		n /= 26
	}
	return string(b)
}

func memberColMapFromMapping(m ManualMemberColumnMapping) map[string]int {
	colMap := map[string]int{
		"userId":             m.UserID,
		"historicalPay":      m.HistoricalPay,
		"historyWithdrawals": m.HistoryWithdrawals,
	}
	if m.PhoneNumber >= 0 {
		colMap["phoneNumber"] = m.PhoneNumber
	}
	if m.TierLevel >= 0 {
		colMap["tierLevel"] = m.TierLevel
	}
	return colMap
}

func PreviewTierValues(r io.Reader, filename string, headerRow, tierColumn int) ([]string, error) {
	if tierColumn < 0 {
		return nil, fmt.Errorf("tierColumn must be >= 0")
	}
	if headerRow < 0 {
		headerRow = 0
	}
	rows, err := readSpreadsheetRowsPreview(r, filename, headerRow+1+tierPreviewMaxRows)
	if err != nil {
		return nil, err
	}
	startRow := headerRow + 1
	if startRow > len(rows) {
		return nil, fmt.Errorf("no data rows after header row %d", headerRow+1)
	}
	seen := make(map[string]struct{}, tierPreviewMaxUnique)
	out := make([]string, 0, 32)
	for i := startRow; i < len(rows); i++ {
		row := rows[i]
		if tierColumn >= len(row) {
			row = padManualRow(row, tierColumn+1)
		}
		if manualRowEmpty(row) {
			continue
		}
		tier := normalizeTierValue(cellAt(row, tierColumn))
		if tier == "" {
			continue
		}
		if _, ok := seen[tier]; ok {
			continue
		}
		seen[tier] = struct{}{}
		out = append(out, tier)
		if len(out) >= tierPreviewMaxUnique {
			break
		}
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("no tier values found in mapped column")
	}
	return out, nil
}


package callback

// CalcPeriodBonus 时段彩金：用户亏损或持平（充提差 >= 0）时计算彩金。
func CalcPeriodBonus(profitDiff, rate float64, divisor int, minBonus, maxBonus float64) float64 {
	if profitDiff < 0 {
		return 0
	}
	if divisor <= 0 {
		divisor = 1
	}
	bonus := profitDiff * rate / float64(divisor)
	if bonus < minBonus {
		bonus = minBonus
	}
	if maxBonus > 0 && bonus > maxBonus {
		bonus = maxBonus
	}
	return roundMoney(bonus)
}

func (s *Service) processPeriodBonus(out *ManualProcessResult, memberRows []ManualRow, filters manualFilterEnv, cfg ManualBonusConfig) {
	divisor := cfg.Divisor
	if divisor <= 0 {
		divisor = 1
	}

	out.BonusRows = make([]ManualRow, 0, len(memberRows)/3)
	out.OtherRows = make([]ManualRow, 0, len(memberRows)/3)
	out.ExcludedRows = make([]ManualRow, 0, len(memberRows)/8)

	for i := range memberRows {
		row := &memberRows[i]
		if fr := filters.apply(*row); fr.excluded {
			row.ExcludeReason = fr.excludeReason
			if fr.unclaimedMatch {
				out.UnclaimedRewardRows = append(out.UnclaimedRewardRows, *row)
				out.Summary.UnclaimedMatchedCount++
			}
			out.ExcludedRows = append(out.ExcludedRows, *row)
			out.Summary.ExcludedCount++
			continue
		}

		row.Profit = roundMoney(CalcProfit(row.HistoricalPay, row.HistoryWithdrawals))
		if row.Profit < 0 {
			out.OtherRows = append(out.OtherRows, *row)
			out.Summary.OtherCount++
			continue
		}
		row.Bonus = CalcPeriodBonus(row.Profit, cfg.Rate, divisor, cfg.MinBonus, cfg.MaxBonus)
		out.BonusRows = append(out.BonusRows, *row)
		out.Summary.BonusCount++
		out.Summary.TotalBonus += row.Bonus
	}
}

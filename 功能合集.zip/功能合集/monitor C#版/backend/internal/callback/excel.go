package callback

import (
	"bytes"
	"fmt"

	"github.com/xuri/excelize/v2"
)

func BuildResultsExcel(task *CallbackTask, results []CallbackResult) (*bytes.Buffer, error) {
	f := excelize.NewFile()
	sheet := "results"
	_ = f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"用户ID", "手机号", "VIP等级", "历史充值", "历史提现",
		"历史优惠", "盈亏", "彩金",
	}
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		_ = f.SetCellValue(sheet, cell, h)
	}

	for i, r := range results {
		row := i + 2
		values := []interface{}{
			r.UserID,
			r.PhoneNumber,
			r.VIPLevel,
			r.HistoricalPay,
			r.HistoryWithdrawals,
			r.HistoricalReward,
			r.Profit,
			r.Bonus,
		}
		for col, val := range values {
			cell, _ := excelize.CoordinatesToCellName(col+1, row)
			_ = f.SetCellValue(sheet, cell, val)
		}
	}

	metaSheet := "task"
	idx, _ := f.NewSheet(metaSheet)
	_ = f.SetCellValue(metaSheet, "A1", "任务ID")
	_ = f.SetCellValue(metaSheet, "B1", task.ID.String())
	_ = f.SetCellValue(metaSheet, "A2", "日期范围")
	_ = f.SetCellValue(metaSheet, "B2", fmt.Sprintf("%s ~ %s", task.DateFrom.Format("2006-01-02"), task.DateTo.Format("2006-01-02")))
	_ = f.SetCellValue(metaSheet, "A3", "回访人数")
	_ = f.SetCellValue(metaSheet, "B3", task.MemberCount)
	_ = f.SetCellValue(metaSheet, "A4", "总彩金")
	_ = f.SetCellValue(metaSheet, "B4", task.TotalBonus)
	if task.HealthLevel != nil {
		_ = f.SetCellValue(metaSheet, "A5", "健康值")
		_ = f.SetCellValue(metaSheet, "B5", *task.HealthLevel)
	}
	f.SetActiveSheet(idx)

	buf := &bytes.Buffer{}
	if err := f.Write(buf); err != nil {
		return nil, err
	}
	return buf, nil
}

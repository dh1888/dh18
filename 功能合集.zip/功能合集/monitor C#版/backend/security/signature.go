// backend/security/security.go
package security

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

var (
	ErrSecretNotConfigured = errors.New("signature secret not configured")
	ErrMissingSignature    = errors.New("missing signature")
	ErrMissingTimestamp    = errors.New("missing timestamp")
	ErrInvalidTimestamp    = errors.New("invalid timestamp format")
	ErrTimestampExpired    = errors.New("timestamp expired")
	ErrInvalidNonce        = errors.New("invalid nonce")
	ErrInvalidSignature    = errors.New("invalid signature")

	ErrEmptyPath     = errors.New("empty path")
	ErrPathTraversal = errors.New("path traversal detected")
	ErrAccessDenied  = errors.New("access denied")
)

// NonceStore 防重放接口
//
// 单机:
//
//	NonceCache
//
// 多实例:
//
//	Redis SETNX
type NonceStore interface {
	CheckAndStore(nonce string) error
	Close() error
}

// SignaturePayload 签名载荷
type SignaturePayload struct {
	Method    string
	Path      string
	Timestamp string
	Nonce     string
	Body      string
}

// SignatureConfig 签名配置
type SignatureConfig struct {
	Secret             []byte
	TimestampTolerance time.Duration
	NonceStore         NonceStore
}

// NewSignatureConfig 创建签名配置
func NewSignatureConfig(secretKey string) *SignatureConfig {
	return &SignatureConfig{
		Secret:             []byte(secretKey),
		TimestampTolerance: 5 * time.Minute,
		NonceStore: NewNonceCache(
			5*time.Minute,
			100000,
		),
	}
}

// GenerateNonce 生成安全随机 nonce
func GenerateNonce() (string, error) {

	b := make([]byte, 32)

	_, err := rand.Read(b)
	if err != nil {
		return "", err
	}

	return base64.RawURLEncoding.EncodeToString(b), nil
}

// GenerateSignature 生成签名
func (c *SignatureConfig) GenerateSignature(
	payload SignaturePayload,
) string {

	message := c.buildMessage(payload)

	mac := hmac.New(sha256.New, c.Secret)

	mac.Write([]byte(message))

	// ✅ 改为 Hex 编码（小写），与客户端保持一致
	// 之前：base64.StdEncoding.EncodeToString(mac.Sum(nil))
	// 现在：hex.EncodeToString(mac.Sum(nil))
	return hex.EncodeToString(mac.Sum(nil))
}

// VerifySignature 验证签名
func (c *SignatureConfig) VerifySignature(
	payload SignaturePayload,
	signature string,
) error {

	// 1. 检查 secret
	if len(c.Secret) == 0 {
		return ErrSecretNotConfigured
	}

	// 2. 检查签名
	if strings.TrimSpace(signature) == "" {
		return ErrMissingSignature
	}

	// 3. 检查 timestamp
	if strings.TrimSpace(payload.Timestamp) == "" {
		return ErrMissingTimestamp
	}

	// 4. 解析 timestamp
	ts, err := time.Parse(time.RFC3339, payload.Timestamp)
	if err != nil {
		return fmt.Errorf("%w: %v", ErrInvalidTimestamp, err)
	}

	// 5. 防未来时间 / 过期时间
	if absDuration(time.Since(ts)) > c.TimestampTolerance {
		return ErrTimestampExpired
	}

	// 6. 验证 nonce
	if !isValidNonce(payload.Nonce) {
		return ErrInvalidNonce
	}

	// 7. 防重放
	if c.NonceStore != nil {

		if err := c.NonceStore.CheckAndStore(
			payload.Nonce,
		); err != nil {
			return err
		}
	}

	// 8. 验证签名
	expected := c.GenerateSignature(payload)

	if !hmac.Equal(
		[]byte(expected),
		[]byte(signature),
	) {
		return ErrInvalidSignature
	}

	return nil
}

// Close 关闭资源
func (c *SignatureConfig) Close() error {

	if c.NonceStore != nil {
		return c.NonceStore.Close()
	}

	return nil
}

// buildMessage 构建签名字符串
func (c *SignatureConfig) buildMessage(
	payload SignaturePayload,
) string {

	return strings.Join([]string{
		strings.ToUpper(payload.Method),
		payload.Path,
		payload.Timestamp,
		payload.Nonce,
		payload.Body,
	}, "\n")
}

// ValidatePath 防路径穿越
func ValidatePath(
	requestedPath,
	baseDir string,
) (string, error) {

	if requestedPath == "" {
		return "", ErrEmptyPath
	}

	// clean
	cleanPath := filepath.Clean(requestedPath)

	// 防路径穿越
	if strings.Contains(cleanPath, "..") {
		return "", ErrPathTraversal
	}

	// abs path
	absPath, err := filepath.Abs(cleanPath)
	if err != nil {
		return "", err
	}

	// real path
	realPath, err := filepath.EvalSymlinks(absPath)
	if err != nil {

		// 文件不存在允许继续
		if !os.IsNotExist(err) {
			return "", err
		}

		realPath = absPath
	}

	// base abs
	absBase, err := filepath.Abs(baseDir)
	if err != nil {
		return "", err
	}

	// base real
	realBase, err := filepath.EvalSymlinks(absBase)
	if err != nil {

		if !os.IsNotExist(err) {
			return "", err
		}

		realBase = absBase
	}

	// rel check
	rel, err := filepath.Rel(realBase, realPath)
	if err != nil {
		return "", err
	}

	if strings.HasPrefix(rel, "..") {
		return "", ErrAccessDenied
	}

	return realPath, nil
}

// ValidateFileType 验证文件类型
func ValidateFileType(
	reader io.Reader,
	filename string,
	allowedMimeTypes []string,
	allowedExts []string,
) bool {

	// ext check
	ext := strings.ToLower(
		filepath.Ext(filename),
	)

	extAllowed := false

	for _, allowed := range allowedExts {

		if ext == strings.ToLower(allowed) {
			extAllowed = true
			break
		}
	}

	if !extAllowed {
		return false
	}

	// mime check
	buffer := make([]byte, 512)

	n, err := reader.Read(buffer)
	if err != nil && err != io.EOF {
		return false
	}

	mimeType := http.DetectContentType(
		buffer[:n],
	)

	for _, allowed := range allowedMimeTypes {

		if mimeType == allowed {
			return true
		}
	}

	return false
}

// MaskSensitiveData 脱敏
func MaskSensitiveData(data string) string {

	runes := []rune(data)

	if len(runes) <= 8 {
		return "***"
	}

	return string(runes[:4]) +
		"***" +
		string(runes[len(runes)-4:])
}

// GetEnvOrDefault 获取环境变量
func GetEnvOrDefault(
	key,
	defaultValue string,
) string {

	value := strings.TrimSpace(
		os.Getenv(key),
	)

	if value == "" {
		return defaultValue
	}

	return value
}

// GetEnvInt 获取 int env
func GetEnvInt(
	key string,
	defaultValue int,
) int {

	value := strings.TrimSpace(
		os.Getenv(key),
	)

	if value == "" {
		return defaultValue
	}

	intVal, err := strconv.Atoi(value)
	if err != nil {
		return defaultValue
	}

	return intVal
}

// GetEnvBool 获取 bool env
func GetEnvBool(
	key string,
	defaultValue bool,
) bool {

	value := strings.TrimSpace(
		strings.ToLower(
			os.Getenv(key),
		),
	)

	if value == "" {
		return defaultValue
	}

	boolVal, err := strconv.ParseBool(value)
	if err != nil {
		return defaultValue
	}

	return boolVal
}

// GetEnvDuration 获取 duration env
func GetEnvDuration(
	key string,
	defaultValue time.Duration,
) time.Duration {

	value := strings.TrimSpace(
		os.Getenv(key),
	)

	if value == "" {
		return defaultValue
	}

	durationVal, err := time.ParseDuration(value)
	if err != nil {
		return defaultValue
	}

	return durationVal
}

func isValidNonce(nonce string) bool {

	if len(nonce) < 16 ||
		len(nonce) > 128 {
		return false
	}

	for _, c := range nonce {

		if !(c >= 'a' && c <= 'z') &&
			!(c >= 'A' && c <= 'Z') &&
			!(c >= '0' && c <= '9') &&
			c != '-' &&
			c != '_' {

			return false
		}
	}

	return true
}

func absDuration(
	d time.Duration,
) time.Duration {

	if d < 0 {
		return -d
	}

	return d
}

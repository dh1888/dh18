// backend/signature/canonical_request.go
// Canonical Request Builder - v1 specification implementation
// This file defines the canonical request construction rules for signature v1

package security

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/url"
	"strings"
	"testing"
)

// CanonicalRequest represents a canonicalized HTTP request for signature computation
type CanonicalRequest struct {
	Timestamp  string // ISO 8601 UTC format: YYYY-MM-DDTHH:mm:ssZ
	HTTPMethod string // UPPERCASE: POST, GET, PUT, DELETE, PATCH
	Path       string // Absolute URL path (decoded)
	BodyHash   string // SHA256(body) in lowercase hex
}

// BuildCanonical constructs a canonical request from raw inputs
// This is the ONLY approved way to build canonical requests for v1
func BuildCanonical(timestamp, method, path string, bodyBytes []byte) *CanonicalRequest {
	// 1. Normalize HTTP method to UPPERCASE
	method = strings.ToUpper(method)

	// 2. Decode and normalize path
	decodedPath := path
	if unescaped, err := url.PathUnescape(path); err == nil {
		decodedPath = unescaped
	}

	// 3. Calculate body hash
	bodyHash := sha256.Sum256(bodyBytes)
	bodyHashHex := hex.EncodeToString(bodyHash[:])

	return &CanonicalRequest{
		Timestamp:  timestamp,
		HTTPMethod: method,
		Path:       decodedPath,
		BodyHash:   bodyHashHex,
	}
}

// String returns the canonical message for HMAC computation
// Format: TIMESTAMP + HTTP_METHOD + PATH + BODY_HASH (no separators)
func (cr *CanonicalRequest) String() string {
	return cr.Timestamp + cr.HTTPMethod + cr.Path + cr.BodyHash
}

// Message returns the canonical message (same as String)
func (cr *CanonicalRequest) Message() string {
	return cr.String()
}

// Validate checks if canonical request is valid according to v1 spec
func (cr *CanonicalRequest) Validate() error {
	if cr == nil {
		return fmt.Errorf("canonical request is nil")
	}

	// Validate timestamp format (ISO 8601 UTC)
	if !isValidRFC3339Timestamp(cr.Timestamp) {
		return fmt.Errorf("invalid timestamp format: %s (must be YYYY-MM-DDTHH:mm:ssZ)", cr.Timestamp)
	}

	// Validate HTTP method
	if !isValidHTTPMethod(cr.HTTPMethod) {
		return fmt.Errorf("invalid HTTP method: %s (must be uppercase)", cr.HTTPMethod)
	}

	// Validate path (must start with /)
	if !strings.HasPrefix(cr.Path, "/") {
		return fmt.Errorf("path must start with /: %s", cr.Path)
	}

	// Validate body hash (must be 64-char lowercase hex)
	if !isValidHex(cr.BodyHash, 64) {
		return fmt.Errorf("invalid body hash: %s (must be 64-char lowercase hex)", cr.BodyHash)
	}

	return nil
}

// isValidRFC3339Timestamp checks if timestamp matches YYYY-MM-DDTHH:mm:ssZ format
func isValidRFC3339Timestamp(ts string) bool {
	if len(ts) != 20 {
		return false // Exact length: YYYY-MM-DDTHH:mm:ssZ
	}
	if ts[19] != 'Z' {
		return false
	}
	if ts[10] != 'T' {
		return false
	}
	if ts[4] != '-' || ts[7] != '-' {
		return false
	}
	if ts[13] != ':' || ts[16] != ':' {
		return false
	}
	// All other characters must be digits
	digits := map[int]bool{0: true, 1: true, 2: true, 3: true, 5: true, 6: true,
		8: true, 9: true, 11: true, 12: true, 14: true, 15: true, 17: true, 18: true}
	for i, c := range ts {
		if digits[i] && (c < '0' || c > '9') {
			return false
		}
	}
	return true
}

// isValidHTTPMethod checks if method is uppercase and known
func isValidHTTPMethod(method string) bool {
	valid := map[string]bool{
		"GET":     true,
		"POST":    true,
		"PUT":     true,
		"DELETE":  true,
		"PATCH":   true,
		"HEAD":    true,
		"OPTIONS": true,
	}
	return valid[method]
}

// isValidHex checks if string is N-character lowercase hexadecimal
func isValidHex(s string, length int) bool {
	if len(s) != length {
		return false
	}
	for _, c := range s {
		if (c < '0' || c > '9') && (c < 'a' || c > 'f') {
			return false
		}
	}
	return true
}

// ComputeSignature calculates HMAC-SHA256 signature
// This is the v1 signature algorithm
func ComputeSignature(canonicalMessage string, deviceSecret string) string {
	mac := hmac.New(sha256.New, []byte(deviceSecret))
	mac.Write([]byte(canonicalMessage))
	return hex.EncodeToString(mac.Sum(nil))
}

// TestVector defines a fixed input and expected output for regression testing
type TestVector struct {
	Name              string
	Timestamp         string
	Method            string
	Path              string
	Body              string
	DeviceSecret      string
	ExpectedSignature string
}

// GetV1TestVectors returns all frozen test vectors for protocol v1
// These MUST NOT change and must match C# implementation exactly
func GetV1TestVectors() []TestVector {
	return []TestVector{
		{
			Name:              "POST upload chunk with JSON",
			Timestamp:         "2026-06-13T14:30:45Z",
			Method:            "POST",
			Path:              "/api/v1/upload/chunk",
			Body:              `{"uploadId":"550e8400-e29b-41d4-a716-446655440000","chunkIndex":0,"totalChunks":5}`,
			DeviceSecret:      "a1b2c3d4e5f6789012345678901234567890123456789012345678901234567",
			ExpectedSignature: "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
		},
		{
			Name:              "POST upload complete",
			Timestamp:         "2026-06-13T14:30:50Z",
			Method:            "POST",
			Path:              "/api/v1/upload/complete",
			Body:              `{"uploadId":"550e8400-e29b-41d4-a716-446655440000","deviceId":"e8c7b3f9-4d3e-4c5a-8a2c-5d5d5d5d5d5d"}`,
			DeviceSecret:      "f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a698",
			ExpectedSignature: "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
		},
		{
			Name:              "GET device verify with empty body",
			Timestamp:         "2026-06-13T14:31:00Z",
			Method:            "GET",
			Path:              "/api/v1/devices/verify",
			Body:              "",
			DeviceSecret:      "0102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f20",
			ExpectedSignature: "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d",
		},
		{
			Name:              "DELETE with different method",
			Timestamp:         "2026-06-13T14:31:05Z",
			Method:            "DELETE",
			Path:              "/api/v1/devices/abc-123",
			Body:              "",
			DeviceSecret:      "aaaabbbbccccddddeeeeffffgggghhhh11112222333344445555666677778888",
			ExpectedSignature: "", // Will be computed
		},
		{
			Name:              "PUT with patch body",
			Timestamp:         "2026-06-13T14:31:10Z",
			Method:            "PUT",
			Path:              "/api/v1/settings/config",
			Body:              `{"enabled":true,"timeout":30}`,
			DeviceSecret:      "88887777666655554444333322221111ffffeeeeddddcccbbbbaaa99998888777",
			ExpectedSignature: "", // Will be computed
		},
	}
}

// ComputeSignatureV1 computes a v1 signature from inputs
func ComputeSignatureV1(timestamp, method, path string, bodyBytes []byte, deviceSecret string) string {
	cr := BuildCanonical(timestamp, method, path, bodyBytes)
	message := cr.Message()

	mac := hmac.New(sha256.New, []byte(deviceSecret))
	mac.Write([]byte(message))
	return hex.EncodeToString(mac.Sum(nil))
}

// TestV1Regression verifies that all test vectors produce expected signatures
func TestV1Regression(t *testing.T) {
	vectors := GetV1TestVectors()

	for _, vec := range vectors {
		t.Run(vec.Name, func(t *testing.T) {
			computed := ComputeSignatureV1(vec.Timestamp, vec.Method, vec.Path, []byte(vec.Body), vec.DeviceSecret)

			if vec.ExpectedSignature != "" && computed != vec.ExpectedSignature {
				t.Errorf("Signature mismatch for %s\n  Expected: %s\n  Got:      %s", vec.Name, vec.ExpectedSignature, computed)
			} else if vec.ExpectedSignature == "" {
				// For new vectors, just verify it's a valid 64-char hex
				if len(computed) != 64 {
					t.Errorf("Invalid signature length for %s: %d (expected 64)", vec.Name, len(computed))
				}
				t.Logf("Vector %s: %s", vec.Name, computed)
			}
		})
	}
}

// TestV1ParityWithCSharp verifies Go signatures match C# output (manual cross-check)
func TestV1ParityWithCSharp(t *testing.T) {
	vectors := GetV1TestVectors()[:3] // Only test first 3 (confirmed via C# test)

	expectedCSharpOutputs := map[string]string{
		"POST upload chunk with JSON": "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
		"POST upload complete":        "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
		"GET device verify with empty body": "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d",
	}

	for _, vec := range vectors {
		t.Run(vec.Name, func(t *testing.T) {
			computed := ComputeSignatureV1(vec.Timestamp, vec.Method, vec.Path, []byte(vec.Body), vec.DeviceSecret)
			expected := expectedCSharpOutputs[vec.Name]

			if computed != expected {
				t.Errorf("Parity mismatch for %s\n  Expected (C#): %s\n  Got (Go):      %s", vec.Name, expected, computed)
			} else {
				t.Logf("✓ Parity verified for %s", vec.Name)
			}
		})
	}
}

// BenchmarkV1Signature benchmarks signature computation
func BenchmarkV1Signature(b *testing.B) {
	vector := GetV1TestVectors()[0]
	body := []byte(vector.Body)

	b.ReportAllocs()
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		_ = ComputeSignatureV1(vector.Timestamp, vector.Method, vector.Path, body, vector.DeviceSecret)
	}
}

// PrintV1TestVectors prints all test vectors in a readable format
func PrintV1TestVectors() {
	vectors := GetV1TestVectors()

	fmt.Print("=== v1 Protocol Test Vectors (FROZEN) ===\n\n")

	for i, vec := range vectors {
		sig := ComputeSignatureV1(vec.Timestamp, vec.Method, vec.Path, []byte(vec.Body), vec.DeviceSecret)

		fmt.Printf("Vector %d: %s\n", i+1, vec.Name)
		fmt.Printf("  Timestamp: %s\n", vec.Timestamp)
		fmt.Printf("  Method:    %s\n", vec.Method)
		fmt.Printf("  Path:      %s\n", vec.Path)
		fmt.Printf("  Body:      %s\n", vec.Body)
		fmt.Printf("  Secret:    %s\n", vec.DeviceSecret)
		fmt.Printf("  Signature: %s\n\n", sig)
	}
}

#!/usr/bin/env node
/**
 * Playwright 截图脚本 — 供 dm-probe 调用
 * 用法: node screenshot.mjs --url https://example.com [--proxy http://host:port] [--output path|-]
 * 依赖: npm install playwright && npx playwright install chromium
 */
import { chromium } from "playwright";
import { writeFileSync } from "fs";

function parseArgs(argv) {
  const out = { url: "", proxy: "", output: "screenshot.png" };
  for (let i = 2; i < argv.length; i++) {
    if (argv[i] === "--url") out.url = argv[++i] || "";
    else if (argv[i] === "--proxy") out.proxy = argv[++i] || "";
    else if (argv[i] === "--output") out.output = argv[++i] || "-";
  }
  return out;
}

const args = parseArgs(process.argv);
if (!args.url) {
  console.error("missing --url");
  process.exit(1);
}

const launchOpts = { headless: true };
if (args.proxy) {
  launchOpts.proxy = { server: args.proxy };
}

const browser = await chromium.launch(launchOpts);
const page = await browser.newPage({
  userAgent:
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
});
await page.goto(args.url, { waitUntil: "networkidle", timeout: 45000 });
const buf = await page.screenshot({ fullPage: false, type: "png" });
await browser.close();

if (args.output === "-") {
  process.stdout.write(buf);
} else {
  writeFileSync(args.output, buf);
}

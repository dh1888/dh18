using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Channels;
using Microsoft.Win32;

namespace EnterpriseAgent;

public interface IBrowserHistoryService
{
    void Start();
    void Stop();
    Task<List<BrowserHistoryData>> GetHistoryAsync(DateTime fromDate, CancellationToken ct = default);
}

public class BrowserHistoryService : IBrowserHistoryService
{
    private readonly IConfigurationService _configService;
    private readonly IHttpClientService _httpService;
    private readonly Channel<List<BrowserHistoryData>> _uploadChannel;
    private CancellationTokenSource? _cts;
    private Task? _collectionLoopTask;
    private Task? _uploadLoopTask;
    private int _isRunning;
    private DateTime _lastCollectionTime;
    private readonly HashSet<string> _reportedUrls = new();
    private readonly object _reportedLock = new();
    
    public BrowserHistoryService(
        IConfigurationService configService,
        IHttpClientService httpService)
    {
        _configService = configService;
        _httpService = httpService;
        _uploadChannel = Channel.CreateBounded<List<BrowserHistoryData>>(new BoundedChannelOptions(50)
        {
            FullMode = BoundedChannelFullMode.DropOldest
        });
        _lastCollectionTime = DateTime.UtcNow.AddDays(-1);
    }
    
    public void Start()
    {
        if (Interlocked.Exchange(ref _isRunning, 1) == 1)
            return;
        
        _cts = new CancellationTokenSource();
        _collectionLoopTask = Task.Run(CollectionLoopAsync);
        _uploadLoopTask = Task.Run(UploadLoopAsync);
        
        Log.Information("✅ 浏览器历史服务已启动");
    }
    
    public void Stop()
    {
        if (Interlocked.Exchange(ref _isRunning, 0) == 0)
            return;
        
        _cts?.Cancel();
        _uploadChannel.Writer.TryComplete();
        
        Log.Information("浏览器历史服务已停止");
    }
    
    public async Task<List<BrowserHistoryData>> GetHistoryAsync(DateTime fromDate, CancellationToken ct = default)
    {
        var histories = new List<BrowserHistoryData>();
        
        // Chrome
        var chromeHistory = await GetChromeHistoryAsync(fromDate, ct);
        histories.AddRange(chromeHistory);
        
        // Edge
        var edgeHistory = await GetEdgeHistoryAsync(fromDate, ct);
        histories.AddRange(edgeHistory);
        
        // Firefox
        var firefoxHistory = await GetFirefoxHistoryAsync(fromDate, ct);
        histories.AddRange(firefoxHistory);
        
        return histories;
    }
    
    private async Task CollectionLoopAsync()
    {
        while (!_cts?.IsCancellationRequested == true)
        {
            try
            {
                var now = DateTime.UtcNow;
                var histories = await GetHistoryAsync(_lastCollectionTime, _cts!.Token);
                
                if (histories.Count > 0)
                {
                    await _uploadChannel.Writer.WriteAsync(histories, _cts.Token);
                    _lastCollectionTime = now;
                }
                
                await Task.Delay(TimeSpan.FromMinutes(5), _cts.Token);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "浏览器历史收集异常");
                await Task.Delay(TimeSpan.FromMinutes(1), _cts!.Token);
            }
        }
    }
    
    private async Task UploadLoopAsync()
    {
        var reader = _uploadChannel.Reader;
        
        while (await reader.WaitToReadAsync())
        {
            while (reader.TryRead(out var histories))
            {
                try
                {
                    var success = await _httpService.UploadBrowserHistoryAsync(histories);
                    if (!success)
                    {
                        Log.Warning($"浏览器历史上传失败，{histories.Count}条记录将重试");
                        await Task.Delay(5000);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "上传浏览器历史异常");
                }
            }
        }
    }
    
    private async Task<List<BrowserHistoryData>> GetChromeHistoryAsync(DateTime fromDate, CancellationToken ct)
    {
        var histories = new List<BrowserHistoryData>();
        var config = _configService.Load();
        
        var chromePaths = new[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Google\\Chrome\\User Data\\Default\\History"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Google\\Chrome\\User Data\\Profile *\\History")
        };
        
        foreach (var pattern in chromePaths)
        {
            var dir = Path.GetDirectoryName(pattern);
            if (dir != null && Directory.Exists(dir))
            {
                foreach (var path in Directory.GetFiles(dir, "History", SearchOption.AllDirectories))
                {
                    var chromeHistories = await ReadChromeHistoryAsync(path, fromDate, config, ct);
                    histories.AddRange(chromeHistories);
                }
            }
        }
        
        return histories;
    }
    
    private async Task<List<BrowserHistoryData>> ReadChromeHistoryAsync(string dbPath, DateTime fromDate, AgentConfig? config, CancellationToken ct)
    {
        var histories = new List<BrowserHistoryData>();
        
        if (!File.Exists(dbPath)) return histories;
        
        try
        {
            var tempPath = Path.GetTempFileName();
            File.Copy(dbPath, tempPath, true);
            
            // 使用SQLite读取历史记录
            using var connection = new Microsoft.Data.Sqlite.SqliteConnection($"Data Source={tempPath}");
            await connection.OpenAsync(ct);
            
            var command = connection.CreateCommand();
            command.CommandText = @"
                SELECT url, title, last_visit_time/1000000 - 11644473600 as visit_time
                FROM urls
                WHERE last_visit_time/1000000 - 11644473600 > @fromDate
                ORDER BY last_visit_time DESC
                LIMIT 500";
            command.Parameters.AddWithValue("@fromDate", new DateTimeOffset(fromDate).ToUnixTimeSeconds());
            
            using var reader = await command.ExecuteReaderAsync(ct);
            
            while (await reader.ReadAsync(ct))
            {
                var url = reader.GetString(0);
                if (string.IsNullOrEmpty(url) || url.StartsWith("chrome://") || url.StartsWith("edge://"))
                    continue;
                
                var urlKey = $"chrome_{url}_{reader.GetInt64(2)}";
                lock (_reportedLock)
                {
                    if (_reportedUrls.Contains(urlKey)) continue;
                    _reportedUrls.Add(urlKey);
                }
                
                histories.Add(new BrowserHistoryData
                {
                    EmployeeId = config?.EmployeeId ?? "",
                    ClientId = config?.ClientId ?? "",
                    Url = url,
                    Title = reader.IsDBNull(1) ? url : reader.GetString(1),
                    Browser = "chrome",
                    VisitTime = DateTimeOffset.FromUnixTimeSeconds(reader.GetInt64(2)).UtcDateTime,
                    Duration = 0,
                    ComputerName = Environment.MachineName,
                    WindowsUser = Environment.UserName
                });
            }
            
            await connection.CloseAsync();
            File.Delete(tempPath);
        }
        catch (Exception ex)
        {
            Log.Error(ex, $"读取Chrome历史失败: {dbPath}");
        }
        
        return histories;
    }
    
    private async Task<List<BrowserHistoryData>> GetEdgeHistoryAsync(DateTime fromDate, CancellationToken ct)
    {
        var histories = new List<BrowserHistoryData>();
        var config = _configService.Load();
        
        var edgePaths = new[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Microsoft\\Edge\\User Data\\Default\\History"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Microsoft\\Edge\\User Data\\Profile *\\History")
        };
        
        foreach (var pattern in edgePaths)
        {
            var dir = Path.GetDirectoryName(pattern);
            if (dir != null && Directory.Exists(dir))
            {
                foreach (var path in Directory.GetFiles(dir, "History", SearchOption.AllDirectories))
                {
                    var edgeHistories = await ReadChromeHistoryAsync(path, fromDate, config, ct);
                    foreach (var h in edgeHistories)
                        h.Browser = "edge";
                    histories.AddRange(edgeHistories);
                }
            }
        }
        
        return histories;
    }
    
    private async Task<List<BrowserHistoryData>> GetFirefoxHistoryAsync(DateTime fromDate, CancellationToken ct)
    {
        var histories = new List<BrowserHistoryData>();
        var config = _configService.Load();
        
        var firefoxProfiles = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "Mozilla\\Firefox\\Profiles");
        
        if (Directory.Exists(firefoxProfiles))
        {
            foreach (var profile in Directory.GetDirectories(firefoxProfiles))
            {
                var placesDb = Path.Combine(profile, "places.sqlite");
                if (File.Exists(placesDb))
                {
                    try
                    {
                        var tempPath = Path.GetTempFileName();
                        File.Copy(placesDb, tempPath, true);
                        
                        using var connection = new Microsoft.Data.Sqlite.SqliteConnection($"Data Source={tempPath}");
                        await connection.OpenAsync(ct);
                        
                        var command = connection.CreateCommand();
                        command.CommandText = @"
                            SELECT p.url, p.title, v.visit_date/1000000 as visit_time
                            FROM moz_places p
                            INNER JOIN moz_historyvisits v ON p.id = v.place_id
                            WHERE v.visit_date/1000000 > @fromDate
                            ORDER BY v.visit_date DESC
                            LIMIT 500";
                        command.Parameters.AddWithValue("@fromDate", new DateTimeOffset(fromDate).ToUnixTimeSeconds());
                        
                        using var reader = await command.ExecuteReaderAsync(ct);
                        
                        while (await reader.ReadAsync(ct))
                        {
                            var url = reader.GetString(0);
                            if (string.IsNullOrEmpty(url) || url.StartsWith("about:"))
                                continue;
                            
                            var urlKey = $"firefox_{url}_{reader.GetInt64(2)}";
                            lock (_reportedLock)
                            {
                                if (_reportedUrls.Contains(urlKey)) continue;
                                _reportedUrls.Add(urlKey);
                            }
                            
                            histories.Add(new BrowserHistoryData
                            {
                                EmployeeId = config?.EmployeeId ?? "",
                                ClientId = config?.ClientId ?? "",
                                Url = url,
                                Title = reader.IsDBNull(1) ? url : reader.GetString(1),
                                Browser = "firefox",
                                VisitTime = DateTimeOffset.FromUnixTimeSeconds(reader.GetInt64(2)).UtcDateTime,
                                Duration = 0,
                                ComputerName = Environment.MachineName,
                                WindowsUser = Environment.UserName
                            });
                        }
                        
                        await connection.CloseAsync();
                        File.Delete(tempPath);
                    }
                    catch (Exception ex)
                    {
                        Log.Error(ex, $"读取Firefox历史失败: {placesDb}");
                    }
                }
            }
        }
        
        return histories;
    }
}
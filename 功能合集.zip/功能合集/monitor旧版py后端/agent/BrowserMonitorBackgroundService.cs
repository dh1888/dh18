// BrowserMonitorBackgroundService.cs - 完善版
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public class BrowserMonitorBackgroundService : BackgroundService
{
    private readonly IBrowserMonitorService _browserMonitorService;
    
    public BrowserMonitorBackgroundService(IBrowserMonitorService browserMonitorService)
    {
        _browserMonitorService = browserMonitorService;
    }
    
    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _browserMonitorService.Start();
        return Task.CompletedTask;
    }
    
    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _browserMonitorService.Stop();
        await base.StopAsync(cancellationToken);
    }
}
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Microsoft.Extensions.DependencyInjection;
using WinApplication = System.Windows.Application;

namespace EnterpriseAgent;

public partial class MainWindow : Window
{
    private readonly IConfigurationService _configService;
    private readonly IHttpClientService _httpService;
    private readonly IDeviceFingerprintService _fingerprintService;
    private readonly ISecurityService _securityService;
    private readonly II18nService _i18nService;
    private bool _isConnecting;

    public MainWindow(
        IConfigurationService configService,
        IHttpClientService httpService,
        IDeviceFingerprintService fingerprintService,
        ISecurityService securityService,
        II18nService i18nService)
    {
        InitializeComponent();
        
        _configService = configService;
        _httpService = httpService;
        _fingerprintService = fingerprintService;
        _securityService = securityService;
        _i18nService = i18nService;
        
        LoadSavedConfig();
        LoadSystemInfo();
        ApplyLanguage();
        
        // 订阅语言变化
        _i18nService.LanguageChanged += OnLanguageChanged;
    }
    
    private void ApplyLanguage()
    {
        // 标题（如果需要翻译标题栏，取消注释）
        // TitleTextBlock.Text = _i18nService.GetText("config_title", "DH企业助手");
        
        // 副标题
        SubtitleTextBlock.Text = _i18nService.GetText("config_subtitle", "欢迎使用DH，首次配置需要填写一下信息：");
        
        // 表单标签 - 确保 XAML 中有对应的 x:Name
        if (NameLabel != null)
            NameLabel.Text = _i18nService.GetText("name", "姓名");
        if (ServerLabel != null)
            ServerLabel.Text = _i18nService.GetText("server_url", "服务器地址");
        if (SystemInfoLabel != null)
            SystemInfoLabel.Text = _i18nService.GetText("system_info", "系统信息");
        
        // 按钮
        ConnectButton.Content = _i18nService.GetText("connect", "连接");
        ExitButton.Content = _i18nService.GetText("exit", "退出");
        
        // 占位符文本（Tag 属性用于 Placeholder）
        NameTextBox.Tag = _i18nService.GetText("name_placeholder", "请输入您的姓名");
        ServerUrlTextBox.Tag = _i18nService.GetText("server_placeholder", "请输入服务器地址，如：https://google.com");
        
        // 系统信息动态内容（实时更新）
        ComputerNameText.Text = $"{_i18nService.GetText("computer_name", "计算机名")}: {Environment.MachineName}";
        UserNameText.Text = $"{_i18nService.GetText("user_name", "用户名")}: {Environment.UserName}";
        
        // 强制刷新占位符显示
        RefreshPlaceholder(NameTextBox);
        RefreshPlaceholder(ServerUrlTextBox);
    }
    
    /// <summary>
    /// 刷新文本框的占位符显示
    /// </summary>
    private void RefreshPlaceholder(System.Windows.Controls.TextBox textBox)
    {
        if (textBox == null) return;
        
        // 通过临时改变文本内容来触发占位符重新评估
        var temp = textBox.Text;
        textBox.Text = "";
        textBox.Text = temp;
    }
    
    private void OnLanguageChanged(string language)
    {
        Dispatcher.Invoke(ApplyLanguage);
    }
    
    private void LoadSavedConfig()
    {
        var config = _configService.Load();
        if (config != null)
        {
            NameTextBox.Text = config.Name;
            ServerUrlTextBox.Text = config.ServerUrl;
        }
        else
        {
            // 默认服务器地址为空
            ServerUrlTextBox.Text = "";
        }
    }
    
    private void LoadSystemInfo()
    {
        ComputerNameText.Text = $"{_i18nService.GetText("computer_name", "计算机名")}: {Environment.MachineName}";
        UserNameText.Text = $"{_i18nService.GetText("user_name", "用户名")}: {Environment.UserName}";
    }
    
    private void ShowStatus(string message, bool isError = false)
    {
        Dispatcher.Invoke(() =>
        {
            StatusTextBlock.Text = message;
            StatusTextBlock.Foreground = isError ? 
                (System.Windows.Media.Brush)FindResource("ErrorBrush") : 
                (System.Windows.Media.Brush)FindResource("SecondaryTextBrush");
            StatusBorder.Visibility = Visibility.Visible;
        });
    }
    
    private void HideStatus()
    {
        Dispatcher.Invoke(() =>
        {
            StatusBorder.Visibility = Visibility.Collapsed;
        });
    }
    
    private async void ConnectButton_Click(object sender, RoutedEventArgs e)
    {
        if (_isConnecting) return;
        
        var name = NameTextBox.Text?.Trim();
        var serverUrl = ServerUrlTextBox.Text?.Trim();
        
        if (string.IsNullOrEmpty(name))
        {
            ShowStatus(_i18nService.GetText("error_name_empty", "请输入姓名"), true);
            return;
        }
        
        if (string.IsNullOrEmpty(serverUrl))
        {
            ShowStatus(_i18nService.GetText("error_server_empty", "请输入服务器地址"), true);
            return;
        }
        
        if (!serverUrl.StartsWith("http://") && !serverUrl.StartsWith("https://"))
        {
            serverUrl = "https://" + serverUrl;
        }
        
        _isConnecting = true;
        ConnectButton.IsEnabled = false;
        ConnectButton.Content = _i18nService.GetText("connecting", "连接中...");
        HideStatus();
        
        try
        {
            // 1. 检查网络连接
            ShowStatus(_i18nService.GetText("checking_network", "正在检查网络..."));
            await Task.Delay(100);
            
            // 2. 获取设备指纹
            ShowStatus(_i18nService.GetText("getting_fingerprint", "正在获取设备指纹..."));
            var fingerprint = await _fingerprintService.GetFingerprintAsync();
            
            // 3. 注册客户端
            ShowStatus(_i18nService.GetText("registering", "正在注册客户端..."));
            var registerResult = await _httpService.RegisterClientAsync(name, fingerprint, serverUrl);
            
            if (registerResult.Success)
            {
                // 4. 保存配置
                var config = new AgentConfig
                {
                    Name = name,
                    ServerUrl = serverUrl,
                    ClientId = registerResult.ClientId,
                    EmployeeId = registerResult.EmployeeId,
                    Token = registerResult.Token,
                    HardwareFingerprint = fingerprint.Hash,
                    ComputerName = Environment.MachineName,
                    WindowsUser = Environment.UserName,
                    RegisteredAt = DateTime.UtcNow,
                    Version = "1.0.0"
                };
                
                _configService.Save(config);
                
                ShowStatus(_i18nService.GetText("register_success", "注册成功！"), false);
                await Task.Delay(500);
                
                // 5. 关闭窗口
                DialogResult = true;
                Close();
            }
            else
            {
                ShowStatus(registerResult.ErrorMessage ?? _i18nService.GetText("register_failed", "注册失败"), true);
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "连接失败");
            // 修复：使用字符串插值，修正语法
            ShowStatus($"{_i18nService.GetText("connect_failed", "连接失败")}: {ex.Message}", true);
        }
        finally
        {
            _isConnecting = false;
            ConnectButton.IsEnabled = true;
            ConnectButton.Content = _i18nService.GetText("connect", "连接");
        }
    }
    
    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
    
    private void ExitButton_Click(object sender, RoutedEventArgs e)
    {
        Environment.Exit(0);
    }
    
    private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed)
        {
            DragMove();
        }
    }
}
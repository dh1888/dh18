using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Channels;
using System.Windows.Forms;

namespace EnterpriseAgent;

public interface IScreenshotCaptureService
{
    Task<ScreenshotData?> CaptureAsync(CancellationToken ct = default);
    void Start();
    void Stop();
    event EventHandler<ScreenshotData>? ScreenshotCaptured;
}

public class ScreenshotCaptureService : IScreenshotCaptureService, IDisposable
{
    private readonly IConfigurationService _configService;
    private readonly IHttpClientService _httpService;
    private readonly IPerceptualHashService _phashService;
    private readonly IWebSocketService _webSocketService;
    private readonly IBatchUploadService _batchService;      // 新增：批量上传服务
    private readonly IWebPEncoder _webpEncoder;               // 新增：WebP编码器
    private readonly Channel<ScreenshotData> _captureChannel;
    private CancellationTokenSource? _cts;
    private Task? _captureLoopTask;
    private Task? _uploadLoopTask;
    private int _isRunning;
    private string? _lastScreenshotPath;
    private DateTime _lastCaptureTime;
    private readonly int _minInterval = 3;
    
    public event EventHandler<ScreenshotData>? ScreenshotCaptured;
    
    // 修改构造函数，注入所有依赖
    public ScreenshotCaptureService(
        IConfigurationService configService,
        IHttpClientService httpService,
        IPerceptualHashService phashService,
        IWebSocketService webSocketService,
        IBatchUploadService batchService,      // 新增参数
        IWebPEncoder webpEncoder)              // 新增参数
    {
        _configService = configService;
        _httpService = httpService;
        _phashService = phashService;
        _webSocketService = webSocketService;
        _batchService = batchService;          // 保存引用
        _webpEncoder = webpEncoder;            // 保存引用
        _captureChannel = Channel.CreateBounded<ScreenshotData>(new BoundedChannelOptions(100)
        {
            FullMode = BoundedChannelFullMode.DropOldest
        });
    }
    
    public void Start()
    {
        if (Interlocked.Exchange(ref _isRunning, 1) == 1)
            return;
        
        _cts = new CancellationTokenSource();
        _captureLoopTask = Task.Run(CaptureLoopAsync);
        _uploadLoopTask = Task.Run(UploadLoopAsync);
        
        Log.Information("✅ 截图服务已启动");
    }
    
    public void Stop()
    {
        if (Interlocked.Exchange(ref _isRunning, 0) == 0)
            return;
        
        _cts?.Cancel();
        _captureChannel.Writer.TryComplete();
        
        Log.Information("截图服务已停止");
    }
    
    public async Task<ScreenshotData?> CaptureAsync(CancellationToken ct = default)
    {
        try
        {
            var config = _configService.Load();
            if (config == null) return null;
            
            // 频率限制
            var now = DateTime.UtcNow;
            if ((now - _lastCaptureTime).TotalSeconds < _minInterval)
            {
                Log.Debug("截图太频繁，跳过");
                return null;
            }
            
            // 获取所有屏幕
            var screens = Screen.AllScreens;
            if (screens.Length == 0) return null;
            
            // 计算总边界
            int minX = int.MaxValue, minY = int.MaxValue;
            int maxX = int.MinValue, maxY = int.MinValue;
            
            foreach (var screen in screens)
            {
                var bounds = screen.Bounds;
                minX = Math.Min(minX, bounds.X);
                minY = Math.Min(minY, bounds.Y);
                maxX = Math.Max(maxX, bounds.Right);
                maxY = Math.Max(maxY, bounds.Bottom);
            }
            
            int width = maxX - minX;
            int height = maxY - minY;
            
            using var bitmap = new Bitmap(width, height);
            using var graphics = Graphics.FromImage(bitmap);
            graphics.CopyFromScreen(minX, minY, 0, 0, new Size(width, height));
            
            // 转换格式
            var format = config.ScreenshotFormat.ToLower();
            var quality = config.ScreenshotQuality;
            
            byte[] imageData;
            
            if (format == "webp")
            {
                imageData = ConvertToWebP(bitmap, quality);
            }
            else
            {
                var codec = GetEncoder(ImageFormat.Jpeg);
                var encoderParams = new EncoderParameters(1);
                encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, quality);
                
                using var ms = new MemoryStream();
                bitmap.Save(ms, codec, encoderParams);
                imageData = ms.ToArray();
            }
            
            _lastCaptureTime = DateTime.UtcNow;
            
            var screenshot = new ScreenshotData
            {
                EmployeeId = config.EmployeeId,
                ClientId = config.ClientId,
                ComputerName = Environment.MachineName,
                WindowsUser = Environment.UserName,
                Timestamp = DateTime.UtcNow,
                Format = format,
                Data = imageData,
                Encrypted = false
            };
            
            // 相似度检测
            if (!string.IsNullOrEmpty(_lastScreenshotPath))
            {
                var tempPath = Path.GetTempFileName();
                await File.WriteAllBytesAsync(tempPath, imageData, ct);
                
                if (_phashService.AreSimilar(_lastScreenshotPath, tempPath))
                {
                    Log.Debug("屏幕内容无变化，跳过截图");
                    File.Delete(tempPath);
                    return null;
                }
                
                File.Delete(tempPath);
            }
            
            // 保存临时文件用于下次比较
            _lastScreenshotPath = Path.GetTempFileName();
            await File.WriteAllBytesAsync(_lastScreenshotPath, imageData, ct);
            
            Log.Information($"📸 截图成功: {imageData.Length / 1024}KB");
            
            // ========== WebSocket 实时推送 ==========
            await PushToWebSocketAsync(screenshot);
            
            // ========== 加入批量队列（用于历史存储）==========
            _batchService.EnqueueScreenshot(screenshot);
            
            return screenshot;
        }
        catch (Exception ex)
        {
            Log.Error(ex, "截图失败");
            return null;
        }
    }
    
    // ========== WebSocket 实时推送方法 ==========
    private async Task PushToWebSocketAsync(ScreenshotData screenshot)
    {
        try
        {
            // 检查 WebSocket 是否已连接
            if (!_webSocketService.IsConnected)
            {
                Log.Debug("WebSocket 未连接，跳过实时推送");
                return;
            }
            
            // 转换为 Base64 字符串（WebSocket 传输）
            var base64Data = Convert.ToBase64String(screenshot.Data);
            
            var message = new
            {
                type = "screenshot",
                data = base64Data,
                timestamp = screenshot.Timestamp.ToString("yyyy-MM-dd HH:mm:ss"),
                timestamp_raw = screenshot.Timestamp.Ticks,
                format = screenshot.Format,
                employee_id = screenshot.EmployeeId,
                client_id = screenshot.ClientId,
                computer_name = screenshot.ComputerName,
                windows_user = screenshot.WindowsUser,
                size_kb = screenshot.Data.Length / 1024
            };
            
            var json = JsonSerializer.Serialize(message);
            
            // 通过 WebSocket 发送
            await _webSocketService.SendAsync(json);
            
            Log.Debug($"📡 实时推送截图: {screenshot.Timestamp:HH:mm:ss}, {screenshot.Data.Length / 1024}KB");
        }
        catch (Exception ex)
        {
            Log.Error(ex, "WebSocket 推送截图失败");
        }
    }
    
    private async Task CaptureLoopAsync()
    {
        var config = _configService.Load();
        var interval = config?.ScreenshotInterval ?? 60;
        
        while (!_cts?.IsCancellationRequested == true)
        {
            try
            {
                var screenshot = await CaptureAsync(_cts!.Token);
                if (screenshot != null)
                {
                    ScreenshotCaptured?.Invoke(this, screenshot);
                    await _captureChannel.Writer.WriteAsync(screenshot, _cts.Token);
                }
                
                await Task.Delay(interval * 1000, _cts.Token);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "截图循环异常");
                await Task.Delay(5000, _cts!.Token);
            }
        }
    }
    
    private async Task UploadLoopAsync()
    {
        var reader = _captureChannel.Reader;
        
        while (await reader.WaitToReadAsync())
        {
            while (reader.TryRead(out var screenshot))
            {
                try
                {
                    var success = await _httpService.UploadScreenshotAsync(screenshot);
                    if (!success)
                    {
                        Log.Warning("截图上传失败，将重试");
                        await Task.Delay(5000);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "上传截图异常");
                }
            }
        }
    }
    
    // ========== 修改：使用真正的 WebP 编码 ==========
    private byte[] ConvertToWebP(Bitmap bitmap, int quality)
    {
        try
        {
            // 使用真正的 WebP 编码器
            if (_webpEncoder.IsAvailable)
            {
                return _webpEncoder.Encode(bitmap, quality);
            }
            
            // 降级到 JPEG
            Log.Warning("WebP 编码器不可用，降级到 JPEG");
            using var ms = new MemoryStream();
            var codec = GetEncoder(ImageFormat.Jpeg);
            var encoderParams = new EncoderParameters(1);
            encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, quality);
            bitmap.Save(ms, codec, encoderParams);
            return ms.ToArray();
        }
        catch (Exception ex)
        {
            Log.Error(ex, "WebP 编码失败，降级到 JPEG");
            // 降级到 JPEG
            using var ms = new MemoryStream();
            var codec = GetEncoder(ImageFormat.Jpeg);
            var encoderParams = new EncoderParameters(1);
            encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, quality);
            bitmap.Save(ms, codec, encoderParams);
            return ms.ToArray();
        }
    }
    
    private ImageCodecInfo GetEncoder(ImageFormat format)
    {
        var codecs = ImageCodecInfo.GetImageEncoders();
        foreach (var codec in codecs)
        {
            if (codec.FormatID == format.Guid)
                return codec;
        }
        return codecs[0];
    }
    
    public void Dispose()
    {
        _cts?.Dispose();
        if (!string.IsNullOrEmpty(_lastScreenshotPath) && File.Exists(_lastScreenshotPath))
            File.Delete(_lastScreenshotPath);
    }
}

public interface IPerceptualHashService
{
    bool AreSimilar(string imagePath1, string imagePath2, int threshold = 95);
}

public class PerceptualHashService : IPerceptualHashService
{
    public bool AreSimilar(string imagePath1, string imagePath2, int threshold = 95)
    {
        try
        {
            using var img1 = new Bitmap(imagePath1);
            using var img2 = new Bitmap(imagePath2);
            
            // 简化的相似度检测：比较哈希
            var hash1 = GetAverageHash(img1);
            var hash2 = GetAverageHash(img2);
            
            var similarity = GetSimilarity(hash1, hash2);
            return similarity >= threshold;
        }
        catch
        {
            return false;
        }
    }
    
    private string GetAverageHash(Bitmap bitmap)
    {
        var resized = new Bitmap(bitmap, new Size(16, 16));
        var gray = new Bitmap(16, 16);
        
        using var g = Graphics.FromImage(gray);
        var colorMatrix = new ColorMatrix(new float[][]
        {
            new float[] { 0.299f, 0.299f, 0.299f, 0, 0 },
            new float[] { 0.587f, 0.587f, 0.587f, 0, 0 },
            new float[] { 0.114f, 0.114f, 0.114f, 0, 0 },
            new float[] { 0, 0, 0, 1, 0 },
            new float[] { 0, 0, 0, 0, 1 }
        });
        
        var attributes = new ImageAttributes();
        attributes.SetColorMatrix(colorMatrix);
        g.DrawImage(resized, new Rectangle(0, 0, 16, 16), 0, 0, 16, 16, GraphicsUnit.Pixel, attributes);
        
        var hash = new System.Text.StringBuilder();
        var total = 0L;
        var pixels = new byte[256];
        
        for (int y = 0; y < 16; y++)
        {
            for (int x = 0; x < 16; x++)
            {
                var pixel = gray.GetPixel(x, y);
                var brightness = (byte)((pixel.R + pixel.G + pixel.B) / 3);
                pixels[y * 16 + x] = brightness;
                total += brightness;
            }
        }
        
        var avg = total / 256;
        
        for (int i = 0; i < 256; i++)
        {
            hash.Append(pixels[i] >= avg ? '1' : '0');
        }
        
        resized.Dispose();
        gray.Dispose();
        
        return hash.ToString();
    }
    
    private int GetSimilarity(string hash1, string hash2)
    {
        if (hash1.Length != hash2.Length) return 0;
        
        var same = 0;
        for (int i = 0; i < hash1.Length; i++)
        {
            if (hash1[i] == hash2[i]) same++;
        }
        
        return (int)((double)same / hash1.Length * 100);
    }
}
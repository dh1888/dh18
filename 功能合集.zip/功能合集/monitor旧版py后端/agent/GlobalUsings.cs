global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Threading;
global using System.Threading.Tasks;
global using Microsoft.Extensions.Logging;
global using Microsoft.Extensions.Hosting;
global using System.Drawing;
global using System.Drawing.Imaging;
global using System.IO;
global using System.Net.Http;
global using System.Windows.Forms;

// 解决 Timer 歧义问题：明确使用 System.Threading.Timer
global using Timer = System.Threading.Timer;
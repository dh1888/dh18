using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace EnterpriseAgent;

public interface IBatchUploadService
{
    void EnqueueScreenshot(ScreenshotData screenshot);
    void Start();
    void Stop();
    BatchUploadStats GetStats();
}

public class BatchUploadStats
{
    public int QueueSize { get; set; }
    public int TotalEnqueued { get; set; }
    public int TotalUploaded { get; set; }
    public int TotalFailed { get; set; }
    public int BatchSize { get; set; } = 20;
    public int FlushIntervalSeconds { get; set; } = 30;
    public long CacheSizeMB { get; set; }
    public int CacheCount { get; set; }
}

public class BatchUploadService : IBatchUploadService, IDisposable
{
    private readonly IHttpClientService _httpService;
    private readonly ILocalCacheService _cacheService;
    private readonly IConfigurationService _configService;
    private readonly List<ScreenshotData> _batch;
    private readonly object _lock = new();
    private Timer? _flushTimer;
    private bool _isRunning;
    private BatchUploadStats _stats = new();
    private readonly JsonSerializerOptions _jsonOptions;

    public BatchUploadService(
        IHttpClientService httpService,
        ILocalCacheService cacheService,
        IConfigurationService configService)
    {
        _httpService = httpService;
        _cacheService = cacheService;
        _configService = configService;
        _batch = new List<ScreenshotData>();
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };
    }

    public void EnqueueScreenshot(ScreenshotData screenshot)
    {
        lock (_lock)
        {
            _batch.Add(screenshot);
            _stats.TotalEnqueued++;
            _stats.QueueSize = _batch.Count;
            
            Log.Debug($"截图入队: {_batch.Count}/{_stats.BatchSize}");
            
            // 达到批量大小立即触发上传
            if (_batch.Count >= _stats.BatchSize)
            {
                var batchToUpload = _batch.ToList();
                _batch.Clear();
                _stats.QueueSize = 0;
                Task.Run(() => UploadBatchAsync(batchToUpload));
            }
        }
    }

    public void Start()
    {
        if (_isRunning) return;
        _isRunning = true;
        
        _flushTimer = new Timer(FlushCallback, null, 
            TimeSpan.FromSeconds(_stats.FlushIntervalSeconds), 
            TimeSpan.FromSeconds(_stats.FlushIntervalSeconds));
        
        // 加载缓存的待上传数据
        Task.Run(LoadCachedBatchesAsync);
        
        Log.Information("✅ 批量上传服务已启动");
        Log.Information($"   批量大小: {_stats.BatchSize}, 刷新间隔: {_stats.FlushIntervalSeconds}秒");
    }

    public void Stop()
    {
        _isRunning = false;
        _flushTimer?.Dispose();
        
        // 刷新所有待上传数据
        FlushAllBatches();
        
        Log.Information("批量上传服务已停止");
    }

    private void FlushCallback(object? state)
    {
        if (!_isRunning) return;
        FlushAllBatches();
    }

    private void FlushAllBatches()
    {
        List<ScreenshotData> batchToUpload;
        lock (_lock)
        {
            if (_batch.Count == 0) return;
            batchToUpload = _batch.ToList();
            _batch.Clear();
            _stats.QueueSize = 0;
        }
        
        if (batchToUpload.Count > 0)
        {
            Task.Run(() => UploadBatchAsync(batchToUpload));
        }
    }

    private async Task UploadBatchAsync(List<ScreenshotData> screenshots)
    {
        try
        {
            var config = _configService.Load();
            if (config == null)
            {
                Log.Warning("配置未加载，批量上传失败");
                await CacheBatchAsync(screenshots);
                return;
            }
            
            // 创建ZIP文件
            using var ms = new MemoryStream();
            using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
            {
                foreach (var screenshot in screenshots)
                {
                    var fileName = $"screenshot_{screenshot.Timestamp:yyyyMMdd_HHmmss}.{screenshot.Format}";
                    var entry = zip.CreateEntry(fileName);
                    using var entryStream = entry.Open();
                    await entryStream.WriteAsync(screenshot.Data);
                }
            }
            
            // 创建multipart表单 - 与Python客户端格式一致
            using var form = new MultipartFormDataContent();
            form.Add(new StringContent(config.EmployeeId), "employee_id");
            form.Add(new StringContent(config.ClientId), "client_id");
            form.Add(new StringContent(Environment.MachineName), "computer_name");
            form.Add(new StringContent(Environment.UserName), "windows_user");
            form.Add(new StringContent(screenshots.Count.ToString()), "count");
            form.Add(new ByteArrayContent(ms.ToArray()), "batch", "screenshots.zip");
            
            // 发送请求
            using var client = new HttpClient();
            client.Timeout = TimeSpan.FromSeconds(60);
            var serverUrl = config.ServerUrl;
            if (!serverUrl.EndsWith("/")) serverUrl += "/";
            
            var response = await client.PostAsync($"{serverUrl}api/upload/batch", form);
            
            if (response.IsSuccessStatusCode)
            {
                _stats.TotalUploaded += screenshots.Count;
                Log.Information($"📦 批量上传成功: {screenshots.Count} 张截图");
            }
            else
            {
                var error = await response.Content.ReadAsStringAsync();
                Log.Warning($"批量上传失败: HTTP {response.StatusCode}, {error}");
                await CacheBatchAsync(screenshots);
                _stats.TotalFailed += screenshots.Count;
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, $"批量上传异常: {ex.Message}");
            await CacheBatchAsync(screenshots);
            _stats.TotalFailed += screenshots.Count;
        }
    }

    private async Task CacheBatchAsync(List<ScreenshotData> screenshots)
    {
        var cacheKey = $"batch_{DateTime.UtcNow:yyyyMMdd_HHmmss}_{Guid.NewGuid():N}";
        await _cacheService.SaveAsync(cacheKey, screenshots, TimeSpan.FromDays(7));
        Log.Warning($"💾 批量上传失败，已缓存: {screenshots.Count} 张截图");
    }

    private async Task LoadCachedBatchesAsync()
    {
        try
        {
            var keys = await _cacheService.GetAllKeysAsync();
            var batchKeys = keys.Where(k => k.StartsWith("batch_")).ToList();
            
            if (batchKeys.Count == 0) return;
            
            Log.Information($"📂 发现 {batchKeys.Count} 个缓存批次，正在恢复...");
            
            foreach (var key in batchKeys)
            {
                var screenshots = await _cacheService.GetAsync<List<ScreenshotData>>(key);
                if (screenshots != null && screenshots.Count > 0)
                {
                    await UploadBatchAsync(screenshots);
                    await _cacheService.DeleteAsync(key);
                }
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "加载缓存批次失败");
        }
    }

    public BatchUploadStats GetStats()
    {
        lock (_lock)
        {
            _stats.QueueSize = _batch.Count;
        }
        _stats.CacheSizeMB = _cacheService.GetCacheSize() / 1024 / 1024;
        _stats.CacheCount = _cacheService.GetCacheCount();
        return _stats;
    }

    public void Dispose()
    {
        Stop();
        _flushTimer?.Dispose();
    }
}
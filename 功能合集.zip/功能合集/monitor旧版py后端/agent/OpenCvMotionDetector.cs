using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using OpenCvSharp;

namespace EnterpriseAgent;

/// <summary>
/// 基于 OpenCV 的高精度运动检测器
/// </summary>
public class OpenCvMotionDetector : IDisposable
{
    private Mat? _previousFrame;
    private Mat? _previousGray;
    private readonly BackgroundSubtractorMOG2? _bgSubtractor;
    private readonly int _minArea = 500;
    private readonly double _changeThreshold = 0.05;
    private bool _disposed;
    
    // 复用 Mat 对象（避免 GC）
    private Mat _diff = new();
    private Mat _thresh = new();
    private Mat _fgMask = new();
    private Mat _kernel;
    
    // 性能统计
    private int _frameCount;
    private double _avgDetectionTime;
    
    public OpenCvMotionDetector(int minArea = 500, double changeThreshold = 0.05)
    {
        _minArea = minArea;
        _changeThreshold = changeThreshold;
        
        // MOG2 背景减除器（更好的运动检测）
        _bgSubtractor = BackgroundSubtractorMOG2.Create(
            history: 500,
            varThreshold: 16,
            detectShadows: true
        );
        
        // 形态学核（用于去噪和合并）
        _kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new OpenCvSharp.Size(5, 5));
        
        Log.Information("✅ OpenCV 运动检测器已初始化");
    }
    
    /// <summary>
    /// 检测运动（混合方法：背景减除 + 帧差法）
    /// </summary>
    public MotionDetectionResult Detect(Bitmap currentFrame)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var result = new MotionDetectionResult();
        
        try
        {
            using var currentMat = BitmapToMat(currentFrame);
            using var gray = new Mat();
            Cv2.CvtColor(currentMat, gray, ColorConversionCodes.BGR2GRAY);
            
            // ========== 1. 背景减除（检测运动物体）==========
            if (_bgSubtractor != null)
            {
                _bgSubtractor.Apply(gray, _fgMask);
                
                // 形态学操作：开运算去噪 + 膨胀合并
                Cv2.MorphologyEx(_fgMask, _fgMask, MorphTypes.Open, _kernel);
                Cv2.Dilate(_fgMask, _fgMask, _kernel);
                
                // 查找运动区域
                var motionRegions = FindContours(_fgMask, currentMat.Width, currentMat.Height);
                result.MotionRegions = motionRegions;
            }
            
            // ========== 2. 帧差法（检测整体变化）==========
            if (_previousGray != null)
            {
                // 计算帧差
                Cv2.Absdiff(gray, _previousGray, _diff);
                Cv2.Threshold(_diff, _thresh, 25, 255, ThresholdTypes.Binary);
                Cv2.MorphologyEx(_thresh, _thresh, MorphTypes.Open, _kernel);
                
                // 计算变化率
                int changedPixels = Cv2.CountNonZero(_thresh);
                int totalPixels = gray.Width * gray.Height;
                result.ChangeRatio = (double)changedPixels / totalPixels;
                
                // 检测变化区域
                var changeRegions = FindContours(_thresh, currentMat.Width, currentMat.Height);
                result.ChangedRegions = changeRegions;
            }
            else
            {
                result.ChangeRatio = 1.0;
            }
            
            // ========== 3. 智能帧类型决策 ==========
            // 完整帧：变化大 或 首次
            result.ShouldSendFullFrame = result.ChangeRatio > 0.3 || _previousGray == null;
            
            // 区域帧：变化小但有运动区域
            result.ShouldSendRegionFrame = !result.ShouldSendFullFrame && 
                                           result.ChangeRatio <= 0.1 && 
                                           result.MotionRegions.Count > 0 &&
                                           result.MotionRegions.Count <= 10;
            
            // 差异帧：中等变化
            result.ShouldSendDiffFrame = !result.ShouldSendFullFrame && 
                                         !result.ShouldSendRegionFrame &&
                                         result.ChangeRatio > 0.02;
            
            // ========== 4. 合并区域（避免过多小区域）==========
            if (result.ShouldSendRegionFrame || result.ShouldSendDiffFrame)
            {
                result.RegionsToSend = result.ShouldSendRegionFrame ? 
                    result.MotionRegions : result.ChangedRegions;
                result.RegionsToSend = MergeRegions(result.RegionsToSend);
            }
            
            // 更新历史帧
            _previousFrame?.Dispose();
            _previousFrame = currentMat.Clone();
            
            _previousGray?.Dispose();
            _previousGray = gray.Clone();
            
            // 更新统计
            _frameCount++;
            _avgDetectionTime = (_avgDetectionTime * (_frameCount - 1) + sw.ElapsedMilliseconds) / _frameCount;
            
            if (_frameCount % 100 == 0)
            {
                Log.Debug($"OpenCV 检测: 平均耗时={_avgDetectionTime:F1}ms, 变化率={result.ChangeRatio:P1}");
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "OpenCV 运动检测失败");
            result.ChangeRatio = 1.0;
            result.ShouldSendFullFrame = true;
        }
        
        sw.Stop();
        result.DetectionTimeMs = sw.ElapsedMilliseconds;
        
        return result;
    }
    
    private List<Rectangle> FindContours(Mat binaryImage, int originalWidth, int originalHeight)
    {
        var regions = new List<Rectangle>();
        
        Cv2.FindContours(binaryImage, out var contours, out _, 
            RetrievalModes.External, ContourApproximationModes.ApproxSimple);
        
        foreach (var contour in contours)
        {
            var rect = Cv2.BoundingRect(contour);
            int area = rect.Width * rect.Height;
            
            if (area >= _minArea)
            {
                // 添加边距，避免边缘切割
                int padding = Math.Min(20, Math.Min(rect.Width, rect.Height) / 4);
                var paddedRect = new Rectangle(
                    Math.Max(0, rect.X - padding),
                    Math.Max(0, rect.Y - padding),
                    Math.Min(originalWidth - rect.X, rect.Width + padding * 2),
                    Math.Min(originalHeight - rect.Y, rect.Height + padding * 2)
                );
                regions.Add(paddedRect);
            }
        }
        
        return regions;
    }
    
    private List<Rectangle> MergeRegions(List<Rectangle> regions)
    {
        if (regions.Count <= 1) return regions;
        
        var merged = new List<Rectangle>();
        var sorted = regions.OrderBy(r => r.X).ThenBy(r => r.Y).ToList();
        
        var current = sorted[0];
        for (int i = 1; i < sorted.Count; i++)
        {
            var next = sorted[i];
            
            // 检查是否重叠或相邻
            if (current.X + current.Width >= next.X - 30 &&
                current.Y + current.Height >= next.Y - 30)
            {
                int newX = Math.Min(current.X, next.X);
                int newY = Math.Min(current.Y, next.Y);
                int newWidth = Math.Max(current.X + current.Width, next.X + next.Width) - newX;
                int newHeight = Math.Max(current.Y + current.Height, next.Y + next.Height) - newY;
                current = new Rectangle(newX, newY, newWidth, newHeight);
            }
            else
            {
                merged.Add(current);
                current = next;
            }
        }
        merged.Add(current);
        
        // 限制最大区域数量
        return merged.Take(20).ToList();
    }
    
    private Mat BitmapToMat(Bitmap bitmap)
    {
        var data = bitmap.LockBits(
            new Rectangle(0, 0, bitmap.Width, bitmap.Height),
            System.Drawing.Imaging.ImageLockMode.ReadOnly,
            System.Drawing.Imaging.PixelFormat.Format24bppRgb);
        
        var mat = new Mat(bitmap.Height, bitmap.Width, MatType.CV_8UC3, data.Scan0, data.Stride);
        var clone = mat.Clone();
        bitmap.UnlockBits(data);
        
        return clone;
    }
    
    public void Reset()
    {
        _previousFrame?.Dispose();
        _previousFrame = null;
        _previousGray?.Dispose();
        _previousGray = null;
        // _bgSubtractor?.Apply(null, null);
    }
    
    public void Dispose()
    {
        if (_disposed) return;
        
        _previousFrame?.Dispose();
        _previousGray?.Dispose();
        _diff?.Dispose();
        _thresh?.Dispose();
        _fgMask?.Dispose();
        _kernel?.Dispose();
        _bgSubtractor?.Dispose();
        
        _disposed = true;
    }
}

/// <summary>
/// 运动检测结果
/// </summary>
public class MotionDetectionResult
{
    public List<Rectangle> MotionRegions { get; set; } = new();
    public List<Rectangle> ChangedRegions { get; set; } = new();
    public List<Rectangle> RegionsToSend { get; set; } = new();
    public double ChangeRatio { get; set; }
    public bool ShouldSendFullFrame { get; set; }
    public bool ShouldSendDiffFrame { get; set; }
    public bool ShouldSendRegionFrame { get; set; }
    public long DetectionTimeMs { get; set; }
}
using System;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public interface IHeartbeatService
{
    void Start();
    void Stop();
    HeartbeatStats GetStats();
}

public class HeartbeatStats
{
    public int HeartbeatCount { get; set; }
    public int SuccessCount { get; set; }
    public int FailureCount { get; set; }
    public double LastLatencyMs { get; set; }
    public double AvgLatencyMs { get; set; }
    public DateTime LastHeartbeatTime { get; set; }
    public DateTime LastSuccessTime { get; set; }
}

public class HeartbeatService : IHeartbeatService, IHostedService
{
    private readonly IConfigurationService _configService;
    private readonly IHttpClientService _httpService;
    private readonly IWebSocketService _webSocketService;
    private readonly IPowerManagerService _powerManager;
    private CancellationTokenSource? _cts;
    private Task? _heartbeatTask;
    private int _isRunning;
    private HeartbeatStats _stats = new();
    private readonly object _statsLock = new();
    
    public HeartbeatService(
        IConfigurationService configService,
        IHttpClientService httpService,
        IWebSocketService webSocketService,
        IPowerManagerService powerManager)
    {
        _configService = configService;
        _httpService = httpService;
        _webSocketService = webSocketService;
        _powerManager = powerManager;
    }
    
    public void Start()
    {
        if (Interlocked.Exchange(ref _isRunning, 1) == 1)
            return;
        
        _cts = new CancellationTokenSource();
        _heartbeatTask = Task.Run(HeartbeatLoopAsync);
        
        Log.Information("✅ 心跳服务已启动");
    }
    
    public void Stop()
    {
        if (Interlocked.Exchange(ref _isRunning, 0) == 0)
            return;
        
        _cts?.Cancel();
        
        Log.Information("心跳服务已停止");
    }
    
    public HeartbeatStats GetStats()
    {
        lock (_statsLock)
        {
            return new HeartbeatStats
            {
                HeartbeatCount = _stats.HeartbeatCount,
                SuccessCount = _stats.SuccessCount,
                FailureCount = _stats.FailureCount,
                LastLatencyMs = _stats.LastLatencyMs,
                AvgLatencyMs = _stats.AvgLatencyMs,
                LastHeartbeatTime = _stats.LastHeartbeatTime,
                LastSuccessTime = _stats.LastSuccessTime
            };
        }
    }
    
    private async Task HeartbeatLoopAsync()
    {
        var consecutiveFailures = 0;
        
        while (!_cts?.IsCancellationRequested == true)
        {
            try
            {
                var config = _configService.Load();
                if (config == null || string.IsNullOrEmpty(config.ClientId))
                {
                    await Task.Delay(5000, _cts!.Token);
                    continue;
                }
                
                var startTime = DateTime.UtcNow;
                
                var heartbeat = new HeartbeatData
                {
                    Status = "online",
                    Stats = GetSystemStats(),
                    Paused = false,
                    IpAddress = GetLocalIpAddress(),
                    Timestamp = DateTime.UtcNow
                };
                
                // 发送HTTP心跳
                var success = await _httpService.SendHeartbeatAsync(heartbeat);
                var latency = (DateTime.UtcNow - startTime).TotalMilliseconds;
                
                lock (_statsLock)
                {
                    _stats.HeartbeatCount++;
                    _stats.LastHeartbeatTime = DateTime.UtcNow;
                    _stats.LastLatencyMs = latency;
                    
                    if (success)
                    {
                        _stats.SuccessCount++;
                        _stats.LastSuccessTime = DateTime.UtcNow;
                        consecutiveFailures = 0;
                        
                        // 更新平均延迟
                        if (_stats.AvgLatencyMs == 0)
                            _stats.AvgLatencyMs = latency;
                        else
                            _stats.AvgLatencyMs = _stats.AvgLatencyMs * 0.9 + latency * 0.1;
                    }
                    else
                    {
                        _stats.FailureCount++;
                        consecutiveFailures++;
                    }
                }
                
                if (success)
                {
                    Log.Debug($"❤️ 心跳成功 (延迟: {latency:F0}ms)");
                }
                else if (consecutiveFailures > 3)
                {
                    Log.Warning($"⚠️ 心跳连续失败 {consecutiveFailures} 次");
                }
                
                // 如果WebSocket已连接，也发送WebSocket心跳
                if (_webSocketService.IsConnected)
                {
                    var wsHeartbeat = new Dictionary<string, object>
                    {
                        ["type"] = "heartbeat",
                        ["timestamp"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
                        ["client_id"] = config.ClientId,
                        ["stats"] = GetSystemStats()
                    };
                    await _webSocketService.SendAsync(System.Text.Json.JsonSerializer.Serialize(wsHeartbeat));
                }
                
                // 动态调整心跳间隔（根据功耗模式）
                var interval = _powerManager.IsPowerSavingMode ? 60000 : 30000;
                await Task.Delay(interval, _cts!.Token);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "心跳发送失败");
                await Task.Delay(30000, _cts!.Token);
            }
        }
    }
    
    private Dictionary<string, object> GetSystemStats()
    {
        var stats = new Dictionary<string, object>();
        
        try
        {
            using var process = Process.GetCurrentProcess();
            
            // CPU使用率
            var cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            stats["cpu"] = Math.Round(cpuCounter.NextValue(), 1);
            
            // 内存使用率
            var memCounter = new PerformanceCounter("Memory", "% Committed Bytes In Use");
            stats["memory"] = Math.Round(memCounter.NextValue(), 1);
            
            // 进程内存
            stats["process_memory_mb"] = Math.Round(process.WorkingSet64 / (1024.0 * 1024), 1);
            
            // 运行时间
            stats["uptime_seconds"] = (int)(DateTime.UtcNow - process.StartTime.ToUniversalTime()).TotalSeconds;
            
            // 线程数
            stats["thread_count"] = process.Threads.Count;
            
            // 句柄数
            stats["handle_count"] = process.HandleCount;
            
            // 功耗状态
            stats["power_saving"] = _powerManager.IsPowerSavingMode;
            stats["idle_mode"] = _powerManager.IsIdleMode;
            stats["battery_mode"] = _powerManager.IsBatteryMode;
            stats["current_interval"] = _powerManager.GetCurrentInterval();
        }
        catch (Exception ex)
        {
            Log.Debug(ex, "获取系统统计失败");
        }
        
        return stats;
    }
    
    private string GetLocalIpAddress()
    {
        try
        {
            foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus == OperationalStatus.Up &&
                    ni.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                {
                    var ipProps = ni.GetIPProperties();
                    foreach (var addr in ipProps.UnicastAddresses)
                    {
                        if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            return addr.Address.ToString();
                        }
                    }
                }
            }
        }
        catch { }
        
        return "unknown";
    }
    
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
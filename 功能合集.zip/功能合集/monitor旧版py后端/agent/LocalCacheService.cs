using System;
using System.Collections.Concurrent;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace EnterpriseAgent;

public interface ILocalCacheService : IDisposable
{
    Task SaveAsync<T>(string key, T data, TimeSpan? expiration = null);
    Task<T?> GetAsync<T>(string key);
    Task DeleteAsync(string key);
    Task<List<string>> GetAllKeysAsync();
    Task CleanupExpiredAsync();
    long GetCacheSize();
    int GetCacheCount();
}

public class LocalCacheService : ILocalCacheService
{
    private readonly string _cacheDirectory;
    private readonly string _metadataFile;
    private readonly ConcurrentDictionary<string, CacheEntryMetadata> _metadata;
    private readonly SemaphoreSlim _fileLock = new(1, 1);
    private readonly SemaphoreSlim _metadataLock = new(1, 1);
    private Timer? _cleanupTimer;
    private bool _disposed;
    private readonly JsonSerializerOptions _jsonOptions;

    private class CacheEntryMetadata
    {
        public string Key { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public long CompressedSize { get; set; }
        public long OriginalSize { get; set; }
        public int RetryCount { get; set; }
        public string? Endpoint { get; set; }
    }

    public LocalCacheService()
    {
        var appData = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "EnterpriseAgent");
        _cacheDirectory = Path.Combine(appData, "Cache");
        _metadataFile = Path.Combine(_cacheDirectory, "metadata.json");
        
        Directory.CreateDirectory(_cacheDirectory);
        
        _metadata = new ConcurrentDictionary<string, CacheEntryMetadata>();
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = true
        };
        
        LoadMetadata();
        
        // 每5分钟清理一次过期缓存
        _cleanupTimer = new Timer(async _ => await CleanupExpiredAsync(), null, 
            TimeSpan.FromMinutes(5), TimeSpan.FromHours(1));
        
        Log.Information($"✅ 本地缓存服务已启动，目录: {_cacheDirectory}");
        Log.Information($"   缓存文件数: {_metadata.Count}, 总大小: {GetCacheSize() / 1024 / 1024:F1} MB");
    }

    private void LoadMetadata()
    {
        if (!File.Exists(_metadataFile)) return;
        
        try
        {
            var json = File.ReadAllText(_metadataFile);
            var data = JsonSerializer.Deserialize<Dictionary<string, CacheEntryMetadata>>(json, _jsonOptions);
            if (data != null)
            {
                foreach (var kv in data)
                    _metadata[kv.Key] = kv.Value;
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "加载缓存元数据失败");
        }
    }

    private async Task SaveMetadataAsync()
    {
        await _metadataLock.WaitAsync();
        try
        {
            var json = JsonSerializer.Serialize(_metadata, _jsonOptions);
            await File.WriteAllTextAsync(_metadataFile, json);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "保存缓存元数据失败");
        }
        finally
        {
            _metadataLock.Release();
        }
    }

    private string GetCacheFilePath(string key)
    {
        using var sha256 = SHA256.Create();
        var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(key));
        var fileName = Convert.ToHexString(hash).ToLower();
        return Path.Combine(_cacheDirectory, fileName);
    }

    public async Task SaveAsync<T>(string key, T data, TimeSpan? expiration = null)
    {
        await _fileLock.WaitAsync();
        try
        {
            var cacheFile = GetCacheFilePath(key);
            var json = JsonSerializer.Serialize(data, _jsonOptions);
            var bytes = Encoding.UTF8.GetBytes(json);
            
            // 压缩保存
            await using var fs = new FileStream(cacheFile, FileMode.Create);
            await using var gzip = new GZipStream(fs, CompressionLevel.Optimal);
            await gzip.WriteAsync(bytes, 0, bytes.Length);
            
            // 保存元数据
            var metadata = new CacheEntryMetadata
            {
                Key = key,
                CreatedAt = DateTime.UtcNow,
                ExpiresAt = expiration.HasValue ? DateTime.UtcNow.Add(expiration.Value) : null,
                CompressedSize = fs.Length,
                OriginalSize = bytes.Length
            };
            _metadata[key] = metadata;
            await SaveMetadataAsync();
            
            Log.Debug($"缓存已保存: {key}, 原始: {bytes.Length / 1024}KB, 压缩后: {fs.Length / 1024}KB");
        }
        catch (Exception ex)
        {
            Log.Error(ex, $"保存缓存失败: {key}");
        }
        finally
        {
            _fileLock.Release();
        }
    }

    public async Task<T?> GetAsync<T>(string key)
    {
        var cacheFile = GetCacheFilePath(key);
        if (!File.Exists(cacheFile))
            return default;
        
        // 检查是否过期
        if (_metadata.TryGetValue(key, out var metadata) && metadata.ExpiresAt.HasValue)
        {
            if (DateTime.UtcNow > metadata.ExpiresAt.Value)
            {
                await DeleteAsync(key);
                return default;
            }
        }
        
        try
        {
            await using var fs = new FileStream(cacheFile, FileMode.Open);
            await using var gzip = new GZipStream(fs, CompressionMode.Decompress);
            using var ms = new MemoryStream();
            await gzip.CopyToAsync(ms);
            
            var bytes = ms.ToArray();
            var json = Encoding.UTF8.GetString(bytes);
            return JsonSerializer.Deserialize<T>(json, _jsonOptions);
        }
        catch (Exception ex)
        {
            Log.Error(ex, $"读取缓存失败: {key}");
            return default;
        }
    }

    public async Task DeleteAsync(string key)
    {
        var cacheFile = GetCacheFilePath(key);
        if (File.Exists(cacheFile))
        {
            try
            {
                File.Delete(cacheFile);
            }
            catch (Exception ex)
            {
                Log.Error(ex, $"删除缓存文件失败: {key}");
            }
        }
        
        _metadata.TryRemove(key, out _);
        await SaveMetadataAsync();
    }

    public async Task<List<string>> GetAllKeysAsync()
    {
        return await Task.Run(() => _metadata.Keys.ToList());
    }

    public async Task CleanupExpiredAsync()
    {
        var expiredKeys = _metadata
            .Where(kv => kv.Value.ExpiresAt.HasValue && DateTime.UtcNow > kv.Value.ExpiresAt.Value)
            .Select(kv => kv.Key)
            .ToList();
        
        foreach (var key in expiredKeys)
        {
            await DeleteAsync(key);
        }
        
        if (expiredKeys.Count > 0)
        {
            Log.Information($"🧹 清理过期缓存: {expiredKeys.Count} 项");
        }
    }

    public long GetCacheSize()
    {
        long totalSize = 0;
        foreach (var file in Directory.GetFiles(_cacheDirectory, "*"))
        {
            if (file == _metadataFile) continue;
            try
            {
                totalSize += new FileInfo(file).Length;
            }
            catch { }
        }
        return totalSize;
    }

    public int GetCacheCount()
    {
        return _metadata.Count;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _cleanupTimer?.Dispose();
        _fileLock.Dispose();
        _metadataLock.Dispose();
    }
}
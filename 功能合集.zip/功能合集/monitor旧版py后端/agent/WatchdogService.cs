using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public interface IWatchdogService
{
    void Watch(string name, Func<Task> processFunc, bool autoRestart = true, Func<bool>? healthCheck = null);
    void Heartbeat(string name);
    void StopWatch(string name);
    WatchdogStatus GetStatus();
}

public class WatchdogStatus
{
    public bool IsRunning { get; set; }
    public Dictionary<string, WatchedProcess> Processes { get; set; } = new();
    public WatchdogStats Stats { get; set; } = new();
}

public class WatchedProcess
{
    public string Name { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public int RestartCount { get; set; }
    public int Pid { get; set; }
    public string? Error { get; set; }
    public bool AutoRestart { get; set; }
    public bool IsAlive { get; set; }
    public int HealthCheckFailures { get; set; }
    public DateTime LastHealthCheck { get; set; }
}

public class WatchdogStats
{
    public int TotalRestarts { get; set; }
    public int FailedRestarts { get; set; }
    public int TotalHealthCheckFailures { get; set; }
    public DateTime? LastCheck { get; set; }
}

public class WatchdogService : IWatchdogService, IHostedService
{
    private readonly ConcurrentDictionary<string, WatchedProcessInfo> _watchedProcesses = new();
    private readonly System.Threading.Timer? _watchdogTimer;
    private bool _isRunning;
    private readonly int _checkInterval = 30;
    private readonly int _maxRestarts = 5;
    private WatchdogStats _stats = new();
    
    private class WatchedProcessInfo
    {
        public Func<Task> ProcessFunc { get; set; } = null!;
        public bool AutoRestart { get; set; }
        public Func<bool>? HealthCheck { get; set; }
        public int HealthCheckInterval { get; set; } = 60;
        public DateTime LastHealthCheck { get; set; }
        public int HealthCheckFailures { get; set; }
        public Task? RunningTask { get; set; }
        public CancellationTokenSource? Cts { get; set; }
        public int RestartCount { get; set; }
        public DateTime LastRestart { get; set; }
        public string Status { get; set; } = "stopped";
        public string? Error { get; set; }
        public DateTime LastHeartbeat { get; set; }
        public int FailureCount { get; set; }
    }
    
    public WatchdogService()
    {
        _watchdogTimer = new System.Threading.Timer(WatchdogLoop, null, _checkInterval * 1000, _checkInterval * 1000);
    }
    
    public void Watch(string name, Func<Task> processFunc, bool autoRestart = true, Func<bool>? healthCheck = null)
    {
        var info = new WatchedProcessInfo
        {
            ProcessFunc = processFunc,
            AutoRestart = autoRestart,
            HealthCheck = healthCheck,
            LastHealthCheck = DateTime.UtcNow,
            Status = "stopped"
        };
        
        _watchedProcesses.TryAdd(name, info);
        Log.Information($"✅ 进程已加入监控: {name}");
        
        StartWatch(name);
    }
    
    private void StartWatch(string name)
    {
        if (!_watchedProcesses.TryGetValue(name, out var info))
            return;
        
        if (info.RunningTask?.IsCompleted == false)
            return;
        
        if (info.RestartCount >= _maxRestarts)
        {
            Log.Error($"进程 {name} 已达最大重启次数");
            info.Status = "failed";
            return;
        }
        
        if ((DateTime.UtcNow - info.LastRestart).TotalSeconds < 60 && info.LastRestart != DateTime.MinValue)
            return;
        
        info.Cts?.Cancel();
        info.Cts = new CancellationTokenSource();
        info.Status = "running";
        info.RestartCount++;
        info.LastRestart = DateTime.UtcNow;
        info.HealthCheckFailures = 0;
        
        info.RunningTask = Task.Run(async () =>
        {
            try
            {
                await info.ProcessFunc();
                info.Status = "stopped";
            }
            catch (Exception ex)
            {
                if (info.Cts?.IsCancellationRequested == true)
                {
                    info.Status = "stopped";
                }
                else
                {
                    Log.Error(ex, $"进程 {name} 异常退出");
                    info.Status = "crashed";
                    info.Error = ex.Message;
                    
                    if (info.AutoRestart)
                    {
                        Log.Information($"⏳ 等待重启进程 {name}");
                        await Task.Delay(5000);
                        StartWatch(name);
                    }
                }
            }
        }, info.Cts.Token);
        
        Log.Information($"🔄 看门狗启动进程: {name}");
    }
    
    public void Heartbeat(string name)
    {
        if (_watchedProcesses.TryGetValue(name, out var info))
        {
            info.LastHeartbeat = DateTime.UtcNow;
            info.FailureCount = 0;
            info.HealthCheckFailures = 0;
        }
    }
    
    public void StopWatch(string name)
    {
        if (_watchedProcesses.TryRemove(name, out var info))
        {
            info.AutoRestart = false;
            info.Status = "stopping";
            info.Cts?.Cancel();
            info.RunningTask?.Wait(5000);
            info.Status = "stopped";
            Log.Information($"⏹️ 看门狗停止进程: {name}");
        }
    }
    
    public WatchdogStatus GetStatus()
    {
        var processes = new Dictionary<string, WatchedProcess>();
        foreach (var kv in _watchedProcesses)
        {
            var info = kv.Value;
            processes[kv.Key] = new WatchedProcess
            {
                Name = kv.Key,
                Status = info.Status,
                RestartCount = info.RestartCount,
                Error = info.Error,
                AutoRestart = info.AutoRestart,
                IsAlive = info.RunningTask?.IsCompleted == false,
                HealthCheckFailures = info.HealthCheckFailures,
                LastHealthCheck = info.LastHealthCheck
            };
        }
        
        return new WatchdogStatus
        {
            IsRunning = _isRunning,
            Processes = processes,
            Stats = _stats
        };
    }
    
    private void WatchdogLoop(object? state)
    {
        if (!_isRunning) return;
        
        _stats.LastCheck = DateTime.UtcNow;
        var now = DateTime.UtcNow;
        
        foreach (var kv in _watchedProcesses)
        {
            var name = kv.Key;
            var info = kv.Value;
            
            if (!info.AutoRestart) continue;
            
            // 检查进程是否存活
            if (info.RunningTask?.IsCompleted != false)
            {
                Log.Warning($"⚠️ 进程 {name} 已停止，准备重启");
                StartWatch(name);
                continue;
            }
            
            // 健康检查
            if (info.HealthCheck != null && (now - info.LastHealthCheck).TotalSeconds >= info.HealthCheckInterval)
            {
                info.LastHealthCheck = now;
                try
                {
                    var isHealthy = info.HealthCheck();
                    if (!isHealthy)
                    {
                        info.HealthCheckFailures++;
                        Log.Warning($"⚠️ 进程 {name} 健康检查失败 ({info.HealthCheckFailures}/3)");
                        if (info.HealthCheckFailures >= 3)
                        {
                            Log.Error($"❌ 进程 {name} 连续3次失败，准备重启");
                            _stats.TotalHealthCheckFailures++;
                            StartWatch(name);
                        }
                    }
                    else
                    {
                        info.HealthCheckFailures = 0;
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, $"健康检查异常: {name}");
                }
            }
        }
    }
    
    public void Start() { _isRunning = true; Log.Information("✅ 进程看门狗已启动"); }
    public void Stop() 
    { 
        _isRunning = false;
        foreach (var name in _watchedProcesses.Keys.ToList())
            StopWatch(name);
        Log.Information("进程看门狗已停止");
    }
    
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
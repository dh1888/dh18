using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public interface ITempFileCleanupService
{
    void Start();
    void Stop();
    long GetTempSizeMB();
}

public class TempFileCleanupService : ITempFileCleanupService, IHostedService
{
    private readonly string _tempDirectory;
    private System.Threading.Timer? _cleanupTimer;
    private bool _isRunning;
    private readonly int _maxAgeHours = 24;
    private readonly long _maxTotalSizeMB = 500;
    
    public TempFileCleanupService()
    {
        _tempDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "EnterpriseAgent", "Temp");
        Directory.CreateDirectory(_tempDirectory);
    }
    
    public void Start()
    {
        if (_isRunning) return;
        _isRunning = true;
        
        // 每 30 分钟清理一次
        _cleanupTimer = new System.Threading.Timer(Cleanup, null, TimeSpan.FromMinutes(5), TimeSpan.FromMinutes(30));
        Log.Information("✅ 临时文件清理服务已启动");
    }
    
    public void Stop()
    {
        _isRunning = false;
        _cleanupTimer?.Dispose();
        Log.Information("临时文件清理服务已停止");
    }
    
    public long GetTempSizeMB()
    {
        if (!Directory.Exists(_tempDirectory)) return 0;
        
        long totalBytes = 0;
        foreach (var file in Directory.GetFiles(_tempDirectory, "*", SearchOption.AllDirectories))
        {
            try
            {
                totalBytes += new FileInfo(file).Length;
            }
            catch { }
        }
        return totalBytes / (1024 * 1024);
    }
    
    private void Cleanup(object? state)
    {
        try
        {
            if (!Directory.Exists(_tempDirectory)) return;
            
            var now = DateTime.UtcNow;
            var files = Directory.GetFiles(_tempDirectory, "*", SearchOption.AllDirectories);
            var deletedCount = 0;
            var freedBytes = 0L;
            
            foreach (var file in files)
            {
                try
                {
                    var info = new FileInfo(file);
                    
                    // 删除超过 24 小时的文件
                    if (info.CreationTimeUtc < now.AddHours(-_maxAgeHours))
                    {
                        freedBytes += info.Length;
                        File.Delete(file);
                        deletedCount++;
                    }
                }
                catch { }
            }
            
            // 清理空目录
            foreach (var dir in Directory.GetDirectories(_tempDirectory))
            {
                try
                {
                    if (!Directory.EnumerateFileSystemEntries(dir).Any())
                    {
                        Directory.Delete(dir);
                    }
                }
                catch { }
            }
            
            if (deletedCount > 0)
            {
                Log.Information($"🧹 临时文件清理: 删除 {deletedCount} 个文件，释放 {freedBytes / (1024 * 1024):F1} MB");
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "临时文件清理异常");
        }
    }
    
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
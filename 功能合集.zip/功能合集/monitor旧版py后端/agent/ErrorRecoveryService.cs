using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public interface IErrorRecoveryService
{
    void ReportError(Exception ex, string component);
    bool ShouldRetry(string component, int retryCount);
    double GetRetryDelay(string component, int retryCount);
    bool IsCircuitBroken(string component);
    ErrorRecoveryStats GetStats();
}

public enum ErrorType
{
    Network, Server, Local, Resource, Unknown
}

public class ErrorRecoveryStats
{
    public Dictionary<string, int> ErrorCounts { get; set; } = new();
    public List<ErrorRecord> RecentErrors { get; set; } = new();
    public Dictionary<string, CircuitBreakerState> CircuitBreakers { get; set; } = new();
}

public class ErrorRecord
{
    public DateTime Time { get; set; }
    public string Type { get; set; } = string.Empty;
    public string Component { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
}

public class CircuitBreakerState
{
    public bool IsBroken { get; set; }
    public DateTime LastBreakTime { get; set; }
    public int TimeoutSeconds { get; set; }
    public double RemainingSeconds => IsBroken ? Math.Max(0, (LastBreakTime.AddSeconds(TimeoutSeconds) - DateTime.UtcNow).TotalSeconds) : 0;
}

public class ErrorRecoveryService : IErrorRecoveryService, IHostedService
{
    private readonly IWebSocketService _webSocketService;
    private readonly ConcurrentDictionary<ErrorType, int> _errorCounts = new();
    private readonly ConcurrentQueue<ErrorRecord> _errorHistory = new();
    private readonly ConcurrentDictionary<string, CircuitBreakerState> _circuitBreakers = new();
    private readonly System.Threading.Timer? _cleanupTimer;
    private readonly int _maxHistory = 100;
    private bool _isRunning;
    
    private readonly Dictionary<ErrorType, (int Threshold, int TimeoutSeconds)> _circuitBreakerConfig = new()
    {
        [ErrorType.Network] = (5, 300),
        [ErrorType.Server] = (3, 600),
        [ErrorType.Local] = (3, 60),
        [ErrorType.Resource] = (2, 120),
        [ErrorType.Unknown] = (3, 60)
    };
    
    public ErrorRecoveryService(IWebSocketService webSocketService)
    {
        _webSocketService = webSocketService;
        _cleanupTimer = new System.Threading.Timer(CleanupLoop, null, 60000, 60000);
        InitializeErrorCounts();
    }
    
    private void InitializeErrorCounts()
    {
        foreach (ErrorType type in Enum.GetValues(typeof(ErrorType)))
            _errorCounts[type] = 0;
    }
    
    public ErrorType ClassifyError(Exception ex)
    {
        var message = ex.Message.ToLower();
        
        if (ex is System.Net.Http.HttpRequestException ||
            ex is System.Net.Sockets.SocketException ||
            message.Contains("network") || message.Contains("connection"))
            return ErrorType.Network;
        
        if (ex is System.Net.Http.HttpRequestException hre && hre.StatusCode.HasValue)
        {
            var statusCode = (int)hre.StatusCode.Value;
            if (statusCode >= 500) return ErrorType.Server;
            if (statusCode == 429) return ErrorType.Resource;
        }
        
        if (message.Contains("memory") || message.Contains("disk") || message.Contains("full"))
            return ErrorType.Resource;
        
        if (ex is System.IO.IOException || ex is UnauthorizedAccessException)
            return ErrorType.Local;
        
        return ErrorType.Unknown;
    }
    
    public void ReportError(Exception ex, string component)
    {
        var errorType = ClassifyError(ex);
        
        _errorCounts.AddOrUpdate(errorType, 1, (_, count) => count + 1);
        
        var record = new ErrorRecord
        {
            Time = DateTime.UtcNow,
            Type = errorType.ToString(),
            Component = component,
            Message = ex.Message
        };
        
        _errorHistory.Enqueue(record);
        while (_errorHistory.Count > _maxHistory)
            _errorHistory.TryDequeue(out _);
        
        CheckCircuitBreaker(errorType);
        TriggerRecovery(errorType, component, ex);
        
        Log.Warning($"错误报告 [{component}]: {errorType} - {ex.Message}");
    }
    
    private void CheckCircuitBreaker(ErrorType errorType)
    {
        if (!_circuitBreakerConfig.TryGetValue(errorType, out var config))
            return;
        
        var key = errorType.ToString();
        var state = _circuitBreakers.GetOrAdd(key, _ => new CircuitBreakerState());
        
        if (state.IsBroken && DateTime.UtcNow > state.LastBreakTime.AddSeconds(state.TimeoutSeconds))
        {
            state.IsBroken = false;
            Log.Information($"🔌 {key} 熔断恢复");
        }
        
        if (!state.IsBroken)
        {
            var recentErrors = _errorHistory
                .Where(e => e.Type == key && e.Time > DateTime.UtcNow.AddMinutes(-1))
                .Count();
            
            if (recentErrors >= config.Threshold)
            {
                state.IsBroken = true;
                state.LastBreakTime = DateTime.UtcNow;
                state.TimeoutSeconds = config.TimeoutSeconds;
                Log.Warning($"⚠️ {key} 触发熔断，暂停 {config.TimeoutSeconds}秒");
            }
        }
    }
    
    private void TriggerRecovery(ErrorType errorType, string component, Exception ex)
    {
        switch (errorType)
        {
            case ErrorType.Network:
                _ = Task.Run(async () => await _webSocketService.ReconnectAsync());
                break;
            case ErrorType.Local:
                GC.Collect();
                break;
        }
    }
    
    public bool ShouldRetry(string component, int retryCount)
    {
        var config = component switch
        {
            "http" => (5, 3),
            "websocket" => (10, 5),
            _ => (3, 3)
        };
        
        return retryCount < config.Item2;
    }
    
    public double GetRetryDelay(string component, int retryCount)
    {
        var baseDelay = component switch
        {
            "http" => 2.0,
            "websocket" => 5.0,
            _ => 1.0
        };
        
        var delay = baseDelay * Math.Pow(2, retryCount - 1);
        return Math.Min(delay, 60);
    }
    
    public bool IsCircuitBroken(string component)
    {
        var key = component;
        if (_circuitBreakers.TryGetValue(key, out var state))
            return state.IsBroken;
        return false;
    }
    
    public ErrorRecoveryStats GetStats()
    {
        return new ErrorRecoveryStats
        {
            ErrorCounts = _errorCounts.ToDictionary(kv => kv.Key.ToString(), kv => kv.Value),
            RecentErrors = _errorHistory.TakeLast(10).ToList(),
            CircuitBreakers = _circuitBreakers.ToDictionary(kv => kv.Key, kv => kv.Value)
        };
    }
    
    private void CleanupLoop(object? state)
    {
        var cutoff = DateTime.UtcNow.AddHours(-1);
        while (_errorHistory.TryPeek(out var record) && record.Time < cutoff)
            _errorHistory.TryDequeue(out _);
    }
    
    public Task StartAsync(CancellationToken cancellationToken)
    {
        _isRunning = true;
        return Task.CompletedTask;
    }
    
    public Task StopAsync(CancellationToken cancellationToken)
    {
        _isRunning = false;
        _cleanupTimer?.Dispose();
        return Task.CompletedTask;
    }
}
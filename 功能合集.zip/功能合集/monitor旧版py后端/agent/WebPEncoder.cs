using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Webp;
using SixLabors.ImageSharp.PixelFormats;
using System.Drawing.Imaging;

namespace EnterpriseAgent;

public interface IWebPEncoder
{
    byte[] Encode(Bitmap bitmap, int quality);
    bool IsAvailable { get; }
}

public class WebPEncoder : IWebPEncoder
{
    private readonly object _lock = new();
    
    public bool IsAvailable => true;
    
    public byte[] Encode(Bitmap bitmap, int quality)
    {
        lock (_lock)
        {
            try
            {
                // 使用完整命名空间避免歧义
                using var memoryStream = new MemoryStream();
                bitmap.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Png);
                memoryStream.Position = 0;
                
                // 明确使用 SixLabors.ImageSharp.Image
                using var image = SixLabors.ImageSharp.Image.Load<Rgba32>(memoryStream);
                
                // 配置 WebP 编码器
                var encoder = new WebpEncoder
                {
                    Quality = Math.Clamp(quality, 1, 100),
                    Method = WebpEncodingMethod.BestQuality,
                    FileFormat = WebpFileFormatType.Lossy,
                    UseAlphaCompression = true
                };
                
                using var outputStream = new MemoryStream();
                image.Save(outputStream, encoder);
                return outputStream.ToArray();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "WebP 编码失败，降级到 JPEG");
                return EncodeToJpegFallback(bitmap, quality);
            }
        }
    }
    
    private byte[] EncodeToJpegFallback(Bitmap bitmap, int quality)
    {
        var codec = GetEncoder(System.Drawing.Imaging.ImageFormat.Jpeg);
        var encoderParams = new EncoderParameters(1);
        encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, quality);
        
        using var ms = new MemoryStream();
        bitmap.Save(ms, codec, encoderParams);
        return ms.ToArray();
    }
    
    private ImageCodecInfo GetEncoder(System.Drawing.Imaging.ImageFormat format)
    {
        var codecs = ImageCodecInfo.GetImageEncoders();
        foreach (var codec in codecs)
        {
            if (codec.FormatID == format.Guid)
                return codec;
        }
        return codecs[0];
    }
}
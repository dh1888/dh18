using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;

namespace EnterpriseAgent;

/// <summary>
/// 区域帧编码器 - 只编码变化的区域，大幅节省带宽
/// </summary>
public class RegionEncoder
{
    private readonly int _backgroundQuality;
    private readonly int _regionQuality;
    
    public RegionEncoder(int backgroundQuality = 30, int regionQuality = 70)
    {
        _backgroundQuality = backgroundQuality;
        _regionQuality = regionQuality;
    }
    
    /// <summary>
    /// 编码区域帧
    /// </summary>
    /// <param name="background">背景帧（上次发送的完整帧）</param>
    /// <param name="current">当前帧</param>
    /// <param name="regions">需要更新的区域</param>
    /// <returns>编码后的区域帧数据</returns>
    public byte[]? EncodeRegionFrame(Bitmap background, Bitmap current, List<Rectangle> regions)
    {
        if (regions == null || regions.Count == 0)
            return null;
        
        try
        {
            using var ms = new MemoryStream();
            using var writer = new BinaryWriter(ms);
            
            // 写入区域数量
            writer.Write((ushort)Math.Min(regions.Count, ushort.MaxValue));
            writer.Write((byte)_regionQuality);
            
            var codec = GetJpegEncoder();
            
            // 1. 编码低质量背景（只编码一次）
            using var bgMs = new MemoryStream();
            using (var bgEncoderParams = new EncoderParameters(1))
            {
                bgEncoderParams.Param[0] = new EncoderParameter(Encoder.Quality, _backgroundQuality);
                background.Save(bgMs, codec, bgEncoderParams);
            }
            var bgData = bgMs.ToArray();
            writer.Write(bgData.Length);
            writer.Write(bgData);
            
            // 2. 编码每个变化区域
            foreach (var region in regions)
            {
                using var regionImg = current.Clone(region, current.PixelFormat);
                using var regionMs = new MemoryStream();
                
                using (var regionEncoderParams = new EncoderParameters(1))
                {
                    regionEncoderParams.Param[0] = new EncoderParameter(Encoder.Quality, _regionQuality);
                    regionImg.Save(regionMs, codec, regionEncoderParams);
                }
                
                var regionData = regionMs.ToArray();
                
                writer.Write((ushort)region.X);
                writer.Write((ushort)region.Y);
                writer.Write((ushort)region.Width);
                writer.Write((ushort)region.Height);
                writer.Write(regionData.Length);
                writer.Write(regionData);
            }
            
            return ms.ToArray();
        }
        catch (Exception ex)
        {
            Log.Error(ex, "编码区域帧失败");
            return null;
        }
    }
    
    private ImageCodecInfo GetJpegEncoder()
    {
        var codecs = ImageCodecInfo.GetImageEncoders();
        foreach (var codec in codecs)
        {
            if (codec.FormatID == ImageFormat.Jpeg.Guid)
                return codec;
        }
        return codecs[0];
    }
}
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public class MemoryWarningEventArgs : EventArgs
{
    public long CurrentMemoryMB { get; set; }
    public long ThresholdMB { get; set; }
    public string WarningType { get; set; } = string.Empty;
}

public interface IMemoryMonitorService
{
    void Start();
    void Stop();
    MemoryStats GetCurrentStats();
    event EventHandler<MemoryWarningEventArgs>? MemoryWarning;
}

public class MemoryStats
{
    public long WorkingSetMB { get; set; }
    public long PrivateMemoryMB { get; set; }
    public long ManagedMemoryMB { get; set; }
    public int Gen0Collections { get; set; }
    public int Gen1Collections { get; set; }
    public int Gen2Collections { get; set; }
    public int TotalThreads { get; set; }
    public TimeSpan Uptime { get; set; }
}

public class MemoryMonitorService : IMemoryMonitorService, IHostedService
{
    private System.Threading.Timer? _monitorTimer;
    private int _isRunning;
    private readonly long _warningThresholdMB = 500;
    private readonly long _criticalThresholdMB = 800;
    private DateTime _lastGcTime = DateTime.UtcNow;
    private readonly object _gcLock = new();
    
    public event EventHandler<MemoryWarningEventArgs>? MemoryWarning;
    
    public void Start()
    {
        if (Interlocked.Exchange(ref _isRunning, 1) == 1) return;
        
        _monitorTimer = new System.Threading.Timer(MonitorMemory, null, 30000, 30000);
        Log.Information("✅ 内存监控服务已启动");
    }
    
    public void Stop()
    {
        if (Interlocked.Exchange(ref _isRunning, 0) == 0) return;
        
        _monitorTimer?.Dispose();
        _monitorTimer = null;
        Log.Information("内存监控服务已停止");
    }
    
    public MemoryStats GetCurrentStats()
    {
        using var process = Process.GetCurrentProcess();
        
        return new MemoryStats
        {
            WorkingSetMB = process.WorkingSet64 / (1024 * 1024),
            PrivateMemoryMB = process.PrivateMemorySize64 / (1024 * 1024),
            ManagedMemoryMB = GC.GetTotalMemory(false) / (1024 * 1024),
            Gen0Collections = GC.CollectionCount(0),
            Gen1Collections = GC.CollectionCount(1),
            Gen2Collections = GC.CollectionCount(2),
            TotalThreads = process.Threads.Count,
            Uptime = DateTime.UtcNow - process.StartTime.ToUniversalTime()
        };
    }
    
    private void MonitorMemory(object? state)
    {
        try
        {
            var stats = GetCurrentStats();
            
            Log.Debug($"内存状态: WS={stats.WorkingSetMB}MB, Private={stats.PrivateMemoryMB}MB, Managed={stats.ManagedMemoryMB}MB");
            
            if (stats.WorkingSetMB > _criticalThresholdMB)
            {
                MemoryWarning?.Invoke(this, new MemoryWarningEventArgs
                {
                    CurrentMemoryMB = stats.WorkingSetMB,
                    ThresholdMB = _criticalThresholdMB,
                    WarningType = "critical"
                });
                ForceGarbageCollection();
            }
            else if (stats.WorkingSetMB > _warningThresholdMB)
            {
                MemoryWarning?.Invoke(this, new MemoryWarningEventArgs
                {
                    CurrentMemoryMB = stats.WorkingSetMB,
                    ThresholdMB = _warningThresholdMB,
                    WarningType = "warning"
                });
            }
            
            // 每10分钟强制GC一次
            if ((DateTime.UtcNow - _lastGcTime).TotalMinutes > 10)
            {
                ForceGarbageCollection();
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "内存监控异常");
        }
    }
    
    private void ForceGarbageCollection()
    {
        lock (_gcLock)
        {
            Log.Debug("强制执行垃圾回收");
            
            try
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                
                _lastGcTime = DateTime.UtcNow;
                
                var afterStats = GetCurrentStats();
                Log.Debug($"GC后内存: {afterStats.WorkingSetMB}MB");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "GC执行失败");
            }
        }
    }
    
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
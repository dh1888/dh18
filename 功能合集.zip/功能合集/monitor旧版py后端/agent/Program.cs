using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using Serilog.Events;
using Hardcodet.Wpf.TaskbarNotification;
using Microsoft.Win32;
// 添加 using alias 解决歧义
using WinApplication = System.Windows.Application;
using WinMessageBox = System.Windows.MessageBox;
using FormsMessageBox = System.Windows.Forms.MessageBox;

namespace EnterpriseAgent;

public static class Program
{
    private static TaskbarIcon? _notifyIcon;
    private static IHost? _host;
    private static Mutex? _appMutex;
    private static readonly object _shutdownLock = new();
    private static bool _isShuttingDown;
    private static bool _isRestarting;
    private static bool _autoStartMenuChecked;

    [STAThread]
    public static void Main(string[] args)
    {
        MainAsync(args).GetAwaiter().GetResult();
    }

    private static async Task MainAsync(string[] args)
    {
        // 设置进程优先级
        using (var process = System.Diagnostics.Process.GetCurrentProcess())
        {
            process.PriorityClass = System.Diagnostics.ProcessPriorityClass.BelowNormal;
        }

        // 全局异常处理
        AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;
        TaskScheduler.UnobservedTaskException += OnUnobservedTaskException;

        // 防止重复启动
        const string mutexName = "Global\\EnterpriseAgent";
        _appMutex = new Mutex(true, mutexName, out var createdNew);
        if (!createdNew)
        {
            WinMessageBox.Show(
                "程序已在运行中",
                "提示",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            return;
        }

        // 初始化日志
        InitializeLogging();

        // 进程退出处理
        AppDomain.CurrentDomain.ProcessExit += OnProcessExit;
        Console.CancelKeyPress += OnCancelKeyPress;

        try
        {
            _host = CreateHostBuilder(args).Build();

            // 初始化托盘图标（先不启动后台服务）
            InitializeTrayIcon();

            // 获取配置服务
            var configService =
                _host.Services.GetRequiredService<IConfigurationService>();

            // ========== 关键修改：先处理配置，再启动后台服务 ==========
            if (!configService.IsConfigured())
            {
                // 显示配置窗口（使用 ShowDialog 而不是 app.Run）
                var mainWindow =
                    _host.Services.GetRequiredService<MainWindow>();

                var result = mainWindow.ShowDialog();

                // 配置完成后，再启动后台服务
                if (result == true && configService.IsConfigured())
                {
                    Log.Information("配置完成，正在启动后台服务...");

                    // 注册事件
                    RegisterEventHandlers();

                    // 启动后台服务
                    await _host.StartAsync();

                    Log.Information("后台服务已启动");
                }
                else
                {
                    Log.Warning("配置未完成，程序退出");

                    Shutdown(0);
                    return;
                }
            }
            else
            {
                // 已有配置，直接启动后台服务
                Log.Information("已有配置，正在启动后台服务...");

                // 注册事件
                RegisterEventHandlers();

                // 启动后台服务
                await _host.StartAsync();

                Log.Information("后台服务已启动");
            }

            // 运行应用（无窗口，后台运行）
            var app = new WinApplication();
            app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
            app.Exit += OnApplicationExit;
            app.DispatcherUnhandledException += OnDispatcherUnhandledException;
            app.Run();
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "应用启动失败");

            WinMessageBox.Show(
                $"应用启动失败: {ex.Message}",
                "错误",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private static void RegisterEventHandlers()
    {
        try
        {
            if (_host == null) return;
            
            // 注册内存监控
            var memoryMonitor = _host.Services.GetService<IMemoryMonitorService>();
            if (memoryMonitor != null)
            {
                memoryMonitor.MemoryWarning += OnMemoryWarning;
            }
            
            // 注册连接监控
            var connectionMonitor = _host.Services.GetService<IConnectionMonitorService>();
            if (connectionMonitor != null)
            {
                connectionMonitor.ConnectionStateChanged += OnConnectionStateChanged;
            }
            
            Log.Debug("事件处理器已注册");
        }
        catch (Exception ex)
        {
            Log.Error(ex, "注册事件处理器失败");
        }
    }

    private static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .UseSerilog()
            .ConfigureServices((context, services) =>
            {
                // 配置管理
                services.AddSingleton<IConfigurationService, ConfigurationService>();
                
                // 安全服务
                services.AddSingleton<ISecurityService, SecurityService>();
                services.AddSingleton<IDeviceFingerprintService, DeviceFingerprintService>();
                
                // 网络服务
                services.AddSingleton<IHttpClientService, HttpClientService>();
                services.AddSingleton<IWebSocketService, WebSocketService>();
                
                // 任务系统
                services.AddSingleton<ITaskRegistry, TaskRegistry>();
                services.AddSingleton<ITaskExecutor, TaskExecutor>();
                services.AddSingleton<ITaskQueue, TaskQueue>();
                services.AddSingleton<ITaskStateManager, TaskStateManager>();

                services.AddSingleton<ILocalCacheService, LocalCacheService>();
                services.AddSingleton<IBatchUploadService, BatchUploadService>();
                services.AddSingleton<IWebPEncoder, WebPEncoder>();
                
                // 监控服务
                services.AddSingleton<IScreenshotCaptureService, ScreenshotCaptureService>();
                services.AddSingleton<IBrowserHistoryService, BrowserHistoryService>();
                services.AddSingleton<IFileOperationService, FileOperationService>();
                services.AddSingleton<IAppMonitorService, AppMonitorService>();
                services.AddSingleton<IBrowserMonitorService, BrowserMonitorService>();
                services.AddSingleton<IPerceptualHashService, PerceptualHashService>();
                
                // 核心服务
                services.AddSingleton<IRemoteScreenService, RemoteScreenService>();
                services.AddSingleton<IHeartbeatService, HeartbeatService>();
                services.AddSingleton<IUpdateService, UpdateService>();
                
                // 清理服务
                services.AddSingleton<ILogCleanupService, LogCleanupService>();
                services.AddSingleton<IMemoryMonitorService, MemoryMonitorService>();
                services.AddSingleton<ITempFileCleanupService, TempFileCleanupService>();
                services.AddSingleton<IPowerManagerService, PowerManagerService>();
                services.AddSingleton<IErrorRecoveryService, ErrorRecoveryService>();
                services.AddSingleton<IHealthMonitorService, HealthMonitorService>();
                services.AddSingleton<IWatchdogService, WatchdogService>();
                
                // 连接监控服务
                services.AddSingleton<IConnectionMonitorService, ConnectionMonitorService>();
                
                // 多语言
                services.AddSingleton<II18nService, I18nService>();
                
                // ========== 后台服务 - 这些会在配置完成后才启动 ==========
                // 注意：这些服务需要在 _host.StartAsync() 时才会启动
                // 我们已经在配置完成后才调用 _host.StartAsync()
                services.AddHostedService<AgentBackgroundService>();
                services.AddHostedService<HeartbeatBackgroundService>();
                services.AddHostedService<ScreenshotBackgroundService>();
                services.AddHostedService<BrowserHistoryBackgroundService>();
                services.AddHostedService<FileOperationBackgroundService>();
                services.AddHostedService<AppUsageBackgroundService>();
                services.AddHostedService<BrowserMonitorBackgroundService>();
                services.AddHostedService<TaskConsumerBackgroundService>();
                services.AddHostedService<LogCleanupService>();
                services.AddHostedService<MemoryMonitorService>();
                services.AddHostedService<TempFileCleanupService>();
                services.AddHostedService<PowerManagerService>();
                services.AddHostedService<HealthMonitorService>();
                services.AddHostedService<WatchdogService>();
                services.AddHostedService<ConnectionMonitorService>();
                
                // UI
                services.AddSingleton<MainWindow>();
                services.AddSingleton<MainWindowViewModel>();
            });

    private static void InitializeLogging()
    {
        var logDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "EnterpriseAgent",
            "Logs");

        Directory.CreateDirectory(logDirectory);

        CleanOldLogs(logDirectory);

        Serilog.Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
            .MinimumLevel.Override("System", LogEventLevel.Warning)
            .MinimumLevel.Override("System.Net.Http", LogEventLevel.Warning)
            .MinimumLevel.Override("System.Net.Sockets", LogEventLevel.Warning)
            .Enrich.FromLogContext()
            .WriteTo.Async(a => a.File(
                Path.Combine(logDirectory, "agent-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 14,
                fileSizeLimitBytes: 50 * 1024 * 1024,
                rollOnFileSizeLimit: true,
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}"
            ))
            .WriteTo.Async(a => a.File(
                Path.Combine(logDirectory, "agent-json-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 7,
                fileSizeLimitBytes: 50 * 1024 * 1024,
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}"
            ))
            .CreateLogger();

        Log.Initialize(Serilog.Log.Logger);
    }

    private static void CleanOldLogs(string logDirectory)
    {
        try
        {
            var now = DateTime.UtcNow;
            var files = Directory.GetFiles(logDirectory, "*.log");
            long totalSize = 0;
            
            foreach (var file in files)
            {
                var info = new FileInfo(file);
                totalSize += info.Length;
                
                if (info.CreationTimeUtc < now.AddDays(-30))
                {
                    try { info.Delete(); } catch { }
                }
            }
            
            if (totalSize > 1024 * 1024 * 1024)
            {
                var oldFiles = files.Select(f => new FileInfo(f))
                    .Where(f => f.Exists)
                    .OrderBy(f => f.CreationTimeUtc)
                    .Take(Math.Max(1, files.Length / 5));
                
                foreach (var file in oldFiles)
                {
                    try { file.Delete(); } catch { }
                }
            }
        }
        catch { }
    }
    
    private static void InitializeTrayIcon()
    {
        _notifyIcon = new TaskbarIcon
        {
            Icon = System.Drawing.Icon.ExtractAssociatedIcon(
                Environment.ProcessPath!),

            ToolTipText = "Enterprise Agent - 运行中",
            Visibility = Visibility.Visible,
            MenuActivation = PopupActivationMode.RightClick,
        };

        var contextMenu =
            new System.Windows.Controls.ContextMenu();

        var statusItem =
            new System.Windows.Controls.MenuItem
            {
                Header = "📊 查看状态"
            };

        statusItem.Click += (s, e) => ShowStatusWindow();
        contextMenu.Items.Add(statusItem);

        var healthItem =
            new System.Windows.Controls.MenuItem
            {
                Header = "❤️ 健康状态"
            };

        healthItem.Click += async (s, e) =>
            await ShowHealthStatusAsync();

        contextMenu.Items.Add(healthItem);

        var remoteStatsItem =
            new System.Windows.Controls.MenuItem
            {
                Header = "🖥️ 远程屏幕状态"
            };

        remoteStatsItem.Click += async (s, e) =>
            await ShowRemoteStatsAsync();

        contextMenu.Items.Add(remoteStatsItem);

        contextMenu.Items.Add(
            new System.Windows.Controls.Separator());

        var pauseItem =
            new System.Windows.Controls.MenuItem
            {
                Header = "⏸️ 暂停监控"
            };

        pauseItem.Click += async (s, e) =>
            await PauseMonitoringAsync();

        contextMenu.Items.Add(pauseItem);

        var screenshotItem =
            new System.Windows.Controls.MenuItem
            {
                Header = "📸 立即截图"
            };

        screenshotItem.Click += async (s, e) =>
            await TakeScreenshotNowAsync();

        contextMenu.Items.Add(screenshotItem);

        contextMenu.Items.Add(
            new System.Windows.Controls.Separator());

        var reconnectItem =
            new System.Windows.Controls.MenuItem
            {
                Header = "🔄 重连"
            };

        reconnectItem.Click += async (s, e) =>
            await ReconnectAsync();

        contextMenu.Items.Add(reconnectItem);

        var autoStartManager =
            new AutoStartManager("EnterpriseAgent");

        var isAutoStartEnabled =
            autoStartManager.IsEnabled();

        _autoStartMenuChecked = isAutoStartEnabled;

        var autoStartItem =
            new System.Windows.Controls.MenuItem
            {
                Header = isAutoStartEnabled
                    ? "⚡ 开机自启 ✓"
                    : "⚡ 开机自启"
            };

        autoStartItem.Click += async (s, e) =>
            await ToggleAutoStartAsync(autoStartItem);

        contextMenu.Items.Add(autoStartItem);

        var restartItem =
            new System.Windows.Controls.MenuItem
            {
                Header = "♻️ 重启应用"
            };

        restartItem.Click += async (s, e) =>
            await RestartAsync();

        contextMenu.Items.Add(restartItem);

        var logItem =
            new System.Windows.Controls.MenuItem
            {
                Header = "📁 查看日志"
            };

        logItem.Click += (s, e) =>
            OpenLogDirectory();

        contextMenu.Items.Add(logItem);

        contextMenu.Items.Add(
            new System.Windows.Controls.Separator());

        // ✅ 修改这里：直接退出，不等待
        var exitItem =
            new System.Windows.Controls.MenuItem
            {
                Header = "❌ 退出"
            };

        exitItem.Click += (s, e) =>
        {
            // 立即退出，不显示确认对话框
            Environment.Exit(0);
        };

        contextMenu.Items.Add(exitItem);

        _notifyIcon.ContextMenu = contextMenu;

        _ = UpdateTrayIconStatus();
    }
    
    private static async Task UpdateTrayIconStatus()
    {
        while (!_isShuttingDown)
        {
            try
            {
                if (_notifyIcon == null) break;
                
                var isConnected = false;
                var remoteScreen = _host?.Services.GetService<IRemoteScreenService>();
                if (remoteScreen != null)
                {
                    isConnected = remoteScreen.IsStreaming;
                }
                
                var stats = remoteScreen?.GetStats();
                var tooltip = isConnected 
                    ? $"Enterprise Agent - 🟢 在线\nFPS: {stats?.CurrentFps:F1} | 质量: {stats?.CurrentQuality}% | 格式: {stats?.CurrentFormat}"
                    : "Enterprise Agent - 🟡 连接中...";
                
                _notifyIcon.ToolTipText = tooltip;
            }
            catch { }
            
            await Task.Delay(5000);
        }
    }
    
    private static void ShowStatusWindow()
    {
        try
        {
            var stats = _host?.Services.GetService<IRemoteScreenService>()?.GetStats();
            var message = $"Enterprise Agent 状态\n\n" +
                         $"运行状态: {(stats?.IsStreaming == true ? "🟢 运行中" : "🔴 已停止")}\n" +
                         $"当前帧率: {stats?.CurrentFps:F1} / {stats?.TargetFps} fps\n" +
                         $"当前画质: {stats?.CurrentQuality}%\n" +
                         $"差异帧: {(stats?.EnableDiffFrame == true ? "✅" : "❌")}\n" +
                         $"区域帧: {(stats?.EnableRegionFrame == true ? "✅" : "❌")}\n" +
                         $"发送帧数: {stats?.FramesSent}\n" +
                         $"差异帧数: {stats?.DiffFramesSent}\n" +
                         $"区域帧数: {stats?.RegionFramesSent}\n" +
                         $"跳过帧数: {stats?.FramesSkipped}\n" +
                         $"总流量: {stats?.TotalBytesSentMB:F2} MB\n" +
                         $"平均延迟: {stats?.AvgLatencyMs:F0} ms\n" +
                         $"编码耗时: {stats?.AvgEncodeTimeMs:F0} ms";
            
            WinMessageBox.Show(message, "系统状态", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "显示状态窗口失败");
        }
    }
    
    private static async Task ShowHealthStatusAsync()
    {
        try
        {
            var healthMonitor = _host?.Services.GetService<IHealthMonitorService>();
            if (healthMonitor == null) return;
            
            var summary = healthMonitor.GetSummary();
            var message = $"健康状态\n\n" +
                         $"总组件: {summary.Total}\n" +
                         $"健康: {summary.Healthy} ✅\n" +
                         $"降级: {summary.Degraded} ⚠️\n" +
                         $"异常: {summary.Unhealthy} ❌\n" +
                         $"未知: {summary.Unknown} ❓\n" +
                         $"健康率: {summary.HealthRate * 100:F1}%\n" +
                         $"恢复次数: {summary.TotalRecoveries}";
            
            WinMessageBox.Show(message, "健康状态", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "显示健康状态失败");
        }
    }
    
    private static async Task ShowRemoteStatsAsync()
    {
        try
        {
            var remoteScreen = _host?.Services.GetService<IRemoteScreenService>();
            if (remoteScreen == null) return;
            
            var stats = remoteScreen.GetStats();
            var message = $"远程屏幕统计\n\n" +
                         $"状态: {(stats.IsStreaming ? "🟢 推流中" : "🔴 已停止")}\n" +
                         $"帧率: {stats.CurrentFps:F1} / {stats.TargetFps} fps\n" +
                         $"画质: {stats.CurrentQuality}%\n" +
                         $"差异帧: {(stats.EnableDiffFrame ? "✅" : "❌")}\n" +
                         $"区域帧: {(stats.EnableRegionFrame ? "✅" : "❌")}\n\n" +
                         $"发送帧: {stats.FramesSent}\n" +
                         $"差异帧: {stats.DiffFramesSent}\n" +
                         $"区域帧: {stats.RegionFramesSent}\n" +
                         $"跳过帧: {stats.FramesSkipped}\n\n" +
                         $"总流量: {stats.TotalBytesSentMB:F2} MB\n" +
                         $"平均延迟: {stats.AvgLatencyMs:F0} ms\n" +
                         $"编码耗时: {stats.AvgEncodeTimeMs:F0} ms";
            
            WinMessageBox.Show(message, "远程屏幕", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "显示远程屏幕统计失败");
        }
    }
    
    private static async Task PauseMonitoringAsync()
    {
        try
        {
            var remoteScreen = _host?.Services.GetService<IRemoteScreenService>();
            remoteScreen?.Stop();
            Log.Information("监控已暂停");
            
            _notifyIcon?.ShowBalloonTip("监控", "监控已暂停", BalloonIcon.Info);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "暂停监控失败");
        }
    }
    
    private static async Task TakeScreenshotNowAsync()
    {
        try
        {
            var screenshotService = _host?.Services.GetService<IScreenshotCaptureService>();
            if (screenshotService != null)
            {
                await screenshotService.CaptureAsync();
                Log.Information("立即截图已触发");
                _notifyIcon?.ShowBalloonTip("截图", "已触发立即截图", BalloonIcon.Info);
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "立即截图失败");
        }
    }
    
    private static async Task ReconnectAsync()
    {
        try
        {
            var webSocket = _host?.Services.GetService<IWebSocketService>();
            if (webSocket != null)
            {
                await webSocket.ReconnectAsync();
                Log.Information("手动重连已触发");
                _notifyIcon?.ShowBalloonTip("重连", "正在重新连接...", BalloonIcon.Info);
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "重连失败");
        }
    }
    
    private static async Task ToggleAutoStartAsync(System.Windows.Controls.MenuItem autoStartItem)
    {
        try
        {
            var autoStartManager = new AutoStartManager("EnterpriseAgent");
            var isEnabled = autoStartManager.IsEnabled();
            
            if (isEnabled)
            {
                var result = WinMessageBox.Show("确定要禁用开机自启吗？\n\n禁用后，系统启动时将不会自动运行本程序。", 
                    "确认禁用", MessageBoxButton.YesNo, MessageBoxImage.Question);
                
                if (result == MessageBoxResult.Yes)
                {
                    autoStartManager.Disable();
                    _autoStartMenuChecked = false;
                    autoStartItem.Header = "⚡ 开机自启";
                    _notifyIcon?.ShowBalloonTip("开机自启", "已禁用开机自启", BalloonIcon.Info);
                    Log.Information("开机自启已禁用");
                }
            }
            else
            {
                var result = WinMessageBox.Show("确定要启用开机自启吗？\n\n启用后，本程序将在系统启动时自动运行。", 
                    "确认启用", MessageBoxButton.YesNo, MessageBoxImage.Question);
                
                if (result == MessageBoxResult.Yes)
                {
                    autoStartManager.Enable();
                    _autoStartMenuChecked = true;
                    autoStartItem.Header = "⚡ 开机自启 ✓";
                    _notifyIcon?.ShowBalloonTip("开机自启", "已启用开机自启", BalloonIcon.Info);
                    Log.Information("开机自启已启用");
                }
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "切换开机自启失败");
            _notifyIcon?.ShowBalloonTip("开机自启失败", ex.Message, BalloonIcon.Error);
        }
    }
    
    private static async Task RestartAsync()
    {
        try
        {
            _isRestarting = true;
            Log.Information("正在重启应用...");
            _notifyIcon?.ShowBalloonTip("重启", "正在重启应用...", BalloonIcon.Info);
            
            var exePath = Environment.ProcessPath;
            if (string.IsNullOrEmpty(exePath))
            {
                Log.Error("无法获取可执行文件路径");
                _notifyIcon?.ShowBalloonTip("重启失败", "无法获取可执行文件路径", BalloonIcon.Error);
                _isRestarting = false;
                return;
            }
            
            var newProcess = new System.Diagnostics.Process();
            newProcess.StartInfo.FileName = exePath;
            newProcess.StartInfo.UseShellExecute = true;
            newProcess.StartInfo.Arguments = "-silent";
            newProcess.Start();
            
            Log.Information("新进程已启动，PID: {0}", newProcess.Id);
            
            await Task.Delay(1000);
            
            Shutdown(0);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "重启失败");
            _notifyIcon?.ShowBalloonTip("重启失败", ex.Message, BalloonIcon.Error);
            _isRestarting = false;
        }
    }
    
    private static void OpenLogDirectory()
    {
        try
        {
            var logDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "EnterpriseAgent", "Logs");
            
            if (Directory.Exists(logDirectory))
            {
                System.Diagnostics.Process.Start("explorer.exe", logDirectory);
            }
            else
            {
                WinMessageBox.Show("日志目录不存在", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "打开日志目录失败");
            WinMessageBox.Show($"打开日志目录失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
    
    private static async Task ShutdownAsync()
    {
        var result = WinMessageBox.Show("确定要退出程序吗？", "确认退出", 
            MessageBoxButton.YesNo, MessageBoxImage.Question);
        
        if (result == MessageBoxResult.Yes)
        {
            Environment.Exit(0);
        }
    }
    
    private static void Shutdown(int exitCode)
    {
        lock (_shutdownLock)
        {
            if (_isShuttingDown) return;
            _isShuttingDown = true;
        }
        
        Log.Information("正在优雅关闭应用...");
        
        try
        {
            var remoteScreen = _host?.Services.GetService<IRemoteScreenService>();
            remoteScreen?.Stop();
            
            var webSocket = _host?.Services.GetService<IWebSocketService>();
            webSocket?.DisconnectAsync().Wait(TimeSpan.FromSeconds(5));
            
            if (_host != null)
            {
                _host.StopAsync().Wait(TimeSpan.FromSeconds(30));
                _host.Dispose();
            }
            
            if (_notifyIcon != null)
            {
                _notifyIcon.Visibility = Visibility.Collapsed;
                _notifyIcon.Dispose();
                _notifyIcon = null;
            }
            
            _appMutex?.ReleaseMutex();
            _appMutex?.Dispose();
            
            Log.CloseAndFlush();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"关闭异常: {ex.Message}");
        }
        finally
        {
            Environment.Exit(exitCode);
        }
    }
    
    private static void OnConnectionStateChanged(object? sender, bool isConnected)
    {
        if (isConnected)
        {
            Log.Information("🔌 连接已恢复");
            _notifyIcon?.ShowBalloonTip("连接", "已连接到服务器", BalloonIcon.Info);
        }
        else
        {
            Log.Warning("⚠️ 连接已断开");
            _notifyIcon?.ShowBalloonTip("连接", "连接已断开，正在重连...", BalloonIcon.Warning);
        }
    }
    
    private static void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        Log.Fatal(e.Exception, "UI线程未处理异常");
        e.Handled = true;
        
        WinMessageBox.Show($"发生错误: {e.Exception.Message}\n\n程序将继续运行。", 
            "错误", MessageBoxButton.OK, MessageBoxImage.Error);
    }
    
    private static void OnProcessExit(object? sender, EventArgs e) => Shutdown(0);
    
    private static void OnCancelKeyPress(object? sender, ConsoleCancelEventArgs e) 
    { 
        e.Cancel = true; 
        Shutdown(0); 
    }
    
    private static void OnApplicationExit(object? sender, ExitEventArgs e) => Shutdown(e.ApplicationExitCode);
    
    private static void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
    {
        Log.Fatal(e.ExceptionObject as Exception, "未处理的异常");
        
        if (!_isRestarting)
        {
            WinMessageBox.Show($"程序发生未处理异常: {e.ExceptionObject}", 
                "错误", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
    
    private static void OnUnobservedTaskException(object? sender, UnobservedTaskExceptionEventArgs e)
    {
        Log.Fatal(e.Exception, "未观察到的任务异常");
        e.SetObserved();
    }
    
    private static void OnMemoryWarning(object? sender, MemoryWarningEventArgs e)
    {
        Log.Warning($"内存警告: {e.WarningType} - 当前内存: {e.CurrentMemoryMB}MB");
        
        if (e.WarningType == "critical")
        {
            _notifyIcon?.ShowBalloonTip("内存警告", $"内存使用过高: {e.CurrentMemoryMB}MB", BalloonIcon.Warning);
        }
    }
}

/// <summary>
/// 开机自启管理器
/// </summary>
public class AutoStartManager
{
    private readonly string _appName;
    private readonly string _exePath;
    
    public AutoStartManager(string appName)
    {
        _appName = appName;
        _exePath = Environment.ProcessPath ?? System.Reflection.Assembly.GetExecutingAssembly().Location;
    }
    
    public bool IsEnabled()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", false);
            var value = key?.GetValue(_appName)?.ToString();
            return !string.IsNullOrEmpty(value);
        }
        catch
        {
            return false;
        }
    }
    
    public void Enable()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
            if (key != null)
            {
                key.SetValue(_appName, $"\"{_exePath}\" -silent");
                Log.Information("✅ 开机自启已启用");
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "启用开机自启失败");
            throw;
        }
    }
    
    public void Disable()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
            key?.DeleteValue(_appName, false);
            Log.Information("✅ 开机自启已禁用");
        }
        catch (Exception ex)
        {
            Log.Error(ex, "禁用开机自启失败");
            throw;
        }
    }
}
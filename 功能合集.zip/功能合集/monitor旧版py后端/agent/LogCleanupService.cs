using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public interface ILogCleanupService
{
    void Start();
    void Stop();
}

public class LogCleanupService : ILogCleanupService, IHostedService
{
    private readonly string _logDirectory;
    private System.Threading.Timer? _cleanupTimer;
    private int _isRunning;
    private readonly int _retentionDays = 7;
    private readonly long _maxTotalSizeMB = 500;
    private readonly SemaphoreSlim _cleanupLock = new(1, 1);
    
    public LogCleanupService()
    {
        _logDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "EnterpriseAgent", "Logs");
        Directory.CreateDirectory(_logDirectory);
    }
    
    public void Start()
    {
        if (Interlocked.Exchange(ref _isRunning, 1) == 1) return;
        
        _cleanupTimer = new System.Threading.Timer(
            async _ => await CleanupAsync(),
            null,
            TimeSpan.FromHours(1),
            TimeSpan.FromHours(1));
        
        // 启动时立即执行一次
        Task.Run(CleanupAsync);
        
        Log.Information("✅ 日志清理服务已启动");
    }
    
    public void Stop()
    {
        if (Interlocked.Exchange(ref _isRunning, 0) == 0) return;
        
        _cleanupTimer?.Dispose();
        _cleanupTimer = null;
        
        Log.Information("日志清理服务已停止");
    }
    
    private async Task CleanupAsync()
    {
        if (!await _cleanupLock.WaitAsync(0)) return;
        
        try
        {
            if (!Directory.Exists(_logDirectory)) return;
            
            var now = DateTime.UtcNow;
            var files = Directory.GetFiles(_logDirectory, "*.log")
                .Select(f => new FileInfo(f))
                .OrderBy(f => f.CreationTimeUtc)
                .ToList();
            
            long totalSizeMB = 0;
            var toDelete = new List<FileInfo>();
            
            foreach (var file in files)
            {
                // 按日期清理
                if (file.CreationTimeUtc < now.AddDays(-_retentionDays))
                {
                    toDelete.Add(file);
                    continue;
                }
                
                totalSizeMB += file.Length / (1024 * 1024);
                
                // 按总大小清理
                if (totalSizeMB > _maxTotalSizeMB)
                {
                    toDelete.Add(file);
                }
            }
            
            foreach (var file in toDelete)
            {
                try
                {
                    file.Delete();
                    Log.Information($"已删除过期日志: {file.Name}");
                }
                catch (Exception ex)
                {
                    Log.Error(ex, $"删除日志失败: {file.Name}");
                }
            }
            
            if (toDelete.Count > 0)
            {
                Log.Information($"🧹 日志清理完成: 删除 {toDelete.Count} 个文件，释放 {toDelete.Sum(f => f.Length) / (1024 * 1024):F1} MB");
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "日志清理异常");
        }
        finally
        {
            _cleanupLock.Release();
        }
    }
    
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
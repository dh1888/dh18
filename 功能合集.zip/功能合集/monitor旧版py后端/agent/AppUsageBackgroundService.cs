using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public class AppUsageBackgroundService : BackgroundService
{
    private readonly IAppMonitorService _appMonitorService;
    
    public AppUsageBackgroundService(IAppMonitorService appMonitorService)
    {
        _appMonitorService = appMonitorService;
    }
    
    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _appMonitorService.Start();
        return Task.CompletedTask;
    }
    
    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _appMonitorService.Stop();
        await base.StopAsync(cancellationToken);
    }
}
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Channels;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace EnterpriseAgent;

public interface IRemoteScreenService
{
    void Start();
    void Stop();
    bool IsStreaming { get; }
    event EventHandler<RemoteScreenFrame>? FrameCaptured;
    void UpdateQuality(int quality);
    void UpdateFps(int fps);
    RemoteScreenStats GetStats();
}

public class RemoteScreenFrame
{
    public byte[] Data { get; set; } = Array.Empty<byte>();
    public int Width { get; set; }
    public int Height { get; set; }
    public int FrameType { get; set; }
    public int FrameId { get; set; }
    public long TimestampMs { get; set; }
    public string Format { get; set; } = "jpeg";  // 改为默认 jpeg，避免 WebP 许可证问题
}

public class RemoteScreenStats
{
    public bool IsStreaming { get; set; }
    public double CurrentFps { get; set; }
    public int TargetFps { get; set; }
    public int CurrentQuality { get; set; }
    public bool EnableDiffFrame { get; set; }
    public bool EnableRegionFrame { get; set; }
    public int FramesSent { get; set; }
    public int DiffFramesSent { get; set; }
    public int RegionFramesSent { get; set; }
    public int FramesSkipped { get; set; }
    public double TotalBytesSentMB { get; set; }
    public double AvgLatencyMs { get; set; }
    public double AvgEncodeTimeMs { get; set; }
    public bool UseOpenCv { get; set; }
    public bool UseHardwareEncoding { get; set; }
    public string CurrentFormat { get; set; } = "jpeg";
}

/// <summary>
/// 移动平均计算器
/// </summary>
public class MovingAverage
{
    private readonly ConcurrentQueue<double> _values = new();
    private readonly int _windowSize;
    private double _sum;
    private readonly object _lock = new();
    
    public MovingAverage(int windowSize = 10)
    {
        _windowSize = windowSize;
    }
    
    public void Add(double value)
    {
        lock (_lock)
        {
            _values.Enqueue(value);
            _sum += value;
            
            while (_values.Count > _windowSize)
            {
                if (_values.TryDequeue(out var old))
                    _sum -= old;
            }
        }
    }
    
    public double Value
    {
        get
        {
            lock (_lock)
            {
                return _values.Count == 0 ? 0 : _sum / _values.Count;
            }
        }
    }
    
    public void Clear()
    {
        lock (_lock)
        {
            _values.Clear();
            _sum = 0;
        }
    }
}

/// <summary>
/// 运动检测器 - 检测屏幕中的运动区域（纯 C# 降级方案）
/// </summary>
public class MotionDetector
{
    private byte[]? _previousFrame;
    private int _previousWidth;
    private int _previousHeight;
    private readonly int _diffThreshold = 25;
    private readonly int _minMotionArea = 800;
    private readonly int _sampleRate = 8;
    
    public List<MotionRegion> DetectMotion(Bitmap currentFrame)
    {
        var regions = new List<MotionRegion>();
        
        try
        {
            int width = currentFrame.Width;
            int height = currentFrame.Height;
            
            int sampleWidth = width / _sampleRate;
            int sampleHeight = height / _sampleRate;
            
            if (sampleWidth < 10 || sampleHeight < 10) return regions;
            
            using var smallFrame = new Bitmap(currentFrame, new Size(sampleWidth, sampleHeight));
            var currentBytes = BitmapToBytes(smallFrame);
            
            if (_previousFrame == null || _previousWidth != sampleWidth || _previousHeight != sampleHeight)
            {
                _previousFrame = currentBytes;
                _previousWidth = sampleWidth;
                _previousHeight = sampleHeight;
                return regions;
            }
            
            var motionMap = new float[sampleWidth, sampleHeight];
            float maxMotion = 0;
            
            unsafe
            {
                fixed (byte* currentPtr = currentBytes)
                fixed (byte* previousPtr = _previousFrame)
                {
                    for (int y = 0; y < sampleHeight; y++)
                    {
                        for (int x = 0; x < sampleWidth; x++)
                        {
                            int idx = (y * sampleWidth + x) * 3;
                            
                            int diffR = Math.Abs(currentPtr[idx] - previousPtr[idx]);
                            int diffG = Math.Abs(currentPtr[idx + 1] - previousPtr[idx + 1]);
                            int diffB = Math.Abs(currentPtr[idx + 2] - previousPtr[idx + 2]);
                            
                            float motion = (diffR + diffG + diffB) / 3.0f;
                            motionMap[x, y] = motion;
                            if (motion > maxMotion) maxMotion = motion;
                        }
                    }
                }
            }
            
            if (maxMotion < 5) return regions;
            
            float threshold = maxMotion * 0.3f;
            var visited = new bool[sampleWidth, sampleHeight];
            
            for (int y = 0; y < sampleHeight; y++)
            {
                for (int x = 0; x < sampleWidth; x++)
                {
                    if (motionMap[x, y] > threshold && !visited[x, y])
                    {
                        var (minX, minY, maxX, maxY, avgMotion, area) = FloodFill(
                            motionMap, visited, x, y, sampleWidth, sampleHeight);
                        
                        int motionAreaPixels = area * _sampleRate * _sampleRate;
                        if (motionAreaPixels >= _minMotionArea)
                        {
                            regions.Add(new MotionRegion
                            {
                                X = minX * _sampleRate,
                                Y = minY * _sampleRate,
                                Width = (maxX - minX + 1) * _sampleRate,
                                Height = (maxY - minY + 1) * _sampleRate,
                                MotionIntensity = avgMotion / 255.0f
                            });
                        }
                    }
                }
            }
            
            regions = MergeOverlappingRegions(regions);
            regions = regions.OrderByDescending(r => r.MotionIntensity).ToList();
            _previousFrame = currentBytes;
        }
        catch (Exception ex)
        {
            Log.Error(ex, "运动检测失败");
        }
        
        return regions;
    }
    
    private (int minX, int minY, int maxX, int maxY, float avgMotion, int area) FloodFill(
        float[,] motionMap, bool[,] visited, int startX, int startY, int width, int height)
    {
        int minX = startX, maxX = startX;
        int minY = startY, maxY = startY;
        float totalMotion = 0;
        int pixelCount = 0;
        
        var queue = new Queue<(int x, int y)>();
        queue.Enqueue((startX, startY));
        visited[startX, startY] = true;
        
        while (queue.Count > 0)
        {
            var (x, y) = queue.Dequeue();
            
            minX = Math.Min(minX, x);
            maxX = Math.Max(maxX, x);
            minY = Math.Min(minY, y);
            maxY = Math.Max(maxY, y);
            totalMotion += motionMap[x, y];
            pixelCount++;
            
            if (x > 0 && !visited[x - 1, y] && motionMap[x - 1, y] > motionMap[startX, startY] * 0.5f)
            {
                visited[x - 1, y] = true;
                queue.Enqueue((x - 1, y));
            }
            if (x < width - 1 && !visited[x + 1, y] && motionMap[x + 1, y] > motionMap[startX, startY] * 0.5f)
            {
                visited[x + 1, y] = true;
                queue.Enqueue((x + 1, y));
            }
            if (y > 0 && !visited[x, y - 1] && motionMap[x, y - 1] > motionMap[startX, startY] * 0.5f)
            {
                visited[x, y - 1] = true;
                queue.Enqueue((x, y - 1));
            }
            if (y < height - 1 && !visited[x, y + 1] && motionMap[x, y + 1] > motionMap[startX, startY] * 0.5f)
            {
                visited[x, y + 1] = true;
                queue.Enqueue((x, y + 1));
            }
        }
        
        return (minX, minY, maxX, maxY, totalMotion / pixelCount, pixelCount);
    }
    
    private List<MotionRegion> MergeOverlappingRegions(List<MotionRegion> regions)
    {
        if (regions.Count <= 1) return regions;
        
        var merged = new List<MotionRegion>();
        var sorted = regions.OrderBy(r => r.X).ToList();
        
        var current = sorted[0];
        for (int i = 1; i < sorted.Count; i++)
        {
            var next = sorted[i];
            
            if (current.X + current.Width >= next.X - 50 &&
                current.Y + current.Height >= next.Y - 50)
            {
                int newX = Math.Min(current.X, next.X);
                int newY = Math.Min(current.Y, next.Y);
                int newWidth = Math.Max(current.X + current.Width, next.X + next.Width) - newX;
                int newHeight = Math.Max(current.Y + current.Height, next.Y + next.Height) - newY;
                
                current = new MotionRegion
                {
                    X = newX,
                    Y = newY,
                    Width = newWidth,
                    Height = newHeight,
                    MotionIntensity = Math.Max(current.MotionIntensity, next.MotionIntensity)
                };
            }
            else
            {
                merged.Add(current);
                current = next;
            }
        }
        merged.Add(current);
        
        return merged;
    }
    
    private byte[] BitmapToBytes(Bitmap bitmap)
    {
        var data = bitmap.LockBits(
            new Rectangle(0, 0, bitmap.Width, bitmap.Height),
            ImageLockMode.ReadOnly,
            PixelFormat.Format24bppRgb);
        
        var bytes = new byte[data.Stride * data.Height];
        Marshal.Copy(data.Scan0, bytes, 0, bytes.Length);
        bitmap.UnlockBits(data);
        
        return bytes;
    }
    
    public void Reset()
    {
        _previousFrame = null;
    }
}

public class MotionRegion
{
    public int X { get; set; }
    public int Y { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public float MotionIntensity { get; set; }
    
    public Rectangle ToRectangle() => new Rectangle(X, Y, Width, Height);
}

/// <summary>
/// 检测结果类（用于 OpenCV 和纯 C# 统一返回）
/// </summary>
public class DetectionResult
{
    public List<Rectangle> RegionsToSend { get; set; } = new();
    public double ChangeRatio { get; set; }
    public bool ShouldSendFullFrame { get; set; }
    public bool ShouldSendDiffFrame { get; set; }
    public bool ShouldSendRegionFrame { get; set; }
    public long DetectionTimeMs { get; set; }
}

public class RemoteScreenService : IRemoteScreenService, IDisposable
{
    private readonly IConfigurationService _configService;
    private readonly IWebSocketService _webSocketService;
    private CancellationTokenSource? _cts;
    private Task? _captureLoopTask;
    private Task? _sendLoopTask;
    private int _isStreaming;
    private int _frameId;
    private bool _disposed;
    
    // ========== 动态参数 ==========
    private int _targetWidth = 1280;
    private int _targetQuality = 70;
    private int _targetFps = 5;
    private int _minQuality = 30;
    private int _maxQuality = 90;
    private int _minFps = 1;
    private int _maxFps = 10;
    private string _targetFormat = "jpeg";  // 改为默认 jpeg
    
    // ========== 帧类型控制 ==========
    private byte[]? _previousFrameData;
    private Bitmap? _backgroundFrame;
    private bool _enableDiffFrame = true;
    private bool _enableRegionFrame = true;
    
    // ========== 检测参数 ==========
    private readonly int _diffThreshold = 30;
    private readonly int _minRegionArea = 500;
    private readonly int _backgroundQuality = 25;
    
    // ========== 混合方案组件 ==========
    private readonly MotionDetector _motionDetector = new();
    private dynamic? _openCvDetector;
    private dynamic? _hwEncoder;
    private bool _useOpenCv = false;
    private bool _useHardwareEncoding = false;
    private bool _useWebP = false;  // 默认 false，使用 JPEG
    
    // OpenCV 统计
    private int _openCvFrames;
    private double _avgOpenCvTime;
    
    // ========== 自适应控制 ==========
    private readonly MovingAverage _networkLatency = new(10);
    private readonly MovingAverage _encodeTime = new(5);
    private DateTime _lastAdjustTime;
    private readonly TimeSpan _adjustInterval = TimeSpan.FromSeconds(5);
    
    // ========== 性能统计 ==========
    private readonly ConcurrentQueue<long> _frameTimeQueue = new();
    private double _actualFps;
    private long _totalBytesSent;
    private int _framesSent;
    private int _framesSkipped;
    private int _diffFramesSent;
    private int _regionFramesSent;
    
    // ========== 帧通道 ==========
    private readonly Channel<RemoteScreenFrame> _frameChannel;
    
    public bool IsStreaming => Interlocked.CompareExchange(ref _isStreaming, 0, 0) == 1;
    public event EventHandler<RemoteScreenFrame>? FrameCaptured;
    
    public RemoteScreenService(
        IConfigurationService configService,
        IWebSocketService webSocketService)
    {
        _configService = configService;
        _webSocketService = webSocketService;
        _frameChannel = Channel.CreateBounded<RemoteScreenFrame>(new BoundedChannelOptions(10)
        {
            FullMode = BoundedChannelFullMode.DropOldest
        });
        
        _webSocketService.MessageReceived += OnWebSocketMessage;
        LoadConfiguration();
        
        InitializeHybridComponents();
    }
    
    private void LoadConfiguration()
    {
        var config = _configService.Load();
        if (config != null)
        {
            _targetFps = Math.Clamp(config.ScreenshotInterval > 0 ? 60 / config.ScreenshotInterval : 5, _minFps, _maxFps);
            _targetQuality = Math.Clamp(config.ScreenshotQuality, _minQuality, _maxQuality);
            
            // 读取格式配置，默认 jpeg（避免 WebP 许可证问题）
            _targetFormat = config.ScreenshotFormat?.ToLower() ?? "jpeg";
            if (_targetFormat != "jpeg" && _targetFormat != "jpg")
            {
                _targetFormat = "jpeg";
            }
            _useWebP = false;  // 禁用 WebP
        }
    }
    
    private void InitializeHybridComponents()
    {
        // 1. 尝试加载 OpenCV
        try
        {
            var openCvType = Type.GetType("OpenCvSharp.Cv2, OpenCvSharp4");
            if (openCvType != null)
            {
                var detectorType = Type.GetType("EnterpriseAgent.OpenCvMotionDetector, EnterpriseAgent");
                if (detectorType != null)
                {
                    _openCvDetector = Activator.CreateInstance(detectorType, 500, 0.05);
                    _useOpenCv = true;
                    Log.Information("✅ OpenCV 高精度检测器已启用");
                }
            }
        }
        catch (Exception ex)
        {
            Log.Warning($"OpenCV 初始化失败: {ex.Message}，降级到纯 C# 检测器");
        }
        
        // 2. 尝试加载硬件加速编码器
        try
        {
            var encoderType = Type.GetType("EnterpriseAgent.HardwareAcceleratedEncoder, EnterpriseAgent");
            if (encoderType != null)
            {
                _hwEncoder = Activator.CreateInstance(encoderType, _targetQuality, true);
                _useHardwareEncoding = true;
                Log.Information("✅ 硬件加速编码器已启用");
            }
        }
        catch (Exception ex)
        {
            Log.Warning($"硬件加速编码器初始化失败: {ex.Message}，降级到标准编码");
        }
        
        Log.Information($"📷 图像格式: JPEG");
    }

    private DetectionResult PerformDetection(Bitmap bitmap)
    {
        var result = new DetectionResult();

        if (_useOpenCv && _openCvDetector != null)
        {
            try
            {
                var sw = System.Diagnostics.Stopwatch.StartNew();

                var detectMethod = _openCvDetector!.GetType().GetMethod("Detect");

                if (detectMethod != null)
                {
                    var openCvResult = detectMethod.Invoke(
                        _openCvDetector,
                        new object[] { bitmap });

                    if (openCvResult != null)
                    {
                        var regionsProp =
                            openCvResult.GetType()
                                .GetProperty("RegionsToSend");

                        var changeRatioProp =
                            openCvResult.GetType()
                                .GetProperty("ChangeRatio");

                        var shouldFullProp =
                            openCvResult.GetType()
                                .GetProperty("ShouldSendFullFrame");

                        var shouldDiffProp =
                            openCvResult.GetType()
                                .GetProperty("ShouldSendDiffFrame");

                        var shouldRegionProp =
                            openCvResult.GetType()
                                .GetProperty("ShouldSendRegionFrame");

                        var timeProp =
                            openCvResult.GetType()
                                .GetProperty("DetectionTimeMs");

                        result.RegionsToSend =
                            (List<Rectangle>)(
                                regionsProp?.GetValue(openCvResult)
                                ?? new List<Rectangle>());

                        result.ChangeRatio =
                            (double)(
                                changeRatioProp?.GetValue(openCvResult)
                                ?? 1.0);

                        result.ShouldSendFullFrame =
                            (bool)(
                                shouldFullProp?.GetValue(openCvResult)
                                ?? true);

                        result.ShouldSendDiffFrame =
                            (bool)(
                                shouldDiffProp?.GetValue(openCvResult)
                                ?? false);

                        result.ShouldSendRegionFrame =
                            (bool)(
                                shouldRegionProp?.GetValue(openCvResult)
                                ?? false);

                        result.DetectionTimeMs =
                            (long)(
                                timeProp?.GetValue(openCvResult)
                                ?? 0L);

                        sw.Stop();

                        _openCvFrames++;

                        _avgOpenCvTime =
                            (_avgOpenCvTime * (_openCvFrames - 1)
                             + result.DetectionTimeMs)
                            / _openCvFrames;

                        if (_openCvFrames % 50 == 0)
                        {
                            Log.Debug(
                                $"OpenCV 检测: 平均={_avgOpenCvTime:F1}ms, " +
                                $"变化率={result.ChangeRatio:P1}, " +
                                $"区域={result.RegionsToSend.Count}");
                        }

                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Debug(
                    $"OpenCV 检测失败: {ex.Message}，降级到纯 C#");
            }
        }

        // 降级：纯 C# 运动检测
        var motionRegions = _motionDetector.DetectMotion(bitmap);

        result.RegionsToSend =
            motionRegions
                .Select(r => r.ToRectangle())
                .ToList();

        result.ChangeRatio =
            _previousFrameData == null
                ? 1.0
                : 0.1;

        result.ShouldSendFullFrame =
            _previousFrameData == null
            || result.RegionsToSend.Count > 20;

        result.ShouldSendDiffFrame =
            !result.ShouldSendFullFrame
            && result.RegionsToSend.Count > 0;

        result.ShouldSendRegionFrame =
            !result.ShouldSendFullFrame
            && result.RegionsToSend.Count > 0
            && result.RegionsToSend.Count <= 10;

        result.DetectionTimeMs = 0;

        return result;
    }
    
    /// <summary>
    /// 将 Bitmap 转换为 byte[]（用于 ImageSharp）
    /// </summary>
    private byte[] BitmapToByteArray(Bitmap bitmap)
    {
        using var ms = new MemoryStream();
        bitmap.Save(ms, ImageFormat.Bmp);
        return ms.ToArray();
    }
    
    /// <summary>
    /// WebP 编码 - 已禁用（需要商业许可证）
    /// </summary>
    private byte[]? EncodeToWebP(Bitmap bitmap, int quality)
    {
        // WebP 编码需要商业许可证，直接返回 null，使用 JPEG 降级
        return null;
    }
    
    /// <summary>
    /// JPEG 编码
    /// </summary>
    private byte[]? EncodeToJpeg(Bitmap bitmap, int quality)
    {
        try
        {
            var codec = GetEncoder(ImageFormat.Jpeg);
            var encoderParams = new EncoderParameters(1);
            encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, quality);
            
            using var ms = new MemoryStream();
            bitmap.Save(ms, codec, encoderParams);
            return ms.ToArray();
        }
        catch (Exception ex)
        {
            Log.Error($"JPEG 编码失败: {ex.Message}");
            return null;
        }
    }
    
    /// <summary>
    /// 编码完整帧（使用 JPEG）
    /// </summary>
    private byte[]? EncodeFullFrame(Bitmap bitmap, int quality)
    {
        // 优先使用硬件加速编码
        if (_useHardwareEncoding && _hwEncoder != null)
        {
            try
            {
                // 添加 !
                var encodeMethod =
                    _hwEncoder!.GetType()
                        .GetMethod("EncodeFullFrame");

                if (encodeMethod != null)
                {
                    return (byte[]?)encodeMethod.Invoke(
                        _hwEncoder,
                        new object[] { bitmap, quality });
                }
            }
            catch (Exception ex)
            {
                Log.Debug(
                    $"硬件加速编码失败: {ex.Message}，降级到标准编码");
            }
        }

        // 使用 JPEG
        return EncodeToJpeg(bitmap, quality);
    }
    
    // ==================== 差异帧检测 ====================
    
    private List<Rectangle> DetectChangedRegions(Bitmap current, Bitmap previous)
    {
        var regions = new List<Rectangle>();
        
        try
        {
            if (current.Width != previous.Width || current.Height != previous.Height)
                return regions;
            
            int sampleWidth = Math.Min(320, current.Width);
            int sampleHeight = Math.Min(240, current.Height);
            
            using var smallCurrent = new Bitmap(current, new Size(sampleWidth, sampleHeight));
            using var smallPrevious = new Bitmap(previous, new Size(sampleWidth, sampleHeight));
            
            var currentData = smallCurrent.LockBits(
                new Rectangle(0, 0, sampleWidth, sampleHeight),
                ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            var previousData = smallPrevious.LockBits(
                new Rectangle(0, 0, sampleWidth, sampleHeight),
                ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            
            try
            {
                unsafe
                {
                    byte* currentPtr = (byte*)currentData.Scan0;
                    byte* previousPtr = (byte*)previousData.Scan0;
                    int stride = currentData.Stride;
                    
                    int blockSize = 16;
                    var changedBlocks = new List<(int x, int y)>();
                    
                    for (int y = 0; y < sampleHeight; y += blockSize)
                    {
                        for (int x = 0; x < sampleWidth; x += blockSize)
                        {
                            if (IsBlockChanged(currentPtr, previousPtr, stride, x, y, blockSize))
                            {
                                changedBlocks.Add((x, y));
                            }
                        }
                    }
                    
                    regions = MergeBlocks(changedBlocks, sampleWidth, sampleHeight, blockSize);
                    
                    float scaleX = (float)current.Width / sampleWidth;
                    float scaleY = (float)current.Height / sampleHeight;
                    for (int i = 0; i < regions.Count; i++)
                    {
                        var r = regions[i];
                        regions[i] = new Rectangle(
                            (int)(r.X * scaleX),
                            (int)(r.Y * scaleY),
                            (int)(r.Width * scaleX),
                            (int)(r.Height * scaleY)
                        );
                    }
                }
            }
            finally
            {
                smallCurrent.UnlockBits(currentData);
                smallPrevious.UnlockBits(previousData);
            }
        }
        catch (Exception ex)
        {
            Log.Error($"差异检测失败: {ex.Message}");
        }
        
        return regions;
    }
    
    private unsafe bool IsBlockChanged(byte* current, byte* previous, int stride, int x, int y, int blockSize)
    {
        int diffCount = 0;
        int totalPixels = blockSize * blockSize;
        int threshold = totalPixels / 10;
        
        for (int dy = 0; dy < blockSize; dy++)
        {
            int yPos = y + dy;
            if (yPos >= 240) break;
            
            byte* curRow = current + yPos * stride + x * 3;
            byte* prevRow = previous + yPos * stride + x * 3;
            
            for (int dx = 0; dx < blockSize; dx++)
            {
                if (x + dx >= 320) break;
                
                int diffR = Math.Abs(curRow[0] - prevRow[0]);
                int diffG = Math.Abs(curRow[1] - prevRow[1]);
                int diffB = Math.Abs(curRow[2] - prevRow[2]);
                
                if (diffR > _diffThreshold || diffG > _diffThreshold || diffB > _diffThreshold)
                {
                    diffCount++;
                    if (diffCount > threshold)
                        return true;
                }
                
                curRow += 3;
                prevRow += 3;
            }
        }
        
        return false;
    }
    
    private List<Rectangle> MergeBlocks(List<(int x, int y)> blocks, int width, int height, int blockSize)
    {
        if (blocks.Count == 0) return new List<Rectangle>();
        
        var merged = new List<Rectangle>();
        var visited = new HashSet<(int, int)>();
        
        foreach (var block in blocks)
        {
            if (visited.Contains(block)) continue;
            
            int minX = block.x, maxX = block.x + blockSize;
            int minY = block.y, maxY = block.y + blockSize;
            visited.Add(block);
            
            bool expanded;
            do
            {
                expanded = false;
                foreach (var other in blocks)
                {
                    if (visited.Contains(other)) continue;
                    
                    if (Math.Abs(other.x - minX) <= blockSize * 2 &&
                        Math.Abs(other.y - minY) <= blockSize * 2)
                    {
                        minX = Math.Min(minX, other.x);
                        maxX = Math.Max(maxX, other.x + blockSize);
                        minY = Math.Min(minY, other.y);
                        maxY = Math.Max(maxY, other.y + blockSize);
                        visited.Add(other);
                        expanded = true;
                    }
                }
            } while (expanded);
            
            minX = Math.Max(0, minX - blockSize);
            maxX = Math.Min(width, maxX + blockSize);
            minY = Math.Max(0, minY - blockSize);
            maxY = Math.Min(height, maxY + blockSize);
            
            var rect = new Rectangle(minX, minY, maxX - minX, maxY - minY);
            if (rect.Width * rect.Height > _minRegionArea)
            {
                merged.Add(rect);
            }
        }
        
        return merged;
    }
    
    /// <summary>
    /// 编码单个区域为 JPEG
    /// </summary>
    private byte[]? EncodeRegion(Bitmap regionImg, int quality)
    {
        return EncodeToJpeg(regionImg, quality);
    }
    
    // ==================== 差异帧编码 ====================
    
    private byte[]? EncodeDiffFrame(Bitmap current, List<Rectangle> regions, int quality)
    {
        if (regions.Count == 0) return null;
        
        try
        {
            using var ms = new MemoryStream();
            using var writer = new BinaryWriter(ms);
            
            writer.Write((ushort)Math.Min(regions.Count, ushort.MaxValue));
            writer.Write((byte)quality);
            
            foreach (var region in regions)
            {
                using var regionImg = current.Clone(region, current.PixelFormat);
                var regionData = EncodeRegion(regionImg, quality);
                if (regionData == null) continue;
                
                writer.Write((ushort)region.X);
                writer.Write((ushort)region.Y);
                writer.Write((ushort)region.Width);
                writer.Write((ushort)region.Height);
                writer.Write(regionData.Length);
                writer.Write(regionData);
            }
            
            return ms.ToArray();
        }
        catch (Exception ex)
        {
            Log.Error($"编码差异帧失败: {ex.Message}");
            return null;
        }
    }
    
    // ==================== 区域帧编码 ====================
    
    private byte[]? EncodeRegionFrame(
        Bitmap current,
        List<Rectangle> regions,
        int quality)
    {
        if (regions.Count == 0 || _backgroundFrame == null)
            return null;

        try
        {
            using var ms = new MemoryStream();
            using var writer = new BinaryWriter(ms);

            writer.Write(
                (ushort)Math.Min(
                    regions.Count,
                    ushort.MaxValue));

            writer.Write((byte)quality);

            // 编码背景
            byte[] bgData;

            if (_useHardwareEncoding && _hwEncoder != null)
            {
                try
                {
                    // 添加 ! 告诉编译器我们知道 _hwEncoder 不为 null
                    var encodeMethod =
                        _hwEncoder!.GetType()
                            .GetMethod("EncodeFullFrame");

                    if (encodeMethod != null)
                    {
                        var result = encodeMethod.Invoke(
                            _hwEncoder,
                            new object[]
                            {
                                _backgroundFrame!,
                                _backgroundQuality
                            });

                        bgData =
                            (byte[]?)result
                            ?? Array.Empty<byte>();
                    }
                    else
                    {
                        bgData =
                            EncodeFullFrame(
                                _backgroundFrame!,
                                _backgroundQuality)
                            ?? Array.Empty<byte>();
                    }
                }
                catch
                {
                    bgData =
                        EncodeFullFrame(
                            _backgroundFrame!,
                            _backgroundQuality)
                        ?? Array.Empty<byte>();
                }
            }
            else
            {
                bgData =
                    EncodeFullFrame(
                        _backgroundFrame!,
                        _backgroundQuality)
                    ?? Array.Empty<byte>();
            }

            writer.Write(bgData.Length);
            writer.Write(bgData);

            // 编码每个变化区域
            foreach (var region in regions)
            {
                using var regionImg =
                    current.Clone(
                        region,
                        current.PixelFormat);

                var regionData =
                    EncodeRegion(
                        regionImg,
                        quality);

                if (regionData == null)
                    continue;

                writer.Write((ushort)region.X);
                writer.Write((ushort)region.Y);
                writer.Write((ushort)region.Width);
                writer.Write((ushort)region.Height);
                writer.Write(regionData.Length);
                writer.Write(regionData);
            }

            return ms.ToArray();
        }
        catch (Exception ex)
        {
            Log.Error(
                $"编码区域帧失败: {ex.Message}");

            return null;
        }
    }
    
    // ==================== 自适应参数调整 ====================
    
    private void AdjustParameters()
    {
        var now = DateTime.UtcNow;
        if (now - _lastAdjustTime < _adjustInterval) return;
        _lastAdjustTime = now;
        
        var avgLatency = _networkLatency.Value;
        var avgEncodeMs = _encodeTime.Value;
        
        if (avgLatency > 500)
        {
            _targetQuality = Math.Max(_minQuality, _targetQuality - 10);
            _targetFps = Math.Max(_minFps, _targetFps - 1);
            _enableRegionFrame = false;
            _enableDiffFrame = true;
        }
        else if (avgLatency > 200)
        {
            _targetQuality = Math.Max(_minQuality, _targetQuality - 5);
            _enableRegionFrame = true;
            _enableDiffFrame = true;
        }
        else if (avgLatency < 100 && _targetQuality < _maxQuality)
        {
            _targetQuality = Math.Min(_maxQuality, _targetQuality + 5);
            if (_targetFps < _maxFps && avgEncodeMs < 50)
            {
                _targetFps = Math.Min(_maxFps, _targetFps + 1);
            }
            _enableRegionFrame = true;
        }
        
        if (avgEncodeMs > 100 && _targetFps > _minFps)
        {
            _targetFps = Math.Max(_minFps, _targetFps - 1);
        }
        
        if (_framesSent % 30 == 0 && _framesSent > 0)
        {
            Log.Debug($"自适应: FPS={_targetFps}, Q={_targetQuality}, 格式=JPEG, 延迟={avgLatency:F0}ms");
        }
    }
    
    // ==================== 帧捕获（核心） ====================
    
    private async Task<RemoteScreenFrame?> CaptureFrameAsync()
    {
        try
        {
            var screens = Screen.AllScreens;
            if (screens == null || screens.Length == 0) return null;
            
            var captureStart = DateTime.UtcNow;
            
            int minX = int.MaxValue, minY = int.MaxValue;
            int maxX = int.MinValue, maxY = int.MinValue;
            foreach (var screen in screens)
            {
                var bounds = screen.Bounds;
                minX = Math.Min(minX, bounds.X);
                minY = Math.Min(minY, bounds.Y);
                maxX = Math.Max(maxX, bounds.Right);
                maxY = Math.Max(maxY, bounds.Bottom);
            }
            
            int captureWidth = maxX - minX;
            int captureHeight = maxY - minY;
            
            if (captureWidth > _targetWidth)
            {
                var ratio = (double)_targetWidth / captureWidth;
                captureWidth = _targetWidth;
                captureHeight = (int)(captureHeight * ratio);
            }
            
            using var bitmap = new Bitmap(captureWidth, captureHeight);
            using var graphics = Graphics.FromImage(bitmap);
            graphics.CopyFromScreen(minX, minY, 0, 0, new Size(captureWidth, captureHeight));
            
            byte[]? frameData = null;
            int frameType = 1;
            bool shouldUpdateBackground = false;
            
            var detectionResult = PerformDetection(bitmap);
            
            if (detectionResult.ShouldSendRegionFrame && _backgroundFrame != null && detectionResult.RegionsToSend.Count > 0)
            {
                frameData = EncodeRegionFrame(bitmap, detectionResult.RegionsToSend, _targetQuality);
                frameType = 3;
                if (frameData != null) Interlocked.Increment(ref _regionFramesSent);
            }
            else if (detectionResult.ShouldSendDiffFrame && detectionResult.RegionsToSend.Count > 0)
            {
                frameData = EncodeDiffFrame(bitmap, detectionResult.RegionsToSend, _targetQuality);
                frameType = 2;
                if (frameData != null) Interlocked.Increment(ref _diffFramesSent);
            }
            else if (detectionResult.ShouldSendFullFrame)
            {
                frameData = EncodeFullFrame(bitmap, _targetQuality);
                frameType = 1;
                shouldUpdateBackground = true;
            }
            else
            {
                return null;
            }
            
            if (frameData == null) return null;
            
            if (shouldUpdateBackground)
            {
                _backgroundFrame?.Dispose();
                _backgroundFrame = new Bitmap(bitmap);
            }
            
            var encodeTime = (DateTime.UtcNow - captureStart).TotalMilliseconds;
            _encodeTime.Add(encodeTime);
            
            _previousFrameData = EncodeFullFrame(bitmap, 40);
            
            var frame = new RemoteScreenFrame
            {
                Data = frameData,
                Width = captureWidth,
                Height = captureHeight,
                FrameType = frameType,
                FrameId = Interlocked.Increment(ref _frameId),
                TimestampMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                Format = "jpeg"
            };
            
            _totalBytesSent += frameData.Length;
            Interlocked.Increment(ref _framesSent);
            
            return frame;
        }
        catch (Exception ex)
        {
            Log.Error($"捕获屏幕帧失败: {ex.Message}");
            return null;
        }
    }
    
    private Bitmap? BytesToBitmap(byte[] data, int width, int height)
    {
        try
        {
            using var ms = new MemoryStream(data);
            return new Bitmap(ms);
        }
        catch
        {
            return null;
        }
    }
    
    private ImageCodecInfo GetEncoder(ImageFormat format)
    {
        var codecs = ImageCodecInfo.GetImageEncoders();
        foreach (var codec in codecs)
        {
            if (codec.FormatID == format.Guid)
                return codec;
        }
        return codecs[0];
    }
    
    // ==================== 捕获和发送循环 ====================
    
    private async Task CaptureLoopAsync()
    {
        var frameInterval = TimeSpan.FromMilliseconds(1000.0 / _targetFps);
        
        while (_cts != null && !_cts.IsCancellationRequested)
        {
            try
            {
                var startTime = DateTime.UtcNow;
                
                var frame = await CaptureFrameAsync();
                if (frame != null)
                {
                    await _frameChannel.Writer.WriteAsync(frame, _cts.Token);
                    FrameCaptured?.Invoke(this, frame);
                    UpdateFrameRate();
                }
                else
                {
                    Interlocked.Increment(ref _framesSkipped);
                }
                
                AdjustParameters();
                
                var elapsed = DateTime.UtcNow - startTime;
                var targetInterval = TimeSpan.FromMilliseconds(1000.0 / _targetFps);
                var delay = targetInterval - elapsed;
                if (delay > TimeSpan.Zero)
                {
                    await Task.Delay(delay, _cts.Token);
                }
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                Log.Error($"采集循环异常: {ex.Message}");
                await Task.Delay(1000, _cts!.Token);
            }
        }
    }
    
    private void UpdateFrameRate()
    {
        var now = DateTime.UtcNow.Ticks;
        _frameTimeQueue.Enqueue(now);
        
        while (_frameTimeQueue.TryPeek(out var oldest) && 
               (now - oldest) > TimeSpan.FromSeconds(1).Ticks)
        {
            _frameTimeQueue.TryDequeue(out _);
        }
        
        _actualFps = _frameTimeQueue.Count;
    }
    
    private async Task SendLoopAsync()
    {
        var reader = _frameChannel.Reader;
        
        while (await reader.WaitToReadAsync())
        {
            while (reader.TryRead(out var frame))
            {
                try
                {
                    await SendFrameAsync(frame);
                }
                catch (Exception ex)
                {
                    Log.Error($"发送帧失败: {ex.Message}");
                }
            }
        }
    }
    
    private async Task SendFrameAsync(RemoteScreenFrame frame)
    {
        var header = new byte[20];
        header[0] = 2;
        header[1] = (byte)frame.FrameType;
        header[2] = (byte)(frame.Width >> 8);
        header[3] = (byte)(frame.Width & 0xFF);
        header[4] = (byte)(frame.Height >> 8);
        header[5] = (byte)(frame.Height & 0xFF);
        
        // 标记格式 (0x01 = JPEG)
        header[6] = 0x01;
        header[7] = 0;
        
        WriteInt32BigEndian(header, 8, frame.FrameId);
        WriteInt32BigEndian(header, 12, (int)frame.TimestampMs);
        WriteInt32BigEndian(header, 16, frame.Data.Length);
        
        var buffer = new byte[20 + frame.Data.Length];
        Array.Copy(header, 0, buffer, 0, 20);
        Array.Copy(frame.Data, 0, buffer, 20, frame.Data.Length);
        
        var sendStart = DateTime.UtcNow;
        await _webSocketService.SendAsync(buffer);
        var latency = (DateTime.UtcNow - sendStart).TotalMilliseconds;
        _networkLatency.Add(latency);
    }
    
    private void WriteInt32BigEndian(byte[] buffer, int offset, int value)
    {
        buffer[offset] = (byte)(value >> 24);
        buffer[offset + 1] = (byte)(value >> 16);
        buffer[offset + 2] = (byte)(value >> 8);
        buffer[offset + 3] = (byte)value;
    }
    
    // ==================== WebSocket 消息处理 ====================
    
    private void OnWebSocketMessage(Dictionary<string, object> message)
    {
        var type = message.GetValueOrDefault("type")?.ToString();
        
        switch (type)
        {
            case "config":
                if (message.TryGetValue("config", out var configObj))
                {
                    var config = configObj as Dictionary<string, object>;
                    if (config != null)
                    {
                        if (config.TryGetValue("quality", out var q))
                            _targetQuality = Math.Clamp(Convert.ToInt32(q), _minQuality, _maxQuality);
                        if (config.TryGetValue("fps", out var fps))
                            _targetFps = Math.Clamp(Convert.ToInt32(fps), _minFps, _maxFps);
                        if (config.TryGetValue("enable_diff", out var diff))
                            _enableDiffFrame = Convert.ToBoolean(diff);
                        if (config.TryGetValue("enable_region", out var region))
                            _enableRegionFrame = Convert.ToBoolean(region);
                        if (config.TryGetValue("format", out var format))
                        {
                            var fmt = format.ToString()?.ToLower();
                            if (fmt == "jpeg" || fmt == "jpg")
                            {
                                _targetFormat = "jpeg";
                                _useWebP = false;
                                Log.Information($"图像格式已更新: {_targetFormat}");
                            }
                        }
                    }
                }
                break;
                
            case "ping":
                _ = Task.Run(async () =>
                {
                    await _webSocketService.SendAsync("{\"type\":\"pong\"}");
                });
                break;
                
            case "command":
                var cmd = message.GetValueOrDefault("command")?.ToString();
                switch (cmd)
                {
                    case "start_stream":
                        Start();
                        break;
                    case "stop_stream":
                        Stop();
                        break;
                    case "quality":
                        if (message.TryGetValue("params", out var p))
                        {
                            var ps = p as Dictionary<string, object>;
                            if (ps != null && ps.TryGetValue("quality", out var q))
                                _targetQuality = Math.Clamp(Convert.ToInt32(q), _minQuality, _maxQuality);
                        }
                        break;
                    case "fps":
                        if (message.TryGetValue("params", out var pf))
                        {
                            var pfs = pf as Dictionary<string, object>;
                            if (pfs != null && pfs.TryGetValue("fps", out var f))
                                _targetFps = Math.Clamp(Convert.ToInt32(f), _minFps, _maxFps);
                        }
                        break;
                    case "diff_enable":
                        if (message.TryGetValue("params", out var pd))
                        {
                            var pds = pd as Dictionary<string, object>;
                            if (pds != null && pds.TryGetValue("enable", out var e))
                                _enableDiffFrame = Convert.ToBoolean(e);
                        }
                        break;
                    case "region_enable":
                        if (message.TryGetValue("params", out var pr))
                        {
                            var prs = pr as Dictionary<string, object>;
                            if (prs != null && prs.TryGetValue("enable", out var e))
                                _enableRegionFrame = Convert.ToBoolean(e);
                        }
                        break;
                }
                break;
        }
    }
    
    // ==================== 公共接口 ====================
    
    public void Start()
    {
        if (Interlocked.Exchange(ref _isStreaming, 1) == 1)
            return;

        // ✅ 延迟5秒启动，避免干扰配置窗口和浏览器
        Task.Run(async () =>
        {
            await Task.Delay(5000);

            _cts = new CancellationTokenSource();

            _captureLoopTask =
                Task.Run(CaptureLoopAsync);

            _sendLoopTask =
                Task.Run(SendLoopAsync);

            Log.Information(
                $"✅ 增强版远程屏幕服务已启动 (格式: JPEG, OpenCV: {(_useOpenCv ? "启用" : "禁用")}, 硬件编码: {(_useHardwareEncoding ? "启用" : "禁用")})");
        });
    }
    
    public void Stop()
    {
        if (Interlocked.Exchange(ref _isStreaming, 0) == 0) return;
        
        _cts?.Cancel();
        
        try
        {
            _captureLoopTask?.Wait(TimeSpan.FromSeconds(5));
            _sendLoopTask?.Wait(TimeSpan.FromSeconds(5));
        }
        catch { }
        
        _frameChannel.Writer.TryComplete();
        
        Log.Information("远程屏幕服务已停止");
    }
    
    public void UpdateQuality(int quality)
    {
        _targetQuality = Math.Clamp(quality, _minQuality, _maxQuality);
    }
    
    public void UpdateFps(int fps)
    {
        _targetFps = Math.Clamp(fps, _minFps, _maxFps);
    }
    
    public RemoteScreenStats GetStats()
    {
        return new RemoteScreenStats
        {
            IsStreaming = IsStreaming,
            CurrentFps = _actualFps,
            TargetFps = _targetFps,
            CurrentQuality = _targetQuality,
            EnableDiffFrame = _enableDiffFrame,
            EnableRegionFrame = _enableRegionFrame,
            FramesSent = _framesSent,
            DiffFramesSent = _diffFramesSent,
            RegionFramesSent = _regionFramesSent,
            FramesSkipped = _framesSkipped,
            TotalBytesSentMB = _totalBytesSent / 1024.0 / 1024,
            AvgLatencyMs = _networkLatency.Value,
            AvgEncodeTimeMs = _encodeTime.Value,
            UseOpenCv = _useOpenCv,
            UseHardwareEncoding = _useHardwareEncoding,
            CurrentFormat = "jpeg"
        };
    }
    
    // ==================== IDisposable 实现 ====================
    
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
    
    protected virtual void Dispose(bool disposing)
    {
        if (_disposed) return;
        
        if (disposing)
        {
            Stop();
            
            _cts?.Dispose();
            _frameChannel.Writer.TryComplete();
            
            _backgroundFrame?.Dispose();
            _backgroundFrame = null;
            _previousFrameData = null;
            
            if (_openCvDetector != null)
            {
                var disposeMethod = _openCvDetector.GetType().GetMethod("Dispose");
                disposeMethod?.Invoke(_openCvDetector, null);
            }
            
            if (_hwEncoder != null)
            {
                var disposeMethod = _hwEncoder.GetType().GetMethod("Dispose");
                disposeMethod?.Invoke(_hwEncoder, null);
            }
            
            _frameTimeQueue.Clear();
            _networkLatency.Clear();
            _encodeTime.Clear();
        }
        
        _disposed = true;
    }
}
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public interface IConnectionMonitorService
{
    void Start();
    void Stop();
    bool IsHealthy { get; }
    event EventHandler<bool>? ConnectionStateChanged;
}

public class ConnectionMonitorService : IConnectionMonitorService, IHostedService
{
    private readonly IWebSocketService _webSocketService;
    private readonly IRemoteScreenService _remoteScreenService;
    private System.Threading.Timer? _monitorTimer;
    private bool _isRunning;
    private bool _lastHealthyState = true;
    
    public bool IsHealthy { get; private set; } = true;
    public event EventHandler<bool>? ConnectionStateChanged;
    
    public ConnectionMonitorService(
        IWebSocketService webSocketService,
        IRemoteScreenService remoteScreenService)
    {
        _webSocketService = webSocketService;
        _remoteScreenService = remoteScreenService;
    }
    
    public void Start()
    {
        if (_isRunning) return;
        _isRunning = true;
        
        // 每 10 秒检查一次
        _monitorTimer = new System.Threading.Timer(CheckConnection, null, 10000, 10000);
        Log.Information("✅ 连接监控服务已启动");
    }
    
    public void Stop()
    {
        _isRunning = false;
        _monitorTimer?.Dispose();
        Log.Information("连接监控服务已停止");
    }
    
    private void CheckConnection(object? state)
    {
        try
        {
            bool isHealthy = _webSocketService.IsConnected;
            
            if (isHealthy != _lastHealthyState)
            {
                _lastHealthyState = isHealthy;
                IsHealthy = isHealthy;
                ConnectionStateChanged?.Invoke(this, isHealthy);
                
                if (!isHealthy)
                {
                    Log.Warning("⚠️ 连接断开，触发重连");
                    _ = Task.Run(async () =>
                    {
                        await _webSocketService.ReconnectAsync();
                    });
                }
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "连接监控异常");
        }
    }
    
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
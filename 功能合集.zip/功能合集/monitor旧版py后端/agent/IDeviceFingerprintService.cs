using System;
using System.IO;
using System.Linq;
using System.Management;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace EnterpriseAgent;

public interface IDeviceFingerprintService
{
    Task<DeviceFingerprint> GetFingerprintAsync();
}

public class DeviceFingerprint
{
    public string Hash { get; set; } = string.Empty;
    public string CpuId { get; set; } = string.Empty;
    public string MotherboardSerial { get; set; } = string.Empty;
    public string DiskSerial { get; set; } = string.Empty;
    public string MacAddress { get; set; } = string.Empty;
    public string ComputerName { get; set; } = string.Empty;
    public string WindowsUser { get; set; } = string.Empty;
    public List<string> HardwareParts { get; set; } = new();
    public bool HasHardware { get; set; }
}

public class DeviceFingerprintService : IDeviceFingerprintService
{
    public async Task<DeviceFingerprint> GetFingerprintAsync()
    {
        return await Task.Run(() =>
        {
            var fingerprint = new DeviceFingerprint();
            var hardwareParts = new List<string>();
            
            // 获取CPU ID
            fingerprint.CpuId = GetCpuId();
            if (!string.IsNullOrEmpty(fingerprint.CpuId))
                hardwareParts.Add($"cpu:{fingerprint.CpuId}");
            else
                hardwareParts.Add("cpu:unknown");
            
            // 获取主板序列号
            fingerprint.MotherboardSerial = GetMotherboardSerial();
            if (!string.IsNullOrEmpty(fingerprint.MotherboardSerial))
                hardwareParts.Add($"mb:{fingerprint.MotherboardSerial}");
            else
                hardwareParts.Add("mb:unknown");
            
            // 获取硬盘序列号
            fingerprint.DiskSerial = GetDiskSerial();
            if (!string.IsNullOrEmpty(fingerprint.DiskSerial))
                hardwareParts.Add($"disk:{fingerprint.DiskSerial}");
            else
                hardwareParts.Add("disk:unknown");
            
            // 获取MAC地址
            fingerprint.MacAddress = GetMacAddress();
            if (!string.IsNullOrEmpty(fingerprint.MacAddress))
                hardwareParts.Add($"mac:{fingerprint.MacAddress}");
            else
                hardwareParts.Add("mac:unknown");
            
            // 获取计算机名
            fingerprint.ComputerName = Environment.MachineName;
            hardwareParts.Add($"computer:{fingerprint.ComputerName}");
            
            // 获取Windows用户名
            fingerprint.WindowsUser = Environment.UserName;
            
            // 排序确保顺序一致
            hardwareParts.Sort();
            fingerprint.HardwareParts = hardwareParts;
            
            // 生成组合Hash
            var combined = string.Join("|", hardwareParts);
            using var sha256 = SHA256.Create();
            var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(combined));
            fingerprint.Hash = Convert.ToHexString(hash).ToLower();
            
            fingerprint.HasHardware = !string.IsNullOrEmpty(fingerprint.CpuId) && 
                                      !string.IsNullOrEmpty(fingerprint.MotherboardSerial) && 
                                      !string.IsNullOrEmpty(fingerprint.DiskSerial);
            
            Log.Debug($"设备指纹生成完成: {fingerprint.Hash}");
            return fingerprint;
        });
    }
    
    private string GetCpuId()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor");
            foreach (var obj in searcher.Get())
            {
                return obj["ProcessorId"]?.ToString() ?? string.Empty;
            }
        }
        catch { }
        return string.Empty;
    }
    
    private string GetMotherboardSerial()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BaseBoard");
            foreach (var obj in searcher.Get())
            {
                return obj["SerialNumber"]?.ToString() ?? string.Empty;
            }
        }
        catch { }
        
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\BIOS");
            return key?.GetValue("BaseBoardSerialNumber")?.ToString() ?? string.Empty;
        }
        catch { }
        
        return string.Empty;
    }
    
    private string GetDiskSerial()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_DiskDrive WHERE Index=0");
            foreach (var obj in searcher.Get())
            {
                var serial = obj["SerialNumber"]?.ToString()?.Trim();
                if (!string.IsNullOrEmpty(serial))
                    return serial;
            }
        }
        catch { }
        
        // 备用：使用系统盘卷序列号
        try
        {
            var drive = DriveInfo.GetDrives().FirstOrDefault(d => d.IsReady && d.Name == Path.GetPathRoot(Environment.SystemDirectory));
            if (drive != null)
            {
                // 获取卷序列号
                return drive.VolumeLabel;
            }
        }
        catch { }
        
        return string.Empty;
    }
    
    private string GetMacAddress()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT MACAddress FROM Win32_NetworkAdapterConfiguration WHERE IPEnabled=True");
            foreach (var obj in searcher.Get())
            {
                var mac = obj["MACAddress"]?.ToString();
                if (!string.IsNullOrEmpty(mac))
                    return mac;
            }
        }
        catch { }
        
        // 备用：使用网络接口
        try
        {
            var networkInterface = System.Net.NetworkInformation.NetworkInterface
                .GetAllNetworkInterfaces()
                .FirstOrDefault(ni => ni.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up &&
                                      ni.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback);
            
            if (networkInterface != null)
            {
                return networkInterface.GetPhysicalAddress().ToString();
            }
        }
        catch { }
        
        return string.Empty;
    }
}
using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Velopack;

namespace EnterpriseAgent;

public interface IUpdateService
{
    void Start();
    void Stop();
    Task<bool> CheckForUpdatesAsync(CancellationToken ct = default);
    Task<bool> DownloadAndInstallAsync(CancellationToken ct = default);
}

public class UpdateService : IUpdateService, IHostedService
{
    private readonly IConfigurationService _configService;
    private System.Threading.Timer? _checkTimer;  // 明确使用 System.Threading.Timer
    private int _isRunning;
    private bool _isUpdating;
    private string _updateUrl = "https://your-update-server.com";
    
    public UpdateService(IConfigurationService configService)
    {
        _configService = configService;
    }
    
    public void Start()
    {
        if (Interlocked.Exchange(ref _isRunning, 1) == 1) return;
        
        // 每小时检查一次更新
        _checkTimer = new System.Threading.Timer(async _ => await CheckForUpdatesAsync(), null, TimeSpan.FromHours(1), TimeSpan.FromHours(1));
        
        Log.Information("✅ 自动更新服务已启动");
    }
    
    public void Stop()
    {
        if (Interlocked.Exchange(ref _isRunning, 0) == 0) return;
        
        _checkTimer?.Dispose();
        _checkTimer = null;
        
        Log.Information("自动更新服务已停止");
    }
    
    public async Task<bool> CheckForUpdatesAsync(CancellationToken ct = default)
    {
        if (_isUpdating) return false;
        
        try
        {
            var mgr = new UpdateManager(_updateUrl);
            var update = await mgr.CheckForUpdatesAsync();
            
            if (update != null)
            {
                Log.Information($"发现新版本: {update.TargetFullRelease.Version}");
                return true;
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "检查更新失败");
        }
        
        return false;
    }
    
    public async Task<bool> DownloadAndInstallAsync(CancellationToken ct = default)
    {
        if (_isUpdating) return false;
        _isUpdating = true;
        
        try
        {
            var mgr = new UpdateManager(_updateUrl);
            var update = await mgr.CheckForUpdatesAsync();
            
            if (update != null)
            {
                Log.Information($"正在下载更新: {update.TargetFullRelease.Version}");
                await mgr.DownloadUpdatesAsync(update);
                Log.Information("正在安装更新...");
                mgr.ApplyUpdatesAndRestart(update);
                return true;
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "更新失败");
        }
        finally
        {
            _isUpdating = false;
        }
        
        return false;
    }
    
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
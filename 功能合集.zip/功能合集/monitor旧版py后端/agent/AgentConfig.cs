using System;
using System.Text.Json.Serialization;

namespace EnterpriseAgent;

public class AgentConfig
{
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;
    
    [JsonPropertyName("server_url")]
    public string ServerUrl { get; set; } = string.Empty;
    
    [JsonPropertyName("client_id")]
    public string ClientId { get; set; } = string.Empty;
    
    [JsonPropertyName("employee_id")]
    public string EmployeeId { get; set; } = string.Empty;
    
    [JsonPropertyName("token")]
    public string Token { get; set; } = string.Empty;
    
    [JsonPropertyName("hardware_fingerprint")]
    public string HardwareFingerprint { get; set; } = string.Empty;
    
    [JsonPropertyName("computer_name")]
    public string ComputerName { get; set; } = string.Empty;
    
    [JsonPropertyName("windows_user")]
    public string WindowsUser { get; set; } = string.Empty;
    
    [JsonPropertyName("registered_at")]
    public DateTime RegisteredAt { get; set; }
    
    [JsonPropertyName("version")]
    public string Version { get; set; } = "1.0.0";
    
    [JsonPropertyName("screenshot_interval")]
    public int ScreenshotInterval { get; set; } = 60;
    
    [JsonPropertyName("screenshot_quality")]
    public int ScreenshotQuality { get; set; } = 80;
    
    [JsonPropertyName("screenshot_format")]
    public string ScreenshotFormat { get; set; } = "webp";
    
    [JsonPropertyName("enable_heartbeat")]
    public bool EnableHeartbeat { get; set; } = true;
    
    [JsonPropertyName("enable_batch_upload")]
    public bool EnableBatchUpload { get; set; } = true;
    
    [JsonPropertyName("enable_browser_monitor")]
    public bool EnableBrowserMonitor { get; set; } = true;
    
    [JsonPropertyName("enable_app_monitor")]
    public bool EnableAppMonitor { get; set; } = true;
    
    [JsonPropertyName("enable_file_monitor")]
    public bool EnableFileMonitor { get; set; } = true;
    
    [JsonPropertyName("enable_remote_screen")]
    public bool EnableRemoteScreen { get; set; } = true;
}
using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Polly;
using Polly.Retry;

namespace EnterpriseAgent;

public interface IHttpClientService
{
    Task<RegisterResult> RegisterClientAsync(string name, DeviceFingerprint fingerprint, string? serverUrl = null);
    Task<ClientConfig> GetClientConfigAsync();
    Task<bool> SendHeartbeatAsync(HeartbeatData heartbeat);
    Task<bool> UploadScreenshotAsync(ScreenshotData screenshot);
    Task<bool> UploadBrowserHistoryAsync(List<BrowserHistoryData> history);
    Task<bool> UploadAppUsageAsync(List<AppUsageData> usage);
    Task<bool> UploadFileOperationsAsync(List<FileOperationData> operations);
    Task<bool> TestConnectionAsync(string serverUrl);
}

public class RegisterResult
{
    public bool Success { get; set; }
    public string ClientId { get; set; } = string.Empty;
    public string EmployeeId { get; set; } = string.Empty;
    public string Token { get; set; } = string.Empty;
    public string ErrorMessage { get; set; } = string.Empty;
}

public class ClientConfig
{
    public int Interval { get; set; } = 60;
    public int Quality { get; set; } = 80;
    public string Format { get; set; } = "webp";
    public bool EnableHeartbeat { get; set; } = true;
    public bool EnableBatchUpload { get; set; } = true;
    public int SimilarityThreshold { get; set; } = 95;
    public int RetryTimes { get; set; } = 3;
}

public class HeartbeatData
{
    public string Status { get; set; } = "online";
    public Dictionary<string, object> Stats { get; set; } = new();
    public bool Paused { get; set; }
    public string IpAddress { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; }
}

public class ScreenshotData
{
    public string EmployeeId { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string ComputerName { get; set; } = string.Empty;
    public string WindowsUser { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; }
    public string Format { get; set; } = "webp";
    public byte[] Data { get; set; } = Array.Empty<byte>();
    public bool Encrypted { get; set; }
}

public class BrowserHistoryData
{
    public string EmployeeId { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Browser { get; set; } = string.Empty;
    public int Duration { get; set; }
    public DateTime VisitTime { get; set; }
    public string ComputerName { get; set; } = string.Empty;
    public string WindowsUser { get; set; } = string.Empty;
}

public class FileOperationData
{
    public string EmployeeId { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string Operation { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    public long FileSize { get; set; }
    public string FileType { get; set; } = string.Empty;
    public bool IsDirectory { get; set; }
    public DateTime OperationTime { get; set; }
    public string ComputerName { get; set; } = string.Empty;
    public string WindowsUser { get; set; } = string.Empty;
}

public class HttpClientService : IHttpClientService
{
    private readonly IConfigurationService _configService;
    private readonly ISecurityService _securityService;
    private HttpClient _httpClient = null!;
    private string _currentServerUrl = string.Empty;
    private readonly AsyncRetryPolicy<HttpResponseMessage> _retryPolicy;
    private readonly SemaphoreSlim _semaphore = new(10, 10);
    
    public HttpClientService(IConfigurationService configService, ISecurityService securityService)
    {
        _configService = configService;
        _securityService = securityService;
        
        var config = _configService.Load();
        _currentServerUrl = config?.ServerUrl ?? "https://localhost:8000";
        
        CreateHttpClient();
        
        _retryPolicy = Policy<HttpResponseMessage>
            .Handle<HttpRequestException>()
            .OrResult(r => (int)r.StatusCode >= 500 || r.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
            .WaitAndRetryAsync(3, retryAttempt => 
                TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    Log.Warning($"HTTP请求重试 {retryCount}/3, 延迟 {timespan.TotalSeconds}s");
                });
    }
    
    private void CreateHttpClient()
    {
        var handler = new SocketsHttpHandler
        {
            PooledConnectionLifetime = TimeSpan.FromMinutes(5),
            PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2),
            MaxConnectionsPerServer = 50,
            EnableMultipleHttp2Connections = true
        };
        
        _httpClient = new HttpClient(handler);
        _httpClient.Timeout = TimeSpan.FromSeconds(30);
        _httpClient.DefaultRequestHeaders.Add("User-Agent", $"EnterpriseAgent/1.0");
        _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
    }
    
    public async Task<bool> TestConnectionAsync(string serverUrl)
    {
        try
        {
            using var client = new HttpClient();
            client.Timeout = TimeSpan.FromSeconds(5);
            var response = await client.GetAsync($"{serverUrl}/health");
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }
    
    private void UpdateServerUrl(string? serverUrl)
    {
        if (!string.IsNullOrEmpty(serverUrl))
        {
            _currentServerUrl = serverUrl;
            CreateHttpClient();
        }
    }
    
    /// <summary>
    /// 核心方法：发送带认证的 HTTP 请求，支持重试时重新创建请求
    /// </summary>
    private async Task<HttpResponseMessage> SendWithAuthAsync(Func<Task<HttpRequestMessage>> requestFactory, CancellationToken ct = default)
    {
        await _semaphore.WaitAsync(ct);
        
        try
        {
            return await _retryPolicy.ExecuteAsync(async () =>
            {
                // ✅ 每次重试都创建新的 HttpRequestMessage
                using var request = await requestFactory();
                
                var config = _configService.Load();
                if (config != null && !string.IsNullOrEmpty(config.Token))
                {
                    var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();
                    var nonce = _securityService.GenerateNonce();
                    var path = request.RequestUri?.PathAndQuery ?? "";
                    
                    // 读取 body 内容（如果需要签名）
                    string body = "";
                    if (request.Content != null)
                    {
                        body = await request.Content.ReadAsStringAsync(ct);
                        // 重新设置 content，因为读取后流已经到末尾
                        request.Content = new StringContent(body, Encoding.UTF8, "application/json");
                    }
                    
                    var signature = _securityService.GenerateSignature(request.Method.Method, path, timestamp, nonce, body);
                    
                    request.Headers.Add("Authorization", $"Bearer {config.Token}");
                    request.Headers.Add("X-Timestamp", timestamp);
                    request.Headers.Add("X-Nonce", nonce);
                    request.Headers.Add("X-Signature", signature);
                }
                
                return await _httpClient.SendAsync(request, ct);
            });
        }
        finally
        {
            _semaphore.Release();
        }
    }
    
    public async Task<RegisterResult> RegisterClientAsync(string name, DeviceFingerprint fingerprint, string? serverUrl = null)
    {
        UpdateServerUrl(serverUrl);
        
        var config = _configService.Load();
        
        var requestBody = new
        {
            computer_name = fingerprint.ComputerName,
            windows_user = fingerprint.WindowsUser,
            mac_address = fingerprint.MacAddress,
            hardware_fingerprint = fingerprint.Hash,
            hardware_parts = fingerprint.HardwareParts,
            has_hardware = fingerprint.HasHardware,
            cpu_id = fingerprint.CpuId,
            disk_serial = fingerprint.DiskSerial,
            employee_name = name,
            client_version = "1.0.0",
            capabilities = new[] { "webp", "heartbeat", "batch", "encryption" }
        };
        
        try
        {
            Log.Information($"发送注册请求到: {_currentServerUrl}/api/client/register");
            
            var response = await SendWithAuthAsync(async () =>
            {
                var content = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");
                return new HttpRequestMessage(HttpMethod.Post, $"{_currentServerUrl}/api/client/register")
                {
                    Content = content
                };
            });
            
            var json = await response.Content.ReadAsStringAsync();
            
            if (response.IsSuccessStatusCode)
            {
                var result = JsonSerializer.Deserialize<Dictionary<string, object>>(json);
                var clientId = result?.GetValueOrDefault("client_id")?.ToString() ?? "";
                var employeeId = result?.GetValueOrDefault("employee_id")?.ToString() ?? "";
                
                Log.Information($"✅ 注册成功: ClientId={clientId}, EmployeeId={employeeId}");
                
                return new RegisterResult
                {
                    Success = true,
                    ClientId = clientId,
                    EmployeeId = employeeId,
                    Token = config?.Token ?? ""
                };
            }
            
            Log.Error($"注册失败: HTTP {response.StatusCode}, Response={json}");
            return new RegisterResult { Success = false, ErrorMessage = json };
        }
        catch (Exception ex)
        {
            Log.Error(ex, "注册客户端失败");
            return new RegisterResult { Success = false, ErrorMessage = ex.Message };
        }
    }
    
    public async Task<ClientConfig> GetClientConfigAsync()
    {
        var config = _configService.Load();
        if (config == null) return new ClientConfig();
        
        try
        {
            var response = await SendWithAuthAsync(async () =>
                new HttpRequestMessage(HttpMethod.Get, $"{_currentServerUrl}/api/client/{config.ClientId}/config"));
            
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<ClientConfig>(json) ?? new ClientConfig();
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "获取客户端配置失败");
        }
        
        return new ClientConfig();
    }
    
    public async Task<bool> SendHeartbeatAsync(HeartbeatData heartbeat)
    {
        var config = _configService.Load();
        if (config == null) return false;
        
        try
        {
            var response = await SendWithAuthAsync(async () =>
            {
                var content = new StringContent(JsonSerializer.Serialize(heartbeat), Encoding.UTF8, "application/json");
                return new HttpRequestMessage(HttpMethod.Post, $"{_currentServerUrl}/api/client/{config.ClientId}/heartbeat")
                {
                    Content = content
                };
            });
            
            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            Log.Debug(ex, "发送心跳失败");
            return false;
        }
    }
    
    public async Task<bool> UploadScreenshotAsync(ScreenshotData screenshot)
    {
        var config = _configService.Load();
        if (config == null) return false;
        
        try
        {
            var response = await SendWithAuthAsync(async () =>
            {
                var form = new MultipartFormDataContent();
                form.Add(new StringContent(screenshot.EmployeeId), "employee_id");
                form.Add(new StringContent(screenshot.ClientId), "client_id");
                form.Add(new StringContent(screenshot.ComputerName), "computer_name");
                form.Add(new StringContent(screenshot.WindowsUser), "windows_user");
                form.Add(new StringContent(screenshot.Timestamp.ToString("yyyy-MM-dd HH:mm:ss")), "timestamp");
                form.Add(new StringContent(screenshot.Format), "format");
                form.Add(new StringContent(screenshot.Encrypted ? "true" : "false"), "encrypted");
                form.Add(new ByteArrayContent(screenshot.Data), "file", $"screenshot.{screenshot.Format}");
                
                return new HttpRequestMessage(HttpMethod.Post, $"{_currentServerUrl}/api/upload")
                {
                    Content = form
                };
            });
            
            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            Log.Error(ex, "上传截图失败");
            return false;
        }
    }
    
    public async Task<bool> UploadBrowserHistoryAsync(List<BrowserHistoryData> history)
    {
        var config = _configService.Load();
        if (config == null) return false;
        
        try
        {
            var response = await SendWithAuthAsync(async () =>
            {
                var content = new StringContent(JsonSerializer.Serialize(history), Encoding.UTF8, "application/json");
                return new HttpRequestMessage(HttpMethod.Post, $"{_currentServerUrl}/api/browser/history")
                {
                    Content = content
                };
            });
            
            if (response.IsSuccessStatusCode)
            {
                Log.Debug($"浏览器历史上传成功: {history.Count}条");
                return true;
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "上传浏览器历史失败");
        }
        
        return false;
    }
    
    public async Task<bool> UploadAppUsageAsync(List<AppUsageData> usage)
    {
        var config = _configService.Load();
        if (config == null) return false;
        
        try
        {
            var response = await SendWithAuthAsync(async () =>
            {
                var content = new StringContent(JsonSerializer.Serialize(usage), Encoding.UTF8, "application/json");
                return new HttpRequestMessage(HttpMethod.Post, $"{_currentServerUrl}/api/apps/usage")
                {
                    Content = content
                };
            });
            
            if (response.IsSuccessStatusCode)
            {
                Log.Debug($"软件使用记录上传成功: {usage.Count}条");
                return true;
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "上传软件使用记录失败");
        }
        
        return false;
    }
    
    public async Task<bool> UploadFileOperationsAsync(List<FileOperationData> operations)
    {
        var config = _configService.Load();
        if (config == null) return false;
        
        try
        {
            var response = await SendWithAuthAsync(async () =>
            {
                var content = new StringContent(JsonSerializer.Serialize(operations), Encoding.UTF8, "application/json");
                return new HttpRequestMessage(HttpMethod.Post, $"{_currentServerUrl}/api/files/operations")
                {
                    Content = content
                };
            });
            
            if (response.IsSuccessStatusCode)
            {
                Log.Debug($"文件操作记录上传成功: {operations.Count}条");
                return true;
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "上传文件操作记录失败");
        }
        
        return false;
    }
}
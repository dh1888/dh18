using System;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Channels;
using System.Collections.Concurrent;
using System.Runtime.CompilerServices;

namespace EnterpriseAgent;

public interface IWebSocketService
{
    Task ConnectAsync(CancellationToken ct = default);
    Task DisconnectAsync();
    Task ReconnectAsync();
    Task SendAsync(string message, CancellationToken ct = default);
    Task SendAsync(byte[] data, CancellationToken ct = default);
    IAsyncEnumerable<string> ReceiveAsync(CancellationToken ct = default);
    bool IsConnected { get; }
    event Action<Dictionary<string, object>>? MessageReceived;
    event Action<byte[], int, int, int, int, int>? BinaryFrameReceived;
}

public class WebSocketService : IWebSocketService, IDisposable
{
    private readonly IConfigurationService _configService;
    private readonly ISecurityService _securityService;
    private ClientWebSocket? _webSocket;
    private CancellationTokenSource? _cts;
    private readonly Channel<string> _sendChannel;
    private Task? _sendLoopTask;
    private Task? _receiveLoopTask;
    private readonly SemaphoreSlim _connectionLock = new(1, 1);
    private bool _isConnecting;
    private int _reconnectAttempts;
    private DateTime _lastReconnectAttempt;
    
    public bool IsConnected => _webSocket?.State == WebSocketState.Open;
    public event Action<Dictionary<string, object>>? MessageReceived;
    public event Action<byte[], int, int, int, int, int>? BinaryFrameReceived;
    
    public WebSocketService(IConfigurationService configService, ISecurityService securityService)
    {
        _configService = configService;
        _securityService = securityService;
        _sendChannel = Channel.CreateBounded<string>(new BoundedChannelOptions(100)
        {
            FullMode = BoundedChannelFullMode.DropOldest
        });
    }
    
    public async Task ConnectAsync(CancellationToken ct = default)
    {
        await _connectionLock.WaitAsync(ct);
        try
        {
            if (_isConnecting || IsConnected) return;
            _isConnecting = true;
            
            var config = _configService.Load();
            if (config == null || string.IsNullOrEmpty(config.ClientId))
            {
                Log.Warning("配置未加载或无ClientId，无法连接WebSocket");
                return;
            }
            
            var wsUrl = config.ServerUrl.Replace("https://", "wss://").Replace("http://", "ws://");
            var uri = new Uri($"{wsUrl}/api/remote/ws/client/{config.ClientId}?token={config.Token}");
            
            _webSocket = new ClientWebSocket();
            _cts = new CancellationTokenSource();
            
            Log.Information($"🔌 连接WebSocket: {uri}");
            
            await _webSocket.ConnectAsync(uri, ct);
            
            _sendLoopTask = Task.Run(SendLoopAsync);
            _receiveLoopTask = Task.Run(ReceiveLoopAsync);
            _ = Task.Run(HeartbeatLoopAsync);
            
            _reconnectAttempts = 0;
            Log.Information($"✅ WebSocket已连接");
            
            await SendClientInfoAsync();
        }
        catch (Exception ex)
        {
            Log.Error(ex, "WebSocket连接失败");
            _ = Task.Run(() => StartReconnectAsync());
        }
        finally
        {
            _isConnecting = false;
        }
    }
    
    private async Task HeartbeatLoopAsync()
    {
        while (IsConnected && (_cts?.IsCancellationRequested == false))
        {
            await Task.Delay(30000);
            if (IsConnected)
            {
                await SendAsync("{\"type\":\"ping\",\"timestamp\":" + 
                    DateTimeOffset.UtcNow.ToUnixTimeSeconds() + "}");
            }
        }
    }
    
    private async Task SendClientInfoAsync()
    {
        var config = _configService.Load();
        if (config == null) return;
        
        var info = new Dictionary<string, object>
        {
            ["type"] = "client_info",
            ["timestamp"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
            ["client_id"] = config.ClientId,
            ["employee_id"] = config.EmployeeId,
            ["capabilities"] = new Dictionary<string, object>
            {
                ["diff_frame"] = true,
                ["region_detect"] = true,
                ["h264"] = false,
                ["qr_detect"] = false,
                ["window_exclusion"] = false,
                ["max_fps"] = 10,
                ["max_quality"] = 95,
                ["max_width"] = 1280
            },
            ["system"] = new Dictionary<string, object>
            {
                ["platform"] = Environment.OSVersion.Platform.ToString(),
                ["version"] = Environment.OSVersion.VersionString
            }
        };
        
        await SendAsync(JsonSerializer.Serialize(info));
    }
    
    private async Task StartReconnectAsync()
    {
        var delay = Math.Min(Math.Pow(2, _reconnectAttempts), 60);
        _lastReconnectAttempt = DateTime.UtcNow;
        
        Log.Information($"🔄 {delay:F1}秒后尝试重连 (尝试 {_reconnectAttempts + 1}/10)");
        await Task.Delay(TimeSpan.FromSeconds(delay));
        
        if (++_reconnectAttempts <= 10)
        {
            await ConnectAsync();
        }
        else
        {
            Log.Error("WebSocket重连次数已达上限");
        }
    }
    
    public async Task DisconnectAsync()
    {
        await _connectionLock.WaitAsync();
        try
        {
            if (_webSocket != null)
            {
                try
                {
                    await _webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "正常关闭", CancellationToken.None);
                }
                catch { }
                _webSocket.Dispose();
                _webSocket = null;
            }
            
            _cts?.Cancel();
            _cts?.Dispose();
            _cts = null;
            
            _sendChannel.Writer.TryComplete();
        }
        finally
        {
            _connectionLock.Release();
        }
    }
    
    public async Task ReconnectAsync()
    {
        await DisconnectAsync();
        await Task.Delay(1000);
        await ConnectAsync();
    }
    
    public async Task SendAsync(string message, CancellationToken ct = default)
    {
        if (!IsConnected)
        {
            Log.Warning("WebSocket未连接，消息被丢弃");
            return;
        }
        
        await _sendChannel.Writer.WriteAsync(message, ct);
    }
    
    public async Task SendAsync(byte[] data, CancellationToken ct = default)
    {
        if (!IsConnected) return;
        
        try
        {
            await _webSocket!.SendAsync(new ArraySegment<byte>(data), WebSocketMessageType.Binary, true, ct);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "发送二进制数据失败");
        }
    }
    
    public async IAsyncEnumerable<string> ReceiveAsync([EnumeratorCancellation] CancellationToken ct = default)
    {
        var receiveChannel = Channel.CreateUnbounded<string>();
        var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        
        // 启动接收任务
        _ = Task.Run(async () =>
        {
            var buffer = new byte[1024 * 1024];
            
            while (!cts.Token.IsCancellationRequested && IsConnected)
            {
                try
                {
                    if (_webSocket == null) break;
                    
                    var result = await _webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), cts.Token);
                    
                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        await receiveChannel.Writer.WriteAsync("[CLOSE]", cts.Token);
                        break;
                    }
                    
                    var message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    await receiveChannel.Writer.WriteAsync(message, cts.Token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "接收消息失败");
                    break;
                }
            }
            
            receiveChannel.Writer.TryComplete();
        }, cts.Token);
        
        // 读取并 yield 消息
        await foreach (var message in receiveChannel.Reader.ReadAllAsync(ct))
        {
            if (message == "[CLOSE]") break;
            yield return message;
        }
    }
    
    private async Task SendLoopAsync()
    {
        var reader = _sendChannel.Reader;
        
        while (IsConnected && await reader.WaitToReadAsync())
        {
            while (reader.TryRead(out var message))
            {
                if (!IsConnected) break;
                
                try
                {
                    var bytes = Encoding.UTF8.GetBytes(message);
                    await _webSocket!.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "发送消息失败");
                }
            }
        }
    }
    
    private async Task ReceiveLoopAsync()
    {
        var buffer = new byte[1024 * 1024];
        var lastHeartbeat = DateTime.UtcNow;
        var heartbeatTimeout = TimeSpan.FromSeconds(45);
        
        while (IsConnected)
        {
            try
            {
                if (DateTime.UtcNow - lastHeartbeat > heartbeatTimeout)
                {
                    Log.Warning("心跳超时，触发重连");
                    _ = Task.Run(ReconnectAsync);
                    break;
                }
                
                if (_webSocket == null) break;
                
                var receiveTask = _webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                var timeoutTask = Task.Delay(5000);
                
                var completed = await Task.WhenAny(receiveTask, timeoutTask);
                
                if (completed == timeoutTask)
                {
                    await SendAsync("{\"type\":\"ping\"}");
                    continue;
                }
                
                var result = await receiveTask;
                
                if (result.MessageType == WebSocketMessageType.Close)
                {
                    await _webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "关闭", CancellationToken.None);
                    break;
                }
                
                lastHeartbeat = DateTime.UtcNow;
                
                if (result.MessageType == WebSocketMessageType.Text)
                {
                    var message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    await ProcessTextMessageAsync(message);
                }
                else if (result.MessageType == WebSocketMessageType.Binary)
                {
                    await ProcessBinaryMessageAsync(buffer, result.Count);
                }
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "接收循环异常");
                await Task.Delay(1000);
            }
        }
    }
    
    private async Task ProcessTextMessageAsync(string message)
    {
        try
        {
            var data = JsonSerializer.Deserialize<Dictionary<string, object>>(message);
            if (data == null) return;
            
            var type = data.GetValueOrDefault("type")?.ToString();
            
            switch (type)
            {
                case "config":
                    Log.Debug("收到配置更新消息");
                    MessageReceived?.Invoke(data);
                    break;
                case "command":
                    Log.Debug($"收到命令: {data.GetValueOrDefault("command")}");
                    MessageReceived?.Invoke(data);
                    break;
                case "viewer_update":
                    var viewers = data.GetValueOrDefault("viewers", 0);
                    Log.Debug($"观众数量更新: {viewers}");
                    MessageReceived?.Invoke(data);
                    break;
                case "heartbeat_ack":
                    break;
                case "pong":
                    if (data.TryGetValue("timestamp", out var ts))
                    {
                        var latency = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - Convert.ToInt64(ts);
                        Log.Debug($"🏓 Pong延迟: {latency}ms");
                    }
                    MessageReceived?.Invoke(data);
                    break;
                case "connected":
                    Log.Information($"会话建立成功: {data.GetValueOrDefault("session_id")}");
                    MessageReceived?.Invoke(data);
                    break;
                case "stop_view":
                    Log.Information("收到停止查看消息");
                    MessageReceived?.Invoke(data);
                    break;
                case "close":
                    Log.Information("收到关闭消息");
                    MessageReceived?.Invoke(data);
                    break;
                default:
                    Log.Debug($"未知消息类型: {type}");
                    break;
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "处理消息失败");
        }
    }
    
    private async Task ProcessBinaryMessageAsync(byte[] data, int length)
    {
        try
        {
            if (length < 20) return;
            
            var version = data[0];
            var frameType = data[1];
            var width = (data[2] << 8) | data[3];
            var height = (data[4] << 8) | data[5];
            var reserved = (data[6] << 8) | data[7];
            var frameId = (data[8] << 24) | (data[9] << 16) | (data[10] << 8) | data[11];
            var timestampSec = (data[12] << 24) | (data[13] << 16) | (data[14] << 8) | data[15];
            var dataSize = (data[16] << 24) | (data[17] << 16) | (data[18] << 8) | data[19];
            
            if (dataSize > 0 && 20 + dataSize <= length)
            {
                var imageData = new byte[dataSize];
                Array.Copy(data, 20, imageData, 0, dataSize);
                
                BinaryFrameReceived?.Invoke(imageData, width, height, frameType, frameId, timestampSec);
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "处理二进制帧失败");
        }
    }
    
    public void Dispose()
    {
        _connectionLock?.Dispose();
        _cts?.Cancel();
        _cts?.Dispose();
        _webSocket?.Dispose();
    }
}
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;

namespace EnterpriseAgent;

public interface II18nService
{
    string CurrentLanguage { get; }
    string GetText(string key, params object[] args);
    void SetLanguage(string language);
    event Action<string>? LanguageChanged;
}

public class I18nService : II18nService
{
    private readonly Dictionary<string, Dictionary<string, string>> _texts;
    private string _currentLanguage;
    
    public string CurrentLanguage => _currentLanguage;
    public event Action<string>? LanguageChanged;
    
    public I18nService()
    {
        _currentLanguage = DetectSystemLanguage();
        _texts = LoadTexts();
    }
    
    private string DetectSystemLanguage()
    {
        var culture = CultureInfo.CurrentUICulture;
        var lang = culture.TwoLetterISOLanguageName.ToLower();
        
        return lang switch
        {
            "zh" => "zh",
            "vi" => "vi",
            _ => "en"
        };
    }
    
    private Dictionary<string, Dictionary<string, string>> LoadTexts()
    {
        return new()
        {
            // 通用
            ["yes"] = new() { ["zh"] = "是", ["vi"] = "Có", ["en"] = "Yes" },
            ["no"] = new() { ["zh"] = "否", ["vi"] = "Không", ["en"] = "No" },
            ["ok"] = new() { ["zh"] = "确定", ["vi"] = "Xác nhận", ["en"] = "OK" },
            ["cancel"] = new() { ["zh"] = "取消", ["vi"] = "Hủy", ["en"] = "Cancel" },
            ["confirm"] = new() { ["zh"] = "确认", ["vi"] = "Xác nhận", ["en"] = "Confirm" },

            // ========== 新增：占位符文本 ==========
            ["name_placeholder"] = new()
            {
                ["zh"] = "请输入您的姓名",
                ["vi"] = "Vui lòng nhập tên của bạn",
                ["en"] = "Please enter your name"
            },

            ["server_placeholder"] = new()
            {
                ["zh"] = "请输入服务器地址，如：https://google.com",
                ["vi"] = "Vui lòng nhập địa chỉ máy chủ, ví dụ: https://google.com",
                ["en"] = "Please enter server URL, e.g.: https://google.com"
            },

            // ========== 新增：错误消息 ==========
            ["error_name_empty"] = new()
            {
                ["zh"] = "请输入姓名",
                ["vi"] = "Vui lòng nhập tên",
                ["en"] = "Please enter your name"
            },

            ["error_server_empty"] = new()
            {
                ["zh"] = "请输入服务器地址",
                ["vi"] = "Vui lòng nhập địa chỉ máy chủ",
                ["en"] = "Please enter server URL"
            },

            ["checking_network"] = new()
            {
                ["zh"] = "正在检查网络...",
                ["vi"] = "Đang kiểm tra mạng...",
                ["en"] = "Checking network..."
            },

            ["getting_fingerprint"] = new()
            {
                ["zh"] = "正在获取设备指纹...",
                ["vi"] = "Đang lấy dấu vân tay thiết bị...",
                ["en"] = "Getting device fingerprint..."
            },

            ["registering"] = new()
            {
                ["zh"] = "正在注册客户端...",
                ["vi"] = "Đang đăng ký client...",
                ["en"] = "Registering client..."
            },

            ["register_success"] = new()
            {
                ["zh"] = "注册成功！",
                ["vi"] = "Đăng ký thành công!",
                ["en"] = "Registration successful!"
            },

            ["register_failed"] = new()
            {
                ["zh"] = "注册失败",
                ["vi"] = "Đăng ký thất bại",
                ["en"] = "Registration failed"
            },

            ["connect_failed"] = new()
            {
                ["zh"] = "连接失败",
                ["vi"] = "Kết nối thất bại",
                ["en"] = "Connection failed"
            },

            ["connecting"] = new()
            {
                ["zh"] = "连接中...",
                ["vi"] = "Đang kết nối...",
                ["en"] = "Connecting..."
            },

            // 配置对话框
            ["config_title"] = new()
            {
                ["zh"] = "DH企业助手 - 首次配置",
                ["vi"] = "DH - Cấu hình lần đầu",
                ["en"] = "DH - First Setup"
            },

            ["config_subtitle"] = new()
            {
                ["zh"] = "欢迎使用DH，首次配置需要填写一下信息：",
                ["vi"] = "Chào mừng bạn đến với DH, vui lòng điền thông tin cấu hình lần đầu:",
                ["en"] = "Welcome to DH, please fill in the configuration information:"
            },

            ["config_welcome"] = new()
            {
                ["zh"] = "欢迎使用DH企业助手",
                ["vi"] = "Chào mừng",
                ["en"] = "Welcome to DH"
            },

            ["config_name"] = new()
            {
                ["zh"] = "您的姓名",
                ["vi"] = "Tên của bạn",
                ["en"] = "Your name"
            },

            ["config_server"] = new()
            {
                ["zh"] = "服务器地址",
                ["vi"] = "Địa chỉ máy chủ",
                ["en"] = "Server URL"
            },

            ["config_connecting"] = new()
            {
                ["zh"] = "连接中...",
                ["vi"] = "Đang kết nối...",
                ["en"] = "Connecting..."
            },

            ["config_success"] = new()
            {
                ["zh"] = "连接成功！",
                ["vi"] = "Thành công!",
                ["en"] = "Success!"
            },

            // 姓名标签
            ["name"] = new()
            {
                ["zh"] = "姓名",
                ["vi"] = "Tên",
                ["en"] = "Name"
            },

            ["server_url"] = new()
            {
                ["zh"] = "服务器地址",
                ["vi"] = "Địa chỉ máy chủ",
                ["en"] = "Server URL"
            },

            // 系统信息
            ["system_info"] = new()
            {
                ["zh"] = "系统信息",
                ["vi"] = "Thông tin hệ thống",
                ["en"] = "System Info"
            },

            ["computer_name"] = new()
            {
                ["zh"] = "计算机名",
                ["vi"] = "Tên máy tính",
                ["en"] = "Computer Name"
            },

            ["user_name"] = new()
            {
                ["zh"] = "用户名",
                ["vi"] = "Tên người dùng",
                ["en"] = "User Name"
            },

            // 按钮
            ["connect"] = new()
            {
                ["zh"] = "连接",
                ["vi"] = "Kết nối",
                ["en"] = "Connect"
            },

            ["exit"] = new()
            {
                ["zh"] = "退出",
                ["vi"] = "Thoát",
                ["en"] = "Exit"
            },

            // 状态
            ["status_running"] = new()
            {
                ["zh"] = "运行中",
                ["vi"] = "Đang chạy",
                ["en"] = "Running"
            },

            ["status_paused"] = new()
            {
                ["zh"] = "已暂停",
                ["vi"] = "Đã tạm dừng",
                ["en"] = "Paused"
            },

            ["status_offline"] = new()
            {
                ["zh"] = "离线",
                ["vi"] = "Ngoại tuyến",
                ["en"] = "Offline"
            },

            ["status_online"] = new()
            {
                ["zh"] = "在线",
                ["vi"] = "Trực tuyến",
                ["en"] = "Online"
            },

            // 托盘菜单
            ["tray_show_status"] = new()
            {
                ["zh"] = "查看状态",
                ["vi"] = "Xem trạng thái",
                ["en"] = "Show Status"
            },

            ["tray_health"] = new()
            {
                ["zh"] = "健康状态",
                ["vi"] = "Sức khỏe",
                ["en"] = "Health"
            },

            ["tray_pause"] = new()
            {
                ["zh"] = "暂停监控",
                ["vi"] = "Tạm dừng",
                ["en"] = "Pause"
            },

            ["tray_resume"] = new()
            {
                ["zh"] = "恢复监控",
                ["vi"] = "Tiếp tục",
                ["en"] = "Resume"
            },

            ["tray_screenshot"] = new()
            {
                ["zh"] = "立即截图",
                ["vi"] = "Chụp ngay",
                ["en"] = "Screenshot"
            },

            ["tray_reconnect"] = new()
            {
                ["zh"] = "重连",
                ["vi"] = "Kết nối lại",
                ["en"] = "Reconnect"
            },

            ["tray_logs"] = new()
            {
                ["zh"] = "查看日志",
                ["vi"] = "Xem log",
                ["en"] = "View Logs"
            },

            ["tray_exit"] = new()
            {
                ["zh"] = "退出",
                ["vi"] = "Thoát",
                ["en"] = "Exit"
            },
        };
    }
    
    public string GetText(string key, params object[] args)
    {
        if (_texts.TryGetValue(key, out var translations) && 
            translations.TryGetValue(_currentLanguage, out var text))
        {
            return args.Length > 0 ? string.Format(text, args) : text;
        }
        
        // 回退到英文
        if (_texts.TryGetValue(key, out var enText) && enText.TryGetValue("en", out var fallback))
            return args.Length > 0 ? string.Format(fallback, args) : fallback;
        
        return key;
    }
    
    public void SetLanguage(string language)
    {
        if (_texts.ContainsKey(language) && _currentLanguage != language)
        {
            _currentLanguage = language;
            LanguageChanged?.Invoke(language);
        }
    }
}
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public enum HealthStatus
{
    Healthy, Degraded, Unhealthy, Unknown
}

public class ComponentHealth
{
    public string Name { get; set; } = string.Empty;
    public HealthStatus Status { get; set; } = HealthStatus.Unknown;
    public DateTime LastCheckTime { get; set; }
    public DateTime LastHealthyTime { get; set; }
    public int FailureCount { get; set; }
    public int RecoveryCount { get; set; }
    public string Message { get; set; } = string.Empty;
    public Dictionary<string, object> Metrics { get; set; } = new();
}

public interface IHealthMonitorService
{
    void RegisterComponent(string name, Action? recoveryCallback = null);
    void UpdateStatus(string component, HealthStatus status, string message = "", Dictionary<string, object>? metrics = null);
    ComponentHealth? GetComponentStatus(string component);
    HealthSummary GetSummary();
    void Start();
    void Stop();
}

public class HealthSummary
{
    public int Total { get; set; }
    public int Healthy { get; set; }
    public int Degraded { get; set; }
    public int Unhealthy { get; set; }
    public int Unknown { get; set; }
    public double HealthRate { get; set; }
    public int TotalRecoveries { get; set; }
}

public class HealthMonitorService : IHealthMonitorService, IHostedService
{
    private readonly ConcurrentDictionary<string, ComponentHealth> _components = new();
    private readonly ConcurrentDictionary<string, List<Action>> _recoveryCallbacks = new();
    private readonly ConcurrentDictionary<string, DateTime> _lastRecoveryTime = new();
    private readonly System.Threading.Timer? _monitorTimer;
    private bool _isRunning;
    private readonly int _checkInterval = 60;
    private readonly int _recoveryCooldown = 300;
    
    public HealthMonitorService()
    {
        _monitorTimer = new System.Threading.Timer(MonitorLoop, null, _checkInterval * 1000, _checkInterval * 1000);
    }
    
    public void RegisterComponent(string name, Action? recoveryCallback = null)
    {
        _components.TryAdd(name, new ComponentHealth { Name = name });
        if (recoveryCallback != null)
            _recoveryCallbacks.AddOrUpdate(name, _ => new List<Action> { recoveryCallback }, (_, list) => { list.Add(recoveryCallback); return list; });
        
        Log.Information($"✅ 组件已注册: {name}");
    }
    
    public void UpdateStatus(string component, HealthStatus status, string message = "", Dictionary<string, object>? metrics = null)
    {
        if (!_components.TryGetValue(component, out var health))
            return;
        
        lock (health)
        {
            var oldStatus = health.Status;
            health.Status = status;
            health.LastCheckTime = DateTime.UtcNow;
            health.Message = message;
            if (metrics != null)
                foreach (var kv in metrics)
                    health.Metrics[kv.Key] = kv.Value;
            
            if (status == HealthStatus.Healthy)
            {
                health.LastHealthyTime = DateTime.UtcNow;
                health.FailureCount = 0;
            }
            else if (status == HealthStatus.Degraded || status == HealthStatus.Unhealthy)
            {
                health.FailureCount++;
            }
            
            if (health.FailureCount >= 3 && oldStatus != status)
                TriggerRecovery(component);
        }
    }
    
    private void TriggerRecovery(string component)
    {
        var now = DateTime.UtcNow;
        if (_lastRecoveryTime.TryGetValue(component, out var last) && (now - last).TotalSeconds < _recoveryCooldown)
            return;
        
        _lastRecoveryTime[component] = now;
        
        if (_components.TryGetValue(component, out var health))
            health.RecoveryCount++;
        
        Log.Warning($"🔄 触发组件恢复: {component}");
        
        if (_recoveryCallbacks.TryGetValue(component, out var callbacks))
        {
            foreach (var callback in callbacks)
            {
                try { callback(); }
                catch (Exception ex) { Log.Error(ex, $"恢复回调失败: {component}"); }
            }
        }
    }
    
    public ComponentHealth? GetComponentStatus(string component)
    {
        _components.TryGetValue(component, out var health);
        return health;
    }
    
    public HealthSummary GetSummary()
    {
        var components = _components.Values.ToList();
        return new HealthSummary
        {
            Total = components.Count,
            Healthy = components.Count(c => c.Status == HealthStatus.Healthy),
            Degraded = components.Count(c => c.Status == HealthStatus.Degraded),
            Unhealthy = components.Count(c => c.Status == HealthStatus.Unhealthy),
            Unknown = components.Count(c => c.Status == HealthStatus.Unknown),
            HealthRate = components.Count > 0 ? (double)components.Count(c => c.Status == HealthStatus.Healthy) / components.Count : 0,
            TotalRecoveries = components.Sum(c => c.RecoveryCount)
        };
    }
    
    private void MonitorLoop(object? state)
    {
        if (!_isRunning) return;
        
        var now = DateTime.UtcNow;
        foreach (var kv in _components)
        {
            var health = kv.Value;
            if ((now - health.LastCheckTime).TotalSeconds > _checkInterval * 3)
            {
                Log.Warning($"组件 {kv.Key} 状态更新超时");
                health.Status = HealthStatus.Unknown;
            }
        }
    }
    
    public void Start() { _isRunning = true; Log.Information("✅ 健康监控已启动"); }
    public void Stop() { _isRunning = false; Log.Information("健康监控已停止"); }
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
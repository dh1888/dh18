using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace EnterpriseAgent;

public interface IAppMonitorService
{
    void Start();
    void Stop();
    AppMonitorStats GetStats();
    event EventHandler<AppUsageData>? AppActivated;
}

public class AppUsageData
{
    public string EmployeeId { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string AppName { get; set; } = string.Empty;
    public string AppPath { get; set; } = string.Empty;
    public string WindowTitle { get; set; } = string.Empty;
    public DateTime StartTime { get; set; }
    public DateTime? EndTime { get; set; }
    public int Duration { get; set; }
    public bool IsForeground { get; set; }
    public int CpuAvg { get; set; }
    public int MemoryAvg { get; set; }
    public string ComputerName { get; set; } = string.Empty;
    public string WindowsUser { get; set; } = string.Empty;
}

public class AppMonitorStats
{
    public int SessionsTracked { get; set; }
    public int SessionsCompleted { get; set; }
    public int AppsReported { get; set; }
    public int SamplesCollected { get; set; }
    public int FocusSwitches { get; set; }
    public int ActiveSessions { get; set; }
    public double CurrentCpuUsage { get; set; }
    public double CurrentMemoryMB { get; set; }
}

public class AppMonitorService : IAppMonitorService, IHostedService
{
    private readonly IConfigurationService _configService;
    private readonly IHttpClientService _httpService;
    private readonly ConcurrentDictionary<int, AppSession> _activeSessions = new();
    private readonly List<AppSession> _completedSessions = new();
    private readonly object _lock = new();
    private System.Threading.Timer? _monitorTimer;
    private System.Threading.Timer? _reportTimer;
    private bool _isRunning;
    private int _lastForegroundPid;
    private DateTime _lastForegroundTime;
    private AppMonitorStats _stats = new();
    
    private class AppSession
    {
        public int Pid { get; set; }
        public string Name { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public string ExePath { get; set; } = string.Empty;
        public string WindowTitle { get; set; } = string.Empty;
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public List<TimeSegment> TimeSegments { get; set; } = new();
        public List<ResourceSample> ResourceSamples { get; set; } = new();
        public bool IsForeground { get; set; }
        public int FocusCount { get; set; }
        public double TotalForegroundTime { get; set; }
        public double TotalBackgroundTime { get; set; }
        public DateTime LastActiveTime { get; set; }
        public double TotalCpuSum { get; set; }
        public double TotalMemorySum { get; set; }
        public int SampleCount { get; set; }
        public double MaxCpu { get; set; }
        public double MaxMemory { get; set; }
        public double MinCpu { get; set; } = 999;
        public double MinMemory { get; set; } = 999;
        
        public double AvgCpu => SampleCount > 0 ? TotalCpuSum / SampleCount : 0;
        public double AvgMemory => SampleCount > 0 ? TotalMemorySum / SampleCount : 0;
        public double TotalDuration => EndTime > DateTime.MinValue ? (EndTime - StartTime).TotalSeconds : (DateTime.UtcNow - StartTime).TotalSeconds;
        public int ForegroundDuration => (int)TotalForegroundTime;
    }
    
    private class TimeSegment
    {
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public bool IsForeground { get; set; }
        public double Duration => (End - Start).TotalSeconds;
    }
    
    private class ResourceSample
    {
        public DateTime Timestamp { get; set; }
        public double CpuPercent { get; set; }
        public double MemoryMB { get; set; }
        public int ThreadCount { get; set; }
    }
    
    // 忽略的系统进程
    private static readonly HashSet<string> IgnoreProcesses = new()
    {
        "System", "Registry", "smss.exe", "csrss.exe", "wininit.exe", "services.exe",
        "lsass.exe", "svchost.exe", "conhost.exe", "dwm.exe", "Idle", "spoolsv.exe",
        "winlogon.exe", "explorer.exe", "taskhostw.exe", "sihost.exe", "dllhost.exe",
        "RuntimeBroker.exe", "ctfmon.exe", "SearchIndexer.exe", "WmiPrvSE.exe"
    };
    
    // 用户应用识别
    private static readonly Dictionary<string, string> UserApps = new(StringComparer.OrdinalIgnoreCase)
    {
        // 浏览器
        ["chrome.exe"] = "Google Chrome",
        ["msedge.exe"] = "Microsoft Edge",
        ["firefox.exe"] = "Firefox",
        ["brave.exe"] = "Brave",
        // 办公软件
        ["winword.exe"] = "Microsoft Word",
        ["excel.exe"] = "Microsoft Excel",
        ["powerpnt.exe"] = "Microsoft PowerPoint",
        ["outlook.exe"] = "Microsoft Outlook",
        ["wps.exe"] = "WPS Office",
        // 开发工具
        ["code.exe"] = "Visual Studio Code",
        ["devenv.exe"] = "Visual Studio",
        ["idea64.exe"] = "IntelliJ IDEA",
        ["pycharm64.exe"] = "PyCharm",
        // 通讯软件
        ["wechat.exe"] = "微信",
        ["qq.exe"] = "QQ",
        ["dingtalk.exe"] = "钉钉",
        ["feishu.exe"] = "飞书",
        ["teams.exe"] = "Microsoft Teams",
        // 设计软件
        ["photoshop.exe"] = "Adobe Photoshop",
        ["illustrator.exe"] = "Adobe Illustrator",
    };
    
    public AppMonitorService(IConfigurationService configService, IHttpClientService httpService)
    {
        _configService = configService;
        _httpService = httpService;
    }
    
    public event EventHandler<AppUsageData>? AppActivated;
    
    public void Start()
    {
        if (_isRunning) return;
        _isRunning = true;
        
        _monitorTimer = new System.Threading.Timer(MonitorLoop, null, 0, 1000);
        _reportTimer = new System.Threading.Timer(ReportLoop, null, 60000, 60000);
        
        Log.Information("✅ 软件监控服务已启动");
    }
    
    public void Stop()
    {
        _isRunning = false;
        _monitorTimer?.Dispose();
        _reportTimer?.Dispose();
        
        // 结束所有活跃会话
        foreach (var pid in _activeSessions.Keys.ToList())
            EndSession(pid, DateTime.UtcNow);
        
        // 上报剩余数据
        ReportData();
        
        Log.Information("软件监控服务已停止");
    }
    
    private void MonitorLoop(object? state)
    {
        if (!_isRunning) return;
        
        try
        {
            var foreground = GetForegroundApp();
            var currentPid = foreground?.Pid ?? 0;
            var now = DateTime.UtcNow;
            
            // 焦点变化处理
            if (currentPid != _lastForegroundPid)
            {
                if (_lastForegroundPid > 0 && _activeSessions.TryGetValue(_lastForegroundPid, out var oldSession))
                {
                    oldSession.IsForeground = false;
                    oldSession.TimeSegments.Add(new TimeSegment
                    {
                        Start = _lastForegroundTime,
                        End = now,
                        IsForeground = true
                    });
                    oldSession.TotalForegroundTime += (now - _lastForegroundTime).TotalSeconds;
                }
                
                if (currentPid > 0 && _activeSessions.TryGetValue(currentPid, out var newSession))
                {
                    newSession.IsForeground = true;
                    newSession.FocusCount++;
                    newSession.TimeSegments.Add(new TimeSegment
                    {
                        Start = now,
                        End = now,
                        IsForeground = true
                    });
                }
                
                _lastForegroundPid = currentPid;
                _lastForegroundTime = now;
                _stats.FocusSwitches++;
            }
            
            // 处理当前前台应用
            if (foreground != null)
            {
                if (_activeSessions.TryGetValue(foreground.Pid, out var session))
                {
                    session.LastActiveTime = now;
                    session.WindowTitle = foreground.WindowTitle ?? "";
                    
                    if (session.TimeSegments.Count > 0 && session.IsForeground)
                    {
                        var lastSegment = session.TimeSegments[^1];
                        lastSegment.End = now;
                        session.TotalForegroundTime = Math.Max(0, session.TotalForegroundTime - 
                            (lastSegment.Duration - (now - lastSegment.Start).TotalSeconds));
                        session.TotalForegroundTime += (now - lastSegment.Start).TotalSeconds;
                    }
                }
                else
                {
                    StartSession(foreground.Pid, foreground.Name, foreground.DisplayName, 
                        foreground.ExePath, foreground.WindowTitle, now);
                }
            }
            
            // 采样资源
            if ((now - _lastForegroundTime).TotalSeconds >= 5)
            {
                CollectResourceSamples(now);
            }
            
            // 清理不活跃会话
            var inactivePids = _activeSessions
                .Where(kv => (now - kv.Value.LastActiveTime).TotalSeconds > 60)
                .Select(kv => kv.Key)
                .ToList();
            
            foreach (var pid in inactivePids)
            {
                EndSession(pid, now);
                _activeSessions.TryRemove(pid, out _);
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "软件监控异常");
        }
    }
    
    private ForegroundAppInfo? GetForegroundApp()
    {
        try
        {
            var hwnd = GetForegroundWindow();
            if (hwnd == IntPtr.Zero) return null;
            
            GetWindowThreadProcessId(hwnd, out var pid);
            if (pid == 0) return null;
            
            var process = Process.GetProcessById(pid);
            var name = process.ProcessName + ".exe";
            
            if (IgnoreProcesses.Contains(name.ToLower()))
                return null;
            
            var windowTitle = GetWindowText(hwnd);
            if (string.IsNullOrEmpty(windowTitle))
                return null;
            
            var displayName = UserApps.GetValueOrDefault(name, name);
            var exePath = process.MainModule?.FileName ?? "";
            
            return new ForegroundAppInfo
            {
                Hwnd = hwnd,
                Pid = pid,
                Name = name,
                DisplayName = displayName,
                ExePath = exePath,
                WindowTitle = windowTitle
            };
        }
        catch
        {
            return null;
        }
    }
    
    private void StartSession(int pid, string name, string displayName, string exePath, string windowTitle, DateTime startTime)
    {
        var session = new AppSession
        {
            Pid = pid,
            Name = name,
            DisplayName = displayName,
            ExePath = exePath,
            WindowTitle = windowTitle,
            StartTime = startTime,
            LastActiveTime = startTime,
            IsForeground = true,
            TimeSegments = { new TimeSegment { Start = startTime, End = startTime, IsForeground = true } }
        };
        
        _activeSessions[pid] = session;
        _stats.SessionsTracked++;
        
        AppActivated?.Invoke(this, new AppUsageData
        {
            AppName = name,
            AppPath = exePath,
            WindowTitle = windowTitle,
            StartTime = startTime,
            IsForeground = true
        });
    }
    
    private void EndSession(int pid, DateTime endTime)
    {
        if (!_activeSessions.TryGetValue(pid, out var session))
            return;
        
        if (session.TimeSegments.Count > 0)
        {
            var lastSegment = session.TimeSegments[^1];
            lastSegment.End = endTime;
            if (lastSegment.IsForeground)
                session.TotalForegroundTime += (endTime - lastSegment.Start).TotalSeconds;
            else
                session.TotalBackgroundTime += (endTime - lastSegment.Start).TotalSeconds;
        }
        
        session.EndTime = endTime;
        
        var totalDuration = session.TotalDuration;
        var foregroundDuration = session.ForegroundDuration;
        var foregroundRatio = totalDuration > 0 ? foregroundDuration / totalDuration : 0;
        
        if (totalDuration >= 3 && foregroundRatio >= 0.3)
        {
            lock (_lock)
            {
                _completedSessions.Add(session);
                _stats.SessionsCompleted++;
            }
        }
    }
    
    private void CollectResourceSamples(DateTime timestamp)
    {
        foreach (var kv in _activeSessions)
        {
            try
            {
                var process = Process.GetProcessById(kv.Key);
                var cpuUsage = GetCpuUsage(process);
                var memoryMB = process.WorkingSet64 / (1024.0 * 1024);
                
                kv.Value.ResourceSamples.Add(new ResourceSample
                {
                    Timestamp = timestamp,
                    CpuPercent = cpuUsage,
                    MemoryMB = memoryMB,
                    ThreadCount = process.Threads.Count
                });
                
                kv.Value.TotalCpuSum += cpuUsage;
                kv.Value.TotalMemorySum += memoryMB;
                kv.Value.SampleCount++;
                kv.Value.MaxCpu = Math.Max(kv.Value.MaxCpu, cpuUsage);
                kv.Value.MaxMemory = Math.Max(kv.Value.MaxMemory, memoryMB);
                kv.Value.MinCpu = Math.Min(kv.Value.MinCpu, cpuUsage);
                kv.Value.MinMemory = Math.Min(kv.Value.MinMemory, memoryMB);
                
                _stats.SamplesCollected++;
            }
            catch { }
        }
    }
    
    private double GetCpuUsage(Process process)
    {
        try
        {
            var startTime = DateTime.UtcNow;
            var startCpu = process.TotalProcessorTime;
            Thread.Sleep(100);
            var endTime = DateTime.UtcNow;
            var endCpu = process.TotalProcessorTime;
            
            var cpuUsedMs = (endCpu - startCpu).TotalMilliseconds;
            var totalMs = (endTime - startTime).TotalMilliseconds;
            return cpuUsedMs / (Environment.ProcessorCount * totalMs) * 100;
        }
        catch
        {
            return 0;
        }
    }
    
    private void ReportLoop(object? state)
    {
        if (!_isRunning) return;
        ReportData();
    }
    
    private void ReportData()
    {
        List<AppSession> sessionsToReport;
        lock (_lock)
        {
            sessionsToReport = _completedSessions.ToList();
            _completedSessions.Clear();
        }
        
        if (sessionsToReport.Count == 0) return;
        
        var config = _configService.Load();
        var computerName = Environment.MachineName;
        var windowsUser = Environment.UserName;
        
        var reportData = new List<AppUsageData>();
        
        foreach (var session in sessionsToReport)
        {
            reportData.Add(new AppUsageData
            {
                EmployeeId = config?.EmployeeId ?? "",
                ClientId = config?.ClientId ?? "",
                AppName = session.Name,
                AppPath = session.ExePath,
                WindowTitle = session.WindowTitle,
                StartTime = session.StartTime,
                EndTime = session.EndTime,
                Duration = (int)session.TotalDuration,
                IsForeground = session.ForegroundDuration > session.TotalBackgroundTime,
                CpuAvg = (int)Math.Round(session.AvgCpu),
                MemoryAvg = (int)Math.Round(session.AvgMemory),
                ComputerName = computerName,
                WindowsUser = windowsUser
            });
        }
        
        Log.Information($"📤 上报软件数据: {reportData.Count}条");
        
        _ = Task.Run(async () =>
        {
            try
            {
                await _httpService.UploadAppUsageAsync(reportData);
                _stats.AppsReported += reportData.Count;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "上报软件数据失败");
                lock (_lock)
                    _completedSessions.AddRange(sessionsToReport);
            }
        });
    }
    
    public AppMonitorStats GetStats()
    {
        return new AppMonitorStats
        {
            SessionsTracked = _stats.SessionsTracked,
            SessionsCompleted = _stats.SessionsCompleted,
            AppsReported = _stats.AppsReported,
            SamplesCollected = _stats.SamplesCollected,
            FocusSwitches = _stats.FocusSwitches,
            ActiveSessions = _activeSessions.Count,
            CurrentCpuUsage = _activeSessions.Values.Sum(s => s.ResourceSamples.LastOrDefault()?.CpuPercent ?? 0),
            CurrentMemoryMB = _activeSessions.Values.Sum(s => s.ResourceSamples.LastOrDefault()?.MemoryMB ?? 0)
        };
    }
    
    private class ForegroundAppInfo
    {
        public IntPtr Hwnd { get; set; }
        public int Pid { get; set; }
        public string Name { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public string ExePath { get; set; } = string.Empty;
        public string WindowTitle { get; set; } = string.Empty;
    }
    
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();
    
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);
    
    [DllImport("user32.dll")]
    private static extern int GetWindowText(IntPtr hWnd, System.Text.StringBuilder text, int count);
    
    private static string GetWindowText(IntPtr hWnd)
    {
        const int nChars = 256;
        var buff = new System.Text.StringBuilder(nChars);
        return GetWindowText(hWnd, buff, nChars) > 0 ? buff.ToString() : "";
    }
    
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Win32;

namespace EnterpriseAgent;

public interface IPowerManagerService
{
    bool IsPowerSavingMode { get; }
    bool IsIdleMode { get; }
    bool IsBatteryMode { get; }
    int GetCurrentInterval();
    PowerStats GetStats();
    void Start();
    void Stop();
}

public class PowerStats
{
    public int PowerSavingEntered { get; set; }
    public int PowerSavingExited { get; set; }
    public int IdleEntered { get; set; }
    public int IdleExited { get; set; }
    public int BatteryModeEntered { get; set; }
    public int BatteryModeExited { get; set; }
    public long TotalTimeSavedSeconds { get; set; }
    public int CurrentInterval { get; set; }
    public int BaseInterval { get; set; }
    public bool IsPowerSaving { get; set; }
    public bool IsIdle { get; set; }
    public bool IsBattery { get; set; }
}

public class PowerManagerService : IPowerManagerService, IHostedService
{
    private readonly IConfigurationService _configService;
    private readonly object _lock = new();
    private System.Threading.Timer? _monitorTimer;
    private bool _isRunning;
    private int _baseInterval;
    private int _powerSavingInterval;
    private int _idleInterval;
    private DateTime _lastActivityTime;
    private PowerStats _stats;
    
    public bool IsPowerSavingMode { get; private set; }
    public bool IsIdleMode { get; private set; }
    public bool IsBatteryMode { get; private set; }
    
    public PowerManagerService(IConfigurationService configService)
    {
        _configService = configService;
        _stats = new PowerStats();
        
        var config = _configService.Load();
        _baseInterval = config?.ScreenshotInterval ?? 60;
        _powerSavingInterval = _baseInterval * 2;
        _idleInterval = _baseInterval * 3;
        _lastActivityTime = DateTime.UtcNow;
        
        // 注册系统电源事件
        SystemEvents.PowerModeChanged += OnPowerModeChanged;
    }
    
    private void OnPowerModeChanged(object sender, PowerModeChangedEventArgs e)
    {
        lock (_lock)
        {
            if (e.Mode == PowerModes.Suspend)
            {
                // 系统休眠
            }
            else if (e.Mode == PowerModes.Resume)
            {
                // 系统唤醒
                RecordActivity();
            }
            else if (e.Mode == PowerModes.StatusChange)
            {
                CheckBatteryStatus();
            }
        }
    }
    
    private void CheckBatteryStatus()
    {
        var systemPowerStatus = new SystemPowerStatus();

        // 添加 ref 关键字
            GetSystemPowerStatus(ref systemPowerStatus);
            var wasBattery = IsBatteryMode;

            IsBatteryMode = systemPowerStatus.ACLineStatus != 1;

            if (IsBatteryMode && !wasBattery)
            {
                _stats.BatteryModeEntered++;
                Log.Information("🔋 切换到电池模式");
            }
            else if (!IsBatteryMode && wasBattery)
            {
                _stats.BatteryModeExited++;
                Log.Information("🔌 切换到电源模式");
            }
        
    }
    
    public void RecordActivity()
    {
        _lastActivityTime = DateTime.UtcNow;
        if (IsIdleMode)
        {
            IsIdleMode = false;
            _stats.IdleExited++;
            Log.Information("✨ 退出空闲模式");
        }
    }
    
    public int GetCurrentInterval()
    {
        lock (_lock)
        {
            if (IsBatteryMode || IsPowerSavingMode)
                return _powerSavingInterval;
            if (IsIdleMode)
                return _idleInterval;
            return _baseInterval;
        }
    }
    
    public PowerStats GetStats()
    {
        lock (_lock)
        {
            _stats.CurrentInterval = GetCurrentInterval();
            _stats.BaseInterval = _baseInterval;
            _stats.IsPowerSaving = IsPowerSavingMode;
            _stats.IsIdle = IsIdleMode;
            _stats.IsBattery = IsBatteryMode;
            return _stats;
        }
    }
    
    public void SetPowerSaving(bool enabled)
    {
        lock (_lock)
        {
            if (enabled && !IsPowerSavingMode)
            {
                _stats.PowerSavingEntered++;
                Log.Information($"启用节电模式");
            }
            else if (!enabled && IsPowerSavingMode)
            {
                _stats.PowerSavingExited++;
                Log.Information($"禁用节电模式");
            }
            IsPowerSavingMode = enabled;
        }
    }
    
    public void Start()
    {
        if (_isRunning) return;
        _isRunning = true;
        _monitorTimer = new System.Threading.Timer(MonitorLoop, null, 0, 1000);
        Log.Information("✅ 功耗管理系统已启动");
    }
    
    public void Stop()
    {
        _isRunning = false;
        _monitorTimer?.Dispose();
        _monitorTimer = null;
    }
    
    private void MonitorLoop(object? state)
    {
        if (!_isRunning) return;
        
        try
        {
            CheckBatteryStatus();
            CheckIdleStatus();
            AdjustInterval();
        }
        catch (Exception ex)
        {
            Log.Error(ex, "功耗监控异常");
        }
    }
    
    private void CheckIdleStatus()
    {
        try
        {
            var idleTime = GetIdleTime();
            var wasIdle = IsIdleMode;
            IsIdleMode = idleTime.TotalSeconds > 300;
            
            if (IsIdleMode && !wasIdle)
            {
                _stats.IdleEntered++;
                Log.Information("💤 进入空闲模式");
            }
        }
        catch { }
    }
    
    private void AdjustInterval()
    {
        // 动态调整截图间隔 - 通过事件通知其他服务
        AdjustIntervalRequested?.Invoke(this, GetCurrentInterval());
    }
    
    public event EventHandler<int>? AdjustIntervalRequested;
    
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
    
    [System.Runtime.InteropServices.DllImport("kernel32.dll")]
    private static extern void GetSystemPowerStatus(ref SystemPowerStatus pps);
    
    private TimeSpan GetIdleTime()
    {
        var lastInputInfo = new LASTINPUTINFO();
        lastInputInfo.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lastInputInfo);
        
        if (GetLastInputInfo(ref lastInputInfo))
        {
            var idleTime = TimeSpan.FromMilliseconds(Environment.TickCount - lastInputInfo.dwTime);
            return idleTime > TimeSpan.Zero ? idleTime : TimeSpan.Zero;
        }
        return TimeSpan.Zero;
    }
    
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    private struct LASTINPUTINFO
    {
        public uint cbSize;
        public uint dwTime;
    }
    
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    private struct SystemPowerStatus
    {
        public byte ACLineStatus;
        public byte BatteryFlag;
        public byte BatteryLifePercent;
        public byte Reserved1;
        public int BatteryLifeTime;
        public int BatteryFullLifeTime;
    }
    
    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}
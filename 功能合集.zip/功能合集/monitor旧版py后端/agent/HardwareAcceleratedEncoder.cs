using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

namespace EnterpriseAgent;

public class HardwareAcceleratedEncoder : IDisposable
{
    private bool _disposed;
    private readonly int _quality;
    private readonly bool _useHardwareAcceleration;
    
    public HardwareAcceleratedEncoder(int quality = 70, bool useHardwareAcceleration = true)
    {
        _quality = Math.Clamp(quality, 30, 95);
        _useHardwareAcceleration = useHardwareAcceleration;
        
        Log.Information($"硬件加速编码器: Quality={_quality}, HW={_useHardwareAcceleration}");
    }
    
    public byte[] EncodeFullFrame(Bitmap bitmap, int quality)
    {
        try
        {
            using var ms = new MemoryStream();
            var codec = GetEncoderInfo("image/jpeg");
            var encoderParams = new EncoderParameters(1);
            encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, quality);
            bitmap.Save(ms, codec, encoderParams);
            return ms.ToArray();
        }
        catch (Exception ex)
        {
            Log.Error(ex, "编码失败");
            return Array.Empty<byte>();
        }
    }
    
    public byte[] EncodeRegionFrame(byte[] imageData, Rectangle region, int quality)
    {
        // 简化版：返回空数组
        return Array.Empty<byte>();
    }
    
    private ImageCodecInfo GetEncoderInfo(string mimeType)
    {
        var codecs = ImageCodecInfo.GetImageEncoders();
        foreach (var codec in codecs)
        {
            if (codec.MimeType == mimeType)
                return codec;
        }
        return codecs[0];
    }
    
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
    }
}
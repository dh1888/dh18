using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace EnterpriseAgent
{
    /// <summary>
    /// StackPanel 扩展 - 支持 Spacing 属性
    /// </summary>
    public static class StackPanelExtensions
    {
        public static readonly DependencyProperty SpacingProperty =
            DependencyProperty.RegisterAttached(
                "Spacing",
                typeof(double),
                typeof(StackPanelExtensions),
                new PropertyMetadata(0.0, OnSpacingChanged));

        public static double GetSpacing(DependencyObject obj)
        {
            return (double)obj.GetValue(SpacingProperty);
        }

        public static void SetSpacing(DependencyObject obj, double value)
        {
            obj.SetValue(SpacingProperty, value);
        }

        private static void OnSpacingChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is StackPanel panel)
            {
                // 移除旧的事件处理
                panel.Loaded -= OnPanelLoaded;
                panel.LayoutUpdated -= OnLayoutUpdated;
                
                // 添加新的事件处理
                panel.Loaded += OnPanelLoaded;
                panel.LayoutUpdated += OnLayoutUpdated;
                
                // 立即更新一次
                UpdateSpacing(panel);
            }
        }

        private static void OnPanelLoaded(object sender, RoutedEventArgs e)
        {
            if (sender is StackPanel panel)
            {
                UpdateSpacing(panel);
            }
        }

        private static void OnLayoutUpdated(object? sender, EventArgs e)
        {
            if (sender is StackPanel panel)
            {
                UpdateSpacing(panel);
            }
        }

        private static void UpdateSpacing(StackPanel panel)
        {
            var spacing = GetSpacing(panel);
            if (spacing <= 0) return;

            // 获取所有非可见性为 Collapsed 的子元素
            var visibleChildren = panel.Children
                .Cast<FrameworkElement>()
                .Where(child => child.Visibility != Visibility.Collapsed)
                .ToList();

            for (int i = 0; i < visibleChildren.Count; i++)
            {
                var child = visibleChildren[i];
                // 跳过最后一个元素
                if (i == visibleChildren.Count - 1)
                {
                    child.Margin = new Thickness(0);
                }
                else
                {
                    // 根据 StackPanel 方向设置 Margin，明确使用 System.Windows.Controls.Orientation
                    if (panel.Orientation == System.Windows.Controls.Orientation.Horizontal)
                    {
                        child.Margin = new Thickness(0, 0, spacing, 0);
                    }
                    else
                    {
                        child.Margin = new Thickness(0, 0, 0, spacing);
                    }
                }
            }
        }
    }
}
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Channels;

namespace EnterpriseAgent;

public interface IFileOperationService
{
    void Start();
    void Stop();
}

public class FileOperationService : IFileOperationService, IDisposable
{
    private readonly IConfigurationService _configService;
    private readonly IHttpClientService _httpService;
    private readonly Channel<List<FileOperationData>> _uploadChannel;
    private FileSystemWatcher? _fileWatcher;
    private CancellationTokenSource? _cts;
    private Task? _uploadLoopTask;
    private int _isRunning;
    private readonly HashSet<string> _watchedPaths = new();
    private readonly List<FileOperationData> _pendingOperations = new();
    private readonly object _queueLock = new();
    private System.Threading.Timer? _flushTimer;
    
    // 忽略的目录
    private static readonly HashSet<string> IgnoreDirectories = new(StringComparer.OrdinalIgnoreCase)
    {
        "Windows", "Program Files", "Program Files (x86)", "ProgramData",
        "System Volume Information", "$Recycle.Bin", "AppData", "Temp", "tmp",
        "Cache", "cache", "node_modules", ".git", ".vs", "bin", "obj"
    };
    
    // 忽略的文件扩展名
    private static readonly HashSet<string> IgnoreExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".tmp", ".temp", ".log", ".cache", ".bak", ".lnk", ".lock",
        ".swp", ".swo", ".~", ".part", ".crdownload"
    };
    
    public FileOperationService(
        IConfigurationService configService,
        IHttpClientService httpService)
    {
        _configService = configService;
        _httpService = httpService;
        _uploadChannel = Channel.CreateBounded<List<FileOperationData>>(new BoundedChannelOptions(100)
        {
            FullMode = BoundedChannelFullMode.DropOldest
        });
    }
    
    public void Start()
    {
        if (Interlocked.Exchange(ref _isRunning, 1) == 1)
            return;

        _cts = new CancellationTokenSource();

        _uploadLoopTask = Task.Run(UploadLoopAsync);

        _flushTimer = new System.Threading.Timer(
            FlushOperations,
            null,
            30000,
            30000);

        // 监控常用目录 - 修复 Downloads 路径
        var directoriesToWatch = new[]
        {
            Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            Environment.GetFolderPath(Environment.SpecialFolder.MyMusic),
            Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
            Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),

            // 修复：Downloads 文件夹需要手动构建路径
            Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.UserProfile),
                "Downloads")
        };

        foreach (var dir in directoriesToWatch)
        {
            if (Directory.Exists(dir) &&
                !_watchedPaths.Contains(dir))
            {
                WatchDirectory(dir);
                _watchedPaths.Add(dir);
            }
        }

        Log.Information(
            $"✅ 文件监控服务已启动，监控 {_watchedPaths.Count} 个目录");
    }
    
    public void Stop()
    {
        if (Interlocked.Exchange(ref _isRunning, 0) == 0)
            return;
        
        _cts?.Cancel();
        _uploadChannel.Writer.TryComplete();
        _flushTimer?.Dispose();
        
        // 刷新待处理操作
        FlushOperations(null);
        
        _fileWatcher?.Dispose();
        _fileWatcher = null;
        
        Log.Information("文件监控服务已停止");
    }
    
    private void WatchDirectory(string path)
    {
        try
        {
            var watcher = new FileSystemWatcher(path)
            {
                IncludeSubdirectories = true,
                EnableRaisingEvents = true,
                InternalBufferSize = 65536
            };
            
            watcher.Created += OnFileCreated;
            watcher.Changed += OnFileChanged;
            watcher.Deleted += OnFileDeleted;
            watcher.Renamed += OnFileRenamed;
            watcher.Error += OnWatcherError;
            
            _fileWatcher = watcher;
            
            Log.Debug($"监控目录: {path}");
        }
        catch (Exception ex)
        {
            Log.Error(ex, $"监控目录失败: {path}");
        }
    }
    
    private void OnWatcherError(object sender, ErrorEventArgs e)
    {
        Log.Error(e.GetException(), "文件监控错误");
    }
    
    private bool ShouldIgnore(string path)
    {
        // 检查忽略目录
        foreach (var ignoreDir in IgnoreDirectories)
        {
            if (path.Contains(ignoreDir, StringComparison.OrdinalIgnoreCase))
                return true;
        }
        
        // 检查扩展名
        var ext = Path.GetExtension(path);
        if (IgnoreExtensions.Contains(ext))
            return true;
        
        // 检查临时文件
        var fileName = Path.GetFileName(path);
        if (fileName.StartsWith("~") || fileName.StartsWith(".") || fileName.StartsWith("_"))
            return true;
        
        return false;
    }
    
    private void OnFileCreated(object sender, FileSystemEventArgs e)
    {
        if (ShouldIgnore(e.FullPath)) return;
        AddOperation("create", e.FullPath);
    }
    
    private void OnFileChanged(object sender, FileSystemEventArgs e)
    {
        if (ShouldIgnore(e.FullPath)) return;
        if (File.Exists(e.FullPath))
        {
            AddOperation("modify", e.FullPath);
        }
    }
    
    private void OnFileDeleted(object sender, FileSystemEventArgs e)
    {
        if (ShouldIgnore(e.FullPath)) return;
        AddOperation("delete", e.FullPath);
    }
    
    private void OnFileRenamed(object sender, RenamedEventArgs e)
    {
        if (ShouldIgnore(e.FullPath)) return;
        AddOperation("rename", e.FullPath, e.OldFullPath);
    }
    
    private void AddOperation(string operation, string filePath, string? oldPath = null)
    {
        try
        {
            var fileInfo = new FileInfo(filePath);
            var isDirectory = Directory.Exists(filePath);
            var ext = Path.GetExtension(filePath);
            var fileType = GetFileTypeCategory(ext);
            
            var operationData = new FileOperationData
            {
                EmployeeId = _configService.Load()?.EmployeeId ?? "",
                ClientId = _configService.Load()?.ClientId ?? "",
                Operation = operation,
                FilePath = filePath,
                FileName = Path.GetFileName(filePath),
                FileSize = isDirectory ? 0 : (fileInfo.Exists ? fileInfo.Length : 0),
                FileType = fileType,
                IsDirectory = isDirectory,
                OperationTime = DateTime.UtcNow,
                ComputerName = Environment.MachineName,
                WindowsUser = Environment.UserName
            };
            
            lock (_queueLock)
            {
                _pendingOperations.Add(operationData);
                
                if (_pendingOperations.Count >= 50)
                {
                    FlushOperations(null);
                }
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, $"添加文件操作失败: {operation} - {filePath}");
        }
    }
    
    private string GetFileTypeCategory(string extension)
    {
        if (string.IsNullOrEmpty(extension)) return "其他";
        
        extension = extension.ToLower();
        
        var categories = new Dictionary<string, string[]>
        {
            ["文档"] = new[] { ".doc", ".docx", ".pdf", ".txt", ".rtf", ".md" },
            ["表格"] = new[] { ".xls", ".xlsx", ".csv" },
            ["演示"] = new[] { ".ppt", ".pptx" },
            ["图片"] = new[] { ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp" },
            ["视频"] = new[] { ".mp4", ".avi", ".mov", ".wmv", ".flv", ".mkv" },
            ["音频"] = new[] { ".mp3", ".wav", ".flac", ".aac", ".ogg" },
            ["压缩包"] = new[] { ".zip", ".rar", ".7z", ".tar", ".gz" },
            ["代码"] = new[] { ".py", ".java", ".c", ".cpp", ".cs", ".js", ".html", ".css", ".json", ".xml" },
            ["可执行"] = new[] { ".exe", ".msi", ".bat", ".cmd", ".ps1" }
        };
        
        foreach (var category in categories)
        {
            if (category.Value.Contains(extension))
                return category.Key;
        }
        
        return "其他";
    }
    
    private void FlushOperations(object? state)
    {
        List<FileOperationData> batch;
        lock (_queueLock)
        {
            if (_pendingOperations.Count == 0) return;
            batch = _pendingOperations.ToList();
            _pendingOperations.Clear();
        }
        
        _uploadChannel.Writer.TryWrite(batch);
    }
    
    private async Task UploadLoopAsync()
    {
        var reader = _uploadChannel.Reader;
        
        while (await reader.WaitToReadAsync())
        {
            while (reader.TryRead(out var operations))
            {
                try
                {
                    var success = await _httpService.UploadFileOperationsAsync(operations);
                    if (!success)
                    {
                        Log.Warning($"文件操作上传失败，{operations.Count}条记录将重试");
                        await Task.Delay(5000);
                    }
                    else
                    {
                        Log.Debug($"文件操作上传成功: {operations.Count}条");
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "上传文件操作异常");
                }
            }
        }
    }
    
    public void Dispose()
    {
        _cts?.Dispose();
        _flushTimer?.Dispose();
        _fileWatcher?.Dispose();
    }
}
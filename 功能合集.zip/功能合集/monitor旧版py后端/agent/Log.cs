using Serilog;
using ILogger = Serilog.ILogger;

namespace EnterpriseAgent;

public static class Log
{
    private static ILogger? _logger;
    
    // 添加 Logger 属性
    public static ILogger? Logger => _logger;
    
    public static void Initialize(ILogger logger)
    {
        _logger = logger;
    }
    
    public static void Information(string message, params object[] args)
    {
        _logger?.Information(message, args);
    }
    
    public static void Warning(string message, params object[] args)
    {
        _logger?.Warning(message, args);
    }
    
    public static void Error(string message, params object[] args)
    {
        _logger?.Error(message, args);
    }
    
    public static void Error(Exception exception, string message, params object[] args)
    {
        _logger?.Error(exception, message, args);
    }
    
    public static void Debug(string message, params object[] args)
    {
        _logger?.Debug(message, args);
    }
    
    public static void Debug(Exception exception, string message, params object[] args)
    {
        _logger?.Debug(exception, message, args);
    }
    
    public static void Fatal(string message, params object[] args)
    {
        _logger?.Fatal(message, args);
    }
    
    public static void Fatal(Exception? exception, string message, params object[] args)
    {
        if (exception != null)
            _logger?.Fatal(exception, message, args);
        else
            _logger?.Fatal(message, args);
    }
    
    public static void CloseAndFlush()
    {
        _logger = null;
        Serilog.Log.CloseAndFlush();
    }
}
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Polly;

namespace EnterpriseAgent;

public class AgentBackgroundService : BackgroundService
{
    private readonly IConfigurationService _configService;
    private readonly IWebSocketService _webSocketService;
    private readonly IHttpClientService _httpService;
    private readonly IHeartbeatService _heartbeatService;
    private readonly IScreenshotCaptureService _screenshotService;
    private readonly IBrowserHistoryService _browserHistoryService;
    private readonly IFileOperationService _fileOperationService;
    private readonly IAppMonitorService _appMonitorService;
    private readonly IBrowserMonitorService _browserMonitorService;
    private readonly IRemoteScreenService _remoteScreenService;
    private readonly ITaskQueue _taskQueue;
    private readonly ITaskRegistry _taskRegistry;
    private readonly IUpdateService _updateService;
    private readonly IPowerManagerService _powerManager;
    private readonly IErrorRecoveryService _errorRecovery;
    private readonly IHealthMonitorService _healthMonitor;
    private readonly IWatchdogService _watchdog;
    private readonly II18nService _i18n;
    
    private readonly AsyncPolicy _retryPolicy;
    private bool _isRegistered;
    
    public AgentBackgroundService(
        IConfigurationService configService,
        IWebSocketService webSocketService,
        IHttpClientService httpService,
        IHeartbeatService heartbeatService,
        IScreenshotCaptureService screenshotService,
        IBrowserHistoryService browserHistoryService,
        IFileOperationService fileOperationService,
        IAppMonitorService appMonitorService,
        IBrowserMonitorService browserMonitorService,
        IRemoteScreenService remoteScreenService,
        ITaskQueue taskQueue,
        ITaskRegistry taskRegistry,
        IUpdateService updateService,
        IPowerManagerService powerManager,
        IErrorRecoveryService errorRecovery,
        IHealthMonitorService healthMonitor,
        IWatchdogService watchdog,
        II18nService i18n)
    {
        _configService = configService;
        _webSocketService = webSocketService;
        _httpService = httpService;
        _heartbeatService = heartbeatService;
        _screenshotService = screenshotService;
        _browserHistoryService = browserHistoryService;
        _fileOperationService = fileOperationService;
        _appMonitorService = appMonitorService;
        _browserMonitorService = browserMonitorService;
        _remoteScreenService = remoteScreenService;
        _taskQueue = taskQueue;
        _taskRegistry = taskRegistry;
        _updateService = updateService;
        _powerManager = powerManager;
        _errorRecovery = errorRecovery;
        _healthMonitor = healthMonitor;
        _watchdog = watchdog;
        _i18n = i18n;
        
        _retryPolicy = Policy
            .Handle<Exception>()
            .WaitAndRetryForeverAsync(
                retryAttempt => TimeSpan.FromSeconds(
                    Math.Min(Math.Pow(2, retryAttempt), 60)),
                (ex, delay) => Log.Warning(
                    $"连接失败: {ex.Message}，{delay.TotalSeconds:F1}秒后重试"));
    }
    
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        Log.Information("🚀 Agent后台服务启动");
        
        // 注册任务处理器
        RegisterTaskHandlers();
        
        // 注册健康监控组件
        RegisterHealthComponents();
        
        // 启动看门狗（仅监控，不立即启动服务）
        _watchdog.Watch("screenshot", () => { _screenshotService.Start(); return Task.CompletedTask; }, true);
        _watchdog.Watch("websocket", async () => { await _webSocketService.ConnectAsync(); }, true);
        
        // 等待配置存在
        while (!_configService.IsConfigured() && !stoppingToken.IsCancellationRequested)
        {
            Log.Information("等待首次配置...");
            await Task.Delay(1000, stoppingToken);
        }
        
        if (stoppingToken.IsCancellationRequested) return;
        
        // ========== 修改开始 ==========
        // 重要：先连接 WebSocket，确保截图时能够实时推送
        
        // 1. 先启动功耗管理和健康监控（不依赖网络）
        _powerManager.Start();
        _healthMonitor.Start();
        
        // 2. 连接 WebSocket（带重试）
        Log.Information("正在连接 WebSocket...");
        await _retryPolicy.ExecuteAsync(async () =>
        {
            await _webSocketService.ConnectAsync(stoppingToken);
        });
        Log.Information("✅ WebSocket 已连接，实时推送功能可用");
        
        // 3. 注册到服务器（带重试）
        await _retryPolicy.ExecuteAsync(async () =>
        {
            await RegisterClientAsync();
        });
        
        _isRegistered = true;
        
        // 4. WebSocket 连接成功后，再启动所有监控服务
        //    这样截图时 WebSocket 已经就绪，可以实时推送
        _heartbeatService.Start();
        _screenshotService.Start();      // 截图服务启动，会通过 WebSocket 实时推送
        _browserHistoryService.Start();
        _fileOperationService.Start();
        _appMonitorService.Start();
        _browserMonitorService.Start();
        _updateService.Start();
        
        // ========== 修改结束 ==========
        
        // 启动远程屏幕（如果配置了）
        var config = _configService.Load();
        if (config?.EnableRemoteScreen == true)
        {
            _remoteScreenService.Start();
        }
        
        // 启动任务消费者
        _ = Task.Run(() => ConsumeTasksAsync(stoppingToken), stoppingToken);
        
        // 等待停止信号
        try
        {
            await Task.Delay(Timeout.Infinite, stoppingToken);
        }
        catch (OperationCanceledException)
        {
            Log.Information("Agent服务正在停止...");
        }
        finally
        {
            StopAllServices();
        }
    }
    
    private void RegisterTaskHandlers()
    {
        _taskRegistry.Register<CaptureScreenshotTask>();
        _taskRegistry.Register<ExecuteCommandTask>();
        _taskRegistry.Register<GetSystemInfoTask>();
        _taskRegistry.Register<UpdateConfigTask>();
        
        Log.Information($"✅ 已注册 {_taskRegistry.GetSupportedCommands().Count()} 个任务处理器");
    }
    
    private void RegisterHealthComponents()
    {
        _healthMonitor.RegisterComponent(
            "network",
            () => { _ = _webSocketService.ReconnectAsync(); });

        _healthMonitor.RegisterComponent(
            "websocket",
            () => { _ = _webSocketService.ReconnectAsync(); });

        _healthMonitor.RegisterComponent(
            "screenshot",
            () => _screenshotService.Start());

        _healthMonitor.RegisterComponent(
            "heartbeat",
            () => { });

        // 初始化为健康状态
        _healthMonitor.UpdateStatus("network", HealthStatus.Healthy);
        _healthMonitor.UpdateStatus("websocket", HealthStatus.Healthy);
        _healthMonitor.UpdateStatus("screenshot", HealthStatus.Healthy);
        _healthMonitor.UpdateStatus("heartbeat", HealthStatus.Healthy);
    }
    
    private async Task RegisterClientAsync()
    {
        var config = _configService.Load();
        if (config == null) return;
        
        // 获取设备指纹
        var fingerprintService = new DeviceFingerprintService();
        var fingerprint = await fingerprintService.GetFingerprintAsync();
        
        // 注册
        var result = await _httpService.RegisterClientAsync(config.Name, fingerprint, config.ServerUrl);
        
        if (result.Success)
        {
            config.ClientId = result.ClientId;
            config.EmployeeId = result.EmployeeId;
            config.Token = result.Token;
            _configService.Save(config);
            
            Log.Information($"✅ 客户端注册成功: ClientId={result.ClientId}, EmployeeId={result.EmployeeId}");
            
            // 获取服务器配置
            var serverConfig = await _httpService.GetClientConfigAsync();
            config.ScreenshotInterval = serverConfig.Interval;
            config.ScreenshotQuality = serverConfig.Quality;
            config.ScreenshotFormat = serverConfig.Format;
            _configService.Save(config);
        }
        else
        {
            Log.Error($"❌ 客户端注册失败: {result.ErrorMessage}");
            throw new Exception($"注册失败: {result.ErrorMessage}");
        }
    }
    
    private async Task ConsumeTasksAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var task = await _taskQueue.DequeueAsync(stoppingToken);
                if (task == null) continue;
                
                // 幂等检查
                var stateManager = new TaskStateManager();
                if (await stateManager.IsTaskProcessedAsync(task.TaskId))
                {
                    Log.Debug($"任务 {task.TaskId} 已处理过，跳过");
                    continue;
                }
                
                var executor = new TaskExecutor(_taskRegistry);
                var result = await executor.ExecuteAsync(task);
                
                if (result.Success)
                {
                    await stateManager.MarkTaskProcessedAsync(task.TaskId);
                    Log.Information($"✅ 任务执行成功: {task.Command}");
                }
                else
                {
                    Log.Error($"❌ 任务执行失败: {task.Command} - {result.Error}");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "任务消费异常");
                await Task.Delay(1000, stoppingToken);
            }
        }
    }
    
    private void StopAllServices()
    {
        Log.Information("正在停止所有服务...");
        
        _remoteScreenService.Stop();
        _browserMonitorService.Stop();
        _appMonitorService.Stop();
        _fileOperationService.Stop();
        _browserHistoryService.Stop();
        _screenshotService.Stop();
        _heartbeatService.Stop();
        _updateService.Stop();
        _powerManager.Stop();
        _healthMonitor.Stop();
        
        _webSocketService.DisconnectAsync().Wait();
        
        Log.Information("✅ 所有服务已停止");
    }
}

// 其他后台服务（简化版）
public class HeartbeatBackgroundService : BackgroundService
{
    private readonly IHeartbeatService _heartbeatService;
    public HeartbeatBackgroundService(IHeartbeatService heartbeatService) => _heartbeatService = heartbeatService;
    protected override Task ExecuteAsync(CancellationToken stoppingToken) { _heartbeatService.Start(); return Task.CompletedTask; }
    public override async Task StopAsync(CancellationToken cancellationToken) { _heartbeatService.Stop(); await base.StopAsync(cancellationToken); }
}

public class ScreenshotBackgroundService : BackgroundService
{
    private readonly IScreenshotCaptureService _screenshotService;
    public ScreenshotBackgroundService(IScreenshotCaptureService screenshotService) => _screenshotService = screenshotService;
    protected override Task ExecuteAsync(CancellationToken stoppingToken) { _screenshotService.Start(); return Task.CompletedTask; }
    public override async Task StopAsync(CancellationToken cancellationToken) { _screenshotService.Stop(); await base.StopAsync(cancellationToken); }
}

public class BrowserHistoryBackgroundService : BackgroundService
{
    private readonly IBrowserHistoryService _browserHistoryService;
    public BrowserHistoryBackgroundService(IBrowserHistoryService browserHistoryService) => _browserHistoryService = browserHistoryService;
    protected override Task ExecuteAsync(CancellationToken stoppingToken) { _browserHistoryService.Start(); return Task.CompletedTask; }
    public override async Task StopAsync(CancellationToken cancellationToken) { _browserHistoryService.Stop(); await base.StopAsync(cancellationToken); }
}

public class FileOperationBackgroundService : BackgroundService
{
    private readonly IFileOperationService _fileOperationService;
    public FileOperationBackgroundService(IFileOperationService fileOperationService) => _fileOperationService = fileOperationService;
    protected override Task ExecuteAsync(CancellationToken stoppingToken) { _fileOperationService.Start(); return Task.CompletedTask; }
    public override async Task StopAsync(CancellationToken cancellationToken) { _fileOperationService.Stop(); await base.StopAsync(cancellationToken); }
}

public class TaskConsumerBackgroundService : BackgroundService
{
    private readonly ITaskQueue _taskQueue;
    private readonly ITaskRegistry _taskRegistry;
    
    public TaskConsumerBackgroundService(ITaskQueue taskQueue, ITaskRegistry taskRegistry)
    {
        _taskQueue = taskQueue;
        _taskRegistry = taskRegistry;
    }
    
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var stateManager = new TaskStateManager();
        var executor = new TaskExecutor(_taskRegistry);
        
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var task = await _taskQueue.DequeueAsync(stoppingToken);
                if (task == null) continue;
                
                if (await stateManager.IsTaskProcessedAsync(task.TaskId))
                {
                    Log.Debug($"任务 {task.TaskId} 已处理过，跳过");
                    continue;
                }
                
                var result = await executor.ExecuteAsync(task);
                
                if (result.Success)
                {
                    await stateManager.MarkTaskProcessedAsync(task.TaskId);
                }
                else
                {
                    Log.Error($"任务执行失败: {task.Command} - {result.Error}");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "任务消费异常");
                await Task.Delay(1000, stoppingToken);
            }
        }
    }
}
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace EnterpriseAgent;

// 截图任务
public class CaptureScreenshotTask : ITaskHandler
{
    public string Command => "capture_screenshot";
    
    public async Task<TaskResult> ExecuteAsync(TaskContext context)
    {
        try
        {
            // 触发立即截图
            // 实际应该通过事件触发
            return new TaskResult
            {
                Success = true,
                Data = new { message = "截图已触发" }
            };
        }
        catch (Exception ex)
        {
            return new TaskResult
            {
                Success = false,
                Error = ex.Message
            };
        }
    }
}

// 执行命令任务
public class ExecuteCommandTask : ITaskHandler
{
    public string Command => "execute_command";
    
    public async Task<TaskResult> ExecuteAsync(TaskContext context)
    {
        try
        {
            var command = context.Parameters.GetValueOrDefault("command")?.ToString();
            if (string.IsNullOrEmpty(command))
            {
                return new TaskResult { Success = false, Error = "命令不能为空" };
            }
            
            var timeout = Convert.ToInt32(context.Parameters.GetValueOrDefault("timeout", 30));
            var workingDir = context.Parameters.GetValueOrDefault("working_directory")?.ToString() ?? Environment.CurrentDirectory;
            
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(timeout));
            using var process = new Process();
            
            process.StartInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/c {command}",
                WorkingDirectory = workingDir,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            
            process.Start();
            
            var output = await process.StandardOutput.ReadToEndAsync();
            var error = await process.StandardError.ReadToEndAsync();
            
            await process.WaitForExitAsync(cts.Token);
            
            return new TaskResult
            {
                Success = process.ExitCode == 0,
                Data = new { output, error, exit_code = process.ExitCode }
            };
        }
        catch (OperationCanceledException)
        {
            return new TaskResult { Success = false, Error = "命令执行超时" };
        }
        catch (Exception ex)
        {
            return new TaskResult { Success = false, Error = ex.Message };
        }
    }
}

// 获取系统信息任务
public class GetSystemInfoTask : ITaskHandler
{
    public string Command => "get_system_info";
    
    public Task<TaskResult> ExecuteAsync(TaskContext context)
    {
        try
        {
            using var process = Process.GetCurrentProcess();
            
            var info = new
            {
                os_version = Environment.OSVersion.ToString(),
                machine_name = Environment.MachineName,
                processor_count = Environment.ProcessorCount,
                process_memory_mb = process.WorkingSet64 / (1024 * 1024),
                process_threads = process.Threads.Count,
                process_handles = process.HandleCount,
                uptime_seconds = (int)(DateTime.UtcNow - process.StartTime.ToUniversalTime()).TotalSeconds,
                framework_version = Environment.Version.ToString(),
                current_directory = Environment.CurrentDirectory,
                is_64bit = Environment.Is64BitOperatingSystem,
                system_page_size = Environment.SystemPageSize
            };
            
            return Task.FromResult(new TaskResult
            {
                Success = true,
                Data = info
            });
        }
        catch (Exception ex)
        {
            return Task.FromResult(new TaskResult
            {
                Success = false,
                Error = ex.Message
            });
        }
    }
}

// 更新配置任务
// 更新配置任务
public class UpdateConfigTask : ITaskHandler
{
    private IConfigurationService? _configService;
    
    public string Command => "update_config";
    
    // 添加无参构造函数（用于反射）
    public UpdateConfigTask() { }
    
    // 有参构造函数用于依赖注入
    public UpdateConfigTask(IConfigurationService configService)
    {
        _configService = configService;
    }
    
    public async Task<TaskResult> ExecuteAsync(TaskContext context)
    {
        try
        {
            // 如果没有注入，尝试通过服务定位器获取
            if (_configService == null)
            {
                // 在 BackgroundService 中注册时，UpdateConfigTask 应该通过构造函数注入
                return new TaskResult { Success = false, Error = "配置服务未初始化" };
            }
            
            var config = _configService.Load();
            if (config == null)
            {
                return new TaskResult { Success = false, Error = "配置未加载" };
            }
            
            if (context.Parameters.TryGetValue("screenshot_interval", out var interval))
                config.ScreenshotInterval = Convert.ToInt32(interval);
            
            if (context.Parameters.TryGetValue("screenshot_quality", out var quality))
                config.ScreenshotQuality = Convert.ToInt32(quality);
            
            if (context.Parameters.TryGetValue("screenshot_format", out var format))
                config.ScreenshotFormat = format.ToString() ?? "webp";
            
            _configService.Save(config);
            
            return new TaskResult
            {
                Success = true,
                Data = new { message = "配置已更新" }
            };
        }
        catch (Exception ex)
        {
            return new TaskResult
            {
                Success = false,
                Error = ex.Message
            };
        }
    }
}
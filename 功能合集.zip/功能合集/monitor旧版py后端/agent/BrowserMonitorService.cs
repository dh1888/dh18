// BrowserMonitorService.cs - 完整实现

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Channels;
using Microsoft.Extensions.Hosting;
using System.Windows.Forms;

namespace EnterpriseAgent;

public interface IBrowserMonitorService
{
    void Start();
    void Stop();
    BrowserMonitorStats GetStats();
    event EventHandler<BrowserTabData>? TabChanged;
}

public class BrowserTabData
{
    public string EmployeeId { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
        public string Browser { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public int TabId { get; set; }
    public bool IsActive { get; set; }
    public DateTime StartTime { get; set; }
    public int Duration { get; set; }
    public string ComputerName { get; set; } = string.Empty;
    public string WindowsUser { get; set; } = string.Empty;
}

public class BrowserMonitorStats
{
    public int TabsTracked { get; set; }
    public int TabsCompleted { get; set; }
    public int ActiveBrowsers { get; set; }
    public int UrlChanges { get; set; }
}

public class BrowserMonitorService : IBrowserMonitorService, IHostedService
{
    private readonly IConfigurationService _configService;
    private readonly IHttpClientService _httpService;
    private readonly IWebSocketService _webSocketService;
    private readonly ConcurrentDictionary<string, BrowserSession> _activeSessions = new();
    private readonly List<BrowserTabData> _completedTabs = new();
    private readonly object _lock = new();
    
    private System.Threading.Timer? _reportTimer;
    private System.Threading.Timer? _monitorTimer;
    private bool _isRunning;
    private BrowserMonitorStats _stats = new();
    
    private string? _currentBrowser;
    private string? _currentUrl;
    private string? _currentTitle;
    private DateTime _currentTabStart;
    private IntPtr _lastBrowserHwnd = IntPtr.Zero;

    // 浏览器进程识别
    private static readonly Dictionary<string, string> BrowserProcesses = new(StringComparer.OrdinalIgnoreCase)
    {
        ["chrome"] = "Chrome",
        ["msedge"] = "Edge",
        ["firefox"] = "Firefox",
        ["brave"] = "Brave",
        ["opera"] = "Opera",
        ["vivaldi"] = "Vivaldi",
        ["chromium"] = "Chromium",
        ["360chrome"] = "360极速浏览器",
        ["qqbrowser"] = "QQ浏览器",
        ["sogouexplorer"] = "搜狗浏览器"
    };

    // Chrome/Edge 调试端口（用于远程调试）
    private static readonly Dictionary<string, int> DebugPorts = new(StringComparer.OrdinalIgnoreCase)
    {
        ["chrome"] = 9222,
        ["msedge"] = 9222,
        ["brave"] = 9222,
        ["chromium"] = 9222
    };

    public event EventHandler<BrowserTabData>? TabChanged;

    public BrowserMonitorService(
        IConfigurationService configService,
        IHttpClientService httpService,
        IWebSocketService webSocketService)
    {
        _configService = configService;
        _httpService = httpService;
        _webSocketService = webSocketService;
    }

    public void Start()
    {
        if (_isRunning)
            return;

        _isRunning = true;

        // 修复：使用 MonitorLoopAsync 而不是 MonitorLoop
        _monitorTimer = new System.Threading.Timer(
            MonitorLoopAsync,
            null,
            0,
            1000);

        _reportTimer = new System.Threading.Timer(
            ReportLoop,
            null,
            30000,
            30000);

        Log.Information("✅ 浏览器监控服务已启动");
    }

    public void Stop()
    {
        _isRunning = false;

        _monitorTimer?.Dispose();
        _reportTimer?.Dispose();

        lock (_lock)
        {
            _completedTabs.Clear();
        }

        Log.Information("浏览器监控服务已停止");
    }

    public BrowserMonitorStats GetStats()
{
    return new BrowserMonitorStats
    {
        TabsTracked = _stats.TabsTracked,
        TabsCompleted = _stats.TabsCompleted,
        ActiveBrowsers = _activeSessions.Count,
        UrlChanges = _stats.UrlChanges
    };
}

    // 修改 StopAsync 方法

    private async void MonitorLoopAsync(object? state)
    {
        if (!_isRunning)
            return;

        try
        {
            var browserInfo = await GetActiveBrowser();
            var now = DateTime.UtcNow;

            if (browserInfo != null)
            {
                // 检测URL变化
                if (browserInfo.Url != _currentUrl ||
                    browserInfo.Title != _currentTitle)
                {
                    // 结束上一个会话
                    if (_currentBrowser != null &&
                        !string.IsNullOrEmpty(_currentUrl))
                    {
                        EndCurrentSession(now);
                    }

                    // 开始新会话
                    StartNewSession(browserInfo, now);

                    _stats.UrlChanges++;
                }
                else if (_currentBrowser != null &&
                         _currentUrl != null)
                {
                    // 更新当前会话时长
                    UpdateCurrentSession(now);
                }

                _lastBrowserHwnd = browserInfo.Hwnd;
            }
            else
            {
                // 没有活跃浏览器，结束当前会话
                if (_currentBrowser != null &&
                    !string.IsNullOrEmpty(_currentUrl))
                {
                    EndCurrentSession(now);

                    _currentBrowser = null;
                    _currentUrl = null;
                    _currentTitle = null;
                }
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "浏览器监控异常");
        }
    }

    private async Task<BrowserInfo?> GetActiveBrowser()
    {
        var hwnd = GetForegroundWindow();
        if (hwnd == IntPtr.Zero) return null;
        
        GetWindowThreadProcessId(hwnd, out var pid);
        if (pid == 0) return null;
        
        try
        {
            var process = Process.GetProcessById((int)pid);
            var processName = process.ProcessName.ToLower();
            
            // 识别浏览器
            string? browserName = null;
            foreach (var kv in BrowserProcesses)
            {
                if (processName.Contains(kv.Key) || processName == kv.Key)
                {
                    browserName = kv.Value;
                    break;
                }
            }
            
            if (browserName == null) return null;
            
            var windowTitle = GetWindowText(hwnd);
            if (string.IsNullOrEmpty(windowTitle)) return null;
            
            // 提取URL - 多种方法
            var url = await ExtractUrlFromBrowser(processName, hwnd, windowTitle);
            
            return new BrowserInfo
            {
                Hwnd = hwnd,
                Pid = (int)pid,
                Browser = browserName,
                ProcessName = processName,
                Title = windowTitle,
                Url = url
            };
        }
        catch
        {
            return null;
        }
    }

    private async Task<string> ExtractUrlFromBrowser(string processName, IntPtr hwnd, string windowTitle)
    {
        string url = "";
        
        // 方法1: 通过窗口标题解析URL
        url = ExtractUrlFromTitle(windowTitle);
        if (!string.IsNullOrEmpty(url)) return url;
        
        // 方法2: 通过Chrome/Edge调试协议获取URL
        if (DebugPorts.ContainsKey(processName))
        {
            url = await GetUrlViaDebugProtocol(processName);
            if (!string.IsNullOrEmpty(url)) return url;
        }
        
        // 方法3: 通过Windows Automation API (UIA) 获取地址栏
        url = GetUrlViaUIA(hwnd);
        if (!string.IsNullOrEmpty(url)) return url;
        
        // 方法4: 通过键盘快捷键复制URL (Ctrl+L 然后 Ctrl+C)
        url = await GetUrlViaClipboard(hwnd);
        
        return url ?? "";
    }

    private string ExtractUrlFromTitle(string title)
    {
        // 常见格式: "页面标题 - 浏览器名称"
        // 或 "页面标题 | 浏览器名称"
        var separators = new[] { " - ", " | ", " – ", " — " };
        
        foreach (var sep in separators)
        {
            var parts = title.Split(sep, StringSplitOptions.None);
            if (parts.Length >= 2)
            {
                var potentialUrl = parts[0];
                if (potentialUrl.StartsWith("http://") || potentialUrl.StartsWith("https://"))
                    return potentialUrl;
            }
        }
        
        // 直接在标题中查找URL
        var words = title.Split(' ');
        foreach (var word in words)
        {
            if (word.StartsWith("http://") || word.StartsWith("https://"))
                return word;
        }
        
        return string.Empty;
    }

    private async Task<string> GetUrlViaDebugProtocol(string processName)
    {
        try
        {
            var port = DebugPorts.GetValueOrDefault(processName, 9222);
            using var client = new HttpClient();
            client.Timeout = TimeSpan.FromSeconds(2);
            
            // 获取活动标签页列表
            var response = await client.GetAsync($"http://localhost:{port}/json/list");
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var tabs = JsonSerializer.Deserialize<List<ChromeTab>>(json);
                
                var activeTab = tabs?.FirstOrDefault(t => t.Type == "page" && t.Url != null);
                if (activeTab != null && !string.IsNullOrEmpty(activeTab.Url))
                {
                    return activeTab.Url;
                }
            }
        }
        catch (Exception ex)
        {
            Log.Debug(ex, "通过调试协议获取URL失败");
        }
        
        return string.Empty;
    }

    private string GetUrlViaUIA(IntPtr hwnd)
    {
        // 简化版：通过查找地址栏子窗口
        // 完整实现需要引用 UIAutomationClient
        
        try
        {
            // 查找地址栏控件（常见类名）
            var addressBarHwnd = FindWindowEx(hwnd, IntPtr.Zero, "Edit", null);
            if (addressBarHwnd == IntPtr.Zero)
                addressBarHwnd = FindWindowEx(hwnd, IntPtr.Zero, "Chrome_OmniboxView", null);
            if (addressBarHwnd == IntPtr.Zero)
                addressBarHwnd = FindWindowEx(hwnd, IntPtr.Zero, "Address Band Root", null);
            
            if (addressBarHwnd != IntPtr.Zero)
            {
                var text = GetWindowText(addressBarHwnd);
                if (text.StartsWith("http://") || text.StartsWith("https://"))
                    return text;
            }
        }
        catch (Exception ex)
        {
            Log.Debug(ex, "通过UIA获取URL失败");
        }
        
        return string.Empty;
    }

    private async Task<string> GetUrlViaClipboard(IntPtr hwnd)
    {
        try
        {
            // 保存当前剪贴板内容
            var previousText = Clipboard.GetText();
            
            // 激活窗口
            SetForegroundWindow(hwnd);
            await Task.Delay(100);
            
            // 模拟 Ctrl+L (选中地址栏)
            SendKeys.SendWait("^l");
            await Task.Delay(100);
            
            // 模拟 Ctrl+C (复制)
            SendKeys.SendWait("^c");
            await Task.Delay(100);
            
            // 获取剪贴板内容
            var url = Clipboard.GetText();
            
            // 恢复剪贴板
            if (!string.IsNullOrEmpty(previousText))
                Clipboard.SetText(previousText);
            
            if (url.StartsWith("http://") || url.StartsWith("https://"))
                return url;
        }
        catch (Exception ex)
        {
            Log.Debug(ex, "通过剪贴板获取URL失败");
        }
        
        return string.Empty;
    }

    private void StartNewSession(BrowserInfo browser, DateTime startTime)
    {
        _currentBrowser = browser.Browser;
        _currentUrl = browser.Url;
        _currentTitle = browser.Title;
        _currentTabStart = startTime;
        
        var sessionKey = $"{browser.Pid}_{browser.Url}";
        var session = new BrowserSession
        {
            Browser = browser.Browser,
            ProcessName = browser.ProcessName,
            Url = browser.Url,
            Title = browser.Title,
            StartTime = startTime,
            LastSeen = startTime
        };
        
        _activeSessions[sessionKey] = session;
        _stats.TabsTracked++;
        
        Log.Debug($"🌐 浏览器标签: {browser.Browser} - {browser.Title}");
        
        // 触发事件
        var tabData = CreateTabData(browser, startTime);
        TabChanged?.Invoke(this, tabData);
        
        // 通过WebSocket实时推送
        _ = Task.Run(async () =>
        {
            await _webSocketService.SendAsync(JsonSerializer.Serialize(new
            {
                type = "browser_tab",
                data = tabData,
                action = "opened"
            }));
        });
    }

    private void EndCurrentSession(DateTime endTime)
    {
        if (string.IsNullOrEmpty(_currentUrl)) return;
        
        var duration = (int)(endTime - _currentTabStart).TotalSeconds;
        
        if (duration >= 3) // 只记录超过3秒的访问
        {
            var config = _configService.Load();
            
            var tabData = new BrowserTabData
            {
                EmployeeId = config?.EmployeeId ?? "",
                ClientId = config?.ClientId ?? "",
                Browser = _currentBrowser ?? "",
                Title = _currentTitle ?? "",
                Url = _currentUrl ?? "",
                StartTime = _currentTabStart,
                Duration = duration,
                IsActive = true,
                ComputerName = Environment.MachineName,
                WindowsUser = Environment.UserName
            };
            
            lock (_lock)
            {
                _completedTabs.Add(tabData);
                _stats.TabsCompleted++;
            }
            
            Log.Debug($"📊 浏览器访问: {_currentUrl} ({duration}秒)");
        }
        
        // 更新会话结束时间
        var sessionKey = $"{_currentBrowser}_{_currentUrl}";
        if (_activeSessions.TryGetValue(sessionKey, out var session))
        {
            session.EndTime = endTime;
            session.Duration = duration;
        }
    }

    private void UpdateCurrentSession(DateTime now)
    {
        var sessionKey = $"{_currentBrowser}_{_currentUrl}";
        if (_activeSessions.TryGetValue(sessionKey, out var session))
        {
            session.LastSeen = now;
        }
    }

    private BrowserTabData CreateTabData(BrowserInfo browser, DateTime startTime)
    {
        var config = _configService.Load();
        
        return new BrowserTabData
        {
            EmployeeId = config?.EmployeeId ?? "",
            ClientId = config?.ClientId ?? "",
            Browser = browser.Browser,
            Title = browser.Title,
            Url = browser.Url,
            StartTime = startTime,
            IsActive = true,
            ComputerName = Environment.MachineName,
            WindowsUser = Environment.UserName
        };
    }

    private void ReportLoop(object? state)
    {
        if (!_isRunning) return;
        ReportData();
    }

    private void ReportData()
    {
        List<BrowserTabData> tabsToReport;
        lock (_lock)
        {
            if (_completedTabs.Count == 0) return;
            tabsToReport = _completedTabs.ToList();
            _completedTabs.Clear();
        }
        
        if (tabsToReport.Count == 0) return;
        
        Log.Information($"📤 上报浏览器数据: {tabsToReport.Count}条");
        
        _ = Task.Run(async () =>
        {
            try
            {
                await _httpService.UploadBrowserHistoryAsync(tabsToReport.Select(t => new BrowserHistoryData
                {
                    EmployeeId = t.EmployeeId,
                    ClientId = t.ClientId,
                    Url = t.Url,
                    Title = t.Title,
                    Browser = t.Browser,
                    Duration = t.Duration,
                    VisitTime = t.StartTime,
                    ComputerName = t.ComputerName,
                    WindowsUser = t.WindowsUser
                }).ToList());
            }
            catch (Exception ex)
            {
                Log.Error(ex, "上报浏览器数据失败");
                lock (_lock)
                    _completedTabs.AddRange(tabsToReport);
            }
        });
    }

    // 辅助类
    private class BrowserInfo
    {
        public IntPtr Hwnd { get; set; }
        public int Pid { get; set; }
        public string Browser { get; set; } = string.Empty;
        public string ProcessName { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;
    }

    private class BrowserSession
    {
        public string Browser { get; set; } = string.Empty;
        public string ProcessName { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public DateTime StartTime { get; set; }
        public DateTime LastSeen { get; set; }
        public DateTime? EndTime { get; set; }
        public int Duration { get; set; }
    }

    private class ChromeTab
    {
        public string Type { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
    }

    // P/Invoke
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    [DllImport("user32.dll")]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    [DllImport("user32.dll")]
    private static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string? lpszWindow);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    private static string GetWindowText(IntPtr hWnd)
    {
        const int nChars = 512;
        var sb = new StringBuilder(nChars);
        return GetWindowText(hWnd, sb, nChars) > 0 ? sb.ToString() : "";
    }

    public Task StartAsync(CancellationToken cancellationToken) { Start(); return Task.CompletedTask; }
    public Task StopAsync(CancellationToken cancellationToken) { Stop(); return Task.CompletedTask; }
}

// 需要在项目中添加的引用（Program.cs中已有）
// services.AddSingleton<IBrowserMonitorService, BrowserMonitorService>();
// services.AddHostedService<BrowserMonitorBackgroundService>();
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Threading.Tasks;

namespace EnterpriseAgent;

public partial class MainWindowViewModel : ObservableObject
{
    private readonly IConfigurationService _configService;
    private readonly IHttpClientService _httpService;
    private readonly IDeviceFingerprintService _fingerprintService;
    private readonly II18nService _i18nService;
    
    [ObservableProperty]
    private string _name = string.Empty;
    
    [ObservableProperty]
    private string _serverUrl = string.Empty;
    
    [ObservableProperty]
    private string _status = string.Empty;
    
    [ObservableProperty]
    private bool _isConnecting;
    
    [ObservableProperty]
    private bool _isStatusError;
    
    [ObservableProperty]
    private string _computerName = string.Empty;
    
    [ObservableProperty]
    private string _windowsUser = string.Empty;
    
    public MainWindowViewModel(
        IConfigurationService configService,
        IHttpClientService httpService,
        IDeviceFingerprintService fingerprintService,
        II18nService i18nService)
    {
        _configService = configService;
        _httpService = httpService;
        _fingerprintService = fingerprintService;
        _i18nService = i18nService;
        
        ComputerName = Environment.MachineName;
        WindowsUser = Environment.UserName;
        
        LoadConfig();
    }
    
    private void LoadConfig()
    {
        var config = _configService.Load();
        if (config != null)
        {
            Name = config.Name;
            ServerUrl = config.ServerUrl;
        }
    }
    
    [RelayCommand]
    private async Task ConnectAsync()
    {
        if (IsConnecting) return;
        
        if (string.IsNullOrWhiteSpace(Name))
        {
            Status = _i18nService.GetText("error_name_empty");
            IsStatusError = true;
            return;
        }
        
        if (string.IsNullOrWhiteSpace(ServerUrl))
        {
            Status = _i18nService.GetText("error_server_empty");
            IsStatusError = true;
            return;
        }
        
        IsConnecting = true;
        Status = _i18nService.GetText("getting_fingerprint");
        IsStatusError = false;
        
        try
        {
            var fingerprint = await _fingerprintService.GetFingerprintAsync();
            
            Status = _i18nService.GetText("registering");
            
            var result = await _httpService.RegisterClientAsync(Name, fingerprint, ServerUrl);
            
            if (result.Success)
            {
                var config = new AgentConfig
                {
                    Name = Name,
                    ServerUrl = ServerUrl,
                    ClientId = result.ClientId,
                    EmployeeId = result.EmployeeId,
                    Token = result.Token,
                    HardwareFingerprint = fingerprint.Hash,
                    ComputerName = ComputerName,
                    WindowsUser = WindowsUser,
                    RegisteredAt = DateTime.UtcNow
                };
                
                _configService.Save(config);
                
                Status = _i18nService.GetText("register_success");
                await Task.Delay(500);
                
                // 关闭窗口
                System.Windows.Application.Current.Windows[0]?.Close();
            }
            else
            {
                Status = result.ErrorMessage ?? _i18nService.GetText("register_failed");
                IsStatusError = true;
            }
        }
        catch (Exception ex)
        {
            Status = $"{_i18nService.GetText("connect_failed")}: {ex.Message}";
            IsStatusError = true;
        }
        finally
        {
            IsConnecting = false;
        }
    }
    
    [RelayCommand]
    private void Exit() => System.Windows.Application.Current.Shutdown();
}
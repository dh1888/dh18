using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Channels;

namespace EnterpriseAgent;

// 任务上下文
public class TaskContext
{
    public string TaskId { get; set; } = string.Empty;
    public string Command { get; set; } = string.Empty;
    public Dictionary<string, object> Parameters { get; set; } = new();
    public DateTime CreatedAt { get; set; }
    public int RetryCount { get; set; }
    public CancellationToken CancellationToken { get; set; }
}

// 任务结果
public class TaskResult
{
    public bool Success { get; set; }
    public string? Error { get; set; }
    public object? Data { get; set; }
    public TimeSpan Duration { get; set; }
}

// 任务处理器接口
public interface ITaskHandler
{
    string Command { get; }
    Task<TaskResult> ExecuteAsync(TaskContext context);
}

// 任务注册表
public interface ITaskRegistry
{
    void Register<T>() where T : ITaskHandler, new();
    ITaskHandler? GetHandler(string command);
    IEnumerable<string> GetSupportedCommands();
}

public class TaskRegistry : ITaskRegistry
{
    private readonly ConcurrentDictionary<string, ITaskHandler> _handlers = new();
    
    public void Register<T>() where T : ITaskHandler, new()
    {
        var handler = new T();
        _handlers.TryAdd(handler.Command, handler);
        Log.Information($"✅ 任务处理器已注册: {handler.Command}");
    }
    
    public ITaskHandler? GetHandler(string command)
    {
        _handlers.TryGetValue(command, out var handler);
        return handler;
    }
    
    public IEnumerable<string> GetSupportedCommands()
    {
        return _handlers.Keys;
    }
}

// 任务执行器
public interface ITaskExecutor
{
    Task<TaskResult> ExecuteAsync(TaskContext context);
}

public class TaskExecutor : ITaskExecutor
{
    private readonly ITaskRegistry _taskRegistry;
    
    public TaskExecutor(ITaskRegistry taskRegistry)
    {
        _taskRegistry = taskRegistry;
    }
    
    public async Task<TaskResult> ExecuteAsync(TaskContext context)
    {
        var handler = _taskRegistry.GetHandler(context.Command);
        if (handler == null)
        {
            return new TaskResult
            {
                Success = false,
                Error = $"未找到命令处理器: {context.Command}"
            };
        }
        
        try
        {
            return await handler.ExecuteAsync(context);
        }
        catch (Exception ex)
        {
            Log.Error(ex, $"任务执行失败: {context.Command}");
            return new TaskResult
            {
                Success = false,
                Error = ex.Message
            };
        }
    }
}

// 任务队列
public interface ITaskQueue
{
    ValueTask EnqueueAsync(TaskContext task, CancellationToken ct = default);
    ValueTask<TaskContext?> DequeueAsync(CancellationToken ct = default);
    int Count { get; }
}

public class TaskQueue : ITaskQueue
{
    private readonly Channel<TaskContext> _channel;
    
    public TaskQueue()
    {
        _channel = Channel.CreateUnbounded<TaskContext>(new UnboundedChannelOptions
        {
            SingleWriter = false,
            SingleReader = true
        });
    }
    
    public int Count => _channel.Reader.Count;
    
    public async ValueTask EnqueueAsync(TaskContext task, CancellationToken ct = default)
    {
        await _channel.Writer.WriteAsync(task, ct);
    }
    
    public async ValueTask<TaskContext?> DequeueAsync(CancellationToken ct = default)
    {
        if (await _channel.Reader.WaitToReadAsync(ct) && _channel.Reader.TryRead(out var task))
        {
            return task;
        }
        return null;
    }
}

// 任务状态管理
public interface ITaskStateManager
{
    Task SaveStateAsync(string taskId, TaskState state);
    Task<TaskState?> LoadStateAsync(string taskId);
    Task<bool> IsTaskProcessedAsync(string taskId);
    Task MarkTaskProcessedAsync(string taskId);
    Task ClearProcessedTasksAsync(TimeSpan olderThan);
}

public class TaskState
{
    public string TaskId { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime StartedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public object? Result { get; set; }
    public string? Error { get; set; }
}

public class TaskStateManager : ITaskStateManager
{
    private readonly ConcurrentDictionary<string, TaskState> _states = new();
    private readonly ConcurrentDictionary<string, DateTime> _processedTasks = new();
    
    public Task SaveStateAsync(string taskId, TaskState state)
    {
        _states[taskId] = state;
        return Task.CompletedTask;
    }
    
    public Task<TaskState?> LoadStateAsync(string taskId)
    {
        _states.TryGetValue(taskId, out var state);
        return Task.FromResult(state);
    }
    
    public Task<bool> IsTaskProcessedAsync(string taskId)
    {
        return Task.FromResult(_processedTasks.ContainsKey(taskId));
    }
    
    public Task MarkTaskProcessedAsync(string taskId)
    {
        _processedTasks.TryAdd(taskId, DateTime.UtcNow);
        return Task.CompletedTask;
    }
    
    public Task ClearProcessedTasksAsync(TimeSpan olderThan)
    {
        var cutoff = DateTime.UtcNow - olderThan;
        var toRemove = _processedTasks.Where(kv => kv.Value < cutoff).Select(kv => kv.Key).ToList();
        foreach (var key in toRemove)
        {
            _processedTasks.TryRemove(key, out _);
        }
        return Task.CompletedTask;
    }
}
using System;
using System.Security.Cryptography;
using System.Text;

namespace EnterpriseAgent;

public interface ISecurityService
{
    string ComputeHash(string input);
    string GenerateNonce();
    string GenerateSignature(string method, string path, string timestamp, string nonce, string body = "");
    bool VerifySignature(string signature, string method, string path, string timestamp, string nonce, string body = "");
    string EncryptString(string plainText);
    string DecryptString(string cipherText);
}

public class SecurityService : ISecurityService
{
    private readonly IConfigurationService _configService;
    private readonly byte[] _entropy;
    
    public SecurityService(IConfigurationService configService)
    {
        _configService = configService;
        _entropy = Encoding.UTF8.GetBytes("EnterpriseAgent_Security_2024");
    }
    
    public string ComputeHash(string input)
    {
        using var sha256 = SHA256.Create();
        var bytes = Encoding.UTF8.GetBytes(input);
        var hash = sha256.ComputeHash(bytes);
        return Convert.ToHexString(hash).ToLower();
    }
    
    public string GenerateNonce()
    {
        return Convert.ToBase64String(Guid.NewGuid().ToByteArray());
    }
    
    public string GenerateSignature(string method, string path, string timestamp, string nonce, string body = "")
    {
        var config = _configService.Load();
        var token = config?.Token ?? string.Empty;
        
        var bodyHash = ComputeHash(body);
        var stringToSign = $"{method}\n{path}\n{timestamp}\n{nonce}\n{bodyHash}\n{token}";
        return ComputeHash(stringToSign);
    }
    
    public bool VerifySignature(string signature, string method, string path, string timestamp, string nonce, string body = "")
    {
        var expected = GenerateSignature(method, path, timestamp, nonce, body);
        return string.Equals(signature, expected, StringComparison.OrdinalIgnoreCase);
    }
    
    public string EncryptString(string plainText)
    {
        if (string.IsNullOrEmpty(plainText))
            return plainText;
        
        try
        {
            var bytes = Encoding.UTF8.GetBytes(plainText);
            var encrypted = ProtectedData.Protect(bytes, _entropy, DataProtectionScope.CurrentUser);
            return Convert.ToBase64String(encrypted);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "加密失败");
            return plainText;
        }
    }
    
    public string DecryptString(string cipherText)
    {
        if (string.IsNullOrEmpty(cipherText))
            return cipherText;
        
        try
        {
            var bytes = Convert.FromBase64String(cipherText);
            var decrypted = ProtectedData.Unprotect(bytes, _entropy, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(decrypted);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "解密失败");
            return cipherText;
        }
    }
}
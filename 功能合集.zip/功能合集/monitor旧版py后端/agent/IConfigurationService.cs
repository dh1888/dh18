using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Win32;

namespace EnterpriseAgent;

public interface IConfigurationService
{
    AgentConfig? Load();
    void Save(AgentConfig config);
    bool IsConfigured();
    void Clear();
    T? Get<T>(string key, T? defaultValue = default);
    void Set<T>(string key, T value);
}

public class ConfigurationService : IConfigurationService
{
    private readonly string _configPath;
    private readonly string _settingsPath;
    private readonly byte[] _entropy;
    private AgentConfig? _cache;
    private readonly object _lock = new();
    
    public ConfigurationService()
    {
        var appData = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "MyMonitorAgent");
        Directory.CreateDirectory(appData);
        
        _configPath = Path.Combine(appData, "config.encrypted");
        _settingsPath = Path.Combine(appData, "settings.json");
        
        // 使用机器级密钥（DPAPI）
        _entropy = Encoding.UTF8.GetBytes("MyMonitorAgent_2024_Salt_Key");
    }
    
    public AgentConfig? Load()
    {
        lock (_lock)
        {
            if (_cache != null)
                return _cache;
            
            if (!File.Exists(_configPath))
                return null;
            
            try
            {
                var encrypted = File.ReadAllBytes(_configPath);
                var decrypted = ProtectedData.Unprotect(encrypted, _entropy, DataProtectionScope.CurrentUser);
                var json = Encoding.UTF8.GetString(decrypted);
                _cache = JsonSerializer.Deserialize<AgentConfig>(json);
                return _cache;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "加载配置失败");
                return null;
            }
        }
    }
    
    public void Save(AgentConfig config)
    {
        lock (_lock)
        {
            try
            {
                var json = JsonSerializer.Serialize(config);
                var bytes = Encoding.UTF8.GetBytes(json);
                var encrypted = ProtectedData.Protect(bytes, _entropy, DataProtectionScope.CurrentUser);
                File.WriteAllBytes(_configPath, encrypted);
                _cache = config;
                
                Log.Information($"配置已保存: ClientId={config.ClientId}, EmployeeId={config.EmployeeId}");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "保存配置失败");
                throw;
            }
        }
    }
    
    public bool IsConfigured()
    {
        var config = Load();
        return config != null && 
               !string.IsNullOrEmpty(config.ClientId) && 
               !string.IsNullOrEmpty(config.EmployeeId)&& 
               !string.IsNullOrEmpty(config.ServerUrl);
    }
    
    public void Clear()
    {
        lock (_lock)
        {
            if (File.Exists(_configPath))
                File.Delete(_configPath);
            _cache = null;
        }
    }
    
    public T? Get<T>(string key, T? defaultValue = default)
    {
        var config = Load();
        if (config == null) return defaultValue;
        
        var property = typeof(AgentConfig).GetProperty(key);
        if (property != null && property.CanRead)
        {
            var value = property.GetValue(config);
            return value is T t ? t : defaultValue;
        }
        
        return defaultValue;
    }
    
    public void Set<T>(string key, T value)
    {
        var config = Load();
        if (config == null) return;
        
        var property = typeof(AgentConfig).GetProperty(key);
        if (property != null && property.CanWrite)
        {
            property.SetValue(config, value);
            Save(config);
        }
    }
}
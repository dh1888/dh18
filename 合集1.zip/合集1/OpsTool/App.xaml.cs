using System.IO;
using System.Windows;
using DHPG.Common;
using DHPG.Data;
using DHPG.Services;
using DHPG.Views;
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace DHPG;

public partial class App : Application
{
    public const string AppName = "DHPG 运维工具";
    public static string AppDataDir { get; private set; } = string.Empty;
    public static string DbPath { get; private set; } = string.Empty;
    public static string LogDir { get; private set; } = string.Empty;
    public static IDbContextFactory<AppDbContext> DbContextFactory { get; private set; } = null!;

    private void Application_Startup(object sender, StartupEventArgs e)
    {
        AppDataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DHPG");
        DbPath = Path.Combine(AppDataDir, "dhpg.db");
        LogDir = Path.Combine(AppDataDir, "logs");

        Directory.CreateDirectory(AppDataDir);
        Directory.CreateDirectory(LogDir);

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.File(
                Path.Combine(LogDir, "dhpg-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 14)
            .CreateLogger();

        Log.Information("{AppName} 启动", AppName);

        try
        {
            AppDbContext.Initialize(DbPath);
            DbContextFactory = new AppDbContextFactory(DbPath);
            Log.Information("数据库初始化完成: {DbPath}", DbPath);

            new ActivityService(DbContextFactory).EnsureBuiltInActivitiesAsync().GetAwaiter().GetResult();

            try
            {
                var settings = new SettingService(DbContextFactory).GetAsync().GetAwaiter().GetResult();
                ThemeManager.Apply(settings.Theme);
            }
            catch (Exception ex)
            {
                Log.Warning(ex, "加载主题失败，使用浅色主题");
                ThemeManager.Apply("Light");
            }
        }
        catch (Exception ex)
        {
            Log.Error(ex, "数据库初始化失败");
            MessageBox.Show($"数据库初始化失败：{ex.Message}", AppName, MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
            return;
        }

        try
        {
            LocalApiHost.Instance.StartAsync().GetAwaiter().GetResult();
            Log.Information("本地 API 已启动: {BaseUrl}", LocalApiHost.Instance.BaseUrl);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "本地 API 启动失败");
            MessageBox.Show(
                $"本地批量页服务启动失败：{ex.Message}\n\n请检查端口占用或重启应用。",
                AppName,
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }

        var mainWindow = new MainWindow();
        mainWindow.Show();

        _ = Task.Run(async () =>
        {
            try
            {
                var processService = new ProcessService(DbContextFactory, new ExcelService());
                var deleted = await processService.CleanupExpiredResultCachesAsync();
                if (deleted > 0)
                    Log.Information("已清理过期结果缓存 {Count} 个", deleted);
            }
            catch (Exception ex)
            {
                Log.Warning(ex, "清理过期结果缓存失败");
            }
        });
    }
    protected override async void OnExit(ExitEventArgs e)
    {
        try
        {
            await LocalApiHost.Instance.DisposeAsync();
        }
        catch (Exception ex)
        {
            Log.Warning(ex, "停止本地 API 失败");
        }

        Log.Information("{AppName} 退出", AppName);
        Log.CloseAndFlush();
        base.OnExit(e);
    }
}

# 生产环境 env 文件说明

主域名：`https://dhpg.lk8.uk`（服务器 `43.106.86.216`，部署目录 `/www/wwwroot/agent/backend`）。

## 文件分工

| 文件 | 是否含真实密钥 | Git | 用途 |
|------|----------------|-----|------|
| `docs/backend后端env服务器配置.txt` | 否（`CHANGE_ME_*`） | 可提交 | **完整**生产 `.env` 占位模板（推荐对照用） |
| `docs/backend.env.production` | 否 | 已 ignore | 同上精简备份；可复制到服务器后填密 |
| `docs/backend后端env.local.txt` | **是** | 已 ignore | 本机/现网完整备份，可直接覆盖服务器 `.env` |
| `docs/backend后端env.secrets.txt` | **是** | 已 ignore | 仅密钥速查 |
| `backend/.env.example` | 否 | 可提交 | 通用开发/生产变量说明 |
| `agent/deployment.production.json` | 否 | 可提交 | 客户端生产 `serverUrl` / `wsTicketRequired` 参考 |
| `agent/deployment.json` | 可能含公钥 | 已 ignore | 打包用真实配置 |

## 覆盖服务器 `.env` 后必做

1. **Postgres**：`DB_PASSWORD` 与库用户密码一致（宝塔常见 `/www/server/pgsql/bin/psql`）
2. **Redis 6379**：`REDIS_PASSWORD` 与 `/www/server/redis/redis.conf` 的 `requirepass` 一致后重启 Redis  
   （LiveKit 自带 Redis 在 **6380**，与业务 Redis 无关）
3. **LiveKit**：`LIVEKIT_API_SECRET` = `livekit.yaml` 的 `keys.enterprise` = `docker-compose.yml` 的 `api_secret`  
   然后 `cd /www/wwwroot/livekit && docker compose up -d`
4. **Supervisor** 重启 `agent-backend`（改 `.env` 不重启不生效）
5. 验证：`curl -sS http://127.0.0.1:8080/health`

## 客户端打包相关

- 在**项目根目录**执行：`powershell -ExecutionPolicy Bypass -File scripts/publish-client.ps1`
- `agent/deployment.json` 使用字段 **`wsTicketRequired`**（不要写 `cookieRequired`）
- `policyPublicKeys` / `updatePublicKeys` 必须是**两把独立密钥**；键名分别对应 `POLICY_SIGNING_KEY_ID` / `UPDATE_SIGNING_KEY_ID`（现网常用 `2026-07`）
- 更新私钥：`signing-keys/update-ed25519.pem`（打包机），生成：`cd backend; go run ./cmd/genpolicykeys -purpose=update`
- **禁止**把 `update-ed25519.pem` 复制到服务器或 `backend/secrets/`
- `serverUrl`：`https://dhpg.lk8.uk`
- 当前 `DEVICE_REGISTRATION_SECRET_ENABLED=false` 时，`registrationSecret` 可留空
- 上传到 `CLIENT_DOWNLOAD_DIR`：**Setup.exe + MonitorAgent-update.zip + MonitorAgent-update.zip.ed25519.json**
- 可选覆盖：`CLIENT_UPDATE_SIGNATURE` / `CLIENT_UPDATE_SIGNING_KEY_ID`（签名不放 downloads 目录时）

## 完整性核对（必填生效项）

保存后服务器 `.env` 至少应包含：

```text
DB_HOST / DB_PORT / DB_USER / DB_PASSWORD / DB_NAME / DB_SSLMODE
JWT_SECRET
POLICY_SIGNING_KEY_ID / POLICY_SIGNING_PRIVATE_KEY_PATH
DEVICE_REGISTRATION_SECRET_ENABLED / DEVICE_REQUIRE_MANUAL_APPROVAL
PORT / ENV
CORS_ALLOWED_ORIGINS
CLIENT_DOWNLOAD_DIR / CLIENT_DOWNLOAD_FILE / CLIENT_UPDATE_FILE / CLIENT_VERSION
ADMIN_USERNAME / ADMIN_PASSWORD
REDIS_ADDR / REDIS_PASSWORD / REDIS_DB
UPLOADS_DIR / UPLOAD_SHARED_STORAGE
LIVEKIT_URL / LIVEKIT_API_HOST / LIVEKIT_API_KEY / LIVEKIT_API_SECRET
LIVEKIT_WHIP_BASE_URL / LIVEKIT_RTMP_BASE_URL / REMOTE_VIEW_PUBLISH_PROTOCOL
WS_TICKET_REQUIRED / WS_TICKET_TTL_SECONDS
TOTP_ENCRYPTION_KEY
DM_SECRET_KEY（若开启域名监控）
```

另确认 downloads 目录含更新包 sidecar：`MonitorAgent-update.zip.ed25519.json`（或 env 提供 `CLIENT_UPDATE_SIGNATURE`）。

缺 `DB_PASSWORD` 时后端会直接 `FATAL` 起不来。

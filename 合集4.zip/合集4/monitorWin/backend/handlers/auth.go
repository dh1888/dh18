package handlers

import (
	"context"
	"database/sql"
	"errors"
	"log"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
	"golang.org/x/crypto/bcrypt"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type AuthHandler struct {
	db       *sql.DB
	redis    *redis.Client
	sessions *services.SessionService
	wsHub    *services.WebSocketHub
	settings *services.SystemSettingsService
	users    *services.UserRepository
	captcha  *services.CaptchaService
	totp     *services.TOTPAuthService
}

func NewAuthHandler(
	db *sql.DB,
	redis *redis.Client,
	sessions *services.SessionService,
	wsHub *services.WebSocketHub,
	settings *services.SystemSettingsService,
	users *services.UserRepository,
) *AuthHandler {
	return &AuthHandler{
		db:       db,
		redis:    redis,
		sessions: sessions,
		wsHub:    wsHub,
		settings: settings,
		users:    users,
		captcha:  services.NewCaptchaService(redis),
		totp:     services.NewTOTPAuthService(redis),
	}
}

func (h *AuthHandler) GetLoginConfig(c *gin.Context) {
	cfg := &models.LoginConfig{CaptchaEnabled: true, TotpEnabled: false}
	if h.settings != nil {
		authCfg, err := h.settings.GetAuthSecurityConfig(c.Request.Context())
		if err == nil && authCfg != nil {
			cfg.CaptchaEnabled = authCfg.LoginCaptchaEnabled
			cfg.TotpEnabled = authCfg.LoginTotpEnabled
		}
	}
	models.Send(c, 200, 0, "success", cfg)
}

func (h *AuthHandler) GetCaptcha(c *gin.Context) {
	if h.captcha == nil {
		models.SendError(c, 503, 5003, "Captcha service unavailable")
		return
	}
	id, imageBase64, err := h.captcha.Issue(c.Request.Context())
	if err != nil {
		models.SendError(c, 503, 5003, "Failed to generate captcha")
		return
	}
	models.Send(c, 200, 0, "success", models.CaptchaResponse{
		CaptchaID:   id,
		ImageBase64: imageBase64,
	})
}

func (h *AuthHandler) Login(c *gin.Context) {
	var req models.LoginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if h.db == nil || h.sessions == nil || h.redis == nil || h.users == nil {
		models.SendError(c, 500, 5000, "Auth service unavailable")
		return
	}

	ctx := c.Request.Context()
	authCfg, _ := h.settings.GetAuthSecurityConfig(ctx)
	captchaEnabled := authCfg == nil || authCfg.LoginCaptchaEnabled
	totpEnabled := authCfg != nil && authCfg.LoginTotpEnabled

	challengeID := strings.TrimSpace(req.LoginChallenge)
	totpCode := strings.TrimSpace(req.TotpCode)

	if challengeID != "" {
		if totpCode == "" {
			models.SendError(c, 400, 1001, "Google Authenticator code is required")
			return
		}
		h.handleLoginChallengeStep(c, challengeID, totpCode)
		return
	}

	if strings.TrimSpace(req.Username) == "" || req.Password == "" {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	if captchaEnabled {
		if !h.captcha.Verify(ctx, req.CaptchaID, req.CaptchaCode) {
			models.SendError(c, 400, 1001, "Invalid or expired captcha")
			return
		}
	}

	username := strings.TrimSpace(req.Username)
	loginUser, err := h.users.GetLoginUserByUsername(ctx, username)
	if err != nil || loginUser.Status != 1 {
		models.SendError(c, 401, 1002, "Invalid credentials")
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(loginUser.PasswordHash), []byte(req.Password)) != nil {
		models.SendError(c, 401, 1002, "Invalid credentials")
		return
	}

	if !totpEnabled {
		h.completeLogin(c, loginUser.ID, loginUser.Username)
		return
	}

	if loginUser.TotpEnabled && loginUser.TotpSecretEnc != "" {
		challenge, err := h.totp.CreateChallenge(ctx, services.LoginChallengePayload{
			UserID:   loginUser.ID.String(),
			Username: loginUser.Username,
			Purpose:  services.LoginChallengeVerify,
		})
		if err != nil {
			models.SendInternalError(c, err)
			return
		}
		models.Send(c, 200, 0, "totp_required", models.LoginResponse{
			RequiresTotp:   true,
			LoginChallenge: challenge,
		})
		return
	}

	key, err := services.GenerateTotpKey(loginUser.Username)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	challenge, err := h.totp.CreateChallenge(ctx, services.LoginChallengePayload{
		UserID:            loginUser.ID.String(),
		Username:          loginUser.Username,
		Purpose:           services.LoginChallengeSetup,
		PendingTotpSecret: key.Secret(),
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "totp_setup_required", models.LoginResponse{
		RequiresTotpSetup:   true,
		LoginChallenge:    challenge,
		TotpProvisioningURI: key.URL(),
	})
}

func (h *AuthHandler) handleLoginChallengeStep(c *gin.Context, challengeID, totpCode string) {
	ctx := c.Request.Context()
	payload, err := h.totp.LoadChallenge(ctx, challengeID)
	if err != nil {
		models.SendError(c, 401, 1002, "Login challenge expired, please sign in again")
		return
	}

	userID, err := uuid.Parse(payload.UserID)
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid login challenge")
		return
	}

	var loginOK bool
	switch payload.Purpose {
	case services.LoginChallengeVerify:
		loginUser, err := h.users.GetLoginUserByUsername(ctx, payload.Username)
		if err != nil || loginUser.ID != userID || !loginUser.TotpEnabled {
			models.SendError(c, 401, 1002, "Invalid credentials")
			return
		}
		secret, err := services.DecryptTotpSecret(loginUser.TotpSecretEnc)
		if err != nil || !services.ValidateTotpCode(secret, totpCode) {
			models.SendError(c, 401, 1002, "Invalid Google Authenticator code")
			return
		}
		loginOK = true
	case services.LoginChallengeSetup:
		if !services.ValidateTotpCode(payload.PendingTotpSecret, totpCode) {
			models.SendError(c, 401, 1002, "Invalid Google Authenticator code")
			return
		}
		enc, err := services.EncryptTotpSecret(payload.PendingTotpSecret)
		if err != nil {
			models.SendInternalError(c, err)
			return
		}
		if err := h.users.EnableUserTOTP(ctx, userID, enc); err != nil {
			models.SendInternalError(c, err)
			return
		}
		loginOK = true
	default:
		models.SendError(c, 401, 1002, "Invalid login challenge")
		return
	}

	if loginOK {
		_ = h.totp.DeleteChallenge(ctx, challengeID)
		h.completeLogin(c, userID, payload.Username)
	}
}

func (h *AuthHandler) completeLogin(c *gin.Context, userID uuid.UUID, username string) {
	ctx := c.Request.Context()
	_, _ = h.db.ExecContext(ctx, `UPDATE users SET last_login_at = $1 WHERE id = $2`, models.UTCNow(), userID)

	role, perms := h.loadUserAuth(ctx, userID.String())
	userInfo := &models.AuthUserInfo{
		ID: userID.String(), Username: username, Role: role, Permissions: perms,
	}

	expiresAt := models.UTCNow().Add(services.UserAccessTokenTTL())
	sessionExpires := models.UTCNow().Add(services.RefreshTokenTTL())
	clientIP := services.ClientIPFromContext(c.GetHeader("X-Forwarded-For"), c.ClientIP())

	sess, err := h.sessions.CreateSession(ctx, services.SessionSubjectUser, userID, sessionExpires, clientIP, c.GetHeader("User-Agent"))
	if err != nil {
		models.SendInternalError(c, err)
		return
	}

	tokenString, err := services.SignSessionJWT(sess.ID.String(), expiresAt)
	if err != nil {
		models.SendError(c, 500, 5000, "Token generation failed")
		return
	}

	refreshToken := uuid.NewString()
	if err := h.bindRefresh(ctx, refreshToken, sess.ID.String(), services.SessionSubjectUser, userID.String()); err != nil {
		models.SendInternalError(c, err)
		return
	}

	log.Printf("Login success: username=%s session_id=%s", username, sess.ID)
	models.Send(c, 200, 0, "success", models.LoginResponse{
		Token: tokenString, RefreshToken: refreshToken, ExpiresAt: models.FormatUTC(expiresAt), User: userInfo,
	})
}

func (h *AuthHandler) Refresh(c *gin.Context) {
	var req struct {
		RefreshToken string `json:"refreshToken"`
	}
	if err := c.ShouldBindJSON(&req); err != nil || strings.TrimSpace(req.RefreshToken) == "" {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if h.sessions == nil || h.redis == nil {
		models.SendError(c, 500, 5000, "Auth service unavailable")
		return
	}

	ctx := c.Request.Context()
	sessionID, err := h.sessions.LookupSessionByRefresh(ctx, strings.TrimSpace(req.RefreshToken))
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid refresh token")
		return
	}

	sess, err := h.sessions.ValidateActiveSession(ctx, sessionID)
	if err != nil || sess.SubjectType != services.SessionSubjectUser {
		models.SendError(c, 401, 1002, "Session has been revoked")
		return
	}

	userID := sess.SubjectID.String()
	role, perms := h.loadUserAuth(ctx, userID)
	username := h.getUsernameByID(ctx, userID)

	expiresAt := models.UTCNow().Add(services.UserAccessTokenTTL())
	tokenString, err := services.SignSessionJWT(sessionID, expiresAt)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}

	newRefresh := uuid.NewString()
	h.sessions.DeleteRefreshBinding(ctx, req.RefreshToken)
	if err := h.bindRefresh(ctx, newRefresh, sessionID, services.SessionSubjectUser, userID); err != nil {
		models.SendInternalError(c, err)
		return
	}

	models.Send(c, 200, 0, "success", models.LoginResponse{
		Token: tokenString, RefreshToken: newRefresh, ExpiresAt: models.FormatUTC(expiresAt),
		User: &models.AuthUserInfo{ID: userID, Username: username, Role: role, Permissions: perms},
	})
}

func (h *AuthHandler) Logout(c *gin.Context) {
	var body struct {
		RefreshToken string `json:"refreshToken"`
	}
	_ = c.ShouldBindJSON(&body)

	tokenString := strings.TrimSpace(strings.TrimPrefix(c.GetHeader("Authorization"), "Bearer "))
	if tokenString == "" {
		models.SendError(c, 400, 1001, "Invalid authorization header")
		return
	}

	sid, err := services.ParseSessionJWT(tokenString)
	if err != nil && !errors.Is(err, jwt.ErrTokenExpired) {
		models.SendError(c, 401, 1002, "Invalid token")
		return
	}

	ctx := c.Request.Context()
	if sid != "" && h.sessions != nil {
		_ = h.sessions.RevokeSession(ctx, sid, "user_logout")
		if h.wsHub != nil {
			h.wsHub.DisconnectAdminsBySession(sid, "user_logout")
		}
	}
	if rt := strings.TrimSpace(body.RefreshToken); rt != "" && h.sessions != nil {
		h.sessions.DeleteRefreshBinding(ctx, rt)
	}
	models.Send(c, 200, 0, "Logged out", nil)
}

func (h *AuthHandler) bindRefresh(ctx context.Context, refreshToken, sessionID, subjectType, subjectID string) error {
	if err := h.sessions.BindRefreshToken(ctx, refreshToken, sessionID, services.RefreshTokenTTL()); err != nil {
		return err
	}
	return services.IndexSessionRefreshToken(ctx, h.redis, subjectType, subjectID, refreshToken, services.RefreshTokenTTL())
}

func (h *AuthHandler) loadUserAuth(ctx context.Context, userID string) (role string, perms []string) {
	roleName := h.getUserRole(ctx, userID)
	perms, err := h.getUserPermissions(ctx, userID)
	if err != nil {
		perms = []string{}
	}
	return normalizeRoleName(roleName), perms
}

func normalizeRoleName(roleName string) string {
	switch strings.TrimSpace(strings.ToLower(roleName)) {
	case "管理员", "admin", "administrator", "超级管理员", "superadmin":
		return "admin"
	case "审计员", "auditor":
		return "auditor"
	case "操作员", "operator", "ops":
		return "operator"
	case "查看员", "viewer":
		return "viewer"
	case "员工", "employee":
		return "employee"
	default:
		return "auditor"
	}
}

func (h *AuthHandler) getUserRole(ctx context.Context, userID string) string {
	if h.db == nil {
		return "auditor"
	}
	var roleName string
	err := h.db.QueryRowContext(ctx,
		`SELECT COALESCE(r.name, 'auditor') FROM user_roles ur JOIN roles r ON ur.role_id = r.id WHERE ur.user_id = $1 LIMIT 1`,
		userID,
	).Scan(&roleName)
	if err != nil {
		return "auditor"
	}
	return roleName
}

func (h *AuthHandler) getUsernameByID(ctx context.Context, userID string) string {
	if h.db == nil {
		return ""
	}
	var username string
	_ = h.db.QueryRowContext(ctx, `SELECT username FROM users WHERE id = $1`, userID).Scan(&username)
	return username
}

func (h *AuthHandler) getUserPermissions(ctx context.Context, userID string) ([]string, error) {
	if h.db == nil {
		return []string{}, nil
	}
	rows, err := h.db.QueryContext(ctx, `
		SELECT DISTINCT jsonb_array_elements_text(r.permissions)
		FROM user_roles ur JOIN roles r ON ur.role_id = r.id WHERE ur.user_id = $1`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	set := map[string]struct{}{}
	for rows.Next() {
		var p string
		if rows.Scan(&p) == nil {
			set[p] = struct{}{}
		}
	}
	out := make([]string, 0, len(set))
	for p := range set {
		out = append(out, p)
	}
	return out, nil
}

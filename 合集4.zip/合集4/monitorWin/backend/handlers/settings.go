package handlers

import (
	"net/url"
	"strings"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type SettingsHandler struct {
	settings *services.SystemSettingsService
}

func NewSettingsHandler(settings *services.SystemSettingsService) *SettingsHandler {
	return &SettingsHandler{settings: settings}
}

func (h *SettingsHandler) GetCorsOrigins(c *gin.Context) {
	cfg, err := h.settings.GetCorsOriginsConfig(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", cfg)
}

func (h *SettingsHandler) UpdateCorsOrigins(c *gin.Context) {
	var req struct {
		Origins []string `json:"origins"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	clean := make([]string, 0, len(req.Origins))
	seen := make(map[string]struct{})
	for _, origin := range req.Origins {
		o := strings.TrimSpace(origin)
		if o == "" {
			continue
		}
		u, err := url.Parse(o)
		if err != nil || u.Scheme == "" || u.Host == "" {
			models.SendError(c, 400, 1001, "Invalid origin: "+o)
			return
		}
		if u.Scheme != "http" && u.Scheme != "https" {
			models.SendError(c, 400, 1001, "Origin scheme must be http or https: "+o)
			return
		}
		normalized := strings.TrimRight(o, "/")
		key := strings.ToLower(normalized)
		if _, ok := seen[key]; ok {
			continue
		}
		seen[key] = struct{}{}
		clean = append(clean, normalized)
	}

	cfg, err := h.settings.SaveCorsOrigins(c.Request.Context(), clean)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	Log(c, "UPDATE", "SYSTEM", "更新 CORS / WebSocket Origin 白名单", "", strings.Join(clean, ","))
	models.Send(c, 200, 0, "CORS origins updated", cfg)
}

func (h *SettingsHandler) UpdateAuthSecurity(c *gin.Context) {
	var req struct {
		LoginCaptchaEnabled bool `json:"loginCaptchaEnabled"`
		LoginTotpEnabled    bool `json:"loginTotpEnabled"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	cfg, err := h.settings.SaveAuthSecurityConfig(c.Request.Context(), req.LoginCaptchaEnabled, req.LoginTotpEnabled)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "SYSTEM", "更新登录安全策略（验证码/谷歌验证）", "", "")
	models.Send(c, 200, 0, "Auth security updated", cfg)
}

func (h *SettingsHandler) GetAuthSecurity(c *gin.Context) {
	cfg, err := h.settings.GetAuthSecurityConfig(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", cfg)
}

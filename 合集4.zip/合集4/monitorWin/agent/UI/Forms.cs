// UI/Forms.cs - UI 表单合并（EmployeeSetupForm 和 StatusForm）支持多语言

using System.Drawing;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Models;
using AppConstants = EnterpriseAgent.Agent.Models.Constants;
using EnterpriseAgent.Agent.Services;
using Microsoft.Extensions.Logging;
using DrawingImage = System.Drawing.Image;
using DrawingSize = System.Drawing.Size;
using DrawingColor = System.Drawing.Color;
using DrawingPoint = System.Drawing.Point;
using DrawingPointF = System.Drawing.PointF;

namespace EnterpriseAgent.Agent.UI;

public enum EmployeeSetupFormMode
{
    /// <summary>首次登录：服务器 + 邀请码 + 账号密码</summary>
    FirstLogin,
    /// <summary>托盘补绑：仅邀请码 / 共享工位</summary>
    InviteBinding
}

#region EmployeeSetupForm

public class EmployeeSetupForm : Form
{
    private TextBox txtUsername = null!;
    private TextBox txtPassword = null!;
    private TextBox txtInviteCode = null!;
    private TextBox txtServerUrl = null!;
    private Button btnSave = null!;
    private Button btnShared = null!;
    private Button btnCancel = null!;
    private Label lblTitle = null!;
    private Label lblInvite = null!;
    private Label lblUsername = null!;
    private Label lblPassword = null!;
    private Label lblServerUrl = null!;
    private Label lblHint = null!;
    private PictureBox pictLogo = null!;

    private readonly ILogger<EmployeeSetupForm>? _logger;
    private readonly ILocalizationService? _localization;
    private readonly string? _lockedServerUrl;
    private readonly EmployeeSetupFormMode _mode;

    public EmployeeInfo? EmployeeInfo { get; private set; }
    public string ServerUrl { get; private set; } = string.Empty;
    public bool UseSharedWorkstation { get; private set; }
    public string InviteCode => txtInviteCode.Text.Trim();
    public string Username => txtUsername.Text.Trim();
    public string Password => txtPassword.Text;

    public EmployeeSetupForm(
        ILogger<EmployeeSetupForm>? logger = null,
        ILocalizationService? localization = null,
        string? serverUrl = null,
        string? lockedServerUrl = null,
        EmployeeSetupFormMode mode = EmployeeSetupFormMode.FirstLogin)
    {
        _logger = logger;
        _localization = localization;
        _mode = mode;
        _lockedServerUrl = string.IsNullOrWhiteSpace(lockedServerUrl) ? null : lockedServerUrl.Trim();

        InitializeComponent();
        ConfigureForMode();
        ApplyLocalization();
        ConfigureServerUrlField(serverUrl);
        CenterToScreen();
    }

    public EmployeeSetupForm(ILogger<EmployeeSetupForm>? logger = null, ILocalizationService? localization = null, string? serverUrl = null)
        : this(logger, localization, serverUrl, lockedServerUrl: null, mode: EmployeeSetupFormMode.FirstLogin)
    {
    }

    private void ConfigureServerUrlField(string? serverUrl)
    {
        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            ServerUrl = _lockedServerUrl ?? serverUrl ?? string.Empty;
            return;
        }

        if (!string.IsNullOrWhiteSpace(_lockedServerUrl))
        {
            txtServerUrl.Text = _lockedServerUrl;
            txtServerUrl.ReadOnly = true;
            txtServerUrl.TabStop = false;
            txtServerUrl.BackColor = SystemColors.Control;
        }
        else
        {
            txtServerUrl.Text = serverUrl ?? string.Empty;
        }
    }

    private void ConfigureForMode()
    {
        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            lblServerUrl.Visible = false;
            txtServerUrl.Visible = false;
            lblUsername.Visible = false;
            txtUsername.Visible = false;
            lblPassword.Visible = false;
            txtPassword.Visible = false;
            btnShared.Visible = true;

            lblInvite.Location = new DrawingPoint(50, 250);
            txtInviteCode.Location = new DrawingPoint(160, 250);
            btnShared.Location = new DrawingPoint(160, 310);
            btnSave.Location = new DrawingPoint(160, 380);
            btnCancel.Location = new DrawingPoint(290, 380);
            lblHint.Size = new DrawingSize(380, 100);
            Size = new DrawingSize(450, 480);
            AcceptButton = btnSave;
            CancelButton = btnCancel;
            return;
        }

        Size = new DrawingSize(450, 600);
        btnShared.Visible = true;
        btnShared.Location = new DrawingPoint(160, 470);
        btnSave.Location = new DrawingPoint(160, 420);
        btnCancel.Location = new DrawingPoint(290, 420);
        lblHint.Size = new DrawingSize(380, 88);
    }

    private void InitializeComponent()
    {
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        Size = new DrawingSize(450, 600);
        BackColor = DrawingColor.White;
        Font = new Font("Segoe UI", 10F);

        pictLogo = new PictureBox
        {
            Size = new DrawingSize(64, 64),
            Location = new DrawingPoint(193, 20),
            BackColor = DrawingColor.Transparent,
            SizeMode = PictureBoxSizeMode.Zoom,
            Image = LoadAppLogo()
        };

        lblTitle = new Label
        {
            Text = "DHPG",
            Font = new Font("Segoe UI", 18F, FontStyle.Bold),
            ForeColor = DrawingColor.FromArgb(0, 120, 212),
            Location = new DrawingPoint(25, 92),
            Size = new DrawingSize(400, 32),
            TextAlign = ContentAlignment.MiddleCenter
        };

        lblHint = new Label
        {
            Text = GetDefaultWelcomeText(),
            Location = new DrawingPoint(35, 128),
            Size = new DrawingSize(380, 88),
            ForeColor = DrawingColor.FromArgb(80, 80, 80),
            Font = new Font("Segoe UI", 9.5F),
            TextAlign = ContentAlignment.TopCenter
        };

        lblServerUrl = new Label { Text = "服务器地址:", Location = new DrawingPoint(50, 225), Size = new DrawingSize(100, 25), TextAlign = ContentAlignment.MiddleRight };
        txtServerUrl = new TextBox { Location = new DrawingPoint(160, 225), Size = new DrawingSize(230, 27), PlaceholderText = "请输入服务器地址" };

        lblInvite = new Label { Text = "邀请码:", Location = new DrawingPoint(50, 270), Size = new DrawingSize(100, 25), TextAlign = ContentAlignment.MiddleRight };
        txtInviteCode = new TextBox { Location = new DrawingPoint(160, 270), Size = new DrawingSize(230, 27), PlaceholderText = "请输入管理员提供的邀请码" };

        lblUsername = new Label { Text = "账号:", Location = new DrawingPoint(50, 315), Size = new DrawingSize(100, 25), TextAlign = ContentAlignment.MiddleRight };
        txtUsername = new TextBox { Location = new DrawingPoint(160, 315), Size = new DrawingSize(230, 27), PlaceholderText = "员工后台登录账号" };

        lblPassword = new Label { Text = "密码:", Location = new DrawingPoint(50, 360), Size = new DrawingSize(100, 25), TextAlign = ContentAlignment.MiddleRight };
        txtPassword = new TextBox { Location = new DrawingPoint(160, 360), Size = new DrawingSize(230, 27), UseSystemPasswordChar = true, PlaceholderText = "员工后台登录密码" };

        btnSave = new Button { Text = "登录", Location = new DrawingPoint(160, 420), Size = new DrawingSize(100, 35), BackColor = DrawingColor.FromArgb(0, 120, 212), ForeColor = DrawingColor.White, FlatStyle = FlatStyle.Flat };
        btnSave.FlatAppearance.BorderSize = 0;
        btnSave.Click += BtnSave_Click;

        btnShared = new Button
        {
            Text = "共享工位（稍后登录）",
            Location = new DrawingPoint(160, 470),
            Size = new DrawingSize(180, 34),
            FlatStyle = FlatStyle.Flat,
            Visible = true
        };
        btnShared.Click += BtnShared_Click;

        btnCancel = new Button { Text = "退出", Location = new DrawingPoint(290, 420), Size = new DrawingSize(100, 35), BackColor = DrawingColor.LightGray, ForeColor = DrawingColor.Black, FlatStyle = FlatStyle.Flat };
        btnCancel.FlatAppearance.BorderSize = 0;
        btnCancel.Click += BtnCancel_Click;

        Controls.AddRange(new Control[]
        {
            pictLogo, lblTitle, lblHint, lblServerUrl, txtServerUrl, lblInvite, txtInviteCode,
            lblUsername, txtUsername, lblPassword, txtPassword, btnSave, btnShared, btnCancel
        });
        FormClosing += EmployeeSetupForm_FormClosing;
        AcceptButton = btnSave;
    }

    private void ApplyLocalization()
    {
        if (_localization == null) return;

        lblTitle.Text = _localization.GetString("AppTitle", "DHPG");
        lblServerUrl.Text = _localization.GetString("ServerURL", "服务器地址:");
        lblInvite.Text = _localization.GetString("InviteCodeLabel", "邀请码:");
        lblUsername.Text = _localization.GetString("LoginUsernameLabel", "账号:");
        lblPassword.Text = _localization.GetString("LoginPasswordLabel", "密码:");
        txtServerUrl.PlaceholderText = _localization.GetString("ServerUrlPlaceholder", "请输入服务器地址");
        txtInviteCode.PlaceholderText = _localization.GetString("InviteCodePlaceholder", "请输入管理员提供的邀请码");
        txtUsername.PlaceholderText = _localization.GetString("LoginUsernamePlaceholder", "员工后台登录账号");
        txtPassword.PlaceholderText = _localization.GetString("LoginPasswordPlaceholder", "员工后台登录密码");

        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            Text = _localization.GetString("DeviceBindingTitle", "完善设备绑定");
            lblHint.Text = _localization.GetString(
                "DeviceBindingPrompt",
                "此设备尚未绑定员工。\n请输入管理员提供的邀请码，或选择共享工位稍后登录。");
            btnSave.Text = _localization.GetString("BindDevice", "绑定设备");
            btnCancel.Text = _localization.GetString("Cancel", "取消");
            btnShared.Text = _localization.GetString("SharedWorkstation", "共享工位（稍后登录）");
            return;
        }

        Text = _localization.GetString("SetupTitle", "DHPG");
        lblHint.Text = BuildWelcomeText(_localization);
        btnSave.Text = _localization.GetString("FirstLoginButton", "登录");
        btnCancel.Text = _localization.GetString("Exit", "退出");
        btnShared.Text = _localization.GetString("SharedWorkstation", "共享工位（稍后登录）");
    }

    private static string GetDefaultWelcomeText()
        => "欢迎使用！未来的工作，我们并肩前行。🚀\n请填写服务器地址、邀请码与员工账号密码。";

    private static string BuildWelcomeText(ILocalizationService localization)
    {
        var welcome = localization.GetString("SetupWelcome", "欢迎使用！未来的工作，我们并肩前行。🚀");
        var hint = localization.GetString("FirstLoginHint", "请填写服务器地址、邀请码与员工账号密码，完成设备绑定并登录。");
        return $"{welcome}\n{hint}";
    }

    private DrawingImage LoadAppLogo()
    {
        var iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
        if (File.Exists(iconPath))
        {
            try
            {
                using var icon = new Icon(iconPath, 64, 64);
                return icon.ToBitmap();
            }
            catch (Exception ex)
            {
                _logger?.LogWarning(ex, "Failed to load logo from {Path}", iconPath);
            }
        }

        return CreateDefaultIcon();
    }

    private DrawingImage CreateDefaultIcon()
    {
        var bitmap = new Bitmap(64, 64);
        using var g = Graphics.FromImage(bitmap);
        g.Clear(DrawingColor.FromArgb(0, 120, 212));
        using var font = new Font("Segoe UI", 28, FontStyle.Bold);
        var appShortName = _localization?.GetString("AppShortName", "EA") ?? "EA";
        g.DrawString(appShortName, font, Brushes.White, new DrawingPointF(12, 12));
        return bitmap;
    }

    private void BtnSave_Click(object? sender, EventArgs e)
    {
        var inviteCode = txtInviteCode.Text.Trim();
        var serverUrl = _lockedServerUrl ?? txtServerUrl.Text.Trim();
        var username = txtUsername.Text.Trim();
        var password = txtPassword.Text;

        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            if (string.IsNullOrWhiteSpace(inviteCode))
            {
                ShowWarning("InviteCodeRequired", "请输入邀请码");
                txtInviteCode.Focus();
                return;
            }

            UseSharedWorkstation = false;
            EmployeeInfo = new EmployeeInfo { InviteCode = inviteCode, PreferSharedLogin = false };
            ServerUrl = serverUrl;
            DialogResult = DialogResult.OK;
            Close();
            return;
        }

        if (string.IsNullOrWhiteSpace(serverUrl))
        {
            ShowWarning("ServerUrlRequired", "请输入服务器地址");
            if (_lockedServerUrl == null)
                txtServerUrl.Focus();
            return;
        }

        if (string.IsNullOrWhiteSpace(inviteCode))
        {
            ShowWarning("InviteCodeRequired", "请输入邀请码");
            txtInviteCode.Focus();
            return;
        }

        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password))
        {
            ShowWarning("LoginCredentialsRequired", "请输入账号和密码");
            if (string.IsNullOrWhiteSpace(username))
                txtUsername.Focus();
            else
                txtPassword.Focus();
            return;
        }

        EmployeeInfo = new EmployeeInfo { InviteCode = inviteCode, PreferSharedLogin = false };
        ServerUrl = serverUrl;
        _logger?.LogInformation("First login setup saved for server {ServerUrl}", serverUrl);
        DialogResult = DialogResult.OK;
        Close();
    }

    private void BtnShared_Click(object? sender, EventArgs e)
    {
        var serverUrl = _lockedServerUrl ?? txtServerUrl.Text.Trim();
        if (_mode == EmployeeSetupFormMode.FirstLogin && string.IsNullOrWhiteSpace(serverUrl))
        {
            ShowWarning("ServerUrlRequired", "请输入服务器地址");
            if (_lockedServerUrl == null)
                txtServerUrl.Focus();
            return;
        }

        UseSharedWorkstation = true;
        EmployeeInfo = new EmployeeInfo { InviteCode = "", PreferSharedLogin = true };
        ServerUrl = serverUrl;
        DialogResult = DialogResult.OK;
        Close();
    }

    private void BtnCancel_Click(object? sender, EventArgs e)
    {
        if (_mode == EmployeeSetupFormMode.InviteBinding)
        {
            DialogResult = DialogResult.Cancel;
            Close();
            return;
        }

        _logger?.LogWarning("Startup configuration cancelled, exiting application");
        Application.Exit();
    }

    private void EmployeeSetupForm_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (_mode == EmployeeSetupFormMode.InviteBinding)
            return;

        if (EmployeeInfo == null && DialogResult != DialogResult.OK)
        {
            var title = _localization?.GetString("ConfirmExit", "确认退出") ?? "确认退出";
            var message = _localization?.GetString("ExitConfirm", "确定要退出吗？") ?? "确定要退出吗？";
            if (MessageBox.Show(message, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                e.Cancel = true;
        }
    }

    private void ShowWarning(string messageKey, string defaultMessage)
    {
        var title = _localization?.GetString("ValidationError", "验证错误") ?? "验证错误";
        var message = _localization?.GetString(messageKey, defaultMessage) ?? defaultMessage;
        MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}

#endregion

#region EmployeeLoginForm

public class EmployeeLoginForm : Form
{
    private TextBox txtUsername = null!;
    private TextBox txtPassword = null!;
    private Button btnLogin = null!;
    private Button btnCancel = null!;
    private readonly ILocalizationService? _localization;

    public string Username => txtUsername.Text.Trim();
    public string Password => txtPassword.Text;

    public EmployeeLoginForm(string? serverHint = null, ILocalizationService? localization = null)
    {
        _localization = localization;
        Text = _localization?.GetString("EmployeeLoginTitle", "员工登录") ?? "员工登录";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        Size = new DrawingSize(420, 260);

        var hintTemplate = string.IsNullOrWhiteSpace(serverHint)
            ? _localization?.GetString("EmployeeLoginHint", "请使用后台子账号登录（同一电脑可多人轮流使用）")
                ?? "请使用后台子账号登录（同一电脑可多人轮流使用）"
            : string.Format(
                _localization?.GetString("EmployeeLoginServerHint", "服务器：{0}") ?? "服务器：{0}",
                serverHint);
        var lblHint = new Label
        {
            Text = hintTemplate,
            Location = new DrawingPoint(30, 20),
            Size = new DrawingSize(360, 40),
            ForeColor = DrawingColor.FromArgb(80, 80, 80)
        };
        var lblUser = new Label
        {
            Text = _localization?.GetString("LoginUsernameLabel", "账号:") ?? "账号:",
            Location = new DrawingPoint(40, 75), Size = new DrawingSize(80, 25), TextAlign = ContentAlignment.MiddleRight
        };
        txtUsername = new TextBox { Location = new DrawingPoint(130, 75), Size = new DrawingSize(240, 27) };
        var lblPwd = new Label
        {
            Text = _localization?.GetString("LoginPasswordLabel", "密码:") ?? "密码:",
            Location = new DrawingPoint(40, 120), Size = new DrawingSize(80, 25), TextAlign = ContentAlignment.MiddleRight
        };
        txtPassword = new TextBox { Location = new DrawingPoint(130, 120), Size = new DrawingSize(240, 27), UseSystemPasswordChar = true };
        btnLogin = new Button
        {
            Text = _localization?.GetString("FirstLoginButton", "登录") ?? "登录",
            Location = new DrawingPoint(130, 170), Size = new DrawingSize(100, 32),
            BackColor = DrawingColor.FromArgb(0, 120, 212), ForeColor = DrawingColor.White, FlatStyle = FlatStyle.Flat
        };
        btnLogin.FlatAppearance.BorderSize = 0;
        btnLogin.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrEmpty(Password))
            {
                var title = _localization?.GetString("Prompt", "提示") ?? "提示";
                var message = _localization?.GetString("LoginCredentialsRequired", "请输入账号和密码") ?? "请输入账号和密码";
                MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DialogResult = DialogResult.OK;
            Close();
        };
        btnCancel = new Button
        {
            Text = _localization?.GetString("Cancel", "取消") ?? "取消",
            Location = new DrawingPoint(270, 170), Size = new DrawingSize(100, 32),
            DialogResult = DialogResult.Cancel
        };

        Controls.AddRange(new Control[] { lblHint, lblUser, txtUsername, lblPwd, txtPassword, btnLogin, btnCancel });
        AcceptButton = btnLogin;
        CancelButton = btnCancel;
    }
}

#endregion

#region StatusForm

public class StatusForm : Form
{
    private readonly Func<string> _getDeviceId;
    private readonly Func<string> _getServerUrl;
    private readonly Func<bool> _isConnected;
    private readonly ILocalizationService? _localization;

    private GroupBox groupDevice = null!;
    private GroupBox groupConnection = null!;
    private GroupBox groupServices = null!;
    private Label lblDeviceId = null!;
    private Label lblDeviceIdValue = null!;
    private Label lblAgentVersion = null!;
    private Label lblAgentVersionValue = null!;
    private Label lblServerUrl = null!;
    private Label lblServerUrlValue = null!;
    private Label lblConnectionStatus = null!;
    private Label lblConnectionStatusValue = null!;
    private Label lblRecording = null!;
    private Label lblRecordingValue = null!;
    private Button btnRefresh = null!;
    private Button btnCopyDeviceId = null!;

    public StatusForm(
        Func<string> getDeviceId,
        Func<string> getServerUrl,
        Func<bool> isConnected,
        ILocalizationService? localization = null)
    {
        _getDeviceId = getDeviceId;
        _getServerUrl = getServerUrl;
        _isConnected = isConnected;
        _localization = localization;

        InitializeComponent();
        ApplyLocalization();
        RefreshStatus();
    }

    private void InitializeComponent()
    {
        Text = "Agent Status";
        Size = new DrawingSize(480, 380);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;

        groupDevice = new GroupBox { Location = new DrawingPoint(20, 15), Size = new DrawingSize(420, 90) };
        lblDeviceId = new Label { Location = new DrawingPoint(15, 28), Size = new DrawingSize(90, 23), Text = "Device ID:" };
        lblDeviceIdValue = new Label { Location = new DrawingPoint(110, 28), Size = new DrawingSize(290, 23), AutoEllipsis = true };
        lblAgentVersion = new Label { Location = new DrawingPoint(15, 55), Size = new DrawingSize(90, 23), Text = "Agent Version:" };
        lblAgentVersionValue = new Label { Location = new DrawingPoint(110, 55), Size = new DrawingSize(290, 23), Text = AppConstants.DefaultAgentVersion };
        groupDevice.Controls.AddRange(new Control[] { lblDeviceId, lblDeviceIdValue, lblAgentVersion, lblAgentVersionValue });

        groupConnection = new GroupBox { Location = new DrawingPoint(20, 115), Size = new DrawingSize(420, 90) };
        lblServerUrl = new Label { Location = new DrawingPoint(15, 28), Size = new DrawingSize(90, 23), Text = "Server URL:" };
        lblServerUrlValue = new Label { Location = new DrawingPoint(110, 28), Size = new DrawingSize(290, 23), AutoEllipsis = true };
        lblConnectionStatus = new Label { Location = new DrawingPoint(15, 55), Size = new DrawingSize(90, 23), Text = "Status:" };
        lblConnectionStatusValue = new Label { Location = new DrawingPoint(110, 55), Size = new DrawingSize(290, 23) };
        groupConnection.Controls.AddRange(new Control[] { lblServerUrl, lblServerUrlValue, lblConnectionStatus, lblConnectionStatusValue });

        groupServices = new GroupBox { Location = new DrawingPoint(20, 215), Size = new DrawingSize(420, 60) };
        lblRecording = new Label { Location = new DrawingPoint(15, 28), Size = new DrawingSize(90, 23), Text = "Recording:" };
        lblRecordingValue = new Label { Location = new DrawingPoint(110, 28), Size = new DrawingSize(290, 23), Text = "-" };
        groupServices.Controls.AddRange(new Control[] { lblRecording, lblRecordingValue });

        btnRefresh = new Button { Location = new DrawingPoint(20, 295), Size = new DrawingSize(100, 32), Text = "Refresh" };
        btnRefresh.Click += (_, _) => RefreshStatus();
        btnCopyDeviceId = new Button { Location = new DrawingPoint(130, 295), Size = new DrawingSize(100, 32), Text = "Copy" };
        btnCopyDeviceId.Click += (_, _) => CopyDeviceId();

        Controls.AddRange(new Control[] { groupDevice, groupConnection, groupServices, btnRefresh, btnCopyDeviceId });
    }

    private void ApplyLocalization()
    {
        if (_localization == null) return;

        Text = _localization.GetString("AgentStatus", "Agent Status");
        groupDevice.Text = _localization.GetString("DeviceInformation", "Device Information");
        groupConnection.Text = _localization.GetString("Connection", "Connection");
        groupServices.Text = _localization.GetString("Services", "Services");
        btnRefresh.Text = _localization.GetString("Refresh", "Refresh");
        btnCopyDeviceId.Text = _localization.GetString("Copy", "Copy");
        lblDeviceId.Text = _localization.GetString("DeviceId", "Device ID:");
        lblAgentVersion.Text = _localization.GetString("AgentVersion", "Agent Version:");
        lblServerUrl.Text = _localization.GetString("ServerURL", "Server URL:");
        lblConnectionStatus.Text = _localization.GetString("Status", "Status:");
        lblRecording.Text = _localization.GetString("Recording", "Recording:");
    }

    private void RefreshStatus()
    {
        var deviceId = _getDeviceId();
        var notRegistered = _localization?.GetString("NotRegistered", "Not registered") ?? "Not registered";
        lblDeviceIdValue.Text = string.IsNullOrWhiteSpace(deviceId) ? notRegistered : deviceId;
        lblServerUrlValue.Text = _getServerUrl();
        var connectedText = _isConnected()
            ? (_localization?.GetString("Connected", "Connected") ?? "Connected")
            : (_localization?.GetString("Disconnected", "Disconnected") ?? "Disconnected");
        lblConnectionStatusValue.Text = connectedText;
    }

    private void CopyDeviceId()
    {
        var deviceId = _getDeviceId();
        if (string.IsNullOrWhiteSpace(deviceId))
        {
            var title = _localization?.GetString("Error", "Error") ?? "Error";
            MessageBox.Show(_localization?.GetString("DeviceIdNotRegistered", "Device not yet registered") ?? "Device not yet registered", title);
            return;
        }

        Clipboard.SetText(deviceId);
        MessageBox.Show(
            _localization?.GetString("DeviceIdCopied", "Device ID copied to clipboard") ?? "Device ID copied to clipboard",
            _localization?.GetString("Copied", "Copied") ?? "Copied");
    }
}

#endregion

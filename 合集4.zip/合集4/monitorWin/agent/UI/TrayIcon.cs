// UI/TrayIcon.cs - 完整版（支持开机自启动 + 多语言 + 打开日志）

using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Extensions.Logging;
using EnterpriseAgent.Agent.Services;
using DrawingColor = System.Drawing.Color;
using DrawingPointF = System.Drawing.PointF; 

namespace EnterpriseAgent.Agent.UI;

public class TrayIcon : IDisposable
{
    private readonly ILogger<TrayIcon>? _logger;
    private readonly NotifyIcon _notifyIcon;
    private readonly ContextMenuStrip _contextMenu;
    private readonly Form _uiSyncForm;
    private readonly Action _onExit;
    private readonly Func<bool> _isConnected;
    private readonly Func<string> _getDeviceId;
    private readonly Func<string> _getServerUrl;
    private readonly ILocalizationService? _localization;
    private StatusForm? _statusForm;
    private bool _disposed;
    
    // 服务状态
    private bool _isRecording;
    private bool _isScreenshotting;
    private bool _isUploading;
    
    // 菜单项
    private ToolStripMenuItem? _autoStartItem;
    private ToolStripMenuItem? _statusItem;
    private ToolStripMenuItem? _employeeItem;
    private ToolStripMenuItem? _showStatusItem;
    private ToolStripMenuItem? _openLogItem;
    private ToolStripMenuItem? _deviceIdMenu;
    private ToolStripMenuItem? _serverMenu;
    private ToolStripMenuItem? _exitItem;
    
    private ToolStripMenuItem? _checkInItem;
    private ToolStripMenuItem? _checkOutItem;
    private readonly Func<Task<bool>>? _onCheckIn;
    private readonly Func<Task<bool>>? _onCheckOut;
    private readonly Func<Task<bool>>? _onEmployeeLogin;
    private readonly Func<Task<bool>>? _onEmployeeLogout;
    private readonly Func<Task<bool>>? _onBindInvite;
    private readonly Func<EmployeeTrayStatus>? _getEmployeeStatus;
    
    public TrayIcon(
        ILogger<TrayIcon>? logger,
        Action onExit,
        Func<bool> isConnected,
        Func<string> getDeviceId,
        Func<string> getServerUrl,
        ILocalizationService? localization = null,
        Func<Task<bool>>? onCheckIn = null,
        Func<Task<bool>>? onCheckOut = null,
        Func<Task<bool>>? onEmployeeLogin = null,
        Func<Task<bool>>? onEmployeeLogout = null,
        Func<EmployeeTrayStatus>? getEmployeeStatus = null,
        Func<Task<bool>>? onBindInvite = null)
    {
        _logger = logger;
        _onExit = onExit ?? throw new ArgumentNullException(nameof(onExit));
        _isConnected = isConnected ?? throw new ArgumentNullException(nameof(isConnected));
        _getDeviceId = getDeviceId ?? throw new ArgumentNullException(nameof(getDeviceId));
        _getServerUrl = getServerUrl ?? throw new ArgumentNullException(nameof(getServerUrl));
        _localization = localization;
        _onCheckIn = onCheckIn;
        _onCheckOut = onCheckOut;
        _onEmployeeLogin = onEmployeeLogin;
        _onEmployeeLogout = onEmployeeLogout;
        _getEmployeeStatus = getEmployeeStatus;
        _onBindInvite = onBindInvite;
        
        _uiSyncForm = new Form
        {
            ShowInTaskbar = false,
            FormBorderStyle = FormBorderStyle.None,
            Size = new Size(0, 0),
            Opacity = 0
        };
        _uiSyncForm.Load += (_, _) => _uiSyncForm.Hide();
        if (!_uiSyncForm.IsHandleCreated)
            _ = _uiSyncForm.Handle;
        
        _contextMenu = new ContextMenuStrip();
        BuildContextMenu();
        
        var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
        _notifyIcon = new NotifyIcon
        {
            Icon = GetAppIcon(),
            Text = appName,
            ContextMenuStrip = _contextMenu,
            Visible = true
        };
        
        _notifyIcon.DoubleClick += (s, e) => ShowStatusWindow();
        
        var timer = new System.Windows.Forms.Timer { Interval = 2000 };
        timer.Tick += (s, e) => UpdateTrayStatus();
        timer.Start();
        
        _logger?.LogInformation("Tray icon initialized");
    }

    public void NotifyAlreadyRunning()
    {
        RunOnUiThread(() =>
        {
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var message = _localization?.GetString("AlreadyRunning", "程序已在运行中，请勿重复打开。")
                ?? "程序已在运行中，请勿重复打开。";
            ShowBalloonTip(appName, message, ToolTipIcon.Info);
            _logger?.LogInformation("Blocked duplicate launch attempt");
        });
    }

    private void RunOnUiThread(Action action)
    {
        if (_uiSyncForm.IsHandleCreated && _uiSyncForm.InvokeRequired)
            _uiSyncForm.BeginInvoke(action);
        else
            action();
    }
    
    /// <summary>
    /// 检查是否已开启开机自启动
    /// </summary>
    private bool IsAutoStartEnabled() => AutoStartManager.IsEnabled();

    private void SetAutoStart(bool enabled)
    {
        try
        {
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";

            if (enabled)
            {
                if (!AutoStartManager.Enable(_logger))
                {
                    var failMessage = _localization?.GetString("AutoStartFailed", "设置开机自启动失败，请检查权限")
                        ?? "设置开机自启动失败，请检查权限";
                    ShowBalloonTip(appName, failMessage, ToolTipIcon.Error);
                    return;
                }

                _logger?.LogInformation("Auto-start enabled: {Path}", AutoStartManager.GetExecutablePath());
                var message = _localization?.GetString("AutoStartEnabled", "已开启开机自启动，下次开机将自动运行")
                    ?? "已开启开机自启动，下次开机将自动运行";
                ShowBalloonTip(appName, message, ToolTipIcon.Info);
            }
            else
            {
                AutoStartManager.Disable(_logger);
                var message = _localization?.GetString("AutoStartDisabled", "已关闭开机自启动")
                    ?? "已关闭开机自启动";
                ShowBalloonTip(appName, message, ToolTipIcon.Info);
            }

            if (_autoStartItem != null)
                _autoStartItem.Checked = enabled;
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Failed to set auto-start");
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var message = _localization?.GetString("AutoStartFailed", "设置开机自启动失败，请检查权限")
                ?? "设置开机自启动失败，请检查权限";
            ShowBalloonTip(appName, message, ToolTipIcon.Error);
        }
    }
    
    /// <summary>
    /// 切换开机自启动状态
    /// </summary>
    private void ToggleAutoStart()
    {
        var newState = !IsAutoStartEnabled();
        SetAutoStart(newState);
    }
    
    /// <summary>
    /// 打开日志文件夹
    /// </summary>
    private void OpenLogFolder()
    {
        try
        {
            // 尝试多个可能的日志目录
            var possiblePaths = new List<string>
            {
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "EnterpriseAgent", "logs"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "EnterpriseAgent", "logs")
            };
            
            string? logPath = null;
            foreach (var path in possiblePaths)
            {
                if (Directory.Exists(path))
                {
                    logPath = path;
                    break;
                }
            }
            
            // 如果没有找到任何日志目录，创建默认目录
            if (string.IsNullOrEmpty(logPath))
            {
                logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
                Directory.CreateDirectory(logPath);
            }
            
            // 打开资源管理器
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = $"\"{logPath}\"",
                UseShellExecute = true
            });
            
            _logger?.LogInformation("Opened log folder: {LogPath}", logPath);
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Failed to open log folder");
            
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var message = _localization?.GetString("OpenLogFailed", "无法打开日志文件夹") ?? "无法打开日志文件夹";
            ShowBalloonTip(appName, message, ToolTipIcon.Error);
        }
    }
    
    private async Task RunWorkAction(Func<Task<bool>> action, string successMessageKey, string successDefault)
    {
        try
        {
            var ok = await action();
            if (ok)
            {
                var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
                var message = _localization?.GetString(successMessageKey, successDefault) ?? successDefault;
                ShowBalloonTip(appName, message, ToolTipIcon.Info);
            }
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Work session action failed");
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var message = _localization?.GetString("ActionFailed", "操作失败，请查看日志") ?? "操作失败，请查看日志";
            ShowBalloonTip(appName, message, ToolTipIcon.Error);
        }
    }
    
    private void BuildContextMenu()
    {
        _contextMenu.Items.Clear();
        
        // 状态显示
        var statusLabel = _localization?.GetString("Status", "状态") ?? "状态";
        _statusItem = new ToolStripMenuItem($"{statusLabel}: 未知") { Enabled = false };
        _contextMenu.Items.Add(_statusItem);

        _employeeItem = new ToolStripMenuItem(FormatEmployeeLine(null)) { Enabled = false };
        _contextMenu.Items.Add(_employeeItem);
        _contextMenu.Items.Add(new ToolStripSeparator());
        
        // 显示状态窗口
        var showStatusText = _localization?.GetString("ShowStatusWindow", "显示状态窗口") ?? "显示状态窗口";
        _showStatusItem = new ToolStripMenuItem(showStatusText, null, (s, e) => ShowStatusWindow());
        _contextMenu.Items.Add(_showStatusItem);

        if (_onCheckIn != null)
        {
            var checkInText = _localization?.GetString("CheckIn", "上班") ?? "上班";
            _checkInItem = new ToolStripMenuItem(checkInText, null,
                async (s, e) => await RunWorkAction(_onCheckIn, "CheckInSuccess", "上班成功"));
            _contextMenu.Items.Add(_checkInItem);
        }
        if (_onCheckOut != null)
        {
            var checkOutText = _localization?.GetString("CheckOut", "下班") ?? "下班";
            _checkOutItem = new ToolStripMenuItem(checkOutText, null,
                async (s, e) => await RunWorkAction(_onCheckOut, "CheckOutSuccess", "下班成功"));
            _contextMenu.Items.Add(_checkOutItem);
        }

        if (_onEmployeeLogin != null)
        {
            var loginText = _localization?.GetString("EmployeeLogin", "员工登录") ?? "员工登录";
            _contextMenu.Items.Add(new ToolStripMenuItem(loginText, null,
                async (s, e) => await RunWorkAction(_onEmployeeLogin, "LoginSuccessTitle", "登录成功")));
        }
        if (_onEmployeeLogout != null)
        {
            var logoutText = _localization?.GetString("SwitchAccountLogout", "切换账号 / 退出登录") ?? "切换账号 / 退出登录";
            _contextMenu.Items.Add(new ToolStripMenuItem(logoutText, null,
                async (s, e) => await RunWorkAction(_onEmployeeLogout, "LogoutTitle", "已退出登录")));
        }
        if (_onBindInvite != null)
        {
            var bindText = _localization?.GetString("BindInviteCode", "绑定邀请码") ?? "绑定邀请码";
            _contextMenu.Items.Add(new ToolStripMenuItem(bindText, null,
                async (s, e) => await RunWorkAction(_onBindInvite, "BindComplete", "绑定完成")));
        }
        
        // ✅ 新增：打开日志
        var openLogText = _localization?.GetString("OpenLog", "打开日志") ?? "打开日志";
        _openLogItem = new ToolStripMenuItem(openLogText, null, (s, e) => OpenLogFolder());
        _contextMenu.Items.Add(_openLogItem);
        
        _contextMenu.Items.Add(new ToolStripSeparator());
        
        // 设备ID菜单
        var deviceIdText = _localization?.GetString("DeviceId", "设备ID") ?? "设备ID";
        _deviceIdMenu = new ToolStripMenuItem(deviceIdText);
        var copyDeviceIdText = _localization?.GetString("CopyDeviceId", "复制设备ID") ?? "复制设备ID";
        var copyDeviceIdItem = new ToolStripMenuItem(copyDeviceIdText, null, (s, e) => CopyDeviceId());
        _deviceIdMenu.DropDownItems.Add(copyDeviceIdItem);
        _contextMenu.Items.Add(_deviceIdMenu);
        
        // 服务器地址菜单
        var serverUrlText = _localization?.GetString("ServerURL", "服务器地址") ?? "服务器地址";
        _serverMenu = new ToolStripMenuItem(serverUrlText);
        var copyServerText = _localization?.GetString("CopyServerUrl", "复制服务器地址") ?? "复制服务器地址";
        var copyServerItem = new ToolStripMenuItem(copyServerText, null, (s, e) => CopyServerUrl());
        _serverMenu.DropDownItems.Add(copyServerItem);
        _contextMenu.Items.Add(_serverMenu);
        
        _contextMenu.Items.Add(new ToolStripSeparator());
        
        // 开机自启动开关
        var autoStartText = _localization?.GetString("AutoStart", "开机自启动") ?? "开机自启动";
        _autoStartItem = new ToolStripMenuItem(autoStartText);
        _autoStartItem.Checked = IsAutoStartEnabled();
        _autoStartItem.Click += (s, e) => ToggleAutoStart();
        _contextMenu.Items.Add(_autoStartItem);
        
        _contextMenu.Items.Add(new ToolStripSeparator());
        
        // 退出
        var exitText = _localization?.GetString("Exit", "退出") ?? "退出";
        _exitItem = new ToolStripMenuItem(exitText, null, (s, e) => 
        {
            _logger?.LogInformation("Exit requested from tray menu");
            _notifyIcon.Visible = false;
            _onExit();
        });
        _contextMenu.Items.Add(_exitItem);
    }
    
    private string FormatEmployeeLine(string? displayName)
    {
        var label = _localization?.GetString("EmployeeLabel", "员工") ?? "员工";
        if (!string.IsNullOrWhiteSpace(displayName))
            return $"{label}: {displayName}";

        var notLoggedIn = _localization?.GetString("EmployeeNotLoggedIn", "未登录（请使用「员工登录」）")
            ?? "未登录（请使用「员工登录」）";
        return $"{label}: {notLoggedIn}";
    }
    
    private void UpdateTrayStatus()
    {
        try
        {
            var isConnected = _isConnected();
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var statusLabel = _localization?.GetString("Status", "状态") ?? "状态";
            var deviceLabel = _localization?.GetString("Device", "设备") ?? "设备";
            var notRegistered = _localization?.GetString("NotRegistered", "未注册") ?? "未注册";
            var connectedText = isConnected ? 
                (_localization?.GetString("Connected", "已连接") ?? "已连接") : 
                (_localization?.GetString("Disconnected", "未连接") ?? "未连接");
            
            // 更新状态菜单项
            if (_statusItem != null)
            {
                var statusIcon = isConnected ? "●" : "○";
                _statusItem.Text = $"{statusLabel}: {statusIcon} {connectedText}";
                _statusItem.ForeColor = isConnected ? DrawingColor.Green : DrawingColor.Red;
            }

        if (_employeeItem != null && _getEmployeeStatus != null)
        {
            try
            {
                var employee = _getEmployeeStatus();
                if (employee.IsLoggedIn)
                {
                    _employeeItem.Text = FormatEmployeeLine(employee.DisplayLabel);
                    _employeeItem.ForeColor = DrawingColor.FromArgb(0, 100, 0);
                }
                else
                {
                    _employeeItem.Text = FormatEmployeeLine(null);
                    _employeeItem.ForeColor = DrawingColor.Gray;
                }
            }
            catch (Exception ex)
            {
                _logger?.LogDebug(ex, "Failed to read employee tray status");
            }
        }
            
            // 更新托盘悬停提示
            var deviceId = _getDeviceId();
            var shortDeviceId = string.IsNullOrEmpty(deviceId) ? notRegistered : 
                (deviceId.Length > 12 ? deviceId[..12] + "..." : deviceId);
            var employeeLabel = _localization?.GetString("EmployeeLabel", "员工") ?? "员工";
            var trayEmployee = _getEmployeeStatus != null ? _getEmployeeStatus() : null;
            _notifyIcon.Text = trayEmployee != null && trayEmployee.IsLoggedIn
                ? $"{appName}\n{employeeLabel}: {trayEmployee.DisplayLabel}\n{deviceLabel}: {shortDeviceId}\n{statusLabel}: {connectedText}"
                : $"{appName}\n{deviceLabel}: {shortDeviceId}\n{statusLabel}: {connectedText}";
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Error updating tray status");
        }
    }
    
    private void ShowStatusWindow()
    {
        try
        {
            if (_statusForm == null || _statusForm.IsDisposed)
            {
                _statusForm = new StatusForm(_getDeviceId, _getServerUrl, _isConnected, _localization);
                _statusForm.FormClosed += (s, e) => _statusForm = null;
            }
            
            if (_statusForm.WindowState == FormWindowState.Minimized)
                _statusForm.WindowState = FormWindowState.Normal;
            
            _statusForm.Show();
            _statusForm.BringToFront();
            _statusForm.Activate();
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Error showing status window");
        }
    }
    
    private void CopyDeviceId()
    {
        try
        {
            var deviceId = _getDeviceId();
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            
            if (!string.IsNullOrEmpty(deviceId))
            {
                Clipboard.SetText(deviceId);
                _logger?.LogInformation("Device ID copied to clipboard");
                var message = _localization?.GetString("DeviceIdCopied", "设备ID已复制到剪贴板") ?? "设备ID已复制到剪贴板";
                ShowBalloonTip(appName, message, ToolTipIcon.Info);
            }
            else
            {
                var message = _localization?.GetString("DeviceIdNotRegistered", "设备尚未注册") ?? "设备尚未注册";
                ShowBalloonTip(appName, message, ToolTipIcon.Warning);
            }
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Failed to copy device ID");
            var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
            var message = _localization?.GetString("CopyFailed", "复制失败") ?? "复制失败";
            ShowBalloonTip(appName, message, ToolTipIcon.Error);
        }
    }
    
    private void CopyServerUrl()
    {
        try
        {
            var serverUrl = _getServerUrl();
            if (!string.IsNullOrEmpty(serverUrl))
            {
                Clipboard.SetText(serverUrl);
                _logger?.LogInformation("Server URL copied to clipboard");
                var appName = _localization?.GetString("AppName", "DHPG") ?? "DHPG";
                var message = _localization?.GetString("ServerUrlCopied", "服务器地址已复制到剪贴板") ?? "服务器地址已复制到剪贴板";
                ShowBalloonTip(appName, message, ToolTipIcon.Info);
            }
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Failed to copy server URL");
        }
    }
    
    private void ShowBalloonTip(string title, string message, ToolTipIcon icon)
    {
        _notifyIcon.ShowBalloonTip(3000, title, message, icon);
    }
    
    private Icon GetAppIcon()
    {
        // 从输出目录加载自定义图标
        var iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
        if (File.Exists(iconPath))
        {
            try
            {
                return new Icon(iconPath);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Failed to load icon from {Path}", iconPath);
            }
        }

        // 后备方案：动态生成
        var bitmap = new Bitmap(64, 64);

        using var g = Graphics.FromImage(bitmap);
        g.Clear(DrawingColor.FromArgb(0, 120, 212));

        using var font = new Font("Segoe UI", 28, FontStyle.Bold);

        g.DrawString("DH", font, Brushes.White, new DrawingPointF(12, 12));

        var hIcon = bitmap.GetHicon();

        return Icon.FromHandle(hIcon);
    }
    
    public void NotifyEmployeeSessionChanged() => RunOnUiThread(UpdateTrayStatus);

    /// <summary>
    /// 启动 WinForms 消息循环；在循环就绪后执行 startup 任务（弹窗等必须在消息循环内）。
    /// </summary>
    public void RunMessageLoop(Func<Task>? onMessageLoopReady = null)
    {
        if (onMessageLoopReady != null)
        {
            void OnIdle(object? sender, EventArgs e)
            {
                Application.Idle -= OnIdle;
                _ = RunStartupUiTaskAsync(onMessageLoopReady);
            }

            Application.Idle += OnIdle;
        }

        Application.Run(_uiSyncForm);
    }

    private async Task RunStartupUiTaskAsync(Func<Task> task)
    {
        try
        {
            await task().ConfigureAwait(true);
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Startup UI task failed");
        }
    }

    public void SetRecordingStatus(bool isRecording)
    {
        _isRecording = isRecording;
        UpdateServiceStatus();
    }
    
    public void SetScreenshotStatus(bool isScreenshotting)
    {
        _isScreenshotting = isScreenshotting;
        UpdateServiceStatus();
    }
    
    public void SetUploadStatus(bool isUploading)
    {
        _isUploading = isUploading;
        UpdateServiceStatus();
    }
    
    private void UpdateServiceStatus()
    {
        string statusText;
        if (_isRecording)
        {
            statusText = _localization?.GetString("Recording", "● 录屏中") ?? "● 录屏中";
        }
        else if (_isScreenshotting)
        {
            statusText = _localization?.GetString("Screenshot", "● 截图中") ?? "● 截图中";
        }
        else if (_isUploading)
        {
            statusText = _localization?.GetString("Uploading", "● 上传中") ?? "● 上传中";
        }
        else
        {
            statusText = _localization?.GetString("Idle", "○ 空闲") ?? "○ 空闲";
        }
        
        if (_statusItem != null)
        {
            var currentText = _statusItem.Text;
            if (!string.IsNullOrEmpty(currentText))
            {
                var parts = currentText.Split('\n');
                if (parts.Length > 0)
                {
                    _statusItem.Text = parts[0] + (parts.Length > 1 ? "\n" + statusText : "");
                }
                else
                {
                    _statusItem.Text = statusText;
                }
            }
        }
    }
    
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        
        _statusForm?.Close();
        _statusForm?.Dispose();
        _notifyIcon?.Dispose();
        _contextMenu?.Dispose();
        _uiSyncForm?.Close();
        _uiSyncForm?.Dispose();
        
        _logger?.LogInformation("Tray icon disposed");
    }
}
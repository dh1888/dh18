using DHPG.Common;



namespace DHPG.Services;



internal static class BatchApiMapper

{

    public static BatchProcessResultDto ToResultDto(BatchProcessResult result) => new()

    {

        ActivityId = result.ActivityId,

        ActivityName = result.ActivityName,

        StartedAt = result.StartedAt,

        FinishedAt = result.FinishedAt,

        SuccessCount = result.SuccessCount,

        FailedCount = result.FailedCount,

        TotalBonusAllSites = result.TotalBonusAllSites,

        Tasks = result.Tasks.Select(ToTaskDto).ToList()

    };



    public static BatchTaskResultDto ToTaskDto(BatchSiteTask task) => new()

    {

        Key = task.Key,

        SiteId = task.SiteId,

        SiteName = task.SiteName,

        SiteCode = task.SiteCode,

        Status = task.Status,

        StatusText = task.StatusText,

        ErrorMessage = task.ErrorMessage,

        ResultCacheKey = task.ResultCacheKey,

        Summary = task.CachedSummary,

        UsesSplitRewards = task.UsesSplitRewardsCached

    };



    public static BatchProcessRequest ToProcessRequest(BatchProcessInputDto input)

    {

        var profile = ResolveMappingProfile(input.Mode);

        return new BatchProcessRequest

        {

            ActivityId = input.ActivityId,

            FilterUnclaimed = input.FilterUnclaimed,

            FilterRecharge = input.FilterRecharge,

            IncludeProfitMember = input.IncludeProfitMember,

            WageringMultiplier = input.WageringMultiplier,

            AppRemark = input.AppRemark,

            BackendRemark = input.BackendRemark,

            SaveToHistory = input.SaveToHistory,

            CalculationDate = ParseCalculationDate(input.CalculationDate),

            Timezone = input.Timezone,

            Tasks = input.Tasks.Select(dto => ToSiteTask(dto, profile)).ToList()

        };

    }



    public static MappingProfile ResolveMappingProfile(BatchPageModeDto mode) => mode switch

    {

        BatchPageModeDto.Callback => MappingProfile.Callback,

        BatchPageModeDto.Loss7d => MappingProfile.Loss7d,

        BatchPageModeDto.YesterdayLoss => MappingProfile.YesterdayLoss,

        BatchPageModeDto.OldCallback234 => MappingProfile.OldCallback234,

        BatchPageModeDto.ComprehensiveCallback => MappingProfile.ComprehensiveCallback,

        _ => MappingProfile.Period

    };



    private static BatchSiteTask ToSiteTask(BatchTaskInputDto dto, MappingProfile profile)

    {

        var task = new BatchSiteTask

        {

            Key = string.IsNullOrWhiteSpace(dto.Key) ? Guid.NewGuid().ToString("N") : dto.Key,

            SiteId = dto.SiteId,

            MemberFilePath = dto.MemberFilePath,

            UnclaimedFilePath = dto.UnclaimedFilePath,

            RechargeFilePath = dto.RechargeFilePath,

            MappingProfile = profile

        };



        if (dto.MappingOverride is not null)

        {

            task.ColumnMappingOverride = profile switch

            {

                MappingProfile.Callback => CloneMapping(dto.MappingOverride.Callback),

                MappingProfile.Loss7d => CloneMapping(dto.MappingOverride.Loss7d),

                MappingProfile.YesterdayLoss => CloneMapping(dto.MappingOverride.YesterdayLoss),

                MappingProfile.OldCallback234 => CloneMapping(dto.MappingOverride.OldCallback234),

                MappingProfile.ComprehensiveCallback => CloneMapping(dto.MappingOverride.Comprehensive),

                _ => CloneMapping(dto.MappingOverride.Period)

            };

            task.UnclaimedUserIdColumnOverride = dto.MappingOverride.UnclaimedUserIdColumn;

        }



        return task;

    }



    private static DateOnly? ParseCalculationDate(string? value)

    {

        if (string.IsNullOrWhiteSpace(value))

            return null;



        return DateOnly.TryParse(value, out var date) ? date : null;

    }



    private static ColumnMappingInfo CloneMapping(ColumnMappingInfo source) => new()

    {

        UserIdColumn = source.UserIdColumn,

        PayColumn = source.PayColumn,

        WithdrawColumn = source.WithdrawColumn,

        NetDiffColumn = source.NetDiffColumn,

        InactiveDaysColumn = source.InactiveDaysColumn,

        PhoneColumn = source.PhoneColumn,

        TierColumn = source.TierColumn,

        HeaderRow = source.HeaderRow

    };



    public static BatchProcessResult FromResultDto(BatchProcessResultDto dto)

    {

        var result = new BatchProcessResult

        {

            ActivityId = dto.ActivityId,

            ActivityName = dto.ActivityName,

            StartedAt = dto.StartedAt,

            FinishedAt = dto.FinishedAt,

            SuccessCount = dto.SuccessCount,

            FailedCount = dto.FailedCount,

            TotalBonusAllSites = dto.TotalBonusAllSites,

            Tasks = dto.Tasks.Select(t => new BatchSiteTask

            {

                Key = t.Key,

                SiteId = t.SiteId,

                SiteName = t.SiteName,

                SiteCode = t.SiteCode,

                Status = t.Status,

                ErrorMessage = t.ErrorMessage

            }).ToList()

        };



        foreach (var task in result.Tasks)

        {

            var source = dto.Tasks.FirstOrDefault(t => t.Key == task.Key);

            if (source?.ResultCacheKey is null || source.Summary is null)

                continue;



            task.AttachCacheOutcome(new ProcessResult

            {

                ResultCacheKey = source.ResultCacheKey,

                Summary = source.Summary,

                UsesSplitRewards = source.UsesSplitRewards

            });

        }



        return result;

    }



    public static string BuildRuleFormulaText(ActivityEditModel model, decimal wageringMultiplier)

    {

        if (model.Kind == ActivityKind.Loss7d)

            return BuildLoss7dRuleFormulaText(model, wageringMultiplier, null, null);

        if (model.Kind == ActivityKind.YesterdayLoss)

            return BuildYesterdayLossRuleFormulaText(model, wageringMultiplier);

        if (model.Kind == ActivityKind.OldCallback234)

            return BuildOldCallback234RuleFormulaText(model, wageringMultiplier);

        if (model.Kind == ActivityKind.ComprehensiveCallback)

            return BuildComprehensiveRuleFormulaText(model, wageringMultiplier);



        var maxText = model.MaxBonus > 0 ? $"最高 {model.MaxBonus:N2}" : "最高不限";

        var profitText = model.AllowProfitMember

            ? $"盈利会员（充值-提现<0）固定 {model.MinBonus:N2}"

            : "盈利会员默认剔除";



        var ratePercent = model.Rate * 100m;

        return $"用户亏损/持平（充值-提现≥0）：(充值-提现)×{ratePercent:0.##}%÷{model.Divisor}，" +

               $"最低 {model.MinBonus:N2}，{maxText}；{profitText}；打码 {wageringMultiplier:N2}。";

    }



    public static string BuildLoss7dRuleFormulaText(

        ActivityEditModel model,

        decimal wageringMultiplier,

        DateOnly? calculationDate,

        ActivityTimezone? timezone)

    {

        var tz = timezone ?? model.DefaultTimezone;

        var date = ActivityTimezoneHelper.ResolveCalculationDate(calculationDate, tz);

        var dayRate = model.WeeklyDayRates.GetRate(date.DayOfWeek);

        var rateText = dayRate is null or <= 0

            ? "未配置"

            : $"{RuleEngine.FormatRatePercentText(dayRate.Value)}%";

        var lossText = model.FilterLossMember

            ? "启用亏损过滤（累计充值-累计提现≥0）"

            : "默认不筛亏损";

        var unclaimedText = model.FilterUnclaimedEnabled

            ? "启用未领过滤"

            : "未启用未领过滤";



        return $"{ActivityDefaults.Loss7dActivityName}：彩金=累计充值×{ActivityTimezoneHelper.FormatWeekday(date.DayOfWeek)}比例（{rateText}），" +

               $"最低 {model.MinBonus:N2}；{lossText}；{unclaimedText}；计算日 {date:yyyy-MM-dd}（{ActivityTimezoneHelper.FormatWeekday(date.DayOfWeek)} · {ActivityTimezoneHelper.FormatTimezone(tz)}）；打码 {wageringMultiplier:N2}。";

    }

    public static string BuildYesterdayLossRuleFormulaText(ActivityEditModel model, decimal wageringMultiplier)
    {
        var tierText = RuleEngine.FormatTieredRatesText(model.TieredAmountRates);
        var unclaimedText = model.FilterUnclaimedEnabled
            ? "启用未领过滤"
            : "未启用未领过滤";

        return $"{ActivityDefaults.YesterdayLossActivityName}：彩金=当日充提差×派送比例（{tierText}），" +
               $"充提差≥{model.MinNetDiff:N2} 才计算，最低彩金 {model.MinBonus:N2}；{unclaimedText}；打码 {wageringMultiplier:N2}。";
    }

    public static string BuildOldCallback234RuleFormulaText(ActivityEditModel model, decimal wageringMultiplier)
    {
        var tierText = RuleEngine.FormatTieredFixedBonusesText(model.TieredFixedBonuses);
        var unclaimedText = model.FilterUnclaimedEnabled ? "启用未领过滤" : "未启用未领过滤";
        var rechargeText = model.FilterRechargeEnabled ? "启用充值数据过滤" : "未启用充值数据过滤";
        var profitText = model.AllowProfitMember
            ? $"盈利会员固定 {model.MinBonus:N2}"
            : "盈利会员默认剔除";
        var netDiffText = model.UseNetDiffColumn ? "直接使用 I 列充提差" : "F 列充值 - H 列提现";

        return $"{ActivityDefaults.OldCallback234ActivityName}：盈亏={netDiffText}（负=盈利，正=亏损）；" +
               $"Q 列保留 0～{model.InactiveDaysMax} 天未登录；亏损派送（{tierText}）；{profitText}；{unclaimedText}；{rechargeText}；打码 {wageringMultiplier:N2}。";
    }

    public static string BuildComprehensiveRuleFormulaText(ActivityEditModel model, decimal wageringMultiplier)
    {
        var modeText = FormatComprehensiveBonusMode(model.ComprehensiveFeatures.BonusMode);
        var unclaimedText = model.FilterUnclaimedEnabled ? "启用未领过滤" : "未启用未领过滤";
        var rechargeText = model.FilterRechargeEnabled ? "启用充值数据过滤" : "未启用充值数据过滤";
        var inactiveText = model.ComprehensiveFeatures.EnableInactiveDaysFilter
            ? $"启用 Q 列 0～{model.InactiveDaysMax} 天未登录过滤"
            : "未启用未登录过滤";
        var minNetDiffText = model.ComprehensiveFeatures.EnableMinNetDiffGate
            ? $"启用充提差≥{model.MinNetDiff:N2} 门槛"
            : "未启用充提差门槛";
        var lossText = model.FilterLossMember ? "启用亏损过滤" : "未启用亏损过滤";
        var profitText = model.AllowProfitMember
            ? $"允许盈利会员（固定 {model.MinBonus:N2}）"
            : "盈利会员默认剔除";

        return $"{ActivityDefaults.ComprehensiveCallbackActivityName}：计算方式={modeText}；{inactiveText}；{minNetDiffText}；{lossText}；{unclaimedText}；{rechargeText}；{profitText}；打码 {wageringMultiplier:N2}。";
    }

    public static string FormatComprehensiveBonusMode(ComprehensiveBonusMode mode) => mode switch
    {
        ComprehensiveBonusMode.StandardMerged => "时段彩金（合并派奖）",
        ComprehensiveBonusMode.StandardSplit => "回访彩金（拆分派奖）",
        ComprehensiveBonusMode.Loss7dWeekly => "老回访1567（累计充值×日比例）",
        ComprehensiveBonusMode.YesterdayLossTiered => "昨日亏损（充提差×比例）",
        ComprehensiveBonusMode.OldCallback234Fixed => "老回访234（固定金额档位）",
        _ => "未配置"
    };

    /// <summary>批量页 bootstrap：勾选盈利会员时，时段/1567/234/昨日亏损与回访彩金一样拆分展示。</summary>
    public static bool ResolveBootstrapUsesSplitRewards(BatchPageModeDto pageMode, ActivityEditModel model) =>
        pageMode switch
        {
            BatchPageModeDto.Callback => true,
            BatchPageModeDto.Period
                or BatchPageModeDto.Loss7d
                or BatchPageModeDto.YesterdayLoss
                or BatchPageModeDto.OldCallback234 => model.AllowProfitMember,
            BatchPageModeDto.ComprehensiveCallback =>
                model.ComprehensiveFeatures.BonusMode == ComprehensiveBonusMode.StandardSplit
                || (model.AllowProfitMember && model.ComprehensiveFeatures.BonusMode
                    is ComprehensiveBonusMode.StandardMerged
                        or ComprehensiveBonusMode.Loss7dWeekly
                        or ComprehensiveBonusMode.YesterdayLossTiered
                        or ComprehensiveBonusMode.OldCallback234Fixed),
            _ => false
        };

}



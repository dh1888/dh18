using System.Reflection;
using System.IO;
using Microsoft.EntityFrameworkCore;
using DHPG.Common;
using DHPG.Data;

namespace DHPG.Services;

/// <summary>
/// 数据处理编排：读文件 → 过滤 → RuleEngine → ProcessResult → 写历史。
/// ProcessView 唯一入口的后端。
/// </summary>
public class ProcessService
{
    private const int ProgressReportInterval = 2000;

    private readonly IDbContextFactory<AppDbContext> _dbFactory;
    private readonly ExcelService _excelService;
    private readonly ResultRepository _resultRepository;

    public ProcessService(
        IDbContextFactory<AppDbContext> dbFactory,
        ExcelService excelService,
        ResultRepository? resultRepository = null)
    {
        _dbFactory = dbFactory;
        _excelService = excelService;
        _resultRepository = resultRepository ?? new ResultRepository();
    }

    /// <summary>执行完整处理流程（async + CT + Progress）</summary>
    public Task<ProcessResult> ProcessAsync(
        ProcessRequest request,
        IProgress<ProcessProgress>? progress = null,
        CancellationToken cancellationToken = default) =>
        ProcessCoreAsync(request, progress, cancellationToken, batchCache: null);

    /// <summary>批量站点处理：顺序调用 ProcessAsync，单站失败不中断整批。</summary>
    public async Task<BatchProcessResult> ProcessBatchAsync(
        BatchProcessRequest request,
        IProgress<BatchProcessProgress>? batchProgress = null,
        IProgress<ProcessProgress>? siteProgress = null,
        CancellationToken cancellationToken = default)
    {
        ValidateBatchRequest(request);

        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);

        var activity = await db.Activities.AsNoTracking()
            .Include(a => a.ColumnMapping)
            .FirstOrDefaultAsync(a => a.Id == request.ActivityId && a.IsEnabled, cancellationToken)
            ?? throw new InvalidOperationException("活动不存在或已禁用。");

        var activityMapping = activity.ColumnMapping?.ToSiteMappingConfig() ?? new SiteMappingConfig();

        var settings = await db.AppSettings.AsNoTracking().FirstAsync(cancellationToken);
        var batchRuntime = Extensions.MergeRuntimeParams(
            activity,
            settings,
            request.WageringMultiplier > 0 ? request.WageringMultiplier : null,
            request.AppRemark,
            request.BackendRemark);

        if (string.IsNullOrWhiteSpace(batchRuntime.AppRemark))
            batchRuntime.AppRemark = activity.AppRemark;
        if (string.IsNullOrWhiteSpace(batchRuntime.BackendRemark))
            batchRuntime.BackendRemark = activity.BackendRemark;
        if (batchRuntime.WageringMultiplier <= 0)
            batchRuntime.WageringMultiplier = activity.DefaultWageringMultiplier;

        if (activity.Kind == ActivityKind.Loss7d
            || (activity.Kind == ActivityKind.ComprehensiveCallback
                && batchRuntime.ComprehensiveFeatures.BonusMode == ComprehensiveBonusMode.Loss7dWeekly))
        {
            batchRuntime.CalculationDate = ActivityTimezoneHelper.ResolveCalculationDate(
                request.CalculationDate,
                request.Timezone);
            batchRuntime.ResolvedDayRate = batchRuntime.WeeklyDayRates.GetRate(
                batchRuntime.CalculationDate.Value.DayOfWeek);
        }

        var siteIds = request.Tasks.Select(t => t.SiteId).Distinct().ToList();
        var sites = await db.Sites.AsNoTracking()
            .Where(s => siteIds.Contains(s.Id))
            .ToDictionaryAsync(s => s.Id, cancellationToken);

        EnrichTaskSiteInfo(request.Tasks, sites);

        var batchCache = new BatchProcessCache
        {
            Activity = activity,
            ActivityMapping = activityMapping,
            BatchRuntime = batchRuntime,
            SnapshotFilterTierKeywords = Extensions.ParseTierKeywords(activity.FilterTierKeywords).ToList(),
            SitesById = sites,
            UnclaimedIdsCache = request.FilterUnclaimed
                ? new Dictionary<string, HashSet<long>>(StringComparer.OrdinalIgnoreCase)
                : null,
            RechargeAmountsCache = request.FilterRecharge
                ? new Dictionary<string, Dictionary<long, decimal>>(StringComparer.OrdinalIgnoreCase)
                : null,
            PendingHistoryResults = request.SaveToHistory ? new List<ProcessResult>() : null
        };

        var startedAt = DateTime.Now;
        var tasks = request.Tasks;
        var total = tasks.Count;
        var successCount = 0;
        var failedCount = 0;
        var totalBonus = 0m;

        foreach (var task in tasks)
        {
            task.Status = BatchTaskStatus.Pending;
            task.ErrorMessage = null;
            task.ClearOutcome();
        }

        for (var i = 0; i < total; i++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var task = tasks[i];
            batchProgress?.Report(new BatchProcessProgress
            {
                CurrentIndex = i + 1,
                TotalTasks = total,
                CurrentSiteName = task.SiteName,
                Phase = "处理中",
                Message = $"正在处理 {task.SiteName} ({i + 1}/{total})"
            });

            task.Status = BatchTaskStatus.Processing;

            try
            {
                var processRequest = new ProcessRequest
                {
                    SiteId = task.SiteId,
                    ActivityId = request.ActivityId,
                    MemberFilePath = task.MemberFilePath!,
                    UnclaimedFilePath = task.UnclaimedFilePath,
                    RechargeFilePath = task.RechargeFilePath,
                    FilterUnclaimed = request.FilterUnclaimed,
                    FilterRecharge = request.FilterRecharge,
                    IncludeProfitMember = request.IncludeProfitMember,
                    WageringMultiplier = request.WageringMultiplier,
                    AppRemark = request.AppRemark,
                    BackendRemark = request.BackendRemark,
                    SaveToHistory = request.SaveToHistory,
                    ColumnMappingOverride = task.ColumnMappingOverride,
                    MappingProfile = task.MappingProfile,
                    UnclaimedUserIdColumnOverride = task.UnclaimedUserIdColumnOverride,
                    CalculationDate = request.CalculationDate,
                    Timezone = request.Timezone
                };

                var result = await ProcessCoreAsync(processRequest, siteProgress, cancellationToken, batchCache);
                task.AttachCacheOutcome(result);
                task.Status = BatchTaskStatus.Success;
                successCount++;
                totalBonus += result.Summary.TotalBonus;
            }
            catch (OperationCanceledException)
            {
                task.Status = BatchTaskStatus.Cancelled;
                task.ErrorMessage = "已取消";
                throw;
            }
            catch (Exception ex)
            {
                task.Status = BatchTaskStatus.Failed;
                task.ErrorMessage = ex.Message;
                failedCount++;
            }
        }

        if (request.SaveToHistory && batchCache.PendingHistoryResults is { Count: > 0 })
            await SaveHistoryBatchAsync(batchCache.PendingHistoryResults, cancellationToken);

        batchProgress?.Report(new BatchProcessProgress
        {
            CurrentIndex = total,
            TotalTasks = total,
            Phase = "完成",
            Message = $"批量完成：成功 {successCount}，失败 {failedCount}"
        });

        return new BatchProcessResult
        {
            ActivityId = request.ActivityId,
            ActivityName = activity.Name,
            StartedAt = startedAt,
            FinishedAt = DateTime.Now,
            SuccessCount = successCount,
            FailedCount = failedCount,
            TotalBonusAllSites = Math.Round(totalBonus, 2, MidpointRounding.AwayFromZero),
            Tasks = tasks
        };
    }

    /// <summary>将 ProcessResult 写入 ProcessHistories（含 SnapshotJson）</summary>
    public async Task<int> SaveHistoryAsync(
        ProcessResult result,
        CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var entity = CreateHistoryEntity(result);
        db.ProcessHistories.Add(entity);
        await db.SaveChangesAsync(cancellationToken);
        return entity.Id;
    }

    /// <summary>批量写入历史（单事务，减少 SQLite 往返）。</summary>
    public async Task SaveHistoryBatchAsync(
        IReadOnlyList<ProcessResult> results,
        CancellationToken cancellationToken = default)
    {
        if (results.Count == 0)
            return;

        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        for (var i = 0; i < results.Count; i++)
            db.ProcessHistories.Add(CreateHistoryEntity(results[i]));

        await db.SaveChangesAsync(cancellationToken);
    }

    /// <summary>收集历史快照中仍引用的 ResultCacheKey，供缓存清理保护。</summary>
    public async Task<HashSet<string>> GetProtectedResultCacheKeysAsync(
        int take = 500,
        CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var snapshotJsons = await db.ProcessHistories.AsNoTracking()
            .OrderByDescending(h => h.ProcessedAt)
            .Take(take)
            .Select(h => h.SnapshotJson)
            .ToListAsync(cancellationToken);

        var keys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < snapshotJsons.Count; i++)
        {
            var snapshot = Extensions.DeserializeSnapshot(snapshotJsons[i]);
            if (!string.IsNullOrEmpty(snapshot?.ResultCacheKey))
                keys.Add(snapshot.ResultCacheKey);
        }

        return keys;
    }

    /// <summary>清理过期结果缓存（保留历史引用的键）。</summary>
    public async Task<int> CleanupExpiredResultCachesAsync(
        TimeSpan? maxAge = null,
        CancellationToken cancellationToken = default)
    {
        var protectedKeys = await GetProtectedResultCacheKeysAsync(cancellationToken: cancellationToken);
        return _resultRepository.CleanupExpired(maxAge, protectedKeys);
    }

    private static ProcessHistory CreateHistoryEntity(ProcessResult result) => new()
    {
        ProcessedAt = result.ProcessedAt,
        SiteId = result.SiteId,
        SiteName = result.SiteName,
        ActivityId = result.ActivityId,
        ActivityName = result.ActivityName,
        TotalCount = result.Summary.TotalCount,
        FilteredCount = result.Summary.FilteredCount,
        RewardCount = result.Summary.RewardCount,
        TotalBonus = result.Summary.TotalBonus,
        SnapshotJson = Extensions.SerializeSnapshot(result.Snapshot),
        ExportFilePath = result.ExportFilePath
    };

    /// <summary>首页 / 历史列表</summary>
    public async Task<List<HistoryListItem>> GetHistoriesAsync(
        int? siteId = null,
        int take = 50,
        CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var query = db.ProcessHistories.AsNoTracking().AsQueryable();
        if (siteId.HasValue)
            query = query.Where(h => h.SiteId == siteId.Value);

        var items = await query
            .OrderByDescending(h => h.ProcessedAt)
            .Take(take)
            .ToListAsync(cancellationToken);

        return items.Select(h => h.ToListItem()).ToList();
    }

    /// <summary>历史详情（只读快照）</summary>
    public async Task<HistoryDetailModel?> GetHistoryDetailAsync(
        int historyId,
        CancellationToken cancellationToken = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var history = await db.ProcessHistories.AsNoTracking()
            .FirstOrDefaultAsync(h => h.Id == historyId, cancellationToken);
        if (history is null)
            return null;

        var snapshot = Extensions.DeserializeSnapshot(history.SnapshotJson) ?? new ProcessSnapshot();

        return new HistoryDetailModel
        {
            Id = history.Id,
            ProcessedAt = history.ProcessedAt,
            SiteName = history.SiteName,
            ActivityName = history.ActivityName,
            Summary = MergeHistorySummary(history, snapshot),
            Snapshot = snapshot,
            ExportFilePath = history.ExportFilePath
        };
    }

    private static ProcessSummary MergeHistorySummary(ProcessHistory history, ProcessSnapshot snapshot)
    {
        if (snapshot.Summary.TotalCount > 0 || snapshot.Summary.RewardCount > 0)
            return snapshot.Summary;

        return new ProcessSummary
        {
            TotalCount = history.TotalCount,
            FilteredCount = history.FilteredCount,
            RewardCount = history.RewardCount,
            TotalBonus = history.TotalBonus
        };
    }

    /// <summary>Dashboard 统计</summary>
    public async Task<DashboardStats> GetDashboardStatsAsync(CancellationToken cancellationToken = default)
    {
        var today = DateTime.Today;
        var tomorrow = today.AddDays(1);
        var version = Assembly.GetExecutingAssembly().GetName().Version;

        var siteCountTask = CountSitesAsync(cancellationToken);
        var activityCountTask = CountActivitiesAsync(cancellationToken);
        var todayCountTask = CountTodayHistoriesAsync(today, tomorrow, cancellationToken);
        var recentTask = LoadRecentHistoriesAsync(cancellationToken);

        await Task.WhenAll(siteCountTask, activityCountTask, todayCountTask, recentTask);

        return new DashboardStats
        {
            Version = version is null ? "0.1.0" : $"{version.Major}.{version.Minor}.{version.Build}",
            SiteCount = await siteCountTask,
            ActivityCount = await activityCountTask,
            TodayProcessCount = await todayCountTask,
            RecentHistories = await recentTask
        };
    }

    private async Task<int> CountSitesAsync(CancellationToken cancellationToken)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        return await db.Sites.CountAsync(cancellationToken);
    }

    private async Task<int> CountActivitiesAsync(CancellationToken cancellationToken)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        return await db.Activities.CountAsync(cancellationToken);
    }

    private async Task<int> CountTodayHistoriesAsync(
        DateTime today,
        DateTime tomorrow,
        CancellationToken cancellationToken)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        return await db.ProcessHistories.CountAsync(
            h => h.ProcessedAt >= today && h.ProcessedAt < tomorrow,
            cancellationToken);
    }

    private async Task<List<HistoryListItem>> LoadRecentHistoriesAsync(CancellationToken cancellationToken)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);
        var recent = await db.ProcessHistories.AsNoTracking()
            .OrderByDescending(h => h.ProcessedAt)
            .Take(10)
            .ToListAsync(cancellationToken);

        return recent.Select(h => h.ToListItem()).ToList();
    }

    private static void ValidateRequest(ProcessRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.MemberFilePath))
            throw new ArgumentException("请先上传会员文件。");

        if (!File.Exists(request.MemberFilePath))
            throw new FileNotFoundException("找不到会员文件。", request.MemberFilePath);

        if (request.FilterUnclaimed && string.IsNullOrWhiteSpace(request.UnclaimedFilePath))
            throw new ArgumentException("已勾选过滤未领彩金，请上传未领名单。");

        if (request.FilterUnclaimed && !File.Exists(request.UnclaimedFilePath!))
            throw new FileNotFoundException("找不到未领名单文件。", request.UnclaimedFilePath);

        if (request.FilterRecharge && string.IsNullOrWhiteSpace(request.RechargeFilePath))
            throw new ArgumentException("已勾选过滤充值数据，请上传充值文件。");

        if (request.FilterRecharge && !File.Exists(request.RechargeFilePath!))
            throw new FileNotFoundException("找不到充值数据文件。", request.RechargeFilePath);
    }

    private static void ValidateBatchRequest(BatchProcessRequest request)
    {
        if (request.ActivityId <= 0)
            throw new ArgumentException("请选择活动。");

        if (request.Tasks.Count == 0)
            throw new ArgumentException("请至少添加一个站点任务。");

        var duplicateSite = request.Tasks
            .GroupBy(t => t.SiteId)
            .FirstOrDefault(g => g.Key > 0 && g.Count() > 1);
        if (duplicateSite is not null)
            throw new ArgumentException("同一批次中站点不可重复。");

        foreach (var task in request.Tasks)
        {
            if (task.SiteId <= 0)
                throw new ArgumentException("请选择站点。");

            if (string.IsNullOrWhiteSpace(task.MemberFilePath))
                throw new ArgumentException("每行任务必须上传会员文件。");

            if (!File.Exists(task.MemberFilePath))
                throw new FileNotFoundException("找不到会员文件。", task.MemberFilePath);

            if (!request.FilterUnclaimed)
                continue;

            if (string.IsNullOrWhiteSpace(task.UnclaimedFilePath))
                throw new ArgumentException("已勾选过滤未领彩金，每行必须上传未领名单。");

            if (!File.Exists(task.UnclaimedFilePath))
                throw new FileNotFoundException("找不到未领名单文件。", task.UnclaimedFilePath);
        }

        if (!request.FilterRecharge)
            return;

        foreach (var task in request.Tasks)
        {
            if (string.IsNullOrWhiteSpace(task.RechargeFilePath))
                throw new ArgumentException("已勾选过滤充值数据，每行必须上传充值文件。");

            if (!File.Exists(task.RechargeFilePath))
                throw new FileNotFoundException("找不到充值数据文件。", task.RechargeFilePath);
        }
    }

    private async Task<ProcessResult> ProcessCoreAsync(
        ProcessRequest request,
        IProgress<ProcessProgress>? progress,
        CancellationToken cancellationToken,
        BatchProcessCache? batchCache)
    {
        ValidateRequest(request);
        var context = await LoadContextAsync(request, cancellationToken, batchCache);

        var result = await Task.Run(
            () => ExecuteProcess(context, progress, cancellationToken),
            cancellationToken);

        if (request.SaveToHistory)
        {
            if (batchCache?.PendingHistoryResults is not null)
                batchCache.PendingHistoryResults.Add(result);
            else
                await SaveHistoryAsync(result, cancellationToken);
        }

        return result;
    }

    private static void EnrichTaskSiteInfo(
        List<BatchSiteTask> tasks,
        IReadOnlyDictionary<int, Site> sites)
    {
        foreach (var task in tasks)
        {
            if (!sites.TryGetValue(task.SiteId, out var site))
                continue;

            task.SiteName = site.Name;
            task.SiteCode = site.Code;
        }
    }

    private async Task<ProcessContext> LoadContextAsync(
        ProcessRequest request,
        CancellationToken cancellationToken,
        BatchProcessCache? batchCache = null)
    {
        if (batchCache is not null)
            return BuildContextFromBatchCache(request, batchCache);

        await using var db = await _dbFactory.CreateDbContextAsync(cancellationToken);

        var site = await db.Sites.AsNoTracking()
            .FirstOrDefaultAsync(s => s.Id == request.SiteId && s.IsEnabled, cancellationToken)
            ?? throw new InvalidOperationException("站点不存在或已禁用。");

        var activity = await db.Activities.AsNoTracking()
            .Include(a => a.ColumnMapping)
            .FirstOrDefaultAsync(
                a => a.Id == request.ActivityId && a.IsEnabled,
                cancellationToken)
            ?? throw new InvalidOperationException("活动不存在或已禁用。");

        var activityMapping = activity.ColumnMapping?.ToSiteMappingConfig() ?? new SiteMappingConfig();
        var settings = await db.AppSettings.AsNoTracking().FirstAsync(cancellationToken);
        var runtime = BuildRuntimeParams(activity, settings, request);

        return BuildProcessContext(request, site, activity, runtime, activityMapping);
    }

    private static ProcessContext BuildContextFromBatchCache(
        ProcessRequest request,
        BatchProcessCache batchCache)
    {
        if (!batchCache.SitesById.TryGetValue(request.SiteId, out var site) || !site.IsEnabled)
            throw new InvalidOperationException("站点不存在或已禁用。");

        if (request.ActivityId != batchCache.Activity.Id)
            throw new InvalidOperationException("活动不存在或已禁用。");

        return BuildProcessContext(
            request,
            site,
            batchCache.Activity,
            batchCache.BatchRuntime,
            batchCache.ActivityMapping,
            batchCache.SnapshotFilterTierKeywords,
            batchCache.UnclaimedIdsCache,
            batchCache.RechargeAmountsCache);
    }

    private static ActivityRuntimeParams BuildRuntimeParams(
        Activity activity,
        AppSettings settings,
        ProcessRequest request)
    {
        var runtime = Extensions.MergeRuntimeParams(
            activity,
            settings,
            request.WageringMultiplier > 0 ? request.WageringMultiplier : null,
            request.AppRemark,
            request.BackendRemark);

        if (string.IsNullOrWhiteSpace(runtime.AppRemark))
            runtime.AppRemark = activity.AppRemark;
        if (string.IsNullOrWhiteSpace(runtime.BackendRemark))
            runtime.BackendRemark = activity.BackendRemark;
        if (runtime.WageringMultiplier <= 0)
            runtime.WageringMultiplier = activity.DefaultWageringMultiplier;

        if (activity.Kind == ActivityKind.Loss7d
            || (activity.Kind == ActivityKind.ComprehensiveCallback
                && runtime.ComprehensiveFeatures.BonusMode == ComprehensiveBonusMode.Loss7dWeekly))
        {
            var timezone = request.Timezone != default
                ? request.Timezone
                : runtime.DefaultTimezone;
            runtime.CalculationDate = ActivityTimezoneHelper.ResolveCalculationDate(
                request.CalculationDate,
                timezone);
            runtime.ResolvedDayRate = runtime.WeeklyDayRates.GetRate(
                runtime.CalculationDate.Value.DayOfWeek);
        }

        return runtime;
    }

    private static ProcessContext BuildProcessContext(
        ProcessRequest request,
        Site site,
        Activity activity,
        ActivityRuntimeParams runtime,
        SiteMappingConfig activityMapping,
        List<string>? snapshotFilterTierKeywords = null,
        Dictionary<string, HashSet<long>>? unclaimedIdsCache = null,
        Dictionary<string, Dictionary<long, decimal>>? rechargeAmountsCache = null) => new()
    {
        Request = request,
        Site = site,
        Activity = activity,
        Mapping = request.ColumnMappingOverride
            ?? activityMapping.ResolveMemberMapping(request.MappingProfile),
        RechargeMapping = activityMapping.Recharge,
        UnclaimedUserIdColumn = request.UnclaimedUserIdColumnOverride
            ?? activityMapping.UnclaimedUserIdColumn,
        Runtime = runtime,
        IncludeProfitMember = request.IncludeProfitMember ?? activity.AllowProfitMember,
        SnapshotFilterTierKeywords = snapshotFilterTierKeywords
            ?? Extensions.ParseTierKeywords(activity.FilterTierKeywords).ToList(),
        UnclaimedIdsCache = unclaimedIdsCache,
        RechargeAmountsCache = rechargeAmountsCache
    };

    private Dictionary<long, decimal>? LoadRechargeAmounts(ProcessContext context)
    {
        if (!context.Request.FilterRecharge)
            return null;

        if (string.IsNullOrWhiteSpace(context.Request.RechargeFilePath))
            return null;

        var cacheKey = BuildRechargeCacheKey(
            context.Request.RechargeFilePath,
            context.RechargeMapping);

        if (context.RechargeAmountsCache is not null
            && context.RechargeAmountsCache.TryGetValue(cacheKey, out var cached))
        {
            return cached;
        }

        var amounts = _excelService.ReadRechargeAmounts(
            context.Request.RechargeFilePath,
            context.RechargeMapping);
        context.RechargeAmountsCache?.Add(cacheKey, amounts);
        return amounts;
    }

    private ProcessResult ExecuteProcess(
        ProcessContext context,
        IProgress<ProcessProgress>? progress,
        CancellationToken cancellationToken)
    {
        progress?.Report(new ProcessProgress { Phase = "读取未领名单", Message = "正在加载..." });

        HashSet<long>? unclaimedIds = null;
        if (context.Request.FilterUnclaimed)
        {
            var unclaimedCacheKey = BuildUnclaimedCacheKey(
                context.Request.UnclaimedFilePath!,
                context.UnclaimedUserIdColumn);

            if (context.UnclaimedIdsCache is not null
                && context.UnclaimedIdsCache.TryGetValue(unclaimedCacheKey, out var cached))
            {
                unclaimedIds = cached;
            }
            else
            {
                unclaimedIds = _excelService.ReadUnclaimedIds(
                    context.Request.UnclaimedFilePath!,
                    context.UnclaimedUserIdColumn);
                context.UnclaimedIdsCache?.Add(unclaimedCacheKey, unclaimedIds);
            }
        }

        progress?.Report(new ProcessProgress { Phase = "读取充值数据", Message = "正在加载..." });
        var rechargeAmounts = LoadRechargeAmounts(context);

        progress?.Report(new ProcessProgress { Phase = "处理会员数据", Message = "正在读取并计算..." });

        var resultCacheKey = _resultRepository.CreateCacheKey();
        var session = _resultRepository.BeginWrite(resultCacheKey);
        var processed = 0;

        try
        {
            foreach (var row in _excelService.ReadMembers(context.Request.MemberFilePath, context.Mapping))
            {
                cancellationToken.ThrowIfCancellationRequested();
                processed++;

                if (processed % ProgressReportInterval == 0)
                {
                    progress?.Report(new ProcessProgress
                    {
                        Phase = "处理会员数据",
                        ProcessedRows = processed,
                        Message = $"已处理 {processed:N0} 行..."
                    });
                }

                ProcessRow(row, context, unclaimedIds, rechargeAmounts, session);
            }

            progress?.Report(new ProcessProgress
            {
                Phase = "完成",
                ProcessedRows = processed,
                TotalRows = processed,
                Message = $"处理完成，共 {processed:N0} 行"
            });

            var summary = BuildSummary(session, context);
            var snapshot = BuildSnapshot(context, summary, processedAt: DateTime.Now);
            return _resultRepository.Complete(
                session,
                summary,
                snapshot,
                context.UsesSplitRewards,
                context.Site.Id,
                context.Site.Name,
                context.Site.Code,
                context.Activity.Id,
                context.Activity.Name);
        }
        catch
        {
            session.Dispose();
            _resultRepository.Delete(resultCacheKey);
            throw;
        }
    }

    private void ProcessRow(
        MemberRow row,
        ProcessContext context,
        HashSet<long>? unclaimedIds,
        Dictionary<long, decimal>? rechargeAmounts,
        ResultWriteSession session)
    {
        var profit = RuleEngine.CalcProfit(row.Pay, row.Withdraw);
        var detail = new ProcessDetailItem
        {
            UserId = row.UserId,
            Phone = row.Phone,
            Pay = row.Pay,
            Withdraw = row.Withdraw,
            Profit = profit,
            Tier = row.Tier
        };

        if (RuleEngine.IsTierExcluded(row.Tier, context.Runtime.FilterTierKeywords))
        {
            detail.ExcludeReason = RuleEngine.FormatTierExcludeReason(row.Tier!);
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        if (context.Request.MappingProfile == MappingProfile.OldCallback234)
        {
            ProcessOldCallback234Row(row, context, unclaimedIds, rechargeAmounts, detail, session);
            return;
        }

        if (context.Request.MappingProfile == MappingProfile.ComprehensiveCallback)
        {
            ProcessComprehensiveRow(row, context, unclaimedIds, rechargeAmounts, detail, session);
            return;
        }

        if (unclaimedIds is not null && unclaimedIds.Contains(row.UserId))
        {
            detail.ExcludeReason = "在未领彩金名单";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        if (context.Request.MappingProfile == MappingProfile.Loss7d)
        {
            ProcessLoss7dRow(row, context, profit, detail, session);
            return;
        }

        if (context.Request.MappingProfile == MappingProfile.YesterdayLoss)
        {
            ProcessYesterdayLossRow(row, context, detail, session);
            return;
        }

        if (context.UsesSplitRewards)
        {
            ProcessSplitRewardRow(row, context, profit, detail, session);
            return;
        }

        var (bonus, isReward, excludeReason) = RuleEngine.ResolveBonus(
            profit,
            context.Runtime.Rate,
            context.Runtime.Divisor,
            context.Runtime.MinBonus,
            context.Runtime.MaxBonus,
            context.IncludeProfitMember);

        detail.Bonus = bonus;

        if (!isReward)
        {
            detail.ExcludeReason = excludeReason;
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        _resultRepository.AppendDetail(session, detail);
        _resultRepository.AppendReward(
            session,
            RewardStreamKind.Merged,
            CreateRewardItem(row.UserId, bonus, context));
    }

    private void ProcessSplitRewardRow(
        MemberRow row,
        ProcessContext context,
        decimal profit,
        ProcessDetailItem detail,
        ResultWriteSession session)
    {
        if (profit < 0)
        {
            if (!context.IncludeProfitMember)
            {
                detail.ExcludeReason = "过滤盈利会员";
                _resultRepository.AppendDetail(session, detail);
                return;
            }

            var bonus = RuleEngine.CalcProfitBonus(context.Runtime.MinBonus);
            detail.Bonus = bonus;
            _resultRepository.AppendDetail(session, detail);
            AppendContextReward(session, context, row.UserId, bonus, RewardStreamKind.Profit);
            return;
        }

        var lossBonus = RuleEngine.CalcLossBonus(
            profit,
            context.Runtime.Rate,
            context.Runtime.Divisor,
            context.Runtime.MinBonus,
            context.Runtime.MaxBonus);
        detail.Bonus = lossBonus;
        _resultRepository.AppendDetail(session, detail);
        AppendContextReward(session, context, row.UserId, lossBonus, RewardStreamKind.Loss);
    }

    private void ProcessLoss7dRow(
        MemberRow row,
        ProcessContext context,
        decimal profit,
        ProcessDetailItem detail,
        ResultWriteSession session)
    {
        if (profit < 0)
        {
            if (!context.IncludeProfitMember)
            {
                detail.ExcludeReason = "过滤盈利会员";
                _resultRepository.AppendDetail(session, detail);
                return;
            }

            var profitBonus = RuleEngine.CalcProfitBonus(context.Runtime.MinBonus);
            detail.Bonus = profitBonus;
            _resultRepository.AppendDetail(session, detail);
            AppendContextReward(session, context, row.UserId, profitBonus, RewardStreamKind.Profit);
            return;
        }

        var dayRate = context.Runtime.ResolvedDayRate;
        if (dayRate is null or <= 0)
        {
            detail.ExcludeReason = "当日未配置比例";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        var bonus = RuleEngine.CalcLoss7dBonus(row.Pay, dayRate.Value, context.Runtime.MinBonus);
        detail.Bonus = bonus;
        _resultRepository.AppendDetail(session, detail);
        AppendContextReward(session, context, row.UserId, bonus, RewardStreamKind.Loss);
    }

    private void ProcessYesterdayLossRow(
        MemberRow row,
        ProcessContext context,
        ProcessDetailItem detail,
        ResultWriteSession session)
    {
        var netDiff = Math.Round(row.NetDiff, 2, MidpointRounding.AwayFromZero);
        detail.Profit = netDiff;

        if (netDiff < 0m)
        {
            if (!context.IncludeProfitMember)
            {
                detail.ExcludeReason = "过滤盈利会员";
                _resultRepository.AppendDetail(session, detail);
                return;
            }

            var profitBonus = RuleEngine.CalcProfitBonus(context.Runtime.MinBonus);
            detail.Bonus = profitBonus;
            _resultRepository.AppendDetail(session, detail);
            AppendContextReward(session, context, row.UserId, profitBonus, RewardStreamKind.Profit);
            return;
        }

        if (netDiff < context.Runtime.MinNetDiff)
        {
            detail.ExcludeReason = "充提差低于最低门槛";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        var rate = context.Runtime.TieredAmountRates.ResolveRate(netDiff);
        if (rate is null or <= 0)
        {
            detail.ExcludeReason = "未匹配派送条件";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        var bonus = RuleEngine.CalcYesterdayLossBonus(netDiff, rate.Value, context.Runtime.MinBonus);
        detail.Bonus = bonus;
        _resultRepository.AppendDetail(session, detail);
        AppendContextReward(session, context, row.UserId, bonus, RewardStreamKind.Loss);
    }

    private void ProcessOldCallback234Row(
        MemberRow row,
        ProcessContext context,
        HashSet<long>? unclaimedIds,
        Dictionary<long, decimal>? rechargeAmounts,
        ProcessDetailItem detail,
        ResultWriteSession session)
    {
        if (!RuleEngine.PassesInactiveDaysFilter(row.InactiveDaysText, context.Runtime.InactiveDaysMax))
        {
            detail.ExcludeReason = "未登录天数不符合";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        if (unclaimedIds is not null && unclaimedIds.Contains(row.UserId))
        {
            detail.ExcludeReason = "在未领彩金名单";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        if (context.Request.FilterRecharge)
        {
            if (rechargeAmounts is null || !rechargeAmounts.TryGetValue(row.UserId, out var rechargePay))
            {
                detail.ExcludeReason = "不在充值数据";
                _resultRepository.AppendDetail(session, detail);
                return;
            }

            row.Pay = rechargePay;
            detail.Pay = row.Pay;
        }

        var netDiff = context.Runtime.UseNetDiffColumn
            ? Math.Round(row.NetDiff, 2, MidpointRounding.AwayFromZero)
            : RuleEngine.CalcProfit(row.Pay, row.Withdraw);
        detail.Profit = netDiff;

        if (netDiff == 0m)
        {
            detail.ExcludeReason = "盈亏为0";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        if (netDiff < 0m)
        {
            if (!context.IncludeProfitMember)
            {
                detail.ExcludeReason = "过滤盈利会员";
                _resultRepository.AppendDetail(session, detail);
                return;
            }

            var profitBonus = RuleEngine.CalcProfitBonus(context.Runtime.MinBonus);
            detail.Bonus = profitBonus;
            _resultRepository.AppendDetail(session, detail);
            AppendContextReward(session, context, row.UserId, profitBonus, RewardStreamKind.Profit);
            return;
        }

        var fixedBonus = context.Runtime.TieredFixedBonuses.ResolveBonus(netDiff);
        if (fixedBonus is null or <= 0m)
        {
            detail.ExcludeReason = "未匹配派送条件";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        detail.Bonus = fixedBonus.Value;
        _resultRepository.AppendDetail(session, detail);
        AppendContextReward(session, context, row.UserId, fixedBonus.Value, RewardStreamKind.Loss);
    }

    private void ProcessComprehensiveRow(
        MemberRow row,
        ProcessContext context,
        HashSet<long>? unclaimedIds,
        Dictionary<long, decimal>? rechargeAmounts,
        ProcessDetailItem detail,
        ResultWriteSession session)
    {
        var features = context.Runtime.ComprehensiveFeatures;

        if (features.EnableInactiveDaysFilter
            && !RuleEngine.PassesInactiveDaysFilter(row.InactiveDaysText, context.Runtime.InactiveDaysMax))
        {
            detail.ExcludeReason = "未登录天数不符合";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        if (unclaimedIds is not null && unclaimedIds.Contains(row.UserId))
        {
            detail.ExcludeReason = "在未领彩金名单";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        if (context.Request.FilterRecharge)
        {
            if (rechargeAmounts is null || !rechargeAmounts.TryGetValue(row.UserId, out var rechargePay))
            {
                detail.ExcludeReason = "不在充值数据";
                _resultRepository.AppendDetail(session, detail);
                return;
            }

            row.Pay = rechargePay;
            detail.Pay = row.Pay;
        }

        var useNetDiff = context.Runtime.UseNetDiffColumn
            || features.BonusMode is ComprehensiveBonusMode.YesterdayLossTiered
                or ComprehensiveBonusMode.OldCallback234Fixed;
        var profit = useNetDiff
            ? Math.Round(row.NetDiff, 2, MidpointRounding.AwayFromZero)
            : RuleEngine.CalcProfit(row.Pay, row.Withdraw);
        detail.Profit = profit;

        if (profit < 0 && !context.IncludeProfitMember)
        {
            detail.ExcludeReason = "过滤盈利会员";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        if (features.EnableMinNetDiffGate && profit >= 0 && profit < context.Runtime.MinNetDiff)
        {
            detail.ExcludeReason = "充提差低于最低门槛";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        switch (features.BonusMode)
        {
            case ComprehensiveBonusMode.StandardMerged:
                if (context.UsesSplitRewards)
                    ProcessSplitRewardRow(row, context, profit, detail, session);
                else
                    ProcessComprehensiveStandardMerged(row, context, profit, detail, session);
                return;
            case ComprehensiveBonusMode.StandardSplit:
                ProcessSplitRewardRow(row, context, profit, detail, session);
                return;
            case ComprehensiveBonusMode.Loss7dWeekly:
                ProcessLoss7dRow(row, context, profit, detail, session);
                return;
            case ComprehensiveBonusMode.YesterdayLossTiered:
                ProcessComprehensiveYesterdayLoss(row, context, profit, detail, session);
                return;
            case ComprehensiveBonusMode.OldCallback234Fixed:
                ProcessComprehensiveOldCallback234Bonus(row, context, profit, detail, session);
                return;
            default:
                detail.ExcludeReason = "未配置彩金计算方式";
                _resultRepository.AppendDetail(session, detail);
                return;
        }
    }

    private void ProcessComprehensiveStandardMerged(
        MemberRow row,
        ProcessContext context,
        decimal profit,
        ProcessDetailItem detail,
        ResultWriteSession session)
    {
        var (bonus, isReward, excludeReason) = RuleEngine.ResolveBonus(
            profit,
            context.Runtime.Rate,
            context.Runtime.Divisor,
            context.Runtime.MinBonus,
            context.Runtime.MaxBonus,
            context.IncludeProfitMember);

        detail.Bonus = bonus;
        if (!isReward)
        {
            detail.ExcludeReason = excludeReason;
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        _resultRepository.AppendDetail(session, detail);
        _resultRepository.AppendReward(
            session,
            RewardStreamKind.Merged,
            CreateRewardItem(row.UserId, bonus, context));
    }

    private void ProcessComprehensiveYesterdayLoss(
        MemberRow row,
        ProcessContext context,
        decimal netDiff,
        ProcessDetailItem detail,
        ResultWriteSession session)
    {
        if (netDiff < 0m)
        {
            if (!context.IncludeProfitMember)
            {
                detail.ExcludeReason = "过滤盈利会员";
                _resultRepository.AppendDetail(session, detail);
                return;
            }

            var profitBonus = RuleEngine.CalcProfitBonus(context.Runtime.MinBonus);
            detail.Bonus = profitBonus;
            _resultRepository.AppendDetail(session, detail);
            AppendContextReward(session, context, row.UserId, profitBonus, RewardStreamKind.Profit);
            return;
        }

        if (netDiff < context.Runtime.MinNetDiff)
        {
            detail.ExcludeReason = "充提差低于最低门槛";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        var rate = context.Runtime.TieredAmountRates.ResolveRate(netDiff);
        if (rate is null or <= 0)
        {
            detail.ExcludeReason = "未匹配派送条件";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        var bonus = RuleEngine.CalcYesterdayLossBonus(netDiff, rate.Value, context.Runtime.MinBonus);
        detail.Bonus = bonus;
        _resultRepository.AppendDetail(session, detail);
        AppendContextReward(session, context, row.UserId, bonus, RewardStreamKind.Loss);
    }

    private void ProcessComprehensiveOldCallback234Bonus(
        MemberRow row,
        ProcessContext context,
        decimal netDiff,
        ProcessDetailItem detail,
        ResultWriteSession session)
    {
        if (netDiff == 0m)
        {
            detail.ExcludeReason = "盈亏为0";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        if (netDiff < 0m)
        {
            if (!context.IncludeProfitMember)
            {
                detail.ExcludeReason = "过滤盈利会员";
                _resultRepository.AppendDetail(session, detail);
                return;
            }

            var profitBonus = RuleEngine.CalcProfitBonus(context.Runtime.MinBonus);
            detail.Bonus = profitBonus;
            _resultRepository.AppendDetail(session, detail);
            AppendContextReward(session, context, row.UserId, profitBonus, RewardStreamKind.Profit);
            return;
        }

        var fixedBonus = context.Runtime.TieredFixedBonuses.ResolveBonus(netDiff);
        if (fixedBonus is null or <= 0m)
        {
            detail.ExcludeReason = "未匹配派送条件";
            _resultRepository.AppendDetail(session, detail);
            return;
        }

        detail.Bonus = fixedBonus.Value;
        _resultRepository.AppendDetail(session, detail);
        AppendContextReward(session, context, row.UserId, fixedBonus.Value, RewardStreamKind.Loss);
    }

    private void AppendContextReward(
        ResultWriteSession session,
        ProcessContext context,
        long userId,
        decimal bonus,
        RewardStreamKind splitKind)
    {
        var kind = context.UsesSplitRewards ? splitKind : RewardStreamKind.Merged;
        _resultRepository.AppendReward(session, kind, CreateRewardItem(userId, bonus, context));
    }

    private static bool ResolveUsesSplitRewards(
        ProcessRequest request,
        ActivityRuntimeParams runtime,
        bool includeProfitMember)
    {
        if (request.MappingProfile == MappingProfile.Callback
            && runtime.Kind is not ActivityKind.Loss7d
                and not ActivityKind.YesterdayLoss
                and not ActivityKind.OldCallback234
                and not ActivityKind.ComprehensiveCallback)
            return true;

        if (request.MappingProfile == MappingProfile.ComprehensiveCallback)
        {
            if (runtime.ComprehensiveFeatures.BonusMode == ComprehensiveBonusMode.StandardSplit)
                return true;

            return includeProfitMember && runtime.ComprehensiveFeatures.BonusMode
                is ComprehensiveBonusMode.StandardMerged
                    or ComprehensiveBonusMode.Loss7dWeekly
                    or ComprehensiveBonusMode.YesterdayLossTiered
                    or ComprehensiveBonusMode.OldCallback234Fixed;
        }

        return includeProfitMember && request.MappingProfile
            is MappingProfile.Period
                or MappingProfile.Loss7d
                or MappingProfile.YesterdayLoss
                or MappingProfile.OldCallback234;
    }

    private static RewardItem CreateRewardItem(long userId, decimal bonus, ProcessContext context) => new()
    {
        UserId = userId,
        Bonus = bonus,
        WageringMultiplier = context.Runtime.WageringMultiplier,
        AppRemark = context.Runtime.AppRemark,
        BackendRemark = context.Runtime.BackendRemark
    };

    private static ProcessSummary BuildSummary(ResultWriteSession session, ProcessContext context)
    {
        if (context.UsesSplitRewards)
        {
            return new ProcessSummary
            {
                TotalCount = session.DetailSeq,
                FilteredCount = session.FilteredCount,
                LossRewardCount = session.LossRewardCount,
                ProfitRewardCount = session.ProfitRewardCount,
                LossTotalBonus = session.LossBonusTotal,
                ProfitTotalBonus = session.ProfitBonusTotal,
                RewardCount = session.LossRewardCount + session.ProfitRewardCount,
                TotalBonus = session.LossBonusTotal + session.ProfitBonusTotal
            };
        }

        return new ProcessSummary
        {
            TotalCount = session.DetailSeq,
            FilteredCount = session.FilteredCount,
            RewardCount = session.MergedRewardCount,
            TotalBonus = session.MergedBonusTotal
        };
    }

    private static ProcessSnapshot BuildSnapshot(
        ProcessContext context,
        ProcessSummary summary,
        DateTime processedAt) => new()
    {
        Version = 1,
        ProcessedAt = processedAt,
        Site = new SnapshotSiteInfo
        {
            Id = context.Site.Id,
            Name = context.Site.Name,
            Code = context.Site.Code
        },
        Activity = new SnapshotActivityInfo
        {
            Id = context.Activity.Id,
            Name = context.Activity.Name,
            Rate = context.Runtime.Rate,
            Divisor = context.Runtime.Divisor,
            MinBonus = context.Runtime.MinBonus,
            MaxBonus = context.Runtime.MaxBonus,
            AllowProfitMember = context.Activity.AllowProfitMember,
            FilterTierKeywords = context.SnapshotFilterTierKeywords,
            DefaultWageringMultiplier = context.Activity.DefaultWageringMultiplier,
            AppRemark = context.Activity.AppRemark,
            BackendRemark = context.Activity.BackendRemark
        },
        ColumnMapping = context.Mapping,
        ProcessOptions = new SnapshotProcessOptions
        {
            FilterUnclaimed = context.Request.FilterUnclaimed,
            IncludeProfitMember = context.IncludeProfitMember
        },
        RewardSettings = new SnapshotRewardSettings
        {
            WageringMultiplier = context.Runtime.WageringMultiplier,
            AppRemark = context.Runtime.AppRemark,
            BackendRemark = context.Runtime.BackendRemark
        },
        Summary = summary
    };

    private sealed class BatchProcessCache
    {
        public Activity Activity { get; init; } = null!;
        public SiteMappingConfig ActivityMapping { get; init; } = new();
        public ActivityRuntimeParams BatchRuntime { get; init; } = null!;
        public List<string> SnapshotFilterTierKeywords { get; init; } = new();
        public Dictionary<int, Site> SitesById { get; init; } = new();
        public Dictionary<string, HashSet<long>>? UnclaimedIdsCache { get; init; }
        public Dictionary<string, Dictionary<long, decimal>>? RechargeAmountsCache { get; init; }
        public List<ProcessResult>? PendingHistoryResults { get; init; }
    }

    private sealed class ProcessContext
    {
        public ProcessRequest Request { get; init; } = null!;
        public Site Site { get; init; } = null!;
        public Activity Activity { get; init; } = null!;
        public ColumnMappingInfo Mapping { get; init; } = null!;
        public RechargeMappingConfig RechargeMapping { get; init; } = new();
        public int UnclaimedUserIdColumn { get; init; }
        public ActivityRuntimeParams Runtime { get; init; } = null!;
        public bool IncludeProfitMember { get; init; }
        public List<string> SnapshotFilterTierKeywords { get; init; } = new();
        public Dictionary<string, HashSet<long>>? UnclaimedIdsCache { get; init; }
        public Dictionary<string, Dictionary<long, decimal>>? RechargeAmountsCache { get; init; }
        public bool UsesSplitRewards =>
            ResolveUsesSplitRewards(Request, Runtime, IncludeProfitMember);
    }

    private static string BuildUnclaimedCacheKey(string filePath, int userIdColumn) =>
        $"{Path.GetFullPath(filePath)}|{userIdColumn}";

    private static string BuildRechargeCacheKey(string filePath, RechargeMappingConfig mapping) =>
        $"{Path.GetFullPath(filePath)}|{mapping.UserIdColumn}|{mapping.AmountColumn}|{mapping.HeaderRow}";
}

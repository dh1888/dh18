using System.IO;
using Microsoft.AspNetCore.Http;
using DHPG.Common;

namespace DHPG.Services;

/// <summary>批量页上传文件暂存（WebView 原生选文件与 HTTP 上传共用）。</summary>
public static class BatchFileStaging
{
    public const long MaxUploadBytes = 200L * 1024 * 1024;

    public static string UploadDirectory => Path.Combine(App.AppDataDir, "uploads");

    public static FileUploadResultDto StageFromPath(string sourcePath)
    {
        if (string.IsNullOrWhiteSpace(sourcePath) || !File.Exists(sourcePath))
            throw new InvalidOperationException("文件不存在。");

        var fileName = Path.GetFileName(sourcePath);
        var ext = Path.GetExtension(fileName).ToLowerInvariant();
        ValidateExtension(ext);

        var length = new FileInfo(sourcePath).Length;
        ValidateSize(length);

        Directory.CreateDirectory(UploadDirectory);
        var storedName = $"{Guid.NewGuid():N}{ext}";
        var dest = Path.Combine(UploadDirectory, storedName);
        File.Copy(sourcePath, dest, overwrite: false);

        return new FileUploadResultDto
        {
            Path = dest,
            FileName = fileName
        };
    }

    public static async Task<FileUploadResultDto> StageFromUploadAsync(IFormFile file, CancellationToken cancellationToken = default)
    {
        if (file.Length == 0)
            throw new InvalidOperationException("未选择文件。");

        ValidateSize(file.Length);

        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        ValidateExtension(ext);

        Directory.CreateDirectory(UploadDirectory);
        var storedName = $"{Guid.NewGuid():N}{ext}";
        var dest = Path.Combine(UploadDirectory, storedName);
        await using (var stream = File.Create(dest))
            await file.CopyToAsync(stream, cancellationToken);

        return new FileUploadResultDto
        {
            Path = dest,
            FileName = file.FileName
        };
    }

    private static void ValidateExtension(string ext)
    {
        if (ext is not (".xlsx" or ".xls" or ".xlsm" or ".csv"))
            throw new InvalidOperationException("仅支持 .xlsx/.xls/.xlsm/.csv。");
    }

    private static void ValidateSize(long length)
    {
        if (length > MaxUploadBytes)
            throw new InvalidOperationException($"文件过大，单个文件不能超过 {MaxUploadBytes / (1024 * 1024)} MB。");
    }
}

using System.IO;
using System.Net;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using DHPG.Common;

namespace DHPG.Services;

/// <summary>本地 Kestrel 宿主：为 WebView2 批量页提供静态资源与 API。</summary>
public sealed class LocalApiHost : IAsyncDisposable
{
    /// <summary>批量页会员/未领/充值文件上传上限（默认 Kestrel 仅 30MB）。</summary>
    public const long MaxUploadBytes = BatchFileStaging.MaxUploadBytes;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        Converters = { new JsonStringEnumConverter(JsonNamingPolicy.CamelCase) }
    };

    private readonly BatchRunCoordinator _batchRun = new();
    private readonly SemaphoreSlim _startLock = new(1, 1);
    private WebApplication? _app;
    private readonly string _uploadDir;
    private readonly string _wwwRoot;

    public static LocalApiHost Instance { get; } = new();

    public int Port { get; private set; }
    public string BaseUrl => $"http://127.0.0.1:{Port}";
    public bool IsRunning => _app is not null;

    private LocalApiHost()
    {
        _uploadDir = BatchFileStaging.UploadDirectory;
        _wwwRoot = Path.Combine(AppContext.BaseDirectory, "wwwroot", "batch");
        Directory.CreateDirectory(_uploadDir);
    }

    public async Task StartAsync(CancellationToken cancellationToken = default)
    {
        if (_app is not null)
            return;

        await _startLock.WaitAsync(cancellationToken);
        try
        {
            if (_app is not null)
                return;

            await StartCoreAsync(cancellationToken);
        }
        finally
        {
            _startLock.Release();
        }
    }

    private async Task StartCoreAsync(CancellationToken cancellationToken)
    {
        Port = GetFreePort();
        var builder = WebApplication.CreateBuilder(new WebApplicationOptions
        {
            ApplicationName = typeof(LocalApiHost).Assembly.FullName,
            Args = Array.Empty<string>()
        });

        builder.WebHost.UseUrls($"http://127.0.0.1:{Port}");
        builder.WebHost.ConfigureKestrel(options =>
        {
            options.Limits.MaxRequestBodySize = MaxUploadBytes;
        });
        builder.Services.Configure<FormOptions>(options =>
        {
            options.MultipartBodyLengthLimit = MaxUploadBytes;
        });
        builder.Services.AddSingleton(_batchRun);
        builder.Services.AddSingleton(new ActivityService(App.DbContextFactory));
        builder.Services.AddSingleton(new ExcelService());
        builder.Services.AddSingleton(new ResultRepository());
        builder.Services.AddSingleton(sp =>
            new ProcessService(App.DbContextFactory, sp.GetRequiredService<ExcelService>(), sp.GetRequiredService<ResultRepository>()));
        builder.Services.AddSingleton(sp =>
            new ExportService(App.DbContextFactory, sp.GetRequiredService<ResultRepository>()));

        builder.Services.ConfigureHttpJsonOptions(options =>
        {
            options.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            options.SerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
            options.SerializerOptions.Converters.Add(new JsonStringEnumConverter(JsonNamingPolicy.CamelCase));
        });

        var app = builder.Build();

        app.Use(async (context, next) =>
        {
            context.Response.Headers["Cache-Control"] = "no-cache";
            try
            {
                await next();
            }
            catch (BadHttpRequestException ex) when (IsRequestBodyTooLarge(ex))
            {
                Serilog.Log.Warning(ex, "上传文件超过大小限制: {Path}", context.Request.Path);
                if (context.Response.HasStarted)
                    throw;

                context.Response.StatusCode = StatusCodes.Status413PayloadTooLarge;
                context.Response.ContentType = "application/json; charset=utf-8";
                await context.Response.WriteAsJsonAsync(
                    new { message = $"文件过大，单个文件不能超过 {MaxUploadBytes / (1024 * 1024)} MB。" },
                    JsonOptions,
                    context.RequestAborted);
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(ex, "本地 API 请求失败: {Path}", context.Request.Path);
                if (context.Response.HasStarted)
                    throw;

                context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                context.Response.ContentType = "application/json; charset=utf-8";
                await context.Response.WriteAsJsonAsync(
                    new { message = $"服务内部错误：{ex.Message}" },
                    JsonOptions,
                    context.RequestAborted);
            }
        });

        if (Directory.Exists(_wwwRoot))
        {
            var provider = new FileExtensionContentTypeProvider();
            provider.Mappings[".js"] = "application/javascript";
            provider.Mappings[".mjs"] = "application/javascript";
            provider.Mappings[".css"] = "text/css";
            provider.Mappings[".svg"] = "image/svg+xml";
            provider.Mappings[".woff2"] = "font/woff2";

            app.UseDefaultFiles(new DefaultFilesOptions
            {
                FileProvider = new PhysicalFileProvider(_wwwRoot),
                DefaultFileNames = ["index.html"]
            });
            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(_wwwRoot),
                ContentTypeProvider = provider
            });
        }

        MapApi(app);
        await app.StartAsync(cancellationToken);
        _app = app;
    }

    private void MapApi(WebApplication app)
    {
        app.MapGet("/api/batch/bootstrap", async (HttpContext ctx, ActivityService activityService, string mode) =>
        {
            var pageMode = ParseMode(mode);
            var activityName = pageMode switch
            {
                BatchPageModeDto.Callback => "回访彩金",
                BatchPageModeDto.Loss7d => ActivityDefaults.Loss7dActivityName,
                BatchPageModeDto.YesterdayLoss => ActivityDefaults.YesterdayLossActivityName,
                BatchPageModeDto.OldCallback234 => ActivityDefaults.OldCallback234ActivityName,
                BatchPageModeDto.ComprehensiveCallback => ActivityDefaults.ComprehensiveCallbackActivityName,
                _ => "时段彩金"
            };
            var activities = await activityService.GetActivitiesAsync(enabledOnly: false);
            var activityList = activities.FirstOrDefault(a => a.Name == activityName)
                ?? activities.FirstOrDefault(a => pageMode switch
                {
                    BatchPageModeDto.Loss7d => a.Kind == ActivityKind.Loss7d,
                    BatchPageModeDto.YesterdayLoss => a.Kind == ActivityKind.YesterdayLoss,
                    BatchPageModeDto.OldCallback234 => a.Kind == ActivityKind.OldCallback234,
                    BatchPageModeDto.ComprehensiveCallback => a.Kind == ActivityKind.ComprehensiveCallback,
                    BatchPageModeDto.Callback => a.Kind == ActivityKind.Callback || a.AllowProfitMember,
                    _ => a.Kind == ActivityKind.Period || !a.AllowProfitMember
                });

            if (activityList is null)
            {
                await WriteJson(ctx, Results.NotFound(new { message = $"未找到活动「{activityName}」。" }));
                return;
            }

            var model = await activityService.GetActivityAsync(activityList.Id);
            if (model is null)
            {
                await WriteJson(ctx, Results.NotFound(new { message = "活动不存在。" }));
                return;
            }

            var runtime = await activityService.GetRuntimeParamsAsync(activityList.Id);
            var (sites, _) = await activityService.GetSitesBundleAsync(enabledOnly: true);
            var wagering = runtime?.WageringMultiplier ?? model.DefaultWageringMultiplier;
            var defaultDate = ActivityTimezoneHelper.TodayInTimezone(model.DefaultTimezone);

            var dto = new BatchBootstrapDto
            {
                Mode = pageMode,
                ActivityId = activityList.Id,
                ActivityName = activityList.Name,
                ActivityKind = model.Kind,
                WeeklyDayRates = model.WeeklyDayRates,
                DefaultTimezone = model.DefaultTimezone,
                DefaultCalculationDate = defaultDate.ToString("yyyy-MM-dd"),
                FilterLossMember = model.FilterLossMember,
                FilterUnclaimedEnabled = model.FilterUnclaimedEnabled,
                MinNetDiff = model.MinNetDiff,
                TieredAmountRates = model.TieredAmountRates,
                InactiveDaysMax = model.InactiveDaysMax,
                UseNetDiffColumn = model.UseNetDiffColumn,
                FilterRechargeEnabled = model.FilterRechargeEnabled,
                TieredFixedBonuses = model.TieredFixedBonuses,
                ComprehensiveFeatures = model.ComprehensiveFeatures,
                RuleFormula = pageMode switch
                {
                    BatchPageModeDto.Loss7d => BatchApiMapper.BuildLoss7dRuleFormulaText(
                        model, wagering, defaultDate, model.DefaultTimezone),
                    BatchPageModeDto.YesterdayLoss => BatchApiMapper.BuildYesterdayLossRuleFormulaText(
                        model, wagering),
                    BatchPageModeDto.OldCallback234 => BatchApiMapper.BuildOldCallback234RuleFormulaText(
                        model, wagering),
                    BatchPageModeDto.ComprehensiveCallback => BatchApiMapper.BuildComprehensiveRuleFormulaText(
                        model, wagering),
                    _ => BatchApiMapper.BuildRuleFormulaText(model, wagering)
                },
                ActivityRule = new ActivityRuleDto
                {
                    Rate = model.Rate,
                    Divisor = model.Divisor,
                    MinBonus = model.MinBonus,
                    MaxBonus = model.MaxBonus,
                    AllowProfitMember = model.AllowProfitMember
                },
                UsesSplitRewards = BatchApiMapper.ResolveBootstrapUsesSplitRewards(pageMode, model),
                ActivityMapping = model.Mapping,
                Defaults = new BatchDefaultsDto
                {
                    FilterUnclaimed = pageMode switch
                    {
                        BatchPageModeDto.Loss7d => model.FilterUnclaimedEnabled,
                        BatchPageModeDto.YesterdayLoss => model.FilterUnclaimedEnabled,
                        BatchPageModeDto.OldCallback234 => model.FilterUnclaimedEnabled,
                        BatchPageModeDto.ComprehensiveCallback => model.FilterUnclaimedEnabled,
                        BatchPageModeDto.Callback => true,
                        _ => false
                    },
                    FilterRecharge = pageMode switch
                    {
                        BatchPageModeDto.OldCallback234 => model.FilterRechargeEnabled,
                        BatchPageModeDto.ComprehensiveCallback => model.FilterRechargeEnabled,
                        _ => false
                    },
                    IncludeProfitMember = model.AllowProfitMember,
                    WageringMultiplier = runtime?.WageringMultiplier ?? model.DefaultWageringMultiplier,
                    AppRemark = runtime?.AppRemark ?? string.Empty,
                    BackendRemark = runtime?.BackendRemark ?? string.Empty,
                    CalculationDate = defaultDate.ToString("yyyy-MM-dd"),
                    Timezone = model.DefaultTimezone
                },
                Sites = sites
            };

            await WriteJson(ctx, Results.Ok(dto));
        });

        app.MapGet("/api/sites", async (HttpContext ctx, ActivityService activityService) =>
        {
            var sites = await activityService.GetSitesAsync(enabledOnly: true);
            await WriteJson(ctx, Results.Ok(sites));
        });

        app.MapGet("/api/activities/{activityId:int}/mapping", async (HttpContext ctx, ActivityService activityService, int activityId) =>
        {
            var activity = await activityService.GetActivityAsync(activityId);
            if (activity is null)
            {
                await WriteJson(ctx, Results.NotFound(new { message = "活动不存在。" }));
                return;
            }

            await WriteJson(ctx, Results.Ok(activity.Mapping));
        });

        app.MapPut("/api/activities/{activityId:int}/mapping", async (HttpContext ctx, ActivityService activityService, int activityId) =>
        {
            var mapping = await ReadJson<SiteMappingConfig>(ctx);
            if (mapping is null)
            {
                await WriteJson(ctx, Results.BadRequest(new { message = "无效的映射数据。" }));
                return;
            }

            var activity = await activityService.GetActivityAsync(activityId);
            if (activity is null)
            {
                await WriteJson(ctx, Results.NotFound(new { message = "活动不存在。" }));
                return;
            }

            await activityService.SaveActivityMappingAsync(activityId, mapping);
            await WriteJson(ctx, Results.Ok(new { message = "列映射已保存到活动。" }));
        });

        app.MapGet("/api/sites/{siteId:int}/mapping", async (HttpContext ctx, ActivityService activityService, int siteId) =>
        {
            var site = await activityService.GetSiteAsync(siteId);
            if (site is null)
            {
                await WriteJson(ctx, Results.NotFound(new { message = "站点不存在。" }));
                return;
            }

            await WriteJson(ctx, Results.Ok(site.Mapping));
        });

        app.MapPut("/api/sites/{siteId:int}/mapping", async (HttpContext ctx, ActivityService activityService, int siteId) =>
        {
            var mapping = await ReadJson<SiteMappingConfig>(ctx);
            if (mapping is null)
            {
                await WriteJson(ctx, Results.BadRequest(new { message = "无效的映射数据。" }));
                return;
            }

            var site = await activityService.GetSiteAsync(siteId);
            if (site is null)
            {
                await WriteJson(ctx, Results.NotFound(new { message = "站点不存在。" }));
                return;
            }

            site.Mapping = mapping;
            await activityService.SaveSiteAsync(site);
            await WriteJson(ctx, Results.Ok(new { message = "列映射已保存。" }));
        });

        app.MapPost("/api/files/upload", async (HttpContext ctx) =>
        {
            if (!ctx.Request.HasFormContentType)
            {
                await WriteJson(ctx, Results.BadRequest(new { message = "请使用 multipart/form-data 上传。" }));
                return;
            }

            var form = await ctx.Request.ReadFormAsync(ctx.RequestAborted);
            var file = form.Files.FirstOrDefault();
            if (file is null)
            {
                await WriteJson(ctx, Results.BadRequest(new { message = "未选择文件。" }));
                return;
            }

            try
            {
                var result = await BatchFileStaging.StageFromUploadAsync(file, ctx.RequestAborted);
                await WriteJson(ctx, Results.Ok(result));
            }
            catch (InvalidOperationException ex)
            {
                var status = ex.Message.Contains("文件过大", StringComparison.Ordinal)
                    ? StatusCodes.Status413PayloadTooLarge
                    : StatusCodes.Status400BadRequest;
                await WriteJson(ctx, Results.Json(new { message = ex.Message }, statusCode: status));
            }
        });

        app.MapGet("/api/files/headers", async (HttpContext ctx, ExcelService excelService, string path, int headerRow) =>
        {
            if (string.IsNullOrWhiteSpace(path) || !IsAllowedPath(path))
            {
                await WriteJson(ctx, Results.BadRequest(new { message = "无效的文件路径。" }));
                return;
            }

            try
            {
                var headers = await excelService.PreviewHeadersAsync(path, headerRow, ctx.RequestAborted);
                await WriteJson(ctx, Results.Ok(headers));
            }
            catch (Exception ex)
            {
                await WriteJson(ctx, Results.BadRequest(new { message = ex.Message }));
            }
        });

        app.MapGet("/api/templates/member", () =>
        {
            var source = FindFixturePath("sample-demo.csv");
            return Results.File(source, "text/csv", "会员数据模板.csv");
        });

        app.MapPost("/api/batch/process", async (HttpContext ctx, ProcessService processService, BatchRunCoordinator coordinator) =>
        {
            var input = await ReadJson<BatchProcessInputDto>(ctx);
            if (input is null || input.Tasks.Count == 0)
            {
                await WriteJson(ctx, Results.BadRequest(new { message = "请至少添加一行任务。" }));
                return;
            }

            if (coordinator.GetStatus().Running)
            {
                await WriteJson(ctx, Results.Conflict(new { message = "已有批量任务正在运行。" }));
                return;
            }

            var profile = BatchApiMapper.ResolveMappingProfile(input.Mode);
            var request = BatchApiMapper.ToProcessRequest(input);

            _ = Task.Run(async () => await coordinator.StartAsync(request, processService).ConfigureAwait(false));
            ctx.Response.StatusCode = StatusCodes.Status202Accepted;
            await ctx.Response.WriteAsJsonAsync(new { message = "批量处理已开始。" }, JsonOptions, ctx.RequestAborted);
        });

        app.MapGet("/api/batch/status", async (HttpContext ctx, BatchRunCoordinator coordinator) =>
            await WriteJson(ctx, Results.Ok(coordinator.GetStatus())));

        app.MapPost("/api/batch/cancel", async (HttpContext ctx, BatchRunCoordinator coordinator) =>
        {
            coordinator.Cancel();
            await WriteJson(ctx, Results.Ok(new { message = "已请求取消。" }));
        });

        app.MapGet("/api/results/{cacheKey}/summary", async (HttpContext ctx, ResultRepository repository, string cacheKey) =>
        {
            if (!repository.Exists(cacheKey))
            {
                await WriteJson(ctx, Results.NotFound(new { message = "结果不存在。" }));
                return;
            }

            var result = repository.LoadSummary(cacheKey);
            var dto = new ResultSummaryDto
            {
                Summary = result.Summary,
                UsesSplitRewards = result.UsesSplitRewards,
                DetailCount = repository.CountDetails(cacheKey, excludedOnly: false),
                ExcludedCount = repository.CountDetails(cacheKey, excludedOnly: true),
                MergedRewardCount = repository.CountRewards(cacheKey, RewardStreamKind.Merged),
                LossRewardCount = repository.CountRewards(cacheKey, RewardStreamKind.Loss),
                ProfitRewardCount = repository.CountRewards(cacheKey, RewardStreamKind.Profit)
            };
            await WriteJson(ctx, Results.Ok(dto));
        });

        app.MapGet("/api/results/{cacheKey}/details", async (
            HttpContext ctx,
            ResultRepository repository,
            string cacheKey,
            int skip = 0,
            int take = 50,
            bool excludedOnly = false) =>
        {
            if (!repository.Exists(cacheKey))
            {
                await WriteJson(ctx, Results.NotFound(new { message = "结果不存在。" }));
                return;
            }

            take = Math.Clamp(take, 1, 500);
            var total = repository.CountDetails(cacheKey, excludedOnly);
            var items = repository.ReadDetailPage(cacheKey, skip, take, excludedOnly);
            await WriteJson(ctx, Results.Ok(new PagedDetailsDto { Total = total, Items = items }));
        });

        app.MapGet("/api/results/{cacheKey}/rewards", async (
            HttpContext ctx,
            ResultRepository repository,
            string cacheKey,
            string kind = "merged",
            int skip = 0,
            int take = 50) =>
        {
            if (!repository.Exists(cacheKey))
            {
                await WriteJson(ctx, Results.NotFound(new { message = "结果不存在。" }));
                return;
            }

            var streamKind = ParseRewardKind(kind);
            take = Math.Clamp(take, 1, 500);
            var total = repository.CountRewards(cacheKey, streamKind);
            var items = repository.ReadRewardPage(cacheKey, streamKind, skip, take);
            await WriteJson(ctx, Results.Ok(new PagedRewardsDto { Total = total, Items = items }));
        });

        app.MapPost("/api/export/excel", async (HttpContext ctx, ExportService exportService, ResultRepository repository) =>
        {
            var input = await ReadJson<ExportExcelInputDto>(ctx);
            if (input is null || string.IsNullOrWhiteSpace(input.CacheKey))
            {
                await WriteJson(ctx, Results.BadRequest(new { message = "缺少 cacheKey。" }));
                return;
            }

            if (!repository.Exists(input.CacheKey))
            {
                await WriteJson(ctx, Results.NotFound(new { message = "结果不存在。" }));
                return;
            }

            var result = repository.LoadSummary(input.CacheKey);
            var export = await exportService.ExportExcelAsync(result);
            await WriteJson(ctx, Results.Ok(export));
        });

        app.MapPost("/api/export/batch-all", async (HttpContext ctx, ExportService exportService) =>
        {
            var input = await ReadJson<ExportBatchAllInputDto>(ctx);
            if (input?.Result is null)
            {
                await WriteJson(ctx, Results.BadRequest(new { message = "缺少批量结果。" }));
                return;
            }

            var batch = BatchApiMapper.FromResultDto(input.Result);
            var export = await exportService.ExportBatchAllAsync(batch);
            await WriteJson(ctx, Results.Ok(export));
        });

        app.MapPost("/api/export/rewards-tsv", async (HttpContext ctx, ResultRepository repository) =>
        {
            var input = await ReadJson<CopyRewardsInputDto>(ctx);
            if (input is null || string.IsNullOrWhiteSpace(input.CacheKey))
            {
                await WriteJson(ctx, Results.BadRequest(new { message = "缺少 cacheKey。" }));
                return;
            }

            if (!repository.Exists(input.CacheKey))
            {
                await WriteJson(ctx, Results.NotFound(new { message = "结果不存在。" }));
                return;
            }

            var kindText = input.Kind?.Trim().ToLowerInvariant();
            string text;
            if (kindText is "all" or "combined")
            {
                text = await Task.Run(() =>
                    ExportService.BuildCombinedRewardTsv(
                        repository.StreamRewards(input.CacheKey, RewardStreamKind.Loss),
                        repository.StreamRewards(input.CacheKey, RewardStreamKind.Profit)));
            }
            else
            {
                var kind = ParseRewardKind(input.Kind);
                text = await Task.Run(() =>
                    ExportService.BuildRewardTsv(repository.StreamRewards(input.CacheKey, kind)));
            }

            await WriteJson(ctx, Results.Ok(new RewardsTsvDto { Text = text }));
        });

        app.MapFallback(async ctx =>
        {
            if (ctx.Request.Path.StartsWithSegments("/api"))
            {
                ctx.Response.StatusCode = StatusCodes.Status404NotFound;
                await ctx.Response.WriteAsJsonAsync(new { message = "API 不存在。" }, JsonOptions);
                return;
            }

            var index = Path.Combine(_wwwRoot, "index.html");
            if (File.Exists(index))
            {
                ctx.Response.ContentType = "text/html";
                await ctx.Response.SendFileAsync(index);
                return;
            }

            ctx.Response.StatusCode = StatusCodes.Status404NotFound;
            await ctx.Response.WriteAsync("批量页面资源未找到，请先构建 web/batch-ui。");
        });
    }

    private bool IsAllowedPath(string path)
    {
        try
        {
            var full = Path.GetFullPath(path);
            if (!File.Exists(full))
                return false;

            var uploadRoot = Path.GetFullPath(_uploadDir);
            return full.StartsWith(uploadRoot, StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    private static BatchPageModeDto ParseMode(string? mode) => mode?.Trim().ToLowerInvariant() switch
    {
        "callback" => BatchPageModeDto.Callback,
        "loss7d" => BatchPageModeDto.Loss7d,
        "yesterdayloss" => BatchPageModeDto.YesterdayLoss,
        "oldcallback234" => BatchPageModeDto.OldCallback234,
        "comprehensive" => BatchPageModeDto.ComprehensiveCallback,
        _ => BatchPageModeDto.Period
    };

    private static RewardStreamKind ParseRewardKind(string? kind) => kind?.ToLowerInvariant() switch
    {
        "loss" => RewardStreamKind.Loss,
        "profit" => RewardStreamKind.Profit,
        _ => RewardStreamKind.Merged
    };

    private static string FindFixturePath(string fileName)
    {
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "fixtures", fileName),
            Path.Combine(Directory.GetCurrentDirectory(), "fixtures", fileName)
        };

        foreach (var path in candidates)
        {
            if (File.Exists(path))
                return path;
        }

        throw new FileNotFoundException($"找不到模板文件：{fileName}");
    }

    private static bool IsRequestBodyTooLarge(BadHttpRequestException ex) =>
        ex.Message.Contains("Request body too large", StringComparison.OrdinalIgnoreCase)
        || ex.Message.Contains("Multipart body length limit", StringComparison.OrdinalIgnoreCase);

    private static int GetFreePort()
    {
        var listener = new System.Net.Sockets.TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var port = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        return port;
    }

    private static async Task<T?> ReadJson<T>(HttpContext ctx)
    {
        try
        {
            return await JsonSerializer.DeserializeAsync<T>(ctx.Request.Body, JsonOptions, ctx.RequestAborted);
        }
        catch
        {
            return default;
        }
    }

    private static async Task WriteJson(HttpContext ctx, IResult result)
    {
        ctx.Response.ContentType = "application/json; charset=utf-8";
        await result.ExecuteAsync(ctx);
    }

    public async ValueTask DisposeAsync()
    {
        if (_app is null)
            return;

        await _app.StopAsync();
        await _app.DisposeAsync();
        _app = null;
    }
}

using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace DHPG.Common;

// =============================================================================
// Excel 解析
// =============================================================================

/// <summary>会员 Excel 列映射（UI / 处理共用）</summary>
public class ColumnMappingInfo
{
    public int UserIdColumn { get; set; } = 0;
    public int PayColumn { get; set; } = 5;
    public int WithdrawColumn { get; set; } = 7;
    public int PhoneColumn { get; set; } = 17;
    public int TierColumn { get; set; } = 21;
    /// <summary>当日充提差列；-1 表示不读</summary>
    public int NetDiffColumn { get; set; } = -1;
    /// <summary>未登录天数列（Q 列等）；-1 表示不读</summary>
    public int InactiveDaysColumn { get; set; } = -1;
    public int HeaderRow { get; set; } = 0;

    public static ColumnMappingInfo CreatePeriodDefaults() => new();

    public static ColumnMappingInfo CreateCallbackDefaults() => new()
    {
        UserIdColumn = 5,
        PayColumn = 8,
        WithdrawColumn = 9,
        PhoneColumn = 23,
        TierColumn = 24,
        HeaderRow = 0
    };

    /// <summary>近7日亏损回访默认映射：F/I/J/X/Y</summary>
    public static ColumnMappingInfo CreateLoss7dDefaults() => new()
    {
        UserIdColumn = 5,
        PayColumn = 8,
        WithdrawColumn = 9,
        PhoneColumn = 23,
        TierColumn = 24,
        HeaderRow = 0
    };

    /// <summary>昨日亏损默认映射：B/L/M/S/T/U</summary>
    public static ColumnMappingInfo CreateYesterdayLossDefaults() => new()
    {
        UserIdColumn = 1,
        PayColumn = 11,
        WithdrawColumn = 12,
        NetDiffColumn = 18,
        PhoneColumn = 19,
        TierColumn = 20,
        HeaderRow = 0
    };

    /// <summary>老回访234默认映射：会员导出 CSV（0=会员id, 5=订单充值, 7=订单提现, 9=充提差, 16=未登录, 17=手机, 21=层级）</summary>
    public static ColumnMappingInfo CreateOldCallback234Defaults() => new()
    {
        UserIdColumn = 0,
        PayColumn = 5,
        WithdrawColumn = 7,
        NetDiffColumn = 9,
        InactiveDaysColumn = 16,
        PhoneColumn = 17,
        TierColumn = 21,
        HeaderRow = 1
    };

    /// <summary>综合回访默认映射：A/F/H/I/Q/R/V（与老回访234一致）</summary>
    public static ColumnMappingInfo CreateComprehensiveDefaults() => CreateOldCallback234Defaults();
}

/// <summary>充值数据文件列映射</summary>
public class RechargeMappingConfig
{
    public int UserIdColumn { get; set; } = 1;
    public int AmountColumn { get; set; } = 5;
    public int HeaderRow { get; set; } = 0;

    public static RechargeMappingConfig CreateDefaults() => new();
}

/// <summary>站点列映射（时段 / 回访 / 近7日 / 未领名单）</summary>
public class SiteMappingConfig
{
    public ColumnMappingInfo Period { get; set; } = ColumnMappingInfo.CreatePeriodDefaults();
    public ColumnMappingInfo Callback { get; set; } = ColumnMappingInfo.CreateCallbackDefaults();
    public ColumnMappingInfo Loss7d { get; set; } = ColumnMappingInfo.CreateLoss7dDefaults();
    public ColumnMappingInfo YesterdayLoss { get; set; } = ColumnMappingInfo.CreateYesterdayLossDefaults();
    public ColumnMappingInfo OldCallback234 { get; set; } = ColumnMappingInfo.CreateOldCallback234Defaults();
    public ColumnMappingInfo Comprehensive { get; set; } = ColumnMappingInfo.CreateComprehensiveDefaults();
    public RechargeMappingConfig Recharge { get; set; } = RechargeMappingConfig.CreateDefaults();
    public int UnclaimedUserIdColumn { get; set; } = 1;

    /// <summary>活动编辑页：各子活动列映射默认值（综合回访超集）</summary>
    public static SiteMappingConfig CreateActivityMappingDefaults() => new()
    {
        Period = ColumnMappingInfo.CreatePeriodDefaults(),
        Callback = ColumnMappingInfo.CreateCallbackDefaults(),
        Loss7d = ColumnMappingInfo.CreateLoss7dDefaults(),
        YesterdayLoss = ColumnMappingInfo.CreateYesterdayLossDefaults(),
        OldCallback234 = ColumnMappingInfo.CreateOldCallback234Defaults(),
        Comprehensive = ColumnMappingInfo.CreateComprehensiveDefaults(),
        Recharge = RechargeMappingConfig.CreateDefaults(),
        UnclaimedUserIdColumn = 1
    };
}

/// <summary>处理时使用的映射类型</summary>
public enum MappingProfile
{
    Period,
    Callback,
    Loss7d,
    YesterdayLoss,
    OldCallback234,
    ComprehensiveCallback
}

/// <summary>ExcelService 流式解析出的单行会员数据</summary>
public class MemberRow
{
    public int RowNumber { get; set; }
    public long UserId { get; set; }
    public decimal Pay { get; set; }
    public decimal Withdraw { get; set; }
    /// <summary>当日充提差（映射列读取；未配置时由 Pay-Withdraw 推算）</summary>
    public decimal NetDiff { get; set; }
    public string? Phone { get; set; }
    public string? Tier { get; set; }
    /// <summary>未登录天数列原始文本（如 1234567）</summary>
    public string? InactiveDaysText { get; set; }
}

// =============================================================================
// 数据处理请求 / 进度
// =============================================================================

/// <summary>ProcessView 提交给 ProcessService 的完整请求</summary>
public class ProcessRequest
{
    public int SiteId { get; set; }
    public int ActivityId { get; set; }
    public string MemberFilePath { get; set; } = string.Empty;

    /// <summary>是否过滤未领取彩金会员</summary>
    public bool FilterUnclaimed { get; set; }

    /// <summary>未领名单文件路径（FilterUnclaimed=true 时必填）</summary>
    public string? UnclaimedFilePath { get; set; }

    /// <summary>是否按充值数据过滤/合并</summary>
    public bool FilterRecharge { get; set; }

    /// <summary>充值数据文件路径（FilterRecharge=true 时必填）</summary>
    public string? RechargeFilePath { get; set; }

    /// <summary>是否获取盈利会员；null=跟随活动 AllowProfitMember</summary>
    public bool? IncludeProfitMember { get; set; }

    /// <summary>派奖页打码倍数（优先级最高）</summary>
    public decimal WageringMultiplier { get; set; }

    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;

    /// <summary>处理完成后是否自动写入历史（默认 true）</summary>
    public bool SaveToHistory { get; set; } = true;

    /// <summary>页面表单覆盖列映射（不为 null 时优先于活动 DB 配置）</summary>
    public ColumnMappingInfo? ColumnMappingOverride { get; set; }

    /// <summary>会员文件映射类型（时段 / 回访）</summary>
    public MappingProfile MappingProfile { get; set; } = MappingProfile.Period;

    /// <summary>未领名单会员 ID 列覆盖（null 时使用活动配置）</summary>
    public int? UnclaimedUserIdColumnOverride { get; set; }

    /// <summary>近7日亏损回访：计算日期（null=按所选时区当天）</summary>
    public DateOnly? CalculationDate { get; set; }

    /// <summary>近7日亏损回访：时区</summary>
    public ActivityTimezone Timezone { get; set; } = ActivityTimezone.Beijing;
}

/// <summary>ProcessService 进度报告（IProgress&lt;ProcessProgress&gt;）</summary>
public class ProcessProgress
{
    public int ProcessedRows { get; set; }
    public int TotalRows { get; set; }
    public string Phase { get; set; } = string.Empty;
    public string? Message { get; set; }

    public double Percent =>
        TotalRows <= 0 ? 0 : Math.Min(100, ProcessedRows * 100.0 / TotalRows);
}

// =============================================================================
// 处理结果
// =============================================================================

/// <summary>ProcessService 完整输出</summary>
public class ProcessResult
{
    public DateTime ProcessedAt { get; set; } = DateTime.Now;
    public int SiteId { get; set; }
    public string SiteName { get; set; } = string.Empty;
    public string SiteCode { get; set; } = string.Empty;
    public int ActivityId { get; set; }
    public string ActivityName { get; set; } = string.Empty;

    public ProcessSummary Summary { get; set; } = new();
    public List<ProcessDetailItem> Details { get; set; } = new();
    public List<RewardItem> Rewards { get; set; } = new();

    /// <summary>回访彩金：亏损侧派奖（profit ≥ 0）</summary>
    public List<RewardItem> LossRewards { get; set; } = new();

    /// <summary>回访彩金：盈利侧派奖（profit &lt; 0）</summary>
    public List<RewardItem> ProfitRewards { get; set; } = new();

    /// <summary>回访彩金使用亏损/盈利两份派奖表</summary>
    public bool UsesSplitRewards { get; set; }

    public ProcessSnapshot Snapshot { get; set; } = new();

    /// <summary>自动导出时的文件路径（可选）</summary>
    public string? ExportFilePath { get; set; }

    /// <summary>磁盘缓存键；非空时 Details/Rewards 列表为空，需经 ResultRepository 读取。</summary>
    public string ResultCacheKey { get; set; } = string.Empty;

    public bool IsSummaryOnly => !string.IsNullOrEmpty(ResultCacheKey);
}

public class ProcessSummary
{
    public int TotalCount { get; set; }
    public int FilteredCount { get; set; }
    public int RewardCount { get; set; }
    public decimal TotalBonus { get; set; }
    public int LossRewardCount { get; set; }
    public int ProfitRewardCount { get; set; }
    public decimal LossTotalBonus { get; set; }
    public decimal ProfitTotalBonus { get; set; }
}

/// <summary>处理明细 Tab 行（含剔除行）</summary>
public class ProcessDetailItem
{
    public long UserId { get; set; }
    public string? Phone { get; set; }
    public decimal Pay { get; set; }
    public decimal Withdraw { get; set; }
    public decimal Profit { get; set; }
    public decimal Bonus { get; set; }
    public string? Tier { get; set; }

    /// <summary>非空表示已剔除，不进派奖</summary>
    public string? ExcludeReason { get; set; }

    public bool IsExcluded => !string.IsNullOrEmpty(ExcludeReason);
}

/// <summary>派奖结果 Tab 行</summary>
public class RewardItem
{
    public long UserId { get; set; }
    public decimal Bonus { get; set; }
    public decimal WageringMultiplier { get; set; }
    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;
}

// =============================================================================
// 历史快照（SnapshotJson 契约，version=1）
// =============================================================================

public class ProcessSnapshot
{
    public int Version { get; set; } = 1;

    [JsonPropertyName("processedAt")]
    public DateTime ProcessedAt { get; set; }

    public SnapshotSiteInfo Site { get; set; } = new();
    public SnapshotActivityInfo Activity { get; set; } = new();
    public ColumnMappingInfo ColumnMapping { get; set; } = new();
    public SnapshotProcessOptions ProcessOptions { get; set; } = new();
    public SnapshotRewardSettings RewardSettings { get; set; } = new();
    public ProcessSummary Summary { get; set; } = new();
    public SnapshotResultPreview? ResultPreview { get; set; }

    /// <summary>关联 ResultRepository 缓存；历史记录可据此恢复全量明细/派奖。</summary>
    [JsonPropertyName("resultCacheKey")]
    public string? ResultCacheKey { get; set; }
}

public class SnapshotSiteInfo
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
}

public class SnapshotActivityInfo
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public int Divisor { get; set; }
    public decimal MinBonus { get; set; }
    public decimal MaxBonus { get; set; }
    public bool AllowProfitMember { get; set; }

    [JsonPropertyName("filterTierKeywords")]
    public List<string> FilterTierKeywords { get; set; } = new();

    public decimal DefaultWageringMultiplier { get; set; }
    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;
}

public class SnapshotProcessOptions
{
    public bool FilterUnclaimed { get; set; }

    [JsonPropertyName("includeProfitMember")]
    public bool IncludeProfitMember { get; set; }
}

public class SnapshotRewardSettings
{
    public decimal WageringMultiplier { get; set; }
    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;
}

public class SnapshotResultPreview
{
    public List<ProcessDetailItem> DetailSample { get; set; } = new();
    public List<RewardItem> RewardSample { get; set; } = new();
    public List<RewardItem> LossRewardSample { get; set; } = new();
    public List<RewardItem> ProfitRewardSample { get; set; } = new();
    public bool UsesSplitRewards { get; set; }
}

// =============================================================================
// UI / CRUD 模型
// =============================================================================

public class AppSettingsModel
{
    public string ExportDirectory { get; set; } = string.Empty;
    public decimal DefaultWageringMultiplier { get; set; } = 1m;
    public string DefaultAppRemark { get; set; } = string.Empty;
    public string DefaultBackendRemark { get; set; } = string.Empty;
    public string Theme { get; set; } = "Light";
    public string LogLevel { get; set; } = "Information";
}

public class SiteListItem
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string? Remark { get; set; }
    public bool IsEnabled { get; set; }
    public DateTime CreatedAt { get; set; }
    public string PeriodMappingText { get; set; } = string.Empty;
    public string CallbackMappingText { get; set; } = string.Empty;
    public string UnclaimedMappingText { get; set; } = string.Empty;
}

/// <summary>站点编辑对话框（含列映射）</summary>
public class SiteEditModel
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string? Remark { get; set; }
    public bool IsEnabled { get; set; } = true;
    public SiteMappingConfig Mapping { get; set; } = new();
}

public class ActivityListItem
{
    public int Id { get; set; }
    public int? SiteId { get; set; }
    public string SiteScopeText { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public bool AllowProfitMember { get; set; }
    public bool IsEnabled { get; set; }
    public int SortOrder { get; set; }
    public bool ApplyToAllSites { get; set; }
    public ActivityKind Kind { get; set; }
    public string KindText { get; set; } = string.Empty;
    public string PeriodMappingText { get; set; } = string.Empty;
    public string CallbackMappingText { get; set; } = string.Empty;
    public string UnclaimedMappingText { get; set; } = string.Empty;
}

/// <summary>活动层级过滤默认关键字</summary>
public static class ActivityDefaults
{
    public const string Loss7dActivityName = "老回访1567";
    public const string Loss7dActivityLegacyName = "近7日亏损回访";
    public const string YesterdayLossActivityName = "昨日亏损";
    public const string OldCallback234ActivityName = "老回访234";
    public const string ComprehensiveCallbackActivityName = "综合回访";

    public static readonly string[] FilterTierKeywords = ["新-无优惠", "黑名单", "无优惠", "洗水套利"];

    public static List<string> CreateFilterTierKeywords() => FilterTierKeywords.ToList();

    public static string FormatKindName(ActivityKind kind) => kind switch
    {
        ActivityKind.Callback => "回访彩金",
        ActivityKind.Loss7d => Loss7dActivityName,
        ActivityKind.YesterdayLoss => YesterdayLossActivityName,
        ActivityKind.OldCallback234 => OldCallback234ActivityName,
        ActivityKind.ComprehensiveCallback => ComprehensiveCallbackActivityName,
        _ => "时段彩金"
    };
}

/// <summary>活动编辑 / 复制对话框</summary>
public class ActivityEditModel
{
    public int Id { get; set; }
    public int? SiteId { get; set; }
    public bool ApplyToAllSites { get; set; } = true;
    public List<int> LinkedSiteIds { get; set; } = new();
    public string Name { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public int Divisor { get; set; } = 1;
    public decimal MinBonus { get; set; }
    public decimal MaxBonus { get; set; }
    public decimal DefaultWageringMultiplier { get; set; } = 1m;
    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;
    public bool AllowProfitMember { get; set; }
    public bool IsEnabled { get; set; } = true;
    public List<string> FilterTierKeywords { get; set; } = ActivityDefaults.CreateFilterTierKeywords();
    public int SortOrder { get; set; }
    public SiteMappingConfig Mapping { get; set; } = new();
    public ActivityKind Kind { get; set; } = ActivityKind.Period;
    public WeeklyDayRates WeeklyDayRates { get; set; } = new();
    public ActivityTimezone DefaultTimezone { get; set; } = ActivityTimezone.Beijing;
    public bool FilterLossMember { get; set; }
    public bool FilterUnclaimedEnabled { get; set; } = true;
    public decimal MinNetDiff { get; set; } = 20m;
    public TieredAmountRates TieredAmountRates { get; set; } = new();
    public int InactiveDaysMax { get; set; } = 7;
    public bool UseNetDiffColumn { get; set; }
    public bool FilterRechargeEnabled { get; set; }
    public TieredFixedBonuses TieredFixedBonuses { get; set; } = new();
    public ComprehensiveCallbackFeatures ComprehensiveFeatures { get; set; } = new();
}

public static class ActivityEditModelFactory
{
    public static ActivityEditModel CreateComprehensiveTemplate() => new()
    {
        Name = ActivityDefaults.ComprehensiveCallbackActivityName,
        Kind = ActivityKind.ComprehensiveCallback,
        ApplyToAllSites = true,
        Rate = 0.02m,
        Divisor = 2,
        MinBonus = 1m,
        MaxBonus = 0m,
        DefaultWageringMultiplier = 1m,
        AllowProfitMember = true,
        IsEnabled = true,
        FilterTierKeywords = ActivityDefaults.CreateFilterTierKeywords(),
        ComprehensiveFeatures = ComprehensiveCallbackFeatures.CreateDefaults(),
        WeeklyDayRates = WeeklyDayRates.CreateLoss7dDefaults(),
        DefaultTimezone = ActivityTimezone.Beijing,
        TieredAmountRates = TieredAmountRates.CreateYesterdayLossDefaults(),
        TieredFixedBonuses = TieredFixedBonuses.CreateOldCallback234Defaults(),
        MinNetDiff = 20m,
        InactiveDaysMax = 7,
        FilterUnclaimedEnabled = true,
        FilterRechargeEnabled = false,
        Mapping = SiteMappingConfig.CreateActivityMappingDefaults()
    };
}

public class HistoryListItem
{
    public int Id { get; set; }
    public DateTime ProcessedAt { get; set; }
    public string SiteName { get; set; } = string.Empty;
    public string ActivityName { get; set; } = string.Empty;
    public int TotalCount { get; set; }
    public int FilteredCount { get; set; }
    public int RewardCount { get; set; }
    public decimal TotalBonus { get; set; }
}

/// <summary>历史详情（只读快照，不含全量行）</summary>
public class HistoryDetailModel
{
    public int Id { get; set; }
    public DateTime ProcessedAt { get; set; }
    public string SiteName { get; set; } = string.Empty;
    public string ActivityName { get; set; } = string.Empty;
    public ProcessSummary Summary { get; set; } = new();
    public ProcessSnapshot Snapshot { get; set; } = new();
    public string? ExportFilePath { get; set; }
}

public class DashboardStats
{
    public string Version { get; set; } = string.Empty;
    public int SiteCount { get; set; }
    public int ActivityCount { get; set; }
    public int TodayProcessCount { get; set; }
    public List<HistoryListItem> RecentHistories { get; set; } = new();
}

// =============================================================================
// 导出
// =============================================================================

public class ExportOptions
{
    /// <summary>为空则使用系统设置默认导出目录</summary>
    public string? OutputDirectory { get; set; }

    /// <summary>为空则按规则自动生成文件名</summary>
    public string? FileName { get; set; }
}

public class ExportResult
{
    public string FilePath { get; set; } = string.Empty;
    public bool Success { get; set; }
    public string? Message { get; set; }
}

// =============================================================================
// 活动运行时参数（ProcessView 加载活动后合并优先级）
// =============================================================================

/// <summary>活动配置 + 系统默认值合并后的运行时参数</summary>
public class ActivityRuntimeParams
{
    public int ActivityId { get; set; }
    public string ActivityName { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public int Divisor { get; set; }
    public decimal MinBonus { get; set; }
    public decimal MaxBonus { get; set; }
    public bool AllowProfitMember { get; set; }
    public string[] FilterTierKeywords { get; set; } = Array.Empty<string>();

    public decimal WageringMultiplier { get; set; }
    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;
    public ActivityKind Kind { get; set; }
    public WeeklyDayRates WeeklyDayRates { get; set; } = new();
    public ActivityTimezone DefaultTimezone { get; set; } = ActivityTimezone.Beijing;
    public bool FilterLossMember { get; set; }
    public bool FilterUnclaimedEnabled { get; set; } = true;
    public decimal? ResolvedDayRate { get; set; }
    public DateOnly? CalculationDate { get; set; }
    public decimal MinNetDiff { get; set; } = 20m;
    public TieredAmountRates TieredAmountRates { get; set; } = new();
    public int InactiveDaysMax { get; set; } = 7;
    public bool UseNetDiffColumn { get; set; }
    public bool FilterRechargeEnabled { get; set; }
    public TieredFixedBonuses TieredFixedBonuses { get; set; } = new();
    public ComprehensiveCallbackFeatures ComprehensiveFeatures { get; set; } = new();
}

// =============================================================================
// ProcessView 页面模式
// =============================================================================

public enum ProcessPageMode
{
    Single,
    PeriodBatch,
    CallbackBatch,
    Loss7dBatch,
    YesterdayLossBatch,
    OldCallback234Batch,
    ComprehensiveCallbackBatch
}

// =============================================================================
// 批量站点处理
// =============================================================================

public enum BatchTaskStatus
{
    Pending,
    Processing,
    Success,
    Failed,
    Cancelled
}

public class BatchSiteTask : INotifyPropertyChanged
{
    public string Key { get; set; } = Guid.NewGuid().ToString("N");

    private int _siteId;
    public int SiteId
    {
        get => _siteId;
        set
        {
            if (_siteId == value)
                return;
            _siteId = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SiteDisplay));
        }
    }

    public string SiteName { get; set; } = string.Empty;
    public string SiteCode { get; set; } = string.Empty;

    public string SiteDisplay =>
        SiteId <= 0
            ? "未选择"
            : string.IsNullOrWhiteSpace(SiteName) ? $"站点 {SiteId}" : SiteName;

    private string? _memberFilePath;
    public string? MemberFilePath
    {
        get => _memberFilePath;
        set
        {
            if (_memberFilePath == value)
                return;
            _memberFilePath = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(MemberFileDisplay));
        }
    }

    private string? _unclaimedFilePath;
    public string? UnclaimedFilePath
    {
        get => _unclaimedFilePath;
        set
        {
            if (_unclaimedFilePath == value)
                return;
            _unclaimedFilePath = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(UnclaimedFileDisplay));
        }
    }

    private BatchTaskStatus _status = BatchTaskStatus.Pending;
    public BatchTaskStatus Status
    {
        get => _status;
        set
        {
            if (_status == value)
                return;
            _status = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(StatusText));
        }
    }

    public string? ErrorMessage { get; set; }

    /// <summary>处理结果磁盘缓存键（批量模式不保留全量明细）。</summary>
    public string? ResultCacheKey { get; private set; }

    /// <summary>批量模式摘要（不持有 ProcessResult 引用）。</summary>
    public ProcessSummary? CachedSummary { get; private set; }

    public bool UsesSplitRewardsCached { get; private set; }

    private ProcessResult? _result;
    public ProcessResult? Result
    {
        get => _result;
        set
        {
            _result = value;
            if (value is not null)
            {
                ResultCacheKey = value.ResultCacheKey;
                CachedSummary = value.Summary;
                UsesSplitRewardsCached = value.UsesSplitRewards;
            }

            NotifyOutcomeChanged();
        }
    }

    public bool HasOutcome => !string.IsNullOrEmpty(ResultCacheKey) || _result is not null;

    public void AttachCacheOutcome(ProcessResult result)
    {
        ResultCacheKey = result.ResultCacheKey;
        CachedSummary = result.Summary;
        UsesSplitRewardsCached = result.UsesSplitRewards;
        _result = null;
        NotifyOutcomeChanged();
    }

    public void ClearOutcome()
    {
        _result = null;
        ResultCacheKey = null;
        CachedSummary = null;
        UsesSplitRewardsCached = false;
        NotifyOutcomeChanged();
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private bool _suppressResultNotification;

    public void BeginBatchUpdate() => _suppressResultNotification = true;

    public void EndBatchUpdate()
    {
        _suppressResultNotification = false;
        NotifyOutcomeChanged();
        OnPropertyChanged(nameof(SiteDisplay));
    }

    private void NotifyOutcomeChanged()
    {
        OnPropertyChanged(nameof(Result));
        if (!_suppressResultNotification)
        {
            OnPropertyChanged(nameof(DisplayRewardCount));
            OnPropertyChanged(nameof(DisplayTotalBonus));
        }
    }

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

    public string StatusText => Status switch
    {
        BatchTaskStatus.Pending => "待处理",
        BatchTaskStatus.Processing => "处理中",
        BatchTaskStatus.Success => "成功",
        BatchTaskStatus.Failed => "失败",
        BatchTaskStatus.Cancelled => "已取消",
        _ => Status.ToString()
    };

    public int DisplayRewardCount => CachedSummary?.RewardCount ?? Result?.Summary.RewardCount ?? 0;

    public decimal DisplayTotalBonus => CachedSummary?.TotalBonus ?? Result?.Summary.TotalBonus ?? 0;

    public string MemberFileDisplay =>
        string.IsNullOrWhiteSpace(MemberFilePath) ? "未选择" : Path.GetFileName(MemberFilePath);

    public string UnclaimedFileDisplay =>
        string.IsNullOrWhiteSpace(UnclaimedFilePath) ? "未选择" : Path.GetFileName(UnclaimedFilePath);

    private string? _rechargeFilePath;
    public string? RechargeFilePath
    {
        get => _rechargeFilePath;
        set
        {
            if (_rechargeFilePath == value)
                return;
            _rechargeFilePath = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(RechargeFileDisplay));
        }
    }

    public string RechargeFileDisplay =>
        string.IsNullOrWhiteSpace(RechargeFilePath) ? "未选择" : Path.GetFileName(RechargeFilePath);

    /// <summary>批量处理时使用的列映射覆盖（由页面表单填充）</summary>
    [JsonIgnore]
    public ColumnMappingInfo? ColumnMappingOverride { get; set; }

    /// <summary>批量处理映射类型</summary>
    [JsonIgnore]
    public MappingProfile MappingProfile { get; set; } = MappingProfile.Period;

    /// <summary>批量处理未领名单列覆盖</summary>
    [JsonIgnore]
    public int? UnclaimedUserIdColumnOverride { get; set; }
}

public class BatchProcessRequest
{
    public int ActivityId { get; set; }
    public bool FilterUnclaimed { get; set; }
    public bool FilterRecharge { get; set; }
    public bool? IncludeProfitMember { get; set; }
    public decimal WageringMultiplier { get; set; }
    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;
    public bool SaveToHistory { get; set; } = true;
    public DateOnly? CalculationDate { get; set; }
    public ActivityTimezone Timezone { get; set; } = ActivityTimezone.Beijing;
    public List<BatchSiteTask> Tasks { get; set; } = new();
}

public class BatchProcessResult
{
    public int ActivityId { get; set; }
    public string ActivityName { get; set; } = string.Empty;
    public DateTime StartedAt { get; set; }
    public DateTime FinishedAt { get; set; }
    public int SuccessCount { get; set; }
    public int FailedCount { get; set; }
    public decimal TotalBonusAllSites { get; set; }
    public List<BatchSiteTask> Tasks { get; set; } = new();
}

public class BatchProcessProgress
{
    public int CurrentIndex { get; set; }
    public int TotalTasks { get; set; }
    public string? CurrentSiteName { get; set; }
    public string Phase { get; set; } = string.Empty;
    public string? Message { get; set; }

    public double Percent => TotalTasks <= 0 ? 0 : CurrentIndex * 100.0 / TotalTasks;
}

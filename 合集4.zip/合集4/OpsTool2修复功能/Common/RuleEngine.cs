using System.Globalization;

namespace DHPG.Common;

/// <summary>唯一彩金计算引擎：静态方法，不按活动名分支。</summary>
public static class RuleEngine
{
    /// <summary>profit = 充值 - 提现（会员盈利 &lt; 0，亏损 &gt; 0）</summary>
    public static decimal CalcProfit(decimal pay, decimal withdraw) =>
        Math.Round(pay - withdraw, 2, MidpointRounding.AwayFromZero);

    /// <summary>亏损侧：profit &gt;= 0</summary>
    public static decimal CalcLossBonus(
        decimal profit,
        decimal rate,
        int divisor,
        decimal minBonus,
        decimal maxBonus)
    {
        if (divisor <= 0)
            divisor = 1;

        var bonus = profit * rate / divisor;
        if (bonus < minBonus)
            bonus = minBonus;
        // maxBonus <= 0 表示不封顶（回访彩金默认 MaxBonus=0）
        if (maxBonus > 0 && bonus > maxBonus)
            bonus = maxBonus;

        return Math.Round(bonus, 2, MidpointRounding.AwayFromZero);
    }

    /// <summary>盈利侧：固定最低彩金</summary>
    public static decimal CalcProfitBonus(decimal minBonus) =>
        Math.Round(minBonus, 2, MidpointRounding.AwayFromZero);

    /// <summary>
    /// 根据 profit 与是否允许盈利会员，计算彩金或剔除。
    /// 返回 IsReward=false 时 ExcludeReason 非空。
    /// </summary>
    public static (decimal Bonus, bool IsReward, string? ExcludeReason) ResolveBonus(
        decimal profit,
        decimal rate,
        int divisor,
        decimal minBonus,
        decimal maxBonus,
        bool includeProfitMember)
    {
        if (profit < 0)
        {
            if (!includeProfitMember)
                return (0m, false, "过滤盈利会员");

            return (CalcProfitBonus(minBonus), true, null);
        }

        return (CalcLossBonus(profit, rate, divisor, minBonus, maxBonus), true, null);
    }

    /// <summary>近7日亏损回访：累计充值 × 当日比例，低于最低彩金取最低。</summary>
    public static decimal CalcLoss7dBonus(decimal cumulativeDeposit, decimal dayRate, decimal minBonus)
    {
        var bonus = cumulativeDeposit * dayRate;
        if (bonus < minBonus)
            bonus = minBonus;

        return Math.Round(bonus, 2, MidpointRounding.AwayFromZero);
    }

    /// <summary>昨日亏损：充提差 × 区间比例，低于最低彩金取最低。</summary>
    public static decimal CalcYesterdayLossBonus(decimal netDiff, decimal rate, decimal minBonus)
    {
        var bonus = netDiff * rate;
        if (bonus < minBonus)
            bonus = minBonus;

        return Math.Round(bonus, 2, MidpointRounding.AwayFromZero);
    }

    public static string FormatTieredRatesText(TieredAmountRates rates)
    {
        if (rates.Tiers.Count == 0)
            return "未配置";

        return string.Join("；", rates.Tiers
            .OrderBy(t => t.MinAmount)
            .Select(t =>
            {
                var maxText = t.MaxAmount is null ? "以上" : t.MaxAmount.Value.ToString("0.##");
                return $"{t.MinAmount:0.##}-{maxText} {FormatRatePercentText(t.Rate)}%";
            }));
    }

    public static string FormatRatePercentText(decimal rate)
    {
        var percent = rate * 100m;
        var text = percent.ToString("0.####");
        return text.TrimEnd('0').TrimEnd('.');
    }

    /// <summary>层级 Contains 模糊匹配（关键字已小写）；层级为空不过滤。</summary>
    public static bool IsTierExcluded(string? tier, string[] lowerKeywords)
    {
        if (string.IsNullOrWhiteSpace(tier) || lowerKeywords.Length == 0)
            return false;

        for (var i = 0; i < lowerKeywords.Length; i++)
        {
            if (tier.Contains(lowerKeywords[i], StringComparison.OrdinalIgnoreCase))
                return true;
        }

        return false;
    }

    public static string FormatTierExcludeReason(string tier) => $"层级已过滤: {tier}";

    /// <summary>Q 列未登录：保留 0..maxDays（含当天 0 天；独立数字匹配避免 10 命中 1、17 命中 7）。</summary>
    public static bool PassesInactiveDaysFilter(string? inactiveDaysText, int maxDays)
    {
        if (maxDays <= 0 || string.IsNullOrWhiteSpace(inactiveDaysText))
            return false;

        var text = inactiveDaysText.Trim();
        if (TryParseInactiveDayCount(text, out var exact))
            return exact >= 0 && exact <= maxDays;

        for (var day = 0; day <= maxDays; day++)
        {
            if (ContainsIsolatedNumber(text, day))
                return true;
        }

        return false;
    }

    private static bool TryParseInactiveDayCount(string text, out int days)
    {
        days = 0;
        if (int.TryParse(text, out days))
            return true;

        if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var num)
            && !double.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out num))
            return false;

        var truncated = (int)Math.Truncate(num);
        if (Math.Abs(num - truncated) > 1e-6)
            return false;

        days = truncated;
        return true;
    }

    private static bool ContainsIsolatedNumber(string text, int number)
    {
        var token = number.ToString();
        var start = 0;
        while (start <= text.Length - token.Length)
        {
            var index = text.IndexOf(token, start, StringComparison.Ordinal);
            if (index < 0)
                return false;

            var beforeOk = index == 0 || !char.IsDigit(text[index - 1]);
            var afterIndex = index + token.Length;
            var afterOk = afterIndex >= text.Length || !char.IsDigit(text[afterIndex]);
            if (beforeOk && afterOk)
                return true;

            start = index + 1;
        }

        return false;
    }

    public static string FormatTieredFixedBonusesText(TieredFixedBonuses bonuses)
    {
        if (bonuses.Tiers.Count == 0)
            return "未配置";

        return string.Join("；", bonuses.Tiers
            .OrderBy(t => t.MinAmount)
            .Select(t =>
            {
                var maxText = t.MaxAmount is null ? "以上" : t.MaxAmount.Value.ToString("0.##");
                return $"亏损 {t.MinAmount:0.##}-{maxText} 送 {t.Bonus:0.##}";
            }));
    }
}

<script setup>
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import MappingForm from './components/MappingForm.vue'
import PageJump from './components/PageJump.vue'
import {
  PAGE_SIZE,
  api,
  cloneMapping,
  defaultMapping,
  fileName,
  getMode,
  isTaskReady,
  resolveLossBonus,
  resolveProfitBonus,
  shouldShowProfitBonus,
  formatBatchBonusMessage,
  buildRuleFormulaText,
  buildLoss7dRuleFormulaText,
  buildYesterdayLossRuleFormulaText,
  buildOldCallback234RuleFormulaText,
  buildComprehensiveRuleFormulaText,
  COMPREHENSIVE_BONUS_MODE,
  formatLoss7dDaySummary,
  getTodayInTimezone,
  resolveEffectiveCalculationDate,
  siteDisplay
} from './api'

const mode = getMode()
const isLoss7d = mode === 'loss7d'
const isYesterdayLoss = mode === 'yesterdayloss'
const isOldCallback234 = mode === 'oldcallback234'
const isComprehensive = mode === 'comprehensive'
const storageKey = `dhpg-batch-state-${mode}`
const loading = ref(true)
const bootstrap = ref(null)
const tasks = ref([])
const selectedKey = ref('')
const settings = ref({
  filterUnclaimed: mode === 'callback' || mode === 'loss7d' || mode === 'yesterdayloss' || mode === 'oldcallback234' || mode === 'comprehensive',
  filterRecharge: false,
  includeProfitMember: mode === 'oldcallback234' || mode === 'comprehensive',
  calculationDate: '',
  timezone: 'beijing',
  wageringMultiplier: 1,
  appRemark: '',
  backendRemark: ''
})

const mappingDraft = ref(defaultMapping())
const mappingOverride = ref(null)
const memberHeaders = ref([])
const unclaimedHeaders = ref([])
const mappingLoadTimer = ref(null)

const processing = ref(false)
const progress = ref(null)
const batchResult = ref(null)
const pollTimer = ref(null)

const showResults = ref(false)
const resultSiteKey = ref('')
const resultSummary = ref(null)
const detailPage = ref(1)
const rewardPage = ref(1)
const lossPage = ref(1)
const profitPage = ref(1)
const detailExcludedOnly = ref(false)
const detailRows = ref([])
const detailTotal = ref(0)
const rewardRows = ref([])
const rewardTotal = ref(0)
const lossRows = ref([])
const lossTotal = ref(0)
const profitRows = ref([])
const profitTotal = ref(0)
const activeRewardTab = ref('merged')

const sites = computed(() => bootstrap.value?.sites ?? fallbackSites.value)
const fallbackSites = ref([])
const PROFIT_SPLIT_MODES = new Set(['period', 'loss7d', 'yesterdayloss', 'oldcallback234'])

const usesSplitRewards = computed(() => {
  if (resultSummary.value?.usesSplitRewards != null) {
    return resultSummary.value.usesSplitRewards
  }
  if (isComprehensive) {
    const bonusMode = bootstrap.value?.comprehensiveFeatures?.bonusMode
    return (
      bootstrap.value?.usesSplitRewards ??
      (bonusMode === COMPREHENSIVE_BONUS_MODE.StandardSplit ||
        (settings.value.includeProfitMember &&
          (bonusMode === COMPREHENSIVE_BONUS_MODE.StandardMerged ||
            bonusMode === COMPREHENSIVE_BONUS_MODE.Loss7dWeekly ||
            bonusMode === COMPREHENSIVE_BONUS_MODE.YesterdayLossTiered ||
            bonusMode === COMPREHENSIVE_BONUS_MODE.OldCallback234Fixed)))
    )
  }
  if (mode === 'callback') {
    return bootstrap.value?.usesSplitRewards ?? true
  }
  if (PROFIT_SPLIT_MODES.has(mode)) {
    return settings.value.includeProfitMember
  }
  return bootstrap.value?.usesSplitRewards ?? false
})
const isComprehensiveLoss7d = computed(
  () =>
    isComprehensive &&
    Number(bootstrap.value?.comprehensiveFeatures?.bonusMode) === COMPREHENSIVE_BONUS_MODE.Loss7dWeekly
)
const showLoss7dDateSettings = computed(() => isLoss7d || isComprehensiveLoss7d.value)
const selectedTask = computed(() => tasks.value.find((t) => t.key === selectedKey.value) ?? null)
const readyCount = computed(() =>
  tasks.value.filter((t) => isTaskReady(t, settings.value.filterUnclaimed, settings.value.filterRecharge)).length
)
const assignedSiteIds = computed(() => new Set(tasks.value.filter((t) => t.siteId > 0).map((t) => t.siteId)))

const mappingLabel = computed(() => {
  const name = bootstrap.value?.activityName
  return name ? `列映射 · ${name}（适用全部站点）` : '列映射：正在加载...'
})

const resultTasks = computed(() => batchResult.value?.tasks ?? [])
const activeResultTask = computed(
  () => resultTasks.value.find((t) => t.key === resultSiteKey.value) ?? resultTasks.value[0] ?? null
)

const activeResultSiteCode = computed(() => {
  const task = activeResultTask.value
  if (!task) return '当前站点'
  return task.siteCode || task.siteName || '当前站点'
})

const showProfitBonusColumn = computed(() =>
  shouldShowProfitBonus(settings.value.includeProfitMember, usesSplitRewards.value)
)

const activeLossBonus = computed(() =>
  resolveLossBonus(resultSummary.value?.summary, usesSplitRewards.value)
)

const activeProfitBonus = computed(() =>
  resolveProfitBonus(resultSummary.value?.summary, usesSplitRewards.value)
)

const displayRuleFormula = computed(() => {
  if (isLoss7d) {
    return buildLoss7dRuleFormulaText(bootstrap.value, settings.value)
  }
  if (isYesterdayLoss) {
    return buildYesterdayLossRuleFormulaText(bootstrap.value, settings.value)
  }
  if (isOldCallback234) {
    return buildOldCallback234RuleFormulaText(bootstrap.value, settings.value)
  }
  if (isComprehensive) {
    return buildComprehensiveRuleFormulaText(bootstrap.value, settings.value)
  }
  const rule = bootstrap.value?.activityRule
  if (!rule) return bootstrap.value?.ruleFormula || '正在加载规则...'
  return buildRuleFormulaText(
    rule,
    settings.value.wageringMultiplier,
    settings.value.includeProfitMember
  )
})

const effectiveCalculationDate = computed(() =>
  showLoss7dDateSettings.value ? resolveEffectiveCalculationDate(settings.value, bootstrap.value) : ''
)

const calculationDateSummary = computed(() => {
  if (!showLoss7dDateSettings.value || !bootstrap.value) return ''
  return formatLoss7dDaySummary(bootstrap.value.weeklyDayRates, effectiveCalculationDate.value)
})

function copyRewardsLabel(kind) {
  const code = activeResultSiteCode.value
  if (kind === 'loss') return `复制${code}亏损派奖TSV`
  if (kind === 'profit') return `复制${code}盈利派奖TSV`
  if (kind === 'all') return `复制${code}合并派奖TSV`
  return `复制${code}派奖TSV`
}

onMounted(async () => {
  window.__dhpgRefreshBootstrap = refreshBootstrap
  try {
    await refreshBootstrap(true)
    const restored = restorePageState()
    if (!restored) {
      settings.value = { ...(bootstrap.value?.defaults ?? settings.value) }
      if (isLoss7d || isComprehensiveLoss7d.value) applyLoss7dDefaultsFromBootstrap()
      if (tasks.value.length === 0) addTask()
    }
    applyActivityMapping()

    const status = await api.batchStatus()
    if (status.result) {
      batchResult.value = status.result
      syncTaskRowsFromResult(status.result)
      expandBatchResults()
    }
  } catch (e) {
    await loadSitesFallback()
    ElMessage.error(e.message || '活动配置加载失败，仍可尝试选择站点。')
    if (tasks.value.length === 0) addTask()
  } finally {
    loading.value = false
  }
})

async function loadSitesFallback() {
  try {
    fallbackSites.value = await api.listSites()
  } catch {
    fallbackSites.value = []
  }
}

async function refreshBootstrap(isInitial = false) {
  try {
    const data = await api.bootstrap(mode)
    if (isInitial || !bootstrap.value) {
      bootstrap.value = data
      return
    }

    bootstrap.value = {
      ...bootstrap.value,
      activityId: data.activityId,
      activityName: data.activityName,
      ruleFormula: data.ruleFormula,
      activityRule: data.activityRule,
      activityMapping: data.activityMapping,
      activityKind: data.activityKind,
      weeklyDayRates: data.weeklyDayRates,
      defaultTimezone: data.defaultTimezone,
      defaultCalculationDate: data.defaultCalculationDate,
      filterLossMember: data.filterLossMember,
      filterUnclaimedEnabled: data.filterUnclaimedEnabled,
      minNetDiff: data.minNetDiff,
      tieredAmountRates: data.tieredAmountRates,
      inactiveDaysMax: data.inactiveDaysMax,
      useNetDiffColumn: data.useNetDiffColumn,
      filterRechargeEnabled: data.filterRechargeEnabled,
      tieredFixedBonuses: data.tieredFixedBonuses,
      comprehensiveFeatures: data.comprehensiveFeatures,
      usesSplitRewards: data.usesSplitRewards,
      sites: data.sites
    }
    if (!mappingOverride.value) applyActivityMapping()
    if (isLoss7d || isComprehensiveLoss7d.value) applyLoss7dDefaultsFromBootstrap()
  } catch (e) {
    if (isInitial) throw e
  }
}

onUnmounted(() => {
  delete window.__dhpgRefreshBootstrap
  savePageState()
  clearInterval(pollTimer.value)
  clearTimeout(mappingLoadTimer.value)
})

watch(
  [tasks, settings, batchResult, showResults, selectedKey, resultSiteKey, mappingOverride],
  () => savePageState(),
  { deep: true }
)

function applyActivityMapping() {
  if (mappingOverride.value) {
    mappingDraft.value = cloneMapping(mappingOverride.value)
    return
  }
  mappingDraft.value = cloneMapping(bootstrap.value?.activityMapping ?? defaultMapping())
}

function savePageState() {
  try {
    sessionStorage.setItem(
      storageKey,
      JSON.stringify({
        tasks: tasks.value,
        settings: settings.value,
        batchResult: batchResult.value,
        showResults: showResults.value,
        selectedKey: selectedKey.value,
        resultSiteKey: resultSiteKey.value,
        mappingOverride: mappingOverride.value ? cloneMapping(mappingOverride.value) : null
      })
    )
  } catch {
    // ignore quota / private mode
  }
}

function restorePageState() {
  try {
    const raw = sessionStorage.getItem(storageKey)
    if (!raw) return false

    const saved = JSON.parse(raw)
    if (Array.isArray(saved.tasks) && saved.tasks.length > 0) tasks.value = saved.tasks
    if (saved.settings) settings.value = saved.settings
    if (saved.batchResult) {
      batchResult.value = saved.batchResult
      showResults.value = true
    } else if (typeof saved.showResults === 'boolean') {
      showResults.value = saved.showResults
    }
    if (saved.selectedKey) selectedKey.value = saved.selectedKey
    if (saved.resultSiteKey) resultSiteKey.value = saved.resultSiteKey
    if (saved.mappingOverride) mappingOverride.value = saved.mappingOverride
    applyActivityMapping()
    return tasks.value.length > 0
  } catch {
    return false
  }
}

watch(selectedKey, () => scheduleHeaderRefresh())

watch(
  () => settings.value.timezone,
  (timezone, previousTimezone) => {
    if ((!isLoss7d && !isComprehensiveLoss7d.value) || !timezone || previousTimezone === undefined) return
    settings.value.calculationDate = getTodayInTimezone(timezone)
  }
)

function applyLoss7dDefaultsFromBootstrap() {
  if ((!isLoss7d && !isComprehensiveLoss7d.value) || !bootstrap.value?.defaults) return
  const defaults = bootstrap.value.defaults
  if (defaults.timezone) {
    settings.value.timezone = String(defaults.timezone).toLowerCase()
  }
  if (!settings.value.calculationDate) {
    settings.value.calculationDate =
      defaults.calculationDate || getTodayInTimezone(settings.value.timezone || 'beijing')
  }
}

function scheduleHeaderRefresh() {
  clearTimeout(mappingLoadTimer.value)
  mappingLoadTimer.value = setTimeout(refreshMappingHeaders, 200)
}

async function refreshMappingHeaders() {
  await refreshMemberHeaders()
  await refreshUnclaimedHeaders()
}
watch(
  () => settings.value.filterUnclaimed,
  () => {
    if (readyCount.value === 0 && tasks.value.length === 0) addTask()
  }
)

function addTask() {
  const task = {
    key: crypto.randomUUID().replace(/-/g, ''),
    siteId: 0,
    memberFilePath: '',
    memberFileName: '',
    unclaimedFilePath: '',
    unclaimedFileName: '',
    rechargeFilePath: '',
    rechargeFileName: '',
    statusText: '待处理',
    displayRewardCount: 0,
    displayLossBonus: 0,
    displayProfitBonus: 0
  }
  tasks.value.push(task)
  selectedKey.value = task.key
}

function selectTaskRow(row) {
  if (!row?.key) return
  selectedKey.value = row.key
}

function removeTask(key) {
  const idx = tasks.value.findIndex((t) => t.key === key)
  if (idx < 0) return
  tasks.value.splice(idx, 1)
  if (selectedKey.value === key) {
    selectedKey.value = tasks.value[Math.min(idx, tasks.value.length - 1)]?.key ?? ''
  }
}

function assignSite(siteId) {
  if (!selectedTask.value || siteId == null || siteId === '') return
  if (assignedSiteIds.value.has(siteId) && selectedTask.value.siteId !== siteId) {
    ElMessage.warning('该站点已在队列中，请勿重复选择。')
    return
  }
  selectedTask.value.siteId = siteId
  scheduleHeaderRefresh()
}

async function refreshUnclaimedHeaders() {
  const task = selectedTask.value
  if (!task?.unclaimedFilePath) {
    unclaimedHeaders.value = []
    return
  }
  try {
    // 与 WPF 批量页一致：未领名单表头默认取第 1 行
    unclaimedHeaders.value = await api.previewHeaders(task.unclaimedFilePath, 0)
  } catch {
    unclaimedHeaders.value = []
  }
}

function onMappingEdited(next) {
  mappingDraft.value = next
  mappingOverride.value = cloneMapping(next)
}

async function refreshMemberHeaders() {
  const task = selectedTask.value
  if (!task?.memberFilePath) {
    memberHeaders.value = []
    return
  }
  const profile =
    mode === 'callback'
      ? 'callback'
      : mode === 'loss7d'
        ? 'loss7d'
        : mode === 'yesterdayloss'
          ? 'yesterdayloss'
          : mode === 'oldcallback234'
            ? 'oldcallback234'
            : mode === 'comprehensive'
              ? 'comprehensive'
              : 'period'
  const headerRow = mappingDraft.value[profile]?.headerRow ?? 0
  try {
    memberHeaders.value = await api.previewHeaders(task.memberFilePath, headerRow)
  } catch {
    memberHeaders.value = []
  }
}

async function saveMapping() {
  const activityId = bootstrap.value?.activityId
  if (!activityId) {
    ElMessage.warning('活动未加载。')
    return
  }
  try {
    await api.saveActivityMapping(activityId, mappingDraft.value)
    mappingOverride.value = null
    if (bootstrap.value) {
      bootstrap.value.activityMapping = cloneMapping(mappingDraft.value)
    }
    ElMessage.success('列映射已保存到活动，全部适用站点生效。')
  } catch (e) {
    ElMessage.error(e.message)
  }
}

async function pickMemberFile(task) {
  try {
    const uploaded = await api.pickAndStageFile()
    task.memberFilePath = uploaded.path
    task.memberFileName = uploaded.fileName
    if (task.key === selectedKey.value) await refreshMemberHeaders()
  } catch (e) {
    if (e.message !== '已取消') ElMessage.error(e.message)
  }
}

async function pickUnclaimedFile(task) {
  try {
    const uploaded = await api.pickAndStageFile()
    task.unclaimedFilePath = uploaded.path
    task.unclaimedFileName = uploaded.fileName
    if (task.key === selectedKey.value) await refreshUnclaimedHeaders()
  } catch (e) {
    if (e.message !== '已取消') ElMessage.error(e.message)
  }
}

async function pickRechargeFile(task) {
  try {
    const uploaded = await api.pickAndStageFile()
    task.rechargeFilePath = uploaded.path
    task.rechargeFileName = uploaded.fileName
  } catch (e) {
    if (e.message !== '已取消') ElMessage.error(e.message)
  }
}

function buildProcessPayload() {
  const payload = {
    mode:
      mode === 'callback'
        ? 'callback'
        : mode === 'loss7d'
          ? 'loss7d'
          : mode === 'yesterdayloss'
            ? 'yesterdayloss'
            : mode === 'oldcallback234'
              ? 'oldcallback234'
              : mode === 'comprehensive'
                ? 'comprehensive'
                : 'period',
    activityId: bootstrap.value.activityId,
    filterUnclaimed: settings.value.filterUnclaimed,
    filterRecharge: settings.value.filterRecharge,
    includeProfitMember: settings.value.includeProfitMember,
    wageringMultiplier: settings.value.wageringMultiplier,
    appRemark: settings.value.appRemark,
    backendRemark: settings.value.backendRemark,
    saveToHistory: true,
    tasks: tasks.value.map((t) => ({
      key: t.key,
      siteId: t.siteId,
      memberFilePath: t.memberFilePath,
      unclaimedFilePath: settings.value.filterUnclaimed ? t.unclaimedFilePath : null,
      rechargeFilePath: settings.value.filterRecharge ? t.rechargeFilePath : null,
      mappingOverride: mappingOverride.value ? cloneMapping(mappingOverride.value) : null
    }))
  }
  if (isLoss7d || isComprehensiveLoss7d.value) {
    payload.calculationDate = effectiveCalculationDate.value
    payload.timezone = settings.value.timezone || bootstrap.value?.defaultTimezone || 'beijing'
  }
  return payload
}

async function startBatch() {
  if (!bootstrap.value?.activityId) {
    ElMessage.warning('活动未加载，请检查活动管理。')
    return
  }
  if (readyCount.value === 0) {
    ElMessage.warning('请至少添加一行有效任务（站点 + 会员文件）。')
    return
  }

  if (tasks.value.some((t) => !isTaskReady(t, settings.value.filterUnclaimed, settings.value.filterRecharge))) {
    const extras = []
    if (settings.value.filterUnclaimed) extras.push('未领名单')
    if (settings.value.filterRecharge) extras.push('充值数据')
    ElMessage.warning('请完善所有队列行（站点 + 会员文件' + (extras.length ? ' + ' + extras.join(' + ') : '') + '）后再开始。')
    return
  }

  const siteIds = tasks.value.map((t) => t.siteId).filter((id) => id > 0)
  if (new Set(siteIds).size !== siteIds.length) {
    ElMessage.warning('同一批次中站点不可重复。')
    return
  }

  processing.value = true
  progress.value = { message: '正在启动...', percent: 0 }
  showResults.value = false
  batchResult.value = null

  try {
    await api.startBatch(buildProcessPayload())
    pollTimer.value = setInterval(pollStatus, 500)
  } catch (e) {
    processing.value = false
    ElMessage.error(e.message)
  }
}

async function pollStatus() {
  try {
    const status = await api.batchStatus()
    progress.value = status.progress
      ? { message: status.progress.message || status.progress.phase, percent: status.progress.percent ?? 0 }
      : progress.value

    if (status.running) return

    clearInterval(pollTimer.value)
    processing.value = false

    if (status.error && !status.result) {
      ElMessage.warning(status.error)
      return
    }

    if (status.result) {
      batchResult.value = status.result
      syncTaskRowsFromResult(status.result)
      expandBatchResults()
      ElMessage.success(formatBatchBonusMessage(status.result, settings.value.includeProfitMember, usesSplitRewards.value))
    }
  } catch (e) {
    clearInterval(pollTimer.value)
    processing.value = false
    ElMessage.error(e.message)
  }
}

function syncTaskRowsFromResult(result) {
  for (const rt of result.tasks) {
    const row = tasks.value.find((t) => t.key === rt.key)
    if (!row) continue
    row.statusText = rt.statusText
    row.displayRewardCount = rt.summary?.rewardCount ?? 0
    const split = rt.usesSplitRewards ?? usesSplitRewards.value
    row.displayLossBonus = resolveLossBonus(rt.summary, split)
    row.displayProfitBonus = resolveProfitBonus(rt.summary, split)
  }
}

async function cancelBatch() {
  try {
    await api.cancelBatch()
  } catch (e) {
    ElMessage.error(e.message)
  }
}

async function openResults() {
  showResults.value = !showResults.value
  if (showResults.value && activeResultTask.value?.resultCacheKey) {
    await loadResultPanel()
  }
}

function expandBatchResults() {
  if (!batchResult.value) return

  if (!resultSiteKey.value && batchResult.value.tasks.length > 0) {
    resultSiteKey.value = batchResult.value.tasks[0].key
  }

  showResults.value = true
  if (activeResultTask.value?.resultCacheKey) {
    void loadResultPanel()
  }
}

watch(resultSiteKey, () => {
  detailPage.value = 1
  rewardPage.value = 1
  lossPage.value = 1
  profitPage.value = 1
  if (showResults.value) loadResultPanel()
})

watch([detailPage, detailExcludedOnly, activeRewardTab, rewardPage, lossPage, profitPage], () => {
  if (showResults.value) loadResultPanel()
})

async function loadResultPanel() {
  const task = activeResultTask.value
  if (!task?.resultCacheKey || task.status !== 'success') {
    resultSummary.value = null
    detailRows.value = []
    rewardRows.value = []
    return
  }

  try {
    resultSummary.value = await api.resultSummary(task.resultCacheKey)
    const skipDetail = (detailPage.value - 1) * PAGE_SIZE
    const details = await api.resultDetails(task.resultCacheKey, skipDetail, PAGE_SIZE, detailExcludedOnly.value)
    detailRows.value = details.items
    detailTotal.value = details.total

    if (usesSplitRewards.value) {
      const loss = await api.resultRewards(task.resultCacheKey, 'loss', (lossPage.value - 1) * PAGE_SIZE, PAGE_SIZE)
      const profit = await api.resultRewards(task.resultCacheKey, 'profit', (profitPage.value - 1) * PAGE_SIZE, PAGE_SIZE)
      lossRows.value = loss.items
      lossTotal.value = loss.total
      profitRows.value = profit.items
      profitTotal.value = profit.total
    } else {
      const rewards = await api.resultRewards(
        task.resultCacheKey,
        'merged',
        (rewardPage.value - 1) * PAGE_SIZE,
        PAGE_SIZE
      )
      rewardRows.value = rewards.items
      rewardTotal.value = rewards.total
    }
  } catch (e) {
    ElMessage.error(e.message)
  }
}

async function exportSite() {
  const key = activeResultTask.value?.resultCacheKey
  if (!key) return ElMessage.warning('当前站点无可导出结果。')
  try {
    const res = await api.exportExcel(key)
    ElMessage.success(res.success ? `已导出：${res.filePath}` : res.message)
  } catch (e) {
    ElMessage.error(e.message)
  }
}

async function exportAll() {
  if (!batchResult.value?.successCount) return ElMessage.warning('暂无成功站点。')
  try {
    const res = await api.exportBatchAll(batchResult.value)
    ElMessage.success(res.success ? res.message || `已导出：${res.filePath}` : res.message)
  } catch (e) {
    ElMessage.error(e.message)
  }
}

async function copyRewards(kind) {
  const task = activeResultTask.value
  if (!task?.resultCacheKey) return ElMessage.warning('当前站点暂无派奖数据。')
  try {
    const res = await api.rewardsTsv(task.resultCacheKey, kind)
    await navigator.clipboard.writeText(res.text)
    ElMessage.success(`已复制 ${task.siteName} 的派奖表。`)
  } catch (e) {
    ElMessage.error(e.message || '复制失败')
  }
}

function tabHeader(task) {
  return task.status === 'success' ? task.siteName : `${task.siteName} (${task.statusText})`
}

function formatMoney(value) {
  const n = Number(value)
  return Number.isFinite(n) ? n.toFixed(2) : '0.00'
}
</script>

<template>
  <div v-loading="loading" class="page">
    <div class="card-block">
      <div class="rule-text">{{ displayRuleFormula }}</div>
    </div>

    <div class="card-block">
      <div class="toolbar-row">
        <el-button type="primary" :disabled="processing" @click="addTask">+ 添加站点</el-button>
        <span>当前行站点：</span>
        <el-select
          :model-value="selectedTask?.siteId || null"
          placeholder="选中队列行后选择站点"
          filterable
          clearable
          style="width: 320px"
          :disabled="!selectedTask || processing || sites.length === 0"
          @update:model-value="assignSite"
        >
          <el-option
            v-for="s in sites"
            :key="s.id"
            :label="`${s.name}（${s.code}）`"
            :value="s.id"
          />
        </el-select>
        <span v-if="sites.length === 0" class="site-hint">暂无可用站点，请先在站点管理中创建并启用。</span>
      </div>

      <el-table
        :data="tasks"
        height="240"
        highlight-current-row
        size="small"
        row-key="key"
        :current-row-key="selectedKey"
        @current-change="(row) => selectTaskRow(row)"
        @row-click="(row) => selectTaskRow(row)"
      >
        <el-table-column label="站点" width="120">
          <template #default="{ row }">{{ siteDisplay(row, sites) }}</template>
        </el-table-column>
        <el-table-column label="会员数据" min-width="220">
          <template #default="{ row }">
            <el-button size="small" :disabled="processing" @click="pickMemberFile(row)">选择文件</el-button>
            <span style="margin-left: 8px; color: #909399">{{ row.memberFileName || fileName(row.memberFilePath) }}</span>
          </template>
        </el-table-column>
        <el-table-column v-if="settings.filterUnclaimed" label="未领名单" min-width="220">
          <template #default="{ row }">
            <el-button size="small" :disabled="processing" @click="pickUnclaimedFile(row)">选择文件</el-button>
            <span style="margin-left: 8px; color: #909399">{{ row.unclaimedFileName || fileName(row.unclaimedFilePath) }}</span>
          </template>
        </el-table-column>
        <el-table-column v-if="settings.filterRecharge" label="充值数据" min-width="220">
          <template #default="{ row }">
            <el-button size="small" :disabled="processing" @click="pickRechargeFile(row)">选择文件</el-button>
            <span style="margin-left: 8px; color: #909399">{{ row.rechargeFileName || fileName(row.rechargeFilePath) }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="statusText" label="状态" width="72" />
        <el-table-column prop="displayRewardCount" label="派发人数" width="80" />
        <el-table-column label="亏损彩金" width="96">
          <template #default="{ row }">{{ formatMoney(row.displayLossBonus) }}</template>
        </el-table-column>
        <el-table-column v-if="showProfitBonusColumn" label="盈利彩金" width="96">
          <template #default="{ row }">{{ formatMoney(row.displayProfitBonus) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="70">
          <template #default="{ row }">
            <el-button type="danger" link :disabled="processing" @click="removeTask(row.key)">移除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <div class="card-block mapping-card">
      <div class="mapping-header">
        <span class="mapping-label">{{ mappingLabel }}</span>
        <el-button
          type="primary"
          size="small"
          :disabled="!bootstrap?.activityId || processing"
          @click="saveMapping"
        >
          保存列映射到活动
        </el-button>
      </div>
      <MappingForm
        :mapping="mappingDraft"
        :member-headers="memberHeaders"
        :unclaimed-headers="unclaimedHeaders"
        :profile="mode"
        @update:mapping="onMappingEdited"
        @header-row-change="refreshMemberHeaders"
      />
    </div>

    <div class="card-block">
      <el-form inline size="small">
        <el-form-item>
          <el-checkbox v-model="settings.filterUnclaimed" :disabled="processing">过滤未领彩金会员</el-checkbox>
        </el-form-item>
        <el-form-item v-if="isOldCallback234 || isComprehensive">
          <el-checkbox v-model="settings.filterRecharge" :disabled="processing">过滤充值数据（需上传充值文件）</el-checkbox>
        </el-form-item>
        <el-form-item v-if="!isComprehensiveLoss7d">
          <el-checkbox v-model="settings.includeProfitMember" :disabled="processing">包含盈利会员</el-checkbox>
        </el-form-item>
        <template v-if="showLoss7dDateSettings">
          <el-form-item label="时区">
            <el-select v-model="settings.timezone" style="width: 120px" :disabled="processing">
              <el-option label="北京时间" value="beijing" />
              <el-option label="巴西时间" value="brazil" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <template #label>
              <span>计算日期</span>
              <span v-if="calculationDateSummary" class="weekday-hint">（{{ calculationDateSummary }}）</span>
            </template>
            <el-date-picker
              v-model="settings.calculationDate"
              type="date"
              value-format="YYYY-MM-DD"
              :placeholder="calculationDateSummary || '默认当天'"
              style="width: 180px"
              :disabled="processing"
            />
          </el-form-item>
        </template>
        <el-form-item label="打码倍数">
          <el-input-number v-model="settings.wageringMultiplier" :min="0" :step="0.1" :disabled="processing" />
        </el-form-item>
        <el-form-item label="APP 备注">
          <el-input v-model="settings.appRemark" style="width: 160px" :disabled="processing" />
        </el-form-item>
        <el-form-item label="后台备注">
          <el-input v-model="settings.backendRemark" style="width: 160px" :disabled="processing" />
        </el-form-item>
      </el-form>
    </div>

    <div class="card-block">
      <div class="toolbar-row">
        <el-button type="primary" :disabled="processing || readyCount === 0" @click="startBatch">
          批量计算彩金（{{ readyCount }} 个站点）
        </el-button>
        <el-button v-if="batchResult" @click="openResults">
          {{ showResults ? '▲ 收起批量处理结果' : '▼ 查看批量处理结果' }}
        </el-button>
        <el-button :disabled="!batchResult?.successCount || processing" @click="exportAll">导出全部成功站点</el-button>
        <el-button v-if="processing" type="danger" @click="cancelBatch">取消</el-button>
      </div>
      <el-progress v-if="processing || progress" :percentage="Math.round(progress?.percent || 0)" :stroke-width="14" />
      <div v-if="progress?.message" style="margin-top: 6px; color: #606266; font-size: 13px">{{ progress.message }}</div>
    </div>

    <div v-if="showResults && batchResult" class="card-block">
      <el-tabs v-model="resultSiteKey" type="card">
        <el-tab-pane v-for="t in resultTasks" :key="t.key" :label="tabHeader(t)" :name="t.key" />
      </el-tabs>

      <template v-if="activeResultTask?.resultCacheKey && activeResultTask.status === 'success'">
        <div class="stat-grid">
          <div class="stat-item"><div class="label">会员数</div><div class="value">{{ resultSummary?.summary?.totalCount ?? 0 }}</div></div>
          <div class="stat-item"><div class="label">过滤人数</div><div class="value">{{ resultSummary?.summary?.filteredCount ?? 0 }}</div></div>
          <div v-if="!usesSplitRewards" class="stat-item"><div class="label">派发人数</div><div class="value">{{ resultSummary?.summary?.rewardCount ?? 0 }}</div></div>
          <div v-if="usesSplitRewards" class="stat-item"><div class="label">亏损派发</div><div class="value">{{ resultSummary?.lossRewardCount ?? 0 }}</div></div>
          <div v-if="usesSplitRewards" class="stat-item"><div class="label">盈利派发</div><div class="value">{{ resultSummary?.profitRewardCount ?? 0 }}</div></div>
          <div class="stat-item"><div class="label">亏损彩金</div><div class="value">{{ formatMoney(activeLossBonus) }}</div></div>
          <div v-if="showProfitBonusColumn" class="stat-item"><div class="label">盈利彩金</div><div class="value">{{ formatMoney(activeProfitBonus) }}</div></div>
        </div>

        <div class="toolbar-row">
          <el-button size="small" @click="exportSite">导出本站 Excel</el-button>
          <el-button v-if="!usesSplitRewards" size="small" @click="copyRewards('merged')">
            {{ copyRewardsLabel('merged') }}
          </el-button>
          <template v-else>
            <el-button size="small" @click="copyRewards('loss')">{{ copyRewardsLabel('loss') }}</el-button>
            <el-button size="small" @click="copyRewards('profit')">{{ copyRewardsLabel('profit') }}</el-button>
            <el-button size="small" @click="copyRewards('all')">{{ copyRewardsLabel('all') }}</el-button>
          </template>
        </div>

        <el-tabs model-value="detail">
          <el-tab-pane label="处理明细" name="detail">
            <div class="toolbar-row">
              <el-checkbox v-model="detailExcludedOnly">仅显示剔除行</el-checkbox>
              <span class="pager-hint">预览每页 {{ PAGE_SIZE }} 条；导出/复制为全量。</span>
            </div>
            <el-table :data="detailRows" size="small" max-height="280">
              <el-table-column prop="userId" label="会员 ID" width="120" />
              <el-table-column label="充值" width="90">
                <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.pay) }}</span></template>
              </el-table-column>
              <el-table-column label="提现" width="90">
                <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.withdraw) }}</span></template>
              </el-table-column>
              <el-table-column label="盈亏" width="90">
                <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.profit) }}</span></template>
              </el-table-column>
              <el-table-column label="彩金" width="90">
                <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.bonus) }}</span></template>
              </el-table-column>
              <el-table-column prop="excludeReason" label="剔除原因" min-width="140" />
            </el-table>
            <PageJump v-model="detailPage" :total="detailTotal" :page-size="PAGE_SIZE" />
          </el-tab-pane>

          <el-tab-pane v-if="!usesSplitRewards" label="派奖结果" name="rewards">
            <el-table :data="rewardRows" size="small" max-height="280">
              <el-table-column prop="userId" label="会员 ID" width="120" />
              <el-table-column label="彩金" width="100">
                <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.bonus) }}</span></template>
              </el-table-column>
              <el-table-column label="打码倍数" width="88">
                <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.wageringMultiplier) }}</span></template>
              </el-table-column>
              <el-table-column prop="appRemark" label="APP 备注" min-width="120" />
              <el-table-column prop="backendRemark" label="后台备注" min-width="120" />
            </el-table>
            <PageJump v-model="rewardPage" :total="rewardTotal" :page-size="PAGE_SIZE" />
          </el-tab-pane>

          <template v-else>
            <el-tab-pane label="亏损派奖" name="loss">
              <el-table :data="lossRows" size="small" max-height="280">
                <el-table-column prop="userId" label="会员 ID" width="120" />
                <el-table-column label="彩金" width="100">
                  <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.bonus) }}</span></template>
                </el-table-column>
                <el-table-column label="打码倍数" width="88">
                  <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.wageringMultiplier) }}</span></template>
                </el-table-column>
                <el-table-column prop="appRemark" label="APP 备注" min-width="120" />
                <el-table-column prop="backendRemark" label="后台备注" min-width="120" />
              </el-table>
              <PageJump v-model="lossPage" :total="lossTotal" :page-size="PAGE_SIZE" />
            </el-tab-pane>
            <el-tab-pane label="盈利派奖" name="profit">
              <el-table :data="profitRows" size="small" max-height="280">
                <el-table-column prop="userId" label="会员 ID" width="120" />
                <el-table-column label="彩金" width="100">
                  <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.bonus) }}</span></template>
                </el-table-column>
                <el-table-column label="打码倍数" width="88">
                  <template #default="{ row }"><span class="num-cell">{{ formatMoney(row.wageringMultiplier) }}</span></template>
                </el-table-column>
                <el-table-column prop="appRemark" label="APP 备注" min-width="120" />
                <el-table-column prop="backendRemark" label="后台备注" min-width="120" />
              </el-table>
              <PageJump v-model="profitPage" :total="profitTotal" :page-size="PAGE_SIZE" />
            </el-tab-pane>
          </template>
        </el-tabs>
      </template>

      <el-alert
        v-else-if="activeResultTask"
        :title="activeResultTask.errorMessage || activeResultTask.statusText"
        type="warning"
        show-icon
        :closable="false"
      />
    </div>
  </div>
</template>

import { isWebViewHost, pickAndStageFileViaBridge } from './webviewBridge.js'

const jsonHeaders = { 'Content-Type': 'application/json' }

async function request(url, options = {}) {
  let res
  try {
    res = await fetch(url, options)
  } catch (error) {
    const message =
      error instanceof TypeError
        ? '无法连接本地服务，请确认 DHPG 已正常启动后重试。'
        : error?.message || '网络请求失败'
    throw new Error(message)
  }

  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    throw new Error(data.message || `请求失败 (${res.status})`)
  }
  return data
}

export function getMode() {
  const mode = new URLSearchParams(window.location.search).get('mode')
  if (mode === 'callback') return 'callback'
  if (mode === 'loss7d') return 'loss7d'
  if (mode === 'yesterdayloss') return 'yesterdayloss'
  if (mode === 'oldcallback234') return 'oldcallback234'
  if (mode === 'comprehensive') return 'comprehensive'
  return 'period'
}

export const api = {
  bootstrap(mode) {
    return request(`/api/batch/bootstrap?mode=${mode}`)
  },
  listSites() {
    return request('/api/sites')
  },
  saveActivityMapping(activityId, mapping) {
    return request(`/api/activities/${activityId}/mapping`, {
      method: 'PUT',
      headers: jsonHeaders,
      body: JSON.stringify(mapping)
    })
  },
  async pickAndStageFile() {
    if (isWebViewHost()) {
      return pickAndStageFileViaBridge()
    }

    return new Promise((resolve, reject) => {
      const input = document.createElement('input')
      input.type = 'file'
      input.accept = '.xlsx,.xls,.xlsm,.csv'
      input.onchange = async () => {
        const file = input.files?.[0]
        if (!file) {
          reject(new Error('已取消'))
          return
        }
        try {
          resolve(await this.uploadFile(file))
        } catch (error) {
          reject(error)
        }
      }
      input.oncancel = () => reject(new Error('已取消'))
      input.click()
    })
  },
  async uploadFile(file) {
    const form = new FormData()
    form.append('file', file)
    let res
    try {
      res = await fetch('/api/files/upload', { method: 'POST', body: form })
    } catch (error) {
      throw new Error(
        error instanceof TypeError
          ? '文件上传失败：连接本地服务中断，若文件较大请稍后重试或压缩后再传。'
          : error?.message || '上传失败'
      )
    }
    const data = await res.json().catch(() => ({}))
    if (!res.ok) throw new Error(data.message || `上传失败 (${res.status})`)
    return data
  },
  previewHeaders(path, headerRow) {
    const q = new URLSearchParams({ path, headerRow: String(headerRow) })
    return request(`/api/files/headers?${q}`)
  },
  startBatch(body) {
    return request('/api/batch/process', {
      method: 'POST',
      headers: jsonHeaders,
      body: JSON.stringify(body)
    })
  },
  batchStatus() {
    return request('/api/batch/status')
  },
  cancelBatch() {
    return request('/api/batch/cancel', { method: 'POST' })
  },
  resultSummary(cacheKey) {
    return request(`/api/results/${encodeURIComponent(cacheKey)}/summary`)
  },
  resultDetails(cacheKey, skip, take, excludedOnly) {
    const q = new URLSearchParams({
      skip: String(skip),
      take: String(take),
      excludedOnly: String(excludedOnly)
    })
    return request(`/api/results/${encodeURIComponent(cacheKey)}/details?${q}`)
  },
  resultRewards(cacheKey, kind, skip, take) {
    const q = new URLSearchParams({
      kind,
      skip: String(skip),
      take: String(take)
    })
    return request(`/api/results/${encodeURIComponent(cacheKey)}/rewards?${q}`)
  },
  exportExcel(cacheKey) {
    return request('/api/export/excel', {
      method: 'POST',
      headers: jsonHeaders,
      body: JSON.stringify({ cacheKey })
    })
  },
  exportBatchAll(result) {
    return request('/api/export/batch-all', {
      method: 'POST',
      headers: jsonHeaders,
      body: JSON.stringify({ result })
    })
  },
  rewardsTsv(cacheKey, kind) {
    return request('/api/export/rewards-tsv', {
      method: 'POST',
      headers: jsonHeaders,
      body: JSON.stringify({ cacheKey, kind })
    })
  },
  downloadTemplate() {
    window.open('/api/templates/member', '_blank')
  }
}

export function indexToColumn(index) {
  let n = index + 1
  let s = ''
  while (n > 0) {
    const r = (n - 1) % 26
    s = String.fromCharCode(65 + r) + s
    n = Math.floor((n - 1) / 26)
  }
  return s
}

export function buildColumnOptions(headers) {
  if (headers?.length) {
    return headers.map((label, index) => ({
      value: index,
      label: `${indexToColumn(index)} · ${label || '(空)'}`
    }))
  }
  return Array.from({ length: 52 }, (_, index) => ({
    value: index,
    label: indexToColumn(index)
  }))
}

export function defaultMapping() {
  return {
    period: {
      userIdColumn: 0,
      payColumn: 5,
      withdrawColumn: 7,
      phoneColumn: 17,
      tierColumn: 21,
      headerRow: 0
    },
    callback: {
      userIdColumn: 5,
      payColumn: 8,
      withdrawColumn: 9,
      phoneColumn: 23,
      tierColumn: 24,
      headerRow: 0
    },
    loss7d: {
      userIdColumn: 5,
      payColumn: 8,
      withdrawColumn: 9,
      phoneColumn: 23,
      tierColumn: 24,
      headerRow: 0
    },
    yesterdayLoss: {
      userIdColumn: 1,
      payColumn: 11,
      withdrawColumn: 12,
      netDiffColumn: 18,
      phoneColumn: 19,
      tierColumn: 20,
      headerRow: 0
    },
    oldCallback234: {
      userIdColumn: 0,
      payColumn: 5,
      withdrawColumn: 7,
      netDiffColumn: 8,
      inactiveDaysColumn: 16,
      phoneColumn: 17,
      tierColumn: 21,
      headerRow: 0
    },
    comprehensive: {
      userIdColumn: 0,
      payColumn: 5,
      withdrawColumn: 7,
      netDiffColumn: 8,
      inactiveDaysColumn: 16,
      phoneColumn: 17,
      tierColumn: 21,
      headerRow: 0
    },
    recharge: {
      userIdColumn: 1,
      amountColumn: 5,
      headerRow: 0
    },
    unclaimedUserIdColumn: 1
  }
}

export function cloneMapping(mapping) {
  return JSON.parse(JSON.stringify(mapping))
}

export function isTaskReady(task, filterUnclaimed, filterRecharge = false) {
  if (!task.siteId || !task.memberFilePath) return false
  if (filterUnclaimed && !task.unclaimedFilePath) return false
  if (filterRecharge && !task.rechargeFilePath) return false
  return true
}

export function siteDisplay(task, sites) {
  if (!task.siteId) return '未选择'
  const site = sites.find((s) => s.id === task.siteId)
  return site?.name || `站点 ${task.siteId}`
}

export function fileName(path) {
  if (!path) return '未选择'
  const parts = path.replace(/\\/g, '/').split('/')
  return parts[parts.length - 1] || path
}

/** 亏损侧彩金：拆分表用 lossTotalBonus，时段等合并表用 totalBonus */
export function resolveLossBonus(summary, usesSplitRewards) {
  if (!summary) return 0
  return usesSplitRewards ? Number(summary.lossTotalBonus ?? 0) : Number(summary.totalBonus ?? 0)
}

/** 盈利侧彩金（仅回访拆分表有效） */
export function resolveProfitBonus(summary, usesSplitRewards) {
  if (!summary || !usesSplitRewards) return 0
  return Number(summary.profitTotalBonus ?? 0)
}

export function shouldShowProfitBonus(includeProfitMember, usesSplitRewards) {
  return includeProfitMember === true && usesSplitRewards === true
}

export function formatBatchBonusMessage(result, includeProfitMember, usesSplitRewards) {
  const tasks = result?.tasks ?? []
  let loss = 0
  let profit = 0
  for (const t of tasks) {
    if (t.status !== 'success' || !t.summary) continue
    const split = t.usesSplitRewards ?? usesSplitRewards
    loss += resolveLossBonus(t.summary, split)
    if (shouldShowProfitBonus(includeProfitMember, split)) {
      profit += resolveProfitBonus(t.summary, split)
    }
  }
  const head = `批量完成：成功 ${result.successCount}，失败 ${result.failedCount}`
  if (shouldShowProfitBonus(includeProfitMember, usesSplitRewards)) {
    return `${head}，亏损彩金 ${loss.toFixed(2)}，盈利彩金 ${profit.toFixed(2)}`
  }
  return `${head}，亏损彩金 ${loss.toFixed(2)}`
}

function formatDecimal(value) {
  return Number(value ?? 0).toFixed(2)
}

function formatRatePercent(rate) {
  const percent = Number(rate ?? 0) * 100
  const text = percent.toFixed(2)
  return text.replace(/\.?0+$/, '')
}

const weekdayNames = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']
const weekdayRateKeys = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']

function formatTimezoneLabel(timezone) {
  return timezone === 'brazil' || timezone === 'Brazil' ? '巴西时间' : '北京时间'
}

export function getTodayInTimezone(timezone) {
  const tz = timezone === 'brazil' || timezone === 'Brazil' ? 'America/Sao_Paulo' : 'Asia/Shanghai'
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: tz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date())
}

export function resolveEffectiveCalculationDate(settings, bootstrap) {
  return settings?.calculationDate || bootstrap?.defaultCalculationDate || getTodayInTimezone(settings?.timezone || bootstrap?.defaultTimezone || 'beijing') || ''
}

export function resolveWeekdayName(calculationDate) {
  if (!calculationDate) return '当天'
  const parts = calculationDate.split('-').map(Number)
  if (parts.length !== 3 || parts.some((n) => !Number.isFinite(n))) return '当天'
  const date = new Date(parts[0], parts[1] - 1, parts[2])
  return weekdayNames[date.getDay()] ?? '当天'
}

export function getWeeklyRate(weeklyDayRates, calculationDate) {
  if (!weeklyDayRates || !calculationDate) return null
  const parts = calculationDate.split('-').map(Number)
  if (parts.length !== 3 || parts.some((n) => !Number.isFinite(n))) return null
  const date = new Date(parts[0], parts[1] - 1, parts[2])
  const value = weeklyDayRates[weekdayRateKeys[date.getDay()]]
  return value == null || Number(value) <= 0 ? null : Number(value)
}

export function formatLoss7dDaySummary(weeklyDayRates, calculationDate) {
  if (!calculationDate) return ''
  const weekday = resolveWeekdayName(calculationDate)
  const rate = getWeeklyRate(weeklyDayRates, calculationDate)
  const rateText = rate == null ? '未配置比例' : `${formatRatePercent(rate)}%`
  return `${weekday} · ${rateText}`
}

/** 与后端 BatchApiMapper.BuildRuleFormulaText 一致；打码/盈利会员取当前页面设置 */
export function buildRuleFormulaText(activityRule, wageringMultiplier, includeProfitMember) {
  if (!activityRule) return ''
  const maxBonus = Number(activityRule.maxBonus ?? 0)
  const minBonus = Number(activityRule.minBonus ?? 0)
  const maxText = maxBonus > 0 ? `最高 ${formatDecimal(maxBonus)}` : '最高不限'
  const profitText = includeProfitMember
    ? `盈利会员（充值-提现<0）固定 ${formatDecimal(minBonus)}`
    : '盈利会员默认剔除'
  const ratePercent = formatRatePercent(activityRule.rate)
  const divisor = Number(activityRule.divisor ?? 1)
  return (
    `用户亏损/持平（充值-提现≥0）：(充值-提现)×${ratePercent}%÷${divisor}，` +
    `最低 ${formatDecimal(minBonus)}，${maxText}；${profitText}；打码 ${formatDecimal(wageringMultiplier)}。`
  )
}

/** 与后端 BatchApiMapper.BuildLoss7dRuleFormulaText 一致 */
export function buildLoss7dRuleFormulaText(bootstrap, settings) {
  if (!bootstrap) return ''
  const minBonus = Number(bootstrap.activityRule?.minBonus ?? 0)
  const calculationDate = resolveEffectiveCalculationDate(settings, bootstrap)
  const timezone = settings.timezone || bootstrap.defaultTimezone || 'beijing'
  const weekday = resolveWeekdayName(calculationDate)
  const dayRate = getWeeklyRate(bootstrap.weeklyDayRates, calculationDate)
  const rateText = dayRate == null ? '未配置' : `${formatRatePercent(dayRate)}%`
  const lossText = bootstrap.filterLossMember
    ? '启用亏损过滤（累计充值-累计提现≥0）'
    : '默认不筛亏损'
  const unclaimedText = bootstrap.filterUnclaimedEnabled
    ? '启用未领过滤'
    : '未启用未领过滤'
  return (
    `${LOSS7D_ACTIVITY_NAME}：彩金=累计充值×${weekday}比例（${rateText}），` +
    `最低 ${formatDecimal(minBonus)}；${lossText}；${unclaimedText}；` +
    `计算日 ${calculationDate}（${weekday} · ${formatTimezoneLabel(timezone)}）；` +
    `打码 ${formatDecimal(settings.wageringMultiplier)}。`
  )
}

export const LOSS7D_ACTIVITY_NAME = '老回访1567'
export const YESTERDAY_LOSS_ACTIVITY_NAME = '昨日亏损'
export const OLD_CALLBACK234_ACTIVITY_NAME = '老回访234'
export const COMPREHENSIVE_ACTIVITY_NAME = '综合回访'

export const COMPREHENSIVE_BONUS_MODE = {
  StandardMerged: 0,
  StandardSplit: 1,
  Loss7dWeekly: 2,
  YesterdayLossTiered: 3,
  OldCallback234Fixed: 4
}

export function formatComprehensiveBonusMode(mode) {
  switch (Number(mode)) {
    case COMPREHENSIVE_BONUS_MODE.StandardMerged:
      return '时段彩金（合并派奖）'
    case COMPREHENSIVE_BONUS_MODE.StandardSplit:
      return '回访彩金（拆分派奖）'
    case COMPREHENSIVE_BONUS_MODE.Loss7dWeekly:
      return '老回访1567（累计充值×日比例）'
    case COMPREHENSIVE_BONUS_MODE.YesterdayLossTiered:
      return '昨日亏损（充提差×比例）'
    case COMPREHENSIVE_BONUS_MODE.OldCallback234Fixed:
      return '老回访234（固定金额档位）'
    default:
      return '未配置'
  }
}

export function buildComprehensiveRuleFormulaText(bootstrap, settings) {
  if (!bootstrap) return ''
  const features = bootstrap.comprehensiveFeatures ?? {}
  const modeText = formatComprehensiveBonusMode(features.bonusMode)
  const inactiveText = features.enableInactiveDaysFilter
    ? `启用 Q 列 0～${Number(bootstrap.inactiveDaysMax ?? 7)} 天未登录过滤`
    : '未启用未登录过滤'
  const minNetDiffText = features.enableMinNetDiffGate
    ? `启用充提差≥${formatDecimal(bootstrap.minNetDiff ?? 20)} 门槛`
    : '未启用充提差门槛'
  const lossText = bootstrap.filterLossMember ? '启用亏损过滤' : '未启用亏损过滤'
  const unclaimedText = bootstrap.filterUnclaimedEnabled ? '启用未领过滤' : '未启用未领过滤'
  const rechargeText = bootstrap.filterRechargeEnabled ? '启用充值数据过滤' : '未启用充值数据过滤'
  const profitText = settings.includeProfitMember
    ? `允许盈利会员（固定 ${formatDecimal(bootstrap.activityRule?.minBonus ?? 0)}）`
    : '盈利会员默认剔除'

  return (
    `${COMPREHENSIVE_ACTIVITY_NAME}：计算方式=${modeText}；${inactiveText}；${minNetDiffText}；${lossText}；` +
    `${unclaimedText}；${rechargeText}；${profitText}；打码 ${formatDecimal(settings.wageringMultiplier)}。`
  )
}

export function buildYesterdayLossRuleFormulaText(bootstrap, settings) {
  if (!bootstrap) return ''
  const minBonus = Number(bootstrap.activityRule?.minBonus ?? 0)
  const minNetDiff = Number(bootstrap.minNetDiff ?? 20)
  const tierText = formatTieredRatesText(bootstrap.tieredAmountRates)
  const unclaimedText = bootstrap.filterUnclaimedEnabled
    ? '启用未领过滤'
    : '未启用未领过滤'
  return (
    `${YESTERDAY_LOSS_ACTIVITY_NAME}：彩金=当日充提差×派送比例（${tierText}），` +
    `充提差≥${formatDecimal(minNetDiff)} 才计算，最低彩金 ${formatDecimal(minBonus)}；${unclaimedText}；` +
    `打码 ${formatDecimal(settings.wageringMultiplier)}。`
  )
}

export function buildOldCallback234RuleFormulaText(bootstrap, settings) {
  if (!bootstrap) return ''
  const minBonus = Number(bootstrap.activityRule?.minBonus ?? 0)
  const inactiveDaysMax = Number(bootstrap.inactiveDaysMax ?? 7)
  const tierText = formatTieredFixedBonusesText(bootstrap.tieredFixedBonuses)
  const unclaimedText = bootstrap.filterUnclaimedEnabled ? '启用未领过滤' : '未启用未领过滤'
  const rechargeText = bootstrap.filterRechargeEnabled ? '启用充值数据过滤' : '未启用充值数据过滤'
  const profitText = settings.includeProfitMember
    ? `盈利会员固定 ${formatDecimal(minBonus)}`
    : '盈利会员默认剔除'
  const netDiffText = bootstrap.useNetDiffColumn ? '直接使用 I 列充提差' : 'F 列充值 - H 列提现'

  return (
    `${OLD_CALLBACK234_ACTIVITY_NAME}：盈亏=${netDiffText}（负=盈利，正=亏损）；` +
    `Q 列保留 0～${inactiveDaysMax} 天未登录；亏损派送（${tierText}）；${profitText}；${unclaimedText}；${rechargeText}；` +
    `打码 ${formatDecimal(settings.wageringMultiplier)}。`
  )
}

function formatTieredFixedBonusesText(bonuses) {
  const tiers = bonuses?.tiers ?? []
  if (!tiers.length) return '未配置'
  return tiers
    .slice()
    .sort((a, b) => Number(a.minAmount) - Number(b.minAmount))
    .map((tier) => {
      const max =
        tier.maxAmount == null || Number(tier.maxAmount) <= 0
          ? '以上'
          : Number(tier.maxAmount).toFixed(2).replace(/\.?0+$/, '')
      return `亏损 ${Number(tier.minAmount)}-${max} 送 ${Number(tier.bonus ?? 0).toFixed(2).replace(/\.?0+$/, '')}`
    })
    .join('；')
}

function formatTieredRatesText(rates) {
  const tiers = rates?.tiers ?? []
  if (!tiers.length) return '未配置'
  return tiers
    .slice()
    .sort((a, b) => Number(a.minAmount) - Number(b.minAmount))
    .map((tier) => {
      const max = tier.maxAmount == null || Number(tier.maxAmount) <= 0
        ? '以上'
        : Number(tier.maxAmount).toFixed(2).replace(/\.?0+$/, '')
      const rate = formatRatePercent(Number(tier.rate ?? 0))
      return `${Number(tier.minAmount)}-${max} ${rate}%`
    })
    .join('；')
}

export const PAGE_SIZE = 50

const pendingPickFiles = new Map()

export function isWebViewHost() {
  return typeof window.chrome?.webview?.postMessage === 'function'
}

export function initWebViewBridge() {
  if (!isWebViewHost() || window.__dhpgWebViewBridgeReady) return
  window.__dhpgWebViewBridgeReady = true

  window.chrome.webview.addEventListener('message', (event) => {
    const msg = typeof event.data === 'string' ? JSON.parse(event.data) : event.data
    if (msg?.type !== 'pickFileResult' || !pendingPickFiles.has(msg.id)) return

    const { resolve, reject } = pendingPickFiles.get(msg.id)
    pendingPickFiles.delete(msg.id)

    if (msg.error) {
      reject(new Error(msg.error))
      return
    }

    resolve({ path: msg.path, fileName: msg.fileName })
  })
}

export function pickAndStageFileViaBridge() {
  if (!isWebViewHost()) {
    return Promise.reject(new Error('当前环境不支持原生选文件。'))
  }

  return new Promise((resolve, reject) => {
    const id = crypto.randomUUID()
    pendingPickFiles.set(id, { resolve, reject })
    window.chrome.webview.postMessage(JSON.stringify({ type: 'pickFile', id }))

    setTimeout(() => {
      if (!pendingPickFiles.has(id)) return
      pendingPickFiles.delete(id)
      reject(new Error('选择文件超时，请重试。'))
    }, 300000)
  })
}

using DHPG.Common;

namespace DHPG.Data;

public class AppSettings
{
    public int Id { get; set; } = 1;
    public string ExportDirectory { get; set; } = string.Empty;
    public decimal DefaultWageringMultiplier { get; set; } = 1m;
    public string DefaultAppRemark { get; set; } = string.Empty;
    public string DefaultBackendRemark { get; set; } = string.Empty;
    public string Theme { get; set; } = "Light";
    public string LogLevel { get; set; } = "Information";
}

public class Site
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string? Remark { get; set; }
    public bool IsEnabled { get; set; } = true;
    public DateTime CreatedAt { get; set; }

    public SiteColumnMapping ColumnMapping { get; set; } = null!;
    public ICollection<Activity> Activities { get; set; } = new List<Activity>();
    public ICollection<ActivitySiteLink> ActivityLinks { get; set; } = new List<ActivitySiteLink>();
    public ICollection<ProcessHistory> ProcessHistories { get; set; } = new List<ProcessHistory>();
}

public class SiteColumnMapping
{
    public int Id { get; set; }
    public int SiteId { get; set; }

    /// <summary>时段彩金会员文件列映射</summary>
    public int UserIdColumn { get; set; } = 0;
    public int PayColumn { get; set; } = 5;
    public int WithdrawColumn { get; set; } = 7;
    public int PhoneColumn { get; set; } = 17;
    public int TierColumn { get; set; } = 21;
    public int HeaderRow { get; set; } = 0;

    /// <summary>回访彩金会员文件列映射</summary>
    public int CallbackUserIdColumn { get; set; } = 5;
    public int CallbackPayColumn { get; set; } = 8;
    public int CallbackWithdrawColumn { get; set; } = 9;
    public int CallbackPhoneColumn { get; set; } = 23;
    public int CallbackTierColumn { get; set; } = 24;
    public int CallbackHeaderRow { get; set; } = 0;

    /// <summary>未领名单会员 ID 列（默认 B 列 = 1）</summary>
    public int UnclaimedUserIdColumn { get; set; } = 1;

    public Site Site { get; set; } = null!;
}

public class Activity
{
    public int Id { get; set; }
    public int? SiteId { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public int Divisor { get; set; } = 1;
    public decimal MinBonus { get; set; }
    public decimal MaxBonus { get; set; }
    public decimal DefaultWageringMultiplier { get; set; } = 1m;
    public string AppRemark { get; set; } = string.Empty;
    public string BackendRemark { get; set; } = string.Empty;
    public bool AllowProfitMember { get; set; }
    public bool IsEnabled { get; set; } = true;
    public string FilterTierKeywords { get; set; } = "[]";
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    /// <summary>为 true 时适用于全部站点；为 false 时仅 SiteLinks 中的站点</summary>
    public bool ApplyToAllSites { get; set; } = true;

    public ActivityKind Kind { get; set; } = ActivityKind.Period;
    public string WeeklyDayRatesJson { get; set; } = "{}";
    public string DefaultTimezone { get; set; } = "Beijing";
    public bool FilterLossMember { get; set; }
    public bool FilterUnclaimedEnabled { get; set; } = true;
    public decimal MinNetDiff { get; set; } = 20m;
    public string TieredAmountRatesJson { get; set; } = "{}";
    public int InactiveDaysMax { get; set; } = 7;
    public bool UseNetDiffColumn { get; set; }
    public bool FilterRechargeEnabled { get; set; }
    public string TieredFixedBonusesJson { get; set; } = "{}";
    public string ComprehensiveFeaturesJson { get; set; } = "{}";

    public Site? Site { get; set; }
    public ActivityColumnMapping ColumnMapping { get; set; } = null!;
    public ICollection<ActivitySiteLink> SiteLinks { get; set; } = new List<ActivitySiteLink>();
    public ICollection<ProcessHistory> ProcessHistories { get; set; } = new List<ProcessHistory>();
}

public class ActivityColumnMapping
{
    public int Id { get; set; }
    public int ActivityId { get; set; }

    /// <summary>时段彩金会员文件列映射</summary>
    public int UserIdColumn { get; set; } = 0;
    public int PayColumn { get; set; } = 5;
    public int WithdrawColumn { get; set; } = 7;
    public int PhoneColumn { get; set; } = 17;
    public int TierColumn { get; set; } = 21;
    public int HeaderRow { get; set; } = 0;

    /// <summary>回访彩金会员文件列映射</summary>
    public int CallbackUserIdColumn { get; set; } = 5;
    public int CallbackPayColumn { get; set; } = 8;
    public int CallbackWithdrawColumn { get; set; } = 9;
    public int CallbackPhoneColumn { get; set; } = 23;
    public int CallbackTierColumn { get; set; } = 24;
    public int CallbackHeaderRow { get; set; } = 0;

    /// <summary>未领名单会员 ID 列（默认 B 列 = 1）</summary>
    public int UnclaimedUserIdColumn { get; set; } = 1;

    /// <summary>近7日亏损回访会员文件列映射</summary>
    public int Loss7dUserIdColumn { get; set; } = 5;
    public int Loss7dDepositColumn { get; set; } = 8;
    public int Loss7dWithdrawColumn { get; set; } = 9;
    public int Loss7dPhoneColumn { get; set; } = 23;
    public int Loss7dTierColumn { get; set; } = 24;
    public int Loss7dHeaderRow { get; set; } = 0;

    /// <summary>昨日亏损会员文件列映射</summary>
    public int YesterdayLossUserIdColumn { get; set; } = 1;
    public int YesterdayLossPayColumn { get; set; } = 11;
    public int YesterdayLossWithdrawColumn { get; set; } = 12;
    public int YesterdayLossNetDiffColumn { get; set; } = 18;
    public int YesterdayLossPhoneColumn { get; set; } = 19;
    public int YesterdayLossTierColumn { get; set; } = 20;
    public int YesterdayLossHeaderRow { get; set; } = 0;

    /// <summary>老回访234会员文件列映射</summary>
    public int OldCallback234UserIdColumn { get; set; } = 0;
    public int OldCallback234PayColumn { get; set; } = 5;
    public int OldCallback234WithdrawColumn { get; set; } = 7;
    public int OldCallback234NetDiffColumn { get; set; } = 9;
    public int OldCallback234InactiveDaysColumn { get; set; } = 16;
    public int OldCallback234PhoneColumn { get; set; } = 17;
    public int OldCallback234TierColumn { get; set; } = 21;
    public int OldCallback234HeaderRow { get; set; } = 0;

    /// <summary>充值数据文件列映射</summary>
    public int RechargeUserIdColumn { get; set; } = 1;
    public int RechargeAmountColumn { get; set; } = 5;
    public int RechargeHeaderRow { get; set; } = 0;

    /// <summary>综合回访会员文件列映射</summary>
    public int ComprehensiveUserIdColumn { get; set; } = 0;
    public int ComprehensivePayColumn { get; set; } = 5;
    public int ComprehensiveWithdrawColumn { get; set; } = 7;
    public int ComprehensiveNetDiffColumn { get; set; } = 8;
    public int ComprehensiveInactiveDaysColumn { get; set; } = 16;
    public int ComprehensivePhoneColumn { get; set; } = 17;
    public int ComprehensiveTierColumn { get; set; } = 21;
    public int ComprehensiveHeaderRow { get; set; } = 0;

    public Activity Activity { get; set; } = null!;
}

public class ActivitySiteLink
{
    public int ActivityId { get; set; }
    public int SiteId { get; set; }

    public Activity Activity { get; set; } = null!;
    public Site Site { get; set; } = null!;
}

public class ProcessHistory
{
    public int Id { get; set; }
    public DateTime ProcessedAt { get; set; }
    public int? SiteId { get; set; }
    public string SiteName { get; set; } = string.Empty;
    public int? ActivityId { get; set; }
    public string ActivityName { get; set; } = string.Empty;
    public int TotalCount { get; set; }
    public int FilteredCount { get; set; }
    public int RewardCount { get; set; }
    public decimal TotalBonus { get; set; }
    public string SnapshotJson { get; set; } = string.Empty;
    public string? ExportFilePath { get; set; }

    public Site? Site { get; set; }
    public Activity? Activity { get; set; }
}

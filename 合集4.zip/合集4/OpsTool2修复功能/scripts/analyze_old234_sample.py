import csv
from pathlib import Path

member_path = Path(r"c:\Users\Admin\Downloads\Telegram Desktop\user_visit-98ea6f1f-40d5-4194-9f9d-5c56a19a3e1c.csv")
unclaimed_path = Path(r"c:\Users\Admin\Downloads\Telegram Desktop\manual_reward-73f83fa4-47b0-4c66-9215-10b0b517d6f9.csv")

TIER_KEYWORDS = ["新-无优惠", "黑名单", "无优惠", "洗水套利"]
INACTIVE_MAX = 7

COL_USER = 0
COL_NETDIFF = 9
COL_INACTIVE = 16
COL_TIER = 21


def parse_user_id(text):
    text = (text or "").strip()
    if not text:
        return None
    try:
        return int(float(text))
    except ValueError:
        return None


def parse_amount(text):
    text = (text or "").strip()
    if not text:
        return 0.0
    try:
        return round(float(text), 2)
    except ValueError:
        return 0.0


def tier_excluded(tier):
    if not tier:
        return False
    tier = tier.strip()
    return any(k in tier for k in TIER_KEYWORDS)


def passes_inactive(text, max_days):
    if max_days <= 0 or not text or not str(text).strip():
        return False
    text = str(text).strip()
    try:
        exact = int(float(text))
        return 0 <= exact <= max_days
    except ValueError:
        pass
    for day in range(0, max_days + 1):
        token = str(day)
        start = 0
        while start <= len(text) - len(token):
            idx = text.find(token, start)
            if idx < 0:
                break
            before_ok = idx == 0 or not text[idx - 1].isdigit()
            after_idx = idx + len(token)
            after_ok = after_idx >= len(text) or not text[after_idx].isdigit()
            if before_ok and after_ok:
                return True
            start = idx + 1
    return False


unclaimed = set()
with unclaimed_path.open("r", encoding="utf-8-sig", newline="") as f:
    reader = csv.reader(f)
    next(reader, None)
    for row in reader:
        if len(row) > 1:
            uid = parse_user_id(row[1])
            if uid is not None:
                unclaimed.add(uid)

stats = {
    "total_rows": 0,
    "invalid_user": 0,
    "tier_filtered": 0,
    "inactive_filtered": 0,
    "unclaimed_filtered": 0,
    "zero_netdiff": 0,
    "profit_reward": 0,
    "loss_reward": 0,
}
inactive_values = {}

with member_path.open("r", encoding="utf-8-sig", newline="") as f:
    reader = csv.reader(f)
    next(reader)
    for row in reader:
        stats["total_rows"] += 1
        if len(row) <= COL_TIER:
            stats["invalid_user"] += 1
            continue
        uid = parse_user_id(row[COL_USER])
        if uid is None:
            stats["invalid_user"] += 1
            continue

        if tier_excluded(row[COL_TIER]):
            stats["tier_filtered"] += 1
            continue

        inactive_text = row[COL_INACTIVE] if len(row) > COL_INACTIVE else ""
        inv_key = inactive_text.strip() if inactive_text else "(empty)"
        inactive_values[inv_key] = inactive_values.get(inv_key, 0) + 1
        if not passes_inactive(inactive_text, INACTIVE_MAX):
            stats["inactive_filtered"] += 1
            continue

        if uid in unclaimed:
            stats["unclaimed_filtered"] += 1
            continue

        net_diff = parse_amount(row[COL_NETDIFF] if len(row) > COL_NETDIFF else "0")
        if net_diff == 0:
            stats["zero_netdiff"] += 1
            continue

        if net_diff < 0:
            stats["profit_reward"] += 1
        else:
            stats["loss_reward"] += 1

print("=== 老回访234 模拟统计 ===")
print(f"会员文件总行数: {stats['total_rows']:,}")
print(f"未领名单人数: {len(unclaimed):,}")
print()
for key, value in stats.items():
    if key != "total_rows":
        print(f"{key}: {value:,}")
print()
print(
    f"最终可派奖 - 盈利: {stats['profit_reward']:,}  "
    f"亏损: {stats['loss_reward']:,}  "
    f"合计: {stats['profit_reward'] + stats['loss_reward']:,}"
)
print()
print("--- 补充对比 ---")
for label, col, allow_zero in [
    ("充提差列 Q=0-7（含当天登录0天）", COL_NETDIFF, True),
    ("默认I列映射(人工提现列) + Q=1-7", 8, False),
]:
    s = {"profit": 0, "loss": 0, "tier": 0, "q": 0, "unclaimed": 0, "zero": 0}

    def pass_q_local(text, allow_zero=False):
        if not str(text or "").strip():
            return False
        try:
            v = int(float(str(text).strip()))
            lo = 0 if allow_zero else 1
            return lo <= v <= INACTIVE_MAX
        except ValueError:
            return passes_inactive(text, INACTIVE_MAX)

    with member_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if len(row) <= COL_TIER:
                continue
            uid = parse_user_id(row[COL_USER])
            if uid is None:
                continue
            if tier_excluded(row[COL_TIER]):
                s["tier"] += 1
                continue
            if not pass_q_local(row[COL_INACTIVE] if len(row) > COL_INACTIVE else "", allow_zero):
                s["q"] += 1
                continue
            if uid in unclaimed:
                s["unclaimed"] += 1
                continue
            net_diff = parse_amount(row[col] if len(row) > col else "0")
            if net_diff == 0:
                s["zero"] += 1
                continue
            if net_diff < 0:
                s["profit"] += 1
            else:
                s["loss"] += 1

    print(label)
    total = s["profit"] + s["loss"]
    print(f"  盈利: {s['profit']:,}  亏损: {s['loss']:,}  合计: {total:,}")
    print(f"  剔除 层级:{s['tier']:,} Q列:{s['q']:,} 未领:{s['unclaimed']:,} 盈亏0:{s['zero']:,}")


using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using DHPG.Common;
using DHPG.Services;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;

namespace DHPG.Views;

public partial class BatchWebView : UserControl
{
    private readonly ProcessPageMode _pageMode;
    private bool _initialized;
    private string? _pendingUrl;

    private static readonly JsonSerializerOptions BridgeJsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public BatchWebView(ProcessPageMode pageMode)
    {
        _pageMode = pageMode;
        InitializeComponent();
        Loaded += BatchWebView_Loaded;
    }

    private string ModeQuery => _pageMode switch
    {
        ProcessPageMode.CallbackBatch => "callback",
        ProcessPageMode.Loss7dBatch => "loss7d",
        ProcessPageMode.YesterdayLossBatch => "yesterdayloss",
        ProcessPageMode.OldCallback234Batch => "oldcallback234",
        ProcessPageMode.ComprehensiveCallbackBatch => "comprehensive",
        _ => "period"
    };

    private async void BatchWebView_Loaded(object sender, RoutedEventArgs e)
    {
        if (_initialized)
            return;

        try
        {
            if (!LocalApiHost.Instance.IsRunning)
                await LocalApiHost.Instance.StartAsync();

            await WebView.EnsureCoreWebView2Async();
            WebView.CoreWebView2.Settings.AreDevToolsEnabled = false;
            WebView.CoreWebView2.Settings.IsStatusBarEnabled = false;
            WebView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
            WebView.CoreWebView2.WebMessageReceived += OnWebMessageReceived;

            _initialized = true;
            NavigateToBatchPage();
        }
        catch (Exception ex)
        {
            HandyControl.Controls.Growl.Error($"批量页面加载失败：{ex.Message}");
        }
    }

    private void OnWebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            var json = e.TryGetWebMessageAsString();
            if (string.IsNullOrWhiteSpace(json))
                return;

            using var doc = JsonDocument.Parse(json);
            var type = doc.RootElement.GetProperty("type").GetString();
            if (type != "pickFile")
                return;

            var id = doc.RootElement.GetProperty("id").GetString();
            if (string.IsNullOrWhiteSpace(id))
                return;

            _ = Dispatcher.InvokeAsync(() => HandlePickFileRequest(id));
        }
        catch (Exception ex)
        {
            Serilog.Log.Warning(ex, "批量页 WebView 消息处理失败");
        }
    }

    private void HandlePickFileRequest(string requestId)
    {
        var dialog = new OpenFileDialog
        {
            Title = "选择 Excel/CSV 文件",
            Filter = "Excel/CSV (*.xlsx;*.xls;*.xlsm;*.csv)|*.xlsx;*.xls;*.xlsm;*.csv|所有文件 (*.*)|*.*",
            Multiselect = false
        };

        if (dialog.ShowDialog() != true)
        {
            PostPickFileResult(requestId, error: "已取消");
            return;
        }

        try
        {
            var staged = BatchFileStaging.StageFromPath(dialog.FileName);
            PostPickFileResult(requestId, staged.Path, staged.FileName);
        }
        catch (Exception ex)
        {
            PostPickFileResult(requestId, error: ex.Message);
        }
    }

    private void PostPickFileResult(string requestId, string? path = null, string? fileName = null, string? error = null)
    {
        if (WebView.CoreWebView2 is null)
            return;

        var payload = JsonSerializer.Serialize(new
        {
            type = "pickFileResult",
            id = requestId,
            path,
            fileName,
            error
        }, BridgeJsonOptions);

        WebView.CoreWebView2.PostWebMessageAsJson(payload);
    }

    public void OnNavigatedTo()
    {
        if (!_initialized)
        {
            _pendingUrl ??= BuildUrl();
            return;
        }

        _ = RefreshBatchPageAsync();
    }

    private async Task RefreshBatchPageAsync()
    {
        try
        {
            if (WebView.CoreWebView2 is null)
                return;

            await WebView.CoreWebView2.ExecuteScriptAsync(
                "window.__dhpgRefreshBootstrap && window.__dhpgRefreshBootstrap()");
        }
        catch
        {
            // WebView 尚未就绪时忽略
        }
    }

    public void OnNavigatedAway()
    {
        // 保持 WebView 文档，便于切菜单后恢复页面状态。
    }

    private void NavigateToBatchPage()
    {
        var url = _pendingUrl ?? BuildUrl();
        _pendingUrl = null;
        WebView.Source = new Uri(url);
    }

    private string BuildUrl() => $"{LocalApiHost.Instance.BaseUrl}/?mode={ModeQuery}";
}

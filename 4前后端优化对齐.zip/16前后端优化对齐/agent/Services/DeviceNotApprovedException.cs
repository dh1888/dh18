namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 设备尚未通过管理员审核，无法执行上传或任务相关 API。
/// </summary>
internal sealed class DeviceNotApprovedException : Exception
{
    public DeviceNotApprovedException(string status)
        : base($"Device not approved (status: {status})")
    {
        ApprovalStatus = status;
    }

    public string ApprovalStatus { get; }
}

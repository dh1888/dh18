// frontend/store/user.ts
import { defineStore } from "pinia";
import { ref, computed } from "vue";
import { authApi } from "@api/index";

export const useUserStore = defineStore(
  "user",
  () => {
    // 状态
    const token = ref<string>("");
    const refreshToken = ref<string>("");
    const expiresAt = ref<string>("");
    const username = ref<string>("");
    const role = ref<string>("auditor");
    const permissions = ref<string[]>([]); // ✅ 新增：权限列表

    // ✅ 1. 先定义解析函数
    const normalizeRoleName = (roleName: string): string => {
      const normalized = roleName.trim().toLowerCase();
      switch (normalized) {
        case "管理员":
        case "administrator":
        case "superadmin":
        case "admin":
          return "admin";
        case "审计员":
        case "auditor":
          return "auditor";
        case "操作员":
        case "operator":
        case "ops":
          return "operator";
        default:
          return "auditor";
      }
    };

    const parseRoleFromToken = (tokenStr: string): string => {
      try {
        if (!tokenStr) return "auditor";
        const parts = tokenStr.split(".");
        if (parts.length !== 3) return "auditor";
        const base64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
        const padded = base64.padEnd(
          base64.length + ((4 - (base64.length % 4)) % 4),
          "=",
        );
        const bytes = Uint8Array.from(atob(padded), (c) => c.charCodeAt(0));
        const payloadString = new TextDecoder().decode(bytes);
        const payload = JSON.parse(payloadString);
        return normalizeRoleName(payload.role || "auditor");
      } catch {
        return "auditor";
      }
    };

    // ✅ 新增：从 Token 解析权限列表
    const parsePermissionsFromToken = (tokenStr: string): string[] => {
      try {
        if (!tokenStr) return [];
        const parts = tokenStr.split(".");
        if (parts.length !== 3) return [];
        const base64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
        const padded = base64.padEnd(
          base64.length + ((4 - (base64.length % 4)) % 4),
          "=",
        );
        const bytes = Uint8Array.from(atob(padded), (c) => c.charCodeAt(0));
        const payloadString = new TextDecoder().decode(bytes);
        const payload = JSON.parse(payloadString);
        return payload.permissions || [];
      } catch {
        return [];
      }
    };

    // ✅ 2. 计算属性
    const isAuthenticated = computed(() => {
      if (!token.value) return false;
      if (!expiresAt.value) return true;
      try {
        const expiryDate = new Date(expiresAt.value);
        if (isNaN(expiryDate.getTime())) return true;
        return expiryDate > new Date();
      } catch {
        return true;
      }
    });

    const connectWebSocket = async (authToken: string) => {
      if (!authToken) return;

      try {
        const { useWebSocketStore } = await import("@store/websocket");
        const wsStore = useWebSocketStore();

        if (wsStore.connected) {
          wsStore.disconnect();
        }
        wsStore.connect(authToken);
      } catch (wsError) {
        const errorMsg =
          wsError instanceof Error ? wsError.message : String(wsError);
        console.error("WebSocket连接失败:", errorMsg);
      }
    };

    // ✅ 3. 登录
    const login = async (usernameVal: string, password: string) => {
      console.log("login called", usernameVal);
      const { data } = await authApi.login({ username: usernameVal, password });

      console.log("login response data:", data);

      token.value = data.token;
      refreshToken.value = data.refreshToken;
      expiresAt.value = data.expiresAt;
      username.value = usernameVal;

      // ✅ 新增：解析并存储权限
      const perms = parsePermissionsFromToken(data.token);
      permissions.value = perms;
      role.value = parseRoleFromToken(data.token);

      sessionStorage.setItem("token", data.token);
      sessionStorage.setItem("refreshToken", data.refreshToken);
      sessionStorage.setItem("expiresAt", data.expiresAt);
      sessionStorage.setItem("username", usernameVal);
      sessionStorage.setItem("permissions", JSON.stringify(perms)); // ✅ 存储权限
      sessionStorage.setItem("role", role.value);

      await connectWebSocket(data.token);
    };

    // ✅ 4. 恢复会话
    const restoreSession = () => {
      const storedToken = sessionStorage.getItem("token");
      const storedRefreshToken = sessionStorage.getItem("refreshToken");
      const storedExpiresAt = sessionStorage.getItem("expiresAt");
      const storedUsername = sessionStorage.getItem("username");
      const storedPermissions = sessionStorage.getItem("permissions"); // ✅ 获取存储的权限

      console.log("restoreSession, token exists:", !!storedToken);

      if (storedToken && storedExpiresAt) {
        const expiryDate = new Date(storedExpiresAt);
        if (expiryDate > new Date()) {
          token.value = storedToken;
          refreshToken.value = storedRefreshToken || "";
          expiresAt.value = storedExpiresAt;
          username.value = storedUsername || "";
          role.value = parseRoleFromToken(storedToken);

          // ✅ 恢复权限
          if (storedPermissions) {
            permissions.value = JSON.parse(storedPermissions);
          } else {
            // 兼容旧 Token，从 Token 中解析
            permissions.value = parsePermissionsFromToken(storedToken);
          }

          console.log(
            "Session restored, role:",
            role.value,
            "permissions count:",
            permissions.value.length,
          );
          void connectWebSocket(storedToken);
          return true;
        }
      }
      return false;
    };

    // ✅ 5. 登出
    const logout = async () => {
      const rt = refreshToken.value || sessionStorage.getItem("refreshToken") || "";
      try {
        await authApi.logout(rt || undefined);
      } catch {
        // 忽略错误
      }
      token.value = "";
      refreshToken.value = "";
      expiresAt.value = "";
      username.value = "";
      role.value = "auditor";
      permissions.value = []; // ✅ 清空权限
      sessionStorage.clear();

      try {
        const { useWebSocketStore } = await import("@store/websocket");
        useWebSocketStore().disconnect();
      } catch {
        // 忽略断开失败
      }
    };

    // ✅ 6. 刷新 token
    const refresh = async (reconnectWebSocket = true) => {
      if (!refreshToken.value) {
        await logout();
        return false;
      }

      try {
        const { data } = await authApi.refresh(refreshToken.value);
        token.value = data.token;
        expiresAt.value = data.expiresAt;
        if (data.refreshToken) {
          refreshToken.value = data.refreshToken;
          sessionStorage.setItem("refreshToken", data.refreshToken);
        }

        // 刷新时也更新权限
        const perms = parsePermissionsFromToken(data.token);
        permissions.value = perms;
        role.value = parseRoleFromToken(data.token);

        sessionStorage.setItem("token", data.token);
        sessionStorage.setItem("expiresAt", data.expiresAt);
        sessionStorage.setItem("permissions", JSON.stringify(perms));

        if (reconnectWebSocket) {
          await connectWebSocket(data.token);
        }

        return true;
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        console.error("刷新失败:", errorMsg);
        await logout();
        return false;
      }
    };

    // ✅ 新增：权限检查方法
    const hasPermission = (permission: string): boolean => {
      if (role.value === "admin") {
        return true; // 管理员拥有所有权限
      }
      return permissions.value.includes(permission);
    };

    return {
      token,
      refreshToken,
      expiresAt,
      username,
      role,
      permissions, // ✅ 导出 permissions
      isAuthenticated,
      login,
      logout,
      refresh,
      restoreSession,
      hasPermission, // ✅ 导出 hasPermission 方法
    };
  },
  {
    persist: false,
  },
);

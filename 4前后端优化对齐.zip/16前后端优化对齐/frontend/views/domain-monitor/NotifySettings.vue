<template>
  <div class="dm-page">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <el-tabs v-model="activeTab" class="modern-tabs">
      <!-- ===== Telegram 机器人 Tab ===== -->
      <el-tab-pane label="Telegram 机器人" name="bots">
        <template #label>
          <span class="tab-label">
            <el-icon><ChatDotRound /></el-icon>
            Telegram 机器人
            <el-badge :value="bots.length" :hidden="bots.length === 0" class="tab-badge" />
          </span>
        </template>

        <el-card shadow="hover" class="main-card">
          <div class="toolbar">
            <el-button type="primary" @click="openBotDialog()" class="add-btn">
              <el-icon><Plus /></el-icon>
              添加机器人
            </el-button>
            <el-button @click="loadBots" :loading="loading" class="refresh-btn">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
            <span class="toolbar-hint" v-if="bots.length">
              共 {{ bots.length }} 个机器人
            </span>
          </div>

          <el-table :data="bots" stripe v-loading="loading" class="modern-table" :header-cell-style="headerCellStyle">
            <el-table-column prop="botName" label="名称" min-width="140">
              <template #default="{ row }">
                <div class="bot-name-cell">
                  <span class="bot-name">{{ row.botName }}</span>
                  <el-tag v-if="row.enabled" size="small" type="success" effect="plain">启用</el-tag>
                  <el-tag v-else size="small" type="info" effect="plain">禁用</el-tag>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="botUsername" label="用户名" width="160">
              <template #default="{ row }">
                <span class="bot-username">{{ row.botUsername ? `@${row.botUsername}` : '-' }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="botToken" label="Token" width="180">
              <template #default="{ row }">
                <span class="bot-token">{{ row.botToken ? '••••••••' : '-' }}</span>
              </template>
            </el-table-column>
            <el-table-column label="验证状态" width="120" align="center">
              <template #default="{ row }">
                <span v-if="row.verifiedAt" class="status-badge verified">
                  <el-icon><CircleCheck /></el-icon>
                  已验证
                </span>
                <span v-else class="status-badge unverified">
                  <el-icon><Warning /></el-icon>
                  未验证
                </span>
              </template>
            </el-table-column>
            <el-table-column label="验证时间" width="170">
              <template #default="{ row }">
                <span class="time-value">{{ formatDateTime(row.verifiedAt) }}</span>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="320" fixed="right" align="center">
              <template #default="{ row }">
                <div class="action-buttons">
                  <el-button link type="primary" size="small" @click="testBot(row)" class="action-btn test-btn">
                    <el-icon><Check /></el-icon>
                    验证
                  </el-button>
                  <el-button link type="success" size="small" @click="discover(row)" class="action-btn discover-btn">
                    <el-icon><Search /></el-icon>
                    发现群组
                  </el-button>
                  <el-button link type="primary" size="small" @click="openBotDialog(row)" class="action-btn edit-btn">
                    <el-icon><Edit /></el-icon>
                    编辑
                  </el-button>
                  <el-button link type="danger" size="small" @click="removeBot(row)" class="action-btn delete-btn">
                    <el-icon><Delete /></el-icon>
                  </el-button>
                </div>
              </template>
            </el-table-column>
          </el-table>

          <el-empty v-if="!bots.length && !loading" description="暂无机器人" class="empty-table">
            <template #image>
              <el-icon :size="48" color="#c0c4cc"><ChatDotRound /></el-icon>
            </template>
            <el-button type="primary" @click="openBotDialog()" class="add-btn">
              <el-icon><Plus /></el-icon>
              添加第一个机器人
            </el-button>
          </el-empty>
        </el-card>
      </el-tab-pane>

      <!-- ===== 已绑定群组 Tab ===== -->
      <el-tab-pane label="已绑定群组" name="groups">
        <template #label>
          <span class="tab-label">
            <el-icon><ChatSquare /></el-icon>
            已绑定群组
            <el-badge :value="boundGroups.length" :hidden="boundGroups.length === 0" class="tab-badge" />
          </span>
        </template>

        <el-card shadow="hover" class="main-card">
          <el-alert
            type="info"
            :closable="false"
            show-icon
            class="tip-alert"
            title="在机器人 Tab 中「发现群组」后绑定；绑定后的群组可用于告警路由。"
          />

          <div class="toolbar">
            <el-button @click="loadBoundGroups" :loading="groupLoading" class="refresh-btn">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
            <span class="toolbar-hint" v-if="boundGroups.length">
              共 {{ boundGroups.length }} 个群组
            </span>
          </div>

          <el-table :data="boundGroups" stripe v-loading="groupLoading" class="modern-table" :header-cell-style="headerCellStyle">
            <el-table-column prop="groupName" label="群组名称" min-width="180">
              <template #default="{ row }">
                <div class="group-cell">
                  <el-icon><ChatSquare /></el-icon>
                  <span class="group-name">{{ row.groupName }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="chatId" label="Chat ID" width="180">
              <template #default="{ row }">
                <span class="chat-id">{{ row.chatId }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="chatType" label="类型" width="120" align="center">
              <template #default="{ row }">
                <el-tag :type="row.chatType === 'group' ? 'primary' : 'warning'" size="small" effect="light">
                  {{ row.chatType === 'group' ? '群组' : row.chatType === 'supergroup' ? '超级群组' : row.chatType || '-' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="机器人" min-width="140">
              <template #default="{ row }">
                <span class="bot-ref">{{ botNameMap[row.botId] || row.botId }}</span>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="200" align="center">
              <template #default="{ row }">
                <el-button link type="primary" size="small" @click="testPush(row)" class="action-btn test-btn">
                  <el-icon><Message /></el-icon>
                  测试推送
                </el-button>
                <el-button link type="danger" size="small" @click="unbindGroup(row)" class="action-btn">
                  解绑
                </el-button>
              </template>
            </el-table-column>
          </el-table>

          <el-empty v-if="!boundGroups.length && !groupLoading" description="暂无绑定的群组" class="empty-table">
            <template #image>
              <el-icon :size="48" color="#c0c4cc"><ChatSquare /></el-icon>
            </template>
            <span class="empty-hint">请先在「Telegram 机器人」Tab 中发现并绑定群组</span>
          </el-empty>
        </el-card>
      </el-tab-pane>

      <!-- ===== 告警路由 Tab ===== -->
      <el-tab-pane label="告警路由" name="routes">
        <template #label>
          <span class="tab-label">
            <el-icon><Guide /></el-icon>
            告警路由
            <el-badge :value="routes.length" :hidden="routes.length === 0" class="tab-badge" />
          </span>
        </template>

        <el-card shadow="hover" class="main-card">
          <div class="toolbar">
            <el-button type="primary" @click="openRouteDialog()" class="add-btn">
              <el-icon><Plus /></el-icon>
              新增路由
            </el-button>
            <el-button @click="loadRoutes" :loading="routeLoading" class="refresh-btn">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
            <span class="toolbar-hint" v-if="routes.length">
              共 {{ routes.length }} 条路由
            </span>
          </div>

          <el-table :data="routes" stripe v-loading="routeLoading" class="modern-table" :header-cell-style="headerCellStyle">
            <el-table-column prop="name" label="名称" min-width="120">
              <template #default="{ row }">
                <span class="route-name">{{ row.name }}</span>
              </template>
            </el-table-column>
            <el-table-column label="告警类型" min-width="180">
              <template #default="{ row }">
                <div class="tag-group">
                  <template v-if="parseStringArray(row.alertTypes).length">
                    <el-tag
                      v-for="type in parseStringArray(row.alertTypes).slice(0, 3)"
                      :key="type"
                      size="small"
                      type="info"
                      effect="light"
                    >
                      {{ alertTypeLabel(type) }}
                    </el-tag>
                    <el-tag v-if="parseStringArray(row.alertTypes).length > 3" size="small" type="info" effect="plain">
                      +{{ parseStringArray(row.alertTypes).length - 3 }}
                    </el-tag>
                  </template>
                  <span v-else class="muted">全部</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="级别" width="140">
              <template #default="{ row }">
                <div class="tag-group">
                  <template v-if="parseStringArray(row.severities).length">
                    <el-tag
                      v-for="sev in parseStringArray(row.severities).slice(0, 2)"
                      :key="sev"
                      size="small"
                      :type="getSeverityTagType(sev)"
                      effect="light"
                    >
                      {{ sev }}
                    </el-tag>
                    <el-tag v-if="parseStringArray(row.severities).length > 2" size="small" type="info" effect="plain">
                      +{{ parseStringArray(row.severities).length - 2 }}
                    </el-tag>
                  </template>
                  <span v-else class="muted">全部</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="目标群组" min-width="160">
              <template #default="{ row }">
                <span class="target-group">{{ groupNameMap[row.groupId] || row.groupId }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="sendMode" label="模式" width="100" align="center">
              <template #default="{ row }">
                <el-tag :type="row.sendMode === 'realtime' ? 'warning' : 'info'" size="small" effect="light">
                  {{ row.sendMode === 'realtime' ? '实时' : row.sendMode || '-' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="启用" width="80" align="center">
              <template #default="{ row }">
                <el-tag :type="row.enabled ? 'success' : 'info'" size="small" effect="light">
                  {{ row.enabled ? '是' : '否' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="160" fixed="right" align="center">
              <template #default="{ row }">
                <div class="action-buttons">
                  <el-button link type="primary" size="small" @click="openRouteDialog(row)" class="action-btn edit-btn">
                    <el-icon><Edit /></el-icon>
                    编辑
                  </el-button>
                  <el-button link type="danger" size="small" @click="removeRoute(row)" class="action-btn delete-btn">
                    <el-icon><Delete /></el-icon>
                  </el-button>
                </div>
              </template>
            </el-table-column>
          </el-table>

          <el-empty v-if="!routes.length && !routeLoading" description="暂无告警路由" class="empty-table">
            <template #image>
              <el-icon :size="48" color="#c0c4cc"><Guide /></el-icon>
            </template>
            <el-button type="primary" @click="openRouteDialog()" class="add-btn">
              <el-icon><Plus /></el-icon>
              添加第一条路由
            </el-button>
          </el-empty>
        </el-card>
      </el-tab-pane>
    </el-tabs>

    <!-- ===== 机器人表单对话框 ===== -->
    <el-dialog
      v-model="botDialogVisible"
      :title="botForm.id ? '编辑机器人' : '添加机器人'"
      width="560px"
      class="modern-dialog"
      destroy-on-close
    >
      <el-form :model="botForm" label-width="100px" class="dialog-form">
        <el-form-item label="名称" required>
          <el-input v-model="botForm.botName" placeholder="请输入机器人名称" size="large" />
        </el-form-item>
        <el-form-item label="Bot Token" required>
          <el-input
            v-model="botForm.botToken"
            type="password"
            show-password
            placeholder="编辑时留空则不修改"
            size="large"
          />
          <span class="form-hint">从 @BotFather 获取的 Token</span>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="botForm.remark" type="textarea" :rows="2" placeholder="请输入备注信息" />
        </el-form-item>
        <el-form-item label="启用">
          <el-switch v-model="botForm.enabled" size="large" />
          <span class="form-hint">禁用后该机器人将不会发送任何消息</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="botDialogVisible = false" size="large">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submitBot" size="large" class="submit-btn">
          <el-icon><Check /></el-icon>
          {{ botForm.id ? '更新' : '创建' }}
        </el-button>
      </template>
    </el-dialog>

    <!-- ===== 发现群组对话框 ===== -->
    <el-dialog
      v-model="discoverVisible"
      title="发现群组"
      width="600px"
      class="modern-dialog"
    >
      <div class="discover-header">
        <el-alert
          type="info"
          :closable="false"
          show-icon
          class="discover-tip"
          title="请先将机器人拉入群组并发送一条消息，然后点击发现"
        />
      </div>
      <el-table :data="discoveredGroups" stripe max-height="360" class="modern-table" :header-cell-style="headerCellStyle">
        <el-table-column prop="groupName" label="群组名称" min-width="180">
          <template #default="{ row }">
            <div class="group-cell">
              <el-icon><ChatSquare /></el-icon>
              <span class="group-name">{{ row.groupName }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="chatId" label="Chat ID" width="180">
          <template #default="{ row }">
            <span class="chat-id">{{ row.chatId }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="chatType" label="类型" width="120" align="center">
          <template #default="{ row }">
            <el-tag :type="row.chatType === 'group' ? 'primary' : 'warning'" size="small" effect="light">
              {{ row.chatType === 'group' ? '群组' : row.chatType === 'supergroup' ? '超级群组' : row.chatType || '-' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120" align="center">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="bindGroup(row)" class="action-btn bind-btn">
              <el-icon><Link /></el-icon>
              绑定
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!discoveredGroups.length" description="未发现群组" :image-size="64">
        <template #image>
          <el-icon :size="40" color="#c0c4cc"><Search /></el-icon>
        </template>
        <span class="empty-hint">请先将机器人拉入群并发送一条消息后重试</span>
      </el-empty>
      <template #footer>
        <el-button @click="discoverVisible = false" size="large">关闭</el-button>
        <el-button type="primary" @click="discover(discoverBotId ? { id: discoverBotId } as any : null)" size="large">
          <el-icon><Refresh /></el-icon>
          重新发现
        </el-button>
      </template>
    </el-dialog>

    <!-- ===== 路由表单对话框 ===== -->
    <el-dialog
      v-model="routeDialogVisible"
      :title="routeForm.id ? '编辑路由' : '新增路由'"
      width="600px"
      class="modern-dialog"
      destroy-on-close
    >
      <el-form :model="routeForm" label-width="100px" class="dialog-form">
        <el-form-item label="名称" required>
          <el-input v-model="routeForm.name" placeholder="请输入路由名称" size="large" />
        </el-form-item>
        <el-form-item label="告警类型">
          <el-select v-model="routeForm.alertTypes" multiple style="width: 100%" size="large" collapse-tags collapse-tags-tooltip>
            <el-option v-for="o in ALERT_TYPE_OPTIONS" :key="o.value" :label="o.label" :value="o.value" />
          </el-select>
          <span class="form-hint">默认全选，匹配全部告警类型</span>
        </el-form-item>
        <el-form-item label="级别">
          <el-select v-model="routeForm.severities" multiple style="width: 100%" size="large" collapse-tags collapse-tags-tooltip>
            <el-option v-for="o in SEVERITY_OPTIONS" :key="o.value" :label="o.label" :value="o.value" />
          </el-select>
          <span class="form-hint">默认全选，匹配全部严重级别</span>
        </el-form-item>
        <el-form-item label="目标群组" required>
          <el-select v-model="routeForm.groupId" style="width: 100%" size="large" placeholder="请选择目标群组">
            <el-option v-for="g in boundGroups" :key="g.id" :label="`${g.groupName} (${g.chatId})`" :value="g.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="发送模式">
          <el-select v-model="routeForm.sendMode" style="width: 100%" size="large">
            <el-option label="实时" value="realtime" />
          </el-select>
          <span class="form-hint">实时推送告警到目标群组</span>
        </el-form-item>
        <el-form-item label="启用">
          <el-switch v-model="routeForm.enabled" size="large" />
          <span class="form-hint">禁用后该路由将不会生效</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="routeDialogVisible = false" size="large">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submitRoute" size="large" class="submit-btn">
          <el-icon><Check /></el-icon>
          {{ routeForm.id ? '更新' : '创建' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Plus,
  Refresh,
  Edit,
  Delete,
  Check,
  Search,
  ChatDotRound,
  ChatSquare,
  Guide,
  Link,
  Message,
  Warning,
  CircleCheck,
} from "@element-plus/icons-vue";
import type { DmTelegramBot, DmTelegramGroup, DmAlertRoute } from "@api/domain_monitor_api";
import domainMonitorApi from "@api/domain_monitor_api";
import {
  formatDateTime,
  alertTypeLabel,
  parseStringArray,
  ALERT_TYPE_OPTIONS,
  SEVERITY_OPTIONS,
  allAlertTypeValues,
  allSeverityValues,
} from "./helpers";

const activeTab = ref("bots");
const loading = ref(false);
const groupLoading = ref(false);
const routeLoading = ref(false);
const submitting = ref(false);

const bots = ref<DmTelegramBot[]>([]);
const boundGroups = ref<DmTelegramGroup[]>([]);
const routes = ref<DmAlertRoute[]>([]);

const botDialogVisible = ref(false);
const botForm = reactive({
  id: "",
  botName: "",
  botToken: "",
  remark: "",
  enabled: true,
});

const discoverVisible = ref(false);
const discoverBotId = ref("");
const discoveredGroups = ref<Array<{ chatId: string; groupName: string; chatType?: string }>>([]);

const routeDialogVisible = ref(false);
const routeForm = reactive({
  id: "",
  name: "",
  alertTypes: [] as string[],
  severities: [] as string[],
  groupId: "",
  sendMode: "realtime",
  enabled: true,
});

const headerCellStyle = {
  background: "linear-gradient(135deg, #f8fafc 0%, #eef2f6 100%)",
  color: "#1e293b",
  fontWeight: "600",
  fontSize: "13px",
  borderBottom: "2px solid #e2e8f0",
};

function getSeverityTagType(severity: string): string {
  const map: Record<string, string> = {
    CRITICAL: "danger",
    ERROR: "warning",
    WARNING: "info",
    INFO: "success",
  };
  return map[severity] || "info";
}

const botNameMap = computed(() => {
  const m: Record<string, string> = {};
  bots.value.forEach((b) => {
    m[b.id] = b.botName;
  });
  return m;
});

const groupNameMap = computed(() => {
  const m: Record<string, string> = {};
  boundGroups.value.forEach((g) => {
    m[g.id] = g.groupName;
  });
  return m;
});

async function loadBots() {
  loading.value = true;
  try {
    const { data } = await domainMonitorApi.listBots();
    bots.value = data || [];
  } catch (e: any) {
    ElMessage.error(e.message || "加载机器人失败");
  } finally {
    loading.value = false;
  }
}

async function loadBoundGroups() {
  groupLoading.value = true;
  try {
    const { data } = await domainMonitorApi.listTelegramGroups();
    boundGroups.value = data || [];
  } catch (e: any) {
    ElMessage.error(e.message || "加载群组失败");
  } finally {
    groupLoading.value = false;
  }
}

async function loadRoutes() {
  routeLoading.value = true;
  try {
    const { data } = await domainMonitorApi.listRoutes();
    routes.value = data || [];
  } catch (e: any) {
    ElMessage.error(e.message || "加载路由失败");
  } finally {
    routeLoading.value = false;
  }
}

function openBotDialog(row?: DmTelegramBot) {
  if (row) {
    botForm.id = row.id;
    botForm.botName = row.botName;
    botForm.botToken = "";
    botForm.remark = row.remark || "";
    botForm.enabled = row.enabled;
  } else {
    botForm.id = "";
    botForm.botName = "";
    botForm.botToken = "";
    botForm.remark = "";
    botForm.enabled = true;
  }
  botDialogVisible.value = true;
}

async function submitBot() {
  if (!botForm.botName.trim()) {
    ElMessage.warning("请输入名称");
    return;
  }
  if (!botForm.id && !botForm.botToken.trim()) {
    ElMessage.warning("请输入 Bot Token");
    return;
  }
  submitting.value = true;
  try {
    const payload: any = {
      botName: botForm.botName.trim(),
      remark: botForm.remark,
      enabled: botForm.enabled,
    };
    if (botForm.botToken.trim()) {
      payload.botToken = botForm.botToken.trim();
    }
    if (botForm.id) {
      await domainMonitorApi.updateBot(botForm.id, payload);
    } else {
      await domainMonitorApi.createBot(payload);
    }
    ElMessage.success("保存成功");
    botDialogVisible.value = false;
    loadBots();
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    submitting.value = false;
  }
}

async function removeBot(row: DmTelegramBot) {
  try {
    await ElMessageBox.confirm(`确定删除机器人 ${row.botName}？`, "确认", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    });
    await domainMonitorApi.deleteBot(row.id);
    ElMessage.success("已删除");
    loadBots();
    loadBoundGroups();
  } catch {
    /* cancelled */
  }
}

async function testBot(row: DmTelegramBot) {
  try {
    await domainMonitorApi.testBot(row.id);
    ElMessage.success("Token 验证成功");
    loadBots();
  } catch (e: any) {
    ElMessage.error(e.message || "验证失败");
  }
}

async function discover(row: DmTelegramBot) {
  discoverBotId.value = row.id;
  try {
    const { data } = await domainMonitorApi.discoverGroups(row.id);
    discoveredGroups.value = data || [];
    discoverVisible.value = true;
    if (!discoveredGroups.value.length) {
      ElMessage.info("未发现群组，请先将机器人拉入群并发送一条消息");
    }
  } catch (e: any) {
    ElMessage.error(e.message || "发现群组失败");
  }
}

async function bindGroup(row: { chatId: string; groupName: string; chatType?: string }) {
  try {
    await domainMonitorApi.bindGroup({
      botId: discoverBotId.value,
      groupName: row.groupName,
      chatId: row.chatId,
      chatType: row.chatType,
    });
    ElMessage.success("绑定成功");
    loadBoundGroups();
  } catch (e: any) {
    ElMessage.error(e.message || "绑定失败");
  }
}

async function testPush(row: DmTelegramGroup) {
  try {
    await domainMonitorApi.testPush({ botId: row.botId, chatId: row.chatId });
    ElMessage.success("测试消息已发送");
  } catch (e: any) {
    ElMessage.error(e.message || "推送失败");
  }
}

async function unbindGroup(row: DmTelegramGroup) {
  try {
    await ElMessageBox.confirm(`解绑群组「${row.groupName}」？`, "确认解绑", { type: "warning" });
    await domainMonitorApi.deleteTelegramGroup(row.id);
    ElMessage.success("已解绑");
    loadBoundGroups();
  } catch {
    /* cancelled or error handled by interceptor */
  }
}

function openRouteDialog(row?: DmAlertRoute) {
  if (row) {
    routeForm.id = row.id;
    routeForm.name = row.name;
    const types = parseStringArray(row.alertTypes);
    routeForm.alertTypes = types.length ? types : allAlertTypeValues();
    const sevs = parseStringArray(row.severities);
    routeForm.severities = sevs.length ? sevs : allSeverityValues();
    routeForm.groupId = row.groupId;
    routeForm.sendMode = row.sendMode || "realtime";
    routeForm.enabled = row.enabled;
  } else {
    routeForm.id = "";
    routeForm.name = "";
    routeForm.alertTypes = allAlertTypeValues();
    routeForm.severities = allSeverityValues();
    routeForm.groupId = boundGroups.value[0]?.id || "";
    routeForm.sendMode = "realtime";
    routeForm.enabled = true;
  }
  routeDialogVisible.value = true;
}

async function submitRoute() {
  if (!routeForm.name.trim() || !routeForm.groupId) {
    ElMessage.warning("请填写名称并选择群组");
    return;
  }
  submitting.value = true;
  try {
    const payload = {
      name: routeForm.name.trim(),
      alertTypes: routeForm.alertTypes,
      severities: routeForm.severities,
      groupId: routeForm.groupId,
      sendMode: routeForm.sendMode,
      enabled: routeForm.enabled,
    };
    if (routeForm.id) {
      await domainMonitorApi.updateRoute(routeForm.id, payload);
    } else {
      await domainMonitorApi.createRoute(payload);
    }
    ElMessage.success("保存成功");
    routeDialogVisible.value = false;
    loadRoutes();
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    submitting.value = false;
  }
}

async function removeRoute(row: DmAlertRoute) {
  try {
    await ElMessageBox.confirm(`确定删除路由 ${row.name}？`, "确认", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    });
    await domainMonitorApi.deleteRoute(row.id);
    ElMessage.success("已删除");
    loadRoutes();
  } catch {
    /* cancelled */
  }
}

onMounted(() => {
  loadBots();
  loadBoundGroups();
  loadRoutes();
});
</script>

<style scoped>
/* ========== 页面背景 ========== */
.dm-page {
  position: relative;
  padding: 4px;
  min-height: 100vh;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.3;
  animation: floatBlob 25s ease-in-out infinite;
}

.blob-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -150px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -200px;
  left: -150px;
  animation-delay: -8s;
}

.blob-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 20%;
  animation-delay: -16s;
}

@keyframes floatBlob {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(40px, -40px) scale(1.05); }
  66% { transform: translate(-30px, 30px) scale(0.95); }
}

/* ========== Tabs ========== */
.modern-tabs {
  position: relative;
  z-index: 1;
}

.modern-tabs :deep(.el-tabs__header) {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(12px);
  border-radius: 16px;
  padding: 6px 16px;
  margin-bottom: 20px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
}

.modern-tabs :deep(.el-tabs__item) {
  font-size: 14px;
  font-weight: 500;
  padding: 0 20px;
  height: 44px;
  line-height: 44px;
  transition: all 0.2s ease;
}

.modern-tabs :deep(.el-tabs__item.is-active) {
  color: #667eea;
}

.modern-tabs :deep(.el-tabs__active-bar) {
  background: linear-gradient(90deg, #667eea, #764ba2);
  height: 3px;
  border-radius: 2px;
}

.tab-label {
  display: flex;
  align-items: center;
  gap: 6px;
}

.tab-badge {
  margin-left: 4px;
}

.tab-badge :deep(.el-badge__content) {
  font-size: 10px;
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  background: linear-gradient(135deg, #667eea, #764ba2);
}

/* ========== 主卡片 ========== */
.main-card {
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
  overflow: hidden;
}

.main-card :deep(.el-card__body) {
  padding: 20px 24px;
}

/* ========== 工具栏 ========== */
.toolbar {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  margin-bottom: 16px;
}

.add-btn {
  border-radius: 10px;
  padding: 8px 20px;
  font-weight: 500;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.25);
  transition: all 0.2s ease;
}

.add-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35);
}

.refresh-btn {
  border-radius: 10px;
  padding: 8px 16px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.refresh-btn:hover {
  transform: translateY(-2px);
}

.toolbar-hint {
  font-size: 13px;
  color: #909399;
  margin-left: auto;
  padding: 4px 12px;
  background: #f5f7fa;
  border-radius: 12px;
}

/* ========== 表格 ========== */
.modern-table {
  width: 100%;
}

.modern-table :deep(.el-table__header th) {
  padding: 12px 0;
}

.modern-table :deep(.el-table__row td) {
  padding: 10px 0;
}

.modern-table :deep(.el-table__row) {
  transition: background 0.2s ease;
}

.modern-table :deep(.el-table__row:hover) {
  background: rgba(102, 126, 234, 0.04);
}

/* ========== 表格单元格 ========== */
.bot-name-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.bot-name {
  font-weight: 600;
  color: #1a1a2e;
}

.bot-username {
  color: #409eff;
  font-weight: 500;
}

.bot-token {
  font-family: monospace;
  color: #606266;
}

.status-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status-badge.verified {
  background: #f0f9f0;
  color: #67c23a;
}

.status-badge.unverified {
  background: #fdf6ec;
  color: #e6a23c;
}

.time-value {
  color: #909399;
  font-size: 13px;
}

.group-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.group-name {
  font-weight: 500;
  color: #1a1a2e;
}

.chat-id {
  font-family: monospace;
  color: #606266;
  font-size: 13px;
}

.bot-ref {
  color: #409eff;
  font-weight: 500;
}

.route-name {
  font-weight: 500;
  color: #1a1a2e;
}

.tag-group {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  align-items: center;
}

.target-group {
  color: #606266;
}

.muted {
  color: #c0c4cc;
}

/* ========== 操作按钮 ========== */
.action-buttons {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
}

.action-btn {
  padding: 4px 8px;
  border-radius: 6px;
  transition: all 0.2s ease;
  font-size: 12px;
}

.action-btn:hover {
  transform: scale(1.05);
}

.action-btn .el-icon {
  font-size: 13px;
}

.test-btn {
  color: #409eff;
}

.test-btn:hover {
  background: rgba(64, 158, 255, 0.1);
}

.discover-btn {
  color: #67c23a;
}

.discover-btn:hover {
  background: rgba(103, 194, 58, 0.1);
}

.edit-btn {
  color: #409eff;
}

.edit-btn:hover {
  background: rgba(64, 158, 255, 0.1);
}

.delete-btn {
  color: #f56c6c;
  padding: 4px 6px;
}

.delete-btn:hover {
  background: rgba(245, 108, 108, 0.1);
}

.bind-btn {
  color: #409eff;
}

.bind-btn:hover {
  background: rgba(64, 158, 255, 0.1);
}

/* ========== 提示 ========== */
.tip-alert {
  margin-bottom: 16px;
  border-radius: 10px;
}

.tip-alert :deep(.el-alert__title) {
  font-weight: 500;
}

/* ========== 空状态 ========== */
.empty-table {
  padding: 20px 0;
}

.empty-hint {
  color: #909399;
  font-size: 13px;
  margin-top: 8px;
}

/* ========== 对话框 ========== */
.modern-dialog :deep(.el-dialog) {
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
}

.modern-dialog :deep(.el-dialog__header) {
  padding: 20px 24px;
  margin: 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-bottom: none;
}

.modern-dialog :deep(.el-dialog__title) {
  color: white;
  font-size: 18px;
  font-weight: 600;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: white;
  font-size: 20px;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close:hover) {
  color: rgba(255, 255, 255, 0.7);
}

.modern-dialog :deep(.el-dialog__body) {
  padding: 24px;
}

.modern-dialog :deep(.el-dialog__footer) {
  padding: 16px 24px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.dialog-form .el-form-item {
  margin-bottom: 18px;
}

.form-hint {
  display: block;
  margin-top: 4px;
  color: #909399;
  font-size: 12px;
}

.submit-btn {
  padding: 10px 32px;
  border-radius: 10px;
  font-weight: 600;
}

/* ========== 发现群组 ========== */
.discover-header {
  margin-bottom: 16px;
}

.discover-tip {
  border-radius: 10px;
}

/* ========== 响应式 ========== */
@media (max-width: 768px) {
  .main-card :deep(.el-card__body) {
    padding: 16px;
  }

  .toolbar {
    flex-direction: column;
    align-items: stretch;
  }

  .toolbar .el-button {
    width: 100%;
    justify-content: center;
  }

  .toolbar-hint {
    margin-left: 0;
    text-align: center;
  }

  .action-buttons {
    flex-wrap: wrap;
  }

  .modern-dialog :deep(.el-dialog) {
    width: 95% !important;
    margin: 20px auto !important;
  }

  .tag-group {
    flex-wrap: wrap;
  }

  .modern-tabs :deep(.el-tabs__item) {
    padding: 0 12px;
    font-size: 12px;
  }

  .bot-name-cell {
    flex-wrap: wrap;
  }
}

@media (max-width: 480px) {
  .main-card :deep(.el-card__body) {
    padding: 12px;
  }

  .tab-label {
    font-size: 12px;
  }

  .tab-badge :deep(.el-badge__content) {
    font-size: 9px;
    height: 16px;
    line-height: 16px;
    padding: 0 4px;
  }

  .action-btn span {
    display: none;
  }

  .action-btn .el-icon {
    font-size: 16px;
    margin: 0;
  }
}
</style>
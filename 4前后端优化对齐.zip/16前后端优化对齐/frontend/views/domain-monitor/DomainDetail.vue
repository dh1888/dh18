<template>
  <div class="dm-page" v-loading="loading">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <!-- ===== 页面头部 ===== -->
    <div class="page-header-wrapper">
      <el-page-header @back="$router.push('/domain-monitor/domains')" class="modern-page-header">
        <template #content>
          <div class="header-content">
            <span class="page-title">{{ domain?.domain || "域名详情" }}</span>
            <el-tag
              v-if="domain?.healthLevel"
              class="health-tag"
              :type="healthLevelTagType(domain.healthLevel)"
              size="large"
              effect="dark"
            >
              {{ healthLevelLabel(domain.healthLevel) }}
            </el-tag>
            <el-tag
              v-if="domain?.enabled"
              type="success"
              size="small"
              effect="plain"
              class="status-tag"
            >
              <el-icon><Check /></el-icon>
              启用
            </el-tag>
            <el-tag
              v-else
              type="info"
              size="small"
              effect="plain"
              class="status-tag"
            >
              <el-icon><Close /></el-icon>
              禁用
            </el-tag>
          </div>
        </template>
        <template #extra>
          <div class="header-actions">
            <el-button
              v-if="domain?.enableContent"
              v-permission="'domain_monitor:manage'"
              @click="resetBaseline"
              :loading="baselineLoading"
              class="action-btn baseline-btn"
            >
              <el-icon><Refresh /></el-icon>
              重置内容基线
            </el-button>
            <el-button
              v-permission="'domain_monitor:manage'"
              type="primary"
              @click="checkNow"
              :loading="checking"
              class="action-btn check-now-btn"
            >
              <el-icon><VideoPlay /></el-icon>
              立即检测
            </el-button>
          </div>
        </template>
      </el-page-header>
    </div>

    <!-- ===== 概览信息 ===== -->
    <el-row :gutter="16" class="info-row" v-if="domain">
      <!-- 左侧：基本信息 -->
      <el-col :span="24" :md="14">
        <el-card shadow="hover" class="info-card">
          <template #header>
            <div class="card-header-custom">
              <span class="card-title">
                <el-icon><InfoFilled /></el-icon>
                域名概览
              </span>
              <span class="card-subtitle">基本信息与健康状态</span>
            </div>
          </template>

          <div class="info-grid">
            <!-- 综合健康 -->
            <div class="info-item highlight">
              <div class="info-label">综合健康</div>
              <div class="info-value">
                <el-tag :type="healthLevelTagType(domain.healthLevel)" size="large" effect="dark" class="health-badge">
                  {{ healthLevelLabel(domain.healthLevel) }}
                </el-tag>
              </div>
            </div>

            <!-- 全球可达率 -->
            <div class="info-item">
              <div class="info-label">全球可达率</div>
              <div class="info-value">
                <span class="reachability-value" :class="getReachabilityClass(domain.reachabilityPct)">
                  {{ domain.reachabilityPct != null ? domain.reachabilityPct.toFixed(0) + "%" : "-" }}
                </span>
                <el-progress
                  v-if="domain.reachabilityPct != null"
                  :percentage="domain.reachabilityPct"
                  :stroke-width="6"
                  :show-text="false"
                  class="reachability-progress"
                />
              </div>
            </div>

            <!-- CDN -->
            <div class="info-item">
              <div class="info-label">CDN</div>
              <div class="info-value">
                <el-tag v-if="domain.lastCdnProvider" type="primary" size="small" effect="light">
                  {{ domain.lastCdnProvider }}
                </el-tag>
                <span v-else class="muted">-</span>
              </div>
            </div>

            <!-- 分组 -->
            <div class="info-item">
              <div class="info-label">分组</div>
              <div class="info-value">
                <span class="group-name">{{ domain.group?.name || "-" }}</span>
              </div>
            </div>

            <!-- 检测间隔 -->
            <div class="info-item">
              <div class="info-label">检测间隔</div>
              <div class="info-value">
                <span class="interval-value">{{ formatInterval(domain.checkInterval) }}</span>
              </div>
            </div>

            <!-- 上次检测 -->
            <div class="info-item">
              <div class="info-label">上次检测</div>
              <div class="info-value">
                <span class="time-value">{{ formatDateTime(domain.lastCheckAt) }}</span>
              </div>
            </div>

            <!-- DNS 状态 -->
            <div class="info-item status-item">
              <div class="info-label">DNS</div>
              <div class="info-value">
                <status-badge :status="domain.lastDnsStatus" />
              </div>
            </div>

            <!-- HTTP 状态 -->
            <div class="info-item status-item">
              <div class="info-label">HTTP</div>
              <div class="info-value">
                <status-badge :status="domain.lastHttpStatus" />
              </div>
            </div>

            <!-- SSL 状态 -->
            <div class="info-item status-item">
              <div class="info-label">SSL</div>
              <div class="info-value">
                <status-badge :status="domain.lastSslStatus" />
              </div>
            </div>

            <!-- WHOIS 状态 -->
            <div class="info-item status-item" v-if="domain.enableWhois">
              <div class="info-label">WHOIS</div>
              <div class="info-value">
                <status-badge :status="domain.lastWhoisStatus || 'unknown'" />
              </div>
            </div>

            <!-- 内容状态 -->
            <div class="info-item status-item" v-if="domain.enableContent">
              <div class="info-label">内容</div>
              <div class="info-value">
                <status-badge :status="domain.lastContentStatus || 'unknown'" />
              </div>
            </div>

            <!-- 备注 -->
            <div class="info-item full-width">
              <div class="info-label">备注</div>
              <div class="info-value remark-text">{{ domain.remark || "-" }}</div>
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 右侧：Probe 节点可达性 -->
      <el-col :span="24" :md="10">
        <el-card shadow="hover" class="reach-card">
          <template #header>
            <div class="card-header-custom">
              <span class="card-title">
                <el-icon><Connection /></el-icon>
                Probe 节点可达性
              </span>
              <span v-if="reachability" class="reach-pct">
                <el-progress
                  :percentage="reachability.reachabilityPct"
                  :stroke-width="6"
                  :show-text="false"
                  style="width: 80px; display: inline-block; margin-right: 8px;"
                />
                {{ reachability.reachabilityPct.toFixed(0) }}%
              </span>
            </div>
          </template>

          <div v-if="reachability?.nodes?.length" class="node-list">
            <div v-for="n in reachability.nodes" :key="n.nodeId" class="node-row">
              <span class="node-icon">{{ nodeReachIcon(n.ok) }}</span>
              <span class="node-name">{{ n.nodeName || n.country }}</span>
              <span class="node-meta">{{ n.country }}{{ n.city ? " · " + n.city : "" }}</span>
              <status-badge :status="n.status" size="small" />
            </div>
          </div>
          <el-empty v-else description="暂无 Probe 节点数据" :image-size="80">
            <template #image>
              <el-icon :size="48" color="#c0c4cc"><Connection /></el-icon>
            </template>
          </el-empty>
        </el-card>
      </el-col>
    </el-row>

    <!-- ===== CDN 变更历史 ===== -->
    <el-card v-if="cdnHistory.length" shadow="hover" class="cdn-card">
      <template #header>
        <div class="card-header-custom">
          <span class="card-title">
            <el-icon><Histogram /></el-icon>
            CDN 变更历史
          </span>
          <el-tag size="small" type="info" effect="plain">
            {{ cdnHistory.length }} 次变更
          </el-tag>
        </div>
      </template>
      <el-table :data="cdnHistory" stripe class="modern-table" size="small">
        <el-table-column prop="previousProvider" label="原 CDN" width="140">
          <template #default="{ row }">
            <el-tag v-if="row.previousProvider" type="info" size="small" effect="light">
              {{ row.previousProvider }}
            </el-tag>
            <span v-else class="muted">-</span>
          </template>
        </el-table-column>
        <el-table-column prop="currentProvider" label="现 CDN" width="140">
          <template #default="{ row }">
            <el-tag v-if="row.currentProvider" type="primary" size="small" effect="light">
              {{ row.currentProvider }}
            </el-tag>
            <span v-else class="muted">-</span>
          </template>
        </el-table-column>
        <el-table-column label="时间" width="180">
          <template #default="{ row }">
            <span class="time-value">{{ formatDateTime(row.detectedAt) }}</span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- ===== 检测记录 ===== -->
    <el-card shadow="hover" class="checks-card">
      <template #header>
        <div class="card-header-custom">
          <div class="header-left">
            <span class="card-title">
              <el-icon><List /></el-icon>
              检测记录
            </span>
            <el-tag size="small" type="info" effect="plain">
              {{ checks.length }} 条
            </el-tag>
          </div>
          <div class="header-right">
            <div class="filters">
              <el-select
                v-model="nodeFilter"
                placeholder="全部节点"
                clearable
                style="width: 160px"
                @change="loadChecks"
                class="filter-select"
              >
                <el-option label="Local Center" value="local" />
                <el-option
                  v-for="n in nodeOptions"
                  :key="n.id"
                  :label="n.label"
                  :value="n.id"
                />
              </el-select>
              <el-select
                v-model="checkTypeFilter"
                placeholder="全部类型"
                clearable
                style="width: 140px"
                @change="loadChecks"
                class="filter-select"
              >
                <el-option label="DNS" value="dns" />
                <el-option label="HTTP" value="http" />
                <el-option label="SSL" value="ssl" />
                <el-option label="WHOIS" value="whois" />
                <el-option label="内容" value="content" />
                <el-option label="截图" value="screenshot" />
                <el-option label="用户模拟" value="userSimulation" />
              </el-select>
              <el-button size="small" @click="loadChecks" class="refresh-btn">
                <el-icon><Refresh /></el-icon>
              </el-button>
            </div>
          </div>
        </div>
      </template>

      <el-table :data="checks" stripe class="modern-table" :header-cell-style="headerCellStyle">
        <el-table-column label="节点" min-width="140">
          <template #default="{ row }">
            <div class="node-cell">
              <span class="node-name">{{ row.nodeName || row.nodeId }}</span>
              <span v-if="row.country" class="node-location">
                {{ row.country }}{{ row.city ? " · " + row.city : "" }}
              </span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="checkType" label="类型" width="100">
          <template #default="{ row }">
            <el-tag :type="getCheckTypeTag(row.checkType)" size="small" effect="light">
              {{ getCheckTypeLabel(row.checkType) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <status-badge :status="row.status" />
          </template>
        </el-table-column>
        <el-table-column prop="durationMs" label="耗时" width="100" align="center">
          <template #default="{ row }">
            <span class="duration" :class="getDurationClass(row.durationMs)">
              {{ row.durationMs != null ? row.durationMs + 'ms' : '-' }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="httpStatus" label="HTTP码" width="90" align="center">
          <template #default="{ row }">
            <span v-if="row.httpStatus" class="http-status" :class="getHttpStatusClass(row.httpStatus)">
              {{ row.httpStatus }}
            </span>
            <span v-else class="muted">-</span>
          </template>
        </el-table-column>
        <el-table-column prop="finalUrl" label="最终URL" min-width="160" show-overflow-tooltip>
          <template #default="{ row }">
            <span class="final-url">{{ row.finalUrl || '-' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="检测时间" width="170">
          <template #default="{ row }">
            <span class="time-value">{{ formatDateTime(row.checkedAt) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
          <template #default="{ row }">
            <div class="action-buttons">
              <el-button link type="primary" size="small" @click="showDetail(row)" class="action-btn detail-btn">
                <el-icon><InfoFilled /></el-icon>
                查看
              </el-button>
              <el-button
                v-if="row.screenshotPath"
                link
                type="primary"
                size="small"
                @click="previewScreenshot(row)"
                class="action-btn screenshot-btn"
              >
                <el-icon><Picture /></el-icon>
                截图
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <el-empty v-if="!checks.length && !loading" description="暂无检测记录" class="empty-table">
        <template #image>
          <el-icon :size="48" color="#c0c4cc"><Document /></el-icon>
        </template>
      </el-empty>
    </el-card>

    <!-- ===== 检测详情对话框 ===== -->
    <el-dialog
      v-model="detailVisible"
      :title="detailView?.title || '检测详情'"
      width="680px"
      class="modern-dialog"
      destroy-on-close
    >
      <div class="detail-content">
        <el-descriptions v-if="detailView" :column="1" border size="large" class="detail-descriptions">
          <el-descriptions-item
            v-for="row in detailView.rows"
            :key="row.label"
            :label="row.label"
            :label-class-name="'detail-label'"
          >
            <span class="detail-value" :class="getDetailValueClass(row)">{{ row.value }}</span>
          </el-descriptions-item>
        </el-descriptions>

        <el-alert
          v-if="detailView?.hint"
          :title="detailView.hint"
          type="info"
          :closable="false"
          show-icon
          class="detail-hint"
        />

        <el-collapse v-if="detailView?.rawJson" class="detail-raw">
          <el-collapse-item title="原始数据（技术排查）" name="raw">
            <pre class="detail-json">{{ detailView.rawJson }}</pre>
          </el-collapse-item>
        </el-collapse>
      </div>
      <template #footer>
        <el-button @click="detailVisible = false" size="large">关闭</el-button>
      </template>
    </el-dialog>

    <!-- ===== 截图预览对话框 ===== -->
    <el-dialog
      v-model="shotVisible"
      title="页面截图"
      width="800px"
      class="modern-dialog screenshot-dialog"
      destroy-on-close
    >
      <div class="screenshot-container" v-loading="screenshotLoading">
        <img v-if="shotUrl" :src="shotUrl" class="shot-img" alt="screenshot" @load="screenshotLoading = false" />
        <el-empty v-else description="暂无截图" :image-size="80" />
      </div>
      <template #footer>
        <el-button @click="shotVisible = false" size="large">关闭</el-button>
        <el-button v-if="shotUrl" type="primary" size="large" @click="downloadScreenshot">
          <el-icon><Download /></el-icon>
          下载截图
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from "vue";
import { useRoute } from "vue-router";
import { ElMessage } from "element-plus";
import {
  Check,
  Close,
  InfoFilled,
  Connection,
  Histogram,
  List,
  Refresh,
  VideoPlay,
  Picture,
  Document,
  Download,
} from "@element-plus/icons-vue";
import domainMonitorApi, {
  type DmDomain,
  type DmCheckResult,
  type ProbeReachabilitySummary,
  type DmCDNHistory,
} from "@api/domain_monitor_api";
import {
  statusTagType,
  statusLabel,
  formatDateTime,
  formatInterval,
  healthLevelLabel,
  healthLevelTagType,
  nodeReachIcon,
  formatCheckDetail,
  waitDomainCheckDone,
  type CheckDetailView,
} from "./helpers";

const route = useRoute();
const domainId = route.params.id as string;
const loading = ref(false);
const checking = ref(false);
const pollingAbort = new AbortController();
const baselineLoading = ref(false);
const screenshotLoading = ref(false);
const domain = ref<DmDomain | null>(null);
const checks = ref<DmCheckResult[]>([]);
const reachability = ref<ProbeReachabilitySummary | null>(null);
const cdnHistory = ref<DmCDNHistory[]>([]);
const checkTypeFilter = ref("");
const nodeFilter = ref("");
const detailVisible = ref(false);
const detailView = ref<CheckDetailView | null>(null);
const shotVisible = ref(false);
const shotUrl = ref("");

const headerCellStyle = {
  background: "linear-gradient(135deg, #f8fafc 0%, #eef2f6 100%)",
  color: "#1e293b",
  fontWeight: "600",
  fontSize: "13px",
  borderBottom: "2px solid #e2e8f0",
};

function getReachabilityClass(pct: number | null | undefined): string {
  if (pct == null) return "";
  if (pct >= 90) return "high";
  if (pct >= 70) return "medium";
  return "low";
}

function getCheckTypeLabel(type: string): string {
  const map: Record<string, string> = {
    dns: "DNS",
    http: "HTTP",
    ssl: "SSL",
    whois: "WHOIS",
    content: "内容",
    screenshot: "截图",
    userSimulation: "用户模拟",
  };
  return map[type] || type;
}

function getCheckTypeTag(type: string): string {
  const map: Record<string, string> = {
    dns: "info",
    http: "primary",
    ssl: "warning",
    whois: "success",
    content: "info",
    screenshot: "primary",
    userSimulation: "warning",
  };
  return map[type] || "info";
}

function getDurationClass(ms: number | null | undefined): string {
  if (ms == null) return "";
  if (ms < 500) return "fast";
  if (ms < 2000) return "medium";
  return "slow";
}

function getHttpStatusClass(status: number | null | undefined): string {
  if (status == null) return "";
  if (status >= 200 && status < 300) return "success";
  if (status >= 300 && status < 400) return "warning";
  return "error";
}

function getDetailValueClass(row: { label: string; value: string }): string {
  if (row.label === "状态") {
    const status = row.value.toLowerCase();
    if (status === "正常" || status === "ok") return "value-success";
    if (status === "警告" || status === "warning") return "value-warning";
    if (status === "异常" || status === "error") return "value-danger";
  }
  return "";
}

function downloadScreenshot() {
  if (!shotUrl.value) return;
  const a = document.createElement("a");
  a.href = shotUrl.value;
  a.download = `screenshot_${domain.value?.domain || 'unknown'}_${Date.now()}.png`;
  a.click();
  ElMessage.success("下载已开始");
}

const nodeOptions = computed(() => {
  const seen = new Map<string, string>();
  for (const n of reachability.value?.nodes || []) {
    seen.set(n.nodeId, `${n.nodeName} (${n.country})`);
  }
  for (const c of checks.value) {
    if (c.nodeId && c.nodeId !== "local" && !seen.has(c.nodeId)) {
      seen.set(c.nodeId, `${c.nodeName} (${c.country || "?"})`);
    }
  }
  return [...seen.entries()].map(([id, label]) => ({ id, label }));
});

async function loadReachability() {
  try {
    const { data } = await domainMonitorApi.getReachability(domainId);
    reachability.value = data;
  } catch {
    reachability.value = null;
  }
}

async function loadCDNHistory() {
  try {
    const { data } = await domainMonitorApi.listCDNHistory(domainId);
    cdnHistory.value = data || [];
  } catch {
    cdnHistory.value = [];
  }
}

async function loadDomain() {
  loading.value = true;
  try {
    const { data } = await domainMonitorApi.getDomain(domainId);
    domain.value = data.domain;
    checks.value = data.recentChecks || [];
    await Promise.all([loadReachability(), loadCDNHistory()]);
  } catch (e: any) {
    ElMessage.error(e.message || "加载失败");
  } finally {
    loading.value = false;
  }
}

async function loadChecks() {
  try {
    const { data } = await domainMonitorApi.listChecks(
      domainId,
      checkTypeFilter.value || undefined,
      nodeFilter.value || undefined,
    );
    checks.value = data || [];
  } catch (e: any) {
    ElMessage.error(e.message || "加载记录失败");
  }
}

async function checkNow() {
  checking.value = true;
  const prevCheckAt = domain.value?.lastCheckAt;
  try {
    await domainMonitorApi.checkDomainNow(domainId);
    ElMessage.info("检测进行中…");
    const updated = await waitDomainCheckDone(domainId, prevCheckAt, 120000, pollingAbort.signal);
    if (updated) {
      domain.value = updated;
      await loadDomain();
      ElMessage.success("检测完成");
    } else {
      ElMessage.warning("检测超时，请稍后手动刷新");
    }
  } catch (e: any) {
    ElMessage.error(e.message || "操作失败");
  } finally {
    checking.value = false;
  }
}

async function resetBaseline() {
  baselineLoading.value = true;
  try {
    const { data } = await domainMonitorApi.resetContentBaseline(domainId);
    ElMessage.success(`基线已更新: ${data.contentHashBaseline.slice(0, 12)}...`);
    loadDomain();
  } catch (e: any) {
    ElMessage.error(e.message || "重置失败，请先执行内容检测");
  } finally {
    baselineLoading.value = false;
  }
}

function showDetail(row: DmCheckResult) {
  detailView.value = formatCheckDetail(row);
  detailVisible.value = true;
}

async function previewScreenshot(row: DmCheckResult) {
  if (!row.screenshotPath) return;
  screenshotLoading.value = true;
  try {
    if (shotUrl.value) URL.revokeObjectURL(shotUrl.value);
    const { data } = await domainMonitorApi.fetchScreenshot(row.screenshotPath);
    shotUrl.value = URL.createObjectURL(data as Blob);
    shotVisible.value = true;
  } catch (e: any) {
    ElMessage.error(e.message || "加载截图失败");
    screenshotLoading.value = false;
  }
}

onMounted(loadDomain);
onUnmounted(() => pollingAbort.abort());
</script>

<style scoped>
/* ========== 页面背景 ========== */
.dm-page {
  position: relative;
  padding: 4px;
  min-height: 100vh;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.3;
  animation: floatBlob 25s ease-in-out infinite;
}

.blob-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -150px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -200px;
  left: -150px;
  animation-delay: -8s;
}

.blob-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 20%;
  animation-delay: -16s;
}

@keyframes floatBlob {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(40px, -40px) scale(1.05); }
  66% { transform: translate(-30px, 30px) scale(0.95); }
}

/* ========== 页面头部 ========== */
.page-header-wrapper {
  position: relative;
  z-index: 1;
}

.modern-page-header {
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(12px);
  border-radius: 16px;
  padding: 12px 20px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
}

.modern-page-header :deep(.el-page-header) {
  padding: 0;
}

.modern-page-header :deep(.el-page-header__left) {
  padding: 4px 8px;
  border-radius: 8px;
  transition: all 0.2s ease;
}

.modern-page-header :deep(.el-page-header__left:hover) {
  background: rgba(102, 126, 234, 0.08);
}

.modern-page-header :deep(.el-page-header__content) {
  font-weight: 500;
}

.header-content {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.page-title {
  font-size: 20px;
  font-weight: 700;
  color: #1a1a2e;
}

.health-tag {
  font-weight: 600;
  padding: 4px 14px;
}

.status-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-weight: 500;
}

.status-tag .el-icon {
  font-size: 14px;
}

.header-actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.action-btn {
  border-radius: 10px;
  padding: 8px 18px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.action-btn:hover {
  transform: translateY(-2px);
}

.baseline-btn {
  background: rgba(230, 162, 60, 0.08);
  border-color: #e6a23c;
  color: #e6a23c;
}

.baseline-btn:hover {
  background: rgba(230, 162, 60, 0.15);
}

.check-now-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.25);
}

.check-now-btn:hover {
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35);
}

/* ========== 信息行 ========== */
.info-row {
  margin: 16px 0;
  position: relative;
  z-index: 1;
}

/* ========== 卡片 ========== */
.info-card,
.reach-card,
.cdn-card,
.checks-card {
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
  overflow: hidden;
  transition: all 0.3s ease;
}

.info-card:hover,
.reach-card:hover,
.cdn-card:hover,
.checks-card:hover {
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.info-card :deep(.el-card__header),
.reach-card :deep(.el-card__header),
.cdn-card :deep(.el-card__header),
.checks-card :deep(.el-card__header) {
  padding: 16px 20px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  background: transparent;
}

.info-card :deep(.el-card__body),
.reach-card :deep(.el-card__body),
.cdn-card :deep(.el-card__body),
.checks-card :deep(.el-card__body) {
  padding: 20px;
}

.card-header-custom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  width: 100%;
}

.card-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: #1a1a2e;
}

.card-title .el-icon {
  color: #667eea;
  font-size: 18px;
}

.card-subtitle {
  font-size: 13px;
  color: #909399;
  font-weight: normal;
}

.reach-card {
  height: 100%;
}

.reach-pct {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  font-weight: 600;
  color: #667eea;
}

/* ========== 信息网格 ========== */
.info-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px 24px;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 8px 0;
  border-bottom: 1px solid rgba(0, 0, 0, 0.04);
}

.info-item.highlight {
  grid-column: 1 / -1;
  background: linear-gradient(135deg, #f8fafc 0%, #f1f4f9 100%);
  border-radius: 10px;
  padding: 12px 16px;
  border-bottom: none;
}

.info-item.status-item {
  background: rgba(248, 250, 252, 0.6);
  border-radius: 8px;
  padding: 8px 12px;
  border-bottom: none;
}

.info-item.full-width {
  grid-column: 1 / -1;
  border-bottom: none;
}

.info-label {
  font-size: 12px;
  color: #909399;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.3px;
}

.info-value {
  font-size: 15px;
  font-weight: 500;
  color: #1a1a2e;
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.health-badge {
  font-weight: 600;
  padding: 4px 16px;
}

.reachability-value {
  font-weight: 700;
  font-size: 18px;
}

.reachability-value.high {
  color: #67c23a;
}

.reachability-value.medium {
  color: #e6a23c;
}

.reachability-value.low {
  color: #f56c6c;
}

.reachability-progress {
  flex: 1;
  min-width: 80px;
  max-width: 120px;
}

.group-name {
  font-weight: 500;
  color: #409eff;
}

.interval-value {
  font-weight: 500;
  color: #409eff;
  background: rgba(64, 158, 255, 0.08);
  padding: 2px 12px;
  border-radius: 12px;
}

.time-value {
  color: #606266;
  font-size: 14px;
}

.remark-text {
  color: #606266;
  font-size: 14px;
  line-height: 1.6;
}

.muted {
  color: #c0c4cc;
}

/* ========== 状态徽章组件 ========== */
.status-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status-badge.ok {
  background: #f0f9f0;
  color: #67c23a;
}

.status-badge.warning {
  background: #fdf6ec;
  color: #e6a23c;
}

.status-badge.error {
  background: #fef0f0;
  color: #f56c6c;
}

.status-badge.critical {
  background: #fde2e2;
  color: #f56c6c;
}

.status-badge.unknown {
  background: #f5f7fa;
  color: #909399;
}

.status-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  display: inline-block;
}

.status-dot.ok {
  background: #67c23a;
}

.status-dot.warning {
  background: #e6a23c;
}

.status-dot.error {
  background: #f56c6c;
}

.status-dot.critical {
  background: #f56c6c;
}

.status-dot.unknown {
  background: #909399;
}

/* ========== Node 列表 ========== */
.node-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: 380px;
  overflow-y: auto;
  padding-right: 4px;
}

.node-list::-webkit-scrollbar {
  width: 4px;
}

.node-list::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 2px;
}

.node-list::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-radius: 2px;
}

.node-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  background: rgba(248, 250, 252, 0.6);
  border-radius: 10px;
  transition: all 0.2s ease;
}

.node-row:hover {
  background: rgba(248, 250, 252, 0.9);
  transform: translateX(4px);
}

.node-icon {
  font-size: 16px;
  width: 24px;
  text-align: center;
}

.node-name {
  font-weight: 600;
  min-width: 80px;
  color: #1a1a2e;
}

.node-meta {
  flex: 1;
  color: #909399;
  font-size: 12px;
}

/* ========== 表格 ========== */
.modern-table {
  width: 100%;
}

.modern-table :deep(.el-table__header th) {
  padding: 12px 0;
}

.modern-table :deep(.el-table__row td) {
  padding: 10px 0;
}

.modern-table :deep(.el-table__row) {
  transition: background 0.2s ease;
}

.modern-table :deep(.el-table__row:hover) {
  background: rgba(102, 126, 234, 0.04);
}

.node-cell {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.node-cell .node-name {
  font-weight: 500;
  font-size: 13px;
  min-width: auto;
}

.node-cell .node-location {
  font-size: 11px;
  color: #909399;
}

.duration {
  font-weight: 500;
}

.duration.fast {
  color: #67c23a;
}

.duration.medium {
  color: #e6a23c;
}

.duration.slow {
  color: #f56c6c;
}

.http-status {
  font-weight: 600;
  padding: 2px 8px;
  border-radius: 4px;
}

.http-status.success {
  color: #67c23a;
  background: #f0f9f0;
}

.http-status.warning {
  color: #e6a23c;
  background: #fdf6ec;
}

.http-status.error {
  color: #f56c6c;
  background: #fef0f0;
}

.final-url {
  color: #409eff;
  font-size: 13px;
}

/* ========== 操作按钮 ========== */
.action-buttons {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
}

.action-btn {
  padding: 4px 8px;
  border-radius: 6px;
  transition: all 0.2s ease;
  font-size: 12px;
}

.action-btn:hover {
  transform: scale(1.05);
}

.action-btn .el-icon {
  font-size: 13px;
}

.detail-btn {
  color: #409eff;
}

.detail-btn:hover {
  background: rgba(64, 158, 255, 0.1);
}

.screenshot-btn {
  color: #67c23a;
}

.screenshot-btn:hover {
  background: rgba(103, 194, 58, 0.1);
}

/* ========== 过滤器 ========== */
.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-right {
  display: flex;
  align-items: center;
}

.filters {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.filter-select :deep(.el-input__wrapper) {
  border-radius: 8px;
  padding: 2px 12px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
}

.filter-select :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #667eea;
}

.filter-select :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

.refresh-btn {
  border-radius: 8px;
  transition: all 0.2s ease;
}

.refresh-btn:hover {
  transform: rotate(45deg);
}

/* ========== 空状态 ========== */
.empty-table {
  padding: 20px 0;
}

/* ========== 对话框 ========== */
.modern-dialog :deep(.el-dialog) {
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
}

.modern-dialog :deep(.el-dialog__header) {
  padding: 20px 24px;
  margin: 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-bottom: none;
}

.modern-dialog :deep(.el-dialog__title) {
  color: white;
  font-size: 18px;
  font-weight: 600;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: white;
  font-size: 20px;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close:hover) {
  color: rgba(255, 255, 255, 0.7);
}

.modern-dialog :deep(.el-dialog__body) {
  padding: 24px;
}

.modern-dialog :deep(.el-dialog__footer) {
  padding: 16px 24px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.detail-content {
  max-height: 60vh;
  overflow-y: auto;
}

.detail-content::-webkit-scrollbar {
  width: 6px;
}

.detail-content::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 3px;
}

.detail-content::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-radius: 3px;
}

.detail-descriptions :deep(.el-descriptions__label) {
  font-weight: 600;
  color: #1a1a2e;
  background: rgba(248, 250, 252, 0.8);
  width: 120px;
}

.detail-value {
  font-family: monospace;
  font-size: 14px;
  word-break: break-all;
}

.detail-value.value-success {
  color: #67c23a;
}

.detail-value.value-warning {
  color: #e6a23c;
}

.detail-value.value-danger {
  color: #f56c6c;
}

.detail-hint {
  margin-top: 16px;
  border-radius: 10px;
}

.detail-raw {
  margin-top: 16px;
}

.detail-raw :deep(.el-collapse-item__header) {
  font-weight: 500;
  border-radius: 8px;
  background: #f5f7fa;
  padding: 0 12px;
}

.detail-raw :deep(.el-collapse-item__wrap) {
  border-radius: 0 0 8px 8px;
}

.detail-json {
  background: #1a1a2e;
  color: #e2e8f0;
  padding: 16px;
  border-radius: 8px;
  max-height: 300px;
  overflow: auto;
  font-size: 12px;
  white-space: pre-wrap;
  word-break: break-all;
  font-family: "Monaco", "Menlo", "Consolas", monospace;
  line-height: 1.6;
}

/* ========== 截图对话框 ========== */
.screenshot-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 300px;
  background: #f5f7fa;
  border-radius: 12px;
  overflow: hidden;
}

.shot-img {
  max-width: 100%;
  max-height: 70vh;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  object-fit: contain;
}

/* ========== 响应式 ========== */
@media (max-width: 1024px) {
  .info-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .info-item.highlight {
    grid-column: 1 / -1;
  }

  .info-item.full-width {
    grid-column: 1 / -1;
  }
}

@media (max-width: 768px) {
  .page-header-wrapper {
    padding: 0 4px;
  }

  .modern-page-header {
    padding: 12px 16px;
  }

  .header-content {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }

  .page-title {
    font-size: 17px;
  }

  .header-actions {
    width: 100%;
    flex-direction: column;
  }

  .header-actions .action-btn {
    width: 100%;
    justify-content: center;
  }

  .info-grid {
    grid-template-columns: 1fr;
  }

  .info-item.highlight {
    grid-column: 1;
  }

  .info-item.full-width {
    grid-column: 1;
  }

  .info-card :deep(.el-card__body),
  .reach-card :deep(.el-card__body),
  .cdn-card :deep(.el-card__body),
  .checks-card :deep(.el-card__body) {
    padding: 16px;
  }

  .filters {
    flex-direction: column;
    align-items: stretch;
    width: 100%;
  }

  .filters .el-select {
    width: 100% !important;
  }

  .card-header-custom {
    flex-direction: column;
    align-items: flex-start;
  }

  .header-left,
  .header-right {
    width: 100%;
  }

  .node-row {
    flex-wrap: wrap;
    gap: 4px;
  }

  .node-name {
    min-width: 60px;
  }

  .modern-dialog :deep(.el-dialog) {
    width: 95% !important;
    margin: 20px auto !important;
  }

  .detail-descriptions :deep(.el-descriptions__label) {
    width: 80px;
    font-size: 13px;
  }

  .action-buttons {
    flex-wrap: wrap;
  }
}

@media (max-width: 480px) {
  .page-title {
    font-size: 15px;
  }

  .info-item .info-value {
    font-size: 13px;
  }

  .reachability-value {
    font-size: 16px;
  }

  .health-tag {
    font-size: 12px;
    padding: 2px 10px;
  }

  .status-tag {
    font-size: 11px;
  }

  .detail-json {
    font-size: 11px;
    padding: 12px;
  }
}
</style>
<template>
  <div class="dm-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
    </div>

    <el-row :gutter="16" class="stats-row">
      <el-col :xs="12" :sm="6" v-for="card in statCards" :key="card.label">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-inner">
            <div class="stat-icon" :style="{ background: card.color }">
              <el-icon :size="22"><component :is="card.icon" /></el-icon>
            </div>
            <div>
              <div class="stat-value">{{ card.value }}</div>
              <div class="stat-label">{{ card.label }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="never" class="main-card" v-loading="loading">
      <template #header>
        <div class="card-header">
          <div class="header-title">
            <el-icon><Monitor /></el-icon>
            <span>Probe 节点</span>
          </div>
          <div class="header-actions">
            <el-button @click="loadNodes">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
            <el-button type="primary" v-permission="'domain_monitor:manage'" @click="openDialog()">
              <el-icon><Plus /></el-icon>
              添加节点
            </el-button>
          </div>
        </div>
      </template>

      <div v-if="nodes.length" class="node-grid">
        <div
          v-for="row in nodes"
          :key="row.id"
          class="node-card"
          :class="{ online: isOnline(row), disabled: !row.enabled }"
        >
          <div class="node-card-head">
            <div class="node-identity">
              <span class="status-dot" :class="isOnline(row) ? 'on' : 'off'"></span>
              <div>
                <div class="node-name">{{ row.name }}</div>
                <div class="node-location">
                  <el-icon><Location /></el-icon>
                  {{ locationLabel(row) }}
                </div>
              </div>
            </div>
            <el-tag :type="row.enabled ? (isOnline(row) ? 'success' : 'info') : 'warning'" size="small" effect="light">
              {{ row.enabled ? (isOnline(row) ? "在线" : "离线") : "已禁用" }}
            </el-tag>
          </div>

          <div class="node-meta">
            <div class="meta-item">
              <span class="meta-label">公网 IP</span>
              <span class="meta-value">{{ row.publicIp || "—" }}</span>
            </div>
            <div class="meta-item">
              <span class="meta-label">版本</span>
              <span class="meta-value">{{ row.version || "—" }}</span>
            </div>
            <div class="meta-item">
              <span class="meta-label">最后心跳</span>
              <span class="meta-value">{{ formatDateTime(row.lastSeenAt) }}</span>
            </div>
          </div>

          <div class="resource-bars">
            <div class="resource-row">
              <span>CPU</span>
              <el-progress
                :percentage="clampPercent(row.cpuPercent)"
                :stroke-width="8"
                :color="progressColor(row.cpuPercent)"
                :show-text="row.cpuPercent != null"
              />
            </div>
            <div class="resource-row">
              <span>内存</span>
              <el-progress
                :percentage="clampPercent(row.memoryPercent)"
                :stroke-width="8"
                :color="progressColor(row.memoryPercent)"
                :show-text="row.memoryPercent != null"
              />
            </div>
          </div>

          <div class="node-actions">
            <el-button size="small" @click="viewLogs(row)">
              <el-icon><Document /></el-icon>
              日志
            </el-button>
            <el-button size="small" v-permission="'domain_monitor:manage'" @click="openDialog(row)">
              <el-icon><Edit /></el-icon>
              编辑
            </el-button>
            <el-button size="small" type="danger" plain v-permission="'domain_monitor:manage'" @click="remove(row)">
              <el-icon><Delete /></el-icon>
              删除
            </el-button>
          </div>
        </div>
      </div>

      <el-empty v-else description="暂无 Probe 节点" class="empty-state">
        <el-button type="primary" v-permission="'domain_monitor:manage'" @click="openDialog()">
          添加第一个节点
        </el-button>
      </el-empty>
    </el-card>

    <el-card shadow="never" class="guide-card">
      <template #header>
        <div class="card-header">
          <div class="header-title">
            <el-icon><Guide /></el-icon>
            <span>部署指南</span>
          </div>
        </div>
      </template>
      <el-collapse accordion>
        <el-collapse-item title="架构说明：Probe 与 Proxy 双模式" name="arch">
          <p><strong>Probe 模式</strong>：在 VPS 上部署探针，由探针本机执行 DNS / HTTP / SSL 等真实网络检测。</p>
          <p><strong>Proxy 模式</strong>：监控中心通过「检测配置 → HTTP 代理」走代理检测。</p>
          <p>域名编辑页可为每项检测单独选择 Probe / Proxy / Local。</p>
        </el-collapse-item>
        <el-collapse-item title="手动部署（推荐生产环境）" name="manual">
          <ol class="guide-list">
            <li>本页添加节点，保存返回的 API Key（仅显示一次）</li>
            <li>
              设置环境变量并启动探针：
              <pre class="code-block">set DM_SERVER=http://中心地址:8080
set DM_NODE_KEY=你的API密钥
go run ./cmd/dm-probe</pre>
            </li>
          </ol>
        </el-collapse-item>
        <el-collapse-item title="自动注册部署" name="auto">
          <ol class="guide-list">
            <li>在「检测配置」中设置 Probe 注册令牌</li>
            <li>
              在 VPS 上执行：
              <pre class="code-block">set DM_REGISTER_TOKEN=注册令牌
set DM_NODE_NAME=Brazil-1
set DM_NODE_COUNTRY=BR
go run ./cmd/dm-probe</pre>
            </li>
          </ol>
        </el-collapse-item>
        <el-collapse-item title="截图检测依赖（Playwright）" name="playwright">
          <pre class="code-block">cd cmd/dm-probe/scripts
npm i playwright
npx playwright install chromium</pre>
        </el-collapse-item>
      </el-collapse>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="form.id ? '编辑节点' : '添加 Probe 节点'" width="480px" class="node-dialog">
      <el-form :model="form" label-width="80px">
        <el-form-item label="名称" required>
          <el-input v-model="form.name" placeholder="如 Brazil-1 / SG-Edge" />
        </el-form-item>
        <el-form-item label="国家">
          <el-input v-model="form.country" placeholder="BR / US / JP / SG / DE" />
        </el-form-item>
        <el-form-item label="城市">
          <el-input v-model="form.city" placeholder="可选" />
        </el-form-item>
        <el-form-item label="启用">
          <el-switch v-model="form.enabled" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submit">确定</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="keyVisible" title="节点 API Key（仅显示一次）" width="520px">
      <el-alert type="warning" :closable="false" show-icon title="请立即复制保存，关闭后无法再次查看" class="key-alert" />
      <el-input v-model="createdKey" readonly class="key-input">
        <template #append>
          <el-button @click="copyKey">复制</el-button>
        </template>
      </el-input>
    </el-dialog>

    <el-dialog v-model="logsVisible" :title="`Probe 任务日志 — ${logsNodeName}`" width="760px">
      <el-table :data="logs" size="small" max-height="420" stripe>
        <el-table-column label="域名" min-width="160">
          <template #default="{ row }">{{ row.domain?.domain || row.domainId }}</template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag size="small" :type="row.status === 'done' ? 'success' : row.status === 'failed' ? 'danger' : 'info'">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="创建" width="170">
          <template #default="{ row }">{{ formatDateTime(row.createdAt) }}</template>
        </el-table-column>
        <el-table-column label="完成" width="170">
          <template #default="{ row }">{{ formatDateTime(row.completedAt) }}</template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Plus,
  Refresh,
  Monitor,
  Location,
  Document,
  Edit,
  Delete,
  Guide,
  Connection,
  CircleCheck,
  CircleClose,
  SwitchButton,
} from "@element-plus/icons-vue";
import domainMonitorApi, { type DmNode, type DmProbeTaskLog } from "@api/domain_monitor_api";
import { formatDateTime } from "./helpers";

const loading = ref(false);
const submitting = ref(false);
const nodes = ref<DmNode[]>([]);
const dialogVisible = ref(false);
const keyVisible = ref(false);
const createdKey = ref("");
const logsVisible = ref(false);
const logsNodeName = ref("");
const logs = ref<DmProbeTaskLog[]>([]);

const form = reactive({
  id: "",
  name: "",
  country: "CN",
  city: "",
  enabled: true,
});

const statCards = computed(() => {
  const total = nodes.value.length;
  const online = nodes.value.filter((n) => n.enabled && isOnline(n)).length;
  const offline = nodes.value.filter((n) => n.enabled && !isOnline(n)).length;
  const disabled = nodes.value.filter((n) => !n.enabled).length;
  return [
    { label: "总节点", value: total, icon: Connection, color: "linear-gradient(135deg, #667eea, #764ba2)" },
    { label: "在线", value: online, icon: CircleCheck, color: "linear-gradient(135deg, #11998e, #38ef7d)" },
    { label: "离线", value: offline, icon: CircleClose, color: "linear-gradient(135deg, #f093fb, #f5576c)" },
    { label: "已禁用", value: disabled, icon: SwitchButton, color: "linear-gradient(135deg, #a8a8a8, #6b7280)" },
  ];
});

function isOnline(row: DmNode) {
  if (!row.lastSeenAt) return false;
  return Date.now() - new Date(row.lastSeenAt).getTime() < 5 * 60 * 1000;
}

function locationLabel(row: DmNode) {
  const parts = [row.country, row.city].filter(Boolean);
  return parts.length ? parts.join(" · ") : "未设置位置";
}

function clampPercent(value?: number | null) {
  if (value == null) return 0;
  return Math.min(100, Math.max(0, Math.round(value)));
}

function progressColor(value?: number | null) {
  const pct = value ?? 0;
  if (pct >= 85) return "#f56c6c";
  if (pct >= 60) return "#e6a23c";
  return "#67c23a";
}

async function loadNodes() {
  loading.value = true;
  try {
    const { data } = await domainMonitorApi.listNodes();
    nodes.value = data || [];
  } catch (e: any) {
    ElMessage.error(e.message || "加载失败");
  } finally {
    loading.value = false;
  }
}

function openDialog(row?: DmNode) {
  if (row) {
    form.id = row.id;
    form.name = row.name;
    form.country = row.country || "CN";
    form.city = row.city || "";
    form.enabled = row.enabled;
  } else {
    form.id = "";
    form.name = "";
    form.country = "CN";
    form.city = "";
    form.enabled = true;
  }
  dialogVisible.value = true;
}

async function viewLogs(row: DmNode) {
  logsNodeName.value = row.name;
  logsVisible.value = true;
  try {
    const { data } = await domainMonitorApi.getNodeLogs(row.id);
    logs.value = data || [];
  } catch (e: any) {
    ElMessage.error(e.message || "加载日志失败");
  }
}

async function submit() {
  if (!form.name.trim()) {
    ElMessage.warning("请输入名称");
    return;
  }
  submitting.value = true;
  try {
    if (form.id) {
      await domainMonitorApi.updateNode(form.id, {
        name: form.name,
        country: form.country,
        city: form.city,
        enabled: form.enabled,
      });
      ElMessage.success("已更新");
    } else {
      const { data } = await domainMonitorApi.createNode({
        name: form.name,
        country: form.country,
        city: form.city,
        enabled: form.enabled,
      });
      createdKey.value = (data as any).apiKey || "";
      keyVisible.value = !!createdKey.value;
      ElMessage.success("节点已创建");
    }
    dialogVisible.value = false;
    loadNodes();
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    submitting.value = false;
  }
}

async function remove(row: DmNode) {
  try {
    await ElMessageBox.confirm(`删除节点「${row.name}」？`, "确认删除", { type: "warning" });
    await domainMonitorApi.deleteNode(row.id);
    ElMessage.success("已删除");
    loadNodes();
  } catch {
    /* cancelled */
  }
}

function copyKey() {
  navigator.clipboard.writeText(createdKey.value);
  ElMessage.success("已复制");
}

onMounted(loadNodes);
</script>

<style scoped>
.dm-page {
  position: relative;
  padding: 4px;
  min-height: 100%;
}

.bg-decoration {
  position: absolute;
  inset: 0;
  overflow: hidden;
  pointer-events: none;
  z-index: 0;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(60px);
  opacity: 0.3;
}

.blob-1 {
  width: 260px;
  height: 260px;
  background: #667eea;
  top: -60px;
  right: -40px;
}

.blob-2 {
  width: 200px;
  height: 200px;
  background: #38ef7d;
  bottom: 40px;
  left: -50px;
}

.stats-row,
.main-card,
.guide-card {
  position: relative;
  z-index: 1;
}

.stat-card {
  margin-bottom: 16px;
  border-radius: 12px;
}

.stat-inner {
  display: flex;
  align-items: center;
  gap: 12px;
}

.stat-icon {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
}

.stat-value {
  font-size: 22px;
  font-weight: 700;
  line-height: 1.2;
}

.stat-label {
  color: #909399;
  font-size: 12px;
  margin-top: 2px;
}

.main-card,
.guide-card {
  border-radius: 12px;
  margin-bottom: 16px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.header-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
  font-size: 15px;
}

.header-actions {
  display: flex;
  gap: 8px;
}

.node-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 16px;
}

.node-card {
  border: 1px solid #ebeef5;
  border-radius: 12px;
  padding: 16px;
  background: linear-gradient(180deg, #fff 0%, #fafbfc 100%);
  transition: box-shadow 0.2s, border-color 0.2s;
}

.node-card:hover {
  box-shadow: 0 8px 24px rgba(102, 126, 234, 0.12);
  border-color: #dcdfe6;
}

.node-card.online {
  border-left: 3px solid #67c23a;
}

.node-card.disabled {
  opacity: 0.75;
}

.node-card-head {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 8px;
  margin-bottom: 14px;
}

.node-identity {
  display: flex;
  gap: 10px;
  align-items: flex-start;
}

.status-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin-top: 6px;
  flex-shrink: 0;
}

.status-dot.on {
  background: #67c23a;
  box-shadow: 0 0 0 3px rgba(103, 194, 58, 0.2);
}

.status-dot.off {
  background: #c0c4cc;
}

.node-name {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.node-location {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

.node-meta {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px 12px;
  margin-bottom: 14px;
}

.meta-item {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.meta-label {
  font-size: 11px;
  color: #909399;
}

.meta-value {
  font-size: 13px;
  color: #606266;
  word-break: break-all;
}

.resource-bars {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 14px;
}

.resource-row {
  display: grid;
  grid-template-columns: 36px 1fr;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: #909399;
}

.node-actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  padding-top: 12px;
  border-top: 1px dashed #ebeef5;
}

.empty-state {
  padding: 32px 0;
}

.guide-list {
  margin: 0 0 0 20px;
  padding: 0;
  line-height: 1.7;
  color: #606266;
}

.code-block {
  margin: 8px 0;
  padding: 12px 14px;
  background: #1e293b;
  color: #e2e8f0;
  border-radius: 8px;
  font-size: 12px;
  line-height: 1.6;
  overflow-x: auto;
  white-space: pre-wrap;
  word-break: break-all;
}

.key-alert {
  margin-bottom: 12px;
}

.key-input {
  margin-top: 4px;
}
</style>

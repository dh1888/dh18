<template>
  <div class="callback-page">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <el-card shadow="hover" class="main-card" v-loading="loading">
      <!-- ===== 卡片头部 ===== -->
      <template #header>
        <div class="card-header-custom">
          <div class="header-left">
            <div class="header-icon-wrapper">
              <el-icon class="header-icon"><Setting /></el-icon>
            </div>
            <div class="header-info">
              <span class="header-title">活动配置</span>
              <span class="header-subtitle">管理彩金规则与策略</span>
            </div>
          </div>
          <div class="header-right" v-if="activity?.updatedAt">
            <el-tag type="info" effect="plain" size="large" class="update-tag">
              <el-icon><Timer /></el-icon>
              更新于 {{ activity.updatedAt }}
            </el-tag>
          </div>
        </div>
      </template>

      <!-- ===== 空状态 ===== -->
      <el-empty v-if="!loading && !activity" description="暂无活动配置" class="empty-state">
        <template #image>
          <el-icon :size="80" color="#c0c4cc"><Setting /></el-icon>
        </template>
        <el-button type="primary" size="large" :loading="saving" @click="initDefaults" class="init-btn">
          <el-icon><Plus /></el-icon>
          初始化默认配置
        </el-button>
      </el-empty>

      <!-- ===== 配置表单 ===== -->
      <template v-else-if="activity">
        <el-form :model="activity" label-width="140px" class="config-form">
          <!-- 统计天数 -->
          <div class="form-section">
            <div class="section-header">
              <span class="section-icon">📊</span>
              <span class="section-title">基础配置</span>
            </div>
            <el-form-item label="统计天数">
              <div class="input-group">
                <el-input-number
                  v-model="activity.days"
                  :min="1"
                  :max="365"
                  size="large"
                  controls-position="right"
                  class="modern-input-number"
                />
                <span class="field-hint">用于默认日期范围（含今天）</span>
              </div>
            </el-form-item>
          </div>

          <!-- Tabs -->
          <el-tabs v-model="activeTab" class="config-tabs">
            <!-- ===== 时段彩金 Tab ===== -->
            <el-tab-pane label="时段彩金" name="period">
              <template #label>
                <span class="tab-label">
                  <el-icon><Timer /></el-icon>
                  时段彩金
                </span>
              </template>

              <div class="tab-toolbar">
                <el-button link type="primary" @click="periodHelpVisible = true" class="help-btn">
                  <el-icon><InfoFilled /></el-icon>
                  规则说明
                </el-button>
              </div>

              <div class="form-grid">
                <el-form-item label="彩金比例">
                  <div class="input-group">
                    <el-input-number
                      v-model="activity.rate"
                      :min="0"
                      :max="1"
                      :step="0.01"
                      :precision="4"
                      size="large"
                      controls-position="right"
                      class="modern-input-number"
                    />
                    <span class="field-hint">如 0.02 表示 2%</span>
                  </div>
                </el-form-item>

                <el-form-item label="除数">
                  <div class="input-group">
                    <el-input-number
                      v-model="activity.divisor"
                      :min="1"
                      size="large"
                      controls-position="right"
                      class="modern-input-number"
                    />
                  </div>
                </el-form-item>

                <el-form-item label="最低彩金">
                  <div class="input-group">
                    <el-input-number
                      v-model="activity.minBonus"
                      :min="0"
                      :precision="2"
                      size="large"
                      controls-position="right"
                      class="modern-input-number"
                    />
                  </div>
                </el-form-item>

                <el-form-item label="最高彩金">
                  <div class="input-group">
                    <el-input-number
                      v-model="activity.maxBonus"
                      :min="0"
                      :precision="2"
                      size="large"
                      controls-position="right"
                      class="modern-input-number"
                    />
                  </div>
                </el-form-item>

                <el-form-item label="过滤层级" class="full-width">
                  <div class="input-group">
                    <el-select
                      v-model="activity.periodFilteredTiers"
                      multiple
                      filterable
                      allow-create
                      default-first-option
                      collapse-tags
                      collapse-tags-tooltip
                      placeholder="输入或选择需过滤的层级"
                      class="modern-select"
                      size="large"
                    >
                      <el-option
                        v-for="tier in periodTierOptions"
                        :key="tier"
                        :label="tier"
                        :value="tier"
                      />
                    </el-select>
                    <span class="field-hint">配合「层级过滤」规则使用</span>
                  </div>
                </el-form-item>

                <el-form-item label="启用规则" class="full-width">
                  <div class="rule-checkboxes-wrapper">
                    <el-checkbox-group v-model="periodEnabledFilters" class="rule-checkboxes">
                      <el-checkbox v-for="f in MANUAL_FILTER_CATALOG" :key="f.id" :value="f.id" size="large">
                        <span class="rule-label">{{ f.label }}</span>
                        <span class="rule-desc"> — {{ f.description }}</span>
                      </el-checkbox>
                    </el-checkbox-group>
                  </div>
                </el-form-item>

                <el-form-item label="打码倍数">
                  <div class="input-group">
                    <el-input-number
                      v-model="activity.periodWageringMultiplier"
                      :min="0"
                      :precision="2"
                      size="large"
                      controls-position="right"
                      class="modern-input-number"
                    />
                  </div>
                </el-form-item>

                <el-form-item label="APP端备注" class="full-width">
                  <div class="input-group">
                    <el-input
                      v-model="activity.periodAppRemark"
                      type="textarea"
                      :rows="2"
                      placeholder="APP 端展示文案"
                      class="modern-textarea"
                      size="large"
                    />
                  </div>
                </el-form-item>

                <el-form-item label="后台备注" class="full-width">
                  <div class="input-group">
                    <el-input
                      v-model="activity.periodBackendRemark"
                      type="textarea"
                      :rows="2"
                      placeholder="后台展示文案"
                      class="modern-textarea"
                      size="large"
                    />
                  </div>
                </el-form-item>
              </div>
            </el-tab-pane>

            <!-- ===== 回访彩金 Tab ===== -->
            <el-tab-pane label="回访彩金" name="callback">
              <template #label>
                <span class="tab-label">
                  <el-icon><Phone /></el-icon>
                  回访彩金
                </span>
              </template>

              <div class="tab-toolbar">
                <el-button link type="primary" @click="callbackHelpVisible = true" class="help-btn">
                  <el-icon><InfoFilled /></el-icon>
                  规则说明
                </el-button>
              </div>

              <div class="form-grid">
                <el-form-item label="彩金比例">
                  <div class="input-group">
                    <el-input-number
                      v-model="activity.callbackRate"
                      :min="0"
                      :max="1"
                      :step="0.01"
                      :precision="4"
                      size="large"
                      controls-position="right"
                      class="modern-input-number"
                    />
                    <span class="field-hint">亏损计算用，如 0.02 表示 2%</span>
                  </div>
                </el-form-item>

                <el-form-item label="除数">
                  <div class="input-group">
                    <el-input-number
                      v-model="activity.callbackDivisor"
                      :min="1"
                      size="large"
                      controls-position="right"
                      class="modern-input-number"
                    />
                    <span class="field-hint">亏损计算用</span>
                  </div>
                </el-form-item>

                <el-form-item label="回访最低彩金">
                  <div class="input-group">
                    <el-input-number
                      v-model="activity.callbackMinBonus"
                      :min="0"
                      :precision="2"
                      size="large"
                      controls-position="right"
                      class="modern-input-number"
                    />
                    <span class="field-hint">盈利按此金额送，亏损计算后不低于此值</span>
                  </div>
                </el-form-item>

                <el-form-item label="过滤层级" class="full-width">
                  <div class="input-group">
                    <el-select
                      v-model="activity.callbackFilteredTiers"
                      multiple
                      filterable
                      allow-create
                      default-first-option
                      collapse-tags
                      collapse-tags-tooltip
                      placeholder="输入或选择需过滤的层级"
                      class="modern-select"
                      size="large"
                    >
                      <el-option
                        v-for="tier in callbackTierOptions"
                        :key="tier"
                        :label="tier"
                        :value="tier"
                      />
                    </el-select>
                    <span class="field-hint">配合「层级过滤」规则使用</span>
                  </div>
                </el-form-item>

                <el-form-item label="启用规则" class="full-width">
                  <div class="rule-checkboxes-wrapper">
                    <el-checkbox-group v-model="callbackEnabledFilters" class="rule-checkboxes">
                      <el-checkbox v-for="f in MANUAL_FILTER_CATALOG" :key="f.id" :value="f.id" size="large">
                        <span class="rule-label">{{ f.label }}</span>
                        <span class="rule-desc"> — {{ f.description }}</span>
                      </el-checkbox>
                    </el-checkbox-group>
                  </div>
                </el-form-item>

                <el-form-item label="打码倍数">
                  <div class="input-group">
                    <el-input-number
                      v-model="activity.callbackWageringMultiplier"
                      :min="0"
                      :precision="2"
                      size="large"
                      controls-position="right"
                      class="modern-input-number"
                    />
                  </div>
                </el-form-item>

                <el-form-item label="APP端备注" class="full-width">
                  <div class="input-group">
                    <el-input
                      v-model="activity.callbackAppRemark"
                      type="textarea"
                      :rows="2"
                      placeholder="APP 端展示文案"
                      class="modern-textarea"
                      size="large"
                    />
                  </div>
                </el-form-item>

                <el-form-item label="后台备注" class="full-width">
                  <div class="input-group">
                    <el-input
                      v-model="activity.callbackBackendRemark"
                      type="textarea"
                      :rows="2"
                      placeholder="后台展示文案"
                      class="modern-textarea"
                      size="large"
                    />
                  </div>
                </el-form-item>
              </div>
            </el-tab-pane>
          </el-tabs>

          <!-- ===== 保存按钮 ===== -->
          <div class="form-actions">
            <el-button type="primary" size="large" :loading="saving" @click="save" class="save-btn">
              <el-icon v-if="!saving"><Check /></el-icon>
              <span>{{ saving ? '保存中...' : '保存配置' }}</span>
            </el-button>
            <el-button size="large" @click="load" :loading="loading" class="reset-btn">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
          </div>
        </el-form>
      </template>
    </el-card>

    <!-- ===== 时段彩金规则说明对话框 ===== -->
    <el-dialog v-model="periodHelpVisible" title="时段彩金规则说明" width="560px" class="modern-dialog">
      <div class="help-content">
        <div class="help-icon-big">📋</div>
        <ul class="rule-list">
          <li>
            <span class="rule-dot">•</span>
            筛选条件：充提差 = 订单充值 − 订单提现（负数为盈利，零或正数为亏损/持平）
          </li>
          <li>
            <span class="rule-dot">•</span>
            可在下方勾选启用规则（层级过滤、未领彩金剔除等），后续可继续扩展
          </li>
          <li>
            <span class="rule-dot">•</span>
            用户亏损或持平（充提差 ≥ 0）计算彩金：充提差 × 比例 ÷ 除数，低于最低取最低
          </li>
          <li class="highlight">
            <span class="rule-dot">💡</span>
            示例：充提差 = +1000，比例 {{ activity?.rate }}，除数 {{ activity?.divisor }}
            → 彩金 <strong>{{ formatMoney(previewPeriodBonus) }}</strong>
          </li>
          <li>
            <span class="rule-dot">•</span>
            手动导入「时段彩金」时读取本 Tab 配置
          </li>
        </ul>
      </div>
    </el-dialog>

    <!-- ===== 回访彩金规则说明对话框 ===== -->
    <el-dialog v-model="callbackHelpVisible" title="回访彩金规则说明" width="560px" class="modern-dialog">
      <div class="help-content">
        <div class="help-icon-big">📞</div>
        <ul class="rule-list">
          <li>
            <span class="rule-dot">•</span>
            上传会员数据 + 未领彩金名单（仅按会员 ID 匹配）
          </li>
          <li>
            <span class="rule-dot">•</span>
            剔除过滤层级；会员 ID 在未领名单中则剔除
          </li>
          <li>
            <span class="rule-dot">•</span>
            充提差 = 累计充值 − 累计提款（负数为盈利，正数为亏损）
          </li>
          <li>
            <span class="rule-dot">•</span>
            盈利（充提差 &lt; 0）：送回访最低彩金
          </li>
          <li>
            <span class="rule-dot">•</span>
            亏损（充提差 &gt; 0）：充提差 × 比例 ÷ 除数，不低于回访最低彩金
          </li>
          <li class="highlight">
            <span class="rule-dot">💡</span>
            示例亏损：充提差 = +1000，比例 {{ activity?.callbackRate }}，除数 {{ activity?.callbackDivisor }}
            → 彩金 <strong>{{ formatMoney(previewCallbackBonus) }}</strong>
          </li>
          <li>
            <span class="rule-dot">•</span>
            盈利与亏损分别进入「盈利回访」「亏损回访」派发表
          </li>
        </ul>
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { ElMessage } from "element-plus";
import { InfoFilled, Setting, Timer, Phone, Check, Refresh, Plus } from "@element-plus/icons-vue";
import callbackApi, { type CallbackActivity } from "@api/callback_api";
import { DEFAULT_FILTERED_TIERS } from "./columnMapping";
import {
  calcBonusPreview,
  calcCallbackBonusPreview,
  formatMoney,
  validateActivityForm,
} from "./helpers";
import {
  ensureActivityManualRules,
  MANUAL_FILTER_CATALOG,
  defaultManualRules,
} from "./manualRules";
import "./styles.css";

const activity = ref<CallbackActivity | null>(null);
const loading = ref(false);
const saving = ref(false);
const activeTab = ref("period");
const periodHelpVisible = ref(false);
const callbackHelpVisible = ref(false);

const periodTierOptions = computed(() => {
  const tiers = activity.value?.periodFilteredTiers ?? [];
  return Array.from(new Set([...DEFAULT_FILTERED_TIERS, ...tiers]));
});

const callbackTierOptions = computed(() => {
  const tiers = activity.value?.callbackFilteredTiers ?? [];
  return Array.from(new Set([...DEFAULT_FILTERED_TIERS, ...tiers]));
});

const previewPeriodBonus = computed(() =>
  activity.value ? calcBonusPreview(1000, activity.value) : 0,
);

const previewCallbackBonus = computed(() =>
  activity.value ? calcCallbackBonusPreview(1000, activity.value) : 0,
);

const periodEnabledFilters = computed({
  get: () =>
    activity.value?.periodManualRules?.enabledFilters ??
    defaultManualRules("period_bonus").enabledFilters,
  set: (v: string[]) => {
    if (!activity.value) return;
    activity.value.periodManualRules = { enabledFilters: [...v] };
  },
});

const callbackEnabledFilters = computed({
  get: () =>
    activity.value?.callbackManualRules?.enabledFilters ??
    defaultManualRules("callback_bonus").enabledFilters,
  set: (v: string[]) => {
    if (!activity.value) return;
    activity.value.callbackManualRules = { enabledFilters: [...v] };
  },
});

function normalizeActivityFields(a: CallbackActivity) {
  if (a.periodWageringMultiplier == null) a.periodWageringMultiplier = 1;
  if (a.callbackWageringMultiplier == null) a.callbackWageringMultiplier = 1;
  if (a.periodAppRemark == null) a.periodAppRemark = "";
  if (a.periodBackendRemark == null) a.periodBackendRemark = "";
  if (a.callbackAppRemark == null) a.callbackAppRemark = "";
  if (a.callbackBackendRemark == null) a.callbackBackendRemark = "";
  if (!a.periodFilteredTiers?.length) {
    a.periodFilteredTiers = [...DEFAULT_FILTERED_TIERS];
  }
  if (!a.callbackFilteredTiers?.length) {
    a.callbackFilteredTiers = [...DEFAULT_FILTERED_TIERS];
  }
  if (a.callbackMinBonus == null) {
    a.callbackMinBonus = a.minBonus ?? 1;
  }
  if (a.callbackRate == null) a.callbackRate = 0.02;
  if (a.callbackDivisor == null) a.callbackDivisor = 2;
  ensureActivityManualRules(a);
}

async function load() {
  loading.value = true;
  try {
    const { data } = await callbackApi.getActivity();
    activity.value = data ?? null;
    if (activity.value) {
      normalizeActivityFields(activity.value);
    }
  } catch (e: any) {
    ElMessage.error(e.message || "加载失败");
  } finally {
    loading.value = false;
  }
}

async function initDefaults() {
  saving.value = true;
  try {
    await load();
    if (activity.value) {
      ElMessage.success("已加载默认配置");
      return;
    }
    ElMessage.warning("请刷新页面或联系管理员");
  } finally {
    saving.value = false;
  }
}

async function save() {
  if (!activity.value) return;
  const err = validateActivityForm(activity.value);
  if (err) {
    ElMessage.warning(err);
    return;
  }
  saving.value = true;
  try {
    const { data } = await callbackApi.updateActivity(activity.value);
    activity.value = data;
    if (activity.value) normalizeActivityFields(activity.value);
    ElMessage.success("已保存");
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    saving.value = false;
  }
}

onMounted(load);
</script>

<style scoped>
/* ========== 页面背景 ========== */
.callback-page {
  position: relative;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.35;
  animation: floatBlob 25s ease-in-out infinite;
}

.blob-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -150px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -200px;
  left: -150px;
  animation-delay: -8s;
}

.blob-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 20%;
  animation-delay: -16s;
}

@keyframes floatBlob {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(40px, -40px) scale(1.05); }
  66% { transform: translate(-30px, 30px) scale(0.95); }
}

/* ========== 主卡片 ========== */
.main-card {
  position: relative;
  z-index: 1;
  border-radius: 20px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.08);
  overflow: hidden;
}

.main-card :deep(.el-card__header) {
  padding: 20px 24px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  background: transparent;
}

.main-card :deep(.el-card__body) {
  padding: 24px;
}

/* ========== 卡片头部 ========== */
.card-header-custom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  flex-wrap: wrap;
  gap: 12px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.header-icon-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  border-radius: 12px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.header-icon {
  font-size: 22px;
}

.header-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.header-title {
  font-size: 20px;
  font-weight: 700;
  color: #1a1a2e;
  letter-spacing: 0.5px;
}

.header-subtitle {
  font-size: 13px;
  color: #909399;
}

.header-right {
  display: flex;
  align-items: center;
}

.update-tag {
  font-size: 13px;
  padding: 6px 16px;
  border-radius: 20px;
  background: #f5f7fa;
  border-color: #e4e7ed;
}

.update-tag .el-icon {
  margin-right: 6px;
}

/* ========== 空状态 ========== */
.empty-state {
  padding: 40px 0;
}

.init-btn {
  border-radius: 10px;
  padding: 12px 32px;
  font-weight: 600;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
  transition: all 0.3s ease;
}

.init-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 24px rgba(102, 126, 234, 0.4);
}

.init-btn .el-icon {
  margin-right: 8px;
}

/* ========== 配置表单 ========== */
.config-form {
  max-width: 100%;
}

/* 表单区块 */
.form-section {
  margin-bottom: 24px;
  padding: 16px 20px;
  background: linear-gradient(135deg, #f8fafc 0%, #f1f4f9 100%);
  border-radius: 12px;
  border: 1px solid #e8ecf1;
}

.section-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 16px;
}

.section-icon {
  font-size: 20px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #1a1a2e;
}

/* ========== Tabs ========== */
.config-tabs {
  margin-top: 8px;
}

.config-tabs :deep(.el-tabs__header) {
  border-bottom: 2px solid #e8ecf1;
  margin-bottom: 20px;
}

.config-tabs :deep(.el-tabs__item) {
  font-size: 15px;
  padding: 0 24px;
  height: 48px;
  line-height: 48px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.config-tabs :deep(.el-tabs__item.is-active) {
  color: #667eea;
}

.config-tabs :deep(.el-tabs__active-bar) {
  background: linear-gradient(90deg, #667eea, #764ba2);
  height: 3px;
  border-radius: 2px;
}

.tab-label {
  display: flex;
  align-items: center;
  gap: 6px;
}

.tab-label .el-icon {
  font-size: 16px;
}

/* ========== 表单网格 ========== */
.form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px 24px;
}

.form-grid .full-width {
  grid-column: 1 / -1;
}

.form-grid .el-form-item {
  margin-bottom: 16px;
}

.form-grid .el-form-item :deep(.el-form-item__label) {
  font-weight: 500;
  color: #303133;
  font-size: 14px;
  line-height: 1.5;
  padding-bottom: 4px;
}

/* ========== 输入组 ========== */
.input-group {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px 12px;
}

.modern-input-number {
  width: 160px;
}

.modern-input-number :deep(.el-input__wrapper) {
  border-radius: 10px;
  padding: 2px 12px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
}

.modern-input-number :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #667eea;
}

.modern-input-number :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

.modern-select {
  width: 100%;
  max-width: 520px;
}

.modern-select :deep(.el-input__wrapper) {
  border-radius: 10px;
  padding: 2px 12px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
}

.modern-select :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #667eea;
}

.modern-select :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

.modern-textarea :deep(.el-textarea__inner) {
  border-radius: 10px;
  padding: 12px 16px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
  font-family: inherit;
}

.modern-textarea :deep(.el-textarea__inner:hover) {
  box-shadow: 0 0 0 1px #667eea;
}

.modern-textarea :deep(.el-textarea__inner:focus) {
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

.field-hint {
  color: #909399;
  font-size: 13px;
  line-height: 1.4;
}

/* ========== 规则复选框 ========== */
.rule-checkboxes-wrapper {
  background: #f8fafc;
  border-radius: 10px;
  padding: 12px 16px;
  border: 1px solid #e8ecf1;
  width: 100%;
  max-width: 520px;
}

.rule-checkboxes {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 8px;
}

.rule-checkboxes :deep(.el-checkbox) {
  padding: 4px 0;
  transition: all 0.2s ease;
}

.rule-checkboxes :deep(.el-checkbox:hover) {
  transform: translateX(4px);
}

.rule-checkboxes :deep(.el-checkbox__input.is-checked .el-checkbox__inner) {
  background-color: #667eea;
  border-color: #667eea;
}

.rule-checkboxes :deep(.el-checkbox__inner) {
  border-radius: 4px;
  width: 18px;
  height: 18px;
}

.rule-checkboxes :deep(.el-checkbox__inner::after) {
  height: 10px;
  left: 5px;
  top: 1px;
}

.rule-label {
  font-weight: 500;
  color: #303133;
}

.rule-desc {
  color: #909399;
  font-size: 13px;
}

/* ========== Tab 工具栏 ========== */
.tab-toolbar {
  margin-bottom: 16px;
  padding: 8px 0;
  display: flex;
  gap: 12px;
}

.help-btn {
  font-size: 14px;
  color: #667eea;
  padding: 4px 12px;
  border-radius: 20px;
  background: rgba(102, 126, 234, 0.08);
  transition: all 0.2s ease;
}

.help-btn:hover {
  background: rgba(102, 126, 234, 0.15);
  transform: translateY(-1px);
}

.help-btn .el-icon {
  margin-right: 4px;
}

/* ========== 表单操作按钮 ========== */
.form-actions {
  display: flex;
  gap: 12px;
  margin-top: 24px;
  padding-top: 20px;
  border-top: 1px solid #e8ecf1;
  flex-wrap: wrap;
}

.save-btn {
  padding: 12px 40px;
  border-radius: 10px;
  font-size: 16px;
  font-weight: 600;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.25);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.save-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 24px rgba(102, 126, 234, 0.35);
}

.save-btn .el-icon {
  margin-right: 8px;
  font-size: 18px;
}

.reset-btn {
  padding: 12px 32px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 500;
  transition: all 0.3s ease;
  border: 1px solid #e8ecf1;
}

.reset-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
  border-color: #c0c4cc;
}

.reset-btn .el-icon {
  margin-right: 6px;
}

/* ========== 帮助对话框 ========== */
.modern-dialog :deep(.el-dialog) {
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
}

.modern-dialog :deep(.el-dialog__header) {
  padding: 20px 24px;
  margin: 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-bottom: none;
}

.modern-dialog :deep(.el-dialog__title) {
  color: white;
  font-size: 18px;
  font-weight: 600;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: white;
  font-size: 20px;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close:hover) {
  color: rgba(255, 255, 255, 0.7);
}

.modern-dialog :deep(.el-dialog__body) {
  padding: 24px;
}

.help-content {
  display: flex;
  gap: 16px;
}

.help-icon-big {
  font-size: 40px;
  flex-shrink: 0;
  line-height: 1;
}

.rule-list {
  margin: 0;
  padding: 0;
  list-style: none;
  line-height: 1.8;
}

.rule-list li {
  padding: 4px 0;
  color: #303133;
  font-size: 14px;
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

.rule-list li .rule-dot {
  color: #667eea;
  font-weight: bold;
  flex-shrink: 0;
}

.rule-list li.highlight {
  background: linear-gradient(135deg, #f0f7ff 0%, #e6f0ff 100%);
  border-radius: 8px;
  padding: 8px 12px;
  margin: 4px 0;
  border: 1px solid rgba(102, 126, 234, 0.15);
}

.rule-list li.highlight strong {
  color: #667eea;
  font-size: 16px;
}

/* ========== 响应式 ========== */
@media (max-width: 1024px) {
  .form-grid {
    grid-template-columns: 1fr;
  }

  .form-grid .full-width {
    grid-column: 1;
  }
}

@media (max-width: 768px) {
  .main-card :deep(.el-card__header) {
    padding: 16px;
  }

  .main-card :deep(.el-card__body) {
    padding: 16px;
  }

  .card-header-custom {
    flex-direction: column;
    align-items: flex-start;
  }

  .header-left {
    width: 100%;
  }

  .header-title {
    font-size: 17px;
  }

  .header-right {
    width: 100%;
  }

  .update-tag {
    width: 100%;
    justify-content: center;
  }

  .form-section {
    padding: 12px 16px;
  }

  .input-group {
    flex-direction: column;
    align-items: stretch;
  }

  .modern-input-number {
    width: 100%;
  }

  .modern-select {
    max-width: 100%;
  }

  .rule-checkboxes-wrapper {
    max-width: 100%;
  }

  .form-actions {
    flex-direction: column;
  }

  .save-btn,
  .reset-btn {
    width: 100%;
    justify-content: center;
  }

  .config-tabs :deep(.el-tabs__item) {
    padding: 0 16px;
    font-size: 13px;
  }

  .help-content {
    flex-direction: column;
    align-items: center;
  }

  .help-icon-big {
    font-size: 32px;
  }
}

@media (max-width: 480px) {
  .header-icon-wrapper {
    width: 36px;
    height: 36px;
  }

  .header-icon {
    font-size: 18px;
  }

  .header-title {
    font-size: 15px;
  }

  .header-subtitle {
    font-size: 12px;
  }

  .rule-list li {
    font-size: 13px;
  }

  .rule-checkboxes :deep(.el-checkbox) {
    width: 100%;
  }
}
</style>
export interface ParsedNetworkRequest {
  url: string;
  baseUrl: string;
  path: string;
  method: string;
  token?: string;
  tenantId?: string;
  queryParams: Record<string, string>;
  body?: Record<string, unknown>;
  suggestedName: string;
  suggestedEndpointCode: string;
}

function splitNetworkBlocks(text: string): string[] {
  const normalized = text.replace(/\r\n/g, "\n").trim();
  if (!normalized) return [];

  const blocks: string[] = [];
  let current: string[] = [];

  for (const line of normalized.split("\n")) {
    const trimmed = line.trim();
    const isNewBlock =
      /^curl\s/i.test(trimmed) ||
      /^fetch\s*\(/i.test(trimmed) ||
      (/^https?:\/\//i.test(trimmed) && current.length === 0);

    if (isNewBlock && current.length > 0) {
      blocks.push(current.join("\n"));
      current = [line];
    } else {
      current.push(line);
    }
  }
  if (current.length > 0) blocks.push(current.join("\n"));
  return blocks.length ? blocks : [normalized];
}

function extractBearerToken(headersText: string): string | undefined {
  const patterns = [
    /authorization['"]?\s*:\s*['"]Bearer\s+([^'"\s\\]+)/i,
    /-H\s+['"]authorization:\s*Bearer\s+([^'"\s\\]+)/i,
    /-H\s+['"]Authorization:\s*Bearer\s+([^'"\s\\]+)/i,
    /Bearer\s+([A-Za-z0-9\-._~+/]+=*)/i,
  ];
  for (const re of patterns) {
    const m = headersText.match(re);
    if (m?.[1]) return m[1].trim();
  }
  return undefined;
}

function parseCurlBlock(block: string): ParsedNetworkRequest | null {
  const methodMatch = block.match(/(?:-X|--request)\s+['"]?(\w+)/i);
  let method = (methodMatch?.[1] || "GET").toUpperCase();

  const urlMatch =
    block.match(/curl\s+(?:-[^\s]+\s+)*['"](https?:[^'"]+)['"]/i) ||
    block.match(/curl\s+(?:-[^\s]+\s+)*(https?:[^\s\\]+)/i) ||
    block.match(/--url\s+['"]?(https?:[^\s'"]+)/i);
  if (!urlMatch?.[1]) return null;

  const rawUrl = urlMatch[1].replace(/\\$/g, "").trim();
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return null;
  }

  const dataMatch =
    block.match(/(?:--data-raw|--data|-d)\s+['"]([\s\S]*?)['"]\s*(?:\\|$)/i) ||
    block.match(/(?:--data-raw|--data|-d)\s+(\{[\s\S]*?\})/i);
  let body: Record<string, unknown> | undefined;
  if (dataMatch?.[1]) {
    try {
      body = JSON.parse(dataMatch[1]);
      if (method === "GET") method = "POST";
    } catch {
      body = undefined;
    }
  }

  const token = extractBearerToken(block);
  const queryParams: Record<string, string> = {};
  parsed.searchParams.forEach((v, k) => {
    queryParams[k] = v;
  });

  const tenantId =
    queryParams.tenantId ||
    queryParams.tenant_id ||
    queryParams.tenant ||
    (body?.tenantId as string) ||
    (body?.tenant_id as string);

  const path = parsed.pathname || "/";
  const hostLabel = parsed.hostname.split(".")[0] || parsed.hostname;

  return {
    url: rawUrl,
    baseUrl: parsed.origin,
    path,
    method,
    token,
    tenantId,
    queryParams,
    body,
    suggestedName: hostLabel,
    suggestedEndpointCode: suggestEndpointCode(path),
  };
}

function parseFetchBlock(block: string): ParsedNetworkRequest | null {
  const urlMatch = block.match(/fetch\s*\(\s*['"](https?:[^'"]+)['"]/i);
  if (!urlMatch?.[1]) return null;

  let parsed: URL;
  try {
    parsed = new URL(urlMatch[1]);
  } catch {
    return null;
  }

  const methodMatch = block.match(/method\s*:\s*['"](\w+)['"]/i);
  const method = (methodMatch?.[1] || "GET").toUpperCase();

  let body: Record<string, unknown> | undefined;
  const bodyMatch = block.match(/body\s*:\s*(JSON\.stringify\()?(\{[\s\S]*?\})\)?/i);
  if (bodyMatch?.[2]) {
    try {
      body = JSON.parse(bodyMatch[2]);
    } catch {
      body = undefined;
    }
  }

  const token = extractBearerToken(block);
  const queryParams: Record<string, string> = {};
  parsed.searchParams.forEach((v, k) => {
    queryParams[k] = v;
  });

  const tenantId =
    queryParams.tenantId ||
    queryParams.tenant_id ||
    (body?.tenantId as string);

  return {
    url: urlMatch[1],
    baseUrl: parsed.origin,
    path: parsed.pathname,
    method,
    token,
    tenantId,
    queryParams,
    body,
    suggestedName: parsed.hostname.split(".")[0] || parsed.hostname,
    suggestedEndpointCode: suggestEndpointCode(parsed.pathname),
  };
}

function parseRawUrlBlock(block: string): ParsedNetworkRequest | null {
  const urlMatch = block.match(/(https?:\/\/[^\s'"<>]+)/i);
  if (!urlMatch?.[1]) return null;
  try {
    const parsed = new URL(urlMatch[1]);
    const queryParams: Record<string, string> = {};
    parsed.searchParams.forEach((v, k) => {
      queryParams[k] = v;
    });
    return {
      url: urlMatch[1],
      baseUrl: parsed.origin,
      path: parsed.pathname,
      method: "GET",
      token: extractBearerToken(block),
      tenantId:
        queryParams.tenantId || queryParams.tenant_id || queryParams.tenant,
      queryParams,
      suggestedName: parsed.hostname.split(".")[0] || parsed.hostname,
      suggestedEndpointCode: suggestEndpointCode(parsed.pathname),
    };
  } catch {
    return null;
  }
}

function suggestEndpointCode(path: string): string {
  const parts = path.split("/").filter(Boolean);
  const last = parts[parts.length - 1] || "";
  if (last.includes(".")) return last;
  return last || "vip.list";
}

export function buildRequestParamsTemplate(
  req: ParsedNetworkRequest,
): string {
  const params: Record<string, unknown> = { ...req.queryParams };
  if (req.body) {
    Object.assign(params, req.body);
  }
  for (const key of Object.keys(params)) {
    const v = params[key];
    if (key.toLowerCase().includes("tenant")) {
      params[key] = "{{tenantId}}";
    } else if (key === "page" && typeof v === "number") {
      params[key] = "{{page}}";
    } else if (
      (key === "pageSize" || key === "page_size") &&
      typeof v === "number"
    ) {
      params[key] = "{{pageSize}}";
    }
  }
  if (!params.tenantId && !params.tenant_id) {
    params.tenantId = "{{tenantId}}";
  }
  return JSON.stringify(params, null, 2);
}

export function defaultResponseMapping(code: string): string {
  if (code.includes("vip") || code.includes("member")) {
    return JSON.stringify(
      {
        listPath: "data.list",
        totalPath: "data.total",
        fields: {
          userId: "userId",
          phoneNumber: "phoneNumber",
          historicalPay: "historicalPay",
          historyWithdrawals: "historyWithdrawals",
          historicalReward: "historicalReward",
          vipLevel: "vipLevel",
        },
      },
      null,
      2,
    );
  }
  return JSON.stringify({ listPath: "data.list", fields: {} }, null, 2);
}

export function defaultPaginationConfig(): string {
  return JSON.stringify(
    {
      enabled: true,
      pageField: "page",
      pageSizeField: "pageSize",
      pageSize: 99,
      startPage: 1,
      stopWhenEmpty: true,
    },
    null,
    2,
  );
}

export function parseNetworkPaste(text: string): ParsedNetworkRequest[] {
  const blocks = splitNetworkBlocks(text);
  const results: ParsedNetworkRequest[] = [];
  const seen = new Set<string>();

  for (const block of blocks) {
    let parsed =
      parseCurlBlock(block) ||
      parseFetchBlock(block) ||
      parseRawUrlBlock(block);
    if (!parsed) continue;
    const key = `${parsed.baseUrl}|${parsed.tenantId || ""}|${parsed.token || ""}`;
    if (seen.has(key)) continue;
    seen.add(key);
    results.push(parsed);
  }
  return results;
}

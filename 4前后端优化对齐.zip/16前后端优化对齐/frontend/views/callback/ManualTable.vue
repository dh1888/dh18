<template>
  <el-table :data="rows" stripe max-height="480" empty-text="暂无数据">
    <el-table-column prop="userId" label="会员ID" width="110" />
    <el-table-column prop="phoneNumber" label="手机号" width="130" />
    <el-table-column :label="payLabel" width="110">
      <template #default="{ row }">{{ formatMoney(row.historicalPay) }}</template>
    </el-table-column>
    <el-table-column :label="withdrawLabel" width="110">
      <template #default="{ row }">{{ formatMoney(row.historyWithdrawals) }}</template>
    </el-table-column>
    <el-table-column label="盈亏" width="100">
      <template #default="{ row }">{{ formatMoney(row.profit) }}</template>
    </el-table-column>
    <el-table-column v-if="showTier" prop="tierLevel" label="层级" width="80" />
    <el-table-column v-if="showBonus" label="彩金" width="100">
      <template #default="{ row }">{{ formatMoney(row.bonus) }}</template>
    </el-table-column>
    <el-table-column v-if="showReason" prop="excludeReason" label="剔除原因" min-width="140" />
  </el-table>
</template>

<script setup lang="ts">
import type { ManualRow } from "@api/callback_api";
import { formatMoney } from "./helpers";

withDefaults(
  defineProps<{
    rows: ManualRow[];
    showBonus?: boolean;
    showReason?: boolean;
    showTier?: boolean;
    payLabel?: string;
    withdrawLabel?: string;
  }>(),
  {
    payLabel: "历史充值",
    withdrawLabel: "历史提现",
  },
);
</script>
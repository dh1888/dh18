// api/rateLimitInterceptor.ts
import type { AxiosInstance, InternalAxiosRequestConfig } from 'axios'
import { 
  loginLimiter, 
  registerLimiter, 
  uploadLimiter, 
  listLimiter, 
  defaultLimiter 
} from './rateLimiter'

function routeKey(method: string, url: string): string {
  const path = (url.split('?')[0] || '').replace(/^\/api\/v1/, '')
  return `${method}:${path}`
}

// 根据请求获取对应的限流器
function getLimiterForRequest(method: string, url: string) {
  const key = routeKey(method, url)
  
  switch (key) {
  case 'POST:/auth/login':
    return loginLimiter
  case 'POST:/devices/register':
    return registerLimiter
  case 'POST:/upload/chunk':
    return uploadLimiter
  case 'GET:/screenshots':
  case 'GET:/recordings':
  case 'GET:/activities':
    return listLimiter
  default:
    return defaultLimiter
  }
}

export function setupRateLimitInterceptor(axiosInstance: AxiosInstance) {
  axiosInstance.interceptors.request.use((config: InternalAxiosRequestConfig) => {
    const method = config.method?.toUpperCase() || 'GET'
    const url = config.url || ''
    const limiter = getLimiterForRequest(method, url)
    
    if (!limiter.canExecute()) {
      throw new Error('请求过于频繁，请稍后再试')
    }
    
    return config
  })
}
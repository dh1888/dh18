package handlers

import (
	"os"
	"strings"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
)

type MetaHandler struct{}

func NewMetaHandler() *MetaHandler {
	return &MetaHandler{}
}

func (h *MetaHandler) Modules(c *gin.Context) {
	dmEnabled := strings.EqualFold(strings.TrimSpace(os.Getenv("DOMAIN_MONITOR_ENABLED")), "true")
	cbEnv := strings.ToLower(strings.TrimSpace(os.Getenv("CALLBACK_ENABLED")))
	callbackEnabled := cbEnv != "false" && cbEnv != "0"
	models.Send(c, 200, 0, "success", gin.H{
		"domainMonitor": dmEnabled,
		"callback":      callbackEnabled,
	})
}

// 域名监控远程探针 — 真实网络环境检测（与中心 Proxy 检测独立）
//
// 环境变量:
//   DM_SERVER          监控中心地址
//   DM_NODE_KEY        节点 API Key（手动注册）
//   DM_REGISTER_TOKEN  自动注册令牌（与检测配置中一致，二选一）
//   DM_NODE_NAME       自动注册节点名称
//   DM_NODE_COUNTRY    国家代码，如 BR / US / JP
//   DM_NODE_CITY       城市
//   HTTP_PROXY         探针本地 HTTP 代理（任务级代理优先）
package main

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/shirou/gopsutil/v3/cpu"
	"github.com/shirou/gopsutil/v3/mem"

	"enterprise-agent/backend/internal/domainmonitor/probechecks"
)

const probeVersion = "2.0.0"

type checkSpec struct {
	Type         string   `json:"type"`
	URL          string   `json:"url,omitempty"`
	UseProxy     bool     `json:"useProxy,omitempty"`
	HttpProxyURL string   `json:"httpProxyUrl,omitempty"`
	FastDNS      bool     `json:"fastDns,omitempty"`
	Keywords     []string `json:"keywords,omitempty"`
}

type task struct {
	TaskID  string      `json:"taskId"`
	Domain  string      `json:"domain"`
	DomainID string     `json:"domainId"`
	Checks  []checkSpec `json:"checks"`
}

type apiResp struct {
	Code int             `json:"code"`
	Data json.RawMessage `json:"data"`
}

func main() {
	server := strings.TrimRight(os.Getenv("DM_SERVER"), "/")
	if server == "" {
		fmt.Println("需要环境变量 DM_SERVER")
		os.Exit(1)
	}
	key := strings.TrimSpace(os.Getenv("DM_NODE_KEY"))
	if key == "" {
		var err error
		key, err = autoRegister(server)
		if err != nil {
			fmt.Println("register:", err)
			os.Exit(1)
		}
		fmt.Println("registered, node key saved to env for this session")
	}
	base := server + "/api/v1/domain-monitor/probe"
	client := &http.Client{Timeout: 90 * time.Second}
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	run := func() {
		ctx, cancel := context.WithTimeout(context.Background(), 85*time.Second)
		defer cancel()
		if err := heartbeat(ctx, client, base, key); err != nil {
			fmt.Println("heartbeat:", err)
			return
		}
		tasks, err := fetchTasks(ctx, client, base, key)
		if err != nil {
			fmt.Println("tasks:", err)
			return
		}
		for _, t := range tasks {
			if err := runTask(ctx, client, base, key, t); err != nil {
				fmt.Println("task", t.Domain, err)
			}
		}
	}

	run()
	for range ticker.C {
		run()
	}
}

func autoRegister(server string) (string, error) {
	token := strings.TrimSpace(os.Getenv("DM_REGISTER_TOKEN"))
	name := strings.TrimSpace(os.Getenv("DM_NODE_NAME"))
	if token == "" || name == "" {
		return "", fmt.Errorf("需要 DM_NODE_KEY 或 DM_REGISTER_TOKEN+DM_NODE_NAME")
	}
	body := map[string]string{
		"registrationToken": token,
		"nodeName":          name,
		"country":           envOr("DM_NODE_COUNTRY", "CN"),
		"city":              envOr("DM_NODE_CITY", ""),
		"publicIp":          fetchPublicIP(),
		"version":           probeVersion,
	}
	b, _ := json.Marshal(body)
	resp, err := http.Post(server+"/api/v1/domain-monitor/probe/register", "application/json", bytes.NewReader(b))
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	var wrap apiResp
	if err := json.NewDecoder(resp.Body).Decode(&wrap); err != nil {
		return "", err
	}
	var data struct {
		APIKey string `json:"apiKey"`
	}
	if err := json.Unmarshal(wrap.Data, &data); err != nil {
		return "", err
	}
	if data.APIKey == "" {
		return "", fmt.Errorf("register failed")
	}
	return data.APIKey, nil
}

func heartbeat(ctx context.Context, client *http.Client, base, key string) error {
	cpuPct, _ := cpu.Percent(0, false)
	memInfo, _ := mem.VirtualMemory()
	cpuVal := 0.0
	if len(cpuPct) > 0 {
		cpuVal = cpuPct[0]
	}
	memVal := 0.0
	if memInfo != nil {
		memVal = memInfo.UsedPercent
	}
	body := map[string]interface{}{
		"version":       probeVersion,
		"publicIp":      fetchPublicIP(),
		"cpuPercent":    cpuVal,
		"memoryPercent": memVal,
	}
	b, _ := json.Marshal(body)
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, base+"/heartbeat", bytes.NewReader(b))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-DM-Node-Key", key)
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return checkOK(resp)
}

func fetchTasks(ctx context.Context, client *http.Client, base, key string) ([]task, error) {
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, base+"/tasks", nil)
	req.Header.Set("X-DM-Node-Key", key)
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if err := checkOK(resp); err != nil {
		return nil, err
	}
	var wrap apiResp
	if err := json.NewDecoder(resp.Body).Decode(&wrap); err != nil {
		return nil, err
	}
	var items []task
	if err := json.Unmarshal(wrap.Data, &items); err != nil {
		return nil, err
	}
	return items, nil
}

func runTask(ctx context.Context, client *http.Client, base, key string, t task) error {
	var results []map[string]interface{}
	var screenshotB64 string

	for _, spec := range t.Checks {
		if spec.Type == "screenshot" {
			shot, st, detail := runScreenshot(ctx, t.Domain, spec)
			results = append(results, map[string]interface{}{
				"checkType":  "screenshot",
				"status":     st,
				"durationMs": 0,
				"rawDetail":  detail,
			})
			if shot != "" {
				screenshotB64 = shot
			}
			continue
		}
		ps := probechecks.Spec{
			Type:         spec.Type,
			URL:          spec.URL,
			UseProxy:     spec.UseProxy,
			HttpProxyURL: resolveProxy(spec),
			FastDNS:      spec.FastDNS,
			Keywords:     spec.Keywords,
		}
		if ps.Type == "http" && ps.URL == "" {
			ps.URL = "https://" + t.Domain
		}
		out := probechecks.Run(ctx, t.Domain, ps)
		results = append(results, probechecks.ToMap(out))
	}

	body := map[string]interface{}{
		"taskId":  t.TaskID,
		"results": results,
	}
	if screenshotB64 != "" {
		body["screenshotBase64"] = screenshotB64
	}
	b, _ := json.Marshal(body)
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, base+"/results", bytes.NewReader(b))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-DM-Node-Key", key)
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return checkOK(resp)
}

func runScreenshot(ctx context.Context, domain string, spec checkSpec) (b64, status, detail string) {
	target := spec.URL
	if target == "" {
		target = "https://" + domain
	}
	proxy := resolveProxy(spec)
	script := locateScreenshotScript()
	if script == "" {
		return "", probechecks.StatusError, mustJSON(map[string]string{
			"error": "playwright script not found; install Node.js + playwright",
			"url":   target,
		})
	}
	args := []string{script, "--url", target, "--output", "-"}
	if proxy != "" {
		args = append(args, "--proxy", proxy)
	}
	cmd := exec.CommandContext(ctx, "node", args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		return "", probechecks.StatusError, mustJSON(map[string]string{
			"error": err.Error() + ": " + stderr.String(),
			"url":   target,
			"proxy": proxy,
		})
	}
	data := stdout.Bytes()
	if len(data) == 0 {
		return "", probechecks.StatusError, mustJSON(map[string]string{"error": "empty screenshot"})
	}
	return base64.StdEncoding.EncodeToString(data), probechecks.StatusOK, mustJSON(map[string]interface{}{
		"url": target, "proxy": proxy, "engine": "playwright",
	})
}

func locateScreenshotScript() string {
	if p := strings.TrimSpace(os.Getenv("DM_SCREENSHOT_SCRIPT")); p != "" {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	_, file, _, _ := runtime.Caller(0)
	candidates := []string{
		filepath.Join(filepath.Dir(file), "scripts", "screenshot.mjs"),
		filepath.Join(".", "cmd", "dm-probe", "scripts", "screenshot.mjs"),
	}
	for _, c := range candidates {
		if _, err := os.Stat(c); err == nil {
			return c
		}
	}
	return ""
}

func resolveProxy(spec checkSpec) string {
	if spec.UseProxy && strings.TrimSpace(spec.HttpProxyURL) != "" {
		return strings.TrimSpace(spec.HttpProxyURL)
	}
	if p := strings.TrimSpace(os.Getenv("HTTP_PROXY")); p != "" {
		return p
	}
	return strings.TrimSpace(os.Getenv("HTTPS_PROXY"))
}

func fetchPublicIP() string {
	client := &http.Client{Timeout: 5 * time.Second}
	resp, err := client.Get("https://api.ipify.org?format=text")
	if err != nil {
		return ""
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	return strings.TrimSpace(string(b))
}

func envOr(key, def string) string {
	if v := strings.TrimSpace(os.Getenv(key)); v != "" {
		return v
	}
	return def
}

func checkOK(resp *http.Response) error {
	if resp.StatusCode >= 300 {
		b, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("http %d: %s", resp.StatusCode, string(b))
	}
	return nil
}

func mustJSON(v interface{}) string {
	b, _ := json.Marshal(v)
	return string(b)
}

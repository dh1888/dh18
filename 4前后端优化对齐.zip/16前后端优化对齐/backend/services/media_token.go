package services

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
)

const (
	mediaTokenKeyPrefix = "media_access:"
	mediaTokenTTL       = 15 * time.Minute
)

var (
	ErrMediaTokenInvalid = errors.New("invalid media token")
	ErrMediaTokenExpired = errors.New("media token expired")
)

// MediaAccessGrant 短期媒体访问授权（用于 video/img 等无法带 Authorization 的场景）
type MediaAccessGrant struct {
	UserID       string `json:"userId"`
	Username     string `json:"username"`
	ResourceType string `json:"resourceType"`
	ResourceID   string `json:"resourceId"`
	Action       string `json:"action"`
}

type MediaTokenService struct {
	redis *redis.Client
}

func NewMediaTokenService(redisClient *redis.Client) *MediaTokenService {
	return &MediaTokenService{redis: redisClient}
}

func (s *MediaTokenService) Issue(ctx context.Context, grant MediaAccessGrant) (string, time.Duration, error) {
	if grant.UserID == "" || grant.ResourceType == "" || grant.ResourceID == "" || grant.Action == "" {
		return "", 0, fmt.Errorf("invalid media grant")
	}

	tokenBytes := make([]byte, 24)
	if _, err := rand.Read(tokenBytes); err != nil {
		return "", 0, err
	}
	token := hex.EncodeToString(tokenBytes)

	payload, err := json.Marshal(grant)
	if err != nil {
		return "", 0, err
	}

	if s.redis != nil {
		if err := s.redis.Set(ctx, mediaTokenKeyPrefix+token, payload, mediaTokenTTL).Err(); err != nil {
			return "", 0, err
		}
		return token, mediaTokenTTL, nil
	}

	return "", 0, fmt.Errorf("media token store unavailable")
}

func (s *MediaTokenService) Validate(ctx context.Context, token, resourceType, resourceID, action string) (*MediaAccessGrant, error) {
	token = trimToken(token)
	if token == "" || s.redis == nil {
		return nil, ErrMediaTokenInvalid
	}

	raw, err := s.redis.Get(ctx, mediaTokenKeyPrefix+token).Bytes()
	if err != nil {
		if err == redis.Nil {
			return nil, ErrMediaTokenExpired
		}
		return nil, err
	}

	var grant MediaAccessGrant
	if err := json.Unmarshal(raw, &grant); err != nil {
		return nil, ErrMediaTokenInvalid
	}

	if grant.ResourceType != resourceType || grant.ResourceID != resourceID || grant.Action != action {
		return nil, ErrMediaTokenInvalid
	}

	return &grant, nil
}

func trimToken(token string) string {
	for len(token) > 0 && (token[0] == ' ' || token[0] == '\t') {
		token = token[1:]
	}
	for len(token) > 0 {
		last := token[len(token)-1]
		if last == ' ' || last == '\t' {
			token = token[:len(token)-1]
			continue
		}
		break
	}
	return token
}

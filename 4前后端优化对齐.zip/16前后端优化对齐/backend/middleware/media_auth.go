package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// MediaAccessAuth 支持 Bearer JWT 或短期 mediaToken（用于 video 流等无法带 Header 的场景）
func MediaAccessAuth(redisClient *redis.Client, resourceType, action, permission string) gin.HandlerFunc {
	svc := services.NewMediaTokenService(redisClient)

	return func(c *gin.Context) {
		resourceID := strings.TrimSpace(c.Param("id"))
		if mediaToken := strings.TrimSpace(c.Query("mediaToken")); mediaToken != "" {
			grant, err := svc.Validate(c.Request.Context(), mediaToken, resourceType, resourceID, action)
			if err != nil {
				if err == services.ErrMediaTokenExpired {
					models.SendError(c, 401, 1002, "Media token expired")
				} else {
					models.SendError(c, 401, 1002, "Invalid media token")
				}
				c.Abort()
				return
			}
			c.Set("userID", grant.UserID)
			c.Set("username", grant.Username)
			c.Next()
			return
		}

		Auth(redisClient)(c)
		if c.IsAborted() {
			return
		}
		RequirePermission(permission)(c)
	}
}

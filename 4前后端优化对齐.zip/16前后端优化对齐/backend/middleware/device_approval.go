package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// RequireApprovedDevice 要求设备已通过管理员审核
func RequireApprovedDevice(deviceRepo *services.DeviceRepository) gin.HandlerFunc {
	return func(c *gin.Context) {
		deviceID := strings.TrimSpace(c.GetString("deviceID"))
		if deviceID == "" {
			deviceID = strings.TrimSpace(c.GetString("deviceId"))
		}
		if deviceID == "" {
			models.SendError(c, 401, 1002, "Device not authenticated")
			c.Abort()
			return
		}

		id, err := uuid.Parse(deviceID)
		if err != nil {
			models.SendError(c, 400, 1001, "Invalid device ID")
			c.Abort()
			return
		}

		device, err := deviceRepo.Get(c.Request.Context(), id)
		if err != nil || device == nil {
			models.SendError(c, 404, 2001, "Device not found")
			c.Abort()
			return
		}

		switch strings.ToLower(strings.TrimSpace(device.Status)) {
		case "approved":
			c.Next()
		case "rejected":
			models.SendError(c, 403, 1003, "Device registration rejected")
			c.Abort()
		default:
			models.SendError(c, 403, 1003, "Device pending admin approval")
			c.Abort()
		}
	}
}

SQL files in this folder are reference/historical scripts.
Runtime schema is applied automatically by:
- backend/services/repositories.go (core tables)
- backend/internal/domainmonitor/schema_bootstrap.go (domain monitor)
- backend/internal/callback/schema.go (callback module)

Do not rely on manually running these files unless you know you need a one-off data migration.

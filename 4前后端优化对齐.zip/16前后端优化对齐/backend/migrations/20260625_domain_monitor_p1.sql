-- Domain Monitor P1：WHOIS / 内容哈希 / 趋势（仅新增列，不修改现有业务表）
-- 执行：psql -U postgres -d enterprise_agent -f backend/migrations/20260625_domain_monitor_p1.sql

ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_whois BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_content BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS content_url TEXT DEFAULT '';
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS content_hash_baseline VARCHAR(64) DEFAULT '';
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS content_keywords JSONB NOT NULL DEFAULT '[]';
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_whois_status VARCHAR(16) NOT NULL DEFAULT 'unknown';
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_content_status VARCHAR(16) NOT NULL DEFAULT 'unknown';
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS whois_expire_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_dm_domains_whois_expire ON dm_domains(whois_expire_at);

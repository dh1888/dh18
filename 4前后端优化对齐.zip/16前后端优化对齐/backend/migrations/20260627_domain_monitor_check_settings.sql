-- Domain Monitor: 响应时间字段 + 检测配置表
ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_http_duration_ms INT NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS dm_settings (
    key VARCHAR(64) PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO dm_settings (key, value) VALUES ('default_check_interval', '300')
ON CONFLICT (key) DO NOTHING;
INSERT INTO dm_settings (key, value) VALUES ('scheduler_tick_seconds', '60')
ON CONFLICT (key) DO NOTHING;

-- =============================================================================
-- 运营回访管理模块（callback）— 第二阶段 DDL
-- 说明：仅新增表/索引/触发器/权限种子，不修改任何已有表结构
-- 执行：psql -U postgres -d enterprise_agent -f backend/migrations/20260628_callback_module.sql
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- -----------------------------------------------------------------------------
-- 1. callback_platform — 第三方平台配置
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS callback_platform (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(128) NOT NULL,
    base_url        VARCHAR(512) NOT NULL,          -- 如 https://api.xxx.com（不含末尾 /）
    tenant_id       VARCHAR(64)  NOT NULL,          -- 如 7457478，调用时自动注入
    token_enc       TEXT         NOT NULL,          -- AES 加密存储，禁止明文
    enabled         BOOLEAN      NOT NULL DEFAULT TRUE,
    remark          TEXT,
    created_by      UUID         REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    deleted_at      TIMESTAMPTZ                         -- 软删除
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_callback_platform_name_active
    ON callback_platform (name)
    WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_callback_platform_enabled
    ON callback_platform (enabled)
    WHERE deleted_at IS NULL;

COMMENT ON TABLE  callback_platform IS '运营回访：第三方平台配置';
COMMENT ON COLUMN callback_platform.token_enc IS 'Bearer Token 加密密文，禁止明文存储/返回';

-- -----------------------------------------------------------------------------
-- 2. callback_api_endpoint — 第三方接口配置（路径/参数/字段映射，不写死在代码）
--    预留：历史充值、历史提现、优惠记录、会员列表等后续接口
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS callback_api_endpoint (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_id             UUID         REFERENCES callback_platform(id) ON DELETE CASCADE,
    code                    VARCHAR(64)  NOT NULL,   -- 业务编码：vip.list / recharge.history 等
    name                    VARCHAR(128) NOT NULL,   -- 显示名称
    path                    VARCHAR(512) NOT NULL,   -- 相对路径：/api/backend/trpc/vip.list
    http_method             VARCHAR(16)  NOT NULL DEFAULT 'GET',
    -- 请求参数模板（JSON）；支持占位符 {{tenantId}} {{page}} {{pageSize}} {{dateFrom}} {{dateTo}}
    request_params_template JSONB        NOT NULL DEFAULT '{}',
    -- 响应字段映射（JSON），示例见文件末尾注释
    response_mapping        JSONB        NOT NULL DEFAULT '{}',
    -- 分页配置（JSON）：enabled, pageField, pageSizeField, pageSize, listPath, totalPath, hasMorePath
    pagination_config       JSONB        NOT NULL DEFAULT '{}',
    enabled                 BOOLEAN      NOT NULL DEFAULT TRUE,
    sort_order              INT          NOT NULL DEFAULT 0,
    remark                  TEXT,
    created_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ
);

-- platform_id 为 NULL 表示全局默认模板；同一平台下 code 唯一
CREATE UNIQUE INDEX IF NOT EXISTS idx_callback_api_endpoint_platform_code
    ON callback_api_endpoint (platform_id, code)
    WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS idx_callback_api_endpoint_global_code
    ON callback_api_endpoint (code)
    WHERE platform_id IS NULL AND deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_callback_api_endpoint_platform
    ON callback_api_endpoint (platform_id)
    WHERE deleted_at IS NULL;

COMMENT ON TABLE callback_api_endpoint IS '运营回访：第三方 API 路径/参数/字段映射配置（可扩展）';

-- -----------------------------------------------------------------------------
-- 3. callback_activity — 活动配置（单活动模式，全表仅允许一行）
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS callback_activity (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    days                INT            NOT NULL DEFAULT 7,
    rate                NUMERIC(10, 6) NOT NULL DEFAULT 0.02,    -- 彩金比例
    divisor             INT            NOT NULL DEFAULT 10,       -- 除数
    min_bonus           NUMERIC(18, 2) NOT NULL DEFAULT 1.00,     -- 最低彩金
    max_bonus           NUMERIC(18, 2) NOT NULL DEFAULT 50.00,    -- 最高彩金
    exclude_rewarded    BOOLEAN        NOT NULL DEFAULT TRUE,     -- historicalReward>0 时剔除
    health_min          NUMERIC(18, 2) NOT NULL DEFAULT 20000.00, -- 健康值下限
    health_max          NUMERIC(18, 2) NOT NULL DEFAULT 30000.00, -- 健康值上限
    updated_by          UUID           REFERENCES users(id) ON DELETE SET NULL,
    created_at          TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

-- 单活动：只允许存在一条配置记录
CREATE UNIQUE INDEX IF NOT EXISTS idx_callback_activity_singleton
    ON callback_activity ((TRUE));

COMMENT ON TABLE callback_activity IS '运营回访：当前生效的活动配置（全局单条）';

-- 插入默认活动配置（若不存在）
INSERT INTO callback_activity (
    days, rate, divisor, min_bonus, max_bonus,
    exclude_rewarded, health_min, health_max
)
SELECT 7, 0.02, 10, 1, 50, TRUE, 20000, 30000
WHERE NOT EXISTS (SELECT 1 FROM callback_activity);

-- -----------------------------------------------------------------------------
-- 4. callback_task — 生成任务 / 历史记录
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS callback_task (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_id         UUID           NOT NULL REFERENCES callback_platform(id),
    date_from           DATE           NOT NULL,
    date_to             DATE           NOT NULL,
    activity_snapshot   JSONB          NOT NULL DEFAULT '{}',  -- 执行时活动配置快照
    status              VARCHAR(32)    NOT NULL DEFAULT 'pending',
    -- pending / running / completed / failed
    member_count        INT            NOT NULL DEFAULT 0,     -- 符合回访人数
    total_bonus         NUMERIC(18, 2) NOT NULL DEFAULT 0,     -- 总彩金
    health_level        VARCHAR(16),                           -- low / normal / high
    error_message       TEXT,
    created_by          UUID           REFERENCES users(id) ON DELETE SET NULL,
    started_at          TIMESTAMPTZ,
    finished_at         TIMESTAMPTZ,
    created_at          TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_callback_task_date_range CHECK (date_to >= date_from),
    CONSTRAINT chk_callback_task_status CHECK (
        status IN ('pending', 'running', 'completed', 'failed')
    ),
    CONSTRAINT chk_callback_task_health CHECK (
        health_level IS NULL OR health_level IN ('low', 'normal', 'high')
    )
);

CREATE INDEX IF NOT EXISTS idx_callback_task_platform
    ON callback_task (platform_id);

CREATE INDEX IF NOT EXISTS idx_callback_task_created_at
    ON callback_task (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_callback_task_status
    ON callback_task (status);

COMMENT ON TABLE callback_task IS '运营回访：名单生成任务及历史';

-- -----------------------------------------------------------------------------
-- 5. callback_result — 任务结果明细
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS callback_result (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    task_id                 UUID           NOT NULL REFERENCES callback_task(id) ON DELETE CASCADE,
    user_id                 BIGINT         NOT NULL,            -- 第三方会员 ID
    phone_number            VARCHAR(32),
    vip_level               INT            NOT NULL DEFAULT 0,
    historical_pay          NUMERIC(18, 2) NOT NULL DEFAULT 0,  -- 历史充值
    history_withdrawals     NUMERIC(18, 2) NOT NULL DEFAULT 0,  -- 历史提现
    historical_reward       NUMERIC(18, 2) NOT NULL DEFAULT 0,  -- 历史优惠（审计/过滤）
    profit                  NUMERIC(18, 2) NOT NULL DEFAULT 0,  -- pay - withdrawals
    bonus                   NUMERIC(18, 2) NOT NULL DEFAULT 0,  -- 彩金
    raw_data                JSONB,                              -- 第三方原始字段快照（可选）
    created_at              TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_callback_result_task_user UNIQUE (task_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_callback_result_task
    ON callback_result (task_id);

CREATE INDEX IF NOT EXISTS idx_callback_result_user
    ON callback_result (user_id);

CREATE INDEX IF NOT EXISTS idx_callback_result_bonus
    ON callback_result (bonus DESC);

CREATE INDEX IF NOT EXISTS idx_callback_result_profit
    ON callback_result (profit);

COMMENT ON TABLE callback_result IS '运营回访：任务筛选后的会员明细';
COMMENT ON COLUMN callback_result.profit IS 'historical_pay - history_withdrawals；profit<0 表示会员盈利';

-- -----------------------------------------------------------------------------
-- 6. callback_request_log — 第三方请求日志（Token 脱敏，禁止存明文）
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS callback_request_log (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_id         UUID         REFERENCES callback_platform(id) ON DELETE SET NULL,
    task_id             UUID         REFERENCES callback_task(id) ON DELETE SET NULL,
    endpoint_code       VARCHAR(64),              -- 如 vip.list
    request_url         TEXT         NOT NULL,     -- 已脱敏 URL（不含 Token）
    request_params      JSONB        NOT NULL DEFAULT '{}',
    response_status     INT,
    response_body       TEXT,                      -- 截断保存，便于排查
    duration_ms         INT          NOT NULL DEFAULT 0,
    error_message       TEXT,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_callback_request_log_platform
    ON callback_request_log (platform_id);

CREATE INDEX IF NOT EXISTS idx_callback_request_log_task
    ON callback_request_log (task_id);

CREATE INDEX IF NOT EXISTS idx_callback_request_log_created
    ON callback_request_log (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_callback_request_log_endpoint
    ON callback_request_log (endpoint_code);

COMMENT ON TABLE callback_request_log IS '运营回访：第三方 API 请求日志（Token 脱敏）';

-- -----------------------------------------------------------------------------
-- updated_at 自动维护（仅 callback 模块新表）
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION callback_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_callback_platform_updated ON callback_platform;
CREATE TRIGGER trg_callback_platform_updated
    BEFORE UPDATE ON callback_platform
    FOR EACH ROW EXECUTE FUNCTION callback_set_updated_at();

DROP TRIGGER IF EXISTS trg_callback_api_endpoint_updated ON callback_api_endpoint;
CREATE TRIGGER trg_callback_api_endpoint_updated
    BEFORE UPDATE ON callback_api_endpoint
    FOR EACH ROW EXECUTE FUNCTION callback_set_updated_at();

DROP TRIGGER IF EXISTS trg_callback_activity_updated ON callback_activity;
CREATE TRIGGER trg_callback_activity_updated
    BEFORE UPDATE ON callback_activity
    FOR EACH ROW EXECUTE FUNCTION callback_set_updated_at();

DROP TRIGGER IF EXISTS trg_callback_task_updated ON callback_task;
CREATE TRIGGER trg_callback_task_updated
    BEFORE UPDATE ON callback_task
    FOR EACH ROW EXECUTE FUNCTION callback_set_updated_at();

-- -----------------------------------------------------------------------------
-- 权限种子：为「管理员」角色追加 callback 权限（不修改 roles 表结构）
-- 权限码：callback:view / callback:manage / callback:settings
-- -----------------------------------------------------------------------------
UPDATE roles
SET permissions = (
    SELECT COALESCE(jsonb_agg(DISTINCT val), '[]'::jsonb)
    FROM (
        SELECT jsonb_array_elements_text(permissions) AS val
        FROM roles
        WHERE name = '管理员'
        UNION ALL
        SELECT unnest(ARRAY[
            'callback:view',
            'callback:manage',
            'callback:settings'
        ])
    ) t
),
updated_at = NOW()
WHERE name = '管理员';

-- -----------------------------------------------------------------------------
-- 全局默认 API 配置模板：vip.list（platform_id=NULL，创建平台时可复制）
-- -----------------------------------------------------------------------------
INSERT INTO callback_api_endpoint (
    platform_id,
    code,
    name,
    path,
    http_method,
    request_params_template,
    response_mapping,
    pagination_config,
    enabled,
    sort_order,
    remark
)
SELECT
    NULL,
    'vip.list',
    'VIP会员列表',
    '/api/backend/trpc/vip.list',
    'GET',
    '{
        "tenantId": "{{tenantId}}",
        "page": 1,
        "pageSize": 99
    }'::jsonb,
    '{
        "listPath": "data.list",
        "totalPath": "data.total",
        "fields": {
            "userId": "userId",
            "phoneNumber": "phoneNumber",
            "historicalPay": "historicalPay",
            "historyWithdrawals": "historyWithdrawals",
            "historicalReward": "historicalReward",
            "vipLevel": "vipLevel"
        }
    }'::jsonb,
    '{
        "enabled": true,
        "pageField": "page",
        "pageSizeField": "pageSize",
        "pageSize": 99,
        "startPage": 1,
        "stopWhenEmpty": true
    }'::jsonb,
    TRUE,
    10,
    '默认会员列表接口；tenantId 由平台配置自动替换'
WHERE NOT EXISTS (
    SELECT 1 FROM callback_api_endpoint
    WHERE platform_id IS NULL AND code = 'vip.list' AND deleted_at IS NULL
);

-- =============================================================================
-- JSON 配置字段说明（供第三阶段开发参考，非 DDL）
--
-- request_params_template 占位符：
--   {{tenantId}} {{page}} {{pageSize}} {{dateFrom}} {{dateTo}}
--
-- response_mapping 示例：
--   listPath   — 列表 JSON 路径
--   totalPath  — 总数 JSON 路径（可选）
--   fields     — 第三方字段 → 内部字段映射
--
-- pagination_config 示例：
--   enabled, pageField, pageSizeField, pageSize, startPage, stopWhenEmpty
--
-- 后续可新增 endpoint code（示例，本迁移不插入）：
--   recharge.history / withdrawal.history / reward.history / member.list
-- =============================================================================

-- 活动配置：手动回访派发表字段（打码倍数、APP端备注、后台备注）
ALTER TABLE callback_activity
    ADD COLUMN IF NOT EXISTS wagering_multiplier NUMERIC(10, 2) NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS app_remark TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS backend_remark TEXT NOT NULL DEFAULT '';

COMMENT ON COLUMN callback_activity.wagering_multiplier IS '打码倍数（手动回访派发表）';
COMMENT ON COLUMN callback_activity.app_remark IS 'APP端备注（手动回访派发表）';
COMMENT ON COLUMN callback_activity.backend_remark IS '后台备注（手动回访派发表）';

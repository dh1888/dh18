package callback

import "math"

func CalcProfit(historicalPay, historyWithdrawals float64) float64 {
	return historicalPay - historyWithdrawals
}

func ShouldIncludeMember(profit, historicalReward float64, excludeRewarded bool) bool {
	if profit >= 0 {
		return false
	}
	if excludeRewarded && historicalReward > 0 {
		return false
	}
	return true
}

func CalcCallbackManualBonus(profit, rate float64, divisor int, callbackMinBonus float64) float64 {
	if callbackMinBonus < 0 {
		callbackMinBonus = 0
	}
	if divisor <= 0 {
		divisor = 1
	}
	if profit < 0 {
		return 0
	}
	bonus := profit * rate / float64(divisor)
	if bonus < callbackMinBonus {
		bonus = callbackMinBonus
	}
	return roundMoney(bonus)
}

func CalcBonus(profit, rate float64, divisor int, minBonus, maxBonus float64) float64 {
	if divisor <= 0 {
		divisor = 1
	}
	bonus := math.Abs(profit) * rate / float64(divisor)
	if bonus < minBonus {
		bonus = minBonus
	}
	if bonus > maxBonus {
		bonus = maxBonus
	}
	return roundMoney(bonus)
}

func CalcHealthLevel(totalBonus, healthMin, healthMax float64) string {
	if totalBonus < healthMin {
		return HealthLevelLow
	}
	if totalBonus > healthMax {
		return HealthLevelHigh
	}
	return HealthLevelNormal
}

func roundMoney(v float64) float64 {
	return math.Round(v*100) / 100
}

package callback

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
)

type TestPlatformInput struct {
	PlatformID   uuid.UUID
	EndpointCode string
}

type TaskEstimate struct {
	MemberCount   int     `json:"memberCount"`
	TotalBonus    float64 `json:"totalBonus"`
	HealthLevel   string  `json:"healthLevel"`
	FetchedCount  int     `json:"fetchedCount"`
	DateFrom      string  `json:"dateFrom"`
	DateTo        string  `json:"dateTo"`
	PlatformID    string  `json:"platformId"`
	EndpointCode  string  `json:"endpointCode"`
}

func (s *Service) TestPlatformConnection(ctx context.Context, in TestPlatformInput) (*ConnectionTestResult, error) {
	platform, err := s.repo.GetPlatform(ctx, in.PlatformID)
	if err != nil {
		return nil, err
	}
	if platform == nil {
		return nil, fmt.Errorf("platform not found")
	}

	endpointCode := strings.TrimSpace(in.EndpointCode)
	if endpointCode == "" {
		endpointCode = EndpointCodeVIPList
	}

	endpoint, err := s.GetEndpointByCode(ctx, platform.ID, endpointCode)
	if err != nil {
		return nil, err
	}
	if endpoint == nil {
		return nil, fmt.Errorf("endpoint %q not configured", endpointCode)
	}

	tokenPlain, err := s.crypto.DecryptToken(platform.TokenEnc)
	if err != nil {
		return nil, fmt.Errorf("decrypt platform token: %w", err)
	}

	now := time.Now()
	return s.client.TestConnection(ctx, FetchRequest{
		Platform:   platform,
		Endpoint:   endpoint,
		DateFrom:   now,
		DateTo:     now,
		TokenPlain: tokenPlain,
	})
}

func (s *Service) EstimateTask(ctx context.Context, in GenerateTaskInput) (*TaskEstimate, error) {
	activity, dateFrom, dateTo, err := s.resolveTaskDates(ctx, in)
	if err != nil {
		return nil, err
	}
	in.DateFrom = dateFrom
	in.DateTo = dateTo

	platform, err := s.repo.GetEnabledPlatform(ctx, in.PlatformID)
	if err != nil {
		return nil, err
	}
	if platform == nil {
		return nil, fmt.Errorf("platform not found or disabled")
	}

	endpointCode := strings.TrimSpace(in.EndpointCode)
	if endpointCode == "" {
		endpointCode = EndpointCodeVIPList
	}

	endpoint, err := s.GetEndpointByCode(ctx, platform.ID, endpointCode)
	if err != nil {
		return nil, err
	}
	if endpoint == nil {
		return nil, fmt.Errorf("endpoint %q not configured", endpointCode)
	}
	if err := endpoint.Row.ValidateMemberMapping(); err != nil {
		return nil, err
	}

	tokenPlain, err := s.crypto.DecryptToken(platform.TokenEnc)
	if err != nil {
		return nil, fmt.Errorf("decrypt platform token: %w", err)
	}

	members, err := s.client.FetchMembers(ctx, FetchRequest{
		Platform:   platform,
		Endpoint:   endpoint,
		DateFrom:   in.DateFrom,
		DateTo:     in.DateTo,
		TokenPlain: tokenPlain,
	})
	if err != nil {
		return nil, err
	}

	snapshot := ActivitySnapshotFromConfig(activity)
	results, totalBonus := s.buildResults(uuid.Nil, members, snapshot)
	health := CalcHealthLevel(totalBonus, snapshot.HealthMin, snapshot.HealthMax)

	return &TaskEstimate{
		MemberCount:  len(results),
		TotalBonus:   totalBonus,
		HealthLevel:  health,
		FetchedCount: len(members),
		DateFrom:     in.DateFrom.Format("2006-01-02"),
		DateTo:       in.DateTo.Format("2006-01-02"),
		PlatformID:   platform.ID.String(),
		EndpointCode: endpointCode,
	}, nil
}

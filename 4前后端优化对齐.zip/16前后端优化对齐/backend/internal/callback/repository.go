package callback

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

const defaultResultBatchSize = 500

type Repository struct {
	db *gorm.DB
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

func (r *Repository) DB() *gorm.DB { return r.db }

func (r *Repository) conn(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

// WithTx 在事务中执行 fn；失败自动回滚。
func (r *Repository) WithTx(ctx context.Context, fn func(tx *Repository) error) error {
	return r.conn(ctx).Transaction(func(tx *gorm.DB) error {
		return fn(&Repository{db: tx})
	})
}

// ParsedEndpoint 已解析 JSON 配置的接口定义（业务层无需再 json.Unmarshal）
type ParsedEndpoint struct {
	Row            CallbackAPIEndpoint
	Mapping        ResponseMapping
	Pagination     PaginationConfig
	ParamsTemplate map[string]interface{}
}

// TaskStatsUpdate 任务统计字段更新（由 service 计算后传入，repository 仅持久化）
type TaskStatsUpdate struct {
	Status       string
	MemberCount  int
	TotalBonus   float64
	HealthLevel  *string
	ErrorMessage string
	StartedAt    *time.Time
	FinishedAt   *time.Time
}

// ---------- Platform ----------

type PlatformListFilter struct {
	Keyword string
	Enabled *bool
	Page    int
	PageSize int
}

func (r *Repository) ListPlatforms(ctx context.Context, f PlatformListFilter) ([]CallbackPlatform, int64, error) {
	q := r.conn(ctx).Model(&CallbackPlatform{})
	if kw := strings.TrimSpace(f.Keyword); kw != "" {
		q = q.Where("name ILIKE ?", "%"+kw+"%")
	}
	if f.Enabled != nil {
		q = q.Where("enabled = ?", *f.Enabled)
	}
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	page, pageSize := normalizePage(f.Page, f.PageSize)
	var items []CallbackPlatform
	err := q.Order("created_at desc").Offset((page - 1) * pageSize).Limit(pageSize).Find(&items).Error
	return items, total, err
}

func (r *Repository) GetPlatform(ctx context.Context, id uuid.UUID) (*CallbackPlatform, error) {
	var p CallbackPlatform
	err := r.conn(ctx).First(&p, "id = ?", id).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &p, err
}

func (r *Repository) GetEnabledPlatform(ctx context.Context, id uuid.UUID) (*CallbackPlatform, error) {
	var p CallbackPlatform
	err := r.conn(ctx).Where("id = ? AND enabled = ?", id, true).First(&p).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &p, err
}

func (r *Repository) CreatePlatform(ctx context.Context, p *CallbackPlatform) error {
	return r.conn(ctx).Create(p).Error
}

func (r *Repository) UpdatePlatform(ctx context.Context, p *CallbackPlatform) error {
	return r.conn(ctx).Save(p).Error
}

func (r *Repository) DeletePlatform(ctx context.Context, id uuid.UUID) error {
	return r.conn(ctx).Delete(&CallbackPlatform{}, "id = ?", id).Error
}

// ---------- API Endpoint ----------

type EndpointListFilter struct {
	PlatformID *uuid.UUID
	Code       string
	Enabled    *bool
}

func (r *Repository) ListEndpoints(ctx context.Context, f EndpointListFilter) ([]CallbackAPIEndpoint, error) {
	q := r.conn(ctx).Model(&CallbackAPIEndpoint{})
	if f.PlatformID != nil {
		q = q.Where("platform_id = ?", *f.PlatformID)
	}
	if code := strings.TrimSpace(f.Code); code != "" {
		q = q.Where("code = ?", code)
	}
	if f.Enabled != nil {
		q = q.Where("enabled = ?", *f.Enabled)
	}
	var items []CallbackAPIEndpoint
	err := q.Order("sort_order asc, code asc").Find(&items).Error
	return items, err
}

func (r *Repository) GetEndpoint(ctx context.Context, id uuid.UUID) (*CallbackAPIEndpoint, error) {
	var e CallbackAPIEndpoint
	err := r.conn(ctx).First(&e, "id = ?", id).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &e, err
}

// GetEndpointByCode 按 endpoint code 获取配置：优先平台级，其次全局（platform_id IS NULL）。
// code 为任意业务编码（如 vip.list / recharge.list），无需修改 Repository。
func (r *Repository) GetEndpointByCode(ctx context.Context, platformID uuid.UUID, code string) (*ParsedEndpoint, error) {
	code = strings.TrimSpace(code)
	if code == "" {
		return nil, fmt.Errorf("endpoint code is required")
	}

	var row CallbackAPIEndpoint
	err := r.conn(ctx).
		Where("platform_id = ? AND code = ? AND enabled = ?", platformID, code, true).
		First(&row).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		err = r.conn(ctx).
			Where("platform_id IS NULL AND code = ? AND enabled = ?", code, true).
			First(&row).Error
	}
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return parseEndpointRow(&row)
}

func (r *Repository) EnsureGlobalEndpoint(ctx context.Context, e *CallbackAPIEndpoint) error {
	code := strings.TrimSpace(e.Code)
	if code == "" {
		return fmt.Errorf("endpoint code is required")
	}
	var existing CallbackAPIEndpoint
	err := r.conn(ctx).
		Where("platform_id IS NULL AND code = ?", code).
		First(&existing).Error
	if err == nil {
		return nil
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}
	row := *e
	row.PlatformID = nil
	return r.CreateEndpoint(ctx, &row)
}

func (r *Repository) CreateEndpoint(ctx context.Context, e *CallbackAPIEndpoint) error {
	normalizeEndpointJSONB(e)
	return r.conn(ctx).Create(e).Error
}

func (r *Repository) UpdateEndpoint(ctx context.Context, e *CallbackAPIEndpoint) error {
	normalizeEndpointJSONB(e)
	return r.conn(ctx).Save(e).Error
}

func (r *Repository) DeleteEndpoint(ctx context.Context, id uuid.UUID) error {
	return r.conn(ctx).Delete(&CallbackAPIEndpoint{}, "id = ?", id).Error
}

func parseEndpointRow(row *CallbackAPIEndpoint) (*ParsedEndpoint, error) {
	mapping, err := parseResponseMapping(row.ResponseMapping)
	if err != nil {
		return nil, fmt.Errorf("endpoint %s response_mapping: %w", row.Code, err)
	}
	pagination, err := parsePaginationConfig(row.PaginationConfig)
	if err != nil {
		return nil, fmt.Errorf("endpoint %s pagination_config: %w", row.Code, err)
	}
	params, err := parseRequestParamsTemplate(row.RequestParamsTemplate)
	if err != nil {
		return nil, fmt.Errorf("endpoint %s request_params_template: %w", row.Code, err)
	}
	return &ParsedEndpoint{
		Row:            *row,
		Mapping:        mapping,
		Pagination:     pagination,
		ParamsTemplate: params,
	}, nil
}

func parseResponseMapping(raw string) (ResponseMapping, error) {
	raw = jsonbStringOrDefault(raw, "{}")
	var m ResponseMapping
	if err := json.Unmarshal([]byte(raw), &m); err != nil {
		return ResponseMapping{}, err
	}
	return m, nil
}

func parsePaginationConfig(raw string) (PaginationConfig, error) {
	raw = jsonbStringOrDefault(raw, "{}")
	var c PaginationConfig
	if err := json.Unmarshal([]byte(raw), &c); err != nil {
		return PaginationConfig{}, err
	}
	return c, nil
}

func parseRequestParamsTemplate(raw string) (map[string]interface{}, error) {
	raw = jsonbStringOrDefault(raw, "{}")
	var m map[string]interface{}
	if err := json.Unmarshal([]byte(raw), &m); err != nil {
		return nil, err
	}
	if m == nil {
		m = map[string]interface{}{}
	}
	return m, nil
}

func normalizeEndpointJSONB(e *CallbackAPIEndpoint) {
	e.RequestParamsTemplate = jsonbStringOrDefault(e.RequestParamsTemplate, "{}")
	e.ResponseMapping = jsonbStringOrDefault(e.ResponseMapping, "{}")
	e.PaginationConfig = jsonbStringOrDefault(e.PaginationConfig, "{}")
}

// ---------- Activity（单例） ----------

func (r *Repository) GetActivity(ctx context.Context) (*CallbackActivity, error) {
	var a CallbackActivity
	err := r.conn(ctx).Order("created_at asc").First(&a).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &a, err
}

func (r *Repository) CreateActivity(ctx context.Context, a *CallbackActivity) error {
	return r.conn(ctx).Create(a).Error
}

func (r *Repository) UpdateActivity(ctx context.Context, a *CallbackActivity) error {
	return r.conn(ctx).Save(a).Error
}

// ---------- Task ----------

type TaskListFilter struct {
	PlatformID *uuid.UUID
	Status     string
	Page       int
	PageSize   int
}

func (r *Repository) ListTasks(ctx context.Context, f TaskListFilter) ([]CallbackTask, int64, error) {
	q := r.conn(ctx).Model(&CallbackTask{})
	if f.PlatformID != nil {
		q = q.Where("platform_id = ?", *f.PlatformID)
	}
	if st := strings.TrimSpace(f.Status); st != "" {
		q = q.Where("status = ?", st)
	}
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	page, pageSize := normalizePage(f.Page, f.PageSize)
	var items []CallbackTask
	err := q.Order("created_at desc").Offset((page - 1) * pageSize).Limit(pageSize).Find(&items).Error
	return items, total, err
}

func (r *Repository) GetTask(ctx context.Context, id uuid.UUID) (*CallbackTask, error) {
	var t CallbackTask
	err := r.conn(ctx).First(&t, "id = ?", id).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &t, err
}

func (r *Repository) CreateTask(ctx context.Context, task *CallbackTask) error {
	task.ActivitySnapshot = jsonbStringOrDefault(task.ActivitySnapshot, "{}")
	return r.conn(ctx).Create(task).Error
}

func (r *Repository) UpdateTask(ctx context.Context, task *CallbackTask) error {
	return r.conn(ctx).Save(task).Error
}

func (r *Repository) UpdateTaskStats(ctx context.Context, id uuid.UUID, u TaskStatsUpdate) error {
	updates := map[string]interface{}{
		"status":        u.Status,
		"member_count":  u.MemberCount,
		"total_bonus":   u.TotalBonus,
		"error_message": u.ErrorMessage,
		"updated_at":    time.Now(),
	}
	if u.HealthLevel != nil {
		updates["health_level"] = *u.HealthLevel
	} else {
		updates["health_level"] = nil
	}
	if u.StartedAt != nil {
		updates["started_at"] = *u.StartedAt
	}
	if u.FinishedAt != nil {
		updates["finished_at"] = *u.FinishedAt
	}
	return r.conn(ctx).Model(&CallbackTask{}).Where("id = ?", id).Updates(updates).Error
}

// SaveTaskWithResults 事务：批量写入结果 + 更新任务统计；任一步失败则全部回滚。
func (r *Repository) SaveTaskWithResults(ctx context.Context, taskID uuid.UUID, stats TaskStatsUpdate, results []CallbackResult) error {
	return r.WithTx(ctx, func(tx *Repository) error {
		if err := tx.UpdateTaskStats(ctx, taskID, stats); err != nil {
			return err
		}
		if len(results) == 0 {
			return nil
		}
		return tx.CreateResultsInBatches(ctx, results, defaultResultBatchSize)
	})
}

// CreateTaskWithResults 事务：创建任务 + 批量写入结果 + 更新最终统计（用于一次性提交完整任务）。
func (r *Repository) CreateTaskWithResults(ctx context.Context, task *CallbackTask, results []CallbackResult) error {
	return r.WithTx(ctx, func(tx *Repository) error {
		if err := tx.CreateTask(ctx, task); err != nil {
			return err
		}
		if len(results) > 0 {
			for i := range results {
				results[i].TaskID = task.ID
			}
			if err := tx.CreateResultsInBatches(ctx, results, defaultResultBatchSize); err != nil {
				return err
			}
		}
		return nil
	})
}

// ---------- Result ----------

type ResultListFilter struct {
	TaskID   uuid.UUID
	Page     int
	PageSize int
}

func (r *Repository) ListResultsByTask(ctx context.Context, f ResultListFilter) ([]CallbackResult, int64, error) {
	q := r.conn(ctx).Model(&CallbackResult{}).Where("task_id = ?", f.TaskID)
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	page, pageSize := normalizePage(f.Page, f.PageSize)
	var items []CallbackResult
	err := q.Order("bonus desc, user_id asc").
		Offset((page - 1) * pageSize).
		Limit(pageSize).
		Find(&items).Error
	return items, total, err
}

func (r *Repository) ListAllResultsByTask(ctx context.Context, taskID uuid.UUID) ([]CallbackResult, error) {
	var items []CallbackResult
	err := r.conn(ctx).
		Where("task_id = ?", taskID).
		Order("bonus desc, user_id asc").
		Find(&items).Error
	return items, err
}

// CreateResultsInBatches 使用 GORM CreateInBatches 批量插入，避免逐条写入。
func (r *Repository) CreateResultsInBatches(ctx context.Context, results []CallbackResult, batchSize int) error {
	if len(results) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = defaultResultBatchSize
	}
	for i := range results {
		results[i].RawData = jsonbStringOrDefault(results[i].RawData, "{}")
	}
	return r.conn(ctx).CreateInBatches(results, batchSize).Error
}

// ---------- Request Log ----------

type RequestLogListFilter struct {
	PlatformID   *uuid.UUID
	TaskID       *uuid.UUID
	EndpointCode string
	Page         int
	PageSize     int
}

func (r *Repository) CreateRequestLog(ctx context.Context, log *CallbackRequestLog) error {
	log.RequestParams = jsonbStringOrDefault(log.RequestParams, "{}")
	return r.conn(ctx).Create(log).Error
}

func (r *Repository) ListRequestLogs(ctx context.Context, f RequestLogListFilter) ([]CallbackRequestLog, int64, error) {
	q := r.conn(ctx).Model(&CallbackRequestLog{})
	if f.PlatformID != nil {
		q = q.Where("platform_id = ?", *f.PlatformID)
	}
	if f.TaskID != nil {
		q = q.Where("task_id = ?", *f.TaskID)
	}
	if code := strings.TrimSpace(f.EndpointCode); code != "" {
		q = q.Where("endpoint_code = ?", code)
	}
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	page, pageSize := normalizePage(f.Page, f.PageSize)
	var items []CallbackRequestLog
	err := q.Order("created_at desc").
		Offset((page - 1) * pageSize).
		Limit(pageSize).
		Find(&items).Error
	return items, total, err
}

// ---------- helpers ----------

func normalizePage(page, pageSize int) (int, int) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 200 {
		pageSize = 20
	}
	return page, pageSize
}

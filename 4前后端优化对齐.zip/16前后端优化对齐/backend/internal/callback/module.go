package callback

import (
	"context"
	"database/sql"
	"log"
	"os"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"enterprise-agent/backend/middleware"
)

type Config struct {
	Enabled   bool
	SecretKey []byte
}

func LoadConfig() Config {
	enabled := true
	if v := strings.ToLower(strings.TrimSpace(os.Getenv("CALLBACK_ENABLED"))); v == "false" || v == "0" {
		enabled = false
	}
	secret := DeriveSecretKey(os.Getenv("CALLBACK_SECRET_KEY"))
	if len(secret) != 32 {
		secret = DeriveSecretKey(os.Getenv("JWT_SECRET"))
	}
	return Config{
		Enabled:   enabled,
		SecretKey: secret,
	}
}

// Bootstrap 模块入口：注册路由（需 CALLBACK_ENABLED=true，默认启用）
func Bootstrap(router *gin.Engine, sqlDB *sql.DB, redisClient *redis.Client) {
	cfg := LoadConfig()
	if !cfg.Enabled {
		log.Println("[Callback] disabled (set CALLBACK_ENABLED=true to enable)")
		return
	}
	if len(cfg.SecretKey) != 32 {
		log.Println("[Callback] warning: secret key invalid length, module disabled")
		return
	}

	gdb, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Warn),
	})
	if err != nil {
		log.Printf("[Callback] gorm init failed: %v", err)
		return
	}
	if err := autoMigrate(gdb); err != nil {
		log.Printf("[Callback] migrate failed: %v", err)
		return
	}
	if err := ensureCallbackSchema(gdb); err != nil {
		log.Printf("[Callback] schema sync warning: %v", err)
	}

	repo := NewRepository(gdb)
	crypto := NewCrypto(cfg.SecretKey)
	client := NewClient(repo, crypto)
	svc := NewService(repo, client, crypto)
	if err := svc.EnsureDefaultEndpoints(context.Background()); err != nil {
		log.Printf("[Callback] seed default endpoints failed: %v", err)
	}
	if _, err := svc.GetActivity(context.Background()); err != nil {
		log.Printf("[Callback] seed default activity failed: %v", err)
	}
	handler := NewHandler(svc)

	api := router.Group("/api/v1")
	cb := api.Group("/callback")
	cb.Use(middleware.Auth(redisClient))
	handler.Register(cb)

	log.Println("[Callback] module started at /api/v1/callback")
}

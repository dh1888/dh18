package callback

import (
	"bytes"
	"encoding/csv"
	"fmt"
	"io"
	"strings"
	"unicode/utf8"

	"github.com/xuri/excelize/v2"
)

func readSpreadsheetRows(r io.Reader, filename string) ([][]string, error) {
	data, err := io.ReadAll(r)
	if err != nil {
		return nil, fmt.Errorf("read file: %w", err)
	}
	return readSpreadsheetRowsFromBytes(data, filename, 0)
}

const spreadsheetPreviewMaxRows = 5

func readSpreadsheetRowsPreview(r io.Reader, filename string, maxRows int) ([][]string, error) {
	if maxRows <= 0 {
		maxRows = spreadsheetPreviewMaxRows
	}
	data, err := io.ReadAll(r)
	if err != nil {
		return nil, fmt.Errorf("read file: %w", err)
	}
	return readSpreadsheetRowsFromBytes(data, filename, maxRows)
}

func readSpreadsheetRowsFromBytes(data []byte, filename string, maxRows int) ([][]string, error) {
	if len(data) == 0 {
		return nil, fmt.Errorf("empty file")
	}
	if isCSVFile(filename, data) {
		if maxRows > 0 {
			return parseCSVRowsLimited(data, maxRows)
		}
		return parseCSVRows(data)
	}
	if maxRows > 0 {
		return readExcelRowsLimited(data, maxRows)
	}
	return readExcelRowsFromBytes(data)
}

func isCSVFile(filename string, data []byte) bool {
	if strings.HasSuffix(strings.ToLower(strings.TrimSpace(filename)), ".csv") {
		return true
	}
	// xlsx/xlsm zip header
	if len(data) >= 2 && data[0] == 'P' && data[1] == 'K' {
		return false
	}
	// legacy xls
	if len(data) >= 8 && data[0] == 0xD0 && data[1] == 0xCF {
		return false
	}
	sample := data
	if len(sample) > 512 {
		sample = sample[:512]
	}
	if !utf8.Valid(sample) {
		return false
	}
	text := string(sample)
	comma := strings.Count(text, ",")
	semicolon := strings.Count(text, ";")
	tab := strings.Count(text, "\t")
	return comma+semicolon+tab > 0
}

func parseCSVRows(data []byte) ([][]string, error) {
	data = bytes.TrimPrefix(data, []byte{0xEF, 0xBB, 0xBF})
	delimiter, err := detectCSVDelimiter(data)
	if err != nil {
		return nil, err
	}
	reader := csv.NewReader(bytes.NewReader(data))
	reader.Comma = delimiter
	reader.LazyQuotes = true
	reader.TrimLeadingSpace = true
	reader.FieldsPerRecord = -1

	rows, err := reader.ReadAll()
	if err != nil {
		return nil, fmt.Errorf("parse csv: %w", err)
	}
	if len(rows) < 1 {
		return nil, fmt.Errorf("empty csv file")
	}
	return rows, nil
}

func parseCSVRowsLimited(data []byte, maxRows int) ([][]string, error) {
	data = bytes.TrimPrefix(data, []byte{0xEF, 0xBB, 0xBF})
	delimiter, err := detectCSVDelimiter(data)
	if err != nil {
		return nil, err
	}
	reader := csv.NewReader(bytes.NewReader(data))
	reader.Comma = delimiter
	reader.LazyQuotes = true
	reader.TrimLeadingSpace = true
	reader.FieldsPerRecord = -1

	rows := make([][]string, 0, maxRows)
	for len(rows) < maxRows {
		record, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, fmt.Errorf("parse csv: %w", err)
		}
		rows = append(rows, record)
	}
	if len(rows) < 1 {
		return nil, fmt.Errorf("empty csv file")
	}
	return rows, nil
}

func detectCSVDelimiter(data []byte) (rune, error) {
	firstLine := data
	if idx := bytes.IndexByte(data, '\n'); idx >= 0 {
		firstLine = data[:idx]
	}
	firstLine = bytes.TrimSpace(firstLine)
	if len(firstLine) == 0 {
		return ',', nil
	}
	candidates := []rune{',', ';', '\t'}
	best := ','
	bestCount := -1
	for _, d := range candidates {
		count := strings.Count(string(firstLine), string(d))
		if count > bestCount {
			bestCount = count
			best = d
		}
	}
	if bestCount <= 0 {
		return ',', nil
	}
	return best, nil
}

func readExcelRowsFromBytes(data []byte) ([][]string, error) {
	f, err := excelize.OpenReader(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("open excel: %w", err)
	}
	defer f.Close()
	sheet := f.GetSheetName(0)
	if sheet == "" {
		return nil, fmt.Errorf("excel has no sheets")
	}
	rows, err := f.GetRows(sheet)
	if err != nil {
		return nil, fmt.Errorf("read rows: %w", err)
	}
	if len(rows) < 1 {
		return nil, fmt.Errorf("empty excel file")
	}
	return rows, nil
}

func readExcelRowsLimited(data []byte, maxRows int) ([][]string, error) {
	f, err := excelize.OpenReader(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("open excel: %w", err)
	}
	defer f.Close()
	sheet := f.GetSheetName(0)
	if sheet == "" {
		return nil, fmt.Errorf("excel has no sheets")
	}
	iter, err := f.Rows(sheet)
	if err != nil {
		return nil, fmt.Errorf("read rows: %w", err)
	}
	defer iter.Close()

	rows := make([][]string, 0, maxRows)
	for iter.Next() && len(rows) < maxRows {
		cols, err := iter.Columns()
		if err != nil {
			return nil, fmt.Errorf("read row: %w", err)
		}
		rows = append(rows, cols)
	}
	if len(rows) < 1 {
		return nil, fmt.Errorf("empty excel file")
	}
	return rows, nil
}

func readExcelRows(r io.Reader) ([][]string, error) {
	return readSpreadsheetRows(r, "")
}

package callback

import (
	"bytes"
	"fmt"
	"strings"

	"github.com/xuri/excelize/v2"
)

func BuildManualTemplateExcel(templateType string) (*bytes.Buffer, error) {
	switch strings.TrimSpace(strings.ToLower(templateType)) {
	case "unclaimed", "unclaimed_file":
		return buildUnclaimedTemplateExcel()
	default:
		return buildMemberTemplateExcel()
	}
}

func buildMemberTemplateExcel() (*bytes.Buffer, error) {
	f := excelize.NewFile()
	sheet := "会员数据"
	_ = f.SetSheetName("Sheet1", sheet)

	headers := []string{"会员ID", "历史充值", "历史提现", "手机号"}
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		_ = f.SetCellValue(sheet, cell, h)
	}
	example := []interface{}{10001, 5000, 8000, "13800000000"}
	for col, val := range example {
		cell, _ := excelize.CoordinatesToCellName(col+1, 2)
		_ = f.SetCellValue(sheet, cell, val)
	}

	buf := &bytes.Buffer{}
	if err := f.Write(buf); err != nil {
		return nil, err
	}
	return buf, nil
}

func buildUnclaimedTemplateExcel() (*bytes.Buffer, error) {
	f := excelize.NewFile()
	sheet := "未领彩金"
	_ = f.SetSheetName("Sheet1", sheet)

	headers := []string{"会员ID"}
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		_ = f.SetCellValue(sheet, cell, h)
	}
	_ = f.SetCellValue(sheet, "A2", 10001)

	buf := &bytes.Buffer{}
	if err := f.Write(buf); err != nil {
		return nil, err
	}
	return buf, nil
}

func manualDispatchLabel(t string) string {
	if t == ManualDispatchCallbackBonus {
		return "回访彩金"
	}
	return "时段彩金"
}

func manualOtherSheetName(t string) string {
	if t == ManualDispatchPeriodBonus {
		return "用户盈利"
	}
	return "亏损回访"
}

func BuildManualExportExcel(req ManualExportRequest) (*bytes.Buffer, error) {
	f := excelize.NewFile()
	exportType := strings.TrimSpace(req.ExportType)
	if exportType == "" {
		exportType = "all"
	}
	dt := req.Result.DispatchType
	otherName := manualOtherSheetName(dt)

	switch exportType {
	case "dispatch", "dispatch_all":
		writeCallbackDispatchSheets(f, req.Result)
	case "dispatch_bonus":
		writeManualDispatchExportSheet(f, req.Result, true)
	case "dispatch_other":
		writeManualDispatchExportSheet(f, req.Result, false)
	case "bonus":
		profitName := "盈利回访"
		if req.Result.DispatchType == ManualDispatchPeriodBonus {
			profitName = "亏损/持平派发"
		}
		writeManualSheet(f, profitName, req.Result.BonusRows, true, false, req.Result.DispatchType)
	case "other":
		writeManualSheet(f, otherName, req.Result.OtherRows, req.Result.DispatchType == ManualDispatchCallbackBonus, false, req.Result.DispatchType)
	case "excluded":
		writeManualSheet(f, "已剔除", req.Result.ExcludedRows, false, true, req.Result.DispatchType)
	case "unclaimed":
		writeManualSheet(f, "未领彩金匹配", req.Result.UnclaimedRewardRows, false, false, req.Result.DispatchType)
	case "all":
		writeCallbackDispatchSheets(f, req.Result)
		if len(req.Result.BonusRows) > 0 {
			profitName := "盈利回访"
			if req.Result.DispatchType == ManualDispatchPeriodBonus {
				profitName = "彩金派发"
			}
			writeManualSheet(f, profitName, req.Result.BonusRows, true, false, req.Result.DispatchType)
		}
		if len(req.Result.OtherRows) > 0 {
			writeManualSheet(f, otherName, req.Result.OtherRows, req.Result.DispatchType == ManualDispatchCallbackBonus, false, req.Result.DispatchType)
		}
		if len(req.Result.ExcludedRows) > 0 {
			writeManualSheet(f, "已剔除", req.Result.ExcludedRows, false, true, req.Result.DispatchType)
		}
		if len(req.Result.UnclaimedRewardRows) > 0 {
			writeManualSheet(f, "未领彩金匹配", req.Result.UnclaimedRewardRows, false, false, req.Result.DispatchType)
		}
		writeManualSummarySheet(f, req.Result)
	default:
		return nil, fmt.Errorf("unknown exportType %q", exportType)
	}

	_ = f.DeleteSheet("Sheet1")
	buf := &bytes.Buffer{}
	if err := f.Write(buf); err != nil {
		return nil, err
	}
	return buf, nil
}

func manualPayWithdrawHeaders(dispatchType string) (pay, withdraw string) {
	if dispatchType == ManualDispatchCallbackBonus {
		return "累计充值", "累计提款"
	}
	return "历史充值", "历史提现"
}

func writeManualSheet(f *excelize.File, name string, rows []ManualRow, withBonus, withReason bool, dispatchType string) {
	sheet := name
	_, _ = f.NewSheet(sheet)
	payHeader, withdrawHeader := manualPayWithdrawHeaders(dispatchType)
	headers := []string{"会员ID", "手机号", payHeader, withdrawHeader, "盈亏"}
	if withBonus {
		headers = append(headers, "彩金")
	}
	if withReason {
		headers = append(headers, "剔除原因")
	}
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		_ = f.SetCellValue(sheet, cell, h)
	}
	for i, r := range rows {
		rowNum := i + 2
		vals := []interface{}{
			r.UserID,
			r.PhoneNumber,
			r.HistoricalPay,
			r.HistoryWithdrawals,
			r.Profit,
		}
		if withBonus {
			vals = append(vals, r.Bonus)
		}
		if withReason {
			vals = append(vals, r.ExcludeReason)
		}
		for col, val := range vals {
			cell, _ := excelize.CoordinatesToCellName(col+1, rowNum)
			_ = f.SetCellValue(sheet, cell, val)
		}
	}
}

func writeManualDispatchExportSheet(f *excelize.File, result ManualProcessResult, bonus bool) {
	cfg := result.BonusConfig
	if result.DispatchType == ManualDispatchCallbackBonus {
		if bonus {
			writeManualDispatchSheet(f, "盈利彩金派发", result.BonusRows, cfg)
			return
		}
		writeManualDispatchSheet(f, "亏损彩金派发", result.OtherRows, cfg)
		return
	}
	if bonus {
		writeManualDispatchSheet(f, "彩金派发", result.BonusRows, cfg)
	}
}

func writeCallbackDispatchSheets(f *excelize.File, result ManualProcessResult) {
	cfg := result.BonusConfig
	if result.DispatchType == ManualDispatchCallbackBonus {
		writeManualDispatchSheet(f, "盈利彩金派发", result.BonusRows, cfg)
		writeManualDispatchSheet(f, "亏损彩金派发", result.OtherRows, cfg)
		return
	}
	writeManualDispatchSheet(f, "彩金派发", result.BonusRows, cfg)
}

func writeManualDispatchSheet(f *excelize.File, name string, rows []ManualRow, cfg ManualBonusConfig) {
	sheet := name
	_, _ = f.NewSheet(sheet)
	headers := []string{"会员ID", "优惠金额", "打码倍数", "APP端备注", "后台备注"}
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		_ = f.SetCellValue(sheet, cell, h)
	}
	for i, r := range rows {
		rowNum := i + 2
		vals := []interface{}{
			r.UserID,
			r.Bonus,
			cfg.WageringMultiplier,
			cfg.AppRemark,
			cfg.BackendRemark,
		}
		for col, val := range vals {
			cell, _ := excelize.CoordinatesToCellName(col+1, rowNum)
			_ = f.SetCellValue(sheet, cell, val)
		}
	}
}

func writeManualSummarySheet(f *excelize.File, result ManualProcessResult) {
	sheet := "汇总"
	_, _ = f.NewSheet(sheet)
	s := result.Summary
	cfg := result.BonusConfig
	pairs := [][2]interface{}{
		{"派发类型", manualDispatchLabel(result.DispatchType)},
		{"会员数据行数", s.TotalRows},
		{"彩金派发人数", s.BonusCount},
		{"其他人数", s.OtherCount},
		{"已剔除人数", s.ExcludedCount},
		{"未领名单行数", s.UnclaimedFileRows},
		{"名单匹配人数", s.UnclaimedMatchedCount},
		{"总彩金", s.TotalBonus},
	}
	if result.DispatchType == ManualDispatchCallbackBonus {
		pairs = append(pairs,
			[2]interface{}{"回访最低彩金", cfg.CallbackMinBonus},
			[2]interface{}{"彩金比例", cfg.Rate},
			[2]interface{}{"除数", cfg.Divisor},
			[2]interface{}{"打码倍数", cfg.WageringMultiplier},
			[2]interface{}{"APP端备注", cfg.AppRemark},
			[2]interface{}{"后台备注", cfg.BackendRemark},
		)
	} else {
		pairs = append(pairs,
			[2]interface{}{"彩金比例", cfg.Rate},
			[2]interface{}{"除数", cfg.Divisor},
			[2]interface{}{"最低彩金", cfg.MinBonus},
			[2]interface{}{"最高彩金", cfg.MaxBonus},
			[2]interface{}{"打码倍数", cfg.WageringMultiplier},
			[2]interface{}{"APP端备注", cfg.AppRemark},
			[2]interface{}{"后台备注", cfg.BackendRemark},
		)
	}
	for i, p := range pairs {
		_ = f.SetCellValue(sheet, fmt.Sprintf("A%d", i+1), p[0])
		_ = f.SetCellValue(sheet, fmt.Sprintf("B%d", i+1), p[1])
	}
}

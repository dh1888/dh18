package callback

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"io"
	"strings"
)

type Crypto struct {
	key []byte
}

func NewCrypto(secretKey []byte) *Crypto {
	return &Crypto{key: secretKey}
}

func DeriveSecretKey(raw string) []byte {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	if b, err := base64.StdEncoding.DecodeString(raw); err == nil && len(b) >= 32 {
		return b[:32]
	}
	sum := sha256.Sum256([]byte(raw))
	return sum[:]
}

func (c *Crypto) EncryptToken(plain string) (string, error) {
	if len(c.key) != 32 {
		return "", fmt.Errorf("secret key must be 32 bytes")
	}
	block, err := aes.NewCipher(c.key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	ciphertext := gcm.Seal(nonce, nonce, []byte(plain), nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func (c *Crypto) DecryptToken(enc string) (string, error) {
	if len(c.key) != 32 {
		return "", fmt.Errorf("secret key must be 32 bytes")
	}
	data, err := base64.StdEncoding.DecodeString(enc)
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher(c.key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	if len(data) < gcm.NonceSize() {
		return "", fmt.Errorf("invalid ciphertext")
	}
	nonce, ciphertext := data[:gcm.NonceSize()], data[gcm.NonceSize():]
	plain, err := gcm.Open(nil, nonce, ciphertext, nil)
	return string(plain), err
}

func MaskToken(token string) string {
	token = strings.TrimSpace(token)
	if len(token) <= 8 {
		return "******"
	}
	if len(token) < 8 {
		return "******"
	}
	return token[:5] + "********" + token[len(token)-3:]
}

func (c *Crypto) MaskEncryptedToken(enc string) string {
	plain, err := c.DecryptToken(enc)
	if err != nil {
		return "******"
	}
	return MaskToken(plain)
}

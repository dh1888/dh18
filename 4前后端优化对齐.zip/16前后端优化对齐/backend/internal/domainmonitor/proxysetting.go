package domainmonitor

import (
	"strings"

	"enterprise-agent/backend/internal/proxytransport"
)

func normalizeSavedProxyURL(raw string) (string, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", nil
	}
	return proxytransport.NormalizeProxyURL(raw)
}

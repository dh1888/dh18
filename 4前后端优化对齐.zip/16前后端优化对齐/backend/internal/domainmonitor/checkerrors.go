package domainmonitor

import (
	"errors"
	"net"
	"strings"
)

func humanizeCheckError(err error) (summary, hint string) {
	if err == nil {
		return "检测失败", ""
	}
	msg := err.Error()
	lower := strings.ToLower(msg)

	switch {
	case strings.Contains(msg, "malformed HTTP response"):
		if strings.Contains(msg, `\x00`) || strings.Contains(msg, "\x00") || strings.Contains(lower, "012\\x04") {
			return "HTTP 协议不匹配（代理或站点返回了 HTTP/2 二进制帧）",
				"常见于全局 HTTP 代理配置不当（如 SOCKS 地址填成 http://、或代理不支持 HTTPS CONNECT）。请核对检测设置中的代理地址，或暂时关闭代理后重测。"
		}
		return "HTTP 响应格式异常", "可能是代理配置错误或目标站点返回非标准 HTTP 响应"
	case strings.Contains(lower, "tls:") || strings.Contains(lower, "x509:") || strings.Contains(lower, "certificate"):
		return "TLS/SSL 握手失败", "证书无效、域名不匹配或 TLS 版本不兼容。浏览器能打开可能是因为走了不同网络路径或忽略了证书警告。"
	case strings.Contains(lower, "no such host") || strings.Contains(lower, "nxdomain"):
		return "DNS 解析失败", "域名在当前 DNS 环境下无法解析"
	case strings.Contains(lower, "connection refused"):
		return "连接被拒绝", "目标端口未开放或被防火墙拦截"
	case strings.Contains(lower, "connection reset"):
		return "连接被重置", "可能被防火墙、CDN 或地区封锁拦截"
	case strings.Contains(msg, "Bad Request"):
		return "代理返回 Bad Request（400）",
			"通常是代理配置错误：1) 应使用 http://127.0.0.1:端口（不要用 socks5://）；2) Clash 用 http-port（常见 7890），不是 mixed/socks 端口；3) 账号密码用 http://user:pass@host:port；4) 本地代理不要用 https:// 前缀。"
	case strings.Contains(lower, "407"):
		return "代理需要认证", "请在代理 URL 中填写用户名和密码：http://user:pass@host:port"
	case strings.Contains(lower, "timeout") || strings.Contains(lower, "deadline exceeded"):
		return "连接超时", "网络不通或响应过慢，可尝试增大超时或检查代理"
	case strings.Contains(lower, "proxy"):
		return "代理连接失败", "请检查 HTTP 代理地址、端口及认证信息是否正确"
	case strings.Contains(lower, "eof"):
		return "连接意外中断", "服务器或代理提前关闭了连接"
	}

	var netErr net.Error
	if errors.As(err, &netErr) && netErr.Timeout() {
		return "连接超时", "网络不通或响应过慢"
	}
	return "请求失败", truncate(msg, 200)
}

func checkErrorDetail(err error, issue string) map[string]interface{} {
	summary, hint := humanizeCheckError(err)
	out := map[string]interface{}{
		"summary": summary,
		"issue":   issue,
	}
	if hint != "" {
		out["hint"] = hint
	}
	if err != nil {
		out["error"] = err.Error()
	}
	return out
}

func sslErrorDetail(err error) map[string]interface{} {
	if err == nil {
		return map[string]interface{}{"summary": "SSL 检测失败"}
	}
	summary, hint := humanizeCheckError(err)
	out := map[string]interface{}{
		"summary": summary,
		"error":   err.Error(),
	}
	if hint != "" {
		out["hint"] = hint
	}
	return out
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

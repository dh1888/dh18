package domainmonitor

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"regexp"
	"strings"
	"time"

	"enterprise-agent/backend/internal/domainmonitor/probechecks"
)

func (e *Engine) checkUserSimulation(ctx context.Context, d *DmDomain) (*DmCheckResult, string) {
	start := time.Now()
	res := e.baseResult(d, "userSimulation")
	target := probeTargetURL(d, "userSimulation")
	spec := probechecks.Spec{
		Type:         "userSimulation",
		URL:          target,
		UseProxy:     true,
		HttpProxyURL: strings.TrimSpace(e.perf().httpProxyUrl),
		Keywords:     parseKeywordList(d.ContentKeywords),
	}
	// 复用 probechecks 检测逻辑，HTTP 客户端使用既有 e.client（含全局代理配置，不修改代理实现）
	out := runUserSimulationWithClient(ctx, e.client, d.Domain, spec)
	res.Status = out.Status
	res.DurationMs = int(time.Since(start).Milliseconds())
	res.HTTPStatus = out.HTTPStatus
	res.FinalURL = out.FinalURL
	res.RawDetail = out.RawDetail
	return res, out.Status
}

var (
	reUserAccessDenied = regexp.MustCompile(`(?i)access denied|geo.?block|not available in your (country|region)`)
	reUserCloudflare   = regexp.MustCompile(`(?i)cloudflare|cf-challenge|checking your browser`)
)

func runUserSimulationWithClient(ctx context.Context, client *http.Client, domain string, spec probechecks.Spec) probechecks.Result {
	target := spec.URL
	if target == "" {
		target = "https://" + domain
	}
	start := time.Now()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	if err != nil {
		return probechecks.Result{CheckType: "userSimulation", Status: statusError, DurationMs: int(time.Since(start).Milliseconds()),
			RawDetail: mustJSON(map[string]string{"error": err.Error()})}
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
	resp, err := client.Do(req)
	if err != nil {
		return probechecks.Result{CheckType: "userSimulation", Status: statusError, DurationMs: int(time.Since(start).Milliseconds()),
			RawDetail: mustJSON(checkErrorDetail(err, "load_failed"))}
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
	text := string(body)
	finalURL := target
	if resp.Request != nil && resp.Request.URL != nil {
		finalURL = resp.Request.URL.String()
	}
	var issues []string
	if resp.StatusCode == 403 {
		issues = append(issues, "403 Forbidden")
	}
	if reUserAccessDenied.MatchString(text) {
		issues = append(issues, "Access Denied / Geo Block")
	}
	if reUserCloudflare.MatchString(text) {
		issues = append(issues, "Cloudflare Challenge")
	}
	for _, kw := range spec.Keywords {
		kw = strings.TrimSpace(kw)
		if kw != "" && !strings.Contains(strings.ToLower(text), strings.ToLower(kw)) {
			issues = append(issues, "missing keyword: "+kw)
		}
	}
	st := statusOK
	if len(issues) > 0 {
		st = statusWarning
	}
	if resp.StatusCode >= 500 {
		st = statusError
	}
	detail := map[string]interface{}{
		"issues": issues, "statusCode": resp.StatusCode, "finalUrl": finalURL,
		"proxy": spec.HttpProxyURL,
	}
	if len(issues) > 0 {
		detail["summary"] = strings.Join(issues, "；")
	} else {
		detail["summary"] = "用户模拟检测通过"
	}
	return probechecks.Result{
		CheckType:  "userSimulation",
		Status:     st,
		DurationMs: int(time.Since(start).Milliseconds()),
		HTTPStatus: resp.StatusCode,
		FinalURL:   finalURL,
		RawDetail:  mustJSON(detail),
	}
}

func (e *Engine) handleUserSimulationAlerts(ctx context.Context, d *DmDomain, res *DmCheckResult, st string) {
	if st == statusOK {
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, "user_sim_fail")
		return
	}
	severity := "WARNING"
	if st == statusError || st == statusCritical {
		severity = "ERROR"
	}
	title := fmt.Sprintf("[user_simulation] %s", d.Domain)
	msg := userSimulationIssueText(res)
	alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "user_sim_fail", severity, title, msg)
	if err != nil {
		return
	}
	e.dispatchTelegram(ctx, "user_sim_fail", severity, title, msg, alert)
}

func userSimulationIssueText(res *DmCheckResult) string {
	var info struct {
		Issues  []string `json:"issues"`
		Summary string   `json:"summary"`
		Error   string   `json:"error"`
	}
	_ = json.Unmarshal([]byte(res.RawDetail), &info)
	if len(info.Issues) > 0 {
		parts := make([]string, 0, len(info.Issues))
		for _, issue := range info.Issues {
			parts = append(parts, localizeIssueLine(issue))
		}
		return strings.Join(parts, "；")
	}
	if s := strings.TrimSpace(info.Summary); s != "" && s != "用户模拟检测通过" {
		return s
	}
	return "用户模拟检测异常"
}

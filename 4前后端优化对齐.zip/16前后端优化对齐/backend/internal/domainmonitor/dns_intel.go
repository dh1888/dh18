package domainmonitor

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"strings"
	"time"
)

var cdnPatterns = []struct {
	Name    string
	Needles []string
}{
	{Name: "Cloudflare", Needles: []string{"cloudflare", "cf-dns", "cdn.cloudflare.net"}},
	{Name: "Fastly", Needles: []string{"fastly", "fastlylb.net", "fastly.net"}},
	{Name: "AWS", Needles: []string{"cloudfront", "amazonaws", "awsdns"}},
	{Name: "Akamai", Needles: []string{"akamai", "akamaiedge", "edgekey.net", "akadns.net"}},
}

func detectCDN(rec map[string]interface{}) string {
	var blob strings.Builder
	appendJSONField(&blob, rec["CNAME"])
	appendJSONField(&blob, rec["NS"])
	appendJSONField(&blob, rec["TXT"])
	for _, p := range cdnPatterns {
		for _, n := range p.Needles {
			if strings.Contains(strings.ToLower(blob.String()), n) {
				return p.Name
			}
		}
	}
	return ""
}

func appendJSONField(b *strings.Builder, v interface{}) {
	if v == nil {
		return
	}
	j, _ := json.Marshal(v)
	b.Write(j)
}

func parseExpectedIPs(raw string) []string {
	raw = strings.TrimSpace(raw)
	if raw == "" || raw == "[]" {
		return nil
	}
	var ips []string
	_ = json.Unmarshal([]byte(raw), &ips)
	return ips
}

func lookupASN(ctx context.Context, ipStr string) string {
	ip := net.ParseIP(ipStr)
	if ip == nil || ip.To4() == nil {
		return ""
	}
	octets := strings.Split(ipStr, ".")
	if len(octets) != 4 {
		return ""
	}
	query := fmt.Sprintf("%s.%s.%s.%s.origin.asn.cymru.com", octets[3], octets[2], octets[1], octets[0])
	txts, err := monitorDNSResolver.LookupTXT(ctx, query)
	if err != nil || len(txts) == 0 {
		return ""
	}
	parts := strings.SplitN(txts[0], "|", 2)
	if len(parts) == 0 {
		return ""
	}
	return strings.TrimSpace(parts[0])
}

type dnsExpectationResult struct {
	HijackIssues []string
	DetectedCDN  string
	DetectedASNs []string
}

func evaluateDNSExpectations(ctx context.Context, d *DmDomain, rec map[string]interface{}) dnsExpectationResult {
	out := dnsExpectationResult{}
	ips := extractIPList(rec)
	expected := parseExpectedIPs(d.ExpectedIPs)

	if len(expected) > 0 && len(ips) > 0 {
		expSet := map[string]struct{}{}
		for _, ip := range expected {
			expSet[strings.TrimSpace(ip)] = struct{}{}
		}
		matched := false
		for _, ip := range ips {
			if _, ok := expSet[ip]; ok {
				matched = true
				break
			}
		}
		if !matched {
			out.HijackIssues = append(out.HijackIssues,
				fmt.Sprintf("IP 偏离预期: 当前 %s，预期 %s", strings.Join(ips, ", "), strings.Join(expected, ", ")))
		}
	}

	for _, ip := range ips {
		if asn := lookupASN(ctx, ip); asn != "" {
			out.DetectedASNs = append(out.DetectedASNs, asn)
			if exp := strings.TrimSpace(d.ExpectedASN); exp != "" && !strings.EqualFold(exp, asn) {
				out.HijackIssues = append(out.HijackIssues, fmt.Sprintf("ASN 偏离: 当前 AS%s，预期 AS%s", asn, exp))
			}
		}
	}

	out.DetectedCDN = detectCDN(rec)
	if expCDN := strings.TrimSpace(d.ExpectedCDN); expCDN != "" && out.DetectedCDN != "" &&
		!strings.EqualFold(expCDN, out.DetectedCDN) {
		out.HijackIssues = append(out.HijackIssues,
			fmt.Sprintf("CDN 偏离: 当前 %s，预期 %s", out.DetectedCDN, expCDN))
	}

	if out.DetectedCDN != "" {
		rec["detectedCdn"] = out.DetectedCDN
	}
	if len(out.DetectedASNs) > 0 {
		rec["detectedAsns"] = out.DetectedASNs
	}
	return out
}

func (e *Engine) handleDNSIntelAlerts(ctx context.Context, d *DmDomain, res *DmCheckResult, eval dnsExpectationResult) {
	if len(eval.HijackIssues) > 0 {
		msg := strings.Join(eval.HijackIssues, "；")
		title := fmt.Sprintf("[dns_hijack] %s", d.Domain)
		alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "dns_hijack", "CRITICAL", title, msg)
		if err == nil {
			e.dispatchTelegram(ctx, "dns_hijack", "CRITICAL", title, msg, alert)
		}
		if res.Status == statusOK {
			res.Status = statusCritical
		}
	} else if strings.TrimSpace(d.ExpectedIPs) != "" || strings.TrimSpace(d.ExpectedASN) != "" || strings.TrimSpace(d.ExpectedCDN) != "" {
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, "dns_hijack")
	}

	if eval.DetectedCDN == "" {
		return
	}
	prev := strings.TrimSpace(d.LastCDNProvider)
	if prev != "" && !strings.EqualFold(prev, eval.DetectedCDN) {
		_ = e.repo.SaveCDNHistory(ctx, &DmCDNHistory{
			DomainID:         d.ID,
			PreviousProvider: prev,
			CurrentProvider:  eval.DetectedCDN,
			DetectedAt:       time.Now().UTC(),
		})
		title := fmt.Sprintf("[cdn_change] %s", d.Domain)
		msg := fmt.Sprintf("CDN 变更: %s → %s", prev, eval.DetectedCDN)
		alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, "cdn_change", "WARNING", title, msg)
		if err == nil {
			e.dispatchTelegram(ctx, "cdn_change", "WARNING", title, msg, alert)
		}
	}
	_ = e.repo.UpdateDomainCDNProvider(ctx, d.ID, eval.DetectedCDN)
}

package domainmonitor

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"strings"
)

type sslAdvancedReport struct {
	ChainValid    bool     `json:"chainValid"`
	SelfSigned    bool     `json:"selfSigned"`
	WeakAlgorithm bool     `json:"weakAlgorithm"`
	TLSVersion    string   `json:"tlsVersion"`
	Issues        []string `json:"issues,omitempty"`
}

var weakSigAlgs = map[x509.SignatureAlgorithm]struct{}{
	x509.MD2WithRSA:       {},
	x509.MD5WithRSA:       {},
	x509.SHA1WithRSA:      {},
	x509.DSAWithSHA1:      {},
	x509.ECDSAWithSHA1:    {},
	x509.SHA256WithRSAPSS: {}, // keep RSA-PSS as ok actually - remove this
}

func init() {
	delete(weakSigAlgs, x509.SHA256WithRSAPSS)
}

func analyzeSSLAdvanced(state tls.ConnectionState, certs []*x509.Certificate) sslAdvancedReport {
	r := sslAdvancedReport{ChainValid: true, TLSVersion: tlsVersionName(state.Version)}
	if len(certs) == 0 {
		r.ChainValid = false
		r.Issues = append(r.Issues, "无证书")
		return r
	}
	leaf := certs[0]
	if leaf.Issuer.String() == leaf.Subject.String() {
		r.SelfSigned = true
		r.Issues = append(r.Issues, "自签名证书")
	}
	if _, weak := weakSigAlgs[leaf.SignatureAlgorithm]; weak {
		r.WeakAlgorithm = true
		r.Issues = append(r.Issues, "弱签名算法: "+leaf.SignatureAlgorithm.String())
	}
	if state.Version < tls.VersionTLS12 {
		r.Issues = append(r.Issues, "TLS 版本过低: "+r.TLSVersion)
	}
	intermediates := x509.NewCertPool()
	for i := 1; i < len(certs); i++ {
		intermediates.AddCert(certs[i])
	}
	opts := x509.VerifyOptions{
		DNSName:       leaf.DNSNames[0],
		Intermediates: intermediates,
	}
	if len(leaf.DNSNames) == 0 {
		opts.DNSName = leaf.Subject.CommonName
	}
	if _, err := leaf.Verify(opts); err != nil && !r.SelfSigned {
		r.ChainValid = false
		r.Issues = append(r.Issues, "证书链验证失败: "+err.Error())
	}
	return r
}

func tlsVersionName(v uint16) string {
	switch v {
	case tls.VersionTLS10:
		return "TLS1.0"
	case tls.VersionTLS11:
		return "TLS1.1"
	case tls.VersionTLS12:
		return "TLS1.2"
	case tls.VersionTLS13:
		return "TLS1.3"
	default:
		return fmt.Sprintf("0x%04x", v)
	}
}

func sslStatusFromAdvanced(baseStatus string, adv sslAdvancedReport) string {
	st := baseStatus
	if !adv.ChainValid || adv.SelfSigned {
		st = statusCritical
	} else if adv.WeakAlgorithm || strings.HasPrefix(adv.TLSVersion, "TLS1.0") || adv.TLSVersion == "TLS1.1" {
		if statusRank(st) < statusRank(statusError) {
			st = statusError
		}
	}
	return st
}

func (e *Engine) handleSSLAdvancedAlerts(ctx context.Context, d *DmDomain, adv sslAdvancedReport) {
	if len(adv.Issues) == 0 {
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, "ssl_chain_fail")
		_ = e.repo.ResolveAlertsByType(ctx, d.ID, "ssl_weak")
		return
	}
	severity := "WARNING"
	if !adv.ChainValid || adv.SelfSigned {
		severity = "CRITICAL"
	}
	msg := strings.Join(adv.Issues, "；")
	alertType := "ssl_weak"
	if !adv.ChainValid || adv.SelfSigned {
		alertType = "ssl_chain_fail"
	}
	title := fmt.Sprintf("[%s] %s", alertType, d.Domain)
	alert, err := e.repo.UpsertOpenAlert(ctx, d.ID, alertType, severity, title, msg)
	if err == nil {
		e.dispatchTelegram(ctx, alertType, severity, title, msg, alert)
	}
}

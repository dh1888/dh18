package domainmonitor

import (
	"encoding/json"
	"fmt"
	"strings"

	"enterprise-agent/backend/internal/proxytransport"
)

// CheckMode 检测执行模式：local/proxy 在监控中心 RunChecks 执行；probe 由远程探针执行。
// 现有 HTTP 代理逻辑（performance.go / e.client）不做任何改动；proxy 模式即走 RunChecks 既有路径。
type CheckMode string

const (
	CheckModeLocal CheckMode = "local"
	CheckModeProxy CheckMode = "proxy"
	CheckModeProbe CheckMode = "probe"
)

// DomainCheckStrategy 每项检测的独立策略（JSON 存于 dm_domains.check_strategy）。
type DomainCheckStrategy struct {
	DNS            CheckMode `json:"dns"`
	HTTP           CheckMode `json:"http"`
	SSL            CheckMode `json:"ssl"`
	Whois          CheckMode `json:"whois"`
	Content        CheckMode `json:"content"`
	Screenshot     CheckMode `json:"screenshot"`
	UserSimulation CheckMode `json:"userSimulation"`
}

func parseCheckStrategy(raw string) DomainCheckStrategy {
	raw = strings.TrimSpace(raw)
	if raw == "" || raw == "{}" {
		return DomainCheckStrategy{}
	}
	var s DomainCheckStrategy
	_ = json.Unmarshal([]byte(raw), &s)
	return s
}

func (s DomainCheckStrategy) modeFor(check string) CheckMode {
	switch check {
	case "dns":
		return s.DNS
	case "http":
		return s.HTTP
	case "ssl":
		return s.SSL
	case "whois":
		return s.Whois
	case "content":
		return s.Content
	case "screenshot":
		return s.Screenshot
	case "userSimulation":
		return s.UserSimulation
	default:
		return ""
	}
}

// resolveCheckMode 解析单项检测应在何处执行。空策略时保持历史行为：全部在中心 RunChecks。
func resolveCheckMode(d *DmDomain, check string) CheckMode {
	if d == nil {
		return CheckModeLocal
	}
	if m := parseCheckStrategy(d.CheckStrategy).modeFor(check); m != "" {
		return m
	}
	// 显式开关：未配置细项时按总开关推断
	switch check {
	case "dns", "ssl", "whois", "content":
		if d.EnableProbeDetection {
			return CheckModeProbe
		}
	case "http":
		if d.EnableProbeDetection && !d.EnableProxyDetection {
			return CheckModeProbe
		}
		if d.EnableProxyDetection {
			return CheckModeProxy
		}
	case "screenshot":
		if d.EnableProxyDetection {
			return CheckModeProxy
		}
	case "userSimulation":
		if d.EnableUserSimulation {
			return CheckModeProxy
		}
	}
	return CheckModeLocal
}

func runOnCenter(d *DmDomain, check string) bool {
	return resolveCheckMode(d, check) != CheckModeProbe
}

func runOnProbe(d *DmDomain, check string) bool {
	if d == nil || !d.EnableProbeDetection {
		return false
	}
	return resolveCheckMode(d, check) == CheckModeProbe
}

// ProbeCheckSpec 下发给探针的单项检测配置。
type ProbeCheckSpec struct {
	Type         string `json:"type"`
	URL          string `json:"url,omitempty"`
	UseProxy     bool   `json:"useProxy,omitempty"`
	HttpProxyURL string `json:"httpProxyUrl,omitempty"`
	FastDNS      bool   `json:"fastDns,omitempty"`
	Keywords     []string `json:"keywords,omitempty"`
}

func buildProbeChecks(d *DmDomain, globalProxy string, fastDNS bool) []ProbeCheckSpec {
	if d == nil {
		return nil
	}
	var specs []ProbeCheckSpec
	add := func(check string, spec ProbeCheckSpec) {
		if !runOnProbe(d, check) {
			return
		}
		spec.Type = check
		specs = append(specs, spec)
	}
	if d.EnableDNS {
		add("dns", ProbeCheckSpec{FastDNS: fastDNS})
	}
	if d.EnableHTTP {
		useProxy := d.EnableProxyDetection && strings.TrimSpace(globalProxy) != ""
		add("http", ProbeCheckSpec{
			URL:          probeTargetURL(d, "http"),
			UseProxy:     useProxy,
			HttpProxyURL: strings.TrimSpace(globalProxy),
		})
	}
	if d.EnableSSL {
		add("ssl", ProbeCheckSpec{})
	}
	if d.EnableWhois {
		add("whois", ProbeCheckSpec{})
	}
	if d.EnableContent {
		add("content", ProbeCheckSpec{
			URL:      probeTargetURL(d, "content"),
			UseProxy: true,
			HttpProxyURL: strings.TrimSpace(globalProxy),
			Keywords: parseKeywordList(d.ContentKeywords),
		})
	}
	if d.EnableScreenshot && resolveCheckMode(d, "screenshot") == CheckModeProbe {
		add("screenshot", ProbeCheckSpec{
			URL:          probeTargetURL(d, "screenshot"),
			UseProxy:     true,
			HttpProxyURL: strings.TrimSpace(globalProxy),
		})
	}
	if d.EnableUserSimulation {
		add("userSimulation", ProbeCheckSpec{
			URL:          probeTargetURL(d, "userSimulation"),
			UseProxy:     true,
			HttpProxyURL: strings.TrimSpace(globalProxy),
			Keywords:     parseKeywordList(d.ContentKeywords),
		})
	}
	return specs
}

func probeTargetURL(d *DmDomain, check string) string {
	switch check {
	case "screenshot":
		if u := strings.TrimSpace(d.ScreenshotURL); u != "" {
			return u
		}
	case "content", "userSimulation":
		if u := strings.TrimSpace(d.ContentURL); u != "" {
			return u
		}
	}
	return "https://" + d.Domain
}

func parseKeywordList(raw string) []string {
	raw = strings.TrimSpace(raw)
	if raw == "" || raw == "[]" {
		return nil
	}
	var list []string
	if err := json.Unmarshal([]byte(raw), &list); err != nil {
		return nil
	}
	return list
}

func parseProbeNodeIDs(raw string) []string {
	raw = strings.TrimSpace(raw)
	if raw == "" || raw == "[]" {
		return nil
	}
	var ids []string
	_ = json.Unmarshal([]byte(raw), &ids)
	return ids
}

func proxyOrLocalLabel(globalProxy string) string {
	if strings.TrimSpace(globalProxy) != "" {
		if proxytransport.IsSOCKS(proxytransport.ProxyScheme(globalProxy)) {
			return "SOCKS5"
		}
		return "代理"
	}
	return "本机"
}

func executionPathLabel(d *DmDomain, check, globalProxy string) string {
	mode := resolveCheckMode(d, check)
	switch mode {
	case CheckModeProbe:
		return "探针"
	case CheckModeProxy:
		return proxyOrLocalLabel(globalProxy)
	default:
		switch check {
		case "dns", "whois":
			return "本机"
		case "http", "ssl", "content", "screenshot", "userSimulation":
			return proxyOrLocalLabel(globalProxy)
		default:
			return "本机"
		}
	}
}

func describeDomainCheckPaths(d *DmDomain, globalProxy string) string {
	if d == nil {
		return ""
	}
	type item struct {
		enabled bool
		label   string
		check   string
	}
	items := []item{
		{d.EnableDNS, "DNS", "dns"},
		{d.EnableHTTP, "HTTP", "http"},
		{d.EnableSSL, "SSL", "ssl"},
		{d.EnableWhois, "WHOIS", "whois"},
		{d.EnableContent, "内容", "content"},
		{d.EnableScreenshot, "截图", "screenshot"},
		{d.EnableUserSimulation, "用户模拟", "userSimulation"},
	}
	parts := make([]string, 0, len(items))
	for _, it := range items {
		if !it.enabled {
			continue
		}
		parts = append(parts, fmt.Sprintf("%s·%s", it.label, executionPathLabel(d, it.check, globalProxy)))
	}
	return strings.Join(parts, " | ")
}

func formatGlobalProxyLabel(globalProxy string) string {
	globalProxy = strings.TrimSpace(globalProxy)
	if globalProxy == "" {
		return "HTTP/SSL 检测：本机直连（未配置代理）"
	}
	return proxytransport.ModeLabel(globalProxy) + " " + proxytransport.MaskProxyURL(globalProxy)
}

func maskProxyURL(raw string) string {
	return proxytransport.MaskProxyURL(raw)
}

func probeNodeSelected(d *DmDomain, nodeID string) bool {
	if d == nil || strings.TrimSpace(d.ProbeNodeScope) != "selected" {
		return true
	}
	ids := parseProbeNodeIDs(d.ProbeNodeIDs)
	if len(ids) == 0 {
		return true
	}
	for _, id := range ids {
		if strings.EqualFold(strings.TrimSpace(id), nodeID) {
			return true
		}
	}
	return false
}

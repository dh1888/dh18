package domainmonitor

import (
	"context"
	"encoding/json"
	"strings"
	"time"

	"github.com/google/uuid"
)

const (
	healthNormal   = "normal"
	healthPartial  = "partial"
	healthAbnormal = "abnormal"
	healthCritical = "critical"
)

type ProbeNodeStatus struct {
	NodeID    string    `json:"nodeId"`
	NodeName  string    `json:"nodeName"`
	Country   string    `json:"country"`
	City      string    `json:"city"`
	Status    string    `json:"status"`
	OK        bool      `json:"ok"`
	CheckType string    `json:"checkType"`
	CheckedAt time.Time `json:"checkedAt"`
}

type ProbeReachabilitySummary struct {
	ReachabilityPct float64           `json:"reachabilityPct"`
	HealthLevel     string            `json:"healthLevel"`
	Nodes           []ProbeNodeStatus `json:"nodes"`
	TotalNodes      int               `json:"totalNodes"`
	OkNodes         int               `json:"okNodes"`
}

func nodeResultOK(st string) bool {
	return st == statusOK || st == statusWarning
}

func (e *Engine) aggregateDomainHealth(ctx context.Context, domainID uuid.UUID) error {
	d, err := e.repo.GetDomain(ctx, domainID)
	if err != nil || d == nil {
		return err
	}
	since := time.Now().UTC().Add(-time.Duration(d.CheckInterval*2) * time.Second)
	if since.Before(time.Now().UTC().Add(-24 * time.Hour)) {
		since = time.Now().UTC().Add(-24 * time.Hour)
	}

	latest, err := e.repo.ListLatestProbeResultsByNode(ctx, domainID, "http", since)
	if err != nil {
		return err
	}
	if len(latest) == 0 {
		latest, _ = e.repo.ListLatestProbeResultsByNode(ctx, domainID, "dns", since)
	}

	summary := buildReachabilitySummary(d, latest)
	if len(summary.Nodes) == 0 {
		summary.HealthLevel = healthFromLocalStatuses(d)
		summary.ReachabilityPct = localReachabilityPct(d)
	} else {
		summary.HealthLevel = healthFromProbeSummary(summary, d)
	}

	summaryJSON := mustJSON(summary)
	return e.repo.UpdateDomainAggregation(ctx, domainID, summary.HealthLevel, summary.ReachabilityPct, summaryJSON)
}

func buildReachabilitySummary(d *DmDomain, results []DmCheckResult) ProbeReachabilitySummary {
	out := ProbeReachabilitySummary{HealthLevel: healthNormal, Nodes: []ProbeNodeStatus{}}
	for _, r := range results {
		if r.NodeID == "" || r.NodeID == nodeID {
			continue
		}
		ok := nodeResultOK(r.Status)
		out.Nodes = append(out.Nodes, ProbeNodeStatus{
			NodeID:    r.NodeID,
			NodeName:  r.NodeName,
			Country:   r.Country,
			City:      r.City,
			Status:    r.Status,
			OK:        ok,
			CheckType: r.CheckType,
			CheckedAt: r.CheckedAt,
		})
		if ok {
			out.OkNodes++
		}
	}
	out.TotalNodes = len(out.Nodes)
	if out.TotalNodes > 0 {
		out.ReachabilityPct = float64(out.OkNodes) / float64(out.TotalNodes) * 100
	}
	return out
}

func healthFromProbeSummary(s ProbeReachabilitySummary, d *DmDomain) string {
	if hasLocalCritical(d) || anyNodeStatus(s.Nodes, statusCritical) {
		return healthCritical
	}
	if s.TotalNodes == 0 {
		return healthFromLocalStatuses(d)
	}
	if s.OkNodes == 0 {
		return healthAbnormal
	}
	if s.OkNodes < s.TotalNodes {
		return healthPartial
	}
	if hasLocalError(d) {
		return healthPartial
	}
	return healthNormal
}

func healthFromLocalStatuses(d *DmDomain) string {
	if hasLocalCritical(d) {
		return healthCritical
	}
	if hasLocalError(d) {
		return healthAbnormal
	}
	stati := []string{d.LastDNSStatus, d.LastHTTPStatus, d.LastSSLStatus, d.LastWhoisStatus, d.LastContentStatus, d.LastScreenshotStatus}
	hasWarning := false
	for _, st := range stati {
		if st == statusWarning {
			hasWarning = true
		}
	}
	if hasWarning {
		return healthPartial
	}
	return healthNormal
}

func localReachabilityPct(d *DmDomain) float64 {
	stati := []string{d.LastDNSStatus, d.LastHTTPStatus, d.LastSSLStatus}
	ok, total := 0, 0
	for _, st := range stati {
		if st == "" || st == "unknown" {
			continue
		}
		total++
		if nodeResultOK(st) {
			ok++
		}
	}
	if total == 0 {
		return 100
	}
	return float64(ok) / float64(total) * 100
}

func hasLocalCritical(d *DmDomain) bool {
	for _, st := range []string{d.LastDNSStatus, d.LastHTTPStatus, d.LastSSLStatus, d.LastWhoisStatus, d.LastContentStatus} {
		if st == statusCritical {
			return true
		}
	}
	return false
}

func hasLocalError(d *DmDomain) bool {
	for _, st := range []string{d.LastDNSStatus, d.LastHTTPStatus, d.LastSSLStatus, d.LastWhoisStatus, d.LastContentStatus} {
		if st == statusError || st == statusCritical {
			return true
		}
	}
	return false
}

func anyNodeStatus(nodes []ProbeNodeStatus, want string) bool {
	for _, n := range nodes {
		if n.Status == want {
			return true
		}
	}
	return false
}

func parseProbeSummary(raw string) ProbeReachabilitySummary {
	var s ProbeReachabilitySummary
	_ = json.Unmarshal([]byte(raw), &s)
	return s
}

func mergeCheckStatuses(stati ...string) string {
	worst := statusOK
	for _, st := range stati {
		st = strings.TrimSpace(st)
		if st == "" || st == "unknown" {
			continue
		}
		if statusRank(st) > statusRank(worst) {
			worst = st
		}
	}
	return worst
}

func statusRank(st string) int {
	switch st {
	case statusCritical:
		return 4
	case statusError:
		return 3
	case statusWarning:
		return 2
	case statusOK:
		return 1
	default:
		return 0
	}
}

func (e *Engine) GetDomainReachability(ctx context.Context, domainID uuid.UUID) (*ProbeReachabilitySummary, error) {
	d, err := e.repo.GetDomain(ctx, domainID)
	if err != nil || d == nil {
		return nil, err
	}
	if strings.TrimSpace(d.ProbeNodeSummary) != "" && d.ProbeNodeSummary != "{}" {
		s := parseProbeSummary(d.ProbeNodeSummary)
		if len(s.Nodes) > 0 {
			return &s, nil
		}
	}
	_ = e.aggregateDomainHealth(ctx, domainID)
	d, _ = e.repo.GetDomain(ctx, domainID)
	if d == nil {
		return &ProbeReachabilitySummary{}, nil
	}
	s := parseProbeSummary(d.ProbeNodeSummary)
	return &s, nil
}

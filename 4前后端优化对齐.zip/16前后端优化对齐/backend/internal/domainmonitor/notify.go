package domainmonitor

import (
	"fmt"
	"strings"
	"time"
)

func alertTypeLabel(alertType string) string {
	labels := map[string]string{
		"dns_fail":        "DNS 故障",
		"http_fail":       "HTTP 不可达",
		"ssl_expire":      "SSL 证书到期",
		"ssl_mismatch":    "SSL 域名不匹配",
		"whois_expire":    "WHOIS 到期",
		"content_change":  "页面内容变更",
		"screenshot_fail": "截图失败",
		"monitor_report":  "监控检测报告",
		"ip_change":       "IP 变更",
		"dns_change":      "DNS 记录变更",
		"http_redirect":   "HTTP 跳转异常",
		"blacklist_hit":   "黑名单命中",
		"user_sim_fail":     "用户模拟异常",
		"dns_hijack":      "DNS 劫持",
		"cdn_change":      "CDN 变更",
		"ssl_chain_fail":  "SSL 证书链异常",
		"ssl_weak":        "SSL 弱算法/TLS",
	}
	if label, ok := labels[alertType]; ok {
		return label
	}
	return alertType
}

func severityLabel(severity string) string {
	switch strings.ToUpper(strings.TrimSpace(severity)) {
	case "CRITICAL":
		return "严重"
	case "ERROR":
		return "错误"
	case "WARNING":
		return "警告"
	case "INFO":
		return "信息"
	default:
		return severity
	}
}

func severityEmoji(severity string) string {
	switch strings.ToUpper(strings.TrimSpace(severity)) {
	case "CRITICAL":
		return "🔴"
	case "ERROR":
		return "🟠"
	case "WARNING":
		return "🟡"
	default:
		return "🔔"
	}
}

func checkStatusLabel(st string) string {
	switch strings.ToLower(strings.TrimSpace(st)) {
	case "ok":
		return "正常"
	case "warning":
		return "警告"
	case "error":
		return "异常"
	case "critical":
		return "严重"
	default:
		return st
	}
}

func extractAlertDomain(title string) string {
	title = strings.TrimSpace(title)
	if idx := strings.Index(title, "] "); idx >= 0 && strings.HasPrefix(title, "[") {
		return strings.TrimSpace(title[idx+2:])
	}
	return title
}

func formatTelegramAlertText(settings *CheckSettings, alertType, severity, title, msg string) string {
	if settings == nil {
		settings = &CheckSettings{ReportTimezone: "UTC"}
	}
	tz := strings.TrimSpace(settings.ReportTimezone)
	if tz == "" {
		tz = "UTC"
	}
	loc := parseReportTimezone(tz)
	now := time.Now().In(loc)
	tzLabel := formatReportTimezoneLabel(tz, loc)

	typeLabel := alertTypeLabel(alertType)
	domain := extractAlertDomain(title)
	detail := formatAlertDetail(alertType, msg)

	var b strings.Builder
	b.WriteString(fmt.Sprintf("%s %s\n\n", severityEmoji(severity), typeLabel))
	if domain != "" {
		b.WriteString(fmt.Sprintf("🌐 域名：%s\n", domain))
	}
	b.WriteString(fmt.Sprintf("⚠️ 级别：%s\n", severityLabel(severity)))
	b.WriteString(fmt.Sprintf("🕐 时间：%s (%s)\n", now.Format("2006-01-02 15:04"), tzLabel))
	if server := strings.TrimSpace(settings.ReportServerLabel); server != "" {
		b.WriteString(fmt.Sprintf("📍 来源：%s\n", server))
	}
	if detail != "" {
		b.WriteString("\n📋 详情\n")
		for _, line := range splitDetailLines(detail) {
			b.WriteString("• ")
			b.WriteString(line)
			b.WriteString("\n")
		}
	}
	return strings.TrimRight(b.String(), "\n")
}

func formatTelegramTestText(settings *CheckSettings, botName, botUsername, chatID string) string {
	if settings == nil {
		settings = &CheckSettings{ReportTimezone: "UTC"}
	}
	tz := strings.TrimSpace(settings.ReportTimezone)
	if tz == "" {
		tz = "UTC"
	}
	loc := parseReportTimezone(tz)
	now := time.Now().In(loc)
	tzLabel := formatReportTimezoneLabel(tz, loc)

	var b strings.Builder
	b.WriteString("✅ 域名监控系统测试成功\n\n")
	b.WriteString(fmt.Sprintf("🤖 机器人：%s (@%s)\n", botName, botUsername))
	b.WriteString(fmt.Sprintf("💬 群组：%s\n", chatID))
	b.WriteString(fmt.Sprintf("🕐 时间：%s (%s)\n", now.Format("2006-01-02 15:04"), tzLabel))
	if server := strings.TrimSpace(settings.ReportServerLabel); server != "" {
		b.WriteString(fmt.Sprintf("📍 来源：%s\n", server))
	}
	return strings.TrimRight(b.String(), "\n")
}

func formatAlertDetail(alertType, msg string) string {
	msg = strings.TrimSpace(msg)
	if msg == "" {
		return defaultAlertDetail(alertType)
	}
	if msg == alertType {
		return defaultAlertDetail(alertType)
	}
	return localizeAlertMessage(msg)
}

func defaultAlertDetail(alertType string) string {
	switch alertType {
	case "ip_change":
		return "解析 IP 与上次检测结果不一致"
	case "dns_change":
		return "DNS 记录与上次检测结果不一致"
	case "http_redirect":
		return "HTTP 发生跨域或异常跳转"
	case "screenshot_fail":
		return "页面截图失败"
	case "blacklist_hit":
		return "解析 IP 命中 DNS 黑名单"
	default:
		return ""
	}
}

func localizeAlertMessage(msg string) string {
	if strings.HasPrefix(strings.TrimSpace(msg), "{") {
		return msg
	}
	parts := splitDetailParts(msg)
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		if line := localizeIssueLine(part); line != "" {
			out = append(out, line)
		}
	}
	return strings.Join(out, "\n")
}

func splitDetailParts(msg string) []string {
	msg = strings.ReplaceAll(msg, "；", ";")
	parts := strings.Split(msg, ";")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func splitDetailLines(msg string) []string {
	lines := strings.Split(msg, "\n")
	out := make([]string, 0, len(lines))
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line != "" {
			out = append(out, line)
		}
	}
	return out
}

func localizeIssueLine(s string) string {
	s = strings.TrimSpace(s)
	replacements := [][2]string{
		{"403 Forbidden", "403 禁止访问"},
		{"Access Denied / Geo Block", "访问被拒 / 地区封锁"},
		{"Cloudflare Challenge", "Cloudflare 人机验证拦截"},
		{"Forbidden page", "页面被禁止访问"},
		{"abnormal redirect to ", "异常跳转到 "},
		{"missing keyword: ", "缺少关键词: "},
		{"missing keywords: ", "缺少关键词: "},
		{"检测异常: ", "检测异常: "},
		{" / status=", "，状态="},
	}
	for _, pair := range replacements {
		s = strings.ReplaceAll(s, pair[0], pair[1])
	}
	if strings.Contains(s, "，状态=") {
		if idx := strings.LastIndex(s, "，状态="); idx >= 0 {
			st := s[idx+len("，状态="):]
			s = s[:idx] + "（" + checkStatusLabel(st) + "）"
		}
	}
	if strings.Contains(s, "@") && strings.Contains(s, "(") && !strings.Contains(s, "被列入") {
		// 1.2.3.4 (zen.spamhaus.org) -> IP 1.2.3.4 被列入 zen.spamhaus.org
		if ip, zone, ok := parseBlacklistHit(s); ok {
			return fmt.Sprintf("IP %s 被列入 %s", ip, zone)
		}
	}
	return s
}

func parseBlacklistHit(s string) (ip, zone string, ok bool) {
	open := strings.Index(s, "(")
	close := strings.LastIndex(s, ")")
	if open <= 0 || close <= open {
		return "", "", false
	}
	ip = strings.TrimSpace(s[:open])
	zone = strings.TrimSpace(s[open+1 : close])
	return ip, zone, ip != "" && zone != ""
}

func alertMessageForCheck(alertType, st string, res *DmCheckResult) string {
	switch alertType {
	case "dns_fail":
		return dnsIssueText(res)
	case "http_fail":
		return httpIssueText(res, st)
	case "ssl_fail":
		return sslIssueText(res)
	case "whois_fail":
		return whoisIssueText(res)
	case "content_change":
		return contentIssueText(res)
	case "screenshot_fail":
		return "页面截图失败"
	case "user_sim_fail":
		return userSimulationIssueText(res)
	default:
		if label := checkStatusLabel(st); label != "" && label != st {
			return fmt.Sprintf("检测异常（%s）", label)
		}
		return "检测异常"
	}
}

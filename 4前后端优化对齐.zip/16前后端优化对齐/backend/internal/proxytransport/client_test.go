package proxytransport

import "testing"

func TestNormalizeProxyURL_NonStandardSOCKS(t *testing.T) {
	got, err := NormalizeProxyURL("sock5://216.238.102.241:1234:admin:admin520")
	if err != nil {
		t.Fatal(err)
	}
	want := "socks5://admin:admin520@216.238.102.241:1234"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestNormalizeProxyURL_StandardSOCKS(t *testing.T) {
	got, err := NormalizeProxyURL("socks5://admin:admin520@216.238.102.241:1234")
	if err != nil {
		t.Fatal(err)
	}
	if got != "socks5://admin:admin520@216.238.102.241:1234" {
		t.Fatalf("unexpected: %s", got)
	}
}

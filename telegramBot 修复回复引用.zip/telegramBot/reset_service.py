import logging
import asyncio
import time
import traceback
import asyncpg
from datetime import datetime, timedelta, date
from typing import Dict, Optional, Any, List
from performance import global_cache

from database import db, parse_sql_row_count
from fine_calc import compute_activity_overtime_fine
from fault_tolerance import Watchdog
from handover_manager import handover_manager

from retry_decorator import (
    with_handover_retry,
    with_execution_phase,
    RetryableError,
    NonRetryableError,
)

# ========== 新增结束 ==========

logger = logging.getLogger("GroupCheckInBot.ResetService")


# ========== 新增：换班专用异常类 ==========
class HandoverRetryableError(RetryableError):
    """换班可重试异常 - 遇到这类错误会自动重试"""

    pass


class HandoverNonRetryableError(NonRetryableError):
    """换班不可重试异常 - 遇到这类错误直接抛出，不会重试"""

    pass


# ========== 新增结束 ==========

_reset_locks: Dict[int, asyncio.Lock] = {}
_reset_locks_guard = asyncio.Lock()


async def _get_reset_lock(chat_id: int) -> asyncio.Lock:
    async with _reset_locks_guard:
        if chat_id not in _reset_locks:
            _reset_locks[chat_id] = asyncio.Lock()
        return _reset_locks[chat_id]


# ========== 新增：重试回调函数 ==========
async def _on_handover_retry(context: dict, retry_num: int, delay: float):
    """重试前的回调函数"""
    chat_id = context.get("chat_id", "?")
    target_date = context.get("target_date", "?")
    logger.warning(
        f"🔄 [{chat_id}] 换班执行重试 {retry_num} 次，等待 {delay:.1f}秒 "
        f"(目标日期: {target_date})"
    )


async def _on_handover_failure(context: dict, exception: Exception, retry_count: int):
    """最终失败后的回调函数"""
    chat_id = context.get("chat_id", "?")
    target_date = context.get("target_date", "?")
    logger.error(
        f"❌ [{chat_id}] 换班执行最终失败\n"
        f"   ├─ 目标日期: {target_date}\n"
        f"   ├─ 重试次数: {retry_count}\n"
        f"   └─ 错误类型: {type(exception).__name__}\n"
        f"   └─ 错误信息: {exception}"
    )

    # 发送通知给管理员（可选，保留现有通知机制）
    try:
        from utils import notification_service

        await notification_service.send_notification(
            chat_id=None,  # 发送给所有管理员
            text=(
                f"⚠️ <b>换班执行失败</b>\n\n"
                f"群组: <code>{chat_id}</code>\n"
                f"目标日期: <code>{target_date}</code>\n"
                f"重试次数: <code>{retry_count}</code>\n"
                f"错误: <code>{str(exception)[:200]}</code>"
            ),
            notification_type="admin",
        )
    except Exception as e:
        logger.error(f"发送失败通知出错: {e}")


# ========== 新增结束 ==========



# ========== 每日重置逻辑 =========
async def reset_daily_data_if_needed(
    chat_id: int, uid: int, business_date: date = None
) -> date:
    """按业务日期重置单个用户数据（群组级硬重置由定时任务负责）"""
    try:
        now = db.get_beijing_time()
        if business_date is None:
            business_date = await handover_manager.get_business_date(chat_id, now)

        user_data = await db.get_user_cached(chat_id, uid)
        if not user_data:
            await db.init_user(chat_id, uid, "用户", business_date=business_date)
            await db.update_user_last_updated(chat_id, uid, business_date)
            return business_date

        last_updated_raw = user_data.get("last_updated")

        if isinstance(last_updated_raw, datetime):
            last_updated = last_updated_raw.date()
        elif isinstance(last_updated_raw, str):
            try:
                last_updated = datetime.fromisoformat(
                    last_updated_raw.replace("Z", "+00:00")
                ).date()
            except Exception:
                try:
                    last_updated = datetime.strptime(
                        last_updated_raw, "%Y-%m-%d"
                    ).date()
                except Exception:
                    last_updated = business_date
        else:
            last_updated = business_date

        if last_updated < business_date:
            logger.info(f"🔄 重置用户数据: {chat_id}-{uid} | 业务日期 {business_date}")

            if user_data.get("current_activity"):
                act = user_data["current_activity"]
                start_time_str = user_data["activity_start_time"]
                try:
                    start_time = datetime.fromisoformat(start_time_str)
                    elapsed = int((now - start_time).total_seconds())

                    shift = user_data.get("shift", "day")

                    record_result = await handover_manager.record_activity(
                        chat_id, uid, act, elapsed, now
                    )
                    forced_date = record_result["business_date"]

                    await db.complete_user_activity(
                        chat_id=chat_id,
                        user_id=uid,
                        activity=act,
                        elapsed_time=elapsed,
                        fine_amount=0,
                        is_overtime=False,
                        shift=shift,
                        forced_date=forced_date,
                    )

                    logger.info(
                        f"🔄 自动结束跨期活动: {uid} - {act} (归到 {forced_date})"
                    )
                except Exception as e:
                    logger.error(f"自动结束活动失败: {e}")

            await db.reset_user_daily_data(chat_id, uid, business_date)
            await db.update_user_last_updated(chat_id, uid, business_date)

        return business_date

    except Exception as e:
        logger.error(f"重置检查失败 {chat_id}-{uid}: {e}")
        try:
            fallback_date = db.get_beijing_time().date()
            await db.init_user(chat_id, uid, "用户", business_date=fallback_date)
            await db.update_user_last_updated(chat_id, uid, fallback_date)
            return fallback_date
        except Exception as init_error:
            logger.error(f"用户初始化也失败: {init_error}")
            return db.get_beijing_time().date()



# ========== 1. 调度入口 ==========
async def is_near_reset_window(
    chat_id: int, now: datetime, margin_seconds: int = 3600
) -> bool:
    """是否在重置执行窗口附近（用于降低非窗口期的后台检查频率）"""
    group_data = await db.get_group_cached(chat_id)
    if not group_data:
        return False

    reset_hour = group_data.get("reset_hour", 0)
    reset_minute = group_data.get("reset_minute", 0)
    natural_today = now.date()

    reset_time = datetime.combine(
        natural_today,
        datetime.strptime(f"{reset_hour:02d}:{reset_minute:02d}", "%H:%M").time(),
    ).replace(tzinfo=now.tzinfo)
    execute_time = reset_time + timedelta(hours=2)

    candidates = [
        execute_time,
        execute_time - timedelta(days=1),
        execute_time + timedelta(days=1),
    ]
    return any(abs((now - dt).total_seconds()) <= margin_seconds for dt in candidates)


# ===== 修改：为主入口函数添加重试装饰器 =====
@with_handover_retry(
    max_retries=3,
    base_delay=10,
    max_delay=300,
    retryable_exceptions=(
        ConnectionError,
        TimeoutError,
        asyncio.TimeoutError,
        HandoverRetryableError,
    ),
    non_retryable_exceptions=(
        ValueError,
        TypeError,
        HandoverNonRetryableError,
    ),
    on_retry=_on_handover_retry,
    on_failure=_on_handover_failure,
)
# ===== 修改结束 =====
async def handle_hard_reset(
    chat_id: int,
    operator_id: Optional[int] = None,
    target_date: Optional[date] = None,
) -> bool:
    """
    硬重置总调度入口 - 纯双班模式（带重试保护 + 群组锁）
    """
    lock = await _get_reset_lock(chat_id)
    if lock.locked():
        logger.info(f"⏭️ 群组 {chat_id} 重置已在进行中，跳过")
        return False

    async with lock:
        try:
            logger.info(f"🔄 [双班模式] 群组 {chat_id} 执行双班硬重置")

            if target_date:
                success = await _dual_shift_hard_reset(
                    chat_id, operator_id, target_date
                )
            else:
                success = await _dual_shift_hard_reset(chat_id, operator_id)

            if success:
                logger.info(f"✅ [双班硬重置] 群组 {chat_id} 执行成功")
            else:
                logger.error(f"❌ [双班硬重置] 群组 {chat_id} 执行失败")

            return success

        except Exception as e:
            logger.error(f"❌ [双班硬重置] 群组 {chat_id} 异常: {e}")
            logger.error(traceback.format_exc())
            return False


# ========== 2. 双班硬重置核心流程 ==========
async def _dual_shift_hard_reset(
    chat_id: int,
    operator_id: Optional[int] = None,
    forced_target_date: Optional[date] = None,
) -> bool:
    """双班硬重置主流程（修复版-确保下班统计正确）"""

    # ===== 1. 创建看门狗，保护整个流程 =====
    watchdog = Watchdog(timeout=300, name=f"dual_reset_{chat_id}")
    # ===== 结束 =====

    try:
        now = db.get_beijing_time()
        # 喂狗：开始处理
        watchdog.feed()

        date_range = await db.get_business_date_range(chat_id, now)
        business_today = date_range["business_today"]
        business_yesterday = date_range["business_yesterday"]
        business_day_before = date_range["business_day_before"]
        natural_today = date_range["natural_today"]

        logger.info(
            f"📅 [双班重置] 日期信息:\n"
            f"   • 自然今天: {natural_today}\n"
            f"   • 业务今天: {business_today}\n"
            f"   • 业务昨天: {business_yesterday}"
        )

        await db.init_group(chat_id)

        target_date: Optional[date] = forced_target_date
        in_execution_window = forced_target_date is not None

        if not forced_target_date:
            group_data = await db.get_group_cached(chat_id)
            reset_hour = group_data.get("reset_hour", 0) if group_data else 0
            reset_minute = group_data.get("reset_minute", 0) if group_data else 0

            reset_time_natural_today = datetime.combine(
                natural_today,
                datetime.strptime(
                    f"{reset_hour:02d}:{reset_minute:02d}", "%H:%M"
                ).time(),
            ).replace(tzinfo=now.tzinfo)

            execute_time_today = reset_time_natural_today + timedelta(hours=2)

            reset_time_natural_yesterday = datetime.combine(
                natural_today - timedelta(days=1),
                datetime.strptime(
                    f"{reset_hour:02d}:{reset_minute:02d}", "%H:%M"
                ).time(),
            ).replace(tzinfo=now.tzinfo)

            execute_time_yesterday = reset_time_natural_yesterday + timedelta(hours=2)

            EXECUTION_WINDOW = 300

            time_to_today = abs((now - execute_time_today).total_seconds())
            time_to_yesterday = abs((now - execute_time_yesterday).total_seconds())

            logger.info(
                f"📅 重置窗口检查:\n"
                f"   ├─ 当前时间: {now.strftime('%H:%M:%S')}\n"
                f"   ├─ 今日执行窗口: {execute_time_today.strftime('%H:%M')} ±{EXECUTION_WINDOW/60}分钟\n"
                f"   ├─ 昨日执行窗口: {execute_time_yesterday.strftime('%H:%M')} ±{EXECUTION_WINDOW/60}分钟\n"
                f"   ├─ 今日时间差: {time_to_today:.0f}秒\n"
                f"   └─ 昨日时间差: {time_to_yesterday:.0f}秒"
            )

            if time_to_today <= EXECUTION_WINDOW:
                target_date = business_yesterday
                in_execution_window = True
                logger.info(f"📅 正常执行窗口，目标日期: {target_date}")

            elif time_to_yesterday <= EXECUTION_WINDOW:
                if not await db.is_reset_completed(chat_id, business_yesterday):
                    target_date = business_yesterday
                    in_execution_window = True
                    logger.warning(
                        f"⚠️ 补执行场景，目标日期: {target_date}（昨天未执行）"
                    )
                else:
                    logger.info(f"✅ 昨天已执行，跳过补执行")
            else:
                logger.debug(f"⏳ 不在执行窗口内")

        pending_cleared = await _process_pending_reset_dates(
            chat_id,
            business_today,
            exclude_date=target_date if in_execution_window else None,
        )
        if pending_cleared:
            logger.info(
                f"✅ [待办重置] 群组 {chat_id} 本次补处理 {pending_cleared} 个日期"
            )

        if not in_execution_window or target_date is None:
            # 不在窗口内属于正常跳过，不应视为失败
            return True

        if forced_target_date:
            logger.info(f"🎯 [双班重置] 使用强制目标日期: {target_date}")

        # 喂狗：日期计算完成
        watchdog.feed()

        if await db.is_reset_completed(chat_id, target_date):
            logger.info(
                f"⏭️ 群组 {chat_id} 日期 {target_date} 已重置完成，跳过"
            )
            return True

        reset_flag_key = f"dual_reset:{chat_id}:{target_date.strftime('%Y%m%d')}"
        if await global_cache.get(reset_flag_key):
            logger.info(f"⏭️ 群组 {chat_id} 今天已完成双班重置，跳过")
            return True

        group_data = await db.get_group_cached(chat_id)
        if not group_data:
            logger.warning(f"⚠️ [双班硬重置] 群组 {chat_id} 没有配置数据，跳过重置")
            return False

        reset_hour = group_data.get("reset_hour", 0)
        reset_minute = group_data.get("reset_minute", 0)

        logger.info(
            f"🚀 [双班硬重置] 开始执行\n"
            f"   ┌─────────────────────────────────\n"
            f"   ├─ 群组ID: {chat_id}\n"
            f"   ├─ 当前时间: {now.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"   ├─ 自然今天: {natural_today}\n"
            f"   ├─ 业务今天: {business_today}\n"
            f"   ├─ 目标日期: {target_date}\n"
            f"   ├─ 重置时间: {reset_hour:02d}:{reset_minute:02d}\n"
            f"   └─ 操作员: {operator_id or '系统'}"
        )

        total_start_time = time.time()

        force_stats = {
            "total": 0,
            "success": 0,
            "failed": 0,
            "day_shift": {"total": 0, "success": 0, "failed": 0},
            "night_shift": {"total": 0, "success": 0, "failed": 0},
            "details": [],
        }

        complete_stats = {
            "total": 0,
            "success": 0,
            "failed": 0,
            "day_shift": {"total": 0, "success": 0, "failed": 0},
            "night_shift": {"total": 0, "success": 0, "failed": 0},
            "details": [],
        }

        # ===== 🎯 修复点1：先执行补全下班记录 =====
        logger.info(f"📊 [步骤1/5] 开始补全未打卡的下班记录...")

        # 先执行补全下班记录
        try:
            complete_stats = await watchdog.run(
                _complete_missing_work_ends(chat_id, target_date, business_today)
            )
            logger.info(
                f"✅ 补全下班记录完成: {complete_stats['success']}/{complete_stats['total']}"
            )
        except Exception as e:
            logger.error(f"❌ [补全下班记录] 失败: {e}")
            logger.error(traceback.format_exc())
        watchdog.feed()

        # ===== 🎯 修复点2：再执行强制结束活动 =====
        logger.info(f"📊 [步骤2/5] 开始强制结束未完成活动...")

        try:
            force_stats = await watchdog.run(
                _force_end_all_unfinished_shifts(
                    chat_id, now, target_date, business_today
                )
            )
            logger.info(
                f"✅ 强制结束活动完成: {force_stats['success']}/{force_stats['total']}"
            )
        except Exception as e:
            logger.error(f"❌ [强制结束活动] 失败: {e}")
            logger.error(traceback.format_exc())
        watchdog.feed()

        # ===== 🎯 修复点3：添加详细日志，记录补全的下班记录 =====
        if complete_stats["details"]:
            logger.info("📝 已补全的下班记录详情:")
            for detail in complete_stats["details"]:
                if detail.get("success"):
                    logger.info(
                        f"   ✅ 用户{detail['user_id']} {detail['shift']}班次 "
                        f"下班时间:{detail.get('work_end_time', '未知')} "
                        f"罚款:{detail.get('fine', 0)}"
                    )

        logger.info(f"📊 [步骤3/5] 导出并归档目标日期数据...")
        export_start = time.time()

        try:
            export_success = await watchdog.run(
                _finalize_reset_date(
                    chat_id,
                    target_date,
                    business_today,
                    skip_export=False,
                )
            )
        except asyncio.TimeoutError:
            logger.error(f"⏰ [数据导出/清理] 超时，将标记为重试")
            raise HandoverRetryableError(f"归档操作超时: {chat_id}")
        watchdog.feed()

        export_time = time.time() - export_start
        cleanup_stats: Dict[str, int] = {}
        deleted_count = 0
        cleanup_skipped = not export_success

        if cleanup_skipped:
            logger.error(
                f"❌ [双班重置] 群组 {chat_id} 归档 {target_date} 失败，"
                f"数据已保留，将在后续任务中自动重试"
            )
            try:
                from utils import notification_service

                await notification_service.send_notification(
                    chat_id=None,
                    text=(
                        f"⚠️ <b>重置导出失败，数据未清理</b>\n\n"
                        f"群组: <code>{chat_id}</code>\n"
                        f"目标日期: <code>{target_date}</code>\n"
                        f"💡 系统将在后续重置循环中自动重试导出与清理"
                    ),
                    notification_type="admin",
                )
            except Exception as notify_err:
                logger.warning(f"⚠️ 导出失败通知发送失败: {notify_err}")
        else:
            logger.info(f"📊 [步骤4/5] 清除过期班次状态...")

            try:
                if not db.pool or not db._initialized:
                    logger.error("数据库连接池未初始化")
                    return False
                async with db.pool.acquire() as conn:
                    result = await watchdog.run(
                        conn.execute(
                            """
                        DELETE FROM group_shift_state 
                        WHERE chat_id = $1 AND record_date < $2
                        """,
                            chat_id,
                            business_today,
                        )
                    )
                    deleted_count = parse_sql_row_count(result, "DELETE")

                    if deleted_count > 0:
                        logger.info(f"✅ 已清除 {deleted_count} 个过期班次状态")

                        keys_to_remove = [
                            key
                            for key in db._cache.keys()
                            if key.startswith(f"shift_state:{chat_id}:")
                        ]
                        for key in keys_to_remove:
                            db._cache.pop(key, None)
                            db._cache_ttl.pop(key, None)
                    else:
                        logger.info("✅ 没有需要清除的班次状态")

            except asyncio.TimeoutError:
                logger.error(f"⏰ [清除班次状态] 超时")
            except Exception as e:
                logger.error(f"❌ [清除班次状态] 失败: {e}")
            watchdog.feed()

        try:
            asyncio.create_task(
                _send_reset_notification(
                    chat_id,
                    force_stats,
                    complete_stats,
                    export_success,
                    cleanup_stats,
                    now,
                    cleanup_skipped=cleanup_skipped,
                )
            )
        except Exception as e:
            logger.error(f"❌ [发送通知] 失败: {e}")

        if not export_success:
            return False

        logger.info(f"✅ [双班重置] 群组 {chat_id} 执行成功，已设置幂等标记")

        total_time = time.time() - total_start_time

        # ===== 🎯 修复点4：在最终日志中添加上班/下班统计 =====
        logger.info(
            f"🎉 [双班硬重置完成] 群组 {chat_id}\n"
            f"   ├─ 目标日期: {target_date}\n"
            f"   ├─ 补全下班记录: {complete_stats['success']}/{complete_stats['total']}\n"
            f"   │   ├─ 白班: {complete_stats['day_shift']['success']}/{complete_stats['day_shift']['total']}\n"
            f"   │   └─ 夜班: {complete_stats['night_shift']['success']}/{complete_stats['night_shift']['total']}\n"
            f"   ├─ 强制结束活动: {force_stats['success']}/{force_stats['total']}\n"
            f"   ├─ 导出成功: {export_success}\n"
            f"   ├─ 清理记录: {sum(v for k, v in cleanup_stats.items() if k != 'users_reset')}条\n"
            f"   ├─ 重置用户: {cleanup_stats.get('users_reset', 0)}人\n"
            f"   ├─ 清除班次状态: {deleted_count}个\n"
            f"   └─ 总耗时: {total_time:.2f}秒"
        )

        return True

    except asyncio.TimeoutError:
        # ===== 6. 看门狗超时处理 =====
        logger.error(
            f"⏰ [双班硬重置] 整体超时 {chat_id}\n"
            f"   ├─ 目标日期: {target_date if 'target_date' in locals() else 'unknown'}\n"
            f"   └─ 超时时间: 300秒"
        )
        # 包装为可重试异常，让外层重试机制处理
        raise HandoverRetryableError(f"换班整体执行超时: {chat_id}")
        # ===== 结束 =====

    except Exception as e:
        logger.error(
            f"❌ [双班硬重置] 失败 {chat_id}\n"
            f"   ├─ 错误类型: {type(e).__name__}\n"
            f"   ├─ 错误信息: {e}\n"
            f"   └─ 堆栈: {traceback.format_exc()}"
        )
        return False


# ========== 新增：批量获取活动配置 ==========
async def _get_activity_configs_batch(activities: List[str]) -> Dict[str, Dict]:
    """
    批量获取活动配置
    返回格式: {
        '活动名': {
            'time_limit_seconds': int,
            'fine_rates': Dict[str, int]
        }
    }
    """
    if not activities:
        return {}

    # 从缓存获取所有活动配置（只查询一次数据库）
    all_limits = await db.get_activity_limits_cached()
    all_fines = await db.get_fine_rates()

    result = {}
    unique_activities = set(activities)

    for activity in unique_activities:
        time_limit_min = all_limits.get(activity, {}).get("time_limit", 0)
        result[activity] = {
            "time_limit_seconds": time_limit_min * 60,
            "fine_rates": all_fines.get(activity, {}),
        }

    logger.debug(f"📊 批量加载活动配置: {len(result)} 个活动: {list(result.keys())}")
    return result


# ========== 3. 统一强制结束所有未完成活动（优化版）==========
@with_execution_phase("force_end_activities")
async def _force_end_all_unfinished_shifts(
    chat_id: int, now: datetime, target_date: date, business_today: date
) -> Dict[str, Any]:
    """强制结束所有进行中的活动（带看门狗保护）"""
    stats = {
        "total": 0,
        "success": 0,
        "failed": 0,
        "day_shift": {"total": 0, "success": 0, "failed": 0},
        "night_shift": {"total": 0, "success": 0, "failed": 0},
        "details": [],
    }

    # ===== 创建子任务看门狗 =====
    watchdog = Watchdog(timeout=120, name=f"force_end_{chat_id}")
    # ===== 结束 =====

    try:
        if not db.pool or not db._initialized:
            logger.error("数据库连接池未初始化")
            return stats

        async with db.pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT user_id, nickname, current_activity, 
                       activity_start_time, shift
                FROM users 
                WHERE chat_id = $1 
                  AND current_activity IS NOT NULL
                """,
                chat_id,
            )

            stats["total"] = len(rows)

            if not rows:
                logger.info(f"📊 群组 {chat_id} 没有进行中的活动")
                return stats

            # ===== 批量获取活动配置 =====
            activities = list(set(row["current_activity"] for row in rows))
            activity_configs = await _get_activity_configs_batch(activities)

            logger.info(f"📊 发现 {len(rows)} 个进行中的活动，开始并发处理...")

            tasks = []
            for row in rows:
                task = asyncio.create_task(
                    _force_end_single_activity_optimized(
                        conn,
                        chat_id,
                        row,
                        now,
                        target_date,
                        business_today,
                        activity_configs,
                    )
                )
                tasks.append(task)

            # ===== 使用看门狗保护并发执行 =====
            results = await watchdog.run(asyncio.gather(*tasks, return_exceptions=True))
            # 喂狗
            watchdog.feed()
            # ===== 结束 =====

            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    stats["failed"] += 1
                    if rows[i]["shift"] == "day":
                        stats["day_shift"]["failed"] += 1
                    else:
                        stats["night_shift"]["failed"] += 1
                    logger.error(f"❌ 处理用户 {rows[i]['user_id']} 失败: {result}")
                else:
                    stats["success"] += 1
                    if result["shift"] == "day":
                        stats["day_shift"]["success"] += 1
                    else:
                        stats["night_shift"]["success"] += 1
                    stats["details"].append(result)

            stats["day_shift"]["total"] = sum(1 for r in rows if r["shift"] == "day")
            stats["night_shift"]["total"] = sum(
                1 for r in rows if r["shift"] == "night"
            )

        logger.info(
            f"✅ [强制结束活动完成] 群组 {chat_id}\n"
            f"   ├─ 总计: {stats['total']} 人\n"
            f"   ├─ 成功: {stats['success']} 人\n"
            f"   ├─ 失败: {stats['failed']} 人\n"
            f"   ├─ 白班: {stats['day_shift']['success']}/{stats['day_shift']['total']}\n"
            f"   └─ 夜班: {stats['night_shift']['success']}/{stats['night_shift']['total']}"
        )

    except asyncio.TimeoutError:
        logger.error(f"⏰ [强制结束活动] 超时 {chat_id}")
        # 超时后包装为可重试异常
        raise HandoverRetryableError(f"强制结束活动超时: {chat_id}")
    except Exception as e:
        logger.error(f"❌ [强制结束活动] 失败 {chat_id}: {e}")
        logger.error(traceback.format_exc())

    return stats


# ========== 新增：优化版的强制结束单个活动 ==========
async def _force_end_single_activity_optimized(
    conn,
    chat_id: int,
    user_row: dict,
    now: datetime,
    target_date: date,
    business_today: date,
    activity_configs: Dict[str, Dict],
) -> Dict[str, Any]:
    """强制结束单个活动（优化版，使用预加载配置）"""
    result = {
        "user_id": user_row["user_id"],
        "shift": user_row["shift"],
        "activity": user_row["current_activity"],
        "elapsed": 0,
        "fine": 0,
        "is_overtime": False,
        "success": False,
    }

    try:
        activity = user_row["current_activity"]
        start_time = datetime.fromisoformat(user_row["activity_start_time"])
        start_date = start_time.date()

        # ===== 修复：统一处理所有活动，都写入记录 =====
        # 计算活动时长
        elapsed = int((now - start_time).total_seconds())
        result["elapsed"] = elapsed

        # 确定强制归档的日期
        if start_date < business_today:
            # 活动开始日期早于业务今天（跨天活动）
            if start_date <= target_date:
                forced_date = target_date
            else:
                forced_date = business_today - timedelta(days=1)
            logger.info(
                f"📅 [强制结束-跨天] 用户{user_row['user_id']} 活动{activity} "
                f"开始于{start_date}，归档到{forced_date}"
            )
        else:
            # 活动开始日期 >= 业务今天（当天活动，但重置时未结束）
            # 归档到业务昨天
            forced_date = business_today - timedelta(days=1)
            logger.info(
                f"📅 [强制结束-当天] 用户{user_row['user_id']} 活动{activity} "
                f"开始于{start_date}，归档到{forced_date}（当天未结束活动强制归档）"
            )

        # 使用预加载的配置
        config = activity_configs.get(activity, {})
        time_limit_seconds = config.get("time_limit_seconds", 0)
        fine_rates = config.get("fine_rates", {})

        is_overtime = elapsed > time_limit_seconds
        overtime_seconds = max(0, elapsed - time_limit_seconds)
        overtime_minutes = overtime_seconds / 60

        fine_amount = 0
        if is_overtime and overtime_seconds > 0 and fine_rates:
            fine_amount = compute_activity_overtime_fine(
                fine_rates, overtime_minutes
            )

        result["fine"] = fine_amount
        result["is_overtime"] = is_overtime

        # ✅ 始终写入活动记录
        await db.complete_user_activity(
            chat_id=chat_id,
            user_id=user_row["user_id"],
            activity=activity,
            elapsed_time=elapsed,
            fine_amount=fine_amount,
            is_overtime=is_overtime,
            shift=user_row["shift"],
            forced_date=forced_date,
        )

        result["success"] = True

        logger.info(
            f"✅ [强制结束] 用户{user_row['user_id']} | "
            f"活动:{activity} | 班次:{user_row['shift']} | "
            f"开始:{start_date} | 归档:{forced_date} | "
            f"时长:{elapsed}s ({elapsed//60}分钟) | 罚款:{fine_amount}"
        )

    except Exception as e:
        logger.error(f"❌ [强制结束] 用户{user_row['user_id']} 失败: {e}")
        # ===== 新增：根据错误类型抛出适当的异常 =====
        if "deadlock" in str(e).lower() or "timeout" in str(e).lower():
            raise HandoverRetryableError(f"可重试错误: {e}") from e
        raise
        # ===== 新增结束 =====

    return result


# ========== 保留原版强制结束单个活动（兼容性）==========
async def _force_end_single_activity(
    conn,
    chat_id: int,
    user_row: dict,
    now: datetime,
    target_date: date,
    business_today: date,
) -> Dict[str, Any]:
    """强制结束单个活动（保留原版，用于兼容性）"""
    # 调用优化版，但需要临时获取配置
    activities = [user_row["current_activity"]]
    activity_configs = await _get_activity_configs_batch(activities)

    return await _force_end_single_activity_optimized(
        conn, chat_id, user_row, now, target_date, business_today, activity_configs
    )


# ========== 4. 补全未打卡的下班记录（优化版）==========
# ===== 添加阶段标记 =====
@with_execution_phase("complete_work_ends")
# ===== 添加结束 =====
async def _complete_missing_work_ends(
    chat_id: int, target_date: date, business_today: date
) -> Dict[str, Any]:
    """为昨天有上班记录但没有下班记录的用户补全下班记录（智能并发版）"""
    stats = {
        "total": 0,
        "success": 0,
        "failed": 0,
        "day_shift": {"total": 0, "success": 0, "failed": 0},
        "night_shift": {"total": 0, "success": 0, "failed": 0},
        "details": [],
    }

    try:
        if not db.pool or not db._initialized:
            logger.error("数据库连接池未初始化")
            return stats

        # 获取需要处理的用户列表
        async with db.pool.acquire() as conn:
            # 查询白班
            day_rows = await conn.fetch(
                """
                SELECT 
                    wr.user_id,
                    wr.shift,
                    wr.shift_detail,
                    wr.checkin_time as work_start_time,
                    u.nickname,
                    wr.record_date
                FROM work_records wr
                JOIN users u ON wr.chat_id = u.chat_id AND wr.user_id = u.user_id
                WHERE wr.chat_id = $1
                  AND wr.record_date = $2
                  AND wr.shift = 'day'
                  AND wr.checkin_type = 'work_start'
                  AND NOT EXISTS(
                      SELECT 1 FROM work_records wr2
                      WHERE wr2.chat_id = wr.chat_id
                        AND wr2.user_id = wr.user_id
                        AND wr2.record_date = wr.record_date
                        AND wr2.shift = wr.shift
                        AND wr2.checkin_type = 'work_end'
                  )
                """,
                chat_id,
                target_date,
            )

            # 查询夜班
            night_next_date = target_date + timedelta(days=1)
            night_rows = await conn.fetch(
                """
                SELECT 
                    wr.user_id,
                    wr.shift,
                    wr.shift_detail,
                    wr.checkin_time as work_start_time,
                    u.nickname,
                    wr.record_date
                FROM work_records wr
                JOIN users u ON wr.chat_id = u.chat_id AND wr.user_id = u.user_id
                WHERE wr.chat_id = $1
                  AND wr.record_date = $2
                  AND wr.shift = 'night'
                  AND wr.checkin_type = 'work_start'
                  AND NOT EXISTS(
                      SELECT 1 FROM work_records wr2
                      WHERE wr2.chat_id = wr.chat_id
                        AND wr2.user_id = wr.user_id
                        AND wr2.record_date = $3
                        AND wr2.shift = wr.shift
                        AND wr2.checkin_type = 'work_end'
                  )
                """,
                chat_id,
                target_date,
                night_next_date,
            )

            rows = list(day_rows) + list(night_rows)
            stats["total"] = len(rows)

            if not rows:
                logger.info(f"📝 群组 {chat_id} 昨日没有未下班的用户")
                return stats

            logger.info(
                f"📝 发现 {len(rows)} 个昨日未下班的用户 "
                f"(白班:{len(day_rows)}人，夜班:{len(night_rows)}人)"
            )

        # ===== 智能计算并发数 =====
        total_users = len(rows)
        max_workers = min(10, max(3, total_users // 5))
        semaphore = asyncio.Semaphore(max_workers)

        logger.info(f"🚀 并发配置: {max_workers} 个worker (总用户: {total_users})")

        # 获取配置数据
        group_data = await db.get_group_cached(chat_id)
        reset_hour = group_data.get("reset_hour", 0)
        reset_minute = group_data.get("reset_minute", 0)
        auto_end_time = f"{reset_hour:02d}:{reset_minute:02d}"

        shift_config = await db.get_shift_config(chat_id)
        work_fine_rates = await db.get_work_fine_rates_for_type("work_end")

        # ===== 修正：创建真正的Task对象 =====
        async def process_with_semaphore(row):
            async with semaphore:
                return await _complete_single_work_end_optimized(
                    chat_id,
                    row,
                    target_date,
                    auto_end_time,
                    shift_config,
                    work_fine_rates,
                )

        # ✅ 正确：使用 create_task 创建真正的Task对象
        tasks = [asyncio.create_task(process_with_semaphore(row)) for row in rows]

        # 使用 as_completed 流式处理结果
        processed = 0
        failed_too_many = False

        for coro in asyncio.as_completed(tasks):
            try:
                result = await coro
                processed += 1

                # 每处理10个用户记录一次进度
                if processed % 10 == 0:
                    logger.info(f"⏳ 进度: {processed}/{total_users} 用户已处理")

                # 更新统计
                stats["success"] += 1
                if result["shift"] == "day":
                    stats["day_shift"]["success"] += 1
                else:
                    stats["night_shift"]["success"] += 1
                stats["details"].append(result)

            except asyncio.CancelledError:
                # 任务被取消，正常退出
                logger.warning(f"⏹️ 任务被取消")
                break

            except Exception as e:
                processed += 1
                stats["failed"] += 1
                logger.error(f"❌ 处理用户失败: {e}")

                # 如果失败太多，提前终止
                if stats["failed"] > total_users // 2:  # 失败超过50%
                    logger.error(
                        f"❌ 失败率过高 ({stats['failed']}/{total_users})，终止处理"
                    )
                    failed_too_many = True
                    break

        # 如果提前终止，取消剩余任务
        if failed_too_many:
            for task in tasks:
                if not task.done():
                    task.cancel()

            # 等待所有任务完成取消
            await asyncio.gather(*tasks, return_exceptions=True)
            logger.info(f"🛑 已取消所有剩余任务")

        stats["day_shift"]["total"] = len(day_rows)
        stats["night_shift"]["total"] = len(night_rows)

        logger.info(
            f"✅ [补全下班记录完成] 群组 {chat_id}\n"
            f"   ├─ 总计: {stats['total']} 人\n"
            f"   ├─ 成功: {stats['success']} 人\n"
            f"   ├─ 失败: {stats['failed']} 人\n"
            f"   ├─ 白班: {stats['day_shift']['success']}/{stats['day_shift']['total']}\n"
            f"   └─ 夜班: {stats['night_shift']['success']}/{stats['night_shift']['total']}"
        )

    except Exception as e:
        logger.error(f"❌ [补全下班记录] 失败 {chat_id}: {e}")
        logger.error(traceback.format_exc())

    return stats


# ========== 修复版：优化版补全单个下班记录 ==========
async def _complete_single_work_end_optimized(
    chat_id: int,
    row: dict,
    target_date: date,
    auto_end_time: str,
    shift_config: dict,
    work_fine_rates: Dict[str, int],
    conn: Optional[asyncpg.Connection] = None,  # 可选：复用外部连接
) -> Dict[str, Any]:
    """
    修复版：补全单个用户的下班记录 - 确保统计字段正确更新

    优化点：
    1. 支持复用外部连接（减少连接获取开销）
    2. 30秒超时保护
    3. 批量插入准备
    4. 详细的错误分类
    5. ✅ 确保 daily_statistics 的 work_end_count 和 work_end_fines 正确更新

    Args:
        chat_id: 群组ID
        row: 用户数据行
        target_date: 目标日期
        auto_end_time: 自动下班时间
        shift_config: 班次配置
        work_fine_rates: 罚款配置
        conn: 可选的数据库连接（如果提供则复用，否则新建）
    """
    result = {
        "user_id": row["user_id"],
        "shift": row["shift"],
        "work_start_time": row["work_start_time"],
        "work_end_time": auto_end_time,
        "fine": 0,
        "duration": 0,
        "success": False,
        "record_date": None,  # 新增：记录实际统计日期
    }

    # ===== 1. 超时控制 =====
    try:
        async with asyncio.timeout(30):  # 30秒超时
            # ===== 2. 根据班次确定期望下班时间和统计日期 =====
            if row["shift"] == "day":
                expected_end_time = shift_config.get("day_end", "18:00")
                # 白班：下班记录在当天
                work_end_date = target_date
                stats_record_date = target_date  # 统计日期 = 当天
            else:  # night
                expected_end_time = shift_config.get("day_start", "09:00")
                # 夜班：下班记录在第二天
                work_end_date = target_date + timedelta(days=1)
                stats_record_date = target_date + timedelta(days=1)  # 统计日期 = 第二天

            result["record_date"] = stats_record_date

            # ===== 3. 解析时间（带异常保护）=====
            try:
                work_start_time = datetime.strptime(
                    row["work_start_time"], "%H:%M"
                ).time()

                expected_end_dt = datetime.combine(
                    work_end_date, datetime.strptime(expected_end_time, "%H:%M").time()
                )
                auto_end_dt = datetime.combine(
                    work_end_date, datetime.strptime(auto_end_time, "%H:%M").time()
                )
                work_start_dt = datetime.combine(
                    target_date if row["shift"] == "day" else target_date,
                    work_start_time,
                )
            except ValueError as e:
                logger.error(f"时间解析失败: {e}")
                result["error"] = f"时间解析失败: {e}"
                return result

            # ===== 4. 计算时间差和罚款（优化版）=====
            time_diff_seconds = int((auto_end_dt - expected_end_dt).total_seconds())
            time_diff_minutes = time_diff_seconds / 60

            # 罚款计算（早退才罚款）
            fine_amount = 0
            if time_diff_seconds < 0 and work_fine_rates:
                # 将阈值转为整数并排序
                thresholds = sorted([int(k) for k in work_fine_rates.keys()])
                abs_minutes = abs(time_diff_minutes)

                # 从大到小检查，找到第一个符合条件的
                for threshold in reversed(thresholds):
                    if abs_minutes >= threshold:
                        fine_amount = work_fine_rates[str(threshold)]
                        break

            # 计算工作时长
            work_duration = int((auto_end_dt - work_start_dt).total_seconds())

            # ===== 5. 确定状态描述（带emoji）=====
            if time_diff_seconds < 0:
                status = f"🚨 自动下班（早退 {abs(time_diff_minutes):.1f}分钟）"
            elif time_diff_seconds > 0:
                status = f"✅ 自动下班（加班 {time_diff_minutes:.1f}分钟）"
            else:
                status = "✅ 自动下班（准时）"

            # ===== 6. 数据库操作（修复版 - 确保统计正确）=====
            if conn:
                # 复用外部连接
                await _execute_work_end_operations_fixed(
                    conn,
                    chat_id,
                    row,
                    stats_record_date,  # 传入统计日期
                    auto_end_time,
                    status,
                    time_diff_minutes,
                    fine_amount,
                    work_duration,
                )
            else:
                # 新建独立连接
                async with db.pool.acquire() as new_conn:
                    await _execute_work_end_operations_fixed(
                        new_conn,
                        chat_id,
                        row,
                        stats_record_date,
                        auto_end_time,
                        status,
                        time_diff_minutes,
                        fine_amount,
                        work_duration,
                    )

            # 记录结果
            result["fine"] = fine_amount
            result["duration"] = work_duration
            result["success"] = True

            logger.info(
                f"✅ [补全下班] 用户{row['user_id']} | "
                f"班次:{row['shift']} | 上班:{row['work_start_time']} | "
                f"自动下班:{auto_end_time} | 统计日期:{stats_record_date} | "
                f"罚款:{fine_amount} | 时长:{work_duration//60}分钟 | "
                f"下班次数+1"
            )

    except asyncio.TimeoutError:
        logger.error(f"⏰ [补全下班] 用户{row['user_id']} 操作超时(30秒)")
        result["error"] = "操作超时"
        # 超时是可重试的错误
        raise HandoverRetryableError(f"补全下班超时: {row['user_id']}")

    except asyncpg.DeadlockDetectedError as e:
        logger.error(f"🔒 [补全下班] 用户{row['user_id']} 死锁: {e}")
        raise HandoverRetryableError(f"数据库死锁: {row['user_id']}")

    except asyncpg.PostgresConnectionError as e:
        logger.error(f"🔌 [补全下班] 用户{row['user_id']} 连接错误: {e}")
        raise HandoverRetryableError(f"数据库连接错误: {row['user_id']}")

    except Exception as e:
        logger.error(f"❌ [补全下班] 用户{row['user_id']} 失败: {e}")
        # 区分可重试和不可重试错误
        error_str = str(e).lower()
        if any(
            k in error_str for k in ["deadlock", "timeout", "connection", "network"]
        ):
            raise HandoverRetryableError(f"可重试错误: {e}") from e
        raise  # 不可重试的错误直接抛出

    return result


# ===== 修复版辅助函数：执行具体数据库操作（确保统计正确）=====
async def _execute_work_end_operations_fixed(
    conn: asyncpg.Connection,
    chat_id: int,
    row: dict,
    stats_record_date: date,  # 统计日期（白班=当天，夜班=第二天）
    auto_end_time: str,
    status: str,
    time_diff_minutes: float,
    fine_amount: int,
    work_duration: int,
):
    """
    修复版：执行下班补全的数据库操作（确保 work_end_count 和 work_end_fines 正确更新）
    """
    async with conn.transaction():
        # 1. 插入 work_records
        await conn.execute(
            """
            INSERT INTO work_records
            (chat_id, user_id, record_date, checkin_type, checkin_time, 
             status, time_diff_minutes, fine_amount, shift, shift_detail)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            """,
            chat_id,
            row["user_id"],
            stats_record_date,  # 使用正确的统计日期
            "work_end",
            auto_end_time,
            status,
            time_diff_minutes,
            fine_amount,
            row["shift"],
            row.get("shift_detail", row["shift"]),
        )

        # 2. ✅ 修复点：确保 daily_statistics 的 work_end_count 正确累加
        await conn.execute(
            """
            INSERT INTO daily_statistics 
            (chat_id, user_id, record_date, shift,
             work_end_count, work_end_fines, work_hours, work_days)
            VALUES ($1, $2, $3, $4, 1, $5, $6, 1)
            ON CONFLICT (chat_id, user_id, record_date, shift) 
            DO UPDATE SET
                work_end_count = daily_statistics.work_end_count + 1,
                work_end_fines = daily_statistics.work_end_fines + $5,
                work_hours = daily_statistics.work_hours + $6,
                work_days = daily_statistics.work_days + 1,
                updated_at = CURRENT_TIMESTAMP
            """,
            chat_id,
            row["user_id"],
            stats_record_date,
            row["shift"],
            fine_amount,
            work_duration,
        )

        # 3. 如果是夜班，还要确保上班那天的记录存在（用于工作天数统计）
        if row["shift"] == "night":
            # 上班日期 = target_date（即参数中传入的 target_date）
            work_start_date = (
                row["record_date"]
                if "record_date" in row
                else stats_record_date - timedelta(days=1)
            )

            await conn.execute(
                """
                INSERT INTO daily_statistics 
                (chat_id, user_id, record_date, shift, work_days)
                VALUES ($1, $2, $3, $4, 1)
                ON CONFLICT (chat_id, user_id, record_date, shift) 
                DO NOTHING
                """,
                chat_id,
                row["user_id"],
                work_start_date,
                row["shift"],
            )

        # 4. 如果有罚款，更新月度统计
        if fine_amount > 0:
            # 计算统计月份
            statistic_date = stats_record_date.replace(day=1)

            await conn.execute(
                """
                INSERT INTO monthly_statistics 
                (chat_id, user_id, statistic_date, shift, work_end_fines, updated_at)
                VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
                ON CONFLICT (chat_id, user_id, statistic_date, shift)
                DO UPDATE SET
                    work_end_fines = monthly_statistics.work_end_fines + $5,
                    updated_at = CURRENT_TIMESTAMP
                """,
                chat_id,
                row["user_id"],
                statistic_date,
                row["shift"],
                fine_amount,
            )

        # 5. 更新用户总罚款
        if fine_amount > 0:
            await conn.execute(
                """
                UPDATE users
                SET total_fines = total_fines + $1,
                    updated_at = CURRENT_TIMESTAMP
                WHERE chat_id = $2 AND user_id = $3
                """,
                fine_amount,
                chat_id,
                row["user_id"],
            )

        # 6. 清理缓存
        cache_key = f"user:{chat_id}:{row['user_id']}"
        if hasattr(db, "_cache"):
            db._cache.pop(cache_key, None)
            db._cache_ttl.pop(cache_key, None)

        logger.debug(
            f"📊 [统计更新] 用户{row['user_id']} {row['shift']}班次 "
            f"日期:{stats_record_date} 下班次数+1 罚款:{fine_amount}"
        )


# ===== 辅助函数：执行具体数据库操作 =====
async def _execute_work_end_operations(
    conn: asyncpg.Connection,
    chat_id: int,
    row: dict,
    target_date: date,
    auto_end_time: str,
    status: str,
    time_diff_minutes: float,
    fine_amount: int,
    work_duration: int,
):
    """执行下班补全的数据库操作（使用已获取的连接）"""

    async with conn.transaction():
        # 1. 添加工记录
        await conn.execute(
            """
            INSERT INTO work_records
            (chat_id, user_id, record_date, checkin_type, checkin_time, 
             status, time_diff_minutes, fine_amount, shift, shift_detail)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            """,
            chat_id,
            row["user_id"],
            target_date,
            "work_end",
            auto_end_time,
            status,
            time_diff_minutes,
            fine_amount,
            row["shift"],
            row.get("shift_detail", row["shift"]),
        )

        # 2. 确保 daily_statistics 记录存在
        await conn.execute(
            """
            INSERT INTO daily_statistics (chat_id, user_id, record_date, shift)
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (chat_id, user_id, record_date, shift) DO NOTHING
            """,
            chat_id,
            row["user_id"],
            target_date,
            row["shift"],
        )

        # 3. 更新工作时长
        if work_duration > 0:
            await conn.execute(
                """
                UPDATE daily_statistics
                SET work_hours = work_hours + $5,
                    work_days = work_days + 1,
                    updated_at = CURRENT_TIMESTAMP
                WHERE chat_id = $1 AND user_id = $2 
                  AND record_date = $3 AND shift = $4
                """,
                chat_id,
                row["user_id"],
                target_date,
                row["shift"],
                work_duration,
            )

        # 4. 如果有罚款，更新罚款统计
        if fine_amount > 0:
            await conn.execute(
                """
                UPDATE daily_statistics
                SET work_end_fines = work_end_fines + $5,
                    updated_at = CURRENT_TIMESTAMP
                WHERE chat_id = $1 AND user_id = $2 
                  AND record_date = $3 AND shift = $4
                """,
                chat_id,
                row["user_id"],
                target_date,
                row["shift"],
                fine_amount,
            )


# ===== 批量处理版本（可选优化）=====
async def _complete_batch_work_ends(
    chat_id: int,
    rows: List[dict],
    target_date: date,
    auto_end_time: str,
    shift_config: dict,
    work_fine_rates: Dict[str, int],
) -> List[Dict[str, Any]]:
    """
    批量补全下班记录（使用单个连接处理多个用户）
    适合处理大量用户时使用
    """
    results = []

    try:
        async with db.pool.acquire() as conn:
            for row in rows:
                try:
                    # 复用同一个连接处理所有用户
                    result = await _complete_single_work_end_optimized(
                        chat_id=chat_id,
                        row=row,
                        target_date=target_date,
                        auto_end_time=auto_end_time,
                        shift_config=shift_config,
                        work_fine_rates=work_fine_rates,
                        conn=conn,  # 传入复用连接
                    )
                    results.append(result)

                except Exception as e:
                    logger.error(f"批量处理中用户{row['user_id']}失败: {e}")
                    results.append(
                        {
                            "user_id": row["user_id"],
                            "shift": row["shift"],
                            "success": False,
                            "error": str(e),
                        }
                    )

    except Exception as e:
        logger.error(f"批量处理整体失败: {e}")

    return results


# ========== 保留原版补全单个下班记录（兼容性）==========
async def _complete_single_work_end(
    conn,
    chat_id: int,
    row: dict,
    target_date: date,
    auto_end_time: str,
    shift_config: dict,
) -> Dict[str, Any]:
    """保留原版函数，但内部调用优化版"""
    work_fine_rates = await db.get_work_fine_rates_for_type("work_end")
    return await _complete_single_work_end_optimized(
        conn, chat_id, row, target_date, auto_end_time, shift_config, work_fine_rates
    )


# ========== 5. 导出数据 ==========
# ===== 导出锁管理 =====
_export_locks: Dict[str, asyncio.Lock] = {}
_export_locks_guard = asyncio.Lock()
_export_semaphore = asyncio.Semaphore(3)


async def _get_export_lock(key: str) -> asyncio.Lock:
    """获取任务锁（不存在则创建）"""
    async with _export_locks_guard:
        lock = _export_locks.get(key)
        if lock is None:
            lock = asyncio.Lock()
            _export_locks[key] = lock
        return lock


async def _cleanup_export_lock(key: str):
    """清理任务锁（避免字典无限增长）"""
    async with _export_locks_guard:
        lock = _export_locks.get(key)
        if lock and not lock.locked():
            _export_locks.pop(key, None)


# ===== 添加阶段标记 =====
@with_execution_phase("export_data")
# ===== 添加结束 =====
async def _export_yesterday_data_concurrent(
    chat_id: int,
    target_date: date,
    from_monthly: bool = False,
) -> bool:
    """
    企业级稳定导出逻辑 - 支持日常/月度导出

    Args:
        chat_id: 群组ID
        target_date: 目标日期
        from_monthly: 是否从月度表导出（True=月度表，False=日常表）
    """
    from export_service import export_and_push_csv
    from database import db

    export_key = f"{chat_id}:{target_date}"

    # 文件名区分月度/日常
    prefix = "monthly" if from_monthly else "daily"
    file_name = f"{prefix}_backup_{chat_id}_{target_date.strftime('%Y%m%d')}.csv"

    export_lock = await _get_export_lock(export_key)

    async with export_lock:
        async with _export_semaphore:
            try:
                shift_config = await db.get_shift_config(chat_id)
                day_start = shift_config.get("day_start", "09:00")
                day_end = shift_config.get("day_end", "21:00")

                source = "月度表" if from_monthly else "日常表"

                # 对于月度导出，目标日期应该是月份的第一天
                display_desc = (
                    f"{target_date.year}年{target_date.month}月"
                    if from_monthly
                    else str(target_date)
                )

                logger.info(
                    f"📊 [数据导出] 群组 {chat_id}\n"
                    f"   ├─ 目标{'月份' if from_monthly else '日期'}: {display_desc}\n"
                    f"   ├─ 数据来源: {source}\n"
                    f"   └─ 班次: 白班 {day_start}-{day_end} 夜班 {day_end}-{day_start}"
                )

                max_attempts = 3

                for attempt in range(max_attempts):
                    try:
                        logger.info(
                            f"🔄 [数据导出] 群组{chat_id} 第 {attempt+1}/{max_attempts} 次尝试 ({source})"
                        )

                        result = await export_and_push_csv(
                            chat_id=chat_id,
                            to_admin_if_no_group=True,
                            file_name=file_name,
                            target_date=target_date,
                            is_daily_reset=not from_monthly,  # 只有日常重置才是 True
                            from_monthly_table=from_monthly,  # ✅ 正确传递参数
                            push_file=True,
                        )

                        if result:
                            logger.info(
                                f"✅ [数据导出] 群组 {chat_id} 导出成功\n"
                                f"   ├─ 目标: {display_desc}\n"
                                f"   ├─ 来源: {source}\n"
                                f"   └─ 文件: {file_name}"
                            )
                            return True

                    except asyncio.TimeoutError:
                        logger.error(
                            f"⏰ [数据导出] 群组{chat_id} 第{attempt+1}次尝试超时"
                        )
                        # ===== 新增：超时错误包装为可重试异常 =====
                        if attempt < max_attempts - 1:
                            raise HandoverRetryableError(f"导出超时: {e}") from e
                        # ===== 新增结束 =====
                    except Exception as e:
                        logger.warning(
                            f"⚠️ [数据导出] 群组{chat_id} 第{attempt+1}次失败: {e}"
                        )
                        if attempt < max_attempts - 1:
                            logger.exception(e)
                            # ===== 新增：包装为可重试异常 =====
                            raise HandoverRetryableError(f"导出失败: {e}") from e
                            # ===== 新增结束 =====

                    if attempt < max_attempts - 1:
                        delay = 2**attempt
                        logger.info(f"⏳ {delay}s 后重试")
                        await asyncio.sleep(delay)

                logger.error(
                    f"❌ [数据导出] 群组{chat_id} 导出失败\n"
                    f"   ├─ 目标: {display_desc}\n"
                    f"   ├─ 来源: {source}\n"
                    f"   └─ 文件: {file_name}"
                )

                try:
                    from utils import notification_service

                    await notification_service.send_notification(
                        chat_id=None,
                        text=(
                            f"⚠️ 数据导出失败\n\n"
                            f"群组 {chat_id}\n"
                            f"目标: {display_desc}\n"
                            f"来源: {source}\n"
                            f"CSV 导出失败，请检查数据库。"
                        ),
                        notification_type="admin",
                    )
                except Exception as notify_error:
                    logger.error(f"❌ 通知发送失败: {notify_error}")

                return False

            finally:
                await _cleanup_export_lock(export_key)


async def _export_monthly_data_concurrent(chat_id: int, year: int, month: int) -> bool:
    """
    导出月度数据 - 便捷函数

    Args:
        chat_id: 群组ID
        year: 年份
        month: 月份
    """
    target_date = date(year, month, 1)
    return await _export_yesterday_data_concurrent(
        chat_id=chat_id,
        target_date=target_date,
        from_monthly=True,  # ✅ 指定从月度表导出
    )


# ========== 6. 数据清理 ==========
async def _finalize_reset_date(
    chat_id: int,
    target_date: date,
    business_today: date,
    *,
    skip_export: bool = False,
) -> bool:
    """
    对单个业务日完成归档：有数据则先导出再物理清理，无数据则直接标记完成。
    返回 True 表示该日期已不再有待处理日表数据。
    """
    if await db.is_reset_completed(chat_id, target_date):
        return True

    has_data = await db.has_daily_data_for_date(chat_id, target_date)
    if not has_data:
        await db.mark_reset_completed(chat_id, target_date)
        flag_key = f"dual_reset:{chat_id}:{target_date.strftime('%Y%m%d')}"
        await global_cache.set(flag_key, True, ttl=86400)
        logger.info(
            f"✅ [归档] 群组 {chat_id} 日期 {target_date} 无日表数据，已标记完成"
        )
        return True

    if not skip_export:
        export_success = await _export_yesterday_data_concurrent(chat_id, target_date)
        if not export_success:
            logger.warning(
                f"⚠️ [归档] 群组 {chat_id} 日期 {target_date} 导出失败，"
                f"保留数据等待下次重试"
            )
            return False

    cleanup_stats = await _cleanup_old_data(chat_id, target_date, business_today)
    await db.mark_reset_completed(chat_id, target_date)
    flag_key = f"dual_reset:{chat_id}:{target_date.strftime('%Y%m%d')}"
    await global_cache.set(flag_key, True, ttl=86400)

    deleted_total = sum(
        v for k, v in cleanup_stats.items() if k != "users_reset"
    )
    logger.info(
        f"✅ [归档] 群组 {chat_id} 日期 {target_date} 清理完成，"
        f"删除 {deleted_total} 条"
    )
    return True


async def _process_pending_reset_dates(
    chat_id: int,
    business_today: date,
    *,
    max_dates: int = 3,
    exclude_date: Optional[date] = None,
) -> int:
    """
    补处理早于业务今天、且有日表数据但未完成重置的日期。
    按日期从旧到新，导出成功后才物理清理。
    exclude_date: 留给完整重置流程处理的日期（如当前窗口内的 business_yesterday）
    """
    pending = await db.get_pending_reset_dates(chat_id, business_today)
    if exclude_date:
        pending = [d for d in pending if d != exclude_date]
    if not pending:
        return 0

    logger.info(
        f"📋 [待办重置] 群组 {chat_id} 有 {len(pending)} 个待归档日期: "
        f"{', '.join(str(d) for d in pending[:5])}"
        f"{'...' if len(pending) > 5 else ''}"
    )

    processed = 0
    for target_date in pending[:max_dates]:
        if await _finalize_reset_date(chat_id, target_date, business_today):
            processed += 1
        else:
            break

    return processed


async def process_all_pending_resets(max_dates_per_group: int = 3) -> Dict[str, int]:
    """为所有群组补处理待归档日期（供定时任务调用）"""
    stats = {"groups": 0, "dates_cleared": 0, "errors": 0}
    try:
        all_groups = await db.get_all_groups()
        for chat_id in all_groups:
            try:
                now = db.get_beijing_time()
                business_today = await handover_manager.get_business_date(
                    chat_id, now
                )
                cleared = await _process_pending_reset_dates(
                    chat_id, business_today, max_dates=max_dates_per_group
                )
                if cleared:
                    stats["groups"] += 1
                    stats["dates_cleared"] += cleared
            except Exception as e:
                stats["errors"] += 1
                logger.error(f"❌ [待办重置] 群组 {chat_id} 处理失败: {e}")
    except Exception as e:
        logger.error(f"❌ [待办重置] 全局处理失败: {e}")
    return stats


async def _cleanup_old_data(
    chat_id: int, target_date: date, business_today: date
) -> Dict[str, int]:
    """物理清理目标业务日数据，并重置相关用户内存字段"""
    stats = {
        "user_activities": 0,
        "work_records": 0,
        "daily_statistics": 0,
        "handover_cycles": 0,
        "users_reset": 0,
    }

    try:
        if not db.pool or not db._initialized:
            logger.error("数据库连接池未初始化")
            return stats

        async with db.pool.acquire() as conn:
            async with conn.transaction():
                result = await conn.execute(
                    """
                    DELETE FROM user_activities 
                    WHERE chat_id = $1 AND activity_date = $2
                    """,
                    chat_id,
                    target_date,
                )
                stats["user_activities"] = parse_sql_row_count(result, "DELETE")

                result = await conn.execute(
                    """
                    DELETE FROM work_records 
                    WHERE chat_id = $1 AND record_date = $2
                    """,
                    chat_id,
                    target_date,
                )
                stats["work_records"] = parse_sql_row_count(result, "DELETE")

                result = await conn.execute(
                    """
                    DELETE FROM daily_statistics 
                    WHERE chat_id = $1 AND record_date = $2
                    """,
                    chat_id,
                    target_date,
                )
                stats["daily_statistics"] = parse_sql_row_count(result, "DELETE")

                result = await conn.execute(
                    """
                    DELETE FROM user_handover_cycles
                    WHERE chat_id = $1 AND handover_date <= $2
                    """,
                    chat_id,
                    target_date,
                )
                stats["handover_cycles"] = parse_sql_row_count(result, "DELETE")

                result = await conn.execute(
                    """
                    UPDATE users 
                    SET total_activity_count = 0,
                        total_accumulated_time = 0,
                        total_fines = 0,
                        total_overtime_time = 0,
                        overtime_count = 0,
                        current_activity = NULL,
                        activity_start_time = NULL,
                        checkin_message_id = NULL,
                        last_updated = $2,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE chat_id = $1 
                      AND last_updated <= $3
                    """,
                    chat_id,
                    business_today,
                    target_date,
                )
                stats["users_reset"] = parse_sql_row_count(result, "UPDATE")

        cache_prefixes = (f"user:{chat_id}:", f"stats:{chat_id}:")
        keys_to_remove = [
            key
            for key in list(db._cache.keys())
            if key.startswith(cache_prefixes)
        ]
        for key in keys_to_remove:
            db._cache.pop(key, None)
            db._cache_ttl.pop(key, None)

        await handover_manager.invalidate_chat_cycle_cache(chat_id)
        handover_manager._invalidate_cache(chat_id)

        total_deleted = (
            stats["user_activities"]
            + stats["work_records"]
            + stats["daily_statistics"]
            + stats["handover_cycles"]
        )

        logger.info(
            f"🧹 [数据清理] 群组{chat_id}\n"
            f"   • 删除用户活动: {stats['user_activities']} 条\n"
            f"   • 删除工作记录: {stats['work_records']} 条\n"
            f"   • 删除日统计: {stats['daily_statistics']} 条\n"
            f"   • 删除换班周期: {stats['handover_cycles']} 条\n"
            f"   • 重置用户状态: {stats['users_reset']} 人\n"
            f"   • 总计删除: {total_deleted} 条\n"
            f"   • 今天数据: ✅ 完整保留 (业务今天 = {business_today})"
        )

    except Exception as e:
        logger.error(f"❌ [数据清理] 失败 {chat_id}: {e}")
        logger.error(traceback.format_exc())
        # ===== 新增：数据清理错误包装为可重试 =====
        if "deadlock" in str(e).lower() or "timeout" in str(e).lower():
            raise HandoverRetryableError(f"清理可重试错误: {e}") from e
        # ===== 新增结束 =====

    return stats


# ========== 7. 发送通知 ==========
async def _send_reset_notification(
    chat_id: int,
    force_stats: Dict[str, Any],
    complete_stats: Dict[str, Any],
    export_success: bool,
    cleanup_stats: Dict[str, int],
    reset_time: datetime,
    cleanup_skipped: bool = False,
):
    """发送重置通知"""
    try:
        from utils import send_reset_notification

        details = []
        total_fines = 0
        for detail in force_stats.get("details", []):
            fine = detail.get("fine", 0)
            total_fines += fine
            details.append(
                {
                    "user_id": detail.get("user_id"),
                    "nickname": f"用户{detail.get('user_id', '?')}",
                    "activity": detail.get("activity", "活动"),
                    "elapsed_time": detail.get("elapsed", 0),
                    "fine_amount": fine,
                    "is_overtime": detail.get("is_overtime", False),
                }
            )

        completed_count = force_stats.get("success", 0) + complete_stats.get(
            "success", 0
        )

        notification_data = {
            "completed_count": completed_count,
            "total_fines": total_fines,
            "details": details,
            "export_success": export_success,
            "cleanup_skipped": cleanup_skipped,
            "cleanup": cleanup_stats,
            "day_shift": {
                "forced": force_stats.get("day_shift", {}).get("success", 0),
                "completed": complete_stats.get("day_shift", {}).get("success", 0),
            },
            "night_shift": {
                "forced": force_stats.get("night_shift", {}).get("success", 0),
                "completed": complete_stats.get("night_shift", {}).get("success", 0),
            },
        }

        await send_reset_notification(chat_id, notification_data, reset_time)
        logger.info("   ✅ 重置通知已发送")

    except Exception as e:
        logger.warning(f"   ⚠️ 发送重置通知失败: {e}")


# ========== 8. 辅助函数 ==========


# ========== 9. 恢复班次状态 ==========
async def recover_shift_states():
    """系统启动时恢复所有用户的班次状态"""
    logger.info("🔄 开始恢复用户班次状态...")
    recovered_count = 0

    try:
        all_groups = await db.get_all_groups()

        for chat_id in all_groups:
            try:
                if not await db.is_dual_mode_enabled(chat_id):
                    continue

                if not db.pool or not db._initialized:
                    logger.error("数据库连接池未初始化")
                    return 0

                async with db.pool.acquire() as conn:
                    rows = await conn.fetch(
                        """
                        SELECT 
                            wr.user_id, 
                            wr.shift, 
                            wr.record_date,
                            MIN(wr.created_at) as earliest_time
                        FROM work_records wr
                        WHERE wr.chat_id = $1
                          AND wr.checkin_type = 'work_start'
                          AND NOT EXISTS (
                              SELECT 1 FROM work_records wr2
                              WHERE wr2.chat_id = wr.chat_id
                                AND wr2.user_id = wr.user_id
                                AND wr2.record_date = wr.record_date
                                AND wr2.shift = wr.shift
                                AND wr2.checkin_type = 'work_end'
                          )
                        GROUP BY wr.user_id, wr.shift, wr.record_date
                        """,
                        chat_id,
                    )

                    for row in rows:
                        await db.set_user_shift_state(
                            chat_id=chat_id,
                            user_id=row["user_id"],
                            shift=row["shift"],
                            record_date=row["record_date"],
                        )
                        recovered_count += 1
                        logger.info(
                            f"✅ 恢复用户班次状态: 群组={chat_id}, "
                            f"用户={row['user_id']}, 班次={row['shift']}"
                        )

            except Exception as e:
                logger.error(f"❌ 恢复群组 {chat_id} 班次状态失败: {e}")

        logger.info(f"✅ 用户班次状态恢复完成，共恢复 {recovered_count} 个班次")
        return recovered_count

    except Exception as e:
        logger.error(f"❌ 用户班次状态恢复过程失败: {e}")
        return 0


# ========== 10. 新增：启动时检查未完成重置 ==========
async def check_missed_resets_on_startup():
    """系统启动时检查是否有错过的重置（高性能并发版）"""
    logger.info("🔍 开始检查是否有未完成的重置...")

    try:
        now = db.get_beijing_time()
        all_groups = await db.get_all_groups()

        if not all_groups:
            logger.info("✅ 没有需要检查的群组")
            return

        # ===== 1. 统计变量 =====
        stats = {
            "total": len(all_groups),
            "completed": 0,  # 已完成的
            "executed": 0,  # 自动执行的
            "missed": 0,  # 需手动处理的
            "skipped": 0,  # 无配置的
            "errors": 0,  # 检查失败的
            "failed": 0,  # 执行失败的
        }

        # ===== 2. 并发控制 =====
        sem = asyncio.Semaphore(5)

        async def check_group(chat_id):
            async with sem:
                try:
                    # 获取群组配置
                    group_data = await db.get_group_cached(chat_id)
                    if not group_data:
                        stats["skipped"] += 1
                        return

                    reset_hour = group_data.get("reset_hour", 0)
                    reset_minute = group_data.get("reset_minute", 0)

                    # 获取业务日期
                    date_range = await db.get_business_date_range(chat_id, now)
                    business_today = date_range["business_today"]
                    business_yesterday = date_range["business_yesterday"]

                    pending = await db.get_pending_reset_dates(
                        chat_id, business_today
                    )
                    if pending:
                        logger.warning(
                            f"⚠️ 待归档日期: 群组={chat_id}, "
                            f"共{len(pending)}天: {pending[0]}..{pending[-1]}"
                        )
                        cleared = await _process_pending_reset_dates(
                            chat_id, business_today, max_dates=5
                        )
                        if cleared:
                            stats["executed"] += 1
                            logger.info(
                                f"✅ 启动补归档 {cleared} 个日期: 群组 {chat_id}"
                            )
                        pending_after = await db.get_pending_reset_dates(
                            chat_id, business_today
                        )
                        if pending_after:
                            stats["missed"] += 1
                        return

                    # 检查是否已完成
                    if await db.is_reset_completed(chat_id, business_yesterday):
                        stats["completed"] += 1
                        return

                    # 计算时间差
                    reset_time_today = now.replace(
                        hour=reset_hour, minute=reset_minute, second=0, microsecond=0
                    )
                    hours_since = (now - reset_time_today).total_seconds() / 3600

                    logger.warning(
                        f"⚠️ 未完成重置: 群组={chat_id}, 日期={business_yesterday}, "
                        f"已过{hours_since:.1f}小时"
                    )

                    # ===== 3. 阈值判断 =====
                    if 0 <= hours_since <= 4:
                        cache_key = f"dual_reset:{chat_id}:{business_yesterday.strftime('%Y%m%d')}"

                        # 检查缓存
                        if await global_cache.get(cache_key):
                            logger.debug(f"⏭️ 缓存已标记: {chat_id}")
                            stats["completed"] += 1
                            return

                        # 执行重置 - 这里调用的 handle_hard_reset 已经带有重试装饰器
                        logger.info(f"🔄 自动执行重置: 群组 {chat_id}")
                        success = await handle_hard_reset(
                            chat_id, None, target_date=business_yesterday
                        )

                        if success:
                            stats["executed"] += 1
                            logger.info(f"✅ 自动执行成功")
                        else:
                            stats["failed"] += 1
                            logger.error(f"❌ 自动执行失败")

                    elif hours_since > 4:
                        stats["missed"] += 1
                        logger.info(f"⏭️ 超过4小时，需手动处理")
                    else:
                        stats["completed"] += 1  # 未来时间视为已完成

                except Exception as e:
                    stats["errors"] += 1
                    logger.error(f"❌ 检查群组 {chat_id} 失败: {e}")

        # ===== 4. 并发执行 =====
        tasks = [check_group(cid) for cid in all_groups]
        await asyncio.gather(*tasks, return_exceptions=True)

        # ===== 5. 生成报告 =====
        report = (
            f"📊 **启动自检报告**\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"📈 总计检查: {stats['total']} 个群组\n"
            f"✅ 已完成: {stats['completed']} 个\n"
            f"🔄 自动执行: {stats['executed']} 个\n"
            f"⚠️ 需手动处理: {stats['missed']} 个\n"
            f"⏭️ 跳过: {stats['skipped']} 个\n"
            f"❌ 执行失败: {stats['failed']} 个\n"
            f"❗ 检查失败: {stats['errors']} 个\n"
            f"━━━━━━━━━━━━━━━━"
        )

        logger.info(f"\n{report}")

        # ===== 6. 如果有失败，发送通知给管理员 =====
        if stats["failed"] > 0 or stats["errors"] > 0:
            from utils import notification_service

            await notification_service.send_notification(
                chat_id=None,  # 发送给所有管理员
                text=f"⚠️ **启动自检警告**\n{stats['failed']} 个重置失败，{stats['errors']} 个检查失败",
                notification_type="admin",
            )

    except Exception as e:
        logger.error(f"❌ 启动检查异常: {e}")
        logger.error(traceback.format_exc())

package handlers

import (
	"fmt"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

func (h *AdminHandler) GetPerformancePushSettings(c *gin.Context) {
	if h.perfPush == nil {
		models.SendError(c, 500, 5000, "performance push service unavailable")
		return
	}
	settings, err := h.perfPush.GetSettings(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", settings)
}

func (h *AdminHandler) SavePerformancePushToken(c *gin.Context) {
	if h.perfPush == nil {
		models.SendError(c, 500, 5000, "performance push service unavailable")
		return
	}
	var req struct {
		BotToken string `json:"botToken"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	settings, err := h.perfPush.SaveBotToken(c.Request.Context(), req.BotToken)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "PERFORMANCE", "保存绩效 Telegram 推送 Bot Token", "", settings.BotUsername)
	models.Send(c, 200, 0, "Token 已保存", settings)
}

func (h *AdminHandler) SavePerformancePushEnabled(c *gin.Context) {
	if h.perfPush == nil {
		models.SendError(c, 500, 5000, "performance push service unavailable")
		return
	}
	var req struct {
		Enabled bool `json:"enabled"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	settings, err := h.perfPush.SetPushEnabled(c.Request.Context(), req.Enabled)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	action := "关闭绩效 Telegram 自动推送"
	if req.Enabled {
		action = "开启绩效 Telegram 自动推送"
	}
	Log(c, "UPDATE", "PERFORMANCE", action, "", fmt.Sprintf("enabled=%v", req.Enabled))
	models.Send(c, 200, 0, "已保存", settings)
}

func (h *AdminHandler) DiscoverPerformancePushChats(c *gin.Context) {
	if h.perfPush == nil {
		models.SendError(c, 500, 5000, "performance push service unavailable")
		return
	}
	groups, err := h.perfPush.DiscoverChats(c.Request.Context())
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", groups)
}

func (h *AdminHandler) BindPerformancePushChat(c *gin.Context) {
	if h.perfPush == nil {
		models.SendError(c, 500, 5000, "performance push service unavailable")
		return
	}
	var req struct {
		ChatID    string `json:"chatId" binding:"required"`
		ChatTitle string `json:"chatTitle"`
		ChatType  string `json:"chatType"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	settings, err := h.perfPush.BindChat(c.Request.Context(), req.ChatID, req.ChatTitle, req.ChatType)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "PERFORMANCE",
		fmt.Sprintf("绑定绩效推送频道/群组：%s", settings.ChatTitle),
		settings.ChatID, settings.ChatTitle)
	models.Send(c, 200, 0, "绑定成功", settings)
}

func (h *AdminHandler) UnbindPerformancePushChat(c *gin.Context) {
	if h.perfPush == nil {
		models.SendError(c, 500, 5000, "performance push service unavailable")
		return
	}
	settings, err := h.perfPush.UnbindChat(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "PERFORMANCE", "解绑绩效推送频道/群组", "", "")
	models.Send(c, 200, 0, "已解绑", settings)
}

func (h *AdminHandler) TestPerformancePush(c *gin.Context) {
	if h.perfPush == nil {
		models.SendError(c, 500, 5000, "performance push service unavailable")
		return
	}
	if err := h.perfPush.TestPush(c.Request.Context()); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	Log(c, "UPDATE", "PERFORMANCE", "测试绩效 Telegram 推送", "", "")
	models.Send(c, 200, 0, "测试消息已发送", nil)
}

func (h *AdminHandler) NotifyPerformancePush(c *gin.Context) {
	if h.perfPush == nil {
		models.Send(c, 200, 0, "skipped", gin.H{"sent": false})
		return
	}
	var req services.PerformancePushRecord
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	sent, err := h.perfPush.PushScoreRecord(c.Request.Context(), req)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if sent {
		change := "加分"
		if req.Score < 0 {
			change = "扣分"
		}
		Log(c, "CREATE", "PERFORMANCE",
			fmt.Sprintf("推送绩效%s：%s %s %d分（%s）", change, req.Date, req.EmployeeName, req.Score, req.Reason),
			req.EmployeeName, req.EmployeeName)
	}
	models.Send(c, 200, 0, "success", gin.H{"sent": sent})
}

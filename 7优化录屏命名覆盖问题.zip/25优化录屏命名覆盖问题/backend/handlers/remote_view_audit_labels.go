package handlers

import (
	"encoding/json"
	"strconv"
	"strings"
)

var remoteViewAuditActionLabels = map[string]string{
	"session_start": "开始远程查看",
	"viewer_join":   "加入查看",
	"viewer_leave":  "离开查看",
	"session_stop":  "结束远程查看",
}

// NormalizeRemoteViewAuditAction 将远程审计动作转为中文展示
func NormalizeRemoteViewAuditAction(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "未知操作"
	}
	if cn, ok := remoteViewAuditActionLabels[value]; ok {
		return cn
	}
	return value
}

// FormatRemoteViewAuditDetail 将远程审计详情 JSON 转为中文可读文本
func FormatRemoteViewAuditDetail(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "无附加信息"
	}

	var payload map[string]interface{}
	if err := json.Unmarshal([]byte(raw), &payload); err != nil {
		return raw
	}
	if len(payload) == 0 {
		return "无附加信息"
	}

	parts := make([]string, 0, len(payload))
	if roomName, ok := payload["roomName"].(string); ok && strings.TrimSpace(roomName) != "" {
		parts = append(parts, "房间："+strings.TrimSpace(roomName))
	}
	if count, ok := payload["viewerCount"]; ok {
		switch v := count.(type) {
		case float64:
			parts = append(parts, formatViewerCount(int(v)))
		case int:
			parts = append(parts, formatViewerCount(v))
		}
	}

	if len(parts) == 0 {
		return raw
	}
	return strings.Join(parts, "；")
}

func formatViewerCount(count int) string {
	if count <= 0 {
		return "剩余观众：0 人（会话即将结束）"
	}
	return "剩余观众：" + strconv.Itoa(count) + " 人"
}

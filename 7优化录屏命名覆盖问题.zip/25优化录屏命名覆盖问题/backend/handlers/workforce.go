package handlers

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type WorkforceHandler struct {
	db        *sql.DB
	workforce *services.WorkforceService
	telegram  *services.WorkforceTelegramService
	userRepo  *services.UserRepository
	deviceRepo *services.DeviceRepository
	wsHub     *services.WebSocketHub
}

func NewWorkforceHandler(db *sql.DB, workforce *services.WorkforceService, telegram *services.WorkforceTelegramService, userRepo *services.UserRepository, deviceRepo *services.DeviceRepository, wsHub *services.WebSocketHub) *WorkforceHandler {
	return &WorkforceHandler{db: db, workforce: workforce, telegram: telegram, userRepo: userRepo, deviceRepo: deviceRepo, wsHub: wsHub}
}

// CreateEmployeeAccount orchestrates user + employee + invite + today attendance.
func (h *WorkforceHandler) CreateEmployeeAccount(c *gin.Context) {
	var req struct {
		Username     string `json:"username" binding:"required"`
		Password     string `json:"password" binding:"required,min=6"`
		EmployeeID   string `json:"employee_id"`
		Name         string `json:"name" binding:"required"`
		Position     string `json:"position"`
		Department   string `json:"department"`
		HireDate     string `json:"hire_date"`
		WorkLocation string `json:"work_location"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	createdBy := parseContextUserUUID(c)

	result, err := h.workforce.CreateEmployeeAccount(c.Request.Context(), &services.CreateEmployeeAccountInput{
		Username:     req.Username,
		Password:     req.Password,
		EmployeeID:   req.EmployeeID,
		Name:         req.Name,
		Position:     req.Position,
		Department:   req.Department,
		HireDate:     req.HireDate,
		WorkLocation: req.WorkLocation,
		CreatedBy:    createdBy,
	})
	if err != nil {
		if strings.Contains(err.Error(), "duplicate") || strings.Contains(err.Error(), "unique") {
			models.SendError(c, 400, 1001, "username or employee id already exists")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	Log(c, "CREATE", "EMPLOYEE_ACCOUNT",
		fmt.Sprintf("创建员工子账号：%s（登录名 %s）", req.Name, req.Username),
		result.EmployeeID.String(), req.Name)

	models.Send(c, 200, 0, "Employee account created", gin.H{
		"userId":     result.UserID,
		"employeeId": result.EmployeeID,
		"inviteCode": result.InviteCode,
		"inviteId":   result.InviteID,
	})
}

func inviteCodeRowJSON(row services.InviteCodeRow) gin.H {
	disposition := services.InviteDisposition(row, time.Now())
	return gin.H{
		"id":               row.ID,
		"code":             row.Code,
		"employeeId":       row.EmployeeID,
		"employeeName":     row.EmployeeName,
		"employeeCode":     row.EmployeeCode,
		"status":           services.InviteStatusLabel(row),
		"disposition":      disposition,
		"dispositionLabel": services.InviteDispositionLabel(disposition),
		"expiresAt":        row.ExpiresAt,
		"usedAt":           row.UsedAt,
		"revokedAt":        row.RevokedAt,
		"supersededAt":     row.SupersededAt,
		"createdAt":        row.CreatedAt,
		"deviceId":         row.DeviceID,
	}
}

func (h *WorkforceHandler) ListInviteCodes(c *gin.Context) {
	var employeeFilter *uuid.UUID
	if eid := c.Query("employee_id"); eid != "" {
		if id, err := uuid.Parse(eid); err == nil {
			employeeFilter = &id
		}
	}

	rows, err := h.workforce.ListCurrentInviteCodes(c.Request.Context(), employeeFilter)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	items := make([]gin.H, 0, len(rows))
	for _, row := range rows {
		items = append(items, inviteCodeRowJSON(row))
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items})
}

func (h *WorkforceHandler) ListInviteCodeHistory(c *gin.Context) {
	var employeeFilter *uuid.UUID
	if eid := c.Query("employee_id"); eid != "" {
		if id, err := uuid.Parse(eid); err == nil {
			employeeFilter = &id
		}
	}

	rows, err := h.workforce.ListInviteCodeHistory(c.Request.Context(), employeeFilter, 500)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	items := make([]gin.H, 0, len(rows))
	for _, row := range rows {
		item := inviteCodeRowJSON(row)
		item["eventLabel"] = inviteCodeEventLabel(row)
		items = append(items, item)
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items})
}

func inviteCodeEventLabel(row services.InviteCodeRow) string {
	now := time.Now()
	disposition := services.InviteDisposition(row, now)
	switch disposition {
	case "active":
		return "新增"
	case "used":
		return "已使用"
	case "expired":
		return "已过期"
	case "revoked":
		return "手动作废"
	case "superseded":
		return "重新生成作废"
	default:
		return disposition
	}
}

func (h *WorkforceHandler) RevokeInviteCode(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid invite id")
		return
	}
	if err := h.workforce.RevokeInviteCode(c.Request.Context(), id); err != nil {
		if errors.Is(err, services.ErrInviteNotFound) {
			models.SendError(c, 404, 2001, "invite not found or already used")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "INVITE_CODE", "作废邀请码", id.String(), id.String())
	models.Send(c, 200, 0, "Invite revoked", nil)
}

func (h *WorkforceHandler) RegenerateInviteCode(c *gin.Context) {
	employeeID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid employee id")
		return
	}
	createdBy := parseContextUserUUID(c)
	row, err := h.workforce.RegenerateInviteCode(c.Request.Context(), employeeID, createdBy)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "CREATE", "INVITE_CODE", fmt.Sprintf("重新生成邀请码（员工 %s）", employeeID), row.ID.String(), employeeID.String())
	item := inviteCodeRowJSON(*row)
	models.Send(c, 200, 0, "Invite regenerated", gin.H{
		"code":     row.Code,
		"inviteId": row.ID,
		"item":     item,
	})
}

func (h *WorkforceHandler) GetPortalMe(c *gin.Context) {
	userID, err := uuid.Parse(c.GetString("userID"))
	if err != nil {
		models.SendError(c, 401, 1002, "unauthorized")
		return
	}

	empID, err := h.workforce.ResolveEmployeeByUserID(c.Request.Context(), userID)
	if err != nil {
		models.SendError(c, 404, 2001, "employee profile not found")
		return
	}

	var name, empNumber, position, department string
	var status int
	_ = h.db.QueryRowContext(c.Request.Context(), `
		SELECT name, COALESCE(employee_id,''), COALESCE(position,''), COALESCE(department,''), status
		FROM employees WHERE id = $1`, empID).Scan(&name, &empNumber, &position, &department, &status)

	today := ""
	var attStatus sql.NullString
	var checkin, checkout sql.NullTime
	_ = h.db.QueryRowContext(c.Request.Context(), `
		SELECT date::text, status, checkin_time, checkout_time FROM attendance_records
		WHERE employee_id = $1 AND date = CURRENT_DATE`, empID).Scan(&today, &attStatus, &checkin, &checkout)

	invites, _ := h.workforce.ListInviteCodes(c.Request.Context(), &empID)
	var activeInvite string
	now := time.Now()
	for _, inv := range invites {
		if services.InviteDisposition(inv, now) == "active" {
			activeInvite = inv.Code
			break
		}
	}

	var deviceBound bool
	var deviceInfo gin.H
	var devID uuid.UUID
	var hostname, agentVer, osVer, devStatus string
	var lastSeen sql.NullTime
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT id, COALESCE(hostname,''), COALESCE(agent_version,''), COALESCE(os_version,''), status, last_seen_at
		FROM devices WHERE employee_uuid = $1 ORDER BY bound_at DESC NULLS LAST LIMIT 1`, empID).
		Scan(&devID, &hostname, &agentVer, &osVer, &devStatus, &lastSeen)
	if err == nil {
		deviceBound = true
		online := "offline"
		if lastSeen.Valid && timeWithinOnline(lastSeen.Time) {
			online = "online"
		}
		deviceInfo = gin.H{
			"id":           devID,
			"hostname":     hostname,
			"agentVersion": agentVer,
			"osVersion":    osVer,
			"status":       devStatus,
			"onlineStatus": online,
			"lastSeenAt":   lastSeen.Time,
		}
	}

	models.Send(c, 200, 0, "success", gin.H{
		"employee": gin.H{
			"id": empID, "name": name, "employeeNumber": empNumber,
			"position": position, "department": department, "status": status,
		},
		"inviteCode":  activeInvite,
		"deviceBound": deviceBound,
		"device":      deviceInfo,
		"todayAttendance": gin.H{
			"date": today, "status": attStatus.String,
			"checkinTime": checkin.Time, "checkoutTime": checkout.Time,
		},
	})
}

func timeWithinOnline(t time.Time) bool {
	return time.Since(t) < 3*time.Minute
}

func (h *WorkforceHandler) GetMyInviteCode(c *gin.Context) {
	userID, _ := uuid.Parse(c.GetString("userID"))
	empID, err := h.workforce.ResolveEmployeeByUserID(c.Request.Context(), userID)
	if err != nil {
		models.SendError(c, 404, 2001, "employee not found")
		return
	}
	invites, err := h.workforce.ListInviteCodes(c.Request.Context(), &empID)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	now := time.Now()
	for _, inv := range invites {
		if services.InviteDisposition(inv, now) == "active" {
			models.Send(c, 200, 0, "success", gin.H{
				"code": inv.Code, "expiresAt": inv.ExpiresAt, "status": "active",
			})
			return
		}
	}
	models.Send(c, 200, 0, "success", gin.H{"code": "", "status": "none"})
}

func (h *WorkforceHandler) GetMyAttendance(c *gin.Context) {
	userID, _ := uuid.Parse(c.GetString("userID"))
	empID, err := h.workforce.ResolveEmployeeByUserID(c.Request.Context(), userID)
	if err != nil {
		models.SendError(c, 404, 2001, "employee not found")
		return
	}
	yearMonth := c.DefaultQuery("year_month", timeNowYearMonth())
	rows, err := h.db.QueryContext(c.Request.Context(), `
		SELECT date::text, status, checkin_time, checkout_time, position_snapshot
		FROM attendance_records WHERE employee_id = $1 AND year_month = $2 ORDER BY date`, empID, yearMonth)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()
	items := []gin.H{}
	for rows.Next() {
		var date, status, snapshot string
		var checkin, checkout sql.NullTime
		if err := rows.Scan(&date, &status, &checkin, &checkout, &snapshot); err != nil {
			continue
		}
		items = append(items, gin.H{
			"date": date, "status": status, "positionSnapshot": snapshot,
			"checkinTime": checkin.Time, "checkoutTime": checkout.Time,
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"yearMonth": yearMonth, "items": items})
}

func (h *WorkforceHandler) GetMyDevice(c *gin.Context) {
	userID, _ := uuid.Parse(c.GetString("userID"))
	empID, err := h.workforce.ResolveEmployeeByUserID(c.Request.Context(), userID)
	if err != nil {
		models.SendError(c, 404, 2001, "employee not found")
		return
	}
	var devID uuid.UUID
	var hostname, agentVer, osVer, status string
	var lastSeen sql.NullTime
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT id, hostname, agent_version, os_version, status, last_seen_at
		FROM devices WHERE employee_uuid = $1 LIMIT 1`, empID).
		Scan(&devID, &hostname, &agentVer, &osVer, &status, &lastSeen)
	if err == sql.ErrNoRows {
		models.Send(c, 200, 0, "success", gin.H{"bound": false})
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	online := "offline"
	if lastSeen.Valid && timeWithinOnline(lastSeen.Time) {
		online = "online"
	}
	models.Send(c, 200, 0, "success", gin.H{
		"bound": true,
		"device": gin.H{
			"id": devID, "hostname": hostname, "agentVersion": agentVer,
			"osVersion": osVer, "status": status, "onlineStatus": online, "lastSeenAt": lastSeen.Time,
		},
	})
}

func (h *WorkforceHandler) GetClientDownload(c *gin.Context) {
	localPath, externalURL, fileName := resolveClientInstaller()
	version := strings.TrimSpace(os.Getenv("CLIENT_VERSION"))

	if externalURL != "" {
		models.Send(c, 200, 0, "success", gin.H{
			"downloadUrl": externalURL,
			"version":     version,
			"fileName":    fileName,
			"mode":        "external",
		})
		return
	}

	if _, err := os.Stat(localPath); err != nil {
		models.Send(c, 200, 0, "success", gin.H{
			"downloadUrl": "/api/v1/employee/client-download/file",
			"version":     version,
			"fileName":    fileName,
			"mode":        "api",
			"available":   false,
		})
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"downloadUrl": "/api/v1/employee/client-download/file",
		"version":     version,
		"fileName":    fileName,
		"mode":        "api",
		"available":   true,
	})
}

func (h *WorkforceHandler) DownloadClientFile(c *gin.Context) {
	localPath, externalURL, fileName := resolveClientInstaller()
	if externalURL != "" {
		c.Redirect(http.StatusFound, externalURL)
		return
	}

	if _, err := os.Stat(localPath); err != nil {
		models.SendError(c, 404, 3001, "Client installer not found. Ask admin to place the file in downloads/ or set CLIENT_DOWNLOAD_URL")
		return
	}

	c.Header("Content-Disposition", "attachment; filename="+fileName)
	c.Header("Content-Type", "application/octet-stream")
	c.File(localPath)
}

func resolveClientInstaller() (localPath, externalURL, fileName string) {
	fileName = strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_FILE"))
	if fileName == "" {
		fileName = "EnterpriseAgent-setup.exe"
	}

	configured := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_URL"))
	if configured != "" {
		if strings.HasPrefix(configured, "http://") || strings.HasPrefix(configured, "https://") {
			return "", configured, fileName
		}
		if strings.HasPrefix(configured, "/") {
			dir := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_DIR"))
			if dir == "" {
				dir = "./downloads"
			}
			rel := strings.TrimPrefix(configured, "/downloads/")
			if rel == configured {
				rel = filepath.Base(configured)
			}
			return filepath.Join(dir, rel), "", filepath.Base(rel)
		}
		return filepath.Join(configured), "", filepath.Base(configured)
	}

	dir := strings.TrimSpace(os.Getenv("CLIENT_DOWNLOAD_DIR"))
	if dir == "" {
		dir = "./downloads"
	}
	return filepath.Join(dir, fileName), "", fileName
}

func (h *WorkforceHandler) EmployeeLogin(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	var req struct {
		Username string `json:"username" binding:"required"`
		Password string `json:"password" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	result, err := h.workforce.EmployeeLogin(c.Request.Context(), deviceID, req.Username, req.Password)
	if err != nil {
		switch {
		case errors.Is(err, services.ErrInvalidCredentials):
			models.SendError(c, 401, 1002, "Invalid username or password")
		case errors.Is(err, services.ErrNotEmployeeRole):
			models.SendError(c, 403, 1003, "Only employee accounts can login here")
		case errors.Is(err, services.ErrEmployeeOnOtherDevice):
			models.SendError(c, 409, 1004, "Employee is active on another device")
		case errors.Is(err, services.ErrInviteEmployeeMismatch):
			models.SendError(c, 403, 1003, "登录账号与设备邀请码绑定的员工不一致，请使用正确账号或联系管理员")
		case errors.Is(err, services.ErrEmployeeNotFound):
			models.SendError(c, 404, 2001, "Employee profile not found")
		default:
			models.SendError(c, 500, 5000, err.Error())
		}
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type": "employee.login", "deviceId": deviceID.String(),
			"employeeId": result.EmployeeID.String(), "name": result.EmployeeName,
		})
	}
	models.Send(c, 200, 0, "login success", gin.H{
		"employeeId": result.EmployeeID, "name": result.EmployeeName,
		"employeeNumber": result.EmployeeNumber, "position": result.Position,
		"username": result.Username,
	})
}

func (h *WorkforceHandler) EmployeeLogout(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	if err := h.workforce.EmployeeLogout(c.Request.Context(), deviceID); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{"type": "employee.logout", "deviceId": deviceID.String()})
	}
	models.Send(c, 200, 0, "logout success", nil)
}

func (h *WorkforceHandler) GetAgentSession(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	var name, empNumber, position, username sql.NullString
	var empUUID sql.NullString
	var sessionAt sql.NullTime
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT d.employee_uuid::text, d.employee_name, d.employee_number, d.position, u.username,
			d.employee_session_at
		FROM devices d
		LEFT JOIN users u ON u.id = d.user_id
		WHERE d.id = $1`, deviceID).Scan(&empUUID, &name, &empNumber, &position, &username, &sessionAt)
	deviceBound := err == nil && empUUID.Valid && empUUID.String != ""
	if !deviceBound {
		models.Send(c, 200, 0, "success", gin.H{"loggedIn": false, "deviceBound": false})
		return
	}
	loggedIn := sessionAt.Valid

	var workSessionOpen bool
	var workSessionID string
	var openSessionID uuid.UUID
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT ws.id FROM work_sessions ws
		WHERE ws.status = 'open' AND (
			ws.device_id = $1
			OR ws.employee_id = (SELECT employee_uuid FROM devices WHERE id = $1)
		)
		ORDER BY ws.checkin_time DESC LIMIT 1`, deviceID).Scan(&openSessionID)
	if err == nil {
		workSessionOpen = true
		workSessionID = openSessionID.String()
	}

	models.Send(c, 200, 0, "success", gin.H{
		"loggedIn":               loggedIn,
		"deviceBound":            true,
		"employeeId":             empUUID.String,
		"name":                   name.String,
		"employeeNumber":         empNumber.String,
		"position":               position.String,
		"username":               username.String,
		"workSessionOpen":        workSessionOpen,
		"workSessionId":          workSessionID,
		"captureLinkedToCheckin": services.CaptureLinkedToCheckin(c.Request.Context(), h.db),
	})
}

func (h *WorkforceHandler) CheckIn(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	result, err := h.workforce.CheckIn(c.Request.Context(), deviceID)
	if err != nil {
		if errors.Is(err, services.ErrSessionExists) {
			models.SendError(c, 409, 1004, "work session already open")
			return
		}
		if errors.Is(err, services.ErrWorkSessionOpenOnTG) {
			models.SendError(c, 409, 1004, "Telegram 已上班，请先在群内下班")
			return
		}
		if errors.Is(err, services.ErrWorkSessionOpenOnPC) {
			models.SendError(c, 409, 1004, "PC 客户端已上班，请先在客户端下班")
			return
		}
		if errors.Is(err, services.ErrShiftAlreadyCompleted) {
			models.SendError(c, 409, 1004, "今日该班次已打过卡，无法重复上班")
			return
		}
		if errors.Is(err, services.ErrEmployeeNotFound) {
			models.SendError(c, 400, 1001, "please login with employee account first")
			return
		}
		if errors.Is(err, services.ErrEmployeeLoginRequired) {
			models.SendError(c, 400, 1001, "please login with employee account first")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type": "employee.checkin", "deviceId": deviceID.String(),
			"sessionId": result.SessionID.String(), "date": result.Date,
		})
	}
	if h.telegram != nil {
		if empID, err := h.workforce.ResolveEmployeeByDeviceID(c.Request.Context(), deviceID); err == nil {
			shift := result.ShiftType
			go h.telegram.NotifyAgentWorkEvent(context.Background(), empID, shift, "上班", result.SessionID)
		}
	}
	models.Send(c, 200, 0, "checked in", gin.H{
		"sessionId": result.SessionID, "date": result.Date,
	})
}

func (h *WorkforceHandler) CheckOut(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	var req struct {
		SessionID string `json:"sessionId"`
	}
	_ = c.ShouldBindJSON(&req)
	var sid *uuid.UUID
	if req.SessionID != "" {
		if id, err := uuid.Parse(req.SessionID); err == nil {
			sid = &id
		}
	}
	result, err := h.workforce.CheckOut(c.Request.Context(), deviceID, sid)
	if err != nil {
		if errors.Is(err, services.ErrNoOpenSession) {
			models.SendError(c, 404, 2001, "no open work session")
			return
		}
		if errors.Is(err, services.ErrOpenActivityBlocksCheckout) {
			models.SendError(c, 409, 1004, "请先回座结束活动后再下班")
			return
		}
		if errors.Is(err, services.ErrWorkSessionOpenOnTG) {
			models.SendError(c, 409, 1004, "Telegram 已上班，请先在群内下班")
			return
		}
		if errors.Is(err, services.ErrWorkSessionOpenOnPC) {
			models.SendError(c, 409, 1004, "PC 客户端已上班，请先在客户端下班")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if h.wsHub != nil {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type": "employee.checkout", "deviceId": deviceID.String(),
			"sessionId": result.SessionID.String(),
		})
	}
	if h.telegram != nil {
		if empID, err := h.workforce.ResolveEmployeeByDeviceID(c.Request.Context(), deviceID); err == nil {
			shift := result.ShiftType
			go h.telegram.NotifyAgentWorkEvent(context.Background(), empID, shift, "下班", result.SessionID)
		}
	}
	models.Send(c, 200, 0, "checked out", gin.H{"sessionId": result.SessionID})
}

func (h *WorkforceHandler) CreateTelegramBindToken(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	if h.telegram == nil {
		models.SendError(c, 500, 5000, "telegram service unavailable")
		return
	}
	empID, err := h.workforce.ResolveEmployeeByDeviceID(c.Request.Context(), deviceID)
	if err != nil {
		if errors.Is(err, services.ErrEmployeeNotFound) {
			models.SendError(c, 400, 1001, "please login with employee account first")
			return
		}
		models.SendInternalError(c, err)
		return
	}
	var sessionAt sql.NullTime
	_ = h.db.QueryRowContext(c.Request.Context(), `SELECT employee_session_at FROM devices WHERE id = $1`, deviceID).Scan(&sessionAt)
	if !sessionAt.Valid {
		models.SendError(c, 400, 1001, "please login with employee account first")
		return
	}
	result, err := h.telegram.CreateTelegramBindToken(c.Request.Context(), deviceID, empID)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"token":        result.Token,
		"expiresAt":    models.FormatUTC(result.ExpiresAt),
		"botUsername":  result.BotUsername,
		"deepLink":     result.DeepLink,
		"employeeId":   result.EmployeeID,
		"employeeName": result.EmployeeName,
	})
}

func (h *WorkforceHandler) GetTelegramBindStatus(c *gin.Context) {
	deviceID, err := uuid.Parse(c.GetString("deviceID"))
	if err != nil {
		models.SendError(c, 401, 1002, "device unauthorized")
		return
	}
	empID, err := h.workforce.ResolveEmployeeByDeviceID(c.Request.Context(), deviceID)
	if err != nil {
		models.Send(c, 200, 0, "success", gin.H{"bound": false, "loggedIn": false})
		return
	}
	var tgUID sql.NullInt64
	var tgUser sql.NullString
	_ = h.db.QueryRowContext(c.Request.Context(), `
		SELECT telegram_user_id, COALESCE(telegram_username,'')
		FROM employee_telegram_bindings WHERE employee_id = $1 AND status = 1`, empID).Scan(&tgUID, &tgUser)
	models.Send(c, 200, 0, "success", gin.H{
		"bound":            tgUID.Valid,
		"loggedIn":         true,
		"employeeId":       empID,
		"telegramUserId":   tgUID.Int64,
		"telegramUsername": tgUser.String,
	})
}

func (h *WorkforceHandler) DisableEmployee(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid employee id")
		return
	}
	if err := h.workforce.DisableEmployee(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	var userIDStr sql.NullString
	_ = h.db.QueryRowContext(c.Request.Context(), `SELECT user_id::text FROM employees WHERE id = $1`, id).Scan(&userIDStr)
	if userIDStr.Valid && strings.TrimSpace(userIDStr.String) != "" {
		if uid, parseErr := uuid.Parse(strings.TrimSpace(userIDStr.String)); parseErr == nil {
			_ = revokeUserSessions(c.Request.Context(), uid, "user_disabled")
		}
	}
	Log(c, "UPDATE", "EMPLOYEE", "禁用员工（软删除）", id.String(), id.String())
	models.Send(c, 200, 0, "Employee disabled", nil)
}

func timeNowYearMonth() string {
	return time.Now().Format("2006-01")
}

func parseContextUserUUID(c *gin.Context) uuid.UUID {
	raw := strings.TrimSpace(c.GetString("userID"))
	if raw == "" {
		return uuid.Nil
	}
	id, err := uuid.Parse(raw)
	if err != nil {
		return uuid.Nil
	}
	return id
}

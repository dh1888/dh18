package services

import (
	"context"
	"crypto/md5"
	"database/sql"
	"fmt"
	"regexp"
	"strings"
	"time"
	"unicode"

	"github.com/google/uuid"
)

const (
	SalaryWorkModeRemote = "remote"
	SalaryWorkModeOnsite = "onsite"
)

type SalaryWorkConfig struct {
	ConfigKey                  string    `json:"configKey"`
	ConfigName                 string    `json:"configName"`
	WorkMode                   string    `json:"workMode"` // backward-compatible alias of configKey
	TotalIncrease              float64   `json:"totalIncrease"`
	FullAttendanceDays         int       `json:"fullAttendanceDays"`
	FullAttendanceAmount       float64   `json:"fullAttendanceAmount"`
	ExchangeRate               float64   `json:"exchangeRate"`
	PerformanceFullScoreAmount float64   `json:"performanceFullScoreAmount"`
	ProtectionFee              float64   `json:"protectionFee"`
	IsBuiltin                  bool      `json:"isBuiltin"`
	SortOrder                  int       `json:"sortOrder"`
	UpdatedAt                  time.Time `json:"updatedAt"`
}

func (cfg *SalaryWorkConfig) normalizeAliases() {
	if cfg.ConfigKey == "" {
		cfg.ConfigKey = strings.TrimSpace(cfg.WorkMode)
	}
	if cfg.WorkMode == "" {
		cfg.WorkMode = cfg.ConfigKey
	}
	cfg.ConfigName = strings.TrimSpace(cfg.ConfigName)
}

func ResolveSalaryWorkMode(workLocation string) string {
	if strings.Contains(strings.TrimSpace(workLocation), "居家") {
		return SalaryWorkModeRemote
	}
	return SalaryWorkModeOnsite
}

func ResolveSalaryConfigKey(workLocation string, configs []SalaryWorkConfig) string {
	loc := strings.TrimSpace(workLocation)
	if loc == "" {
		return SalaryWorkModeOnsite
	}

	bestKey := ""
	bestLen := 0
	for _, cfg := range configs {
		name := strings.TrimSpace(cfg.ConfigName)
		if name == "" {
			continue
		}
		if loc == name || strings.Contains(loc, name) {
			if len([]rune(name)) > bestLen {
				bestLen = len([]rune(name))
				bestKey = cfg.ConfigKey
			}
		}
	}
	if bestKey != "" {
		return bestKey
	}
	return ResolveSalaryWorkMode(loc)
}

type SalaryConfigService struct {
	db *sql.DB
}

func NewSalaryConfigService(db *sql.DB) *SalaryConfigService {
	return &SalaryConfigService{db: db}
}

func defaultSalaryWorkConfig(key, name string, sortOrder int, builtin bool) SalaryWorkConfig {
	return SalaryWorkConfig{
		ConfigKey:                  key,
		ConfigName:                 name,
		WorkMode:                   key,
		TotalIncrease:              0,
		FullAttendanceDays:         0,
		FullAttendanceAmount:       0,
		ExchangeRate:               0,
		PerformanceFullScoreAmount: 0,
		ProtectionFee:              0,
		IsBuiltin:                  builtin,
		SortOrder:                  sortOrder,
	}
}

func (s *SalaryConfigService) ensureTable(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, `
		CREATE TABLE IF NOT EXISTS salary_configs (
			config_key VARCHAR(64) PRIMARY KEY,
			config_name VARCHAR(64) NOT NULL DEFAULT '',
			total_increase DECIMAL(12,2) NOT NULL DEFAULT 0,
			full_attendance_days INTEGER NOT NULL DEFAULT 0,
			full_attendance_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
			exchange_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
			performance_full_score_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
			protection_fee DECIMAL(12,2) NOT NULL DEFAULT 0,
			sort_order INTEGER NOT NULL DEFAULT 0,
			is_builtin BOOLEAN NOT NULL DEFAULT false,
			updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
		)`)
	if err != nil {
		return err
	}
	return s.migrateLegacySchema(ctx)
}

func (s *SalaryConfigService) migrateLegacySchema(ctx context.Context) error {
	var hasWorkMode bool
	err := s.db.QueryRowContext(ctx, `
		SELECT EXISTS (
			SELECT 1 FROM information_schema.columns
			WHERE table_name = 'salary_configs' AND column_name = 'work_mode'
		)`).Scan(&hasWorkMode)
	if err != nil {
		return err
	}
	if !hasWorkMode {
		return s.seedBuiltinConfigs(ctx)
	}

	_, err = s.db.ExecContext(ctx, `
		ALTER TABLE salary_configs RENAME COLUMN work_mode TO config_key`)
	if err != nil && !strings.Contains(strings.ToLower(err.Error()), "already exists") {
		return err
	}

	migrations := []string{
		`ALTER TABLE salary_configs ALTER COLUMN config_key TYPE VARCHAR(64)`,
		`ALTER TABLE salary_configs ADD COLUMN IF NOT EXISTS config_name VARCHAR(64) NOT NULL DEFAULT ''`,
		`ALTER TABLE salary_configs ADD COLUMN IF NOT EXISTS sort_order INTEGER NOT NULL DEFAULT 0`,
		`ALTER TABLE salary_configs ADD COLUMN IF NOT EXISTS is_builtin BOOLEAN NOT NULL DEFAULT false`,
		`UPDATE salary_configs SET config_name = '居家', is_builtin = true, sort_order = 1
		 WHERE config_key = 'remote' AND (config_name IS NULL OR config_name = '')`,
		`UPDATE salary_configs SET config_name = '现场', is_builtin = true, sort_order = 2
		 WHERE config_key = 'onsite' AND (config_name IS NULL OR config_name = '')`,
		`UPDATE salary_configs SET config_name = config_key
		 WHERE config_name IS NULL OR config_name = ''`,
	}
	for _, stmt := range migrations {
		if _, err := s.db.ExecContext(ctx, stmt); err != nil {
			return err
		}
	}
	return s.seedBuiltinConfigs(ctx)
}

func (s *SalaryConfigService) seedBuiltinConfigs(ctx context.Context) error {
	builtins := []SalaryWorkConfig{
		defaultSalaryWorkConfig(SalaryWorkModeRemote, "居家", 1, true),
		defaultSalaryWorkConfig(SalaryWorkModeOnsite, "现场", 2, true),
	}
	for _, cfg := range builtins {
		_, err := s.db.ExecContext(ctx, `
			INSERT INTO salary_configs (
				config_key, config_name, total_increase, full_attendance_days, full_attendance_amount,
				exchange_rate, performance_full_score_amount, protection_fee, sort_order, is_builtin, updated_at
			) VALUES ($1, $2, 0, 0, 0, 0, 0, 0, $3, $4, NOW())
			ON CONFLICT (config_key) DO NOTHING`,
			cfg.ConfigKey, cfg.ConfigName, cfg.SortOrder, cfg.IsBuiltin)
		if err != nil {
			return err
		}
	}
	return nil
}

func (s *SalaryConfigService) ListConfigs(ctx context.Context) ([]SalaryWorkConfig, error) {
	if err := s.ensureTable(ctx); err != nil {
		return nil, err
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT config_key, config_name, total_increase, full_attendance_days, full_attendance_amount,
		       exchange_rate, performance_full_score_amount, protection_fee, sort_order, is_builtin, updated_at
		FROM salary_configs
		ORDER BY sort_order ASC, config_name ASC, config_key ASC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	out := make([]SalaryWorkConfig, 0)
	for rows.Next() {
		cfg, err := scanSalaryWorkConfig(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, cfg)
	}
	return out, rows.Err()
}

func scanSalaryWorkConfig(scanner interface {
	Scan(dest ...interface{}) error
}) (SalaryWorkConfig, error) {
	var cfg SalaryWorkConfig
	var updatedAt time.Time
	err := scanner.Scan(
		&cfg.ConfigKey, &cfg.ConfigName,
		&cfg.TotalIncrease, &cfg.FullAttendanceDays, &cfg.FullAttendanceAmount,
		&cfg.ExchangeRate, &cfg.PerformanceFullScoreAmount, &cfg.ProtectionFee,
		&cfg.SortOrder, &cfg.IsBuiltin, &updatedAt,
	)
	if err != nil {
		return SalaryWorkConfig{}, err
	}
	cfg.WorkMode = cfg.ConfigKey
	cfg.UpdatedAt = updatedAt
	return cfg, nil
}

func (s *SalaryConfigService) GetConfig(ctx context.Context, configKey string) (SalaryWorkConfig, error) {
	if err := s.ensureTable(ctx); err != nil {
		return SalaryWorkConfig{}, err
	}
	configKey = strings.TrimSpace(configKey)
	cfg := defaultSalaryWorkConfig(configKey, configKey, 0, false)
	var updatedAt time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT config_key, config_name, total_increase, full_attendance_days, full_attendance_amount,
		       exchange_rate, performance_full_score_amount, protection_fee, sort_order, is_builtin, updated_at
		FROM salary_configs WHERE config_key = $1`, configKey).
		Scan(
			&cfg.ConfigKey, &cfg.ConfigName,
			&cfg.TotalIncrease, &cfg.FullAttendanceDays, &cfg.FullAttendanceAmount,
			&cfg.ExchangeRate, &cfg.PerformanceFullScoreAmount, &cfg.ProtectionFee,
			&cfg.SortOrder, &cfg.IsBuiltin, &updatedAt,
		)
	if err == sql.ErrNoRows {
		return cfg, nil
	}
	if err != nil {
		return SalaryWorkConfig{}, err
	}
	cfg.WorkMode = cfg.ConfigKey
	cfg.UpdatedAt = updatedAt
	return cfg, nil
}

func (s *SalaryConfigService) CreateConfig(ctx context.Context, configName string) (SalaryWorkConfig, error) {
	if err := s.ensureTable(ctx); err != nil {
		return SalaryWorkConfig{}, err
	}
	configName = strings.TrimSpace(configName)
	if configName == "" {
		return SalaryWorkConfig{}, fmt.Errorf("配置名称不能为空")
	}

	configKey, err := s.allocateConfigKey(ctx, configName)
	if err != nil {
		return SalaryWorkConfig{}, err
	}

	var maxSort int
	_ = s.db.QueryRowContext(ctx, `SELECT COALESCE(MAX(sort_order), 0) FROM salary_configs`).Scan(&maxSort)

	cfg := defaultSalaryWorkConfig(configKey, configName, maxSort+1, false)
	now := time.Now().UTC()
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO salary_configs (
			config_key, config_name, total_increase, full_attendance_days, full_attendance_amount,
			exchange_rate, performance_full_score_amount, protection_fee, sort_order, is_builtin, updated_at
		) VALUES ($1, $2, 0, 0, 0, 0, 0, 0, $3, false, $4)`,
		cfg.ConfigKey, cfg.ConfigName, cfg.SortOrder, now)
	if err != nil {
		return SalaryWorkConfig{}, err
	}
	return s.GetConfig(ctx, cfg.ConfigKey)
}

func (s *SalaryConfigService) UpsertConfig(ctx context.Context, cfg SalaryWorkConfig) (SalaryWorkConfig, error) {
	if err := s.ensureTable(ctx); err != nil {
		return SalaryWorkConfig{}, err
	}
	cfg.normalizeAliases()
	if cfg.ConfigKey == "" {
		return SalaryWorkConfig{}, fmt.Errorf("configKey is required")
	}
	if cfg.FullAttendanceDays < 0 {
		return SalaryWorkConfig{}, fmt.Errorf("full attendance days cannot be negative")
	}

	existing, err := s.GetConfig(ctx, cfg.ConfigKey)
	if err != nil {
		return SalaryWorkConfig{}, err
	}
	if existing.ConfigKey == "" {
		return SalaryWorkConfig{}, fmt.Errorf("配置不存在")
	}
	if strings.TrimSpace(cfg.ConfigName) == "" {
		cfg.ConfigName = existing.ConfigName
	}

	now := time.Now().UTC()
	_, err = s.db.ExecContext(ctx, `
		UPDATE salary_configs SET
			config_name = $2,
			total_increase = $3,
			full_attendance_days = $4,
			full_attendance_amount = $5,
			exchange_rate = $6,
			performance_full_score_amount = $7,
			protection_fee = $8,
			updated_at = $9
		WHERE config_key = $1`,
		cfg.ConfigKey, cfg.ConfigName,
		cfg.TotalIncrease, cfg.FullAttendanceDays, cfg.FullAttendanceAmount,
		cfg.ExchangeRate, cfg.PerformanceFullScoreAmount, cfg.ProtectionFee, now)
	if err != nil {
		return SalaryWorkConfig{}, err
	}
	return s.GetConfig(ctx, cfg.ConfigKey)
}

func (s *SalaryConfigService) DeleteConfig(ctx context.Context, configKey string) error {
	if err := s.ensureTable(ctx); err != nil {
		return err
	}
	configKey = strings.TrimSpace(configKey)
	if configKey == SalaryWorkModeRemote || configKey == SalaryWorkModeOnsite {
		return fmt.Errorf("内置配置不可删除")
	}
	res, err := s.db.ExecContext(ctx, `DELETE FROM salary_configs WHERE config_key = $1 AND is_builtin = false`, configKey)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return fmt.Errorf("配置不存在或不可删除")
	}
	return nil
}

func (s *SalaryConfigService) allocateConfigKey(ctx context.Context, configName string) (string, error) {
	base := slugifyConfigKey(configName)
	key := base
	for i := 0; i < 20; i++ {
		var exists bool
		if err := s.db.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM salary_configs WHERE config_key = $1)`, key).Scan(&exists); err != nil {
			return "", err
		}
		if !exists {
			var nameExists bool
			if err := s.db.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM salary_configs WHERE config_name = $1)`, configName).Scan(&nameExists); err != nil {
				return "", err
			}
			if nameExists {
				return "", fmt.Errorf("配置名称「%s」已存在", configName)
			}
			return key, nil
		}
		key = fmt.Sprintf("%s_%d", base, i+1)
	}
	return "", fmt.Errorf("无法生成唯一配置标识")
}

var nonSlugChars = regexp.MustCompile(`[^a-z0-9]+`)

func slugifyConfigKey(name string) string {
	name = strings.TrimSpace(name)
	if name == "" {
		return "cfg_" + uuid.NewString()[:8]
	}

	asciiOnly := true
	for _, r := range name {
		if r > unicode.MaxASCII {
			asciiOnly = false
			break
		}
	}
	if !asciiOnly {
		sum := md5.Sum([]byte(name))
		return fmt.Sprintf("cfg_%x", sum[:4])
	}

	key := strings.ToLower(name)
	key = nonSlugChars.ReplaceAllString(key, "_")
	key = strings.Trim(key, "_")
	if key == "" {
		return "cfg_" + uuid.NewString()[:8]
	}
	if len(key) > 48 {
		key = key[:48]
	}
	return key
}

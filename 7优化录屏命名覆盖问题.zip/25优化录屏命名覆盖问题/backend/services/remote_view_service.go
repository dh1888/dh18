package services

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"

	"enterprise-agent/backend/config"
	"enterprise-agent/backend/models"
)

const (
	remoteViewStartAgentDelay    = 300 * time.Millisecond
	remoteViewIngressDeleteDelay = 2 * time.Second
)

type RemoteViewService struct {
	cfg         config.LiveKitConfig
	repo        *RemoteViewRepository
	deviceRepo  *DeviceRepository
	policyRepo  *PolicyRepository
	wsHub       *WebSocketHub
	tokens      *LiveKitTokenService
	ingress     *liveKitIngressClient
	statsMu     sync.RWMutex
	deviceStats map[string]*models.RemoteViewStatsPayload
	startLocks  sync.Map
}

func NewRemoteViewService(
	cfg config.LiveKitConfig,
	repo *RemoteViewRepository,
	deviceRepo *DeviceRepository,
	policyRepo *PolicyRepository,
	wsHub *WebSocketHub,
) *RemoteViewService {
	svc := &RemoteViewService{
		cfg:         cfg,
		repo:        repo,
		deviceRepo:  deviceRepo,
		policyRepo:  policyRepo,
		wsHub:       wsHub,
		tokens:      NewLiveKitTokenService(cfg.APIKey, cfg.APISecret, cfg.TokenTTL),
		deviceStats: make(map[string]*models.RemoteViewStatsPayload),
	}
	if cfg.Enabled() {
		svc.ingress = newLiveKitIngressClient(cfg.APIHost, cfg.APIKey, cfg.APISecret, cfg.RTMPBaseURL)
	}
	return svc
}

func (s *RemoteViewService) UpdateDeviceStats(deviceID string, stats *models.RemoteViewStatsPayload) {
	if stats == nil {
		return
	}
	s.statsMu.Lock()
	s.deviceStats[deviceID] = stats
	s.statsMu.Unlock()

	if s.wsHub != nil {
		s.wsHub.BroadcastToAdmin(gin.H{
			"type":        "remote_view_stats",
			"deviceId":    deviceID,
			"fps":         stats.FPS,
			"bitrateKbps": stats.BitrateKbps,
			"encoder":     stats.Encoder,
		})
	}
}

func (s *RemoteViewService) GetDeviceStats(deviceID string) *models.RemoteViewStatsPayload {
	s.statsMu.RLock()
	defer s.statsMu.RUnlock()
	return s.deviceStats[deviceID]
}

func (s *RemoteViewService) StartSession(
	ctx context.Context,
	deviceIDStr, userIDStr, username, clientIP string,
) (*models.RemoteViewStartResponse, error) {
	if !s.cfg.Enabled() {
		return nil, fmt.Errorf("livekit is not configured")
	}

	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid device id")
	}

	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid user id")
	}

	device, err := s.deviceRepo.Get(ctx, deviceID)
	if err != nil {
		return nil, fmt.Errorf("device not found")
	}

	if !s.wsHub.IsAgentOnline(deviceIDStr) {
		return nil, fmt.Errorf("device is not connected")
	}

	unlock := s.lockDeviceStart(deviceIDStr)
	defer unlock()

	s.expireStaleStartingIfNeeded(ctx, deviceID)

	roomName := config.RoomNameForDevice(deviceIDStr)
	expiresAt := models.UTCNow().Add(s.cfg.TokenTTL)

	active, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err == nil && active != nil {
		if active.ViewerCount >= s.cfg.MaxViewersPerDev {
			return nil, fmt.Errorf("maximum viewers reached for this device")
		}

		viewerToken, err := s.tokens.CreateSubscriberToken(roomName, userIDStr, active.ID.String())
		if err != nil {
			return nil, err
		}

		if _, err := s.repo.IncrementViewerCount(ctx, active.ID); err != nil {
			return nil, err
		}

		s.writeAudit(ctx, &active.ID, deviceID, userID, username, "viewer_join", clientIP, gin.H{
			"roomName": roomName,
		})

		return &models.RemoteViewStartResponse{
			SessionID:   active.ID.String(),
			DeviceID:    deviceIDStr,
			DeviceName:  device.Hostname,
			RoomName:    roomName,
			LiveKitURL:  s.cfg.URL,
			ViewerToken: viewerToken,
			ExpiresAt:   expiresAt,
		}, nil
	}

	sessionID := uuid.New()
	now := models.UTCNow()
	session := &models.RemoteViewSession{
		ID:                sessionID,
		DeviceID:          deviceID,
		RoomName:          roomName,
		Status:            models.RemoteViewStatusStarting,
		StartedBy:         userID,
		StartedByName:     username,
		ViewerCount:       1,
		PublisherIdentity: "agent-" + deviceIDStr,
		LiveKitURL:        s.cfg.URL,
		StartedAt:         now,
		CreatedAt:         now,
		UpdatedAt:         now,
	}

	rtmpURL, ingressID, err := s.ensureIngress(ctx, roomName, deviceIDStr)
	if err != nil {
		return nil, err
	}
	session.IngressID = ingressID
	session.RTMPURL = rtmpURL

	if err := s.repo.Create(ctx, session); err != nil {
		if s.ingress != nil && ingressID != "" {
			_ = s.ingress.DeleteIngress(ctx, ingressID)
		}
		return nil, err
	}

	viewerToken, err := s.tokens.CreateSubscriberToken(roomName, userIDStr, sessionID.String())
	if err != nil {
		return nil, err
	}

	s.writeAudit(ctx, &sessionID, deviceID, userID, username, "session_start", clientIP, gin.H{
		"roomName": roomName,
	})

	go func() {
		time.Sleep(remoteViewStartAgentDelay)
		rv := s.resolveRemoteViewPublishParams(ctx)
		s.wsHub.SendCommandToDevice(deviceIDStr, "start_remote_view", gin.H{
			"sessionId": sessionID.String(),
			"roomName":  roomName,
			"livekitUrl": s.cfg.URL,
			"rtmpUrl":   rtmpURL,
			"width":     rv.Width,
			"height":    rv.Height,
			"fps":       rv.Fps,
		})
		log.Printf("[RemoteView] start_remote_view sent to device %s session=%s rtmp=%s size=%dx%d@%d",
			deviceIDStr, sessionID, maskRTMPURL(rtmpURL), rv.Width, rv.Height, rv.Fps)
	}()

	return &models.RemoteViewStartResponse{
		SessionID:   sessionID.String(),
		DeviceID:    deviceIDStr,
		DeviceName:  device.Hostname,
		RoomName:    roomName,
		LiveKitURL:  s.cfg.URL,
		ViewerToken: viewerToken,
		ExpiresAt:   expiresAt,
	}, nil
}

func (s *RemoteViewService) resolveRemoteViewPublishParams(ctx context.Context) models.RemoteViewPolicyConfig {
	defaults := models.RemoteViewPolicyConfig{
		Width:  models.DefaultRemoteViewWidth,
		Height: models.DefaultRemoteViewHeight,
		Fps:    models.DefaultRemoteViewFps,
	}
	if s.policyRepo == nil {
		return defaults
	}

	policy, err := s.policyRepo.GetCurrent(ctx)
	if err != nil || policy == nil {
		return defaults
	}

	return models.ParseRemoteViewFromPolicyContent(string(policy.Content))
}

func (s *RemoteViewService) StopSession(
	ctx context.Context,
	deviceIDStr, userIDStr, username, sessionIDStr, clientIP string,
) (bool, error) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return false, fmt.Errorf("invalid device id")
	}

	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		return false, fmt.Errorf("invalid user id")
	}

	var session *models.RemoteViewSession
	if sessionIDStr != "" {
		sessionID, parseErr := uuid.Parse(sessionIDStr)
		if parseErr != nil {
			return false, fmt.Errorf("invalid session id")
		}
		session, err = s.repo.GetByID(ctx, sessionID)
	} else {
		session, err = s.repo.GetActiveByDevice(ctx, deviceID)
	}
	if err != nil || session == nil {
		return false, fmt.Errorf("session not found")
	}

	if session.DeviceID != deviceID {
		return false, fmt.Errorf("session does not belong to device")
	}

	// 已结束或正在结束：幂等返回，避免重复减计数、重复删 Ingress
	if session.Status == models.RemoteViewStatusStopped || session.Status == models.RemoteViewStatusStopping {
		return false, nil
	}

	sessionDeviceID := session.DeviceID.String()

	viewerCount, err := s.repo.DecrementViewerCount(ctx, session.ID)
	if err != nil {
		return false, err
	}

	s.writeAudit(ctx, &session.ID, deviceID, userID, username, "viewer_leave", clientIP, gin.H{
		"viewerCount": viewerCount,
	})

	publisherStopped := false
	if viewerCount <= 0 {
		_ = s.repo.UpdateStatus(ctx, session.ID, models.RemoteViewStatusStopping)
		s.wsHub.SendCommandToDevice(sessionDeviceID, "stop_remote_view", gin.H{
			"sessionId": session.ID.String(),
		})
		if s.ingress != nil && session.IngressID != "" {
			s.scheduleIngressDelete(session.IngressID)
		}
		_ = s.repo.MarkStopped(ctx, session.ID, "user_stop")
		s.statsMu.Lock()
		delete(s.deviceStats, sessionDeviceID)
		s.statsMu.Unlock()
		publisherStopped = true

		s.writeAudit(ctx, &session.ID, deviceID, userID, username, "session_stop", clientIP, nil)
	}

	return publisherStopped, nil
}

func (s *RemoteViewService) GetStatus(ctx context.Context, deviceIDStr string) (*models.RemoteViewStatusResponse, error) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid device id")
	}

	s.expireStaleStartingIfNeeded(ctx, deviceID)

	session, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err != nil {
		return &models.RemoteViewStatusResponse{IsActive: false}, nil
	}

	resp := &models.RemoteViewStatusResponse{
		IsActive:    true,
		SessionID:   session.ID.String(),
		Status:      session.Status,
		ViewerCount: session.ViewerCount,
		StartedAt:   models.FormatUTC(session.StartedAt),
		Stats:       s.GetDeviceStats(deviceIDStr),
	}
	return resp, nil
}

func (s *RemoteViewService) MarkSessionActive(ctx context.Context, deviceIDStr, sessionIDStr string) error {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return fmt.Errorf("invalid device id")
	}
	sessionID, err := uuid.Parse(sessionIDStr)
	if err != nil {
		return fmt.Errorf("invalid session id")
	}

	session, err := s.repo.GetByID(ctx, sessionID)
	if err != nil || session == nil {
		return fmt.Errorf("session not found")
	}
	if session.DeviceID != deviceID {
		return fmt.Errorf("session does not belong to device")
	}
	if session.Status == models.RemoteViewStatusStopped {
		return fmt.Errorf("session already stopped")
	}

	return s.repo.UpdateStatus(ctx, sessionID, models.RemoteViewStatusActive)
}

func (s *RemoteViewService) MarkSessionFailed(ctx context.Context, deviceIDStr, sessionIDStr, reason string) error {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return fmt.Errorf("invalid device id")
	}
	sessionID, err := uuid.Parse(sessionIDStr)
	if err != nil {
		return fmt.Errorf("invalid session id")
	}
	if strings.TrimSpace(reason) == "" {
		reason = "publish_failed"
	}

	session, err := s.repo.GetByID(ctx, sessionID)
	if err != nil || session == nil {
		return fmt.Errorf("session not found")
	}
	if session.DeviceID != deviceID {
		return fmt.Errorf("session does not belong to device")
	}
	if session.Status == models.RemoteViewStatusStopped || session.Status == models.RemoteViewStatusFailed {
		return nil
	}

	if s.ingress != nil && session.IngressID != "" {
		s.scheduleIngressDelete(session.IngressID)
	}
	if err := s.repo.MarkFailed(ctx, session.ID, reason); err != nil {
		return err
	}
	s.statsMu.Lock()
	delete(s.deviceStats, deviceIDStr)
	s.statsMu.Unlock()
	return nil
}

func (s *RemoteViewService) expireStaleStartingIfNeeded(ctx context.Context, deviceID uuid.UUID) {
	session, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err != nil || session == nil {
		return
	}
	if session.Status != models.RemoteViewStatusStarting {
		return
	}
	if time.Since(session.UpdatedAt) < s.cfg.StartingTimeout {
		return
	}

	log.Printf("[RemoteView] expiring stale starting session %s for device %s", session.ID, deviceID)
	if s.ingress != nil && session.IngressID != "" {
		_ = s.ingress.DeleteIngress(ctx, session.IngressID)
	}
	_ = s.repo.MarkFailed(ctx, session.ID, "starting_timeout")
	s.statsMu.Lock()
	delete(s.deviceStats, deviceID.String())
	s.statsMu.Unlock()
	s.wsHub.SendCommandToDevice(deviceID.String(), "stop_remote_view", gin.H{
		"sessionId": session.ID.String(),
	})
}

func (s *RemoteViewService) lockDeviceStart(deviceID string) func() {
	v, _ := s.startLocks.LoadOrStore(deviceID, &sync.Mutex{})
	mu := v.(*sync.Mutex)
	mu.Lock()
	return mu.Unlock
}

func (s *RemoteViewService) PingLiveKit(ctx context.Context) error {
	if s.ingress == nil {
		return fmt.Errorf("livekit is not configured")
	}
	return s.ingress.Ping(ctx)
}

func (s *RemoteViewService) ensureIngress(ctx context.Context, roomName, deviceID string) (string, string, error) {
	if s.ingress == nil {
		return "", "", fmt.Errorf("livekit ingress client not configured")
	}

	rtmpURL, ingressID, err := s.ingress.CreateRTMPIngress(ctx, roomName, deviceID)
	if err != nil {
		return "", "", fmt.Errorf("create ingress: %w", err)
	}
	return rtmpURL, ingressID, nil
}

// scheduleIngressDelete waits before tearing down Ingress so the agent can finish RTMP teardown.
func (s *RemoteViewService) scheduleIngressDelete(ingressID string) {
	if s.ingress == nil || ingressID == "" {
		return
	}
	go func(id string) {
		time.Sleep(remoteViewIngressDeleteDelay)
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		if err := s.ingress.DeleteIngress(ctx, id); err != nil {
			log.Printf("[RemoteView] delete ingress failed: %v", err)
		}
	}(ingressID)
}

func (s *RemoteViewService) writeAudit(
	ctx context.Context,
	sessionID *uuid.UUID,
	deviceID, operatorID uuid.UUID,
	operatorName, action, clientIP string,
	detail interface{},
) {
	entry := &models.RemoteViewAuditLog{
		ID:           uuid.New(),
		SessionID:    sessionID,
		DeviceID:     deviceID,
		OperatorID:   operatorID,
		OperatorName: operatorName,
		Action:       action,
		Detail:       auditDetail(detail),
		ClientIP:     clientIP,
		CreatedAt:    models.UTCNow(),
	}
	if err := s.repo.InsertAudit(ctx, entry); err != nil {
		log.Printf("[RemoteView] audit insert failed: %v", err)
	}
}

func (s *RemoteViewService) ListAuditLogs(ctx context.Context, deviceID *uuid.UUID, page, pageSize int) ([]models.RemoteViewAuditLog, int, error) {
	return s.repo.ListAuditLogs(ctx, deviceID, page, pageSize)
}

func (s *RemoteViewService) OnAgentDisconnected(ctx context.Context, deviceIDStr string) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return
	}
	session, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err != nil || session == nil {
		return
	}
	_ = s.repo.MarkStopped(ctx, session.ID, "agent_offline")
	if s.ingress != nil && session.IngressID != "" {
		_ = s.ingress.DeleteIngress(ctx, session.IngressID)
	}
	s.statsMu.Lock()
	delete(s.deviceStats, deviceIDStr)
	s.statsMu.Unlock()
}

type LiveKitTokenService struct {
	apiKey    string
	apiSecret string
	ttl       time.Duration
}

func NewLiveKitTokenService(apiKey, apiSecret string, ttl time.Duration) *LiveKitTokenService {
	return &LiveKitTokenService{
		apiKey:    apiKey,
		apiSecret: apiSecret,
		ttl:       ttl,
	}
}

type liveKitVideoGrant struct {
	RoomJoin      bool   `json:"roomJoin,omitempty"`
	Room          string `json:"room,omitempty"`
	CanPublish    bool   `json:"canPublish,omitempty"`
	CanSubscribe  bool   `json:"canSubscribe,omitempty"`
	IngressAdmin  bool   `json:"ingressAdmin,omitempty"`
}

type liveKitClaims struct {
	Video liveKitVideoGrant `json:"video"`
	jwt.RegisteredClaims
}

func (s *LiveKitTokenService) signToken(identity string, grant liveKitVideoGrant) (string, error) {
	if s.apiKey == "" || s.apiSecret == "" {
		return "", fmt.Errorf("livekit api credentials not configured")
	}

	now := time.Now()
	claims := liveKitClaims{
		Video: grant,
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    s.apiKey,
			Subject:   identity,
			NotBefore: jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(s.ttl)),
			IssuedAt:  jwt.NewNumericDate(now),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.apiSecret))
}

func (s *LiveKitTokenService) CreateSubscriberToken(roomName, userID, sessionID string) (string, error) {
	return s.signToken(fmt.Sprintf("viewer-%s-%s", userID, sessionID), liveKitVideoGrant{
		RoomJoin:     true,
		Room:         roomName,
		CanPublish:   false,
		CanSubscribe: true,
	})
}

func (s *LiveKitTokenService) createAdminToken(ttl time.Duration) (string, error) {
	if s.apiKey == "" || s.apiSecret == "" {
		return "", fmt.Errorf("livekit api credentials not configured")
	}
	now := time.Now()
	claims := liveKitClaims{
		Video: liveKitVideoGrant{IngressAdmin: true},
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    s.apiKey,
			NotBefore: jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(ttl)),
			IssuedAt:  jwt.NewNumericDate(now),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.apiSecret))
}

type liveKitIngressClient struct {
	apiHost     string
	apiKey      string
	apiSecret   string
	rtmpBaseURL string
	http        *http.Client
	tokens      *LiveKitTokenService
}

func newLiveKitIngressClient(apiHost, apiKey, apiSecret, rtmpBaseURL string) *liveKitIngressClient {
	return &liveKitIngressClient{
		apiHost:     strings.TrimSuffix(apiHost, "/"),
		apiKey:      apiKey,
		apiSecret:   apiSecret,
		rtmpBaseURL: strings.TrimSuffix(strings.TrimSpace(rtmpBaseURL), "/"),
		http:        &http.Client{Timeout: 15 * time.Second},
		tokens:      NewLiveKitTokenService(apiKey, apiSecret, 5*time.Minute),
	}
}

type createIngressRequest struct {
	InputType           int    `json:"input_type"`
	Name                string `json:"name"`
	RoomName            string `json:"room_name"`
	ParticipantIdentity string `json:"participant_identity"`
	ParticipantName     string `json:"participant_name"`
}

type ingressInfoResponse struct {
	IngressId string `json:"ingress_id"`
	Url       string `json:"url"`
	StreamKey string `json:"stream_key"`
}

func (c *liveKitIngressClient) CreateRTMPIngress(ctx context.Context, roomName, deviceID string) (rtmpURL, ingressID string, err error) {
	body, _ := json.Marshal(createIngressRequest{
		InputType:           0,
		Name:                roomName,
		RoomName:            roomName,
		ParticipantIdentity: "agent-" + deviceID,
		ParticipantName:     "agent-" + deviceID,
	})

	token, err := c.tokens.createAdminToken(5 * time.Minute)
	if err != nil {
		return "", "", err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.apiHost+"/twirp/livekit.Ingress/CreateIngress", bytes.NewReader(body))
	if err != nil {
		return "", "", err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return "", "", err
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", "", fmt.Errorf("create ingress http %d: %s", resp.StatusCode, string(respBody))
	}

	var info ingressInfoResponse
	if err := json.Unmarshal(respBody, &info); err != nil {
		return "", "", err
	}

	rtmpURL, err = normalizeRTMPIngressURL(c.rtmpBaseURL, info.Url, info.StreamKey)
	if err != nil {
		return "", "", fmt.Errorf("normalize rtmp url: %w", err)
	}
	return rtmpURL, info.IngressId, nil
}

func (c *liveKitIngressClient) DeleteIngress(ctx context.Context, ingressID string) error {
	body, _ := json.Marshal(map[string]string{"ingress_id": ingressID})

	token, err := c.tokens.createAdminToken(5 * time.Minute)
	if err != nil {
		return err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.apiHost+"/twirp/livekit.Ingress/DeleteIngress", bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		respBody, _ := io.ReadAll(resp.Body)
		if isIngressNotFound(resp.StatusCode, string(respBody)) {
			return nil
		}
		return fmt.Errorf("delete ingress http %d: %s", resp.StatusCode, string(respBody))
	}
	return nil
}

func (c *liveKitIngressClient) Ping(ctx context.Context) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.apiHost, nil)
	if err != nil {
		return err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 400 {
		return fmt.Errorf("livekit http %d", resp.StatusCode)
	}
	return nil
}

type RemoteViewRepository struct {
	db *sql.DB
}

func NewRemoteViewRepository(db *sql.DB) *RemoteViewRepository {
	return &RemoteViewRepository{db: db}
}

func (r *RemoteViewRepository) GetActiveByDevice(ctx context.Context, deviceID uuid.UUID) (*models.RemoteViewSession, error) {
	row := r.db.QueryRowContext(ctx, `
		SELECT id, device_id, room_name, status, started_by, started_by_name, viewer_count,
		       publisher_identity, livekit_url, COALESCE(ingress_id, ''), COALESCE(rtmp_url, ''),
		       started_at, ended_at, COALESCE(end_reason, ''), created_at, updated_at
		FROM remote_view_sessions
		WHERE device_id = $1 AND status IN ('starting', 'active')
		ORDER BY created_at DESC
		LIMIT 1
	`, deviceID)

	return scanRemoteViewSession(row)
}

func (r *RemoteViewRepository) GetByID(ctx context.Context, sessionID uuid.UUID) (*models.RemoteViewSession, error) {
	row := r.db.QueryRowContext(ctx, `
		SELECT id, device_id, room_name, status, started_by, started_by_name, viewer_count,
		       publisher_identity, livekit_url, COALESCE(ingress_id, ''), COALESCE(rtmp_url, ''),
		       started_at, ended_at, COALESCE(end_reason, ''), created_at, updated_at
		FROM remote_view_sessions
		WHERE id = $1
	`, sessionID)
	return scanRemoteViewSession(row)
}

func (r *RemoteViewRepository) Create(ctx context.Context, session *models.RemoteViewSession) error {
	_, err := r.db.ExecContext(ctx, `
		INSERT INTO remote_view_sessions (
			id, device_id, room_name, status, started_by, started_by_name, viewer_count,
			publisher_identity, livekit_url, ingress_id, rtmp_url, started_at, created_at, updated_at
		) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
	`, session.ID, session.DeviceID, session.RoomName, session.Status, session.StartedBy,
		session.StartedByName, session.ViewerCount, session.PublisherIdentity, session.LiveKitURL,
		session.IngressID, session.RTMPURL, session.StartedAt, session.CreatedAt, session.UpdatedAt)
	return err
}

func (r *RemoteViewRepository) IncrementViewerCount(ctx context.Context, sessionID uuid.UUID) (int, error) {
	var count int
	err := r.db.QueryRowContext(ctx, `
		UPDATE remote_view_sessions
		SET viewer_count = viewer_count + 1, updated_at = NOW()
		WHERE id = $1
		RETURNING viewer_count
	`, sessionID).Scan(&count)
	return count, err
}

func (r *RemoteViewRepository) DecrementViewerCount(ctx context.Context, sessionID uuid.UUID) (int, error) {
	var count int
	err := r.db.QueryRowContext(ctx, `
		UPDATE remote_view_sessions
		SET viewer_count = GREATEST(viewer_count - 1, 0), updated_at = NOW()
		WHERE id = $1
		RETURNING viewer_count
	`, sessionID).Scan(&count)
	return count, err
}

func (r *RemoteViewRepository) UpdateStatus(ctx context.Context, sessionID uuid.UUID, status string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions SET status = $2, updated_at = NOW() WHERE id = $1
	`, sessionID, status)
	return err
}

func (r *RemoteViewRepository) MarkStopped(ctx context.Context, sessionID uuid.UUID, reason string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET status = 'stopped', end_reason = $2, ended_at = NOW(), updated_at = NOW()
		WHERE id = $1
	`, sessionID, reason)
	return err
}

func (r *RemoteViewRepository) MarkFailed(ctx context.Context, sessionID uuid.UUID, reason string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET status = 'failed', end_reason = $2, ended_at = NOW(), updated_at = NOW()
		WHERE id = $1 AND status IN ('starting', 'active', 'stopping')
	`, sessionID, reason)
	return err
}

func (r *RemoteViewRepository) UpdateIngress(ctx context.Context, sessionID uuid.UUID, ingressID, rtmpURL string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET ingress_id = $2, rtmp_url = $3, updated_at = NOW()
		WHERE id = $1
	`, sessionID, ingressID, rtmpURL)
	return err
}

func (r *RemoteViewRepository) InsertAudit(ctx context.Context, entry *models.RemoteViewAuditLog) error {
	var detail interface{}
	if entry.Detail != "" {
		detail = entry.Detail
	}
	_, err := r.db.ExecContext(ctx, `
		INSERT INTO remote_view_audit_logs (
			id, session_id, device_id, operator_id, operator_name, action, detail, client_ip, created_at
		) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8,$9)
	`, entry.ID, entry.SessionID, entry.DeviceID, entry.OperatorID, entry.OperatorName,
		entry.Action, detail, entry.ClientIP, entry.CreatedAt)
	return err
}

func (r *RemoteViewRepository) ListAuditLogs(ctx context.Context, deviceID *uuid.UUID, page, pageSize int) ([]models.RemoteViewAuditLog, int, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 100 {
		pageSize = 20
	}
	offset := (page - 1) * pageSize

	countQuery := `SELECT COUNT(*) FROM remote_view_audit_logs a`
	listQuery := `
		SELECT a.id, a.session_id, a.device_id, a.operator_id, a.operator_name, a.action,
		       COALESCE(a.detail::text, ''), COALESCE(a.client_ip, ''), a.created_at,
		       COALESCE(d.employee_name, ''), COALESCE(d.employee_number, ''), COALESCE(d.hostname, '')
		FROM remote_view_audit_logs a
		LEFT JOIN devices d ON d.id = a.device_id
	`
	args := []interface{}{}
	argIdx := 1
	where := ""
	if deviceID != nil {
		where = fmt.Sprintf(" WHERE a.device_id = $%d", argIdx)
		args = append(args, *deviceID)
		argIdx++
	}

	var total int
	if err := r.db.QueryRowContext(ctx, countQuery+where, args...).Scan(&total); err != nil {
		return nil, 0, err
	}

	listQuery += where + fmt.Sprintf(" ORDER BY a.created_at DESC LIMIT $%d OFFSET $%d", argIdx, argIdx+1)
	args = append(args, pageSize, offset)

	rows, err := r.db.QueryContext(ctx, listQuery, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	var logs []models.RemoteViewAuditLog
	for rows.Next() {
		var item models.RemoteViewAuditLog
		var sessionID sql.NullString
		if err := rows.Scan(&item.ID, &sessionID, &item.DeviceID, &item.OperatorID, &item.OperatorName,
			&item.Action, &item.Detail, &item.ClientIP, &item.CreatedAt,
			&item.EmployeeName, &item.EmployeeNumber, &item.Hostname); err != nil {
			return nil, 0, err
		}
		if sessionID.Valid {
			if sid, err := uuid.Parse(sessionID.String); err == nil {
				item.SessionID = &sid
			}
		}
		logs = append(logs, item)
	}
	return logs, total, rows.Err()
}

func scanRemoteViewSession(row *sql.Row) (*models.RemoteViewSession, error) {
	var session models.RemoteViewSession
	var endedAt sql.NullTime
	err := row.Scan(
		&session.ID, &session.DeviceID, &session.RoomName, &session.Status,
		&session.StartedBy, &session.StartedByName, &session.ViewerCount,
		&session.PublisherIdentity, &session.LiveKitURL, &session.IngressID, &session.RTMPURL,
		&session.StartedAt, &endedAt, &session.EndReason, &session.CreatedAt, &session.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}
	if endedAt.Valid {
		session.EndedAt = &endedAt.Time
	}
	return &session, nil
}

func auditDetail(v interface{}) string {
	if v == nil {
		return ""
	}
	b, err := json.Marshal(v)
	if err != nil {
		log.Printf("[RemoteView] audit detail marshal failed: %v", err)
		return ""
	}
	return string(b)
}

package services

import (
	"context"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
)

func telegramShiftStateMaxHours() int {
	if v := strings.TrimSpace(os.Getenv("TELEGRAM_SHIFT_STATE_MAX_HOURS")); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			return n
		}
	}
	return 24
}

func tgExportChatFilter(chatID string) (string, string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return "", ""
	}
	return ` AND EXISTS (
			SELECT 1 FROM employee_telegram_bindings b
			WHERE b.employee_id = ws.employee_id AND b.status = 1 AND b.chat_id = $3
		)`, chatID
}

func tgExportActivityChatFilter(chatID string) (string, string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return "", ""
	}
	return ` AND COALESCE(s.source_chat_id,'') = $3`, chatID
}

func tgExportHandoverChatFilter(chatID string) (string, string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return "", ""
	}
	return ` AND COALESCE(chat_id,'') = $3`, chatID
}

func exportFilenameSuffix(chatID, dateFrom, dateTo string) string {
	if strings.TrimSpace(chatID) == "" {
		return fmt.Sprintf("telegram_attendance_%s_%s", dateFrom, dateTo)
	}
	return fmt.Sprintf("telegram_attendance_%s_%s_%s", chatID, dateFrom, dateTo)
}

func (s *WorkforceTelegramService) resetAutoCheckoutTime(ctx context.Context, settings *TelegramSettings, chatID, exportDate, shift string) time.Time {
	loc := tgLoadLocation(settings.Timezone)
	parsed, err := time.ParseInLocation("2006-01-02", exportDate, loc)
	if err != nil {
		return time.Now().In(loc)
	}
	if shift == "night" {
		startH, startM, ok := parseClock(settings.DayStart)
		if !ok {
			startH, startM = 9, 0
		}
		return time.Date(parsed.Year(), parsed.Month(), parsed.Day()+1, startH, startM, 0, 0, loc)
	}
	resetTime := settings.DailyResetTime
	if t := s.GetGroupDailyResetTime(ctx, chatID); strings.TrimSpace(t) != "" {
		resetTime = t
	}
	resetH, resetM, ok := parseClock(resetTime)
	if !ok {
		resetH, resetM = 0, 0
	}
	return time.Date(parsed.Year(), parsed.Month(), parsed.Day(), resetH, resetM, 0, 0, loc).Add(telegramResetExecutionDelay)
}

func (s *WorkforceTelegramService) completeMissingWorkEndsForGroup(ctx context.Context, chatID, exportDate string) (int, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return 0, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return 0, err
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT ws.id, ws.employee_id, COALESCE(ws.shift_type,'day'), ws.attendance_date::text
		FROM work_sessions ws
		JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source = 'telegram' AND ws.status = 'open' AND b.chat_id = $1
		  AND ws.attendance_date <= $2::date`, chatID, exportDate)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	closed := 0
	for rows.Next() {
		var sid, empID uuid.UUID
		var shift, recordDate string
		if rows.Scan(&sid, &empID, &shift, &recordDate) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		checkoutAt := s.resetAutoCheckoutTime(ctx, settings, chatID, exportDate, shift)
		if recordDate != exportDate {
			checkoutAt = s.resetAutoCheckoutTime(ctx, settings, chatID, recordDate, shift)
		}
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, checkoutAt, "日重置补全下班"); err != nil {
			log.Printf("[Telegram] complete work end session=%s: %v", sid, err)
			continue
		}
		closed++
	}
	return closed, nil
}

func (s *WorkforceTelegramService) forceCloseOpenActivitiesForGroup(ctx context.Context, chatID string) (int, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return 0, nil
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT s.employee_id FROM wf_tg_activity_sessions s
		WHERE s.status = 'open' AND COALESCE(s.source_chat_id,'') = $1`, chatID)
	if err != nil {
		return 0, err
	}
	defer rows.Close()
	closed := 0
	for rows.Next() {
		var empID uuid.UUID
		if rows.Scan(&empID) != nil {
			continue
		}
		if err := s.forceCloseOpenActivityByEmployee(ctx, empID); err == nil {
			closed++
		}
	}
	return closed, nil
}

func (s *WorkforceTelegramService) purgeDailyDetailForGroup(ctx context.Context, chatID, exportDate string) error {
	chatID = strings.TrimSpace(chatID)
	exportDate = strings.TrimSpace(exportDate)
	if chatID == "" || exportDate == "" {
		return nil
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	_, err = tx.ExecContext(ctx, `
		DELETE FROM wf_tg_activity_sessions
		WHERE status = 'closed' AND attendance_date = $2::date
		  AND COALESCE(source_chat_id,'') = $1`, chatID, exportDate)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		DELETE FROM work_sessions ws
		USING employee_telegram_bindings b
		WHERE ws.employee_id = b.employee_id AND b.status = 1 AND b.chat_id = $1
		  AND ws.source = 'telegram' AND ws.status = 'closed'
		  AND ws.attendance_date = $2::date`, chatID, exportDate)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		DELETE FROM wf_tg_group_shift_state
		WHERE chat_id = $1 AND record_date <= $2::date`, chatID, exportDate)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		DELETE FROM wf_tg_handover_cycles
		WHERE chat_id = $1 AND handover_date <= $2::date`, chatID, exportDate)
	if err != nil {
		return err
	}
	return tx.Commit()
}

func (s *WorkforceTelegramService) closeExpiredWorkSessionsForEmployee(ctx context.Context, empID uuid.UUID, chatID string) (int, error) {
	maxHours := telegramShiftStateMaxHours()
	cutoff := time.Now().Add(-time.Duration(maxHours) * time.Hour)
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, COALESCE(shift_type,'day'), attendance_date::text
		FROM work_sessions
		WHERE employee_id = $1 AND source = 'telegram' AND status = 'open'
		  AND checkin_time < $2`, empID, cutoff)
	if err != nil {
		return 0, err
	}
	defer rows.Close()
	closed := 0
	for rows.Next() {
		var sid uuid.UUID
		var shift, recordDate string
		if rows.Scan(&sid, &shift, &recordDate) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		checkoutAt := time.Now()
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, checkoutAt, fmt.Sprintf("班次超时自动下班（>%dh）", maxHours)); err != nil {
			log.Printf("[Telegram] expired shift close session=%s: %v", sid, err)
			continue
		}
		closed++
	}
	return closed, nil
}

func (s *WorkforceTelegramService) CloseExpiredWorkSessionsGlobal(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	maxHours := telegramShiftStateMaxHours()
	cutoff := time.Now().Add(-time.Duration(maxHours) * time.Hour)
	rows, err := s.db.QueryContext(ctx, `
		SELECT ws.id, ws.employee_id, COALESCE(b.chat_id,''), COALESCE(ws.shift_type,'day'), ws.attendance_date::text
		FROM work_sessions ws
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source = 'telegram' AND ws.status = 'open' AND ws.checkin_time < $1`, cutoff)
	if err != nil {
		return
	}
	defer rows.Close()
	for rows.Next() {
		var sid, empID uuid.UUID
		var chatID, shift, recordDate string
		if rows.Scan(&sid, &empID, &chatID, &shift, &recordDate) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, time.Now(), fmt.Sprintf("班次超时自动下班（>%dh）", maxHours)); err != nil {
			log.Printf("[Telegram] global expired shift close session=%s: %v", sid, err)
		}
	}
}

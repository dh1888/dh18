package services

import (
	"fmt"
	"strings"
)

// normalizeRTMPIngressURL builds a publish URL from LiveKit CreateIngress fields.
// Falls back to baseURL (LIVEKIT_RTMP_BASE_URL / livekit.yaml ingress.rtmp_base_url) when url is empty.
func normalizeRTMPIngressURL(baseURL, ingressURL, streamKey string) (string, error) {
	streamKey = strings.TrimSpace(streamKey)
	if streamKey == "" {
		return "", fmt.Errorf("ingress response missing stream_key")
	}

	ingressURL = strings.TrimSpace(ingressURL)
	baseURL = strings.TrimSuffix(strings.TrimSpace(baseURL), "/")

	combined := strings.TrimSuffix(ingressURL, "/")
	if combined != "" {
		combined += "/" + strings.TrimPrefix(streamKey, "/")
	} else if baseURL != "" {
		combined = baseURL + "/" + strings.TrimPrefix(streamKey, "/")
	} else {
		combined = "/" + strings.TrimPrefix(streamKey, "/")
	}

	if !isValidRTMPURL(combined) {
		if baseURL == "" {
			return "", fmt.Errorf(
				"invalid rtmp url %q: set livekit ingress.rtmp_base_url or LIVEKIT_RTMP_BASE_URL",
				combined,
			)
		}
		combined = baseURL + "/" + strings.TrimPrefix(streamKey, "/")
	}

	if baseURL != "" && isLoopbackRTMP(combined) && !isLoopbackRTMP(baseURL) {
		combined = baseURL + "/" + strings.TrimPrefix(streamKey, "/")
	}

	if !isValidRTMPURL(combined) {
		return "", fmt.Errorf("invalid rtmp url: %q", combined)
	}

	return combined, nil
}

func isLoopbackRTMP(u string) bool {
	lower := strings.ToLower(u)
	return strings.Contains(lower, "127.0.0.1") || strings.Contains(lower, "localhost")
}

func isValidRTMPURL(u string) bool {
	lower := strings.ToLower(strings.TrimSpace(u))
	return strings.HasPrefix(lower, "rtmp://") && len(lower) > len("rtmp://")
}

func maskRTMPURL(u string) string {
	u = strings.TrimSpace(u)
	idx := strings.LastIndex(u, "/")
	if idx < 0 || idx >= len(u)-1 {
		return u
	}
	key := u[idx+1:]
	if len(key) <= 4 {
		return u[:idx+1] + "***"
	}
	return u[:idx+1] + "***" + key[len(key)-4:]
}

func isIngressNotFound(statusCode int, body string) bool {
	if statusCode == httpStatusNotFound {
		return true
	}
	lower := strings.ToLower(body)
	return strings.Contains(lower, "not_found") ||
		strings.Contains(lower, "does not exist") ||
		strings.Contains(lower, "ingress not found")
}

const httpStatusNotFound = 404

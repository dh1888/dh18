package services

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
)

type WorkforceTelegramService struct {
	db        *sql.DB
	workforce *WorkforceService
	wsHub     *WebSocketHub
}

func NewWorkforceTelegramService(db *sql.DB, workforce *WorkforceService) *WorkforceTelegramService {
	return &WorkforceTelegramService{db: db, workforce: workforce}
}

func (s *WorkforceTelegramService) SetWebSocketHub(hub *WebSocketHub) {
	s.wsHub = hub
}

type TelegramSettings struct {
	ID                    uuid.UUID
	Enabled               bool
	BotUsername           string
	BotID                 int64
	HasBotToken           bool
	Timezone              string
	DayStart              string
	DayEnd                string
	NightStart            string
	NightEnd              string
	GraceMinutes          int
	GraceMinutesAfter     int
	DualShiftEnabled      bool
	DailyResetTime        string
	DailyResetEnabled     bool
	ShiftWindowDisabled   bool
	WorkEndGraceMinutes   int
	WorkEndGraceAfter     int
	RequirePCLogin          bool
	CaptureLinkedToCheckin  bool
	AdminTelegramUserIDs    string
	BotMode               string
	WebhookURL            string
	HasWebhookSecret      bool
	BotUILang             string
	UpdatedAt             time.Time
}

type TelegramGroupRow struct {
	ID                 uuid.UUID
	ChatID             string
	ChatTitle          string
	Enabled            bool
	ShiftGraceBefore   *int
	ShiftGraceAfter    *int
	WorkEndGraceBefore *int
	WorkEndGraceAfter  *int
	DailyResetTime     string
	BotUILang          string
	CreatedAt          time.Time
}

type TelegramBindingRow struct {
	ID               uuid.UUID
	EmployeeID       uuid.UUID
	EmployeeName     string
	EmployeeCode     string
	TelegramUserID   int64
	TelegramUsername string
	ChatID           string
	BoundAt          time.Time
	Status           int
}

func (s *WorkforceTelegramService) IsActive(ctx context.Context) (bool, error) {
	if !TelegramAttendanceEnabled() {
		return false, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return false, err
	}
	return settings.Enabled && settings.HasBotToken, nil
}

func (s *WorkforceTelegramService) GetSettings(ctx context.Context) (*TelegramSettings, error) {
	row := s.db.QueryRowContext(ctx, `
		SELECT id, enabled, COALESCE(bot_username,''), COALESCE(bot_id,0),
			CASE WHEN bot_token_enc IS NOT NULL AND bot_token_enc != '' THEN TRUE ELSE FALSE END,
			timezone, day_start, day_end, COALESCE(night_start,'21:00'), COALESCE(night_end,'09:00'),
			grace_minutes, COALESCE(grace_minutes_after, 360), dual_shift_enabled, COALESCE(daily_reset_time,'09:00'), COALESCE(daily_reset_enabled, TRUE),
			COALESCE(shift_window_disabled, FALSE), COALESCE(work_end_grace_minutes, 5), COALESCE(work_end_grace_after, 360), COALESCE(require_pc_login, TRUE),
			COALESCE(capture_linked_to_checkin, FALSE),
			COALESCE(admin_telegram_user_ids,''),
			COALESCE(bot_mode,'polling'), COALESCE(webhook_url,''),
			CASE WHEN webhook_secret IS NOT NULL AND webhook_secret != '' THEN TRUE ELSE FALSE END,
			COALESCE(bot_ui_lang,'both'), updated_at
		FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`)
	var out TelegramSettings
	if err := row.Scan(&out.ID, &out.Enabled, &out.BotUsername, &out.BotID, &out.HasBotToken,
		&out.Timezone, &out.DayStart, &out.DayEnd, &out.NightStart, &out.NightEnd,
		&out.GraceMinutes, &out.GraceMinutesAfter, &out.DualShiftEnabled, &out.DailyResetTime, &out.DailyResetEnabled,
		&out.ShiftWindowDisabled, &out.WorkEndGraceMinutes, &out.WorkEndGraceAfter, &out.RequirePCLogin, &out.CaptureLinkedToCheckin, &out.AdminTelegramUserIDs,
		&out.BotMode, &out.WebhookURL, &out.HasWebhookSecret, &out.BotUILang, &out.UpdatedAt); err != nil {
		return nil, err
	}
	return &out, nil
}

func (s *WorkforceTelegramService) UpdateSettings(ctx context.Context, in map[string]interface{}) (*TelegramSettings, error) {
	current, err := s.GetSettings(ctx)
	if err != nil {
		return nil, err
	}

	enabled := current.Enabled
	if v, ok := in["enabled"].(bool); ok {
		enabled = v
	}
	timezone := current.Timezone
	if v, ok := in["timezone"].(string); ok && strings.TrimSpace(v) != "" {
		timezone = strings.TrimSpace(v)
	}
	dayStart := current.DayStart
	if v, ok := in["dayStart"].(string); ok && strings.TrimSpace(v) != "" {
		dayStart = strings.TrimSpace(v)
	}
	dayEnd := current.DayEnd
	if v, ok := in["dayEnd"].(string); ok && strings.TrimSpace(v) != "" {
		dayEnd = strings.TrimSpace(v)
	}
	grace := current.GraceMinutes
	if v, ok := in["graceMinutes"].(float64); ok {
		grace = int(v)
	}
	graceAfter := current.GraceMinutesAfter
	if v, ok := in["graceMinutesAfter"].(float64); ok {
		graceAfter = int(v)
	}
	dual := current.DualShiftEnabled
	if v, ok := in["dualShiftEnabled"].(bool); ok {
		dual = v
	}
	nightStart := current.NightStart
	if v, ok := in["nightStart"].(string); ok && strings.TrimSpace(v) != "" {
		nightStart = strings.TrimSpace(v)
	}
	nightEnd := current.NightEnd
	if v, ok := in["nightEnd"].(string); ok && strings.TrimSpace(v) != "" {
		nightEnd = strings.TrimSpace(v)
	}
	dailyResetTime := current.DailyResetTime
	if v, ok := in["dailyResetTime"].(string); ok && strings.TrimSpace(v) != "" {
		dailyResetTime = strings.TrimSpace(v)
	}
	dailyResetEnabled := current.DailyResetEnabled
	if v, ok := in["dailyResetEnabled"].(bool); ok {
		dailyResetEnabled = v
	}
	shiftWindowDisabled := current.ShiftWindowDisabled
	if v, ok := in["shiftWindowDisabled"].(bool); ok {
		shiftWindowDisabled = v
	}
	workEndGrace := current.WorkEndGraceMinutes
	if v, ok := in["workEndGraceMinutes"].(float64); ok {
		workEndGrace = int(v)
	}
	workEndGraceAfter := current.WorkEndGraceAfter
	if v, ok := in["workEndGraceAfter"].(float64); ok {
		workEndGraceAfter = int(v)
	}
	requirePCLogin := current.RequirePCLogin
	if v, ok := in["requirePCLogin"].(bool); ok {
		requirePCLogin = v
	}
	captureLinkedToCheckin := current.CaptureLinkedToCheckin
	if v, ok := in["captureLinkedToCheckin"].(bool); ok {
		captureLinkedToCheckin = v
	}
	adminTelegramUserIDs := current.AdminTelegramUserIDs
	if v, ok := in["adminTelegramUserIds"].(string); ok {
		adminTelegramUserIDs = strings.TrimSpace(v)
	}
	botMode := current.BotMode
	if v, ok := in["botMode"].(string); ok && strings.TrimSpace(v) != "" {
		botMode = strings.ToLower(strings.TrimSpace(v))
	}
	webhookURL := current.WebhookURL
	if v, ok := in["webhookUrl"].(string); ok {
		webhookURL = strings.TrimSpace(v)
	}
	botUILang := current.BotUILang
	if v, ok := in["botUiLang"].(string); ok && strings.TrimSpace(v) != "" {
		botUILang = strings.ToLower(strings.TrimSpace(v))
	}

	botTokenEnc := sql.NullString{}
	botUsername := current.BotUsername
	botID := current.BotID
	if token, ok := in["botToken"].(string); ok && strings.TrimSpace(token) != "" {
		enc, err := EncryptSecret(strings.TrimSpace(token))
		if err != nil {
			return nil, err
		}
		botTokenEnc = sql.NullString{String: enc, Valid: true}
		me, err := telegramGetMe(strings.TrimSpace(token))
		if err != nil {
			return nil, fmt.Errorf("verify bot token: %w", err)
		}
		botUsername = me.Username
		botID = me.ID
	}

	workerSecret := sql.NullString{}
	if v, ok := in["regenerateWorkerSecret"].(bool); ok && v {
		secret, err := generateWorkerSecret()
		if err != nil {
			return nil, err
		}
		workerSecret = sql.NullString{String: secret, Valid: true}
	}
	webhookSecret := sql.NullString{}
	if v, ok := in["regenerateWebhookSecret"].(bool); ok && v {
		secret, err := generateWorkerSecret()
		if err != nil {
			return nil, err
		}
		webhookSecret = sql.NullString{String: secret, Valid: true}
	}

	query := `
		UPDATE wf_telegram_settings SET
			enabled = $1, timezone = $2, day_start = $3, day_end = $4,
			night_start = $5, night_end = $6, grace_minutes = $7, dual_shift_enabled = $8,
			daily_reset_time = $9, daily_reset_enabled = $10,
			shift_window_disabled = $11, work_end_grace_minutes = $12, work_end_grace_after = $13, require_pc_login = $14,
			capture_linked_to_checkin = $15,
			admin_telegram_user_ids = $16, grace_minutes_after = $17,
			bot_mode = $18, webhook_url = $19, bot_ui_lang = $20, updated_at = NOW()`
	args := []interface{}{enabled, timezone, dayStart, dayEnd, nightStart, nightEnd, grace, dual, dailyResetTime, dailyResetEnabled, shiftWindowDisabled, workEndGrace, workEndGraceAfter, requirePCLogin, captureLinkedToCheckin, adminTelegramUserIDs, graceAfter, botMode, webhookURL, botUILang}
	argN := 21
	if botTokenEnc.Valid {
		query += fmt.Sprintf(", bot_token_enc = $%d, bot_username = $%d, bot_id = $%d", argN, argN+1, argN+2)
		args = append(args, botTokenEnc.String, botUsername, botID)
		argN += 3
	}
	if workerSecret.Valid {
		query += fmt.Sprintf(", worker_secret = $%d", argN)
		args = append(args, workerSecret.String)
		argN++
	}
	if webhookSecret.Valid {
		query += fmt.Sprintf(", webhook_secret = $%d", argN)
		args = append(args, webhookSecret.String)
		argN++
	}
	query += fmt.Sprintf(" WHERE id = $%d", argN)
	args = append(args, current.ID)

	if _, err := s.db.ExecContext(ctx, query, args...); err != nil {
		return nil, err
	}
	if botTokenEnc.Valid {
		if _, err := s.EnsureWorkerSecret(ctx); err != nil {
			return nil, err
		}
	}
	return s.GetSettings(ctx)
}

func (s *WorkforceTelegramService) GetWebhookSecret(ctx context.Context) (string, error) {
	var secret sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT webhook_secret FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).Scan(&secret)
	if err != nil {
		return "", err
	}
	if !secret.Valid {
		return "", nil
	}
	return strings.TrimSpace(secret.String), nil
}

func generateWorkerSecret() (string, error) {
	b := make([]byte, 24)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func (s *WorkforceTelegramService) ValidateWorkerSecret(ctx context.Context, secret string) error {
	secret = strings.TrimSpace(secret)
	if secret == "" {
		return errors.New("missing worker secret")
	}
	envSecret := strings.TrimSpace(os.Getenv("TELEGRAM_WORKER_SECRET"))
	if envSecret != "" && secret == envSecret {
		return nil
	}
	var dbSecret sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT worker_secret FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).Scan(&dbSecret)
	if err != nil {
		return err
	}
	if dbSecret.Valid && dbSecret.String == secret {
		return nil
	}
	return errors.New("invalid worker secret")
}

func (s *WorkforceTelegramService) GetBotToken(ctx context.Context) (string, error) {
	var enc sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT bot_token_enc FROM wf_telegram_settings WHERE enabled = TRUE ORDER BY updated_at DESC LIMIT 1`).Scan(&enc)
	if err != nil || !enc.Valid {
		return "", errors.New("bot token not configured")
	}
	return DecryptSecret(enc.String)
}

type telegramMeResult struct {
	ID        int64
	Username  string
	FirstName string
}

func telegramGetMe(token string) (*telegramMeResult, error) {
	req, err := http.NewRequest(http.MethodGet, "https://api.telegram.org/bot"+token+"/getMe", nil)
	if err != nil {
		return nil, err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK     bool `json:"ok"`
		Result struct {
			ID        int64  `json:"id"`
			Username  string `json:"username"`
			FirstName string `json:"first_name"`
		} `json:"result"`
		Description string `json:"description"`
	}
	if err := json.Unmarshal(body, &parsed); err != nil {
		return nil, err
	}
	if !parsed.OK {
		if parsed.Description != "" {
			return nil, errors.New(parsed.Description)
		}
		return nil, errors.New("telegram getMe failed")
	}
	return &telegramMeResult{
		ID: parsed.Result.ID, Username: parsed.Result.Username, FirstName: parsed.Result.FirstName,
	}, nil
}

func scanTelegramGroupRow(row *TelegramGroupRow, sb, sa, wb, wa sql.NullInt32, reset, lang sql.NullString) {
	if sb.Valid && int(sb.Int32) > 0 {
		v := int(sb.Int32)
		row.ShiftGraceBefore = &v
	}
	if sa.Valid && int(sa.Int32) > 0 {
		v := int(sa.Int32)
		row.ShiftGraceAfter = &v
	}
	if wb.Valid && int(wb.Int32) > 0 {
		v := int(wb.Int32)
		row.WorkEndGraceBefore = &v
	}
	if wa.Valid && int(wa.Int32) > 0 {
		v := int(wa.Int32)
		row.WorkEndGraceAfter = &v
	}
	if reset.Valid {
		row.DailyResetTime = strings.TrimSpace(reset.String)
	}
	if lang.Valid {
		row.BotUILang = strings.TrimSpace(lang.String)
	}
}

func (s *WorkforceTelegramService) ListGroups(ctx context.Context) ([]TelegramGroupRow, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, chat_id, COALESCE(chat_title,''), enabled,
			shift_grace_before, shift_grace_after, work_end_grace_before, work_end_grace_after,
			daily_reset_time, bot_ui_lang, created_at
		FROM wf_telegram_groups ORDER BY created_at DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TelegramGroupRow, 0)
	for rows.Next() {
		var row TelegramGroupRow
		var sb, sa, wb, wa sql.NullInt32
		var reset, lang sql.NullString
		if err := rows.Scan(&row.ID, &row.ChatID, &row.ChatTitle, &row.Enabled,
			&sb, &sa, &wb, &wa, &reset, &lang, &row.CreatedAt); err != nil {
			continue
		}
		scanTelegramGroupRow(&row, sb, sa, wb, wa, reset, lang)
		items = append(items, row)
	}
	return items, nil
}

func (s *WorkforceTelegramService) UpsertGroup(ctx context.Context, chatID, chatTitle string, enabled bool, overrides map[string]interface{}) (*TelegramGroupRow, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return nil, fmt.Errorf("chat_id required")
	}
	shiftBefore := nullableIntFromAny(overrides["shiftGraceBefore"])
	shiftAfter := nullableIntFromAny(overrides["shiftGraceAfter"])
	workBefore := nullableIntFromAny(overrides["workEndGraceBefore"])
	workAfter := nullableIntFromAny(overrides["workEndGraceAfter"])
	dailyReset := nullableStringFromAny(overrides["dailyResetTime"])
	groupLang := nullableStringFromAny(overrides["botUiLang"])

	var row TelegramGroupRow
	var sb, sa, wb, wa sql.NullInt32
	var reset, lang sql.NullString
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO wf_telegram_groups (
			chat_id, chat_title, enabled,
			shift_grace_before, shift_grace_after, work_end_grace_before, work_end_grace_after, daily_reset_time, bot_ui_lang
		)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
		ON CONFLICT (chat_id) DO UPDATE SET
			chat_title = CASE WHEN EXCLUDED.chat_title <> '' THEN EXCLUDED.chat_title ELSE wf_telegram_groups.chat_title END,
			enabled = EXCLUDED.enabled,
			shift_grace_before = COALESCE(EXCLUDED.shift_grace_before, wf_telegram_groups.shift_grace_before),
			shift_grace_after = COALESCE(EXCLUDED.shift_grace_after, wf_telegram_groups.shift_grace_after),
			work_end_grace_before = COALESCE(EXCLUDED.work_end_grace_before, wf_telegram_groups.work_end_grace_before),
			work_end_grace_after = COALESCE(EXCLUDED.work_end_grace_after, wf_telegram_groups.work_end_grace_after),
			daily_reset_time = COALESCE(EXCLUDED.daily_reset_time, wf_telegram_groups.daily_reset_time),
			bot_ui_lang = COALESCE(EXCLUDED.bot_ui_lang, wf_telegram_groups.bot_ui_lang)
		RETURNING id, chat_id, COALESCE(chat_title,''), enabled,
			shift_grace_before, shift_grace_after, work_end_grace_before, work_end_grace_after,
			daily_reset_time, bot_ui_lang, created_at`,
		chatID, strings.TrimSpace(chatTitle), enabled,
		shiftBefore, shiftAfter, workBefore, workAfter, dailyReset, groupLang).Scan(
		&row.ID, &row.ChatID, &row.ChatTitle, &row.Enabled,
		&sb, &sa, &wb, &wa, &reset, &lang, &row.CreatedAt)
	if err != nil {
		return nil, err
	}
	scanTelegramGroupRow(&row, sb, sa, wb, wa, reset, lang)
	return &row, nil
}

func nullableIntFromAny(v interface{}) sql.NullInt32 {
	if v == nil {
		return sql.NullInt32{}
	}
	n := intFromAny(v, 0)
	if n <= 0 {
		return sql.NullInt32{}
	}
	return sql.NullInt32{Int32: int32(n), Valid: true}
}

func nullableStringFromAny(v interface{}) sql.NullString {
	if v == nil {
		return sql.NullString{}
	}
	s := strings.TrimSpace(fmt.Sprint(v))
	if s == "" {
		return sql.NullString{}
	}
	return sql.NullString{String: s, Valid: true}
}

func (s *WorkforceTelegramService) DeleteGroup(ctx context.Context, id uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM wf_telegram_groups WHERE id = $1`, id)
	return err
}

func (s *WorkforceTelegramService) ListBindings(ctx context.Context, search string) ([]TelegramBindingRow, error) {
	search = strings.TrimSpace(search)
	query := `
		SELECT b.id, b.employee_id, e.name, COALESCE(e.employee_id,''),
			b.telegram_user_id, COALESCE(b.telegram_username,''), COALESCE(b.chat_id,''),
			b.bound_at, b.status
		FROM employee_telegram_bindings b
		JOIN employees e ON e.id = b.employee_id
		WHERE b.status = 1`
	args := []interface{}{}
	if search != "" {
		query += ` AND (e.name ILIKE $1 OR e.employee_id ILIKE $1 OR b.telegram_username ILIKE $1 OR b.telegram_user_id::text ILIKE $1)`
		args = append(args, "%"+search+"%")
	}
	query += ` ORDER BY b.bound_at DESC`
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TelegramBindingRow, 0)
	for rows.Next() {
		var row TelegramBindingRow
		if err := rows.Scan(&row.ID, &row.EmployeeID, &row.EmployeeName, &row.EmployeeCode,
			&row.TelegramUserID, &row.TelegramUsername, &row.ChatID, &row.BoundAt, &row.Status); err != nil {
			continue
		}
		items = append(items, row)
	}
	return items, nil
}

func (s *WorkforceTelegramService) CreateBinding(ctx context.Context, employeeID uuid.UUID, telegramUserID int64, telegramUsername, chatID string) (*TelegramBindingRow, error) {
	if telegramUserID <= 0 {
		return nil, fmt.Errorf("invalid telegram user id")
	}
	var exists int
	if err := s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM employees WHERE id = $1 AND status = 1`, employeeID).Scan(&exists); err != nil || exists == 0 {
		return nil, ErrEmployeeNotFound
	}
	var id uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO employee_telegram_bindings (employee_id, telegram_user_id, telegram_username, chat_id, status)
		VALUES ($1, $2, $3, $4, 1)
		ON CONFLICT (employee_id) DO UPDATE SET
			telegram_user_id = EXCLUDED.telegram_user_id,
			telegram_username = EXCLUDED.telegram_username,
			chat_id = EXCLUDED.chat_id,
			status = 1,
			bound_at = NOW()
		RETURNING id`, employeeID, telegramUserID, nullString(strings.TrimSpace(telegramUsername)), nullString(strings.TrimSpace(chatID))).Scan(&id)
	if err != nil {
		return nil, err
	}
	items, err := s.ListBindings(ctx, "")
	if err != nil {
		return nil, err
	}
	for _, item := range items {
		if item.ID == id {
			return &item, nil
		}
	}
	return nil, fmt.Errorf("binding not found after create")
}

func (s *WorkforceTelegramService) DeleteBinding(ctx context.Context, id uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM employee_telegram_bindings WHERE id = $1`, id)
	return err
}

func (s *WorkforceTelegramService) GetBindingByID(ctx context.Context, id uuid.UUID) (*TelegramBindingRow, error) {
	var row TelegramBindingRow
	err := s.db.QueryRowContext(ctx, `
		SELECT b.id, b.employee_id, e.name, COALESCE(e.employee_id,''), b.telegram_user_id,
			COALESCE(b.telegram_username,''), COALESCE(b.chat_id,''), b.bound_at, b.status
		FROM employee_telegram_bindings b
		JOIN employees e ON e.id = b.employee_id
		WHERE b.id = $1 AND b.status = 1`, id).
		Scan(&row.ID, &row.EmployeeID, &row.EmployeeName, &row.EmployeeCode,
			&row.TelegramUserID, &row.TelegramUsername, &row.ChatID, &row.BoundAt, &row.Status)
	if err == sql.ErrNoRows {
		return nil, ErrTelegramNotBound
	}
	if err != nil {
		return nil, err
	}
	return &row, nil
}

func (s *WorkforceTelegramService) ResolveEmployeeByTelegramUserID(ctx context.Context, telegramUserID int64) (uuid.UUID, error) {
	var empID uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT employee_id FROM employee_telegram_bindings
		WHERE telegram_user_id = $1 AND status = 1`, telegramUserID).Scan(&empID)
	if err == sql.ErrNoRows {
		return uuid.Nil, ErrTelegramNotBound
	}
	return empID, err
}

func (s *WorkforceTelegramService) GetEmployeeSessionStatus(ctx context.Context, empID uuid.UUID) (bool, *uuid.UUID, error) {
	var sid uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM work_sessions WHERE employee_id = $1 AND status = 'open'
		ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&sid)
	if err == sql.ErrNoRows {
		return false, nil, nil
	}
	if err != nil {
		return false, nil, err
	}
	return true, &sid, nil
}

func (s *WorkforceTelegramService) TelegramCheckIn(ctx context.Context, telegramUserID int64, chatID, forcedShift string) (*CheckInResult, uuid.UUID, string, float64, string, string, error) {
	active, err := s.IsActive(ctx)
	if err != nil {
		return nil, uuid.Nil, "", 0, "", "", err
	}
	if !active {
		return nil, uuid.Nil, "", 0, "", "", ErrTelegramDisabled
	}
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil {
		return nil, uuid.Nil, "", 0, "", "", err
	}
	if chatID != "" {
		_, _ = s.UpsertGroup(ctx, chatID, "", true, nil)
		_, _ = s.db.ExecContext(ctx, `
			UPDATE employee_telegram_bindings SET chat_id = $1 WHERE employee_id = $2 AND status = 1`,
			chatID, empID)
		s.MaybeLazyResetForChat(ctx, chatID)
	}
	var name string
	_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, empID).Scan(&name)
	outcome, err := s.telegramCheckInWithShift(ctx, empID, telegramUserID, chatID, forcedShift)
	if err != nil {
		return nil, empID, name, 0, "", "", err
	}
	return outcome.Result, empID, name, outcome.WorkFine, outcome.HandoverHint, outcome.GroupReplyHTML, nil
}

func (s *WorkforceTelegramService) TelegramCheckOut(ctx context.Context, telegramUserID int64, chatID string) (*CheckOutResult, uuid.UUID, string, float64, string, string, string, error) {
	active, err := s.IsActive(ctx)
	if err != nil {
		return nil, uuid.Nil, "", 0, "", "", "", err
	}
	if !active {
		return nil, uuid.Nil, "", 0, "", "", "", ErrTelegramDisabled
	}
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil {
		return nil, uuid.Nil, "", 0, "", "", "", err
	}
	var name string
	_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, empID).Scan(&name)
	if chatID == "" {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(chat_id,'') FROM employee_telegram_bindings WHERE employee_id = $1 AND status = 1`, empID).Scan(&chatID)
	}
	outcome, err := s.telegramCheckOutFIFO(ctx, empID, telegramUserID, chatID)
	if err != nil {
		return nil, empID, name, 0, "", "", "", err
	}
	return outcome.Result, empID, name, outcome.WorkFine, outcome.HandoverHint, outcome.ActivityWarn, outcome.GroupReplyHTML, nil
}

func ParseTelegramUserID(raw string) (int64, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return 0, fmt.Errorf("empty telegram user id")
	}
	return strconv.ParseInt(raw, 10, 64)
}

package services

import "testing"

func TestNormalizeRTMPIngressURL_FullURLFromLiveKit(t *testing.T) {
	got, err := normalizeRTMPIngressURL(
		"",
		"rtmp://127.0.0.1:1935/x",
		"abc123",
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	want := "rtmp://127.0.0.1:1935/x/abc123"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestNormalizeRTMPIngressURL_FallbackBase(t *testing.T) {
	got, err := normalizeRTMPIngressURL(
		"rtmp://43.106.86.216:1935/x",
		"",
		"mh46benn3d5h",
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	want := "rtmp://43.106.86.216:1935/x/mh46benn3d5h"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestNormalizeRTMPIngressURL_ReplaceLoopbackWithPublicBase(t *testing.T) {
	got, err := normalizeRTMPIngressURL(
		"rtmp://43.106.86.216:1935/x",
		"rtmp://127.0.0.1:1935/x",
		"mh46benn3d5h",
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	want := "rtmp://43.106.86.216:1935/x/mh46benn3d5h"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestNormalizeRTMPIngressURL_InvalidWithoutBase(t *testing.T) {
	_, err := normalizeRTMPIngressURL("", "", "onlykey")
	if err == nil {
		t.Fatal("expected error for path-only url without base")
	}
}

func TestMaskRTMPURL(t *testing.T) {
	in := "rtmp://43.106.86.216:1935/x/mh46benn3d5h"
	got := maskRTMPURL(in)
	want := "rtmp://43.106.86.216:1935/x/***3d5h"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestIsIngressNotFound(t *testing.T) {
	if !isIngressNotFound(404, `{"code":"not_found"}`) {
		t.Fatal("expected 404 body to be not found")
	}
	if isIngressNotFound(500, "internal error") {
		t.Fatal("expected 500 to not be not found")
	}
}

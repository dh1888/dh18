package services

import (
	"context"
	"database/sql"
	"fmt"
	"html"
	"strings"
	"time"
)

type PenaltyPushService struct {
	db *sql.DB
}

func NewPenaltyPushService(db *sql.DB) *PenaltyPushService {
	return &PenaltyPushService{db: db}
}

type PenaltyPushSettings struct {
	HasBotToken bool   `json:"hasBotToken"`
	BotUsername string `json:"botUsername"`
	ChatID      string `json:"chatId"`
	ChatTitle   string `json:"chatTitle"`
	ChatType    string `json:"chatType"`
	Enabled     bool   `json:"enabled"`
	Ready       bool   `json:"ready"`
	UpdatedAt   string `json:"updatedAt,omitempty"`
}

func penaltyPushReady(hasBotToken bool, chatID string, enabled bool) bool {
	return enabled && hasBotToken && strings.TrimSpace(chatID) != ""
}

type PenaltyPushRecord struct {
	Date         string  `json:"date"`
	EmployeeName string  `json:"employeeName"`
	Position     string  `json:"position"`
	Amount       float64 `json:"amount"`
	Category     string  `json:"category"`
	Reason       string  `json:"reason"`
}

func (s *PenaltyPushService) GetSettings(ctx context.Context) (*PenaltyPushSettings, error) {
	out := &PenaltyPushSettings{}
	var tokenEnc, botUsername, chatID, chatTitle, chatType sql.NullString
	var botID sql.NullInt64
	var enabled bool
	var updatedAt time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT bot_token_enc, bot_username, bot_id, chat_id, chat_title, chat_type, enabled, updated_at
		FROM penalty_push_settings WHERE id = 1`).
		Scan(&tokenEnc, &botUsername, &botID, &chatID, &chatTitle, &chatType, &enabled, &updatedAt)
	if err == sql.ErrNoRows {
		return out, nil
	}
	if err != nil {
		return nil, err
	}
	out.HasBotToken = tokenEnc.Valid && strings.TrimSpace(tokenEnc.String) != ""
	if botUsername.Valid {
		out.BotUsername = botUsername.String
	}
	if chatID.Valid {
		out.ChatID = chatID.String
	}
	if chatTitle.Valid {
		out.ChatTitle = chatTitle.String
	}
	if chatType.Valid {
		out.ChatType = chatType.String
	}
	out.Enabled = enabled
	out.Ready = penaltyPushReady(out.HasBotToken, out.ChatID, enabled)
	out.UpdatedAt = updatedAt.UTC().Format(time.RFC3339)
	return out, nil
}

func (s *PenaltyPushService) SetPushEnabled(ctx context.Context, enabled bool) (*PenaltyPushSettings, error) {
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO penalty_push_settings (id, enabled, updated_at)
		VALUES (1, $1, NOW())
		ON CONFLICT (id) DO UPDATE SET
			enabled = EXCLUDED.enabled,
			updated_at = NOW()`, enabled)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PenaltyPushService) SaveBotToken(ctx context.Context, token string) (*PenaltyPushSettings, error) {
	token = strings.TrimSpace(token)
	if token == "" {
		return nil, fmt.Errorf("Bot Token 不能为空")
	}
	username, botID, err := performanceTelegramGetMe(token)
	if err != nil {
		return nil, err
	}
	enc, err := EncryptSecret(token)
	if err != nil {
		return nil, err
	}
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO penalty_push_settings (id, bot_token_enc, bot_username, bot_id, updated_at)
		VALUES (1, $1, $2, $3, NOW())
		ON CONFLICT (id) DO UPDATE SET
			bot_token_enc = EXCLUDED.bot_token_enc,
			bot_username = EXCLUDED.bot_username,
			bot_id = EXCLUDED.bot_id,
			updated_at = NOW()`, enc, username, botID)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PenaltyPushService) DiscoverChats(ctx context.Context) ([]map[string]string, error) {
	token, err := s.getBotToken(ctx)
	if err != nil {
		return nil, err
	}
	return telegramScanRecentChats(token)
}

func (s *PenaltyPushService) BindChat(ctx context.Context, chatID, chatTitle, chatType string) (*PenaltyPushSettings, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return nil, fmt.Errorf("chatId required")
	}
	if _, err := s.getBotToken(ctx); err != nil {
		return nil, err
	}
	title := strings.TrimSpace(chatTitle)
	if title == "" {
		title = chatID
	}
	chatType = strings.TrimSpace(chatType)
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO penalty_push_settings (id, chat_id, chat_title, chat_type, updated_at)
		VALUES (1, $1, $2, $3, NOW())
		ON CONFLICT (id) DO UPDATE SET
			chat_id = EXCLUDED.chat_id,
			chat_title = EXCLUDED.chat_title,
			chat_type = EXCLUDED.chat_type,
			updated_at = NOW()`, chatID, title, chatType)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PenaltyPushService) UnbindChat(ctx context.Context) (*PenaltyPushSettings, error) {
	_, err := s.db.ExecContext(ctx, `
		UPDATE penalty_push_settings
		SET chat_id = NULL, chat_title = NULL, chat_type = NULL, updated_at = NOW()
		WHERE id = 1`)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PenaltyPushService) PushPenaltyRecord(ctx context.Context, rec PenaltyPushRecord) (bool, error) {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return false, err
	}
	if !settings.Ready {
		return false, nil
	}
	token, err := s.getBotToken(ctx)
	if err != nil {
		return false, err
	}
	text := buildPenaltyPushHTML(rec)
	if err := performanceTelegramSendHTML(token, settings.ChatID, text); err != nil {
		return false, err
	}
	return true, nil
}

func (s *PenaltyPushService) TestPush(ctx context.Context) error {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return err
	}
	if settings.ChatID == "" {
		return fmt.Errorf("请先绑定频道或群组")
	}
	token, err := s.getBotToken(ctx)
	if err != nil {
		return err
	}
	text := "<b>⚠️ 罚款推送测试</b>\n\n配置成功，后续新增罚款记录将推送到此频道/群组。"
	return performanceTelegramSendHTML(token, settings.ChatID, text)
}

func (s *PenaltyPushService) getBotToken(ctx context.Context) (string, error) {
	var enc sql.NullString
	err := s.db.QueryRowContext(ctx, `SELECT bot_token_enc FROM penalty_push_settings WHERE id = 1`).Scan(&enc)
	if err == sql.ErrNoRows || !enc.Valid || strings.TrimSpace(enc.String) == "" {
		return "", fmt.Errorf("请先配置 Bot Token")
	}
	if err != nil {
		return "", err
	}
	return DecryptSecret(enc.String)
}

func buildPenaltyPushHTML(rec PenaltyPushRecord) string {
	date := html.EscapeString(strings.TrimSpace(rec.Date))
	name := html.EscapeString(strings.TrimSpace(rec.EmployeeName))
	position := html.EscapeString(strings.TrimSpace(rec.Position))
	if position == "" {
		position = "-"
	}
	category := html.EscapeString(strings.TrimSpace(rec.Category))
	if category == "" {
		category = "-"
	}
	reason := html.EscapeString(strings.TrimSpace(rec.Reason))
	if reason == "" {
		reason = "-"
	}
	amountText := fmt.Sprintf("¥%.2f", rec.Amount)
	return fmt.Sprintf(
		"<b>⚠️ 罚款通知</b>\n\n"+
			"<b>日期</b>：%s\n"+
			"<b>员工</b>：%s\n"+
			"<b>岗位</b>：%s\n"+
			"<b>金额</b>：%s\n"+
			"<b>类别</b>：%s\n"+
			"<b>原因</b>：%s",
		date, name, position, amountText, category, reason,
	)
}

package services

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log"
	"math"
	"sort"
	"strings"
	"time"

	"github.com/google/uuid"
)

var (
	ErrActivityNotInWork     = errors.New("must check in to work before activity")
	ErrActivityAlreadyActive = errors.New("activity already in progress")
	ErrActivityNotActive     = errors.New("no activity in progress")
	ErrActivityLimitReached  = errors.New("daily activity limit reached")
	ErrActivityTypeDisabled  = errors.New("activity type disabled")
	ErrActivityTypeNotFound  = errors.New("activity type not found")
	ErrBackProcessing        = errors.New("back request already processing")
)

type TgActivityType struct {
	ID               uuid.UUID
	Code             string
	Name             string
	MaxTimesPerDay   int
	MaxConcurrent    int
	TimeLimitSeconds int
	SortOrder        int
	Enabled          bool
}

type TgActivityFine struct {
	ID             uuid.UUID
	ActivityCode   string
	SegmentMinutes int
	FineAmount     float64
}

type TgActivitySession struct {
	ID              uuid.UUID
	EmployeeID      uuid.UUID
	EmployeeName    string
	ActivityCode    string
	ActivityName    string
	AttendanceDate  string
	StartedAt       time.Time
	EndedAt         *time.Time
	ElapsedSeconds  int
	LimitSeconds    int
	OvertimeSeconds int
	FineAmount      float64
	Status          string
	ShiftType       string
	GroupReplyHTML  string
}

type TgActivityStartResult struct {
	Session        *TgActivitySession
	MessageText    string
	GroupReplyHTML string
	InlineKeyboard map[string]interface{}
}

func computeActivityOvertimeFine(segments map[int]float64, overtimeMinutes float64) float64 {
	if len(segments) == 0 || overtimeMinutes <= 0 {
		return 0
	}
	keys := make([]int, 0, len(segments))
	for k := range segments {
		keys = append(keys, k)
	}
	sort.Ints(keys)
	for _, seg := range keys {
		if overtimeMinutes <= float64(seg) {
			return segments[seg]
		}
	}
	return segments[keys[len(keys)-1]]
}

func (s *WorkforceTelegramService) ListActivityTypes(ctx context.Context) ([]TgActivityType, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, code, name, max_times_per_day, COALESCE(max_concurrent,0), time_limit_seconds, sort_order, enabled
		FROM wf_tg_activity_types ORDER BY sort_order ASC, name ASC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TgActivityType, 0)
	for rows.Next() {
		var row TgActivityType
		if err := rows.Scan(&row.ID, &row.Code, &row.Name, &row.MaxTimesPerDay, &row.MaxConcurrent, &row.TimeLimitSeconds, &row.SortOrder, &row.Enabled); err != nil {
			continue
		}
		items = append(items, row)
	}
	return items, nil
}

func (s *WorkforceTelegramService) UpsertActivityType(ctx context.Context, in map[string]interface{}) (*TgActivityType, error) {
	code := strings.TrimSpace(fmt.Sprint(in["code"]))
	name := strings.TrimSpace(fmt.Sprint(in["name"]))
	if code == "" || name == "" {
		return nil, fmt.Errorf("code and name required")
	}
	maxTimes := intFromAny(in["maxTimesPerDay"], 0)
	maxConcurrent := intFromAny(in["maxConcurrent"], 0)
	limitSec := intFromAny(in["timeLimitSeconds"], 300)
	sortOrder := intFromAny(in["sortOrder"], 0)
	enabled := boolFromAny(in["enabled"], true)

	var id uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO wf_tg_activity_types (code, name, max_times_per_day, max_concurrent, time_limit_seconds, sort_order, enabled, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
		ON CONFLICT (code) DO UPDATE SET
			name = EXCLUDED.name,
			max_times_per_day = EXCLUDED.max_times_per_day,
			max_concurrent = EXCLUDED.max_concurrent,
			time_limit_seconds = EXCLUDED.time_limit_seconds,
			sort_order = EXCLUDED.sort_order,
			enabled = EXCLUDED.enabled,
			updated_at = NOW()
		RETURNING id`, code, name, maxTimes, maxConcurrent, limitSec, sortOrder, enabled).Scan(&id)
	if err != nil {
		return nil, err
	}
	types, err := s.ListActivityTypes(ctx)
	if err != nil {
		return nil, err
	}
	for _, t := range types {
		if t.ID == id {
			return &t, nil
		}
	}
	return nil, fmt.Errorf("activity type not found after upsert")
}

func (s *WorkforceTelegramService) DeleteActivityType(ctx context.Context, code string) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM wf_tg_activity_types WHERE code = $1`, strings.TrimSpace(code))
	return err
}

func (s *WorkforceTelegramService) ListActivityFines(ctx context.Context, activityCode string) ([]TgActivityFine, error) {
	query := `SELECT id, activity_code, segment_minutes, fine_amount FROM wf_tg_activity_fines`
	args := []interface{}{}
	if strings.TrimSpace(activityCode) != "" {
		query += ` WHERE activity_code = $1`
		args = append(args, activityCode)
	}
	query += ` ORDER BY activity_code, segment_minutes ASC`
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TgActivityFine, 0)
	for rows.Next() {
		var row TgActivityFine
		if err := rows.Scan(&row.ID, &row.ActivityCode, &row.SegmentMinutes, &row.FineAmount); err != nil {
			continue
		}
		items = append(items, row)
	}
	return items, nil
}

func (s *WorkforceTelegramService) UpsertActivityFine(ctx context.Context, activityCode string, segmentMinutes int, fineAmount float64) (*TgActivityFine, error) {
	activityCode = strings.TrimSpace(activityCode)
	if activityCode == "" || segmentMinutes <= 0 {
		return nil, fmt.Errorf("invalid fine rule")
	}
	var id uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO wf_tg_activity_fines (activity_code, segment_minutes, fine_amount)
		VALUES ($1, $2, $3)
		ON CONFLICT (activity_code, segment_minutes) DO UPDATE SET fine_amount = EXCLUDED.fine_amount
		RETURNING id`, activityCode, segmentMinutes, fineAmount).Scan(&id)
	if err != nil {
		return nil, err
	}
	fines, err := s.ListActivityFines(ctx, activityCode)
	if err != nil {
		return nil, err
	}
	for _, f := range fines {
		if f.ID == id {
			return &f, nil
		}
	}
	return nil, fmt.Errorf("fine rule not found")
}

type TgActivityFineBatchItem struct {
	SegmentMinutes int
	FineAmount     float64
}

func (s *WorkforceTelegramService) BatchUpsertActivityFines(ctx context.Context, activityCode string, items []TgActivityFineBatchItem) ([]TgActivityFine, error) {
	activityCode = strings.TrimSpace(activityCode)
	if activityCode == "" {
		return nil, fmt.Errorf("activity code required")
	}
	if len(items) == 0 {
		return nil, fmt.Errorf("at least one rule required")
	}

	seen := make(map[int]struct{}, len(items))
	for _, item := range items {
		if item.SegmentMinutes <= 0 {
			return nil, fmt.Errorf("segment minutes must be positive")
		}
		if _, dup := seen[item.SegmentMinutes]; dup {
			return nil, fmt.Errorf("duplicate segment minutes in batch: %d", item.SegmentMinutes)
		}
		seen[item.SegmentMinutes] = struct{}{}
	}

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	out := make([]TgActivityFine, 0, len(items))
	for _, item := range items {
		var id uuid.UUID
		err := tx.QueryRowContext(ctx, `
			INSERT INTO wf_tg_activity_fines (activity_code, segment_minutes, fine_amount)
			VALUES ($1, $2, $3)
			ON CONFLICT (activity_code, segment_minutes) DO UPDATE SET fine_amount = EXCLUDED.fine_amount
			RETURNING id`, activityCode, item.SegmentMinutes, item.FineAmount).Scan(&id)
		if err != nil {
			return nil, err
		}
		out = append(out, TgActivityFine{
			ID: id, ActivityCode: activityCode,
			SegmentMinutes: item.SegmentMinutes, FineAmount: item.FineAmount,
		})
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return out, nil
}

func (s *WorkforceTelegramService) DeleteActivityFine(ctx context.Context, id uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM wf_tg_activity_fines WHERE id = $1`, id)
	return err
}

func (s *WorkforceTelegramService) getActivityType(ctx context.Context, code string) (*TgActivityType, error) {
	code = strings.TrimSpace(code)
	var row TgActivityType
	err := s.db.QueryRowContext(ctx, `
		SELECT id, code, name, max_times_per_day, COALESCE(max_concurrent,0), time_limit_seconds, sort_order, enabled
		FROM wf_tg_activity_types WHERE code = $1`, code).
		Scan(&row.ID, &row.Code, &row.Name, &row.MaxTimesPerDay, &row.MaxConcurrent, &row.TimeLimitSeconds, &row.SortOrder, &row.Enabled)
	if err == sql.ErrNoRows {
		return nil, ErrActivityTypeNotFound
	}
	if err != nil {
		return nil, err
	}
	return &row, nil
}

func (s *WorkforceTelegramService) resolveActivityTypeByNameOrCode(ctx context.Context, key string) (*TgActivityType, error) {
	key = strings.TrimSpace(key)
	if key == "" {
		return nil, ErrActivityTypeNotFound
	}
	types, err := s.ListActivityTypes(ctx)
	if err != nil {
		return nil, err
	}
	for _, t := range types {
		if t.Code == key || t.Name == key {
			if !t.Enabled {
				return nil, ErrActivityTypeDisabled
			}
			return &t, nil
		}
	}
	return nil, ErrActivityTypeNotFound
}

func (s *WorkforceTelegramService) countTodayCompletedActivities(ctx context.Context, empID uuid.UUID, activityCode, date string) (int, error) {
	var count int
	err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND activity_code = $2 AND attendance_date = $3::date AND status = 'closed'`,
		empID, activityCode, date).Scan(&count)
	return count, err
}

func (s *WorkforceTelegramService) GetOpenActivitySession(ctx context.Context, empID uuid.UUID) (*TgActivitySession, error) {
	return s.getOpenActivitySession(ctx, empID)
}

func (s *WorkforceTelegramService) getOpenActivitySession(ctx context.Context, empID uuid.UUID) (*TgActivitySession, error) {
	var row TgActivitySession
	var endedAt sql.NullTime
	err := s.db.QueryRowContext(ctx, `
		SELECT s.id, s.employee_id, e.name, s.activity_code, s.activity_name, s.attendance_date::text,
			s.started_at, s.ended_at, s.elapsed_seconds, s.limit_seconds, s.overtime_seconds, s.fine_amount, s.status
		FROM wf_tg_activity_sessions s
		JOIN employees e ON e.id = s.employee_id
		WHERE s.employee_id = $1 AND s.status = 'open'`, empID).
		Scan(&row.ID, &row.EmployeeID, &row.EmployeeName, &row.ActivityCode, &row.ActivityName, &row.AttendanceDate,
			&row.StartedAt, &endedAt, &row.ElapsedSeconds, &row.LimitSeconds, &row.OvertimeSeconds, &row.FineAmount, &row.Status)
	if err == sql.ErrNoRows {
		return nil, ErrActivityNotActive
	}
	if err != nil {
		return nil, err
	}
	if endedAt.Valid {
		row.EndedAt = &endedAt.Time
	}
	return &row, nil
}

func (s *WorkforceTelegramService) loadActivityFineMap(ctx context.Context, activityCode string) map[int]float64 {
	fines, err := s.ListActivityFines(ctx, activityCode)
	if err != nil {
		return nil
	}
	out := make(map[int]float64)
	for _, f := range fines {
		out[f.SegmentMinutes] = f.FineAmount
	}
	return out
}

func (s *WorkforceTelegramService) autoEndActivityIfCrossShift(ctx context.Context, empID uuid.UUID, newShift, recordDate string) error {
	sess, err := s.getOpenActivitySession(ctx, empID)
	if errors.Is(err, ErrActivityNotActive) {
		return nil
	}
	if err != nil {
		return err
	}
	var actShift string
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day') FROM wf_tg_activity_sessions WHERE id = $1`, sess.ID).Scan(&actShift)
	if sess.AttendanceDate == recordDate && actShift == newShift {
		return nil
	}
	_, err = s.closeActivitySession(ctx, sess.ID, false)
	return err
}

func (s *WorkforceTelegramService) endActivityForEmployee(ctx context.Context, empID uuid.UUID) (*TgActivitySession, error) {
	if !s.tryAcquireBackLock(empID) {
		return nil, ErrBackProcessing
	}
	session, err := s.getOpenActivitySession(ctx, empID)
	if err != nil {
		return nil, err
	}
	return s.closeActivitySession(ctx, session.ID, false)
}

func (s *WorkforceTelegramService) TelegramStartActivity(ctx context.Context, telegramUserID int64, chatID, activityKey string) (*TgActivityStartResult, error) {
	active, err := s.IsActive(ctx)
	if err != nil || !active {
		return nil, ErrTelegramDisabled
	}
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil {
		return nil, err
	}
	effectiveChat := strings.TrimSpace(chatID)
	if effectiveChat == "" {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(chat_id,'') FROM employee_telegram_bindings WHERE employee_id = $1 AND status = 1`, empID).Scan(&effectiveChat)
	}
	if effectiveChat != "" {
		s.MaybeLazyResetForChat(ctx, effectiveChat)
	}
	if !tryAcquireUserLock(empID, 3*time.Second) {
		return nil, ErrBackProcessing
	}
	if _, err := s.closeExpiredWorkSessionsForEmployee(ctx, empID, effectiveChat); err != nil {
		log.Printf("[Telegram] close expired shifts emp=%s: %v", empID, err)
	}

	workShift, err := s.getOpenWorkShift(ctx, empID)
	if err != nil {
		return nil, ErrActivityNotInWork
	}
	if _, err = s.getOpenActivitySession(ctx, empID); err == nil {
		return nil, ErrActivityAlreadyActive
	} else if !errors.Is(err, ErrActivityNotActive) {
		return nil, err
	}

	actType, err := s.resolveActivityTypeByNameOrCode(ctx, activityKey)
	if err != nil {
		return nil, err
	}

	businessDate, _, cycle, err := s.resolveActivityBusinessDate(ctx, effectiveChat, empID, workShift)
	if err != nil {
		businessDate = time.Now().Format("2006-01-02")
		cycle = 1
	}

	if actType.MaxTimesPerDay > 0 {
		count, err := s.countActivitiesOnDate(ctx, empID, actType.Code, businessDate, workShift, cycle)
		if err != nil {
			return nil, err
		}
		if count >= actType.MaxTimesPerDay {
			return nil, ErrActivityLimitReached
		}
	}
	if actType.MaxConcurrent > 0 {
		var openTeam int
		_ = s.db.QueryRowContext(ctx, `
			SELECT COUNT(*) FROM wf_tg_activity_sessions
			WHERE activity_code = $1 AND status = 'open'
			  AND ($2 = '' OR COALESCE(source_chat_id,'') = $2)`,
			actType.Code, effectiveChat).Scan(&openTeam)
		if openTeam >= actType.MaxConcurrent {
			return nil, ErrActivityConcurrentLimit
		}
	}

	sessionID := uuid.New()
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_activity_sessions (
			id, employee_id, activity_code, activity_name, attendance_date, limit_seconds, status, source, shift_type, source_chat_id
		) VALUES ($1, $2, $3, $4, $5::date, $6, 'open', 'telegram', $7, NULLIF($8,''))`,
		sessionID, empID, actType.Code, actType.Name, businessDate, actType.TimeLimitSeconds, workShift, effectiveChat)
	if err != nil {
		return nil, err
	}
	sess, err := s.getOpenActivitySession(ctx, empID)
	if err != nil {
		return nil, err
	}
	count, _ := s.countActivitiesOnDate(ctx, empID, actType.Code, businessDate, workShift, cycle)
	limitMin := actType.TimeLimitSeconds / 60
	if actType.TimeLimitSeconds%60 != 0 && actType.TimeLimitSeconds > 0 {
		limitMin++
	}
	maxStr := "不限"
	if actType.MaxTimesPerDay > 0 {
		maxStr = fmt.Sprintf("%d", actType.MaxTimesPerDay)
	}
	msg := fmt.Sprintf("✅ 打卡成功：%s\n📊 班次：%s\n⏰ 时限：%d 分钟\n📈 今日次数：第 %d 次（上限 %s 次）\n\n💡 结束后请点击「回座」按钮",
		actType.Name, shiftLabel(workShift), limitMin, count+1, maxStr)
	groupHTML := buildActivityStartGroupReplyHTML(
		telegramUserID, sess.EmployeeName, actType.Name,
		time.Now().Format("01/02 15:04:05"), shiftLabel(workShift),
		count+1, actType.MaxTimesPerDay, limitMin,
	)
	return &TgActivityStartResult{
		Session:        sess,
		MessageText:    msg,
		GroupReplyHTML: groupHTML,
		InlineKeyboard: inlineQuickBackKeyboard(sessionID.String()),
	}, nil
}

func (s *WorkforceTelegramService) TelegramEndActivity(ctx context.Context, telegramUserID int64) (*TgActivitySession, error) {
	active, err := s.IsActive(ctx)
	if err != nil || !active {
		return nil, ErrTelegramDisabled
	}
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil {
		return nil, err
	}
	return s.endActivityForEmployee(ctx, empID)
}

func (s *WorkforceTelegramService) TelegramEndActivityBySession(ctx context.Context, sessionID uuid.UUID) (*TgActivitySession, error) {
	var empID uuid.UUID
	err := s.db.QueryRowContext(ctx, `SELECT employee_id FROM wf_tg_activity_sessions WHERE id = $1 AND status = 'open'`, sessionID).Scan(&empID)
	if err == sql.ErrNoRows {
		return nil, ErrActivityNotActive
	}
	if err != nil {
		return nil, err
	}
	if !s.tryAcquireBackLock(empID) {
		return nil, ErrBackProcessing
	}
	return s.closeActivitySession(ctx, sessionID, false)
}

func (s *WorkforceTelegramService) closeActivitySession(ctx context.Context, sessionID uuid.UUID, autoEnded bool) (*TgActivitySession, error) {
	var empID uuid.UUID
	var session TgActivitySession
	var endedAt sql.NullTime
	err := s.db.QueryRowContext(ctx, `
		SELECT s.id, s.employee_id, e.name, s.activity_code, s.activity_name, s.attendance_date::text,
			s.started_at, s.ended_at, s.elapsed_seconds, s.limit_seconds, s.overtime_seconds, s.fine_amount, s.status,
			COALESCE(s.shift_type,'day'), COALESCE(s.source_chat_id,'')
		FROM wf_tg_activity_sessions s
		JOIN employees e ON e.id = s.employee_id
		WHERE s.id = $1 AND s.status = 'open'`, sessionID).
		Scan(&session.ID, &session.EmployeeID, &session.EmployeeName, &session.ActivityCode, &session.ActivityName, &session.AttendanceDate,
			&session.StartedAt, &endedAt, &session.ElapsedSeconds, &session.LimitSeconds, &session.OvertimeSeconds, &session.FineAmount, &session.Status,
			&session.ShiftType, new(string))
	if err == sql.ErrNoRows {
		return nil, ErrActivityNotActive
	}
	if err != nil {
		return nil, err
	}
	empID = session.EmployeeID

	now := time.Now()
	elapsed := int(math.Max(0, now.Sub(session.StartedAt).Seconds()))
	overtime := 0
	if session.LimitSeconds > 0 && elapsed > session.LimitSeconds {
		overtime = elapsed - session.LimitSeconds
	}
	overtimeMinutes := float64(overtime) / 60.0
	fineMap := s.loadActivityFineMap(ctx, session.ActivityCode)
	fine := computeActivityOvertimeFine(fineMap, overtimeMinutes)

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	var penaltyID sql.NullString
	if fine > 0 {
		pid := uuid.NewString()
		_, err = tx.ExecContext(ctx, `
			INSERT INTO penalty_records (id, employee_id, employee_name, position, amount, category, reason, penalty_date, created_by, created_at)
			SELECT $1, e.id, e.name, COALESCE(e.position,''), $2, 'TG活动', $3, $4::date, 'telegram', NOW()
			FROM employees e WHERE e.id = $5`,
			pid, fine, fmt.Sprintf("%s 超时 %d 秒", session.ActivityName, overtime), session.AttendanceDate, empID)
		if err != nil {
			return nil, err
		}
		penaltyID = sql.NullString{String: pid, Valid: true}
	}

	_, err = tx.ExecContext(ctx, `
		UPDATE wf_tg_activity_sessions SET
			status = 'closed', ended_at = NOW(), elapsed_seconds = $1,
			overtime_seconds = $2, fine_amount = $3, penalty_record_id = NULLIF($4, '')::uuid,
			auto_ended = $5
		WHERE id = $6 AND status = 'open'`,
		elapsed, overtime, fine, nullStringFromNull(penaltyID), autoEnded, sessionID)
	if err != nil {
		return nil, err
	}
	if err = tx.Commit(); err != nil {
		return nil, err
	}

	var chatID string
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(source_chat_id,'') FROM wf_tg_activity_sessions WHERE id = $1`, sessionID).Scan(&chatID)
	if chatID == "" {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(chat_id,'') FROM employee_telegram_bindings WHERE employee_id = $1 AND status = 1`, empID).Scan(&chatID)
	}
	if period, err := s.DetermineCurrentPeriod(ctx, chatID, now); err == nil {
		s.bumpHandoverCycleWork(ctx, chatID, empID, period, elapsed)
	}

	var tgUID int64
	_ = s.db.QueryRowContext(ctx, `
		SELECT telegram_user_id FROM employee_telegram_bindings WHERE employee_id = $1 AND status = 1 LIMIT 1`, empID).
		Scan(&tgUID)

	activityCounts, totalDailyCount, totalDailySec := s.dailyActivityStats(ctx, empID, session.AttendanceDate, session.ShiftType)
	todayActivityCount := activityCounts[session.ActivityName]
	totalActivitySec := 0
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(SUM(elapsed_seconds),0)::int FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND attendance_date = $2::date AND shift_type = $3
		  AND activity_name = $4 AND status = 'closed'`,
		empID, session.AttendanceDate, session.ShiftType, session.ActivityName).Scan(&totalActivitySec)

	session.GroupReplyHTML = buildActivityEndGroupReplyHTML(
		tgUID, session.EmployeeName, session.ActivityName,
		now.Format("01/02 15:04:05"),
		elapsed, todayActivityCount, totalActivitySec, totalDailySec, totalDailyCount,
		activityCounts,
		overtime > 0, overtime, fine,
	)

	if overtime > 0 {
		s.NotifyActivityOvertimeBack(ctx, chatID, session.EmployeeName, session.ActivityName, tgUID, overtime, fine, now)
	} else if autoEnded {
		s.NotifyActivityEvent(ctx, chatID, session.EmployeeName, session.ActivityName, "超时自动结束",
			fmt.Sprintf("用时 %s", formatDurationZh(elapsed)))
	}

	session.ElapsedSeconds = elapsed
	session.OvertimeSeconds = overtime
	session.FineAmount = fine
	session.Status = "closed"
	session.EndedAt = &now
	return &session, nil
}

func nullStringFromNull(v sql.NullString) string {
	if v.Valid {
		return v.String
	}
	return ""
}

func (s *WorkforceTelegramService) dailyActivityStats(ctx context.Context, empID uuid.UUID, attendanceDate, shift string) (map[string]int, int, int) {
	counts := make(map[string]int)
	totalCount := 0
	totalSec := 0
	rows, err := s.db.QueryContext(ctx, `
		SELECT activity_name, COUNT(*), COALESCE(SUM(elapsed_seconds),0)::int
		FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND attendance_date = $2::date AND shift_type = $3 AND status = 'closed'
		GROUP BY activity_name ORDER BY activity_name`, empID, attendanceDate, shift)
	if err != nil {
		return counts, 0, 0
	}
	defer rows.Close()
	for rows.Next() {
		var name string
		var count, sec int
		if rows.Scan(&name, &count, &sec) != nil {
			continue
		}
		counts[name] = count
		totalCount += count
		totalSec += sec
	}
	return counts, totalCount, totalSec
}

func (s *WorkforceTelegramService) ListActivitySessions(ctx context.Context, date, employeeID, search string, limit int) ([]TgActivitySession, error) {
	if limit <= 0 {
		limit = 100
	}
	if limit > 500 {
		limit = 500
	}
	tz := "Asia/Shanghai"
	if settings, err := s.GetSettings(ctx); err == nil && strings.TrimSpace(settings.Timezone) != "" {
		tz = strings.TrimSpace(settings.Timezone)
	}
	where := "s.status IN ('open', 'closed')"
	args := []interface{}{}
	argN := 1
	if strings.TrimSpace(date) != "" {
		where += fmt.Sprintf(` AND (
			s.attendance_date = $%d::date
			OR ((s.started_at AT TIME ZONE $%d)::date = $%d::date)
		)`, argN, argN+1, argN)
		args = append(args, date, tz)
		argN += 2
	}
	if strings.TrimSpace(employeeID) != "" {
		where += fmt.Sprintf(" AND s.employee_id = $%d::uuid", argN)
		args = append(args, employeeID)
		argN++
	}
	if strings.TrimSpace(search) != "" {
		where += fmt.Sprintf(" AND (e.name ILIKE $%d OR s.activity_name ILIKE $%d)", argN, argN)
		args = append(args, "%"+search+"%")
		argN++
	}
	query := fmt.Sprintf(`
		SELECT s.id, s.employee_id, e.name, s.activity_code, s.activity_name, s.attendance_date::text,
			s.started_at, s.ended_at, s.elapsed_seconds, s.limit_seconds, s.overtime_seconds, s.fine_amount, s.status
		FROM wf_tg_activity_sessions s
		JOIN employees e ON e.id = s.employee_id
		WHERE %s
		ORDER BY s.started_at DESC
		LIMIT %d`, where, limit)
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TgActivitySession, 0)
	for rows.Next() {
		var row TgActivitySession
		var endedAt sql.NullTime
		if err := rows.Scan(&row.ID, &row.EmployeeID, &row.EmployeeName, &row.ActivityCode, &row.ActivityName, &row.AttendanceDate,
			&row.StartedAt, &endedAt, &row.ElapsedSeconds, &row.LimitSeconds, &row.OvertimeSeconds, &row.FineAmount, &row.Status); err != nil {
			continue
		}
		if endedAt.Valid {
			row.EndedAt = &endedAt.Time
		}
		items = append(items, row)
	}
	return items, nil
}

type TgWorkSessionRow struct {
	ID             uuid.UUID
	EmployeeID     uuid.UUID
	EmployeeName   string
	EmployeeCode   string
	AttendanceDate string
	ShiftType      string
	CheckinTime    time.Time
	CheckoutTime   *time.Time
	Source         string
	Status         string
}

func (s *WorkforceTelegramService) ListWorkSessions(ctx context.Context, date, employeeID, search string, limit int) ([]TgWorkSessionRow, error) {
	if limit <= 0 {
		limit = 100
	}
	if limit > 500 {
		limit = 500
	}
	tz := "Asia/Shanghai"
	if settings, err := s.GetSettings(ctx); err == nil && strings.TrimSpace(settings.Timezone) != "" {
		tz = strings.TrimSpace(settings.Timezone)
	}
	where := "ws.source IN ('telegram', 'agent')"
	args := []interface{}{}
	argN := 1
	if strings.TrimSpace(date) != "" {
		where += fmt.Sprintf(` AND (
			ws.attendance_date = $%d::date
			OR ((ws.checkin_time AT TIME ZONE $%d)::date = $%d::date)
		)`, argN, argN+1, argN)
		args = append(args, date, tz)
		argN += 2
	}
	if strings.TrimSpace(employeeID) != "" {
		where += fmt.Sprintf(" AND ws.employee_id = $%d::uuid", argN)
		args = append(args, employeeID)
		argN++
	}
	if strings.TrimSpace(search) != "" {
		where += fmt.Sprintf(" AND (e.name ILIKE $%d OR COALESCE(e.employee_id,'') ILIKE $%d)", argN, argN)
		args = append(args, "%"+search+"%")
		argN++
	}
	query := fmt.Sprintf(`
		SELECT ws.id, ws.employee_id, e.name, COALESCE(e.employee_id,''),
			ws.attendance_date::text, COALESCE(ws.shift_type,'day'),
			ws.checkin_time, ws.checkout_time, ws.source, ws.status
		FROM work_sessions ws
		JOIN employees e ON e.id = ws.employee_id
		WHERE %s
		ORDER BY ws.checkin_time DESC
		LIMIT %d`, where, limit)
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TgWorkSessionRow, 0)
	for rows.Next() {
		var row TgWorkSessionRow
		var checkout sql.NullTime
		if err := rows.Scan(&row.ID, &row.EmployeeID, &row.EmployeeName, &row.EmployeeCode,
			&row.AttendanceDate, &row.ShiftType, &row.CheckinTime, &checkout, &row.Source, &row.Status); err != nil {
			continue
		}
		if checkout.Valid {
			row.CheckoutTime = &checkout.Time
		}
		items = append(items, row)
	}
	return items, nil
}

type TgMyInfoSummary struct {
	EmployeeName      string
	WorkSessionOpen   bool
	CurrentActivity   string
	ActivityStartedAt *time.Time
	TodayActivities   []map[string]interface{}
	TodayFineTotal    float64
	ShiftFilter       string
	ShiftLabel        string
}

func (s *WorkforceTelegramService) GetMyInfo(ctx context.Context, telegramUserID int64) (*TgMyInfoSummary, error) {
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil {
		return nil, err
	}
	var name string
	_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, empID).Scan(&name)

	openWork, _, _ := s.GetEmployeeSessionStatus(ctx, empID)
	out := &TgMyInfoSummary{EmployeeName: name, WorkSessionOpen: openWork}

	if sess, err := s.getOpenActivitySession(ctx, empID); err == nil {
		out.CurrentActivity = sess.ActivityName
		t := sess.StartedAt
		out.ActivityStartedAt = &t
	}

	today := time.Now().Format("2006-01-02")
	rows, err := s.db.QueryContext(ctx, `
		SELECT activity_name, COUNT(*), COALESCE(SUM(elapsed_seconds),0), COALESCE(SUM(fine_amount),0)
		FROM wf_tg_activity_sessions
		WHERE employee_id = $1 AND attendance_date = $2::date AND status = 'closed'
		GROUP BY activity_name ORDER BY activity_name`, empID, today)
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var actName string
			var count, totalSec int
			var fineTotal float64
			if rows.Scan(&actName, &count, &totalSec, &fineTotal) == nil {
				out.TodayActivities = append(out.TodayActivities, map[string]interface{}{
					"name": actName, "count": count, "totalSeconds": totalSec, "fineAmount": fineTotal,
				})
				out.TodayFineTotal += fineTotal
			}
		}
	}
	return out, nil
}

func intFromAny(v interface{}, def int) int {
	switch n := v.(type) {
	case float64:
		return int(n)
	case int:
		return n
	case int64:
		return int(n)
	default:
		return def
	}
}

func boolFromAny(v interface{}, def bool) bool {
	b, ok := v.(bool)
	if !ok {
		return def
	}
	return b
}

func (s *WorkforceTelegramService) ListEnabledActivityTypesForWorker(ctx context.Context) ([]TgActivityType, error) {
	all, err := s.ListActivityTypes(ctx)
	if err != nil {
		return nil, err
	}
	out := make([]TgActivityType, 0)
	for _, t := range all {
		if t.Enabled {
			out = append(out, t)
		}
	}
	return out, nil
}

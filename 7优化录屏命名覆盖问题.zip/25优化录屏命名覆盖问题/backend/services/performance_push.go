package services

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"net/http"
	"strings"
	"time"
)

type PerformancePushService struct {
	db *sql.DB
}

func NewPerformancePushService(db *sql.DB) *PerformancePushService {
	return &PerformancePushService{db: db}
}

type PerformancePushSettings struct {
	HasBotToken bool   `json:"hasBotToken"`
	BotUsername string `json:"botUsername"`
	ChatID      string `json:"chatId"`
	ChatTitle   string `json:"chatTitle"`
	ChatType    string `json:"chatType"`
	Enabled     bool   `json:"enabled"`
	Ready       bool   `json:"ready"`
	UpdatedAt   string `json:"updatedAt,omitempty"`
}

func performancePushReady(hasBotToken bool, chatID string, enabled bool) bool {
	return enabled && hasBotToken && strings.TrimSpace(chatID) != ""
}

type PerformancePushRecord struct {
	Date         string `json:"date"`
	EmployeeName string `json:"employeeName"`
	Position     string `json:"position"`
	Score        int    `json:"score"`
	Reason       string `json:"reason"`
}

func (s *PerformancePushService) GetSettings(ctx context.Context) (*PerformancePushSettings, error) {
	out := &PerformancePushSettings{}
	var tokenEnc, botUsername, chatID, chatTitle, chatType sql.NullString
	var botID sql.NullInt64
	var enabled bool
	var updatedAt time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT bot_token_enc, bot_username, bot_id, chat_id, chat_title, chat_type, enabled, updated_at
		FROM performance_push_settings WHERE id = 1`).
		Scan(&tokenEnc, &botUsername, &botID, &chatID, &chatTitle, &chatType, &enabled, &updatedAt)
	if err == sql.ErrNoRows {
		return out, nil
	}
	if err != nil {
		return nil, err
	}
	out.HasBotToken = tokenEnc.Valid && strings.TrimSpace(tokenEnc.String) != ""
	if botUsername.Valid {
		out.BotUsername = botUsername.String
	}
	if chatID.Valid {
		out.ChatID = chatID.String
	}
	if chatTitle.Valid {
		out.ChatTitle = chatTitle.String
	}
	if chatType.Valid {
		out.ChatType = chatType.String
	}
	out.Enabled = enabled
	out.Ready = performancePushReady(out.HasBotToken, out.ChatID, enabled)
	out.UpdatedAt = updatedAt.UTC().Format(time.RFC3339)
	return out, nil
}

func (s *PerformancePushService) SetPushEnabled(ctx context.Context, enabled bool) (*PerformancePushSettings, error) {
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO performance_push_settings (id, enabled, updated_at)
		VALUES (1, $1, NOW())
		ON CONFLICT (id) DO UPDATE SET
			enabled = EXCLUDED.enabled,
			updated_at = NOW()`, enabled)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PerformancePushService) SaveBotToken(ctx context.Context, token string) (*PerformancePushSettings, error) {
	token = strings.TrimSpace(token)
	if token == "" {
		return nil, fmt.Errorf("Bot Token 不能为空")
	}
	username, botID, err := performanceTelegramGetMe(token)
	if err != nil {
		return nil, err
	}
	enc, err := EncryptSecret(token)
	if err != nil {
		return nil, err
	}
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO performance_push_settings (id, bot_token_enc, bot_username, bot_id, updated_at)
		VALUES (1, $1, $2, $3, NOW())
		ON CONFLICT (id) DO UPDATE SET
			bot_token_enc = EXCLUDED.bot_token_enc,
			bot_username = EXCLUDED.bot_username,
			bot_id = EXCLUDED.bot_id,
			updated_at = NOW()`, enc, username, botID)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PerformancePushService) DiscoverChats(ctx context.Context) ([]map[string]string, error) {
	token, err := s.getBotToken(ctx)
	if err != nil {
		return nil, err
	}
	return telegramScanRecentChats(token)
}

func (s *PerformancePushService) BindChat(ctx context.Context, chatID, chatTitle, chatType string) (*PerformancePushSettings, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return nil, fmt.Errorf("chatId required")
	}
	if _, err := s.getBotToken(ctx); err != nil {
		return nil, err
	}
	title := strings.TrimSpace(chatTitle)
	if title == "" {
		title = chatID
	}
	chatType = strings.TrimSpace(chatType)
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO performance_push_settings (id, chat_id, chat_title, chat_type, updated_at)
		VALUES (1, $1, $2, $3, NOW())
		ON CONFLICT (id) DO UPDATE SET
			chat_id = EXCLUDED.chat_id,
			chat_title = EXCLUDED.chat_title,
			chat_type = EXCLUDED.chat_type,
			updated_at = NOW()`, chatID, title, chatType)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PerformancePushService) UnbindChat(ctx context.Context) (*PerformancePushSettings, error) {
	_, err := s.db.ExecContext(ctx, `
		UPDATE performance_push_settings
		SET chat_id = NULL, chat_title = NULL, chat_type = NULL, updated_at = NOW()
		WHERE id = 1`)
	if err != nil {
		return nil, err
	}
	return s.GetSettings(ctx)
}

func (s *PerformancePushService) PushScoreRecord(ctx context.Context, rec PerformancePushRecord) (bool, error) {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return false, err
	}
	if !settings.Ready {
		return false, nil
	}
	token, err := s.getBotToken(ctx)
	if err != nil {
		return false, err
	}
	text := buildPerformancePushHTML(rec)
	if err := performanceTelegramSendHTML(token, settings.ChatID, text); err != nil {
		return false, err
	}
	return true, nil
}

func (s *PerformancePushService) TestPush(ctx context.Context) error {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return err
	}
	if settings.ChatID == "" {
		return fmt.Errorf("请先绑定频道或群组")
	}
	token, err := s.getBotToken(ctx)
	if err != nil {
		return err
	}
	text := "<b>📋 绩效推送测试</b>\n\n配置成功，后续新增绩效记录将推送到此频道/群组。"
	return performanceTelegramSendHTML(token, settings.ChatID, text)
}

func (s *PerformancePushService) getBotToken(ctx context.Context) (string, error) {
	var enc sql.NullString
	err := s.db.QueryRowContext(ctx, `SELECT bot_token_enc FROM performance_push_settings WHERE id = 1`).Scan(&enc)
	if err == sql.ErrNoRows || !enc.Valid || strings.TrimSpace(enc.String) == "" {
		return "", fmt.Errorf("请先配置 Bot Token")
	}
	if err != nil {
		return "", err
	}
	return DecryptSecret(enc.String)
}

func buildPerformancePushHTML(rec PerformancePushRecord) string {
	changeType := "加分"
	scoreText := fmt.Sprintf("+%d分", rec.Score)
	if rec.Score < 0 {
		changeType = "扣分"
		scoreText = fmt.Sprintf("%d分", rec.Score)
	}
	date := html.EscapeString(strings.TrimSpace(rec.Date))
	name := html.EscapeString(strings.TrimSpace(rec.EmployeeName))
	position := html.EscapeString(strings.TrimSpace(rec.Position))
	if position == "" {
		position = "-"
	}
	reason := html.EscapeString(strings.TrimSpace(rec.Reason))
	if reason == "" {
		reason = "-"
	}
	return fmt.Sprintf(
		"<b>📋 绩效变动通知</b>\n\n"+
			"<b>日期</b>：%s\n"+
			"<b>员工</b>：%s\n"+
			"<b>岗位</b>：%s\n"+
			"<b>变动</b>：%s（%s）\n"+
			"<b>原因</b>：%s",
		date, name, position, scoreText, changeType, reason,
	)
}

func performanceTelegramGetMe(token string) (string, int64, error) {
	client := &http.Client{Timeout: 12 * time.Second}
	resp, err := client.Get(fmt.Sprintf("https://api.telegram.org/bot%s/getMe", token))
	if err != nil {
		return "", 0, err
	}
	defer resp.Body.Close()
	var out struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
		Result      struct {
			ID       int64  `json:"id"`
			Username string `json:"username"`
		} `json:"result"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return "", 0, err
	}
	if !out.OK {
		if out.Description == "" {
			out.Description = "getMe failed"
		}
		return "", 0, fmt.Errorf("%s", out.Description)
	}
	return out.Result.Username, out.Result.ID, nil
}

func performanceTelegramSendHTML(token, chatID, htmlText string) error {
	payload := map[string]interface{}{
		"chat_id":    chatID,
		"text":       htmlText,
		"parse_mode": "HTML",
	}
	body, _ := json.Marshal(payload)
	resp, err := http.Post(
		fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", token),
		"application/json",
		bytes.NewReader(body),
	)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
	}
	_ = json.Unmarshal(raw, &parsed)
	if !parsed.OK {
		if parsed.Description == "" {
			parsed.Description = string(raw)
		}
		return fmt.Errorf("telegram sendMessage: %s", parsed.Description)
	}
	return nil
}

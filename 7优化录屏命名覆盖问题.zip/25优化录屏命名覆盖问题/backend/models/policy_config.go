package models

import (
	"encoding/json"
	"math"
)

const (
	DefaultRemoteViewWidth  = 1280
	DefaultRemoteViewHeight = 720
	DefaultRemoteViewFps    = 10
)

type RemoteViewPolicyConfig struct {
	Width  int `json:"width"`
	Height int `json:"height"`
	Fps    int `json:"fps"`
}

type UploadPolicyConfig struct {
	Enabled        bool `json:"enabled"`
	RateLimitKBps  int  `json:"rateLimitKBps"`
	MaxConcurrent  int  `json:"maxConcurrent"`
	ChunkSizeKB    int  `json:"chunkSizeKB"`
}

type PolicyConfigEnvelope struct {
	Config struct {
		RemoteView *RemoteViewPolicyConfig `json:"remoteView"`
		Upload     *UploadPolicyConfig     `json:"upload"`
	} `json:"config"`
}

func clampInt(value, min, max, fallback int) int {
	if value < min || value > max {
		return fallback
	}
	return value
}

// ParseRemoteViewFromPolicyContent reads config.remoteView from signed policy JSON.
func ParseRemoteViewFromPolicyContent(content string) RemoteViewPolicyConfig {
	cfg := RemoteViewPolicyConfig{
		Width:  DefaultRemoteViewWidth,
		Height: DefaultRemoteViewHeight,
		Fps:    DefaultRemoteViewFps,
	}
	if content == "" {
		return cfg
	}

	var envelope PolicyConfigEnvelope
	if err := json.Unmarshal([]byte(content), &envelope); err != nil || envelope.Config.RemoteView == nil {
		return cfg
	}

	rv := envelope.Config.RemoteView
	if rv.Width > 0 {
		cfg.Width = clampInt(rv.Width, 640, 3840, DefaultRemoteViewWidth)
	}
	if rv.Height > 0 {
		cfg.Height = clampInt(rv.Height, 480, 2160, DefaultRemoteViewHeight)
	}
	if rv.Fps > 0 {
		cfg.Fps = clampInt(rv.Fps, 1, 30, DefaultRemoteViewFps)
	}

	// Keep even dimensions for encoders.
	cfg.Width = int(math.Floor(float64(cfg.Width/2))) * 2
	cfg.Height = int(math.Floor(float64(cfg.Height/2))) * 2
	if cfg.Width <= 0 {
		cfg.Width = DefaultRemoteViewWidth
	}
	if cfg.Height <= 0 {
		cfg.Height = DefaultRemoteViewHeight
	}

	return cfg
}

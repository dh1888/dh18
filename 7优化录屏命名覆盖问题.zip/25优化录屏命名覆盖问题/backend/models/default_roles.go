package models

// ========== 扩展权限常量 ==========

const (
	PermInviteView   = "invite:view"
	PermInviteManage = "invite:manage"

	PermCallbackView     = "callback:view"
	PermCallbackManage   = "callback:manage"
	PermCallbackSettings = "callback:settings"

	PermDomainMonitorView     = "domain_monitor:view"
	PermDomainMonitorManage   = "domain_monitor:manage"
	PermDomainMonitorSettings = "domain_monitor:settings"

	PermProfileView     = "profile:view"
	PermProfileEdit     = "profile:edit"
	PermProfilePassword = "profile:password"
	PermProfileTotp     = "profile:totp"
	PermProfileInvite   = "profile:invite"

	PermEmployeePortalView         = "employee:portal:view"
	PermEmployeeAttendanceViewOwn  = "employee:attendance:view_own"
	PermEmployeeRecordingViewOwn   = "employee:recording:view_own"
	PermEmployeeDeviceViewOwn      = "employee:device:view_own"
	PermEmployeeInviteViewOwn      = "employee:invite:view_own"
	PermEmployeeProfileEdit        = "employee:profile:edit"
	PermEmployeeClientDownload       = "employee:client:download"
)

// DefaultEmployeePortalPermissions 员工自助门户（Agent 登录）
var DefaultEmployeePortalPermissions = []string{
	PermEmployeePortalView,
	PermEmployeeAttendanceViewOwn,
	PermEmployeeRecordingViewOwn,
	PermEmployeeDeviceViewOwn,
	PermEmployeeInviteViewOwn,
	PermEmployeeProfileEdit,
	PermEmployeeClientDownload,
}

// AllAdminPermissions 管理员拥有全部后台权限
func AllAdminPermissions() []string {
	return []string{
		PermUserView, PermUserCreate, PermUserUpdate, PermUserDelete, PermUserManage,
		PermRoleView, PermRoleCreate, PermRoleUpdate, PermRoleDelete,
		PermDeviceView, PermDeviceRemote, PermDeviceManage, PermDeviceBind, PermDeviceUnbind,
		PermRecordingView, PermRecordingPlay, PermRecordingExport, PermRecordingDelete, PermRecordingUpload,
		PermScreenshotView, PermScreenshotDelete,
		PermActivityView, PermActivityExport, PermActivityDelete,
		PermPolicyView, PermPolicyCreate, PermPolicyUpdate, PermPolicyDelete,
		PermAuditView,
		PermAttendanceView, PermAttendanceEdit,
		PermTelegramView, PermTelegramEdit,
		PermInviteView, PermInviteManage,
		PermSiteView, PermSiteManage,
		PermStatsView, PermStatsEdit,
		PermSalaryView, PermSalaryEdit, PermSalaryUpload, PermSalaryDelete, PermSalaryPaymentAddressView,
		PermOperationLogView, PermOperationLogExport, PermOperationLogDelete,
		PermCallbackView, PermCallbackManage, PermCallbackSettings,
		PermDomainMonitorView, PermDomainMonitorManage, PermDomainMonitorSettings,
		PermProfileView, PermProfileEdit, PermProfilePassword, PermProfileTotp, PermProfileInvite,
	}
}

// DefaultOperatorPermissions 操作员（组长）
var DefaultOperatorPermissions = []string{
	PermUserView, PermUserCreate, PermUserUpdate, PermUserDelete, PermUserManage,
	PermDeviceView, PermDeviceRemote, PermDeviceManage, PermDeviceBind, PermDeviceUnbind,
	PermRecordingView, PermRecordingPlay, PermRecordingExport,
	PermScreenshotView,
	PermActivityView,
	PermAttendanceView, PermAttendanceEdit,
	PermTelegramView, PermTelegramEdit,
	PermSiteView, PermSiteManage,
	PermStatsView, PermStatsEdit,
	PermSalaryView,
	PermCallbackView, PermCallbackManage, PermCallbackSettings,
	PermDomainMonitorView, PermDomainMonitorManage, PermDomainMonitorSettings,
	PermInviteView, PermInviteManage,
}

// DefaultAuditorPermissions 审计员（助理）— 以查看为主，考勤/出款/个人资料可编辑
var DefaultAuditorPermissions = []string{
	PermUserView,
	PermDeviceView,
	PermRecordingView, PermRecordingPlay,
	PermScreenshotView,
	PermActivityView,
	PermAttendanceView, PermAttendanceEdit,
	PermTelegramView, PermTelegramEdit,
	PermSiteView, PermSiteManage,
	PermStatsView, PermStatsEdit,
	PermSalaryView,
	PermProfileView, PermProfileEdit, PermProfilePassword, PermProfileTotp, PermProfileInvite,
}

// DefaultViewerPermissions 查看员 — 只读：工资、出款统计、考勤
var DefaultViewerPermissions = []string{
	PermSalaryView,
	PermStatsView,
	PermAttendanceView,
}

// DefaultRoleSeed 启动时自动创建/同步的默认角色
type DefaultRoleSeed struct {
	Name        string
	Description string
	Permissions []string
	ExactSync   bool // true=每次启动对齐权限列表；false=仅合并缺失权限
}

var DefaultRoleSeeds = []DefaultRoleSeed{
	{
		Name:        "管理员",
		Description: "拥有所有权限",
		Permissions: AllAdminPermissions(),
		ExactSync:   false,
	},
	{
		Name:        "操作员",
		Description: "组长：用户/设备/考勤/出款/运营等管理权限",
		Permissions: DefaultOperatorPermissions,
		ExactSync:   true,
	},
	{
		Name:        "审计员",
		Description: "助理：以查看为主，考勤与出款可编辑",
		Permissions: DefaultAuditorPermissions,
		ExactSync:   true,
	},
	{
		Name:        "查看员",
		Description: "只读：工资、出款统计、考勤",
		Permissions: DefaultViewerPermissions,
		ExactSync:   true,
	},
}

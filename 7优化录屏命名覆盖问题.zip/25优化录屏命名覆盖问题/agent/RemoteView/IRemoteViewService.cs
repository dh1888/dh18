namespace EnterpriseAgent.Agent.RemoteView;

public sealed class RemoteHealthStatus
{
    public bool IsPublishing { get; init; }
    public bool ProcessAlive { get; init; }
    public bool FrameRecent { get; init; }
    public double FrameAgeSeconds { get; init; }
    public int RestartCount { get; init; }
    public string? SessionId { get; init; }
    public string? LastError { get; init; }
}

public interface IRemoteViewService
{
    bool IsPublishing { get; }
    string? ActiveSessionId { get; }
    RemoteViewStats GetStats();
    RemoteHealthStatus GetHealth();
    Task StartAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default);
    Task StopAsync(CancellationToken cancellationToken = default);
    Task ReconnectAsync(string reason, CancellationToken cancellationToken = default);
    string? TakePendingTransportError();
    /// <summary>Consumes and clears the user-initiated stop flag (used to suppress PublishFailed storms).</summary>
    bool TakeUserInitiatedStop();

    event Func<string?, string, Task>? PublishFailed;
}

using System.Diagnostics;
using System.Text;
using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Security;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EnterpriseAgent.Agent.RemoteView;

/// <summary>
/// Independent remote view publishing service (FFmpeg gdigrab or shared bridge → RTMP → LiveKit Ingress).
/// </summary>
public sealed class RemoteViewService : IRemoteViewService, IRemoteViewPublisher, IDisposable
{
    private static readonly TimeSpan SharedBridgeReadyTimeout = TimeSpan.FromSeconds(20);
    private static readonly TimeSpan RtmpReadyTimeout = TimeSpan.FromSeconds(15);

    private readonly ILogger<RemoteViewService> _logger;
    private readonly RemoteViewConfig _config;
    private readonly ICaptureCoordinator _captureCoordinator;
    private readonly object _gate = new();
    private Process? _ffmpegProcess;
    private RemoteViewStartParams? _activeParams;
    private string _encoder = "libx264";
    private string? _cachedProbeEncoder;
    private int _cachedProbeWidth;
    private int _cachedProbeHeight;
    private int _cachedProbeFps;
    private int _frameCount;
    private DateTime _statsSinceUtc = DateTime.UtcNow;
    private DateTime _lastFrameUtc = DateTime.MinValue;
    private int _restartCount;
    private string? _lastError;
    private string? _pendingTransportError;
    private bool _disposed;
    private readonly List<string> _recentStderr = new();
    private readonly object _stderrLock = new();
    private TaskCompletionSource? _firstFrameTcs;
    private volatile bool _userInitiatedStop;
    private int _processEpoch;

    public RemoteViewService(
        ILogger<RemoteViewService> logger,
        IOptions<RemoteViewConfig> options,
        ICaptureCoordinator captureCoordinator)
    {
        _logger = logger;
        _config = options.Value;
        _captureCoordinator = captureCoordinator;
    }

    public event Func<string?, string, Task>? PublishFailed;

    public bool IsPublishing
    {
        get
        {
            lock (_gate)
            {
                return _ffmpegProcess is { HasExited: false };
            }
        }
    }

    public string? ActiveSessionId
    {
        get
        {
            lock (_gate)
            {
                return _activeParams?.SessionId;
            }
        }
    }

    public RemoteViewStats GetStats()
    {
        lock (_gate)
        {
            var elapsed = Math.Max((DateTime.UtcNow - _statsSinceUtc).TotalSeconds, 1);
            var measuredFps = (int)Math.Round(_frameCount / elapsed);
            var configuredFps = _activeParams?.Fps ?? _config.TargetFps;

            return new RemoteViewStats
            {
                Fps = measuredFps > 0 ? measuredFps : configuredFps,
                BitrateKbps = _config.VideoBitrateKbps,
                Encoder = _encoder,
                IsPublishing = IsPublishing,
                SessionId = _activeParams?.SessionId,
            };
        }
    }

    public RemoteHealthStatus GetHealth()
    {
        lock (_gate)
        {
            var frameAge = _lastFrameUtc == DateTime.MinValue
                ? double.MaxValue
                : (DateTime.UtcNow - _lastFrameUtc).TotalSeconds;

            return new RemoteHealthStatus
            {
                IsPublishing = IsPublishing,
                ProcessAlive = IsPublishing,
                FrameRecent = frameAge < 30,
                FrameAgeSeconds = frameAge,
                RestartCount = _restartCount,
                SessionId = _activeParams?.SessionId,
                LastError = _lastError,
            };
        }
    }

    public bool TakeUserInitiatedStop()
    {
        lock (_gate)
        {
            if (!_userInitiatedStop)
                return false;
            _userInitiatedStop = false;
            return true;
        }
    }

    public async Task StartAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(parameters);
        if (string.IsNullOrWhiteSpace(parameters.RtmpUrl))
            throw new InvalidOperationException("RTMP URL is required");

        _userInitiatedStop = false;
        await StopInternalAsync(notifyFailed: false, userInitiated: false, cancellationToken);
        _restartCount = 0;
        _lastError = null;
        await LaunchInternalAsync(parameters, cancellationToken);
    }

    public Task StopAsync(CancellationToken cancellationToken = default) =>
        StopInternalAsync(notifyFailed: false, userInitiated: true, cancellationToken);

    public string? TakePendingTransportError()
    {
        lock (_gate)
        {
            var error = _pendingTransportError;
            _pendingTransportError = null;
            return error;
        }
    }

    public async Task ReconnectAsync(string reason, CancellationToken cancellationToken = default)
    {
        RemoteViewStartParams? parameters;
        lock (_gate)
        {
            parameters = _activeParams;
        }

        if (parameters == null)
            return;

        var maxRestarts = Math.Max(1, _config.RtmpMaxRestartsPerSession);
        if (_restartCount >= maxRestarts)
        {
            _lastError = $"RTMP unstable after {maxRestarts} retries: {reason}";
            _logger.LogError(
                "Remote view exceeded max restarts ({Max}) session={SessionId} reason={Reason}",
                maxRestarts, parameters.SessionId, reason);
            await StopInternalAsync(notifyFailed: true, userInitiated: false, cancellationToken);
            await RaisePublishFailedAsync(parameters.SessionId, _lastError);
            return;
        }

        _restartCount++;
        var delay = Math.Min(600 + _restartCount * 300, 3000);
        _logger.LogInformation(
            "Remote view reconnect in {Delay}ms attempt={Count}/{Max} reason={Reason}",
            delay, _restartCount, maxRestarts, reason);

        await Task.Delay(delay, cancellationToken);
        await StopInternalAsync(notifyFailed: false, userInitiated: false, cancellationToken);
        await Task.Delay(Math.Max(_config.IngressWarmupMs / 2, 400), cancellationToken);

        if (_captureCoordinator.IsSharedCaptureActive)
        {
            var health = _captureCoordinator.GetSharedBridgeHealth();
            if (!health.RemotePipeConnected)
                await _captureCoordinator.ReconnectSharedBridgeConsumerAsync(CaptureConsumer.RemoteView, cancellationToken);
        }

        try
        {
            await LaunchInternalAsync(parameters, cancellationToken);
        }
        catch (Exception ex)
        {
            _lastError = ex.Message;
            _logger.LogWarning(ex, "Remote view reconnect failed session={SessionId}", parameters.SessionId);
            if (_restartCount >= maxRestarts)
                await RaisePublishFailedAsync(parameters.SessionId, _lastError);
        }
    }

    Task IRemoteViewPublisher.StartPublishAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken) =>
        StartAsync(parameters, cancellationToken);

    Task IRemoteViewPublisher.StopPublishAsync(CancellationToken cancellationToken) =>
        StopAsync(cancellationToken);

    private async Task LaunchInternalAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken)
    {
        var ffmpeg = FindFfmpeg();
        if (string.IsNullOrWhiteSpace(ffmpeg))
            throw new InvalidOperationException("ffmpeg.exe not found");

        await _captureCoordinator.NotifyConsumerStartingAsync(CaptureConsumer.RemoteView, cancellationToken);
        var profile = _captureCoordinator.GetProfile();

        var width = parameters.Width > 0 ? parameters.Width : profile.RemoteWidth;
        var height = parameters.Height > 0 ? parameters.Height : profile.RemoteHeight;
        var fps = parameters.Fps > 0 ? parameters.Fps : profile.RemoteFps;
        var bitrate = _config.VideoBitrateKbps;
        _encoder = await DetectEncoderAsync(ffmpeg, width, height, fps, bitrate, cancellationToken);
        var args = BuildFfmpegArgs(profile, _encoder, width, height, fps, bitrate, parameters.RtmpUrl);

        lock (_stderrLock)
            _recentStderr.Clear();

        _firstFrameTcs = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

        _logger.LogInformation(
            "Starting remote view session={SessionId} mode={Mode} encoder={Encoder} {Width}x{Height}@{Fps}",
            parameters.SessionId, profile.Mode, _encoder, width, height, fps);
        _logger.LogInformation("Remote view FFmpeg args: {Args}", SensitiveDataFilter.FilterStatic(args));

        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = ffmpeg,
                Arguments = args,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true,
            },
            EnableRaisingEvents = true,
        };

        process.ErrorDataReceived += (_, e) => HandleStderrLine(e.Data);

        _frameCount = 0;
        _statsSinceUtc = DateTime.UtcNow;
        _lastFrameUtc = DateTime.UtcNow;

        if (!process.Start())
            throw new InvalidOperationException("Failed to start ffmpeg process");

        process.BeginErrorReadLine();

        lock (_gate)
        {
            _ffmpegProcess = process;
            _activeParams = parameters;
        }

        var processEpoch = Volatile.Read(ref _processEpoch);

        await (profile.Mode == CaptureMode.SharedBridge && _captureCoordinator.IsSharedBridgeOrchestrated
            ? Task.CompletedTask
            : profile.Mode == CaptureMode.SharedBridge
                ? WaitForSharedBridgeReadyAsync(process, cancellationToken)
                : WaitForRtmpReadyAsync(process, cancellationToken));

        _ = Task.Run(async () =>
        {
            string? sessionId;
            lock (_gate)
            {
                sessionId = _activeParams?.SessionId;
            }

            try
            {
                await process.WaitForExitAsync(CancellationToken.None);
                if (processEpoch != Volatile.Read(ref _processEpoch))
                    return;

                if (process.ExitCode != 0)
                {
                    var detail = $"ffmpeg exited with code {process.ExitCode}";
                    _lastError = detail;
                    _logger.LogWarning("Remote view FFmpeg exited with code {Code}", process.ExitCode);
                    await RaisePublishFailedAsync(sessionId, detail);
                }
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Remote view exit watcher ended");
            }
            finally
            {
                lock (_gate)
                {
                    if (ReferenceEquals(_ffmpegProcess, process))
                    {
                        _ffmpegProcess = null;
                    }
                }
            }
        }, CancellationToken.None);
    }

    private void HandleStderrLine(string? line)
    {
        if (string.IsNullOrWhiteSpace(line))
            return;

        lock (_stderrLock)
        {
            _recentStderr.Add(line);
            if (_recentStderr.Count > 12)
                _recentStderr.RemoveAt(0);
        }

        if (line.Contains("frame=", StringComparison.Ordinal))
        {
            Interlocked.Increment(ref _frameCount);
            _lastFrameUtc = DateTime.UtcNow;
            var sharedBridge = _captureCoordinator.GetProfile().Mode == CaptureMode.SharedBridge;
            if (_frameCount == 1 || (sharedBridge && _captureCoordinator.NeedsConsumerFirstFrame(CaptureConsumer.RemoteView)))
            {
                _firstFrameTcs?.TrySetResult();
                if (sharedBridge)
                    _captureCoordinator.NotifyConsumerFirstFrame(CaptureConsumer.RemoteView);
            }
            if (_restartCount > 0)
            {
                _restartCount = 0;
                _logger.LogDebug("Remote view stable, restart counter reset");
            }
        }

        if (IsRtmpTransportError(line))
        {
            var filtered = SensitiveDataFilter.FilterStatic(line);
            _logger.LogWarning("RTMP transport error: {Line}", filtered);
            lock (_gate)
            {
                _pendingTransportError = filtered;
            }
        }
        else if (line.Contains("error", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogWarning("Remote FFmpeg: {Line}", SensitiveDataFilter.FilterStatic(line));
        }
    }

    private string GetRecentStderrSummary()
    {
        lock (_stderrLock)
        {
            if (_recentStderr.Count == 0)
                return "";

            return string.Join(" | ", _recentStderr.Select(SensitiveDataFilter.FilterStatic));
        }
    }

    private async Task StopInternalAsync(bool notifyFailed, bool userInitiated, CancellationToken cancellationToken)
    {
        Process? process;
        RemoteViewStartParams? parameters;
        lock (_gate)
        {
            process = _ffmpegProcess;
            parameters = _activeParams;
            _ffmpegProcess = null;
            if (!notifyFailed)
            {
                _activeParams = null;
                if (userInitiated)
                    _userInitiatedStop = true;
            }
        }

        if (process != null)
            Interlocked.Increment(ref _processEpoch);

        if (process != null)
        {
            try
            {
                if (!process.HasExited)
                {
                    if (!process.WaitForExit(3000))
                        process.Kill(entireProcessTree: true);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to stop remote view FFmpeg");
            }
            finally
            {
                process.Dispose();
            }
        }

        if (parameters != null || notifyFailed)
            await _captureCoordinator.NotifyConsumerStoppingAsync(CaptureConsumer.RemoteView, cancellationToken);
    }

    private async Task WaitForSharedBridgeReadyAsync(Process process, CancellationToken cancellationToken)
    {
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(SharedBridgeReadyTimeout);

        try
        {
            if (_firstFrameTcs != null)
                await _firstFrameTcs.Task.WaitAsync(timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            if (process.HasExited)
            {
                var detail = GetRecentStderrSummary();
                throw new InvalidOperationException(
                    string.IsNullOrWhiteSpace(detail)
                        ? $"Remote SharedBridge encoder exited with code {process.ExitCode}"
                        : $"Remote SharedBridge encoder exited: {detail}");
            }

            throw new TimeoutException("Timed out waiting for remote SharedBridge first frame");
        }

        if (process.HasExited)
            throw new InvalidOperationException($"Remote SharedBridge encoder exited with code {process.ExitCode}");
    }

    private async Task WaitForRtmpReadyAsync(Process process, CancellationToken cancellationToken)
    {
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(RtmpReadyTimeout);

        try
        {
            if (_firstFrameTcs != null)
                await _firstFrameTcs.Task.WaitAsync(timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            if (process.HasExited)
            {
                var detail = GetRecentStderrSummary();
                throw new InvalidOperationException(
                    string.IsNullOrWhiteSpace(detail)
                        ? $"Remote RTMP encoder exited with code {process.ExitCode}"
                        : $"Remote RTMP encoder exited: {detail}");
            }

            throw new TimeoutException("Timed out waiting for remote RTMP first frame");
        }

        if (process.HasExited)
            throw new InvalidOperationException($"Remote RTMP encoder exited with code {process.ExitCode}");
    }

    private async Task RaisePublishFailedAsync(string? sessionId, string detail)
    {
        lock (_gate)
        {
            if (_userInitiatedStop)
            {
                _logger.LogDebug("Suppressing PublishFailed after user-initiated stop: {Detail}", detail);
                return;
            }
        }

        var handler = PublishFailed;
        if (handler == null)
            return;

        try
        {
            await handler(sessionId, detail);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "PublishFailed handler error");
        }
    }

    private static string BuildFfmpegArgs(
        CaptureProfile profile,
        string encoder,
        int width,
        int height,
        int fps,
        int bitrateKbps,
        string rtmpUrl)
    {
        var gop = Math.Max(fps, 10);
        var encoderArgs = encoder switch
        {
            "h264_nvenc" => $"-c:v h264_nvenc -preset p4 -profile:v baseline -rc cbr -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bitrateKbps * 2}k",
            "h264_qsv" => $"-c:v h264_qsv -profile:v baseline -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bitrateKbps * 2}k",
            "h264_amf" => $"-c:v h264_amf -profile:v baseline -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bitrateKbps * 2}k",
            _ => $"-c:v libx264 -preset veryfast -tune zerolatency -profile:v baseline -b:v {bitrateKbps}k -maxrate {bitrateKbps}k -bufsize {bitrateKbps * 2}k",
        };

        var sb = new StringBuilder();
        sb.Append("-hide_banner -loglevel warning -progress pipe:2 -nostats ");

        if (profile.Mode == CaptureMode.SharedBridge && !string.IsNullOrWhiteSpace(profile.RemoteInputArgs))
        {
            sb.Append(profile.RemoteInputArgs).Append(' ');
            if (width != profile.RemoteWidth || height != profile.RemoteHeight)
                sb.Append($"-vf \"scale={width}:{height}\" ");
        }
        else
        {
            sb.Append($"-f gdigrab -framerate {fps} -i desktop ");
            sb.Append($"-vf \"fps={fps},scale={width}:{height}:force_original_aspect_ratio=decrease," +
                      $"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2\" ");
        }

        sb.Append(encoderArgs).Append(' ');
        sb.Append($"-pix_fmt yuv420p -g {gop} -keyint_min {gop} ");
        sb.Append("-f flv -flvflags no_duration_filesize -flush_packets 1 ");
        sb.Append('"').Append(rtmpUrl.Replace("\"", "\\\"")).Append('"');
        return sb.ToString();
    }

    private static bool IsRtmpTransportError(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return false;

        if (text.Contains("Error submitting a packet to the muxer", StringComparison.OrdinalIgnoreCase))
            return true;
        if (text.Contains("-10053", StringComparison.Ordinal) || text.Contains("-10054", StringComparison.Ordinal))
            return true;
        if (text.Contains("Error opening output", StringComparison.OrdinalIgnoreCase))
            return true;
        return text.Contains("I/O error", StringComparison.OrdinalIgnoreCase) &&
               text.Contains("rtmp", StringComparison.OrdinalIgnoreCase);
    }

    private static string? FindFfmpeg()
    {
        var paths = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "ffmpeg.exe"),
            Path.Combine(AppContext.BaseDirectory, "bin", "ffmpeg.exe"),
            @"C:\ffmpeg\bin\ffmpeg.exe",
        };

        foreach (var path in paths)
        {
            if (File.Exists(path))
                return path;
        }

        return null;
    }

    private async Task<string> DetectEncoderAsync(
        string ffmpeg,
        int width,
        int height,
        int fps,
        int bitrateKbps,
        CancellationToken cancellationToken)
    {
        if (_cachedProbeEncoder != null
            && _cachedProbeWidth == width
            && _cachedProbeHeight == height
            && _cachedProbeFps == fps
            && await ProbeEncoderAsync(ffmpeg, _cachedProbeEncoder, width, height, fps, bitrateKbps, cancellationToken))
        {
            _logger.LogDebug("Remote view encoder cache hit: {Encoder}", _cachedProbeEncoder);
            return _cachedProbeEncoder;
        }

        foreach (var encoder in new[] { "h264_nvenc", "h264_qsv", "h264_amf", "libx264" })
        {
            if (await ProbeEncoderAsync(ffmpeg, encoder, width, height, fps, bitrateKbps, cancellationToken))
            {
                _logger.LogInformation("Remote view encoder probe passed: {Encoder}", encoder);
                CacheProbeEncoder(encoder, width, height, fps);
                return encoder;
            }

            _logger.LogWarning("Remote view encoder probe failed: {Encoder}", encoder);
        }

        CacheProbeEncoder("libx264", width, height, fps);
        return "libx264";
    }

    private void CacheProbeEncoder(string encoder, int width, int height, int fps)
    {
        _cachedProbeEncoder = encoder;
        _cachedProbeWidth = width;
        _cachedProbeHeight = height;
        _cachedProbeFps = fps;
    }

    private static async Task<bool> ProbeEncoderAsync(
        string ffmpeg,
        string encoder,
        int width,
        int height,
        int fps,
        int bitrateKbps,
        CancellationToken cancellationToken)
    {
        var alignedWidth = width & ~1;
        var alignedHeight = height & ~1;
        var testOutput = Path.GetTempFileName() + ".flv";

        try
        {
            var encoderArgs = encoder switch
            {
                "h264_nvenc" => $"-c:v h264_nvenc -preset p4 -profile:v baseline -rc cbr -b:v {bitrateKbps}k",
                "h264_qsv" => $"-c:v h264_qsv -profile:v baseline -b:v {bitrateKbps}k",
                "h264_amf" => $"-c:v h264_amf -profile:v baseline -b:v {bitrateKbps}k",
                _ => $"-c:v libx264 -preset veryfast -tune zerolatency -profile:v baseline -b:v {bitrateKbps}k",
            };

            var args =
                $"-hide_banner -f lavfi -i testsrc=duration=1:size={alignedWidth}x{alignedHeight}:rate={fps} " +
                $"{encoderArgs} -pix_fmt yuv420p -t 1 -f flv -y \"{testOutput}\"";

            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffmpeg,
                    Arguments = args,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardError = true,
                },
            };

            process.Start();
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(10));
            try
            {
                await process.WaitForExitAsync(cts.Token);
            }
            catch (OperationCanceledException)
            {
                try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { }
                return false;
            }

            return process.ExitCode == 0 && File.Exists(testOutput) && new FileInfo(testOutput).Length > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            try
            {
                if (File.Exists(testOutput))
                    File.Delete(testOutput);
            }
            catch
            {
                // ignore cleanup failures
            }
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        StopAsync().GetAwaiter().GetResult();
    }
}

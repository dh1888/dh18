using System.Diagnostics;
using System.Text;
using System.Text.Json;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.Lifecycle;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EnterpriseAgent.Agent.RemoteView;

public interface IRemoteViewPublisher
{
    bool IsPublishing { get; }
    string? ActiveSessionId { get; }
    RemoteViewStats GetStats();
    Task StartPublishAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default);
    Task StopPublishAsync(CancellationToken cancellationToken = default);
}

public sealed class RemoteViewConfig
{
    public bool Enabled { get; set; } = true;
    public int TargetWidth { get; set; } = 1280;
    public int TargetHeight { get; set; } = 720;
    public int TargetFps { get; set; } = 10;
    public int VideoBitrateKbps { get; set; } = 1500;
    /// <summary>Wait after stop / before RTMP connect so Ingress can accept a new publisher.</summary>
    public int IngressWarmupMs { get; set; } = 400;
    /// <summary>FFmpeg launch attempts when RTMP output fails to open.</summary>
    public int RtmpLaunchMaxAttempts { get; set; } = 3;
    /// <summary>Max automatic FFmpeg restarts per remote-view session before reporting failed.</summary>
    public int RtmpMaxRestartsPerSession { get; set; } = 5;
}

public sealed class RemoteViewStartParams
{
    public string SessionId { get; init; } = "";
    public string RoomName { get; init; } = "";
    public string LiveKitUrl { get; init; } = "";
    public string RtmpUrl { get; init; } = "";
    public int Width { get; init; } = 1920;
    public int Height { get; init; } = 1080;
    public int Fps { get; init; } = 15;
}

public sealed class RemoteViewStats
{
    public int Fps { get; set; }
    public int BitrateKbps { get; set; }
    public string Encoder { get; set; } = "libx264";
    public bool IsPublishing { get; set; }
    public string? SessionId { get; set; }
}

/// <summary>
/// 远程查看：录屏与推流分离（双进程架构），经 LifecycleCoordinator 编排。
/// </summary>
public sealed class CompositeRemoteViewPublisher : IRemoteViewPublisher, IDisposable
{
    private readonly ILifecycleCoordinator _lifecycle;
    private readonly IRemoteViewService _remoteView;
    private readonly ILogger<CompositeRemoteViewPublisher> _logger;
    private bool _disposed;

    public event Func<string?, string, Task>? PublishFailed;

    public CompositeRemoteViewPublisher(
        ILifecycleCoordinator lifecycle,
        IRemoteViewService remoteView,
        ILogger<CompositeRemoteViewPublisher> logger)
    {
        _lifecycle = lifecycle;
        _remoteView = remoteView;
        _logger = logger;
        _lifecycle.RemoteViewPublishFailed += OnRecorderRemoteFailedAsync;
    }

    public bool IsPublishing => _lifecycle.IsRemoteActive;

    public string? ActiveSessionId => _remoteView.ActiveSessionId;

    public RemoteViewStats GetStats() => _remoteView.GetStats();

    public async Task StartPublishAsync(RemoteViewStartParams parameters, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation(
            "Starting remote view via recorder lifecycle session={SessionId}",
            parameters.SessionId);

        var result = await _lifecycle.RequestAsync(
            RecorderCommand.EnterRemoteView,
            new RecorderRequestContext { RemoteView = parameters, Reason = "RemoteViewSession" },
            cancellationToken);

        if (!result.Success)
            throw new InvalidOperationException(result.Message ?? "EnterRemoteView failed");
    }

    public async Task StopPublishAsync(CancellationToken cancellationToken = default)
    {
        await _lifecycle.RequestAsync(
            RecorderCommand.ExitRemoteView,
            new RecorderRequestContext { Reason = "RemoteViewSession stop" },
            cancellationToken);
    }

    private Task OnRecorderRemoteFailedAsync(string? sessionId, string detail)
    {
        PublishFailed?.Invoke(sessionId, detail);
        return Task.CompletedTask;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _lifecycle.RemoteViewPublishFailed -= OnRecorderRemoteFailedAsync;
        StopPublishAsync().GetAwaiter().GetResult();
    }
}

public sealed class RemoteViewSessionController
{
    private readonly ILogger<RemoteViewSessionController> _logger;
    private readonly IRemoteViewPublisher _publisher;
    private readonly RemoteViewConfig _config;
    private readonly IServiceProvider _serviceProvider;
    private readonly SemaphoreSlim _sessionLock = new(1, 1);
    private readonly TimeSpan _statsInterval = TimeSpan.FromSeconds(5);
    private CancellationTokenSource? _statsCts;
    private Task? _statsTask;

    public RemoteViewSessionController(
        ILogger<RemoteViewSessionController> logger,
        IRemoteViewPublisher publisher,
        IOptions<RemoteViewConfig> options,
        IServiceProvider serviceProvider)
    {
        _logger = logger;
        _publisher = publisher;
        _config = options.Value;
        _serviceProvider = serviceProvider;

        if (publisher is CompositeRemoteViewPublisher compositePublisher)
        {
            compositePublisher.PublishFailed += OnPublishFailedAsync;
        }
    }

    public async Task HandleStartAsync(JsonElement paramsElement, CancellationToken cancellationToken = default)
    {
        if (!_config.Enabled)
        {
            _logger.LogInformation("Remote view is disabled by configuration");
            return;
        }

        await _sessionLock.WaitAsync(cancellationToken);
        try
        {
            var startParams = ParseStartParams(paramsElement);
            if (string.IsNullOrWhiteSpace(startParams.RtmpUrl))
            {
                await SendEventAsync(startParams.SessionId, "failed", "RTMP URL is missing");
                return;
            }

            if (_publisher.IsPublishing)
            {
                var activeId = _publisher.ActiveSessionId;
                if (string.Equals(activeId, startParams.SessionId, StringComparison.OrdinalIgnoreCase))
                {
                    _logger.LogInformation("Remote view already active for session {SessionId}", startParams.SessionId);
                    await SendEventAsync(startParams.SessionId, "published");
                    return;
                }

                _logger.LogInformation(
                    "Replacing remote view session {Old} -> {New}",
                    activeId, startParams.SessionId);
                await _publisher.StopPublishAsync(cancellationToken);
                var cooldownMs = Math.Max(_config.IngressWarmupMs, 300);
                await Task.Delay(cooldownMs, cancellationToken);
            }
            else if (_config.IngressWarmupMs > 0)
            {
                await Task.Delay(_config.IngressWarmupMs, cancellationToken);
            }

            try
            {
                await _publisher.StartPublishAsync(startParams, cancellationToken);
                await SendEventAsync(startParams.SessionId, "published");
                StartStatsLoop();
                _logger.LogInformation("Remote view publishing started for session {SessionId}", startParams.SessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to start remote view for session {SessionId}", startParams.SessionId);
                try
                {
                    await _publisher.StopPublishAsync(cancellationToken);
                }
                catch (Exception stopEx)
                {
                    _logger.LogWarning(stopEx, "Cleanup stop failed after remote view start error");
                }
                await SendEventAsync(startParams.SessionId, "failed", ex.Message);
            }
        }
        finally
        {
            _sessionLock.Release();
        }
    }

    public async Task HandleStopAsync(JsonElement paramsElement = default, CancellationToken cancellationToken = default)
    {
        await _sessionLock.WaitAsync(cancellationToken);
        try
        {
            await HandleStopCoreAsync(paramsElement, cancellationToken);
            var cooldownMs = Math.Max(_config.IngressWarmupMs, 500);
            if (cooldownMs > 0)
                await Task.Delay(cooldownMs, cancellationToken);
        }
        finally
        {
            _sessionLock.Release();
        }
    }

    private async Task HandleStopCoreAsync(JsonElement paramsElement, CancellationToken cancellationToken)
    {
        string? requestedSessionId = null;
        if (paramsElement.ValueKind == JsonValueKind.Object &&
            paramsElement.TryGetProperty("sessionId", out var sidProp))
        {
            requestedSessionId = sidProp.GetString();
        }

        var activeSessionId = _publisher.ActiveSessionId;
        if (!string.IsNullOrWhiteSpace(requestedSessionId) &&
            !string.IsNullOrWhiteSpace(activeSessionId) &&
            !string.Equals(requestedSessionId, activeSessionId, StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogInformation(
                "Ignoring stop for session {Requested} (active {Active})",
                requestedSessionId, activeSessionId);
            return;
        }

        var sessionId = activeSessionId ?? requestedSessionId;
        StopStatsLoop();
        await _publisher.StopPublishAsync(cancellationToken);
        await SendEventAsync(sessionId, "stopped");
        _logger.LogInformation("Remote view publishing stopped");
    }

    private async Task OnPublishFailedAsync(string? sessionId, string detail)
    {
        StopStatsLoop();
        await SendEventAsync(sessionId, "failed", detail);
    }

    private RemoteViewStartParams ParseStartParams(JsonElement element)
    {
        string GetString(string name) =>
            element.TryGetProperty(name, out var prop) ? prop.GetString() ?? "" : "";

        int GetInt(string name, int fallback) =>
            element.TryGetProperty(name, out var prop) && prop.TryGetInt32(out var value) ? value : fallback;

        return new RemoteViewStartParams
        {
            SessionId = GetString("sessionId"),
            RoomName = GetString("roomName"),
            LiveKitUrl = GetString("livekitUrl"),
            RtmpUrl = GetString("rtmpUrl"),
            Width = GetInt("width", 1280),
            Height = GetInt("height", 720),
            Fps = GetInt("fps", 10),
        };
    }

    private void StartStatsLoop()
    {
        StopStatsLoop();
        _statsCts = new CancellationTokenSource();
        var token = _statsCts.Token;
        _statsTask = Task.Run(async () =>
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    if (_publisher.IsPublishing)
                    {
                        var stats = _publisher.GetStats();
                        await SendStatsAsync(stats, token);
                    }
                    await Task.Delay(_statsInterval, token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogDebug(ex, "Remote view stats loop error");
                }
            }
        }, token);
    }

    private void StopStatsLoop()
    {
        try
        {
            _statsCts?.Cancel();
        }
        catch
        {
            // ignore
        }
        finally
        {
            _statsCts?.Dispose();
            _statsCts = null;
            _statsTask = null;
        }
    }

    private Task SendStatsAsync(RemoteViewStats stats, CancellationToken cancellationToken)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "remote_view_stats",
            sessionId = stats.SessionId,
            fps = stats.Fps,
            bitrateKbps = stats.BitrateKbps,
            encoder = stats.Encoder,
        });
        return GetWebSocketService().SendMessageAsync(payload, cancellationToken);
    }

    private Task SendEventAsync(string? sessionId, string eventName, string? detail = null)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "remote_view_event",
            sessionId,
            @event = eventName,
            detail,
        });
        return GetWebSocketService().SendMessageAsync(payload);
    }

    private Services.WebSocketService GetWebSocketService() =>
        _serviceProvider.GetRequiredService<Services.WebSocketService>();
}


using EnterpriseAgent.Agent.Recorder;
using Xunit;

namespace EnterpriseAgent.Agent.Recorder.Tests;

/// <summary>
/// Recorder SSOT 状态机单元测试（验收矩阵中可静态验证的部分）。
/// </summary>
public sealed class RecorderStateMachineTests
{
    [Theory]
    [InlineData(true, true, false, false, false, RecorderState.Recording)]
    [InlineData(true, true, false, false, true, RecorderState.RecordingAndRemote)]
    [InlineData(false, false, false, false, true, RecorderState.StandaloneRemote)]
    [InlineData(false, false, false, false, false, RecorderState.Idle)]
    public void Derive_MapsInputsToExpectedState(
        bool workSession,
        bool recordingEnabled,
        bool unifiedRemote,
        bool remoteOnly,
        bool standaloneRemote,
        RecorderState expected)
    {
        var state = RecorderStateMachine.Derive(
            workSession,
            recordingEnabled,
            unifiedRemote,
            remoteOnly,
            standaloneRemote);

        Assert.Equal(expected, state);
    }

    [Fact]
    public void ResolveRecoverCommand_RoutesRemoteStatesToReconnectRemote()
    {
        Assert.Equal(
            RecorderCommand.ReconnectRemote,
            RecorderStateMachine.ResolveRecoverCommand(RecorderState.RecordingAndRemote));
        Assert.Equal(
            RecorderCommand.ReconnectRemote,
            RecorderStateMachine.ResolveRecoverCommand(RecorderState.StandaloneRemote));
    }

    [Fact]
    public void ResolveRecoverCommand_RoutesRecordingOnlyToRecoverCapture()
    {
        Assert.Equal(
            RecorderCommand.RecoverCapture,
            RecorderStateMachine.ResolveRecoverCommand(RecorderState.Recording));
        Assert.Equal(
            RecorderCommand.RecoverCapture,
            RecorderStateMachine.ResolveRecoverCommand(RecorderState.Idle));
    }

    [Theory]
    [InlineData(RecorderState.RecordingAndRemote)]
    [InlineData(RecorderState.StandaloneRemote)]
    [InlineData(RecorderState.Transitioning)]
    public void ShouldQueuePolicyChange_WhenRemoteOrTransitioning(RecorderState state)
    {
        Assert.True(RecorderStateMachine.ShouldQueuePolicyChange(state));
    }

    [Fact]
    public void AllowsFullEngineRestart_OnlyWhenNotRemoteUnified()
    {
        Assert.True(RecorderStateMachine.AllowsFullEngineRestart(RecorderState.Idle));
        Assert.True(RecorderStateMachine.AllowsFullEngineRestart(RecorderState.Recording));
        Assert.False(RecorderStateMachine.AllowsFullEngineRestart(RecorderState.RecordingAndRemote));
        Assert.False(RecorderStateMachine.AllowsFullEngineRestart(RecorderState.StandaloneRemote));
    }
}

using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Recorder;

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.RecordingServices;

public interface IRecordingService
{
    bool IsRunning { get; }
    bool WorkSessionActive { get; }
    string? OutputPattern { get; }
    RecordingHealthSnapshot GetHealthSnapshot(RecorderState state, bool remoteViewActive);
    void SetWorkSessionActive(bool active);
    void UpdatePolicy(AgentPolicy policy);
    /// <summary>Starts recording; returns false if start did not launch FFmpeg.</summary>
    Task<bool> TryStartAsync(CancellationToken cancellationToken = default);
    /// <summary>Waits until recording process/lock is idle (orchestrator transitions).</summary>
    Task WaitUntilQuiescentAsync(CancellationToken cancellationToken = default);
    Task StopAsync(bool fullShutdown = true, bool fastTransition = false, CancellationToken cancellationToken = default);
    Task RestartAsync(string reason, CancellationToken cancellationToken = default);
    /// <summary>Restores gdigrab recording after SharedBridge teardown without RestartAsync delays.</summary>
    Task<bool> RestoreGdigrabCaptureAsync(CancellationToken cancellationToken = default);
    /// <summary>Health recovery — only invoked by Lifecycle orchestrator.</summary>
    Task<bool> RecoverForHealthAsync(string reason, CancellationToken cancellationToken = default);
    void RestoreOutputPattern(string? pattern);
}

using System.Runtime.Versioning;
using System.Security.Cryptography;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Services;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.RecordingServices;

/// <summary>
/// Indexes completed recording segments, persists metadata, and dispatches upload queue entries.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class RecordingIndexer : BackgroundService
{
    private readonly ILogger<RecordingIndexer> _logger;
    private readonly AgentConfig _config;
    private readonly IServiceScopeFactory _scopeFactory;
    private static int _isIndexing;

    public RecordingIndexer(
        ILogger<RecordingIndexer> logger,
        AgentConfig config,
        IServiceScopeFactory scopeFactory)
    {
        _logger = logger;
        _config = config;
        _scopeFactory = scopeFactory;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Recording indexer started");
        await IndexRecordingsAsync(stoppingToken);
    }

    private async Task IndexRecordingsAsync(CancellationToken ct)
    {
        if (Interlocked.Exchange(ref _isIndexing, 1) == 1)
        {
            _logger.LogDebug("Indexing already in progress, skipping");
            return;
        }

        try
        {
            var indexedFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            while (!ct.IsCancellationRequested)
            {
                try
                {
                    var recordingsPath = Path.Combine(_config.GetEffectiveStoragePath(), "recordings");

                    if (!Directory.Exists(recordingsPath))
                    {
                        await Task.Delay(5000, ct);
                        continue;
                    }

                    var files = Directory.EnumerateFiles(recordingsPath, "*.mp4", SearchOption.AllDirectories)
                        .Select(path => new FileInfo(path))
                        .OrderBy(f => f.LastWriteTimeUtc)
                        .ToList();

                    if (files.Count > 0)
                    {
                        _logger.LogInformation("Indexing {Count} recording files", files.Count);
                        _logger.LogDebug("Recordings path: {Path}", recordingsPath);
                    }

                    foreach (var file in files)
                    {
                        ct.ThrowIfCancellationRequested();

                        if (file.Length <= Constants.MinRecordingFileBytes)
                            continue;

                        if (indexedFiles.Contains(file.FullName))
                            continue;

                        var existing = await GetRecordingByFilePathAsync(file.FullName);
                        if (existing != null)
                        {
                            if (existing.FileSize > Constants.MinRecordingFileBytes)
                            {
                                indexedFiles.Add(file.FullName);
                                continue;
                            }

                            if (!await IsFileReadyAsync(file.FullName, ct))
                                continue;

                            var refreshed = ParseRecordingFromFile(file.FullName);
                            if (refreshed == null)
                                continue;

                            refreshed.FileSize = file.Length;
                            refreshed.Sha256 = await ComputeSha256Async(file.FullName, ct);
                            await UpdateRecordingMetadataAsync(
                                existing.Id,
                                refreshed.FileSize,
                                refreshed.Sha256,
                                refreshed.StartTime,
                                refreshed.EndTime);
                            indexedFiles.Add(file.FullName);
                            continue;
                        }

                        if (!await IsFileReadyAsync(file.FullName, ct))
                            continue;

                        var recording = ParseRecordingFromFile(file.FullName);
                        if (recording == null)
                            continue;

                        recording.FileSize = file.Length;
                        recording.Sha256 = await ComputeSha256Async(file.FullName, ct);
                        await AddRecordingAsync(recording);
                        if (ShouldAutoUploadOnIndex())
                            await QueueRecordingForUploadAsync(recording, ct);
                        indexedFiles.Add(file.FullName);

                        _logger.LogInformation(
                            "Indexed recording: {FileName}",
                            Path.GetFileName(file.FullName));
                    }

                    if (indexedFiles.Count > 10000)
                        indexedFiles.Clear();
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Recording indexer failed");
                    await Task.Delay(5000, ct);
                }

                await Task.Delay(10000, ct);
            }
        }
        finally
        {
            Interlocked.Exchange(ref _isIndexing, 0);
        }
    }

    private Policy? GetCurrentPolicy()
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            return scope.ServiceProvider.GetService<PolicySyncService>()?.GetCurrentPolicy();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to resolve current policy for indexing");
            return null;
        }
    }

    private bool ShouldAutoUploadOnIndex()
    {
        var policy = GetCurrentPolicy();
        if (policy == null)
            return false;

        var recordingConfig = policy.GetRecordingConfig();
        if (!recordingConfig.AutoUploadOnIndex)
            return false;

        return policy.GetUploadConfig().Enabled;
    }

    private async Task QueueRecordingForUploadAsync(Recording recording, CancellationToken ct)
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var uploader = scope.ServiceProvider.GetRequiredService<FileUploadService>();

            var queueItem = new UploadQueue
            {
                Id = Guid.NewGuid().ToString(),
                FilePath = recording.FilePath,
                FileType = "recording",
                FileId = recording.Id,
                Status = "pending",
                Offset = 0,
                RetryCount = 0,
                CreatedAt = DateTime.UtcNow,
                RecordStartTime = recording.StartTime,
                RecordEndTime = recording.EndTime,
            };

            await uploader.QueueFileWithTimeAsync(queueItem);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to queue recording for upload: {FilePath}", recording.FilePath);
        }
    }

    private Recording? ParseRecordingFromFile(string file)
    {
        var sliceSeconds = GetCurrentPolicy()?.GetRecordingConfig().GetSliceSeconds()
            ?? new RecordingConfig().GetSliceSeconds();

        if (!RecordingTimeParser.TryParse(file, sliceSeconds, out var utcStartTime, out var utcEndTime))
            return null;

        return new Recording
        {
            DeviceId = _config.DeviceId,
            StartTime = utcStartTime,
            EndTime = utcEndTime,
            FilePath = file,
            Uploaded = false,
        };
    }

    private async Task AddRecordingAsync(Recording recording)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();
        await repo.AddAsync(recording);
    }

    private async Task<Recording?> GetRecordingByFilePathAsync(string filePath)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();
        return await repo.GetByFilePathAsync(filePath);
    }

    private async Task UpdateRecordingMetadataAsync(
        string id,
        long fileSize,
        string sha256,
        DateTime startTime,
        DateTime endTime)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();
        await repo.UpdateMetadataAsync(id, fileSize, sha256, startTime, endTime);
    }

    private static async Task<bool> IsFileReadyAsync(string filePath, CancellationToken ct)
    {
        const int maxAttempts = 20;
        const int delayMs = 500;
        long lastLength = -1;
        var stableReads = 0;

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            if (!File.Exists(filePath))
                return false;

            try
            {
                using var fs = File.Open(
                    filePath,
                    FileMode.Open,
                    FileAccess.Read,
                    FileShare.ReadWrite | FileShare.Delete);
                var length = fs.Length;
                if (length <= Constants.MinRecordingFileBytes)
                {
                    lastLength = length;
                    stableReads = 0;
                    await Task.Delay(delayMs, ct);
                    continue;
                }

                if (length == lastLength)
                    stableReads++;
                else
                    stableReads = 0;

                lastLength = length;
                if (stableReads >= 1)
                    return true;
            }
            catch (IOException) when (attempt < maxAttempts)
            {
                await Task.Delay(delayMs, ct);
            }
            catch (UnauthorizedAccessException) when (attempt < maxAttempts)
            {
                await Task.Delay(delayMs, ct);
            }

            await Task.Delay(delayMs, ct);
        }

        return false;
    }

    private static async Task<string> ComputeSha256Async(string path, CancellationToken ct)
    {
        const int maxAttempts = 8;
        const int delayMs = 500;

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                await using var stream = new FileStream(
                    path,
                    FileMode.Open,
                    FileAccess.Read,
                    FileShare.ReadWrite | FileShare.Delete,
                    81920,
                    true);
                var hash = await SHA256.HashDataAsync(stream, ct);
                return Convert.ToHexString(hash).ToLowerInvariant();
            }
            catch (IOException) when (attempt < maxAttempts)
            {
                await Task.Delay(delayMs, ct);
            }
            catch (UnauthorizedAccessException) when (attempt < maxAttempts)
            {
                await Task.Delay(delayMs, ct);
            }
        }

        await using var finalStream = new FileStream(
            path,
            FileMode.Open,
            FileAccess.Read,
            FileShare.ReadWrite | FileShare.Delete,
            81920,
            true);
        var finalHash = await SHA256.HashDataAsync(finalStream, ct);
        return Convert.ToHexString(finalHash).ToLowerInvariant();
    }
}

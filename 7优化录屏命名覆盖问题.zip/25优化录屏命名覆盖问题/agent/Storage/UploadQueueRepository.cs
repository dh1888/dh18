// Storage/UploadQueueRepository.cs - 优化版（支持断点续传）

using EnterpriseAgent.Agent.Models;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Storage;

public class UploadQueueRepository
{
    private readonly SqliteDbContext _db;
    private readonly ILogger<UploadQueueRepository> _logger;

    public UploadQueueRepository(SqliteDbContext db, ILogger<UploadQueueRepository> logger)
    {
        _db = db;
        _logger = logger;
    }

    /// <summary>
    /// 添加上传任务到队列
    /// </summary>
    public async Task AddAsync(UploadQueue item)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            INSERT INTO upload_queue (
                id, file_path, file_type, file_id, status, offset, 
                retry_count, error_message, upload_id, 
                record_start_time, record_end_time,   -- ✅ 新增
                last_upload_activity,
                created_at, updated_at
            ) VALUES (
                @id, @fp, @ft, @fid, @st, @off, @rc, @err, @uid,
                @record_start_time, @record_end_time, @last_upload_activity,
                @created, @updated
            )", conn);

        cmd.Parameters.AddWithValue("@id", item.Id);
        cmd.Parameters.AddWithValue("@fp", item.FilePath);
        cmd.Parameters.AddWithValue("@ft", item.FileType);
        cmd.Parameters.AddWithValue("@fid", item.FileId);
        cmd.Parameters.AddWithValue("@st", item.Status);
        cmd.Parameters.AddWithValue("@off", item.Offset);
        cmd.Parameters.AddWithValue("@rc", item.RetryCount);
        cmd.Parameters.AddWithValue("@err", item.ErrorMessage ?? "");
        cmd.Parameters.AddWithValue("@uid", item.UploadId ?? "");

        // ✅ 新增：日期时间参数
        cmd.Parameters.AddWithValue("@record_start_time",
            item.RecordStartTime?.ToIso8601String() ?? "");
        cmd.Parameters.AddWithValue("@record_end_time",
            item.RecordEndTime?.ToIso8601String() ?? "");

        cmd.Parameters.AddWithValue("@created", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@last_upload_activity", DateTime.UtcNow.ToIso8601String());

        await cmd.ExecuteNonQueryAsync();
        _logger.LogDebug("Added to upload queue: {FilePath} (Type: {FileType})",
            Path.GetFileName(item.FilePath), item.FileType);
    }

    /// <summary>
    /// 批量添加上传任务（单事务，用于大批量录屏入队）
    /// </summary>
    public async Task<int> AddManyAsync(IEnumerable<UploadQueue> items)
    {
        var itemList = items.Where(i => !string.IsNullOrWhiteSpace(i.FilePath)).ToList();
        if (itemList.Count == 0)
            return 0;

        using var conn = _db.GetConnection();
        using var tx = conn.BeginTransaction();
        using var cmd = new SqliteCommand(@"
            INSERT INTO upload_queue (
                id, file_path, file_type, file_id, status, offset,
                retry_count, error_message, upload_id,
                record_start_time, record_end_time,
                last_upload_activity,
                created_at, updated_at
            ) VALUES (
                @id, @fp, @ft, @fid, @st, @off, @rc, @err, @uid,
                @record_start_time, @record_end_time, @last_upload_activity,
                @created, @updated
            )", conn, tx);

        var idParam = cmd.Parameters.Add("@id", SqliteType.Text);
        var fpParam = cmd.Parameters.Add("@fp", SqliteType.Text);
        var ftParam = cmd.Parameters.Add("@ft", SqliteType.Text);
        var fidParam = cmd.Parameters.Add("@fid", SqliteType.Text);
        var stParam = cmd.Parameters.Add("@st", SqliteType.Text);
        var offParam = cmd.Parameters.Add("@off", SqliteType.Integer);
        var rcParam = cmd.Parameters.Add("@rc", SqliteType.Integer);
        var errParam = cmd.Parameters.Add("@err", SqliteType.Text);
        var uidParam = cmd.Parameters.Add("@uid", SqliteType.Text);
        var rstParam = cmd.Parameters.Add("@record_start_time", SqliteType.Text);
        var retParam = cmd.Parameters.Add("@record_end_time", SqliteType.Text);
        var luaParam = cmd.Parameters.Add("@last_upload_activity", SqliteType.Text);
        var createdParam = cmd.Parameters.Add("@created", SqliteType.Text);
        var updatedParam = cmd.Parameters.Add("@updated", SqliteType.Text);

        var now = DateTime.UtcNow.ToIso8601String();
        var inserted = 0;

        foreach (var item in itemList)
        {
            idParam.Value = item.Id;
            fpParam.Value = item.FilePath;
            ftParam.Value = item.FileType;
            fidParam.Value = item.FileId;
            stParam.Value = item.Status;
            offParam.Value = item.Offset;
            rcParam.Value = item.RetryCount;
            errParam.Value = item.ErrorMessage ?? "";
            uidParam.Value = item.UploadId ?? "";
            rstParam.Value = item.RecordStartTime?.ToIso8601String() ?? "";
            retParam.Value = item.RecordEndTime?.ToIso8601String() ?? "";
            luaParam.Value = now;
            createdParam.Value = now;
            updatedParam.Value = now;

            inserted += await cmd.ExecuteNonQueryAsync();
        }

        tx.Commit();
        _logger.LogInformation("Batch added {Count} items to upload queue", inserted);
        return inserted;
    }

    /// <summary>
    /// 批量查询活跃队列项的文件路径 → 队列 ID
    /// </summary>
    public async Task<Dictionary<string, UploadQueue>> GetActiveByFilePathsAsync(IEnumerable<string> filePaths)
    {
        var pathList = filePaths.Where(p => !string.IsNullOrWhiteSpace(p)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var result = new Dictionary<string, UploadQueue>(StringComparer.OrdinalIgnoreCase);
        if (pathList.Count == 0)
            return result;

        const int batchSize = 100;
        using var conn = _db.GetConnection();

        for (var offset = 0; offset < pathList.Count; offset += batchSize)
        {
            var batch = pathList.Skip(offset).Take(batchSize).ToList();
            var placeholders = string.Join(",", batch.Select((_, i) => $"@fp{i}"));
            using var cmd = new SqliteCommand($@"
                SELECT id, file_path, file_type, file_id, status
                FROM upload_queue
                WHERE status IN ('pending', 'uploading')
                  AND file_path IN ({placeholders})", conn);

            for (var i = 0; i < batch.Count; i++)
                cmd.Parameters.AddWithValue($"@fp{i}", batch[i]);

            using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                var queueItem = new UploadQueue
                {
                    Id = reader.GetString(0),
                    FilePath = reader.GetString(1),
                    FileType = reader.GetString(2),
                    FileId = reader.GetString(3),
                    Status = reader.GetString(4),
                };
                result[queueItem.FilePath] = queueItem;
            }
        }

        return result;
    }

    /// <summary>
    /// 统计 pending/uploading 队列长度
    /// </summary>
    public async Task<int> CountActiveAsync()
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT COUNT(*) FROM upload_queue
            WHERE status IN ('pending', 'uploading') AND retry_count < @maxRetry", conn);
        cmd.Parameters.AddWithValue("@maxRetry", Constants.MaxRetryCount);
        var result = await cmd.ExecuteScalarAsync();
        return result == null ? 0 : Convert.ToInt32(result);
    }

    /// <summary>
    /// 更新上传会话 ID
    /// </summary>
    public async Task UpdateUploadIdAsync(string id, string uploadId)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE upload_queue 
            SET upload_id = @uid, updated_at = @up 
            WHERE id = @id", conn);

        cmd.Parameters.AddWithValue("@uid", uploadId);
        cmd.Parameters.AddWithValue("@up", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@id", id);

        await cmd.ExecuteNonQueryAsync();
        _logger.LogDebug("Updated upload ID for task {Id}: {UploadId}", id, uploadId);
    }

    /// <summary>
    /// 更新录屏起止时间（回填旧队列项）
    /// </summary>
    public async Task UpdateRecordTimesAsync(string id, DateTime startUtc, DateTime endUtc)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE upload_queue
            SET record_start_time = @st, record_end_time = @et, updated_at = @up
            WHERE id = @id", conn);

        cmd.Parameters.AddWithValue("@st", startUtc.ToIso8601String());
        cmd.Parameters.AddWithValue("@et", endUtc.ToIso8601String());
        cmd.Parameters.AddWithValue("@up", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@id", id);

        await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 获取缺少录屏时间的 pending/uploading 任务
    /// </summary>
    public async Task<List<UploadQueue>> GetRecordingsMissingTimesAsync(int limit = 200)
    {
        var result = new List<UploadQueue>();
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT id, file_path, file_type, file_id, status, offset, retry_count,
                   error_message, upload_id, record_start_time, record_end_time
            FROM upload_queue
            WHERE file_type = 'recording'
              AND status IN ('pending', 'uploading')
              AND (record_start_time IS NULL OR record_start_time = ''
                   OR record_end_time IS NULL OR record_end_time = '')
            LIMIT @limit", conn);
        cmd.Parameters.AddWithValue("@limit", limit);

        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new UploadQueue
            {
                Id = reader.GetString(0),
                FilePath = reader.GetString(1),
                FileType = reader.GetString(2),
                FileId = reader.GetString(3),
                Status = reader.GetString(4),
                Offset = reader.GetInt64(5),
                RetryCount = reader.GetInt32(6),
                ErrorMessage = reader.IsDBNull(7) ? "" : reader.GetString(7),
                UploadId = reader.IsDBNull(8) ? "" : reader.GetString(8),
                RecordStartTime = reader.IsDBNull(9) || string.IsNullOrWhiteSpace(reader.GetString(9))
                    ? null
                    : DateTimeExtensions.FromIso8601String(reader.GetString(9)),
                RecordEndTime = reader.IsDBNull(10) || string.IsNullOrWhiteSpace(reader.GetString(10))
                    ? null
                    : DateTimeExtensions.FromIso8601String(reader.GetString(10)),
            });
        }
        return result;
    }

    /// <summary>
    /// 获取待处理的上传任务
    /// </summary>
    public async Task<List<UploadQueue>> GetPendingAsync(int limit = 10)
    {
        var result = new List<UploadQueue>();

        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT 
                id, file_path, file_type, file_id, status, offset, retry_count, 
                error_message, upload_id, 
                record_start_time, record_end_time, last_upload_activity,
                created_at, updated_at
            FROM upload_queue
            WHERE status IN ('pending', 'uploading') AND retry_count < @maxRetry
            ORDER BY 
                CASE WHEN status = 'uploading' THEN 0 ELSE 1 END,
                retry_count ASC,
                created_at ASC
            LIMIT @limit", conn);

        cmd.Parameters.AddWithValue("@maxRetry", Constants.MaxRetryCount);
        cmd.Parameters.AddWithValue("@limit", limit);

        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new UploadQueue
            {
                Id = reader.GetString(0),
                FilePath = reader.GetString(1),
                FileType = reader.GetString(2),
                FileId = reader.GetString(3),
                Status = reader.GetString(4),
                Offset = reader.GetInt64(5),
                RetryCount = reader.GetInt32(6),
                ErrorMessage = reader.IsDBNull(7) ? "" : reader.GetString(7),
                UploadId = reader.IsDBNull(8) ? "" : reader.GetString(8),

                // ✅ 读取时间字段
                RecordStartTime = reader.IsDBNull(9)
                    ? null
                    : DateTimeExtensions.FromIso8601String(reader.GetString(9)),

                RecordEndTime = reader.IsDBNull(10)
                    ? null
                    : DateTimeExtensions.FromIso8601String(reader.GetString(10)),

                LastUploadActivity = reader.IsDBNull(11)
                    ? null
                    : DateTimeExtensions.FromIso8601String(reader.GetString(11)),

                CreatedAt = DateTimeExtensions.FromIso8601String(reader.GetString(12)),
                UpdatedAt = DateTimeExtensions.FromIso8601String(reader.GetString(13))
            });
        }

        return result;
    }

    /// <summary>
    /// 更新任务状态
    /// </summary>
    public async Task UpdateStatusAsync(string id, string status, string? error = null, int? retryCount = null)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE upload_queue
            SET status = @st, 
                error_message = @err, 
                retry_count = @rc, 
                last_retry_at = @lra, 
                last_upload_activity = @lua,
                updated_at = @up
            WHERE id = @id", conn);

        cmd.Parameters.AddWithValue("@st", status);
        cmd.Parameters.AddWithValue("@err", error ?? "");
        cmd.Parameters.AddWithValue("@rc", retryCount ?? 0);
        cmd.Parameters.AddWithValue("@lra", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@lua", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@up", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@id", id);

        await cmd.ExecuteNonQueryAsync();
        
        _logger.LogDebug("Updated upload task {Id} status to {Status} (retry: {RetryCount})", 
            id, status, retryCount);
    }

    /// <summary>
    /// 更新上传偏移量（用于断点续传）
    /// </summary>
    public async Task UpdateOffsetAsync(string id, long offset)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE upload_queue 
            SET offset = @off, last_upload_activity = @lua, updated_at = @up 
            WHERE id = @id", conn);

        cmd.Parameters.AddWithValue("@off", offset);
        cmd.Parameters.AddWithValue("@lua", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@up", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@id", id);

        await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 别名：与 ResetStuckTasksAsync 相同的功能，用于向外暴露语义更明确的方法名
    /// </summary>
    public Task<int> ResetStuckUploadsAsync(TimeSpan timeout)
    {
        return ResetStuckTasksAsync(timeout);
    }

    /// <summary>
    /// 更新偏移量并记录上次上传活动时间（用于检测是否卡住）
    /// </summary>
    public async Task UpdateOffsetWithActivityAsync(string id, long offset)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE upload_queue 
            SET offset = @off, last_upload_activity = @lua, updated_at = @up 
            WHERE id = @id", conn);

        cmd.Parameters.AddWithValue("@off", offset);
        cmd.Parameters.AddWithValue("@lua", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@up", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@id", id);

        await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 检查文件是否已在队列中
    /// </summary>
    public async Task<bool> ExistsPendingAsync(string filePath)
    {
        var item = await GetActiveByFilePathAsync(filePath);
        return item != null;
    }

    /// <summary>
    /// 获取指定文件当前活跃的上传队列项（pending / uploading）
    /// </summary>
    public async Task<UploadQueue?> GetActiveByFilePathAsync(string filePath)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT id, file_path, file_type, file_id, status
            FROM upload_queue
            WHERE file_path = @fp AND status IN ('pending', 'uploading')
            ORDER BY created_at DESC
            LIMIT 1", conn);

        cmd.Parameters.AddWithValue("@fp", filePath);

        using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync())
            return null;

        return new UploadQueue
        {
            Id = reader.GetString(0),
            FilePath = reader.GetString(1),
            FileType = reader.GetString(2),
            FileId = reader.GetString(3),
            Status = reader.GetString(4),
        };
    }

    /// <summary>
    /// 批量查询队列项状态（用于任务等待上传完成）
    /// </summary>
    public async Task<Dictionary<string, string>> GetStatusesByIdsAsync(IEnumerable<string> ids)
    {
        var idList = ids.Where(id => !string.IsNullOrWhiteSpace(id)).Distinct().ToList();
        var result = new Dictionary<string, string>(StringComparer.Ordinal);

        if (idList.Count == 0)
            return result;

        var placeholders = string.Join(",", idList.Select((_, i) => $"@id{i}"));
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(
            $"SELECT id, status FROM upload_queue WHERE id IN ({placeholders})", conn);

        for (var i = 0; i < idList.Count; i++)
            cmd.Parameters.AddWithValue($"@id{i}", idList[i]);

        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
            result[reader.GetString(0)] = reader.GetString(1);

        return result;
    }

    /// <summary>
    /// 删除失败的上传任务
    /// </summary>
    public async Task<int> DeleteFailedAsync()
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand("DELETE FROM upload_queue WHERE status = 'failed'", conn);
        var deleted = await cmd.ExecuteNonQueryAsync();
        
        if (deleted > 0)
        {
            _logger.LogInformation("Deleted {Count} failed upload tasks", deleted);
        }
        
        return deleted;
    }

    /// <summary>
    /// 删除指定 ID 的上传任务
    /// </summary>
    public async Task<int> DeleteAsync(string id)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand("DELETE FROM upload_queue WHERE id = @id", conn);
        cmd.Parameters.AddWithValue("@id", id);
        return await cmd.ExecuteNonQueryAsync();
    }

    /// <summary>
    /// 清理过期的上传任务（超过指定天数）
    /// </summary>
    public async Task<int> DeleteOlderThanAsync(DateTime cutoff)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(
            "DELETE FROM upload_queue WHERE created_at < @cut AND status IN ('completed', 'failed')", 
            conn);
        cmd.Parameters.AddWithValue("@cut", cutoff.ToIso8601String());
        var deleted = await cmd.ExecuteNonQueryAsync();
        
        if (deleted > 0)
        {
            _logger.LogInformation("Deleted {Count} old upload tasks older than {Cutoff}", 
                deleted, cutoff.ToString("yyyy-MM-dd"));
        }
        
        return deleted;
    }

    /// <summary>
    /// 将可重试的失败上传任务重新入队（文件仍存在时）
    /// </summary>
    public async Task<int> RequeueRetryableFailedAsync(int limit = 30, int minAgeMinutes = 30)
    {
        var requeued = 0;
        var cutoff = DateTime.UtcNow.AddMinutes(-minAgeMinutes).ToIso8601String();

        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT id, file_path, retry_count
            FROM upload_queue
            WHERE status = 'failed' AND updated_at <= @cut
            ORDER BY updated_at ASC
            LIMIT @limit", conn);

        cmd.Parameters.AddWithValue("@cut", cutoff);
        cmd.Parameters.AddWithValue("@limit", limit);

        var candidates = new List<(string Id, string FilePath)>();
        using (var reader = await cmd.ExecuteReaderAsync())
        {
            while (await reader.ReadAsync())
            {
                candidates.Add((reader.GetString(0), reader.GetString(1)));
            }
        }

        foreach (var (id, filePath) in candidates)
        {
            if (!File.Exists(filePath))
                continue;

            using var update = new SqliteCommand(@"
                UPDATE upload_queue
                SET status = 'pending',
                    retry_count = 0,
                    offset = 0,
                    error_message = 'Requeued by self-healing',
                    updated_at = @up
                WHERE id = @id AND status = 'failed'", conn);

            update.Parameters.AddWithValue("@up", DateTime.UtcNow.ToIso8601String());
            update.Parameters.AddWithValue("@id", id);

            if (await update.ExecuteNonQueryAsync() > 0)
                requeued++;
        }

        if (requeued > 0)
            _logger.LogInformation("Requeued {Count} failed upload tasks for retry", requeued);

        return requeued;
    }

    /// <summary>
    /// 获取失败任务数量
    /// </summary>
    public async Task<int> GetFailedCountAsync()
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand("SELECT COUNT(*) FROM upload_queue WHERE status = 'failed'", conn);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync());
    }

    /// <summary>
    /// 服务启动时将全部 uploading 任务重置为 pending（崩溃/强杀恢复）
    /// </summary>
    public async Task<int> ResetAllUploadingAsync()
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE upload_queue
            SET status = 'pending',
                error_message = 'Reset on service startup',
                last_upload_activity = @lua,
                updated_at = @up
            WHERE status = 'uploading'", conn);

        cmd.Parameters.AddWithValue("@up", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@lua", DateTime.UtcNow.ToIso8601String());

        var resetCount = await cmd.ExecuteNonQueryAsync();
        if (resetCount > 0)
        {
            _logger.LogWarning("Reset {Count} uploading tasks to pending on startup", resetCount);
        }

        return resetCount;
    }

    /// <summary>
    /// 重置卡住的上传任务（状态为 uploading 但超过指定时间）
    /// </summary>
    public async Task<int> ResetStuckTasksAsync(TimeSpan timeout)
    {
        var cutoff = DateTime.UtcNow.Subtract(timeout);
        
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            UPDATE upload_queue 
            SET status = 'pending', 
                error_message = 'Reset due to timeout', 
                last_upload_activity = @lua,
                updated_at = @up
            WHERE status = 'uploading' AND (updated_at < @cut OR (last_upload_activity IS NOT NULL AND last_upload_activity < @cut))", conn);
        
        cmd.Parameters.AddWithValue("@up", DateTime.UtcNow.ToIso8601String());
        cmd.Parameters.AddWithValue("@cut", cutoff.ToIso8601String());
        cmd.Parameters.AddWithValue("@lua", DateTime.UtcNow.ToIso8601String());
        
        var resetCount = await cmd.ExecuteNonQueryAsync();
        
        if (resetCount > 0)
        {
            _logger.LogWarning("Reset {Count} stuck upload tasks (timeout: {Timeout} minutes)", 
                resetCount, timeout.TotalMinutes);
        }
        
        return resetCount;
    }

    /// <summary>
    /// 获取指定文件的上传任务
    /// </summary>
    public async Task<UploadQueue?> GetByFileIdAsync(string fileId, string fileType)
    {
        using var conn = _db.GetConnection();
        using var cmd = new SqliteCommand(@"
            SELECT 
                id, file_path, file_type, file_id, status, offset, retry_count, 
                error_message, upload_id, created_at, updated_at
            FROM upload_queue
            WHERE file_id = @fid AND file_type = @ft
            ORDER BY created_at DESC
            LIMIT 1", conn);

        cmd.Parameters.AddWithValue("@fid", fileId);
        cmd.Parameters.AddWithValue("@ft", fileType);

        using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            return new UploadQueue
            {
                Id = reader.GetString(0),
                FilePath = reader.GetString(1),
                FileType = reader.GetString(2),
                FileId = reader.GetString(3),
                Status = reader.GetString(4),
                Offset = reader.GetInt64(5),
                RetryCount = reader.GetInt32(6),
                ErrorMessage = reader.IsDBNull(7) ? "" : reader.GetString(7),
                UploadId = reader.IsDBNull(8) ? "" : reader.GetString(8),
                CreatedAt = DateTimeExtensions.FromIso8601String(reader.GetString(9)),
                UpdatedAt = DateTimeExtensions.FromIso8601String(reader.GetString(10))
            };
        }
        
        return null;
    }

    /// <summary>
    /// 获取队列统计信息
    /// </summary>
    public async Task<(int pending, int uploading, int completed, int failed)> GetQueueStatsAsync(CancellationToken ct = default)
    {
        using var conn = _db.GetConnection();

        using var cmd = new SqliteCommand(@"
        SELECT status, COUNT(*) 
        FROM upload_queue 
        GROUP BY status", conn);

        using var reader = await cmd.ExecuteReaderAsync(ct); // ✅ 传递 ct

        var stats = new Dictionary<string, int>();

        while (await reader.ReadAsync(ct)) // ✅ 传递 ct
        {
            var status = reader.GetString(0);
            var count = reader.GetInt32(1);

            stats[status] = count;
        }

        return (
            pending: stats.GetValueOrDefault("pending", 0),
            uploading: stats.GetValueOrDefault("uploading", 0),
            completed: stats.GetValueOrDefault("completed", 0),
            failed: stats.GetValueOrDefault("failed", 0)
        );
    }
}
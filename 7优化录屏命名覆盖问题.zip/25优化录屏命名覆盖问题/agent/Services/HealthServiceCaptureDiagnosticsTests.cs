using EnterpriseAgent.Agent.Lifecycle;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.Services;
using System.Text.Json;
using Xunit;

namespace EnterpriseAgent.Agent.Services.Tests;

public sealed class HealthServiceCaptureDiagnosticsTests
{
    [Fact]
    public void EvaluateCaptureLifecycle_ReturnsHealthyWhenNoViolations()
    {
        var diagnostics = new CaptureLifecycleDiagnostics
        {
            CaptureState = CaptureLifecycleState.Recording,
            RecorderState = RecorderState.Recording,
            InvariantViolations = Array.Empty<string>(),
        };

        var check = HealthService.EvaluateCaptureLifecycle(diagnostics);

        Assert.True(check.IsHealthy);
        Assert.Contains("Recording", check.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void EvaluateCaptureLifecycle_ReturnsDegradedWhenInvariantViolated()
    {
        var diagnostics = new CaptureLifecycleDiagnostics
        {
            CaptureState = CaptureLifecycleState.SharedBridgeRunning,
            RecorderState = RecorderState.RecordingAndRemote,
            InvariantViolations = new[] { "recording=false,remote=true" },
        };

        var check = HealthService.EvaluateCaptureLifecycle(diagnostics);

        Assert.False(check.IsHealthy);
        Assert.Contains("recording=false,remote=true", check.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void HealthReport_SerializesCaptureLifecycleSection()
    {
        var report = new HealthReport
        {
            Status = "Healthy",
            CaptureLifecycle = new CaptureLifecycleDiagnostics
            {
                CaptureState = CaptureLifecycleState.Recording,
                RecorderState = RecorderState.Recording,
                LastCorrelationId = "abc123",
                InvariantViolations = Array.Empty<string>(),
            },
        };

        var json = JsonSerializer.Serialize(report, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        });

        Assert.Contains("\"captureLifecycle\"", json, StringComparison.Ordinal);
        Assert.Contains("\"lastCorrelationId\":\"abc123\"", json, StringComparison.Ordinal);
        Assert.Contains("\"recorderState\"", json, StringComparison.Ordinal);
    }
}

using System.Threading.Channels;
using EnterpriseAgent.Agent.Recorder;

namespace EnterpriseAgent.Agent.Lifecycle;

/// <summary>
/// Serializes lifecycle intents — no fire-and-forget RequestAsync.
/// </summary>
public sealed class CaptureIntentQueue : IAsyncDisposable
{
    private readonly Func<RecorderCommand, RecorderRequestContext, CancellationToken, Task<RecorderResult>> _executor;
    private readonly CaptureLifecycleTelemetry _telemetry;
    private readonly Channel<(RecorderCommand Command, RecorderRequestContext Context, TaskCompletionSource<RecorderResult> Completion)> _channel;
    private readonly Task _processor;
    private readonly CancellationTokenSource _cts = new();

    public CaptureIntentQueue(
        Func<RecorderCommand, RecorderRequestContext, CancellationToken, Task<RecorderResult>> executor,
        CaptureLifecycleTelemetry telemetry)
    {
        _executor = executor;
        _telemetry = telemetry;
        _channel = Channel.CreateUnbounded<(RecorderCommand, RecorderRequestContext, TaskCompletionSource<RecorderResult>)>(
            new UnboundedChannelOptions { SingleReader = true, SingleWriter = false });
        _processor = Task.Run(ProcessAsync);
    }

    public Task<RecorderResult> EnqueueAsync(
        RecorderCommand command,
        RecorderRequestContext context,
        CancellationToken cancellationToken = default)
    {
        var correlationId = _telemetry.NewCorrelationId();
        context = new RecorderRequestContext
        {
            RemoteView = context.RemoteView,
            Reason = string.IsNullOrWhiteSpace(context.Reason)
                ? correlationId
                : $"{context.Reason}|cid={correlationId}",
            PolicyRecordingEnabled = context.PolicyRecordingEnabled,
        };

        _telemetry.AuditIntent(correlationId, command.ToString(), context.Reason);

        var tcs = new TaskCompletionSource<RecorderResult>(TaskCreationOptions.RunContinuationsAsynchronously);
        if (!_channel.Writer.TryWrite((command, context, tcs)))
        {
            tcs.SetResult(RecorderResult.Failed(RecorderState.Transitioning, "Lifecycle intent queue unavailable"));
            return tcs.Task;
        }

        return tcs.Task.WaitAsync(cancellationToken);
    }

    private async Task ProcessAsync()
    {
        await foreach (var (command, context, completion) in _channel.Reader.ReadAllAsync(_cts.Token))
        {
            try
            {
                var result = await _executor(command, context, _cts.Token);
                completion.TrySetResult(result);
            }
            catch (Exception ex)
            {
                completion.TrySetResult(RecorderResult.Failed(RecorderState.Transitioning, ex.Message));
            }
        }
    }

    public async ValueTask DisposeAsync()
    {
        _channel.Writer.TryComplete();
        _cts.Cancel();
        try { await _processor.ConfigureAwait(false); }
        catch (OperationCanceledException) { }
        _cts.Dispose();
    }
}

namespace EnterpriseAgent.Agent.Lifecycle;

public enum RestartPolicyBucket
{
    LifecycleTransition,
    HealthRecovery,
    EncoderRetry,
    UserInitiated,
}

/// <summary>
/// Independent sliding-window throttles (replaces shared _restartHistory semantics).
/// </summary>
public sealed class RestartPolicyRegistry
{
    private readonly object _gate = new();
    private readonly Queue<DateTime> _lifecycleTransitions = new();
    private readonly Queue<DateTime> _healthRecoveries = new();
    private readonly Queue<DateTime> _encoderRetries = new();
    private readonly Queue<DateTime> _userInitiated = new();
    private DateTime _lastHealthRecoveryUtc = DateTime.MinValue;
    private DateTime _lastUserInitiatedUtc = DateTime.MinValue;
    private DateTime _lastEncoderRetryUtc = DateTime.MinValue;

    public bool TryAcquire(RestartPolicyBucket bucket, out string? blockReason)
    {
        blockReason = null;
        var now = DateTime.UtcNow;

        lock (_gate)
        {
            switch (bucket)
            {
                case RestartPolicyBucket.LifecycleTransition:
                    Trim(_lifecycleTransitions, now, TimeSpan.FromMinutes(5));
                    if (_lifecycleTransitions.Count >= 12)
                    {
                        blockReason = "Lifecycle transition burst limit";
                        return false;
                    }
                    _lifecycleTransitions.Enqueue(now);
                    return true;

                case RestartPolicyBucket.HealthRecovery:
                    if (now - _lastHealthRecoveryUtc < TimeSpan.FromSeconds(45))
                    {
                        blockReason = "Health recovery cooldown (45s)";
                        return false;
                    }
                    Trim(_healthRecoveries, now, TimeSpan.FromHours(1));
                    if (_healthRecoveries.Count >= 8)
                    {
                        blockReason = "Health recovery hourly limit";
                        return false;
                    }
                    _lastHealthRecoveryUtc = now;
                    _healthRecoveries.Enqueue(now);
                    return true;

                case RestartPolicyBucket.EncoderRetry:
                    if (now - _lastEncoderRetryUtc < TimeSpan.FromSeconds(10))
                    {
                        blockReason = "Encoder retry cooldown (10s)";
                        return false;
                    }
                    Trim(_encoderRetries, now, TimeSpan.FromMinutes(5));
                    if (_encoderRetries.Count >= 6)
                    {
                        blockReason = "Encoder retry burst limit";
                        return false;
                    }
                    _lastEncoderRetryUtc = now;
                    _encoderRetries.Enqueue(now);
                    return true;

                case RestartPolicyBucket.UserInitiated:
                    if (now - _lastUserInitiatedUtc < TimeSpan.FromSeconds(30))
                    {
                        blockReason = "User-initiated restart cooldown (30s)";
                        return false;
                    }
                    Trim(_userInitiated, now, TimeSpan.FromHours(1));
                    if (_userInitiated.Count >= 10)
                    {
                        blockReason = "User-initiated hourly limit";
                        return false;
                    }
                    _lastUserInitiatedUtc = now;
                    _userInitiated.Enqueue(now);
                    return true;

                default:
                    return true;
            }
        }
    }

    public void RecordSuccessfulStart(RestartPolicyBucket bucket)
    {
        // Reserved for metrics; acquire already records transition/recovery attempts.
    }

    public RestartPolicyDiagnostics GetDiagnostics()
    {
        var now = DateTime.UtcNow;
        lock (_gate)
        {
            Trim(_lifecycleTransitions, now, TimeSpan.FromMinutes(5));
            Trim(_healthRecoveries, now, TimeSpan.FromHours(1));
            Trim(_encoderRetries, now, TimeSpan.FromMinutes(5));
            Trim(_userInitiated, now, TimeSpan.FromHours(1));

            return new RestartPolicyDiagnostics
            {
                LifecycleTransitionsLast5Min = _lifecycleTransitions.Count,
                HealthRecoveriesLastHour = _healthRecoveries.Count,
                EncoderRetriesLast5Min = _encoderRetries.Count,
                UserInitiatedLastHour = _userInitiated.Count,
                LastHealthRecoveryUtc = NullIfMin(_lastHealthRecoveryUtc),
                LastEncoderRetryUtc = NullIfMin(_lastEncoderRetryUtc),
                LastUserInitiatedUtc = NullIfMin(_lastUserInitiatedUtc),
            };
        }
    }

    private static DateTime? NullIfMin(DateTime value) =>
        value == DateTime.MinValue ? null : value;

    private static void Trim(Queue<DateTime> queue, DateTime now, TimeSpan window)
    {
        while (queue.Count > 0 && now - queue.Peek() > window)
            queue.Dequeue();
    }
}

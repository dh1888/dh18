using EnterpriseAgent.Agent.Capture;

namespace EnterpriseAgent.Agent.Lifecycle;

/// <summary>
/// Point-in-time capture configuration restored on SharedBridge rollback (L3).
/// </summary>
public sealed class CaptureSnapshot
{
    public CaptureMode Mode { get; init; } = CaptureMode.DualGdigrab;
    public string? OutputPattern { get; init; }
    public string Encoder { get; init; } = "libx264";
    public bool RecordingWasRunning { get; init; }
    public DateTime CapturedUtc { get; init; } = DateTime.UtcNow;
}

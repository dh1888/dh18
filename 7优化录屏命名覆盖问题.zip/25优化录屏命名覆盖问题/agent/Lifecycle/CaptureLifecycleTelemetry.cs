using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Lifecycle;

/// <summary>
/// Correlation + structured audit for capture lifecycle transitions (P2 foundation).
/// </summary>
public sealed class CaptureLifecycleTelemetry
{
    private readonly ILogger<CaptureLifecycleTelemetry> _logger;

    public CaptureLifecycleTelemetry(ILogger<CaptureLifecycleTelemetry> logger) => _logger = logger;

    public string NewCorrelationId() => Guid.NewGuid().ToString("N")[..12];

    public void AuditTransition(
        string correlationId,
        CaptureLifecycleState from,
        CaptureLifecycleState to,
        string trigger,
        bool success,
        string? detail = null)
    {
        _logger.LogInformation(
            "CaptureLifecycle transition cid={CorrelationId} {From}->{To} trigger={Trigger} success={Success} detail={Detail}",
            correlationId,
            from,
            to,
            trigger,
            success,
            detail ?? "");
    }

    public void AuditIntent(string correlationId, string intentKind, string reason)
    {
        _logger.LogInformation(
            "CaptureLifecycle intent cid={CorrelationId} kind={Kind} reason={Reason}",
            correlationId,
            intentKind,
            reason);
    }
}

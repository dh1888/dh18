using EnterpriseAgent.Agent.Lifecycle;
using Xunit;

namespace EnterpriseAgent.Agent.Lifecycle.Tests;

public sealed class CaptureLifecycleDiagnosticsAnalyzerTests
{
    [Fact]
    public void DetectInvariantViolations_FlagsRecordingFalseRemoteTrueOnSharedBridge()
    {
        var violations = CaptureLifecycleDiagnosticsAnalyzer.DetectInvariantViolations(
            captureState: CaptureLifecycleState.SharedBridgeRunning,
            shouldRecordingBeActive: true,
            recordingRunning: false,
            remoteActive: true,
            remotePublishing: true,
            sharedBridgeForRemote: true,
            sharedCaptureActive: true);

        Assert.Contains("recording=false,remote=true", violations);
    }

    [Fact]
    public void DetectInvariantViolations_FlagsSharedBridgeRunningWithoutBridge()
    {
        var violations = CaptureLifecycleDiagnosticsAnalyzer.DetectInvariantViolations(
            captureState: CaptureLifecycleState.SharedBridgeRunning,
            shouldRecordingBeActive: true,
            recordingRunning: true,
            remoteActive: true,
            remotePublishing: true,
            sharedBridgeForRemote: true,
            sharedCaptureActive: false);

        Assert.Contains("shared_bridge_running_without_active_bridge", violations);
    }

    [Fact]
    public void DetectInvariantViolations_ReturnsEmptyWhenConsistent()
    {
        var violations = CaptureLifecycleDiagnosticsAnalyzer.DetectInvariantViolations(
            captureState: CaptureLifecycleState.Recording,
            shouldRecordingBeActive: true,
            recordingRunning: true,
            remoteActive: false,
            remotePublishing: false,
            sharedBridgeForRemote: false,
            sharedCaptureActive: false);

        Assert.Empty(violations);
    }
}

public sealed class RemoteFailureClassifierTests
{
    [Fact]
    public void Classify_UserStop_WhenIntentionalFlagSet()
    {
        var kind = RemoteFailureClassifier.Classify("ffmpeg exited with code -1", intentionalUserStop: true);
        Assert.Equal(RemoteFailureKind.UserStop, kind);
    }

    [Theory]
    [InlineData("Timed out waiting for remote SharedBridge first frame", RemoteFailureKind.Timeout)]
    [InlineData("Error submitting a packet to muxer", RemoteFailureKind.TransportError)]
    [InlineData("ffmpeg exited with code -1", RemoteFailureKind.FfmpegCrash)]
    public void Classify_MapsDetailToExpectedKind(string detail, RemoteFailureKind expected)
    {
        var kind = RemoteFailureClassifier.Classify(detail, intentionalUserStop: false);
        Assert.Equal(expected, kind);
    }
}

public sealed class RestartPolicyRegistryTests
{
    [Fact]
    public void TryAcquire_HealthRecovery_EnforcesCooldown()
    {
        var registry = new RestartPolicyRegistry();

        Assert.True(registry.TryAcquire(RestartPolicyBucket.HealthRecovery, out _));
        Assert.False(registry.TryAcquire(RestartPolicyBucket.HealthRecovery, out var blockReason));
        Assert.Contains("cooldown", blockReason, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void GetDiagnostics_ReflectsRecentAcquireCounts()
    {
        var registry = new RestartPolicyRegistry();
        Assert.True(registry.TryAcquire(RestartPolicyBucket.LifecycleTransition, out _));
        Assert.True(registry.TryAcquire(RestartPolicyBucket.LifecycleTransition, out _));

        var diagnostics = registry.GetDiagnostics();
        Assert.Equal(2, diagnostics.LifecycleTransitionsLast5Min);
    }
}

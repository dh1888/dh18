namespace EnterpriseAgent.Agent.Lifecycle;

/// <summary>
/// Explicit capture lifecycle FSM (orchestrator-owned).
/// </summary>
public enum CaptureLifecycleState
{
    Idle,
    Recording,
    PreparingSharedBridge,
    SharedBridgeRunning,
    Rollback,
    Recovering,
    Stopping,
    Stopped,
}

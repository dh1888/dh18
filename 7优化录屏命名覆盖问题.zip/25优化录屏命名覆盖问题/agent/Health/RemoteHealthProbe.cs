using EnterpriseAgent.Agent.Lifecycle;
using EnterpriseAgent.Agent.RemoteView;

namespace EnterpriseAgent.Agent.Health;

public sealed class RemoteHealthProbe : IRemoteHealthProbe
{
    private readonly IRemoteViewService _remoteView;
    private readonly ILifecycleCoordinator _lifecycle;

    public RemoteHealthProbe(IRemoteViewService remoteView, ILifecycleCoordinator lifecycle)
    {
        _remoteView = remoteView;
        _lifecycle = lifecycle;
    }

    public RemoteHealthSnapshot Sample()
    {
        var health = _remoteView.GetHealth();
        var frameAge = health.FrameAgeSeconds;
        var frameRecent = frameAge < 30;

        return new RemoteHealthSnapshot
        {
            IsPublishing = health.IsPublishing,
            ProcessAlive = health.ProcessAlive,
            FrameRecent = frameRecent,
            FrameAgeSeconds = frameAge,
            RestartCount = health.RestartCount,
            SessionId = health.SessionId,
            RemoteActive = _lifecycle.IsRemoteActive,
            IsHealthy = !_lifecycle.IsRemoteActive || (health.IsPublishing && frameRecent),
            PendingTransportError = _remoteView.TakePendingTransportError(),
        };
    }
}

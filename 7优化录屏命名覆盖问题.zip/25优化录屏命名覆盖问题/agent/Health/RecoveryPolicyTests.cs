using EnterpriseAgent.Agent.Capture;
using EnterpriseAgent.Agent.Health;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Recorder;
using EnterpriseAgent.Agent.RemoteView;
using Microsoft.Extensions.Options;
using Xunit;

namespace EnterpriseAgent.Agent.Health.Tests;

public sealed class RecoveryPolicyTests
{
    private readonly RecoveryPolicy _policy = new(Options.Create(new RemoteViewConfig()));

    private static SharedBridgeHealthSnapshot HealthyBridge() => new()
    {
        State = SharedBridgeState.Flowing,
        FrameFlowing = true,
        BridgeProcessAlive = true,
        RecordingPipeConnected = true,
        RemotePipeConnected = true,
    };

    [Fact]
    public void Evaluate_RecoverRecordingConsumerWhenSharedBridgeActiveAndProcessDead()
    {
        var decision = _policy.Evaluate(
            recording: new RecordingHealthSnapshot
            {
                ShouldBeRecording = true,
                ProcessAlive = false,
                IsHealthy = false,
                StallSeconds = 999,
            },
            remote: new RemoteHealthSnapshot { RemoteActive = true, IsPublishing = true, FrameRecent = true },
            bridge: HealthyBridge(),
            sharedCaptureActive: true,
            lastResumeUtc: DateTime.MinValue,
            nowUtc: DateTime.UtcNow);

        Assert.Equal(RecoveryAction.RecoverSharedBridge, decision.Action);
        Assert.Equal("RECORDING_CONSUMER_DEAD", decision.Reason);
    }

    [Fact]
    public void Evaluate_RecoverRecordingConsumerWhenSharedBridgeActiveAndFileStalled()
    {
        var decision = _policy.Evaluate(
            recording: new RecordingHealthSnapshot
            {
                ShouldBeRecording = true,
                ProcessAlive = true,
                IsHealthy = false,
                FileRecent = false,
                FileGrowing = false,
            },
            remote: new RemoteHealthSnapshot { RemoteActive = true, IsPublishing = true, FrameRecent = true },
            bridge: HealthyBridge(),
            sharedCaptureActive: true,
            lastResumeUtc: DateTime.MinValue,
            nowUtc: DateTime.UtcNow);

        Assert.Equal(RecoveryAction.RecoverSharedBridge, decision.Action);
        Assert.Equal("RECORDING_CONSUMER_STALL", decision.Reason);
    }

    [Fact]
    public void Evaluate_SkipsRecordingConsumerRecoveryWhenSharedBridgeHealthyAndRecordingHealthy()
    {
        var decision = _policy.Evaluate(
            recording: new RecordingHealthSnapshot
            {
                ShouldBeRecording = true,
                ProcessAlive = true,
                IsHealthy = true,
                FileRecent = true,
                FileGrowing = true,
            },
            remote: new RemoteHealthSnapshot { RemoteActive = true, IsPublishing = true, FrameRecent = true },
            bridge: HealthyBridge(),
            sharedCaptureActive: true,
            lastResumeUtc: DateTime.MinValue,
            nowUtc: DateTime.UtcNow);

        Assert.Equal(RecoveryAction.None, decision.Action);
        Assert.Contains("SharedBridge", decision.Reason, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Evaluate_ExitRemoteWhenActiveWithoutBridgeAndRecordingDead()
    {
        var decision = _policy.Evaluate(
            recording: new RecordingHealthSnapshot
            {
                ShouldBeRecording = true,
                ProcessAlive = false,
                IsHealthy = false,
            },
            remote: new RemoteHealthSnapshot { RemoteActive = true, IsPublishing = false, SessionId = "s1" },
            bridge: null,
            sharedCaptureActive: false,
            lastResumeUtc: DateTime.MinValue,
            nowUtc: DateTime.UtcNow);

        Assert.Equal(RecoveryAction.ExitRemoteFailed, decision.Action);
        Assert.Equal("REMOTE_WITHOUT_BRIDGE", decision.Reason);
    }

    [Fact]
    public void Evaluate_RecoverRecordingWhenNotOnSharedBridgeAndRemoteInactive()
    {
        var decision = _policy.Evaluate(
            recording: new RecordingHealthSnapshot
            {
                ShouldBeRecording = true,
                ProcessAlive = false,
                IsHealthy = false,
            },
            remote: new RemoteHealthSnapshot { RemoteActive = false },
            bridge: null,
            sharedCaptureActive: false,
            lastResumeUtc: DateTime.MinValue,
            nowUtc: DateTime.UtcNow);

        Assert.Equal(RecoveryAction.RecoverRecording, decision.Action);
    }
}

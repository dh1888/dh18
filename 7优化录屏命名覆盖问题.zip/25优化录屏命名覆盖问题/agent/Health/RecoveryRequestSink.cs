namespace EnterpriseAgent.Agent.Health;

public sealed class RecoveryRequestSink : IRecoveryRequestSink
{
    private readonly object _gate = new();
    private string? _pendingReason;

    public void RequestRecordingRecovery(string reason)
    {
        if (string.IsNullOrWhiteSpace(reason))
            reason = "REQUESTED";

        lock (_gate)
        {
            _pendingReason = reason;
        }
    }

    public bool TryTakePendingRecordingRecovery(out string reason)
    {
        lock (_gate)
        {
            if (_pendingReason == null)
            {
                reason = "";
                return false;
            }

            reason = _pendingReason;
            _pendingReason = null;
            return true;
        }
    }
}

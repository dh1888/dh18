namespace EnterpriseAgent.Agent.Health;

public enum RecoveryAction
{
    None,
    RecoverRecording,
    ReconnectRemote,
    RecoverSharedBridge,
    ExitRemoteFailed,
}

public sealed class RecoveryDecision
{
    public RecoveryAction Action { get; init; } = RecoveryAction.None;
    public string Reason { get; init; } = "";
}

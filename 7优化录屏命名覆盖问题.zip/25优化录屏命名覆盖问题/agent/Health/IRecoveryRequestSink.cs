namespace EnterpriseAgent.Agent.Health;

/// <summary>
/// Queues recording recovery requests for HealthCoordinator (sole recover executor).
/// </summary>
public interface IRecoveryRequestSink
{
    void RequestRecordingRecovery(string reason);
    bool TryTakePendingRecordingRecovery(out string reason);
}

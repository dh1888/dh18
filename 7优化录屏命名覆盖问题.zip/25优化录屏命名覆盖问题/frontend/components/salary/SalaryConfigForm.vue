<template>
  <div class="salary-config-form">
    <div class="config-grid">
      <div v-for="field in fields" :key="field.key" class="config-field-card">
        <div class="field-head">
          <div class="field-icon" :style="{ background: field.gradient }">
            <el-icon><component :is="field.icon" /></el-icon>
          </div>
          <div>
            <div class="field-label">{{ field.label }}</div>
            <div class="field-hint">{{ field.hint }}</div>
          </div>
        </div>
        <el-input-number
          v-model="model[field.key]"
          :min="field.min"
          :max="field.max"
          :precision="field.precision"
          :step="field.step"
          controls-position="right"
          class="field-input"
        />
      </div>
    </div>

    <div class="penalty-note">
      <el-icon class="note-icon"><InfoFilled /></el-icon>
      <div>
        <strong>罚款说明</strong>
        <p>罚款不在此配置。计算工资时将自动从「考勤绩效 → 罚款详情」按月汇总到每位员工。</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  TrendCharts,
  Calendar,
  Money,
  Switch,
  Star,
  Lock,
  InfoFilled,
} from "@element-plus/icons-vue";
import type { SalaryWorkConfig } from "@api/admin_api";

defineProps<{ mode?: string }>();
const model = defineModel<SalaryWorkConfig>({ required: true });

type FieldKey = keyof Pick<
  SalaryWorkConfig,
  | "totalIncrease"
  | "fullAttendanceDays"
  | "fullAttendanceAmount"
  | "exchangeRate"
  | "performanceFullScoreAmount"
  | "protectionFee"
>;

const fields: Array<{
  key: FieldKey;
  label: string;
  hint: string;
  min: number;
  max?: number;
  precision: number;
  step: number;
  icon: typeof Money;
  gradient: string;
}> = [
  {
    key: "totalIncrease",
    label: "递增总额",
    hint: "计入底薪：上月底薪 + 递增总额",
    min: 0,
    precision: 2,
    step: 100,
    icon: TrendCharts,
    gradient: "linear-gradient(135deg, #667eea, #764ba2)",
  },
  {
    key: "fullAttendanceDays",
    label: "满勤天数",
    hint: "0 = 上满当月自然日",
    min: 0,
    max: 31,
    precision: 0,
    step: 1,
    icon: Calendar,
    gradient: "linear-gradient(135deg, #43e97b, #38f9d7)",
  },
  {
    key: "fullAttendanceAmount",
    label: "满勤金额",
    hint: "达到满勤天数后发放",
    min: 0,
    precision: 2,
    step: 100,
    icon: Money,
    gradient: "linear-gradient(135deg, #4facfe, #00f2fe)",
  },
  {
    key: "exchangeRate",
    label: "汇率",
    hint: "实发合计 = 各项合计 ÷ 汇率",
    min: 0,
    precision: 4,
    step: 0.01,
    icon: Switch,
    gradient: "linear-gradient(135deg, #fa709a, #fee140)",
  },
  {
    key: "performanceFullScoreAmount",
    label: "绩效奖励 (10分)",
    hint: "按实际绩效分数比例计算",
    min: 0,
    precision: 2,
    step: 50,
    icon: Star,
    gradient: "linear-gradient(135deg, #f093fb, #f5576c)",
  },
  {
    key: "protectionFee",
    label: "保护费",
    hint: "每月固定保护费扣项",
    min: 0,
    precision: 2,
    step: 50,
    icon: Lock,
    gradient: "linear-gradient(135deg, #a18cd1, #fbc2eb)",
  },
];
</script>

<style scoped>
.salary-config-form {
  width: 100%;
}

.config-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
}

.config-field-card {
  padding: 18px;
  border-radius: 16px;
  background: #f8fafc;
  border: 1px solid #eef2f7;
  transition: all 0.25s ease;
}

.config-field-card:hover {
  border-color: rgba(64, 158, 255, 0.25);
  box-shadow: 0 6px 20px rgba(64, 158, 255, 0.08);
  transform: translateY(-2px);
}

.field-head {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 14px;
}

.field-icon {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.field-label {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 4px;
}

.field-hint {
  font-size: 12px;
  color: #909399;
  line-height: 1.4;
}

.field-input {
  width: 100%;
}

.field-input :deep(.el-input__wrapper) {
  border-radius: 10px;
  box-shadow: 0 0 0 1px #e4e7ed inset;
}

.penalty-note {
  display: flex;
  gap: 14px;
  margin-top: 20px;
  padding: 16px 18px;
  border-radius: 14px;
  background: linear-gradient(135deg, rgba(64, 158, 255, 0.08), rgba(64, 158, 255, 0.03));
  border: 1px solid rgba(64, 158, 255, 0.15);
}

.note-icon {
  font-size: 22px;
  color: #409eff;
  flex-shrink: 0;
  margin-top: 2px;
}

.penalty-note strong {
  display: block;
  font-size: 14px;
  color: #303133;
  margin-bottom: 4px;
}

.penalty-note p {
  margin: 0;
  font-size: 13px;
  color: #606266;
  line-height: 1.5;
}

@media (max-width: 900px) {
  .config-grid {
    grid-template-columns: 1fr;
  }
}
</style>

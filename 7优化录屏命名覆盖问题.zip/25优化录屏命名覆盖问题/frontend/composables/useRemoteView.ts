import { ref, shallowRef } from "vue";
import {
  Room,
  RoomEvent,
  Track,
  ConnectionState,
  type RemoteParticipant,
  type RemoteTrack,
  type RemoteTrackPublication,
} from "livekit-client";
import { remoteViewApi } from "@api/index";
import type { RemoteViewStartSession } from "@api/types";
import { ElMessage } from "element-plus";

export function useRemoteView() {
  const room = shallowRef<Room | null>(null);
  const connectionState = ref<ConnectionState>(ConnectionState.Disconnected);
  const sessionInfo = ref<RemoteViewStartSession | null>(null);
  const sessionStatus = ref("");
  const stats = ref({
    fps: 0,
    bitrateKbps: 0,
    encoder: "",
  });

  let reconnectAttempts = 0;
  let reconnectTimer: number | null = null;
  let viewGeneration = 0;
  let activeVideoContainer: HTMLElement | null = null;
  const MAX_RECONNECT = 5;

  const clearVideoContainer = (container?: HTMLElement | null) => {
    const target = container ?? activeVideoContainer;
    target?.replaceChildren();
  };

  const attachVideo = (container: HTMLElement, track: RemoteTrack) => {
    const element = track.attach();
    element.className = "remote-video-player";
    container.replaceChildren(element);
  };

  const clearReconnectTimer = () => {
    if (reconnectTimer != null) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
  };

  const attachExistingVideoTracks = (
    lkRoom: Room,
    container: HTMLElement,
  ) => {
    for (const participant of lkRoom.remoteParticipants.values()) {
      attachParticipantVideo(participant, container);
    }
  };

  const attachParticipantVideo = (
    participant: RemoteParticipant,
    container: HTMLElement,
  ) => {
    for (const publication of participant.trackPublications.values()) {
      const pub = publication as RemoteTrackPublication;
      if (pub.track && pub.kind === Track.Kind.Video) {
        attachVideo(container, pub.track as RemoteTrack);
      }
    }
  };

  const bindRoomEvents = (
    lkRoom: Room,
    deviceId: string,
    videoContainer: HTMLElement,
    generation: number,
  ) => {
    lkRoom.on(RoomEvent.TrackSubscribed, (track) => {
      if (generation !== viewGeneration) return;
      if (track.kind === Track.Kind.Video) {
        attachVideo(videoContainer, track as RemoteTrack);
      }
    });

    lkRoom.on(RoomEvent.TrackUnsubscribed, (track) => {
      if (generation !== viewGeneration) return;
      if (track.kind === Track.Kind.Video) {
        track.detach();
        clearVideoContainer(videoContainer);
      }
    });

    lkRoom.on(RoomEvent.ConnectionStateChanged, (state) => {
      if (generation !== viewGeneration) return;
      connectionState.value = state;
      if (state === ConnectionState.Connected) {
        reconnectAttempts = 0;
        sessionStatus.value = "active";
        attachExistingVideoTracks(lkRoom, videoContainer);
      } else if (state === ConnectionState.Reconnecting) {
        sessionStatus.value = "reconnecting";
      }
    });

    //  transient WebRTC 抖动由 LiveKit SDK 自动重连；不要 stop/start 后端会话（会重建 Ingress 导致 RTMP 断流）
    lkRoom.on(RoomEvent.Reconnected, () => {
      if (generation !== viewGeneration) return;
      reconnectAttempts = 0;
      sessionStatus.value = "active";
      attachExistingVideoTracks(lkRoom, videoContainer);
    });

    lkRoom.on(RoomEvent.Disconnected, () => {
      if (generation !== viewGeneration) return;
      sessionStatus.value = "disconnected";
      console.warn("[RemoteView] LiveKit disconnected; waiting for SDK reconnect or manual stop");
    });
  };

  const startView = async (deviceId: string, videoContainer: HTMLElement) => {
    let startedSessionId: string | undefined;
    const generation = ++viewGeneration;
    activeVideoContainer = videoContainer;
    clearVideoContainer(videoContainer);

    try {
      const { data } = await remoteViewApi.start(deviceId);
      if (generation !== viewGeneration) {
        await remoteViewApi.stop(deviceId, data.sessionId);
        throw new Error("Remote view start cancelled");
      }

      sessionInfo.value = data;
      sessionStatus.value = "starting";
      startedSessionId = data.sessionId;

      const lkRoom = new Room({
        adaptiveStream: true,
        dynacast: false,
        disconnectOnPageLeave: true,
      });

      bindRoomEvents(lkRoom, deviceId, videoContainer, generation);

      await lkRoom.connect(data.livekitUrl, data.viewerToken);
      if (generation !== viewGeneration) {
        await lkRoom.disconnect();
        throw new Error("Remote view start cancelled");
      }

      room.value = lkRoom;
      sessionStatus.value = "active";
      attachExistingVideoTracks(lkRoom, videoContainer);
      return data;
    } catch (error) {
      if (startedSessionId) {
        try {
          await remoteViewApi.stop(deviceId, startedSessionId);
        } catch {
          // ignore cleanup errors
        }
      }
      sessionInfo.value = null;
      sessionStatus.value = "";
      throw error;
    }
  };

  const stopView = async (deviceId: string) => {
    viewGeneration += 1;
    reconnectAttempts = MAX_RECONNECT;
    clearReconnectTimer();
    const container = activeVideoContainer;
    if (room.value) {
      await room.value.disconnect();
      room.value = null;
    }
    clearVideoContainer(container);
    activeVideoContainer = null;
    if (sessionInfo.value?.sessionId) {
      await remoteViewApi.stop(deviceId, sessionInfo.value.sessionId);
    }
    sessionInfo.value = null;
    sessionStatus.value = "";
    connectionState.value = ConnectionState.Disconnected;
    stats.value = { fps: 0, bitrateKbps: 0, encoder: "" };
  };

  const refreshStatus = async (deviceId: string) => {
    const { data } = await remoteViewApi.getStatus(deviceId);
    sessionStatus.value = data.status || (data.isActive ? "active" : "");
    if (data.stats) {
      stats.value = {
        fps: data.stats.fps,
        bitrateKbps: data.stats.bitrateKbps,
        encoder: data.stats.encoder,
      };
    }
    return data;
  };

  const applyRemoteStats = (payload: {
    fps?: number;
    bitrateKbps?: number;
    encoder?: string;
  }) => {
    stats.value = {
      fps: payload.fps ?? stats.value.fps,
      bitrateKbps: payload.bitrateKbps ?? stats.value.bitrateKbps,
      encoder: payload.encoder ?? stats.value.encoder,
    };
  };

  return {
    room,
    connectionState,
    sessionInfo,
    sessionStatus,
    stats,
    startView,
    stopView,
    refreshStatus,
    applyRemoteStats,
  };
}

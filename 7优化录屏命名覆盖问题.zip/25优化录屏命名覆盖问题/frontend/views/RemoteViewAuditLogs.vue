<template>
  <div class="remote-view-audit" v-permission="'device:remote'">
    <el-card shadow="hover">
      <template #header>
        <div class="card-header">
          <span>远程查看审计日志</span>
          <div class="actions">
            <el-select
              v-model="filters.deviceId"
              placeholder="筛选员工（可选）"
              clearable
              filterable
              style="width: 240px"
              @change="onFilterChange"
            >
              <el-option
                v-for="device in devices"
                :key="device.id"
                :label="formatDeviceOption(device)"
                :value="device.id"
              />
            </el-select>
            <el-button @click="loadLogs" :loading="loading">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
          </div>
        </div>
      </template>

      <el-table :data="logs" v-loading="loading" stripe>
        <el-table-column prop="createdAt" label="时间" width="180">
          <template #default="{ row }">
            {{ formatDateTime(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column prop="operatorName" label="操作人" width="140" />
        <el-table-column prop="action" label="动作" width="140">
          <template #default="{ row }">
            <el-tag size="small" :type="getActionTagType(row.action)">
              {{ row.action }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="员工姓名" min-width="140" show-overflow-tooltip>
          <template #default="{ row }">
            {{ formatEmployeeName(row) }}
          </template>
        </el-table-column>
        <el-table-column prop="sessionId" label="会话 ID" min-width="200" show-overflow-tooltip />
        <el-table-column prop="clientIp" label="客户端 IP" width="140" />
        <el-table-column prop="detail" label="详情" min-width="260" show-overflow-tooltip />
      </el-table>

      <div class="pager">
        <el-pagination
          background
          layout="total, prev, pager, next"
          :total="total"
          :page-size="pageSize"
          :current-page="page"
          @current-change="onPageChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from "vue";
import { Refresh } from "@element-plus/icons-vue";
import { ElMessage } from "element-plus";
import { remoteViewApi, deviceApi } from "@api/index";
import type { Device, RemoteViewAuditLog } from "@api/types";
import { formatDateTime } from "@api/format";

const loading = ref(false);
const logs = ref<RemoteViewAuditLog[]>([]);
const devices = ref<Device[]>([]);
const total = ref(0);
const page = ref(1);
const pageSize = ref(20);
const filters = reactive<{ deviceId: string | undefined }>({ deviceId: "" });

const getFilterDeviceId = () => {
  const id = filters.deviceId;
  if (id == null || typeof id !== "string") return undefined;
  const trimmed = id.trim();
  return trimmed || undefined;
};

const formatEmployeeName = (row: RemoteViewAuditLog) => {
  if (row.employeeName?.trim()) {
    return row.employeeNumber?.trim()
      ? `${row.employeeName}（${row.employeeNumber}）`
      : row.employeeName;
  }
  if (row.hostname?.trim()) return row.hostname;
  if (row.deviceId) return row.deviceId.slice(-8);
  return "未知";
};

const formatDeviceOption = (device: Device) => {
  const name = device.employeeName?.trim() || device.hostname?.trim() || "未命名";
  return device.employeeNumber?.trim()
    ? `${name}（${device.employeeNumber}）`
    : name;
};

const getActionTagType = (action: string) => {
  switch (action) {
    case "开始远程查看":
      return "success";
    case "加入查看":
      return "primary";
    case "离开查看":
      return "warning";
    case "结束远程查看":
      return "info";
    default:
      return "info";
  }
};

const loadDevices = async () => {
  try {
    const { data } = await deviceApi.listAll();
    devices.value = data.items || [];
  } catch {
    devices.value = [];
  }
};

const loadLogs = async () => {
  loading.value = true;
  try {
    const { data } = await remoteViewApi.listAuditLogs({
      page: page.value,
      pageSize: pageSize.value,
      deviceId: getFilterDeviceId(),
    });
    logs.value = data.items || [];
    total.value = data.total || 0;
  } catch (error: any) {
    ElMessage.error(error.message || "加载审计日志失败");
  } finally {
    loading.value = false;
  }
};

const onFilterChange = (value: string | undefined) => {
  filters.deviceId = value ?? "";
  page.value = 1;
  loadLogs();
};

const onPageChange = (nextPage: number) => {
  page.value = nextPage;
  loadLogs();
};

onMounted(async () => {
  await loadDevices();
  await loadLogs();
});
</script>

<style scoped>
.remote-view-audit {
  padding: 16px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.pager {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}
</style>

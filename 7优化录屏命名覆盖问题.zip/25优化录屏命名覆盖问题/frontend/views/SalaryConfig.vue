<template>
  <div class="salary-config-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <div class="page-content">
      <div class="page-hero">
        <div class="hero-left">
          <div class="hero-icon" :class="activeConfigKey">
            <el-icon :size="28"><Setting /></el-icon>
          </div>
          <div>
            <h2>工资配置</h2>
            <p>按工作地点匹配配置，保存后在「计算工资」中自动套用</p>
          </div>
        </div>
        <div class="hero-actions">
          <el-button size="large" class="add-btn" @click="openCreateDialog">
            <el-icon><Plus /></el-icon>
            新增配置
          </el-button>
          <el-button type="primary" size="large" class="save-btn" :loading="saving" @click="saveCurrent">
            <el-icon><Check /></el-icon>
            保存{{ activeConfig?.configName || "" }}配置
          </el-button>
        </div>
      </div>

      <div class="mode-switch">
        <button
          v-for="cfg in configs"
          :key="cfg.configKey"
          type="button"
          class="mode-btn"
          :class="{ active: activeConfigKey === cfg.configKey }"
          @click="activeConfigKey = cfg.configKey"
        >
          <el-icon><component :is="tabIcon(cfg)" /></el-icon>
          <span>{{ cfg.configName }}</span>
          <el-icon
            v-if="!cfg.isBuiltin"
            class="tab-close"
            @click.stop="confirmDelete(cfg)"
          >
            <Close />
          </el-icon>
        </button>
      </div>

      <el-card v-if="activeConfig" class="config-card" shadow="never">
        <div class="mode-banner" :class="bannerClass">
          <div class="banner-text">
            <strong>{{ activeConfig.configName }}</strong>
            <span>员工工作地点为「{{ activeConfig.configName }}」或包含该名称时使用本配置</span>
          </div>
          <el-tag effect="dark" round size="small">
            {{ activeConfig.isBuiltin ? "内置" : "自定义" }}
          </el-tag>
        </div>

        <SalaryConfigForm v-model="activeConfig" />
      </el-card>

      <el-empty v-else-if="!loading" description="暂无配置，请点击「新增配置」" />
    </div>

    <el-dialog v-model="createDialogVisible" title="新增工资配置" width="420px" destroy-on-close>
      <el-form @submit.prevent="submitCreate">
        <el-form-item label="配置名称" required>
          <el-input
            v-model="newConfigName"
            placeholder="例如：外包、兼职、海外"
            maxlength="32"
            show-word-limit
            @keyup.enter="submitCreate"
          />
        </el-form-item>
        <p class="create-hint">配置字段与现有配置相同；员工「工作地点」匹配该名称时将自动套用。</p>
      </el-form>
      <template #footer>
        <el-button @click="createDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="creating" @click="submitCreate">创建</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { Setting, Check, Plus, Close, House, OfficeBuilding, Document } from "@element-plus/icons-vue";
import adminApi, { type SalaryWorkConfig } from "@api/admin_api";
import SalaryConfigForm from "@/components/salary/SalaryConfigForm.vue";

const loading = ref(false);
const saving = ref(false);
const creating = ref(false);
const configs = ref<SalaryWorkConfig[]>([]);
const activeConfigKey = ref("");
const createDialogVisible = ref(false);
const newConfigName = ref("");

const defaultConfig = (key: string, name: string, isBuiltin = false): SalaryWorkConfig => ({
  configKey: key,
  configName: name,
  workMode: key,
  totalIncrease: 0,
  fullAttendanceDays: 0,
  fullAttendanceAmount: 0,
  exchangeRate: 0,
  performanceFullScoreAmount: 0,
  protectionFee: 0,
  isBuiltin,
});

const normalizeConfig = (item: SalaryWorkConfig): SalaryWorkConfig => ({
  ...defaultConfig(item.configKey || item.workMode || "", item.configName || ""),
  ...item,
  configKey: item.configKey || item.workMode || "",
  configName: item.configName || item.configKey || "",
  workMode: item.configKey || item.workMode || "",
});

const activeConfig = computed({
  get: () => configs.value.find((c) => c.configKey === activeConfigKey.value),
  set: (val) => {
    if (!val) return;
    const idx = configs.value.findIndex((c) => c.configKey === val.configKey);
    if (idx >= 0) configs.value[idx] = val;
  },
});

const bannerClass = computed(() => {
  const key = activeConfigKey.value;
  if (key === "remote") return "remote";
  if (key === "onsite") return "onsite";
  return "custom";
});

const tabIcon = (cfg: SalaryWorkConfig) => {
  if (cfg.configKey === "remote") return House;
  if (cfg.configKey === "onsite") return OfficeBuilding;
  return Document;
};

const loadConfigs = async () => {
  loading.value = true;
  try {
    const { data } = await adminApi.getSalaryConfigs();
    const items = (data.items || []).map(normalizeConfig);
    configs.value = items.length ? items : [
      defaultConfig("remote", "居家", true),
      defaultConfig("onsite", "现场", true),
    ];
    if (!activeConfigKey.value || !configs.value.some((c) => c.configKey === activeConfigKey.value)) {
      activeConfigKey.value = configs.value[0]?.configKey || "";
    }
  } catch (error: any) {
    ElMessage.error(error.message || "加载工资配置失败");
  } finally {
    loading.value = false;
  }
};

const saveCurrent = async () => {
  const cfg = activeConfig.value;
  if (!cfg) return;
  saving.value = true;
  try {
    await adminApi.upsertSalaryConfig({ ...cfg, configKey: cfg.configKey, workMode: cfg.configKey });
    ElMessage.success("配置已保存");
    await loadConfigs();
    activeConfigKey.value = cfg.configKey;
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    saving.value = false;
  }
};

const openCreateDialog = () => {
  newConfigName.value = "";
  createDialogVisible.value = true;
};

const submitCreate = async () => {
  const name = newConfigName.value.trim();
  if (!name) {
    ElMessage.warning("请输入配置名称");
    return;
  }
  creating.value = true;
  try {
    const { data } = await adminApi.createSalaryConfig({ configName: name });
    const created = normalizeConfig(data);
    configs.value.push(created);
    activeConfigKey.value = created.configKey;
    createDialogVisible.value = false;
    ElMessage.success(`已创建「${created.configName}」配置`);
  } catch (error: any) {
    ElMessage.error(error.message || "创建失败");
  } finally {
    creating.value = false;
  }
};

const confirmDelete = async (cfg: SalaryWorkConfig) => {
  if (cfg.isBuiltin) return;
  try {
    await ElMessageBox.confirm(
      `确定删除「${cfg.configName}」配置？删除后不可恢复。`,
      "删除配置",
      { type: "warning", confirmButtonText: "删除", cancelButtonText: "取消" },
    );
    await adminApi.deleteSalaryConfig(cfg.configKey);
    configs.value = configs.value.filter((c) => c.configKey !== cfg.configKey);
    if (activeConfigKey.value === cfg.configKey) {
      activeConfigKey.value = configs.value[0]?.configKey || "";
    }
    ElMessage.success("已删除");
  } catch {
    /* cancelled */
  }
};

watch(activeConfigKey, (key) => {
  if (!key && configs.value.length) {
    activeConfigKey.value = configs.value[0].configKey;
  }
});

onMounted(loadConfigs);
</script>

<style scoped>
.salary-config-page {
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
}

.bg-decoration {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.35;
  animation: float 20s ease-in-out infinite;
}

.blob-1 {
  width: 480px;
  height: 480px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -180px;
  right: -80px;
}

.blob-2 {
  width: 520px;
  height: 520px;
  background: linear-gradient(135deg, #43e97b, #38f9d7);
  bottom: -220px;
  left: -120px;
  animation-delay: -6s;
}

.blob-3 {
  width: 360px;
  height: 360px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 35%;
  left: 28%;
  animation-delay: -12s;
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(24px, -24px) scale(1.04); }
  66% { transform: translate(-16px, 16px) scale(0.96); }
}

.page-content {
  position: relative;
  z-index: 1;
  padding: 4px 0 24px;
}

.page-hero {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.hero-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.hero-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.hero-icon {
  width: 56px;
  height: 56px;
  border-radius: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
  background: linear-gradient(135deg, #667eea, #764ba2);
}

.hero-icon.remote {
  background: linear-gradient(135deg, #667eea, #764ba2);
}

.hero-icon.onsite {
  background: linear-gradient(135deg, #f093fb, #f5576c);
}

.page-hero h2 {
  margin: 0 0 6px;
  font-size: 22px;
  font-weight: 700;
  color: #1a1a2e;
}

.page-hero p {
  margin: 0;
  font-size: 13px;
  color: #909399;
}

.add-btn,
.save-btn {
  border-radius: 12px;
  padding: 0 22px;
  font-weight: 600;
}

.save-btn {
  box-shadow: 0 4px 14px rgba(64, 158, 255, 0.35);
}

.mode-switch {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 6px;
  background: rgba(255, 255, 255, 0.85);
  backdrop-filter: blur(8px);
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.6);
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
  margin-bottom: 16px;
}

.mode-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  border: none;
  border-radius: 10px;
  background: transparent;
  color: #606266;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.25s ease;
}

.mode-btn:hover {
  color: #303133;
  background: rgba(64, 158, 255, 0.06);
}

.mode-btn.active {
  background: linear-gradient(135deg, #409eff, #337ecc);
  color: #fff;
  box-shadow: 0 4px 12px rgba(64, 158, 255, 0.35);
}

.tab-close {
  margin-left: 4px;
  font-size: 12px;
  opacity: 0.65;
  border-radius: 50%;
  padding: 2px;
}

.tab-close:hover {
  opacity: 1;
  background: rgba(255, 255, 255, 0.25);
}

.mode-btn.active .tab-close:hover {
  background: rgba(0, 0, 0, 0.12);
}

.config-card {
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.5);
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(12px);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
}

.config-card :deep(.el-card__body) {
  padding: 24px 28px 28px;
}

.mode-banner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 14px 18px;
  border-radius: 14px;
  margin-bottom: 24px;
}

.mode-banner.remote {
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.12), rgba(118, 75, 162, 0.08));
  border: 1px solid rgba(102, 126, 234, 0.2);
}

.mode-banner.onsite {
  background: linear-gradient(135deg, rgba(240, 147, 251, 0.12), rgba(245, 87, 108, 0.08));
  border: 1px solid rgba(245, 87, 108, 0.2);
}

.mode-banner.custom {
  background: linear-gradient(135deg, rgba(79, 172, 254, 0.12), rgba(0, 242, 254, 0.08));
  border: 1px solid rgba(79, 172, 254, 0.2);
}

.banner-text {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.banner-text strong {
  font-size: 15px;
  color: #303133;
}

.banner-text span {
  font-size: 12px;
  color: #909399;
}

.create-hint {
  margin: 0;
  font-size: 12px;
  color: #909399;
  line-height: 1.5;
}

@media (max-width: 768px) {
  .page-hero {
    flex-direction: column;
    align-items: stretch;
  }

  .hero-actions {
    width: 100%;
  }

  .hero-actions .el-button {
    flex: 1;
  }

  .mode-btn {
    flex: 1;
    justify-content: center;
    min-width: calc(50% - 8px);
  }
}
</style>

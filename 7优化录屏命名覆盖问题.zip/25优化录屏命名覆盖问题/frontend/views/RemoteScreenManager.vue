<!-- frontend/views/RemoteScreenManager.vue -->
<template>
  <div v-if="canAccessRemote" class="remote-screen">
    <el-drawer v-model="drawerVisible" title="在线员工" size="320px" direction="ltr">
      <div class="employee-list" v-loading="loadingEmployees">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索员工姓名/设备名"
          :prefix-icon="Search"
          clearable
          size="small"
          class="search-input"
        />

        <el-empty v-if="filteredDevices.length === 0" description="暂无在线员工" />

        <div
          v-for="device in filteredDevices"
          :key="device.id"
          class="employee-item"
          :class="{ active: currentDeviceId === device.id }"
          @click="selectDevice(device)"
        >
          <div class="employee-info">
            <div class="employee-name">
              {{ device.employeeName || device.hostname || "未知" }}
            </div>
            <div class="employee-detail">{{ device.hostname }}</div>
          </div>
          <el-button
            type="primary"
            size="small"
            :loading="connectingDeviceId === device.id"
            @click.stop="connectToDevice(device)"
          >
            查看
          </el-button>
        </div>
      </div>

      <template #footer>
        <div class="drawer-footer">
          <el-button @click="refreshDevices" :loading="refreshing" size="small">
            <el-icon><Refresh /></el-icon>刷新
          </el-button>
          <span class="online-count">在线: {{ onlineDevices.length }}</span>
        </div>
      </template>
    </el-drawer>

    <div class="main-area">
      <div class="toolbar">
        <el-button-group>
          <el-button @click="drawerVisible = true">
            <el-icon><Grid /></el-icon>员工列表
          </el-button>
          <el-button
            v-if="currentDeviceId"
            :type="isViewing ? 'danger' : 'primary'"
            @click="toggleView"
            :loading="connecting"
          >
            <el-icon><VideoCamera v-if="!isViewing" /><VideoPause v-else /></el-icon>
            {{ isViewing ? "停止查看" : "开始查看" }}
          </el-button>
        </el-button-group>

        <div class="status-info" v-if="isViewing">
          <el-tag size="small" type="success" effect="plain">
            {{ stats.fps > 0 ? stats.fps : "--" }} fps
          </el-tag>
          <el-tag size="small" type="info" effect="plain">
            {{ stats.bitrateKbps || 0 }} kbps
          </el-tag>
          <el-tag v-if="stats.encoder" size="small" type="warning" effect="plain">
            {{ stats.encoder }}
          </el-tag>
          <el-tag size="small" :type="connectionTagType" effect="dark">
            {{ connectionLabel }}
          </el-tag>
        </div>
      </div>

      <div class="screen-container">
        <div class="video-host">
          <div ref="videoStage" class="remote-video-stage"></div>
        </div>
        <div v-show="showPlaceholder" class="screen-placeholder">
          <el-empty :description="placeholderText" />
        </div>
        <div v-show="connecting" class="loading-mask">
          <el-icon class="is-loading" size="40"><Loading /></el-icon>
          <span>连接中...</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, nextTick } from "vue";
import { ElMessage } from "element-plus";
import {
  Grid,
  VideoCamera,
  VideoPause,
  Refresh,
  Search,
  Loading,
} from "@element-plus/icons-vue";
import { ConnectionState } from "livekit-client";
import { deviceApi } from "@api/index";
import type { Device } from "@api/types";
import { useRemoteView } from "@/composables/useRemoteView";
import { useWebSocketStore } from "@store/websocket";
import { useUserStore } from "@store/user";
import { hasAnyPermission } from "@store/permission";

const REMOTE_DEVICE_KEY = "remoteView.selectedDeviceId";
const REMOTE_NAME_KEY = "remoteView.selectedEmployeeName";

const {
  connectionState,
  sessionStatus,
  stats,
  startView,
  stopView,
  refreshStatus,
  applyRemoteStats,
} = useRemoteView();

const wsStore = useWebSocketStore();
const userStore = useUserStore();

const canAccessRemote = computed(
  () => userStore.role === "admin" || hasAnyPermission(["device:remote"]),
);

const drawerVisible = ref(false);
const loadingEmployees = ref(false);
const refreshing = ref(false);
const connecting = ref(false);
const isViewing = ref(false);
const currentDeviceId = ref("");
const currentEmployeeName = ref("");
const searchKeyword = ref("");
const devices = ref<Device[]>([]);
const connectingDeviceId = ref("");
const videoStage = ref<HTMLElement>();
let statsTimer: number | null = null;
let viewOpChain: Promise<void> = Promise.resolve();

const persistSelectedDevice = (deviceId: string, employeeName: string) => {
  sessionStorage.setItem(REMOTE_DEVICE_KEY, deviceId);
  sessionStorage.setItem(REMOTE_NAME_KEY, employeeName);
};

const restoreSelectedDevice = () => {
  const savedId = sessionStorage.getItem(REMOTE_DEVICE_KEY) || "";
  const savedName = sessionStorage.getItem(REMOTE_NAME_KEY) || "";
  if (savedId) {
    currentDeviceId.value = savedId;
    currentEmployeeName.value = savedName;
  }
};

const runViewOp = async <T>(operation: () => Promise<T>): Promise<T> => {
  const op = viewOpChain.then(operation);
  viewOpChain = op.then(
    () => undefined,
    () => undefined,
  );
  return op;
};

const showPlaceholder = computed(() => !isViewing.value);
const placeholderText = computed(() =>
  currentDeviceId.value
    ? `点击开始查看 ${currentEmployeeName.value || "该员工"}`
    : "请选择员工",
);

const resolveVideoStage = async (): Promise<HTMLElement | null> => {
  if (videoStage.value) return videoStage.value;
  await nextTick();
  return videoStage.value ?? null;
};

const onlineDevices = computed(() =>
  devices.value.filter((d) => d.onlineStatus === "online"),
);

const filteredDevices = computed(() => {
  if (!searchKeyword.value) return onlineDevices.value;
  const keyword = searchKeyword.value.toLowerCase();
  return onlineDevices.value.filter(
    (d) =>
      d.employeeName?.toLowerCase().includes(keyword) ||
      d.hostname?.toLowerCase().includes(keyword),
  );
});

const connectionLabel = computed(() => {
  if (sessionStatus.value === "starting") return "推流启动中";
  if (sessionStatus.value === "failed") return "推流失败";
  switch (connectionState.value) {
    case ConnectionState.Connected:
      return "已连接";
    case ConnectionState.Connecting:
      return "连接中";
    case ConnectionState.Reconnecting:
      return "重连中";
    default:
      return "未连接";
  }
});

const connectionTagType = computed(() => {
  if (sessionStatus.value === "failed") return "danger";
  if (sessionStatus.value === "starting") return "warning";
  if (connectionState.value === ConnectionState.Connected) return "success";
  if (connectionState.value === ConnectionState.Connecting) return "warning";
  return "info";
});

const refreshDevices = async () => {
  refreshing.value = true;
  loadingEmployees.value = true;
  try {
    const { data } = await deviceApi.listAll();
    devices.value = data.items || [];
  } catch (error: any) {
    ElMessage.error(error.message || "加载失败");
  } finally {
    refreshing.value = false;
    loadingEmployees.value = false;
  }
};

const selectDevice = async (device: Device) => {
  drawerVisible.value = false;

  if (device.id === currentDeviceId.value && !isViewing.value) {
    currentEmployeeName.value = device.employeeName || device.hostname || "未知";
    persistSelectedDevice(device.id, currentEmployeeName.value);
    return;
  }

  if (isViewing.value) {
    const activeDeviceId = currentDeviceId.value;
    if (activeDeviceId && activeDeviceId !== device.id) {
      await disconnect(activeDeviceId);
    } else if (activeDeviceId === device.id) {
      return;
    }
  }

  currentDeviceId.value = device.id;
  currentEmployeeName.value = device.employeeName || device.hostname || "未知";
  persistSelectedDevice(currentDeviceId.value, currentEmployeeName.value);
};

const connectToDevice = async (device: Device) => {
  if (device.onlineStatus !== "online") {
    ElMessage.warning("设备不在线");
    return;
  }
  await runViewOp(async () => {
    await selectDevice(device);
    await connect();
  });
};

const connect = async () => {
  if (!currentDeviceId.value) {
    restoreSelectedDevice();
  }
  if (!currentDeviceId.value) {
    ElMessage.warning("请先选择员工");
    return;
  }

  const stage = await resolveVideoStage();
  if (!stage) {
    ElMessage.warning("播放器未就绪，请稍后重试");
    return;
  }

  connecting.value = true;
  connectingDeviceId.value = currentDeviceId.value;
  try {
    await startView(currentDeviceId.value, stage);
    isViewing.value = true;
    startStatsPolling();
    ElMessage.success(`正在查看 ${currentEmployeeName.value} 的屏幕`);
  } catch (error: any) {
    ElMessage.error(error.message || "连接失败");
  } finally {
    connecting.value = false;
    connectingDeviceId.value = "";
  }
};

const disconnect = async (deviceId?: string) => {
  const targetId = deviceId || currentDeviceId.value;
  if (!targetId) return;
  stopStatsPolling();
  try {
    await stopView(targetId);
  } catch (error: any) {
    console.error(error);
  }
  isViewing.value = false;
  await nextTick();
};

const toggleView = async () => {
  await runViewOp(async () => {
    if (isViewing.value) {
      await disconnect();
    } else {
      await connect();
    }
  });
};

const startStatsPolling = () => {
  stopStatsPolling();
  statsTimer = window.setInterval(async () => {
    if (!currentDeviceId.value || !isViewing.value) return;
    if (wsStore.connected) return;
    try {
      const data = await refreshStatus(currentDeviceId.value);
      if (data.status === "failed" || (!data.isActive && sessionStatus.value === "failed")) {
        ElMessage.error("远程推流失败，已停止查看");
        await runViewOp(() => disconnect());
      }
    } catch {
      // ignore polling errors
    }
  }, 15000);
};

const onRemoteViewStats = (event: Event) => {
  const detail = (event as CustomEvent).detail as {
    deviceId?: string;
    fps?: number;
    bitrateKbps?: number;
    encoder?: string;
  };
  if (!detail.deviceId || detail.deviceId !== currentDeviceId.value || !isViewing.value) {
    return;
  }
  applyRemoteStats(detail);
};

const onRemoteViewEvent = async (event: Event) => {
  const detail = (event as CustomEvent).detail as {
    deviceId?: string;
    event?: string;
    sessionId?: string;
    detail?: string;
  };
  if (!detail.deviceId || detail.deviceId !== currentDeviceId.value || !isViewing.value) {
    return;
  }
  if (detail.event === "failed") {
    ElMessage.error(detail.detail || "远程推流失败，已停止查看");
    await runViewOp(() => disconnect());
  }
};

const stopStatsPolling = () => {
  if (statsTimer) {
    clearInterval(statsTimer);
    statsTimer = null;
  }
};

onMounted(() => {
  restoreSelectedDevice();
  refreshDevices();
  window.addEventListener("remote-view-stats", onRemoteViewStats);
  window.addEventListener("remote-view-event", onRemoteViewEvent);
});

onUnmounted(() => {
  stopStatsPolling();
  window.removeEventListener("remote-view-stats", onRemoteViewStats);
  window.removeEventListener("remote-view-event", onRemoteViewEvent);
  if (isViewing.value && currentDeviceId.value) {
    stopView(currentDeviceId.value).catch(console.error);
  }
});
</script>

<style scoped lang="scss">
.remote-screen {
  display: flex;
  height: calc(100vh - 100px);
  min-height: 480px;
  margin: -20px;
  width: calc(100% + 40px);
  background: #0f1115;
}

.main-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
}

.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 16px;
  background: #171a21;
  border-bottom: 1px solid #2a2f3a;
}

.status-info {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.screen-container {
  position: relative;
  flex: 1;
  min-height: 0;
  background: #000;
  overflow: hidden;
}

.video-host {
  position: absolute;
  inset: 0;
  z-index: 0;
}

.video-host .remote-video-stage {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.screen-container :deep(.remote-video-player) {
  width: 100%;
  height: 100%;
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  display: block;
  background: #000;
}

.screen-placeholder,
.loading-mask {
  position: absolute;
  inset: 0;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  color: #9aa4b2;
  gap: 12px;
  pointer-events: none;
}

.loading-mask {
  z-index: 2;
  pointer-events: auto;
  background: rgba(0, 0, 0, 0.45);
}

.employee-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.employee-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  border-radius: 8px;
  cursor: pointer;

  &.active,
  &:hover {
    background: #f5f7fa;
  }
}

.employee-name {
  font-weight: 600;
}

.employee-detail {
  font-size: 12px;
  color: #909399;
}

.drawer-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.search-input {
  margin-bottom: 12px;
}
</style>

<template>
  <div class="overview-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
    </div>

    <el-card class="toolbar-card" shadow="never">
      <div class="toolbar-row">
        <h2 class="page-title">截图概览</h2>
        <el-form :inline="true" class="toolbar-form">
          <el-form-item>
            <el-radio-group v-model="searchMode" size="small" @change="handleSearchModeChange">
              <el-radio-button value="date">日期</el-radio-button>
              <el-radio-button value="datetime">日期时间</el-radio-button>
            </el-radio-group>
          </el-form-item>

          <el-form-item v-if="searchMode === 'date'">
            <el-date-picker
              v-model="dateRange"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              value-format="YYYY-MM-DD"
              :shortcuts="dateShortcuts"
              clearable
              size="default"
              style="width: 240px"
            />
          </el-form-item>

          <el-form-item v-if="searchMode === 'datetime'">
            <el-date-picker
              v-model="dateTimeRange"
              type="datetimerange"
              range-separator="至"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
              value-format="YYYY-MM-DD HH:mm:ss"
              clearable
              size="default"
              style="width: 320px"
            />
          </el-form-item>

          <el-form-item>
            <div class="auto-refresh-group">
              <span class="auto-refresh-label">自动刷新</span>
              <el-switch
                v-model="autoRefresh"
                inline-prompt
                active-text="开"
                inactive-text="关"
                @change="handleAutoRefreshChange"
              />
              <el-select
                v-if="autoRefresh"
                v-model="refreshInterval"
                size="default"
                style="width: 96px"
                @change="handleRefreshIntervalChange"
              >
                <el-option label="15秒" :value="15" />
                <el-option label="30秒" :value="30" />
                <el-option label="60秒" :value="60" />
                <el-option label="2分" :value="120" />
              </el-select>
            </div>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" :loading="loading" @click="handleSearch">
              <el-icon><Search /></el-icon>
              搜索
            </el-button>
            <el-button @click="handleReset">重置</el-button>
          </el-form-item>

          <el-form-item class="limit-item">
            <el-input-number
              v-model="displayLimit"
              :min="1"
              :max="30"
              :step="1"
              size="default"
              @change="handleLimitChange"
            />
            <span class="limit-suffix">张</span>
          </el-form-item>

          <el-form-item>
            <el-button :loading="loading" @click="() => loadOverview()">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>

    <div class="overview-list" v-loading="loading">
      <el-empty
        v-if="!loading && rows.length === 0"
        description="暂无员工截图数据"
      />

      <div
        v-for="row in rows"
        :key="row.deviceId"
        class="employee-row"
      >
        <div class="employee-info">
          <div class="employee-name">
            {{ row.employeeName || row.hostname || "未命名员工" }}
          </div>
          <div class="employee-meta">
            <span v-if="row.employeeNumber">{{ row.employeeNumber }}</span>
            <span class="total-count">共 {{ row.totalCount }} 张</span>
          </div>
        </div>

        <div class="gallery-wrap">
          <div v-if="row.screenshots.length === 0" class="no-shots">
            暂无截图
          </div>
          <div v-else class="gallery-nav-wrap">
            <button
              v-show="galleryScrollStates[row.deviceId]?.left"
              type="button"
              class="gallery-nav-btn"
              @click="scrollGallery(row.deviceId, -1)"
            >
              <el-icon><ArrowLeft /></el-icon>
            </button>
            <div
              :ref="getGalleryRef(row.deviceId)"
              class="gallery-scroll"
            >
              <div
                v-for="(shot, index) in row.screenshots"
                :key="shot.id"
                class="thumb-item"
                :class="{ latest: index === 0 }"
                @click="openViewer(row, index)"
              >
                <div class="thumb-frame">
                  <img
                    v-if="imageUrlMap[shot.id]"
                    :src="imageUrlMap[shot.id]"
                    :alt="formatTimeOnly(shot.capturedAt)"
                    loading="lazy"
                  />
                  <div v-else class="thumb-placeholder">
                    <el-icon class="is-loading"><Loading /></el-icon>
                  </div>
                </div>
                <div class="thumb-time">{{ formatTimeOnly(shot.capturedAt) }}</div>
              </div>
            </div>
            <button
              v-show="galleryScrollStates[row.deviceId]?.right"
              type="button"
              class="gallery-nav-btn"
              @click="scrollGallery(row.deviceId, 1)"
            >
              <el-icon><ArrowRight /></el-icon>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 全屏查看器 -->
    <Teleport to="body">
      <Transition name="viewer-fade">
        <div
          v-if="viewerVisible"
          class="viewer-overlay"
          tabindex="0"
          ref="viewerOverlayRef"
          @click.self="closeViewer"
          @keydown="handleViewerKeydown"
          @wheel.prevent="handleViewerWheel"
        >
          <button class="viewer-close" type="button" @click="closeViewer">
            <el-icon><Close /></el-icon>
          </button>

          <button
            class="viewer-nav prev"
            type="button"
            :disabled="!canGoPrev"
            @click.stop="goPrev"
          >
            <el-icon><ArrowLeft /></el-icon>
          </button>

          <div class="viewer-main" @click="goNext">
            <img
              v-if="viewerUrl"
              :src="viewerUrl"
              class="viewer-image"
              alt="screenshot preview"
            />
            <div v-else class="viewer-loading">
              <el-icon class="is-loading"><Loading /></el-icon>
            </div>
          </div>

          <button
            class="viewer-nav next"
            type="button"
            :disabled="!canGoNext"
            @click.stop="goNext"
          >
            <el-icon><ArrowRight /></el-icon>
          </button>

          <div class="viewer-footer">
            <div class="viewer-info">
              <span class="viewer-name">{{ viewerEmployeeName }}</span>
              <span class="viewer-index">{{ viewerIndex + 1 }} / {{ viewerShots.length }}</span>
              <span class="viewer-time">{{ viewerCapturedAt }}</span>
              <span class="viewer-hint">点击图片下一张 · ← → 切换 · 滚轮上下切换 · Esc 关闭</span>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import {
  ref,
  reactive,
  computed,
  onMounted,
  onBeforeUnmount,
  nextTick,
  watch,
} from "vue";
import { ElMessage } from "element-plus";
import {
  Refresh,
  Loading,
  Close,
  ArrowLeft,
  ArrowRight,
  Search,
} from "@element-plus/icons-vue";
import { screenshotApi } from "@api/index";
import type { Screenshot, ScreenshotOverviewItem } from "@api/types";

const STORAGE_KEY = "screenshotOverviewLimit";
const AUTO_REFRESH_KEY = "screenshotOverviewAutoRefresh";
const REFRESH_INTERVAL_KEY = "screenshotOverviewRefreshInterval";

const loading = ref(false);
const silentRefreshing = ref(false);
const rows = ref<ScreenshotOverviewItem[]>([]);
const displayLimit = ref(Number(localStorage.getItem(STORAGE_KEY)) || 10);
const searchMode = ref<"date" | "datetime">("datetime");
const dateRange = ref<[string, string] | null>(null);
const dateTimeRange = ref<[string, string] | null>(null);
const autoRefresh = ref(localStorage.getItem(AUTO_REFRESH_KEY) === "true");
const refreshInterval = ref(
  Number(localStorage.getItem(REFRESH_INTERVAL_KEY)) || 30,
);
const imageUrlMap = reactive<Record<string, string>>({});
const fullImageUrlMap = reactive<Record<string, string>>({});

const galleryRefs: Record<string, HTMLElement | null> = {};
const galleryScrollStates = reactive<
  Record<string, { left: boolean; right: boolean }>
>({});
const galleryRefCallbacks = new Map<string, (el: unknown) => void>();
const galleryResizeObservers = new WeakMap<HTMLElement, ResizeObserver>();

let refreshTimer: ReturnType<typeof setInterval> | null = null;

const dateShortcuts = [
  {
    text: "今日",
    value: () => {
      const today = new Date();
      return [today, today];
    },
  },
  {
    text: "昨日",
    value: () => {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      return [yesterday, yesterday];
    },
  },
  {
    text: "近7天",
    value: () => {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 6);
      return [start, end];
    },
  },
];

const viewerVisible = ref(false);
const viewerOverlayRef = ref<HTMLElement | null>(null);
const viewerRow = ref<ScreenshotOverviewItem | null>(null);
const viewerIndex = ref(0);
const viewerUrl = ref("");

const viewerShots = computed(() => viewerRow.value?.screenshots ?? []);
const viewerEmployeeName = computed(
  () =>
    viewerRow.value?.employeeName ||
    viewerRow.value?.hostname ||
    "未知员工",
);
const viewerCapturedAt = computed(() => {
  const shot = viewerShots.value[viewerIndex.value];
  return shot ? formatDateTime(shot.capturedAt) : "";
});
const canGoPrev = computed(() => viewerIndex.value > 0);
const canGoNext = computed(
  () => viewerIndex.value < viewerShots.value.length - 1,
);

const syncGalleryScrollState = (deviceId: string) => {
  const el = galleryRefs[deviceId];
  if (!el) return;
  const maxScroll = el.scrollWidth - el.clientWidth;
  const next = {
    left: el.scrollLeft > 2,
    right: maxScroll > 2 && el.scrollLeft < maxScroll - 2,
  };
  const prev = galleryScrollStates[deviceId];
  if (prev?.left === next.left && prev?.right === next.right) return;
  galleryScrollStates[deviceId] = next;
};

const syncAllGalleryScrollStates = () => {
  nextTick(() => {
    Object.keys(galleryRefs).forEach((deviceId) => syncGalleryScrollState(deviceId));
  });
};

const cleanupGalleryRef = (deviceId: string) => {
  delete galleryRefs[deviceId];
  delete galleryScrollStates[deviceId];
  galleryRefCallbacks.delete(deviceId);
};

const getGalleryRef = (deviceId: string) => {
  let callback = galleryRefCallbacks.get(deviceId);
  if (callback) return callback;

  callback = (el: unknown) => {
    const node = el as HTMLElement | null;
    if (!node) {
      galleryRefs[deviceId] = null;
      return;
    }

    galleryRefs[deviceId] = node;

    if (!galleryResizeObservers.has(node)) {
      node.addEventListener(
        "scroll",
        () => syncGalleryScrollState(deviceId),
        { passive: true },
      );
      const observer = new ResizeObserver(() => syncGalleryScrollState(deviceId));
      observer.observe(node);
      galleryResizeObservers.set(node, observer);
    }

    nextTick(() => syncGalleryScrollState(deviceId));
  };

  galleryRefCallbacks.set(deviceId, callback);
  return callback;
};

const scrollGallery = (deviceId: string, direction: -1 | 1) => {
  const el = galleryRefs[deviceId];
  if (!el) return;
  const step = Math.max(280, Math.floor(el.clientWidth * 0.75));
  el.scrollBy({ left: direction * step, behavior: "smooth" });
  window.setTimeout(() => syncGalleryScrollState(deviceId), 320);
};

const formatTimeOnly = (time: string) => {
  if (!time) return "--:--:--";
  const date = new Date(time);
  return date.toLocaleTimeString("zh-CN", { hour12: false });
};

const formatDateTime = (time: string) => {
  if (!time) return "-";
  return new Date(time).toLocaleString("zh-CN", { hour12: false });
};

const getLocalTimezoneOffset = (): string => {
  const offset = -new Date().getTimezoneOffset();
  const sign = offset >= 0 ? "+" : "-";
  const hours = Math.floor(Math.abs(offset) / 60);
  const minutes = Math.abs(offset) % 60;
  return `${sign}${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
};

const toUTCStartOfDay = (dateStr: string): string => {
  const timezone = getLocalTimezoneOffset();
  return new Date(`${dateStr}T00:00:00${timezone}`).toISOString();
};

const toUTCEndOfDay = (dateStr: string): string => {
  const timezone = getLocalTimezoneOffset();
  return new Date(`${dateStr}T23:59:59${timezone}`).toISOString();
};

const toUTCFromDateTimeStr = (dateTimeStr: string): string => {
  const timezone = getLocalTimezoneOffset();
  const normalized = dateTimeStr.replace(" ", "T");
  return new Date(`${normalized}${timezone}`).toISOString();
};

const buildQueryParams = () => {
  const params: {
    limit: number;
    startDate?: string;
    endDate?: string;
  } = {
    limit: displayLimit.value,
  };

  if (searchMode.value === "date" && dateRange.value?.[0] && dateRange.value?.[1]) {
    params.startDate = toUTCStartOfDay(dateRange.value[0]);
    params.endDate = toUTCEndOfDay(dateRange.value[1]);
  } else if (
    searchMode.value === "datetime" &&
    dateTimeRange.value?.[0] &&
    dateTimeRange.value?.[1]
  ) {
    params.startDate = toUTCFromDateTimeStr(dateTimeRange.value[0]);
    params.endDate = toUTCFromDateTimeStr(dateTimeRange.value[1]);
  }

  return params;
};

const IMAGE_LOAD_CONCURRENCY = 4;
let activeImageLoads = 0;
const imageLoadWaiters: Array<() => void> = [];

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function withImageConcurrency<T>(fn: () => Promise<T>): Promise<T> {
  while (activeImageLoads >= IMAGE_LOAD_CONCURRENCY) {
    await new Promise<void>((resolve) => imageLoadWaiters.push(resolve));
  }
  activeImageLoads += 1;
  try {
    return await fn();
  } finally {
    activeImageLoads -= 1;
    const next = imageLoadWaiters.shift();
    if (next) next();
  }
}

const loadImageUrl = async (id: string, retries = 2): Promise<string> => {
  if (imageUrlMap[id]) return imageUrlMap[id];

  return withImageConcurrency(async () => {
    if (imageUrlMap[id]) return imageUrlMap[id];
    try {
      const response = await screenshotApi.getThumbnailBlob(id);
      const blob =
        response.data instanceof Blob
          ? response.data
          : new Blob([response.data as BlobPart]);
      const url = URL.createObjectURL(blob);
      imageUrlMap[id] = url;
      return url;
    } catch {
      try {
        const response = await screenshotApi.getImageBlob(id);
        const blob =
          response.data instanceof Blob
            ? response.data
            : new Blob([response.data as BlobPart]);
        const url = URL.createObjectURL(blob);
        imageUrlMap[id] = url;
        return url;
      } catch (error) {
        if (retries > 0) {
          await sleep(400 * (3 - retries));
          return loadImageUrl(id, retries - 1);
        }
        throw error;
      }
    }
  });
};

const prefetchRowImages = (items: ScreenshotOverviewItem[]) => {
  for (const row of items) {
    for (const shot of row.screenshots) {
      void loadImageUrl(shot.id).catch(() => undefined);
    }
  }
};

const loadOverview = async (silent = false) => {
  if (silent) {
    silentRefreshing.value = true;
  } else {
    loading.value = true;
  }
  try {
    const { data } = await screenshotApi.getOverview(buildQueryParams());
    rows.value = (data.items || []).filter(
      (row) => row.totalCount > 0 || row.screenshots.length > 0,
    );
    prefetchRowImages(rows.value);
    syncAllGalleryScrollStates();
  } catch (error: any) {
    if (!silent) {
      ElMessage.error(error.message || "加载截图概览失败");
      rows.value = [];
    }
  } finally {
    loading.value = false;
    silentRefreshing.value = false;
  }
};

const handleSearch = () => {
  loadOverview();
};

const handleReset = () => {
  searchMode.value = "datetime";
  dateRange.value = null;
  dateTimeRange.value = null;
  loadOverview();
};

const handleSearchModeChange = () => {
  dateRange.value = null;
  dateTimeRange.value = null;
};

const stopAutoRefresh = () => {
  if (refreshTimer) {
    clearInterval(refreshTimer);
    refreshTimer = null;
  }
};

const startAutoRefresh = () => {
  stopAutoRefresh();
  if (!autoRefresh.value || viewerVisible.value) return;
  refreshTimer = setInterval(() => {
    if (!viewerVisible.value) {
      void loadOverview(true);
    }
  }, refreshInterval.value * 1000);
};

const handleAutoRefreshChange = (enabled: boolean) => {
  localStorage.setItem(AUTO_REFRESH_KEY, String(enabled));
  if (enabled) {
    startAutoRefresh();
  } else {
    stopAutoRefresh();
  }
};

const handleRefreshIntervalChange = () => {
  localStorage.setItem(REFRESH_INTERVAL_KEY, String(refreshInterval.value));
  if (autoRefresh.value) {
    startAutoRefresh();
  }
};

const handleLimitChange = () => {
  if (displayLimit.value < 1) displayLimit.value = 1;
  if (displayLimit.value > 30) displayLimit.value = 30;
  localStorage.setItem(STORAGE_KEY, String(displayLimit.value));
  loadOverview();
};

const loadFullImageUrl = async (id: string): Promise<string> => {
  if (fullImageUrlMap[id]) return fullImageUrlMap[id];
  const response = await screenshotApi.getImageBlob(id);
  const blob =
    response.data instanceof Blob
      ? response.data
      : new Blob([response.data as BlobPart]);
  const url = URL.createObjectURL(blob);
  fullImageUrlMap[id] = url;
  return url;
};

const loadViewerImage = async () => {
  const shot = viewerShots.value[viewerIndex.value];
  if (!shot) {
    viewerUrl.value = "";
    return;
  }
  viewerUrl.value = "";
  try {
    viewerUrl.value = await loadFullImageUrl(shot.id);
  } catch {
    ElMessage.warning("图片加载失败");
  }
};

const openViewer = async (row: ScreenshotOverviewItem, index: number) => {
  viewerRow.value = row;
  viewerIndex.value = index;
  viewerVisible.value = true;
  await nextTick();
  viewerOverlayRef.value?.focus();
  await loadViewerImage();
};

const closeViewer = () => {
  viewerVisible.value = false;
  viewerRow.value = null;
  viewerIndex.value = 0;
  viewerUrl.value = "";
};

const goPrev = async () => {
  if (!canGoPrev.value) return;
  viewerIndex.value -= 1;
  await loadViewerImage();
};

const goNext = async () => {
  if (!canGoNext.value) return;
  viewerIndex.value += 1;
  await loadViewerImage();
};

const handleViewerKeydown = (event: KeyboardEvent) => {
  if (event.key === "Escape") {
    closeViewer();
    return;
  }
  if (event.key === "ArrowLeft") {
    event.preventDefault();
    void goPrev();
    return;
  }
  if (event.key === "ArrowRight") {
    event.preventDefault();
    void goNext();
  }
};

const handleViewerWheel = (event: WheelEvent) => {
  if (event.deltaY > 0) {
    void goNext();
  } else if (event.deltaY < 0) {
    void goPrev();
  }
};

watch(rows, (items) => {
  const activeIds = new Set(items.map((row) => row.deviceId));
  Object.keys(galleryRefs).forEach((deviceId) => {
    if (!activeIds.has(deviceId)) {
      cleanupGalleryRef(deviceId);
    }
  });
  syncAllGalleryScrollStates();
});

watch(viewerVisible, (visible) => {
  document.body.style.overflow = visible ? "hidden" : "";
  if (visible) {
    stopAutoRefresh();
  } else if (autoRefresh.value) {
    startAutoRefresh();
  }
});

onMounted(() => {
  loadOverview();
  if (autoRefresh.value) {
    startAutoRefresh();
  }
  window.addEventListener("resize", syncAllGalleryScrollStates);
});

onBeforeUnmount(() => {
  stopAutoRefresh();
  window.removeEventListener("resize", syncAllGalleryScrollStates);
  document.body.style.overflow = "";
  Object.values(imageUrlMap).forEach((url) => URL.revokeObjectURL(url));
  Object.values(fullImageUrlMap).forEach((url) => URL.revokeObjectURL(url));
});
</script>

<style scoped>
.overview-page {
  position: relative;
  min-height: 100%;
  padding-bottom: 24px;
}

.bg-decoration {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.35;
}

.blob-1 {
  width: 420px;
  height: 420px;
  background: #a5b4fc;
  top: -120px;
  right: -80px;
}

.blob-2 {
  width: 360px;
  height: 360px;
  background: #99f6e4;
  bottom: -100px;
  left: -60px;
}

.toolbar-card,
.overview-list {
  position: relative;
  z-index: 1;
}

.toolbar-card {
  margin-bottom: 16px;
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.8);
  background: rgba(255, 255, 255, 0.88);
  backdrop-filter: blur(12px);
}

.toolbar-row {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-wrap: nowrap;
  overflow-x: auto;
}

.page-title {
  margin: 0;
  flex-shrink: 0;
  font-size: 18px;
  font-weight: 700;
  color: #1f2937;
  white-space: nowrap;
}

.toolbar-form {
  display: flex;
  flex-wrap: nowrap;
  align-items: center;
  flex: 1;
  min-width: 0;
}

.toolbar-form :deep(.el-form-item) {
  margin-right: 12px;
  margin-bottom: 0;
}

.limit-item :deep(.el-form-item__content) {
  display: flex;
  align-items: center;
  flex-wrap: nowrap;
}

.limit-suffix {
  margin-left: 6px;
  font-size: 13px;
  color: #6b7280;
  white-space: nowrap;
}

.auto-refresh-group {
  display: flex;
  align-items: center;
  gap: 8px;
}

.auto-refresh-label {
  font-size: 13px;
  color: #606266;
  white-space: nowrap;
}

.overview-list {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.employee-row {
  display: grid;
  grid-template-columns: 140px 1fr;
  gap: 16px;
  align-items: stretch;
  padding: 16px 18px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.92);
  border: 1px solid #eef2f7;
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
  transition: box-shadow 0.2s ease, transform 0.2s ease;
}

.employee-row:hover {
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

.employee-info {
  display: flex;
  flex-direction: column;
  justify-content: center;
  border-right: 1px solid #f1f5f9;
  padding-right: 12px;
}

.employee-name {
  font-size: 16px;
  font-weight: 700;
  color: #111827;
  line-height: 1.4;
}

.employee-meta {
  margin-top: 8px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 12px;
  color: #64748b;
}

.total-count {
  color: #94a3b8;
}

.limit-item :deep(.el-input-number) {
  width: 120px;
}

.gallery-wrap {
  min-width: 0;
}

.gallery-nav-wrap {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}

.gallery-nav-btn {
  flex-shrink: 0;
  width: 32px;
  height: 32px;
  border: 1px solid #e2e8f0;
  border-radius: 50%;
  background: #fff;
  color: #475569;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.06);
  transition: background 0.15s ease, color 0.15s ease, border-color 0.15s ease;
}

.gallery-nav-btn:hover {
  background: #f8fafc;
  color: #6366f1;
  border-color: #c7d2fe;
}

.no-shots {
  height: 100%;
  min-height: 92px;
  display: flex;
  align-items: center;
  color: #94a3b8;
  font-size: 13px;
}

.gallery-scroll {
  display: flex;
  gap: 12px;
  flex: 1;
  min-width: 0;
  overflow-x: auto;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.gallery-scroll::-webkit-scrollbar {
  display: none;
}

.thumb-item {
  flex: 0 0 auto;
  width: 132px;
  cursor: pointer;
}

.thumb-frame {
  height: 78px;
  border-radius: 10px;
  overflow: hidden;
  background: #f8fafc;
  border: 2px solid transparent;
  transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
}

.thumb-item.latest .thumb-frame {
  border-color: #22c55e;
  box-shadow: 0 0 0 1px rgba(34, 197, 94, 0.15);
}

.thumb-item:hover .thumb-frame {
  transform: translateY(-2px);
  border-color: #6366f1;
}

.thumb-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.thumb-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #94a3b8;
}

.thumb-time {
  margin-top: 6px;
  text-align: center;
  font-size: 11px;
  color: #64748b;
  font-variant-numeric: tabular-nums;
}

.viewer-overlay {
  position: fixed;
  inset: 0;
  z-index: 4000;
  background: rgba(15, 23, 42, 0.92);
  display: flex;
  align-items: center;
  justify-content: center;
  outline: none;
}

.viewer-close {
  position: absolute;
  top: 20px;
  right: 20px;
  width: 42px;
  height: 42px;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
}

.viewer-nav {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 48px;
  height: 48px;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
}

.viewer-nav:disabled {
  opacity: 0.25;
  cursor: not-allowed;
}

.viewer-nav.prev {
  left: 24px;
}

.viewer-nav.next {
  right: 24px;
}

.viewer-main {
  max-width: calc(100vw - 160px);
  max-height: calc(100vh - 120px);
  cursor: pointer;
}

.viewer-image {
  max-width: 100%;
  max-height: calc(100vh - 120px);
  object-fit: contain;
  border-radius: 8px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.35);
}

.viewer-loading {
  width: 320px;
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 28px;
}

.viewer-footer {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  padding: 16px 24px 20px;
  text-align: center;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.55));
}

.viewer-info {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: nowrap;
  gap: 16px;
  font-size: 15px;
  font-weight: 600;
  color: #fff;
  text-shadow: 0 1px 4px rgba(0, 0, 0, 0.45);
  white-space: nowrap;
}

.viewer-name {
  font-size: 16px;
}

.viewer-index,
.viewer-time {
  color: #f8fafc;
}

.viewer-hint {
  color: #e2e8f0;
  font-weight: 500;
}

.viewer-fade-enter-active,
.viewer-fade-leave-active {
  transition: opacity 0.2s ease;
}

.viewer-fade-enter-from,
.viewer-fade-leave-to {
  opacity: 0;
}

@media (max-width: 900px) {
  .employee-row {
    grid-template-columns: 1fr;
  }

  .employee-info {
    border-right: none;
    border-bottom: 1px solid #f1f5f9;
    padding-right: 0;
    padding-bottom: 12px;
  }

  .viewer-main {
    max-width: calc(100vw - 48px);
  }

  .viewer-nav {
    display: none;
  }
}
</style>

# 打包 WinForms 客户端为自包含部署包，并复制到项目 downloads/ 供 Web 下载
# 用法（在项目根目录）:
#   powershell -ExecutionPolicy Bypass -File scripts/publish-client.ps1

$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$AgentDir = Join-Path $Root "agent"
$PublishDir = Join-Path $AgentDir "publish\win-x64"
$DownloadsDir = Join-Path $Root "downloads"
$ZipName = "EnterpriseAgent-setup.zip"
$ZipPath = Join-Path $DownloadsDir $ZipName

Write-Host "==> Enterprise Agent client publish" -ForegroundColor Cyan
Write-Host "    Root: $Root"

if (-not (Test-Path (Join-Path $AgentDir "EnterpriseAgent.Agent.csproj"))) {
    throw "Cannot find agent project under $AgentDir"
}

$deploymentPath = Join-Path $AgentDir "deployment.json"
if (-not (Test-Path $deploymentPath)) {
    Write-Host "WARN: agent/deployment.json not found. Copy deployment.json.example first." -ForegroundColor Yellow
    Copy-Item (Join-Path $AgentDir "deployment.json.example") $deploymentPath
    throw "Please edit agent/deployment.json (serverUrl, secrets) and run again."
}

$deployment = Get-Content $deploymentPath -Raw | ConvertFrom-Json
if ([string]::IsNullOrWhiteSpace($deployment.serverUrl) -and [string]::IsNullOrWhiteSpace($deployment.defaultServerUrl)) {
    Write-Host "WARN: deployment.json has no serverUrl. Employees must enter server URL manually on first run." -ForegroundColor Yellow
}

if ($deployment.allowInsecureTransport -eq $true) {
    Write-Host "WARN: allowInsecureTransport=true — use only for local HTTP debugging, not production publish." -ForegroundColor Yellow
}

$policySecret = [string]$deployment.policySignatureSecret
if (-not [string]::IsNullOrWhiteSpace($policySecret) -and $policySecret -notmatch '请填写|相同|CHANGE_ME|your-') {
    Write-Host "WARN: deployment.json contains a real policySignatureSecret. Ensure this zip is not committed to Git." -ForegroundColor Yellow
}

$regSecret = [string]$deployment.registrationSecret
if (-not [string]::IsNullOrWhiteSpace($regSecret) -and $regSecret -notmatch '请填写|相同|CHANGE_ME|your-') {
    Write-Host "WARN: deployment.json contains a real registrationSecret. Ensure this zip is not committed to Git." -ForegroundColor Yellow
}

if (-not [string]::IsNullOrWhiteSpace($deployment.serverUrl) -and [string]$deployment.serverUrl -match '^http://') {
    Write-Host "WARN: serverUrl uses http:// — production should use https:// (see P5 migration plan)." -ForegroundColor Yellow
}

$ffmpegPath = Join-Path $AgentDir "ffmpeg.exe"
if (-not (Test-Path $ffmpegPath)) {
    Write-Host "WARN: agent/ffmpeg.exe not found. Screen recording upload may fail until ffmpeg is bundled." -ForegroundColor Yellow
    Write-Host "      Download ffmpeg for Windows and place ffmpeg.exe in the agent/ folder, then re-run." -ForegroundColor Yellow
}

Write-Host "==> dotnet publish (self-contained win-x64)..." -ForegroundColor Cyan
Push-Location $AgentDir
try {
    dotnet publish EnterpriseAgent.Agent.csproj `
        -c Release `
        -r win-x64 `
        --self-contained true `
        /p:PublishReadyToRun=true `
        /p:IncludeNativeLibrariesForSelfExtract=true `
        -o $PublishDir
    if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed with exit code $LASTEXITCODE" }
}
finally {
    Pop-Location
}

if (-not (Test-Path (Join-Path $PublishDir "DHPG.exe"))) {
    throw "Publish output missing DHPG.exe at $PublishDir"
}

New-Item -ItemType Directory -Force -Path $DownloadsDir | Out-Null
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }

Write-Host "==> Creating zip: $ZipPath" -ForegroundColor Cyan
Compress-Archive -Path (Join-Path $PublishDir "*") -DestinationPath $ZipPath -CompressionLevel Optimal

$version = (Select-Xml -Path (Join-Path $AgentDir "EnterpriseAgent.Agent.csproj") -XPath "//Version" | Select-Object -First 1).Node.InnerText
if ([string]::IsNullOrWhiteSpace($version)) { $version = "2.0.0" }

Write-Host ""
Write-Host "Done." -ForegroundColor Green
Write-Host "  Package : $ZipPath"
Write-Host "  Size    : $([math]::Round((Get-Item $ZipPath).Length / 1MB, 2)) MB"
Write-Host ""
Write-Host "Add to backend/.env (then restart backend):" -ForegroundColor Yellow
Write-Host "  CLIENT_DOWNLOAD_FILE=$ZipName"
Write-Host "  CLIENT_VERSION=$version"
Write-Host ""
Write-Host "Employee usage:" -ForegroundColor Yellow
Write-Host "  1. Login web portal -> click download icon (top-right)"
Write-Host "  2. Extract zip to a folder (e.g. C:\DHPG)"
Write-Host "  3. Run DHPG.exe -> login with employee account or invite code"

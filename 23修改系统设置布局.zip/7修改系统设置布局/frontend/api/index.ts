// frontend/api/index.ts
import request from "./request";
import type {
  LoginRequest,
  LoginResponse,
  LoginConfig,
  CaptchaResponse,
  AuthSecurityConfig,
  TotpEnrollResponse,
  TotpStatus,
  Device,
  DeviceListResponse,
  OnlineStatsResponse,
  RecordingListResponse,
  Recording,
  Policy,
  PolicyContent,
  CleanupPolicy,
  StorageStats,
  CleanupLog,
  PageResponse,
  DeviceTask,
  User,
  Role,
  RemoteViewStartSession,
  RemoteViewStatus,
  Screenshot,
  ScreenshotListResponse,
  ScreenshotOverviewResponse,
  ActivityLog,
  ActivityStats,
  DailyActivitySummary,
} from "./types";

// ✅ 从 format.ts 导入格式化函数（避免重复）
import {
  formatBytes,
  formatDateTime,
  formatDate,
  formatTime,
  getRelativeTime,
  getStatusType,
  getStatusText,
  formatDuration,
  truncateText,
  formatDeviceId,
  formatPercent,
  formatNumber,
  formatISOString,
} from "./format";

// ========== 重新导出格式化函数（保持向后兼容） ==========
export {
  formatBytes,
  formatDateTime,
  formatDate,
  formatTime,
  getRelativeTime,
  getStatusType,
  getStatusText,
  formatDuration,
  truncateText,
  formatDeviceId,
  formatPercent,
  formatNumber,
  formatISOString,
};

// ========== 时间工具（与后端 UTC 保持一致） ==========
export const formatUTC = (date: Date = new Date()): string => {
  return date.toISOString();
};

export const parseUTC = (dateStr: string): Date => {
  return new Date(dateStr);
};

// ========== 认证 API ==========
export const authApi = {
  getLoginConfig: async (): Promise<{ data: LoginConfig }> => {
    const response = await request.get<any>("/auth/login-config");
    if (response.data?.data) return { data: response.data.data as LoginConfig };
    return { data: response.data as LoginConfig };
  },

  getCaptcha: async (): Promise<{ data: CaptchaResponse }> => {
    const response = await request.get<any>("/auth/captcha");
    const payload = (response.data?.data ?? response.data) as CaptchaResponse;
    return { data: payload };
  },

  login: async (data: LoginRequest): Promise<{ data: LoginResponse; message?: string }> => {
    const response = await request.post<any>("/auth/login", data);
    const raw = response.data;
    const body = (raw?.data ?? raw) as LoginResponse;
    const message =
      raw && typeof raw === "object" && "message" in raw
        ? String((raw as { message?: string }).message || "")
        : undefined;
    return { data: body, message };
  },

  refresh: async (
    refreshToken: string,
  ): Promise<{ data: LoginResponse }> => {
    const response = await request.post<any>("/auth/refresh", { refreshToken });
    if (
      response.data &&
      typeof response.data === "object" &&
      "data" in response.data
    ) {
      return { data: response.data.data as LoginResponse };
    }
    return { data: response.data as LoginResponse };
  },

  logout: (refreshToken?: string) =>
    request.post("/auth/logout", refreshToken ? { refreshToken } : {}),

  wsTicket: async (): Promise<{ ticket: string; expiresIn: number }> => {
    const response = await request.post<any>("/ws-ticket", {});
    return response.data as { ticket: string; expiresIn: number };
  },
};

export const metaApi = {
  modules: () =>
    request.get<{ domainMonitor: boolean; callback: boolean; wsTicketRequired?: boolean }>(
      "/meta/modules",
    ),
};

// ========== 设备 API ==========
export const deviceApi = {
  list: (params: {
    page?: number;
    pageSize?: number;
    status?: string;
    employeeSearch?: string; // ✅ 新增
    deviceStatus?: string; // ✅ 新增
    keyword?: string; // ✅ 新增
  }) => request.get<DeviceListResponse>("/devices", { params }),

  /** 分页拉取全部设备（后端单页最大 100 条） */
  listAll: async (
    params?: Omit<
      {
        page?: number;
        pageSize?: number;
        status?: string;
        employeeSearch?: string;
        deviceStatus?: string;
        keyword?: string;
      },
      "page" | "pageSize"
    >,
  ) => {
    const all: Device[] = [];
    let page = 1;
    const pageSize = 100;
    let total = 0;
    while (true) {
      const { data } = await request.get<DeviceListResponse>("/devices", {
        params: { ...params, page, pageSize },
      });
      all.push(...(data.items || []));
      total = data.total ?? all.length;
      if (all.length >= total || !(data.items?.length)) break;
      page++;
    }
    return {
      data: {
        items: all,
        total: all.length,
        page: 1,
        pageSize: all.length,
      } satisfies DeviceListResponse,
    };
  },

  get: (id: string) => request.get<Device>(`/devices/${id}`),

  bind: (id: string, employeeId: string) =>
    request.post(`/devices/${id}/bind`, { employeeId }),

  unbind: (id: string) => request.post(`/devices/${id}/unbind`),

  forceOffline: (id: string) => request.post(`/devices/${id}/force-offline`),

  updateStatus: (id: string, status: "pending" | "approved" | "rejected") =>
    request.put(`/devices/${id}/status`, { status }),

  onlineStats: () => request.get<OnlineStatsResponse>("/devices/stats/online"),

  reportInfo: (data: {
    deviceId: string;
    hostname: string;
    osVersion: string;
    agentVersion: string;
  }) => request.post("/devices/info", data),

  register: (data: {
    deviceId: string;
    hostname: string;
    osVersion: string;
    agentVersion: string;
    fingerprint: Record<string, string>;
    publicKey: string;
  }) => request.post<LoginResponse>("/devices/register", data),
  updateEmployee: (
    id: string,
    data: {
      employeeId?: string;
      employeeName?: string;
      employeeNumber?: string;
      position?: string;
    },
  ) => request.put(`/devices/${id}/employee`, data),
};

// ========== 录制 API ==========
const recordingApiBase =
  (import.meta.env.VITE_API_BASE_URL as string) || "/api/v1";

type MediaResourceType = "recording" | "screenshot";
type MediaAction = "stream" | "download" | "view";

const mediaTokenCache = new Map<
  string,
  { token: string; expiresAt: number }
>();

const getMediaAccessUrl = async (
  resourceType: MediaResourceType,
  resourceId: string,
  action: MediaAction,
  path: string,
): Promise<string> => {
  const cacheKey = `${resourceType}:${resourceId}:${action}`;
  const cached = mediaTokenCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now() + 60_000) {
    return `${recordingApiBase}${path}?mediaToken=${encodeURIComponent(cached.token)}`;
  }

  const { data } = await request.post<{
    mediaToken: string;
    expiresIn: number;
  }>("/media/access-token", {
    resourceType,
    resourceId,
    action,
  });

  mediaTokenCache.set(cacheKey, {
    token: data.mediaToken,
    expiresAt: Date.now() + data.expiresIn * 1000,
  });

  return `${recordingApiBase}${path}?mediaToken=${encodeURIComponent(data.mediaToken)}`;
};

/** 短期令牌流式播放地址（供 <video> 使用，不在 URL 中传递 JWT） */
export const getRecordingStreamUrl = (id: string): Promise<string> =>
  getMediaAccessUrl("recording", id, "stream", `/recordings/${id}/stream`);

/** 短期令牌下载地址 */
export const getRecordingDownloadUrl = (id: string): Promise<string> =>
  getMediaAccessUrl("recording", id, "download", `/recordings/${id}/download`);

export const recordingApi = {
  list: (params: {
    deviceId?: string;
    startTime?: string;
    endTime?: string;
    page?: number;
    pageSize?: number;
  }) => request.get<RecordingListResponse>("/recordings", { params }),

  /** 分页拉取全部录制（后端单页最大 100 条） */
  listAll: async (
    params?: Omit<
      {
        deviceId?: string;
        startTime?: string;
        endTime?: string;
        page?: number;
        pageSize?: number;
      },
      "page" | "pageSize"
    >,
  ) => {
    const all: Recording[] = [];
    let page = 1;
    const pageSize = 100;
    let total = 0;
    while (true) {
      const { data } = await request.get<RecordingListResponse>("/recordings", {
        params: { ...params, page, pageSize },
      });
      all.push(...(data.items || []));
      total = data.total ?? all.length;
      if (all.length >= total || !(data.items?.length)) break;
      page++;
    }
    return { data: { items: all, total: all.length } };
  },

  getStats: (params: {
    deviceId?: string;
    startTime?: string;
    endTime?: string;
  }) =>
    request.get<{
      total: number;
      totalSize: number;
      avgSize: number;
      todayCount: number;
    }>("/recordings/stats", { params }),

  getPlayUrl: (id: string) =>
    request.get<{ url: string; streamUrl?: string }>(
      `/recordings/${id}/play`,
    ),

  delete: (id: string) => request.delete(`/recordings/${id}`),

  batchDelete: (ids: string[]) =>
    request.post("/recordings/batch-delete", { ids }),
};

// ========== 策略 API ==========
export const policyApi = {
  list: () => request.get<Policy[]>("/policies"),

  get: (id: string) => request.get<Policy>(`/policies/${id}`),

  create: (name: string, content: PolicyContent) =>
    request.post<Policy>("/policies", {
      name,
      content: content, // ✅ 直接传对象
    }),

  update: (id: string, name: string, content: PolicyContent) =>
    request.put<Policy>(`/policies/${id}`, {
      name,
      content: content,
    }),

  delete: (id: string) => request.delete(`/policies/${id}`),

  publish: (id: string) => request.post(`/policies/${id}/publish`),

  rollback: (id: string) => request.post(`/policies/${id}/rollback`),
};

// ========== 清理 API ==========
export const cleanupApi = {
  getPolicy: () => request.get<CleanupPolicy>("/cleanup/policy"),

  updatePolicy: (policy: CleanupPolicy) =>
    request.put<CleanupPolicy>("/cleanup/policy", policy),

  getStats: () => request.get<StorageStats>("/cleanup/stats"),

  manualCleanup: () => request.post<CleanupLog>("/cleanup/manual"),

  getLogs: (params?: { page?: number; pageSize?: number }) =>
    request.get<PageResponse<CleanupLog>>("/cleanup/logs", { params }),
};

export interface CorsOriginsConfig {
  origins: string[];
  effectiveOrigins: string[];
  source: "database" | "environment" | "default" | "none";
  updatedAt?: string;
}

export interface LoginIPWhitelistConfig {
  enabled: boolean;
  ips: string[];
  updatedAt?: string;
}

export const settingsApi = {
  getCorsOrigins: () => request.get<CorsOriginsConfig>("/settings/cors-origins"),

  updateCorsOrigins: (origins: string[]) =>
    request.put<CorsOriginsConfig>("/settings/cors-origins", { origins }),

  getAuthSecurity: () => request.get<AuthSecurityConfig>("/settings/auth-security"),

  updateAuthSecurity: (data: {
    loginCaptchaEnabled: boolean;
    loginTotpEnabled: boolean;
  }) => request.put<AuthSecurityConfig>("/settings/auth-security", data),

  getLoginIPWhitelist: () =>
    request.get<LoginIPWhitelistConfig>("/settings/login-ip-whitelist"),

  updateLoginIPWhitelist: (data: { enabled: boolean; ips: string[] }) =>
    request.put<LoginIPWhitelistConfig>("/settings/login-ip-whitelist", data),
};

export type { AuthSecurityConfig } from "./types";

// ========== 任务 API ==========
export const taskApi = {
  create: (data: {
    deviceId: string;
    type: string;
    startTime?: string;
    endTime?: string;
  }) => request.post<DeviceTask>("/tasks", data),

  get: (id: string) => request.get<DeviceTask>(`/tasks/${id}`),

  list: () => request.get<{ items: DeviceTask[]; total: number }>("/tasks"),

  cancel: (id: string) => request.post(`/tasks/${id}/cancel`),

  retry: (id: string) => request.post(`/tasks/${id}/retry`),
};

// ========== 用户 API ==========
export const userApi = {
  list: (params?: { page?: number; pageSize?: number; keyword?: string }) =>
    request.get<{ items: User[]; total: number }>("/users", { params }),

  create: (data: {
    username: string;
    password: string;
    realName?: string;
    email?: string;
    roleIds?: string[];
  }) => request.post<User>("/users", data),

  get: (id: string) => request.get<User>(`/users/${id}`),

  update: (
    id: string,
    data: {
      realName?: string;
      email?: string;
      status?: number;
      roleIds?: string[];
    },
  ) => request.put<User>(`/users/${id}`, data),

  delete: (id: string) => request.delete(`/users/${id}`),

  resetPassword: (id: string, password: string) =>
    request.post(`/users/${id}/reset-password`, { password }),

  resetTotp: (id: string) => request.post(`/users/${id}/reset-totp`),

  startTotpEnroll: async (id: string): Promise<TotpEnrollResponse> => {
    const response = await request.post<any>(`/users/${id}/totp-enroll`);
    return (response.data?.data ?? response.data) as TotpEnrollResponse;
  },

  confirmTotpEnroll: (id: string, data: { setupChallenge: string; totpCode: string }) =>
    request.post(`/users/${id}/totp-enroll/confirm`, data),

  getTotpStatus: async (): Promise<TotpStatus> => {
    const response = await request.get<any>("/user/totp");
    return (response.data?.data ?? response.data) as TotpStatus;
  },

  startOwnTotpEnroll: async (password: string): Promise<TotpEnrollResponse> => {
    const response = await request.post<any>("/user/totp/enroll", { password });
    return (response.data?.data ?? response.data) as TotpEnrollResponse;
  },

  confirmOwnTotpEnroll: (data: { setupChallenge: string; totpCode: string }) =>
    request.post("/user/totp/enroll/confirm", data),

  getProfile: () => request.get<User>("/user/profile"),

  updateProfile: (data: { realName?: string; email?: string }) =>
    request.put<User>("/user/profile", data),

  changeOwnPassword: (data: { oldPassword: string; newPassword: string }) =>
    request.post("/user/change-password", data),
};

// ========== 角色 API ==========
export const roleApi = {
  list: () => request.get<Role[]>("/roles"),

  create: (data: {
    name: string;
    description?: string;
    permissions: string[];
  }) => request.post<Role>("/roles", data),

  update: (
    id: string,
    data: { name?: string; description?: string; permissions?: string[] },
  ) => request.put<Role>(`/roles/${id}`, data),

  delete: (id: string) => request.delete(`/roles/${id}`),
};

// ========== 截图 API ==========
export const screenshotApi = {
  list: (params: {
    deviceId?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    pageSize?: number;
  }) => request.get<ScreenshotListResponse>("/screenshots", { params }),

  get: (id: string) => request.get<Screenshot>(`/screenshots/${id}`),

  /** 通过 Authorization 头获取图片（不在 URL 中传递 JWT） */
  getImageBlob: (id: string) =>
    request.get<Blob>(`/screenshots/${id}/image`, { responseType: "blob" }),

  getThumbnailBlob: (id: string) =>
    request.get<Blob>(`/screenshots/${id}/thumbnail`, { responseType: "blob" }),

  delete: (id: string) => request.delete(`/screenshots/${id}`),

  batchDelete: (ids: string[]) =>
    request.post("/screenshots/batch-delete", { ids }),

  getEmployeeStats: (deviceId: string) =>
    request.get<{ todayCount: number; totalCount: number }>(
      `/screenshots/stats/employee/${deviceId}`,
    ),

  getOverview: (params?: {
    limit?: number;
    startDate?: string;
    endDate?: string;
    startTime?: string;
    endTime?: string;
  }) => request.get<ScreenshotOverviewResponse>("/screenshots/overview", { params }),
};

// ========== 活动日志 API ==========
export const activityApi = {
  list: (params: {
    deviceId?: string;
    startDate?: string;
    endDate?: string;
    processName?: string;
    page?: number;
    pageSize?: number;
  }) =>
    request.get<{
      items: ActivityLog[];
      total: number;
      page: number;
      pageSize: number;
    }>("/activities", { params }),

  getStats: (deviceId?: string, startDate?: string, endDate?: string) => {
    const params: any = {};
    if (deviceId) params.deviceId = deviceId;
    if (startDate) params.startDate = startDate;
    if (endDate) params.endDate = endDate;
    return request.get<ActivityStats>("/activities/stats", { params });
  },

  getDailySummary: (deviceId?: string, days?: number) =>
    request.get<DailyActivitySummary[]>("/activities/daily-summary", {
      params: { deviceId, days },
    }),

  export: (params: {
    deviceId?: string;
    startDate?: string;
    endDate?: string;
  }) => request.get("/activities/export", { params, responseType: "blob" }),

  delete: (data: { ids?: string[]; daysOld?: number }) =>
    request.delete("/activities", { data }),

  // ✅ Agent 上报活动日志（客户端使用）
  report: (deviceId: string, activities: ActivityLog[]) =>
    request.post("/activities/report", { deviceId, activities }),

  // ✅ 获取进程列表（用于活动日志筛选）
  getProcessNames: (deviceId?: string) =>
    request.get<string[]>("/activities/processes", { params: { deviceId } }),
};

// ========== 远程查看 API（LiveKit）==========
export const remoteViewApi = {
  start: (deviceId: string) =>
    request.post<RemoteViewStartSession>(
      `/devices/${deviceId}/remote-view/start`,
    ),

  stop: (deviceId: string, sessionId?: string) =>
    request.post<{ deviceId: string; stopped: boolean; publisherStopped: boolean }>(
      `/devices/${deviceId}/remote-view/stop`,
      sessionId ? { sessionId } : {},
    ),

  getStatus: (deviceId: string) =>
    request.get<RemoteViewStatus>(`/devices/${deviceId}/remote-view/status`),
};

package handlers

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"mime/multipart"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/xuri/excelize/v2"

	"enterprise-agent/backend/models"
)

type salaryColumnField struct {
	Key      string   `json:"key"`
	Label    string   `json:"label"`
	Keywords []string `json:"-"`
	Default  int      `json:"defaultIndex"`
}

type salaryColumnPreviewItem struct {
	Index  int    `json:"index"`
	Letter string `json:"letter"`
	Header string `json:"header"`
}

func salaryColumnFields() []salaryColumnField {
	return []salaryColumnField{
		{Key: "position", Label: "职务", Keywords: []string{"职务", "岗位", "职位"}, Default: 0},
		{Key: "name", Label: "姓名/用户名", Keywords: []string{"名字", "姓名", "用户名", "员工姓名", "员工名字"}, Default: 1},
		{Key: "hireDateDept", Label: "入职日期-部门", Keywords: []string{"入职日期-部门", "入职日期", "入职时间", "部门"}, Default: 2},
		{Key: "monthsEmployed", Label: "在职月数", Keywords: []string{"在职月数", "在职月份", "工龄月数"}, Default: 3},
		{Key: "lastMonthBase", Label: "上月底薪", Keywords: []string{"上月底薪", "上月基本", "上月基础"}, Default: 4},
		{Key: "totalIncrease", Label: "递增总额", Keywords: []string{"递增总额", "递增合计", "递增"}, Default: 5},
		{Key: "baseSalary", Label: "底薪(RMB)", Keywords: []string{"底薪（rmb）", "底薪(rmb)", "底薪rmb", "底薪", "基本底薪"}, Default: 6},
		{Key: "attendanceDays", Label: "出勤", Keywords: []string{"出勤", "出勤天数", "满勤"}, Default: 7},
		{Key: "actualBaseSalary", Label: "实际底薪", Keywords: []string{"实际底薪", "实发底薪"}, Default: 8},
		{Key: "attendanceAdjustment", Label: "调勤", Keywords: []string{"调勤", "考勤调整", "考勤调节"}, Default: 9},
		{Key: "halfYearUnpaidLeave", Label: "半年未休", Keywords: []string{"半年未休", "未休", "半年假"}, Default: 10},
		{Key: "exchangeRate", Label: "汇率", Keywords: []string{"汇率"}, Default: 11},
		{Key: "performanceScore", Label: "绩效分数", Keywords: []string{"绩效分数", "绩效分"}, Default: 12},
		{Key: "performanceBonusB", Label: "绩效奖励B", Keywords: []string{"绩效奖励b", "绩效奖励B", "绩效奖B"}, Default: 13},
		{Key: "reward", Label: "奖励", Keywords: []string{"奖励", "奖金"}, Default: 14},
		{Key: "penalty", Label: "罚款", Keywords: []string{"罚款", "扣罚"}, Default: 15},
		{Key: "advance", Label: "预支15-15", Keywords: []string{"预支15-15", "预支", "借支"}, Default: 16},
		{Key: "otherDeduction", Label: "其他扣款", Keywords: []string{"其他扣款", "其它扣款", "其他扣除"}, Default: 17},
		{Key: "protectionReturn", Label: "保护费返还", Keywords: []string{"保护费返还", "保护费退回"}, Default: 18},
		{Key: "protectionFee", Label: "保护费", Keywords: []string{"保护费"}, Default: 19},
		{Key: "totalSalary", Label: "实发合计", Keywords: []string{"实发合计", "实发工资", "合计", "总计"}, Default: 20},
		{Key: "remark", Label: "备注", Keywords: []string{"备注", "说明"}, Default: 21},
	}
}

func defaultSalaryColumnMap() map[string]int {
	m := make(map[string]int, len(salaryColumnFields()))
	for _, f := range salaryColumnFields() {
		m[f.Key] = f.Default
	}
	return m
}

func salaryColumnIndexToLetter(idx int) string {
	if idx < 0 {
		return ""
	}
	n := idx + 1
	var parts []byte
	for n > 0 {
		n--
		parts = append([]byte{byte('A' + n%26)}, parts...)
		n /= 26
	}
	return string(parts)
}

func findSalaryHeaderColumn(header []string, keywords []string) int {
	for i, cell := range header {
		cellNorm := strings.ToLower(strings.TrimSpace(cell))
		if cellNorm == "" {
			continue
		}
		for _, kw := range keywords {
			kwNorm := strings.ToLower(strings.TrimSpace(kw))
			if cellNorm == kwNorm || strings.Contains(cellNorm, kwNorm) {
				return i
			}
		}
	}
	return -1
}

func resolveSalaryColumnsFromHeader(header []string) map[string]int {
	mapping := defaultSalaryColumnMap()
	for _, f := range salaryColumnFields() {
		if col := findSalaryHeaderColumn(header, f.Keywords); col >= 0 {
			mapping[f.Key] = col
		}
	}
	return mapping
}

func readSalaryUploadRows(file *multipart.FileHeader) ([][]string, error) {
	src, err := file.Open()
	if err != nil {
		return nil, err
	}
	defer src.Close()

	f, err := excelize.OpenReader(src)
	if err != nil {
		return nil, fmt.Errorf("无法解析Excel文件")
	}

	sheetName := f.GetSheetName(0)
	rows, err := f.GetRows(sheetName)
	if err != nil {
		return nil, err
	}
	if len(rows) < 2 {
		return nil, fmt.Errorf("文件无数据")
	}
	return rows, nil
}

func parseUseDynamicColumns(c *gin.Context) bool {
	return strings.EqualFold(strings.TrimSpace(c.PostForm("useDynamicColumns")), "true")
}

func clearSalaryMonthLayout(ctx context.Context, db *sql.DB, yearMonth string) error {
	_, err := db.ExecContext(ctx, `DELETE FROM salary_month_layouts WHERE year_month = $1`, yearMonth)
	return err
}

func parseNameColumnIndex(c *gin.Context, header []string) int {
	if raw := strings.TrimSpace(c.PostForm("nameColumn")); raw != "" {
		if idx, err := strconv.Atoi(raw); err == nil && idx >= 0 {
			return idx
		}
	}
	return suggestNameColumnIndex(header)
}

func suggestNameColumnIndex(header []string) int {
	nameKeywords := []string{"名字", "姓名", "用户名", "员工姓名", "员工名字"}
	if col := findSalaryHeaderColumn(header, nameKeywords); col >= 0 {
		return col
	}
	return 1
}

func maxSalarySheetWidth(rows [][]string) int {
	max := 0
	for _, row := range rows {
		if len(row) > max {
			max = len(row)
		}
	}
	if max < 1 {
		return 1
	}
	return max
}

func buildSalarySheetHeaders(headerRow []string, width int) []string {
	if width < len(headerRow) {
		width = len(headerRow)
	}
	if width < 1 {
		width = 1
	}
	headers := make([]string, width)
	used := make(map[string]int, width)
	for i := 0; i < width; i++ {
		label := strings.TrimSpace(getColumnValue(headerRow, i))
		if label == "" || isSalaryEmptyToken(label) {
			label = salaryColumnIndexToLetter(i) + "列"
		}
		if count, ok := used[label]; ok {
			count++
			used[label] = count
			label = fmt.Sprintf("%s(%d)", label, count)
		} else {
			used[label] = 1
		}
		headers[i] = label
	}
	return headers
}

func buildSalarySheetValues(headers []string, row []string) []string {
	values := make([]string, len(headers))
	for i := range headers {
		val := getColumnValue(row, i)
		if isSalaryEmptyToken(val) {
			val = ""
		} else {
			val = formatSalaryCellDisplay(headers[i], val)
		}
		values[i] = val
	}
	return values
}

func upsertSalaryMonthLayout(ctx context.Context, db *sql.DB, yearMonth string, headers []string, nameCol int) error {
	headersJSON, err := json.Marshal(headers)
	if err != nil {
		return err
	}
	_, err = db.ExecContext(ctx, `
		INSERT INTO salary_month_layouts (year_month, headers, name_column_index, updated_at)
		VALUES ($1, $2::jsonb, $3, NOW())
		ON CONFLICT (year_month) DO UPDATE SET
			headers = EXCLUDED.headers,
			name_column_index = EXCLUDED.name_column_index,
			updated_at = NOW()
	`, yearMonth, string(headersJSON), nameCol)
	return err
}

func loadSalaryMonthLayout(ctx context.Context, db *sql.DB, yearMonth string) ([]string, error) {
	if yearMonth == "" {
		return nil, nil
	}
	var raw []byte
	err := db.QueryRowContext(ctx, `
		SELECT headers FROM salary_month_layouts WHERE year_month = $1`, yearMonth).Scan(&raw)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	var headers []string
	if err := json.Unmarshal(raw, &headers); err != nil {
		return nil, err
	}
	return headers, nil
}

func fillSalaryLegacyFields(record *SalaryRecord, row []string, colMap map[string]int, fallbackPosition string) {
	record.Position = getColumnValue(row, colMap["position"])
	if record.Position == "" {
		record.Position = fallbackPosition
	}
	record.HireDateDept = formatSalaryHireDateDept(getColumnValue(row, colMap["hireDateDept"]))
	record.MonthsEmployed, _ = strconv.Atoi(getColumnValue(row, colMap["monthsEmployed"]))
	record.LastMonthBase, _ = parseSalaryFloat(getColumnValue(row, colMap["lastMonthBase"]))
	record.TotalIncrease, _ = parseSalaryFloat(getColumnValue(row, colMap["totalIncrease"]))
	record.BaseSalary, _ = parseSalaryFloat(getColumnValue(row, colMap["baseSalary"]))
	record.AttendanceDays, _ = parseSalaryFloat(getColumnValue(row, colMap["attendanceDays"]))
	record.ActualBaseSalary, _ = parseSalaryFloat(getColumnValue(row, colMap["actualBaseSalary"]))
	record.AttendanceAdjustment, _ = parseSalaryFloat(getColumnValue(row, colMap["attendanceAdjustment"]))
	record.HalfYearUnpaidLeave, _ = parseSalaryFloat(getColumnValue(row, colMap["halfYearUnpaidLeave"]))
	record.ExchangeRate, _ = parseSalaryFloat(getColumnValue(row, colMap["exchangeRate"]))
	record.PerformanceScore, _ = strconv.Atoi(getColumnValue(row, colMap["performanceScore"]))
	record.PerformanceBonusB, _ = parseSalaryFloat(getColumnValue(row, colMap["performanceBonusB"]))
	record.Reward, _ = parseSalaryFloat(getColumnValue(row, colMap["reward"]))
	record.Penalty, _ = parseSalaryFloat(getColumnValue(row, colMap["penalty"]))
	record.Advance, _ = parseSalaryFloat(getColumnValue(row, colMap["advance"]))
	record.OtherDeduction, _ = parseSalaryFloat(getColumnValue(row, colMap["otherDeduction"]))
	record.ProtectionReturn, _ = parseSalaryFloat(getColumnValue(row, colMap["protectionReturn"]))
	record.ProtectionFee, _ = parseSalaryFloat(getColumnValue(row, colMap["protectionFee"]))
	record.TotalSalary, _ = parseSalaryFloat(getColumnValue(row, colMap["totalSalary"]))
	record.Remark = getColumnValue(row, colMap["remark"])
	if isSalaryEmptyToken(record.Remark) {
		record.Remark = ""
	}
}

func parseSalaryColumnMapFromForm(c *gin.Context, header []string) (map[string]int, bool, error) {
	useCustom := strings.EqualFold(strings.TrimSpace(c.PostForm("useCustomMapping")), "true")
	if !useCustom {
		return defaultSalaryColumnMap(), false, nil
	}

	raw := strings.TrimSpace(c.PostForm("columnMap"))
	if raw == "" {
		return resolveSalaryColumnsFromHeader(header), true, nil
	}

	var override map[string]int
	if err := json.Unmarshal([]byte(raw), &override); err != nil {
		return nil, true, fmt.Errorf("列映射格式无效")
	}
	if len(override) == 0 {
		return resolveSalaryColumnsFromHeader(header), true, nil
	}

	mapping := defaultSalaryColumnMap()
	for key, idx := range override {
		if idx < 0 {
			continue
		}
		mapping[key] = idx
	}
	if _, ok := mapping["name"]; !ok || mapping["name"] < 0 {
		return nil, true, fmt.Errorf("请选择姓名/用户名列")
	}
	return mapping, true, nil
}

func salaryColumnFieldDefsForAPI() []map[string]interface{} {
	fields := make([]map[string]interface{}, 0, len(salaryColumnFields()))
	for _, f := range salaryColumnFields() {
		fields = append(fields, map[string]interface{}{
			"key":          f.Key,
			"label":        f.Label,
			"defaultIndex": f.Default,
			"defaultLetter": salaryColumnIndexToLetter(f.Default),
		})
	}
	return fields
}

func buildSalaryColumnPreview(header []string) []salaryColumnPreviewItem {
	maxCols := len(header)
	if maxCols < 22 {
		maxCols = 22
	}
	items := make([]salaryColumnPreviewItem, 0, maxCols)
	for i := 0; i < maxCols; i++ {
		h := ""
		if i < len(header) {
			h = strings.TrimSpace(header[i])
		}
		items = append(items, salaryColumnPreviewItem{
			Index:  i,
			Letter: salaryColumnIndexToLetter(i),
			Header: h,
		})
	}
	return items
}

// PreviewSalaryUpload 预览工资表表头并推荐列映射
func (h *AdminHandler) PreviewSalaryUpload(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		models.SendError(c, 400, 1001, "请选择文件")
		return
	}

	rows, err := readSalaryUploadRows(file)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	header := rows[0]
	sheetWidth := maxSalarySheetWidth(rows)
	sheetHeaders := buildSalarySheetHeaders(header, sheetWidth)
	nameCol := suggestNameColumnIndex(header)

	models.Send(c, 200, 0, "success", map[string]interface{}{
		"columns":             buildSalaryColumnPreview(header),
		"headers":             sheetHeaders,
		"suggestedNameColumn": nameCol,
		"sampleRowCount":      len(rows) - 1,
	})
}

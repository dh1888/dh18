客户端下载目录（供 Web 后台员工下载）

一、一键打包（推荐）
  在项目根目录执行：
    powershell -ExecutionPolicy Bypass -File scripts/publish-client.ps1

  脚本会：
  1. 自包含发布 win-x64 客户端（含 .NET 8 运行时，目标机无需安装 SDK）
  2. 打包为 EnterpriseAgent-setup.zip
  3. 输出到此 downloads/ 目录

  然后在 backend/.env 配置：
    CLIENT_DOWNLOAD_FILE=EnterpriseAgent-setup.zip
    CLIENT_VERSION=2.0.0

  重启后端即可。

二、打包前准备
  1. 编辑 agent/deployment.json
     - serverUrl：员工客户端连接的后台地址（HTTPS 生产环境）
     - policySignatureSecret：与 backend/.env 中 POLICY_SIGNATURE_SECRET 一致
     - registrationSecret：与 backend/.env 中 DEVICE_REGISTRATION_SECRET 一致（如有）
     - allowInsecureTransport：本地 HTTP 调试可 true，生产必须 false

  2. （强烈建议）将 ffmpeg.exe 放到 agent/ 目录
     录屏转码/上传依赖 ffmpeg，需与 DHPG.exe 同目录发布。

三、员工使用流程
  1. Web 登录 -> 右上角下载图标（或个人中心「下载客户端」）
  2. 解压 zip 到任意目录
  3. 双击 DHPG.exe
  4. 共享工位：输入服务器地址 + 员工账号密码
     或首次绑定：输入邀请码

四、手动 publish 命令（可选）
  cd agent
  dotnet publish EnterpriseAgent.Agent.csproj -c Release -r win-x64 --self-contained true -o publish/win-x64
  再将 publish/win-x64 整个文件夹打成 zip 放到本目录。

五、环境变量
  CLIENT_DOWNLOAD_DIR   默认 ./downloads
  CLIENT_DOWNLOAD_FILE  默认 EnterpriseAgent-setup.exe（zip 时请改为 .zip 文件名）
  CLIENT_DOWNLOAD_URL   也可填外部 CDN 完整 URL，跳过本地文件
  CLIENT_VERSION        显示在下载 tooltip 的版本号

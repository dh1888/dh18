// frontend/src/router/index.ts
import { createRouter, createWebHistory } from "vue-router";
import { ElMessage } from "element-plus";
import { useUserStore } from "@store/user";
import { hasAnyPermission } from "@store/permission";

// 定义应用名称
const APP_TITLE = "DHPG管理后台";

const routes = [
  {
    path: "/login",
    name: "Login",
    component: () => import("@views/Login.vue"),
    meta: { requiresAuth: false, title: "登录" },
  },
  {
    path: "/",
    component: () => import("@layouts/MainLayout.vue"),
    meta: { requiresAuth: true },
    children: [
      {
        path: "",
        name: "Dashboard",
        component: () => import("@views/Dashboard.vue"),
        meta: { title: "仪表盘", icon: "DataLine" },
      },
      {
        path: "devices",
        name: "Devices",
        component: () => import("@views/Devices.vue"),
        meta: { title: "员工管理", icon: "Monitor", permission: "device:view" },
      },
      {
        path: "recordings",
        name: "Recordings",
        component: () => import("@views/Recordings.vue"),
        meta: {
          title: "录屏查看",
          icon: "VideoCamera",
          permissions: ["recording:view", "employee:recording:view_own"],
        },
      },
      {
        path: "policies",
        name: "Policies",
        component: () => import("@views/Policies.vue"),
        meta: {
          title: "策略管理",
          icon: "Document",
          permission: "policy:view",
        },
      },
      {
        path: "settings",
        name: "Settings",
        component: () => import("@views/Settings.vue"),
        meta: {
          title: "系统设置",
          icon: "Setting",
          permission: "policy:update",
        },
      },
      {
        path: "security-whitelist",
        name: "SecurityWhitelist",
        component: () => import("@views/SecurityWhitelist.vue"),
        meta: {
          title: "安全白名单",
          icon: "Lock",
          permission: "policy:update",
        },
      },
      {
        path: "users",
        name: "Users",
        component: () => import("@views/Users.vue"),
        meta: { title: "用户管理", icon: "User", permission: "user:view" },
      },
      {
        path: "roles",
        name: "Roles",
        component: () => import("@views/Roles.vue"),
        meta: { title: "角色管理", icon: "Avatar", permission: "role:view" },
      },
      {
        path: "profile",
        name: "Profile",
        component: () => import("@views/Profile.vue"),
        meta: { title: "个人资料", icon: "UserFilled" },
      },
      {
        path: "portal",
        name: "EmployeePortal",
        component: () => import("@views/portal/EmployeePortal.vue"),
        meta: { title: "个人中心", icon: "User", employeeOnly: true },
      },
      {
        path: "upload",
        name: "Upload",
        component: () => import("@views/UploadManager.vue"),
        meta: {
          title: "上传任务",
          icon: "Upload",
          permission: "recording:upload",
        },
      },
      {
        path: "screenshots",
        name: "Screenshots",
        component: () => import("@views/Screenshots.vue"),
        meta: {
          title: "截图查看",
          icon: "Camera",
          permission: "screenshot:view",
        },
      },
      {
        path: "screenshots-overview",
        name: "ScreenshotOverview",
        component: () => import("@views/ScreenshotOverview.vue"),
        meta: {
          title: "截图概览",
          icon: "Grid",
          permission: "screenshot:view",
        },
      },
      {
        path: "activities",
        name: "Activities",
        component: () => import("@views/Activities.vue"),
        meta: { title: "活动日志", icon: "List", permission: "activity:view" },
      },
      {
        path: "remote-screen",
        name: "RemoteScreen",
        component: () => import("@views/RemoteScreenManager.vue"),
        meta: {
          title: "远程屏幕",
          icon: "Connection",
          permission: "device:remote",
          keepAlive: false,
        },
      },
      // 在 routes 数组中 children 里添加
      {
        path: "attendance",
        redirect: "/attendance/records",
      },
      {
        path: "attendance/records",
        name: "AttendanceRecords",
        component: () => import("@views/attendance/AttendanceRecords.vue"),
        meta: {
          title: "考勤查看",
          icon: "Calendar",
          permission: "attendance:view",
        },
      },
      {
        path: "invite-codes",
        name: "InviteCodes",
        component: () => import("@views/InviteCodes.vue"),
        meta: {
          title: "邀请码管理",
          icon: "Ticket",
          permission: "invite:view",
        },
      },
      {
        path: "attendance/performance",
        name: "PerformanceReview",
        component: () => import("@views/attendance/PerformanceReview.vue"),
        meta: {
          title: "绩效考核",
          icon: "TrendCharts",
          permission: "attendance:view",
        },
      },
      {
        path: "attendance/penalty",
        name: "PenaltyDetails",
        component: () => import("@views/attendance/PenaltyDetails.vue"),
        meta: {
          title: "罚款详情",
          icon: "Warning",
          permission: "attendance:view",
        },
      },
      {
        path: "attendance/telegram",
        name: "TelegramAttendance",
        component: () => import("@views/attendance/TelegramAttendance.vue"),
        meta: {
          title: "TG 配置管理",
          icon: "ChatDotRound",
          permission: "telegram:view",
        },
      },
      {
        path: "attendance/telegram/records",
        name: "TelegramRecords",
        component: () => import("@views/attendance/TelegramRecords.vue"),
        meta: {
          title: "TG 考勤记录",
          icon: "Document",
          permissions: ["attendance:view", "telegram:view"],
        },
      },
      {
        path: "site-management",
        name: "SiteManagement",
        component: () => import("@views/SiteManagement.vue"),
        meta: {
          title: "出款站点",
          icon: "OfficeBuilding",
          permission: "site:view",
        },
      },
      {
        path: "site-stats",
        name: "SiteStats",
        component: () => import("@views/SiteStats.vue"),
        meta: {
          title: "出款统计",
          icon: "TrendCharts",
          permission: "stats:view",
        },
      },
      {
        path: "monthly-stats",
        name: "MonthlyStats",
        component: () => import("@views/MonthlyStats.vue"),
        meta: {
          title: "出款汇总",
          icon: "DataAnalysis",
          permission: "stats:view",
        },
      },
      {
        path: "salary-management",
        name: "SalaryManagement",
        component: () => import("@views/SalaryManagement.vue"),
        meta: {
          title: "工资管理",
          icon: "Money",
          permission: "salary:upload",
        },
      },
      {
        path: "salary-view",
        name: "SalaryView",
        component: () => import("@views/SalaryView.vue"),
        meta: {
          title: "工资查看",
          icon: "Money",
          permission: "salary:view",
        },
      },
      {
        path: "payment-addresses",
        name: "PaymentAddresses",
        component: () => import("@views/PaymentAddresses.vue"),
        meta: {
          title: "收款地址",
          icon: "Wallet",
          permission: "salary:payment_address:view",
        },
      },
      {
        path: "operation-logs",
        name: "OperationLogs",
        component: () => import("@views/OperationLogs.vue"),
        meta: {
          title: "操作日志",
          icon: "Document",
          permission: "operation_log:view",
        },
      },
      {
        path: "domain-monitor",
        redirect: "/domain-monitor/overview",
      },
      {
        path: "domain-monitor/overview",
        name: "DomainMonitorOverview",
        component: () => import("@views/domain-monitor/Overview.vue"),
        meta: {
          title: "域名监控概览",
          icon: "Link",
          permission: "domain_monitor:view",
        },
      },
      {
        path: "domain-monitor/domains",
        name: "DomainMonitorDomains",
        component: () => import("@views/domain-monitor/Domains.vue"),
        meta: {
          title: "域名管理",
          icon: "Link",
          permission: "domain_monitor:view",
        },
      },
      {
        path: "domain-monitor/domains/:id",
        name: "DomainMonitorDomainDetail",
        component: () => import("@views/domain-monitor/DomainDetail.vue"),
        meta: {
          title: "域名详情",
          icon: "Link",
          permission: "domain_monitor:view",
          keepAlive: false,
        },
      },
      {
        path: "domain-monitor/alerts",
        name: "DomainMonitorAlerts",
        component: () => import("@views/domain-monitor/Alerts.vue"),
        meta: {
          title: "域名告警",
          icon: "Bell",
          permission: "domain_monitor:view",
        },
      },
      {
        path: "domain-monitor/settings",
        name: "DomainMonitorSettings",
        component: () => import("@views/domain-monitor/NotifySettings.vue"),
        meta: {
          title: "域名通知配置",
          icon: "Setting",
          permission: "domain_monitor:settings",
        },
      },
      {
        path: "domain-monitor/check-config",
        name: "DomainMonitorCheckConfig",
        component: () => import("@views/domain-monitor/CheckSettings.vue"),
        meta: {
          title: "检测配置",
          icon: "Timer",
          permission: "domain_monitor:settings",
        },
      },
      {
        path: "domain-monitor/nodes",
        name: "DomainMonitorNodes",
        component: () => import("@views/domain-monitor/Nodes.vue"),
        meta: {
          title: "Probe 管理",
          icon: "Connection",
          permission: "domain_monitor:view",
        },
      },
      {
        path: "domain-monitor/reports",
        name: "DomainMonitorReports",
        component: () => import("@views/domain-monitor/Reports.vue"),
        meta: {
          title: "监控报告",
          icon: "Document",
          permission: "domain_monitor:view",
        },
      },
      {
        path: "callback",
        redirect: "/callback/generate",
      },
      {
        path: "callback/generate",
        name: "CallbackGenerate",
        component: () => import("@views/callback/Generate.vue"),
        meta: {
          title: "生成回访名单",
          icon: "DocumentAdd",
          permission: "callback:manage",
        },
      },
      {
        path: "callback/manual",
        redirect: "/callback/manual/period",
      },
      {
        path: "callback/manual/period",
        name: "CallbackManualPeriod",
        component: () => import("@views/callback/ManualPeriod.vue"),
        meta: {
          title: "时段彩金",
          icon: "Upload",
          permission: "callback:manage",
        },
      },
      {
        path: "callback/manual/callback",
        name: "CallbackManualCallback",
        component: () => import("@views/callback/ManualCallback.vue"),
        meta: {
          title: "回访彩金",
          icon: "Upload",
          permission: "callback:manage",
        },
      },
      {
        path: "callback/tasks",
        name: "CallbackTasks",
        component: () => import("@views/callback/Tasks.vue"),
        meta: {
          title: "回访历史",
          icon: "List",
          permission: "callback:view",
        },
      },
      {
        path: "callback/platforms",
        name: "CallbackPlatforms",
        component: () => import("@views/callback/Platforms.vue"),
        meta: {
          title: "平台管理",
          icon: "OfficeBuilding",
          permission: "callback:settings",
        },
      },
      {
        path: "callback/activity",
        name: "CallbackActivity",
        component: () => import("@views/callback/Activity.vue"),
        meta: {
          title: "活动配置",
          icon: "Setting",
          permission: "callback:settings",
        },
      },
      {
        path: "callback/endpoints",
        name: "CallbackEndpoints",
        component: () => import("@views/callback/Endpoints.vue"),
        meta: {
          title: "接口配置",
          icon: "Connection",
          permission: "callback:settings",
        },
      },
      {
        path: "callback/logs",
        name: "CallbackLogs",
        component: () => import("@views/callback/RequestLogs.vue"),
        meta: {
          title: "请求日志",
          icon: "Document",
          permission: "callback:settings",
        },
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

/**
 * 基于用户实际权限检查
 * @param permission 需要的权限
 * @returns 是否拥有权限
 */
function checkPermission(permission: string): boolean {
  const userStore = useUserStore();

  // 未登录时返回 false
  if (!userStore.isAuthenticated) {
    return false;
  }

  // 超级管理员（admin角色）拥有所有权限
  if (userStore.role === "admin") {
    return true;
  }

  // 从 userStore.permissions 读取用户的实际权限列表
  const userPermissions = userStore.permissions || [];
  return userPermissions.includes(permission);
}

// 设置页面标题
const setPageTitle = (to: any) => {
  const pageTitle = to.meta?.title as string;
  if (pageTitle) {
    document.title = `${pageTitle} - ${APP_TITLE}`;
  } else {
    document.title = APP_TITLE;
  }
};

router.beforeEach(async (to, _from, next) => {
  const userStore = useUserStore();

  if (to.meta.requiresAuth !== false) {
    if (!userStore.isAuthenticated) {
      const restored = userStore.restoreSession();
      if (!restored) {
        next("/login");
        return;
      }
      if (!userStore.isAuthenticated) {
        const ok = await userStore.ensureSession();
        if (!ok) {
          next("/login");
          return;
        }
      }
    }
  }

  // 已登录时访问登录页，跳转到首页
  if (to.path === "/login" && userStore.isAuthenticated) {
    next(userStore.isEmployee ? "/portal" : "/");
    return;
  }

  if (userStore.isEmployee && to.path === "/") {
    next("/portal");
    return;
  }

  if (userStore.isEmployee && to.meta.employeeOnly !== true && to.path !== "/portal" && to.path !== "/profile" && to.path !== "/recordings" && to.meta.requiresAuth !== false) {
    if (!to.path.startsWith("/portal") && to.path !== "/profile" && to.path !== "/recordings") {
      next("/portal");
      return;
    }
  }

  if (to.meta.employeeOnly && !userStore.isEmployee && userStore.role !== "admin") {
    next("/");
    return;
  }

  // 权限检查
  const requiredPermissions = to.meta.permissions as string[] | undefined;
  const requiredPermission = to.meta.permission as string;
  if (userStore.isAuthenticated) {
    if (requiredPermissions?.length) {
      if (!hasAnyPermission(requiredPermissions)) {
        sessionStorage.setItem("permissionDenied", "1");
        next("/");
        return;
      }
    } else if (requiredPermission && !checkPermission(requiredPermission)) {
      sessionStorage.setItem("permissionDenied", "1");
      next("/");
      return;
    }
  }

  // 设置浏览器标题
  setPageTitle(to);

  next();
});

router.afterEach(() => {
  if (sessionStorage.getItem("permissionDenied")) {
    sessionStorage.removeItem("permissionDenied");
    ElMessage.warning("权限不足，无法访问该页面");
  }
});

export default router;

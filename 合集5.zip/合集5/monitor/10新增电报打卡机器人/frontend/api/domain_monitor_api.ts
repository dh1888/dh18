import request from "./request";

export interface DmGroup {
  id: string;
  name: string;
  description?: string;
  sortOrder?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface DmDomain {
  id: string;
  groupId?: string | null;
  group?: DmGroup | null;
  domain: string;
  enabled: boolean;
  checkInterval: number;
  remark?: string;
  enableDns: boolean;
  enableHttp: boolean;
  enableSsl: boolean;
  lastCheckAt?: string | null;
  lastDnsStatus: string;
  lastHttpStatus: string;
  lastHttpDurationMs?: number;
  lastSslStatus: string;
  enableWhois?: boolean;
  enableContent?: boolean;
  contentUrl?: string;
  contentHashBaseline?: string;
  contentKeywords?: string | string[];
  lastWhoisStatus?: string;
  lastContentStatus?: string;
  whoisExpireAt?: string | null;
  enableScreenshot?: boolean;
  screenshotUrl?: string;
  lastScreenshotStatus?: string;
  enableBlacklist?: boolean;
  enableProbeDetection?: boolean;
  enableProxyDetection?: boolean;
  enableUserSimulation?: boolean;
  checkStrategy?: Record<string, string> | string;
  probeNodeScope?: string;
  probeNodeIds?: string[] | string;
  healthLevel?: string;
  reachabilityPct?: number;
  probeNodeSummary?: string | ProbeReachabilitySummary;
  expectedIps?: string[] | string;
  expectedAsn?: string;
  expectedCdn?: string;
  lastCdnProvider?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface ProbeNodeStatus {
  nodeId: string;
  nodeName: string;
  country: string;
  city?: string;
  status: string;
  ok: boolean;
  checkType: string;
  checkedAt: string;
}

export interface ProbeReachabilitySummary {
  reachabilityPct: number;
  healthLevel: string;
  nodes: ProbeNodeStatus[];
  totalNodes: number;
  okNodes: number;
}

export interface DmCDNHistory {
  id: string;
  domainId: string;
  previousProvider: string;
  currentProvider: string;
  detectedAt: string;
}

export interface DmCheckResult {
  id: string;
  domainId: string;
  nodeId: string;
  nodeName: string;
  country?: string;
  city?: string;
  checkType: string;
  status: string;
  durationMs?: number;
  httpStatus?: number;
  finalUrl?: string;
  dnsRecords?: string | Record<string, unknown>;
  sslInfo?: string | Record<string, unknown>;
  rawDetail?: string | Record<string, unknown>;
  screenshotPath?: string;
  redirectChain?: string | string[];
  checkedAt: string;
}

export interface DmAlert {
  id: string;
  domainId?: string | null;
  alertType: string;
  severity: string;
  title: string;
  message: string;
  status: string;
  nodeId?: string;
  firstAt: string;
  lastAt: string;
  resolvedAt?: string | null;
}

export interface DmDashboardStats {
  totalDomains: number;
  normalCount: number;
  partialCount?: number;
  abnormalCount: number;
  criticalHealthCount?: number;
  criticalCount: number;
  availability: number;
  globalReachability?: number;
  alertsToday: number;
  openAlerts: number;
  whoisExpiring?: number;
  contentAbnormal?: number;
  onlineNodes?: number;
  droppedCheckJobs?: number;
  droppedPriorityJobs?: number;
}

export interface DmTrendPoint {
  date: string;
  okCount: number;
  failCount: number;
  availability: number;
}

export interface DmHttpCheckPoint {
  id: string;
  domainId: string;
  domain: string;
  checkedAt: string;
  status: string;
  durationMs: number;
  httpStatus: number;
  nodeName: string;
}

export interface DmBatchFailureItem {
  domain: string;
  reason: string;
  issues?: string[];
}

export interface DmCheckBatchStatus {
  batchId: string;
  total: number;
  completed: number;
  failed: number;
  normal?: number;
  running: boolean;
  failures?: DmBatchFailureItem[];
  startedAt: string;
  finishedAt?: string | null;
}

export interface DmCheckSettings {
  defaultCheckInterval: number;
  schedulerTickSeconds: number;
  autoCheckPriority?: boolean;
  telegramReportEnabled?: boolean;
  telegramRealtimeEnabled?: boolean;
  reportServerLabel?: string;
  reportTimezone?: string;
  reportTitle?: string;
  workerPoolSize?: number;
  httpTimeoutSeconds?: number;
  domainCheckTimeoutSeconds?: number;
  fastDnsCheck?: boolean;
  scheduleBatchLimit?: number;
  probeOnBatchCheck?: boolean;
  httpProxyUrl?: string;
  probeRegistrationToken?: string;
}

export interface DmProxyTestStep {
  name: string;
  ok: boolean;
  testUrl?: string;
  httpStatus?: number;
  durationMs?: number;
  summary?: string;
  hint?: string;
  error?: string;
}

export interface DmProxyTestResult {
  ok: boolean;
  mode: "direct" | "proxy" | "socks5";
  proxyDisplay?: string;
  testUrl: string;
  httpStatus?: number;
  durationMs?: number;
  exitIp?: string;
  directExitIp?: string;
  message: string;
  summary?: string;
  hint?: string;
  error?: string;
  steps?: DmProxyTestStep[];
}

export interface DmNode {
  id: string;
  name: string;
  country: string;
  city?: string;
  publicIp?: string;
  version?: string;
  cpuPercent?: number;
  memoryPercent?: number;
  enabled: boolean;
  lastSeenAt?: string | null;
  createdAt?: string;
}

export interface DmProbeTaskLog {
  id: string;
  domainId: string;
  nodeId: string;
  status: string;
  checkSpecs?: string;
  createdAt?: string;
  completedAt?: string | null;
  domain?: DmDomain;
}

export interface DmReport {
  id: string;
  reportType: string;
  periodStart: string;
  periodEnd: string;
  filePath: string;
  summary?: string | Record<string, unknown>;
  createdAt: string;
}

export interface DmTelegramBot {
  id: string;
  botName: string;
  botToken?: string;
  botUsername?: string;
  botId?: number;
  enabled: boolean;
  remark?: string;
  verifiedAt?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface DmTelegramGroup {
  id: string;
  botId: string;
  groupName: string;
  chatId: string;
  chatType?: string;
  enabled: boolean;
  createdAt?: string;
}

export interface DmAlertRoute {
  id: string;
  name: string;
  alertTypes: string | string[];
  severities: string | string[];
  groupId: string;
  sendMode: string;
  enabled: boolean;
  createdAt?: string;
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page?: number;
  pageSize?: number;
}

const domainMonitorApi = {
  getOverview: () =>
    request.get<DmDashboardStats>("/domain-monitor/dashboard/overview"),

  getTrends: (days = 7) =>
    request.get<DmTrendPoint[]>("/domain-monitor/dashboard/trends", {
      params: { days },
    }),

  getHttpChecks: (params?: {
    days?: number;
    limit?: number;
    domainId?: string;
  }) =>
    request.get<DmHttpCheckPoint[]>("/domain-monitor/dashboard/http-checks", {
      params,
    }),

  getCheckSettings: () =>
    request.get<DmCheckSettings>("/domain-monitor/settings/check"),
  saveCheckSettings: (data: DmCheckSettings & { applyToAllDomains?: boolean }) =>
    request.put<DmCheckSettings>("/domain-monitor/settings/check", data),
  testHttpProxy: (data?: { httpProxyUrl?: string; testUrl?: string }) =>
    request.post<DmProxyTestResult>("/domain-monitor/settings/check/test-proxy", data ?? {}),

  listGroups: () => request.get<DmGroup[]>("/domain-monitor/groups"),
  createGroup: (data: Partial<DmGroup>) =>
    request.post<DmGroup>("/domain-monitor/groups", data),
  updateGroup: (id: string, data: Partial<DmGroup>) =>
    request.put<DmGroup>(`/domain-monitor/groups/${id}`, data),
  deleteGroup: (id: string) =>
    request.delete(`/domain-monitor/groups/${id}`),

  listDomains: (params?: {
    page?: number;
    pageSize?: number;
    groupId?: string;
    keyword?: string;
    enabled?: boolean;
  }) => request.get<Paginated<DmDomain>>("/domain-monitor/domains", { params }),

  getDomain: (id: string) =>
    request.get<{ domain: DmDomain; recentChecks: DmCheckResult[] }>(
      `/domain-monitor/domains/${id}`,
    ),

  createDomain: (data: Partial<DmDomain> & { domain: string }) =>
    request.post<DmDomain>("/domain-monitor/domains", data),
  updateDomain: (id: string, data: Partial<DmDomain>) =>
    request.put<DmDomain>(`/domain-monitor/domains/${id}`, data),
  deleteDomain: (id: string) =>
    request.delete(`/domain-monitor/domains/${id}`),
  checkDomainNow: (id: string) =>
    request.post(`/domain-monitor/domains/${id}/check`),
  checkAllDomains: () =>
    request.post<{ queued: number; total: number; batchId: string }>(
      "/domain-monitor/domains/check-all",
    ),
  getCheckBatchStatus: (batchId: string) =>
    request.get<DmCheckBatchStatus>("/domain-monitor/domains/check-batch/status", {
      params: { batchId },
    }),
  resetContentBaseline: (id: string, hash?: string) =>
    request.post<{ contentHashBaseline: string }>(
      `/domain-monitor/domains/${id}/content/baseline`,
      hash ? { hash } : {},
    ),
  listChecks: (id: string, checkType?: string, nodeId?: string) =>
    request.get<DmCheckResult[]>(`/domain-monitor/domains/${id}/checks`, {
      params: { checkType: checkType || undefined, nodeId: nodeId || undefined },
    }),
  getReachability: (id: string) =>
    request.get<ProbeReachabilitySummary>(`/domain-monitor/domains/${id}/reachability`),
  listCDNHistory: (id: string) =>
    request.get<DmCDNHistory[]>(`/domain-monitor/domains/${id}/cdn-history`),

  exportDomains: (format: "csv" | "xlsx" = "csv") =>
    request.get("/domain-monitor/domains/export", {
      params: { format },
      responseType: "blob",
    }),

  importDomains: (formData: FormData) =>
    request.post<{ created: number; skipped: number }>(
      "/domain-monitor/domains/import",
      formData,
      { timeout: 120000 },
    ),

  batchUpdateDomains: (data: {
    ids: string[];
    patch: {
      updateGroup?: boolean;
      groupId?: string;
      clearGroup?: boolean;
      enabled?: boolean;
      checkInterval?: number;
      syncCheckInterval?: boolean;
      enableDns?: boolean;
      enableHttp?: boolean;
      enableSsl?: boolean;
      enableWhois?: boolean;
      enableContent?: boolean;
    };
  }) =>
    request.post<{ updated: number }>(
      "/domain-monitor/domains/batch-update",
      data,
    ),

  syncDomainCheckIntervals: () =>
    request.post<{ updated: number; defaultCheckInterval: number }>(
      "/domain-monitor/domains/sync-check-interval",
    ),

  listAlerts: (params?: {
    page?: number;
    pageSize?: number;
    status?: string;
    severity?: string;
  }) => request.get<Paginated<DmAlert>>("/domain-monitor/alerts", { params }),

  ackAlert: (id: string) =>
    request.put(`/domain-monitor/alerts/${id}/ack`),
  resolveAlert: (id: string) =>
    request.put(`/domain-monitor/alerts/${id}/resolve`),

  listBots: () =>
    request.get<DmTelegramBot[]>("/domain-monitor/notify/telegram/bots"),
  createBot: (data: {
    botName: string;
    botToken: string;
    enabled?: boolean;
    remark?: string;
  }) => request.post<DmTelegramBot>("/domain-monitor/notify/telegram/bots", data),
  updateBot: (
    id: string,
    data: Partial<{ botName: string; botToken: string; enabled: boolean; remark: string }>,
  ) => request.put<DmTelegramBot>(`/domain-monitor/notify/telegram/bots/${id}`, data),
  deleteBot: (id: string) =>
    request.delete(`/domain-monitor/notify/telegram/bots/${id}`),
  testBot: (id: string) =>
    request.post(`/domain-monitor/notify/telegram/bots/${id}/test`),
  discoverGroups: (botId: string) =>
    request.get<Array<{ chatId: string; groupName: string; chatType?: string }>>(
      `/domain-monitor/notify/telegram/bots/${botId}/groups`,
    ),
  bindGroup: (data: {
    botId: string;
    groupName: string;
    chatId: string;
    chatType?: string;
  }) => request.post<DmTelegramGroup>("/domain-monitor/notify/telegram/groups", data),
  listTelegramGroups: (botId?: string) =>
    request.get<DmTelegramGroup[]>("/domain-monitor/notify/telegram/groups", {
      params: botId ? { botId } : undefined,
    }),
  deleteTelegramGroup: (id: string) =>
    request.delete(`/domain-monitor/notify/telegram/groups/${id}`),
  testPush: (data: { botId: string; chatId: string }) =>
    request.post("/domain-monitor/notify/telegram/test-push", data),

  listRoutes: () =>
    request.get<DmAlertRoute[]>("/domain-monitor/notify/routes"),
  createRoute: (data: {
    name: string;
    alertTypes?: string[];
    severities?: string[];
    groupId: string;
    sendMode?: string;
    enabled?: boolean;
  }) => request.post<DmAlertRoute>("/domain-monitor/notify/routes", data),
  updateRoute: (
    id: string,
    data: Partial<{
      name: string;
      alertTypes: string[];
      severities: string[];
      groupId: string;
      sendMode: string;
      enabled: boolean;
    }>,
  ) => request.put<DmAlertRoute>(`/domain-monitor/notify/routes/${id}`, data),
  deleteRoute: (id: string) =>
    request.delete(`/domain-monitor/notify/routes/${id}`),

  listNodes: () => request.get<DmNode[]>("/domain-monitor/nodes"),
  createNode: (data: { name: string; country?: string; city?: string; enabled?: boolean }) =>
    request.post<{ id: string; apiKey: string } & DmNode>("/domain-monitor/nodes", data),
  updateNode: (id: string, data: Partial<DmNode>) =>
    request.put<DmNode>(`/domain-monitor/nodes/${id}`, data),
  deleteNode: (id: string) => request.delete(`/domain-monitor/nodes/${id}`),
  getNodeLogs: (id: string) =>
    request.get<DmProbeTaskLog[]>(`/domain-monitor/nodes/${id}/logs`),

  listReports: () => request.get<DmReport[]>("/domain-monitor/reports"),
  generateReport: (reportType: "daily" | "weekly" = "daily") =>
    request.post("/domain-monitor/reports/generate", { reportType }),
  downloadReport: (id: string) =>
    request.get(`/domain-monitor/reports/${id}/download`, { responseType: "blob" }),

  fetchScreenshot: (path: string) =>
    request.get<Blob>("/domain-monitor/media/screenshot", {
      params: { path },
      responseType: "blob",
    }),
};

export default domainMonitorApi;

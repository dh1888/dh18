<template>
  <el-container class="layout-container">
    <el-aside :width="isCollapse ? '64px' : '220px'" class="sidebar">
      <div class="logo">
        <img src="/dh.png" alt="Logo" class="logo-img" />
        <span v-if="!isCollapse">DHPG管理后台</span>
      </div>

      <div
        class="sidebar-menu-scroll"
        :class="{ 'is-menu-hovered': sidebarMenuHovered }"
        @mouseenter="sidebarMenuHovered = true"
        @mouseleave="sidebarMenuHovered = false"
      >
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        :collapse-transition="false"
        router
        unique-opened
        :default-openeds="initialMenuOpeneds"
        @open="handleMenuOpen"
        @close="handleMenuClose"
        background-color="transparent"
        text-color="#fff"
        active-text-color="#409eff"
      >
        <!-- 员工门户 -->
        <template v-if="userStore.isEmployee">
          <el-menu-item index="/portal">
            <el-icon><User /></el-icon>
            <span>个人中心</span>
          </el-menu-item>
          <el-menu-item index="/recordings" v-permission="['recording:view', 'employee:recording:view_own']">
            <el-icon><VideoCamera /></el-icon>
            <span>我的录屏</span>
          </el-menu-item>
          <el-menu-item index="/profile">
            <el-icon><UserFilled /></el-icon>
            <span>账号安全</span>
          </el-menu-item>
        </template>

        <!-- 1. 仪表盘 -->
        <el-menu-item v-if="!userStore.isEmployee" index="/">
          <el-icon><DataLine /></el-icon>
          <span>仪表盘</span>
        </el-menu-item>

        <!-- 2. 截图查看 -->
        <el-menu-item v-if="!userStore.isEmployee" index="/screenshots" v-permission="'screenshot:view'">
          <el-icon><Camera /></el-icon>
          <span>截图查看</span>
        </el-menu-item>

        <!-- 2.5 截图概览 -->
        <el-menu-item
          v-if="!userStore.isEmployee"
          index="/screenshots-overview"
          v-permission="'screenshot:view'"
        >
          <el-icon><Grid /></el-icon>
          <span>截图概览</span>
        </el-menu-item>

        <!-- 3. 录屏查看 -->
        <el-menu-item
          v-if="!userStore.isEmployee"
          index="/recordings"
          v-permission="'recording:view'"
        >
          <el-icon><VideoCamera /></el-icon>
          <span>录屏查看</span>
        </el-menu-item>

        <el-menu-item index="/remote-screen" v-permission="'device:remote'">
          <el-icon><Connection /></el-icon>
          <span>远程屏幕</span>
        </el-menu-item>

        <!-- 4. 员工管理（原设备管理） -->
        <el-menu-item index="/devices" v-permission="'device:view'">
          <el-icon><User /></el-icon>
          <span>员工管理</span>
        </el-menu-item>

        <!-- 5. 活动日志 -->
        <el-menu-item index="/activities" v-permission="'activity:view'">
          <el-icon><List /></el-icon>
          <span>活动日志</span>
        </el-menu-item>

        <!-- 6. 设备管理组（上传管理、策略管理） -->
        <el-sub-menu index="device-group" v-if="hasDeviceGroupPermission">
          <template #title>
            <el-icon><Monitor /></el-icon>
            <span>设备管理</span>
          </template>

          <el-menu-item index="/upload" v-permission="'recording:upload'">
            <el-icon><Upload /></el-icon>
            <span>上传任务</span>
          </el-menu-item>

          <el-menu-item index="/policies" v-permission="'policy:view'">
            <el-icon><Document /></el-icon>
            <span>策略管理</span>
          </el-menu-item>
        </el-sub-menu>

        <!-- 在现有菜单后、系统管理前添加 -->

        <!-- 出款管理组 -->
        <el-sub-menu index="payment-group" v-if="hasPaymentPermission">
          <template #title>
            <el-icon><Money /></el-icon>
            <span>出款管理</span>
          </template>

          <el-menu-item index="/site-management" v-permission="'site:view'">
            <el-icon><OfficeBuilding /></el-icon>
            <span>出款站点</span>
          </el-menu-item>

          <el-menu-item index="/site-stats" v-permission="'stats:view'">
            <el-icon><TrendCharts /></el-icon>
            <span>出款统计</span>
          </el-menu-item>

          <el-menu-item index="/monthly-stats" v-permission="'stats:view'">
            <el-icon><DataAnalysis /></el-icon>
            <span>出款汇总</span>
          </el-menu-item>
        </el-sub-menu>

        <!-- 考勤绩效组 -->
        <el-sub-menu index="attendance-group" v-if="hasAttendancePermission">
          <template #title>
            <el-icon><Calendar /></el-icon>
            <span>考勤绩效</span>
          </template>

          <el-menu-item
            index="/attendance/records"
            v-permission="'attendance:view'"
          >
            <el-icon><Calendar /></el-icon>
            <span>考勤查看</span>
          </el-menu-item>

          <el-menu-item
            index="/attendance/performance"
            v-permission="'attendance:view'"
          >
            <el-icon><TrendCharts /></el-icon>
            <span>绩效考核</span>
          </el-menu-item>

          <el-menu-item
            index="/attendance/penalty"
            v-permission="'attendance:view'"
          >
            <el-icon><Warning /></el-icon>
            <span>罚款详情</span>
          </el-menu-item>
        </el-sub-menu>

        <el-sub-menu index="telegram-group" v-if="showTelegramMenu">
          <template #title>
            <el-icon><ChatDotRound /></el-icon>
            <span>Telegram 考勤</span>
          </template>

          <el-menu-item
            index="/attendance/telegram/records"
            v-if="canViewTelegramRecords"
          >
            <el-icon><Document /></el-icon>
            <span>考勤记录</span>
          </el-menu-item>

          <el-menu-item
            index="/attendance/telegram"
            v-if="hasTelegramPermission"
          >
            <el-icon><Setting /></el-icon>
            <span>配置管理</span>
          </el-menu-item>
        </el-sub-menu>

        <!-- 工资管理组 -->
        <el-sub-menu index="salary-group" v-if="hasSalaryPermission">
          <template #title>
            <el-icon><Money /></el-icon>
            <span>工资管理</span>
          </template>

          <el-menu-item
            index="/salary-management"
            v-permission="'salary:upload'"
          >
            <el-icon><Upload /></el-icon>
            <span>工资管理</span>
          </el-menu-item>

          <el-menu-item index="/salary-view" v-permission="'salary:view'">
            <el-icon><View /></el-icon>
            <span>工资查看</span>
          </el-menu-item>

          <el-menu-item
            index="/payment-addresses"
            v-permission="'salary:payment_address:view'"
          >
            <el-icon><Wallet /></el-icon>
            <span>收款地址</span>
          </el-menu-item>
        </el-sub-menu>

        <!-- 域名监控组 -->
        <el-sub-menu index="domain-monitor-group" v-if="hasDomainMonitorPermission">
          <template #title>
            <el-icon><Link /></el-icon>
            <span>域名监控</span>
          </template>

          <el-menu-item
            index="/domain-monitor/overview"
            v-permission="'domain_monitor:view'"
          >
            <el-icon><DataLine /></el-icon>
            <span>监控概览</span>
          </el-menu-item>

          <el-menu-item
            index="/domain-monitor/domains"
            v-permission="'domain_monitor:view'"
          >
            <el-icon><Link /></el-icon>
            <span>域名管理</span>
          </el-menu-item>

          <el-menu-item
            index="/domain-monitor/alerts"
            v-permission="'domain_monitor:view'"
          >
            <el-icon><Warning /></el-icon>
            <span>告警中心</span>
          </el-menu-item>

          <el-menu-item
            index="/domain-monitor/check-config"
            v-permission="'domain_monitor:settings'"
          >
            <el-icon><Timer /></el-icon>
            <span>检测配置</span>
          </el-menu-item>

          <el-menu-item
            index="/domain-monitor/settings"
            v-permission="'domain_monitor:settings'"
          >
            <el-icon><Setting /></el-icon>
            <span>通知配置</span>
          </el-menu-item>

          <el-menu-item
            index="/domain-monitor/nodes"
            v-permission="'domain_monitor:view'"
          >
            <el-icon><Connection /></el-icon>
            <span>Probe 管理</span>
          </el-menu-item>

          <el-menu-item
            index="/domain-monitor/reports"
            v-permission="'domain_monitor:view'"
          >
            <el-icon><Document /></el-icon>
            <span>监控报告</span>
          </el-menu-item>
        </el-sub-menu>

        <!-- 运营工具 -->
        <el-sub-menu index="ops-tools-group" v-if="hasCallbackPermission">
          <template #title>
            <el-icon><Tools /></el-icon>
            <span>运营工具</span>
          </template>
          <el-menu-item
            index="/callback/generate"
            v-permission="'callback:manage'"
          >
            <el-icon><DocumentAdd /></el-icon>
            <span>生成名单</span>
          </el-menu-item>
          <el-menu-item
            index="/callback/manual/period"
            v-permission="'callback:manage'"
          >
            <el-icon><Upload /></el-icon>
            <span>时段彩金</span>
          </el-menu-item>
          <el-menu-item
            index="/callback/manual/callback"
            v-permission="'callback:manage'"
          >
            <el-icon><Upload /></el-icon>
            <span>回访彩金</span>
          </el-menu-item>
          <el-menu-item index="/callback/tasks" v-permission="'callback:view'">
            <el-icon><List /></el-icon>
            <span>历史任务</span>
          </el-menu-item>
          <el-menu-item
            index="/callback/platforms"
            v-permission="'callback:settings'"
          >
            <el-icon><OfficeBuilding /></el-icon>
            <span>平台管理</span>
          </el-menu-item>
          <el-menu-item
            index="/callback/activity"
            v-permission="'callback:settings'"
          >
            <el-icon><Setting /></el-icon>
            <span>活动配置</span>
          </el-menu-item>
          <el-menu-item
            index="/callback/endpoints"
            v-permission="'callback:settings'"
          >
            <el-icon><Connection /></el-icon>
            <span>接口配置</span>
          </el-menu-item>
          <el-menu-item index="/callback/logs" v-permission="'callback:settings'">
            <el-icon><Document /></el-icon>
            <span>请求日志</span>
          </el-menu-item>
        </el-sub-menu>

        <el-menu-item
          index="/operation-logs"
          v-permission="'operation_log:view'"
        >
          <el-icon><Document /></el-icon>
          <span>操作日志</span>
        </el-menu-item>

        <!-- 7. 系统管理组 -->
        <el-sub-menu index="system" v-if="hasSystemPermission">
          <template #title>
            <el-icon><Setting /></el-icon>
            <span>系统管理</span>
          </template>

          <el-menu-item index="/users" v-permission="'user:view'">
            <el-icon><User /></el-icon>
            <span>用户管理</span>
          </el-menu-item>

          <el-menu-item index="/roles" v-permission="'role:view'">
            <el-icon><Avatar /></el-icon>
            <span>角色管理</span>
          </el-menu-item>

          <el-menu-item index="/profile">
            <el-icon><UserFilled /></el-icon>
            <span>个人资料</span>
          </el-menu-item>

          <el-menu-item index="/settings" v-permission="'policy:update'">
            <el-icon><Setting /></el-icon>
            <span>系统设置</span>
          </el-menu-item>

          <el-menu-item index="/security-whitelist" v-permission="'policy:update'">
            <el-icon><Lock /></el-icon>
            <span>安全白名单</span>
          </el-menu-item>

          <el-menu-item index="/invite-codes" v-permission="'invite:view'">
            <el-icon><Ticket /></el-icon>
            <span>邀请码管理</span>
          </el-menu-item>
        </el-sub-menu>

        <!-- 如果没有系统管理权限，单独显示个人资料 -->
        <el-menu-item index="/profile" v-if="!hasSystemPermission">
          <el-icon><UserFilled /></el-icon>
          <span>个人资料</span>
        </el-menu-item>
      </el-menu>
      </div>
    </el-aside>

    <el-container class="main-panel">
      <div class="layout-top-fixed">
      <el-header class="header">
        <div class="header-left">
          <el-icon class="collapse-btn" @click="toggleCollapse">
            <Fold v-if="!isCollapse" />
            <Expand v-else />
          </el-icon>
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item
              v-for="(item, index) in breadcrumbs"
              :key="index"
              :to="index === breadcrumbs.length - 1 ? undefined : item.path"
            >
              {{ item.title }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>

        <div class="header-right">
          <!-- 在线设备图标 -->
          <el-tooltip
            v-if="userStore.hasPermission('device:view')"
            :content="`在线设备: ${onlineDeviceCount}`"
            placement="bottom"
          >
            <el-badge
              :value="onlineDeviceCount"
              :hidden="onlineDeviceCount === 0"
              type="primary"
            >
              <el-icon :size="20" class="online-icon" @click="goToDevices"
                ><Connection
              /></el-icon>
            </el-badge>
          </el-tooltip>

          <el-tooltip
            v-if="userStore.hasPermission('screenshot:view')"
            content="查看截图"
            placement="bottom"
          >
            <el-icon :size="20" class="header-icon" @click="goToScreenshots">
              <Camera />
            </el-icon>
          </el-tooltip>

          <el-tooltip
            v-if="userStore.hasPermission('recording:view') || userStore.hasPermission('employee:recording:view_own')"
            content="查看录屏"
            placement="bottom"
          >
            <el-icon :size="20" class="header-icon" @click="goToRecordings">
              <VideoCamera />
            </el-icon>
          </el-tooltip>

          <el-tooltip
            v-if="userStore.hasPermission('employee:client:download')"
            :content="clientDownloadTooltip"
            placement="bottom"
          >
            <el-icon
              :size="20"
              class="header-icon"
              :class="{ 'is-downloading': clientDownloading }"
              @click="handleClientDownload"
            >
              <Download />
            </el-icon>
          </el-tooltip>

          <el-popover
            v-model:visible="notificationVisible"
            placement="bottom-end"
            :width="360"
            trigger="click"
            popper-class="notification-popover"
            @show="loadNotifications"
          >
            <template #reference>
              <el-badge
                :value="notificationUnread"
                :hidden="notificationUnread === 0"
                type="danger"
                class="notification-badge"
              >
                <el-tooltip content="通知" placement="bottom">
                  <el-icon :size="20" class="header-icon notification-icon">
                    <Bell />
                  </el-icon>
                </el-tooltip>
              </el-badge>
            </template>
            <div class="notification-panel">
              <div class="notification-panel-header">
                <span class="notification-panel-title">通知</span>
                <el-button
                  v-if="notificationUnread > 0"
                  link
                  type="primary"
                  size="small"
                  @click="markAllNotificationsRead"
                >
                  全部已读
                </el-button>
              </div>
              <div v-if="notificationLoading" class="notification-loading">
                加载中...
              </div>
              <div v-else-if="notifications.length === 0" class="notification-empty">
                暂无通知
              </div>
              <div v-else class="notification-list">
                <div
                  v-for="item in notifications"
                  :key="item.id"
                  class="notification-item"
                  :class="{ unread: !item.isRead }"
                  @click="handleNotificationClick(item)"
                >
                  <div class="notification-item-title">{{ item.title }}</div>
                  <div class="notification-item-content">{{ item.content }}</div>
                  <div class="notification-item-time">{{ formatNotificationTime(item.createdAt) }}</div>
                </div>
              </div>
            </div>
          </el-popover>

          <!-- ✅ 修改：头像下拉菜单（移除原有用户图标，使用头像） -->
          <el-dropdown @command="handleCommand" class="user-dropdown">
            <div class="user-info">
              <!-- 头像区域 -->
              <el-avatar :size="36" :src="userAvatar" class="user-avatar" />
              <span class="username">{{ userStore.username || "Admin" }}</span>
              <el-icon class="arrow-icon"><ArrowDown /></el-icon>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">
                  <el-icon><User /></el-icon>
                  个人资料
                </el-dropdown-item>
                <el-dropdown-item command="changePassword">
                  <el-icon><Lock /></el-icon>
                  修改密码
                </el-dropdown-item>
                <el-dropdown-item command="logout" divided>
                  <el-icon><SwitchButton /></el-icon>
                  退出登录
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <!-- 多标签页：选中标签页才显示关闭按钮 -->
      <div class="tabs-section" v-if="visitedViews.length > 0">
        <div class="tabs-container">
          <button
            v-show="tabsOverflow"
            type="button"
            class="tabs-nav-btn"
            :disabled="!canScrollLeft"
            title="向左滚动"
            @click="scrollTabs('left')"
          >
            <el-icon><ArrowLeft /></el-icon>
          </button>
          <div
            ref="tabsScrollRef"
            class="tabs-scroll"
            @scroll="updateTabsScrollState"
          >
            <div
              v-for="item in visitedViews"
              :key="item.path"
              class="tab-item"
              :class="{ active: activeTab === item.path }"
              @click="handleTabClick(item.path)"
              @contextmenu.prevent="(e) => handleContextMenu(e, item.path)"
              @mouseenter="hoveredTab = item.path"
              @mouseleave="hoveredTab = null"
            >
              <span class="tab-icon">
                <el-icon><component :is="getTabIcon(item.path)" /></el-icon>
              </span>
              <span class="tab-title">{{ item.title }}</span>
              <!-- 关闭按钮：鼠标悬停或当前激活时显示 -->
              <span
                v-if="hoveredTab === item.path || activeTab === item.path"
                class="tab-close"
                @click.stop="removeTab(item.path)"
                title="关闭"
              >
                <el-icon><Close /></el-icon>
              </span>
            </div>
          </div>
          <button
            v-show="tabsOverflow"
            type="button"
            class="tabs-nav-btn"
            :disabled="!canScrollRight"
            title="向右滚动"
            @click="scrollTabs('right')"
          >
            <el-icon><ArrowRight /></el-icon>
          </button>
          <!-- 标签页右侧操作按钮 -->
          <div class="tabs-actions" v-if="visitedViews.length > 0">
            <el-dropdown
              @command="handleTabsCommand"
              trigger="click"
              placement="bottom-end"
            >
              <el-button :icon="ArrowDown" size="small" circle />
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item
                    command="close-current"
                    :disabled="visitedViews.length === 1"
                  >
                    <el-icon><Close /></el-icon>
                    关闭当前
                  </el-dropdown-item>
                  <el-dropdown-item
                    command="close-other"
                    :disabled="visitedViews.length === 1"
                  >
                    <el-icon><Remove /></el-icon>
                    关闭其他
                  </el-dropdown-item>
                  <el-dropdown-item command="close-all">
                    <el-icon><FolderDelete /></el-icon>
                    关闭所有
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
        </div>
      </div>

      <!-- 标签页右键菜单 -->
      <div
        v-if="contextMenuVisible"
        class="tab-context-menu"
        :style="{ left: contextMenuX + 'px', top: contextMenuY + 'px' }"
        @click.stop
      >
        <div class="context-menu-item" @click="closeCurrentTab">
          <el-icon><Close /></el-icon>
          <span>关闭当前</span>
        </div>
        <div class="context-menu-item" @click="closeOtherTabs">
          <el-icon><Remove /></el-icon>
          <span>关闭其他</span>
        </div>
        <div class="context-menu-item" @click="closeAllTabs">
          <el-icon><FolderDelete /></el-icon>
          <span>关闭所有</span>
        </div>
      </div>
      </div>

      <el-main class="main-content">
        <router-view v-slot="{ Component, route: currentRoute }">
          <transition name="fade-transform" mode="out-in">
            <keep-alive :include="cachedViews">
              <component :is="Component" :key="currentRoute.path" />
            </keep-alive>
          </transition>
        </router-view>
      </el-main>
    </el-container>

    <!-- 移动端遮罩层 -->
    <div
      v-if="isMobile && !isCollapse"
      class="mobile-mask"
      @click="toggleCollapse"
    ></div>

    <!-- ✅ 新增：修改密码对话框 -->
    <el-dialog
      v-model="changePasswordVisible"
      title="修改密码"
      width="450px"
      class="animate-dialog"
    >
      <el-form
        :model="passwordForm"
        :rules="passwordRules"
        ref="passwordFormRef"
        label-width="100px"
      >
        <el-form-item label="当前密码" prop="oldPassword">
          <el-input
            v-model="passwordForm.oldPassword"
            type="password"
            show-password
            placeholder="请输入当前密码"
          />
        </el-form-item>
        <el-form-item label="新密码" prop="newPassword">
          <el-input
            v-model="passwordForm.newPassword"
            type="password"
            show-password
            placeholder="请输入新密码（至少6位）"
          />
        </el-form-item>
        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input
            v-model="passwordForm.confirmPassword"
            type="password"
            show-password
            placeholder="请再次输入新密码"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="changePasswordVisible = false">取消</el-button>
        <el-button
          type="primary"
          @click="confirmChangePassword"
          :loading="changePasswordLoading"
          >确定</el-button
        >
      </template>
    </el-dialog>
  </el-container>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, watch, reactive, nextTick } from "vue";
import { useRoute, useRouter } from "vue-router";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Fold,
  Expand,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Close,
  Remove,
  FolderDelete,
  DataLine,
  Camera,
  Monitor,
  VideoCamera,
  Upload,
  List,
  Document,
  Setting,
  User,
  Avatar,
  UserFilled,
  Connection,
  Odometer,
  Picture,
  Grid,
  Lock,
  SwitchButton,
  TrendCharts,
  Warning,
  Money,
  View,
  Wallet,
  Link,
  Bell,
  Timer,
  OfficeBuilding,
  Calendar,
  Ticket,
  Tools,
  Phone,
  DocumentAdd,
  Download,
  ChatDotRound,
} from "@element-plus/icons-vue";
import { useUserStore } from "@store/user";
import { useWebSocketStore } from "@store/websocket";
import { userApi, metaApi, deviceApi } from "@api/index";
import { downloadClientInstaller } from "@api/clientDownload";
import workforceApi from "@api/workforce_api";
import notificationApi from "@api/notification_api";
import type { UserNotification } from "@api/notification_api";
import type { Device } from "@api/types";

const route = useRoute();
const router = useRouter();
const userStore = useUserStore();
const wsStore = useWebSocketStore();
const devices = ref<Device[]>([]);
const onlineDeviceCount = ref(0);

const notificationVisible = ref(false);
const notificationLoading = ref(false);
const notificationUnread = ref(0);
const notifications = ref<UserNotification[]>([]);
const shownPopupIds = new Set<string>();
let notificationCountTimer: ReturnType<typeof setInterval> | null = null;
let notificationPopupTimer: ReturnType<typeof setInterval> | null = null;

function formatNotificationTime(value: string) {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString("zh-CN", { hour12: false });
}

async function loadNotifications() {
  notificationLoading.value = true;
  try {
    const res = await notificationApi.list({ limit: 30 });
    notifications.value = res.data?.items || [];
    notificationUnread.value = res.data?.unreadCount || 0;
  } catch {
    notifications.value = [];
  } finally {
    notificationLoading.value = false;
  }
}

async function refreshNotificationUnread() {
  try {
    const res = await notificationApi.unreadCount();
    notificationUnread.value = res.data?.unreadCount || 0;
  } catch {
    /* ignore */
  }
}

async function checkPopupNotifications() {
  try {
    const res = await notificationApi.popups();
    const items = res.data || [];
    for (const item of items) {
      if (shownPopupIds.has(item.id)) continue;
      shownPopupIds.add(item.id);
      try {
        await ElMessageBox.alert(item.content, item.title, {
          confirmButtonText: "知道了",
          type: item.type === "salary_paid" ? "success" : "info",
        });
      } catch {
        /* closed */
      } finally {
        try {
          await notificationApi.markRead(item.id);
        } catch {
          /* ignore */
        }
        await refreshNotificationUnread();
      }
    }
  } catch {
    /* ignore */
  }
}

async function handleNotificationClick(item: UserNotification) {
  if (item.isRead) return;
  try {
    await notificationApi.markRead(item.id);
    item.isRead = true;
    notificationUnread.value = Math.max(0, notificationUnread.value - 1);
  } catch {
    /* ignore */
  }
}

async function markAllNotificationsRead() {
  try {
    await notificationApi.markAllRead();
    notifications.value.forEach((item) => {
      item.isRead = true;
    });
    notificationUnread.value = 0;
  } catch (error: any) {
    ElMessage.error(error.message || "操作失败");
  }
}

const isCollapse = ref(false);
const sidebarMenuHovered = ref(false);

const goToDevices = () => {
  router.push("/devices");
};

const goToScreenshots = () => {
  router.push("/screenshots");
};

const goToRecordings = () => {
  router.push("/recordings");
};

const clientDownloading = ref(false);
const clientVersion = ref("");
const clientDownloadTooltip = computed(() =>
  clientVersion.value
    ? `下载客户端 v${clientVersion.value}`
    : "下载客户端",
);

const loadClientDownloadMeta = async () => {
  if (!userStore.hasPermission("employee:client:download")) return;
  try {
    const res = await workforceApi.getClientDownload();
    const data = res.data || res;
    clientVersion.value = data.version || "";
  } catch {
    clientVersion.value = "";
  }
};

const handleClientDownload = async () => {
  if (clientDownloading.value) return;
  clientDownloading.value = true;
  try {
    await downloadClientInstaller();
  } catch (error: any) {
    ElMessage.error(error.message || "客户端下载失败，请联系管理员配置安装包");
  } finally {
    clientDownloading.value = false;
  }
};

const roleAvatarMap = {
  admin: "/1.png", // 管理员头像
  operator: "/2.jpg", // 操作员头像
  auditor: "/2.jpg", // 审计员头像
  default: "1.png", // 默认头像
};

// ✅ 头像相关
const userAvatar = computed(() => {
  const role = userStore.role;
  return (
    roleAvatarMap[role as keyof typeof roleAvatarMap] || roleAvatarMap.default
  );
});

// 修改密码对话框
const changePasswordVisible = ref(false);
const changePasswordLoading = ref(false);
const passwordFormRef = ref();
const passwordForm = reactive({
  oldPassword: "",
  newPassword: "",
  confirmPassword: "",
});

const passwordRules = {
  oldPassword: [{ required: true, message: "请输入当前密码", trigger: "blur" }],
  newPassword: [
    { required: true, message: "请输入新密码", trigger: "blur" },
    { min: 6, message: "密码长度不能小于6位", trigger: "blur" },
    {
      pattern: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/,
      message: "密码必须包含字母和数字",
      trigger: "blur",
    },
  ],
  confirmPassword: [
    { required: true, message: "请确认密码", trigger: "blur" },
    {
      validator: (_: any, value: string, callback: Function) => {
        if (value !== passwordForm.newPassword) {
          callback(new Error("两次输入的密码不一致"));
        } else {
          callback();
        }
      },
      trigger: "blur",
    },
  ],
};

const activeMenu = computed(() => route.path);

// ========== 手风琴效果相关（初始值只读，避免 open/close 时整棵菜单重渲染） ==========
const getDefaultOpeneds = (): string[] => {
  const saved = localStorage.getItem("openedMenus");
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : ["device-group"];
    } catch {
      return ["device-group"];
    }
  }
  return ["device-group"];
};

const initialMenuOpeneds = getDefaultOpeneds();

let menuPersistTimer: ReturnType<typeof setTimeout> | null = null;

const schedulePersistOpenedMenus = (openeds: string[]) => {
  if (menuPersistTimer) clearTimeout(menuPersistTimer);
  menuPersistTimer = setTimeout(() => {
    localStorage.setItem("openedMenus", JSON.stringify(openeds));
  }, 200);
};

const handleMenuOpen = (index: string) => {
  schedulePersistOpenedMenus([index]);
};

const handleMenuClose = (_index: string) => {
  schedulePersistOpenedMenus([]);
};

// 加载设备列表并计算在线数量
const loadDevicesForCount = async () => {
  if (!userStore.hasPermission("device:view")) {
    return;
  }
  try {
    const { data } = await deviceApi.listAll();
    devices.value = data.items || [];
    // 统计在线设备数量
    onlineDeviceCount.value = devices.value.filter(
      (d) => d.onlineStatus === "online",
    ).length;
  } catch (error) {
    console.error("加载设备列表失败:", error);
  }
};

// ========== 面包屑相关 ==========
const breadcrumbs = computed(() => {
  const matched = route.matched;
  const items: { path: string; title: string }[] = [];

  for (let i = 1; i < matched.length; i++) {
    const match = matched[i];
    let title = match.meta?.title as string;

    if (!title && typeof match.name === "string") {
      const titleMap: Record<string, string> = {
        Dashboard: "仪表盘",
        Devices: "员工管理",
        Recordings: "录屏查看",
        Policies: "策略管理",
        Settings: "系统设置",
        Users: "用户管理",
        Roles: "角色管理",
        Profile: "个人资料",
        Upload: "上传管理",
        Screenshots: "截图查看",
        ScreenshotOverview: "截图概览",
        Activities: "活动日志",
        RemoteScreen: "远程屏幕",
      };
      title = titleMap[match.name] || match.name;
    }

    if (title) {
      items.push({
        path: match.path,
        title: title,
      });
    }
  }

  if (items.length === 0 && route.meta?.title) {
    items.push({
      path: route.path,
      title: route.meta.title as string,
    });
  }

  return items;
});

const hasSystemPermission = computed(() => {
  return (
    userStore.hasPermission("user:view") ||
    userStore.hasPermission("role:view") ||
    userStore.hasPermission("policy:update") ||
    userStore.hasPermission("invite:view")
  );
});

const hasAttendancePermission = computed(() => {
  return userStore.hasPermission("attendance:view");
});

const hasTelegramPermission = computed(() => {
  return userStore.hasPermission("telegram:view");
});

const canViewTelegramRecords = computed(() => {
  return (
    userStore.hasPermission("attendance:view") ||
    userStore.hasPermission("telegram:view")
  );
});

const showTelegramMenu = computed(() => {
  return canViewTelegramRecords.value || hasTelegramPermission.value;
});

const hasDeviceGroupPermission = computed(() => {
  return (
    userStore.hasPermission("recording:upload") ||
    userStore.hasPermission("policy:view")
  );
});

// ========== 多标签页相关 ==========
interface VisitedView {
  path: string;
  title: string;
  name?: string;
}

const visitedViews = ref<VisitedView[]>([]);
const activeTab = ref("");
const tabsScrollRef = ref<HTMLElement | null>(null);
const canScrollLeft = ref(false);
const canScrollRight = ref(false);
const tabsOverflow = ref(false);
const TABS_SCROLL_STEP = 220;
let tabsResizeObserver: ResizeObserver | null = null;

const updateTabsScrollState = () => {
  const el = tabsScrollRef.value;
  if (!el) {
    canScrollLeft.value = false;
    canScrollRight.value = false;
    tabsOverflow.value = false;
    return;
  }
  const { scrollLeft, scrollWidth, clientWidth } = el;
  tabsOverflow.value = scrollWidth > clientWidth + 1;
  canScrollLeft.value = scrollLeft > 1;
  canScrollRight.value = scrollLeft + clientWidth < scrollWidth - 1;
};

const scrollTabs = (direction: "left" | "right") => {
  const el = tabsScrollRef.value;
  if (!el) return;
  const delta = direction === "left" ? -TABS_SCROLL_STEP : TABS_SCROLL_STEP;
  el.scrollBy({ left: delta, behavior: "smooth" });
};

const scrollActiveTabIntoView = () => {
  const container = tabsScrollRef.value;
  if (!container) return;
  const activeEl = container.querySelector(".tab-item.active") as HTMLElement | null;
  if (!activeEl) return;
  const left = activeEl.offsetLeft;
  const right = left + activeEl.offsetWidth;
  const viewLeft = container.scrollLeft;
  const viewRight = viewLeft + container.clientWidth;
  if (left < viewLeft) {
    container.scrollTo({ left: left - 8, behavior: "smooth" });
  } else if (right > viewRight) {
    container.scrollTo({ left: right - container.clientWidth + 8, behavior: "smooth" });
  }
};
const cachedViews = ref<string[]>([]);
const hoveredTab = ref<string | null>(null);

const contextMenuVisible = ref(false);
const contextMenuX = ref(0);
const contextMenuY = ref(0);
const currentContextMenuPath = ref("");

const isMobile = ref(false);

const getTabIcon = (path: string) => {
  const iconMap: Record<string, any> = {
    "/": "Odometer",
    "/dashboard": "Odometer",
    "/screenshots": "Picture",
    "/screenshots-overview": "Grid",
    "/devices": "Monitor",
    "/recordings": "VideoCamera",
    "/remote-screen": "Connection",
    "/upload": "Upload",
    "/activities": "List",
    "/policies": "Document",
    "/users": "User",
    "/roles": "Avatar",
    "/settings": "Setting",
    "/profile": "UserFilled",
    "/domain-monitor/overview": "DataLine",
    "/domain-monitor/domains": "Link",
    "/domain-monitor/alerts": "Bell",
    "/domain-monitor/check-config": "Timer",
    "/domain-monitor/settings": "Setting",
    "/domain-monitor/nodes": "Connection",
    "/domain-monitor/reports": "Document",
    "/callback/generate": "DocumentAdd",
    "/callback/manual/period": "Upload",
    "/callback/manual/callback": "Upload",
    "/callback/manual": "Upload",
    "/callback/tasks": "List",
    "/callback/platforms": "OfficeBuilding",
    "/callback/activity": "Setting",
    "/callback/endpoints": "Connection",
    "/callback/logs": "Document",
  };
  const iconName = iconMap[path] || "Document";
  const iconComponents: Record<string, any> = {
    Odometer,
    Picture,
    Monitor,
    VideoCamera,
    Upload,
    List,
    Document,
    User,
    Avatar,
    Setting,
    UserFilled,
    DataLine,
    Camera,
    Grid,
    Connection,
    Link,
    Bell,
    Timer,
    Phone,
    DocumentAdd,
    OfficeBuilding,
  };
  return iconComponents[iconName] || Document;
};

const addView = (view: VisitedView) => {
  if (visitedViews.value.some((v) => v.path === view.path)) return;
  visitedViews.value.push(view);
};

const removeTab = (targetPath: string) => {
  const index = visitedViews.value.findIndex((v) => v.path === targetPath);
  if (index !== -1) {
    visitedViews.value.splice(index, 1);
    if (targetPath === route.path && visitedViews.value.length > 0) {
      const nextPath =
        visitedViews.value[index]?.path || visitedViews.value[index - 1]?.path;
      if (nextPath) router.push(nextPath);
    }
  }
};

const closeCurrentTab = () => {
  if (currentContextMenuPath.value) {
    removeTab(currentContextMenuPath.value);
  } else if (route.path) {
    removeTab(route.path);
  }
  contextMenuVisible.value = false;
};

const closeOtherTabs = () => {
  const currentPath = currentContextMenuPath.value || route.path;
  const current = visitedViews.value.find((v) => v.path === currentPath);
  visitedViews.value = current ? [current] : [];
  contextMenuVisible.value = false;
};

const closeAllTabs = () => {
  visitedViews.value = [];
  router.push("/");
  contextMenuVisible.value = false;
};

const handleTabsCommand = (command: string) => {
  if (command === "close-current") {
    removeTab(route.path);
  } else if (command === "close-other") {
    const current = visitedViews.value.find((v) => v.path === route.path);
    visitedViews.value = current ? [current] : [];
  } else if (command === "close-all") {
    visitedViews.value = [];
    router.push("/");
  }
};

const handleTabClick = (path: string) => {
  router.push(path);
};

const handleContextMenu = (e: MouseEvent, path: string) => {
  e.preventDefault();
  currentContextMenuPath.value = path;
  contextMenuX.value = e.clientX;
  contextMenuY.value = e.clientY;
  contextMenuVisible.value = true;

  const closeMenu = () => {
    contextMenuVisible.value = false;
    document.removeEventListener("click", closeMenu);
  };
  setTimeout(() => {
    document.addEventListener("click", closeMenu);
  }, 10);
};

const addCacheView = (name: string) => {
  if (name && !cachedViews.value.includes(name)) {
    cachedViews.value.push(name);
  }
};

const checkMobile = () => {
  isMobile.value = window.innerWidth <= 768;
};

const toggleCollapse = () => {
  isCollapse.value = !isCollapse.value;
};

// ✅ 修改：添加修改密码命令
const handleCommand = async (command: string) => {
  if (command === "logout") {
    try {
      // 1. 断开 WebSocket（先断开，避免后续请求）
      wsStore.disconnect();

      // 2. 调用登出接口
      await userStore.logout();

      // 3. 清理存储
      sessionStorage.clear();
      localStorage.removeItem("openedMenus");

      // 4. 提示成功
      ElMessage.success("已退出登录");

      // 5. 跳转（使用 window.location 确保立即跳转）
      window.location.href = "/login";
    } catch (error) {
      console.error("Logout error:", error);
      // 出错时也强制清理并跳转
      sessionStorage.clear();
      window.location.href = "/login";
    }
  } else if (command === "profile") {
    router.push("/profile");
  } else if (command === "changePassword") {
    changePasswordVisible.value = true;
  }
};

// 在 script setup 中添加
const hasPaymentPermission = computed(() => {
  return (
    userStore.hasPermission("site:view") ||
    userStore.hasPermission("stats:view")
  );
});

// ✅ 添加这里 - 工资管理组
const hasSalaryPermission = computed(() => {
  return (
    userStore.hasPermission("salary:upload") ||
    userStore.hasPermission("salary:view") ||
    userStore.hasPermission("salary:payment_address:view")
  );
});

const moduleFlags = ref({ domainMonitor: false, callback: true, telegramAttendance: false });

async function loadModuleFlags() {
  try {
    const { data } = await metaApi.modules();
    if (data) {
      moduleFlags.value = {
        domainMonitor: !!data.domainMonitor,
        callback: data.callback !== false,
        telegramAttendance: !!data.telegramAttendance,
      };
    }
  } catch {
    /* 保持默认：仅隐藏域名监控 */
  }
}

const hasDomainMonitorPermission = computed(() => {
  if (!moduleFlags.value.domainMonitor) return false;
  return (
    userStore.hasPermission("domain_monitor:view") ||
    userStore.hasPermission("domain_monitor:manage") ||
    userStore.hasPermission("domain_monitor:settings")
  );
});

const hasCallbackPermission = computed(() => {
  if (!moduleFlags.value.callback) return false;
  return (
    userStore.hasPermission("callback:view") ||
    userStore.hasPermission("callback:manage") ||
    userStore.hasPermission("callback:settings")
  );
});

// ✅ 新增：确认修改密码
const confirmChangePassword = async () => {
  if (!passwordFormRef.value) return;

  try {
    await passwordFormRef.value.validate();
  } catch {
    return;
  }

  changePasswordLoading.value = true;
  try {
    await userApi.changeOwnPassword({
      oldPassword: passwordForm.oldPassword,
      newPassword: passwordForm.newPassword,
    });
    ElMessage.success("密码修改成功，请重新登录");
    changePasswordVisible.value = false;
    // 修改成功后自动登出
    setTimeout(() => {
      userStore.logout();
      wsStore.disconnect();
      router.push("/login");
    }, 1500);
  } catch (error: any) {
    ElMessage.error(error.message || "修改密码失败");
  } finally {
    changePasswordLoading.value = false;
  }
};

// 监听路由变化
watch(
  route,
  (to) => {
    const title = (to.meta.title as string) || (to.name as string) || "未知";
    addView({ path: to.path, title, name: to.name as string });
    activeTab.value = to.path;
    if (to.meta.keepAlive && to.name) {
      addCacheView(to.name as string);
    }
    nextTick(() => {
      updateTabsScrollState();
      scrollActiveTabIntoView();
    });
  },
  { immediate: true },
);

watch(
  () => visitedViews.value.length,
  () => {
    nextTick(updateTabsScrollState);
  },
);

onMounted(() => {
  loadModuleFlags();
  refreshNotificationUnread();
  checkPopupNotifications();
  notificationCountTimer = setInterval(refreshNotificationUnread, 30000);
  notificationPopupTimer = setInterval(checkPopupNotifications, 15000);
  if (userStore.hasPermission("device:view")) {
    loadDevicesForCount();
    setInterval(loadDevicesForCount, 30000);
  }
  loadClientDownloadMeta();
  nextTick(() => {
    if (tabsScrollRef.value) {
      tabsResizeObserver = new ResizeObserver(updateTabsScrollState);
      tabsResizeObserver.observe(tabsScrollRef.value);
      updateTabsScrollState();
    }
  });
});
onUnmounted(() => {
  window.removeEventListener("resize", checkMobile);
  if (menuPersistTimer) clearTimeout(menuPersistTimer);
  if (notificationCountTimer) clearInterval(notificationCountTimer);
  if (notificationPopupTimer) clearInterval(notificationPopupTimer);
  tabsResizeObserver?.disconnect();
});
</script>

<style scoped>
.layout-container {
  height: 100vh;
  overflow: hidden;
}

.main-panel {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden;
}

.layout-top-fixed {
  flex-shrink: 0;
  z-index: 100;
  background: #fff;
}

.sidebar {
  display: flex;
  flex-direction: column;
  height: 100vh;
  transition: width 0.3s;
  overflow: hidden;
  --el-menu-bg-color: transparent;
  --el-menu-hover-bg-color: transparent;
  --el-menu-active-color: #409eff;
  --el-menu-text-color: rgba(255, 255, 255, 0.92);
  /* 整栏多色渐变，子菜单透明以透出同一背景 */
  background: linear-gradient(
    165deg,
    #1a1a2e 0%,
    #16213e 22%,
    #0f3460 48%,
    #1b3a5c 72%,
    #2d1b4e 100%
  ) !important;
}

.sidebar-menu-scroll {
  flex: 1;
  min-height: 0;
  overflow-x: hidden;
  overflow-y: auto;
  contain: layout style;
  /* 右侧预留滚动条叠放区，避免 hover 出现滚动条时挤压菜单 */
  padding: 4px 14px 16px 8px;
  margin-right: -6px;
  scrollbar-width: thin;
  scrollbar-color: transparent transparent;
}

/* 关闭子菜单展开/收起动画，减少点击卡顿感 */
.sidebar :deep(.el-collapse-transition-enter-active),
.sidebar :deep(.el-collapse-transition-leave-active) {
  transition: none !important;
}

.sidebar :deep(.el-menu--collapse-transition),
.sidebar :deep(.vertical-collapse-transition) {
  transition: none !important;
}

.sidebar-menu-scroll::-webkit-scrollbar {
  width: 6px;
  background: transparent;
}

.sidebar-menu-scroll::-webkit-scrollbar-track {
  background: transparent;
}

.sidebar-menu-scroll::-webkit-scrollbar-thumb {
  background: transparent;
  border-radius: 6px;
  transition: background-color 0.2s ease;
}

.sidebar-menu-scroll.is-menu-hovered {
  scrollbar-color: rgba(255, 255, 255, 0.28) transparent;
}

.sidebar-menu-scroll.is-menu-hovered::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.28);
}

.sidebar-menu-scroll.is-menu-hovered::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.42);
}

.sidebar-menu-scroll :deep(.el-menu) {
  border-right: none;
  background: transparent !important;
}

/* 子菜单容器与主菜单背景一致（透明，继承侧边栏渐变） */
.sidebar :deep(.el-menu),
.sidebar :deep(.el-menu--inline),
.sidebar :deep(.el-sub-menu),
.sidebar :deep(.el-sub-menu .el-menu),
.sidebar :deep(.el-sub-menu .el-menu--inline),
.sidebar :deep(.el-sub-menu.is-opened > .el-menu),
.sidebar :deep(.el-sub-menu.is-active > .el-menu) {
  background-color: transparent !important;
  background: transparent !important;
}

/* 所有菜单项背景透明 */
.sidebar :deep(.el-menu-item),
.sidebar :deep(.el-sub-menu__title),
.sidebar :deep(.el-menu--inline .el-menu-item) {
  background-color: transparent !important;
  background: transparent !important;
  transition: background 0.12s ease, color 0.12s ease;
}

/* 展开/激活中的子菜单标题默认透明（非 hover） */
.sidebar :deep(.el-sub-menu.is-opened > .el-sub-menu__title:not(:hover)),
.sidebar :deep(.el-sub-menu.is-active > .el-sub-menu__title:not(:hover)) {
  background-color: transparent !important;
  background: transparent !important;
  color: rgba(255, 255, 255, 0.95) !important;
}

/* 菜单 hover 渐变（含展开/激活子菜单标题与当前路由项） */
.sidebar :deep(.el-menu-item):hover,
.sidebar :deep(.el-sub-menu__title):hover,
.sidebar :deep(.el-menu--inline .el-menu-item):hover,
.sidebar :deep(.el-sub-menu.is-opened > .el-sub-menu__title):hover,
.sidebar :deep(.el-sub-menu.is-active > .el-sub-menu__title):hover,
.sidebar :deep(.el-menu-item.is-active):hover,
.sidebar :deep(.el-menu--inline .el-menu-item.is-active):hover {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
  color: white !important;
  border-radius: 8px !important;
  position: relative;
  z-index: 1;
}

/* ✅ 激活项样式 - 主菜单：只改变字体颜色，不改变背景 */
.sidebar :deep(.el-menu-item.is-active) {
  background: transparent !important;
  color: #409eff !important;
  border-radius: 0 !important;
  margin: 0 !important;
  width: auto !important;
}

/* ✅ 激活项样式 - 子菜单：只改变字体颜色，不改变背景 */
.sidebar :deep(.el-menu--inline .el-menu-item.is-active) {
  background: transparent !important;
  color: #409eff !important;
  border-radius: 0 !important;
  margin: 0 !important;
  width: auto !important;
}

/* 图标颜色跟随变化 - hover 时变白 */
.sidebar :deep(.el-menu-item):hover .el-icon,
.sidebar :deep(.el-sub-menu__title):hover .el-icon,
.sidebar :deep(.el-menu--inline .el-menu-item):hover .el-icon,
.sidebar :deep(.el-sub-menu.is-opened > .el-sub-menu__title):hover .el-icon,
.sidebar :deep(.el-sub-menu.is-active > .el-sub-menu__title):hover .el-icon,
.sidebar :deep(.el-menu-item.is-active):hover .el-icon,
.sidebar :deep(.el-menu--inline .el-menu-item.is-active):hover .el-icon {
  color: white !important;
}

/* ✅ 激活项的图标颜色变为 #409eff */
.sidebar :deep(.el-menu-item.is-active) .el-icon,
.sidebar :deep(.el-menu--inline .el-menu-item.is-active) .el-icon {
  color: #409eff !important;
}

.logo {
  flex-shrink: 0;
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: #fff;
  font-size: 18px;
  font-weight: bold;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  background: transparent;
}

/* 默认图标可见 */
.sidebar :deep(.el-menu-item) .el-icon,
.sidebar :deep(.el-sub-menu__title) .el-icon {
  color: rgba(255, 255, 255, 0.92);
}

.sidebar :deep(.el-sub-menu.is-opened > .el-sub-menu__title) .el-icon,
.sidebar :deep(.el-sub-menu.is-active > .el-sub-menu__title) .el-icon {
  color: rgba(255, 255, 255, 0.92);
}

/* ✅ 顶部导航栏固定，不随内容滚动 */
.header {
  flex-shrink: 0;
  height: 60px;
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  margin-bottom: 0;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 20px;
}

.collapse-btn {
  font-size: 20px;
  cursor: pointer;
  transition: transform 0.2s;
}

.collapse-btn:hover {
  transform: scale(1.1);
}

.header-right {
  display: flex;
  align-items: center;
  gap: 20px;
}

.notification-badge {
  display: inline-flex;
  align-items: center;
}

.notification-icon {
  cursor: pointer;
}

.notification-panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.notification-panel-title {
  font-size: 15px;
  font-weight: 600;
  color: #303133;
}

.notification-loading,
.notification-empty {
  padding: 24px 0;
  text-align: center;
  color: #909399;
  font-size: 13px;
}

.notification-list {
  max-height: 360px;
  overflow-y: auto;
}

.notification-item {
  padding: 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.2s;
  border-bottom: 1px solid #f0f2f5;
}

.notification-item:last-child {
  border-bottom: none;
}

.notification-item:hover {
  background: #f5f7fa;
}

.notification-item.unread {
  background: #ecf5ff;
}

.notification-item-title {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 4px;
}

.notification-item-content {
  font-size: 13px;
  color: #606266;
  line-height: 1.5;
  margin-bottom: 6px;
}

.notification-item-time {
  font-size: 12px;
  color: #909399;
}

/* 用户信息样式（适配头像） */
.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 24px;
  transition: background 0.3s;
}

.user-info:hover {
  background: #f5f5f5;
}

.user-avatar {
  flex-shrink: 0;
  border: 2px solid #e4e7ed;
  transition: border-color 0.3s;
}

.user-info:hover .user-avatar {
  border-color: #409eff;
}

.username {
  font-size: 14px;
  color: #333;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.arrow-icon {
  font-size: 12px;
  color: #909399;
  transition: transform 0.2s;
}

.user-info:hover .arrow-icon {
  transform: translateY(2px);
}

/* 标签页区域包装器 */
.tabs-section {
  flex-shrink: 0;
  margin-top: 0;
  background: white;
  margin-top:2px;
  border-bottom: 1px solid #eef2f6;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);
}

.tabs-container {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 12px 0 12px;
}

.tabs-nav-btn {
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: 1px solid #e4e7ed;
  border-radius: 50%;
  background: #fff;
  color: #606266;
  cursor: pointer;
  transition: all 0.2s ease;
}

.tabs-nav-btn:hover:not(:disabled) {
  color: #409eff;
  border-color: #c6e2ff;
  background: #ecf5ff;
}

.tabs-nav-btn:disabled {
  opacity: 0.35;
  cursor: not-allowed;
}

.tabs-scroll {
  display: flex;
  align-items: center;
  gap: 6px;
  overflow-x: auto;
  overflow-y: hidden;
  flex: 1;
  min-width: 0;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.tabs-scroll::-webkit-scrollbar {
  display: none;
}

.tab-item {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  background-color: #f9fafc;
  border-radius: 12px 12px 8px 8px;
  cursor: pointer;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  font-size: 13px;
  color: #5a6874;
  white-space: nowrap;
  position: relative;
  border: 1px solid #edf2f7;
  border-bottom: none;
  margin-bottom: -1px;
}

.tab-item:hover {
  background-color: #f0f4fa;
  color: #409eff;
  transform: translateY(-1px);
}

.tab-item.active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-color: transparent;
  border-bottom-color: white;
  font-weight: 500;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
}

.tab-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  transition: all 0.2s;
}

.tab-item.active .tab-icon {
  color: white;
  animation: iconPulse 0.3s ease;
}

@keyframes iconPulse {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
  100% {
    transform: scale(1);
  }
}

.tab-title {
  max-width: 140px;
  overflow: hidden;
  text-overflow: ellipsis;
}

.tab-close {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  border-radius: 6px;
  font-size: 12px;
  opacity: 0.5; /* 默认半透明 */
  transition: all 0.2s;
  margin-left: 4px;
  color: #5a6874; /* 非激活状态使用深色 */
  background: transparent;
}

.tab-item.active .tab-close {
  opacity: 0.9;
  color: white; /* 激活状态使用白色 */
}
.tab-item.active .tab-close {
  opacity: 0.9;
}

.tab-item.active .tab-close:hover {
  opacity: 1;
  background-color: rgba(255, 255, 255, 0.2);
}

/* 非激活状态悬停时的关闭按钮 */
.tab-item:not(.active):hover .tab-close {
  opacity: 0.8;
  color: #409eff;
}

.tabs-actions {
  display: flex;
  align-items: center;
  gap: 6px;
  padding-left: 14px;
  margin-left: auto;
  border-left: 1px solid #e8edf3;
}

.tabs-actions .el-button {
  transition: all 0.2s ease;
}

.tabs-actions .el-button:hover {
  transform: rotate(180deg);
  background-color: #f5f8fc;
}

.tab-context-menu {
  position: fixed;
  background: white;
  border-radius: 14px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
  padding: 8px 0;
  min-width: 150px;
  z-index: 10000;
  animation: menuFadeIn 0.15s ease;
  border: 1px solid #eef2f8;
  backdrop-filter: blur(2px);
}

@keyframes menuFadeIn {
  from {
    opacity: 0;
    transform: scale(0.96) translateY(-4px);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

.context-menu-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 18px;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 13px;
  color: #2c3e50;
}

.context-menu-item:hover {
  background: #f0f7ff;
  color: #409eff;
}

.context-menu-item .el-icon {
  font-size: 16px;
}

.main-content {
  flex: 1;
  min-height: 0;
  background-color: #f5f7fb;
  padding: 20px;
  overflow-y: auto;
  overflow-x: hidden;
}

.fade-transform-leave-active,
.fade-transform-enter-active {
  transition: all 0.3s ease;
}

.fade-transform-enter-from {
  opacity: 0;
  transform: translateX(24px);
}

.fade-transform-leave-to {
  opacity: 0;
  transform: translateX(-24px);
}

.el-menu-item [class^="el-icon"],
.el-sub-menu [class^="el-icon"] {
  margin-right: 8px;
}

.el-sub-menu .el-menu-item {
  padding-left: 50px !important;
}

.mobile-mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 999;
}

/* 对话框动画 */
.animate-dialog :deep(.el-dialog) {
  border-radius: 12px;
  animation: dialogFadeIn 0.3s ease;
}

@keyframes dialogFadeIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

/* 移动端适配 */
@media (max-width: 768px) {
  .main-content {
    padding: 14px !important;
  }

  .tabs-container {
    padding: 6px 12px 0;
  }

  .header {
    padding: 0 12px;
    margin-bottom: 1px;
  }

  .username {
    display: none;
  }

  .user-info {
    padding: 2px 4px;
  }

  .user-avatar {
    width: 32px !important;
    height: 32px !important;
  }

  .header-left .el-breadcrumb {
    display: none;
  }

  .tab-title {
    max-width: 80px;
  }

  .tab-item {
    padding: 6px 12px;
  }
}

/* 平板适配 */
@media (min-width: 769px) and (max-width: 1024px) {
  .main-content {
    padding: 18px !important;
  }

  .username {
    max-width: 80px;
    overflow: hidden;
    text-overflow: ellipsis;
  }
}
</style>

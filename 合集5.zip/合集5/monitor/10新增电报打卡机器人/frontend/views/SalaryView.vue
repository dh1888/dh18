<template>
  <div class="salary-view">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <div class="salary-container">
      <div class="salary-header">
        <h1 class="page-title">
          <el-icon><Money /></el-icon>
          工资单
        </h1>
        <div class="month-selector">
          <el-select
            v-model="selectedMonth"
            @change="loadMySalary"
            placeholder="选择月份"
            size="large"
          >
            <el-option
              v-for="month in availableMonths"
              :key="month"
              :label="formatMonth(month)"
              :value="month"
            />
          </el-select>
        </div>
      </div>

      <div v-if="loading" class="loading-container">
        <el-icon class="is-loading" :size="40"><Loading /></el-icon>
        <span>加载中...</span>
      </div>

      <template v-else>
        <div v-if="mySalary" class="salary-card">
        <!-- 员工信息 -->
        <div class="employee-info">
          <div class="avatar-wrapper">
            <el-avatar
              :size="80"
              :style="{
                backgroundColor: getAvatarColor(mySalary.employeeName),
              }"
            >
              {{ mySalary.employeeName?.charAt(0) }}
            </el-avatar>
          </div>
          <div class="info-details">
            <h2 class="employee-name">{{ mySalary.employeeName }}</h2>
            <div class="employee-meta">
              <el-tag type="primary" size="large">{{
                mySalary.position || "员工"
              }}</el-tag>
              <el-tag type="info" size="large">{{
                formatMonth(selectedMonth)
              }}</el-tag>
            </div>
          </div>
        </div>

        <!-- 工资明细 -->
        <div class="salary-details">
          <!-- 基本信息 -->
          <div class="detail-section">
            <h3 class="section-title">基本信息</h3>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">职务</span>
                <span class="detail-value">{{ mySalary.position || "-" }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">入职日期-部门</span>
                <span class="detail-value">{{
                  mySalary.hireDateDept || "-"
                }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">在职月数</span>
                <span class="detail-value"
                  >{{ mySalary.monthsEmployed || 0 }}个月</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">汇率</span>
                <span class="detail-value">{{
                  mySalary.exchangeRate || 0
                }}</span>
              </div>
            </div>
          </div>

          <!-- 工资构成 -->
          <div class="detail-section">
            <h3 class="section-title">工资构成</h3>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">上月底薪</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.lastMonthBase) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">递增总额</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.totalIncrease) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">底薪(RMB)</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.baseSalary) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">出勤</span>
                <span class="detail-value"
                  >{{ mySalary.attendanceDays }}天</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">实际底薪</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.actualBaseSalary) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">调勤</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.attendanceAdjustment) }}</span
                >
              </div>
            </div>
          </div>

          <!-- 绩效与奖励 -->
          <div class="detail-section">
            <h3 class="section-title">绩效与奖励</h3>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">绩效分数</span>
                <span class="detail-value"
                  >{{ mySalary.performanceScore || 0 }}分</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">绩效奖励B</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.performanceBonusB) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">奖励</span>
                <span class="detail-value"
                  >¥{{ formatNumber(mySalary.reward) }}</span
                >
              </div>
            </div>
          </div>

          <!-- 扣款项目 -->
          <div class="detail-section deduction-section">
            <h3 class="section-title">扣款项目</h3>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">罚款</span>
                <span class="detail-value penalty"
                  >-¥{{ formatNumber(mySalary.penalty) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">预支15-15</span>
                <span class="detail-value deduction"
                  >-¥{{ formatNumber(mySalary.advance) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">其他扣款</span>
                <span class="detail-value deduction"
                  >-¥{{ formatNumber(mySalary.otherDeduction) }}</span
                >
              </div>
              <div class="detail-item">
                <span class="detail-label">保护费</span>
                <span class="detail-value deduction"
                  >-¥{{ formatNumber(mySalary.protectionFee) }}</span
                >
              </div>
            </div>
          </div>

          <!-- 保护费返还 -->
          <div class="detail-section">
            <h3 class="section-title">保护费返还</h3>
            <div class="detail-item">
              <span class="detail-label">保护费返还</span>
              <span class="detail-value"
                >+¥{{ formatNumber(mySalary.protectionReturn) }}</span
              >
            </div>
          </div>

          <!-- 合计 -->
          <div class="detail-section total-section">
            <div class="total-item">
              <span class="total-label">实发合计</span>
              <span class="total-value"
                >¥{{ formatNumber(mySalary.totalSalary) }}</span
              >
            </div>
            <div class="total-item" v-if="mySalary.remark">
              <span class="total-label">备注</span>
              <span class="total-remark">{{ mySalary.remark }}</span>
            </div>
          </div>
        </div>

        <!-- 打印按钮 -->
        <div class="print-btn-wrapper">
          <el-button type="primary" size="large" @click="printSalary">
            <el-icon><Printer /></el-icon>
            打印工资条
          </el-button>
        </div>
        </div>

        <div v-else class="empty-state">
          <el-empty description="暂无工资数据">
            <template #image>
              <el-icon :size="80" color="#c0c4cc"><Money /></el-icon>
            </template>
            <el-button type="primary" @click="loadMySalary">刷新</el-button>
          </el-empty>
        </div>

        <!-- 收款信息（无工资数据也可配置） -->
        <div class="payment-card">
          <div class="payment-card-header">
          <h3 class="section-title">
            <el-icon><Wallet /></el-icon>
            收款信息
          </h3>
          <el-button type="primary" @click="openPaymentDialog">
            {{ paymentAddress ? "修改收款地址" : "添加收款地址" }}
          </el-button>
        </div>

        <div v-if="paymentLoading" class="payment-loading">
          <el-icon class="is-loading"><Loading /></el-icon>
          加载收款信息...
        </div>
        <div v-else-if="paymentAddress" class="payment-details">
          <div class="preferred-tip" v-if="paymentAddress.preferredMethodLabel">
            默认收款方式：{{ paymentAddress.preferredMethodLabel }}
          </div>
          <div
            v-for="acc in paymentAddress.boundAccounts || []"
            :key="acc.type"
            class="bound-section"
            :class="{ preferred: acc.isPreferred }"
          >
            <div class="bound-section-title">
              {{ acc.label }}
              <el-tag v-if="acc.isPreferred" size="small" type="success">默认</el-tag>
            </div>
            <div class="detail-grid">
              <template v-if="acc.type === 'bank'">
                <div class="detail-item">
                  <span class="detail-label">收款人</span>
                  <span class="detail-value">{{ paymentAddress.accountHolder }}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">开户行</span>
                  <span class="detail-value">{{ paymentAddress.bankName }}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">银行账号</span>
                  <span class="detail-value mono">{{ paymentAddress.bankAccount }}</span>
                </div>
              </template>
              <template v-else-if="acc.type === 'usdt'">
                <div class="detail-item">
                  <span class="detail-label">网络</span>
                  <span class="detail-value">{{ paymentAddress.usdtNetwork }}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">USDT 地址</span>
                  <span class="detail-value mono">{{ paymentAddress.usdtAddress }}</span>
                </div>
              </template>
              <template v-else>
                <div class="detail-item">
                  <span class="detail-label">类型</span>
                  <span class="detail-value">{{ paymentAddress.otherWalletType }}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">地址/账号</span>
                  <span class="detail-value mono">{{ paymentAddress.otherWalletAddress }}</span>
                </div>
              </template>
            </div>
          </div>
          <div class="detail-item remark-item" v-if="paymentAddress.remark">
            <span class="detail-label">备注</span>
            <span class="detail-value">{{ paymentAddress.remark }}</span>
          </div>
          <div class="payment-updated" v-if="paymentAddress.updatedAt">
            最后更新：{{ formatPaymentTime(paymentAddress.updatedAt) }}
          </div>
        </div>
        <el-empty v-else description="尚未配置收款地址，请点击上方按钮添加" :image-size="80" />
        </div>
      </template>
    </div>

    <!-- 编辑收款地址 -->
    <el-dialog
      v-model="paymentDialogVisible"
      :title="paymentAddress ? '修改收款地址' : '添加收款地址'"
      width="560px"
      destroy-on-close
    >
      <el-alert
        type="warning"
        :closable="false"
        show-icon
        title="保存收款地址需输入谷歌验证码"
        style="margin-bottom: 16px"
      />
      <el-form :model="paymentForm" label-width="110px">
        <el-divider content-position="left">银行账户</el-divider>
        <el-form-item label="收款人">
          <el-input v-model="paymentForm.accountHolder" placeholder="与银行卡一致的姓名" />
        </el-form-item>
        <el-form-item label="开户银行">
          <el-input v-model="paymentForm.bankName" placeholder="例如：中国工商银行" />
        </el-form-item>
        <el-form-item label="银行账号">
          <el-input v-model="paymentForm.bankAccount" placeholder="银行卡号" />
        </el-form-item>

        <el-divider content-position="left">USDT 钱包</el-divider>
        <el-form-item label="网络类型">
          <el-select v-model="paymentForm.usdtNetwork" placeholder="选择网络" clearable style="width: 100%">
            <el-option label="TRC20" value="TRC20" />
            <el-option label="ERC20" value="ERC20" />
            <el-option label="BEP20" value="BEP20" />
            <el-option label="其他" value="其他" />
          </el-select>
        </el-form-item>
        <el-form-item label="USDT 地址">
          <el-input v-model="paymentForm.usdtAddress" placeholder="USDT 收款地址" />
        </el-form-item>

        <el-divider content-position="left">其他钱包</el-divider>
        <el-form-item label="钱包类型">
          <el-input v-model="paymentForm.otherWalletType" placeholder="例如：支付宝、微信、ETH" />
        </el-form-item>
        <el-form-item label="钱包地址">
          <el-input v-model="paymentForm.otherWalletAddress" placeholder="账号或链上地址" />
        </el-form-item>

        <el-form-item label="备注">
          <el-input v-model="paymentForm.remark" type="textarea" :rows="2" />
        </el-form-item>

        <el-form-item
          v-if="availablePaymentOptions.length > 1"
          label="默认账号"
          required
        >
          <el-radio-group v-model="paymentForm.preferredMethod">
            <el-radio
              v-for="opt in availablePaymentOptions"
              :key="opt.value"
              :value="opt.value"
            >
              {{ opt.label }}
            </el-radio>
          </el-radio-group>
          <div class="form-tip">绑定多种收款方式时，请选择工资发放默认使用的账号</div>
        </el-form-item>

        <el-form-item label="谷歌验证码" required>
          <el-input
            v-model="paymentForm.totpCode"
            maxlength="6"
            placeholder="6 位验证码"
            autocomplete="one-time-code"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="paymentDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="paymentSaving" @click="savePaymentAddress">
          保存
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { Money, Loading, Printer, Wallet } from "@element-plus/icons-vue";
import adminApi from "@api/admin_api";

const loading = ref(false);
const mySalary = ref<any>(null);
const selectedMonth = ref(getLastMonth());
const availableMonths = ref<string[]>([]);

const paymentLoading = ref(false);
const paymentAddress = ref<any>(null);
const paymentDialogVisible = ref(false);
const paymentSaving = ref(false);
const paymentForm = ref({
  accountHolder: "",
  bankName: "",
  bankAccount: "",
  usdtNetwork: "",
  usdtAddress: "",
  otherWalletType: "",
  otherWalletAddress: "",
  preferredMethod: "",
  remark: "",
  totpCode: "",
});

const availablePaymentOptions = computed(() => {
  const options: { value: string; label: string }[] = [];
  const f = paymentForm.value;
  if (f.accountHolder && f.bankName && f.bankAccount) {
    options.push({ value: "bank", label: `银行卡 ${f.bankAccount}` });
  }
  if (f.usdtNetwork && f.usdtAddress) {
    options.push({
      value: "usdt",
      label: `USDT(${f.usdtNetwork}) ${f.usdtAddress.slice(0, 8)}...`,
    });
  }
  if (f.otherWalletType && f.otherWalletAddress) {
    options.push({
      value: "other",
      label: `${f.otherWalletType} ${f.otherWalletAddress.slice(0, 8)}...`,
    });
  }
  return options;
});

function getLastMonth() {
  const now = new Date();
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${lastMonth.getFullYear()}-${String(lastMonth.getMonth() + 1).padStart(2, "0")}`;
}

function formatMonth(month: string) {
  if (!month) return "-";
  const [year, m] = month.split("-");
  return `${year}年${parseInt(m)}月`;
}

function formatNumber(num: number) {
  if (num === undefined || num === null) return "0";
  return num.toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function getAvatarColor(name: string) {
  const colors = [
    "#667eea",
    "#764ba2",
    "#f093fb",
    "#4facfe",
    "#43e97b",
    "#fa709a",
  ];
  const index = (name?.charCodeAt(0) || 0) % colors.length;
  return colors[index];
}

async function loadAvailableMonths() {
  try {
    const response = await adminApi.getSalaryMonths();
    availableMonths.value = response.data || [];
    if (availableMonths.value.length > 0 && !selectedMonth.value) {
      selectedMonth.value = availableMonths.value[0];
    }
  } catch (error) {
    console.error("加载月份列表失败:", error);
  }
}

async function loadMySalary() {
  loading.value = true;
  try {
    const params: any = {};
    if (selectedMonth.value) params.yearMonth = selectedMonth.value;
    const response = await adminApi.getSalaryRecords(params);
    const records = response.data?.items || [];
    mySalary.value = records[0] || null;
  } catch (error: any) {
    ElMessage.error(error.message || "加载工资数据失败");
    mySalary.value = null;
  } finally {
    loading.value = false;
  }
}

function formatPaymentTime(value: string) {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString("zh-CN", { hour12: false });
}

async function loadPaymentAddress() {
  paymentLoading.value = true;
  try {
    const response = await adminApi.getMyPaymentAddress();
    paymentAddress.value = response.data || null;
  } catch (error: any) {
    ElMessage.error(error.message || "加载收款信息失败");
    paymentAddress.value = null;
  } finally {
    paymentLoading.value = false;
  }
}

function openPaymentDialog() {
  const src = paymentAddress.value || {};
  paymentForm.value = {
    accountHolder: src.accountHolder || "",
    bankName: src.bankName || "",
    bankAccount: src.bankAccount || "",
    usdtNetwork: src.usdtNetwork || "",
    usdtAddress: src.usdtAddress || "",
    otherWalletType: src.otherWalletType || "",
    otherWalletAddress: src.otherWalletAddress || "",
    preferredMethod: src.preferredMethod || "",
    remark: src.remark || "",
    totpCode: "",
  };
  paymentDialogVisible.value = true;
}

async function savePaymentAddress() {
  if (!paymentForm.value.totpCode.trim()) {
    ElMessage.warning("请输入谷歌验证码");
    return;
  }
  if (availablePaymentOptions.value.length > 1 && !paymentForm.value.preferredMethod) {
    ElMessage.warning("请选择默认使用的收款账号");
    return;
  }
  paymentSaving.value = true;
  try {
    const response = await adminApi.upsertMyPaymentAddress({ ...paymentForm.value });
    paymentAddress.value = response.data;
    paymentDialogVisible.value = false;
    ElMessage.success("收款地址已保存");
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    paymentSaving.value = false;
  }
}

function printSalary() {
  const printContent = document
    .querySelector(".salary-card")
    ?.cloneNode(true) as HTMLElement;
  if (!printContent) return;

  const printWindow = window.open("", "_blank");
  if (!printWindow) return;

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"><title>工资条 - ${mySalary.value?.employeeName}</title>
    <style>
      body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; padding: 40px; margin: 0; }
      .salary-card { max-width: 800px; margin: 0 auto; border: 1px solid #e4e7ed; border-radius: 16px; padding: 24px; }
      .employee-info { display: flex; align-items: center; gap: 24px; margin-bottom: 32px; padding-bottom: 24px; border-bottom: 2px solid #f0f2f6; }
      .employee-name { margin: 0 0 8px 0; font-size: 24px; }
      .detail-section { margin-bottom: 24px; }
      .section-title { margin-bottom: 16px; font-size: 18px; color: #303133; }
      .detail-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
      .detail-item { display: flex; justify-content: space-between; padding: 12px; background: #f5f7fa; border-radius: 8px; }
      .detail-label { color: #909399; }
      .detail-value { font-weight: 600; color: #303133; }
      .penalty, .deduction { color: #f56c6c; }
      .total-section { margin-top: 24px; padding-top: 24px; border-top: 2px solid #f0f2f6; }
      .total-item { display: flex; justify-content: space-between; padding: 16px; background: linear-gradient(135deg, #667eea10, #764ba210); border-radius: 12px; }
      .total-label { font-size: 18px; font-weight: 600; }
      .total-value { font-size: 28px; font-weight: 700; color: #67c23a; }
      .print-btn-wrapper { display: none; }
    </style>
    </head>
    <body>${printContent.outerHTML}</body>
    </html>
  `);
  printWindow.document.close();
  printWindow.print();
}

onMounted(() => {
  loadAvailableMonths();
  loadMySalary();
  loadPaymentAddress();
});
</script>

<style scoped>
.salary-view {
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
  padding: 20px;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}
.blob-1 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -200px;
  right: -100px;
}
.blob-2 {
  width: 600px;
  height: 600px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -250px;
  left: -150px;
}
.blob-3 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 30%;
}

@keyframes float {
  0%,
  100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -30px) scale(1.05);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.95);
  }
}

.salary-container {
  max-width: 1000px;
  margin: 0 auto;
  position: relative;
  z-index: 1;
}
.salary-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  flex-wrap: wrap;
  gap: 16px;
}
.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 28px;
  font-weight: 700;
  color: #1a1a2e;
  margin: 0;
}
.month-selector {
  min-width: 160px;
}
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 400px;
  gap: 16px;
  color: #909399;
}
.salary-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  padding: 32px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
}
.employee-info {
  display: flex;
  align-items: center;
  gap: 24px;
  margin-bottom: 32px;
  padding-bottom: 24px;
  border-bottom: 2px solid #f0f2f6;
}
.avatar-wrapper {
  flex-shrink: 0;
}
.employee-name {
  margin: 0 0 12px 0;
  font-size: 28px;
  font-weight: 700;
  color: #1a1a2e;
}
.employee-meta {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.salary-details {
  display: flex;
  flex-direction: column;
  gap: 28px;
}
.detail-section {
  background: rgba(248, 250, 252, 0.6);
  border-radius: 16px;
  padding: 20px;
}
.section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 16px 0;
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}
.detail-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}
.detail-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 16px;
  background: white;
  border-radius: 12px;
  transition: all 0.2s;
}
.detail-item:hover {
  transform: translateX(4px);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}
.detail-label {
  color: #909399;
  font-size: 14px;
}
.detail-value {
  font-weight: 600;
  color: #303133;
  font-size: 16px;
}
.detail-value.penalty,
.detail-value.deduction {
  color: #f56c6c;
}
.total-section {
  background: linear-gradient(135deg, #667eea08, #764ba208);
  border: 1px solid #e8ecf1;
}
.total-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
}
.total-item:first-child {
  border-bottom: 1px solid #e8ecf1;
}
.total-label {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}
.total-value {
  font-size: 32px;
  font-weight: 700;
  color: #67c23a;
}
.total-remark {
  color: #909399;
  font-size: 14px;
}
.print-btn-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 32px;
  padding-top: 24px;
  border-top: 1px solid #f0f2f6;
}
.print-btn-wrapper .el-button {
  padding: 12px 40px;
  border-radius: 40px;
}
.empty-state {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  padding: 60px;
  text-align: center;
  margin-bottom: 20px;
}

.payment-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 24px;
  padding: 24px 28px;
  margin-top: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
}

.payment-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  gap: 12px;
}

.payment-card-header .section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0;
  font-size: 18px;
  color: #303133;
}

.payment-loading {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #909399;
  padding: 20px 0;
}

.payment-updated {
  margin-top: 16px;
  font-size: 13px;
  color: #909399;
}

.detail-value.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  word-break: break-all;
  text-align: right;
  max-width: 60%;
}

.preferred-tip {
  margin-bottom: 16px;
  padding: 10px 14px;
  background: #f0f9eb;
  border-radius: 8px;
  color: #67c23a;
  font-size: 14px;
}

.bound-section {
  margin-bottom: 16px;
  padding: 12px;
  border: 1px solid #ebeef5;
  border-radius: 12px;
}

.bound-section.preferred {
  border-color: #b3e19d;
  background: #fafdf8;
}

.bound-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  font-size: 15px;
  font-weight: 600;
  color: #303133;
}

.remark-item {
  margin-top: 8px;
}

.form-tip {
  margin-top: 6px;
  font-size: 12px;
  color: #909399;
  line-height: 1.5;
}

@media (max-width: 768px) {
  .salary-container {
    padding: 0;
  }
  .salary-card {
    padding: 20px;
  }
  .employee-info {
    flex-direction: column;
    text-align: center;
  }
  .detail-grid {
    grid-template-columns: 1fr;
  }
  .detail-item {
    flex-direction: column;
    text-align: center;
    gap: 8px;
  }
  .total-value {
    font-size: 24px;
  }
  .salary-header {
    flex-direction: column;
    text-align: center;
  }
}
</style>

<template>
  <div class="screenshots-page">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <!-- 筛选区域 -->
    <el-card class="filter-card card-hover">
      <el-form :inline="true" :model="filters" class="filter-form">
        <el-form-item label="员工">
          <el-select
            v-model="filters.deviceId"
            placeholder="选择员工查看截图"
            clearable
            filterable
            style="width: 240px"
            @change="handleSearch"
          >
            <el-option
              v-for="device in devices"
              :key="device.id"
              :label="
                device.employeeName
                  ? `${device.employeeName} (${device.employeeNumber || '未设置'})`
                  : device.hostname
              "
              :value="device.id"
            />
          </el-select>
        </el-form-item>

        <!-- 日期范围选择器（内嵌快捷选项） -->
        <el-form-item label="日期范围">
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="YYYY-MM-DD"
            :shortcuts="dateShortcuts"
            @change="handleDateRangeChange"
            style="width: 300px"
          />
        </el-form-item>

        <!-- 时间范围选择器（合并为单个组件） -->
        <el-form-item label="时间范围">
          <el-time-picker
            v-model="timeRange"
            is-range
            range-separator="至"
            start-placeholder="开始时间"
            end-placeholder="结束时间"
            format="HH:mm:ss"
            value-format="HH:mm:ss"
            clearable
            style="width: 280px"
            @change="handleTimeRangeChange"
          />
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            @click="handleSearch"
            :loading="searchLoading"
          >
            <el-icon><Search /></el-icon>
            搜索
          </el-button>
          <el-button @click="handleReset">
            <el-icon><Refresh /></el-icon>
            重置
          </el-button>
          <el-button @click="handleRefresh" :loading="loading">
            <el-icon><RefreshRight /></el-icon>
            刷新
          </el-button>
          <el-button
            v-if="!deleteMode"
            v-permission="'screenshot:delete'"
            type="danger"
            plain
            @click="openDeleteDialog"
          >
            <el-icon><Delete /></el-icon>
            删除
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 删除模式操作栏 -->
    <el-card v-if="deleteMode" class="delete-mode-bar card-hover">
      <div class="delete-mode-bar-inner">
        <div class="delete-mode-bar-text">
          <el-icon><Delete /></el-icon>
          <span>删除模式：点击图片选择要删除的截图 (可按ESC退出)</span>
          <el-tag type="danger" size="small">已选 {{ selectedIds.length }} 张</el-tag>
        </div>
        <div class="delete-mode-bar-actions">
          <el-button @click="exitDeleteMode">取消</el-button>
          <el-button
            type="danger"
            :disabled="selectedIds.length === 0"
            :loading="selectedDeleteLoading"
            @click="confirmDeleteSelected"
          >
            删除选中
          </el-button>
        </div>
      </div>
    </el-card>

    <!-- 网格视图 -->
    <div v-if="pagination.total > 0" class="result-hint">
      共 {{ pagination.total }} 张截图（仅显示已上传至服务器的记录）
      <span v-if="deleteMode" class="delete-mode-hint">
        已开启删除模式，请选择图片后点击「删除选中」
      </span>
    </div>
    <div
      class="grid-container"
      :class="{ 'delete-mode-active': deleteMode }"
      v-loading="loading"
    >
      <div
        v-for="screenshot in screenshots || []"
        :key="screenshot.id"
        class="screenshot-card"
        :class="{ 'is-selected': deleteMode && selectedIds.includes(screenshot.id) }"
      >
        <!-- 图片区域：使用 Element Plus 原生预览，带懒加载 -->
        <div
          class="card-image"
          :class="{ 'selectable': deleteMode }"
          :data-screenshot-id="screenshot.id"
          @click.stop="handleCardImageClick(screenshot)"
        >
          <!-- 懒加载图片 + 骨架屏 -->
          <el-image
            :src="getImageUrl(screenshot)"
            :alt="screenshot.id"
            fit="cover"
            :preview-src-list="deleteMode ? [] : [getPreviewImageUrl(screenshot)].filter(Boolean)"
            :preview-teleported="true"
            @error="handleImageError(screenshot)"
          >
            <!-- 加载中骨架屏 -->
            <template #placeholder>
              <div class="image-skeleton">
                <el-skeleton animated :row="3" />
                <div class="skeleton-loading">
                  <el-icon class="is-loading"><Loading /></el-icon>
                  <span>加载中...</span>
                </div>
              </div>
            </template>

            <!-- 加载失败占位 -->
            <template #error>
              <div class="image-error">
                <el-icon><Picture /></el-icon>
                <span>加载失败</span>
              </div>
            </template>
          </el-image>

          <!-- 加密标识 -->
          <div v-if="screenshot.encrypted" class="encrypted-badge">
            <el-icon><Lock /></el-icon>
            加密
          </div>

          <div
            v-if="deleteMode && selectedIds.includes(screenshot.id)"
            class="selected-badge"
          >
            <el-icon><Select /></el-icon>
          </div>
        </div>

        <div
          v-if="!deleteMode"
          class="delete-hover-btn"
          v-permission="'screenshot:delete'"
        >
          <el-button
            circle
            type="danger"
            size="small"
            @click.stop="handleDelete(screenshot)"
          >
            <el-icon><Delete /></el-icon>
          </el-button>
        </div>

        <!-- 信息区域：点击打开自定义预览对话框 -->
        <div
          class="card-info"
          @click="deleteMode ? toggleScreenshotSelection(screenshot.id) : handlePreview(screenshot)"
        >
          <div class="device-name">
            <!-- 新增员工信息 -->
            <el-icon><User /></el-icon>
            <span class="employee-name">{{
              getEmployeeName(screenshot.deviceId)
            }}</span>

            <el-divider direction="vertical" />

            <!-- 原有设备信息 -->
            <el-icon><Monitor /></el-icon>
            <el-tooltip
              :content="`设备ID: ${screenshot.deviceId}`"
              placement="top"
            >
              <span>{{ getDeviceDisplayName(screenshot.deviceId) }}</span>
            </el-tooltip>
          </div>
          <div class="capture-time">
            <el-icon><Clock /></el-icon>
            <span class="capture-date">{{
              formatDateOnly(screenshot.capturedAt)
            }}</span>
            <span class="capture-time-only">{{
              formatTimeOnly(screenshot.capturedAt)
            }}</span>
          </div>
          <div class="file-size">
            <el-icon><Document /></el-icon>
            {{ formatFileSize(screenshot.fileSize) }}
          </div>
        </div>
      </div>

      <!-- 加载更多时的骨架屏 -->
      <div v-if="loadingMore" class="skeleton-grid">
        <div v-for="i in 6" :key="i" class="skeleton-card">
          <el-skeleton animated :row="4" />
        </div>
      </div>

      <!-- 空状态 -->
      <el-empty
        v-if="!loading && (!screenshots || screenshots.length === 0)"
        description="暂无截图数据"
      />
    </div>

    <!-- 分页 -->
    <div class="pagination">
      <el-pagination
        v-model:current-page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        :page-sizes="[12, 24, 48, 96]"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>

    <!-- 自定义预览对话框 -->
    <el-dialog
      v-model="previewVisible"
      title="截图预览"
      width="1100px"
      :top="'10px'"
      @close="closePreview"
      @before-close="closePreview"
      class="animate-dialog modern-dialog"
    >
      <div class="preview-container">
        <img
          v-if="previewVisible && previewUrl"
          :src="previewUrl"
          class="preview-image"
          @error="handlePreviewError"
        />
        <div class="preview-info">
          <el-descriptions :column="2" border>
            <el-descriptions-item label="员工姓名">
              {{ getEmployeeName(currentScreenshot?.deviceId || "") }}
            </el-descriptions-item>
            <el-descriptions-item label="设备名称">
              {{ getDeviceDisplayName(currentScreenshot?.deviceId || "") }}
            </el-descriptions-item>
            <el-descriptions-item label="设备ID">
              <el-tooltip
                :content="currentScreenshot?.deviceId"
                placement="top"
              >
                <span
                  >{{
                    currentScreenshot?.deviceId?.slice(0, 16) || "-"
                  }}...</span
                >
              </el-tooltip>
            </el-descriptions-item>
            <el-descriptions-item label="拍摄时间">
              {{ formatDateTime(currentScreenshot?.capturedAt || "") }}
            </el-descriptions-item>
            <el-descriptions-item label="文件大小">
              {{ formatFileSize(currentScreenshot?.fileSize || 0) }}
            </el-descriptions-item>
            <el-descriptions-item label="加密状态">
              <el-tag
                :type="currentScreenshot?.encrypted ? 'warning' : 'success'"
                size="small"
              >
                {{ currentScreenshot?.encrypted ? "已加密" : "未加密" }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="图片ID">
              {{ currentScreenshot?.id }}
            </el-descriptions-item>
          </el-descriptions>
        </div>
      </div>
      <template #footer>
        <el-button @click="previewVisible = false">关闭</el-button>
        <el-button type="danger" @click="handleDeleteFromPreview">
          删除截图
        </el-button>
        <el-button type="primary" @click="downloadScreenshot">
          下载图片
        </el-button>
      </template>
    </el-dialog>

    <!-- 删除对话框 -->
    <el-dialog
      v-model="deleteDialogVisible"
      title="删除截图"
      width="480px"
      @close="resetDeleteForm"
    >
      <el-form label-width="100px">
        <el-form-item label="删除方式">
          <el-radio-group v-model="deleteForm.mode">
            <el-radio value="selected">删除指定</el-radio>
            <el-radio value="date">按日期删除</el-radio>
            <el-radio value="all">全部删除</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item v-if="deleteForm.mode === 'date'" label="选择日期" required>
          <el-date-picker
            v-model="deleteForm.date"
            type="date"
            placeholder="选择要删除的日期"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
            style="width: 100%"
          />
        </el-form-item>

        <el-alert
          :title="deleteAlertTitle"
          :type="deleteAlertType"
          :closable="false"
          show-icon
        >
          <template #default>{{ deleteAlertText }}</template>
        </el-alert>
      </el-form>

      <template #footer>
        <el-button @click="deleteDialogVisible = false">取消</el-button>
        <el-button
          :type="deleteForm.mode === 'selected' ? 'primary' : 'danger'"
          :loading="deleteActionLoading"
          @click="handleDeleteDialogConfirm"
        >
          {{ deleteDialogConfirmText }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch, nextTick, onMounted, onBeforeUnmount } from "vue";
import { useRoute } from "vue-router";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Search,
  Refresh,
  RefreshRight,
  Delete,
  Monitor,
  Clock,
  Document,
  // View,
  Lock,
  Picture,
  Loading,
  User,
  Select,
} from "@element-plus/icons-vue";
import { screenshotApi, deviceApi } from "@api/index";
import type { Screenshot, Device } from "@api/types";

// 导入 lodash 防抖
import { debounce } from "lodash-es";

const route = useRoute();

const loading = ref(false);
const loadingMore = ref(false);
const searchLoading = ref(false);
const screenshots = ref<Screenshot[]>([]);
const devices = ref<Device[]>([]);
const previewVisible = ref(false);
const previewUrl = ref("");
const currentScreenshot = ref<Screenshot | null>(null);
const timeRange = ref<[string, string] | null>(null);
const imageUrlMap = reactive<Record<string, string>>({});

const deleteMode = ref(false);
const selectedIds = ref<string[]>([]);
const deleteDialogVisible = ref(false);
const deleteActionLoading = ref(false);
const selectedDeleteLoading = ref(false);
const deleteForm = reactive({
  mode: "selected" as "selected" | "date" | "all",
  date: "",
});

const deleteDialogConfirmText = computed(() =>
  deleteForm.mode === "selected" ? "进入选择" : "删除",
);

const deleteAlertTitle = computed(() => {
  if (deleteForm.mode === "selected") return "删除指定";
  if (deleteForm.mode === "all") return "危险操作";
  return "删除提示";
});

const deleteAlertType = computed(() => {
  if (deleteForm.mode === "all") return "error";
  if (deleteForm.mode === "selected") return "info";
  return "warning";
});

const deleteAlertText = computed(() => {
  if (deleteForm.mode === "selected") {
    return "进入删除模式后，可点击图片多选，再点击「删除选中」确认删除。按 Esc 或「取消」可退出。";
  }
  if (deleteForm.mode === "date") {
    return "将删除所选日期内的全部截图，此操作不可恢复。";
  }
  return "将删除系统中的全部截图，此操作不可恢复，请谨慎操作。";
});

// 日期范围
const dateRange = ref<[string, string] | null>(null);

// 日期选择器快捷选项
const dateShortcuts = [
  {
    text: "今日",
    value: () => {
      const today = new Date();
      return [today, today];
    },
  },
  {
    text: "昨日",
    value: () => {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      return [yesterday, yesterday];
    },
  },
  {
    text: "近3天",
    value: () => {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 2);
      return [start, end];
    },
  },
  {
    text: "近7天",
    value: () => {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 6);
      return [start, end];
    },
  },
  {
    text: "本月",
    value: () => {
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      return [start, end];
    },
  },
];

// 筛选条件（增加 startTime 和 endTime）
const filters = reactive({
  deviceId: "",
  startDate: "",
  endDate: "",
  startTime: "",
  endTime: "",
});

const pagination = reactive({
  page: 1,
  pageSize: 24,
  total: 0,
});

// 设备名称映射
const deviceNameMap = computed(() => {
  const map: Record<string, string> = {};
  devices.value.forEach((d) => {
    if (d.employeeId) {
      map[d.id] = `${d.hostname} (员工: ${d.employeeId})`;
    } else {
      map[d.id] =
        d.hostname || d.deviceFingerprint?.slice(0, 8) || d.id.slice(0, 8);
    }
  });
  return map;
});

// 获取设备显示名称
const getDeviceDisplayName = (deviceId: string) => {
  return (
    deviceNameMap.value[deviceId] || deviceId?.slice(0, 8) + "..." || "未知设备"
  );
};

const getEmployeeName = (deviceId: string) => {
  const device = devices.value.find((d) => d.id === deviceId);
  if (device?.employeeName) {
    return device.employeeName;
  }
  return getDeviceDisplayName(deviceId);
};

// 通过 Authorization 头加载图片，避免 JWT 出现在 URL
const IMAGE_LOAD_CONCURRENCY = 4;
let activeImageLoads = 0;
const imageLoadWaiters: Array<() => void> = [];

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function withImageConcurrency<T>(fn: () => Promise<T>): Promise<T> {
  while (activeImageLoads >= IMAGE_LOAD_CONCURRENCY) {
    await new Promise<void>((resolve) => imageLoadWaiters.push(resolve));
  }
  activeImageLoads += 1;
  try {
    return await fn();
  } finally {
    activeImageLoads -= 1;
    const next = imageLoadWaiters.shift();
    if (next) next();
  }
}

const imageCacheKey = (id: string, thumbnail: boolean) =>
  thumbnail ? `${id}:thumb` : `${id}:full`;

const loadImageUrl = async (
  id: string,
  useThumbnail = true,
  retries = 2,
): Promise<string> => {
  const cacheKey = imageCacheKey(id, useThumbnail);
  if (imageUrlMap[cacheKey]) return imageUrlMap[cacheKey];

  return withImageConcurrency(async () => {
    if (imageUrlMap[cacheKey]) return imageUrlMap[cacheKey];

    try {
      const response = useThumbnail
        ? await screenshotApi.getThumbnailBlob(id)
        : await screenshotApi.getImageBlob(id);
      const blob =
        response.data instanceof Blob
          ? response.data
          : new Blob([response.data as BlobPart]);
      const url = URL.createObjectURL(blob);
      imageUrlMap[cacheKey] = url;
      return url;
    } catch (error) {
      if (retries > 0) {
        await sleep(400 * (3 - retries));
        return loadImageUrl(id, useThumbnail, retries - 1);
      }
      throw error;
    }
  });
};

const queueScreenshotThumbnail = (id: string) => {
  if (imageUrlMap[imageCacheKey(id, true)]) return;
  void loadImageUrl(id, true).catch((error) => {
    console.warn("截图缩略图加载失败:", id, error);
  });
};

const getImageUrl = (screenshot: Screenshot) =>
  imageUrlMap[imageCacheKey(screenshot.id, true)] || "";

const getPreviewImageUrl = (screenshot: Screenshot) =>
  imageUrlMap[imageCacheKey(screenshot.id, false)] ||
  imageUrlMap[imageCacheKey(screenshot.id, true)] ||
  "";

// 格式化时间
const formatDateTime = (time: string) => {
  if (!time) return "-";
  const date = new Date(time);
  return date.toLocaleString("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
};

// 格式化文件大小
const formatFileSize = (bytes: number) => {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
};

// ========== 日期时间构建函数==========
/**
 * 获取浏览器本地时区偏移（如 +08:00）
 */
const getLocalTimezoneOffset = (): string => {
  const offset = -new Date().getTimezoneOffset();
  const sign = offset >= 0 ? "+" : "-";
  const hours = Math.floor(Math.abs(offset) / 60);
  const minutes = Math.abs(offset) % 60;
  return `${sign}${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
};

/**
 * 将本地日期时间转换为 UTC ISO 字符串
 * @param dateStr 日期字符串，格式：YYYY-MM-DD
 * @param timeStr 时间字符串，格式：HH:mm:ss
 * @returns UTC 时间字符串，格式：2026-06-03T02:00:00.000Z
 */
const toUTCISOString = (dateStr: string, timeStr: string): string => {
  const timezone = getLocalTimezoneOffset();
  const localDateTime = new Date(`${dateStr}T${timeStr}${timezone}`);
  return localDateTime.toISOString();
};

/**
 * 将本地日期转换为 UTC 的开始时间（00:00:00）
 */
const toUTCStartOfDay = (dateStr: string): string => {
  const timezone = getLocalTimezoneOffset();
  const localDateTime = new Date(`${dateStr}T00:00:00${timezone}`);
  return localDateTime.toISOString();
};

/**
 * 将本地日期转换为 UTC 的结束时间（23:59:59）
 */
const toUTCEndOfDay = (dateStr: string): string => {
  const timezone = getLocalTimezoneOffset();
  const localDateTime = new Date(`${dateStr}T23:59:59${timezone}`);
  return localDateTime.toISOString();
};

/**
 * 构建开始日期时间参数（转换为 UTC）
 */
const buildStartDateTime = (): string | undefined => {
  if (!filters.startDate) return undefined;

  if (filters.startTime) {
    // 有具体时间：将本地时间转换为 UTC
    return toUTCISOString(filters.startDate, filters.startTime);
  } else {
    // 只有日期：返回该日期在本地 00:00:00 对应的 UTC 时间
    return toUTCStartOfDay(filters.startDate);
  }
};

/**
 * 构建结束日期时间参数（转换为 UTC）
 */
const buildEndDateTime = (): string | undefined => {
  if (!filters.endDate) return undefined;

  if (filters.endTime) {
    // 有具体时间：将本地时间转换为 UTC
    return toUTCISOString(filters.endDate, filters.endTime);
  } else {
    // 只有日期：返回该日期在本地 23:59:59 对应的 UTC 时间
    return toUTCEndOfDay(filters.endDate);
  }
};

const handleTimeRangeChange = (range: [string, string] | null) => {
  if (range && range[0] && range[1]) {
    filters.startTime = range[0];
    filters.endTime = range[1];
  } else {
    filters.startTime = "";
    filters.endTime = "";
  }
  pagination.page = 1;
  console.log("时间范围变化:", {
    startTime: filters.startTime,
    endTime: filters.endTime,
  });
  handleSearch();
};

/**
 * 处理日期范围选择器变化
 */
const handleDateRangeChange = (range: [string, string] | null) => {
  if (range && range[0] && range[1]) {
    filters.startDate = range[0];
    filters.endDate = range[1];
    // ✅ 不清空时间，允许日期和时间组合使用
  } else {
    filters.startDate = "";
    filters.endDate = "";
  }
  pagination.page = 1;
};

// 加载设备列表
const loadDevices = async () => {
  try {
    console.log("开始加载设备列表...");
    const { data } = await deviceApi.listAll();
    devices.value = data.items || [];
    console.log("设备列表加载成功:", devices.value.length, "个设备");
  } catch (error: any) {
    console.error("加载设备列表失败:", error);
    ElMessage.error(`加载设备列表失败: ${error.message || error}`);
    devices.value = [];
  }
};

// 加载截图列表（核心加载函数）
const loadScreenshots = async (isLoadMore = false) => {
  if (isLoadMore) {
    loadingMore.value = true;
  } else {
    loading.value = true;
  }

  try {
    const params: any = {
      page: pagination.page,
      pageSize: pagination.pageSize,
    };

    if (filters.deviceId) {
      params.deviceId = filters.deviceId;
    }

    // ✅ 如果有日期，使用日期
    if (filters.startDate && filters.endDate) {
      // 有日期：日期 + 时间
      const startDateTime = buildStartDateTime();
      const endDateTime = buildEndDateTime();
      if (startDateTime) params.startDate = startDateTime;
      if (endDateTime) params.endDate = endDateTime;
    }
    // ✅ 如果没有日期，但有时间，则使用当天日期 + 时间
    else if (filters.startTime || filters.endTime) {
      const today = new Date().toISOString().slice(0, 10);
      const startDateTime = buildStartDateTimeWithDate(
        today,
        filters.startTime,
      );
      const endDateTime = buildEndDateTimeWithDate(today, filters.endTime);
      if (startDateTime) params.startDate = startDateTime;
      if (endDateTime) params.endDate = endDateTime;
    }

    const { data } = await screenshotApi.list(params);
    screenshots.value = Array.isArray(data.items) ? data.items : [];
    pagination.total = Number(data.total) || 0;
  } catch (error: any) {
    console.error("加载截图列表失败:", error);
    ElMessage.error(error.message || "加载截图列表失败");
    screenshots.value = [];
    pagination.total = 0;
  } finally {
    loading.value = false;
    loadingMore.value = false;
  }
};

// ✅ 新增：使用指定日期构建开始时间
// ✅ 使用指定日期构建开始时间（支持时区转换）
const buildStartDateTimeWithDate = (
  date: string,
  time: string,
): string | undefined => {
  if (!date) return undefined;
  if (time) {
    return toUTCISOString(date, time);
  }
  return toUTCStartOfDay(date);
};

// ✅ 使用指定日期构建结束时间（支持时区转换）
const buildEndDateTimeWithDate = (
  date: string,
  time: string,
): string | undefined => {
  if (!date) return undefined;
  if (time) {
    return toUTCISOString(date, time);
  }
  return toUTCEndOfDay(date);
};

// ===== 搜索防抖处理 =====
// 创建防抖函数，延迟500ms执行
const debouncedSearch = debounce(() => {
  pagination.page = 1;
  loadScreenshots();
  searchLoading.value = false;
}, 500);

// 搜索入口（带防抖和加载状态）
const handleSearch = () => {
  searchLoading.value = true;
  debouncedSearch();
};

/**
 * 重置所有筛选条件
 */
const handleReset = () => {
  filters.deviceId = "";
  filters.startTime = "";
  filters.endTime = "";
  timeRange.value = null;
  dateRange.value = null;
  filters.startDate = "";
  filters.endDate = "";
  pagination.page = 1;
  loadScreenshots();
};

// 刷新
const handleRefresh = () => {
  loadScreenshots();
};

// 预览截图（自定义对话框）
const handlePreview = async (screenshot: Screenshot) => {
  currentScreenshot.value = screenshot;
  try {
    previewUrl.value = await loadImageUrl(screenshot.id, false);
    previewVisible.value = true;
  } catch {
    try {
      previewUrl.value = await loadImageUrl(screenshot.id, true, 1);
      previewVisible.value = true;
    } catch {
      ElMessage.warning("图片加载失败，请稍后重试");
    }
  }
};

// 关闭预览
const closePreview = () => {
  previewUrl.value = "";
  currentScreenshot.value = null;
};

// 图片加载错误（el-image 的 error 事件）
const handleImageError = async (screenshot: Screenshot) => {
  const thumbKey = imageCacheKey(screenshot.id, true);
  delete imageUrlMap[thumbKey];
  try {
    await loadImageUrl(screenshot.id, true, 2);
  } catch {
    try {
      await loadImageUrl(screenshot.id, false, 1);
    } catch {
      console.warn("截图加载失败:", screenshot.id);
    }
  }
};

// 预览错误
const handlePreviewError = () => {
  ElMessage.warning("图片加载失败");
};

// 删除单张截图
const handleDelete = (screenshot: Screenshot) => {
  ElMessageBox.confirm(
    `确定要删除 ${formatDateTime(screenshot.capturedAt)} 的截图吗？`,
    "删除确认",
    { confirmButtonText: "确定", cancelButtonText: "取消", type: "warning" },
  ).then(async () => {
    try {
      await screenshotApi.delete(screenshot.id);
      ElMessage.success("删除成功");
      revokeImageUrl(screenshot.id);
      loadScreenshots();
    } catch (error: any) {
      ElMessage.error(error.message || "删除失败");
    }
  });
};

const revokeImageUrl = (id: string) => {
  for (const key of [imageCacheKey(id, true), imageCacheKey(id, false)]) {
    const url = imageUrlMap[key];
    if (url) {
      URL.revokeObjectURL(url);
      delete imageUrlMap[key];
    }
  }
};

const clearImageUrlMap = () => {
  Object.keys(imageUrlMap).forEach((key) => {
    const url = imageUrlMap[key];
    if (url) URL.revokeObjectURL(url);
    delete imageUrlMap[key];
  });
};

let screenshotImageObserver: IntersectionObserver | null = null;

const observePendingScreenshotCards = () => {
  if (!screenshotImageObserver) return;
  document
    .querySelectorAll(".screenshots-page .card-image[data-screenshot-id]")
    .forEach((el) => {
      const id = el.getAttribute("data-screenshot-id");
      if (id && !imageUrlMap[imageCacheKey(id, true)]) {
        screenshotImageObserver!.observe(el);
      }
    });
};

const enterDeleteMode = () => {
  deleteMode.value = true;
  selectedIds.value = [];
};

const exitDeleteMode = () => {
  deleteMode.value = false;
  selectedIds.value = [];
};

const handleDeleteModeKeydown = (event: KeyboardEvent) => {
  if (event.key !== "Escape" || !deleteMode.value) return;
  if (previewVisible.value || deleteDialogVisible.value) return;
  exitDeleteMode();
};

const toggleScreenshotSelection = (id: string) => {
  const index = selectedIds.value.indexOf(id);
  if (index >= 0) {
    selectedIds.value.splice(index, 1);
  } else {
    selectedIds.value.push(id);
  }
};

const handleCardImageClick = (screenshot: Screenshot) => {
  if (deleteMode.value) {
    toggleScreenshotSelection(screenshot.id);
    return;
  }
};

const confirmDeleteSelected = async () => {
  if (selectedIds.value.length === 0) {
    ElMessage.warning("请先选择要删除的截图");
    return;
  }

  try {
    await ElMessageBox.confirm(
      `确定要删除选中的 ${selectedIds.value.length} 张截图吗？`,
      "删除确认",
      { confirmButtonText: "确定", cancelButtonText: "取消", type: "warning" },
    );
  } catch {
    return;
  }

  selectedDeleteLoading.value = true;
  try {
    const ids = [...selectedIds.value];
    const chunkSize = 100;
    for (let i = 0; i < ids.length; i += chunkSize) {
      await screenshotApi.batchDelete(ids.slice(i, i + chunkSize));
    }
    ids.forEach((id) => revokeImageUrl(id));
    ElMessage.success(`已删除 ${ids.length} 张截图`);
    exitDeleteMode();
    await loadScreenshots();
  } catch (error: any) {
    ElMessage.error(error.message || "删除失败");
  } finally {
    selectedDeleteLoading.value = false;
  }
};

const openDeleteDialog = () => {
  exitDeleteMode();
  deleteForm.mode = "selected";
  deleteForm.date = "";
  deleteDialogVisible.value = true;
};

const resetDeleteForm = () => {
  deleteForm.mode = "selected";
  deleteForm.date = "";
};

const handleDeleteDialogConfirm = async () => {
  if (deleteForm.mode === "selected") {
    deleteDialogVisible.value = false;
    enterDeleteMode();
    return;
  }
  await confirmDeletePurge();
};

const confirmDeletePurge = async () => {
  if (deleteForm.mode === "date" && !deleteForm.date) {
    ElMessage.warning("请选择要删除的日期");
    return;
  }

  const confirmText =
    deleteForm.mode === "all"
      ? "确定要删除全部截图吗？此操作不可恢复。"
      : `确定要删除 ${deleteForm.date} 的全部截图吗？此操作不可恢复。`;

  try {
    await ElMessageBox.confirm(confirmText, "删除确认", {
      confirmButtonText: "确定删除",
      cancelButtonText: "取消",
      type: "warning",
    });
  } catch {
    return;
  }

  deleteActionLoading.value = true;
  try {
    let response;
    if (deleteForm.mode === "all") {
      response = await screenshotApi.purge({ deleteAll: true });
    } else {
      response = await screenshotApi.purge({
        startDate: toUTCStartOfDay(deleteForm.date),
        endDate: toUTCEndOfDay(deleteForm.date),
      });
    }
    const deleted = response.data?.deleted ?? 0;
    if (deleted > 0) {
      ElMessage.success(`已删除 ${deleted} 张截图`);
    } else {
      ElMessage.info("没有符合条件的截图");
    }
    deleteDialogVisible.value = false;
    clearImageUrlMap();
    await loadScreenshots();
  } catch (error: any) {
    ElMessage.error(error.message || "删除失败");
  } finally {
    deleteActionLoading.value = false;
  }
};

// 从预览窗口删除
const handleDeleteFromPreview = () => {
  if (currentScreenshot.value) {
    previewVisible.value = false;
    handleDelete(currentScreenshot.value);
  }
};

// 下载截图
const downloadScreenshot = () => {
  if (!currentScreenshot.value) return;

  const a = document.createElement("a");
  a.href = previewUrl.value;
  a.download = `screenshot_${currentScreenshot.value.capturedAt.replace(/[:.]/g, "-")}.jpg`;
  a.click();
  ElMessage.success("下载已开始");
};

// 只格式化日期
const formatDateOnly = (time: string) => {
  if (!time) return "-";
  const date = new Date(time);
  return date.toLocaleDateString("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
};

// 只格式化时间；有非零毫秒时才显示，避免多余的 ".000"
const formatTimeOnly = (time: string) => {
  if (!time) return "-";
  const date = new Date(time);
  const base = date.toLocaleTimeString("zh-CN", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
  const ms = date.getMilliseconds();
  return ms > 0 ? `${base}.${String(ms).padStart(3, "0")}` : base;
};

// 分页变化处理
const handleCurrentChange = (page: number) => {
  pagination.page = page;
  loadScreenshots();
};

const handleSizeChange = (size: number) => {
  pagination.pageSize = size;
  pagination.page = 1;
  loadScreenshots();
};

// 监听时间变化，自动搜索（带防抖）
const handleTimeChange = debounce(() => {
  handleSearch();
}, 300);

const initFromRouteParams = () => {
  const deviceId = route.query.deviceId as string;
  const deviceName = route.query.deviceName as string;

  if (deviceId) {
    filters.deviceId = deviceId;
    if (deviceName) {
      ElMessage.success(`正在查看设备: ${deviceName} 的截图`);
    }
    handleSearch();
  }
};

// 组件卸载时取消防抖
onBeforeUnmount(() => {
  debouncedSearch.cancel();
  handleTimeChange.cancel();
  window.removeEventListener("keydown", handleDeleteModeKeydown);
  screenshotImageObserver?.disconnect();
  screenshotImageObserver = null;
  clearImageUrlMap();
});

onMounted(() => {
  screenshotImageObserver = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        const id = entry.target.getAttribute("data-screenshot-id");
        if (id) {
          queueScreenshotThumbnail(id);
          screenshotImageObserver?.unobserve(entry.target);
        }
      }
    },
    { rootMargin: "240px" },
  );
  window.addEventListener("keydown", handleDeleteModeKeydown);
  loadDevices();
  initFromRouteParams();
  if (!route.query.deviceId) {
    loadScreenshots();
  }
});

watch(
  screenshots,
  () => nextTick(observePendingScreenshotCards),
  { flush: "post" },
);
</script>

<style scoped>
.screenshots-page {
  padding: 0px;
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
}

/* ========== 背景装饰 ========== */
.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}

.blob-1 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -200px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 600px;
  height: 600px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -250px;
  left: -150px;
  animation-delay: -5s;
}

.blob-3 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 30%;
  animation-delay: -10s;
}

@keyframes float {
  0%,
  100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -30px) scale(1.05);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.95);
  }
}

/* 确保内容在背景之上 */
.filter-card,
.delete-mode-bar,
.grid-container,
.pagination {
  position: relative;
  z-index: 1;
}

.filter-card {
  margin-bottom: 20px;
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  transition: all 0.3s ease;
}

/* 筛选表单居中对齐 */
.filter-form {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
}

.filter-form .el-form-item {
  margin-bottom: 0;
  display: inline-flex;
  align-items: center;
}

.filter-form .el-form-item:last-child {
  margin-left: auto;
}

/* 卡片悬停动画 */
.card-hover {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.card-hover:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
}

/* 按钮样式 */
:deep(.el-button--primary) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border: none;
  transition: all 0.3s ease;
}

:deep(.el-button--primary):hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

:deep(.el-button--danger) {
  background: linear-gradient(135deg, #fa709a, #fee140);
  border: none;
  color: white;
}

:deep(.el-button--danger):hover {
  transform: translateY(-2px);
}

/* 网格视图 */
.grid-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.result-hint {
  margin: 0 0 12px 4px;
  color: #606266;
  font-size: 13px;
}

.delete-mode-hint {
  margin-left: 12px;
  color: #e6a23c;
  font-weight: 500;
}

.delete-mode-bar {
  margin-bottom: 16px;
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(245, 108, 108, 0.25);
}

.delete-mode-bar-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
}

.delete-mode-bar-text {
  display: flex;
  align-items: center;
  gap: 10px;
  color: #303133;
  font-size: 14px;
  font-weight: 500;
}

.delete-mode-bar-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.delete-mode-bar-tip {
  margin-top: 8px;
  font-size: 12px;
  color: #909399;
}

.delete-mode-active .screenshot-card.is-selected {
  outline: 3px solid #f56c6c;
  outline-offset: -3px;
  box-shadow: 0 0 0 4px rgba(245, 108, 108, 0.15);
}

.card-image.selectable {
  cursor: pointer;
}

.selected-badge {
  position: absolute;
  top: 12px;
  left: 12px;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: #f56c6c;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 11;
  box-shadow: 0 2px 8px rgba(245, 108, 108, 0.45);
}

.screenshot-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
  transition: all 0.3s ease;
  position: relative;
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.screenshot-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
}

/* 图片区域样式 */
.card-image {
  position: relative;
  width: 100%;
  height: 180px;
  overflow: hidden;
  background: rgba(245, 247, 250, 0.8);
  cursor: pointer;
}

.card-image :deep(.el-image) {
  width: 100%;
  height: 100%;
}

.card-image :deep(.el-image__inner) {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.screenshot-card:hover .card-image :deep(.el-image__inner) {
  transform: scale(1.05);
}

/* 图片懒加载骨架屏样式 */
.image-skeleton {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
  background-size: 200% 100%;
  animation: skeleton-loading 1.5s infinite;
}

.skeleton-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: #999;
  font-size: 12px;
}

.skeleton-loading .el-icon {
  font-size: 24px;
  animation: rotate 1s linear infinite;
}

@keyframes skeleton-loading {
  0% {
    background-position: 200% 0;
  }
  100% {
    background-position: -200% 0;
  }
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

/* 骨架屏网格（加载更多时） */
.skeleton-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  width: 100%;
}

.skeleton-card {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  overflow: hidden;
  padding: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
}

/* 图片加载错误样式 */
.image-error {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: #999;
  background: rgba(245, 247, 250, 0.8);
}

.image-error .el-icon {
  font-size: 32px;
}

/* 加密标识 */
.encrypted-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  background: rgba(0, 0, 0, 0.7);
  color: #ffc53d;
  padding: 4px 8px;
  border-radius: 8px;
  font-size: 11px;
  display: flex;
  align-items: center;
  gap: 4px;
  backdrop-filter: blur(4px);
  z-index: 10;
  pointer-events: none;
}

/* 信息区域 */
.card-info {
  padding: 12px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  cursor: pointer;
  transition: background 0.2s ease;
}

.card-info:hover {
  background: rgba(245, 247, 250, 0.5);
}

.device-name,
.capture-time,
.file-size {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: #666;
  margin-bottom: 8px;
}

.device-name .el-icon,
.capture-time .el-icon,
.file-size .el-icon {
  font-size: 14px;
  color: #909399;
}

.employee-name {
  font-weight: 600;
  font-size: 14px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  cursor: help;
}

/* 悬浮删除按钮 */
.delete-hover-btn {
  position: absolute;
  top: 12px;
  right: 12px;
  z-index: 10;
  opacity: 0;
  transition: opacity 0.2s ease;
}

.screenshot-card:hover .delete-hover-btn {
  opacity: 1;
}

.delete-hover-btn .el-button {
  width: 32px;
  height: 32px;
  padding: 0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  background: linear-gradient(135deg, #fa709a, #fee140);
  border: none;
}

.delete-hover-btn .el-button:hover {
  transform: scale(1.05);
}

.capture-time {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: #666;
  margin-bottom: 8px;
}

.capture-date {
  font-weight: normal;
  color: #666;
}

.capture-time-only {
  font-weight: 700;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  font-size: 14px;
}

/* 分页 */
.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.pagination :deep(.el-pagination .btn-prev),
.pagination :deep(.el-pagination .btn-next),
.pagination :deep(.el-pager li) {
  border-radius: 10px;
  margin: 0 3px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  font-weight: 500;
  min-width: 36px;
  height: 36px;
}

.pagination :deep(.el-pager li.active) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-color: transparent;
  color: #ffffff;
}

/* 预览对话框 */
.preview-container {
  text-align: center;
}

.preview-image {
  max-width: 100%;
  max-height: auto;
  border-radius: 12px;
  margin-bottom: 5px;
}

.preview-info {
  margin-top: 0px;
}

/* 现代化对话框 */
.modern-dialog :deep(.el-dialog) {
  border-radius: 20px;
  overflow: hidden;
}

.modern-dialog :deep(.el-dialog__header) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  padding: 16px 20px;
  margin: 0;
}

.modern-dialog :deep(.el-dialog__title) {
  color: white;
  font-weight: 600;
  font-size: 18px;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: white;
  font-size: 18px;
}

.modern-dialog :deep(.el-dialog__body) {
  padding: 20px;
  max-height: 70vh;
  overflow-y: auto;
}

.modern-dialog :deep(.el-dialog__footer) {
  padding: 16px 20px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

/* 对话框动画 */
.animate-dialog :deep(.el-dialog) {
  animation: dialogFadeIn 0.3s ease;
}

.device-name span:last-child {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 120px;
}

@keyframes dialogFadeIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

/* 描述列表样式优化 */
:deep(.el-descriptions) {
  background: transparent;
}

:deep(.el-descriptions__label) {
  background: rgba(248, 250, 252, 0.8);
  font-weight: 600;
}

/* 滚动条美化 */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(135deg, #5a67d8, #6b46c1);
}

/* 响应式 */
@media (max-width: 1200px) {
  .screenshots-page {
    padding: 1px;
  }

  .blob-1,
  .blob-2,
  .blob-3 {
    opacity: 0.2;
  }
}

@media (max-width: 768px) {
  .screenshots-page {
    padding: 1px;
  }

  .blob-1,
  .blob-2,
  .blob-3 {
    display: none;
  }

  .grid-container {
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
    gap: 12px;
  }

  .filter-form {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }

  .filter-form .el-form-item {
    margin-bottom: 0;
    width: 100%;
  }

  .filter-form .el-form-item .el-select,
  .filter-form .el-form-item .el-date-editor,
  .filter-form .el-form-item .el-time-select {
    width: 100% !important;
  }

  .filter-form .el-form-item:last-child {
    margin-left: 0;
    justify-content: flex-start;
  }

  .el-date-editor--daterange {
    width: 100% !important;
  }

  .pagination {
    overflow-x: auto;
  }

  .pagination :deep(.el-pagination) {
    flex-wrap: wrap;
    justify-content: center;
  }
}
</style>

<template>
  <div class="upload-manager">
    <el-alert
      type="info"
      :closable="false"
      show-icon
      class="info-alert"
      title="录屏文件由已审核的 Agent 客户端自动上传"
      description="管理员请在「录屏管理」中按时间范围创建上传任务；本页用于查看 Agent 执行进度。浏览器无法直接上传分块文件（需设备签名）。"
    />

    <el-card class="tasks-card">
      <template #header>
        <div class="card-header">
          <span>Agent 上传任务</span>
          <el-button size="small" @click="refreshTasks" :loading="loading">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
        </div>
      </template>

      <div class="stats-bar">
        <div class="stat-item">
          <span class="stat-label">总任务</span>
          <span class="stat-value">{{ allTasks.length }}</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">等待中</span>
          <span class="stat-value pending">{{ statusCount("pending") }}</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">执行中</span>
          <span class="stat-value running">{{ statusCount("running") }}</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">已完成</span>
          <span class="stat-value completed">{{ statusCount("completed") }}</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">失败</span>
          <span class="stat-value failed">{{ statusCount("failed") }}</span>
        </div>
      </div>

      <el-table :data="displayTasks" v-loading="loading" stripe>
        <el-table-column prop="id" label="任务ID" width="200">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="showTaskDetail(row)">
              {{ row.id?.substring(0, 12) || "未知" }}...
            </el-button>
          </template>
        </el-table-column>

        <el-table-column prop="deviceId" label="设备" width="180">
          <template #default="{ row }">
            {{ formatDeviceId(row.deviceId) }}
          </template>
        </el-table-column>

        <el-table-column prop="type" label="类型" width="140">
          <template #default="{ row }">
            {{ formatTaskType(row.type) }}
          </template>
        </el-table-column>

        <el-table-column label="时间范围" min-width="220">
          <template #default="{ row }">
            <div class="time-range">
              <span>{{ formatDateTime(row.startTime) }}</span>
              <span v-if="row.endTime"> ~ {{ formatDateTime(row.endTime) }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="progress" label="进度" width="160">
          <template #default="{ row }">
            <el-progress
              :percentage="row.progress ?? 0"
              :stroke-width="6"
              :status="getProgressStatus(row.status)"
            />
          </template>
        </el-table-column>

        <el-table-column prop="createdAt" label="创建时间" width="170">
          <template #default="{ row }">
            {{ formatDateTime(row.createdAt) }}
          </template>
        </el-table-column>

        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="showTaskDetail(row)">
              详情
            </el-button>
            <el-button
              v-if="canCancel(row.status)"
              v-permission="'recording:upload'"
              type="danger"
              link
              size="small"
              @click="handleCancel(row)"
            >
              取消
            </el-button>
            <el-button
              v-if="row.status === 'failed'"
              v-permission="'recording:upload'"
              type="warning"
              link
              size="small"
              @click="handleRetry(row)"
            >
              重试
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="allTasks.length"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>

      <el-empty
        v-if="allTasks.length === 0 && !loading"
        description="暂无上传任务，请在录屏管理中创建"
      />
    </el-card>

    <el-dialog v-model="detailVisible" title="任务详情" width="640px">
      <div v-if="selectedTask" class="task-detail">
        <el-descriptions :column="1" border>
          <el-descriptions-item label="任务ID">
            {{ selectedTask.id }}
          </el-descriptions-item>
          <el-descriptions-item label="设备ID">
            {{ selectedTask.deviceId }}
          </el-descriptions-item>
          <el-descriptions-item label="任务类型">
            {{ formatTaskType(selectedTask.type) }}
          </el-descriptions-item>
          <el-descriptions-item label="开始时间">
            {{ formatDateTime(selectedTask.startTime) }}
          </el-descriptions-item>
          <el-descriptions-item label="结束时间">
            {{ formatDateTime(selectedTask.endTime) }}
          </el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="getStatusType(selectedTask.status)">
              {{ getStatusText(selectedTask.status) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="进度">
            {{ selectedTask.progress ?? 0 }}%
          </el-descriptions-item>
          <el-descriptions-item label="创建时间">
            {{ formatDateTime(selectedTask.createdAt) }}
          </el-descriptions-item>
          <el-descriptions-item v-if="selectedTask.completedAt" label="完成时间">
            {{ formatDateTime(selectedTask.completedAt) }}
          </el-descriptions-item>
          <el-descriptions-item v-if="selectedTask.result" label="结果说明">
            {{ selectedTask.result }}
          </el-descriptions-item>
        </el-descriptions>
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { taskApi } from "@api/index";
import type { DeviceTask } from "@api/types";
import { formatDateTime } from "@api/format";
import { Refresh } from "@element-plus/icons-vue";

const allTasks = ref<DeviceTask[]>([]);
const loading = ref(false);
const selectedTask = ref<DeviceTask | null>(null);
const detailVisible = ref(false);

const pagination = ref({
  page: 1,
  pageSize: 20,
});

const displayTasks = computed(() => {
  const start = (pagination.value.page - 1) * pagination.value.pageSize;
  const end = start + pagination.value.pageSize;
  return allTasks.value.slice(start, end);
});

const statusCount = (status: string) =>
  allTasks.value.filter((task) => task.status === status).length;

const formatDeviceId = (deviceId?: string) => {
  if (!deviceId) return "-";
  return deviceId.length > 12 ? `${deviceId.slice(0, 8)}...` : deviceId;
};

const formatTaskType = (type?: string) => {
  if (type === "upload_recordings") return "录屏上传";
  if (type === "upload_screenshots") return "截图上传";
  return type || "-";
};

const getStatusType = (status: string): string => {
  const map: Record<string, string> = {
    pending: "info",
    running: "warning",
    completed: "success",
    failed: "danger",
    cancelled: "info",
  };
  return map[status] || "info";
};

const getStatusText = (status: string): string => {
  const map: Record<string, string> = {
    pending: "等待中",
    running: "执行中",
    completed: "已完成",
    failed: "失败",
    cancelled: "已取消",
  };
  return map[status] || status;
};

const getProgressStatus = (status: string) => {
  if (status === "completed") return "success";
  if (status === "failed") return "exception";
  return undefined;
};

const canCancel = (status: string) =>
  status === "pending" || status === "running";

const refreshTasks = async () => {
  loading.value = true;
  try {
    const { data } = await taskApi.list();
    allTasks.value = data?.items ?? [];
  } catch (error: any) {
    ElMessage.error(error.message || "获取任务列表失败");
    allTasks.value = [];
  } finally {
    loading.value = false;
  }
};

const handleCancel = async (task: DeviceTask) => {
  try {
    await ElMessageBox.confirm("确定要取消该上传任务吗？", "取消确认", {
      type: "warning",
      confirmButtonText: "确定",
      cancelButtonText: "取消",
    });
    await taskApi.cancel(task.id);
    ElMessage.success("任务已取消");
    await refreshTasks();
  } catch (error: any) {
    if (error !== "cancel") {
      ElMessage.error(error.message || "取消失败");
    }
  }
};

const handleRetry = async (task: DeviceTask) => {
  try {
    await taskApi.retry(task.id);
    ElMessage.success("任务已重新排队");
    await refreshTasks();
  } catch (error: any) {
    ElMessage.error(error.message || "重试失败");
  }
};

const handleSizeChange = (size: number) => {
  pagination.value.pageSize = size;
  pagination.value.page = 1;
};

const handleCurrentChange = (page: number) => {
  pagination.value.page = page;
};

const showTaskDetail = (task: DeviceTask) => {
  selectedTask.value = task;
  detailVisible.value = true;
};

onMounted(() => {
  refreshTasks();
});
</script>

<style scoped>
.upload-manager {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.info-alert {
  border-radius: 8px;
}

.tasks-card {
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.stats-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  padding: 16px;
  background-color: #f5f7fa;
  border-radius: 4px;
  margin-bottom: 16px;
}

.stat-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.stat-label {
  color: #909399;
  font-size: 12px;
}

.stat-value {
  color: #303133;
  font-weight: bold;
  font-size: 20px;
}

.stat-value.pending {
  color: #909399;
}

.stat-value.running {
  color: #e6a23c;
}

.stat-value.completed {
  color: #67c23a;
}

.stat-value.failed {
  color: #f56c6c;
}

.time-range {
  display: flex;
  flex-direction: column;
  gap: 2px;
  font-size: 13px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.task-detail {
  padding: 8px 0;
}
</style>

<template>
  <div class="security-whitelist-page attendance-management">
    <div class="bg-decoration" aria-hidden="true">
      <div class="blob blob-1 sec-blob-1"></div>
      <div class="blob blob-2 sec-blob-2"></div>
    </div>

    <div class="sec-content">
      <el-card class="sec-main-card" shadow="never">
        <template #header>
          <div class="sec-page-header">
            <div>
              <h2 class="sec-title">安全与白名单</h2>
              <p class="sec-subtitle">
                配置跨域来源、登录安全策略与后台登录 IP 限制，保存后立即生效
              </p>
            </div>
          </div>
        </template>

        <div class="sec-panel">
          <div class="sec-panel-head">
            <div class="sec-panel-icon cors">
              <el-icon><Link /></el-icon>
            </div>
            <div>
              <h3 class="sec-panel-title">
                <span class="sec-panel-num">01</span>
                CORS / WebSocket Origin 白名单
              </h3>
              <p class="sec-panel-desc">
                填写浏览器地址栏中的完整 Origin（含协议与端口），用于 API 跨域与 WebSocket 连接校验。
              </p>
            </div>
          </div>

          <div class="sec-field-card">
            <label class="sec-field-label">允许的来源</label>
            <el-select
              v-model="corsOrigins"
              multiple
              filterable
              allow-create
              default-first-option
              placeholder="例如 https://monitor.example.com:8888"
              class="sec-select"
            >
              <el-option
                v-for="item in corsOrigins"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </div>

          <div class="sec-field-card">
            <label class="sec-field-label">当前生效</label>
            <div class="sec-tag-panel">
              <el-tag
                v-for="item in corsConfig.effectiveOrigins"
                :key="item"
                size="small"
                effect="light"
                class="sec-origin-tag"
              >
                {{ item }}
              </el-tag>
              <span v-if="!corsConfig.effectiveOrigins?.length" class="sec-empty-tip">
                未配置（生产环境将导致 Web 无法连接）
              </span>
            </div>
            <p class="sec-meta">
              来源：{{ corsSourceLabel
              }}<span v-if="corsConfig.updatedAt"
                >，更新于 {{ formatTime(corsConfig.updatedAt) }}</span
              >
            </p>
          </div>

          <div class="sec-actions">
            <el-button type="primary" :loading="corsSaveLoading" @click="handleSaveCorsOrigins">
              保存 Origin 白名单
            </el-button>
            <el-button @click="loadCorsOrigins">重置</el-button>
          </div>
        </div>

        <div class="sec-panel">
          <div class="sec-panel-head">
            <div class="sec-panel-icon auth">
              <el-icon><Lock /></el-icon>
            </div>
            <div>
              <h3 class="sec-panel-title">
                <span class="sec-panel-num">02</span>
                登录安全
              </h3>
              <p class="sec-panel-desc">
                控制 Web 后台登录时的图形验证码与谷歌验证器（TOTP）。
              </p>
            </div>
          </div>

          <div class="sec-toggle-grid">
            <div class="sec-toggle-card">
              <div class="sec-toggle-icon captcha">
                <el-icon><Picture /></el-icon>
              </div>
              <div class="sec-toggle-body">
                <h5>图形验证码</h5>
                <p>开启后登录页需输入服务端生成的验证码</p>
              </div>
              <el-switch v-model="authSecurity.loginCaptchaEnabled" />
            </div>

            <div class="sec-toggle-card">
              <div class="sec-toggle-icon totp">
                <el-icon><Key /></el-icon>
              </div>
              <div class="sec-toggle-body">
                <h5>谷歌验证器</h5>
                <p>开启后用户需使用 Google Authenticator 等应用完成二次验证</p>
              </div>
              <el-switch v-model="authSecurity.loginTotpEnabled" />
            </div>
          </div>

          <p v-if="authSecurity.updatedAt" class="sec-meta block">
            上次更新：{{ formatTime(authSecurity.updatedAt) }}
          </p>

          <div class="sec-actions">
            <el-button type="primary" :loading="authSecuritySaveLoading" @click="handleSaveAuthSecurity">
              保存登录安全
            </el-button>
            <el-button @click="loadAuthSecurity">重置</el-button>
          </div>
        </div>

        <div class="sec-panel">
          <div class="sec-panel-head">
            <div class="sec-panel-icon ip">
              <el-icon><Location /></el-icon>
            </div>
            <div>
              <h3 class="sec-panel-title">
                <span class="sec-panel-num">03</span>
                登录 IP 白名单
              </h3>
              <p class="sec-panel-desc">
                开启后，仅列表中的 IP 或网段可登录 Web 管理后台。客户端识别优先使用 Nginx 转发的 X-Forwarded-For 首段 IP。
              </p>
            </div>
          </div>

          <div class="sec-toggle-grid single">
            <div class="sec-toggle-card">
              <div class="sec-toggle-icon ip-switch">
                <el-icon><Connection /></el-icon>
              </div>
              <div class="sec-toggle-body">
                <h5>启用 IP 白名单</h5>
                <p>关闭时不校验登录 IP</p>
              </div>
              <el-switch v-model="loginIPWhitelist.enabled" />
            </div>
          </div>

          <div class="sec-field-card" :class="{ disabled: !loginIPWhitelist.enabled }">
            <label class="sec-field-label">允许的 IP / 网段</label>
            <el-select
              v-model="loginIPWhitelistIPs"
              multiple
              filterable
              allow-create
              default-first-option
              placeholder="例如 203.0.113.10 或 192.168.1.0/24"
              class="sec-select"
              :disabled="!loginIPWhitelist.enabled"
            >
              <el-option
                v-for="item in loginIPWhitelistIPs"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </div>

          <p v-if="loginIPWhitelist.updatedAt" class="sec-meta block">
            上次更新：{{ formatTime(loginIPWhitelist.updatedAt) }}
          </p>

          <div class="sec-actions">
            <el-button type="primary" :loading="loginIPSaveLoading" @click="handleSaveLoginIPWhitelist">
              保存 IP 白名单
            </el-button>
            <el-button @click="loadLoginIPWhitelist">重置</el-button>
          </div>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, computed } from "vue";
import { ElMessage } from "element-plus";
import { Link, Lock, Location, Picture, Key, Connection } from "@element-plus/icons-vue";
import {
  settingsApi,
  type AuthSecurityConfig,
  type CorsOriginsConfig,
  type LoginIPWhitelistConfig,
} from "@api/index";

const corsOrigins = ref<string[]>([]);
const corsSaveLoading = ref(false);
const corsConfig = reactive<CorsOriginsConfig>({
  origins: [],
  effectiveOrigins: [],
  source: "none",
});

const corsSourceLabel = computed(() => {
  const map: Record<string, string> = {
    database: "Web 后台配置",
    environment: ".env 环境变量",
    default: "开发环境默认值",
    none: "未配置",
  };
  return map[corsConfig.source] || corsConfig.source;
});

const authSecurity = reactive<AuthSecurityConfig>({
  loginCaptchaEnabled: true,
  loginTotpEnabled: false,
});
const authSecuritySaveLoading = ref(false);

const loginIPWhitelist = reactive<LoginIPWhitelistConfig>({
  enabled: false,
  ips: [],
});
const loginIPWhitelistIPs = ref<string[]>([]);
const loginIPSaveLoading = ref(false);

const formatTime = (time: string | null) => {
  if (!time) return "—";
  const date = new Date(time);
  return date.toLocaleString("zh-CN");
};

const loadCorsOrigins = async () => {
  try {
    const { data } = await settingsApi.getCorsOrigins();
    Object.assign(corsConfig, data);
    corsOrigins.value = [...(data.origins || [])];
  } catch (error: any) {
    ElMessage.error(error.message || "加载 CORS 白名单失败");
  }
};

const handleSaveCorsOrigins = async () => {
  corsSaveLoading.value = true;
  try {
    const { data } = await settingsApi.updateCorsOrigins(corsOrigins.value);
    Object.assign(corsConfig, data);
    corsOrigins.value = [...(data.origins || [])];
    ElMessage.success("CORS 白名单已保存并立即生效");
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    corsSaveLoading.value = false;
  }
};

const loadAuthSecurity = async () => {
  try {
    const { data } = await settingsApi.getAuthSecurity();
    Object.assign(authSecurity, data);
  } catch (error: any) {
    ElMessage.error(error.message || "加载登录安全配置失败");
  }
};

const handleSaveAuthSecurity = async () => {
  authSecuritySaveLoading.value = true;
  try {
    const { data } = await settingsApi.updateAuthSecurity({
      loginCaptchaEnabled: authSecurity.loginCaptchaEnabled,
      loginTotpEnabled: authSecurity.loginTotpEnabled,
    });
    Object.assign(authSecurity, data);
    ElMessage.success("登录安全配置已保存");
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    authSecuritySaveLoading.value = false;
  }
};

const loadLoginIPWhitelist = async () => {
  try {
    const { data } = await settingsApi.getLoginIPWhitelist();
    Object.assign(loginIPWhitelist, data);
    loginIPWhitelistIPs.value = [...(data.ips || [])];
  } catch (error: any) {
    ElMessage.error(error.message || "加载登录 IP 白名单失败");
  }
};

const handleSaveLoginIPWhitelist = async () => {
  if (loginIPWhitelist.enabled && loginIPWhitelistIPs.value.length === 0) {
    ElMessage.warning("启用 IP 白名单时请至少添加一条 IP 或网段");
    return;
  }

  loginIPSaveLoading.value = true;
  try {
    const { data } = await settingsApi.updateLoginIPWhitelist({
      enabled: loginIPWhitelist.enabled,
      ips: loginIPWhitelistIPs.value,
    });
    Object.assign(loginIPWhitelist, data);
    loginIPWhitelistIPs.value = [...(data.ips || [])];
    ElMessage.success("登录 IP 白名单已保存并立即生效");
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    loginIPSaveLoading.value = false;
  }
};

onMounted(() => {
  loadCorsOrigins();
  loadAuthSecurity();
  loadLoginIPWhitelist();
});
</script>

<style scoped>
@import "./attendance/attendance.css";

.security-whitelist-page {
  position: relative;
  min-height: 100%;
}

.sec-blob-1 {
  background: linear-gradient(135deg, #f97316, #ea580c);
  opacity: 0.24;
}

.sec-blob-2 {
  background: linear-gradient(135deg, #6366f1, #4f46e5);
  opacity: 0.22;
}

.sec-content {
  position: relative;
  z-index: 1;
  width: 100%;
  padding: 8px 0 32px;
}

.sec-main-card {
  border-radius: 18px;
  border: 1px solid rgba(255, 255, 255, 0.65);
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(16px);
  box-shadow: 0 8px 32px rgba(15, 23, 42, 0.08);
}

.sec-main-card :deep(.el-card__header) {
  padding: 20px 24px 12px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.sec-main-card :deep(.el-card__body) {
  padding: 16px 24px 24px;
}

.sec-page-header {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}

.sec-title {
  margin: 0 0 6px;
  font-size: 20px;
  font-weight: 700;
  color: #303133;
}

.sec-subtitle {
  margin: 0;
  font-size: 13px;
  color: #909399;
  line-height: 1.5;
  max-width: 640px;
}

.sec-panel {
  margin-bottom: 20px;
  padding: 20px;
  border-radius: 16px;
  background: linear-gradient(145deg, #f8fafc 0%, #f1f5f9 100%);
  border: 1px solid rgba(0, 0, 0, 0.06);
}

.sec-panel:last-child {
  margin-bottom: 0;
}

.sec-panel-head {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  margin-bottom: 18px;
}

.sec-panel-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  border-radius: 14px;
  font-size: 22px;
  color: #fff;
  flex-shrink: 0;
}

.sec-panel-icon.cors {
  background: linear-gradient(135deg, #38bdf8, #0ea5e9);
}

.sec-panel-icon.auth {
  background: linear-gradient(135deg, #818cf8, #6366f1);
}

.sec-panel-icon.ip {
  background: linear-gradient(135deg, #34d399, #10b981);
}

.sec-panel-title {
  margin: 0 0 6px;
  font-size: 16px;
  font-weight: 600;
  color: #303133;
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.sec-panel-num {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 28px;
  height: 28px;
  padding: 0 8px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, #667eea, #764ba2);
}

.sec-panel-desc {
  margin: 0;
  font-size: 13px;
  color: #909399;
  line-height: 1.55;
}

.sec-field-card {
  margin-bottom: 14px;
  padding: 16px;
  border-radius: 14px;
  background: #fff;
  border: 1px solid rgba(0, 0, 0, 0.06);
  box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
  transition: opacity 0.2s ease;
}

.sec-field-card.disabled {
  opacity: 0.55;
}

.sec-field-label {
  display: block;
  margin-bottom: 10px;
  font-size: 13px;
  font-weight: 600;
  color: #606266;
}

.sec-select {
  width: 100%;
}

.sec-tag-panel {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  min-height: 28px;
  padding: 12px;
  border-radius: 10px;
  background: rgba(0, 136, 204, 0.04);
  border: 1px dashed rgba(0, 136, 204, 0.2);
}

.sec-origin-tag {
  margin: 0;
  border-radius: 8px;
}

.sec-empty-tip {
  font-size: 13px;
  color: #f56c6c;
}

.sec-meta {
  margin: 10px 0 0;
  font-size: 12px;
  color: #909399;
}

.sec-meta.block {
  margin-bottom: 4px;
}

.sec-toggle-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}

.sec-toggle-grid.single {
  grid-template-columns: 1fr;
  max-width: 520px;
}

.sec-toggle-card {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 16px;
  border-radius: 14px;
  background: #fff;
  border: 1px solid rgba(0, 0, 0, 0.06);
  box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.sec-toggle-card:hover {
  border-color: rgba(99, 102, 241, 0.25);
  box-shadow: 0 8px 24px rgba(99, 102, 241, 0.1);
}

.sec-toggle-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 42px;
  height: 42px;
  border-radius: 12px;
  font-size: 20px;
  color: #fff;
  flex-shrink: 0;
}

.sec-toggle-icon.captcha {
  background: linear-gradient(135deg, #fbbf24, #f59e0b);
}

.sec-toggle-icon.totp {
  background: linear-gradient(135deg, #818cf8, #6366f1);
}

.sec-toggle-icon.ip-switch {
  background: linear-gradient(135deg, #34d399, #10b981);
}

.sec-toggle-body {
  flex: 1;
  min-width: 0;
}

.sec-toggle-body h5 {
  margin: 0 0 4px;
  font-size: 14px;
  font-weight: 600;
  color: #303133;
}

.sec-toggle-body p {
  margin: 0;
  font-size: 12px;
  color: #909399;
  line-height: 1.5;
}

.sec-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 4px;
  padding-top: 14px;
  border-top: 1px dashed rgba(0, 0, 0, 0.08);
}

@media (max-width: 768px) {
  .sec-toggle-grid {
    grid-template-columns: 1fr;
  }
}
</style>

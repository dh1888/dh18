export function formatSeconds(sec: number) {
  if (!sec) return "0秒";
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m > 0) return s ? `${m}分${s}秒` : `${m}分钟`;
  return `${s}秒`;
}

export function formatDateTime(v: string) {
  if (!v) return "-";
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? v : d.toLocaleString("zh-CN", { hour12: false });
}

export function formatGroupGrace(before?: number, after?: number) {
  if (!before && !after) return "全局";
  const parts: string[] = [];
  if (before) parts.push(`前${before}`);
  if (after) parts.push(`后${after}`);
  return parts.join("/") || "全局";
}

export function groupOptionLabel(g: { chatTitle?: string; chatId?: string }) {
  const title = (g.chatTitle || "").trim() || "未命名群";
  return `${title} (${g.chatId || ""})`;
}

export function todayDateStr() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

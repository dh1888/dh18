<template>
  <div class="dm-page">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <el-tabs v-model="activeTab" class="modern-tabs">
      <!-- ===== 域名列表 Tab ===== -->
      <el-tab-pane label="域名列表" name="domains">
        <template #label>
          <span class="tab-label">
            <el-icon><Monitor /></el-icon>
            域名列表
            <el-badge :value="pagination.total" :hidden="pagination.total === 0" class="tab-badge" />
          </span>
        </template>

        <el-card shadow="hover" class="filter-card">
          <el-form :inline="true" @submit.prevent="loadDomains" class="filter-form">
            <el-form-item label="关键词">
              <el-input
                v-model="filters.keyword"
                placeholder="搜索域名"
                clearable
                @clear="loadDomains"
                class="modern-input"
                prefix-icon="Search"
              />
            </el-form-item>
            <el-form-item label="分组">
              <el-select
                v-model="filters.groupId"
                placeholder="全部分组"
                clearable
                style="width: 160px"
                @change="loadDomains"
                class="modern-select"
              >
                <el-option
                  v-for="g in groups"
                  :key="g.id"
                  :label="g.name"
                  :value="g.id"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="状态">
              <el-select
                v-model="filters.enabled"
                placeholder="全部状态"
                clearable
                style="width: 120px"
                @change="loadDomains"
                class="modern-select"
              >
                <el-option label="启用" :value="true" />
                <el-option label="禁用" :value="false" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="loadDomains" class="search-btn">
                <el-icon><Search /></el-icon>
                查询
              </el-button>
              <el-button @click="resetFilters" class="reset-btn">
                <el-icon><RefreshLeft /></el-icon>
                重置
              </el-button>
            </el-form-item>
          </el-form>

          <div class="toolbar">
            <div class="toolbar-left">
              <el-button
                type="primary"
                v-permission="'domain_monitor:manage'"
                @click="openDomainDialog()"
                class="add-btn"
              >
                <el-icon><Plus /></el-icon>
                新增域名
              </el-button>
              <el-button
                v-permission="'domain_monitor:manage'"
                :disabled="!selectedDomains.length"
                @click="openBatchDialog"
                class="batch-btn"
                :class="{ 'has-selection': selectedDomains.length }"
              >
                <el-icon><Edit /></el-icon>
                批量编辑
                <el-badge
                  v-if="selectedDomains.length"
                  :value="selectedDomains.length"
                  class="selection-badge"
                />
              </el-button>
              <el-button
                v-permission="'domain_monitor:manage'"
                @click="openImportDialog"
                class="import-btn"
              >
                <el-icon><Upload /></el-icon>
                导入
              </el-button>
            </div>
            <div class="toolbar-right">
              <el-button @click="exportDomains('csv')" class="export-btn">
                <el-icon><Document /></el-icon>
                导出 CSV
              </el-button>
              <el-button @click="exportDomains('xlsx')" class="export-btn">
                <el-icon><Document /></el-icon>
                导出 Excel
              </el-button>
              <el-button
                type="warning"
                v-permission="'domain_monitor:manage'"
                :loading="checkAllLoading"
                @click="checkAllDomains"
                class="check-all-btn"
              >
                <el-icon><VideoPlay /></el-icon>
                一键检测全部
              </el-button>
            </div>
          </div>
        </el-card>

        <el-card shadow="hover" class="table-card" v-loading="loading">
          <el-table
            ref="domainTableRef"
            :data="domains"
            stripe
            row-key="id"
            @selection-change="onDomainSelectionChange"
            class="modern-table"
            :header-cell-style="headerCellStyle"
          >
            <el-table-column type="selection" width="48" reserve-selection />
            <el-table-column prop="domain" label="域名" min-width="180">
              <template #default="{ row }">
                <div class="domain-cell">
                  <span class="domain-name">{{ row.domain }}</span>
                  <el-tag v-if="row.enabled" size="small" type="success" effect="plain">启用</el-tag>
                  <el-tag v-else size="small" type="info" effect="plain">禁用</el-tag>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="健康" width="120" align="center">
              <template #default="{ row }">
                <el-tag :type="healthLevelTagType(row.healthLevel)" size="small" effect="dark" class="health-tag">
                  {{ healthLevelLabel(row.healthLevel) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="可达率" width="80" align="center">
              <template #default="{ row }">
                <span class="reachability" :class="getReachabilityClass(row.reachabilityPct)">
                  {{ row.reachabilityPct != null ? row.reachabilityPct.toFixed(0) + "%" : "-" }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="分组" width="80">
              <template #default="{ row }">
                <span class="group-name">{{ row.group?.name || '-' }}</span>
              </template>
            </el-table-column>
            <el-table-column label="DNS" width="90" align="center">
              <template #default="{ row }">
                <span class="status-badge" :class="getStatusClass(row.lastDnsStatus)">
                  <span class="status-dot" :class="getStatusClass(row.lastDnsStatus)"></span>
                  {{ statusLabel(row.lastDnsStatus) }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="HTTP" width="90" align="center">
              <template #default="{ row }">
                <span class="status-badge" :class="getStatusClass(row.lastHttpStatus)">
                  <span class="status-dot" :class="getStatusClass(row.lastHttpStatus)"></span>
                  {{ statusLabel(row.lastHttpStatus) }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="响应时间" width="100" align="center">
              <template #default="{ row }">
                <span class="response-time" :class="getResponseTimeClass(row.lastHttpDurationMs)">
                  {{ formatDurationMs(row.lastHttpDurationMs) }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="SSL" width="100" align="center">
              <template #default="{ row }">
                <span class="status-badge" :class="getStatusClass(row.lastSslStatus)">
                  <span class="status-dot" :class="getStatusClass(row.lastSslStatus)"></span>
                  {{ statusLabel(row.lastSslStatus) }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="WHOIS" width="100" align="center">
              <template #default="{ row }">
                <span v-if="row.enableWhois" class="status-badge" :class="getStatusClass(row.lastWhoisStatus || 'unknown')">
                  <span class="status-dot" :class="getStatusClass(row.lastWhoisStatus || 'unknown')"></span>
                  {{ statusLabel(row.lastWhoisStatus || "unknown") }}
                </span>
                <span v-else class="muted">-</span>
              </template>
            </el-table-column>
           
            <el-table-column label="间隔" width="90" align="center">
              <template #default="{ row }">
                <span class="interval">{{ formatInterval(row.checkInterval) }}</span>
              </template>
            </el-table-column>
            <el-table-column label="上次检测" width="150">
              <template #default="{ row }">
                <span class="last-check">{{ formatDateTime(row.lastCheckAt) }}</span>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="260" fixed="right" align="center">
              <template #default="{ row }">
                <div class="action-buttons">
                  <el-button link type="primary" size="small" @click="goDetail(row.id)" class="action-btn detail-btn">
                    <el-icon><InfoFilled /></el-icon>
                    详情
                  </el-button>
                  <el-button
                    link
                    type="primary"
                    size="small"
                    v-permission="'domain_monitor:manage'"
                    :loading="!!checkingIds[row.id]"
                    :disabled="!!checkingIds[row.id]"
                    @click="checkNow(row)"
                    class="action-btn check-btn"
                  >
                    <el-icon><VideoPlay /></el-icon>
                    检测
                  </el-button>
                  <el-button
                    link
                    type="primary"
                    size="small"
                    v-permission="'domain_monitor:manage'"
                    @click="openDomainDialog(row)"
                    class="action-btn edit-btn"
                  >
                    <el-icon><Edit /></el-icon>
                    编辑
                  </el-button>
                  <el-button
                    link
                    type="danger"
                    size="small"
                    v-permission="'domain_monitor:manage'"
                    @click="removeDomain(row)"
                    class="action-btn delete-btn"
                  >
                    <el-icon><Delete /></el-icon>
                  </el-button>
                </div>
              </template>
            </el-table-column>
          </el-table>

          <div class="pagination">
            <el-pagination
              v-model:current-page="pagination.page"
              v-model:page-size="pagination.pageSize"
              :total="pagination.total"
              :page-sizes="[10, 20, 50, 100]"
              layout="total, sizes, prev, pager, next, jumper"
              background
              @size-change="loadDomains"
              @current-change="loadDomains"
            />
          </div>
        </el-card>
      </el-tab-pane>

      <!-- ===== 分组管理 Tab ===== -->
      <el-tab-pane label="分组管理" name="groups">
        <template #label>
          <span class="tab-label">
            <el-icon><Folder /></el-icon>
            分组管理
            <el-badge :value="groups.length" :hidden="groups.length === 0" class="tab-badge" />
          </span>
        </template>

        <el-card shadow="hover" class="table-card">
          <div class="toolbar">
            <el-button
              type="primary"
              v-permission="'domain_monitor:manage'"
              @click="openGroupDialog()"
              class="add-btn"
            >
              <el-icon><Plus /></el-icon>
              新增分组
            </el-button>
          </div>

          <el-table :data="groups" stripe v-loading="groupLoading" class="modern-table" :header-cell-style="headerCellStyle">
            <el-table-column prop="name" label="名称" min-width="160">
              <template #default="{ row }">
                <div class="group-cell">
                  <span class="group-name">{{ row.name }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="description" label="描述" min-width="200">
              <template #default="{ row }">
                <span class="group-desc">{{ row.description || '-' }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="sortOrder" label="排序" width="100" align="center">
              <template #default="{ row }">
                <span class="sort-order">{{ row.sortOrder }}</span>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="160" align="center">
              <template #default="{ row }">
                <div class="action-buttons">
                  <el-button
                    link
                    type="primary"
                    size="small"
                    v-permission="'domain_monitor:manage'"
                    @click="openGroupDialog(row)"
                    class="action-btn edit-btn"
                  >
                    <el-icon><Edit /></el-icon>
                    编辑
                  </el-button>
                  <el-button
                    link
                    type="danger"
                    size="small"
                    v-permission="'domain_monitor:manage'"
                    @click="removeGroup(row)"
                    class="action-btn delete-btn"
                  >
                    <el-icon><Delete /></el-icon>
                  </el-button>
                </div>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-tab-pane>
    </el-tabs>

    <!-- ===== 域名表单对话框 ===== -->
    <el-dialog
      v-model="domainDialogVisible"
      :title="domainForm.id ? '编辑域名' : '新增域名'"
      width="600px"
      class="modern-dialog"
      destroy-on-close
    >
      <el-form :model="domainForm" label-width="110px" class="dialog-form">
        <el-form-item label="域名" required>
          <el-input v-model="domainForm.domain" placeholder="example.com" size="large" />
        </el-form-item>
        <el-form-item label="分组">
          <el-select v-model="domainForm.groupId" clearable placeholder="无" size="large" style="width: 100%">
            <el-option v-for="g in groups" :key="g.id" :label="g.name" :value="g.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="检测间隔">
          <el-input-number v-model="domainForm.checkInterval" :min="60" :step="60" size="large" />
          <span class="form-tip">秒（默认 {{ formatInterval(defaultCheckInterval) }}）</span>
        </el-form-item>
        <el-form-item label="自动检测">
          <el-switch v-model="domainForm.enabled" size="large" />
          <span class="form-tip">启用后按检测间隔参与后台自动检测</span>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="domainForm.remark" type="textarea" :rows="2" placeholder="请输入备注信息" />
        </el-form-item>

        <el-divider content-position="left">
          <span class="divider-label"><el-icon><Check /></el-icon> 检测项</span>
        </el-divider>
        <el-form-item label=" " class="check-item-group">
          <div class="check-grid">
            <el-checkbox
              v-for="item in checkItems"
              :key="item.key"
              v-model="domainForm[item.key as keyof typeof domainForm]"
              size="large"
            >
              <span class="check-label">{{ item.label }}</span>
              <span v-if="item.desc" class="check-desc">{{ item.desc }}</span>
            </el-checkbox>
          </div>
        </el-form-item>

        <el-divider content-position="left">
          <span class="divider-label"><el-icon><Connection /></el-icon> 检测模式</span>
        </el-divider>
        <el-form-item label="总开关" class="mode-switch-group">
          <el-checkbox v-model="domainForm.enableProbeDetection">Probe 检测</el-checkbox>
          <el-checkbox v-model="domainForm.enableProxyDetection">Proxy 检测</el-checkbox>
          <el-checkbox v-model="domainForm.enableUserSimulation">用户模拟</el-checkbox>
        </el-form-item>
        <el-form-item label="Probe 节点">
          <el-radio-group v-model="domainForm.probeNodeScope" size="large">
            <el-radio value="all">全部在线节点</el-radio>
            <el-radio value="selected">指定节点</el-radio>
          </el-radio-group>
          <el-select
            v-if="domainForm.probeNodeScope === 'selected'"
            v-model="domainForm.probeNodeIds"
            multiple
            filterable
            placeholder="选择 Probe 节点"
            style="width: 100%; margin-top: 8px"
            size="large"
          >
            <el-option v-for="n in probeNodes" :key="n.id" :label="`${n.name} (${n.country})`" :value="n.id" />
          </el-select>
        </el-form-item>

        <el-form-item label="分项策略">
          <div class="strategy-grid">
            <div v-for="row in strategyRows" :key="row.key" class="strategy-row">
              <span class="strategy-label">{{ row.label }}</span>
              <el-select v-model="domainForm.checkStrategy[row.key]" size="large" style="width: 130px">
                <el-option v-for="o in CHECK_MODE_OPTIONS" :key="o.value" :label="o.label" :value="o.value" />
              </el-select>
            </div>
          </div>
          <p class="form-tip">local=中心直连；proxy=中心走全局代理；probe=远程 Probe 本机检测</p>
        </el-form-item>

        <el-divider content-position="left">
          <span class="divider-label"><el-icon><Lock /></el-icon> DNS 预期（劫持检测）</span>
        </el-divider>
        <el-form-item label="预期 IP">
          <el-select
            v-model="domainForm.expectedIps"
            multiple
            filterable
            allow-create
            default-first-option
            placeholder="如 1.2.3.4"
            style="width: 100%"
            size="large"
          />
        </el-form-item>
        <el-form-item label="预期 ASN">
          <el-input v-model="domainForm.expectedAsn" placeholder="如 13335（Cloudflare）" size="large" />
        </el-form-item>
        <el-form-item label="预期 CDN">
          <el-select v-model="domainForm.expectedCdn" clearable placeholder="可选" style="width: 100%" size="large">
            <el-option label="Cloudflare" value="Cloudflare" />
            <el-option label="Fastly" value="Fastly" />
            <el-option label="AWS" value="AWS" />
            <el-option label="Akamai" value="Akamai" />
          </el-select>
        </el-form-item>

        <template v-if="domainForm.enableScreenshot">
          <el-form-item label="截图 URL">
            <el-input v-model="domainForm.screenshotUrl" placeholder="留空则使用 https://域名" size="large" />
          </el-form-item>
        </template>

        <template v-if="domainForm.enableContent">
          <el-form-item label="检测 URL">
            <el-input v-model="domainForm.contentUrl" placeholder="留空则使用 https://域名" size="large" />
          </el-form-item>
          <el-form-item label="关键词">
            <el-select
              v-model="domainForm.contentKeywords"
              multiple
              filterable
              allow-create
              default-first-option
              placeholder="页面需包含的关键词（可选）"
              style="width: 100%"
              size="large"
            />
          </el-form-item>
        </template>
      </el-form>
      <template #footer>
        <el-button @click="domainDialogVisible = false" size="large">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submitDomain" size="large" class="submit-btn">
          <el-icon><Check /></el-icon>
          {{ domainForm.id ? '更新' : '创建' }}
        </el-button>
      </template>
    </el-dialog>

    <!-- ===== 分组表单对话框 ===== -->
    <el-dialog
      v-model="groupDialogVisible"
      :title="groupForm.id ? '编辑分组' : '新增分组'"
      width="480px"
      class="modern-dialog"
    >
      <el-form :model="groupForm" label-width="80px" class="dialog-form">
        <el-form-item label="名称" required>
          <el-input v-model="groupForm.name" placeholder="请输入分组名称" size="large" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="groupForm.description" type="textarea" :rows="2" placeholder="请输入分组描述" />
        </el-form-item>
        <el-form-item label="排序">
          <el-input-number v-model="groupForm.sortOrder" :min="0" size="large" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="groupDialogVisible = false" size="large">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submitGroup" size="large">
          <el-icon><Check /></el-icon>
          确定
        </el-button>
      </template>
    </el-dialog>

    <!-- ===== 批量检测进度对话框 ===== -->
    <el-dialog
      v-model="batchDialogVisible"
      title="批量检测"
      :width="batchProgress.failures.length > 0 ? '600px' : '460px'"
      align-center
      :close-on-click-modal="false"
      :show-close="!batchProgress.running"
      :before-close="onBatchDialogClose"
      class="modern-dialog batch-dialog"
    >
      <div class="batch-dialog-body">
        <div class="batch-status-icon" :class="{ running: batchProgress.running, done: !batchProgress.running }">
          <el-icon v-if="batchProgress.running"><Loading /></el-icon>
          <el-icon v-else><CircleCheck /></el-icon>
        </div>
        <p class="batch-dialog-tip">
          {{ batchProgress.running ? '正在检测全部域名，请勿关闭窗口…' : '全部域名检测已完成' }}
        </p>
        <el-progress
          :percentage="batchProgressPercent"
          :status="batchProgress.running ? undefined : 'success'"
          :stroke-width="12"
          striped
          striped-flow
        />
        <p class="batch-dialog-meta">
          进度 {{ batchProgress.completed }} / {{ batchProgress.total }}
          <span v-if="batchProgress.failed > 0" class="batch-failed">
            · 异常 {{ batchProgress.failed }}
          </span>
          <span v-else-if="!batchProgress.running && batchProgress.total > 0" class="batch-success">
            · 全部正常
          </span>
        </p>
        <div v-if="!batchProgress.running && batchProgress.failures.length > 0" class="batch-failures">
          <p class="batch-failures-title">异常域名及原因</p>
          <el-table :data="batchProgress.failures" size="small" max-height="280" stripe>
            <el-table-column prop="domain" label="域名" min-width="160" />
            <el-table-column prop="reason" label="原因" min-width="200" />
          </el-table>
        </div>
      </div>
      <template #footer>
        <el-button v-if="!batchProgress.running" type="primary" size="large" @click="batchDialogVisible = false">
          知道了
        </el-button>
      </template>
    </el-dialog>

    <!-- ===== 导入对话框 ===== -->
    <el-dialog
      v-model="importVisible"
      title="导入域名"
      width="520px"
      @closed="resetImportUpload"
      class="modern-dialog"
    >
      <el-upload
        ref="importUploadRef"
        drag
        :auto-upload="false"
        :limit="1"
        accept=".csv,.xlsx,.xls"
        :on-change="onImportFile"
        :on-remove="onImportRemove"
        :on-exceed="handleImportExceed"
        class="import-upload"
      >
        <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
        <div class="el-upload__text">拖拽或点击选择 CSV / XLSX / XLS</div>
        <template #tip>
          <div class="el-upload__tip">支持 .csv, .xlsx, .xls 格式</div>
        </template>
      </el-upload>
      <el-form label-width="88px" class="import-form">
        <el-form-item label="导入分组">
          <el-select
            v-model="importGroupId"
            clearable
            placeholder="不指定则使用文件中的分组列"
            style="width: 100%"
            size="large"
          >
            <el-option v-for="g in groups" :key="g.id" :label="g.name" :value="g.id" />
          </el-select>
        </el-form-item>
      </el-form>
      <p class="import-hint">
        <el-icon><InfoFilled /></el-icon>
        检测间隔将使用当前配置值（{{ formatInterval(defaultCheckInterval) }}）；默认开启 DNS、HTTP、SSL、WHOIS
      </p>
      <template #footer>
        <el-button @click="closeImportDialog" size="large">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="doImport" size="large">
          <el-icon><Upload /></el-icon>
          开始导入
        </el-button>
      </template>
    </el-dialog>

    <!-- ===== 批量编辑对话框 ===== -->
    <el-dialog
      v-model="batchEditVisible"
      :title="`批量编辑 (${selectedDomains.length} 个域名)`"
      width="560px"
      class="modern-dialog"
    >
      <el-alert type="info" :closable="false" show-icon class="batch-tip" title="仅勾选需要修改的项，未勾选项保持原值不变" />
      <el-form :model="batchForm" label-width="108px" class="batch-form">
        <el-form-item>
          <el-checkbox v-model="batchForm.updateGroup" size="large">修改分组</el-checkbox>
        </el-form-item>
        <el-form-item v-if="batchForm.updateGroup" label="目标分组">
          <el-radio-group v-model="batchForm.groupAction" size="large">
            <el-radio value="set">指定分组</el-radio>
            <el-radio value="clear">清除分组</el-radio>
          </el-radio-group>
          <el-select
            v-if="batchForm.groupAction === 'set'"
            v-model="batchForm.groupId"
            placeholder="选择分组"
            style="width: 100%; margin-top: 8px"
            size="large"
          >
            <el-option v-for="g in groups" :key="g.id" :label="g.name" :value="g.id" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-checkbox v-model="batchForm.updateEnabled" size="large">修改启用状态</el-checkbox>
        </el-form-item>
        <el-form-item v-if="batchForm.updateEnabled" label="启用">
          <el-switch v-model="batchForm.enabled" size="large" />
        </el-form-item>

        <el-form-item>
          <el-checkbox v-model="batchForm.updateCheckInterval" size="large">修改检测间隔</el-checkbox>
        </el-form-item>
        <el-form-item v-if="batchForm.updateCheckInterval" label="检测间隔">
          <el-radio-group v-model="batchForm.intervalMode" size="large">
            <el-radio value="config">使用配置值（{{ formatInterval(defaultCheckInterval) }}）</el-radio>
            <el-radio value="custom">自定义</el-radio>
          </el-radio-group>
          <el-input-number
            v-if="batchForm.intervalMode === 'custom'"
            v-model="batchForm.checkInterval"
            :min="60"
            :step="60"
            style="margin-top: 8px"
            size="large"
          />
        </el-form-item>

        <el-form-item>
          <el-checkbox v-model="batchForm.updateChecks" size="large">修改检测项</el-checkbox>
        </el-form-item>
        <el-form-item v-if="batchForm.updateChecks" label="检测项">
          <div class="batch-check-grid">
            <el-checkbox
              v-for="item in batchCheckItems"
              :key="item.key"
              v-model="batchForm[item.key as keyof typeof batchForm]"
              size="large"
            >
              {{ item.label }}
            </el-checkbox>
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="batchEditVisible = false" size="large">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submitBatchEdit" size="large">
          <el-icon><Check /></el-icon>
          应用
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, onUnmounted, computed } from "vue";
import { useRouter } from "vue-router";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Plus,
  UploadFilled,
  VideoPlay,
  Search,
  RefreshLeft,
  Edit,
  Upload,
  Document,
  Delete,
  InfoFilled,
  Monitor,
  Folder,
  Check,
  Connection,
  Lock,
  Loading,
  CircleCheck,
} from "@element-plus/icons-vue";
import type { UploadFile, UploadInstance, UploadRawFile, TableInstance } from "element-plus";
import domainMonitorApi, {
  type DmDomain,
  type DmGroup,
  type DmNode,
  type DmBatchFailureItem,
} from "@api/domain_monitor_api";
import {
  statusTagType,
  statusLabel,
  formatDateTime,
  formatInterval,
  formatDurationMs,
  downloadBlob,
  parseStringArray,
  pollCheckBatch,
  waitDomainCheckDone,
  validateDomainName,
  parseJsonField,
  healthLevelLabel,
  healthLevelTagType,
} from "./helpers";

const CHECK_MODE_OPTIONS = [
  { value: "", label: "默认" },
  { value: "local", label: "Local" },
  { value: "proxy", label: "Proxy" },
  { value: "probe", label: "Probe" },
];

const strategyRows = [
  { key: "dns", label: "DNS" },
  { key: "http", label: "HTTP" },
  { key: "ssl", label: "SSL" },
  { key: "whois", label: "WHOIS" },
  { key: "content", label: "内容" },
  { key: "screenshot", label: "截图" },
  { key: "userSimulation", label: "用户模拟" },
];

const checkItems = [
  { key: "enableDns", label: "DNS", desc: "域名解析检测" },
  { key: "enableHttp", label: "HTTP", desc: "网站可达性" },
  { key: "enableSsl", label: "SSL", desc: "证书有效性" },
  { key: "enableWhois", label: "WHOIS", desc: "域名注册信息" },
  { key: "enableContent", label: "内容哈希", desc: "页面内容变更" },
  { key: "enableScreenshot", label: "页面截图", desc: "页面快照" },
  { key: "enableBlacklist", label: "DNS 黑名单", desc: "黑名单检测" },
];

const batchCheckItems = [
  { key: "enableDns", label: "DNS" },
  { key: "enableHttp", label: "HTTP" },
  { key: "enableSsl", label: "SSL" },
  { key: "enableWhois", label: "WHOIS" },
  { key: "enableContent", label: "内容哈希" },
];

const router = useRouter();
const activeTab = ref("domains");
const loading = ref(false);
const groupLoading = ref(false);
const submitting = ref(false);
const pollingAbort = new AbortController();
const checkAllLoading = ref(false);
const batchDialogVisible = ref(false);
const checkingIds = reactive<Record<string, boolean>>({});
const batchProgress = reactive({
  running: false,
  total: 0,
  completed: 0,
  failed: 0,
  failures: [] as DmBatchFailureItem[],
});
const batchProgressPercent = computed(() => {
  if (!batchProgress.total) return 0;
  return Math.min(100, Math.round((batchProgress.completed / batchProgress.total) * 100));
});
const domains = ref<DmDomain[]>([]);
const groups = ref<DmGroup[]>([]);
const probeNodes = ref<DmNode[]>([]);
const importVisible = ref(false);
const importFile = ref<File | null>(null);
const importGroupId = ref("");
const importUploadRef = ref<UploadInstance>();
const batchEditVisible = ref(false);
const selectedDomains = ref<DmDomain[]>([]);
const domainTableRef = ref<TableInstance>();
const batchForm = reactive({
  updateGroup: false,
  groupAction: "set" as "set" | "clear",
  groupId: "",
  updateEnabled: false,
  enabled: true,
  updateCheckInterval: false,
  intervalMode: "config" as "config" | "custom",
  checkInterval: 300,
  updateChecks: false,
  enableDns: true,
  enableHttp: true,
  enableSsl: true,
  enableWhois: true,
  enableContent: false,
});

const filters = reactive({
  keyword: "",
  groupId: "",
  enabled: undefined as boolean | undefined,
});

const pagination = reactive({ page: 1, pageSize: 20, total: 0 });
const defaultCheckInterval = ref(300);

const domainDialogVisible = ref(false);
const domainForm = reactive({
  id: "",
  domain: "",
  groupId: "" as string | undefined,
  checkInterval: 300,
  remark: "",
  enabled: true,
  enableDns: true,
  enableHttp: true,
  enableSsl: true,
  enableWhois: false,
  enableContent: false,
  enableScreenshot: false,
  enableBlacklist: false,
  enableProbeDetection: false,
  enableProxyDetection: false,
  enableUserSimulation: false,
  checkStrategy: {} as Record<string, string>,
  probeNodeScope: "all" as "all" | "selected",
  probeNodeIds: [] as string[],
  expectedIps: [] as string[],
  expectedAsn: "",
  expectedCdn: "",
  contentUrl: "",
  screenshotUrl: "",
  contentKeywords: [] as string[],
});

const groupDialogVisible = ref(false);
const groupForm = reactive({
  id: "",
  name: "",
  description: "",
  sortOrder: 0,
});

const headerCellStyle = {
  background: "linear-gradient(135deg, #f8fafc 0%, #eef2f6 100%)",
  color: "#1e293b",
  fontWeight: "600",
  fontSize: "13px",
  borderBottom: "2px solid #e2e8f0",
};

function getStatusClass(status: string | null | undefined): string {
  const s = (status || "unknown").toLowerCase();
  if (s === "ok") return "ok";
  if (s === "warning") return "warning";
  if (s === "error") return "error";
  if (s === "critical") return "critical";
  return "unknown";
}

function getReachabilityClass(pct: number | null | undefined): string {
  if (pct == null) return "";
  if (pct >= 90) return "high";
  if (pct >= 70) return "medium";
  return "low";
}

function getResponseTimeClass(ms: number | null | undefined): string {
  if (ms == null) return "";
  if (ms < 500) return "fast";
  if (ms < 2000) return "medium";
  return "slow";
}

async function loadProbeNodes() {
  try {
    const { data } = await domainMonitorApi.listNodes();
    probeNodes.value = data || [];
  } catch {
    probeNodes.value = [];
  }
}

function resetCheckStrategy() {
  domainForm.checkStrategy = {};
  for (const row of strategyRows) {
    domainForm.checkStrategy[row.key] = "";
  }
}

function applyCheckStrategyFromRow(d?: DmDomain) {
  resetCheckStrategy();
  if (!d?.checkStrategy) return;
  const parsed = parseJsonField<Record<string, string>>(d.checkStrategy);
  if (parsed) {
    for (const item of strategyRows) {
      domainForm.checkStrategy[item.key] = parsed[item.key] || "";
    }
  }
}

function parseProbeNodeIds(raw?: string[] | string): string[] {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw;
  return parseStringArray(raw);
}

async function loadCheckDefaults() {
  try {
    const { data } = await domainMonitorApi.getCheckSettings();
    if (data?.defaultCheckInterval) {
      defaultCheckInterval.value = data.defaultCheckInterval;
    }
    await syncCheckIntervalsIfNeeded();
  } catch {
    /* keep fallback */
  }
}

async function syncCheckIntervalsIfNeeded() {
  try {
    const { data } = await domainMonitorApi.syncDomainCheckIntervals();
    if (data?.updated && data.updated > 0) {
      ElMessage.info(`已将 ${data.updated} 个域名的检测间隔同步为 ${formatInterval(data.defaultCheckInterval)}`);
    }
  } catch {
    /* ignore sync errors on load */
  }
}

function onDomainSelectionChange(rows: DmDomain[]) {
  selectedDomains.value = rows;
}

function clearDomainSelection() {
  domainTableRef.value?.clearSelection();
  selectedDomains.value = [];
}

function openImportDialog() {
  importGroupId.value = filters.groupId || "";
  importVisible.value = true;
}

function openBatchDialog() {
  if (!selectedDomains.value.length) {
    ElMessage.warning("请先选择要编辑的域名");
    return;
  }
  batchForm.updateGroup = false;
  batchForm.groupAction = "set";
  batchForm.groupId = filters.groupId || groups.value[0]?.id || "";
  batchForm.updateEnabled = false;
  batchForm.enabled = true;
  batchForm.updateCheckInterval = false;
  batchForm.intervalMode = "config";
  batchForm.checkInterval = defaultCheckInterval.value;
  batchForm.updateChecks = false;
  batchForm.enableDns = true;
  batchForm.enableHttp = true;
  batchForm.enableSsl = true;
  batchForm.enableWhois = true;
  batchForm.enableContent = false;
  batchEditVisible.value = true;
}

async function loadGroups() {
  groupLoading.value = true;
  try {
    const { data } = await domainMonitorApi.listGroups();
    groups.value = data || [];
  } catch (e: any) {
    ElMessage.error(e.message || "加载分组失败");
  } finally {
    groupLoading.value = false;
  }
}

async function loadDomains() {
  loading.value = true;
  try {
    const { data } = await domainMonitorApi.listDomains({
      page: pagination.page,
      pageSize: pagination.pageSize,
      keyword: filters.keyword || undefined,
      groupId: filters.groupId || undefined,
      enabled: filters.enabled,
    });
    domains.value = data?.items || [];
    pagination.total = data?.total || 0;
  } catch (e: any) {
    ElMessage.error(e.message || "加载域名失败");
  } finally {
    loading.value = false;
  }
}

function resetFilters() {
  filters.keyword = "";
  filters.groupId = "";
  filters.enabled = undefined;
  pagination.page = 1;
  loadDomains();
}

function goDetail(id: string) {
  router.push(`/domain-monitor/domains/${id}`);
}

function openDomainDialog(row?: DmDomain) {
  if (row) {
    domainForm.id = row.id;
    domainForm.domain = row.domain;
    domainForm.groupId = row.groupId || undefined;
    domainForm.checkInterval = row.checkInterval;
    domainForm.remark = row.remark || "";
    domainForm.enabled = row.enabled;
    domainForm.enableDns = row.enableDns;
    domainForm.enableHttp = row.enableHttp;
    domainForm.enableSsl = row.enableSsl;
    domainForm.enableWhois = !!row.enableWhois;
    domainForm.enableContent = !!row.enableContent;
    domainForm.enableScreenshot = !!row.enableScreenshot;
    domainForm.enableBlacklist = !!row.enableBlacklist;
    domainForm.enableProbeDetection = !!row.enableProbeDetection;
    domainForm.enableProxyDetection = !!row.enableProxyDetection;
    domainForm.enableUserSimulation = !!row.enableUserSimulation;
    domainForm.probeNodeScope = (row.probeNodeScope as "all" | "selected") || "all";
    domainForm.probeNodeIds = parseProbeNodeIds(row.probeNodeIds);
    domainForm.expectedIps = parseStringArray(row.expectedIps);
    domainForm.expectedAsn = row.expectedAsn || "";
    domainForm.expectedCdn = row.expectedCdn || "";
    applyCheckStrategyFromRow(row);
    domainForm.contentUrl = row.contentUrl || "";
    domainForm.screenshotUrl = row.screenshotUrl || "";
    domainForm.contentKeywords = parseStringArray(row.contentKeywords);
  } else {
    domainForm.id = "";
    domainForm.domain = "";
    domainForm.groupId = undefined;
    domainForm.checkInterval = defaultCheckInterval.value;
    domainForm.remark = "";
    domainForm.enabled = true;
    domainForm.enableDns = true;
    domainForm.enableHttp = true;
    domainForm.enableSsl = true;
    domainForm.enableWhois = false;
    domainForm.enableContent = false;
    domainForm.enableScreenshot = false;
    domainForm.enableBlacklist = false;
    domainForm.enableProbeDetection = false;
    domainForm.enableProxyDetection = false;
    domainForm.enableUserSimulation = false;
    domainForm.probeNodeScope = "all";
    domainForm.probeNodeIds = [];
    domainForm.expectedIps = [];
    domainForm.expectedAsn = "";
    domainForm.expectedCdn = "";
    resetCheckStrategy();
    domainForm.contentUrl = "";
    domainForm.screenshotUrl = "";
    domainForm.contentKeywords = [];
  }
  domainDialogVisible.value = true;
}

async function submitDomain() {
  const domainErr = validateDomainName(domainForm.domain);
  if (domainErr) {
    ElMessage.warning(domainErr);
    return;
  }
  submitting.value = true;
  try {
    const payload = {
      domain: domainForm.domain.trim(),
      groupId: domainForm.groupId || null,
      checkInterval: domainForm.checkInterval,
      remark: domainForm.remark,
      enabled: domainForm.enabled,
      enableDns: domainForm.enableDns,
      enableHttp: domainForm.enableHttp,
      enableSsl: domainForm.enableSsl,
      enableWhois: domainForm.enableWhois,
      enableContent: domainForm.enableContent,
      enableScreenshot: domainForm.enableScreenshot,
      enableBlacklist: domainForm.enableBlacklist,
      enableProbeDetection: domainForm.enableProbeDetection,
      enableProxyDetection: domainForm.enableProxyDetection,
      enableUserSimulation: domainForm.enableUserSimulation,
      checkStrategy: Object.fromEntries(Object.entries(domainForm.checkStrategy).filter(([, v]) => v)),
      probeNodeScope: domainForm.probeNodeScope,
      probeNodeIds: domainForm.probeNodeScope === "selected" ? domainForm.probeNodeIds : [],
      expectedIps: domainForm.expectedIps,
      expectedAsn: domainForm.expectedAsn.trim(),
      expectedCdn: domainForm.expectedCdn,
      contentUrl: domainForm.contentUrl,
      screenshotUrl: domainForm.screenshotUrl,
      contentKeywords: domainForm.contentKeywords,
    };
    if (domainForm.id) {
      await domainMonitorApi.updateDomain(domainForm.id, payload);
      ElMessage.success("更新成功");
    } else {
      await domainMonitorApi.createDomain(payload);
      ElMessage.success("创建成功");
    }
    domainDialogVisible.value = false;
    loadDomains();
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    submitting.value = false;
  }
}

async function removeDomain(row: DmDomain) {
  try {
    await ElMessageBox.confirm(`确定删除域名 ${row.domain}？`, "确认", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    });
    await domainMonitorApi.deleteDomain(row.id);
    ElMessage.success("已删除");
    loadDomains();
  } catch {
    /* cancelled */
  }
}

async function checkNow(row: DmDomain) {
  if (checkingIds[row.id]) return;
  checkingIds[row.id] = true;
  const prevCheckAt = row.lastCheckAt;
  try {
    await domainMonitorApi.checkDomainNow(row.id);
    const updated = await waitDomainCheckDone(row.id, prevCheckAt, 120000, pollingAbort.signal);
    if (updated) {
      const idx = domains.value.findIndex((d) => d.id === row.id);
      if (idx >= 0) {
        domains.value[idx] = {
          ...domains.value[idx],
          ...updated,
          group: domains.value[idx].group ?? updated.group,
        };
      }
      ElMessage.success(`${row.domain} 检测完成`);
    } else {
      await loadDomains();
      await ElMessageBox.alert(`域名 ${row.domain} 在 120 秒内未完成检测，请稍后刷新列表查看结果。`, "检测超时", {
        type: "warning",
        confirmButtonText: "知道了",
      });
    }
  } catch (e: any) {
    ElMessage.error(e.message || "操作失败");
  } finally {
    delete checkingIds[row.id];
  }
}

function onBatchDialogClose(done: () => void) {
  if (batchProgress.running) return;
  done();
}

async function checkAllDomains() {
  try {
    await ElMessageBox.confirm("将对所有已启用的域名发起立即检测（含探针节点任务），是否继续？", "一键检测全部", {
      type: "warning",
      confirmButtonText: "确定",
      cancelButtonText: "取消",
    });
    checkAllLoading.value = true;
    const { data } = await domainMonitorApi.checkAllDomains();
    const total = data?.total ?? data?.queued ?? 0;
    if (!data?.batchId || total === 0) {
      ElMessage.warning("没有可检测的已启用域名");
      return;
    }
    batchProgress.running = true;
    batchProgress.total = total;
    batchProgress.completed = 0;
    batchProgress.failed = 0;
    batchProgress.failures = [];
    batchDialogVisible.value = true;
    const finalStatus = await pollCheckBatch(data.batchId, (st) => {
      batchProgress.running = st.running;
      batchProgress.total = st.total;
      batchProgress.completed = st.completed;
      batchProgress.failed = st.failed;
      batchProgress.failures = st.failures ?? [];
    }, 1000, pollingAbort.signal);
    batchProgress.running = false;
    if (!finalStatus) return;
    await loadDomains();
    ElMessage.success(
      finalStatus.failed > 0
        ? `检测完成：${finalStatus.completed}/${finalStatus.total}，失败 ${finalStatus.failed}`
        : `检测完成：${finalStatus.completed}/${finalStatus.total}`,
    );
  } catch (e: any) {
    if (e !== "cancel") {
      ElMessage.error(e.message || "操作失败");
    }
    batchDialogVisible.value = false;
    batchProgress.running = false;
  } finally {
    checkAllLoading.value = false;
  }
}

async function exportDomains(format: "csv" | "xlsx") {
  try {
    const res = await domainMonitorApi.exportDomains(format);
    const blob = res.data as Blob;
    downloadBlob(blob, `domains.${format === "xlsx" ? "xlsx" : "csv"}`);
  } catch (e: any) {
    ElMessage.error(e.message || "导出失败");
  }
}

function resetImportUpload() {
  importFile.value = null;
  importGroupId.value = "";
  importUploadRef.value?.clearFiles();
}

function closeImportDialog() {
  importVisible.value = false;
}

function onImportFile(file: UploadFile) {
  importFile.value = file.raw || null;
}

function onImportRemove() {
  importFile.value = null;
}

function handleImportExceed(files: File[]) {
  importUploadRef.value?.clearFiles();
  const next = files[0];
  if (!next) return;
  importUploadRef.value?.handleStart(next as UploadRawFile);
  importFile.value = next;
}

async function doImport() {
  if (!importFile.value) {
    ElMessage.warning("请选择文件");
    return;
  }
  submitting.value = true;
  try {
    const fd = new FormData();
    fd.append("file", importFile.value);
    if (importGroupId.value) {
      fd.append("groupId", importGroupId.value);
    }
    const { data } = await domainMonitorApi.importDomains(fd);
    ElMessage.success(`导入完成：新增 ${data.created}，跳过 ${data.skipped}`);
    closeImportDialog();
    loadDomains();
    loadGroups();
  } catch (e: any) {
    ElMessage.error(e.message || "导入失败");
    resetImportUpload();
  } finally {
    submitting.value = false;
  }
}

async function submitBatchEdit() {
  if (!selectedDomains.value.length) {
    ElMessage.warning("请先选择要编辑的域名");
    return;
  }
  if (!batchForm.updateGroup && !batchForm.updateEnabled && !batchForm.updateCheckInterval && !batchForm.updateChecks) {
    ElMessage.warning("请至少勾选一项要修改的内容");
    return;
  }
  if (batchForm.updateGroup && batchForm.groupAction === "set" && !batchForm.groupId) {
    ElMessage.warning("请选择目标分组");
    return;
  }
  submitting.value = true;
  try {
    const patch: Record<string, unknown> = {};
    if (batchForm.updateGroup) {
      patch.updateGroup = true;
      if (batchForm.groupAction === "clear") {
        patch.clearGroup = true;
      } else {
        patch.groupId = batchForm.groupId;
      }
    }
    if (batchForm.updateEnabled) {
      patch.enabled = batchForm.enabled;
    }
    if (batchForm.updateCheckInterval) {
      if (batchForm.intervalMode === "config") {
        patch.syncCheckInterval = true;
      } else {
        patch.checkInterval = batchForm.checkInterval;
      }
    }
    if (batchForm.updateChecks) {
      patch.enableDns = batchForm.enableDns;
      patch.enableHttp = batchForm.enableHttp;
      patch.enableSsl = batchForm.enableSsl;
      patch.enableWhois = batchForm.enableWhois;
      patch.enableContent = batchForm.enableContent;
    }
    const { data } = await domainMonitorApi.batchUpdateDomains({
      ids: selectedDomains.value.map((d) => d.id),
      patch,
    });
    ElMessage.success(`已更新 ${data?.updated ?? 0} 个域名`);
    batchEditVisible.value = false;
    clearDomainSelection();
    loadDomains();
  } catch (e: any) {
    ElMessage.error(e.message || "批量编辑失败");
  } finally {
    submitting.value = false;
  }
}

function openGroupDialog(row?: DmGroup) {
  if (row) {
    groupForm.id = row.id;
    groupForm.name = row.name;
    groupForm.description = row.description || "";
    groupForm.sortOrder = row.sortOrder || 0;
  } else {
    groupForm.id = "";
    groupForm.name = "";
    groupForm.description = "";
    groupForm.sortOrder = 0;
  }
  groupDialogVisible.value = true;
}

async function submitGroup() {
  if (!groupForm.name.trim()) {
    ElMessage.warning("请输入分组名称");
    return;
  }
  submitting.value = true;
  try {
    const payload = {
      name: groupForm.name.trim(),
      description: groupForm.description,
      sortOrder: groupForm.sortOrder,
    };
    if (groupForm.id) {
      await domainMonitorApi.updateGroup(groupForm.id, payload);
    } else {
      await domainMonitorApi.createGroup(payload);
    }
    ElMessage.success("保存成功");
    groupDialogVisible.value = false;
    loadGroups();
  } catch (e: any) {
    ElMessage.error(e.message || "保存失败");
  } finally {
    submitting.value = false;
  }
}

async function removeGroup(row: DmGroup) {
  try {
    await ElMessageBox.confirm(`确定删除分组 ${row.name}？`, "确认", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    });
    await domainMonitorApi.deleteGroup(row.id);
    ElMessage.success("已删除");
    loadGroups();
  } catch {
    /* cancelled */
  }
}

onMounted(async () => {
  await loadCheckDefaults();
  loadGroups();
  loadProbeNodes();
  await loadDomains();
});

onUnmounted(() => {
  pollingAbort.abort();
});
</script>

<style scoped>
/* ========== 页面背景 ========== */
.dm-page {
  position: relative;
  padding: 4px;
  min-height: 100vh;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.3;
  animation: floatBlob 25s ease-in-out infinite;
}

.blob-1 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -150px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -200px;
  left: -150px;
  animation-delay: -8s;
}

.blob-3 {
  width: 300px;
  height: 300px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 20%;
  animation-delay: -16s;
}

@keyframes floatBlob {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(40px, -40px) scale(1.05); }
  66% { transform: translate(-30px, 30px) scale(0.95); }
}

/* ========== Tabs ========== */
.modern-tabs {
  position: relative;
  z-index: 1;
}

.modern-tabs :deep(.el-tabs__header) {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(12px);
  border-radius: 16px;
  padding: 6px 16px;
  margin-bottom: 20px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
}

.modern-tabs :deep(.el-tabs__item) {
  font-size: 14px;
  font-weight: 500;
  padding: 0 20px;
  height: 44px;
  line-height: 44px;
  transition: all 0.2s ease;
}

.modern-tabs :deep(.el-tabs__item.is-active) {
  color: #667eea;
}

.modern-tabs :deep(.el-tabs__active-bar) {
  background: linear-gradient(90deg, #667eea, #764ba2);
  height: 3px;
  border-radius: 2px;
}

.tab-label {
  display: flex;
  align-items: center;
  gap: 6px;
}

.tab-badge {
  margin-left: 4px;
}

.tab-badge :deep(.el-badge__content) {
  font-size: 10px;
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
}

/* ========== 筛选卡片 ========== */
.filter-card {
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
  margin-bottom: 16px;
  overflow: hidden;
}

.filter-card :deep(.el-card__body) {
  padding: 20px 24px;
}

.filter-form {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 12px 16px;
}

.filter-form .el-form-item {
  margin-bottom: 0;
}

.modern-input :deep(.el-input__wrapper) {
  border-radius: 10px;
  padding: 2px 14px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
}

.modern-input :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #667eea;
}

.modern-input :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

.modern-select :deep(.el-input__wrapper) {
  border-radius: 10px;
  padding: 2px 12px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  transition: all 0.2s ease;
}

.modern-select :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #667eea;
}

.modern-select :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

.search-btn,
.reset-btn {
  border-radius: 10px;
  padding: 10px 20px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.search-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.25);
}

.search-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35);
}

.reset-btn:hover {
  transform: translateY(-2px);
}

/* ========== 工具栏 ========== */
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 14px;
  padding-top: 14px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.toolbar-left,
.toolbar-right {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
}

.add-btn {
  border-radius: 10px;
  padding: 8px 20px;
  font-weight: 500;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.25);
  transition: all 0.2s ease;
}

.add-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35);
}

.batch-btn {
  border-radius: 10px;
  padding: 8px 16px;
  font-weight: 500;
  transition: all 0.2s ease;
  position: relative;
}

.batch-btn.has-selection {
  border-color: #667eea;
  color: #667eea;
}

.batch-btn.has-selection:hover {
  background: rgba(102, 126, 234, 0.08);
}

.selection-badge {
  margin-left: 4px;
}

.selection-badge :deep(.el-badge__content) {
  font-size: 10px;
  padding: 0 6px;
  height: 18px;
  line-height: 18px;
  background-color: #667eea;
}

.import-btn,
.export-btn {
  border-radius: 10px;
  padding: 8px 16px;
  font-weight: 500;
  transition: all 0.2s ease;
}

.import-btn:hover,
.export-btn:hover {
  transform: translateY(-2px);
}

.check-all-btn {
  border-radius: 10px;
  padding: 8px 18px;
  font-weight: 500;
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
  border: none;
  color: white;
  box-shadow: 0 4px 12px rgba(245, 87, 108, 0.25);
  transition: all 0.2s ease;
}

.check-all-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(245, 87, 108, 0.35);
  color: white;
}

/* ========== 表格卡片 ========== */
.table-card {
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
  overflow: hidden;
}

.table-card :deep(.el-card__body) {
  padding: 0;
}

.modern-table {
  width: 100%;
}

.modern-table :deep(.el-table__header th) {
  padding: 14px 0;
}

.modern-table :deep(.el-table__row td) {
  padding: 12px 0;
}

.modern-table :deep(.el-table__row) {
  transition: background 0.2s ease;
}

.modern-table :deep(.el-table__row:hover) {
  background: rgba(102, 126, 234, 0.04);
}

/* ========== 状态徽章样式 ========== */
.status-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status-badge.ok {
  background: #f0f9f0;
  color: #67c23a;
}

.status-badge.warning {
  background: #fdf6ec;
  color: #e6a23c;
}

.status-badge.error {
  background: #fef0f0;
  color: #f56c6c;
}

.status-badge.critical {
  background: #fde2e2;
  color: #f56c6c;
}

.status-badge.unknown {
  background: #f5f7fa;
  color: #909399;
}

.status-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  display: inline-block;
}

.status-dot.ok {
  background: #67c23a;
}

.status-dot.warning {
  background: #e6a23c;
}

.status-dot.error {
  background: #f56c6c;
}

.status-dot.critical {
  background: #f56c6c;
}

.status-dot.unknown {
  background: #909399;
}

/* ========== 表格单元格 ========== */
.domain-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.domain-name {
  font-weight: 600;
  color: #1a1a2e;
}

.health-tag {
  font-weight: 600;
}

.reachability {
  font-weight: 600;
}

.reachability.high {
  color: #67c23a;
}

.reachability.medium {
  color: #e6a23c;
}

.reachability.low {
  color: #f56c6c;
}

.group-name {
  color: #606266;
}

.response-time {
  font-weight: 500;
}

.response-time.fast {
  color: #67c23a;
}

.response-time.medium {
  color: #e6a23c;
}

.response-time.slow {
  color: #f56c6c;
}

.interval {
  font-weight: 500;
  color: #409eff;
}

.last-check {
  color: #909399;
  font-size: 13px;
}

.muted {
  color: #c0c4cc;
}

/* ========== 操作按钮 ========== */
.action-buttons {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
}

.action-btn {
  padding: 4px 8px;
  border-radius: 6px;
  transition: all 0.2s ease;
  font-size: 12px;
}

.action-btn:hover {
  transform: scale(1.05);
}

.action-btn .el-icon {
  font-size: 14px;
}

.detail-btn {
  color: #409eff;
}

.detail-btn:hover {
  background: rgba(64, 158, 255, 0.1);
}

.check-btn {
  color: #67c23a;
}

.check-btn:hover {
  background: rgba(103, 194, 58, 0.1);
}

.edit-btn {
  color: #409eff;
}

.edit-btn:hover {
  background: rgba(64, 158, 255, 0.1);
}

.delete-btn {
  color: #f56c6c;
  padding: 4px 6px;
}

.delete-btn:hover {
  background: rgba(245, 108, 108, 0.1);
}

/* ========== 分页 ========== */
.pagination {
  margin-top: 16px;
  padding: 16px 20px;
  display: flex;
  justify-content: flex-end;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.pagination :deep(.el-pagination.is-background .el-pager li:not(.is-disabled).is-active) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

/* ========== 分组管理 ========== */
.group-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.group-name {
  font-weight: 500;
  color: #1a1a2e;
}

.group-desc {
  color: #909399;
}

.sort-order {
  display: inline-block;
  padding: 2px 12px;
  background: #f5f7fa;
  border-radius: 10px;
  font-weight: 500;
  color: #606266;
}

/* ========== 对话框 ========== */
.modern-dialog :deep(.el-dialog) {
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
}

.modern-dialog :deep(.el-dialog__header) {
  padding: 20px 24px;
  margin: 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-bottom: none;
}

.modern-dialog :deep(.el-dialog__title) {
  color: white;
  font-size: 18px;
  font-weight: 600;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: white;
  font-size: 20px;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close:hover) {
  color: rgba(255, 255, 255, 0.7);
}

.modern-dialog :deep(.el-dialog__body) {
  padding: 24px;
}

.modern-dialog :deep(.el-dialog__footer) {
  padding: 16px 24px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.dialog-form .el-form-item {
  margin-bottom: 18px;
}

.form-tip {
  margin-left: 10px;
  color: #909399;
  font-size: 12px;
}

.divider-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-weight: 600;
  color: #303133;
}

.divider-label .el-icon {
  color: #667eea;
}

.check-item-group {
  margin-bottom: 8px;
}

.check-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 8px;
  width: 100%;
}

.check-grid :deep(.el-checkbox) {
  padding: 4px 0;
}

.check-label {
  font-weight: 500;
}

.check-desc {
  color: #909399;
  font-size: 12px;
  margin-left: 4px;
}

.mode-switch-group {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}

.mode-switch-group :deep(.el-checkbox) {
  font-weight: 500;
}

.strategy-grid {
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
}

.strategy-row {
  display: flex;
  align-items: center;
  gap: 12px;
}

.strategy-label {
  width: 72px;
  font-size: 13px;
  font-weight: 500;
  color: #606266;
}

.submit-btn {
  padding: 10px 32px;
  border-radius: 10px;
  font-weight: 600;
}

/* ========== 批量检测对话框 ========== */
.batch-dialog-body {
  padding: 8px 0 12px;
  text-align: center;
}

.batch-status-icon {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
  font-size: 32px;
}

.batch-status-icon.running {
  background: rgba(230, 162, 60, 0.15);
  color: #e6a23c;
  animation: spin 1.5s linear infinite;
}

.batch-status-icon.done {
  background: rgba(103, 194, 58, 0.15);
  color: #67c23a;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.batch-dialog-tip {
  margin: 0 0 16px;
  color: var(--el-text-color-regular);
  font-size: 15px;
  font-weight: 500;
}

.batch-dialog-meta {
  margin: 12px 0 0;
  font-size: 14px;
  color: var(--el-text-color-secondary);
}

.batch-failed {
  color: #f56c6c;
  font-weight: 600;
}

.batch-success {
  color: #67c23a;
  font-weight: 600;
}

.batch-failures {
  margin-top: 16px;
  text-align: left;
}

.batch-failures-title {
  margin: 0 0 8px;
  font-size: 13px;
  font-weight: 600;
  color: var(--el-text-color-regular);
}

/* ========== 导入对话框 ========== */
.import-upload :deep(.el-upload-dragger) {
  border-radius: 12px;
  padding: 32px 20px;
  border: 2px dashed #d9d9d9;
  transition: all 0.2s ease;
}

.import-upload :deep(.el-upload-dragger:hover) {
  border-color: #667eea;
  background: rgba(102, 126, 234, 0.04);
}

.import-hint {
  margin-top: 12px;
  padding: 10px 14px;
  background: #f0f7ff;
  border-radius: 8px;
  color: #409eff;
  font-size: 13px;
  display: flex;
  align-items: flex-start;
  gap: 8px;
  border: 1px solid rgba(64, 158, 255, 0.15);
}

.import-hint .el-icon {
  margin-top: 2px;
}

.import-form {
  margin-top: 16px;
}

/* ========== 批量编辑对话框 ========== */
.batch-tip {
  margin-bottom: 16px;
  border-radius: 10px;
}

.batch-form {
  margin-top: 4px;
}

.batch-check-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

/* ========== 响应式 ========== */
@media (max-width: 1024px) {
  .toolbar {
    flex-direction: column;
    align-items: stretch;
  }

  .toolbar-left,
  .toolbar-right {
    justify-content: center;
  }

  .filter-form {
    flex-direction: column;
    align-items: stretch;
  }

  .filter-form .el-form-item {
    width: 100%;
  }

  .filter-form .el-form-item .el-select,
  .filter-form .el-form-item .el-input {
    width: 100% !important;
  }

  .check-grid {
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  }
}

@media (max-width: 768px) {
  .filter-card :deep(.el-card__body) {
    padding: 16px;
  }

  .toolbar-left,
  .toolbar-right {
    flex-wrap: wrap;
  }

  .toolbar-left .el-button,
  .toolbar-right .el-button {
    flex: 1;
    min-width: 100px;
    justify-content: center;
  }

  .action-buttons {
    flex-wrap: wrap;
  }

  .modern-dialog :deep(.el-dialog) {
    width: 95% !important;
    margin: 20px auto !important;
  }

  .strategy-grid {
    gap: 6px;
  }

  .strategy-row {
    flex-wrap: wrap;
  }

  .strategy-label {
    width: 60px;
  }

  .batch-check-grid {
    flex-direction: column;
  }

  .pagination {
    overflow-x: auto;
  }

  .pagination :deep(.el-pagination) {
    flex-wrap: wrap;
    justify-content: center;
  }

  .mode-switch-group {
    flex-direction: column;
    gap: 8px;
  }
}

@media (max-width: 480px) {
  .filter-card :deep(.el-card__body) {
    padding: 12px;
  }

  .toolbar-left .el-button,
  .toolbar-right .el-button {
    flex: 1 1 100%;
    min-width: auto;
  }

  .domain-cell {
    flex-wrap: wrap;
  }

  .domain-name {
    font-size: 13px;
  }

  .health-tag {
    font-size: 11px;
  }
}
</style>
<template>
  <div class="payment-addresses-page">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <el-card class="toolbar-card" shadow="hover">
      <div class="toolbar">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索姓名、工号、部门、岗位、账号或地址"
          clearable
          :prefix-icon="Search"
          @input="handleSearch"
          style="width: 340px"
        />
        <el-button type="primary" @click="loadData">
          <el-icon><Refresh /></el-icon>
          刷新
        </el-button>
        <span class="toolbar-hint">点击姓名或操作列「查看」打开详情</span>
      </div>
    </el-card>

    <el-card class="table-card" shadow="hover">
      <el-table
        :data="items"
        v-loading="loading"
        stripe
        border
      >
        <el-table-column label="姓名" min-width="120">
          <template #default="{ row }">
            <span class="name-link" @click.stop="openDetail(row)">{{ row.employeeName }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="employeeCode" label="工号" width="120" />
        <el-table-column prop="department" label="部门" min-width="110">
          <template #default="{ row }">{{ row.department || "-" }}</template>
        </el-table-column>
        <el-table-column prop="position" label="岗位" min-width="110">
          <template #default="{ row }">{{ row.position || "-" }}</template>
        </el-table-column>
        <el-table-column label="工资状态" min-width="180">
          <template #default="{ row }">
            <div class="salary-status-cell">
              <span class="salary-month">{{ row.lastMonthLabel || "-" }}</span>
              <span class="salary-amount" v-if="row.lastMonthAmount != null">
                ¥{{ formatSalaryAmount(row.lastMonthAmount) }}
              </span>
              <span class="salary-amount pending-text" v-else-if="row.lastMonthStatus === 'pending'">
                应发
              </span>
              <el-tag
                size="small"
                :type="salaryStatusTagType(row.lastMonthStatus)"
              >
                {{ row.lastMonthStatusLabel || "-" }}
              </el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="绑定账号/地址" min-width="280">
          <template #default="{ row }">
            <div class="bound-list" v-if="row.boundAccounts?.length">
              <div
                v-for="(acc, idx) in row.boundAccounts"
                :key="idx"
                class="bound-item"
                :class="{ preferred: acc.isPreferred }"
              >
                <span class="bound-label">{{ acc.label }}</span>
                <span class="bound-value mono">{{ acc.display }}</span>
                <el-tag v-if="acc.isPreferred" size="small" type="success">默认</el-tag>
              </div>
            </div>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <el-table-column prop="updatedAt" label="更新时间" width="170">
          <template #default="{ row }">
            {{ row.updatedAt ? formatTime(row.updatedAt) : "-" }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="210" align="center" fixed="right">
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              size="small"
              @click.stop="openDetail(row)"
            >
              查看
            </el-button>
            <el-button
              link
              type="primary"
              size="small"
              v-permission="['salary:upload', 'salary:payment_address:view']"
              @click.stop="openProofUploadDialog(row)"
            >
              上传图片
            </el-button>
            <el-button
              link
              type="success"
              size="small"
              v-permission="'salary:upload'"
              :disabled="!row.lastMonthSalaryId || row.lastMonthStatus === 'paid'"
              @click.stop="markPaid(row)"
            >
              已发
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="page"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[20, 50, 100, 200]"
          layout="total, sizes, prev, pager, next"
          @size-change="loadData"
          @current-change="loadData"
        />
      </div>
    </el-card>

    <el-drawer
      v-model="detailVisible"
      :title="detailTitle"
      size="500px"
      destroy-on-close
    >
      <div v-if="selectedRow" class="detail-panel">
        <div class="employee-block">
          <el-avatar :size="56" :style="{ backgroundColor: getAvatarColor(selectedRow.employeeName) }">
            {{ selectedRow.employeeName?.charAt(0) }}
          </el-avatar>
          <div>
            <div class="employee-name">{{ selectedRow.employeeName }}</div>
            <div class="employee-meta">
              <el-tag size="small" type="info">{{ selectedRow.employeeCode || "无工号" }}</el-tag>
              <el-tag size="small" v-if="selectedRow.department">{{ selectedRow.department }}</el-tag>
              <el-tag size="small" v-if="selectedRow.position">{{ selectedRow.position }}</el-tag>
            </div>
          </div>
        </div>

        <div class="preferred-banner" v-if="selectedRow.preferredMethodLabel">
          默认收款方式：<strong>{{ selectedRow.preferredMethodLabel }}</strong>
        </div>

        <div class="salary-year-section">
          <div class="salary-year-header">
            <h4 class="block-title">{{ salaryYear }}年 工资明细</h4>
            <el-select v-model="salaryYear" size="small" style="width: 100px" @change="loadSalaryYear">
              <el-option v-for="y in salaryYearOptions" :key="y" :label="`${y}年`" :value="y" />
            </el-select>
          </div>
          <div v-loading="salaryYearLoading" class="salary-month-grid">
            <div
              v-for="item in salaryMonths"
              :key="item.yearMonth"
              class="salary-month-item"
              :class="item.status"
            >
              <div class="month-label">{{ item.monthLabel }}</div>
              <div class="month-amount" v-if="item.amount != null">
                ¥{{ formatSalaryAmount(item.amount) }}
              </div>
              <div class="month-amount empty" v-else>-</div>
              <el-tag size="small" :type="salaryStatusTagType(item.status)">
                {{ item.statusLabel }}
              </el-tag>
            </div>
          </div>
        </div>

        <template v-for="acc in selectedRow.boundAccounts || []" :key="acc.type">
          <div class="account-block" :class="{ preferred: acc.isPreferred }">
            <div class="account-block-header">
              <h4 class="block-title">{{ acc.label }}</h4>
              <el-tag v-if="acc.isPreferred" size="small" type="success">默认使用</el-tag>
            </div>
            <div class="info-list">
              <template v-if="acc.type === 'bank'">
                <div class="info-row">
                  <span class="label">收款人</span>
                  <span class="value">{{ selectedRow.accountHolder }}</span>
                </div>
                <div class="info-row">
                  <span class="label">开户行</span>
                  <span class="value">{{ selectedRow.bankName }}</span>
                </div>
                <div class="info-row">
                  <span class="label">银行账号</span>
                  <span class="value mono">{{ selectedRow.bankAccount }}</span>
                </div>
              </template>
              <template v-else-if="acc.type === 'usdt'">
                <div class="info-row">
                  <span class="label">网络</span>
                  <span class="value">{{ selectedRow.usdtNetwork || "-" }}</span>
                </div>
                <div class="info-row">
                  <span class="label">地址</span>
                  <span class="value mono">{{ selectedRow.usdtAddress }}</span>
                </div>
              </template>
              <template v-else>
                <div class="info-row">
                  <span class="label">类型</span>
                  <span class="value">{{ selectedRow.otherWalletType || "-" }}</span>
                </div>
                <div class="info-row">
                  <span class="label">地址/账号</span>
                  <span class="value mono">{{ selectedRow.otherWalletAddress }}</span>
                </div>
              </template>
            </div>
          </div>
        </template>

        <template v-if="selectedRow.remark">
          <h4 class="block-title">备注</h4>
          <p class="remark-text">{{ selectedRow.remark }}</p>
        </template>

        <div class="updated-at" v-if="selectedRow.updatedAt">
          最后更新：{{ formatTime(selectedRow.updatedAt) }}
        </div>
      </div>
    </el-drawer>

    <!-- 上传打款截图 -->
    <el-dialog
      v-model="proofUploadVisible"
      title="上传打款截图"
      width="520px"
      destroy-on-close
      @closed="clearProofPreview"
    >
      <el-alert
        v-if="proofUploadTarget"
        type="info"
        :closable="false"
        show-icon
        :title="`员工：${proofUploadTarget.employeeName}`"
        style="margin-bottom: 16px"
      />
      <el-form label-width="90px">
        <el-form-item label="工资月份" required>
          <el-date-picker
            v-model="proofUploadForm.yearMonth"
            type="month"
            placeholder="选择月份"
            format="YYYY年MM月"
            value-format="YYYY-MM"
            style="width: 100%"
            @change="onProofMonthChange"
          />
        </el-form-item>
        <el-form-item label="打款截图" required>
          <el-upload
            ref="proofUploadRef"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/gif,image/webp,image/bmp,.jpg,.jpeg,.png,.gif,.webp,.bmp"
            :on-change="handleProofFileChange"
            list-type="picture-card"
          >
            <el-icon><Plus /></el-icon>
          </el-upload>
          <div class="el-upload__tip">支持 JPG、PNG、GIF、WEBP、BMP，最大 10MB</div>
        </el-form-item>
        <el-form-item v-if="proofPreviewUrl" label="当前截图">
          <img :src="proofPreviewUrl" alt="打款截图" class="proof-preview-img" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="proofUploadVisible = false">取消</el-button>
        <el-button type="primary" :loading="proofUploading" @click="submitProofUpload">
          上传
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { Search, Refresh, Plus } from "@element-plus/icons-vue";
import adminApi from "@api/admin_api";

const loading = ref(false);
const proofUploading = ref(false);
const proofUploadVisible = ref(false);
const proofUploadTarget = ref<any>(null);
const proofUploadForm = ref({ yearMonth: "", file: null as File | null });
const proofUploadRef = ref();
const proofPreviewUrl = ref("");
const items = ref<any[]>([]);
const total = ref(0);
const page = ref(1);
const pageSize = ref(50);
const searchKeyword = ref("");
const detailVisible = ref(false);
const selectedRow = ref<any>(null);
const salaryYear = ref(new Date().getFullYear());
const salaryYearOptions = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);
const salaryMonths = ref<any[]>([]);
const salaryYearLoading = ref(false);
let searchTimer: ReturnType<typeof setTimeout> | null = null;

const detailTitle = computed(() =>
  selectedRow.value ? `${selectedRow.value.employeeName} · 收款信息` : "收款信息",
);

function formatTime(value: string) {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString("zh-CN", { hour12: false });
}

function getAvatarColor(name: string) {
  const colors = ["#667eea", "#764ba2", "#4facfe", "#43e97b", "#fa709a"];
  return colors[(name?.charCodeAt(0) || 0) % colors.length];
}

function formatSalaryAmount(value: number) {
  if (value === undefined || value === null) return "0";
  return Number(value).toLocaleString("zh-CN", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
}

function salaryStatusTagType(status: string) {
  if (status === "paid") return "success";
  if (status === "pending") return "warning";
  return "info";
}

async function loadSalaryYear() {
  if (!selectedRow.value?.employeeUuid) return;
  salaryYearLoading.value = true;
  try {
    const response = await adminApi.getPaymentAddressSalaryYear(
      selectedRow.value.employeeUuid,
      { year: salaryYear.value },
    );
    salaryMonths.value = response.data?.months || [];
  } catch (error: any) {
    ElMessage.error(error.message || "加载工资明细失败");
    salaryMonths.value = [];
  } finally {
    salaryYearLoading.value = false;
  }
}

function openDetail(row: any) {
  selectedRow.value = row;
  detailVisible.value = true;
  salaryYear.value = new Date().getFullYear();
  loadSalaryYear();
}

function getLastMonth() {
  const now = new Date();
  const d = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function openProofUploadDialog(row: any) {
  proofUploadTarget.value = row;
  proofUploadForm.value = {
    yearMonth: row.lastMonthYearMonth || getLastMonth(),
    file: null,
  };
  proofUploadVisible.value = true;
  if (proofUploadRef.value) proofUploadRef.value.clearFiles();
  loadExistingProofPreview(row.employeeUuid, proofUploadForm.value.yearMonth);
}

function handleProofFileChange(file: any) {
  proofUploadForm.value.file = file.raw;
}

function onProofMonthChange(month: string) {
  if (proofUploadTarget.value?.employeeUuid && month) {
    loadExistingProofPreview(proofUploadTarget.value.employeeUuid, month);
  }
}

function clearProofPreview() {
  if (proofPreviewUrl.value) {
    URL.revokeObjectURL(proofPreviewUrl.value);
    proofPreviewUrl.value = "";
  }
}

async function loadExistingProofPreview(employeeId: string, yearMonth: string) {
  clearProofPreview();
  if (!employeeId || !yearMonth) return;
  try {
    const res = await adminApi.getSalaryPaymentProof({ employeeId, yearMonth });
    const proof = res.data;
    if (proof?.id) {
      const blobRes = await adminApi.fetchSalaryPaymentProofFile(proof.id);
      proofPreviewUrl.value = URL.createObjectURL(blobRes.data as Blob);
    }
  } catch {
    /* ignore */
  }
}

async function submitProofUpload() {
  if (!proofUploadForm.value.yearMonth) {
    ElMessage.warning("请选择工资月份");
    return;
  }
  if (!proofUploadForm.value.file) {
    ElMessage.warning("请选择打款截图");
    return;
  }
  if (!proofUploadTarget.value?.employeeUuid) {
    ElMessage.warning("员工信息无效");
    return;
  }
  proofUploading.value = true;
  try {
    const formData = new FormData();
    formData.append("file", proofUploadForm.value.file);
    formData.append("employeeId", proofUploadTarget.value.employeeUuid);
    formData.append("yearMonth", proofUploadForm.value.yearMonth);
    await adminApi.uploadSalaryPaymentProof(formData);
    ElMessage.success("打款截图上传成功");
    proofUploadVisible.value = false;
    await loadData();
  } catch (error: any) {
    ElMessage.error(error.message || "上传失败");
  } finally {
    proofUploading.value = false;
  }
}

async function markPaid(row: any) {
  if (!row.lastMonthSalaryId && !row.employeeUuid) {
    ElMessage.warning("该月工资尚未上传，请先上传");
    return;
  }
  try {
    await ElMessageBox.confirm(
      `确认将 ${row.employeeName} ${row.lastMonthLabel} 工资标记为已发？`,
      "标记已发",
      { type: "warning", confirmButtonText: "确认", cancelButtonText: "取消" },
    );
    await adminApi.markSalaryPaid({
      id: row.lastMonthSalaryId || undefined,
      employeeId: row.employeeUuid,
      yearMonth: row.lastMonthYearMonth,
    });
    ElMessage.success("已标记为已发");
    await loadData();
    if (detailVisible.value && selectedRow.value?.employeeUuid === row.employeeUuid) {
      selectedRow.value = { ...row, lastMonthStatus: "paid", lastMonthStatusLabel: "已发" };
      loadSalaryYear();
    }
  } catch (error: any) {
    if (error !== "cancel") {
      ElMessage.error(error.message || "操作失败");
    }
  }
}

async function loadData() {
  loading.value = true;
  try {
    const response = await adminApi.listPaymentAddresses({
      skip: (page.value - 1) * pageSize.value,
      limit: pageSize.value,
      search: searchKeyword.value.trim() || undefined,
    });
    items.value = response.data?.items || [];
    total.value = response.data?.total || 0;
  } catch (error: any) {
    ElMessage.error(error.message || "加载收款地址失败");
  } finally {
    loading.value = false;
  }
}

function handleSearch() {
  if (searchTimer) clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    page.value = 1;
    loadData();
  }, 300);
}

onMounted(loadData);
</script>

<style scoped>
.payment-addresses-page {
  min-height: 100vh;
  padding: 20px;
  position: relative;
  background: #f0f2f6;
}

.bg-decoration {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.35;
}

.blob-1 {
  width: 420px;
  height: 420px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -120px;
  right: -80px;
}

.blob-2 {
  width: 520px;
  height: 520px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  bottom: -180px;
  left: -120px;
}

.blob-3 {
  width: 360px;
  height: 360px;
  background: linear-gradient(135deg, #43e97b, #38f9d7);
  top: 40%;
  left: 35%;
}

.toolbar-card,
.table-card {
  position: relative;
  z-index: 1;
  margin-bottom: 16px;
  border-radius: 16px;
}

.toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: center;
}

.toolbar-hint {
  color: #909399;
  font-size: 13px;
}

.name-link {
  color: #409eff;
  cursor: pointer;
  font-weight: 500;
}

.name-link:hover {
  text-decoration: underline;
}

.bound-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.bound-item {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  font-size: 13px;
}

.bound-item.preferred {
  color: #303133;
}

.bound-label {
  color: #909399;
  flex-shrink: 0;
}

.bound-value {
  word-break: break-all;
}

.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.pagination-wrapper {
  margin-top: 16px;
  display: flex;
  justify-content: flex-end;
}

.detail-panel {
  padding: 0 4px 24px;
}

.employee-block {
  display: flex;
  gap: 16px;
  align-items: center;
  padding-bottom: 20px;
  margin-bottom: 16px;
  border-bottom: 1px solid #ebeef5;
}

.employee-name {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
}

.employee-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.preferred-banner {
  margin-bottom: 16px;
  padding: 10px 12px;
  background: #f0f9eb;
  border-radius: 8px;
  color: #67c23a;
  font-size: 14px;
}

.account-block {
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ebeef5;
  border-radius: 10px;
}

.account-block.preferred {
  border-color: #b3e19d;
  background: #fafdf8;
}

.account-block-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}

.block-title {
  margin: 0;
  font-size: 15px;
  color: #606266;
}

.info-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.info-row {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  padding: 8px 10px;
  background: #f5f7fa;
  border-radius: 8px;
}

.info-row .label {
  color: #909399;
  flex-shrink: 0;
}

.info-row .value {
  color: #303133;
  font-weight: 500;
  text-align: right;
  word-break: break-all;
}

.remark-text {
  margin: 0 0 24px;
  padding: 12px;
  background: #f5f7fa;
  border-radius: 8px;
  color: #606266;
  line-height: 1.6;
}

.updated-at {
  font-size: 13px;
  color: #909399;
}

.salary-status-cell {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  font-size: 13px;
}

.salary-month {
  color: #606266;
  font-weight: 500;
}

.salary-amount {
  color: #303133;
  font-weight: 600;
}

.pending-text {
  color: #e6a23c;
}

.salary-year-section {
  margin-bottom: 24px;
  padding-bottom: 20px;
  border-bottom: 1px solid #ebeef5;
}

.salary-year-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.salary-month-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  min-height: 48px;
}

.salary-month-item {
  padding: 10px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  background: #fafafa;
  text-align: center;
}

.salary-month-item.paid {
  border-color: #b3e19d;
  background: #fafdf8;
}

.salary-month-item.pending {
  border-color: #f3d19e;
  background: #fdfaf3;
}

.salary-month-item .month-label {
  font-size: 13px;
  color: #909399;
  margin-bottom: 4px;
}

.salary-month-item .month-amount {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 6px;
  word-break: break-all;
}

.salary-month-item .month-amount.empty {
  color: #c0c4cc;
  font-weight: 400;
}

.proof-preview-img {
  max-width: 100%;
  max-height: 240px;
  border-radius: 8px;
  border: 1px solid #ebeef5;
}
</style>

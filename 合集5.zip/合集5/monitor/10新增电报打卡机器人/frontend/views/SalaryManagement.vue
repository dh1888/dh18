<template>
  <div class="salary-management">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <div class="stat-card-modern">
        <div class="stat-card-inner">
          <div
            class="stat-icon-wrapper"
            style="
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            "
          >
            <el-icon :size="28"><Money /></el-icon>
          </div>
          <div class="stat-details">
            <div class="stat-value">¥{{ formatNumber(totalAmount) }}</div>
            <div class="stat-label">总实发金额</div>
          </div>
        </div>
      </div>
      <div class="stat-card-modern">
        <div class="stat-card-inner">
          <div
            class="stat-icon-wrapper"
            style="
              background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            "
          >
            <el-icon :size="28"><User /></el-icon>
          </div>
          <div class="stat-details">
            <div class="stat-value">{{ salaryRecords.length }}</div>
            <div class="stat-label">发放人数</div>
          </div>
        </div>
      </div>
      <div class="stat-card-modern">
        <div class="stat-card-inner">
          <div
            class="stat-icon-wrapper"
            style="
              background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            "
          >
            <el-icon :size="28"><TrendCharts /></el-icon>
          </div>
          <div class="stat-details">
            <div class="stat-value">{{ formatNumber(avgSalary) }}</div>
            <div class="stat-label">人均实发</div>
          </div>
        </div>
      </div>
      <div class="stat-card-modern">
        <div class="stat-card-inner">
          <div
            class="stat-icon-wrapper"
            style="
              background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            "
          >
            <el-icon :size="28"><Calendar /></el-icon>
          </div>
          <div class="stat-details">
            <div class="stat-value">{{ currentMonth }}</div>
            <div class="stat-label">当前月份</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 工具栏 -->
    <el-card class="toolbar-card" shadow="hover">
      <div class="toolbar-container">
        <div class="toolbar-filters">
          <div class="filter-item">
            <el-date-picker
              v-model="selectedMonth"
              type="month"
              placeholder="选择月份"
              format="YYYY年MM月"
              value-format="YYYY-MM"
              @change="loadSalaryRecords"
              size="large"
              class="month-picker"
            />
          </div>
          <div class="filter-item">
            <el-input
              v-model="searchKeyword"
              placeholder="搜索员工姓名"
              clearable
              :prefix-icon="Search"
              @input="handleSearch"
              size="large"
              class="search-input"
            />
          </div>
        </div>
        <div class="toolbar-actions">
          <el-button
            class="action-btn primary-btn"
            @click="showUploadDialog"
            v-permission="'salary:upload'"
          >
            <el-icon><Upload /></el-icon>
            上传工资表
          </el-button>
          <el-button
            class="action-btn"
            @click="loadSalaryRecords"
            :loading="loading"
          >
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
          <el-button
            class="action-btn"
            @click="exportData"
            :disabled="salaryRecords.length === 0"
          >
            <el-icon><Download /></el-icon>
            导出
          </el-button>
        </div>
      </div>
    </el-card>

    <!-- 工资表格 -->
    <el-card class="table-card-modern" shadow="hover">
      <el-table
        v-loading="loading"
        :data="filteredRecords"
        stripe
        border
        style="width: 100%"
        :header-cell-style="headerCellStyle"
      >
        <el-table-column type="index" width="50" label="序号" fixed="left" />
        <el-table-column
          prop="employeeName"
          label="姓名"
          width="100"
          fixed="left"
        >
          <template #default="{ row }">
            <div class="employee-cell clickable" @click="openDetail(row)">
              <el-avatar
                :size="32"
                :style="{ backgroundColor: getAvatarColor(row.employeeName) }"
              >
                {{ row.employeeName?.charAt(0) }}
              </el-avatar>
              <span class="name-link">{{ row.employeeName }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="position" label="职务" width="100" />
        <el-table-column
          prop="hireDateDept"
          label="入职日期-部门"
          width="150"
          show-overflow-tooltip
        />
        <el-table-column
          prop="monthsEmployed"
          label="在职月数"
          width="90"
          align="center"
        />
        <el-table-column
          prop="lastMonthBase"
          label="上月底薪"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.lastMonthBase) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="totalIncrease"
          label="递增总额"
          width="100"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.totalIncrease) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="baseSalary"
          label="底薪(RMB)"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.baseSalary) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="attendanceDays"
          label="出勤"
          width="80"
          align="center"
        >
          <template #default="{ row }">{{ row.attendanceDays }}天</template>
        </el-table-column>
        <el-table-column
          prop="actualBaseSalary"
          label="实际底薪"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.actualBaseSalary) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="attendanceAdjustment"
          label="调勤"
          width="80"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.attendanceAdjustment) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="halfYearUnpaidLeave"
          label="半年未休"
          width="100"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.halfYearUnpaidLeave) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="exchangeRate"
          label="汇率"
          width="80"
          align="right"
        >
          <template #default="{ row }">{{ row.exchangeRate }}</template>
        </el-table-column>
        <el-table-column
          prop="performanceScore"
          label="绩效分数"
          width="90"
          align="center"
        />
        <el-table-column
          prop="performanceBonusB"
          label="绩效奖励B"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.performanceBonusB) }}</template
          >
        </el-table-column>
        <el-table-column prop="reward" label="奖励" width="100" align="right">
          <template #default="{ row }"
            >¥{{ formatNumber(row.reward) }}</template
          >
        </el-table-column>
        <el-table-column prop="penalty" label="罚款" width="100" align="right">
          <template #default="{ row }">
            <span class="penalty-amount">¥{{ formatNumber(row.penalty) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="advance"
          label="预支15-15"
          width="100"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.advance) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="otherDeduction"
          label="其他扣款"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.otherDeduction) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="protectionReturn"
          label="保护费返还"
          width="110"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.protectionReturn) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="protectionFee"
          label="保护费"
          width="100"
          align="right"
        >
          <template #default="{ row }"
            >¥{{ formatNumber(row.protectionFee) }}</template
          >
        </el-table-column>
        <el-table-column
          prop="totalSalary"
          label="实发合计"
          width="120"
          align="right"
          fixed="right"
        >
          <template #default="{ row }">
            <div class="total-cell">
              <span class="total-salary">¥{{ formatNumber(row.totalSalary) }}</span>
              <el-tag
                size="small"
                :type="row.paidStatus === 'paid' ? 'success' : 'warning'"
              >
                {{ row.paidStatusLabel || (row.paidStatus === 'paid' ? '已发' : '待发') }}
              </el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="remark"
          label="备注"
          min-width="150"
          show-overflow-tooltip
        />
        <el-table-column label="操作" width="320" fixed="right" align="center">
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              size="small"
              @click="openDetail(row)"
            >
              查看
            </el-button>
            <el-button
              link
              type="primary"
              size="small"
              v-permission="'salary:upload'"
              @click="openProofUploadDialog(row)"
            >
              上传图片
            </el-button>
            <el-button
              link
              type="success"
              size="small"
              v-permission="'salary:upload'"
              :disabled="row.paidStatus === 'paid'"
              @click="markPaid(row)"
            >
              已发
            </el-button>
            <el-button
              link
              type="primary"
              size="small"
              @click="editRecord(row)"
              v-permission="'salary:edit'"
            >
              <el-icon><Edit /></el-icon>编辑
            </el-button>
            <el-button
              link
              type="danger"
              size="small"
              @click="deleteRecord(row)"
              v-permission="'salary:delete'"
            >
              <el-icon><Delete /></el-icon>删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 上传打款截图 -->
    <el-dialog
      v-model="proofUploadVisible"
      title="上传打款截图"
      width="520px"
      class="modern-dialog"
      destroy-on-close
      @closed="clearProofPreview"
    >
      <el-alert
        v-if="proofUploadTarget"
        type="info"
        :closable="false"
        show-icon
        :title="`员工：${proofUploadTarget.employeeName} · ${formatMonthLabel(proofUploadForm.yearMonth)}`"
        style="margin-bottom: 16px"
      />
      <el-form label-width="90px">
        <el-form-item label="工资月份" required>
          <el-date-picker
            v-model="proofUploadForm.yearMonth"
            type="month"
            placeholder="选择月份"
            format="YYYY年MM月"
            value-format="YYYY-MM"
            style="width: 100%"
            @change="onProofMonthChange"
          />
        </el-form-item>
        <el-form-item label="打款截图" required>
          <el-upload
            ref="proofUploadRef"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/gif,image/webp,image/bmp,.jpg,.jpeg,.png,.gif,.webp,.bmp"
            :on-change="handleProofFileChange"
            list-type="picture-card"
          >
            <el-icon><Plus /></el-icon>
          </el-upload>
          <div class="el-upload__tip">支持 JPG、PNG、GIF、WEBP、BMP，最大 10MB</div>
        </el-form-item>
        <el-form-item v-if="proofPreviewUrl" label="当前截图">
          <img :src="proofPreviewUrl" alt="打款截图" class="proof-preview-img" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="proofUploadVisible = false">取消</el-button>
        <el-button type="primary" :loading="proofUploading" @click="submitProofUpload">
          上传
        </el-button>
      </template>
    </el-dialog>

    <!-- 上传对话框 -->
    <el-dialog
      v-model="uploadVisible"
      title="上传工资表"
      width="600px"
      class="modern-dialog"
    >
      <el-form :model="uploadForm" label-width="100px">
        <el-form-item label="选择月份" required>
          <el-date-picker
            v-model="uploadForm.yearMonth"
            type="month"
            placeholder="选择工资月份"
            format="YYYY年MM月"
            value-format="YYYY-MM"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="上传文件" required>
          <el-upload
            ref="uploadRef"
            :auto-upload="false"
            :on-change="handleFileChange"
            :limit="1"
            accept=".xlsx,.xls"
            drag
          >
            <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
            <div class="el-upload__text">拖拽文件到此或<em>点击选择</em></div>
            <template #tip>
              <div class="el-upload__tip">
                支持 .xlsx, .xls 格式，请确保Excel中包含所有工资列
              </div>
            </template>
          </el-upload>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="uploadVisible = false">取消</el-button>
        <el-button type="primary" @click="uploadSalary" :loading="uploading"
          >开始上传</el-button
        >
      </template>
    </el-dialog>

    <!-- 编辑对话框 -->
    <el-dialog
      v-model="editVisible"
      title="编辑工资记录"
      width="800px"
      class="modern-dialog"
    >
      <el-form :model="editForm" label-width="120px" class="edit-form">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="员工姓名">
              <el-input v-model="editForm.employeeName" disabled />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="职务">
              <el-input v-model="editForm.position" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="入职日期-部门">
              <el-input v-model="editForm.hireDateDept" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="在职月数">
              <el-input-number
                v-model="editForm.monthsEmployed"
                :min="0"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="上月底薪">
              <el-input-number
                v-model="editForm.lastMonthBase"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="递增总额">
              <el-input-number
                v-model="editForm.totalIncrease"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="底薪(RMB)">
              <el-input-number
                v-model="editForm.baseSalary"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="出勤">
              <el-input-number
                v-model="editForm.attendanceDays"
                :min="0"
                :step="0.5"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="实际底薪">
              <el-input-number
                v-model="editForm.actualBaseSalary"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="调勤">
              <el-input-number
                v-model="editForm.attendanceAdjustment"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="半年未休">
              <el-input-number
                v-model="editForm.halfYearUnpaidLeave"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="汇率">
              <el-input-number
                v-model="editForm.exchangeRate"
                :min="0"
                :step="0.1"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="绩效分数">
              <el-input-number
                v-model="editForm.performanceScore"
                :min="0"
                :max="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="绩效奖励B">
              <el-input-number
                v-model="editForm.performanceBonusB"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="奖励">
              <el-input-number
                v-model="editForm.reward"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="罚款">
              <el-input-number
                v-model="editForm.penalty"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="预支15-15">
              <el-input-number
                v-model="editForm.advance"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="其他扣款">
              <el-input-number
                v-model="editForm.otherDeduction"
                :min="0"
                :step="50"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="保护费返还">
              <el-input-number
                v-model="editForm.protectionReturn"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="保护费">
              <el-input-number
                v-model="editForm.protectionFee"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="实发合计">
              <el-input-number
                v-model="editForm.totalSalary"
                :min="0"
                :step="100"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="备注">
          <el-input
            v-model="editForm.remark"
            type="textarea"
            :rows="2"
            placeholder="请输入备注"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="editVisible = false">取消</el-button>
        <el-button type="primary" @click="saveEdit" :loading="saving"
          >保存修改</el-button
        >
      </template>
    </el-dialog>

    <!-- 上传结果对话框 -->
    <el-dialog v-model="resultVisible" title="上传结果" width="500px">
      <el-alert
        :type="resultData.failCount === 0 ? 'success' : 'warning'"
        :closable="false"
        show-icon
      >
        <template #title>
          成功 {{ resultData.successCount }} 条，失败
          {{ resultData.failCount }} 条
        </template>
      </el-alert>
      <div v-if="resultData.failedRecords?.length" class="failed-records">
        <el-divider />
        <h4>失败记录：</h4>
        <el-table :data="resultData.failedRecords" size="small">
          <el-table-column prop="row" label="行号" width="80" />
          <el-table-column prop="name" label="姓名" width="120" />
          <el-table-column prop="reason" label="原因" />
        </el-table>
      </div>
      <template #footer>
        <el-button type="primary" @click="resultVisible = false"
          >确定</el-button
        >
      </template>
    </el-dialog>

    <!-- 员工工资详情 -->
    <el-drawer
      v-model="detailVisible"
      :title="detailTitle"
      size="560px"
      destroy-on-close
    >
      <div v-if="detailRecord" class="detail-panel" v-loading="detailLoading">
        <div class="employee-block">
          <el-avatar :size="56" :style="{ backgroundColor: getAvatarColor(detailRecord.employeeName) }">
            {{ detailRecord.employeeName?.charAt(0) }}
          </el-avatar>
          <div>
            <div class="employee-name">{{ detailRecord.employeeName }}</div>
            <div class="employee-meta">
              <el-tag size="small" type="primary">{{ formatMonthLabel(detailRecord.yearMonth) }}</el-tag>
              <el-tag size="small" v-if="paymentInfo?.department">{{ paymentInfo.department }}</el-tag>
              <el-tag size="small" v-if="paymentInfo?.position || detailRecord.position">
                {{ paymentInfo?.position || detailRecord.position }}
              </el-tag>
            </div>
          </div>
        </div>

        <h4 class="section-heading">工资明细</h4>
        <div class="info-grid">
          <div class="info-row" v-for="item in salaryDetailItems" :key="item.label">
            <span class="label">{{ item.label }}</span>
            <span class="value" :class="item.class">{{ item.value }}</span>
          </div>
        </div>

        <div class="salary-year-section">
          <div class="salary-year-header">
            <h4 class="section-heading">{{ salaryYear }}年 工资状态</h4>
            <el-select v-model="salaryYear" size="small" style="width: 100px" @change="loadSalaryYear">
              <el-option v-for="y in salaryYearOptions" :key="y" :label="`${y}年`" :value="y" />
            </el-select>
          </div>
          <div v-loading="salaryYearLoading" class="salary-month-grid">
            <div
              v-for="item in salaryMonths"
              :key="item.yearMonth"
              class="salary-month-item"
              :class="item.status"
            >
              <div class="month-label">{{ item.monthLabel }}</div>
              <div class="month-amount" v-if="item.amount != null">¥{{ formatSalaryAmount(item.amount) }}</div>
              <div class="month-amount empty" v-else>-</div>
              <el-tag size="small" :type="salaryStatusTagType(item.status)">{{ item.statusLabel }}</el-tag>
            </div>
          </div>
        </div>

        <h4 class="section-heading">收款信息</h4>
        <template v-if="paymentInfo?.configured && paymentInfo.boundAccounts?.length">
          <div class="preferred-banner" v-if="paymentInfo.preferredMethodLabel">
            默认收款方式：<strong>{{ paymentInfo.preferredMethodLabel }}</strong>
          </div>
          <div
            v-for="acc in paymentInfo.boundAccounts"
            :key="acc.type"
            class="account-block"
            :class="{ preferred: acc.isPreferred }"
          >
            <div class="account-block-header">
              <span class="account-title">{{ acc.label }}</span>
              <el-tag v-if="acc.isPreferred" size="small" type="success">默认</el-tag>
            </div>
            <div class="info-grid compact">
              <template v-if="acc.type === 'bank'">
                <div class="info-row"><span class="label">收款人</span><span class="value">{{ paymentInfo.accountHolder }}</span></div>
                <div class="info-row"><span class="label">开户行</span><span class="value">{{ paymentInfo.bankName }}</span></div>
                <div class="info-row"><span class="label">银行账号</span><span class="value mono">{{ paymentInfo.bankAccount }}</span></div>
              </template>
              <template v-else-if="acc.type === 'usdt'">
                <div class="info-row"><span class="label">网络</span><span class="value">{{ paymentInfo.usdtNetwork }}</span></div>
                <div class="info-row"><span class="label">地址</span><span class="value mono">{{ paymentInfo.usdtAddress }}</span></div>
              </template>
              <template v-else>
                <div class="info-row"><span class="label">类型</span><span class="value">{{ paymentInfo.otherWalletType }}</span></div>
                <div class="info-row"><span class="label">地址/账号</span><span class="value mono">{{ paymentInfo.otherWalletAddress }}</span></div>
              </template>
            </div>
          </div>
          <p v-if="paymentInfo.remark" class="payment-remark">备注：{{ paymentInfo.remark }}</p>
        </template>
        <el-empty v-else description="该员工尚未绑定收款信息" :image-size="64" />
      </div>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Search,
  Refresh,
  Upload,
  Download,
  Edit,
  Delete,
  UploadFilled,
  Money,
  User,
  TrendCharts,
  Calendar,
  Plus,
} from "@element-plus/icons-vue";
import adminApi from "@api/admin_api";

const loading = ref(false);
const uploading = ref(false);
const proofUploading = ref(false);
const saving = ref(false);
const uploadVisible = ref(false);
const proofUploadVisible = ref(false);
const proofUploadTarget = ref<any>(null);
const proofUploadForm = ref({ yearMonth: "", file: null as File | null });
const proofUploadRef = ref();
const proofPreviewUrl = ref("");
const editVisible = ref(false);
const resultVisible = ref(false);
const detailVisible = ref(false);
const detailLoading = ref(false);
const detailRecord = ref<any>(null);
const paymentInfo = ref<any>(null);
const salaryYear = ref(new Date().getFullYear());
const salaryYearOptions = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);
const salaryMonths = ref<any[]>([]);
const salaryYearLoading = ref(false);
const salaryRecords = ref<any[]>([]);
const searchKeyword = ref("");
const selectedMonth = ref(getLastMonth());
const uploadRef = ref();

const uploadForm = ref({
  yearMonth: getLastMonth(),
  file: null,
});

const editForm = ref<any>({});

const resultData = ref({
  successCount: 0,
  failCount: 0,
  failedRecords: [] as any[],
});

const headerCellStyle = {
  background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
  color: "#ffffff",
  fontWeight: "600",
  fontSize: "14px",
  textAlign: "center",
};

const filteredRecords = computed(() => {
  if (!searchKeyword.value) return salaryRecords.value;
  const keyword = searchKeyword.value.toLowerCase();
  return salaryRecords.value.filter((r) =>
    r.employeeName?.toLowerCase().includes(keyword),
  );
});

const totalAmount = computed(() => {
  return salaryRecords.value.reduce((sum, r) => sum + (r.totalSalary || 0), 0);
});

const avgSalary = computed(() => {
  if (salaryRecords.value.length === 0) return 0;
  return totalAmount.value / salaryRecords.value.length;
});

const currentMonth = computed(() => {
  if (!selectedMonth.value) return "-";
  const [year, month] = selectedMonth.value.split("-");
  return `${year}年${parseInt(month)}月`;
});

const detailTitle = computed(() =>
  detailRecord.value ? `${detailRecord.value.employeeName} · 工资详情` : "工资详情",
);

const salaryDetailItems = computed(() => {
  const r = detailRecord.value;
  if (!r) return [];
  const money = (v: number) => `¥${formatNumber(v)}`;
  return [
    { label: "职务", value: r.position || "-" },
    { label: "入职日期-部门", value: r.hireDateDept || "-" },
    { label: "在职月数", value: `${r.monthsEmployed || 0}个月` },
    { label: "上月底薪", value: money(r.lastMonthBase) },
    { label: "递增总额", value: money(r.totalIncrease) },
    { label: "底薪(RMB)", value: money(r.baseSalary) },
    { label: "出勤", value: `${r.attendanceDays || 0}天` },
    { label: "实际底薪", value: money(r.actualBaseSalary) },
    { label: "调勤", value: money(r.attendanceAdjustment) },
    { label: "半年未休", value: money(r.halfYearUnpaidLeave) },
    { label: "汇率", value: String(r.exchangeRate ?? "-") },
    { label: "绩效分数", value: String(r.performanceScore ?? "-") },
    { label: "绩效奖励B", value: money(r.performanceBonusB) },
    { label: "奖励", value: money(r.reward) },
    { label: "罚款", value: money(r.penalty), class: "penalty" },
    { label: "预支15-15", value: money(r.advance) },
    { label: "其他扣款", value: money(r.otherDeduction) },
    { label: "保护费返还", value: money(r.protectionReturn) },
    { label: "保护费", value: money(r.protectionFee) },
    { label: "实发合计", value: money(r.totalSalary), class: "total" },
    { label: "备注", value: r.remark || "-" },
  ];
});

function getLastMonth() {
  const now = new Date();
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${lastMonth.getFullYear()}-${String(lastMonth.getMonth() + 1).padStart(2, "0")}`;
}

function formatNumber(num: number) {
  if (num === undefined || num === null) return "0";
  return num.toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function getAvatarColor(name: string) {
  const colors = [
    "#667eea",
    "#764ba2",
    "#f093fb",
    "#4facfe",
    "#43e97b",
    "#fa709a",
  ];
  const index = (name?.charCodeAt(0) || 0) % colors.length;
  return colors[index];
}

function formatMonthLabel(yearMonth: string) {
  if (!yearMonth) return "-";
  const [year, m] = yearMonth.split("-");
  return `${year}年${parseInt(m)}月`;
}

function formatSalaryAmount(value: number) {
  return Number(value).toLocaleString("zh-CN", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
}

function salaryStatusTagType(status: string) {
  if (status === "paid") return "success";
  if (status === "pending") return "warning";
  return "info";
}

async function loadSalaryYear() {
  if (!detailRecord.value?.employeeId) return;
  salaryYearLoading.value = true;
  try {
    const response = await adminApi.getPaymentAddressSalaryYear(
      detailRecord.value.employeeId,
      { year: salaryYear.value },
    );
    salaryMonths.value = response.data?.months || [];
  } catch {
    salaryMonths.value = [];
  } finally {
    salaryYearLoading.value = false;
  }
}

async function openDetail(row: any) {
  detailRecord.value = row;
  paymentInfo.value = null;
  salaryMonths.value = [];
  detailVisible.value = true;
  detailLoading.value = true;
  salaryYear.value = row.yearMonth
    ? parseInt(row.yearMonth.split("-")[0], 10)
    : new Date().getFullYear();

  try {
    const [paymentRes] = await Promise.all([
      adminApi.getEmployeePaymentAddress(row.employeeId),
      loadSalaryYear(),
    ]);
    paymentInfo.value = paymentRes.data || null;
  } catch (error: any) {
    ElMessage.error(error.message || "加载详情失败");
  } finally {
    detailLoading.value = false;
  }
}

async function loadSalaryRecords() {
  loading.value = true;
  try {
    const params: any = {};
    if (selectedMonth.value) params.yearMonth = selectedMonth.value;
    const response = await adminApi.getSalaryRecords(params);
    salaryRecords.value = response.data?.items || [];
  } catch (error: any) {
    ElMessage.error(error.message || "加载数据失败");
  } finally {
    loading.value = false;
  }
}

function handleSearch() {}

function showUploadDialog() {
  uploadForm.value = {
    yearMonth: selectedMonth.value || getLastMonth(),
    file: null,
  };
  if (uploadRef.value) uploadRef.value.clearFiles();
  uploadVisible.value = true;
}

function openProofUploadDialog(row: any) {
  proofUploadTarget.value = row;
  proofUploadForm.value = {
    yearMonth: row.yearMonth || selectedMonth.value || getLastMonth(),
    file: null,
  };
  proofUploadVisible.value = true;
  if (proofUploadRef.value) proofUploadRef.value.clearFiles();
  loadExistingProofPreview(row.employeeId, proofUploadForm.value.yearMonth);
}

function handleProofFileChange(file: any) {
  proofUploadForm.value.file = file.raw;
}

function clearProofPreview() {
  if (proofPreviewUrl.value) {
    URL.revokeObjectURL(proofPreviewUrl.value);
    proofPreviewUrl.value = "";
  }
}

function onProofMonthChange(month: string) {
  if (proofUploadTarget.value?.employeeId && month) {
    loadExistingProofPreview(proofUploadTarget.value.employeeId, month);
  }
}

async function loadExistingProofPreview(employeeId: string, yearMonth: string) {
  clearProofPreview();
  if (!employeeId || !yearMonth) return;
  try {
    const res = await adminApi.getSalaryPaymentProof({ employeeId, yearMonth });
    const proof = res.data;
    if (proof?.id) {
      const blobRes = await adminApi.fetchSalaryPaymentProofFile(proof.id);
      proofPreviewUrl.value = URL.createObjectURL(blobRes.data as Blob);
    }
  } catch {
    /* ignore */
  }
}

async function submitProofUpload() {
  if (!proofUploadForm.value.yearMonth) {
    ElMessage.warning("请选择工资月份");
    return;
  }
  if (!proofUploadForm.value.file) {
    ElMessage.warning("请选择打款截图");
    return;
  }
  if (!proofUploadTarget.value?.employeeId) {
    ElMessage.warning("员工信息无效");
    return;
  }
  proofUploading.value = true;
  try {
    const formData = new FormData();
    formData.append("file", proofUploadForm.value.file);
    formData.append("employeeId", proofUploadTarget.value.employeeId);
    formData.append("yearMonth", proofUploadForm.value.yearMonth);
    await adminApi.uploadSalaryPaymentProof(formData);
    ElMessage.success("打款截图上传成功");
    proofUploadVisible.value = false;
    await loadSalaryRecords();
  } catch (error: any) {
    ElMessage.error(error.message || "上传失败");
  } finally {
    proofUploading.value = false;
  }
}

function handleFileChange(file: any) {
  uploadForm.value.file = file.raw;
}

async function uploadSalary() {
  if (!uploadForm.value.yearMonth) {
    ElMessage.warning("请选择月份");
    return;
  }
  if (!uploadForm.value.file) {
    ElMessage.warning("请选择文件");
    return;
  }

  uploading.value = true;
  try {
    const formData = new FormData();
    formData.append("file", uploadForm.value.file);
    formData.append("yearMonth", uploadForm.value.yearMonth);

    const response = await adminApi.uploadSalary(formData);
    const data = response.data;

    resultData.value = {
      successCount: data.successCount || 0,
      failCount: data.failCount || 0,
      failedRecords: data.failedRecords || [],
    };

    resultVisible.value = true;
    uploadVisible.value = false;

    if (data.successCount > 0) {
      ElMessage.success(`成功上传 ${data.successCount} 条记录`);
      await loadSalaryRecords();
    }
  } catch (error: any) {
    ElMessage.error(error.message || "上传失败");
  } finally {
    uploading.value = false;
  }
}

function editRecord(row: any) {
  editForm.value = { ...row };
  editVisible.value = true;
}

async function saveEdit() {
  saving.value = true;
  try {
    await adminApi.updateSalaryRecord(editForm.value.id, editForm.value);
    ElMessage.success("保存成功");
    editVisible.value = false;
    await loadSalaryRecords();
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    saving.value = false;
  }
}

async function deleteRecord(row: any) {
  try {
    await ElMessageBox.confirm(
      `确定要删除员工 "${row.employeeName}" 的工资记录吗？`,
      "警告",
      {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      },
    );
    await adminApi.deleteSalaryRecord(row.id);
    ElMessage.success("删除成功");
    await loadSalaryRecords();
  } catch (error: any) {
    if (error !== "cancel") {
      ElMessage.error(error.message || "删除失败");
    }
  }
}

async function markPaid(row: any) {
  if (!row.id) {
    ElMessage.warning("工资记录无效");
    return;
  }
  if (row.paidStatus === "paid") {
    ElMessage.info("该月工资已是已发状态");
    return;
  }
  try {
    await ElMessageBox.confirm(
      `确认将 ${row.employeeName} ${formatMonthLabel(row.yearMonth)} 工资标记为已发？`,
      "标记已发",
      { type: "warning", confirmButtonText: "确认", cancelButtonText: "取消" },
    );
    await adminApi.markSalaryPaid({ id: row.id });
    ElMessage.success("已标记为已发");
    await loadSalaryRecords();
  } catch (error: any) {
    if (error !== "cancel") {
      ElMessage.error(error.message || "操作失败");
    }
  }
}

function exportData() {
  if (filteredRecords.value.length === 0) {
    ElMessage.warning("没有数据可导出");
    return;
  }

  const headers = [
    "姓名",
    "职务",
    "入职日期-部门",
    "在职月数",
    "上月底薪",
    "递增总额",
    "底薪(RMB)",
    "出勤",
    "实际底薪",
    "调勤",
    "半年未休",
    "汇率",
    "绩效分数",
    "绩效奖励B",
    "奖励",
    "罚款",
    "预支15-15",
    "其他扣款",
    "保护费返还",
    "保护费",
    "实发合计",
    "备注",
  ];
  const rows = filteredRecords.value.map((r) => [
    r.employeeName,
    r.position,
    r.hireDateDept,
    r.monthsEmployed,
    r.lastMonthBase,
    r.totalIncrease,
    r.baseSalary,
    r.attendanceDays,
    r.actualBaseSalary,
    r.attendanceAdjustment,
    r.halfYearUnpaidLeave,
    r.exchangeRate,
    r.performanceScore,
    r.performanceBonusB,
    r.reward,
    r.penalty,
    r.advance,
    r.otherDeduction,
    r.protectionReturn,
    r.protectionFee,
    r.totalSalary,
    r.remark || "",
  ]);

  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
  ].join("\n");
  const blob = new Blob(["\uFEFF" + csvContent], {
    type: "text/csv;charset=utf-8;",
  });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `工资表_${selectedMonth.value}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
  ElMessage.success("导出成功");
}

onMounted(() => {
  loadSalaryRecords();
});
</script>

<style scoped>
.salary-management {
  padding: 0px;
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
}

.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}

.blob-1 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -200px;
  right: -100px;
}
.blob-2 {
  width: 600px;
  height: 600px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -250px;
  left: -150px;
}
.blob-3 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 30%;
}

@keyframes float {
  0%,
  100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -30px) scale(1.05);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.95);
  }
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 24px;
  position: relative;
  z-index: 1;
}

.stat-card-modern {
  background: #ffffff;
  border-radius: 20px;
  overflow: hidden;
  position: relative;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
  transition: all 0.3s ease;
}

.stat-card-modern:hover {
  transform: translateY(-6px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
}

.stat-card-inner {
  padding: 20px 24px;
  display: flex;
  align-items: center;
  gap: 16px;
  position: relative;
  z-index: 2;
}

.stat-icon-wrapper {
  width: 56px;
  height: 56px;
  border-radius: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
}

.stat-details {
  flex: 1;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #1a1a2e;
  line-height: 1.2;
  margin-bottom: 6px;
}

.stat-label {
  font-size: 13px;
  color: #666;
  font-weight: 500;
}

.toolbar-card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  margin-bottom: 20px;
  position: relative;
  z-index: 1;
}

.toolbar-card :deep(.el-card__body) {
  padding: 16px 20px;
}

.toolbar-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 16px;
}

.toolbar-filters {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.filter-item {
  min-width: 160px;
}
.toolbar-actions {
  display: flex;
  gap: 12px;
}

.action-btn {
  border-radius: 12px;
  padding: 10px 20px;
  font-weight: 500;
  transition: all 0.3s ease;
  background: #f5f5f5;
  border-color: #e0e0e0;
  color: #666;
}
.action-btn:hover {
  transform: translateY(-2px);
}
.primary-btn {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border: none;
  color: white;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}
.primary-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(102, 126, 234, 0.4);
  color: white;
}

.table-card-modern {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  overflow: hidden;
  position: relative;
  z-index: 1;
}

.penalty-amount {
  color: #f56c6c;
  font-weight: 600;
}
.total-salary {
  color: #67c23a;
  font-weight: 700;
  font-size: 16px;
}
.total-cell {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 4px;
}
.employee-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.employee-cell.clickable {
  cursor: pointer;
}

.name-link {
  color: #409eff;
  font-weight: 500;
}

.name-link:hover {
  text-decoration: underline;
}

.detail-panel {
  padding: 0 4px 24px;
}

.employee-block {
  display: flex;
  gap: 16px;
  align-items: center;
  padding-bottom: 16px;
  margin-bottom: 16px;
  border-bottom: 1px solid #ebeef5;
}

.employee-name {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 8px;
}

.employee-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.section-heading {
  margin: 0 0 12px;
  font-size: 15px;
  color: #303133;
  font-weight: 600;
}

.info-grid {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 24px;
}

.info-grid.compact {
  margin-bottom: 0;
}

.info-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 8px 12px;
  background: #f5f7fa;
  border-radius: 8px;
  font-size: 13px;
}

.info-row .label {
  color: #909399;
  flex-shrink: 0;
}

.info-row .value {
  color: #303133;
  font-weight: 500;
  text-align: right;
  word-break: break-all;
}

.info-row .value.penalty {
  color: #f56c6c;
}

.info-row .value.total {
  color: #67c23a;
  font-size: 16px;
  font-weight: 700;
}

.info-row .value.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.salary-year-section {
  margin-bottom: 24px;
  padding-bottom: 20px;
  border-bottom: 1px solid #ebeef5;
}

.salary-year-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.salary-month-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  min-height: 40px;
}

.salary-month-item {
  padding: 10px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  background: #fafafa;
  text-align: center;
}

.salary-month-item.paid {
  border-color: #b3e19d;
  background: #fafdf8;
}

.salary-month-item.pending {
  border-color: #f3d19e;
  background: #fdfaf3;
}

.salary-month-item .month-label {
  font-size: 12px;
  color: #909399;
  margin-bottom: 4px;
}

.salary-month-item .month-amount {
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 6px;
  word-break: break-all;
}

.salary-month-item .month-amount.empty {
  color: #c0c4cc;
  font-weight: 400;
}

.preferred-banner {
  margin-bottom: 12px;
  padding: 10px 12px;
  background: #f0f9eb;
  border-radius: 8px;
  color: #67c23a;
  font-size: 13px;
}

.account-block {
  margin-bottom: 12px;
  padding: 12px;
  border: 1px solid #ebeef5;
  border-radius: 10px;
}

.account-block.preferred {
  border-color: #b3e19d;
  background: #fafdf8;
}

.account-block-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.account-title {
  font-weight: 600;
  color: #606266;
}

.payment-remark {
  margin: 8px 0 0;
  font-size: 13px;
  color: #909399;
}

.modern-dialog :deep(.el-dialog) {
  border-radius: 20px;
  overflow: hidden;
}
.modern-dialog :deep(.el-dialog__header) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  padding: 16px 20px;
  margin: 0;
}
.modern-dialog :deep(.el-dialog__title) {
  color: white;
  font-weight: 600;
  font-size: 18px;
}
.modern-dialog :deep(.el-dialog__body) {
  padding: 20px;
}

.failed-records {
  margin-top: 16px;
}
.edit-form :deep(.el-input-number) {
  width: 100%;
}

@media (max-width: 1200px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }
  .toolbar-container {
    flex-direction: column;
    align-items: stretch;
  }
  .toolbar-filters {
    flex-direction: column;
  }
  .filter-item {
    width: 100%;
  }
  .toolbar-actions {
    justify-content: flex-end;
  }
}
.proof-preview-img {
  max-width: 100%;
  max-height: 240px;
  border-radius: 8px;
  border: 1px solid #ebeef5;
}
</style>

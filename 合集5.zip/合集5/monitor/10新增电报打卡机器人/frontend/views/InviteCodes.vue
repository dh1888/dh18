<template>
  <div class="invite-codes-page attendance-management">
    <div class="bg-decoration" aria-hidden="true">
      <div class="blob blob-1 invite-blob-1"></div>
      <div class="blob blob-2 invite-blob-2"></div>
    </div>

    <div class="invite-content">
      <el-card class="invite-main-card" shadow="never">
        <template #header>
          <div class="invite-header">
            <div>
              <h2 class="invite-title">邀请码管理</h2>
              <p class="invite-subtitle">
                每位员工仅展示当前邀请码；使用后失效，重新生成会更新本卡片而非新增
              </p>
            </div>
            <div class="invite-header-actions">
              <el-button @click="openHistoryDialog">
                <el-icon><List /></el-icon>
                邀请码记录
              </el-button>
              <el-button type="primary" @click="loadInviteCodes" :loading="loading">
                <el-icon><Refresh /></el-icon>
                刷新
              </el-button>
            </div>
          </div>
        </template>

        <div class="invite-stat-grid">
          <div class="invite-stat-card active">
            <span class="invite-stat-num">{{ inviteStats.active }}</span>
            <span class="invite-stat-label">有效</span>
          </div>
          <div class="invite-stat-card used">
            <span class="invite-stat-num">{{ inviteStats.used }}</span>
            <span class="invite-stat-label">已使用</span>
          </div>
          <div class="invite-stat-card expired">
            <span class="invite-stat-num">{{ inviteStats.expired }}</span>
            <span class="invite-stat-label">已过期</span>
          </div>
          <div class="invite-stat-card revoked">
            <span class="invite-stat-num">{{ inviteStats.revoked }}</span>
            <span class="invite-stat-label">已作废</span>
          </div>
        </div>

        <div class="invite-filter-bar">
          <el-form :inline="true" class="filter-form">
            <el-form-item label="员工">
              <el-select
                v-model="employeeFilter"
                placeholder="全部员工"
                clearable
                filterable
                class="filter-select"
                @change="loadInviteCodes"
              >
                <el-option
                  v-for="emp in employees"
                  :key="emp.id"
                  :label="`${emp.name}${emp.employeeId ? ` (${emp.employeeId})` : ''}`"
                  :value="emp.id"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="状态">
              <el-select
                v-model="statusFilter"
                placeholder="全部状态"
                clearable
                class="filter-select status"
              >
                <el-option label="有效" value="active" />
                <el-option label="已使用" value="used" />
                <el-option label="已过期" value="expired" />
                <el-option label="已作废" value="revoked" />
              </el-select>
            </el-form-item>
          </el-form>
        </div>

        <div v-loading="loading" class="invite-card-grid">
          <div
            v-for="row in filteredItems"
            :key="row.employeeId"
            class="invite-card"
            :class="`status-${row.status}`"
          >
            <div class="invite-card-top">
              <code class="invite-code">{{ row.code }}</code>
              <el-tag :type="statusTagType(row.status)" size="small" effect="light">
                {{ statusLabel(row.status) }}
              </el-tag>
            </div>

            <div class="invite-card-employee">
              <el-icon><User /></el-icon>
              <span>{{ row.employeeName || "-" }}</span>
              <span v-if="row.employeeCode" class="employee-code">{{ row.employeeCode }}</span>
            </div>

            <div class="invite-card-meta">
              <div class="meta-row">
                <span class="meta-label">过期时间</span>
                <span>{{ formatTime(row.expiresAt) }}</span>
              </div>
              <div class="meta-row">
                <span class="meta-label">使用时间</span>
                <span>{{ formatTime(row.usedAt) }}</span>
              </div>
              <div class="meta-row">
                <span class="meta-label">绑定设备</span>
                <span>{{ row.deviceId ? row.deviceId.slice(0, 8) + "…" : "-" }}</span>
              </div>
              <div class="meta-row">
                <span class="meta-label">更新时间</span>
                <span>{{ formatTime(row.createdAt) }}</span>
              </div>
            </div>

            <div class="invite-card-actions">
              <el-button link type="primary" @click="copyCode(row.code)">
                <el-icon><DocumentCopy /></el-icon>
                复制
              </el-button>
              <el-button
                v-if="row.status === 'active'"
                link
                type="danger"
                v-permission="'invite:manage'"
                @click="handleRevoke(row)"
              >
                作废
              </el-button>
              <el-button
                link
                type="primary"
                v-permission="'invite:manage'"
                @click="handleRegenerate(row)"
              >
                {{ row.status === "active" ? "重新生成" : "生成新码" }}
              </el-button>
            </div>
          </div>

          <div v-if="!loading && !filteredItems.length" class="invite-empty">
            {{ statusFilter || employeeFilter ? "没有符合筛选条件的邀请码" : "暂无邀请码，请为员工生成" }}
          </div>
        </div>
      </el-card>
    </div>

    <el-dialog v-model="historyVisible" title="邀请码记录" width="920px" destroy-on-close>
      <div class="history-toolbar">
        <el-select
          v-model="historyEmployeeFilter"
          placeholder="全部员工"
          clearable
          filterable
          class="filter-select"
          @change="loadHistory"
        >
          <el-option
            v-for="emp in employees"
            :key="emp.id"
            :label="`${emp.name}${emp.employeeId ? ` (${emp.employeeId})` : ''}`"
            :value="emp.id"
          />
        </el-select>
        <el-select
          v-model="historyEventFilter"
          placeholder="全部操作"
          clearable
          class="filter-select status"
        >
          <el-option label="新增" value="新增" />
          <el-option label="已使用" value="已使用" />
          <el-option label="手动作废" value="手动作废" />
          <el-option label="重新生成作废" value="重新生成作废" />
          <el-option label="已过期" value="已过期" />
        </el-select>
        <el-button @click="loadHistory" :loading="historyLoading">刷新</el-button>
      </div>

      <el-table :data="filteredHistory" v-loading="historyLoading" stripe max-height="480">
        <el-table-column prop="createdAt" label="创建时间" min-width="160">
          <template #default="{ row }">{{ formatTime(row.createdAt) }}</template>
        </el-table-column>
        <el-table-column prop="employeeName" label="员工" width="100" />
        <el-table-column prop="code" label="邀请码" min-width="130">
          <template #default="{ row }"><code class="invite-code-inline">{{ row.code }}</code></template>
        </el-table-column>
        <el-table-column prop="eventLabel" label="操作" width="120">
          <template #default="{ row }">
            <el-tag :type="eventTagType(row.eventLabel)" size="small" effect="light">
              {{ row.eventLabel || row.dispositionLabel }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="过期" width="160">
          <template #default="{ row }">{{ formatTime(row.expiresAt) }}</template>
        </el-table-column>
        <el-table-column label="使用" width="160">
          <template #default="{ row }">{{ formatTime(row.usedAt) }}</template>
        </el-table-column>
        <el-table-column label="作废" width="160">
          <template #default="{ row }">{{ formatTime(row.revokedAt || row.supersededAt) }}</template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { Refresh, User, DocumentCopy, List } from "@element-plus/icons-vue";
import workforceApi from "@api/workforce_api";
import adminApi from "@api/admin_api";

interface InviteCodeRow {
  id: string;
  code: string;
  employeeId: string;
  employeeName: string;
  employeeCode?: string;
  status: string;
  disposition?: string;
  dispositionLabel?: string;
  eventLabel?: string;
  expiresAt?: string;
  usedAt?: string;
  revokedAt?: string;
  supersededAt?: string;
  createdAt?: string;
  deviceId?: string;
}

interface EmployeeOption {
  id: string;
  name: string;
  employeeId?: string;
}

const loading = ref(false);
const items = ref<InviteCodeRow[]>([]);
const employees = ref<EmployeeOption[]>([]);
const employeeFilter = ref("");
const statusFilter = ref("");

const historyVisible = ref(false);
const historyLoading = ref(false);
const historyItems = ref<InviteCodeRow[]>([]);
const historyEmployeeFilter = ref("");
const historyEventFilter = ref("");

const filteredItems = computed(() => {
  if (!statusFilter.value) return items.value;
  return items.value.filter((row) => row.status === statusFilter.value);
});

const filteredHistory = computed(() => {
  if (!historyEventFilter.value) return historyItems.value;
  return historyItems.value.filter(
    (row) => (row.eventLabel || row.dispositionLabel) === historyEventFilter.value,
  );
});

const inviteStats = computed(() => ({
  active: items.value.filter((r) => r.status === "active").length,
  used: items.value.filter((r) => r.status === "used").length,
  expired: items.value.filter((r) => r.status === "expired").length,
  revoked: items.value.filter((r) => r.status === "revoked").length,
}));

const statusLabel = (status: string) => {
  const map: Record<string, string> = {
    active: "有效",
    used: "已使用",
    expired: "已过期",
    revoked: "已作废",
  };
  return map[status] || status;
};

const statusTagType = (status: string) => {
  const map: Record<string, string> = {
    active: "success",
    used: "info",
    expired: "warning",
    revoked: "danger",
  };
  return map[status] || "info";
};

const eventTagType = (label?: string) => {
  switch (label) {
    case "新增":
      return "success";
    case "已使用":
      return "info";
    case "已过期":
      return "warning";
    case "手动作废":
    case "重新生成作废":
      return "danger";
    default:
      return "info";
  }
};

const formatTime = (value?: string) => {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
};

const loadEmployees = async () => {
  try {
    const { data } = await adminApi.getEmployees({ limit: 500 });
    employees.value = (data.items || data || []).map((e: any) => ({
      id: e.id,
      name: e.name,
      employeeId: e.employee_id || e.employeeId,
    }));
  } catch {
    employees.value = [];
  }
};

const loadInviteCodes = async () => {
  loading.value = true;
  try {
    const { data } = await workforceApi.listInviteCodes(employeeFilter.value || undefined);
    items.value = data.items || [];
  } catch (error: any) {
    ElMessage.error(error.message || "加载邀请码失败");
  } finally {
    loading.value = false;
  }
};

const upsertInviteItem = (item: InviteCodeRow) => {
  const idx = items.value.findIndex((row) => row.employeeId === item.employeeId);
  if (idx >= 0) {
    items.value[idx] = item;
  } else {
    items.value.unshift(item);
  }
};

const copyCode = async (code: string) => {
  try {
    await navigator.clipboard.writeText(code);
    ElMessage.success("已复制邀请码");
  } catch {
    ElMessage.error("复制失败");
  }
};

const handleRevoke = (row: InviteCodeRow) => {
  ElMessageBox.confirm(`确定作废邀请码 ${row.code} 吗？`, "作废邀请码", {
    type: "warning",
  }).then(async () => {
    await workforceApi.revokeInviteCode(row.id);
    ElMessage.success("邀请码已作废");
    await loadInviteCodes();
  });
};

const handleRegenerate = (row: InviteCodeRow) => {
  const isActive = row.status === "active";
  ElMessageBox.confirm(
    isActive
      ? `将为员工「${row.employeeName}」生成新的邀请码，当前有效码将作废。`
      : `将为员工「${row.employeeName}」生成新的邀请码。`,
    isActive ? "重新生成邀请码" : "生成邀请码",
    { type: "info" },
  ).then(async () => {
    const { data } = await workforceApi.regenerateInviteCode(row.employeeId);
    const item: InviteCodeRow = data.item || {
      ...row,
      id: data.inviteId,
      code: data.code,
      status: "active",
      usedAt: undefined,
      revokedAt: undefined,
      supersededAt: undefined,
    };
    upsertInviteItem(item);
    ElMessage.success(`新邀请码：${data.code || item.code}`);
  });
};

const openHistoryDialog = async () => {
  historyVisible.value = true;
  historyEmployeeFilter.value = employeeFilter.value;
  await loadHistory();
};

const loadHistory = async () => {
  historyLoading.value = true;
  try {
    const { data } = await workforceApi.listInviteCodeHistory(
      historyEmployeeFilter.value || undefined,
    );
    historyItems.value = data.items || [];
  } catch (error: any) {
    ElMessage.error(error.message || "加载邀请码记录失败");
  } finally {
    historyLoading.value = false;
  }
};

onMounted(async () => {
  await Promise.all([loadEmployees(), loadInviteCodes()]);
});
</script>

<style scoped>
@import "./attendance/attendance.css";

.invite-codes-page {
  position: relative;
  min-height: 100%;
}

.invite-blob-1 {
  background: linear-gradient(135deg, #667eea, #764ba2);
  opacity: 0.28;
}

.invite-blob-2 {
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  opacity: 0.22;
}

.invite-content {
  position: relative;
  z-index: 1;
  width: 100%;
}

.invite-main-card {
  border-radius: 18px;
  border: 1px solid rgba(255, 255, 255, 0.65);
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(16px);
  box-shadow: 0 8px 32px rgba(15, 23, 42, 0.08);
}

.invite-main-card :deep(.el-card__header) {
  padding: 20px 24px 12px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.invite-main-card :deep(.el-card__body) {
  padding: 16px 24px 24px;
}

.invite-header {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}

.invite-header-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.invite-title {
  margin: 0 0 6px;
  font-size: 20px;
  font-weight: 700;
  color: #303133;
}

.invite-subtitle {
  margin: 0;
  font-size: 13px;
  color: #909399;
  line-height: 1.5;
  max-width: 560px;
}

.invite-stat-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 20px;
}

.invite-stat-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  padding: 16px 12px;
  border-radius: 14px;
  background: #f9fafb;
  border: 1px solid rgba(0, 0, 0, 0.06);
}

.invite-stat-num {
  font-size: 26px;
  font-weight: 700;
  line-height: 1.2;
}

.invite-stat-label {
  font-size: 12px;
  color: #909399;
}

.invite-stat-card.active .invite-stat-num { color: #10b981; }
.invite-stat-card.used .invite-stat-num { color: #6366f1; }
.invite-stat-card.expired .invite-stat-num { color: #f59e0b; }
.invite-stat-card.revoked .invite-stat-num { color: #ef4444; }

.invite-filter-bar {
  margin-bottom: 16px;
  padding: 14px 16px;
  border-radius: 12px;
  background: linear-gradient(145deg, #f8fafc 0%, #f1f5f9 100%);
  border: 1px solid rgba(0, 0, 0, 0.06);
}

.filter-form { margin: 0; }
.filter-form :deep(.el-form-item) { margin-bottom: 0; margin-right: 16px; }
.filter-select { width: 240px; }
.filter-select.status { width: 140px; }

.history-toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 16px;
}

.invite-card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 14px;
  min-height: 80px;
}

.invite-card {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 16px;
  border-radius: 14px;
  background: #fff;
  border: 1px solid rgba(0, 0, 0, 0.06);
  border-top: 3px solid #909399;
  box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
}

.invite-card.status-active { border-top-color: #10b981; }
.invite-card.status-used { border-top-color: #6366f1; }
.invite-card.status-expired { border-top-color: #f59e0b; }
.invite-card.status-revoked { border-top-color: #ef4444; opacity: 0.85; }

.invite-card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.invite-code {
  font-family: Consolas, "Courier New", monospace;
  font-size: 15px;
  font-weight: 700;
  color: #0088cc;
  background: rgba(0, 136, 204, 0.08);
  padding: 6px 10px;
  border-radius: 8px;
}

.invite-code-inline {
  font-family: Consolas, "Courier New", monospace;
  font-size: 13px;
  color: #0088cc;
}

.invite-card-employee {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  font-weight: 600;
  color: #303133;
}

.employee-code {
  font-size: 12px;
  font-weight: 400;
  color: #909399;
}

.invite-card-meta {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 10px 12px;
  border-radius: 10px;
  background: #f9fafb;
}

.meta-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  font-size: 12px;
  color: #606266;
}

.meta-label { color: #909399; flex-shrink: 0; }

.invite-card-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  padding-top: 8px;
  border-top: 1px dashed rgba(0, 0, 0, 0.06);
}

.invite-empty {
  grid-column: 1 / -1;
  padding: 40px 16px;
  text-align: center;
  font-size: 13px;
  color: #909399;
  border-radius: 12px;
  background: rgba(0, 0, 0, 0.02);
  border: 1px dashed rgba(0, 0, 0, 0.08);
}

@media (max-width: 768px) {
  .invite-stat-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .filter-select, .filter-select.status { width: 100%; }
}
</style>

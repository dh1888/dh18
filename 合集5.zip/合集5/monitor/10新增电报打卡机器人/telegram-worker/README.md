# telegram-worker（可选）

**默认不需要运行本目录。**

Telegram Bot 已内嵌在 `backend` 进程中：Web 保存 Bot Token 并启用后，**重启 backend** 即可。

仅在以下情况才单独运行：

- 后端 `.env` 设置 `TELEGRAM_BOT_EMBEDDED=false`（外部 Worker 模式）
- 需要将 Bot 部署在与 backend 不同的机器上

```bash
cd telegram-worker
go run .
```

首次外部模式可用 Web「生成配对码」连接，或配置 `TELEGRAM_PAIRING_CODE` / `TELEGRAM_WORKER_SECRET`。

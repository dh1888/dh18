// Services/WebSocketService.cs - 完整修改版（集成 AuthTokenProvider）

using System.Net.Http.Headers;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

public class WebSocketService : BackgroundService
{
    private readonly ILogger<WebSocketService> _logger;
    private readonly AgentConfig _config;
    private readonly IMessageBus _messageBus;
    private readonly ISensitiveDataFilter _sensitiveDataFilter;
    private readonly IServiceProvider _serviceProvider;
    private readonly IAuthTokenProvider _authTokenProvider;
    private readonly IHttpClientFactory _httpFactory;

    // ========== WebSocket 连接 ==========
    private ClientWebSocket? _ws;
    private bool _connected;

    // ========== 锁 ==========
    private readonly SemaphoreSlim _sendLock = new(1, 1);
    private readonly SemaphoreSlim _connectLock = new(1, 1);
    private readonly SemaphoreSlim _reconnectLock = new(1, 1);
    private readonly SemaphoreSlim _refreshReconnectLock = new(1, 1);

    // ========== 后台任务管理 ==========
    private Task? _receiveTask;
    private Task? _heartbeatTask;
    private Task? _pendingReconnectTask;
    private Task? _pendingRefreshReconnectTask;
    private CancellationTokenSource? _connectionCts;
    private CancellationToken _hostStoppingToken;
    private bool _isStopping;

    // ========== 心跳状态 ==========
    private DateTime _lastPongTime;
    private int _reconnectAttempts;
    private bool _loggedLongTermReconnectPhase;
    private DateTime _lastReconnectAttempt = DateTime.MinValue;

    // ========== 防重连风暴 ==========
    private const int MinReconnectIntervalMs = 3000;

    // ========== 强制重连标志 ==========
    private volatile bool _forceReconnect;
    private long _pendingReconnectTokenVersion = -1;

    // ========== 事件 ==========
    public event Func<string, JsonElement, Task>? OnMessage;

    // ========== Token 订阅 ==========
    private IDisposable? _tokenSubscription;
    private long _currentTokenVersion = -1;

    public WebSocketService(
        ILogger<WebSocketService> logger,
        AgentConfig config,
        IMessageBus messageBus,
        ISensitiveDataFilter sensitiveDataFilter,
        IServiceProvider serviceProvider,
        IAuthTokenProvider authTokenProvider,
        IHttpClientFactory httpFactory)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _messageBus = messageBus ?? throw new ArgumentNullException(nameof(messageBus));
        _sensitiveDataFilter = sensitiveDataFilter ?? throw new ArgumentNullException(nameof(sensitiveDataFilter));
        _serviceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
        _authTokenProvider = authTokenProvider ?? throw new ArgumentNullException(nameof(authTokenProvider));
        _httpFactory = httpFactory ?? throw new ArgumentNullException(nameof(httpFactory));
        _lastPongTime = DateTime.UtcNow;

        // ✅ 订阅 Token 更新（保证不会丢失）
        _tokenSubscription = _authTokenProvider.Subscribe(OnTokenSnapshot);
    }

    #region ========== Token 事件处理 ==========

    /// <summary>
    /// ✅ Token 快照更新回调
    /// </summary>
    private void OnTokenSnapshot(AuthSnapshot snapshot)
    {
        if (_isStopping || _hostStoppingToken.IsCancellationRequested)
            return;

        if (!snapshot.IsAuthenticated)
        {
            _logger.LogDebug("Token snapshot received: not authenticated");
            return;
        }

        // ✅ 检查版本号，忽略旧事件
        if (snapshot.Version <= _currentTokenVersion)
        {
            _logger.LogDebug("Ignoring old token version: {Version} (current: {Current})", 
                snapshot.Version, _currentTokenVersion);
            return;
        }

        _currentTokenVersion = snapshot.Version;
        _pendingReconnectTokenVersion = snapshot.Version;
        _logger.LogInformation("📢 Token updated to v{Version}, scheduling WebSocket reconnect...", snapshot.Version);

        _forceReconnect = true;
        if (_connected)
        {
            _pendingReconnectTask = ReconnectAsync(snapshot.Version, _hostStoppingToken);
        }
    }

    #endregion

    #region ========== 主循环 ==========

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _hostStoppingToken = stoppingToken;
        _logger.LogInformation("WebSocket service started");

        while (!stoppingToken.IsCancellationRequested && !_isStopping)
        {
            try
            {
                if (_authTokenProvider.IsSessionRevoked)
                {
                    _logger.LogDebug("Session revoked, pausing WebSocket reconnect until re-approval");
                    await Task.Delay(TimeSpan.FromSeconds(60), stoppingToken);
                    continue;
                }

                await ConnectAndListenAsync(stoppingToken);

                if (_forceReconnect)
                {
                    _logger.LogInformation("Force reconnect flag detected, re-entering connection loop immediately");
                    _forceReconnect = false;
                    continue;
                }

                var delaySeconds = GetReconnectDelaySeconds();
                if (_reconnectAttempts > 0)
                {
                    LogLongTermReconnectPhaseIfNeeded(delaySeconds);
                    _logger.LogDebug("Reconnecting in {Delay}s (attempt {Attempts})", delaySeconds, _reconnectAttempts);
                }
                await Task.Delay(TimeSpan.FromSeconds(delaySeconds), stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "WebSocket connection error");
                var delaySeconds = GetReconnectDelaySeconds();
                if (_reconnectAttempts > 0)
                {
                    LogLongTermReconnectPhaseIfNeeded(delaySeconds);
                }
                await Task.Delay(TimeSpan.FromSeconds(delaySeconds), stoppingToken);
            }
        }

        await CleanupConnectionAsync();
        _logger.LogInformation("WebSocket service stopped");
    }

    #endregion

    #region ========== 连接管理 ==========

    private async Task ConnectAndListenAsync(CancellationToken ct)
    {
        if (!await _connectLock.WaitAsync(0, ct))
        {
            _logger.LogDebug("Connection already in progress");
            return;
        }

        try
        {
            if (_authTokenProvider.IsSessionRevoked)
            {
                _logger.LogDebug("Session revoked, skipping WebSocket connect");
                await Task.Delay(TimeSpan.FromSeconds(30), ct);
                return;
            }

            var snapshot = await WaitForAuthSnapshotAsync(ct);

            if (string.IsNullOrEmpty(snapshot.Token))
            {
                _logger.LogDebug("Token is empty, waiting for device registration");
                await Task.Delay(TimeSpan.FromSeconds(30), ct);
                return;
            }

            await CleanupConnectionAsync();

            _connectionCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            var connectionCt = _connectionCts.Token;

            // WS ticket 仅在 WS_TICKET_REQUIRED=true 时使用；本地开发直接用 Bearer JWT
            var wsUrl = _config.GetEffectiveWsUrl();
            var wsTicketRequired = IsWsTicketRequired();
            var ticket = wsTicketRequired ? await FetchWsTicketAsync(snapshot, ct) : null;
            Uri uri;
            _ws = new ClientWebSocket();
            _ws.Options.KeepAliveInterval = TimeSpan.FromSeconds(30);

            if (!string.IsNullOrEmpty(ticket))
            {
                uri = new Uri($"{wsUrl}?deviceId={Uri.EscapeDataString(snapshot.DeviceId)}&ticket={Uri.EscapeDataString(ticket)}");
                _logger.LogInformation("Connecting to WebSocket v{Version} at {WsUrl} (ticket)",
                    snapshot.Version, wsUrl);
            }
            else if (wsTicketRequired)
            {
                _logger.LogWarning("WS ticket required but unavailable, delaying reconnect");
                await Task.Delay(TimeSpan.FromSeconds(5), ct);
                return;
            }
            else
            {
                uri = new Uri($"{wsUrl}?deviceId={Uri.EscapeDataString(snapshot.DeviceId)}");
                _ws.Options.SetRequestHeader("Authorization", $"Bearer {snapshot.Token}");
                _logger.LogInformation("Connecting to WebSocket v{Version} at {WsUrl} (Token length: {TokenLength})",
                    snapshot.Version, wsUrl, snapshot.Token?.Length ?? 0);
            }

            await _ws.ConnectAsync(uri, ct);

            _connected = true;
            _reconnectAttempts = 0;
            _loggedLongTermReconnectPhase = false;
            _lastPongTime = DateTime.UtcNow;
            _pendingReconnectTokenVersion = -1;

            _logger.LogInformation("✅ WebSocket connected successfully");

            _ = PublishConnectedEventAsync();

            SchedulePolicySyncAfterConnect();

            var ws = _ws;

            _heartbeatTask = Task.Run(() => HeartbeatLoopAsync(ws, connectionCt), connectionCt);
            _receiveTask = Task.Run(() => ReceiveLoopAsync(ws, connectionCt), connectionCt);

            while (ws.State == WebSocketState.Open && !connectionCt.IsCancellationRequested)
            {
                await Task.Delay(1000, connectionCt);
            }
        }
        catch (WebSocketException ex) when (ex.WebSocketErrorCode == WebSocketError.ConnectionClosedPrematurely)
        {
            _logger.LogWarning("WebSocket connection closed prematurely");
            _reconnectAttempts++;
        }
        catch (WebSocketException ex) when (ex.Message.Contains("401") || ex.WebSocketErrorCode == WebSocketError.HeaderError)
        {
            _logger.LogWarning("🔴 WebSocket authentication failed (401), token may be invalid");
            _reconnectAttempts++;
            
            // ✅ 触发重新刷新 Token
            _pendingRefreshReconnectTask = RefreshTokenAndReconnectAsync();
        }
        catch (HttpRequestException ex) when (ex.StatusCode == System.Net.HttpStatusCode.Unauthorized)
        {
            _logger.LogWarning("🔴 WebSocket authentication failed (401), token may be invalid");
            _reconnectAttempts++;
            _pendingRefreshReconnectTask = RefreshTokenAndReconnectAsync();
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("WebSocket connection cancelled");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to connect WebSocket");
            _reconnectAttempts++;
        }
        finally
        {
            _connected = false;
            _connectLock.Release();
        }
    }

    private async Task<AuthSnapshot> WaitForAuthSnapshotAsync(CancellationToken ct)
    {
        const int maxAttempts = 30;
        for (var i = 0; i < maxAttempts; i++)
        {
            var snapshot = _authTokenProvider.GetSnapshot();
            var pendingVersion = Volatile.Read(ref _pendingReconnectTokenVersion);
            if (pendingVersion <= 0 || snapshot.Version >= pendingVersion)
                return snapshot;

            await Task.Delay(100, ct);
        }

        return _authTokenProvider.GetSnapshot();
    }

    private async Task CleanupConnectionAsync()
    {
        await StopRemoteViewIfPublishingAsync();

        if (_connectionCts != null)
        {
            try
            {
                _connectionCts.Cancel();
            }
            catch { }
        }

        if (_ws != null && _ws.State == WebSocketState.Open)
        {
            try
            {
                await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Cleanup", CancellationToken.None);
                _logger.LogDebug("WebSocket closed gracefully");
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Error closing WebSocket");
            }
        }

        var tasks = new List<Task>();
        if (_heartbeatTask != null && !_heartbeatTask.IsCompleted) tasks.Add(_heartbeatTask);
        if (_receiveTask != null && !_receiveTask.IsCompleted) tasks.Add(_receiveTask);

        if (tasks.Count > 0)
        {
            var allCompleted = false;
            try
            {
                await Task.WhenAll(tasks).WaitAsync(TimeSpan.FromSeconds(10));
                allCompleted = true;
                _logger.LogDebug("Background tasks completed");
            }
            catch (TimeoutException)
            {
                _logger.LogWarning("Background tasks did not complete within timeout, skipping socket dispose");
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Error waiting for background tasks");
            }

            if (!allCompleted)
            {
                _logger.LogWarning("Forcing WebSocket dispose after background task timeout");
                try
                {
                    _ws?.Dispose();
                }
                catch (Exception ex)
                {
                    _logger.LogDebug(ex, "Error forcing WebSocket dispose");
                }

                _heartbeatTask = null;
                _receiveTask = null;
                _ws = null;
                if (_connectionCts != null)
                {
                    _connectionCts.Dispose();
                    _connectionCts = null;
                }
                _connected = false;
                return;
            }
        }

        if (_connectionCts != null)
        {
            _connectionCts.Dispose();
            _connectionCts = null;
        }

        _heartbeatTask = null;
        _receiveTask = null;

        if (_ws != null)
        {
            try
            {
                _ws.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Error disposing WebSocket");
            }
            _ws = null;
        }

        _connected = false;
    }

    private void SchedulePolicySyncAfterConnect()
    {
        _ = Task.Run(async () =>
        {
            try
            {
                await Task.Delay(TimeSpan.FromSeconds(2));
                if (_isStopping) return;

                using var scope = _serviceProvider.CreateScope();
                var policySync = scope.ServiceProvider.GetRequiredService<PolicySyncService>();
                await policySync.ForceSyncAsync();
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Post-connect policy sync failed");
            }
        });
    }

    #endregion

    #region ========== 接收循环 ==========

    private async Task ReceiveLoopAsync(ClientWebSocket ws, CancellationToken ct)
    {
        _logger.LogDebug("ReceiveLoop started");

        try
        {
            while (!ct.IsCancellationRequested && ws.State == WebSocketState.Open)
            {
                try
                {
                    var message = await ReceiveFullMessageAsync(ws, ct);
                    if (message == null)
                    {
                        _logger.LogWarning("WebSocket closed by server");
                        break;
                    }

                    await HandleMessageAsync(message);
                }
                catch (WebSocketException ex) when (ex.WebSocketErrorCode == WebSocketError.ConnectionClosedPrematurely)
                {
                    _logger.LogWarning("WebSocket connection closed prematurely in ReceiveLoop");
                    break;
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error receiving WebSocket message");
                    await Task.Delay(1000, ct);
                }
            }
        }
        finally
        {
            _logger.LogDebug("ReceiveLoop exiting, cascading cancellation to connection");

            if (!ct.IsCancellationRequested)
            {
                var cts = _connectionCts;

                if (cts != null)
                {
                    try
                    {
                        cts.Cancel();
                    }
                    catch (ObjectDisposedException)
                    {
                        // CleanupConnectionAsync 已经 Dispose 了
                    }
                }
            }
        }
    }

    private static async Task<string?> ReceiveFullMessageAsync(ClientWebSocket ws, CancellationToken ct)
    {
        using var messageStream = new MemoryStream();
        var buffer = new byte[Constants.WebSocketReceiveBufferSize];

        while (true)
        {
            var result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);

            if (result.MessageType == WebSocketMessageType.Close)
                return null;

            if (result.Count > 0)
                messageStream.Write(buffer, 0, result.Count);

            if (messageStream.Length > Constants.MaxWebSocketMessageSize)
                throw new InvalidOperationException(
                    $"WebSocket message exceeds {Constants.MaxWebSocketMessageSize} bytes");

            if (result.EndOfMessage)
                return Encoding.UTF8.GetString(messageStream.ToArray());
        }
    }

    #endregion

    #region ========== 心跳循环 ==========

    private async Task HeartbeatLoopAsync(ClientWebSocket ws, CancellationToken ct)
    {
        _logger.LogDebug("HeartbeatLoop started");

        try
        {
            while (!ct.IsCancellationRequested && ws.State == WebSocketState.Open)
            {
                try
                {
                    await Task.Delay(TimeSpan.FromSeconds(Constants.WebSocketHeartbeatIntervalSeconds), ct);

                    if (ct.IsCancellationRequested || ws.State != WebSocketState.Open) continue;

                    if (DateTime.UtcNow - _lastPongTime > TimeSpan.FromSeconds(Constants.WebSocketHeartbeatTimeoutSeconds))
                    {
                        _logger.LogWarning("No pong received, closing connection for reconnect");
                        try
                        {
                            await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Heartbeat timeout", CancellationToken.None);
                        }
                        catch { }
                        break;
                    }

                    var json = JsonSerializer.Serialize(new { type = "ping", timestamp = DateTime.UtcNow.ToString("o") });
                    var bytes = Encoding.UTF8.GetBytes(json);

                    await _sendLock.WaitAsync(ct);
                    try
                    {
                        if (ws.State == WebSocketState.Open)
                        {
                            await ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, ct);
                        }
                    }
                    finally
                    {
                        _sendLock.Release();
                    }
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Heartbeat failed");
                }
            }
        }
        finally
        {
            _logger.LogDebug("HeartbeatLoop exiting, cascading cancellation to connection");

            if (!ct.IsCancellationRequested)
            {
                var cts = _connectionCts;

                if (cts != null)
                {
                    try
                    {
                        cts.Cancel();
                    }
                    catch (ObjectDisposedException)
                    {
                        // CleanupConnectionAsync 已经 Dispose 了
                    }
                }
            }
        }
    }

    #endregion

    #region ========== 消息处理 ==========

    private async Task HandleMessageAsync(string message)
    {
        try
        {
            using var doc = JsonDocument.Parse(message);
            var root = doc.RootElement;

            if (!root.TryGetProperty("type", out var typeElement))
            {
                _logger.LogWarning("Received message without type field");
                return;
            }

            var type = typeElement.GetString();
            if (string.IsNullOrEmpty(type)) return;

            // 心跳优先处理，避免被 MessageBus 慢订阅者阻塞
            if (type == "pong")
            {
                _lastPongTime = DateTime.UtcNow;
                return;
            }

            if (type == "device_revoked")
            {
                _ = HandleDeviceRevokedAsync(root);
                return;
            }

            // 关键下行消息 ACK（策略/命令），便于服务端在未确认时重试
            if ((type == "policy_update" || type == "command") &&
                root.TryGetProperty("messageId", out var messageIdElement))
            {
                var messageId = messageIdElement.GetString();
                if (!string.IsNullOrEmpty(messageId))
                {
                    _ = SendAckAsync(messageId);
                }
            }

            // 命令与任务消息异步处理，避免阻塞接收循环
            if (type == "command")
            {
                _ = ProcessCommandAsync(root.Clone());
                return;
            }

            if (OnMessage != null)
            {
                var messageType = type;
                var payload = root.Clone();
                _ = InvokeOnMessageAsync(messageType, payload);
            }

            // 其余消息异步发布
            if (type != "command")
            {
                var busType = type;
                var busPayload = root.Clone();
                _ = PublishMessageAsync(busType, busPayload);
            }
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Failed to parse WebSocket message");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to handle WebSocket message");
        }
    }

    private async Task InvokeOnMessageAsync(string messageType, JsonElement payload)
    {
        try
        {
            if (OnMessage != null)
                await OnMessage(messageType, payload);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "OnMessage handler failed for type {MessageType}", messageType);
        }
    }

    private async Task ProcessCommandAsync(JsonElement root)
    {
        try
        {
            await HandleCommandAsync(root);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to process WebSocket command");
        }
    }

    private async Task PublishConnectedEventAsync()
    {
        try
        {
            await _messageBus.PublishAsync("websocket.connected", default);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to publish websocket.connected event");
        }
    }

    private async Task PublishMessageAsync(string messageType, JsonElement payload)
    {
        try
        {
            await _messageBus.PublishAsync(messageType, payload);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to publish WebSocket message type {MessageType}", messageType);
        }
    }

    #endregion

    #region ========== 命令处理 ==========

    private async Task HandleCommandAsync(JsonElement root)
    {
        if (!root.TryGetProperty("command", out var commandElement))
        {
            _logger.LogWarning("Command message missing 'command' field");
            return;
        }

        var command = commandElement.GetString();
        var paramsElement = root.TryGetProperty("params", out var p) ? p : default;

        _logger.LogInformation("Received command: {Command}", command);

        switch (command)
        {
            case "start_remote_view":
                await HandleStartRemoteViewAsync(paramsElement);
                break;

            case "stop_remote_view":
                await HandleStopRemoteViewAsync(paramsElement);
                break;

            case "start_work_capture":
                HandleStartWorkCapture(paramsElement);
                break;

            case "stop_work_capture":
                HandleStopWorkCapture(paramsElement);
                break;

            default:
                _logger.LogWarning("Unknown command: {Command}", command);
                break;
        }
    }

    private async Task HandleStartRemoteViewAsync(JsonElement paramsElement)
    {
        try
        {
            using var scope = _serviceProvider.CreateScope();
            var controller = scope.ServiceProvider.GetRequiredService<RemoteView.RemoteViewSessionController>();
            await controller.HandleStartAsync(paramsElement);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to start remote view");
        }
    }

    private async Task HandleStopRemoteViewAsync(JsonElement paramsElement = default)
    {
        try
        {
            using var scope = _serviceProvider.CreateScope();
            var controller = scope.ServiceProvider.GetRequiredService<RemoteView.RemoteViewSessionController>();
            await controller.HandleStopAsync(paramsElement);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to stop remote view");
        }
    }

    private void HandleStartWorkCapture(JsonElement paramsElement)
    {
        try
        {
            var sessionId = paramsElement.TryGetProperty("sessionId", out var sid) ? sid.GetString() : null;
            if (string.IsNullOrWhiteSpace(sessionId))
            {
                _logger.LogWarning("start_work_capture missing sessionId");
                return;
            }
            var source = paramsElement.TryGetProperty("source", out var src) ? src.GetString() : "telegram";
            using var scope = _serviceProvider.CreateScope();
            var workSession = scope.ServiceProvider.GetRequiredService<WorkSessionService>();
            workSession.StartExternalWorkSession(sessionId!, source ?? "telegram");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to start work capture from command");
        }
    }

    private void HandleStopWorkCapture(JsonElement paramsElement)
    {
        try
        {
            string? sessionId = null;
            if (paramsElement.TryGetProperty("sessionId", out var sid))
                sessionId = sid.GetString();
            using var scope = _serviceProvider.CreateScope();
            var workSession = scope.ServiceProvider.GetRequiredService<WorkSessionService>();
            workSession.StopExternalWorkSession(sessionId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to stop work capture from command");
        }
    }

    #endregion

    #region ========== 发送消息 ==========

    public async Task SendMessageAsync(string message, CancellationToken ct = default)
    {
        var ws = _ws;
        if (!_connected || ws?.State != WebSocketState.Open)
        {
            _logger.LogWarning("WebSocket not open, cannot send message");
            return;
        }

        await _sendLock.WaitAsync(ct);
        try
        {
            if (ws.State != WebSocketState.Open) return;
            var bytes = Encoding.UTF8.GetBytes(message);
            await ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, ct);
            _logger.LogTrace("Message sent via WebSocket");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to send message via WebSocket");
            throw;
        }
        finally
        {
            _sendLock.Release();
        }
    }

    private async Task SendAckAsync(string messageId)
    {
        try
        {
            var json = JsonSerializer.Serialize(new { type = "ack", messageId });
            await SendMessageAsync(json);
            _logger.LogTrace("Sent ACK for message {MessageId}", messageId);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to send ACK for message {MessageId}", messageId);
        }
    }

    #endregion

    #region ========== 重连退避 ==========

    /// <summary>
    /// 计算主循环重连等待秒数：指数退避（封顶 60s），达到阈值后进入长期稳态间隔（60s + 抖动，仍无限重试）。
    /// </summary>
    private double GetReconnectDelaySeconds()
    {
        if (_reconnectAttempts <= 0)
            return 1;

        if (_reconnectAttempts >= Constants.MaxWebSocketReconnectAttempts)
        {
            return Constants.LongTermReconnectIntervalSeconds
                + Random.Shared.Next(0, Constants.LongTermReconnectJitterMaxSeconds + 1);
        }

        return Math.Min(Math.Pow(2, _reconnectAttempts), Constants.LongTermReconnectIntervalSeconds);
    }

    private void LogLongTermReconnectPhaseIfNeeded(double delaySeconds)
    {
        if (_loggedLongTermReconnectPhase
            || _reconnectAttempts < Constants.MaxWebSocketReconnectAttempts)
        {
            return;
        }

        _loggedLongTermReconnectPhase = true;
        _logger.LogInformation(
            "WebSocket entering long-term reconnect phase: next delay {Delay}s (base {Base}s + jitter 0-{Jitter}s, will continue until connected)",
            delaySeconds,
            Constants.LongTermReconnectIntervalSeconds,
            Constants.LongTermReconnectJitterMaxSeconds);
    }

    #endregion

    #region ========== 重连机制 ==========

    public Task ReconnectAsync(long? tokenVersion = null)
        => ReconnectAsync(tokenVersion, _hostStoppingToken);

    private async Task ReconnectAsync(long? tokenVersion, CancellationToken ct)
    {
        if (_isStopping || ct.IsCancellationRequested)
        {
            _logger.LogDebug("Reconnect skipped: service stopping");
            return;
        }

        if (tokenVersion.HasValue && tokenVersion.Value > _pendingReconnectTokenVersion)
        {
            _pendingReconnectTokenVersion = tokenVersion.Value;
        }

        if (!await _reconnectLock.WaitAsync(0, ct))
        {
            _logger.LogDebug("Reconnect already in progress, flagging follow-up reconnect");
            _forceReconnect = true;
            _connectionCts?.Cancel();
            return;
        }

        try
        {
            var elapsed = (DateTime.UtcNow - _lastReconnectAttempt).TotalMilliseconds;
            if (elapsed < MinReconnectIntervalMs)
            {
                var waitTime = (int)(MinReconnectIntervalMs - elapsed);
                _logger.LogDebug("Reconnect throttled, waiting {WaitTime}ms", waitTime);
                await Task.Delay(waitTime, ct);
            }

            _lastReconnectAttempt = DateTime.UtcNow;
            _logger.LogInformation("Forcing WebSocket reconnection...");

            _forceReconnect = true;
            _reconnectAttempts = 0;
            _loggedLongTermReconnectPhase = false;
            _connectionCts?.Cancel();
        }
        finally
        {
            _reconnectLock.Release();
        }
    }

    #endregion

    #region ========== Token 刷新辅助 ==========

    /// <summary>
    /// 刷新 Token 并重连（401 时调用），合并并发请求
    /// </summary>
    /// <summary>
    /// 管理员强制下线：清除本地 Token，等待用户重新注册/登录
    /// </summary>
    private async Task HandleDeviceRevokedAsync(JsonElement root)
    {
        var reason = root.TryGetProperty("reason", out var reasonEl)
            ? reasonEl.GetString()
            : "admin_force_offline";
        _logger.LogWarning("Device session revoked by server: {Reason}", reason);

        _authTokenProvider.RevokeSession();
        _forceReconnect = false;
        _connectionCts?.Cancel();
    }

    private async Task<string?> FetchWsTicketAsync(AuthSnapshot snapshot, CancellationToken ct)
    {
        if (string.IsNullOrEmpty(snapshot.Token))
        {
            return null;
        }

        try
        {
            using var client = _httpFactory.CreateClient("AgentClient");
            using var request = new HttpRequestMessage(HttpMethod.Post,
                $"{_config.ServerUrl}/api/v1/devices/ws-ticket");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

            using var response = await client.SendAsync(request, ct);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogDebug("WS ticket request failed: {StatusCode}", response.StatusCode);
                return null;
            }

            var body = await response.Content.ReadAsStringAsync(ct);
            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            var data = root.TryGetProperty("data", out var d) ? d : root;
            if (data.TryGetProperty("ticket", out var ticketEl))
            {
                return ticketEl.GetString();
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "WS ticket fetch failed, using legacy Bearer auth");
        }

        return null;
    }

    private static bool IsWsTicketRequired()
    {
        return string.Equals(
            Environment.GetEnvironmentVariable("WS_TICKET_REQUIRED"),
            "true",
            StringComparison.OrdinalIgnoreCase);
    }

    private async Task RefreshTokenAndReconnectAsync()
    {
        if (_isStopping || _hostStoppingToken.IsCancellationRequested)
            return;

        if (_authTokenProvider.IsSessionRevoked)
        {
            _logger.LogDebug("Session revoked, skip refresh/reconnect");
            return;
        }

        if (!await _refreshReconnectLock.WaitAsync(0))
        {
            _logger.LogDebug("Token refresh/reconnect already in progress");
            return;
        }

        try
        {
            _logger.LogInformation("Attempting to refresh token...");
            var newToken = await _authTokenProvider.RefreshTokenAsync();
            if (!string.IsNullOrEmpty(newToken))
            {
                _logger.LogInformation("Token refreshed, reconnecting WebSocket...");
                var version = _authTokenProvider.GetSnapshot().Version;
                await ReconnectAsync(version, _hostStoppingToken);
            }
            else
            {
                if (!_authTokenProvider.IsSessionRevoked)
                {
                    _logger.LogWarning("Token refresh failed, forcing re-registration");
                    await ForceReRegisterAsync();
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to refresh token");
            if (!_authTokenProvider.IsSessionRevoked)
            {
                await ForceReRegisterAsync();
            }
        }
        finally
        {
            _refreshReconnectLock.Release();
        }
    }

    /// <summary>
    /// ✅ 强制重新注册（当 Token 完全无效时）
    /// </summary>
    private async Task ForceReRegisterAsync()
    {
        try
        {
            using var scope = _serviceProvider.CreateScope();
            var registrationService = scope.ServiceProvider.GetRequiredService<DeviceRegistrationService>();
            await registrationService.ForceReRegisterAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to force re-registration");
        }
    }

    private async Task StopRemoteViewIfPublishingAsync()
    {
        try
        {
            using var scope = _serviceProvider.CreateScope();
            var publisher = scope.ServiceProvider.GetRequiredService<RemoteView.IRemoteViewPublisher>();
            if (!publisher.IsPublishing)
                return;

            var controller = scope.ServiceProvider.GetRequiredService<RemoteView.RemoteViewSessionController>();
            await controller.HandleStopAsync();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Remote view cleanup on disconnect skipped or failed");
        }
    }

    #endregion

    #region ========== 属性与停止 ==========

    public bool IsConnected => _connected && _ws?.State == WebSocketState.Open;

    private async Task WaitForPendingBackgroundOperationsAsync(CancellationToken ct)
    {
        var tasks = new List<Task>();
        if (_pendingReconnectTask != null && !_pendingReconnectTask.IsCompleted)
            tasks.Add(_pendingReconnectTask);
        if (_pendingRefreshReconnectTask != null && !_pendingRefreshReconnectTask.IsCompleted)
            tasks.Add(_pendingRefreshReconnectTask);

        if (tasks.Count == 0)
            return;

        try
        {
            await Task.WhenAll(tasks).WaitAsync(TimeSpan.FromSeconds(5), ct);
        }
        catch (TimeoutException)
        {
            _logger.LogWarning("Pending WebSocket reconnect tasks did not finish within shutdown timeout");
        }
        catch (OperationCanceledException)
        {
            // Host shutdown cancellation
        }
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Stopping WebSocket service...");
        _isStopping = true;
        _forceReconnect = false;

        // ✅ 取消 Token 订阅
        _tokenSubscription?.Dispose();
        _tokenSubscription = null;

        await CleanupConnectionAsync();
        await WaitForPendingBackgroundOperationsAsync(cancellationToken);
        await base.StopAsync(cancellationToken);
    }

    #endregion
}
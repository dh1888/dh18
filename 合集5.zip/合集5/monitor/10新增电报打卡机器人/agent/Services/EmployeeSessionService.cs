using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using EnterpriseAgent.Agent.Models;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 共享工位：员工使用后台账号密码登录/登出，同一终端可轮流多人使用。
/// </summary>
public sealed class EmployeeSessionService
{
    private readonly ILogger<EmployeeSessionService> _logger;
    private readonly IHttpClientFactory _httpFactory;
    private readonly IAuthTokenProvider _authTokenProvider;
    private readonly WorkSessionService? _workSession;

    private readonly object _lock = new();
    private string? _employeeName;
    private string? _username;
    private string? _employeeNumber;
    private string? _position;

    public event EventHandler? SessionChanged;

    public EmployeeSessionService(
        ILogger<EmployeeSessionService> logger,
        IHttpClientFactory httpFactory,
        IAuthTokenProvider authTokenProvider,
        WorkSessionService? workSession = null)
    {
        _logger = logger;
        _httpFactory = httpFactory;
        _authTokenProvider = authTokenProvider;
        _workSession = workSession;
    }

    private Func<string>? _serverUrlResolver;
    public void SetServerUrlResolver(Func<string> resolver) => _serverUrlResolver = resolver;

    public bool IsLoggedIn => GetTrayStatus().IsLoggedIn;

    public string? LastLoginError { get; private set; }

    public string? EmployeeName
    {
        get { lock (_lock) return _employeeName; }
    }

    public string? Username
    {
        get { lock (_lock) return _username; }
    }

    public string? EmployeeNumber
    {
        get { lock (_lock) return _employeeNumber; }
    }

    public string? Position
    {
        get { lock (_lock) return _position; }
    }

    public EmployeeTrayStatus GetTrayStatus()
    {
        lock (_lock)
        {
            return new EmployeeTrayStatus
            {
                IsLoggedIn = !string.IsNullOrEmpty(_employeeName) || !string.IsNullOrEmpty(_username),
                Name = _employeeName,
                Username = _username,
                EmployeeNumber = _employeeNumber,
                Position = _position
            };
        }
    }

    public async Task<bool> RefreshSessionAsync(CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return false;

        using var request = new HttpRequestMessage(HttpMethod.Get, $"{ServerUrl()}/api/v1/agent/session");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        if (!response.IsSuccessStatusCode)
            return false;

        var body = await response.Content.ReadAsStringAsync(ct);
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return false;
            var loggedIn = data.TryGetProperty("loggedIn", out var li) && li.GetBoolean();
            if (!loggedIn)
            {
                lock (_lock)
                {
                    if (string.IsNullOrEmpty(_employeeName) && string.IsNullOrEmpty(_username))
                        ClearLocal();
                }
                NotifySessionChanged();
                return false;
            }
            var name = data.TryGetProperty("name", out var n) ? n.GetString() : "";
            var user = data.TryGetProperty("username", out var u) ? u.GetString() : "";
            var empNo = data.TryGetProperty("employeeNumber", out var en) ? en.GetString() : "";
            var position = data.TryGetProperty("position", out var p) ? p.GetString() : "";
            lock (_lock)
            {
                _employeeName = name;
                _username = user;
                _employeeNumber = empNo;
                _position = position;
            }
            NotifySessionChanged();
            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>设备是否已通过邀请码等方式关联员工（不要求账号密码登录）。</summary>
    public async Task<bool> IsDeviceBoundAsync(CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
            return false;

        using var request = new HttpRequestMessage(HttpMethod.Get, $"{ServerUrl()}/api/v1/agent/session");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        if (!response.IsSuccessStatusCode)
            return false;

        var body = await response.Content.ReadAsStringAsync(ct);
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return false;
            return data.TryGetProperty("deviceBound", out var bound) && bound.GetBoolean();
        }
        catch
        {
            return false;
        }
    }

    public async Task<bool> LoginAsync(string username, string password, CancellationToken ct = default)
    {
        var snapshot = _authTokenProvider.GetSnapshot();
        if (string.IsNullOrEmpty(snapshot.Token))
        {
            _logger.LogWarning("Employee login failed: device not registered");
            return false;
        }

        var payload = JsonSerializer.Serialize(new { username, password });
        using var request = new HttpRequestMessage(HttpMethod.Post, $"{ServerUrl()}/api/v1/agent/employee-login")
        {
            Content = new StringContent(payload, Encoding.UTF8, "application/json")
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            LastLoginError = TryParseApiError(body) ?? $"HTTP {(int)response.StatusCode}";
            _logger.LogWarning("Employee login failed: {Status} {Body}", response.StatusCode, body);
            return false;
        }

        LastLoginError = null;

        string? name = null;
        string? user = username;
        string? empNo = null;
        string? position = null;
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("data", out var data))
            {
                name = data.TryGetProperty("name", out var n) ? n.GetString() : null;
                user = data.TryGetProperty("username", out var u) ? u.GetString() : username;
                empNo = data.TryGetProperty("employeeNumber", out var en) ? en.GetString() : null;
                position = data.TryGetProperty("position", out var p) ? p.GetString() : null;
            }
        }
        catch { /* ignore */ }

        lock (_lock)
        {
            _employeeName = name ?? username;
            _username = user;
            _employeeNumber = empNo;
            _position = position;
        }
        _logger.LogInformation("Employee logged in: {Name} ({User})", _employeeName, _username);
        NotifySessionChanged();
        return true;
    }

    public async Task<bool> LogoutAsync(CancellationToken ct = default)
    {
        if (_workSession != null && _workSession.HasOpenSession)
        {
            await _workSession.CheckOutAsync(ct);
        }

        var snapshot = _authTokenProvider.GetSnapshot();
        if (!string.IsNullOrEmpty(snapshot.Token))
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, $"{ServerUrl()}/api/v1/agent/employee-logout");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);
            using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("Employee logout API failed: {Status}", response.StatusCode);
            }
        }

        ClearLocal();
        _logger.LogInformation("Employee logged out");
        NotifySessionChanged();
        return true;
    }

    private void ClearLocal()
    {
        lock (_lock)
        {
            _employeeName = null;
            _username = null;
            _employeeNumber = null;
            _position = null;
        }
    }

    private void NotifySessionChanged() => SessionChanged?.Invoke(this, EventArgs.Empty);

    private string ServerUrl() => _serverUrlResolver?.Invoke() ?? "http://localhost:8080";

    private static string? TryParseApiError(string body)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("detail", out var detail) && detail.ValueKind == JsonValueKind.String)
                return detail.GetString();
            if (doc.RootElement.TryGetProperty("message", out var message) && message.ValueKind == JsonValueKind.String)
                return message.GetString();
        }
        catch { /* ignore */ }
        return null;
    }
}

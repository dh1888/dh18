// Services/ScreenRecorderService.cs - 完整修复版（添加系统睡眠/唤醒支持）

using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Cryptography;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using Microsoft.Win32;
using System.Globalization; 

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.Services;

[SupportedOSPlatform("windows")]
public sealed class ScreenRecorderService : BackgroundService
{
    private readonly ILogger<ScreenRecorderService> _logger;
    private readonly AgentConfig _config;
    private readonly IHostEnvironment _environment;
    private readonly SemaphoreSlim _processLock = new(1, 1);
    private readonly IServiceScopeFactory _scopeFactory;

    private AgentPolicy? _currentPolicy;
    private Process? _ffmpegProcess;
    private EventHandler? _ffmpegExitedHandler;
    private CancellationTokenSource? _recordingCts;
    private Task? _ffmpegOutputTask;
    private Task? _healthMonitorTask;
    private Task? _indexerTask;

    private bool _isStopping;
    private volatile bool _workSessionActive;
    private DateTime _lastSuccessfulFrame = DateTime.UtcNow;
    private long _lastObservedFileSize;
    private string? _cachedFfmpegPath;
    private DateTime _ffmpegPathCacheTime;
    private string? _cachedEncoder;
    private DateTime _encoderCacheTime;
    private (int width, int height)? _cachedDisplaySize;
    private DateTime _displaySizeCacheTime;

    private readonly Queue<DateTime> _restartHistory = new();
    private DateTime _lastRestartAttempt;
    private int _consecutiveFailures;
    private DateTime _lastIndexedWriteTimeUtc = DateTime.MinValue;

    // ========== 编码器智能降级字段 ==========
    private readonly SemaphoreSlim _encoderDetectionLock = new(1, 1);
    private string _currentEncoder = "libx264";
    private bool _hasEncoderError;
    private int _encoderFailureCount;
    private const int MaxEncoderFailures = 3;
    private DateTime _lastEncoderSwitchTime = DateTime.MinValue;
    private bool _forceSoftwareEncoder = false;
    
    // 像素格式回退标志
    private bool _needPixelFormatFallback = false;

    private DateTime _lastResumeTime = DateTime.MinValue;

    private bool _gpuDetectionFailedThisSession = false;

    // 统一重启锁 - 防止并发重启
    private readonly SemaphoreSlim _restartLock = new(1, 1);

// 三信号时间戳（替代单一的文件大小检测）
    private DateTime _lastFileActivity = DateTime.UtcNow;
    private DateTime _lastEncoderHeartbeat = DateTime.UtcNow;

// 重启冷却追踪
    private DateTime _lastFullRestartTime = DateTime.MinValue;
    private long _frameCount;


    private static int _isIndexing = 0;

    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(int nIndex);
    private const int SM_CXSCREEN = 0;
    private const int SM_CYSCREEN = 1;

    private string DeviceId => _config.DeviceId;

    private Task? _healthCheckTask;

    public ScreenRecorderService(
        ILogger<ScreenRecorderService> logger,
        IServiceScopeFactory scopeFactory,
        AgentConfig config,
        IHostEnvironment environment)
    {
        _logger = logger;
        _scopeFactory = scopeFactory;
        _config = config;
        _environment = environment;
        
        // ✅ 注册系统电源事件（睡眠/唤醒）
        SystemEvents.PowerModeChanged += OnPowerModeChanged;
        SystemEvents.SessionSwitch += OnSessionSwitch;
        _logger.LogDebug("System power events registered");
    }

    #region 系统电源事件处理

    /// <summary>
    /// 系统电源状态变化处理（睡眠/唤醒）
    /// </summary>
    /// 
    private void OnPowerModeChanged(object sender, PowerModeChangedEventArgs e)
    {
        if (e.Mode == PowerModes.Suspend)
        {
            _logger.LogInformation("⚠️ System entering sleep/suspend, stopping recording gracefully...");

            try
            {
                using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                Task.Run(async () =>
                {
                    using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(cts.Token);
                    await StopRecordingAsync().WaitAsync(linkedCts.Token);
                }).GetAwaiter().GetResult();

                _logger.LogInformation("✓ Recording stopped successfully before sleep");
            }
            catch (OperationCanceledException)
            {
                _logger.LogWarning("⚠️ Stop recording timeout before sleep, forcing cleanup");
                // 简化：清理失败也无需额外处理
                Task.Run(() => ForceCleanupAsync()).Wait(1000);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error stopping recording during system sleep");
                Task.Run(() => ForceCleanupAsync()).Wait(1000);
            }
        }
        else if (e.Mode == PowerModes.Resume)
        {
            _lastResumeTime = DateTime.UtcNow;
            _logger.LogInformation("🔄 System resumed from sleep, restarting recording...");

            _ = Task.Run(async () =>
            {
                try
                {
                    // 等待系统完全恢复
                    await Task.Delay(5000);

                    // 清理可能失效的进程引用
                    await CleanupProcessAsync();

                    // 重置编码器状态
                    _forceSoftwareEncoder = false;
                    _encoderFailureCount = 0;
                    _hasEncoderError = false;
                    _needPixelFormatFallback = false;
                    _encoderCacheTime = DateTime.MinValue;

                    _logger.LogInformation("✓ State reset, triggering unified restart");

                    try
                    {
                        using var scope = _scopeFactory.CreateScope();
                        var db = scope.ServiceProvider.GetService<SqliteDbContext>();
                        if (db != null)
                        {
                            db.InvalidateConnection();
                            _logger.LogInformation("Database connection invalidated after resume");
                        }

                        var uploader = scope.ServiceProvider.GetService<FileUploadService>();
                        if (uploader != null)
                        {
                            try
                            {
                                uploader.ResetHttpClient();
                                _logger.LogInformation("FileUploadService HttpClient reset after resume");
                            }
                            catch (Exception ex)
                            {
                                _logger.LogWarning(ex, "Failed to reset FileUploadService HttpClient");
                            }
                        }

                        var uploadRepo = scope.ServiceProvider.GetService<UploadQueueRepository>();
                        if (uploadRepo != null)
                        {
                            try
                            {
                                // 使用统一重置接口
                                await uploadRepo.ResetStuckUploadsAsync(TimeSpan.FromMinutes(30));
                                _logger.LogInformation("Upload queue ResetStuckUploadsAsync executed after resume");
                            }
                            catch (Exception ex)
                            {
                                _logger.LogWarning(ex, "Failed to reset stuck upload tasks after resume");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Exception while refreshing dependencies after resume");
                    }

                    // 直接调用统一重启入口，RestartEngineAsync 内部会处理停止/启动与 CTS 重建
                    await RestartEngineAsync(RestartMode.Full, "System resume");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Unexpected error during resume recovery");
                }
            });
        }
    }

    /// <summary>
    /// 会话切换事件处理（锁屏/解锁）
    /// </summary>
    private void OnSessionSwitch(object sender, SessionSwitchEventArgs e)
    {
        switch (e.Reason)
        {
            case SessionSwitchReason.SessionLock:
                _logger.LogInformation("🔒 Screen locked, continuing recording (no action needed)");
                // 锁屏时录屏可以继续，不需要停止
                break;

            case SessionSwitchReason.SessionUnlock:
                _logger.LogInformation("🔓 Screen unlocked, checking recording status...");
                // 解锁后检查并恢复录屏
                _ = Task.Run(async () =>
                {
                    await Task.Delay(2000); // 等待2秒让系统完全恢复
                    await CheckAndRestartRecordingIfNeeded();
                });
                break;

            case SessionSwitchReason.SessionLogoff:
            case SessionSwitchReason.SessionLogon:
                _logger.LogInformation("User logoff/logon: {Reason}", e.Reason);
                break;
        }
    }

    private async Task RecordingHealthCheckLoop(CancellationToken stoppingToken)
    {
        // 状态跟踪
        bool wasHealthy = true;
        int consecutiveFailures = 0;
        DateTime lastRestartAttempt = DateTime.MinValue;
        // DateTime lastResumeTime = DateTime.MinValue; // 需要在 Resume 事件中更新

        // 初始延迟，避免启动时误报
        await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);

        // 固定的检查间隔
        var normalInterval = TimeSpan.FromSeconds(30);
        var degradedInterval = TimeSpan.FromSeconds(60); // 失败后降低频率

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var config = _currentPolicy?.GetRecordingConfig();
                if (config?.Enabled != true || !_workSessionActive)
                {
                    // 录制未启用或未上班，等待较长时间再检查
                    await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
                    continue;
                }

                // 检查系统是否在恢复中（最近30秒内恢复过）
                if ((DateTime.UtcNow - _lastResumeTime).TotalSeconds < 30)
                {
                    _logger.LogDebug("Health check skipped: System resuming");
                    await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
                    continue;
                }

                bool isAlive = IsProcessAlive();

                // 状态变化日志
                if (!isAlive && wasHealthy)
                {
                    _logger.LogWarning("⚠️ Health check: Recording process died");
                    wasHealthy = false;
                }
                else if (isAlive && !wasHealthy)
                {
                    _logger.LogInformation("✓ Health check: Recording recovered");
                    wasHealthy = true;
                    consecutiveFailures = 0;
                }

                // 需要重启（仅上班期间）
                if (!isAlive && _workSessionActive)
                {
                    // ✅ 修复：统一的重启限流机制
                    var timeSinceLastRestart = DateTime.UtcNow - lastRestartAttempt;
                    
                    // 重启频率：至少间隔 60 秒，防止重启风暴
                    if (timeSinceLastRestart.TotalSeconds < 60)
                    {
                        _logger.LogDebug(
                            "⏳ Restart throttled, last attempt was {Seconds:F0}s ago (min interval: 60s)",
                            timeSinceLastRestart.TotalSeconds);

                        // 等待较长时间再检查
                        await Task.Delay(TimeSpan.FromSeconds(60), stoppingToken);
                        continue;
                    }

                    _logger.LogWarning(
                        "⚠️ Attempting to restart recording (failure {FailureCount})",
                        consecutiveFailures + 1);

                    lastRestartAttempt = DateTime.UtcNow;

                    try
                    {
                        // ✅ 调用统一的重启方法（已经包含节流逻辑）
                        await RestartRecordingAsync();
                        consecutiveFailures = 0;

                        // 重启后等待恢复
                        await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken);

                        // 验证重启是否成功
                        if (IsProcessAlive())
                        {
                            _logger.LogInformation("✓ Recording restarted successfully");
                            wasHealthy = true;
                        }
                        else
                        {
                            _logger.LogWarning("Restart claimed success but process not alive");
                            consecutiveFailures++;
                        }
                    }
                    catch (Exception ex)
                    {
                        consecutiveFailures++;
                        _logger.LogError(
                            ex,
                            "❌ Restart failed (failure {FailureCount})",
                            consecutiveFailures);

                        // 连续失败3次后，等待2分钟再重试
                        if (consecutiveFailures >= 3)
                        {
                            _logger.LogWarning(
                                "Multiple failures detected, backing off for 2 minutes (failures: {Count})",
                                consecutiveFailures);
                            await Task.Delay(TimeSpan.FromMinutes(2), stoppingToken);
                            consecutiveFailures = 0; // 重置计数器，避免永久等待
                        }
                    }
                }

                // 选择检查间隔
                var interval = consecutiveFailures > 0 ? degradedInterval : normalInterval;
                await Task.Delay(interval, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Health check loop cancelled");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Health check loop error");
                // 出错后等待较长时间再重试
                await Task.Delay(TimeSpan.FromSeconds(60), stoppingToken);
            }
        }

        _logger.LogInformation("Health check loop stopped");
    }

    /// <summary>
    /// 检查录屏状态并在需要时重启
    /// </summary>
    private async Task CheckAndRestartRecordingIfNeeded()
    {
        if (!_workSessionActive)
        {
            _logger.LogDebug("No active work session, skipping restart after unlock");
            return;
        }

        var config = _currentPolicy?.GetRecordingConfig();
        if (config?.Enabled != true)
        {
            _logger.LogDebug("Recording disabled by policy, skipping restart");
            return;
        }

        // 检查 FFmpeg 进程是否存活
        if (IsProcessAlive())
        {
            _logger.LogDebug("FFmpeg process is alive, no restart needed");
            return;
        }

        // ✅ 添加限流检查，避免频繁重启
        if ((DateTime.UtcNow - _lastRestartAttempt).TotalSeconds < 30)
        {
            _logger.LogDebug(
                "Restart throttled, last attempt was {Seconds:F0}s ago",
                (DateTime.UtcNow - _lastRestartAttempt).TotalSeconds);

            return;
        }

        _logger.LogWarning("⚠️ Recording not running after unlock, restarting...");
        await RestartEngineAsync(RestartMode.Full, "Unlock recovery");
    }

    /// <summary>
    /// 强制清理（用于睡眠等紧急情况）
    /// </summary>
    private async Task ForceCleanupAsync()
    {
        var process = _ffmpegProcess;
        if (process == null) return;
        
        try
        {
            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
                await Task.Delay(500);
            }
            process.Dispose();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error during force cleanup");
        }
        finally
        {
            _ffmpegProcess = null;
        }
    }

    #endregion

    #region 进程状态检查

    /// <summary>
    /// 检查进程是否存活（安全版本，避免休眠后异常）
    /// </summary>
    private bool IsProcessAlive()
    {
        if (_ffmpegProcess == null) return false;
        
        try
        {
            // 检查进程是否还在运行
            return !_ffmpegProcess.HasExited;
        }
        catch (InvalidOperationException)
        {
            // 进程对象已失效（休眠后常见）
            _logger.LogDebug("Process object invalid, assuming dead");
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error checking process status");
            return false;
        }
    }

    /// <summary>
    /// 安全的进程清理（增强版）- 防止资源泄漏
    /// </summary>
    private async Task CleanupProcessAsync()
    {
        var process = _ffmpegProcess;
        if (process == null) return;

        try
        {
            // ✅ 安全地检查进程是否存在
            bool hasExited = true;
            try
            {
                hasExited = process.HasExited;
            }
            catch (InvalidOperationException)
            {
                // 进程已消失（如休眠后）
                _logger.LogDebug("Process already gone (invalid operation)");
            }
            
            if (!hasExited)
            {
                _logger.LogDebug("Stopping FFmpeg process gracefully (PID: {Pid})", process.Id);
                
                // 1. 先尝试优雅退出（关闭标准输入）
                try 
                { 
                    process.StandardInput?.Close();
                    _logger.LogDebug("Standard input closed");
                } 
                catch (Exception ex) 
                { 
                    _logger.LogDebug(ex, "Could not close standard input"); 
                }
                
                // 2. 等待最多3秒让 FFmpeg 完成当前分片
                try
                {
                    await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(3));
                    if (process.HasExited)
                    {
                        _logger.LogDebug("FFmpeg exited gracefully");
                    }
                }
                catch (TimeoutException)
                {
                    _logger.LogWarning("FFmpeg didn't exit gracefully within 3 seconds");
                }
                
                // 3. 如果还没退出，强制杀死
                if (!process.HasExited)
                {
                    _logger.LogWarning("⚠️ Killing FFmpeg process (PID: {Pid})", process.Id);
                    try
                    {
                        process.Kill(entireProcessTree: true);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Could not kill process");
                    }
                    
                    // 等待进程退出
                    for (int i = 0; i < Constants.FfmpegMaxExitWaitAttempts; i++)
                    {
                        await Task.Delay(100);
                        try
                        {
                            if (process.HasExited)
                            {
                                _logger.LogDebug("Process killed successfully after {Attempts} attempts", i + 1);
                                break;
                            }
                        }
                        catch (InvalidOperationException)
                        {
                            // 进程对象已失效
                            break;
                        }
                    }
                }
            }
            
            // ✅ 最后确保 Dispose 被调用
            if (_ffmpegExitedHandler != null)
            {
                try { process.Exited -= _ffmpegExitedHandler; } catch { }
                _ffmpegExitedHandler = null;
            }
            process.Dispose();
            _logger.LogDebug("Process disposed");
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error cleaning up process");
        }
        finally
        {
            _ffmpegProcess = null;
        }

        // 等待后台任务完成（但不要等太久）
        await SafeWaitTaskAsync(_ffmpegOutputTask);
        await SafeWaitTaskAsync(_healthMonitorTask);
        await SafeWaitTaskAsync(_indexerTask);
    }

    #endregion

    public void UpdatePolicy(AgentPolicy policy)
    {
        var previousConfig = _currentPolicy?.GetRecordingConfig();
        _currentPolicy = policy;
        var recordingConfig = policy.GetRecordingConfig();
        var recordingConfigChanged = HasRecordingConfigChanged(previousConfig, recordingConfig);

        _logger.LogInformation(
            "Recording policy updated: Enabled={Enabled}, FPS={Fps}, GPU={Gpu}, SliceMinutes={SliceMinutes}, ConfigChanged={ConfigChanged}",
            recordingConfig.Enabled,
            recordingConfig.Fps,
            recordingConfig.EnableGpu,
            recordingConfig.SliceMinutes,
            recordingConfigChanged
        );

        if (!recordingConfig.EnableGpu)
        {
            _forceSoftwareEncoder = false;
            _encoderFailureCount = 0;
            _logger.LogDebug("GPU encoding disabled in policy, resetting encoder force flag");
        }

        if (recordingConfig.EnableGpu && _forceSoftwareEncoder)
        {
            var timeSinceFallback = DateTime.UtcNow - _lastEncoderSwitchTime;
            if (timeSinceFallback > TimeSpan.FromMinutes(30))
            {
                _logger.LogInformation("Retrying hardware encoder after 30 minutes cooldown");
                _forceSoftwareEncoder = false;
                _encoderFailureCount = 0;
                _encoderCacheTime = DateTime.MinValue;
            }
        }

        if (!recordingConfig.Enabled)
        {
            _ = StopRecordingAsync();
            return;
        }

        if (_workSessionActive && (!IsProcessAlive() || recordingConfigChanged))
        {
            var reason = !IsProcessAlive()
                ? "Policy update - process not alive"
                : "Policy update - recording config changed";
            _ = RestartEngineAsync(RestartMode.Full, reason);
        }
    }

    private static bool HasRecordingConfigChanged(RecordingConfig? previous, RecordingConfig current)
    {
        if (previous == null)
            return true;

        return previous.Enabled != current.Enabled
            || previous.Fps != current.Fps
            || previous.IdleFps != current.IdleFps
            || previous.SliceMinutes != current.SliceMinutes
            || previous.EnableGpu != current.EnableGpu
            || previous.Quality != current.Quality
            || !string.Equals(previous.Resolution, current.Resolution, StringComparison.OrdinalIgnoreCase)
            || !string.Equals(previous.EncoderPriority, current.EncoderPriority, StringComparison.OrdinalIgnoreCase)
            || !string.Equals(previous.HardwareEncoderPreset, current.HardwareEncoderPreset, StringComparison.OrdinalIgnoreCase)
            || !string.Equals(previous.SoftwareEncoderPreset, current.SoftwareEncoderPreset, StringComparison.OrdinalIgnoreCase)
            || previous.AllowEncoderFallback != current.AllowEncoderFallback
            || previous.GpuEncoderRetryMinutes != current.GpuEncoderRetryMinutes
            || previous.EnableNvenc32Align != current.EnableNvenc32Align
            || previous.UseNvencHq != current.UseNvencHq
            || previous.EnableEncoderPreCheck != current.EnableEncoderPreCheck;
    }
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Screen recorder service started");

        // 初始化默认策略
        if (_currentPolicy == null)
        {
            var defaultPolicy = new Policy
            {
                Version = 1,
                Config = JsonSerializer.Deserialize<JsonElement>(
                    @"{
                        ""recording"": {
                            ""enabled"": true,
                            ""fps"": 10,
                            ""enableGpu"": true,
                            ""quality"": 60,
                            ""sliceMinutes"": 1
                        }
                    }")
            };

            UpdatePolicy(defaultPolicy);
            _logger.LogWarning("Using default recording policy (server sync not available)");
        }

        var ffmpegPath = FindFfmpegCached();
        if (string.IsNullOrWhiteSpace(ffmpegPath))
        {
            _logger.LogError(
                "Screen recording is enabled but ffmpeg.exe is missing. " +
                "Copy ffmpeg.exe to the DHPG.exe directory and restart, or run from publish/ after dotnet publish.");
        }

        // ✅ 启动独立的健康检查后台任务
        _healthCheckTask = Task.Run(() => RecordingHealthCheckLoop(stoppingToken), stoppingToken);

        // ✅ 启动索引器任务（如果还没在其他地方启动）
        if (_indexerTask == null || _indexerTask.IsCompleted)
        {
            _indexerTask = Task.Run(() => IndexRecordingsAsync(stoppingToken), stoppingToken);
        }

        // 主循环 - 仅在上班会话期间自动启动/恢复录制
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var config = _currentPolicy?.GetRecordingConfig();

                if (config?.Enabled == true && _workSessionActive && !IsProcessAlive())
                {
                    _logger.LogDebug("Process not alive in main loop, attempting start during work session");
                    
                    // 检查是否已经有启动任务在进行
                    if (!await _processLock.WaitAsync(0))
                    {
                        _logger.LogDebug("Another start/restart is already in progress");
                    }
                    else
                    {
                        _processLock.Release();
                        await StartRecordingAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Recorder main loop error");
            }

            // 主循环间隔可以更长一些，因为健康检查循环会处理深度监控
            await Task.Delay(Constants.RecordingMainLoopIntervalMs, stoppingToken);
        }

        // 等待健康检查任务完成
        if (_healthCheckTask != null)
        {
            try { await _healthCheckTask.WaitAsync(TimeSpan.FromSeconds(5)); }
            catch { }
        }
    }

    public bool WorkSessionActive => _workSessionActive;

    public void StartRecording()
    {
        _workSessionActive = true;
        _ = StartRecordingAsync();
    }

    public void StopRecording()
    {
        _workSessionActive = false;
        _ = StopRecordingAsync();
    }

    #region 编码器检测与智能选择（保持原有代码不变）

    private void EnsureEncoderDetected()
    {
        if (_cachedEncoder != null && DateTime.UtcNow - _encoderCacheTime < TimeSpan.FromMinutes(10))
            return;

        if (!_encoderDetectionLock.Wait(TimeSpan.FromSeconds(30)))
        {
            _logger.LogWarning("Encoder detection lock timeout, using default encoder");
            _cachedEncoder ??= "libx264";
            return;
        }

        try
        {
            if (_cachedEncoder != null && DateTime.UtcNow - _encoderCacheTime < TimeSpan.FromMinutes(10))
                return;

            var ffmpeg = FindFfmpegCached();
            if (string.IsNullOrWhiteSpace(ffmpeg))
            {
                _cachedEncoder = "libx264";
                _logger.LogWarning("FFmpeg not found, defaulting to software encoder");
                return;
            }

            _cachedEncoder = DetectAvailableEncoder(ffmpeg);
            _encoderCacheTime = DateTime.UtcNow;
            _logger.LogInformation("Encoder detection completed: {Encoder}", _cachedEncoder);
        }
        finally
        {
            _encoderDetectionLock.Release();
        }
    }

    private string DetectAvailableEncoder(string ffmpeg)
    {
        try
        {
            var availableEncoders = GetAvailableEncoders(ffmpeg);

            if (availableEncoders.Contains("h264_nvenc"))
            {
                _logger.LogInformation("✅ NVENC encoder detected (NVIDIA GPU)");
                return "h264_nvenc";
            }

            if (availableEncoders.Contains("h264_qsv"))
            {
                _logger.LogInformation("✅ QSV encoder detected (Intel GPU)");
                return "h264_qsv";
            }

            if (availableEncoders.Contains("h264_amf"))
            {
                _logger.LogInformation("✅ AMF encoder detected (AMD GPU)");
                return "h264_amf";
            }

            _logger.LogInformation("⚠️ No hardware encoder detected, using software encoder (libx264)");
            return "libx264";
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to detect hardware encoders, falling back to software");
            return "libx264";
        }
    }

    private HashSet<string> GetAvailableEncoders(string ffmpeg)
    {
        var encoders = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        try
        {
            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffmpeg,
                    Arguments = "-encoders",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };

            process.Start();
            var output = process.StandardOutput.ReadToEnd();
            process.WaitForExit(5000);

            if (output.Contains("h264_nvenc", StringComparison.OrdinalIgnoreCase))
                encoders.Add("h264_nvenc");
            if (output.Contains("h264_qsv", StringComparison.OrdinalIgnoreCase))
                encoders.Add("h264_qsv");
            if (output.Contains("h264_amf", StringComparison.OrdinalIgnoreCase))
                encoders.Add("h264_amf");
            if (output.Contains("libx264", StringComparison.OrdinalIgnoreCase))
                encoders.Add("libx264");

            _logger.LogDebug("Detected encoders: {Encoders}", string.Join(", ", encoders));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to get encoder list");
        }

        if (!encoders.Contains("libx264"))
            encoders.Add("libx264");

        return encoders;
    }

    private string GetBestEncoder(bool gpuEnabled)
    {
        // ✅ 如果本次会话已标记 GPU 失败，直接返回软件编码
        if (_gpuDetectionFailedThisSession)
        {
            _logger.LogDebug("GPU disabled for this session, using software encoder");
            return "libx264";
        }

        if (_forceSoftwareEncoder)
        {
            _logger.LogDebug("Software encoder forced due to previous failures");
            return "libx264";
        }

        if (!gpuEnabled)
        {
            _logger.LogDebug("GPU encoding disabled by policy");
            return "libx264";
        }

        EnsureEncoderDetected();
        return _cachedEncoder ?? "libx264";
    }

    private string BuildNvencTestParams(RecordingConfig config)
    {
        var q = 5;
        var rcMode = config.UseNvencHq ? "vbr_hq" : "vbr";
        var preset = ValidatePreset(config.HardwareEncoderPreset,
            new[] { "p1", "p2", "p3", "p4", "p5", "p6", "p7" }, "p4");
        
        return $"-preset {preset} -rc {rcMode} -b:v {q}M -pix_fmt nv12";
    }

    private async Task<bool> ProbeEncoderAsync(string ffmpeg, string encoder, string? testParams = null)
    {
        const int timeoutSeconds = 10;
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(timeoutSeconds));
        
        string? testOutput = null;
        
        try
        {
            testOutput = Path.GetTempFileName() + ".mp4";
            
            // 构建参数（功能与第一个代码完全相同）
            var baseArgs = $"-f lavfi -i testsrc=duration=1:size=320x240:rate=10 -c:v {encoder}";
            var args = string.IsNullOrEmpty(testParams) 
                ? $"{baseArgs} -t 1 -y {testOutput}"
                : $"{baseArgs} {testParams} -t 1 -y {testOutput}";
            
            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffmpeg,
                    Arguments = args,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardError = true
                },
                EnableRaisingEvents = true  // 新增，但不影响原有功能
            };
            
            process.Start();
            
            try
            {
                await process.WaitForExitAsync(cts.Token);
            }
            catch (OperationCanceledException)
            {
                _logger.LogWarning("Encoder {Encoder} probe test timeout after {Timeout}s", encoder, timeoutSeconds);
                try { process.Kill(); } catch { }
                return false;
            }
            
            var success = process.ExitCode == 0 && File.Exists(testOutput);
            return success;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogDebug(ex, "Encoder {Encoder} probe test exception", encoder);
            return false;
        }
        finally
        {
            // 清理临时文件（功能与第一个代码相同）
            if (testOutput != null && File.Exists(testOutput))
            {
                try { File.Delete(testOutput); } catch { }
            }
        }
    }

    private async Task<string> GetAvailableEncoderWithProbeAsync(string ffmpeg, bool gpuEnabled, RecordingConfig config)
    {
        if (!gpuEnabled || _forceSoftwareEncoder)
            return "libx264";
        
        var availableEncoders = GetAvailableEncoders(ffmpeg);
        var priorityList = config.GetEncoderPriorityList();
        
        foreach (var encoder in priorityList)
        {
            if (encoder == "libx264")
                return "libx264";
            
            if (!availableEncoders.Contains(encoder))
                continue;
            
            if (!config.EnableEncoderPreCheck)
            {
                _logger.LogInformation("Using encoder {Encoder} (pre-check disabled)", encoder);
                return encoder;
            }
            
            var testParams = encoder switch
            {
                "h264_nvenc" => BuildNvencTestParams(config),
                "h264_qsv" => "-global_quality 25",
                "h264_amf" => "-quality speed",
                _ => null
            };
            
            var isAvailable = await ProbeEncoderAsync(ffmpeg, encoder, testParams);
            
            if (isAvailable)
            {
                _logger.LogInformation("Encoder {Encoder} probe test passed, using it", encoder);
                return encoder;
            }
            
            _logger.LogWarning("Encoder {Encoder} probe test failed, trying next encoder", encoder);
        }
        
        return "libx264";
    }

    private (string encoderArgs, (int width, int height) alignedResolution) BuildEncoderArgs(
        string encoder, int quality, int fps, (int width, int height) resolution, RecordingConfig config)
    {
        var alignedResolution = resolution;

        switch (encoder)
        {
            case "h264_nvenc":
                alignedResolution.width &= ~1;
                alignedResolution.height &= ~1;
                
                if (config.EnableNvenc32Align)
                {
                    alignedResolution.width = (alignedResolution.width + 31) & ~31;
                    alignedResolution.height = (alignedResolution.height + 31) & ~31;
                }
                
                var fpsMultiplier = Math.Clamp(fps / 10.0, 0.8, 3.0);
                var baseBitrate = quality switch
                {
                    <= 30 => 2,
                    <= 60 => 5,
                    _ => 8
                };
                var q = (int)(baseBitrate * fpsMultiplier);
                q = Math.Clamp(q, 2, 20);
                
                var bitrate = $"{q}M";
                var maxrate = $"{Math.Min(q + 3, 25)}M";
                var bufsize = $"{Math.Min(q * 2, 30)}M";
                
                var rcMode = config.UseNvencHq ? "vbr_hq" : "vbr";
                
                var preset = ValidatePreset(config.HardwareEncoderPreset,
                    new[] { "p1", "p2", "p3", "p4", "p5", "p6", "p7" }, "p4");
                
                var pixFmt = _needPixelFormatFallback ? "yuv420p" : "nv12";
                
                var args = string.Join(" ", new[]
                {
                    "-c:v h264_nvenc",
                    $"-preset {preset}",
                    $"-rc {rcMode}",
                    $"-b:v {bitrate}",
                    $"-maxrate {maxrate}",
                    $"-bufsize {bufsize}",
                    $"-pix_fmt {pixFmt}"
                });
                
                _logger.LogDebug("NVENC parameters: {Args} (fps: {Fps}, quality: {Quality}, pix_fmt: {PixFmt})", 
                    args, fps, quality, pixFmt);
                
                return (args, alignedResolution);

            case "h264_qsv":
                var qsvQuality = quality switch
                {
                    <= 30 => 35,
                    <= 60 => 28,
                    _ => 23
                };
                var qsvPreset = ValidatePreset(config.HardwareEncoderPreset,
                    new[] { "veryfast", "medium", "slow" }, "veryfast");
                return ($"-c:v h264_qsv -preset {qsvPreset} -global_quality {qsvQuality} -pix_fmt nv12", alignedResolution);

            case "h264_amf":
                var amfQuality = quality switch
                {
                    <= 30 => 35,
                    <= 60 => 28,
                    _ => 23
                };
                var amfPreset = ValidatePreset(config.HardwareEncoderPreset,
                    new[] { "speed", "quality" }, "speed");
                return ($"-c:v h264_amf -quality {amfPreset} -rc cqp -qp_i {amfQuality} -qp_p {amfQuality}", alignedResolution);

            default:
                var crf = Math.Clamp(51 - (int)(quality / 100.0 * 28), 18, 51);
                var swPreset = ValidatePreset(config.SoftwareEncoderPreset,
                    new[] { "ultrafast", "veryfast", "fast", "medium", "slow", "slower" }, "veryfast");
                return ($"-c:v libx264 -preset {swPreset} -crf {crf} -pix_fmt yuv420p", alignedResolution);
        }
    }

    private string ValidatePreset(string preset, string[] validPresets, string defaultPreset)
    {
        if (string.IsNullOrWhiteSpace(preset))
            return defaultPreset;
        
        return validPresets.Contains(preset, StringComparer.OrdinalIgnoreCase) 
            ? preset.ToLowerInvariant() 
            : defaultPreset;
    }

    private bool IsEncoderError(string line)
    {
        var lowerLine = line.ToLowerInvariant();
        return (lowerLine.Contains("encoder") || lowerLine.Contains("nvenc") ||
                lowerLine.Contains("qsv") || lowerLine.Contains("amf")) &&
               (lowerLine.Contains("error") || lowerLine.Contains("failed") ||
                lowerLine.Contains("unsupported") || lowerLine.Contains("invalid"));
    }

    private async Task CheckEncoderHealthAsync()
    {
        if (_currentEncoder == "libx264") return;

        if (_hasEncoderError)
        {
            _encoderFailureCount++;
            _logger.LogWarning("Encoder {Encoder} failure {Count}/{Max}",
                _currentEncoder, _encoderFailureCount, MaxEncoderFailures);

            _hasEncoderError = false;

            if (_encoderFailureCount >= MaxEncoderFailures)
            {
                _logger.LogError("Encoder {Encoder} failed repeatedly, falling back to software encoding",
                    _currentEncoder);

                _forceSoftwareEncoder = true;
                _currentEncoder = "libx264";
                _encoderFailureCount = 0;
                _lastEncoderSwitchTime = DateTime.UtcNow;

                await RestartRecordingAsync();
            }
        }
        else if (_encoderFailureCount > 0)
        {
            _encoderFailureCount--;
            _logger.LogDebug("Encoder {Encoder} recovered, failure count: {Count}",
                _currentEncoder, _encoderFailureCount);
        }
    }

    #endregion

    private async Task StartRecordingAsync()
    {
        if ((DateTime.UtcNow - _lastResumeTime).TotalSeconds < 10)
        {
            _logger.LogDebug("System recently resumed, waiting 3 seconds before starting recording");
            await Task.Delay(3000);
        }

        if (!await _processLock.WaitAsync(0))
        {
            _logger.LogDebug("StartRecording already in progress");
            return;
        }

        try
        {
            _isStopping = false;

            if (IsProcessAlive()) return;
            if (!CanStartRecording()) return;
            if (!HasEnoughDiskSpace())
            {
                _logger.LogError("Insufficient disk space");
                return;
            }

            await CleanupProcessAsync();

            var ffmpeg = FindFfmpegCached();
            if (string.IsNullOrWhiteSpace(ffmpeg))
            {
                _logger.LogError("FFmpeg not found");
                _consecutiveFailures++;
                return;
            }

            var config = _currentPolicy?.GetRecordingConfig() ?? new RecordingConfig();
            var fps = Math.Clamp(config.Fps, 1, 30);
            var sliceSeconds = Math.Max(config.GetSliceSeconds(), Constants.MinSliceSeconds);
            var resolution = GetResolution(config.Resolution);

            // ========== ✅ 每次启动时检测一次 GPU 编码器 ==========
            string newEncoder;

            // 如果本次运行已经检测过且失败了，直接使用软件编码
            if (_gpuDetectionFailedThisSession)
            {
                _logger.LogInformation("GPU encoder detection failed earlier this session, using software encoder (libx264)");
                newEncoder = "libx264";
            }
            else
            {
                // 首次启动时检测
                bool gpuRequested = config.EnableGpu && !_forceSoftwareEncoder;
                
                if (gpuRequested && config.EnableEncoderPreCheck)
                {
                    _logger.LogInformation("🔍 Probing GPU encoder availability...");
                    newEncoder = await GetAvailableEncoderWithProbeAsync(ffmpeg, true, config);
                    
                    // 如果检测失败，记录本次会话不再尝试
                    if (newEncoder == "libx264" && gpuRequested)
                    {
                        _gpuDetectionFailedThisSession = true;
                        _logger.LogWarning("❌ GPU encoder probe failed, will use software encoder for this session. Restart client to retry GPU.");
                    }
                }
                else
                {
                    newEncoder = GetBestEncoder(gpuRequested);
                    if (newEncoder == "libx264" && gpuRequested)
                    {
                        _gpuDetectionFailedThisSession = true;
                        _logger.LogWarning("❌ No GPU encoder available, will use software encoder for this session. Restart client to retry GPU.");
                    }
                }
            }

            if (_currentEncoder != newEncoder)
            {
                _logger.LogInformation("Encoder switching: {OldEncoder} -> {NewEncoder}",
                    _currentEncoder, newEncoder);
                _lastEncoderSwitchTime = DateTime.UtcNow;
                _currentEncoder = newEncoder;
            }

            var (encoderArgs, alignedResolution) = BuildEncoderArgs(_currentEncoder, config.Quality, fps, resolution, config);

            var recordingsDir = Path.Combine(_config.GetEffectiveStoragePath(), "recordings");
            Directory.CreateDirectory(recordingsDir);

            var localNow = DateTime.Now;
            var dateDir = Path.Combine(recordingsDir, localNow.ToLocalDateDirectory());
            Directory.CreateDirectory(dateDir);

            var testFile = Path.Combine(dateDir, ".write_test_" + Guid.NewGuid().ToString("N"));
            try
            {
                await File.WriteAllTextAsync(testFile, "test");
                File.Delete(testFile);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Recording directory not writable: {Directory}", dateDir);
                throw;
            }

            var outputPattern = Path.Combine(dateDir, $"{DateTime.UtcNow:yyyy-MM-dd_HH-mm-ss}_%03d.mp4");

            var args = $"-hide_banner -loglevel warning " +
                       $"-f gdigrab -framerate {fps} -i desktop " +
                       $"-vf \"fps={fps},scale={alignedResolution.width}:{alignedResolution.height}\" " +
                       $"{encoderArgs} " +
                       $"-movflags +faststart " +
                       $"-f segment " +
                       $"-segment_time {sliceSeconds} " +
                       $"-reset_timestamps 1 " +
                       $"\"{outputPattern}\"";

            _logger.LogInformation("=== Recording Configuration ===");
            _logger.LogInformation("Resolution: {Width}x{Height}", alignedResolution.width, alignedResolution.height);
            _logger.LogInformation("FPS: {Fps}, Quality: {Quality}, Slice: {Slice}s", fps, config.Quality, sliceSeconds);
            _logger.LogInformation("FFmpeg args: {Args}", args);

            _ffmpegProcess = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffmpeg,
                    Arguments = args,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardError = true,
                    RedirectStandardOutput = true
                },
                EnableRaisingEvents = true
            };

            _ffmpegExitedHandler = async (s, e) => await OnFfmpegExitedAsync();
            _ffmpegProcess.Exited += _ffmpegExitedHandler;

            if (!_ffmpegProcess.Start())
            {
                _logger.LogError("Failed to start FFmpeg");
                _consecutiveFailures++;
                await CleanupProcessAsync();
                return;
            }

            try { _recordingCts?.Cancel(); } catch { }
            _recordingCts?.Dispose();
            _recordingCts = new CancellationTokenSource();

            _ffmpegOutputTask = Task.Run(() => LogFfmpegOutputAsync(_ffmpegProcess));
            if (_healthMonitorTask == null || _healthMonitorTask.IsCompleted)
            {
                _healthMonitorTask = Task.Run(() => MonitorRecordingHealthAsync(_recordingCts.Token));
            }
            _indexerTask = Task.Run(() => IndexRecordingsAsync(_recordingCts.Token));

            RegisterRestart();

            _consecutiveFailures = 0;
            _lastSuccessfulFrame = DateTime.UtcNow;
            _lastObservedFileSize = 0;
            _hasEncoderError = false;

            _logger.LogInformation("Recording started successfully!");
        }
        catch (Exception ex)
        {
            _consecutiveFailures++;
            _logger.LogError(ex, "Failed starting recording");
            await CleanupProcessAsync();
        }
        finally
        {
            _processLock.Release();
        }
    }

    private async Task OnFfmpegExitedAsync()
    {
        try
        {
            var exitCode = _ffmpegProcess?.ExitCode ?? -1;
            _logger.LogInformation(
                exitCode == 0
                    ? "✓ FFmpeg exited normally"
                    : "❌ FFmpeg exited with code {ExitCode}",
                exitCode
            );

            // ========== 处理编码器失败 ==========
            // ========== 运行时编码器失败处理 ==========
            if (exitCode != 0 && _currentEncoder != "libx264")
            {
                _logger.LogWarning(
                    "⚠️ Hardware encoder {Encoder} failed at runtime (exit code: {ExitCode}), switching to software encoder for this session",
                    _currentEncoder,
                    exitCode
                );

                // ✅ 运行时失败：切换到软件编码，并标记本次会话不再尝试 GPU
                _gpuDetectionFailedThisSession = true;
                _currentEncoder = "libx264";
                
                _logger.LogWarning("✅ GPU encoding disabled for this session. Restart client to retry GPU.");
            }
            else if (exitCode == 0 && _encoderFailureCount > 0)
            {
                _encoderFailureCount--;
                _logger.LogDebug("✓ Encoder recovered, failure count: {Count}", _encoderFailureCount);
            }

            // ========== 清理进程并决定是否重启 ==========
            bool shouldRestart = false;
            // ✅ 添加超时
            if (!await _processLock.WaitAsync(TimeSpan.FromSeconds(10)))
            {
                _logger.LogWarning("Could not acquire process lock in exit handler");
                return;
            }
            
            try
            {
                if (_ffmpegProcess != null)
                {
                    _ffmpegProcess.Dispose();
                    _ffmpegProcess = null;
                }

                var config = _currentPolicy?.GetRecordingConfig();
                // 只在非故意停止且录制启用时才重启
                shouldRestart = !_isStopping && exitCode != 0 && (config?.Enabled == true);
            }
            finally
            {
                _processLock.Release();
            }

            // ========== 有延迟地重启 ==========
            if (shouldRestart)
            {
                var delay = 2000;
                _logger.LogInformation(
                    "Restarting recording in {Delay}ms (Encoder: {Encoder}, Retries: {Count})",
                    delay, _currentEncoder, _encoderFailureCount);

                await Task.Delay(delay);

                if (_isStopping)
                {
                    _logger.LogDebug("Skip recording restart during shutdown");
                    return;
                }

                await RestartEngineAsync(RestartMode.Full, "FFmpeg exited with code " + exitCode);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ FFmpeg exit handler failed");
        }
    }

    private static async Task SafeWaitTaskAsync(Task? task)
    {
        if (task == null) return;
        try { await task.WaitAsync(TimeSpan.FromSeconds(3)); }
        catch { }
    }

    /// <summary>
    /// 健康监控循环 - V7版（三信号融合，不再误判）
    /// </summary>
   /// <summary>
    /// 健康监控循环 - V7版（三信号融合，不再误判）
    /// </summary>
    private async Task MonitorRecordingHealthAsync(CancellationToken ct)
    {
        // 等待录制稳定后再开始监控
        await Task.Delay(TimeSpan.FromSeconds(60), ct);
        
        // ✅ 添加启动日志
        _logger.LogInformation("🟢 Health monitoring started (V7 three-signal mode)");
        
        while (!ct.IsCancellationRequested)
        {
            await Task.Delay(TimeSpan.FromSeconds(30), ct);

            var now = DateTime.UtcNow;

            // 提前读取配置阈值，避免在后面使用前未声明
            var fileRecentSeconds = _config?.RecordingHealth?.FileRecentSeconds ?? 120;

            // ========== 1. 进程存活检查（优先级最高） ==========
            var processAlive = IsProcessAlive();
            if (!processAlive)
            {
                _logger.LogWarning("❌ FFmpeg process dead, restarting...");
                await RestartEngineAsync(RestartMode.Full, "PROCESS_DEAD");
                continue;
            }

            await CheckEncoderHealthAsync();

            // ========== 2. 获取文件活动与增长状态 ==========
            var effectiveStoragePath = _config?.GetEffectiveStoragePath();
            bool fileRecent = false;
            bool fileGrowing = false;
            DateTime? latestFileTime = null;
            long latestFileSize = 0;

            var fileAlive = false;

            if (!string.IsNullOrEmpty(effectiveStoragePath))
            {
                var recordingsPath = Path.Combine(effectiveStoragePath, "recordings");
                if (Directory.Exists(recordingsPath))
                {
                    var latestFile = Directory.EnumerateFiles(recordingsPath, "*.mp4", SearchOption.AllDirectories)
                        .Select(f => new FileInfo(f))
                        .OrderByDescending(f => f.LastWriteTimeUtc)
                        .FirstOrDefault();

                    if (latestFile != null)
                    {
                        latestFileTime = latestFile.LastWriteTimeUtc;
                        latestFileSize = latestFile.Length;
                        var fileAge = now - latestFile.LastWriteTimeUtc;
                        var fileAliveThresholdSeconds = _config?.RecordingHealth?.FileAliveThresholdSeconds ?? 120;
                        fileRecent = fileAge < TimeSpan.FromSeconds(fileAliveThresholdSeconds);

                        // 文件增长检测：与上次观察到的大小比较
                        try
                        {
                            fileGrowing = latestFileSize > _lastObservedFileSize;
                        }
                        catch (Exception ex)
                        {
                            _logger.LogDebug(ex, "Failed to compute file growth");
                        }

                        fileAlive = fileGrowing;
                        if (fileAlive)
                        {
                            _lastFileActivity = now;
                        }

                        // 更新全局观察大小为当前文件大小（供下一次比较）
                        _lastObservedFileSize = latestFileSize;
                    }
                }
            }

                // ========== 3. 编码器心跳检查 ==========
                var encoderHeartbeatAge = (now - _lastEncoderHeartbeat).TotalSeconds;
                var encoderAliveThreshold = _config?.RecordingHealth?.EncoderAliveThresholdSeconds ?? 120;
                var encoderStaleThreshold = _config?.RecordingHealth?.EncoderStaleThresholdSeconds ?? 120;

                var encoderAlive = encoderHeartbeatAge < encoderAliveThreshold;      // 健康阈值
                var encoderStale = encoderHeartbeatAge >= encoderStaleThreshold;     // 明确失效阈值

            // ========== 4. 分层健康判定 ==========
            // Healthy: 进程存活且（心跳活跃 或 文件活跃）
            var isHealthy = processAlive && (encoderAlive || fileAlive);

            if (isHealthy)
            {
                _lastSuccessfulFrame = now;
            }

            // ✅ 只在状态不健康时输出 Warning，健康时输出 Debug
            if (isHealthy)
            {
                    _logger.LogDebug(
                        "💓 Health check | processAlive={ProcessAlive}, fileRecent={FileRecent}, fileGrowing={FileGrowing}, encoderAlive={EncoderAlive}, healthy=true",
                        processAlive, fileRecent, fileGrowing, encoderAlive);
            }
            else
            {
                    _logger.LogWarning(
                        "❗ Health check | processAlive={ProcessAlive}, fileRecent={FileRecent}, fileGrowing={FileGrowing}, encoderAlive={EncoderAlive}, healthy=false, stall={StallTime:F0}s",
                        processAlive, fileRecent, fileGrowing, encoderAlive, (now - _lastSuccessfulFrame).TotalSeconds);
            }

            // ========== 5. 判定与修复策略 ==========
            var stallTime = now - _lastSuccessfulFrame;

            if (processAlive && encoderStale && !fileGrowing)
            {
                _logger.LogWarning(
                    "❗ Recording unhealthy: processAlive={ProcessAlive}, encoderStale={EncoderStale}, fileGrowing={FileGrowing}, fileRecent={FileRecent}, encoderAlive={EncoderAlive}, heartbeat={HeartbeatAge:F0}s",
                    processAlive, encoderStale, fileGrowing, fileRecent, encoderAlive, encoderHeartbeatAge);

                await RestartEngineAsync(RestartMode.Full, "ENCODER_STALE_AND_NO_FILE_GROWTH");
                continue;
            }

            if (stallTime > TimeSpan.FromSeconds(Constants.RecordingStallTimeoutSeconds))
            {
                string reason;

                if (!processAlive)
                    reason = "PROCESS_DEAD";
                else if (encoderStale && !fileGrowing && !fileRecent)
                    reason = "NO_ENCODER_HEARTBEAT_AND_NO_FILE_ACTIVITY";
                else if (encoderStale && !fileGrowing)
                    reason = "NO_ENCODER_HEARTBEAT";
                else
                    reason = "NO_FILE_ACTIVITY";

                _logger.LogWarning(
                    "🔴 Recording stalled: {Reason}, stall={StallTime}s, fileRecent={FileRecent}, fileGrowing={FileGrowing}, encoderAlive={EncoderAlive}",
                    reason, stallTime.TotalSeconds, fileRecent, fileGrowing, encoderAlive);

                await RestartEngineAsync(RestartMode.Full, reason);
                continue;
            }
        }
    }

    private async Task RestartRecordingAsync()
    {
        // ✅ 修复：防止重启风暴
        await RestartEngineAsync(RestartMode.Full, "Legacy restart call");

        _lastRestartAttempt = DateTime.UtcNow;
      

        try
        {
            await StopRecordingAsync();
            await Task.Delay(2000);
            await StartRecordingAsync();
            _consecutiveFailures = 0;
            _logger.LogInformation("✓ Recording restart completed");
        }
        catch (Exception ex)
        {
            _consecutiveFailures++;
            _logger.LogError(ex, "❌ Recording restart failed (consecutive failures: {Count})", _consecutiveFailures);
        }
    }

    private async Task StopRecordingAsync()
    {
        if (!await _processLock.WaitAsync(TimeSpan.FromSeconds(10)))
        {
            _logger.LogWarning("Could not acquire process lock for stop");
            return;
        }

        try
        {
            _isStopping = true;
            _recordingCts?.Cancel();
            await CleanupProcessAsync();
            _logger.LogInformation("Recording stopped");
        }
        finally
        {
            _processLock.Release();
        }
    }

    private async Task IndexRecordingsAsync(CancellationToken ct)
    {
        if (Interlocked.Exchange(ref _isIndexing, 1) == 1)
        {
            _logger.LogDebug("Indexing already in progress, skipping");
            return;
        }

        try
        {
            var indexedFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            while (!ct.IsCancellationRequested)
            {
                try
                {
                    var recordingsPath = Path.Combine(_config.GetEffectiveStoragePath(), "recordings");

                    _lastFileActivity = DateTime.UtcNow;

                    if (!Directory.Exists(recordingsPath))
                    {
                        await Task.Delay(5000, ct);
                        continue;
                    }

                    if (_logger.IsEnabled(LogLevel.Debug))
                    {
                        var allMp4Files = Directory.EnumerateFiles(recordingsPath, "*.mp4", SearchOption.AllDirectories).ToList();
                        _logger.LogDebug("Total MP4 files in directory: {Count}", allMp4Files.Count);
                    }

                    var files = Directory.EnumerateFiles(recordingsPath, "*.mp4", SearchOption.AllDirectories)
                        .Select(path => new FileInfo(path))
                        .OrderBy(f => f.LastWriteTimeUtc)
                        .ToList();

                    if (files.Count > 0)
                    {
                            _logger.LogInformation("Indexing {Count} recording files", files.Count);
                            _logger.LogDebug("Recordings path: {Path}", recordingsPath);
                    }
                    else
                    {
                            _logger.LogDebug("Index scan: no new recordings");
                    }

                    _logger.LogInformation("Files to process (all mp4 files): {Count}", files.Count);

                    foreach (var file in files)
                    {
                        ct.ThrowIfCancellationRequested();

                        if (file.Length <= Constants.MinRecordingFileBytes)
                        {
                            _logger.LogDebug("Skipping tiny/incomplete recording: {FileName} ({Size} bytes)",
                                file.Name, file.Length);
                            continue;
                        }

                        if (indexedFiles.Contains(file.FullName))
                        {
                            _logger.LogDebug("Skipping already indexed file: {FileName}", file.FullName);
                            continue;
                        }

                        var existing = await GetRecordingByFilePathAsync(file.FullName);
                        if (existing != null)
                        {
                            if (existing.FileSize > Constants.MinRecordingFileBytes)
                            {
                                _logger.LogDebug("Skipping already indexed file by path: {FileName}", file.FullName);
                                indexedFiles.Add(file.FullName);
                                continue;
                            }

                            if (!await IsFileReadyAsync(file.FullName, ct))
                            {
                                _logger.LogDebug("Existing stub record not ready for refresh: {FileName}", file.FullName);
                                continue;
                            }

                            var refreshed = ParseRecordingFromFile(file.FullName);
                            if (refreshed == null)
                                continue;

                            refreshed.FileSize = file.Length;
                            refreshed.Sha256 = await ComputeSha256Async(file.FullName, ct);
                            await UpdateRecordingMetadataAsync(existing.Id, refreshed.FileSize, refreshed.Sha256, refreshed.StartTime, refreshed.EndTime);
                            indexedFiles.Add(file.FullName);
                            _logger.LogInformation("Refreshed recording metadata: {FileName} ({Size} bytes)",
                                file.Name, file.Length);
                            continue;
                        }

                        if (!await IsFileReadyAsync(file.FullName, ct))
                        {
                            _logger.LogDebug("File not ready: {FileName}", file.FullName);
                            continue;
                        }

                        var recording = ParseRecordingFromFile(file.FullName);
                        if (recording == null)
                        {
                            _logger.LogWarning("Failed to parse recording from file: {FileName}", file.FullName);
                            continue;
                        }

                        _logger.LogInformation("Parsed recording: {FileName} -> StartTime: {StartTime}, EndTime: {EndTime}",
                            Path.GetFileName(file.FullName),
                            recording.StartTime.ToString("yyyy-MM-dd HH:mm:ss"),
                            recording.EndTime.ToString("yyyy-MM-dd HH:mm:ss"));

                        recording.FileSize = file.Length;
                        recording.Sha256 = await ComputeSha256Async(file.FullName, ct);

                        await AddRecordingAsync(recording);

                        // 如果需要上传，取消注释
                        // await QueueRecordingForUploadAsync(recording, ct);

                        indexedFiles.Add(file.FullName);
                        _lastIndexedWriteTimeUtc = file.LastWriteTimeUtc;

                        _logger.LogInformation("Successfully indexed recording: {FileName}", Path.GetFileName(file.FullName));
                    }

                    if (indexedFiles.Count > 10000)
                    {
                        _logger.LogInformation("Cleaning indexed files cache (size: {Count})", indexedFiles.Count);
                        indexedFiles.Clear();
                    }
                }
                catch (OperationCanceledException)
                {
                    _logger.LogDebug("Indexing cancelled");
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Recording indexer failed");
                    await Task.Delay(5000, ct);
                }

                await Task.Delay(10000, ct);
            }
        }
        finally
        {
            Interlocked.Exchange(ref _isIndexing, 0);
            _logger.LogDebug("Indexing lock released");
        }
    }

    // ✅ 新增方法：将录屏入队上传（带时间）
    private async Task QueueRecordingForUploadAsync(Recording recording, CancellationToken ct)
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var uploader = scope.ServiceProvider.GetRequiredService<FileUploadService>();
            
            // 创建带时间的上传队列项
            var queueItem = new UploadQueue
            {
                Id = Guid.NewGuid().ToString(),
                FilePath = recording.FilePath,
                FileType = "recording",
                FileId = recording.Id,
                Status = "pending",
                Offset = 0,
                RetryCount = 0,
                CreatedAt = DateTime.UtcNow,
                RecordStartTime = recording.StartTime,  // ✅ 传递开始时间
                RecordEndTime = recording.EndTime       // ✅ 传递结束时间
            };
            
            // 调用新的入队方法
            await uploader.QueueFileWithTimeAsync(queueItem);
            
            _logger.LogDebug("Queued recording for upload: {FilePath}, StartTime: {StartTime}, EndTime: {EndTime}", 
                Path.GetFileName(recording.FilePath), recording.StartTime, recording.EndTime);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to queue recording for upload: {FilePath}", recording.FilePath);
            // 不抛出异常，避免影响索引流程
        }
    }

    private async Task LogFfmpegOutputAsync(Process process)
    {
        try
        {
            var stderrTimeoutSeconds = _config?.RecordingHealth?.StderrReadTimeoutSeconds ?? 90;
            var stderrTimeoutKillThreshold = _config?.RecordingHealth?.StderrTimeoutKillThreshold ?? 3;
            int consecutiveTimeouts = 0;

            while (true)
            {
                CancellationToken ct = _recordingCts?.Token ?? CancellationToken.None;

                bool processExited;
                try
                {
                    processExited = process.HasExited;
                }
                catch (InvalidOperationException)
                {
                    _logger.LogDebug("FFmpeg process handle released, stopping stderr log reader");
                    break;
                }

                if (processExited)
                {
                    _logger.LogDebug("FFmpeg process has exited, stopping stderr log reader");
                    break;
                }

                var readTask = process.StandardError.ReadLineAsync();
                var delayTask = Task.Delay(TimeSpan.FromSeconds(stderrTimeoutSeconds), ct);

                var completed = await Task.WhenAny(readTask, delayTask);

                if (completed != readTask)
                {
                    consecutiveTimeouts++;
                    _logger.LogWarning("FFmpeg stderr read timeout {Count}/{Threshold} (seconds: {Seconds})", consecutiveTimeouts, stderrTimeoutKillThreshold, stderrTimeoutSeconds);

                    // 必须等待进行中的 ReadLineAsync 结束，否则下次读取会抛 InvalidOperationException
                    try { await readTask.ConfigureAwait(false); }
                    catch (ObjectDisposedException) { break; }
                    catch (IOException ex) { _logger.LogDebug(ex, "FFmpeg stderr read ended after timeout"); }
                    catch (InvalidOperationException ex) { _logger.LogDebug(ex, "FFmpeg stderr read ended after timeout"); }

                    if (ct.IsCancellationRequested || process.HasExited)
                        break;

                    if (consecutiveTimeouts >= stderrTimeoutKillThreshold)
                    {
                        try
                        {
                            if (!process.HasExited)
                            {
                                _logger.LogError("FFmpeg stderr read timed out repeatedly, killing process (PID: {Pid})", process.Id);
                                process.Kill(entireProcessTree: true);
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Failed to kill ffmpeg after stderr timeouts");
                        }

                        break;
                    }

                    await Task.Delay(TimeSpan.FromSeconds(1), ct);
                    continue;
                }

                string? line;
                try
                {
                    line = await readTask.ConfigureAwait(false);
                }
                catch (ObjectDisposedException)
                {
                    break;
                }
                catch (IOException ex)
                {
                    _logger.LogDebug(ex, "FFmpeg stderr read failed");
                    break;
                }
                catch (InvalidOperationException ex)
                {
                    _logger.LogDebug(ex, "FFmpeg stderr read failed");
                    break;
                }

                if (line == null)
                    break;

                consecutiveTimeouts = 0;

                if (string.IsNullOrWhiteSpace(line)) continue;

                _lastEncoderHeartbeat = DateTime.UtcNow;

                if (line.Contains("frame=", StringComparison.OrdinalIgnoreCase))
                {
                    Interlocked.Increment(ref _frameCount);
                    _logger.LogDebug("FFmpeg frame output received (total: {FrameCount})", _frameCount);
                }

                if (line.Contains("pixel format", StringComparison.OrdinalIgnoreCase) ||
                    line.Contains("pix_fmt", StringComparison.OrdinalIgnoreCase))
                {
                    _needPixelFormatFallback = true;
                    _logger.LogWarning("Pixel format error detected, will retry with yuv420p");
                }

                if (IsEncoderError(line))
                {
                    _hasEncoderError = true;
                    _logger.LogWarning("FFmpeg encoder error: {Line}", SensitiveDataFilter.FilterStatic(line));
                }
                else if (line.Contains("error", StringComparison.OrdinalIgnoreCase))
                {
                    _logger.LogWarning("FFmpeg error: {Line}", SensitiveDataFilter.FilterStatic(line));
                }
                else
                {
                    _logger.LogDebug("FFmpeg: {Line}", line);
                }
            }
        }
        catch (OperationCanceledException) { }
        catch (ObjectDisposedException) { }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FFmpeg log reader failed");
        }
    }

    private static async Task<bool> IsFileReadyAsync(string filePath, CancellationToken ct)
    {
        const int maxAttempts = 20;
        const int delayMs = 500;
        long lastLength = -1;
        var stableReads = 0;

        for (int attempt = 1; attempt <= maxAttempts; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            if (!File.Exists(filePath)) return false;

            try
            {
                using var fs = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
                var length = fs.Length;
                if (length <= Constants.MinRecordingFileBytes)
                {
                    lastLength = length;
                    stableReads = 0;
                    await Task.Delay(delayMs, ct);
                    continue;
                }

                if (length == lastLength)
                    stableReads++;
                else
                    stableReads = 0;

                lastLength = length;
                if (stableReads >= 1)
                    return true;
            }
            catch (IOException) when (attempt < maxAttempts)
            {
                await Task.Delay(delayMs, ct);
            }
            catch (UnauthorizedAccessException) when (attempt < maxAttempts)
            {
                await Task.Delay(delayMs, ct);
            }

            await Task.Delay(delayMs, ct);
        }

        return false;
    }

    private static async Task<string> ComputeSha256Async(string path, CancellationToken ct)
    {
        const int maxAttempts = 8;
        const int delayMs = 500;

        for (int attempt = 1; attempt <= maxAttempts; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 81920, true);
                var hash = await SHA256.HashDataAsync(stream, ct);
                return Convert.ToHexString(hash).ToLowerInvariant();
            }
            catch (IOException) when (attempt < maxAttempts)
            {
                await Task.Delay(delayMs, ct);
            }
            catch (UnauthorizedAccessException) when (attempt < maxAttempts)
            {
                await Task.Delay(delayMs, ct);
            }
        }

        // Let any final failure propagate if still locked after retries.
        await using var finalStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 81920, true);
        var finalHash = await SHA256.HashDataAsync(finalStream, ct);
        return Convert.ToHexString(finalHash).ToLowerInvariant();
    }

    private Recording? ParseRecordingFromFile(string file)
    {
        try
        {
            var config = _currentPolicy?.GetRecordingConfig() ?? new RecordingConfig();
            var sliceSeconds = config.GetSliceSeconds();

            if (RecordingTimeParser.TryParse(file, sliceSeconds, out var utcStartTime, out var utcEndTime))
            {
                _logger.LogDebug(
                    "Parsed recording: {File} -> Start: {StartTime} UTC, End: {EndTime} UTC",
                    Path.GetFileName(file), utcStartTime, utcEndTime);

                return new Recording
                {
                    DeviceId = DeviceId,
                    StartTime = utcStartTime,
                    EndTime = utcEndTime,
                    FilePath = file,
                    Uploaded = false
                };
            }

            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Parse failed for file: {File}", file);
            return null;
        }
    }

    private async Task AddRecordingAsync(Recording recording)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();
        await repo.AddAsync(recording);
    }

    private async Task<Recording?> GetRecordingByFilePathAsync(string filePath)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();
        return await repo.GetByFilePathAsync(filePath);
    }

    private async Task UpdateRecordingMetadataAsync(string id, long fileSize, string sha256, DateTime startTime, DateTime endTime)
    {
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<RecordingRepository>();
        await repo.UpdateMetadataAsync(id, fileSize, sha256, startTime, endTime);
    }

    private string GetInputSource() => "gdigrab";

    private (int width, int height) GetDisplaySize()
    {
        if (_cachedDisplaySize.HasValue && DateTime.UtcNow - _displaySizeCacheTime < TimeSpan.FromSeconds(30))
            return _cachedDisplaySize.Value;

        try
        {
            var width = GetSystemMetrics(SM_CXSCREEN);
            var height = GetSystemMetrics(SM_CYSCREEN);
            if (width > 0 && height > 0)
            {
                _cachedDisplaySize = (width, height);
                _displaySizeCacheTime = DateTime.UtcNow;
                return (width, height);
            }
        }
        catch { }
        return (1920, 1080);
    }

    private (int width, int height) GetResolution(string? resolution)
    {
        var (width, height) = ParseResolutionString(resolution);
        var screen = GetDisplaySize();
        
        width = Math.Min(width, screen.width);
        height = Math.Min(height, screen.height);
        
        const int MAX_WIDTH = 1920;
        const int MAX_HEIGHT = 1080;
        width = Math.Min(width, MAX_WIDTH);
        height = Math.Min(height, MAX_HEIGHT);
        
        width = Math.Max(width, 640);
        height = Math.Max(height, 480);
        
        width &= ~1;
        height &= ~1;
        
        if (width <= 0 || height <= 0)
        {
            _logger.LogWarning("Invalid resolution, falling back to 1280x720");
            return (1280, 720);
        }
        
        _logger.LogDebug("Base resolution: {Width}x{Height}", width, height);
        return (width, height);
    }

    private (int width, int height) ParseResolutionString(string? resolution)
    {
        const int DEFAULT_WIDTH = 1920;
        const int DEFAULT_HEIGHT = 1080;

        if (string.IsNullOrWhiteSpace(resolution))
            return (DEFAULT_WIDTH, DEFAULT_HEIGHT);

        var parts = resolution.Trim()
            .ToLowerInvariant()
            .Split(new[] { 'x', '*', '×' }, StringSplitOptions.RemoveEmptyEntries);

        if (parts.Length != 2)
            return (DEFAULT_WIDTH, DEFAULT_HEIGHT);

        int.TryParse(parts[0], out var w);
        int.TryParse(parts[1], out var h);

        if (w <= 0) w = DEFAULT_WIDTH;
        if (h <= 0) h = DEFAULT_HEIGHT;

        return (w, h);
    }

    private bool CanStartRecording()
    {
        var now = DateTime.UtcNow;

        // =========================================================
        // 1️⃣ 软件编码器模式（libx264）
        // =========================================================
        if (_forceSoftwareEncoder || _currentEncoder == "libx264")
        {
            // ❌ 连续失败保护（硬停止）
            if (_consecutiveFailures >= 10)
            {
                _logger.LogError(
                    "Software encoder failed 10 times consecutively, stopping retries");

                return false;
            }

            // ⏳ 软件编码器冷却（防抖）
            if (now - _lastRestartAttempt < TimeSpan.FromSeconds(3))
            {
                _logger.LogDebug("Software encoder restart throttled (3s cooldown)");
                return false;
            }

            _lastRestartAttempt = now;
            return true;
        }

        // =========================================================
        // 2️⃣ 清理过期 restart 记录（5分钟窗口）
        // =========================================================
        while (_restartHistory.Count > 0 &&
               now - _restartHistory.Peek() > TimeSpan.FromMinutes(5))
        {
            _restartHistory.Dequeue();
        }

        // =========================================================
        // 3️⃣ 硬件编码器失败过多 → 降级软件
        // =========================================================
        if (_restartHistory.Count >= 10)
        {
            _logger.LogWarning(
                "Hardware encoder: {Count} restarts in 5 minutes, falling back to software",
                _restartHistory.Count);

            SwitchToSoftwareEncoder(now);

            return true; // ✅ 已切换成功，允许启动
        }

        // =========================================================
        // 4️⃣ 连续失败过多 → 降级软件
        // =========================================================
        if (_consecutiveFailures >= 5)
        {
            _logger.LogWarning(
                "Hardware encoder: {Count} consecutive failures, falling back to software",
                _consecutiveFailures);

            SwitchToSoftwareEncoder(now);

            return true; // ✅ 同样允许启动
        }

        // =========================================================
        // 5️⃣ 硬件编码器启动节流（防风暴）
        // =========================================================
        if (now - _lastRestartAttempt < TimeSpan.FromSeconds(10))
        {
            _logger.LogDebug("Hardware encoder restart throttled (10s cooldown)");
            return false;
        }

        // =========================================================
        // 6️⃣ 允许启动
        // =========================================================
        _lastRestartAttempt = now;
        return true;
    }

    private void RegisterRestart() => _restartHistory.Enqueue(DateTime.UtcNow);

    private bool HasEnoughDiskSpace()
    {
        try
        {
            var drive = Path.GetPathRoot(_config.GetEffectiveStoragePath());
            if (string.IsNullOrWhiteSpace(drive)) return true;
            return new DriveInfo(drive).AvailableFreeSpace > Constants.MinDiskSpaceBytes;
        }
        catch { return true; }
    }

    private string? FindFfmpegCached()
    {
        if (_cachedFfmpegPath != null && DateTime.UtcNow - _ffmpegPathCacheTime < TimeSpan.FromMinutes(5) && File.Exists(_cachedFfmpegPath))
            return _cachedFfmpegPath;

        var path = FindFfmpeg();
        _cachedFfmpegPath = path;
        _ffmpegPathCacheTime = DateTime.UtcNow;
        return path;
    }

    private string? FindFfmpeg()
    {
        foreach (var path in GetFfmpegSearchPaths())
        {
            try
            {
                if (File.Exists(path))
                    return path;
            }
            catch
            {
                // ignore invalid paths
            }
        }

        _logger.LogError(
            "FFmpeg not found. Place ffmpeg.exe next to DHPG.exe or add it to PATH. Searched: {Paths}",
            string.Join("; ", GetFfmpegSearchPaths()));
        return null;
    }

    private static IEnumerable<string> GetFfmpegSearchPaths()
    {
        var baseDir = AppDomain.CurrentDomain.BaseDirectory;
        yield return Path.Combine(baseDir, "ffmpeg.exe");
        yield return Path.Combine(baseDir, "bin", "ffmpeg.exe");

        var projectDir = Path.GetFullPath(Path.Combine(baseDir, "..", "..", ".."));
        yield return Path.Combine(projectDir, "ffmpeg.exe");

        yield return @"C:\ffmpeg\bin\ffmpeg.exe";
        yield return @"C:\Program Files\ffmpeg\bin\ffmpeg.exe";

        var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (var dir in pathEnv.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            yield return Path.Combine(dir, "ffmpeg.exe");
        }
    }

    #region 公开方法

    public string GetCurrentEncoder() => _currentEncoder;

    public bool IsUsingGpuEncoder() => _currentEncoder != "libx264";

    public async Task RetryGpuEncoderAsync()
    {
        _logger.LogInformation("Manual GPU encoder retry requested");
        _forceSoftwareEncoder = false;
        _encoderFailureCount = 0;
        _hasEncoderError = false;
        _needPixelFormatFallback = false;
        _encoderCacheTime = DateTime.MinValue;
        _lastEncoderSwitchTime = DateTime.MinValue;
        await RestartRecordingAsync();
    }

    public EncoderDiagnostics GetEncoderDiagnostics()
    {
        return new EncoderDiagnostics
        {
            CurrentEncoder = _currentEncoder,
            CachedEncoder = _cachedEncoder ?? "unknown",
            EncoderFailureCount = _encoderFailureCount,
            IsUsingHardware = IsUsingGpuEncoder(),
            LastSwitchTime = _lastEncoderSwitchTime,
            CacheAge = _cachedEncoder != null ? DateTime.UtcNow - _encoderCacheTime : TimeSpan.Zero,
            ForceSoftwareEncoder = _forceSoftwareEncoder
        };
    }

    /// <summary>
    /// 供 SelfHealingService 使用的录屏健康快照（与内部健康检查逻辑一致）。
    /// </summary>
    public RecordingHealthSnapshot GetRecordingHealthSnapshot()
    {
        var config = _currentPolicy?.GetRecordingConfig();
        var enabled = config?.Enabled ?? false;
        var now = DateTime.UtcNow;

        var processAlive = false;
        try
        {
            processAlive = _ffmpegProcess != null && !_ffmpegProcess.HasExited;
        }
        catch (InvalidOperationException)
        {
            processAlive = false;
        }

        var encoderHeartbeatAge = (now - _lastEncoderHeartbeat).TotalSeconds;
        var encoderAliveThreshold = _config?.RecordingHealth?.EncoderAliveThresholdSeconds ?? 120;
        var encoderAlive = encoderHeartbeatAge < encoderAliveThreshold;

        var fileRecent = false;
        var fileGrowing = false;
        try
        {
            var recordingsPath = _config?.GetEffectiveStoragePath();
            if (!string.IsNullOrWhiteSpace(recordingsPath))
            {
                recordingsPath = Path.Combine(recordingsPath, "recordings");
            }
            if (!string.IsNullOrWhiteSpace(recordingsPath) && Directory.Exists(recordingsPath))
            {
                FileInfo? latestFile = null;
                foreach (var file in Directory.EnumerateFiles(recordingsPath, "*.mp4", SearchOption.AllDirectories))
                {
                    var info = new FileInfo(file);
                    if (latestFile == null || info.LastWriteTimeUtc > latestFile.LastWriteTimeUtc)
                        latestFile = info;
                }

                if (latestFile != null)
                {
                    var fileAliveThreshold = _config?.RecordingHealth?.FileAliveThresholdSeconds ?? 120;
                    fileRecent = (now - latestFile.LastWriteTimeUtc).TotalSeconds < fileAliveThreshold;
                    fileGrowing = latestFile.Length > _lastObservedFileSize;
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to evaluate recording file health");
        }

        var fileAlive = fileGrowing || fileRecent;
        var isHealthy = !enabled || (processAlive && (encoderAlive || fileAlive));
        var shouldBeRecording = enabled && _workSessionActive && !_isStopping;

        return new RecordingHealthSnapshot
        {
            RecordingEnabled = enabled,
            ShouldBeRecording = shouldBeRecording,
            ProcessAlive = processAlive,
            IsHealthy = isHealthy,
            EncoderAlive = encoderAlive,
            FileRecent = fileRecent,
            FileGrowing = fileGrowing,
            StallSeconds = (now - _lastSuccessfulFrame).TotalSeconds,
            EncoderHeartbeatAgeSeconds = encoderHeartbeatAge,
            CurrentEncoder = _currentEncoder
        };
    }

    /// <summary>
    /// 自愈服务触发的统一重启入口。
    /// </summary>
    public async Task<bool> RequestSelfHealingRestartAsync(CancellationToken ct = default)
    {
        if (_isStopping || !_workSessionActive)
            return false;

        await RestartEngineAsync(RestartMode.Full, "SELF_HEALING");
        try
        {
            await Task.Delay(3000, ct);
        }
        catch (OperationCanceledException)
        {
            return false;
        }

        return GetRecordingHealthSnapshot().IsHealthy;
    }

    /// <summary>
    /// 切换到软件编码器 (libx264)
    /// </summary>
    /// <param name="timestamp">切换时间戳</param>
    private void SwitchToSoftwareEncoder(DateTime timestamp)
    {
        // 记录切换前状态
        var oldEncoder = _currentEncoder;
        
        // 执行切换
        _forceSoftwareEncoder = true;
        _currentEncoder = "libx264";
        _cachedEncoder = "libx264";
        _restartHistory.Clear();
        _consecutiveFailures = 0;
        _lastEncoderSwitchTime = timestamp;
        _gpuDetectionFailedThisSession = true;
        _needPixelFormatFallback = false;  // 重置像素格式回退
        
        _logger.LogWarning(
            "🔄 Switched to software encoder: {OldEncoder} -> libx264 (Reason: hardware encoder failure)",
            oldEncoder);
    }

    #endregion

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Stopping screen recorder service...");

        // 1. 设置停止标志，通知所有循环退出
        _isStopping = true;

        // 2. 取消录制 CancellationTokenSource
        if (_recordingCts != null)
        {
            try
            {
                _recordingCts.Cancel();
                _logger.LogDebug("Recording cancellation requested");
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error cancelling recording token");
            }
        }

        // 3. 取消事件订阅（避免停止后仍收到事件）
        try
        {
            SystemEvents.PowerModeChanged -= OnPowerModeChanged;
            SystemEvents.SessionSwitch -= OnSessionSwitch;
            _logger.LogDebug("System events unsubscribed");
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error unsubscribing from system events");
        }

        // 4. 等待后台任务完成（健康检查、索引器等）
        var backgroundTasks = new List<Task>();
        if (_healthCheckTask != null) backgroundTasks.Add(_healthCheckTask);
        if (_healthMonitorTask != null) backgroundTasks.Add(_healthMonitorTask);
        if (_indexerTask != null) backgroundTasks.Add(_indexerTask);
        if (_ffmpegOutputTask != null) backgroundTasks.Add(_ffmpegOutputTask);

        if (backgroundTasks.Any())
        {
            _logger.LogDebug("Waiting for {Count} background tasks to complete", backgroundTasks.Count);

            try
            {
                await Task.WhenAll(backgroundTasks)
                    .WaitAsync(TimeSpan.FromSeconds(5), cancellationToken);

                _logger.LogDebug("All background tasks completed");
            }
            catch (TimeoutException)
            {
                _logger.LogWarning("Background tasks did not stop within timeout, continuing shutdown");
            }
            catch (OperationCanceledException)
            {
                _logger.LogWarning("Background tasks cancelled during shutdown");
            }
        }

        // 5. 停止录制进程
        try
        {
            await StopRecordingAsync();
            _logger.LogInformation("Recording stopped successfully");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error stopping recording during shutdown");

            // 最后手段：强制清理
            try
            {
                await ForceCleanupAsync();
            }
            catch (Exception cleanupEx)
            {
                _logger.LogError(cleanupEx, "Force cleanup also failed");
            }
        }

        // 6. 调用基类停止
        await base.StopAsync(cancellationToken);

        _logger.LogInformation("Screen recorder service stopped");
    }

    // ============================================================
    // V7 统一重启引擎
    // ============================================================

    /// <summary>
    /// 重启模式
    /// </summary>
    private enum RestartMode
    {
        Recover,    // 轻量恢复
        Capture,    // 重建捕获层
        Encoder,    // 切换编码器
        Full        // 完整重启
    }

    /// <summary>
    /// 统一重启入口 - 唯一控制 FFmpeg 的地方
    /// </summary>
    private async Task RestartEngineAsync(RestartMode mode, string reason)
    {
        // 串行化保护
        if (!await _restartLock.WaitAsync(0))
        {
            _logger.LogDebug("Restart already in progress, skipping. Mode={Mode}, Reason={Reason}", mode, reason);
            return;
        }
        
        try
        {
            // 完整重启需要冷却检查
            if (mode == RestartMode.Full)
            {
                if (!CanPerformFullRestart())
                {
                    _logger.LogWarning("Full restart throttled, skipping. Reason={Reason}", reason);
                    return;
                }
            }
            
            _logger.LogWarning("RestartEngine: Mode={Mode}, Reason={Reason}", mode, reason);
            
            // 1. 停止录制
            await StopRecordingAsync();
            
            // 2. 等待资源释放
            await Task.Delay(2000);
            
            // 3. 根据模式应用配置
            ApplyRestartMode(mode);
            
            // 4. 重置所有信号
            ResetAllSignals();

            // 5. 重启录制（StopRecordingAsync 会置 _isStopping，此处必须清除）
            _isStopping = false;
            if (_workSessionActive)
                await StartRecordingAsync();
            else
                _logger.LogDebug("RestartEngine skipped start: no active work session");
            
            // 6. 验证
            await Task.Delay(3000);
            if (IsProcessAlive())
            {
                _logger.LogInformation("RestartEngine completed: Mode={Mode}", mode);
                _consecutiveFailures = 0;
            }
            else
            {
                _logger.LogWarning("RestartEngine completed but process not alive");
                Interlocked.Increment(ref _consecutiveFailures);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "RestartEngine failed: Mode={Mode}", mode);
            Interlocked.Increment(ref _consecutiveFailures);
        }
        finally
        {
            _restartLock.Release();
        }
    }

    /// <summary>
    /// 检查是否可以执行完整重启
    /// </summary>
    private bool CanPerformFullRestart()
    {
        var now = DateTime.UtcNow;
        
        // 清理1小时前的记录
        while (_restartHistory.Count > 0 && now - _restartHistory.Peek() > TimeSpan.FromHours(1))
            _restartHistory.Dequeue();
        
        // 1小时内超过10次则禁止
        if (_restartHistory.Count >= 10)
        {
            _logger.LogError("Too many restarts in last hour ({Count}), entering degraded mode", _restartHistory.Count);
            return false;
        }
        
        // 5分钟内超过3次则限流
        var last5MinCount = _restartHistory.Count(t => now - t < TimeSpan.FromMinutes(5));
        if (last5MinCount >= 3)
        {
            _logger.LogWarning("Too many restarts in 5 minutes ({Count}), throttling", last5MinCount);
            return false;
        }
        
        // 最小间隔30秒
        if (now - _lastFullRestartTime < TimeSpan.FromSeconds(30))
        {
            _logger.LogDebug("Restart throttled: last restart was {Seconds:F0}s ago", (now - _lastFullRestartTime).TotalSeconds);
            return false;
        }
        
        _restartHistory.Enqueue(now);
        _lastFullRestartTime = now;
        return true;
    }

    /// <summary>
    /// 根据重启模式应用配置
    /// </summary>
    /// <summary>
    /// 根据重启模式应用配置
    /// </summary>
    /// <summary>
    /// 根据重启模式应用配置
    /// </summary>
    private void ApplyRestartMode(RestartMode mode)
    {
        switch (mode)
        {
            case RestartMode.Recover:
                _logger.LogDebug("Recover mode: resetting signals only");
                break;
                
            case RestartMode.Capture:
                _logger.LogInformation("Capture mode: resetting recording session");
                // 注意：ScreenRecorderService 中不直接持有 _screenCapture（那是远程屏幕用的）
                // 这里仅做逻辑重置，实际的进程重启由 RestartEngineAsync 统一处理
                break;
                
            case RestartMode.Encoder:
                _logger.LogInformation("Encoder mode: switching to software encoder");
                _forceSoftwareEncoder = true;
                _currentEncoder = "libx264";
                _gpuDetectionFailedThisSession = true;
                break;
                
            case RestartMode.Full:
                _logger.LogInformation("Full mode: complete reset");
                _forceSoftwareEncoder = false;
                _encoderFailureCount = 0;
                _hasEncoderError = false;
                _needPixelFormatFallback = false;
                _encoderCacheTime = DateTime.MinValue;
                break;
        }
    }

    /// <summary>
    /// 重置所有信号
    /// </summary>
    private void ResetAllSignals()
    {
        var now = DateTime.UtcNow;
        _lastFileActivity = now;
        _lastEncoderHeartbeat = now;
        _lastSuccessfulFrame = now;
        _logger.LogDebug("All signals reset");
    }

    // 同时需要在 Dispose 中添加清理
    public override void Dispose()
    {
        SystemEvents.PowerModeChanged -= OnPowerModeChanged;
        SystemEvents.SessionSwitch -= OnSessionSwitch;
        _recordingCts?.Dispose();
        _processLock.Dispose();
        _encoderDetectionLock?.Dispose();
        base.Dispose();
    }
}

public class EncoderDiagnostics
{
    public string CurrentEncoder { get; set; } = "";
    public string CachedEncoder { get; set; } = "";
    public int EncoderFailureCount { get; set; }
    public bool IsUsingHardware { get; set; }
    public DateTime LastSwitchTime { get; set; }
    public TimeSpan CacheAge { get; set; }
    public bool ForceSoftwareEncoder { get; set; }
}

public sealed class RecordingHealthSnapshot
{
    public bool RecordingEnabled { get; init; }
    public bool ShouldBeRecording { get; init; }
    public bool ProcessAlive { get; init; }
    public bool IsHealthy { get; init; }
    public bool EncoderAlive { get; init; }
    public bool FileRecent { get; init; }
    public bool FileGrowing { get; init; }
    public double StallSeconds { get; init; }
    public double EncoderHeartbeatAgeSeconds { get; init; }
    public string CurrentEncoder { get; init; } = "";
}
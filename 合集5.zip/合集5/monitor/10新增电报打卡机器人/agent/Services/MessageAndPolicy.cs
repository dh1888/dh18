// Services/MessageAndPolicy.cs - 完整修改版（集成 AuthTokenProvider）

using System.Net.Http.Json;
using System.Text;
using System.Collections.Concurrent;
using System.Text.Json;
using EnterpriseAgent.Agent.Extensions;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Storage; 
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;


namespace EnterpriseAgent.Agent.Services;

#region 消息总线

/// <summary>
/// 消息总线接口，用于解耦 WebSocket 与业务逻辑
/// </summary>
public interface IMessageBus
{
    /// <summary>
    /// 订阅特定类型的消息
    /// </summary>
    /// <param name="messageType">消息类型</param>
    /// <param name="handler">消息处理程序</param>
    void Subscribe(string messageType, Func<JsonElement, Task> handler);

    /// <summary>
    /// 取消订阅消息
    /// </summary>
    /// <param name="messageType">消息类型</param>
    /// <param name="handler">消息处理程序</param>
    void Unsubscribe(string messageType, Func<JsonElement, Task> handler);

    /// <summary>
    /// 发布消息
    /// </summary>
    /// <param name="messageType">消息类型</param>
    /// <param name="payload">消息负载</param>
    Task PublishAsync(string messageType, JsonElement payload);

    /// <summary>
    /// 订阅所有消息
    /// </summary>
    /// <param name="handler">消息处理程序，参数为 (messageType, payload)</param>
    void SubscribeAll(Func<string, JsonElement, Task> handler);

    /// <summary>
    /// 取消订阅所有消息
    /// </summary>
    void UnsubscribeAll(Func<string, JsonElement, Task> handler);
}

/// <summary>
/// 消息总线实现，支持发布-订阅模式
/// </summary>
public class MessageBus : IMessageBus
{
    private readonly ILogger<MessageBus> _logger;
    private readonly Dictionary<string, List<Func<JsonElement, Task>>> _subscribers = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<Func<string, JsonElement, Task>> _allSubscribers = new();
    private readonly object _lock = new();

    public MessageBus(ILogger<MessageBus> logger)
    {
        _logger = logger;
    }

    public void Subscribe(string messageType, Func<JsonElement, Task> handler)
    {
        if (string.IsNullOrWhiteSpace(messageType))
            throw new ArgumentNullException(nameof(messageType));
        if (handler == null)
            throw new ArgumentNullException(nameof(handler));

        lock (_lock)
        {
            if (!_subscribers.ContainsKey(messageType))
                _subscribers[messageType] = new List<Func<JsonElement, Task>>();

            _subscribers[messageType].Add(handler);
            _logger.LogDebug("Subscribed to message type: {MessageType}", messageType);
        }
    }

    public void Unsubscribe(string messageType, Func<JsonElement, Task> handler)
    {
        if (string.IsNullOrWhiteSpace(messageType) || handler == null)
            return;

        lock (_lock)
        {
            if (_subscribers.TryGetValue(messageType, out var handlers))
            {
                handlers.Remove(handler);
                if (handlers.Count == 0)
                    _subscribers.Remove(messageType);
                
                _logger.LogDebug("Unsubscribed from message type: {MessageType}", messageType);
            }
        }
    }

    public async Task PublishAsync(string messageType, JsonElement payload)
    {
        if (string.IsNullOrWhiteSpace(messageType))
            throw new ArgumentNullException(nameof(messageType));

        List<Func<JsonElement, Task>>? handlers = null;
        List<Func<string, JsonElement, Task>>? allHandlers = null;

        lock (_lock)
        {
            if (_subscribers.TryGetValue(messageType, out var subs))
                handlers = new List<Func<JsonElement, Task>>(subs);

            allHandlers = new List<Func<string, JsonElement, Task>>(_allSubscribers);
        }

        if (handlers != null)
        {
            foreach (var handler in handlers)
            {
                try
                {
                    await handler(payload);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error handling message of type {MessageType}", messageType);
                }
            }
        }

        if (allHandlers != null)
        {
            foreach (var handler in allHandlers)
            {
                try
                {
                    await handler(messageType, payload);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error in all-message handler for type {MessageType}", messageType);
                }
            }
        }

        _logger.LogDebug("Published message of type: {MessageType}", messageType);
    }

    public void SubscribeAll(Func<string, JsonElement, Task> handler)
    {
        if (handler == null)
            throw new ArgumentNullException(nameof(handler));

        lock (_lock)
        {
            _allSubscribers.Add(handler);
            _logger.LogDebug("Subscribed to all messages");
        }
    }

    public void UnsubscribeAll(Func<string, JsonElement, Task> handler)
    {
        if (handler == null)
            return;

        lock (_lock)
        {
            _allSubscribers.Remove(handler);
            _logger.LogDebug("Unsubscribed from all messages");
        }
    }
}

#endregion

#region 策略同步服务

public class PolicySyncService : BackgroundService
{
    private readonly ILogger<PolicySyncService> _logger;
    private readonly IMessageBus _messageBus;
    private readonly IHttpClientFactory _httpFactory;
    private readonly AgentConfig _config;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ScreenRecorderService _recorder;
    private readonly FileUploadService _uploader;
    private readonly ScreenshotService _screenshotService;
    private readonly CleanupService _cleanup;
    private readonly IAuthTokenProvider _authTokenProvider;  // ✅ 新增
    
    private Policy? _currentPolicy;
    private readonly SemaphoreSlim _syncLock = new(1, 1);
    private DateTime _lastSyncTime;
    private bool _isStopping;

    public PolicySyncService(
        ILogger<PolicySyncService> logger,
        IMessageBus messageBus,
        IHttpClientFactory httpFactory,
        AgentConfig config,
        IServiceScopeFactory scopeFactory,
        ScreenRecorderService recorder,
        FileUploadService uploader,
        ScreenshotService screenshotService,
        CleanupService cleanup,
        IAuthTokenProvider authTokenProvider)  // ✅ 新增参数
    {
        _logger = logger;
        _messageBus = messageBus ?? throw new ArgumentNullException(nameof(messageBus));
        _httpFactory = httpFactory;
        _config = config;
        _scopeFactory = scopeFactory;
        _recorder = recorder ?? throw new ArgumentNullException(nameof(recorder));
        _uploader = uploader ?? throw new ArgumentNullException(nameof(uploader));
        _screenshotService = screenshotService ?? throw new ArgumentNullException(nameof(screenshotService));
        _cleanup = cleanup ?? throw new ArgumentNullException(nameof(cleanup));
        _authTokenProvider = authTokenProvider;  // ✅ 保存引用

        // ========== ✅ 新增：WebSocket 策略更新订阅 ==========
        // 订阅后端推送的策略更新消息 (type: "policy_update")
        _messageBus.Subscribe("policy_update", async payload =>
        {
            await HandleWebSocketPolicyUpdateAsync(payload);
        });
        
        // 可选：订阅策略同步请求（后端可通过此消息要求客户端立即同步）
        _messageBus.Subscribe("policy.sync", async _ =>
        {
            _logger.LogInformation("收到策略同步请求，立即同步");
            await ForceSyncAsync();
        });
    }

    private async Task HandleWebSocketPolicyUpdateAsync(JsonElement payload)
    {
        _logger.LogInformation("📡 收到策略更新 WebSocket 推送");

        try
        {
            if (!payload.TryGetProperty("policy", out var policyElement))
            {
                _logger.LogWarning("策略更新消息缺少 policy 字段");
                return;
            }

            var policyJson = policyElement.GetRawText();
            var policy = JsonSerializer.Deserialize<Policy>(policyJson, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

            if (policy == null)
            {
                _logger.LogWarning("策略更新消息解析失败");
                return;
            }

            if (payload.TryGetProperty("version", out var versionElement) &&
                versionElement.TryGetInt32(out var envelopeVersion))
            {
                if (policy.Version != envelopeVersion)
                {
                    _logger.LogDebug(
                        "策略 envelope 版本 {EnvelopeVersion} 与 policy.Version {PolicyVersion} 不一致，以 envelope 为准",
                        envelopeVersion,
                        policy.Version);
                    policy.Version = envelopeVersion;
                }
            }

            if (payload.TryGetProperty("signature", out var signatureElement))
            {
                policy.Signature = signatureElement.GetString() ?? "";
            }

            // 优先使用服务端下发的 content 原文验签，避免 JSON 重序列化导致签名不一致
            var signedContentJson = policyJson;
            if (payload.TryGetProperty("content", out var contentElement) &&
                contentElement.ValueKind == JsonValueKind.String)
            {
                var contentString = contentElement.GetString();
                if (!string.IsNullOrWhiteSpace(contentString))
                    signedContentJson = contentString;
            }

            await ApplyPolicyIfNewerAsync(policy, "websocket", publishEvent: false, signedContentJson: signedContentJson);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "处理 WebSocket 策略更新失败");
        }
    }

    /// <summary>
    /// 统一策略应用入口：版本比较 + 签名校验 + 缓存 + 应用（HTTP / WebSocket 共用）
    /// </summary>
    private async Task<bool> ApplyPolicyIfNewerAsync(
        Policy policy,
        string source,
        bool publishEvent,
        CancellationToken ct = default,
        string? signedContentJson = null)
    {
        await _syncLock.WaitAsync(ct);
        try
        {
            var currentVersion = _currentPolicy?.Version ?? 0;
            if (policy.Version <= currentVersion)
            {
                _logger.LogDebug(
                    "忽略来自 {Source} 的策略: v{Version} 不高于当前 v{CurrentVersion}",
                    source,
                    policy.Version,
                    currentVersion);
                return false;
            }

            if (string.IsNullOrEmpty(policy.Signature))
            {
                _logger.LogError(
                    "来自 {Source} 的策略缺少签名，拒绝 v{Version}",
                    source,
                    policy.Version);
                return false;
            }

            var contentForVerify = signedContentJson;
            if (string.IsNullOrEmpty(contentForVerify))
            {
                contentForVerify = JsonSerializer.Serialize(new
                {
                    policy.Version,
                    policy.Rules,
                    policy.Config
                });
            }

            if (!VerifyPolicyContentSignature(contentForVerify, policy.Signature))
            {
                _logger.LogError(
                    "来自 {Source} 的策略签名校验失败，拒绝 v{Version}",
                    source,
                    policy.Version);
                return false;
            }

            _logger.LogInformation(
                "应用来自 {Source} 的策略: v{OldVersion} -> v{NewVersion}",
                source,
                currentVersion,
                policy.Version);

            using var scope = _scopeFactory.CreateScope();
            var policyRepo = scope.ServiceProvider.GetRequiredService<PolicyRepository>();
            await policyRepo.CacheAsync(policy, contentForVerify);

            _currentPolicy = policy;
            ApplyPolicy(policy);
            _lastSyncTime = DateTime.UtcNow;

            if (publishEvent)
            {
                await _messageBus.PublishAsync("policy.updated", JsonSerializer.SerializeToElement(policy));
            }

            _logger.LogInformation("策略已从 {Source} 更新到版本 {Version}", source, policy.Version);
            return true;
        }
        finally
        {
            _syncLock.Release();
        }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Policy sync service started");
        
        await LoadCachedPolicyAsync();
        await SyncPolicyWithRetryAsync(stoppingToken);
        
        while (!stoppingToken.IsCancellationRequested && !_isStopping)
        {
            try
            {
                await SyncPolicyAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Policy sync failed");
            }
            
            await Task.Delay(
                TimeSpan.FromSeconds(Math.Max(_config.Policy.SyncIntervalSeconds, 60)),
                stoppingToken);
        }
        
        _logger.LogInformation("Policy sync service stopped");
    }

    private async Task LoadCachedPolicyAsync()
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var policyRepo = scope.ServiceProvider.GetRequiredService<PolicyRepository>();
            
            var cached = await policyRepo.GetCachedAsync();
            if (cached != null)
            {
                await ApplyPolicyIfNewerAsync(
                    cached.Policy,
                    "cache",
                    publishEvent: false,
                    signedContentJson: cached.SignedContentJson);
                _logger.LogInformation("Loaded cached policy version {Version}", cached.Policy.Version);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to load cached policy");
        }
    }

    private async Task SyncPolicyWithRetryAsync(CancellationToken ct)
    {
        for (int i = 0; i < Constants.MaxRetryCount; i++)
        {
            try
            {
                await SyncPolicyAsync(ct);
                return;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Initial policy sync attempt {Attempt}/{MaxRetries} failed", i + 1, Constants.MaxRetryCount);
                if (i < Constants.MaxRetryCount - 1)
                    await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, i)), ct);
            }
        }
    }

    private async Task SyncPolicyAsync(CancellationToken ct)
    {
        try
        {
            var success = await TrySyncPolicyOnceAsync(ct);
            if (!success)
            {
                // 401 后 refresh 已在 TrySyncPolicyOnceAsync 内完成，重试一次
                await TrySyncPolicyOnceAsync(ct);
            }

            using var scope = _scopeFactory.CreateScope();
            var workSession = scope.ServiceProvider.GetService<WorkSessionService>();
            if (workSession != null)
            {
                await workSession.SyncCaptureSettingsAsync(ct);
                workSession.ApplyAutoCaptureFromPolicy(_currentPolicy);
            }
        }
        catch (HttpRequestException ex)
        {
            _logger.LogWarning(ex, "HTTP request failed during policy sync");
            throw;
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("Policy sync cancelled");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during policy sync");
            throw;
        }
    }

    private async Task<bool> TrySyncPolicyOnceAsync(CancellationToken ct)
    {
        try
        {
            var url = $"{_config.ServerUrl}/api/v1/policies/current";

            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            if (!HttpAuthExtensions.TryApplyBearerToken(request, _authTokenProvider))
            {
                _logger.LogWarning("Token is empty, skipping policy sync");
                return false;
            }

            using var http = _httpFactory.CreateClient("AgentClient");
            using var response = await http.SendAsync(request, ct);

            if (response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync(ct);
                if (TryParsePolicyFromApiResponse(body, out var policy, out var signedContentJson))
                {
                    await ApplyPolicyIfNewerAsync(
                        policy,
                        "http",
                        publishEvent: true,
                        ct,
                        signedContentJson);
                }
                else
                {
                    _logger.LogWarning("Policy API response format invalid or signature missing");
                }
                return true;
            }

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                _logger.LogWarning("Unauthorized to fetch policy, attempting token refresh");
                await _authTokenProvider.RefreshTokenAsync(ct);
                return false;
            }

            _logger.LogWarning("Policy sync failed with status {StatusCode}", (int)response.StatusCode);
            return false;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
    }

    private static bool TryParsePolicyFromApiResponse(
        string json,
        out Policy policy,
        out string signedContentJson)
    {
        policy = null!;
        signedContentJson = "";

        try
        {
            using var doc = JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty("data", out var data))
                return false;

            if (!data.TryGetProperty("content", out var contentProp))
                return false;

            signedContentJson = contentProp.GetString() ?? "";
            if (string.IsNullOrWhiteSpace(signedContentJson))
                return false;

            if (!data.TryGetProperty("signature", out var signatureProp))
                return false;

            var signature = signatureProp.GetString() ?? "";
            if (string.IsNullOrWhiteSpace(signature))
                return false;

            var parsed = JsonSerializer.Deserialize<Policy>(signedContentJson, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });
            if (parsed == null)
                return false;

            parsed.Signature = signature;

            if (data.TryGetProperty("version", out var versionProp) &&
                versionProp.TryGetInt32(out var envelopeVersion) &&
                envelopeVersion > 0)
            {
                parsed.Version = envelopeVersion;
            }

            policy = parsed;
            return true;
        }
        catch
        {
            return false;
        }
    }

    private bool VerifyPolicyContentSignature(string contentJson, string signature)
    {
        try
        {
            var secret = _config.Auth?.PolicySignatureSecret;

            if (string.IsNullOrEmpty(secret))
            {
                _logger.LogError("PolicySignatureSecret is not configured");
                return false;
            }

            using var hmac = new System.Security.Cryptography.HMACSHA256(Encoding.UTF8.GetBytes(secret));
            var bytes = Encoding.UTF8.GetBytes(contentJson);
            var hash = hmac.ComputeHash(bytes);
            var computed = Convert.ToHexString(hash).ToLowerInvariant();

            if (string.Equals(signature, computed, StringComparison.OrdinalIgnoreCase))
                return true;

            try
            {
                var sigBytes = Convert.FromBase64String(signature);
                var sigHex = Convert.ToHexString(sigBytes).ToLowerInvariant();
                if (string.Equals(sigHex, computed, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            catch { }

            return false;
        }
        catch
        {
            return false;
        }
    }

    private void ApplyPolicy(Policy policy)
    {
        try
        {
            _logger.LogInformation("Applying policy version {Version}", policy.Version);
            
            _recorder?.UpdatePolicy(policy);
            _uploader?.UpdatePolicy(policy);
            _screenshotService?.UpdatePolicy(policy);
            
            var cleanupConfig = policy.GetCleanupConfig();
            _cleanup?.UpdatePolicy(cleanupConfig);

            using var scope = _scopeFactory.CreateScope();
            var workSession = scope.ServiceProvider.GetService<WorkSessionService>();
            workSession?.ApplyAutoCaptureFromPolicy(policy);
            
            _logger.LogInformation("Policy applied successfully");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to apply policy");
        }
    }

    public async Task ForceSyncAsync()
    {
        _logger.LogInformation("Forcing policy sync");
        await SyncPolicyAsync(CancellationToken.None);
    }

    public Policy? GetCurrentPolicy() => _currentPolicy;

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Stopping policy sync service...");
        _isStopping = true;
        
        if (_syncLock.CurrentCount == 0)
        {
            await _syncLock.WaitAsync(TimeSpan.FromSeconds(10), cancellationToken);
            _syncLock.Release();
        }
        
        await base.StopAsync(cancellationToken);
    }
}

#endregion

#region 活动日志实时上报服务

/// <summary>
/// 活动日志实时上报服务 - 监听消息总线并转发到 WebSocket
/// </summary>
public class ActivityRealTimeReporter : BackgroundService
{
    private const int MaxBufferedActivities = 500;

    private readonly ILogger<ActivityRealTimeReporter> _logger;
    private readonly IMessageBus _messageBus;
    private readonly WebSocketService _webSocketService;
    private readonly AgentConfig _config;

    private readonly ConcurrentQueue<string> _offlineBuffer = new();
    private int _bufferedCount;

    private Func<JsonElement, Task>? _handler;
    private Func<JsonElement, Task>? _connectedHandler;

    public ActivityRealTimeReporter(
        ILogger<ActivityRealTimeReporter> logger,
        IMessageBus messageBus,
        WebSocketService webSocketService,
        AgentConfig config)
    {
        _logger = logger;
        _messageBus = messageBus;
        _webSocketService = webSocketService;
        _config = config;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Activity real-time reporter started (with offline buffer)");

        _handler = async payload =>
        {
            try
            {
                await ForwardActivityToWebSocket(payload, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                // 正常取消
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to forward activity to WebSocket");
            }
        };

        _connectedHandler = async _ =>
        {
            try
            {
                await FlushOfflineBufferAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                // 正常取消
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to flush offline activity buffer on reconnect");
            }
        };

        _messageBus.Subscribe("activity.real_time", _handler);
        _messageBus.Subscribe("websocket.connected", _connectedHandler);

        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                if (_webSocketService.IsConnected && !_offlineBuffer.IsEmpty)
                    await FlushOfflineBufferAsync(stoppingToken);

                await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
            }
        }
        catch (OperationCanceledException)
        {
            // 正常停止
        }
    }

    private async Task ForwardActivityToWebSocket(JsonElement payload, CancellationToken ct)
    {
        if (!_webSocketService.IsConnected)
        {
            BufferActivity(payload);
            return;
        }

        await SendActivityAsync(payload, ct);
    }

    private void BufferActivity(JsonElement payload)
    {
        var json = JsonSerializer.Serialize(payload);
        _offlineBuffer.Enqueue(json);

        var count = Interlocked.Increment(ref _bufferedCount);
        while (count > MaxBufferedActivities && _offlineBuffer.TryDequeue(out _))
            count = Interlocked.Decrement(ref _bufferedCount);

        if (count == 1 || count % 50 == 0)
            _logger.LogDebug("Buffered real-time activity (offline), queue size ~{Count}", count);
    }

    private async Task FlushOfflineBufferAsync(CancellationToken ct)
    {
        if (!_webSocketService.IsConnected || _offlineBuffer.IsEmpty)
            return;

        var flushed = 0;
        while (_offlineBuffer.TryDequeue(out var json))
        {
            Interlocked.Decrement(ref _bufferedCount);

            try
            {
                var payload = JsonSerializer.Deserialize<JsonElement>(json);
                await SendActivityAsync(payload, ct);
                flushed++;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to flush buffered activity");
            }
        }

        if (flushed > 0)
            _logger.LogInformation("Flushed {Count} buffered real-time activities after reconnect", flushed);
    }

    private async Task SendActivityAsync(JsonElement payload, CancellationToken ct)
    {
        var message = new WebSocketMessage
        {
            Type = "activity.real_time",
            Data = payload,
            Timestamp = DateTime.UtcNow,
            DeviceId = _config.DeviceId
        };

        var json = JsonSerializer.Serialize(message);
        await _webSocketService.SendMessageAsync(json, ct);
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Stopping activity real-time reporter...");
        if (_handler != null)
        {
            _messageBus.Unsubscribe("activity.real_time", _handler);
            _handler = null;
        }
        if (_connectedHandler != null)
        {
            _messageBus.Unsubscribe("websocket.connected", _connectedHandler);
            _connectedHandler = null;
        }
        await base.StopAsync(cancellationToken);
    }
}

/// <summary>
/// WebSocket 消息结构
/// </summary>
public class WebSocketMessage
{
    public string Type { get; set; } = "";
    public JsonElement Data { get; set; }
    public DateTime Timestamp { get; set; }
    public string DeviceId { get; set; } = "";
}

#endregion
using System.Net.Http.Headers;

using System.Text;

using System.Text.Json;

using EnterpriseAgent.Agent.Models;

using Microsoft.Extensions.Logging;



namespace EnterpriseAgent.Agent.Services;



/// <summary>

/// 上下班 Session：调用后端 checkin/checkout，并协调录屏/截图启停。

/// </summary>

public sealed class WorkSessionService

{

    private readonly ILogger<WorkSessionService> _logger;

    private readonly IHttpClientFactory _httpFactory;

    private readonly IAuthTokenProvider _authTokenProvider;

    private readonly ScreenRecorderService _recorder;

    private readonly ScreenshotService _screenshot;



    private string? _openSessionId;

    private volatile bool _captureLinkedToCheckin;

    private readonly object _lock = new();



    public WorkSessionService(

        ILogger<WorkSessionService> logger,

        IHttpClientFactory httpFactory,

        IAuthTokenProvider authTokenProvider,

        ScreenRecorderService recorder,

        ScreenshotService screenshot)

    {

        _logger = logger;

        _httpFactory = httpFactory;

        _authTokenProvider = authTokenProvider;

        _recorder = recorder;

        _screenshot = screenshot;

    }



    public bool HasOpenSession

    {

        get { lock (_lock) return !string.IsNullOrEmpty(_openSessionId); }

    }



    public bool CaptureLinkedToCheckin => _captureLinkedToCheckin;



    public void UpdateCaptureLinkedToCheckin(bool linked)

    {

        if (_captureLinkedToCheckin == linked)

            return;



        _captureLinkedToCheckin = linked;

        _logger.LogInformation("Capture mode updated: linkedToCheckin={Linked}", linked);



        if (linked)

        {

            lock (_lock)

            {

                if (string.IsNullOrEmpty(_openSessionId))

                    StopWorkCapture();

            }

        }

    }



    public void ApplyAutoCaptureFromPolicy(Policy? policy)

    {

        if (_captureLinkedToCheckin)

            return;



        var recordingEnabled = policy?.GetRecordingConfig()?.Enabled == true;

        var screenshotEnabled = policy?.GetScreenshotConfig()?.Enabled == true;



        if (recordingEnabled || screenshotEnabled)

        {

            StartWorkCapture();

            _logger.LogInformation("Auto capture enabled from policy (recording={Recording}, screenshot={Screenshot})",

                recordingEnabled, screenshotEnabled);

        }

        else

        {

            StopWorkCapture();

            _logger.LogInformation("Auto capture disabled: recording and screenshot are off in policy");

        }

    }



    public async Task<bool> CheckInAsync(CancellationToken ct = default)

    {

        var snapshot = _authTokenProvider.GetSnapshot();

        if (!snapshot.IsApproved || string.IsNullOrEmpty(snapshot.Token))

        {

            _logger.LogWarning("Check-in rejected: device not approved or missing token");

            return false;

        }



        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/checkin");

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);



        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);

        var body = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)

        {

            _logger.LogWarning("Check-in failed: {Status} {Body}", response.StatusCode, body);

            return false;

        }



        var sessionId = ParseSessionId(body);

        lock (_lock) { _openSessionId = sessionId; }



        if (_captureLinkedToCheckin)

            StartWorkCapture();



        _logger.LogInformation("Check-in OK, session={SessionId}, captureLinked={Linked}", sessionId, _captureLinkedToCheckin);

        return true;

    }



    public async Task<bool> CheckOutAsync(CancellationToken ct = default)

    {

        var snapshot = _authTokenProvider.GetSnapshot();

        if (string.IsNullOrEmpty(snapshot.Token))

            return false;



        string? sessionId;

        lock (_lock) { sessionId = _openSessionId; }



        using var request = new HttpRequestMessage(HttpMethod.Post, $"{GetServerUrl()}/api/v1/agent/checkout");

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);

        if (!string.IsNullOrEmpty(sessionId))

        {

            var payload = JsonSerializer.Serialize(new { sessionId });

            request.Content = new StringContent(payload, Encoding.UTF8, "application/json");

        }



        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);

        var body = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)

        {

            _logger.LogWarning("Check-out failed: {Status} {Body}", response.StatusCode, body);

            return false;

        }



        lock (_lock) { _openSessionId = null; }



        if (_captureLinkedToCheckin)

            StopWorkCapture();



        _logger.LogInformation("Check-out OK");

        return true;

    }



    /// <summary>

    /// 启动时从服务端恢复未关闭的上班会话（崩溃/重启后续录）。

    /// </summary>

    public async Task TryRestoreOpenSessionAsync(CancellationToken ct = default)

    {

        var snapshot = _authTokenProvider.GetSnapshot();

        if (string.IsNullOrEmpty(snapshot.Token))

            return;



        using var request = new HttpRequestMessage(HttpMethod.Get, $"{GetServerUrl()}/api/v1/agent/session");

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);



        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);

        if (!response.IsSuccessStatusCode)

            return;



        var body = await response.Content.ReadAsStringAsync(ct);

        try

        {

            using var doc = JsonDocument.Parse(body);

            if (!doc.RootElement.TryGetProperty("data", out var data))

                return;



            if (data.TryGetProperty("captureLinkedToCheckin", out var linkedProp) &&

                (linkedProp.ValueKind == JsonValueKind.True || linkedProp.ValueKind == JsonValueKind.False))

            {

                UpdateCaptureLinkedToCheckin(linkedProp.GetBoolean());

            }



            var open = data.TryGetProperty("workSessionOpen", out var wso) && wso.GetBoolean();

            string? sessionId = null;

            if (data.TryGetProperty("workSessionId", out var wsid))

                sessionId = wsid.GetString();



            if (open)

            {

                lock (_lock) { _openSessionId = sessionId; }

                if (_captureLinkedToCheckin)

                {

                    StartWorkCapture();

                    _logger.LogInformation("Restored open work session, capture resumed (session={SessionId})", sessionId);

                }

            }

            else

            {

                lock (_lock) { _openSessionId = null; }

            }

        }

        catch (Exception ex)

        {

            _logger.LogWarning(ex, "Failed to restore open work session");

        }

    }



    public async Task SyncCaptureSettingsAsync(CancellationToken ct = default)

    {

        var snapshot = _authTokenProvider.GetSnapshot();

        if (string.IsNullOrEmpty(snapshot.Token))

            return;



        using var request = new HttpRequestMessage(HttpMethod.Get, $"{GetServerUrl()}/api/v1/agent/session");

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", snapshot.Token);



        using var response = await _httpFactory.CreateClient("AgentClient").SendAsync(request, ct);

        if (!response.IsSuccessStatusCode)

            return;



        var body = await response.Content.ReadAsStringAsync(ct);

        try

        {

            using var doc = JsonDocument.Parse(body);

            if (!doc.RootElement.TryGetProperty("data", out var data))

                return;

            if (data.TryGetProperty("captureLinkedToCheckin", out var linkedProp) &&

                (linkedProp.ValueKind == JsonValueKind.True || linkedProp.ValueKind == JsonValueKind.False))

            {

                UpdateCaptureLinkedToCheckin(linkedProp.GetBoolean());

            }

        }

        catch (Exception ex)

        {

            _logger.LogDebug(ex, "Failed to sync capture settings");

        }

    }



	public void StartExternalWorkSession(string sessionId, string source = "telegram")

	{

        if (!_captureLinkedToCheckin)

        {

            _logger.LogDebug("Ignored external work capture (auto mode, session={SessionId})", sessionId);

            return;

        }



		lock (_lock) { _openSessionId = sessionId; }

		if (!_screenshot.WorkSessionActive)

		{

			StartWorkCapture();

			_logger.LogInformation("External work capture started (source={Source}, session={SessionId})", source, sessionId);

		}

		else

		{

			_logger.LogInformation("External work session updated (source={Source}, session={SessionId})", source, sessionId);

		}

	}



	public void StopExternalWorkSession(string? sessionId = null)

	{

        if (!_captureLinkedToCheckin)

            return;



		lock (_lock)

		{

			if (!string.IsNullOrEmpty(sessionId) && !string.IsNullOrEmpty(_openSessionId) && _openSessionId != sessionId)

				return;

			_openSessionId = null;

		}

		StopWorkCapture();

		_logger.LogInformation("External work capture stopped (session={SessionId})", sessionId);

	}



	private void StartWorkCapture()

    {

        _screenshot.StartCapture();

        _recorder.StartRecording();

    }



    private void StopWorkCapture()

    {

        _recorder.StopRecording();

        _screenshot.StopCapture();

    }



    private string GetServerUrl() => _serverUrlResolver?.Invoke() ?? "http://localhost:8080";



    private Func<string>? _serverUrlResolver;

    public void SetServerUrlResolver(Func<string> resolver) => _serverUrlResolver = resolver;



    private static string? ParseSessionId(string json)

    {

        try

        {

            using var doc = JsonDocument.Parse(json);

            if (doc.RootElement.TryGetProperty("data", out var data)

                && data.TryGetProperty("sessionId", out var sid))

            {

                return sid.GetString();

            }

        }

        catch { /* ignore */ }



        return null;

    }

}



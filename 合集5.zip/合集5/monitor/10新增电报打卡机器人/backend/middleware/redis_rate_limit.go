package middleware

import (
	"context"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

// RedisRateLimit applies a fixed-window counter in Redis (multi-instance safe).
func RedisRateLimit(redisClient *redis.Client, prefix string, limit int, window time.Duration, keyFn func(*gin.Context) string) gin.HandlerFunc {
	if limit <= 0 {
		limit = 60
	}
	if window <= 0 {
		window = time.Minute
	}
	if prefix == "" {
		prefix = "rl"
	}

	return func(c *gin.Context) {
		if redisClient == nil {
			if services.IsProductionEnv() {
				models.SendError(c, 503, 5003, "Rate limit service unavailable")
				c.Abort()
				return
			}
			c.Next()
			return
		}
		keyPart := c.ClientIP()
		if keyFn != nil {
			if v := strings.TrimSpace(keyFn(c)); v != "" {
				keyPart = v
			}
		}
		redisKey := fmt.Sprintf("rl:%s:%s", prefix, keyPart)

		ctx, cancel := context.WithTimeout(c.Request.Context(), 2*time.Second)
		defer cancel()

		count, err := redisClient.Incr(ctx, redisKey).Result()
		if err != nil {
			if services.IsProductionEnv() {
				models.SendError(c, 503, 5003, "Rate limit service unavailable")
				c.Abort()
				return
			}
			c.Next()
			return
		}
		if count == 1 {
			_ = redisClient.Expire(ctx, redisKey, window).Err()
		}
		if count > int64(limit) {
			models.SendError(c, 429, 2001, "Too many requests, please try again later")
			c.Abort()
			return
		}
		c.Next()
	}
}

// GlobalAPIRateLimit default edge-friendly API throttle (~300/min/IP).
func GlobalAPIRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntDefault("GLOBAL_API_RATE_LIMIT_PER_MIN", 300)
	return RedisRateLimit(redisClient, "global_api", limit, time.Minute, nil)
}

// UploadCompleteRateLimit limits merge attempts per device.
func UploadCompleteRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntDefault("UPLOAD_COMPLETE_RATE_LIMIT_PER_MIN", 12)
	return RedisRateLimit(redisClient, "upload_complete", limit, time.Minute, func(c *gin.Context) string {
		if id := strings.TrimSpace(c.GetString("deviceID")); id != "" {
			return id
		}
		return c.ClientIP()
	})
}

// WSTicketUserRateLimit limits user WS ticket issuance.
func WSTicketUserRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntDefault("WS_TICKET_RATE_LIMIT_PER_MIN", 30)
	return RedisRateLimit(redisClient, "ws_ticket_user", limit, time.Minute, func(c *gin.Context) string {
		if id := strings.TrimSpace(c.GetString("userID")); id != "" {
			return "user:" + id
		}
		return c.ClientIP()
	})
}

// WSTicketDeviceRateLimit limits device WS ticket issuance.
func WSTicketDeviceRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntDefault("WS_TICKET_RATE_LIMIT_PER_MIN", 30)
	return RedisRateLimit(redisClient, "ws_ticket_device", limit, time.Minute, func(c *gin.Context) string {
		if id := strings.TrimSpace(c.GetString("deviceID")); id != "" {
			return "device:" + id
		}
		return c.ClientIP()
	})
}

// WSHandshakeRateLimit limits WebSocket upgrade attempts per IP.
func WSHandshakeRateLimit(redisClient *redis.Client) gin.HandlerFunc {
	limit := envIntDefault("WS_HANDSHAKE_RATE_LIMIT_PER_MIN", 30)
	return RedisRateLimit(redisClient, "ws_handshake", limit, time.Minute, nil)
}

// InternalOpsAuth protects /metrics and /ready in production (X-Ops-Token or Bearer).
func InternalOpsAuth() gin.HandlerFunc {
	return func(c *gin.Context) {
		if !services.IsProductionEnv() {
			c.Next()
			return
		}
		expected := strings.TrimSpace(os.Getenv("OPS_TOKEN"))
		if expected == "" {
			expected = strings.TrimSpace(os.Getenv("METRICS_TOKEN"))
		}
		if expected == "" {
			models.SendError(c, 503, 5003, "Operations endpoint not configured")
			c.Abort()
			return
		}
		got := strings.TrimSpace(c.GetHeader("X-Ops-Token"))
		if got == "" {
			auth := strings.TrimSpace(c.GetHeader("Authorization"))
			if strings.HasPrefix(auth, "Bearer ") {
				got = strings.TrimSpace(strings.TrimPrefix(auth, "Bearer "))
			}
		}
		if got != expected {
			models.SendError(c, 401, 1002, "Unauthorized")
			c.Abort()
			return
		}
		c.Next()
	}
}

func envIntDefault(key string, def int) int {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil || n <= 0 {
		return def
	}
	return n
}

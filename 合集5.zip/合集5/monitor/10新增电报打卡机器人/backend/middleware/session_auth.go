package middleware

import (
	"errors"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

var sessionSvc *services.SessionService

func InitSessionService(svc *services.SessionService) {
	sessionSvc = svc
}

func GetSessionService() *services.SessionService {
	return sessionSvc
}

func abortAuthServiceUnavailable(c *gin.Context) {
	models.SendError(c, 503, 5003, "Authentication service temporarily unavailable")
	c.Abort()
}

func abortAuthError(c *gin.Context, code int, message string) {
	models.SendError(c, code, 1002, message)
	c.Abort()
}

// authenticateSessionJWT parses sid-only JWT and loads active session into context.
func authenticateSessionJWT(c *gin.Context, tokenString string, requireUser, requireDevice bool) bool {
	if sessionSvc == nil {
		abortAuthServiceUnavailable(c)
		return false
	}

	sid, err := services.ParseSessionJWT(tokenString)
	if err != nil {
		if errors.Is(err, jwt.ErrTokenExpired) {
			abortAuthError(c, 401, "Token expired")
		} else {
			abortAuthError(c, 401, "Invalid token")
		}
		return false
	}

	sess, err := sessionSvc.ValidateActiveSession(c.Request.Context(), sid)
	if err != nil {
		switch {
		case errors.Is(err, services.ErrSessionRevoked):
			abortAuthError(c, 401, "Session has been revoked")
		case errors.Is(err, services.ErrSessionExpired):
			abortAuthError(c, 401, "Session expired")
		case errors.Is(err, services.ErrSessionNotFound):
			abortAuthError(c, 401, "Session not found")
		default:
			abortAuthServiceUnavailable(c)
		}
		return false
	}

	c.Set("sessionID", sid)
	c.Set("sessionSubjectType", sess.SubjectType)
	c.Set("sessionSubjectID", sess.SubjectID.String())

	switch sess.SubjectType {
	case services.SessionSubjectUser:
		if requireDevice {
			abortAuthError(c, 403, "Device session required")
			return false
		}
		return populateUserContext(c, sess.SubjectID.String())
	case services.SessionSubjectDevice:
		if requireUser {
			abortAuthError(c, 403, "User session required")
			return false
		}
		deviceID := sess.SubjectID.String()
		c.Set("deviceID", deviceID)
		c.Set("deviceId", deviceID)
		c.Set("device_id", deviceID)
		return true
	default:
		abortAuthError(c, 401, "Invalid session subject")
		return false
	}
}

func populateUserContext(c *gin.Context, userID string) bool {
	if active, ok := loadUserAccountActive(c.Request.Context(), userID); !ok || !active {
		abortAuthError(c, 401, "User account is disabled or not found")
		return false
	}
	c.Set("userID", userID)
	if username, ok := loadUsernameFromDB(c.Request.Context(), userID); ok {
		c.Set("username", username)
	}
	if role, perms, ok := loadUserAuthFromDB(c.Request.Context(), userID); ok {
		c.Set("role", normalizeRoleName(role))
		c.Set("permissions", perms)
	} else {
		abortAuthError(c, 401, "User account is disabled or not found")
		return false
	}
	return true
}

func populateSessionFromAuthSession(c *gin.Context, sess *services.AuthSession) bool {
	c.Set("sessionID", sess.ID.String())
	c.Set("sessionSubjectType", sess.SubjectType)
	c.Set("sessionSubjectID", sess.SubjectID.String())
	switch sess.SubjectType {
	case services.SessionSubjectUser:
		return populateUserContext(c, sess.SubjectID.String())
	case services.SessionSubjectDevice:
		deviceID := sess.SubjectID.String()
		c.Set("deviceID", deviceID)
		c.Set("deviceId", deviceID)
		c.Set("device_id", deviceID)
		return true
	default:
		return false
	}
}

func redeemWSTicket(c *gin.Context, ticket string) (*services.AuthSession, bool) {
	if sessionSvc == nil {
		abortAuthServiceUnavailable(c)
		return nil, false
	}
	sessionID, err := sessionSvc.RedeemWSTicket(c.Request.Context(), ticket)
	if err != nil {
		c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Invalid or expired ticket"})
		return nil, false
	}
	sess, err := sessionSvc.ValidateActiveSession(c.Request.Context(), sessionID)
	if err != nil {
		c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Session is not active"})
		return nil, false
	}
	if !populateSessionFromAuthSession(c, sess) {
		c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Invalid session subject"})
		return nil, false
	}
	return sess, true
}

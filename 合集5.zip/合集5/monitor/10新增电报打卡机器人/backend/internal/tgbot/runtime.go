package tgbot

import (
	"errors"
	"strings"
	"sync"
)

var (
	errMissingWorkerSecret = errors.New("missing worker secret")
	errMissingBotToken     = errors.New("bot token not configured")

	runtimeMu  sync.RWMutex
	activeCfg  config
)

func setActiveConfig(cfg config) {
	runtimeMu.Lock()
	activeCfg = cfg
	runtimeMu.Unlock()
}

// ActiveConfig returns the latest bot runtime configuration.
func ActiveConfig() config {
	runtimeMu.RLock()
	defer runtimeMu.RUnlock()
	return activeCfg
}

// WebhookSecretExpected returns the secret token Telegram should send.
func WebhookSecretExpected() string {
	return strings.TrimSpace(ActiveConfig().WebhookSecret)
}

package tgbot

import (
	"context"
	"log"
	"os"
	"strconv"
	"strings"
)

// Options configures the Telegram bot runner (embedded in backend or standalone).
type Options struct {
	BackendURL    string
	WorkerSecret  string
	BotToken      string
	BotMode       string
	WebhookURL    string
	WebhookSecret string
	WebhookPath   string
	WebhookListen string
	PollTimeout   int
	Embedded      bool
}

func (o Options) toConfig() config {
	cfg := config{
		BackendURL:    strings.TrimRight(strings.TrimSpace(o.BackendURL), "/"),
		WorkerSecret:  strings.TrimSpace(o.WorkerSecret),
		BotToken:      strings.TrimSpace(o.BotToken),
		BotMode:       strings.TrimSpace(o.BotMode),
		WebhookURL:    strings.TrimSpace(o.WebhookURL),
		WebhookSecret: strings.TrimSpace(o.WebhookSecret),
		WebhookPath:   strings.TrimSpace(o.WebhookPath),
		WebhookListen: strings.TrimSpace(o.WebhookListen),
		PollTimeout:   o.PollTimeout,
	}
	if cfg.BotMode == "" {
		cfg.BotMode = "polling"
	}
	if cfg.PollTimeout <= 0 {
		cfg.PollTimeout = 25
	}
	if cfg.WebhookPath == "" {
		cfg.WebhookPath = "/telegram/webhook"
	}
	if cfg.WebhookListen == "" {
		cfg.WebhookListen = ":8081"
	}
	return cfg
}

// ConfigFromOptions exposes the internal runtime config snapshot.
func ConfigFromOptions(o Options) config {
	return o.toConfig()
}

// Run starts polling or webhook mode until ctx is cancelled.
func Run(ctx context.Context, opts Options) error {
	cfg := opts.toConfig()
	if cfg.WorkerSecret == "" {
		return errMissingWorkerSecret
	}
	setActiveConfig(cfg)
	refreshRuntimeConfig(&cfg, "")
	if cfg.BotToken == "" {
		return errMissingBotToken
	}
	if !opts.Embedded {
		startWorkerHeartbeat(cfg)
	}
	logMode := "polling"
	if cfg.useWebhook() {
		logMode = "webhook"
	}
	log.Printf("[tgbot] started backend=%s mode=%s embedded=%v", cfg.BackendURL, logMode, opts.Embedded)
	refreshRuntimeConfig(&cfg, "")
	if len(cachedAdminIDs) > 0 {
		notifyAdminsStartup(cfg, logMode)
	}
	if cfg.useWebhook() {
		if opts.Embedded {
			// Webhook updates are delivered via backend HTTP route; keep config fresh.
			return runEmbeddedWebhook(ctx, cfg)
		}
		runWebhook(cfg)
		return nil
	}
	return runPollingCtx(ctx, cfg)
}

// RunStandalone loads .env and starts the bot (optional external process).
func RunStandalone(ctx context.Context) error {
	_ = loadDotEnv()
	cfg, err := loadStandaloneConfig()
	if err != nil {
		return err
	}
	opts := Options{
		BackendURL:    cfg.BackendURL,
		WorkerSecret:  cfg.WorkerSecret,
		BotToken:      cfg.BotToken,
		BotMode:       cfg.BotMode,
		WebhookURL:    cfg.WebhookURL,
		WebhookSecret: cfg.WebhookSecret,
		WebhookPath:   cfg.WebhookPath,
		WebhookListen: cfg.WebhookListen,
		PollTimeout:   cfg.PollTimeout,
		Embedded:      false,
	}
	return Run(ctx, opts)
}

func loadStandaloneConfig() (config, error) {
	backend := strings.TrimSpace(os.Getenv("BACKEND_URL"))
	if backend == "" {
		backend = "http://127.0.0.1:8080/api/v1"
	}
	backend = strings.TrimRight(backend, "/")

	creds := loadWorkerCredentials()
	if backend == "http://127.0.0.1:8080/api/v1" && creds != nil && creds.BackendURL != "" {
		backend = creds.BackendURL
	}

	secret := strings.TrimSpace(os.Getenv("TELEGRAM_WORKER_SECRET"))
	if secret == "" && creds != nil {
		secret = creds.WorkerSecret
	}

	cfg := config{BackendURL: backend, WorkerSecret: secret}

	pairingCode := strings.TrimSpace(os.Getenv("TELEGRAM_PAIRING_CODE"))
	if cfg.WorkerSecret == "" && pairingCode != "" {
		if err := pairWorker(&cfg, pairingCode); err != nil {
			return config{}, err
		}
	}
	if cfg.WorkerSecret == "" {
		return config{}, errMissingWorkerSecret
	}

	timeout := 25
	if v := strings.TrimSpace(os.Getenv("TELEGRAM_POLL_TIMEOUT")); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			timeout = n
		}
	}
	botMode := strings.TrimSpace(os.Getenv("TELEGRAM_BOT_MODE"))
	if botMode == "" {
		botMode = "polling"
	}
	webhookPath := strings.TrimSpace(os.Getenv("TELEGRAM_WEBHOOK_PATH"))
	if webhookPath == "" {
		webhookPath = "/telegram/webhook"
	}
	webhookListen := strings.TrimSpace(os.Getenv("TELEGRAM_WEBHOOK_LISTEN"))
	if webhookListen == "" {
		if p := strings.TrimSpace(os.Getenv("TELEGRAM_WEBHOOK_PORT")); p != "" {
			webhookListen = ":" + p
		} else if p := strings.TrimSpace(os.Getenv("PORT")); p != "" {
			webhookListen = ":" + p
		} else {
			webhookListen = ":8081"
		}
	}
	cfg.BotToken = strings.TrimSpace(os.Getenv("TELEGRAM_BOT_TOKEN"))
	cfg.PollTimeout = timeout
	cfg.BotMode = botMode
	cfg.WebhookURL = strings.TrimSpace(os.Getenv("TELEGRAM_WEBHOOK_URL"))
	cfg.WebhookSecret = strings.TrimSpace(os.Getenv("TELEGRAM_WEBHOOK_SECRET"))
	cfg.WebhookPath = webhookPath
	cfg.WebhookListen = webhookListen
	return cfg, nil
}

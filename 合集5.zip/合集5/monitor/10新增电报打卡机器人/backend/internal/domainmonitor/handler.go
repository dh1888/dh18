package domainmonitor

import (
	"context"
	"encoding/base64"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/xuri/excelize/v2"

	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/models"
)

type Handler struct {
	repo   *Repository
	engine *Engine
}

func NewHandler(repo *Repository, engine *Engine) *Handler {
	return &Handler{repo: repo, engine: engine}
}

func (h *Handler) Register(rg *gin.RouterGroup) {
	rg.GET("/dashboard/overview", middleware.RequirePermission("domain_monitor:view"), h.Overview)
	rg.GET("/dashboard/trends", middleware.RequirePermission("domain_monitor:view"), h.Trends)
	rg.GET("/dashboard/http-checks", middleware.RequirePermission("domain_monitor:view"), h.HttpChecks)

	rg.GET("/settings/check", middleware.RequirePermission("domain_monitor:settings"), h.GetCheckSettings)
	rg.PUT("/settings/check", middleware.RequirePermission("domain_monitor:settings"), h.SaveCheckSettings)
	rg.POST("/settings/check/test-proxy", middleware.RequirePermission("domain_monitor:settings"), h.TestHttpProxy)

	rg.GET("/groups", middleware.RequirePermission("domain_monitor:view"), h.ListGroups)
	rg.POST("/groups", middleware.RequirePermission("domain_monitor:manage"), h.CreateGroup)
	rg.PUT("/groups/:id", middleware.RequirePermission("domain_monitor:manage"), h.UpdateGroup)
	rg.DELETE("/groups/:id", middleware.RequirePermission("domain_monitor:manage"), h.DeleteGroup)

	rg.GET("/domains", middleware.RequirePermission("domain_monitor:view"), h.ListDomains)
	rg.POST("/domains", middleware.RequirePermission("domain_monitor:manage"), h.CreateDomain)
	rg.GET("/domains/export", middleware.RequirePermission("domain_monitor:view"), h.ExportDomains)
	rg.POST("/domains/import", middleware.RequirePermission("domain_monitor:manage"), h.ImportDomains)
	rg.POST("/domains/batch-update", middleware.RequirePermission("domain_monitor:manage"), h.BatchUpdateDomains)
	rg.POST("/domains/sync-check-interval", middleware.RequirePermission("domain_monitor:manage"), h.SyncDomainCheckIntervals)
	rg.POST("/domains/check-all", middleware.RequirePermission("domain_monitor:manage"), h.CheckAllDomainsNow)
	rg.GET("/domains/check-batch/status", middleware.RequirePermission("domain_monitor:view"), h.CheckBatchStatus)
	rg.GET("/domains/:id", middleware.RequirePermission("domain_monitor:view"), h.GetDomain)
	rg.PUT("/domains/:id", middleware.RequirePermission("domain_monitor:manage"), h.UpdateDomain)
	rg.DELETE("/domains/:id", middleware.RequirePermission("domain_monitor:manage"), h.DeleteDomain)
	rg.POST("/domains/:id/check", middleware.RequirePermission("domain_monitor:manage"), h.CheckDomainNow)
	rg.POST("/domains/:id/content/baseline", middleware.RequirePermission("domain_monitor:manage"), h.ResetContentBaseline)
	rg.GET("/domains/:id/checks", middleware.RequirePermission("domain_monitor:view"), h.ListChecks)
	rg.GET("/domains/:id/reachability", middleware.RequirePermission("domain_monitor:view"), h.GetDomainReachability)
	rg.GET("/domains/:id/cdn-history", middleware.RequirePermission("domain_monitor:view"), h.ListCDNHistory)

	rg.GET("/alerts", middleware.RequirePermission("domain_monitor:view"), h.ListAlerts)
	rg.PUT("/alerts/:id/ack", middleware.RequirePermission("domain_monitor:manage"), h.AckAlert)
	rg.PUT("/alerts/:id/resolve", middleware.RequirePermission("domain_monitor:manage"), h.ResolveAlert)

	rg.GET("/notify/telegram/bots", middleware.RequirePermission("domain_monitor:settings"), h.ListBots)
	rg.POST("/notify/telegram/bots", middleware.RequirePermission("domain_monitor:settings"), h.CreateBot)
	rg.PUT("/notify/telegram/bots/:id", middleware.RequirePermission("domain_monitor:settings"), h.UpdateBot)
	rg.DELETE("/notify/telegram/bots/:id", middleware.RequirePermission("domain_monitor:settings"), h.DeleteBot)
	rg.POST("/notify/telegram/bots/:id/test", middleware.RequirePermission("domain_monitor:settings"), h.TestBot)
	rg.GET("/notify/telegram/bots/:id/groups", middleware.RequirePermission("domain_monitor:settings"), h.DiscoverGroups)
	rg.POST("/notify/telegram/groups", middleware.RequirePermission("domain_monitor:settings"), h.BindGroup)
	rg.GET("/notify/telegram/groups", middleware.RequirePermission("domain_monitor:settings"), h.ListTelegramGroups)
	rg.DELETE("/notify/telegram/groups/:id", middleware.RequirePermission("domain_monitor:settings"), h.DeleteTelegramGroup)
	rg.POST("/notify/telegram/test-push", middleware.RequirePermission("domain_monitor:settings"), h.TestPush)

	rg.GET("/notify/routes", middleware.RequirePermission("domain_monitor:settings"), h.ListRoutes)
	rg.POST("/notify/routes", middleware.RequirePermission("domain_monitor:settings"), h.CreateRoute)
	rg.PUT("/notify/routes/:id", middleware.RequirePermission("domain_monitor:settings"), h.UpdateRoute)
	rg.DELETE("/notify/routes/:id", middleware.RequirePermission("domain_monitor:settings"), h.DeleteRoute)

	rg.GET("/nodes", middleware.RequirePermission("domain_monitor:view"), h.ListNodes)
	rg.GET("/nodes/:id/logs", middleware.RequirePermission("domain_monitor:view"), h.GetNodeLogs)
	rg.POST("/nodes", middleware.RequirePermission("domain_monitor:manage"), h.CreateNode)
	rg.PUT("/nodes/:id", middleware.RequirePermission("domain_monitor:manage"), h.UpdateNode)
	rg.DELETE("/nodes/:id", middleware.RequirePermission("domain_monitor:manage"), h.DeleteNode)

	rg.GET("/reports", middleware.RequirePermission("domain_monitor:view"), h.ListReports)
	rg.POST("/reports/generate", middleware.RequirePermission("domain_monitor:manage"), h.GenerateReport)
	rg.GET("/reports/:id/download", middleware.RequirePermission("domain_monitor:view"), h.DownloadReport)

	rg.GET("/media/screenshot", middleware.RequirePermission("domain_monitor:view"), h.ServeScreenshot)
}

func (h *Handler) Overview(c *gin.Context) {
	stats, err := h.repo.DashboardStats(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if h.engine != nil {
		stats.DroppedCheckJobs, stats.DroppedPriorityJobs = h.engine.QueueMetrics()
	}
	models.Send(c, 200, 0, "success", stats)
}

func (h *Handler) Trends(c *gin.Context) {
	days, _ := strconv.Atoi(c.DefaultQuery("days", "7"))
	items, err := h.repo.AvailabilityTrend(c.Request.Context(), days)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) HttpChecks(c *gin.Context) {
	days, _ := strconv.Atoi(c.DefaultQuery("days", "7"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "500"))
	var domainID *uuid.UUID
	if v := strings.TrimSpace(c.Query("domainId")); v != "" {
		id, err := parseUUID(v)
		if err != nil {
			models.SendError(c, 400, 1001, "invalid domainId")
			return
		}
		domainID = &id
	}
	items, err := h.repo.ListRecentHttpChecks(c.Request.Context(), days, limit, domainID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) GetCheckSettings(c *gin.Context) {
	cfg, err := h.repo.GetCheckSettings(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", sanitizeCheckSettings(cfg))
}

func sanitizeCheckSettings(cfg *CheckSettings) gin.H {
	if cfg == nil {
		return gin.H{}
	}
	configured := strings.TrimSpace(cfg.ProbeRegistrationToken) != ""
	out := *cfg
	out.ProbeRegistrationToken = ""
	data, err := json.Marshal(&out)
	if err != nil {
		return gin.H{}
	}
	var view gin.H
	if err := json.Unmarshal(data, &view); err != nil {
		return gin.H{}
	}
	view["probeRegistrationToken"] = ""
	view["probeRegistrationTokenConfigured"] = configured
	return view
}

func (h *Handler) SaveCheckSettings(c *gin.Context) {
	var req struct {
		DefaultCheckInterval      int    `json:"defaultCheckInterval" binding:"required"`
		SchedulerTickSeconds      int    `json:"schedulerTickSeconds" binding:"required"`
		AutoCheckPriority         bool   `json:"autoCheckPriority"`
		TelegramReportEnabled     bool   `json:"telegramReportEnabled"`
		TelegramRealtimeEnabled   bool   `json:"telegramRealtimeEnabled"`
		ReportServerLabel         string `json:"reportServerLabel"`
		ReportTimezone            string `json:"reportTimezone"`
		ReportTitle               string `json:"reportTitle"`
		WorkerPoolSize            int    `json:"workerPoolSize"`
		HttpTimeoutSeconds        int    `json:"httpTimeoutSeconds"`
		DomainCheckTimeoutSeconds int    `json:"domainCheckTimeoutSeconds"`
		FastDnsCheck              bool   `json:"fastDnsCheck"`
		ScheduleBatchLimit        int    `json:"scheduleBatchLimit"`
		ProbeOnBatchCheck         bool   `json:"probeOnBatchCheck"`
		HttpProxyUrl              string `json:"httpProxyUrl"`
		ProbeRegistrationToken  string `json:"probeRegistrationToken"`
		ApplyToAllDomains         bool   `json:"applyToAllDomains"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	cfg := &CheckSettings{
		DefaultCheckInterval:      req.DefaultCheckInterval,
		SchedulerTickSeconds:      req.SchedulerTickSeconds,
		AutoCheckPriority:         req.AutoCheckPriority,
		TelegramReportEnabled:     req.TelegramReportEnabled,
		TelegramRealtimeEnabled:   req.TelegramRealtimeEnabled,
		ReportServerLabel:         req.ReportServerLabel,
		ReportTimezone:            req.ReportTimezone,
		ReportTitle:               req.ReportTitle,
		WorkerPoolSize:            req.WorkerPoolSize,
		HttpTimeoutSeconds:        req.HttpTimeoutSeconds,
		DomainCheckTimeoutSeconds: req.DomainCheckTimeoutSeconds,
		FastDnsCheck:              req.FastDnsCheck,
		ScheduleBatchLimit:        req.ScheduleBatchLimit,
		ProbeOnBatchCheck:         req.ProbeOnBatchCheck,
		HttpProxyUrl:              req.HttpProxyUrl,
		ProbeRegistrationToken:  req.ProbeRegistrationToken,
	}
	if err := h.repo.SaveCheckSettings(c.Request.Context(), cfg, req.ApplyToAllDomains); err != nil {
		models.SendInternalError(c, err)
		return
	}
	h.engine.ApplyPerformanceSettings(c.Request.Context())
	saved, _ := h.repo.GetCheckSettings(c.Request.Context())
	if saved == nil {
		saved = cfg
	}
	models.Send(c, 200, 0, "success", sanitizeCheckSettings(saved))
}

func (h *Handler) TestHttpProxy(c *gin.Context) {
	var req struct {
		HttpProxyUrl string `json:"httpProxyUrl"`
		TestUrl      string `json:"testUrl"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	proxyURL := strings.TrimSpace(req.HttpProxyUrl)
	if proxyURL == "" {
		settings, err := h.repo.GetCheckSettings(c.Request.Context())
		if err == nil && settings != nil {
			proxyURL = strings.TrimSpace(settings.HttpProxyUrl)
		}
	}
	timeout := 15 * time.Second
	if settings, err := h.repo.GetCheckSettings(c.Request.Context()); err == nil && settings != nil && settings.HttpTimeoutSeconds > 0 {
		timeout = time.Duration(settings.HttpTimeoutSeconds) * time.Second
		if timeout < 10*time.Second {
			timeout = 10 * time.Second
		}
	}
	ctx, cancel := context.WithTimeout(c.Request.Context(), timeout+5*time.Second)
	defer cancel()
	result := testHTTPProxy(ctx, proxyURL, req.TestUrl, timeout)
	if !result.OK {
		models.Send(c, 200, 0, result.Message, result)
		return
	}
	models.Send(c, 200, 0, result.Message, result)
}

func (h *Handler) ListGroups(c *gin.Context) {
	items, err := h.repo.ListGroups(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) CreateGroup(c *gin.Context) {
	var req struct {
		Name        string `json:"name" binding:"required"`
		Description string `json:"description"`
		SortOrder   int    `json:"sortOrder"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	g := &DmGroup{Name: strings.TrimSpace(req.Name), Description: req.Description, SortOrder: req.SortOrder}
	if err := h.repo.CreateGroup(c.Request.Context(), g); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendCreated(c, g)
}

func (h *Handler) UpdateGroup(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	var req struct {
		Name        string `json:"name"`
		Description string `json:"description"`
		SortOrder   int    `json:"sortOrder"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	g := &DmGroup{ID: id, Name: req.Name, Description: req.Description, SortOrder: req.SortOrder}
	if err := h.repo.UpdateGroup(c.Request.Context(), g); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", g)
}

func (h *Handler) DeleteGroup(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.repo.DeleteGroup(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendStatus(c, 200, "deleted")
}

func (h *Handler) ListDomains(c *gin.Context) {
	var enabled *bool
	if v := c.Query("enabled"); v != "" {
		b := v == "true" || v == "1"
		enabled = &b
	}
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "20"))
	items, total, err := h.repo.ListDomains(c.Request.Context(), DomainListFilter{
		GroupID:  c.Query("groupId"),
		Keyword:  c.Query("keyword"),
		Enabled:  enabled,
		Page:     page,
		PageSize: pageSize,
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items, "total": total, "page": page, "pageSize": pageSize})
}

func (h *Handler) CreateDomain(c *gin.Context) {
	var req struct {
		Domain        string   `json:"domain" binding:"required"`
		GroupID       *string  `json:"groupId"`
		Enabled       *bool    `json:"enabled"`
		CheckInterval int      `json:"checkInterval"`
		Remark        string   `json:"remark"`
		EnableDNS     *bool    `json:"enableDns"`
		EnableHTTP    *bool    `json:"enableHttp"`
		EnableSSL     *bool    `json:"enableSsl"`
		EnableWhois   *bool    `json:"enableWhois"`
		EnableContent *bool    `json:"enableContent"`
		EnableScreenshot *bool `json:"enableScreenshot"`
		EnableBlacklist *bool  `json:"enableBlacklist"`
		EnableProbeDetection *bool `json:"enableProbeDetection"`
		EnableProxyDetection *bool `json:"enableProxyDetection"`
		EnableUserSimulation *bool `json:"enableUserSimulation"`
		CheckStrategy     map[string]string `json:"checkStrategy"`
		ProbeNodeScope    string   `json:"probeNodeScope"`
		ProbeNodeIDs      []string `json:"probeNodeIds"`
		ExpectedIPs       []string `json:"expectedIps"`
		ExpectedASN       string   `json:"expectedAsn"`
		ExpectedCDN       string   `json:"expectedCdn"`
		ContentURL    string   `json:"contentUrl"`
		ScreenshotURL string   `json:"screenshotUrl"`
		ContentKeywords []string `json:"contentKeywords"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	d := &DmDomain{
		Domain:        req.Domain,
		Remark:        req.Remark,
		Enabled:       true,
		CheckInterval: h.repo.DefaultCheckInterval(c.Request.Context()),
		EnableDNS:     true,
		EnableHTTP:    true,
		EnableSSL:     true,
	}
	if req.CheckInterval > 0 {
		d.CheckInterval = req.CheckInterval
	}
	if req.Enabled != nil {
		d.Enabled = *req.Enabled
	}
	if req.GroupID != nil && *req.GroupID != "" {
		gid, err := parseUUID(*req.GroupID)
		if err == nil {
			d.GroupID = &gid
		}
	}
	applyDomainCheckFlags(d, req.EnableDNS, req.EnableHTTP, req.EnableSSL, req.EnableWhois, req.EnableContent)
	if req.EnableScreenshot != nil {
		d.EnableScreenshot = *req.EnableScreenshot
	}
	if req.EnableBlacklist != nil {
		d.EnableBlacklist = *req.EnableBlacklist
	}
	applyDomainDetectionFlags(d, req.EnableProbeDetection, req.EnableProxyDetection, req.EnableUserSimulation, req.CheckStrategy, req.ProbeNodeScope, req.ProbeNodeIDs)
	applyDNSExpectations(d, req.ExpectedIPs, req.ExpectedASN, req.ExpectedCDN)
	if req.ScreenshotURL != "" {
		d.ScreenshotURL = strings.TrimSpace(req.ScreenshotURL)
	}
	if req.ContentURL != "" {
		d.ContentURL = strings.TrimSpace(req.ContentURL)
	}
	if req.ContentKeywords != nil {
		d.ContentKeywords = jsonStrings(req.ContentKeywords)
	}
	if err := h.repo.CreateDomain(c.Request.Context(), d); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendCreated(c, d)
}

func (h *Handler) GetDomain(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	d, err := h.repo.GetDomain(c.Request.Context(), id)
	if err != nil || d == nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	checks, _ := h.repo.ListCheckResults(c.Request.Context(), id, "", "", 20)
	models.Send(c, 200, 0, "success", gin.H{"domain": d, "recentChecks": checks})
}

func (h *Handler) UpdateDomain(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	existing, err := h.repo.GetDomain(c.Request.Context(), id)
	if err != nil || existing == nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	var req struct {
		Domain              string   `json:"domain"`
		GroupID             *string  `json:"groupId"`
		Enabled             *bool    `json:"enabled"`
		CheckInterval       *int     `json:"checkInterval"`
		Remark              *string  `json:"remark"`
		EnableDNS           *bool    `json:"enableDns"`
		EnableHTTP          *bool    `json:"enableHttp"`
		EnableSSL           *bool    `json:"enableSsl"`
		EnableWhois         *bool    `json:"enableWhois"`
		EnableContent       *bool    `json:"enableContent"`
		EnableScreenshot    *bool    `json:"enableScreenshot"`
		EnableBlacklist     *bool    `json:"enableBlacklist"`
		EnableProbeDetection *bool   `json:"enableProbeDetection"`
		EnableProxyDetection *bool   `json:"enableProxyDetection"`
		EnableUserSimulation *bool   `json:"enableUserSimulation"`
		CheckStrategy       map[string]string `json:"checkStrategy"`
		ProbeNodeScope      *string  `json:"probeNodeScope"`
		ProbeNodeIDs        []string `json:"probeNodeIds"`
		ExpectedIPs         []string `json:"expectedIps"`
		ExpectedASN         *string  `json:"expectedAsn"`
		ExpectedCDN         *string  `json:"expectedCdn"`
		ContentURL          *string  `json:"contentUrl"`
		ScreenshotURL       *string  `json:"screenshotUrl"`
		ContentHashBaseline *string  `json:"contentHashBaseline"`
		ContentKeywords     []string `json:"contentKeywords"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if req.Domain != "" {
		existing.Domain = req.Domain
	}
	if req.GroupID != nil {
		if *req.GroupID == "" {
			existing.GroupID = nil
		} else if gid, err := parseUUID(*req.GroupID); err == nil {
			existing.GroupID = &gid
		}
	}
	if req.Enabled != nil {
		existing.Enabled = *req.Enabled
	}
	if req.CheckInterval != nil && *req.CheckInterval > 0 {
		existing.CheckInterval = *req.CheckInterval
	}
	if req.Remark != nil {
		existing.Remark = *req.Remark
	}
	if req.EnableDNS != nil {
		existing.EnableDNS = *req.EnableDNS
	}
	if req.EnableHTTP != nil {
		existing.EnableHTTP = *req.EnableHTTP
	}
	if req.EnableSSL != nil {
		existing.EnableSSL = *req.EnableSSL
	}
	if req.EnableWhois != nil {
		existing.EnableWhois = *req.EnableWhois
	}
	if req.EnableContent != nil {
		existing.EnableContent = *req.EnableContent
	}
	if req.EnableScreenshot != nil {
		existing.EnableScreenshot = *req.EnableScreenshot
	}
	if req.EnableBlacklist != nil {
		existing.EnableBlacklist = *req.EnableBlacklist
	}
	if req.EnableProbeDetection != nil {
		existing.EnableProbeDetection = *req.EnableProbeDetection
	}
	if req.EnableProxyDetection != nil {
		existing.EnableProxyDetection = *req.EnableProxyDetection
	}
	if req.EnableUserSimulation != nil {
		existing.EnableUserSimulation = *req.EnableUserSimulation
	}
	if req.CheckStrategy != nil {
		existing.CheckStrategy = jsonStringsMap(req.CheckStrategy)
	}
	if req.ProbeNodeScope != nil {
		existing.ProbeNodeScope = strings.TrimSpace(*req.ProbeNodeScope)
		if existing.ProbeNodeScope == "" {
			existing.ProbeNodeScope = "all"
		}
	}
	if req.ProbeNodeIDs != nil {
		existing.ProbeNodeIDs = jsonStrings(req.ProbeNodeIDs)
	}
	if req.ExpectedIPs != nil {
		existing.ExpectedIPs = jsonStrings(req.ExpectedIPs)
	}
	if req.ExpectedASN != nil {
		existing.ExpectedASN = strings.TrimSpace(*req.ExpectedASN)
	}
	if req.ExpectedCDN != nil {
		existing.ExpectedCDN = strings.TrimSpace(*req.ExpectedCDN)
	}
	if req.ScreenshotURL != nil {
		existing.ScreenshotURL = strings.TrimSpace(*req.ScreenshotURL)
	}
	if req.ContentURL != nil {
		existing.ContentURL = strings.TrimSpace(*req.ContentURL)
	}
	if req.ContentHashBaseline != nil {
		existing.ContentHashBaseline = strings.TrimSpace(*req.ContentHashBaseline)
	}
	if req.ContentKeywords != nil {
		existing.ContentKeywords = jsonStrings(req.ContentKeywords)
	}
	if err := h.repo.UpdateDomain(c.Request.Context(), existing); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", existing)
}

func (h *Handler) DeleteDomain(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.repo.DeleteDomain(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendStatus(c, 200, "deleted")
}

func (h *Handler) CheckDomainNow(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	h.engine.EnqueueDomain(id)
	h.engine.maybeEnqueueProbe(id, false)
	models.Send(c, 200, 0, "success", gin.H{"queued": true})
}

func (h *Handler) CheckAllDomainsNow(c *gin.Context) {
	batchID, queued, err := h.engine.EnqueueAllDomains(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"queued":  queued,
		"total":   queued,
		"batchId": batchID,
	})
}

func (h *Handler) CheckBatchStatus(c *gin.Context) {
	raw := strings.TrimSpace(c.Query("batchId"))
	if raw == "" {
		models.SendError(c, 400, 1001, "batchId required")
		return
	}
	batchID, err := parseUUID(raw)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid batchId")
		return
	}
	st := h.engine.GetCheckBatchStatus(batchID)
	if st == nil {
		models.SendError(c, 404, 2001, "batch not found")
		return
	}
	models.Send(c, 200, 0, "success", st)
}

func (h *Handler) ResetContentBaseline(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	d, err := h.repo.GetDomain(c.Request.Context(), id)
	if err != nil || d == nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	var req struct {
		Hash string `json:"hash"`
	}
	_ = c.ShouldBindJSON(&req)
	hash := strings.TrimSpace(req.Hash)
	if hash == "" {
		checks, _ := h.repo.ListCheckResults(c.Request.Context(), id, "content", "", 1)
		if len(checks) == 0 {
			models.SendError(c, 400, 1001, "no content check result; run check first or provide hash")
			return
		}
		var info struct {
			Hash string `json:"hash"`
		}
		_ = json.Unmarshal([]byte(checks[0].RawDetail), &info)
		hash = info.Hash
	}
	if hash == "" {
		models.SendError(c, 400, 1001, "hash required")
		return
	}
	if err := h.repo.UpdateContentBaseline(c.Request.Context(), id, hash); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"contentHashBaseline": hash})
}

func applyDNSExpectations(d *DmDomain, ips []string, asn, cdn string) {
	if ips != nil {
		d.ExpectedIPs = jsonStrings(ips)
	}
	if strings.TrimSpace(asn) != "" {
		d.ExpectedASN = strings.TrimSpace(asn)
	}
	if strings.TrimSpace(cdn) != "" {
		d.ExpectedCDN = strings.TrimSpace(cdn)
	}
}

func applyDomainDetectionFlags(d *DmDomain, probe, proxy, userSim *bool, strategy map[string]string, scope string, nodeIDs []string) {
	if probe != nil {
		d.EnableProbeDetection = *probe
	}
	if proxy != nil {
		d.EnableProxyDetection = *proxy
	}
	if userSim != nil {
		d.EnableUserSimulation = *userSim
	}
	if strategy != nil {
		d.CheckStrategy = jsonStringsMap(strategy)
	}
	if strings.TrimSpace(scope) != "" {
		d.ProbeNodeScope = strings.TrimSpace(scope)
	}
	if nodeIDs != nil {
		d.ProbeNodeIDs = jsonStrings(nodeIDs)
	}
}

func jsonStringsMap(m map[string]string) string {
	if len(m) == 0 {
		return "{}"
	}
	b, _ := json.Marshal(m)
	return string(b)
}

func applyDomainCheckFlags(d *DmDomain, dns, http, ssl, whois, content *bool) {
	if dns != nil {
		d.EnableDNS = *dns
	}
	if http != nil {
		d.EnableHTTP = *http
	}
	if ssl != nil {
		d.EnableSSL = *ssl
	}
	if whois != nil {
		d.EnableWhois = *whois
	}
	if content != nil {
		d.EnableContent = *content
	}
}

func (h *Handler) ListChecks(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	checkType := c.Query("checkType")
	nodeID := strings.TrimSpace(c.Query("nodeId"))
	items, err := h.repo.ListCheckResults(c.Request.Context(), id, checkType, nodeID, 100)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) GetDomainReachability(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	summary, err := h.engine.GetDomainReachability(c.Request.Context(), id)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", summary)
}

func (h *Handler) ListCDNHistory(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	items, err := h.repo.ListCDNHistory(c.Request.Context(), id, 50)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) ExportDomains(c *gin.Context) {
	items, err := h.repo.ListAllDomains(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	format := strings.ToLower(c.DefaultQuery("format", "csv"))
	if format == "xlsx" {
		h.exportExcel(c, items)
		return
	}
	c.Header("Content-Type", "text/csv; charset=utf-8")
	c.Header("Content-Disposition", "attachment; filename=domains.csv")
	w := csv.NewWriter(c.Writer)
	_ = w.Write([]string{"domain", "group", "enabled", "checkInterval", "remark"})
	for _, d := range items {
		group := ""
		if d.Group != nil {
			group = d.Group.Name
		}
		_ = w.Write([]string{d.Domain, group, strconv.FormatBool(d.Enabled), strconv.Itoa(d.CheckInterval), d.Remark})
	}
	w.Flush()
}

func (h *Handler) exportExcel(c *gin.Context, items []DmDomain) {
	f := excelize.NewFile()
	sheet := "domains"
	_ = f.SetSheetName("Sheet1", sheet)
	headers := []string{"domain", "group", "enabled", "checkInterval", "remark"}
	for i, hname := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		_ = f.SetCellValue(sheet, cell, hname)
	}
	for i, d := range items {
		row := i + 2
		group := ""
		if d.Group != nil {
			group = d.Group.Name
		}
		_ = f.SetCellValue(sheet, fmt.Sprintf("A%d", row), d.Domain)
		_ = f.SetCellValue(sheet, fmt.Sprintf("B%d", row), group)
		_ = f.SetCellValue(sheet, fmt.Sprintf("C%d", row), d.Enabled)
		_ = f.SetCellValue(sheet, fmt.Sprintf("D%d", row), d.CheckInterval)
		_ = f.SetCellValue(sheet, fmt.Sprintf("E%d", row), d.Remark)
	}
	c.Header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Header("Content-Disposition", "attachment; filename=domains.xlsx")
	_ = f.Write(c.Writer)
}

func (h *Handler) ImportDomains(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		models.SendError(c, 400, 1001, "file required")
		return
	}
	f, err := file.Open()
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	defer f.Close()
	rows, err := readImportSpreadsheetRows(f, file.Filename)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	var defaultGroupID *uuid.UUID
	if groupIDStr := strings.TrimSpace(c.PostForm("groupId")); groupIDStr != "" {
		gid, err := parseUUID(groupIDStr)
		if err != nil {
			models.SendError(c, 400, 1001, "invalid groupId")
			return
		}
		defaultGroupID = &gid
	}
	created, skipped := h.importRows(c.Request.Context(), rows, defaultGroupID)
	models.Send(c, 200, 0, "success", gin.H{"created": created, "skipped": skipped})
}

func (h *Handler) BatchUpdateDomains(c *gin.Context) {
	var req struct {
		IDs   []string `json:"ids" binding:"required,min=1"`
		Patch struct {
			GroupID           *string `json:"groupId"`
			UpdateGroup       bool    `json:"updateGroup"`
			ClearGroup        bool    `json:"clearGroup"`
			Enabled           *bool   `json:"enabled"`
			CheckInterval     *int    `json:"checkInterval"`
			SyncCheckInterval bool    `json:"syncCheckInterval"`
			EnableDNS         *bool   `json:"enableDns"`
			EnableHTTP        *bool   `json:"enableHttp"`
			EnableSSL         *bool   `json:"enableSsl"`
			EnableWhois       *bool   `json:"enableWhois"`
			EnableContent     *bool   `json:"enableContent"`
		} `json:"patch" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	ids := make([]uuid.UUID, 0, len(req.IDs))
	for _, raw := range req.IDs {
		id, err := parseUUID(raw)
		if err != nil {
			models.SendError(c, 400, 1001, "invalid domain id")
			return
		}
		ids = append(ids, id)
	}
	patch := DomainBatchPatch{
		UpdateGroup:       req.Patch.UpdateGroup,
		ClearGroup:        req.Patch.ClearGroup,
		Enabled:           req.Patch.Enabled,
		CheckInterval:     req.Patch.CheckInterval,
		SyncCheckInterval: req.Patch.SyncCheckInterval,
		EnableDNS:         req.Patch.EnableDNS,
		EnableHTTP:        req.Patch.EnableHTTP,
		EnableSSL:         req.Patch.EnableSSL,
		EnableWhois:       req.Patch.EnableWhois,
		EnableContent:     req.Patch.EnableContent,
	}
	if req.Patch.UpdateGroup && !req.Patch.ClearGroup {
		if req.Patch.GroupID == nil || strings.TrimSpace(*req.Patch.GroupID) == "" {
			models.SendError(c, 400, 1001, "groupId required when updateGroup is true")
			return
		}
		gid, err := parseUUID(*req.Patch.GroupID)
		if err != nil {
			models.SendError(c, 400, 1001, "invalid groupId")
			return
		}
		patch.GroupID = &gid
	}
	if patch.CheckInterval != nil && *patch.CheckInterval < 60 {
		models.SendError(c, 400, 1001, "checkInterval must be >= 60")
		return
	}
	updated, err := h.repo.BatchUpdateDomains(c.Request.Context(), ids, patch)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"updated": updated})
}

func (h *Handler) SyncDomainCheckIntervals(c *gin.Context) {
	interval := h.repo.DefaultCheckInterval(c.Request.Context())
	updated, err := h.repo.SyncAllDomainCheckIntervals(c.Request.Context(), interval)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{
		"updated":              updated,
		"defaultCheckInterval": interval,
	})
}

func (h *Handler) importRows(ctx context.Context, rows [][]string, defaultGroupID *uuid.UUID) (created, skipped int) {
	cols := detectDomainImportColumns(rows)
	defaultInterval := h.repo.DefaultCheckInterval(ctx)
	for i := cols.startRow; i < len(rows); i++ {
		row := rows[i]
		domainRaw := importCellValue(row, cols.domainCol)
		if domainRaw == "" {
			continue
		}
		domain := normalizeDomain(domainRaw)
		if !isValidDomainName(domain) {
			skipped++
			continue
		}
		if existing, _ := h.repo.GetDomainByName(ctx, domain); existing != nil {
			skipped++
			continue
		}
		item := &DmDomain{
			Domain:        domain,
			Enabled:       parseImportEnabled(importCellValue(row, cols.enabledCol), true),
			CheckInterval: defaultInterval,
			Remark:        importCellValue(row, cols.remarkCol),
			EnableDNS:     true,
			EnableHTTP:    true,
			EnableSSL:     true,
			EnableWhois:   true,
		}
		if defaultGroupID != nil {
			item.GroupID = defaultGroupID
		} else if groupName := importCellValue(row, cols.groupCol); groupName != "" {
			if g, _ := h.repo.GetGroupByName(ctx, groupName); g != nil {
				item.GroupID = &g.ID
			} else {
				g := &DmGroup{Name: groupName}
				if err := h.repo.CreateGroup(ctx, g); err == nil {
					item.GroupID = &g.ID
				}
			}
		}
		if err := h.repo.CreateDomain(ctx, item); err != nil {
			skipped++
			continue
		}
		created++
	}
	return
}

func (h *Handler) ListAlerts(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "20"))
	items, total, err := h.repo.ListAlerts(c.Request.Context(), AlertListFilter{
		Status:   c.Query("status"),
		Severity: c.Query("severity"),
		Page:     page,
		PageSize: pageSize,
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items, "total": total})
}

func (h *Handler) AckAlert(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.repo.UpdateAlertStatus(c.Request.Context(), id, "ack"); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendStatus(c, 200, "ok")
}

func (h *Handler) ResolveAlert(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.repo.UpdateAlertStatus(c.Request.Context(), id, "resolved"); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendStatus(c, 200, "ok")
}

// ---------- Telegram ----------

func (h *Handler) ListBots(c *gin.Context) {
	bots, err := h.repo.ListBots(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	out := make([]gin.H, 0, len(bots))
	for _, b := range bots {
		out = append(out, botResponse(b, h.engine))
	}
	models.Send(c, 200, 0, "success", out)
}

func botResponse(b DmTelegramBot, engine *Engine) gin.H {
	masked := "******"
	if b.BotTokenEnc != "" {
		if plain, err := engine.DecryptBotToken(b.BotTokenEnc); err == nil {
			masked = MaskToken(plain)
		}
	}
	return gin.H{
		"id": b.ID, "botName": b.BotName, "botToken": masked, "botUsername": b.BotUsername,
		"botId": b.BotID, "enabled": b.Enabled, "remark": b.Remark, "verifiedAt": b.VerifiedAt,
		"createdAt": b.CreatedAt, "updatedAt": b.UpdatedAt,
	}
}

func (h *Handler) CreateBot(c *gin.Context) {
	var req struct {
		BotName  string `json:"botName" binding:"required"`
		BotToken string `json:"botToken" binding:"required"`
		Enabled  *bool  `json:"enabled"`
		Remark   string `json:"remark"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	enc, err := h.engine.EncryptBotToken(req.BotToken)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	b := &DmTelegramBot{BotName: req.BotName, BotTokenEnc: enc, Remark: req.Remark, Enabled: true}
	if req.Enabled != nil {
		b.Enabled = *req.Enabled
	}
	if err := h.repo.SaveBot(c.Request.Context(), b); err != nil {
		models.SendInternalError(c, err)
		return
	}
	_ = h.engine.VerifyBot(c.Request.Context(), b)
	b2, _ := h.repo.GetBot(c.Request.Context(), b.ID)
	models.SendCreated(c, botResponse(*b2, h.engine))
}

func (h *Handler) UpdateBot(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	b, err := h.repo.GetBot(c.Request.Context(), id)
	if err != nil || b == nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	var req struct {
		BotName  string `json:"botName"`
		BotToken string `json:"botToken"`
		Enabled  *bool  `json:"enabled"`
		Remark   *string `json:"remark"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if req.BotName != "" {
		b.BotName = req.BotName
	}
	if req.BotToken != "" && !strings.Contains(req.BotToken, "******") {
		enc, err := h.engine.EncryptBotToken(req.BotToken)
		if err != nil {
			models.SendError(c, 400, 1001, err.Error())
			return
		}
		b.BotTokenEnc = enc
	}
	if req.Enabled != nil {
		b.Enabled = *req.Enabled
	}
	if req.Remark != nil {
		b.Remark = *req.Remark
	}
	if err := h.repo.SaveBot(c.Request.Context(), b); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", botResponse(*b, h.engine))
}

func (h *Handler) DeleteBot(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.repo.DeleteBot(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendStatus(c, 200, "deleted")
}

func (h *Handler) TestBot(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	b, err := h.repo.GetBot(c.Request.Context(), id)
	if err != nil || b == nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	if err := h.engine.VerifyBot(c.Request.Context(), b); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	b2, _ := h.repo.GetBot(c.Request.Context(), id)
	models.Send(c, 200, 0, "success", gin.H{
		"valid": true, "botId": b2.BotID, "botName": b2.BotName, "username": b2.BotUsername,
	})
}

func (h *Handler) DiscoverGroups(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	b, err := h.repo.GetBot(c.Request.Context(), id)
	if err != nil || b == nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	token, err := h.engine.DecryptBotToken(b.BotTokenEnc)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	groups, err := telegramGetRecentGroups(token)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", groups)
}

func (h *Handler) BindGroup(c *gin.Context) {
	var req struct {
		BotID     string `json:"botId" binding:"required"`
		GroupName string `json:"groupName" binding:"required"`
		ChatID    string `json:"chatId" binding:"required"`
		ChatType  string `json:"chatType"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	botID, err := parseUUID(req.BotID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid botId")
		return
	}
	g := &DmTelegramGroup{BotID: botID, GroupName: req.GroupName, ChatID: req.ChatID, ChatType: req.ChatType, Enabled: true}
	if err := h.repo.UpsertTelegramGroup(c.Request.Context(), g); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendCreated(c, g)
}

func (h *Handler) ListTelegramGroups(c *gin.Context) {
	var items []DmTelegramGroup
	var err error
	if v := c.Query("botId"); v != "" {
		id, parseErr := parseUUID(v)
		if parseErr != nil {
			models.SendError(c, 400, 1001, "invalid botId")
			return
		}
		items, err = h.repo.ListGroupsByBot(c.Request.Context(), id)
	} else {
		items, err = h.repo.ListTelegramGroups(c.Request.Context(), nil)
	}
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) DeleteTelegramGroup(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.repo.DeleteTelegramGroup(c.Request.Context(), id); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

func (h *Handler) TestPush(c *gin.Context) {
	var req struct {
		BotID  string `json:"botId" binding:"required"`
		ChatID string `json:"chatId" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	botID, err := parseUUID(req.BotID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid botId")
		return
	}
	b, err := h.repo.GetBot(c.Request.Context(), botID)
	if err != nil || b == nil {
		models.SendError(c, 404, 2001, "bot not found")
		return
	}
	token, err := h.engine.DecryptBotToken(b.BotTokenEnc)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	settings, _ := h.repo.GetCheckSettings(c.Request.Context())
	text := formatTelegramTestText(settings, b.BotName, b.BotUsername, req.ChatID)
	if err := telegramSendMessage(token, req.ChatID, text); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"sent": true})
}

func (h *Handler) ListRoutes(c *gin.Context) {
	items, err := h.repo.ListRoutes(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) CreateRoute(c *gin.Context) {
	var req struct {
		Name       string   `json:"name" binding:"required"`
		AlertTypes []string `json:"alertTypes"`
		Severities []string `json:"severities"`
		GroupID    string   `json:"groupId" binding:"required"`
		SendMode   string   `json:"sendMode"`
		Enabled    *bool    `json:"enabled"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	gid, err := parseUUID(req.GroupID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid groupId")
		return
	}
	rt := &DmAlertRoute{
		Name: req.Name, AlertTypes: jsonStrings(req.AlertTypes), Severities: jsonStrings(req.Severities),
		GroupID: gid, SendMode: req.SendMode, Enabled: true,
	}
	if rt.SendMode == "" {
		rt.SendMode = "realtime"
	}
	if req.Enabled != nil {
		rt.Enabled = *req.Enabled
	}
	if err := h.repo.SaveRoute(c.Request.Context(), rt); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendCreated(c, rt)
}

func (h *Handler) UpdateRoute(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	var req struct {
		Name       string   `json:"name"`
		AlertTypes []string `json:"alertTypes"`
		Severities []string `json:"severities"`
		GroupID    string   `json:"groupId"`
		SendMode   string   `json:"sendMode"`
		Enabled    *bool    `json:"enabled"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	routes, _ := h.repo.ListRoutes(c.Request.Context())
	var rt *DmAlertRoute
	for i := range routes {
		if routes[i].ID == id {
			rt = &routes[i]
			break
		}
	}
	if rt == nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	if req.Name != "" {
		rt.Name = req.Name
	}
	if req.AlertTypes != nil {
		rt.AlertTypes = jsonStrings(req.AlertTypes)
	}
	if req.Severities != nil {
		rt.Severities = jsonStrings(req.Severities)
	}
	if req.GroupID != "" {
		if gid, err := parseUUID(req.GroupID); err == nil {
			rt.GroupID = gid
		}
	}
	if req.SendMode != "" {
		rt.SendMode = req.SendMode
	}
	if req.Enabled != nil {
		rt.Enabled = *req.Enabled
	}
	if err := h.repo.SaveRoute(c.Request.Context(), rt); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", rt)
}

func (h *Handler) DeleteRoute(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.repo.DeleteRoute(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendStatus(c, 200, "deleted")
}

// RegisterProbe 探针节点 API（X-DM-Node-Key 认证，不走 JWT）
func (h *Handler) RegisterProbe(rg *gin.RouterGroup) {
	rg.POST("/register", middleware.RateLimitByIP(6, 3), h.ProbeRegister)
	rg.POST("/heartbeat", h.ProbeHeartbeat)
	rg.GET("/tasks", h.ProbeTasks)
	rg.POST("/results", h.ProbeSubmitResults)
}

func (h *Handler) ProbeRegister(c *gin.Context) {
	var req struct {
		RegistrationToken string `json:"registrationToken" binding:"required"`
		NodeName          string `json:"nodeName" binding:"required"`
		Country           string `json:"country"`
		City              string `json:"city"`
		PublicIP          string `json:"publicIp"`
		Version           string `json:"version"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	cfg, _ := h.repo.GetCheckSettings(c.Request.Context())
	expected := ""
	if cfg != nil {
		expected = strings.TrimSpace(cfg.ProbeRegistrationToken)
	}
	if expected == "" || !strings.EqualFold(expected, strings.TrimSpace(req.RegistrationToken)) {
		models.SendError(c, 401, 1002, "invalid registration token")
		return
	}
	apiKey, err := GenerateNodeAPIKey()
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	n := &DmNode{
		Name:       strings.TrimSpace(req.NodeName),
		APIKeyHash: hashNodeKey(apiKey),
		Country:    defaultStr(req.Country, "CN"),
		City:       strings.TrimSpace(req.City),
		PublicIP:   strings.TrimSpace(req.PublicIP),
		Version:    strings.TrimSpace(req.Version),
		Enabled:    true,
	}
	if err := h.repo.SaveNode(c.Request.Context(), n); err != nil {
		models.SendInternalError(c, err)
		return
	}
	_ = h.repo.UpdateNodeHeartbeat(c.Request.Context(), n.ID, n.PublicIP, n.Version, 0, 0)
	models.SendCreated(c, gin.H{
		"nodeId": n.ID, "name": n.Name, "apiKey": apiKey,
	})
}

func (h *Handler) probeNode(c *gin.Context) (*DmNode, bool) {
	key := strings.TrimSpace(c.GetHeader("X-DM-Node-Key"))
	if key == "" {
		models.SendError(c, 401, 1002, "missing X-DM-Node-Key")
		return nil, false
	}
	node, err := h.repo.GetNodeByAPIKey(c.Request.Context(), key)
	if err != nil || node == nil {
		models.SendError(c, 401, 1002, "invalid node key")
		return nil, false
	}
	return node, true
}

func (h *Handler) probeHeartbeatMeta(c *gin.Context) (publicIP, version string, cpu, mem float64) {
	var req struct {
		PublicIP      string  `json:"publicIp"`
		Version       string  `json:"version"`
		CPUPercent    float64 `json:"cpuPercent"`
		MemoryPercent float64 `json:"memoryPercent"`
	}
	_ = c.ShouldBindJSON(&req)
	return strings.TrimSpace(req.PublicIP), strings.TrimSpace(req.Version), req.CPUPercent, req.MemoryPercent
}

func (h *Handler) ProbeHeartbeat(c *gin.Context) {
	node, ok := h.probeNode(c)
	if !ok {
		return
	}
	publicIP, version, cpu, mem := h.probeHeartbeatMeta(c)
	_ = h.repo.UpdateNodeHeartbeat(c.Request.Context(), node.ID, publicIP, version, cpu, mem)
	models.Send(c, 200, 0, "success", gin.H{"nodeId": node.ID, "name": node.Name})
}

func (h *Handler) ProbeTasks(c *gin.Context) {
	node, ok := h.probeNode(c)
	if !ok {
		return
	}
	tasks, err := h.repo.ClaimProbeTasks(c.Request.Context(), node.ID, 10)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	checkCfg, _ := h.repo.GetCheckSettings(c.Request.Context())
	proxyURL := ""
	fastDNS := true
	if checkCfg != nil {
		proxyURL = strings.TrimSpace(checkCfg.HttpProxyUrl)
		fastDNS = checkCfg.FastDnsCheck
	}
	out := make([]gin.H, 0, len(tasks))
	for _, t := range tasks {
		if t.Domain == nil {
			continue
		}
		var specs []ProbeCheckSpec
		if strings.TrimSpace(t.CheckSpecs) != "" && t.CheckSpecs != "[]" {
			_ = json.Unmarshal([]byte(t.CheckSpecs), &specs)
		}
		if len(specs) == 0 {
			specs = buildProbeChecks(t.Domain, proxyURL, fastDNS)
		}
		if len(specs) == 0 {
			specs = []ProbeCheckSpec{{Type: "http", URL: probeTargetURL(t.Domain, "http")}}
		}
		out = append(out, gin.H{
			"taskId":   t.ID,
			"domainId": t.DomainID,
			"domain":   t.Domain.Domain,
			"checks":   specs,
		})
	}
	models.Send(c, 200, 0, "success", out)
}

func probeURL(d *DmDomain) string {
	return probeTargetURL(d, "http")
}

func (h *Handler) GetNodeLogs(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	items, err := h.repo.ListNodeProbeTasks(c.Request.Context(), id, 50)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) ProbeSubmitResults(c *gin.Context) {
	node, ok := h.probeNode(c)
	if !ok {
		return
	}
	var req struct {
		TaskID           string          `json:"taskId" binding:"required"`
		Results          []ProbeResultIn `json:"results"`
		ScreenshotBase64 string          `json:"screenshotBase64"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	taskID, err := parseUUID(req.TaskID)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid taskId")
		return
	}
	var shot []byte
	if req.ScreenshotBase64 != "" {
		shot, err = base64.StdEncoding.DecodeString(req.ScreenshotBase64)
		if err != nil {
			models.SendError(c, 400, 1001, "invalid screenshot base64")
			return
		}
	}
	if err := h.engine.IngestProbeResults(c.Request.Context(), node, taskID, req.Results, shot); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"accepted": true})
}

func (h *Handler) ListNodes(c *gin.Context) {
	items, err := h.repo.ListNodes(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) CreateNode(c *gin.Context) {
	var req struct {
		Name    string `json:"name" binding:"required"`
		Country string `json:"country"`
		City    string `json:"city"`
		Enabled *bool  `json:"enabled"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	apiKey, err := GenerateNodeAPIKey()
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	n := &DmNode{
		Name:       strings.TrimSpace(req.Name),
		APIKeyHash: hashNodeKey(apiKey),
		Country:    defaultStr(req.Country, "CN"),
		City:       req.City,
		Enabled:    true,
	}
	if req.Enabled != nil {
		n.Enabled = *req.Enabled
	}
	if err := h.repo.SaveNode(c.Request.Context(), n); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendCreated(c, gin.H{
		"id": n.ID, "name": n.Name, "country": n.Country, "city": n.City,
		"enabled": n.Enabled, "apiKey": apiKey,
	})
}

func defaultStr(v, def string) string {
	if strings.TrimSpace(v) == "" {
		return def
	}
	return strings.TrimSpace(v)
}

func (h *Handler) UpdateNode(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	n, err := h.repo.GetNode(c.Request.Context(), id)
	if err != nil || n == nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	var req struct {
		Name    string `json:"name"`
		Country string `json:"country"`
		City    string `json:"city"`
		Enabled *bool  `json:"enabled"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if req.Name != "" {
		n.Name = req.Name
	}
	if req.Country != "" {
		n.Country = req.Country
	}
	if req.City != "" {
		n.City = req.City
	}
	if req.Enabled != nil {
		n.Enabled = *req.Enabled
	}
	if err := h.repo.SaveNode(c.Request.Context(), n); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", n)
}

func (h *Handler) DeleteNode(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.repo.DeleteNode(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.SendStatus(c, 200, "deleted")
}

func (h *Handler) ListReports(c *gin.Context) {
	items, err := h.repo.ListReports(c.Request.Context(), 50)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) GenerateReport(c *gin.Context) {
	var req struct {
		ReportType string `json:"reportType"`
	}
	_ = c.ShouldBindJSON(&req)
	reportType := strings.ToLower(req.ReportType)
	if reportType == "" {
		reportType = "daily"
	}
	now := time.Now().UTC()
	var start, end time.Time
	if reportType == "weekly" {
		start = now.AddDate(0, 0, -7).Truncate(24 * time.Hour)
		end = now
	} else {
		start = now.AddDate(0, 0, -1).Truncate(24 * time.Hour)
		end = now
	}
	if err := h.engine.GenerateReport(c.Request.Context(), reportType, start, end); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"generated": true})
}

func (h *Handler) DownloadReport(c *gin.Context) {
	id, err := parseUUID(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	rep, err := h.repo.GetReport(c.Request.Context(), id)
	if err != nil || rep == nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	full := filepath.Join(uploadsDir(), filepath.FromSlash(rep.FilePath))
	if !strings.HasPrefix(filepath.Clean(full), filepath.Clean(uploadsDir())) {
		models.SendError(c, 400, 1001, "invalid path")
		return
	}
	c.FileAttachment(full, filepath.Base(full))
}

func (h *Handler) ServeScreenshot(c *gin.Context) {
	rel := strings.TrimSpace(c.Query("path"))
	if rel == "" || strings.Contains(rel, "..") {
		models.SendError(c, 400, 1001, "invalid path")
		return
	}
	full := filepath.Join(uploadsDir(), filepath.FromSlash(rel))
	if !strings.HasPrefix(filepath.Clean(full), filepath.Clean(uploadsDir())) {
		models.SendError(c, 400, 1001, "invalid path")
		return
	}
	if _, err := os.Stat(full); err != nil {
		models.SendError(c, 404, 2001, "not found")
		return
	}
	c.File(full)
}

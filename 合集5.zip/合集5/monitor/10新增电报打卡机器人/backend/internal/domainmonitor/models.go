package domainmonitor

import (
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// P0 数据模型（仅 dm_* 表，GORM 仅在本模块使用）

type DmGroup struct {
	ID          uuid.UUID `gorm:"type:uuid;primaryKey" json:"id"`
	Name        string    `gorm:"size:64;uniqueIndex;not null" json:"name"`
	Description string    `gorm:"type:text" json:"description"`
	SortOrder   int       `gorm:"not null;default:0" json:"sortOrder"`
	CreatedAt   time.Time `json:"createdAt"`
	UpdatedAt   time.Time `json:"updatedAt"`
}

func (DmGroup) TableName() string { return "dm_groups" }

type DmDomain struct {
	ID             uuid.UUID  `gorm:"type:uuid;primaryKey" json:"id"`
	GroupID        *uuid.UUID `gorm:"type:uuid;index" json:"groupId"`
	Group          *DmGroup   `gorm:"foreignKey:GroupID" json:"group,omitempty"`
	Domain         string     `gorm:"size:255;uniqueIndex;not null" json:"domain"`
	Enabled        bool       `gorm:"not null;default:true" json:"enabled"`
	CheckInterval  int        `gorm:"not null;default:300" json:"checkInterval"`
	Remark         string     `gorm:"type:text" json:"remark"`
	EnableDNS      bool       `gorm:"not null;default:true" json:"enableDns"`
	EnableHTTP     bool       `gorm:"not null;default:true" json:"enableHttp"`
	EnableSSL      bool       `gorm:"not null;default:true" json:"enableSsl"`
	EnableWhois    bool       `gorm:"not null;default:false" json:"enableWhois"`
	EnableContent  bool       `gorm:"not null;default:false" json:"enableContent"`
	ContentURL     string     `gorm:"type:text" json:"contentUrl"`
	ContentHashBaseline string `gorm:"size:64" json:"contentHashBaseline"`
	ContentKeywords string    `gorm:"type:jsonb" json:"contentKeywords"`
	LastCheckAt    *time.Time `json:"lastCheckAt"`
	LastDNSStatus  string     `gorm:"size:16;default:'unknown'" json:"lastDnsStatus"`
	LastHTTPStatus string     `gorm:"size:16;default:'unknown'" json:"lastHttpStatus"`
	LastHTTPDurationMs int    `gorm:"not null;default:0" json:"lastHttpDurationMs"`
	LastSSLStatus  string     `gorm:"size:16;default:'unknown'" json:"lastSslStatus"`
	LastWhoisStatus string    `gorm:"size:16;default:'unknown'" json:"lastWhoisStatus"`
	LastContentStatus string  `gorm:"size:16;default:'unknown'" json:"lastContentStatus"`
	EnableScreenshot  bool    `gorm:"not null;default:false" json:"enableScreenshot"`
	ScreenshotURL     string  `gorm:"type:text" json:"screenshotUrl"`
	LastScreenshotStatus string `gorm:"size:16;default:'unknown'" json:"lastScreenshotStatus"`
	EnableBlacklist   bool    `gorm:"not null;default:false" json:"enableBlacklist"`
	EnableProbeDetection bool `gorm:"not null;default:false" json:"enableProbeDetection"`
	EnableProxyDetection bool `gorm:"not null;default:false" json:"enableProxyDetection"`
	EnableUserSimulation bool `gorm:"not null;default:false" json:"enableUserSimulation"`
	CheckStrategy     string  `gorm:"type:jsonb;not null;default:'{}'" json:"checkStrategy"`
	ProbeNodeScope    string  `gorm:"size:16;not null;default:'all'" json:"probeNodeScope"`
	ProbeNodeIDs      string  `gorm:"type:jsonb;not null;default:'[]'" json:"probeNodeIds"`
	HealthLevel       string  `gorm:"size:16;not null;default:'normal'" json:"healthLevel"`
	ReachabilityPct   float64 `gorm:"not null;default:100" json:"reachabilityPct"`
	ProbeNodeSummary  string  `gorm:"type:jsonb;not null;default:'{}'" json:"probeNodeSummary"`
	ExpectedIPs       string  `gorm:"type:jsonb;not null;default:'[]'" json:"expectedIps"`
	ExpectedASN       string  `gorm:"size:32" json:"expectedAsn"`
	ExpectedCDN       string  `gorm:"size:64" json:"expectedCdn"`
	LastCDNProvider   string  `gorm:"size:64" json:"lastCdnProvider"`
	WhoisExpireAt  *time.Time `json:"whoisExpireAt"`
	CreatedAt      time.Time  `json:"createdAt"`
	UpdatedAt      time.Time  `json:"updatedAt"`
}

func (DmDomain) TableName() string { return "dm_domains" }

type DmCheckResult struct {
	ID              uuid.UUID `gorm:"type:uuid;primaryKey" json:"id"`
	DomainID        uuid.UUID `gorm:"type:uuid;index;not null" json:"domainId"`
	NodeID          string    `gorm:"size:64;not null;default:'local'" json:"nodeId"`
	NodeName        string    `gorm:"size:128;not null;default:'Local Center'" json:"nodeName"`
	Country         string    `gorm:"size:8;not null;default:'CN'" json:"country"`
	City            string    `gorm:"size:64" json:"city"`
	CheckType       string    `gorm:"size:32;not null;index" json:"checkType"`
	Status          string    `gorm:"size:16;not null" json:"status"`
	DurationMs      int       `json:"durationMs"`
	HTTPStatus      int       `json:"httpStatus"`
	FinalURL        string    `gorm:"type:text" json:"finalUrl"`
	RedirectChain   string    `gorm:"type:jsonb" json:"redirectChain"`
	DNSRecords      string    `gorm:"type:jsonb" json:"dnsRecords"`
	SSLInfo         string    `gorm:"type:jsonb" json:"sslInfo"`
	RawDetail       string    `gorm:"type:jsonb" json:"rawDetail"`
	ScreenshotPath  string    `gorm:"type:text" json:"screenshotPath"`
	CheckedAt       time.Time `gorm:"index;not null" json:"checkedAt"`
}

func (DmCheckResult) TableName() string { return "dm_check_results" }

type DmCDNHistory struct {
	ID               uuid.UUID `gorm:"type:uuid;primaryKey" json:"id"`
	DomainID         uuid.UUID `gorm:"type:uuid;index;not null" json:"domainId"`
	PreviousProvider string    `gorm:"size:64" json:"previousProvider"`
	CurrentProvider  string    `gorm:"size:64;not null" json:"currentProvider"`
	DetectedAt       time.Time `gorm:"index;not null" json:"detectedAt"`
}

func (DmCDNHistory) TableName() string { return "dm_cdn_history" }

type DmAlert struct {
	ID         uuid.UUID  `gorm:"type:uuid;primaryKey" json:"id"`
	DomainID   *uuid.UUID `gorm:"type:uuid;index" json:"domainId"`
	AlertType  string     `gorm:"size:64;not null;index" json:"alertType"`
	Severity   string     `gorm:"size:16;not null" json:"severity"`
	Title      string     `gorm:"size:256;not null" json:"title"`
	Message    string     `gorm:"type:text;not null" json:"message"`
	Status     string     `gorm:"size:16;not null;default:'open';index" json:"status"`
	NodeID     string     `gorm:"size:64" json:"nodeId"`
	FirstAt    time.Time  `json:"firstAt"`
	LastAt     time.Time  `json:"lastAt"`
	ResolvedAt *time.Time `json:"resolvedAt"`
}

func (DmAlert) TableName() string { return "dm_alerts" }

type DmTelegramBot struct {
	ID           uuid.UUID  `gorm:"type:uuid;primaryKey" json:"id"`
	BotName      string     `gorm:"size:128;not null" json:"botName"`
	BotTokenEnc  string     `gorm:"type:text;not null" json:"-"`
	BotUsername  string     `gorm:"size:64" json:"botUsername"`
	BotID        int64      `json:"botId"`
	Enabled      bool       `gorm:"not null;default:true" json:"enabled"`
	Remark       string     `gorm:"type:text" json:"remark"`
	VerifiedAt   *time.Time `json:"verifiedAt"`
	CreatedAt    time.Time  `json:"createdAt"`
	UpdatedAt    time.Time  `json:"updatedAt"`
}

func (DmTelegramBot) TableName() string { return "dm_telegram_bots" }

type DmTelegramGroup struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey" json:"id"`
	BotID     uuid.UUID `gorm:"type:uuid;index;not null" json:"botId"`
	GroupName string    `gorm:"size:256;not null" json:"groupName"`
	ChatID    string    `gorm:"size:64;not null" json:"chatId"`
	ChatType  string    `gorm:"size:32" json:"chatType"`
	Enabled   bool      `gorm:"not null;default:true" json:"enabled"`
	CreatedAt time.Time `json:"createdAt"`
}

func (DmTelegramGroup) TableName() string { return "dm_telegram_groups" }

type DmAlertRoute struct {
	ID         uuid.UUID `gorm:"type:uuid;primaryKey" json:"id"`
	Name       string    `gorm:"size:128;not null" json:"name"`
	AlertTypes string    `gorm:"type:jsonb;not null" json:"alertTypes"`
	Severities string    `gorm:"type:jsonb;not null" json:"severities"`
	GroupID    uuid.UUID `gorm:"type:uuid;not null" json:"groupId"`
	SendMode   string    `gorm:"size:16;not null;default:'realtime'" json:"sendMode"`
	Enabled    bool      `gorm:"not null;default:true" json:"enabled"`
	CreatedAt  time.Time `json:"createdAt"`
}

func (DmAlertRoute) TableName() string { return "dm_alert_routes" }

type DmNode struct {
	ID            uuid.UUID  `gorm:"type:uuid;primaryKey" json:"id"`
	Name          string     `gorm:"size:128;not null" json:"name"`
	APIKeyHash    string     `gorm:"size:64;uniqueIndex;not null" json:"-"`
	Country       string     `gorm:"size:8;not null;default:'CN'" json:"country"`
	City          string     `gorm:"size:64" json:"city"`
	PublicIP      string     `gorm:"size:64" json:"publicIp"`
	Version       string     `gorm:"size:32" json:"version"`
	CPUPercent    float64    `gorm:"not null;default:0" json:"cpuPercent"`
	MemoryPercent float64    `gorm:"not null;default:0" json:"memoryPercent"`
	Enabled       bool       `gorm:"not null;default:true" json:"enabled"`
	LastSeenAt    *time.Time `json:"lastSeenAt"`
	CreatedAt     time.Time  `json:"createdAt"`
	UpdatedAt     time.Time  `json:"updatedAt"`
}

func (DmNode) TableName() string { return "dm_nodes" }

type DmProbeTask struct {
	ID          uuid.UUID  `gorm:"type:uuid;primaryKey" json:"id"`
	DomainID    uuid.UUID  `gorm:"type:uuid;index;not null" json:"domainId"`
	Domain      *DmDomain  `gorm:"foreignKey:DomainID" json:"domain,omitempty"`
	NodeID      uuid.UUID  `gorm:"type:uuid;index;not null" json:"nodeId"`
	Status      string     `gorm:"size:16;not null;default:'pending'" json:"status"`
	CheckSpecs  string     `gorm:"type:jsonb;not null;default:'[]'" json:"checkSpecs"`
	CreatedAt   time.Time  `json:"createdAt"`
	CompletedAt *time.Time `json:"completedAt"`
}

func (DmProbeTask) TableName() string { return "dm_probe_tasks" }

type DmReport struct {
	ID          uuid.UUID `gorm:"type:uuid;primaryKey" json:"id"`
	ReportType  string    `gorm:"size:16;not null" json:"reportType"`
	PeriodStart time.Time `json:"periodStart"`
	PeriodEnd   time.Time `json:"periodEnd"`
	FilePath    string    `gorm:"type:text;not null" json:"filePath"`
	Summary     string    `gorm:"type:jsonb" json:"summary"`
	CreatedAt   time.Time `json:"createdAt"`
}

func (DmReport) TableName() string { return "dm_reports" }

const (
	settingDefaultCheckInterval  = "default_check_interval"
	settingSchedulerTickSeconds  = "scheduler_tick_seconds"
	settingAutoCheckPriority     = "auto_check_priority"
	settingTelegramReportEnabled     = "telegram_report_enabled"
	settingTelegramRealtimeEnabled   = "telegram_realtime_enabled"
	settingReportServerLabel     = "report_server_label"
	settingReportTimezone        = "report_timezone"
	settingReportTitle           = "report_title"
	settingWorkerPoolSize        = "worker_pool_size"
	settingHttpTimeoutSeconds    = "http_timeout_seconds"
	settingDomainCheckTimeoutSec = "domain_check_timeout_seconds"
	settingFastDnsCheck          = "fast_dns_check"
	settingScheduleBatchLimit    = "schedule_batch_limit"
	settingProbeOnBatchCheck     = "probe_on_batch_check"
	settingHttpProxyUrl          = "http_proxy_url"
	settingProbeRegistrationToken = "probe_registration_token"
)

type DmSetting struct {
	Key       string    `gorm:"size:64;primaryKey" json:"key"`
	Value     string    `gorm:"type:text;not null" json:"value"`
	UpdatedAt time.Time `json:"updatedAt"`
}

func (DmSetting) TableName() string { return "dm_settings" }

type CheckSettings struct {
	DefaultCheckInterval      int    `json:"defaultCheckInterval"`
	SchedulerTickSeconds      int    `json:"schedulerTickSeconds"`
	AutoCheckPriority         bool   `json:"autoCheckPriority"`
	TelegramReportEnabled     bool   `json:"telegramReportEnabled"`
	TelegramRealtimeEnabled   bool   `json:"telegramRealtimeEnabled"`
	ReportServerLabel         string `json:"reportServerLabel"`
	ReportTimezone            string `json:"reportTimezone"`
	ReportTitle               string `json:"reportTitle"`
	WorkerPoolSize            int    `json:"workerPoolSize"`
	HttpTimeoutSeconds        int    `json:"httpTimeoutSeconds"`
	DomainCheckTimeoutSeconds int    `json:"domainCheckTimeoutSeconds"`
	FastDnsCheck              bool   `json:"fastDnsCheck"`
	ScheduleBatchLimit        int    `json:"scheduleBatchLimit"`
	ProbeOnBatchCheck         bool   `json:"probeOnBatchCheck"`
	HttpProxyUrl              string `json:"httpProxyUrl"`
	ProbeRegistrationToken  string `json:"probeRegistrationToken"`
}

type BatchFailureItem struct {
	Domain    string   `json:"domain"`
	Reason    string   `json:"reason"`
	Issues    []string `json:"issues,omitempty"`
	CheckPath string   `json:"checkPath,omitempty"`
}

type DomainCheckSummary struct {
	Domain    string
	OK        bool
	Reason    string
	Issues    []string
	CheckPath string
}

type CheckBatchStatus struct {
	BatchID    uuid.UUID          `json:"batchId"`
	Total      int                `json:"total"`
	Completed  int                `json:"completed"`
	Failed     int                `json:"failed"`
	Normal     int                `json:"normal"`
	Running    bool               `json:"running"`
	Failures   []BatchFailureItem `json:"failures"`
	StartedAt  time.Time          `json:"startedAt"`
	FinishedAt *time.Time         `json:"finishedAt,omitempty"`
}

func assignUUIDIfEmpty(id *uuid.UUID) {
	if id != nil && *id == uuid.Nil {
		*id = uuid.New()
	}
}

func (m *DmGroup) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *DmDomain) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	normalizeDomainDefaults(m)
	return nil
}

func normalizeDomainDefaults(m *DmDomain) {
	if m.CheckInterval <= 0 {
		m.CheckInterval = 300
	}
	if strings.TrimSpace(m.ProbeNodeScope) == "" {
		m.ProbeNodeScope = "all"
	}
	if strings.TrimSpace(m.HealthLevel) == "" {
		m.HealthLevel = "normal"
	}
	if m.ReachabilityPct <= 0 {
		m.ReachabilityPct = 100
	}
	m.CheckStrategy = ensureJSONB(m.CheckStrategy, "{}")
	m.ProbeNodeIDs = ensureJSONB(m.ProbeNodeIDs, "[]")
	m.ProbeNodeSummary = ensureJSONB(m.ProbeNodeSummary, "{}")
	m.ExpectedIPs = ensureJSONB(m.ExpectedIPs, "[]")
	m.ContentKeywords = ensureJSONB(m.ContentKeywords, "[]")
	if strings.TrimSpace(m.LastDNSStatus) == "" {
		m.LastDNSStatus = "unknown"
	}
	if strings.TrimSpace(m.LastHTTPStatus) == "" {
		m.LastHTTPStatus = "unknown"
	}
	if strings.TrimSpace(m.LastSSLStatus) == "" {
		m.LastSSLStatus = "unknown"
	}
	if strings.TrimSpace(m.LastWhoisStatus) == "" {
		m.LastWhoisStatus = "unknown"
	}
	if strings.TrimSpace(m.LastContentStatus) == "" {
		m.LastContentStatus = "unknown"
	}
	if strings.TrimSpace(m.LastScreenshotStatus) == "" {
		m.LastScreenshotStatus = "unknown"
	}
}

func ensureJSONB(value, fallback string) string {
	if strings.TrimSpace(value) == "" {
		return fallback
	}
	return value
}

func (m *DmCheckResult) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *DmAlert) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *DmTelegramBot) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *DmTelegramGroup) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *DmAlertRoute) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *DmNode) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *DmProbeTask) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func (m *DmReport) BeforeCreate(_ *gorm.DB) error {
	assignUUIDIfEmpty(&m.ID)
	return nil
}

func autoMigrate(db *gorm.DB) error {
	if err := bootstrapDomainMonitorSchema(db); err != nil {
		return fmt.Errorf("bootstrap schema: %w", err)
	}
	return ensureSchemaPatches(db)
}

func ensureSchemaPatches(db *gorm.DB) error {
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_http_duration_ms INT NOT NULL DEFAULT 0`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_blacklist BOOLEAN NOT NULL DEFAULT false`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_probe_detection BOOLEAN NOT NULL DEFAULT false`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_proxy_detection BOOLEAN NOT NULL DEFAULT false`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS enable_user_simulation BOOLEAN NOT NULL DEFAULT false`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS check_strategy JSONB NOT NULL DEFAULT '{}'`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS probe_node_scope VARCHAR(16) NOT NULL DEFAULT 'all'`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS probe_node_ids JSONB NOT NULL DEFAULT '[]'`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_nodes ADD COLUMN IF NOT EXISTS public_ip VARCHAR(64) DEFAULT ''`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_nodes ADD COLUMN IF NOT EXISTS version VARCHAR(32) DEFAULT ''`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_nodes ADD COLUMN IF NOT EXISTS cpu_percent DOUBLE PRECISION NOT NULL DEFAULT 0`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_nodes ADD COLUMN IF NOT EXISTS memory_percent DOUBLE PRECISION NOT NULL DEFAULT 0`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_probe_tasks ADD COLUMN IF NOT EXISTS check_specs JSONB NOT NULL DEFAULT '[]'`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS health_level VARCHAR(16) NOT NULL DEFAULT 'normal'`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS reachability_pct DOUBLE PRECISION NOT NULL DEFAULT 100`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS probe_node_summary JSONB NOT NULL DEFAULT '{}'`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS expected_ips JSONB NOT NULL DEFAULT '[]'`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS expected_asn VARCHAR(32) DEFAULT ''`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS expected_cdn VARCHAR(64) DEFAULT ''`).Error; err != nil {
		return err
	}
	if err := db.Exec(`ALTER TABLE dm_domains ADD COLUMN IF NOT EXISTS last_cdn_provider VARCHAR(64) DEFAULT ''`).Error; err != nil {
		return err
	}
	defaults := map[string]string{
		settingDefaultCheckInterval:  "300",
		settingSchedulerTickSeconds:  "60",
		settingAutoCheckPriority:     "true",
		settingTelegramReportEnabled:   "false",
		settingTelegramRealtimeEnabled: "false",
		settingReportServerLabel:     "Local Center",
		settingReportTimezone:        "UTC",
		settingReportTitle:           "域名监控报告",
		settingWorkerPoolSize:        "100",
		settingHttpTimeoutSeconds:    "8",
		settingDomainCheckTimeoutSec: "25",
		settingFastDnsCheck:          "true",
		settingScheduleBatchLimit:    "1000",
		settingProbeOnBatchCheck:     "false",
		settingHttpProxyUrl:          "",
		settingProbeRegistrationToken: "",
	}
	for key, val := range defaults {
		var n int64
		db.Model(&DmSetting{}).Where("key = ?", key).Count(&n)
		if n == 0 {
			if err := db.Create(&DmSetting{Key: key, Value: val, UpdatedAt: time.Now().UTC()}).Error; err != nil {
				return err
			}
		}
	}
	if err := db.Exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_dm_alerts_open_unique ON dm_alerts(domain_id, alert_type) WHERE status = 'open'`).Error; err != nil {
		return err
	}
	if err := db.Exec(`CREATE INDEX IF NOT EXISTS idx_dm_alerts_domain_type_status ON dm_alerts(domain_id, alert_type, status)`).Error; err != nil {
		return err
	}
	if err := db.Exec(`CREATE INDEX IF NOT EXISTS idx_dm_alerts_status_last_at ON dm_alerts(status, last_at DESC)`).Error; err != nil {
		return err
	}
	return nil
}

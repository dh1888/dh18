package callback

import (
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/internal/ssrfguard"
	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/models"
)

type Handler struct {
	svc *Service
}

func NewHandler(svc *Service) *Handler {
	return &Handler{svc: svc}
}

func (h *Handler) Register(rg *gin.RouterGroup) {
	callbackRead := middleware.RequireAnyPermission("callback:view", "callback:manage", "callback:settings")

	rg.GET("/platforms", callbackRead, h.ListPlatforms)
	rg.POST("/platforms", middleware.RequirePermission("callback:settings"), h.CreatePlatform)
	rg.GET("/platforms/:id", callbackRead, h.GetPlatform)
	rg.PUT("/platforms/:id", middleware.RequirePermission("callback:settings"), h.UpdatePlatform)
	rg.DELETE("/platforms/:id", middleware.RequirePermission("callback:settings"), h.DeletePlatform)
	rg.POST("/platforms/:id/test", middleware.RequirePermission("callback:settings"), h.TestPlatform)

	rg.GET("/endpoints", middleware.RequirePermission("callback:settings"), h.ListEndpoints)
	rg.POST("/endpoints", middleware.RequirePermission("callback:settings"), h.CreateEndpoint)
	rg.GET("/endpoints/:id", middleware.RequirePermission("callback:settings"), h.GetEndpoint)
	rg.PUT("/endpoints/:id", middleware.RequirePermission("callback:settings"), h.UpdateEndpoint)
	rg.DELETE("/endpoints/:id", middleware.RequirePermission("callback:settings"), h.DeleteEndpoint)

	rg.GET("/activity", callbackRead, h.GetActivity)
	rg.PUT("/activity", middleware.RequirePermission("callback:settings"), h.UpdateActivity)

	rg.POST("/tasks/estimate", middleware.RequirePermission("callback:manage"), h.EstimateTask)
	rg.POST("/tasks/generate", middleware.RequirePermission("callback:manage"), h.GenerateTask)
	rg.GET("/tasks", callbackRead, h.ListTasks)
	rg.GET("/tasks/:id", callbackRead, h.GetTask)
	rg.GET("/tasks/:id/results", callbackRead, h.ListTaskResults)
	rg.GET("/tasks/:id/export", callbackRead, h.ExportTask)

	rg.GET("/request-logs", callbackRead, h.ListRequestLogs)

	rg.POST("/manual/preview", middleware.RequirePermission("callback:manage"), h.PreviewManualColumns)
	rg.POST("/manual/preview-tiers", middleware.RequirePermission("callback:manage"), h.PreviewManualTierValues)

	rg.GET("/manual/template", middleware.RequirePermission("callback:manage"), h.DownloadManualTemplate)
	rg.POST("/manual/process", middleware.RequirePermission("callback:manage"), h.ProcessManualImport)
	rg.POST("/manual/export", middleware.RequirePermission("callback:manage"), h.ExportManualResult)
}

func (h *Handler) ListPlatforms(c *gin.Context) {
	page, pageSize := parsePage(c)
	var enabled *bool
	if v := c.Query("enabled"); v != "" {
		b := v == "true" || v == "1"
		enabled = &b
	}
	res, err := h.svc.ListPlatforms(c.Request.Context(), PlatformListFilter{
		Keyword:  c.Query("keyword"),
		Enabled:  enabled,
		Page:     page,
		PageSize: pageSize,
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", res)
}

func (h *Handler) GetPlatform(c *gin.Context) {
	id, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	item, err := h.svc.GetPlatform(c.Request.Context(), id)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if item == nil {
		models.SendError(c, 404, 1004, "platform not found")
		return
	}
	models.Send(c, 200, 0, "success", item)
}

type platformCreateReq struct {
	Name     string `json:"name" binding:"required"`
	BaseURL  string `json:"baseUrl" binding:"required"`
	TenantID string `json:"tenantId" binding:"required"`
	Token    string `json:"token" binding:"required"`
	Enabled  *bool  `json:"enabled"`
	Remark   string `json:"remark"`
}

func (h *Handler) CreatePlatform(c *gin.Context) {
	var req platformCreateReq
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if err := ssrfguard.ValidateOutboundURL(req.BaseURL); err != nil {
		models.SendError(c, 400, 1001, "invalid baseUrl: "+err.Error())
		return
	}
	enabled := true
	if req.Enabled != nil {
		enabled = *req.Enabled
	}
	item, err := h.svc.CreatePlatform(c.Request.Context(), CreatePlatformInput{
		Name:      req.Name,
		BaseURL:   req.BaseURL,
		TenantID:  req.TenantID,
		Token:     req.Token,
		Enabled:   enabled,
		Remark:    req.Remark,
		CreatedBy: parseUserUUID(c),
	})
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", item)
}

type platformUpdateReq struct {
	Name     string `json:"name" binding:"required"`
	BaseURL  string `json:"baseUrl" binding:"required"`
	TenantID string `json:"tenantId" binding:"required"`
	Token    string `json:"token"`
	Enabled  *bool  `json:"enabled"`
	Remark   string `json:"remark"`
}

func (h *Handler) UpdatePlatform(c *gin.Context) {
	id, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	var req platformUpdateReq
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if err := ssrfguard.ValidateOutboundURL(req.BaseURL); err != nil {
		models.SendError(c, 400, 1001, "invalid baseUrl: "+err.Error())
		return
	}
	enabled := true
	if req.Enabled != nil {
		enabled = *req.Enabled
	}
	item, err := h.svc.UpdatePlatform(c.Request.Context(), UpdatePlatformInput{
		ID:       id,
		Name:     req.Name,
		BaseURL:  req.BaseURL,
		TenantID: req.TenantID,
		Token:    req.Token,
		Enabled:  enabled,
		Remark:   req.Remark,
	})
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", item)
}

func (h *Handler) DeletePlatform(c *gin.Context) {
	id, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.svc.DeletePlatform(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

func (h *Handler) ListEndpoints(c *gin.Context) {
	var platformID *uuid.UUID
	if v := c.Query("platformId"); v != "" {
		id, err := uuid.Parse(v)
		if err != nil {
			models.SendError(c, 400, 1001, "invalid platformId")
			return
		}
		platformID = &id
	}
	items, err := h.svc.ListEndpoints(c.Request.Context(), EndpointListFilter{
		PlatformID: platformID,
		Code:       c.Query("code"),
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", items)
}

func (h *Handler) GetEndpoint(c *gin.Context) {
	id, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	item, err := h.svc.GetEndpoint(c.Request.Context(), id)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if item == nil {
		models.SendError(c, 404, 1004, "endpoint not found")
		return
	}
	models.Send(c, 200, 0, "success", item)
}

func (h *Handler) CreateEndpoint(c *gin.Context) {
	var req CallbackAPIEndpoint
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	req.ID = uuid.Nil
	if err := h.svc.CreateEndpoint(c.Request.Context(), &req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", req)
}

func (h *Handler) UpdateEndpoint(c *gin.Context) {
	id, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	var req CallbackAPIEndpoint
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	req.ID = id
	if err := h.svc.UpdateEndpoint(c.Request.Context(), &req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", req)
}

func (h *Handler) DeleteEndpoint(c *gin.Context) {
	id, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	if err := h.svc.DeleteEndpoint(c.Request.Context(), id); err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

func (h *Handler) GetActivity(c *gin.Context) {
	item, err := h.svc.GetActivity(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", item)
}

func (h *Handler) UpdateActivity(c *gin.Context) {
	var req CallbackActivity
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	existing, err := h.svc.GetActivity(c.Request.Context())
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	req.ID = existing.ID
	req.UpdatedBy = parseUserUUID(c)
	if err := h.svc.UpdateActivity(c.Request.Context(), &req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", req)
}

type generateTaskReq struct {
	PlatformID   string `json:"platformId" binding:"required"`
	DateFrom     string `json:"dateFrom"`
	DateTo       string `json:"dateTo"`
	EndpointCode string `json:"endpointCode"`
}

func parseOptionalDate(s string) (time.Time, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return time.Time{}, nil
	}
	return parseDate(s)
}

func bindGenerateTaskInput(c *gin.Context) (GenerateTaskInput, error) {
	var req generateTaskReq
	if err := c.ShouldBindJSON(&req); err != nil {
		return GenerateTaskInput{}, err
	}
	platformID, err := uuid.Parse(req.PlatformID)
	if err != nil {
		return GenerateTaskInput{}, fmt.Errorf("invalid platformId")
	}
	dateFrom, err := parseOptionalDate(req.DateFrom)
	if err != nil {
		return GenerateTaskInput{}, fmt.Errorf("invalid dateFrom")
	}
	dateTo, err := parseOptionalDate(req.DateTo)
	if err != nil {
		return GenerateTaskInput{}, fmt.Errorf("invalid dateTo")
	}
	return GenerateTaskInput{
		PlatformID:   platformID,
		DateFrom:     dateFrom,
		DateTo:       dateTo,
		EndpointCode: req.EndpointCode,
		CreatedBy:    parseUserUUID(c),
	}, nil
}

func (h *Handler) GenerateTask(c *gin.Context) {
	in, err := bindGenerateTaskInput(c)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	task, err := h.svc.GenerateTask(c.Request.Context(), in)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", task)
}

func (h *Handler) EstimateTask(c *gin.Context) {
	in, err := bindGenerateTaskInput(c)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	estimate, err := h.svc.EstimateTask(c.Request.Context(), in)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", estimate)
}

type testPlatformReq struct {
	EndpointCode string `json:"endpointCode"`
}

func (h *Handler) TestPlatform(c *gin.Context) {
	id, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	var req testPlatformReq
	_ = c.ShouldBindJSON(&req)
	result, err := h.svc.TestPlatformConnection(c.Request.Context(), TestPlatformInput{
		PlatformID:   id,
		EndpointCode: req.EndpointCode,
	})
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", result)
}

func (h *Handler) ListTasks(c *gin.Context) {
	page, pageSize := parsePage(c)
	var platformID *uuid.UUID
	if v := c.Query("platformId"); v != "" {
		id, err := uuid.Parse(v)
		if err != nil {
			models.SendError(c, 400, 1001, "invalid platformId")
			return
		}
		platformID = &id
	}
	res, err := h.svc.ListTasks(c.Request.Context(), TaskListFilter{
		PlatformID: platformID,
		Status:     c.Query("status"),
		Page:       page,
		PageSize:   pageSize,
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", res)
}

func (h *Handler) GetTask(c *gin.Context) {
	id, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	task, err := h.svc.GetTask(c.Request.Context(), id)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	if task == nil {
		models.SendError(c, 404, 1004, "task not found")
		return
	}
	models.Send(c, 200, 0, "success", task)
}

func (h *Handler) ListTaskResults(c *gin.Context) {
	taskID, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	page, pageSize := parsePage(c)
	res, err := h.svc.ListTaskResults(c.Request.Context(), ResultListFilter{
		TaskID:   taskID,
		Page:     page,
		PageSize: pageSize,
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", res)
}

func (h *Handler) ExportTask(c *gin.Context) {
	taskID, err := parseUUIDParam(c, "id")
	if err != nil {
		models.SendError(c, 400, 1001, "invalid id")
		return
	}
	buf, task, err := h.svc.ExportTaskResults(c.Request.Context(), taskID)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	filename := "callback_" + task.ID.String() + ".xlsx"
	c.Header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Header("Content-Disposition", "attachment; filename="+filename)
	c.Data(http.StatusOK, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", buf.Bytes())
}

func (h *Handler) PreviewManualColumns(c *gin.Context) {
	fileHeader, err := c.FormFile("file")
	if err != nil {
		models.SendError(c, 400, 1001, "file is required")
		return
	}
	headerRow, _ := strconv.Atoi(c.DefaultPostForm("headerRow", "0"))
	if headerRow < 0 {
		headerRow = 0
	}
	file, err := fileHeader.Open()
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	defer file.Close()

	cols, err := PreviewSpreadsheetColumns(file, fileHeader.Filename, headerRow)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", cols)
}

func (h *Handler) PreviewManualTierValues(c *gin.Context) {
	fileHeader, err := c.FormFile("file")
	if err != nil {
		models.SendError(c, 400, 1001, "file is required")
		return
	}
	headerRow, _ := strconv.Atoi(c.DefaultPostForm("headerRow", "0"))
	tierColumn, _ := strconv.Atoi(c.DefaultPostForm("tierColumn", "-1"))
	if tierColumn < 0 {
		models.SendError(c, 400, 1001, "tierColumn is required")
		return
	}
	file, err := fileHeader.Open()
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	defer file.Close()

	values, err := PreviewTierValues(file, fileHeader.Filename, headerRow, tierColumn)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", values)
}

func (h *Handler) DownloadManualTemplate(c *gin.Context) {
	templateType := c.Query("type")
	buf, err := BuildManualTemplateExcel(templateType)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	filename := "callback_member_template.xlsx"
	if strings.EqualFold(templateType, "unclaimed") {
		filename = "callback_unclaimed_template.xlsx"
	}
	c.Header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Header("Content-Disposition", "attachment; filename="+filename)
	c.Data(http.StatusOK, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", buf.Bytes())
}

func (h *Handler) ProcessManualImport(c *gin.Context) {
	dispatchType := c.PostForm("dispatchType")

	memberMapping, err := ParseMemberColumnMappingJSON(c.PostForm("memberMapping"))
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	unclaimedMapping, err := ParseUnclaimedColumnMappingJSON(c.PostForm("unclaimedMapping"))
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	memberHeader, err := c.FormFile("memberFile")
	if err != nil {
		models.SendError(c, 400, 1001, "memberFile is required")
		return
	}
	memberFile, err := memberHeader.Open()
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	defer memberFile.Close()

	var unclaimedFile io.Reader
	var unclaimedFilename string
	if unclaimedHeader, err := c.FormFile("unclaimedFile"); err == nil {
		unclaimedFilename = unclaimedHeader.Filename
		f, err := unclaimedHeader.Open()
		if err != nil {
			models.SendError(c, 400, 1001, err.Error())
			return
		}
		defer f.Close()
		unclaimedFile = f
	}

	result, err := h.svc.ProcessManualImport(
		c.Request.Context(),
		dispatchType,
		memberFile,
		memberHeader.Filename,
		unclaimedFile,
		unclaimedFilename,
		memberMapping,
		unclaimedMapping,
	)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", result)
}

func (h *Handler) ExportManualResult(c *gin.Context) {
	var req ManualExportRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	full, err := h.svc.ResolveManualExportResult(req)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	req.Result = full
	buf, err := BuildManualExportExcel(req)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	name := "callback_manual_" + strings.TrimSpace(req.ExportType)
	if name == "callback_manual_" {
		name = "callback_manual_all"
	}
	c.Header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Header("Content-Disposition", "attachment; filename="+name+".xlsx")
	c.Data(http.StatusOK, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", buf.Bytes())
}

func (h *Handler) ListRequestLogs(c *gin.Context) {
	page, pageSize := parsePage(c)
	var platformID, taskID *uuid.UUID
	if v := c.Query("platformId"); v != "" {
		id, err := uuid.Parse(v)
		if err != nil {
			models.SendError(c, 400, 1001, "invalid platformId")
			return
		}
		platformID = &id
	}
	if v := c.Query("taskId"); v != "" {
		id, err := uuid.Parse(v)
		if err != nil {
			models.SendError(c, 400, 1001, "invalid taskId")
			return
		}
		taskID = &id
	}
	res, err := h.svc.ListRequestLogs(c.Request.Context(), RequestLogListFilter{
		PlatformID:   platformID,
		TaskID:       taskID,
		EndpointCode: c.Query("endpointCode"),
		Page:         page,
		PageSize:     pageSize,
	})
	if err != nil {
		models.SendInternalError(c, err)
		return
	}
	models.Send(c, 200, 0, "success", res)
}

func parseUUIDParam(c *gin.Context, name string) (uuid.UUID, error) {
	return uuid.Parse(c.Param(name))
}

func parsePage(c *gin.Context) (int, int) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "20"))
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 200 {
		pageSize = 20
	}
	return page, pageSize
}

func parseDate(s string) (time.Time, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return time.Time{}, fmt.Errorf("empty date")
	}
	return time.Parse("2006-01-02", s)
}

func parseUserUUID(c *gin.Context) *uuid.UUID {
	raw := strings.TrimSpace(c.GetString("userID"))
	if raw == "" {
		return nil
	}
	id, err := uuid.Parse(raw)
	if err != nil {
		return nil
	}
	return &id
}

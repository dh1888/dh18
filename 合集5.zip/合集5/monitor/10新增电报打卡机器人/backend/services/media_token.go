package services

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

const (
	mediaTokenKeyPrefix   = "media_access:"
	mediaTokenLeasePrefix = "media_access:lease:"
	mediaTokenTTL         = 15 * time.Minute
	mediaStreamLeaseTTL   = 15 * time.Minute
)

var (
	ErrMediaTokenInvalid = errors.New("invalid media token")
	ErrMediaTokenExpired = errors.New("media token expired")
)

// MediaAccessGrant 短期媒体访问授权（Session 签发的能力委托）
type MediaAccessGrant struct {
	SessionID        string   `json:"sessionId,omitempty"`
	UserID           string   `json:"userId"`
	Username         string   `json:"username"`
	Role             string   `json:"role,omitempty"`
	AllowedDeviceIDs []string `json:"allowedDeviceIds,omitempty"`
	ResourceType     string   `json:"resourceType"`
	ResourceID       string   `json:"resourceId"`
	Action           string   `json:"action"`
}

type MediaTokenService struct {
	redis    *redis.Client
	sessions *SessionService
}

func NewMediaTokenService(redisClient *redis.Client, sessions *SessionService) *MediaTokenService {
	return &MediaTokenService{redis: redisClient, sessions: sessions}
}

func (s *MediaTokenService) Issue(ctx context.Context, grant MediaAccessGrant) (string, time.Duration, error) {
	if grant.UserID == "" || grant.ResourceType == "" || grant.ResourceID == "" || grant.Action == "" {
		return "", 0, fmt.Errorf("invalid media grant")
	}
	if grant.SessionID == "" {
		return "", 0, fmt.Errorf("media grant requires session id")
	}

	tokenBytes := make([]byte, 24)
	if _, err := rand.Read(tokenBytes); err != nil {
		return "", 0, err
	}
	token := hex.EncodeToString(tokenBytes)

	payload, err := json.Marshal(grant)
	if err != nil {
		return "", 0, err
	}

	if s.redis != nil {
		if err := s.redis.Set(ctx, mediaTokenKeyPrefix+token, payload, mediaTokenTTL).Err(); err != nil {
			return "", 0, err
		}
		return token, mediaTokenTTL, nil
	}

	return "", 0, fmt.Errorf("media token store unavailable")
}

func (s *MediaTokenService) Validate(ctx context.Context, token, resourceType, resourceID, action string) (*MediaAccessGrant, error) {
	token = trimToken(token)
	if token == "" || s.redis == nil {
		return nil, ErrMediaTokenInvalid
	}

	if action == "stream" {
		if grant, err := s.validateLease(ctx, token, resourceType, resourceID, action); err == nil {
			return grant, nil
		} else if err != ErrMediaTokenExpired {
			return nil, err
		}
	}

	raw, err := s.consumeToken(ctx, mediaTokenKeyPrefix+token)
	if err != nil {
		if err == redis.Nil {
			return nil, ErrMediaTokenExpired
		}
		return nil, err
	}

	grant, err := s.parseGrant(raw, resourceType, resourceID, action)
	if err != nil {
		return nil, err
	}

	if err := s.ensureActiveSession(ctx, grant); err != nil {
		return nil, err
	}

	if action == "stream" {
		_ = s.redis.Set(ctx, mediaTokenLeasePrefix+token, raw, mediaStreamLeaseTTL).Err()
	}

	return grant, nil
}

func (s *MediaTokenService) validateLease(ctx context.Context, token, resourceType, resourceID, action string) (*MediaAccessGrant, error) {
	raw, err := s.redis.Get(ctx, mediaTokenLeasePrefix+token).Bytes()
	if err != nil {
		if err == redis.Nil {
			return nil, ErrMediaTokenExpired
		}
		return nil, err
	}
	grant, err := s.parseGrant(raw, resourceType, resourceID, action)
	if err != nil {
		return nil, err
	}
	if err := s.ensureActiveSession(ctx, grant); err != nil {
		return nil, err
	}
	return grant, nil
}

func (s *MediaTokenService) parseGrant(raw []byte, resourceType, resourceID, action string) (*MediaAccessGrant, error) {
	var grant MediaAccessGrant
	if err := json.Unmarshal(raw, &grant); err != nil {
		return nil, ErrMediaTokenInvalid
	}
	if grant.ResourceType != resourceType || grant.ResourceID != resourceID || grant.Action != action {
		return nil, ErrMediaTokenInvalid
	}
	return &grant, nil
}

func (s *MediaTokenService) ensureActiveSession(ctx context.Context, grant *MediaAccessGrant) error {
	if grant.SessionID == "" || s.sessions == nil {
		return nil
	}
	if _, err := s.sessions.ValidateActiveSession(ctx, grant.SessionID); err != nil {
		return ErrMediaTokenExpired
	}
	return nil
}

func (s *MediaTokenService) consumeToken(ctx context.Context, key string) ([]byte, error) {
	raw, err := s.redis.GetDel(ctx, key).Bytes()
	if err == nil {
		return raw, nil
	}
	if err != redis.Nil && !isRedisUnknownCommand(err) {
		return nil, err
	}
	if err == redis.Nil {
		return nil, redis.Nil
	}
	raw, err = s.redis.Get(ctx, key).Bytes()
	if err != nil {
		return nil, err
	}
	if delErr := s.redis.Del(ctx, key).Err(); delErr != nil {
		return nil, delErr
	}
	return raw, nil
}

func isRedisUnknownCommand(err error) bool {
	if err == nil {
		return false
	}
	msg := err.Error()
	return strings.Contains(msg, "unknown command") || strings.Contains(msg, "ERR unknown")
}

func trimToken(token string) string {
	for len(token) > 0 && (token[0] == ' ' || token[0] == '\t') {
		token = token[1:]
	}
	for len(token) > 0 {
		last := token[len(token)-1]
		if last == ' ' || last == '\t' {
			token = token[:len(token)-1]
			continue
		}
		break
	}
	return token
}

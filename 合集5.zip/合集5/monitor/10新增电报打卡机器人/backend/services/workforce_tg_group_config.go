package services

import (
	"context"
	"database/sql"
	"strings"
)

const (
	defaultShiftGraceBefore    = 120
	defaultShiftGraceAfter     = 360
	defaultWorkEndGraceBefore  = 120
	defaultWorkEndGraceAfter   = 360
)

type TgGraceConfig struct {
	ShiftGraceBefore   int
	ShiftGraceAfter    int
	WorkEndGraceBefore int
	WorkEndGraceAfter  int
}

func normalizeGraceConfig(cfg TgGraceConfig) TgGraceConfig {
	if cfg.ShiftGraceBefore < 30 {
		cfg.ShiftGraceBefore = defaultShiftGraceBefore
	}
	if cfg.ShiftGraceAfter < 30 {
		cfg.ShiftGraceAfter = defaultShiftGraceAfter
	}
	if cfg.WorkEndGraceBefore < 30 {
		cfg.WorkEndGraceBefore = defaultWorkEndGraceBefore
	}
	if cfg.WorkEndGraceAfter < 30 {
		cfg.WorkEndGraceAfter = defaultWorkEndGraceAfter
	}
	return cfg
}

func (s *WorkforceTelegramService) graceFromSettings(settings *TelegramSettings) TgGraceConfig {
	cfg := TgGraceConfig{
		ShiftGraceBefore:   settings.GraceMinutes,
		ShiftGraceAfter:    settings.GraceMinutesAfter,
		WorkEndGraceBefore: settings.WorkEndGraceMinutes,
		WorkEndGraceAfter:  settings.WorkEndGraceAfter,
	}
	return normalizeGraceConfig(cfg)
}

func (s *WorkforceTelegramService) GetGraceConfig(ctx context.Context, chatID string) (TgGraceConfig, error) {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return TgGraceConfig{}, err
	}
	cfg := s.graceFromSettings(settings)
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return cfg, nil
	}
	var sb, sa, wb, wa sql.NullInt32
	err = s.db.QueryRowContext(ctx, `
		SELECT shift_grace_before, shift_grace_after, work_end_grace_before, work_end_grace_after
		FROM wf_telegram_groups WHERE chat_id = $1`, chatID).
		Scan(&sb, &sa, &wb, &wa)
	if err == sql.ErrNoRows {
		return cfg, nil
	}
	if err != nil {
		return cfg, err
	}
	if sb.Valid && int(sb.Int32) > 0 {
		cfg.ShiftGraceBefore = int(sb.Int32)
	}
	if sa.Valid && int(sa.Int32) > 0 {
		cfg.ShiftGraceAfter = int(sa.Int32)
	}
	if wb.Valid && int(wb.Int32) > 0 {
		cfg.WorkEndGraceBefore = int(wb.Int32)
	}
	if wa.Valid && int(wa.Int32) > 0 {
		cfg.WorkEndGraceAfter = int(wa.Int32)
	}
	return normalizeGraceConfig(cfg), nil
}

func (s *WorkforceTelegramService) GetGroupDailyResetTime(ctx context.Context, chatID string) string {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return "09:00"
	}
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return settings.DailyResetTime
	}
	var t sql.NullString
	if s.db.QueryRowContext(ctx, `
		SELECT daily_reset_time FROM wf_telegram_groups WHERE chat_id = $1`, chatID).Scan(&t) != nil || !t.Valid || strings.TrimSpace(t.String) == "" {
		return settings.DailyResetTime
	}
	return strings.TrimSpace(t.String)
}

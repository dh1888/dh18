package services

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/redis/go-redis/v9"
)

func testMediaRedis(t *testing.T) *redis.Client {
	t.Helper()
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "127.0.0.1:6379"
	}
	client := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: os.Getenv("REDIS_PASSWORD"),
		DB:       14,
	})
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		t.Skipf("redis unavailable at %s: %v", addr, err)
	}
	return client
}

func TestMediaTokenSingleConsumeDownload(t *testing.T) {
	client := testMediaRedis(t)
	defer client.Close()
	ctx := context.Background()

	svc := NewMediaTokenService(client, nil)
	recID := "rec-dl-" + time.Now().Format("150405.000")
	token, _, err := svc.Issue(ctx, MediaAccessGrant{
		SessionID:    "sess-1",
		UserID:       "user-1",
		Username:     "alice",
		ResourceType: "recording",
		ResourceID:   recID,
		Action:       "download",
	})
	if err != nil {
		t.Fatalf("issue: %v", err)
	}

	if _, err := svc.Validate(ctx, token, "recording", recID, "download"); err != nil {
		t.Fatalf("first validate: %v", err)
	}
	if _, err := svc.Validate(ctx, token, "recording", recID, "download"); err != ErrMediaTokenExpired {
		t.Fatalf("expected expired on reuse, got %v", err)
	}
}

func TestMediaTokenStreamLease(t *testing.T) {
	client := testMediaRedis(t)
	defer client.Close()
	ctx := context.Background()

	svc := NewMediaTokenService(client, nil)
	recID := "rec-stream-" + time.Now().Format("150405.000")
	token, _, err := svc.Issue(ctx, MediaAccessGrant{
		SessionID:    "sess-2",
		UserID:       "user-2",
		Username:     "bob",
		ResourceType: "recording",
		ResourceID:   recID,
		Action:       "stream",
	})
	if err != nil {
		t.Fatalf("issue: %v", err)
	}

	if _, err := svc.Validate(ctx, token, "recording", recID, "stream"); err != nil {
		t.Fatalf("first stream validate: %v", err)
	}
	if _, err := svc.Validate(ctx, token, "recording", recID, "stream"); err != nil {
		t.Fatalf("lease stream validate: %v", err)
	}
}

package services

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"math"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type AgentCaptureSyncResult struct {
	DeviceID uuid.UUID
	Synced   bool
	Online   bool
}

func (s *WorkforceTelegramService) findApprovedDeviceForEmployee(ctx context.Context, empID uuid.UUID) (uuid.UUID, bool, error) {
	deviceID, err := s.findDeviceForEmployee(ctx, empID)
	if err != nil || deviceID == uuid.Nil {
		return uuid.Nil, false, err
	}
	online := s.wsHub != nil && s.wsHub.IsAgentOnline(deviceID.String())
	return deviceID, online, nil
}

func (s *WorkforceTelegramService) linkSessionToDevice(ctx context.Context, sessionID, deviceID uuid.UUID) {
	_, _ = s.db.ExecContext(ctx, `
		UPDATE work_sessions SET device_id = $1, updated_at = NOW()
		WHERE id = $2 AND device_id IS NULL`, deviceID, sessionID)
}

func (s *WorkforceTelegramService) SyncAgentCaptureStart(ctx context.Context, empID, sessionID uuid.UUID) AgentCaptureSyncResult {
	out := AgentCaptureSyncResult{}
	if !CaptureLinkedToCheckin(ctx, s.db) || s.wsHub == nil {
		return out
	}
	deviceID, online, err := s.findApprovedDeviceForEmployee(ctx, empID)
	if err != nil || deviceID == uuid.Nil {
		return out
	}
	out.DeviceID = deviceID
	out.Online = online
	s.linkSessionToDevice(ctx, sessionID, deviceID)
	if !online {
		log.Printf("[Telegram] agent capture start skipped: device %s offline (employee %s)", deviceID, empID)
		return out
	}
	s.wsHub.SendCommandToDevice(deviceID.String(), "start_work_capture", gin.H{
		"sessionId": sessionID.String(),
		"source":    "telegram",
	})
	out.Synced = true
	return out
}

func (s *WorkforceTelegramService) SyncAgentCaptureStop(ctx context.Context, empID, sessionID uuid.UUID) AgentCaptureSyncResult {
	out := AgentCaptureSyncResult{}
	if !CaptureLinkedToCheckin(ctx, s.db) || s.wsHub == nil {
		return out
	}
	deviceID, online, err := s.findApprovedDeviceForEmployee(ctx, empID)
	if err != nil || deviceID == uuid.Nil {
		return out
	}
	out.DeviceID = deviceID
	out.Online = online
	if !online {
		return out
	}
	params := gin.H{"source": "telegram"}
	if sessionID != uuid.Nil {
		params["sessionId"] = sessionID.String()
	}
	s.wsHub.SendCommandToDevice(deviceID.String(), "stop_work_capture", params)
	out.Synced = true
	return out
}

func (s *WorkforceTelegramService) openWorkSessionID(ctx context.Context, empID uuid.UUID) uuid.UUID {
	var sid uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM work_sessions WHERE employee_id = $1 AND status = 'open'
		ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&sid)
	if err != nil {
		return uuid.Nil
	}
	return sid
}

// NotifyAgentWorkEvent posts PC client check-in/out to the bound Telegram check-in group
// using the same HTML templates as in-group TG check-in. Exception alerts go to push targets.
func (s *WorkforceTelegramService) NotifyAgentWorkEvent(ctx context.Context, empID uuid.UUID, shift, event string, sessionID uuid.UUID) {
	if empID == uuid.Nil || sessionID == uuid.Nil {
		return
	}
	active, err := s.IsActive(ctx)
	if err != nil || !active {
		return
	}
	var chatID string
	var tgUID int64
	var empName string
	err = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(b.chat_id,''), COALESCE(b.telegram_user_id,0), COALESCE(e.name,'')
		FROM employees e
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = e.id AND b.status = 1
		WHERE e.id = $1`, empID).Scan(&chatID, &tgUID, &empName)
	if err != nil || strings.TrimSpace(chatID) == "" {
		return
	}
	settings, _, _, _, err := s.loadExtendedSettings(ctx)
	if err != nil {
		return
	}
	grace, _ := s.GetGraceConfig(ctx, chatID)
	loc := tgLoadLocation(settings.Timezone)

	switch event {
	case "上班":
		s.notifyAgentCheckInGroup(ctx, empID, tgUID, chatID, empName, sessionID, shift, settings, grace, loc)
	case "下班":
		s.notifyAgentCheckOutGroup(ctx, empID, tgUID, chatID, empName, sessionID, shift, settings, grace, loc)
	}
}

func (s *WorkforceTelegramService) resolveWorkStartClock(ctx context.Context, chatID string, settings *TelegramSettings, period *TgPeriodInfo, shift string) string {
	if shift == "night" {
		startClock := settings.NightStart
		if period != nil && period.IsHandover {
			if cfg, _ := s.GetHandoverConfig(ctx, chatID); cfg != nil {
				startClock = cfg.NightStartTime
			}
		}
		return startClock
	}
	startClock := settings.DayStart
	if period != nil && period.IsHandover && strings.Contains(period.PeriodType, "handover_day") {
		if cfg, _ := s.GetHandoverConfig(ctx, chatID); cfg != nil {
			startClock = cfg.HandoverDayStartTime
		}
	}
	return startClock
}

func (s *WorkforceTelegramService) notifyAgentCheckInGroup(
	ctx context.Context, empID uuid.UUID, tgUID int64, chatID, empName string, sessionID uuid.UUID,
	shift string, settings *TelegramSettings, grace TgGraceConfig, loc *time.Location,
) {
	var shiftType, shiftDetail, recordDate string
	var checkin time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day'), COALESCE(shift_detail,''), attendance_date::text, checkin_time
		FROM work_sessions WHERE id = $1`, sessionID).
		Scan(&shiftType, &shiftDetail, &recordDate, &checkin)
	if err != nil {
		return
	}
	if strings.TrimSpace(shift) == "" {
		shift = shiftType
	}
	checkin = checkin.In(loc)
	period, _ := s.DetermineCurrentPeriod(ctx, chatID, checkin)
	startClock := s.resolveWorkStartClock(ctx, chatID, settings, period, shiftType)
	lateMin := minutesAfterScheduled(checkin, startClock, grace.ShiftGraceBefore, loc)
	fineReason := fmt.Sprintf("%s上班迟到 %d 分钟（PC客户端）", shiftLabel(shiftType)+shiftDetailLabel(shiftDetail), lateMin)
	workFine, _ := s.applyWorkFine(ctx, empID, "work_start", lateMin, recordDate, fineReason)

	if chatID != "" {
		_ = s.setGroupShiftState(ctx, chatID, empID, shiftType, recordDate)
	}

	hint := ""
	if period != nil {
		hint = s.handoverStatusHint(ctx, chatID, period)
		hint += s.buildRelaySuccessorHintAfterCheckIn(ctx, empID, chatID, shiftType, recordDate, checkin)
	}
	expected := resolveWorkStartExpectedTime(checkin, recordDate, shiftType, shiftDetail, startClock, loc)
	groupHTML := buildWorkStartGroupReplyHTML(
		tgUID, empName, shiftType, shiftDetail, checkin, expected, lateMin, workFine, strings.TrimSpace(hint),
	)
	groupHTML = "💻 <b>PC客户端打卡</b>\n" + groupHTML
	kb := s.BuildWorkerReplyKeyboard(ctx, chatID)
	if err := s.SendTelegramHTML(ctx, chatID, groupHTML, kb); err != nil {
		log.Printf("[Telegram] agent check-in group notify failed chat=%s emp=%s: %v", chatID, empID, err)
	}
	activitySec := s.sumTodayActivitySeconds(ctx, empID, recordDate, shiftType)
	s.NotifyWorkExceptionPush(ctx, chatID, empName, shiftType, "上班", workFine, lateMin, 0, activitySec, shiftDetail)
}

func (s *WorkforceTelegramService) notifyAgentCheckOutGroup(
	ctx context.Context, empID uuid.UUID, tgUID int64, chatID, empName string, sessionID uuid.UUID,
	shift string, settings *TelegramSettings, grace TgGraceConfig, loc *time.Location,
) {
	var shiftType, shiftDetail, recordDate string
	var checkin, checkout time.Time
	err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(shift_type,'day'), COALESCE(shift_detail,''), attendance_date::text, checkin_time, checkout_time
		FROM work_sessions WHERE id = $1 AND status = 'closed'`, sessionID).
		Scan(&shiftType, &shiftDetail, &recordDate, &checkin, &checkout)
	if err != nil {
		return
	}
	if strings.TrimSpace(shift) == "" {
		shift = shiftType
	}
	checkin = checkin.In(loc)
	checkout = checkout.In(loc)
	now := checkout

	var endClock string
	if shiftType == "night" {
		endClock = settings.NightEnd
	} else {
		endClock = settings.DayEnd
	}
	earlyMin := minutesBeforeScheduled(now, endClock, grace.WorkEndGraceBefore, loc)
	fineReason := fmt.Sprintf("%s下班早退 %d 分钟（PC客户端）", shiftLabel(shiftType), earlyMin)
	workFine, _ := s.applyWorkFine(ctx, empID, "work_end", earlyMin, recordDate, fineReason)

	activityWarn := s.buildCrossShiftActivityWarn(ctx, empID, shiftType, recordDate)
	if chatID != "" {
		s.clearGroupShiftState(ctx, chatID, empID, shiftType)
		s.maybeBroadcastShiftEnd(ctx, chatID, shiftType, recordDate)
	}

	workSec := int(math.Max(0, now.Sub(checkin).Seconds()))
	activitySec := s.sumTodayActivitySeconds(ctx, empID, recordDate, shiftType)
	handoverHint := s.buildRelayCheckoutHint(ctx, chatID, empID, shiftType, recordDate, now)
	expectedEnd := combineDateTime(now, endClock, loc)
	if rd, err := time.ParseInLocation("2006-01-02", recordDate, loc); err == nil {
		expectedEnd = combineDateTime(rd, endClock, loc)
	}
	groupHTML := buildWorkEndGroupReplyHTML(
		tgUID, empName, shiftType, now, expectedEnd, earlyMin, workFine, handoverHint, activityWarn,
	)
	groupHTML = "💻 <b>PC客户端打卡</b>\n" + groupHTML
	kb := s.BuildWorkerReplyKeyboard(ctx, chatID)
	if err := s.SendTelegramHTML(ctx, chatID, groupHTML, kb); err != nil {
		log.Printf("[Telegram] agent check-out group notify failed chat=%s emp=%s: %v", chatID, empID, err)
	}
	s.NotifyWorkExceptionPush(ctx, chatID, empName, shiftType, "下班", workFine, earlyMin, workSec, activitySec, "")
}

func (s *WorkforceTelegramService) latestClosedWorkSeconds(ctx context.Context, empID uuid.UUID) int {
	var sec sql.NullFloat64
	_ = s.db.QueryRowContext(ctx, `
		SELECT EXTRACT(EPOCH FROM (checkout_time - checkin_time))
		FROM work_sessions
		WHERE employee_id = $1 AND status = 'closed'
		ORDER BY checkout_time DESC LIMIT 1`, empID).Scan(&sec)
	if sec.Valid && sec.Float64 > 0 {
		return int(sec.Float64)
	}
	return 0
}

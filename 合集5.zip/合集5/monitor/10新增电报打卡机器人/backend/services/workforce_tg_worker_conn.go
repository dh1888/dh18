package services

import (
	"context"
	"crypto/rand"
	"database/sql"
	"errors"
	"math/big"
	"strings"
	"time"
)

const workerOnlineThreshold = 2 * time.Minute
const pairingCodeTTL = 15 * time.Minute
const pairingAlphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

type WorkerConnectionInfo struct {
	Online           bool
	LastSeenAt       *time.Time
	HasWorkerSecret  bool
	HasActivePairing bool
	PairingExpiresAt *time.Time
}

func (s *WorkforceTelegramService) EnsureWorkerSecret(ctx context.Context) (string, error) {
	var secret sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT worker_secret FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).Scan(&secret)
	if err != nil {
		return "", err
	}
	if secret.Valid && strings.TrimSpace(secret.String) != "" {
		return strings.TrimSpace(secret.String), nil
	}
	newSecret, err := generateWorkerSecret()
	if err != nil {
		return "", err
	}
	_, err = s.db.ExecContext(ctx, `
		UPDATE wf_telegram_settings SET worker_secret = $1, updated_at = NOW()`, newSecret)
	return newSecret, err
}

func generatePairingCode() (string, error) {
	var sb strings.Builder
	max := big.NewInt(int64(len(pairingAlphabet)))
	for i := 0; i < 8; i++ {
		n, err := rand.Int(rand.Reader, max)
		if err != nil {
			return "", err
		}
		sb.WriteByte(pairingAlphabet[n.Int64()])
	}
	return sb.String(), nil
}

func (s *WorkforceTelegramService) GenerateWorkerPairing(ctx context.Context) (code string, expiresAt time.Time, err error) {
	if _, err = s.EnsureWorkerSecret(ctx); err != nil {
		return "", time.Time{}, err
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return "", time.Time{}, err
	}
	if !settings.HasBotToken {
		return "", time.Time{}, errors.New("请先保存 Bot Token")
	}
	if !settings.Enabled {
		return "", time.Time{}, errors.New("请先启用 Telegram 并保存配置")
	}
	code, err = generatePairingCode()
	if err != nil {
		return "", time.Time{}, err
	}
	expiresAt = time.Now().UTC().Add(pairingCodeTTL)
	_, err = s.db.ExecContext(ctx, `
		UPDATE wf_telegram_settings SET worker_pairing_code = $1, worker_pairing_expires_at = $2, updated_at = NOW()`,
		code, expiresAt)
	return code, expiresAt, err
}

func (s *WorkforceTelegramService) PairWorker(ctx context.Context, code string) (workerSecret, botToken string, err error) {
	code = strings.ToUpper(strings.TrimSpace(code))
	if len(code) < 6 {
		return "", "", errors.New("配对码无效")
	}
	var dbCode sql.NullString
	var expires sql.NullTime
	var secret sql.NullString
	err = s.db.QueryRowContext(ctx, `
		SELECT worker_pairing_code, worker_pairing_expires_at, worker_secret
		FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).Scan(&dbCode, &expires, &secret)
	if err != nil {
		return "", "", err
	}
	if !dbCode.Valid || dbCode.String != code {
		return "", "", errors.New("配对码无效或已使用")
	}
	if !expires.Valid || time.Now().UTC().After(expires.Time) {
		return "", "", errors.New("配对码已过期，请在 Web 重新生成")
	}
	if !secret.Valid || strings.TrimSpace(secret.String) == "" {
		return "", "", errors.New("Worker Secret 未配置")
	}
	botToken, err = s.GetBotToken(ctx)
	if err != nil {
		return "", "", errors.New("Bot Token 未配置或未启用")
	}
	_, _ = s.db.ExecContext(ctx, `
		UPDATE wf_telegram_settings SET
			worker_pairing_code = NULL,
			worker_pairing_expires_at = NULL,
			worker_last_seen_at = NOW(),
			updated_at = NOW()`)
	return strings.TrimSpace(secret.String), botToken, nil
}

func (s *WorkforceTelegramService) TouchWorkerHeartbeat(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, `
		UPDATE wf_telegram_settings SET worker_last_seen_at = NOW(), updated_at = NOW()`)
	return err
}

func (s *WorkforceTelegramService) GetWorkerConnectionInfo(ctx context.Context) (*WorkerConnectionInfo, error) {
	var lastSeen sql.NullTime
	var secret sql.NullString
	var pairCode sql.NullString
	var pairExp sql.NullTime
	err := s.db.QueryRowContext(ctx, `
		SELECT worker_last_seen_at, worker_secret, worker_pairing_code, worker_pairing_expires_at
		FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).Scan(&lastSeen, &secret, &pairCode, &pairExp)
	if err != nil {
		return nil, err
	}
	info := &WorkerConnectionInfo{
		HasWorkerSecret: secret.Valid && strings.TrimSpace(secret.String) != "",
	}
	if lastSeen.Valid {
		t := lastSeen.Time
		info.LastSeenAt = &t
		info.Online = time.Since(t) < workerOnlineThreshold
	}
	if pairCode.Valid && pairExp.Valid && time.Now().UTC().Before(pairExp.Time) {
		info.HasActivePairing = true
		t := pairExp.Time
		info.PairingExpiresAt = &t
	}
	return info, nil
}

func (s *WorkforceTelegramService) GetBotTokenForWorker(ctx context.Context) (string, error) {
	var enc sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT bot_token_enc FROM wf_telegram_settings
		WHERE enabled = TRUE AND bot_token_enc IS NOT NULL AND bot_token_enc != ''
		ORDER BY updated_at DESC LIMIT 1`).Scan(&enc)
	if err != nil || !enc.Valid {
		return "", errors.New("bot token not configured")
	}
	return DecryptSecret(enc.String)
}

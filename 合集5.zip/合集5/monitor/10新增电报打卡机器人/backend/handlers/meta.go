package handlers

import (
	"database/sql"
	"os"
	"strings"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type MetaHandler struct {
	db *sql.DB
}

func NewMetaHandler(db *sql.DB) *MetaHandler {
	return &MetaHandler{db: db}
}

func (h *MetaHandler) Modules(c *gin.Context) {
	dmEnabled := strings.EqualFold(strings.TrimSpace(os.Getenv("DOMAIN_MONITOR_ENABLED")), "true")
	cbEnv := strings.ToLower(strings.TrimSpace(os.Getenv("CALLBACK_ENABLED")))
	callbackEnabled := cbEnv != "false" && cbEnv != "0"
	models.Send(c, 200, 0, "success", gin.H{
		"domainMonitor":            dmEnabled,
		"callback":                 callbackEnabled,
		"telegramAttendance":       services.TelegramAttendanceEnabled(),
		"captureLinkedToCheckin":   services.CaptureLinkedToCheckin(c.Request.Context(), h.db),
		"telegramAgentCapture":     services.CaptureLinkedToCheckin(c.Request.Context(), h.db), // legacy alias
		"wsTicketRequired":         services.WSTicketRequired(),
	})
}

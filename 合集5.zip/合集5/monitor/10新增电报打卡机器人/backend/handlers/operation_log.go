package handlers

import (
	"bytes"
	"database/sql"
	"fmt"
	"io"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services/logx"
)

// ========== 操作日志处理器 ==========

type OperationLogHandler struct {
	db *sql.DB
}

func NewOperationLogHandler(db *sql.DB) *OperationLogHandler {
	return &OperationLogHandler{db: db}
}

// GetOperationLogs 获取操作日志列表
func (h *OperationLogHandler) GetOperationLogs(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "20"))
	operatorName := c.Query("operatorName")
	operationModule := c.Query("operationModule")
	operationType := c.Query("operationType")
	startDate := c.Query("startDate")
	endDate := c.Query("endDate")

	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 20
	}
	if pageSize > 100 {
		pageSize = 100
	}

	offset := (page - 1) * pageSize

	where := "1=1"
	args := []interface{}{}
	argIdx := 1

	if operatorName != "" {
		where += fmt.Sprintf(` AND (
			%s ILIKE $%d
			OR ol.operator_name ILIKE $%d
			OR u.real_name ILIKE $%d
			OR u.username ILIKE $%d
		)`, operationLogOperatorDisplay, argIdx, argIdx, argIdx, argIdx)
		args = append(args, "%"+operatorName+"%")
		argIdx++
	}
	if operationModule != "" {
		moduleValues := OperationModuleFilterValues(operationModule)
		if len(moduleValues) == 1 {
			where += fmt.Sprintf(" AND ol.operation_module = $%d", argIdx)
			args = append(args, moduleValues[0])
			argIdx++
		} else if len(moduleValues) > 1 {
			placeholders := make([]string, len(moduleValues))
			for i, v := range moduleValues {
				placeholders[i] = fmt.Sprintf("$%d", argIdx)
				args = append(args, v)
				argIdx++
			}
			where += fmt.Sprintf(" AND ol.operation_module IN (%s)", strings.Join(placeholders, ","))
		}
	}
	if operationType != "" {
		typeValues := OperationTypeFilterValues(operationType)
		if len(typeValues) == 1 {
			where += fmt.Sprintf(" AND ol.operation_type = $%d", argIdx)
			args = append(args, typeValues[0])
			argIdx++
		} else if len(typeValues) > 1 {
			placeholders := make([]string, len(typeValues))
			for i, v := range typeValues {
				placeholders[i] = fmt.Sprintf("$%d", argIdx)
				args = append(args, v)
				argIdx++
			}
			where += fmt.Sprintf(" AND ol.operation_type IN (%s)", strings.Join(placeholders, ","))
		}
	}
	if startDate != "" {
		where += fmt.Sprintf(" AND ol.created_at >= $%d", argIdx)
		args = append(args, startDate)
		argIdx++
	}
	if endDate != "" {
		where += fmt.Sprintf(" AND ol.created_at <= $%d", argIdx)
		args = append(args, endDate+" 23:59:59")
		argIdx++
	}

	// 查询总数
	countQuery := fmt.Sprintf(`
		SELECT COUNT(DISTINCT ol.id) FROM operation_logs ol
		%s
		WHERE %s`, operationLogUserJoin, where)
	var total int
	if err := h.db.QueryRow(countQuery, args...).Scan(&total); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// 查询数据（添加 execution_time_ms 字段）
	query := fmt.Sprintf(`
		SELECT ol.id, ol.operator_id, %s AS operator_name, ol.operator_role, ol.operation_type,
			   ol.operation_module, ol.operation_desc, ol.target_id, ol.target_name,
			   ol.ip_address, ol.user_agent, ol.execution_time_ms, ol.created_at
		FROM operation_logs ol
		%s
		WHERE %s
		ORDER BY ol.created_at DESC
		LIMIT $%d OFFSET $%d
	`, operationLogOperatorDisplay, operationLogUserJoin, where, argIdx, argIdx+1)

	args = append(args, pageSize, offset)

	rows, err := h.db.Query(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var logs []map[string]interface{}
	for rows.Next() {
		var log models.OperationLog
		var operatorID sql.NullString
		var operatorRole, targetID, targetName, userAgent sql.NullString
		var executionTimeMs sql.NullInt32

		err := rows.Scan(
			&log.ID, &operatorID, &log.OperatorName, &operatorRole,
			&log.OperationType, &log.OperationModule, &log.OperationDesc,
			&targetID, &targetName, &log.IPAddress, &userAgent,
			&executionTimeMs, &log.CreatedAt,
		)
		if err != nil {
			continue
		}

		if operatorID.Valid {
			log.OperatorID = operatorID.String
		}
		if operatorRole.Valid {
			log.OperatorRole = operatorRole.String
		}
		if targetID.Valid {
			log.TargetID = targetID.String
		}
		if targetName.Valid {
			log.TargetName = targetName.String
		}
		if userAgent.Valid {
			log.UserAgent = userAgent.String
		}
		if executionTimeMs.Valid {
			log.ExecutionTimeMs = int(executionTimeMs.Int32)
		}

		view := operationLogView{
			OperationType:   log.OperationType,
			OperationModule: log.OperationModule,
			OperatorRole:    log.OperatorRole,
		}
		normalizeOperationLogFields(&view)

		logs = append(logs, map[string]interface{}{
			"id":              log.ID,
			"operatorId":      log.OperatorID,
			"operatorName":    log.OperatorName,
			"operatorRole":    view.OperatorRole,
			"operationType":   view.OperationType,
			"operationModule": view.OperationModule,
			"operationDesc":   log.OperationDesc,
			"targetId":        log.TargetID,
			"targetName":      log.TargetName,
			"ipAddress":       log.IPAddress,
			"userAgent":       log.UserAgent,
			"executionTimeMs": log.ExecutionTimeMs,
			"createdAt":       log.CreatedAt,
		})
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items":    logs,
		"total":    total,
		"page":     page,
		"pageSize": pageSize,
	})
}

// GetOperationModules 获取操作模块列表
func (h *OperationLogHandler) GetOperationModules(c *gin.Context) {
	rows, err := h.db.Query(`
		SELECT DISTINCT operation_module FROM operation_logs 
		ORDER BY operation_module
	`)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var modules []string
	seen := map[string]struct{}{}
	for rows.Next() {
		var module string
		rows.Scan(&module)
		cn := NormalizeOperationModule(module)
		if _, ok := seen[cn]; ok {
			continue
		}
		seen[cn] = struct{}{}
		modules = append(modules, cn)
	}

	models.Send(c, 200, 0, "success", modules)
}

// GetOperationTypes 获取操作类型列表
func (h *OperationLogHandler) GetOperationTypes(c *gin.Context) {
	rows, err := h.db.Query(`
		SELECT DISTINCT operation_type FROM operation_logs 
		ORDER BY operation_type
	`)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var types []string
	typeSeen := map[string]struct{}{}
	for rows.Next() {
		var t string
		rows.Scan(&t)
		cn := NormalizeOperationType(t)
		if _, ok := typeSeen[cn]; ok {
			continue
		}
		typeSeen[cn] = struct{}{}
		types = append(types, cn)
	}

	models.Send(c, 200, 0, "success", types)
}

// ExportOperationLogs 导出操作日志
func (h *OperationLogHandler) ExportOperationLogs(c *gin.Context) {
	operatorName := c.Query("operatorName")
	operationModule := c.Query("operationModule")
	startDate := c.Query("startDate")
	endDate := c.Query("endDate")

	where := "1=1"
	args := []interface{}{}
	argIdx := 1

	if operatorName != "" {
		where += fmt.Sprintf(` AND (
			%s ILIKE $%d
			OR ol.operator_name ILIKE $%d
			OR u.real_name ILIKE $%d
			OR u.username ILIKE $%d
		)`, operationLogOperatorDisplay, argIdx, argIdx, argIdx, argIdx)
		args = append(args, "%"+operatorName+"%")
		argIdx++
	}
	if operationModule != "" {
		moduleValues := OperationModuleFilterValues(operationModule)
		if len(moduleValues) == 1 {
			where += fmt.Sprintf(" AND ol.operation_module = $%d", argIdx)
			args = append(args, moduleValues[0])
			argIdx++
		} else if len(moduleValues) > 1 {
			placeholders := make([]string, len(moduleValues))
			for i, v := range moduleValues {
				placeholders[i] = fmt.Sprintf("$%d", argIdx)
				args = append(args, v)
				argIdx++
			}
			where += fmt.Sprintf(" AND ol.operation_module IN (%s)", strings.Join(placeholders, ","))
		}
	}
	if startDate != "" {
		where += fmt.Sprintf(" AND ol.created_at >= $%d", argIdx)
		args = append(args, startDate)
		argIdx++
	}
	if endDate != "" {
		where += fmt.Sprintf(" AND ol.created_at <= $%d", argIdx)
		args = append(args, endDate+" 23:59:59")
		argIdx++
	}

	query := fmt.Sprintf(`
		SELECT %s AS operator_name, ol.operator_role, ol.operation_type, ol.operation_module,
			   ol.operation_desc, ol.target_name, ol.ip_address, ol.execution_time_ms, ol.created_at
		FROM operation_logs ol
		%s
		WHERE %s
		ORDER BY ol.created_at DESC
		LIMIT 10000
	`, operationLogOperatorDisplay, operationLogUserJoin, where)

	rows, err := h.db.Query(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var builder strings.Builder
	builder.WriteString("操作人,角色,操作类型,操作模块,操作描述,目标名称,IP地址,耗时(ms),操作时间\n")

	for rows.Next() {
		var operatorName, operatorRole, operationType, operationModule, operationDesc, targetName, ipAddress string
		var executionTimeMs int
		var createdAt time.Time
		rows.Scan(&operatorName, &operatorRole, &operationType, &operationModule,
			&operationDesc, &targetName, &ipAddress, &executionTimeMs, &createdAt)

		view := operationLogView{
			OperationType:   operationType,
			OperationModule: operationModule,
			OperatorRole:    operatorRole,
		}
		normalizeOperationLogFields(&view)

		builder.WriteString(fmt.Sprintf("%s,%s,%s,%s,%s,%s,%s,%d,%s\n",
			escapeCSV(operatorName), escapeCSV(view.OperatorRole),
			escapeCSV(view.OperationType), escapeCSV(view.OperationModule),
			escapeCSV(operationDesc), escapeCSV(targetName),
			escapeCSV(ipAddress), executionTimeMs, createdAt.Format("2006-01-02 15:04:05")))
	}

	c.Header("Content-Type", "text/csv; charset=utf-8")
	c.Header("Content-Disposition", "attachment; filename=operation_logs_"+time.Now().Format("20060102")+".csv")
	c.String(200, builder.String())
}

// DeleteOperationLogs 批量删除操作日志
func (h *OperationLogHandler) DeleteOperationLogs(c *gin.Context) {
	var req struct {
		IDs       []string `json:"ids"`
		DaysOld   int      `json:"daysOld"`
		DeleteAll bool     `json:"deleteAll"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	if req.DeleteAll {
		_, err := h.db.Exec("DELETE FROM operation_logs")
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		models.Send(c, 200, 0, "所有操作日志已删除", gin.H{"deleted": "all"})
		return
	}

	if req.DaysOld > 0 {
		cutoff := time.Now().AddDate(0, 0, -req.DaysOld)
		result, err := h.db.Exec("DELETE FROM operation_logs WHERE created_at < $1", cutoff)
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		rowsAffected, _ := result.RowsAffected()
		models.Send(c, 200, 0, fmt.Sprintf("已删除 %d 条记录", rowsAffected), gin.H{"deleted": rowsAffected})
		return
	}

	if len(req.IDs) == 0 {
		models.SendError(c, 400, 1001, "请提供要删除的ID")
		return
	}

	placeholders := make([]string, len(req.IDs))
	args := make([]interface{}, len(req.IDs))
	for i, id := range req.IDs {
		placeholders[i] = "$" + strconv.Itoa(i+1)
		args[i] = id
	}

	query := fmt.Sprintf("DELETE FROM operation_logs WHERE id IN (%s)", strings.Join(placeholders, ","))
	result, err := h.db.Exec(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	rowsAffected, _ := result.RowsAffected()
	models.Send(c, 200, 0, fmt.Sprintf("已删除 %d 条记录", rowsAffected), gin.H{"deleted": rowsAffected})
}

func escapeCSV(s string) string {
	if s == "" {
		return ""
	}
	if strings.ContainsAny(s, ",\"\n\r") {
		return fmt.Sprintf("\"%s\"", strings.ReplaceAll(s, "\"", "\"\""))
	}
	return s
}

// ========== 操作日志中间件（只记录修改操作）==========

// OperationLogMiddleware 操作日志中间件 - 只记录 POST/PUT/DELETE 请求
func OperationLogMiddleware(db *sql.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 只记录修改操作（POST、PUT、DELETE）
		method := c.Request.Method
		if method != "POST" && method != "PUT" && method != "DELETE" {
			c.Next()
			return
		}

		// 跳过不需要记录日志的路径
		skipPaths := []string{
			"/api/v1/auth/login",
			"/api/v1/auth/refresh",
			"/api/v1/auth/logout",
			"/health",
			"/api/v1/ws/",
			"/api/v1/screenshots",
			"/api/v1/upload/chunk",
			"/api/v1/upload/complete",
			"/api/v1/operation-logs",
			"/api/v1/activities/report",
			"/api/v1/tasks",
			"/api/v1/upload-tasks",
		}

		requestPath := c.Request.URL.Path
		for _, skip := range skipPaths {
			if strings.HasPrefix(requestPath, skip) {
				c.Next()
				return
			}
		}

		// 记录开始时间 ⭐ 新增
		startTime := time.Now()

		// 读取请求体（仅用于读取后重新设置，不保存到日志）
		if c.Request.Body != nil {
			bodyBytes, _ := io.ReadAll(c.Request.Body)
			// 重新设置body，让后续handler可以读取
			c.Request.Body = io.NopCloser(bytes.NewBuffer(bodyBytes))
		}

		c.Next()

		// ⭐ 计算执行耗时（毫秒）
		executionTimeMs := int(time.Since(startTime).Milliseconds())

		// 获取操作人信息
		operatorID := c.GetString("userID")
		username := c.GetString("username")
		operatorName := resolveOperatorDisplayName(db, operatorID, username)
		operatorRole := c.GetString("role")

		// 如果是设备认证，不记录操作日志
		if operatorID == "" && operatorName == "" {
			return
		}

		// 判断操作类型和模块
		operationType := getOperationType(method)
		operationModule := getOperationModule(requestPath)
		responseStatus := c.Writer.Status()

		// 只记录成功的操作（2xx状态码）
		if responseStatus < 200 || responseStatus >= 300 {
			return
		}

		// 业务 handler 已写入更详细日志的路径，跳过中间件记录，避免重复且描述不清
		if shouldSkipMiddlewareOperationLog(requestPath) {
			return
		}

		targetID, targetName := extractLogTarget(c)
		operationDesc := buildOperationDesc(requestPath, method)
		operationDesc = appendTargetHint(operationDesc, targetName)

		log := &models.OperationLog{
			ID:              uuid.New().String(),
			OperatorID:      operatorID,
			OperatorName:    operatorName,
			OperatorRole:    operatorRole,
			OperationType:   NormalizeOperationType(operationType),
			OperationModule: NormalizeOperationModule(operationModule),
			OperationDesc:   operationDesc,
			TargetID:        targetID,
			TargetName:      targetName,
			IPAddress:       c.ClientIP(), // ⭐ 确保IP正确获取
			UserAgent:       c.Request.UserAgent(),
			ExecutionTimeMs: executionTimeMs, // ⭐ 新增：耗时
			CreatedAt:       time.Now(),
		}

		// 异步保存日志
		go saveOperationLog(db, log)
	}
}

func getOperationType(method string) string {
	switch method {
	case "POST":
		return NormalizeOperationType("CREATE")
	case "PUT", "PATCH":
		return NormalizeOperationType("UPDATE")
	case "DELETE":
		return NormalizeOperationType("DELETE")
	default:
		return NormalizeOperationType("OTHER")
	}
}

func getOperationModule(path string) string {
	switch {
	case strings.Contains(path, "/auth/"):
		return NormalizeOperationModule("AUTH")
	case strings.Contains(path, "/users"):
		return NormalizeOperationModule("USER")
	case strings.Contains(path, "/roles"):
		return NormalizeOperationModule("ROLE")
	case strings.Contains(path, "/devices"):
		return NormalizeOperationModule("DEVICE")
	case strings.Contains(path, "/recordings"):
		return NormalizeOperationModule("RECORDING")
	case strings.Contains(path, "/screenshots"):
		return NormalizeOperationModule("SCREENSHOT")
	case strings.Contains(path, "/activities"):
		return NormalizeOperationModule("ACTIVITY")
	case strings.Contains(path, "/policies"):
		return NormalizeOperationModule("POLICY")
	case strings.Contains(path, "/employees"):
		return NormalizeOperationModule("EMPLOYEE")
	case strings.Contains(path, "/attendance"):
		return NormalizeOperationModule("ATTENDANCE")
	case strings.Contains(path, "/performance"):
		return NormalizeOperationModule("PERFORMANCE")
	case strings.Contains(path, "/penalty"):
		return NormalizeOperationModule("PENALTY")
	case strings.Contains(path, "/site-stats"):
		return NormalizeOperationModule("SITE_STATS")
	case strings.Contains(path, "/salary"):
		return NormalizeOperationModule("SALARY")
	case strings.Contains(path, "/tasks"):
		return NormalizeOperationModule("TASK")
	case strings.Contains(path, "/workforce/telegram"):
		return NormalizeOperationModule("TELEGRAM_ATTENDANCE")
	case strings.Contains(path, "/invite-codes"):
		return NormalizeOperationModule("INVITE_CODE")
	case strings.Contains(path, "/employee-accounts"):
		return NormalizeOperationModule("EMPLOYEE_ACCOUNT")
	case strings.Contains(path, "/settings"):
		return NormalizeOperationModule("SYSTEM")
	case strings.Contains(path, "/notifications"):
		return NormalizeOperationModule("NOTIFICATION")
	case strings.Contains(path, "/remote-view"):
		return NormalizeOperationModule("REMOTE_VIEW")
	case strings.Contains(path, "/cleanup"):
		return NormalizeOperationModule("POLICY")
	default:
		return NormalizeOperationModule("OTHER")
	}
}

type operationDescRule struct {
	pathKeyword string
	method      string
	description string
}

// 路径匹配顺序：越具体的规则越靠前
var operationDescRules = []operationDescRule{
	{"/performance/push-settings/token", "PUT", "保存绩效 Telegram 推送 Bot Token"},
	{"/performance/push-settings/discover", "POST", "发现绩效推送频道或群组"},
	{"/performance/push-settings/bind", "PUT", "绑定绩效推送频道或群组"},
	{"/performance/push-settings/bind", "DELETE", "解绑绩效推送频道或群组"},
	{"/performance/push-settings/test", "POST", "测试绩效 Telegram 推送"},
	{"/performance/push-notify", "POST", "推送新增绩效记录到 Telegram"},
	{"/penalty/push-settings/token", "PUT", "保存罚款 Telegram 推送 Bot Token"},
	{"/penalty/push-settings/discover", "POST", "发现罚款推送频道或群组"},
	{"/penalty/push-settings/bind", "PUT", "绑定罚款推送频道或群组"},
	{"/penalty/push-settings/bind", "DELETE", "解绑罚款推送频道或群组"},
	{"/penalty/push-settings/test", "POST", "测试罚款 Telegram 推送"},
	{"/penalty/push-notify", "POST", "推送新增罚款记录到 Telegram"},
	{"/workforce/telegram/settings", "PUT", "更新 Telegram 考勤配置"},
	{"/workforce/telegram/groups", "POST", "绑定 Telegram 考勤群"},
	{"/workforce/telegram/groups", "DELETE", "删除 Telegram 考勤群"},
	{"/workforce/telegram/bindings", "POST", "创建 Telegram 员工绑定"},
	{"/workforce/telegram/bindings", "DELETE", "解除 Telegram 员工绑定"},
	{"/workforce/telegram/bindings/", "reset-daily", "重置员工当日 Telegram 打卡"},
	{"/workforce/telegram/daily-reset", "POST", "手动执行 Telegram 日重置"},
	{"/workforce/telegram/push-settings", "PUT", "更新 Telegram 推送配置"},
	{"/workforce/telegram/work-fines", "POST", "新增上下班罚款规则"},
	{"/workforce/telegram/work-fines", "DELETE", "删除上下班罚款规则"},
	{"/workforce/telegram/activity-fines", "POST", "新增活动超时罚款规则"},
	{"/workforce/telegram/activity-fines", "DELETE", "删除活动超时罚款规则"},
	{"/workforce/telegram/handover-config", "PUT", "更新 Telegram 换班日配置"},
	{"/workforce/telegram/shared-workstations", "POST", "添加共享工位成员"},
	{"/workforce/telegram/shared-workstations", "DELETE", "移除共享工位成员"},
	{"/invite-codes/regenerate", "POST", "重新生成员工邀请码"},
	{"/invite-codes/", "revoke", "作废邀请码"},
	{"/settings/cors-origins", "PUT", "更新 CORS 白名单"},
	{"/settings/auth-security", "PUT", "更新登录安全策略"},
	{"/settings/login-ip-whitelist", "PUT", "更新登录 IP 白名单"},
	{"/notifications", "POST", "发送系统通知"},
	{"/notifications", "PUT", "更新系统通知"},
	{"/notifications", "DELETE", "删除系统通知"},
	{"/remote-view/sessions", "POST", "发起远程查看会话"},
	{"/remote-view/sessions", "DELETE", "结束远程查看会话"},
	{"/site-stats/upload/preview", "POST", "预览出款统计上传表头"},
	{"/site-stats/upload", "POST", "上传出款统计数据"},
	{"/site-stats/data/clear-by-date", "DELETE", "清除指定站点出款统计"},
	{"/site-stats/clear-by-date-only", "DELETE", "清除指定日期全部出款统计"},
	{"/site-stats/clear-by-date-shift", "DELETE", "清除指定日期班次出款统计"},
	{"/site-stats/data/clear", "DELETE", "清空全部出款统计数据"},
	{"/site-stats/sites", "POST", "新增出款站点"},
	{"/site-stats/sites", "PUT", "修改出款站点"},
	{"/site-stats/sites", "DELETE", "删除出款站点"},
	{"/site-stats/employee-accounts/import", "POST", "导入出款员工账号"},
	{"/site-stats/employee-accounts", "POST", "新增出款员工账号"},
	{"/site-stats/employee-accounts", "PUT", "修改出款员工账号"},
	{"/site-stats/employee-accounts", "DELETE", "删除出款员工账号"},
	{"/employees", "POST", "新增员工"},
	{"/employees", "PUT", "修改员工信息"},
	{"/employees", "DELETE", "删除员工"},
	{"/attendance/records/import", "POST", "导入考勤记录"},
	{"/attendance/records", "POST", "保存考勤记录"},
	{"/performance/batch", "POST", "批量保存绩效考核"},
	{"/performance/", "PUT", "修改员工绩效考核"},
	{"/performance/", "DELETE", "删除员工绩效考核"},
	{"/penalty/record", "POST", "添加罚款记录"},
	{"/penalty/records", "PUT", "修改罚款记录"},
	{"/penalty/records", "DELETE", "删除罚款记录"},
	{"/salary/upload", "POST", "上传工资表"},
	{"/salary/records", "PUT", "修改工资记录"},
	{"/salary/records", "DELETE", "删除工资记录"},
	{"/users", "POST", "创建系统用户"},
	{"/users", "PUT", "修改系统用户"},
	{"/users", "DELETE", "删除系统用户"},
	{"/roles", "POST", "创建角色"},
	{"/roles", "PUT", "修改角色"},
	{"/roles", "DELETE", "删除角色"},
	{"/policies/", "publish", "发布监控策略"},
	{"/policies", "POST", "创建监控策略"},
	{"/policies", "PUT", "修改监控策略"},
	{"/policies", "DELETE", "删除监控策略"},
	{"/policies/", "rollback", "回滚监控策略"},
	{"/devices", "POST", "绑定监控设备"},
	{"/devices", "PUT", "修改设备信息"},
	{"/devices", "DELETE", "解绑监控设备"},
	{"/devices/", "bind", "绑定设备到员工"},
	{"/devices/", "unbind", "解绑设备员工"},
	{"/devices/", "force-offline", "强制设备下线"},
	{"/devices/", "status", "更新设备审核状态"},
	{"/recordings", "DELETE", "删除录屏文件"},
	{"/screenshots/batch-delete", "POST", "批量删除截图"},
	{"/screenshots/purge", "POST", "批量清理截图"},
	{"/screenshots", "DELETE", "删除截图"},
	{"/cleanup/manual", "POST", "手动执行存储清理"},
	{"/cleanup/policy", "PUT", "修改存储清理策略"},
	{"/tasks/batch-status", "POST", "批量更新任务状态"},
	{"/tasks/", "cancel", "取消上传任务"},
	{"/tasks/", "retry", "重试上传任务"},
	{"/tasks", "POST", "创建上传任务"},
	{"/tasks", "DELETE", "删除上传任务"},
	{"/user/profile", "PUT", "修改个人资料"},
	{"/user/change-password", "POST", "修改登录密码"},
}

func shouldSkipMiddlewareOperationLog(path string) bool {
	prefixes := []string{
		"/api/v1/users",
		"/api/v1/user/profile",
		"/api/v1/user/change-password",
		"/api/v1/roles",
		"/api/v1/admin/attendance/records",
		"/api/v1/admin/penalty",
		"/api/v1/admin/performance",
		"/api/v1/admin/employees",
		"/api/v1/admin/employee-accounts",
		"/api/v1/admin/site-stats",
		"/api/v1/admin/workforce/telegram",
		"/api/v1/admin/invite-codes",
		"/api/v1/salary",
		"/api/v1/tasks",
		"/api/v1/settings",
	}
	for _, prefix := range prefixes {
		if strings.HasPrefix(path, prefix) {
			return true
		}
	}
	return false
}

func buildOperationDesc(path, method string) string {
	if strings.Contains(path, "/users/") && strings.Contains(path, "/roles") {
		switch method {
		case "POST":
			return "分配用户角色"
		case "DELETE":
			return "移除用户角色"
		}
	}
	if strings.Contains(path, "reset-password") && method == "POST" {
		return "重置用户密码"
	}

	for _, rule := range operationDescRules {
		if !strings.Contains(path, rule.pathKeyword) {
			continue
		}
		if rule.method != "" && rule.method != method && !strings.Contains(path, rule.method) {
			continue
		}
		return rule.description
	}

	actionName := map[string]string{
		"POST":   "新增",
		"PUT":    "修改",
		"DELETE": "删除",
		"PATCH":  "修改",
	}[method]
	moduleName := getOperationModuleLabel(path)
	if actionName != "" && moduleName != "" {
		return actionName + moduleName
	}
	return method + " " + path
}

func getOperationModuleLabel(path string) string {
	switch {
	case strings.Contains(path, "/users"):
		return "系统用户"
	case strings.Contains(path, "/roles"):
		return "角色"
	case strings.Contains(path, "/devices"):
		return "设备"
	case strings.Contains(path, "/recordings"):
		return "录屏"
	case strings.Contains(path, "/screenshots"):
		return "截图"
	case strings.Contains(path, "/policies"):
		return "监控策略"
	case strings.Contains(path, "/cleanup"):
		return "清理策略"
	case strings.Contains(path, "/employees"):
		return "员工"
	case strings.Contains(path, "/attendance"):
		return "考勤"
	case strings.Contains(path, "/performance"):
		return "绩效考核"
	case strings.Contains(path, "/penalty"):
		return "罚款"
	case strings.Contains(path, "/site-stats"):
		return "出款统计"
	case strings.Contains(path, "/salary"):
		return "工资"
	case strings.Contains(path, "/tasks"):
		return "任务"
	default:
		return "数据"
	}
}

func extractLogTarget(c *gin.Context) (targetID, targetName string) {
	if id := c.Param("id"); id != "" {
		return id, ""
	}
	if employeeID := c.Param("employeeId"); employeeID != "" {
		if month := c.Param("month"); month != "" {
			return employeeID, month + " 月绩效"
		}
		return employeeID, ""
	}
	return "", ""
}

func appendTargetHint(desc, targetName string) string {
	targetName = strings.TrimSpace(targetName)
	if targetName == "" || strings.Contains(desc, targetName) {
		return desc
	}
	return desc + "：" + targetName
}

func getOperationDesc(path, method string) string {
	return buildOperationDesc(path, method)
}

func truncateString(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen] + "..."
}

// saveOperationLog 保存操作日志到数据库（包含 IP 和耗时）
func saveOperationLog(db *sql.DB, log *models.OperationLog) {
	query := `
        INSERT INTO operation_logs (
            id, operator_id, operator_name, operator_role, operation_type,
            operation_module, operation_desc, target_id, target_name,
            ip_address, user_agent, execution_time_ms, created_at
        ) VALUES ($1, NULLIF($2, ''), $3, $4, $5, $6, $7, NULLIF($8, ''), NULLIF($9, ''), $10, $11, $12, $13)
    `
    _, err := db.Exec(query,
        log.ID, log.OperatorID, log.OperatorName, log.OperatorRole,
        log.OperationType, log.OperationModule, log.OperationDesc,
        log.TargetID, log.TargetName, log.IPAddress, log.UserAgent,
        log.ExecutionTimeMs, log.CreatedAt,
    )
    if err != nil {
        logx.Debug("saveOperationLog failed: %v", err)
    }
}

// SaveOperationLog 公共方法：供其他 handler 调用记录操作日志
func (h *OperationLogHandler) SaveOperationLog(c *gin.Context, operationType, operationModule, operationDesc, targetID, targetName string) {
	operatorID := c.GetString("userID")
	username := c.GetString("username")
	operatorName := resolveOperatorDisplayName(h.db, operatorID, username)
	operatorRole := c.GetString("role")

	if operatorID == "" && operatorName == "" {
		return
	}

	log := &models.OperationLog{
		ID:              uuid.New().String(),
		OperatorID:      operatorID,
		OperatorName:    operatorName,
		OperatorRole:    operatorRole,
		OperationType:   NormalizeOperationType(operationType),
		OperationModule: NormalizeOperationModule(operationModule),
		OperationDesc:   operationDesc,
		TargetID:        targetID,
		TargetName:      targetName,
		IPAddress:       c.ClientIP(),
		UserAgent:       c.Request.UserAgent(),
		ExecutionTimeMs: 0, // 手动调用时无法计算耗时，设为0
		CreatedAt:       time.Now(),
	}

	go saveOperationLog(h.db, log)
}

// GlobalLogger 全局操作日志处理器，在 main.go 中初始化
var GlobalLogger *OperationLogHandler

// Log 全局日志记录函数，方便在各个 handler 中调用
func Log(c *gin.Context, operationType, operationModule, operationDesc, targetID, targetName string) {
	if GlobalLogger != nil {
		GlobalLogger.SaveOperationLog(c, operationType, operationModule, operationDesc, targetID, targetName)
	}
}

func resolveOperatorDisplayName(db *sql.DB, operatorID, username string) string {
	var realName sql.NullString

	if operatorID != "" {
		if err := db.QueryRow(`SELECT real_name FROM users WHERE id::text = $1`, operatorID).Scan(&realName); err == nil {
			if realName.Valid && strings.TrimSpace(realName.String) != "" {
				return strings.TrimSpace(realName.String)
			}
		}
	}

	if username != "" {
		if err := db.QueryRow(`SELECT real_name FROM users WHERE username = $1`, username).Scan(&realName); err == nil {
			if realName.Valid && strings.TrimSpace(realName.String) != "" {
				return strings.TrimSpace(realName.String)
			}
		}
		return username
	}

	return ""
}

const operationLogUserJoin = `
LEFT JOIN users u ON (
	(ol.operator_id IS NOT NULL AND ol.operator_id <> '' AND u.id::text = ol.operator_id)
	OR u.username = ol.operator_name
)`

const operationLogOperatorDisplay = `COALESCE(NULLIF(TRIM(u.real_name), ''), ol.operator_name)`
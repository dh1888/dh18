package handlers

import "strings"

var operationTypeLabels = map[string]string{
	"CREATE":   "创建",
	"UPDATE":   "修改",
	"DELETE":   "删除",
	"UPLOAD":   "上传",
	"EXPORT":   "导出",
	"VIEW":     "查看",
	"DOWNLOAD": "下载",
	"LOGIN":    "登录",
	"LOGOUT":   "登出",
	"QUERY":    "查询",
	"POST":     "创建",
	"PUT":      "修改",
	"PATCH":    "修改",
	"OTHER":    "其他",
}

var operationModuleLabels = map[string]string{
	"USER":                "用户管理",
	"ROLE":                "角色管理",
	"DEVICE":              "设备管理",
	"RECORDING":           "录屏管理",
	"SCREENSHOT":          "截图管理",
	"ACTIVITY":            "活动日志",
	"POLICY":              "策略管理",
	"EMPLOYEE":            "员工管理",
	"ATTENDANCE":          "考勤管理",
	"PERFORMANCE":         "绩效管理",
	"PENALTY":             "罚款管理",
	"SITE_STATS":          "出款统计",
	"SALARY":              "工资管理",
	"TASK":                "任务管理",
	"TELEGRAM_ATTENDANCE": "Telegram考勤",
	"INVITE_CODE":         "邀请码管理",
	"EMPLOYEE_ACCOUNT":    "员工账号",
	"SYSTEM":              "系统设置",
	"AUTH":                "登录认证",
	"NOTIFICATION":        "消息通知",
	"REMOTE_VIEW":         "远程查看",
	"OTHER":               "其他",
}

var operatorRoleLabels = map[string]string{
	"admin":        "管理员",
	"super_admin":  "超级管理员",
	"operator":     "操作员",
	"auditor":      "审计员",
	"hr":           "人事",
	"finance":      "财务",
	"attendance":   "考勤员",
}

// NormalizeOperationType 将操作类型转为中文展示
func NormalizeOperationType(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "其他"
	}
	if cn, ok := operationTypeLabels[strings.ToUpper(value)]; ok {
		return cn
	}
	if cn, ok := operationTypeLabels[value]; ok {
		return cn
	}
	return value
}

// NormalizeOperationModule 将操作模块转为中文展示
func NormalizeOperationModule(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "其他"
	}
	if cn, ok := operationModuleLabels[strings.ToUpper(value)]; ok {
		return cn
	}
	if cn, ok := operationModuleLabels[value]; ok {
		return cn
	}
	return value
}

// NormalizeOperatorRole 将角色转为中文展示
func NormalizeOperatorRole(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return "-"
	}
	key := strings.ToLower(value)
	if cn, ok := operatorRoleLabels[key]; ok {
		return cn
	}
	return value
}

// OperationModuleFilterValues 筛选时同时匹配中英文模块值
func OperationModuleFilterValues(label string) []string {
	label = strings.TrimSpace(label)
	if label == "" {
		return nil
	}
	seen := map[string]struct{}{label: {}}
	out := []string{label}
	for code, cn := range operationModuleLabels {
		if cn == label || strings.EqualFold(code, label) {
			for _, v := range []string{code, cn} {
				if _, ok := seen[v]; ok {
					continue
				}
				seen[v] = struct{}{}
				out = append(out, v)
			}
		}
	}
	return out
}

// OperationTypeFilterValues 筛选时同时匹配中英文类型值
func OperationTypeFilterValues(label string) []string {
	label = strings.TrimSpace(label)
	if label == "" {
		return nil
	}
	seen := map[string]struct{}{label: {}}
	out := []string{label}
	for code, cn := range operationTypeLabels {
		if cn == label || strings.EqualFold(code, label) {
			for _, v := range []string{code, cn} {
				if _, ok := seen[v]; ok {
					continue
				}
				seen[v] = struct{}{}
				out = append(out, v)
			}
		}
	}
	return out
}

func normalizeOperationLogFields(log *operationLogView) {
	if log == nil {
		return
	}
	log.OperationType = NormalizeOperationType(log.OperationType)
	log.OperationModule = NormalizeOperationModule(log.OperationModule)
	log.OperatorRole = NormalizeOperatorRole(log.OperatorRole)
}

type operationLogView struct {
	OperationType   string
	OperationModule string
	OperatorRole    string
}

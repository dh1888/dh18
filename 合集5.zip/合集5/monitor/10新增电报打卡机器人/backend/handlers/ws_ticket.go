package handlers

import (
	"errors"

	"github.com/gin-gonic/gin"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type WSTicketHandler struct {
	sessions *services.SessionService
}

func NewWSTicketHandler(sessions *services.SessionService) *WSTicketHandler {
	return &WSTicketHandler{sessions: sessions}
}

func (h *WSTicketHandler) IssueUser(c *gin.Context) {
	if h.sessions == nil {
		models.SendError(c, 503, 5003, "WS ticket service unavailable")
		return
	}

	sessionID := c.GetString("sessionID")
	if sessionID == "" {
		models.SendError(c, 401, 1002, "Missing session")
		return
	}

	ticket, ttl, err := h.sessions.IssueWSTicket(c.Request.Context(), sessionID)
	if err != nil {
		if errors.Is(err, services.ErrSessionRevoked) || errors.Is(err, services.ErrSessionExpired) {
			models.SendError(c, 401, 1002, "Session is not active")
			return
		}
		models.SendInternalError(c, err)
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"ticket":    ticket,
		"expiresIn": int(ttl.Seconds()),
	})
}

func (h *WSTicketHandler) IssueDevice(c *gin.Context) {
	if h.sessions == nil {
		models.SendError(c, 503, 5003, "WS ticket service unavailable")
		return
	}

	sessionID := c.GetString("sessionID")
	if sessionID == "" {
		models.SendError(c, 401, 1002, "Missing session")
		return
	}

	deviceID := c.GetString("deviceID")
	if deviceID == "" {
		models.SendError(c, 401, 1002, "Device not authenticated")
		return
	}

	sess, err := h.sessions.ValidateActiveSession(c.Request.Context(), sessionID)
	if err != nil {
		models.SendError(c, 401, 1002, "Session is not active")
		return
	}
	if sess.SubjectType != services.SessionSubjectDevice || sess.SubjectID.String() != deviceID {
		models.SendError(c, 403, 1003, "Session device mismatch")
		return
	}

	ticket, ttl, err := h.sessions.IssueWSTicket(c.Request.Context(), sessionID)
	if err != nil {
		models.SendInternalError(c, err)
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"ticket":    ticket,
		"expiresIn": int(ttl.Seconds()),
	})
}

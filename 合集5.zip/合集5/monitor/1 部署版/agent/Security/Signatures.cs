// Security/Signatures.cs

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Logging;
using EnterpriseAgent.Agent.Services;

namespace EnterpriseAgent.Agent.Security;

/// <summary>
/// API 签名服务接口（禁止修改）
/// </summary>
public interface ISignatureService
{
    string GenerateSignature(string timestamp, string nonce, object payload);
    (string timestamp, string nonce, string signature) CreateSignedRequest(object payload);
    string GenerateHmacSha256(string data, string secret);
    void AddSignatureHeaders(HttpRequestMessage request, string timestamp, string nonce, string signature);
}

/// <summary>
/// 上传签名负载
/// </summary>
public class UploadSignaturePayload
{
    [JsonPropertyName("uploadId")]
    public string UploadId { get; set; } = "";

    [JsonPropertyName("fileName")]
    public string? FileName { get; set; }

    [JsonPropertyName("fileType")]
    public string? FileType { get; set; }

    [JsonPropertyName("fileId")]
    public string? FileId { get; set; }

    [JsonPropertyName("chunkIndex")]
    public int ChunkIndex { get; set; }

    [JsonPropertyName("totalChunks")]
    public int TotalChunks { get; set; }

    [JsonIgnore]
    public string? Data { get; set; }
}

/// <summary>
/// 完成上传
/// </summary>
public class CompleteUploadSignaturePayload
{
    [JsonPropertyName("uploadId")]
    public string UploadId { get; set; } = "";

    [JsonPropertyName("deviceId")]
    public string? DeviceId { get; set; }
}

public class ApiSigner : ISignatureService
{
    private readonly Models.AgentConfig _config;
    private readonly ILogger<ApiSigner> _logger;
    private readonly IAuthTokenProvider? _authTokenProvider;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    // ✅ 向后兼容构造函数
    public ApiSigner(Models.AgentConfig config, ILogger<ApiSigner> logger)
        : this(config, null, logger)
    {
    }

    // ✅ 主构造函数
    public ApiSigner(
        Models.AgentConfig config,
        IAuthTokenProvider? authTokenProvider,
        ILogger<ApiSigner> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _authTokenProvider = authTokenProvider;
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        _logger.LogInformation(
            "ApiSigner initialized - DeviceId:{DeviceId}, HasSecret:{HasSecret}, HasProvider:{HasProvider}",
            SafeDeviceId(),
            TryGetSecret(out _),
            _authTokenProvider != null);
    }

    private bool TryGetSecret(out string? secret)
    {
        secret = null;

        if (_authTokenProvider != null)
        {
            var snap = _authTokenProvider.GetSnapshot();
            if (!string.IsNullOrEmpty(snap.DeviceSecret))
            {
                secret = snap.DeviceSecret;
                return true;
            }
        }

        var configSecret = _config?.Auth?.DeviceSecret;
        if (!string.IsNullOrEmpty(configSecret))
        {
            secret = configSecret;
            return true;
        }

        return false;
    }

    #region ====== 统一凭证访问 ======

    private string GetSecretInternal()
    {
        if (TryGetSecret(out var secret) && !string.IsNullOrEmpty(secret))
            return secret;

        throw new InvalidOperationException(
            "DeviceSecret not available. Wait for device registration to complete.");
    }

    private string GetDeviceIdInternal()
    {
        try
        {
            if (_authTokenProvider != null)
            {
                var snap = _authTokenProvider.GetSnapshot();
                if (!string.IsNullOrEmpty(snap.DeviceId))
                    return snap.DeviceId;
            }

            return _config?.DeviceId ?? string.Empty;
        }
        catch
        {
            return _config?.DeviceId ?? string.Empty;
        }
    }

    private string SafeDeviceId()
        => GetDeviceIdInternal();

    #endregion

    #region ====== 核心签名 ======

    public string GenerateSignature(string timestamp, string nonce, object payload)
    {
        var payloadJson = BuildPayloadJson(payload);
        var message = $"{timestamp}|{nonce}|{payloadJson}";
        return HmacSha256Internal(message, GetSecretInternal());
    }

    public (string timestamp, string nonce, string signature) CreateSignedRequest(object payload)
    {
        var timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");
        var nonce = GenerateNonce();
        var signature = GenerateSignature(timestamp, nonce, payload);
        return (timestamp, nonce, signature);
    }

    /// <summary>
    /// ✅ 异步版本 - 避免死锁
    /// </summary>
    public async Task AddSignatureHeadersAsync(
        HttpRequestMessage request,
        string timestamp,
        string nonce,
        string signature,
        CancellationToken cancellationToken = default)
    {
        var bodyHash = await GetBodyHashAsync(request, cancellationToken).ConfigureAwait(false);

        var method = request.Method.Method;
        var path = request.RequestUri?.AbsolutePath ?? "/";

        var message = timestamp + method + path + bodyHash;
        var finalSig = HmacSha256Internal(message, GetSecretInternal());

        var deviceId = GetDeviceIdInternal();
        if (!string.IsNullOrEmpty(deviceId))
            request.Headers.TryAddWithoutValidation("X-Device-Id", deviceId);

        request.Headers.TryAddWithoutValidation("X-Timestamp", timestamp);
        request.Headers.TryAddWithoutValidation("X-Nonce", nonce);
        request.Headers.TryAddWithoutValidation("X-Signature", finalSig);
        request.Headers.TryAddWithoutValidation("X-Signature-Version", "v1");
    }

    /// <summary>
    /// 同步版本 - 建议使用异步版本
    /// </summary>
    public void AddSignatureHeaders(HttpRequestMessage request, string timestamp, string nonce, string signature)
    {
        _logger.LogWarning(
            "[SIG_WARN] Using synchronous AddSignatureHeaders - consider migrating to AddSignatureHeadersAsync");

        try
        {
            AddSignatureHeadersAsync(request, timestamp, nonce, signature, CancellationToken.None)
                .ConfigureAwait(false)
                .GetAwaiter()
                .GetResult();
        }
        catch (AggregateException ex) when (ex.InnerExceptions.Count == 1)
        {
            throw ex.InnerException!;
        }
        catch (AggregateException ex)
        {
            throw ex.InnerException ?? ex;
        }
    }

    #endregion

    #region ====== 工具方法 ======

    public string GenerateHmacSha256(string data, string secret)
        => HmacSha256Internal(data, string.IsNullOrEmpty(secret) ? GetSecretInternal() : secret);

    private static string HmacSha256Internal(string data, string secret)
    {
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(secret));
        var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(data));
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private static string GenerateNonce()
    {
        Span<byte> bytes = stackalloc byte[24];
        RandomNumberGenerator.Fill(bytes);

        return Convert.ToBase64String(bytes)
            .Replace('+', '-')
            .Replace('/', '_')
            .TrimEnd('=');
    }

    private static string GetBodyHash(HttpRequestMessage request)
    {
        if (request.Content == null)
            return string.Empty;

        var body = request.Content.ReadAsByteArrayAsync()
            .GetAwaiter()
            .GetResult();

        using var sha = SHA256.Create();
        var hash = sha.ComputeHash(body);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    /// <summary>
    /// ✅ 异步获取 BodyHash - 对原始字节做 SHA256（支持二进制分块上传）
    /// </summary>
    private static async Task<string> GetBodyHashAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken = default)
    {
        if (request.Content == null)
            return string.Empty;

        try
        {
            var body = await request.Content
                .ReadAsByteArrayAsync(cancellationToken)
                .ConfigureAwait(false);

            using var sha = SHA256.Create();
            var hash = sha.ComputeHash(body);
            return Convert.ToHexString(hash).ToLowerInvariant();
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch
        {
            return string.Empty;
        }
    }

    private static string BuildPayloadJson(object payload)
    {
        if (payload is not UploadSignaturePayload u)
            return JsonSerializer.Serialize(payload, JsonOptions);

        // ✅ 修复：使用可空类型避免条件表达式类型不匹配
        int? chunkIndex = u.ChunkIndex == 0 ? null : u.ChunkIndex;
        int? totalChunks = u.TotalChunks == 0 ? null : u.TotalChunks;

        var optimized = new
        {
            uploadId = u.UploadId,
            fileName = string.IsNullOrWhiteSpace(u.FileName) ? null : u.FileName,
            fileType = string.IsNullOrWhiteSpace(u.FileType) ? null : u.FileType,
            fileId = string.IsNullOrWhiteSpace(u.FileId) ? null : u.FileId,
            chunkIndex = chunkIndex,
            totalChunks = totalChunks
        };

        return JsonSerializer.Serialize(optimized, JsonOptions);
    }

    #endregion
}

/// <summary>
/// ✅ 扩展方法 - 便捷使用
/// </summary>
public static class ApiSignerExtensions
{
    public static async Task AddSignatureAsync(
        this HttpRequestMessage request,
        ApiSigner signer,
        object payload,
        CancellationToken cancellationToken = default)
    {
        var (timestamp, nonce, signature) = signer.CreateSignedRequest(payload);
        await signer.AddSignatureHeadersAsync(request, timestamp, nonce, signature, cancellationToken)
            .ConfigureAwait(false);
    }
}

/// <summary>
/// Represents a canonicalized HTTP request for signature computation.
/// This is the ONLY approved way to build canonical requests for v1.
/// </summary>
public class CanonicalRequest
{
    /// <summary>
    /// Timestamp in ISO 8601 UTC format: YYYY-MM-DDTHH:mm:ssZ
    /// </summary>
    public string Timestamp { get; set; } = string.Empty;

    /// <summary>
    /// HTTP method in UPPERCASE: POST, GET, PUT, DELETE, PATCH
    /// </summary>
    public string HttpMethod { get; set; } = string.Empty;

    /// <summary>
    /// Absolute URL path (UTF-8 decoded)
    /// </summary>
    public string Path { get; set; } = string.Empty;

    /// <summary>
    /// SHA256(body) in lowercase hex (64 characters)
    /// </summary>
    public string BodyHash { get; set; } = string.Empty;

    /// <summary>
    /// Builds a canonical request from raw inputs
    /// </summary>
    public static CanonicalRequest BuildCanonical(string timestamp, string method, string path, byte[] bodyBytes)
    {
        // 1. Normalize HTTP method to UPPERCASE
        method = method?.ToUpperInvariant() ?? "GET";

        // 2. Decode and normalize path
        string decodedPath = path ?? "/";
        try
        {
            decodedPath = Uri.UnescapeDataString(decodedPath);
        }
        catch
        {
            // If decoding fails, use original path
        }

        // 3. Calculate body hash
        using var sha = SHA256.Create();
        var bodyHash = sha.ComputeHash(bodyBytes ?? Array.Empty<byte>());
        var bodyHashHex = Convert.ToHexString(bodyHash).ToLowerInvariant();

        return new CanonicalRequest
        {
            Timestamp = timestamp,
            HttpMethod = method,
            Path = decodedPath,
            BodyHash = bodyHashHex
        };
    }

    /// <summary>
    /// Returns the canonical message for HMAC computation.
    /// Format: TIMESTAMP + HTTP_METHOD + PATH + BODY_HASH (no separators)
    /// </summary>
    public string GetMessage() => $"{Timestamp}{HttpMethod}{Path}{BodyHash}";

    /// <summary>
    /// Overrides ToString to return the canonical message
    /// </summary>
    public override string ToString() => GetMessage();

    /// <summary>
    /// Validates if canonical request is valid according to v1 spec
    /// </summary>
    public (bool isValid, string error) Validate()
    {
        // Validate timestamp format (ISO 8601 UTC)
        if (!IsValidRfc3339Timestamp(Timestamp))
        {
            return (false, $"Invalid timestamp format: {Timestamp} (must be YYYY-MM-DDTHH:mm:ssZ)");
        }

        // Validate HTTP method
        if (!IsValidHttpMethod(HttpMethod))
        {
            return (false, $"Invalid HTTP method: {HttpMethod} (must be uppercase)");
        }

        // Validate path (must start with /)
        if (!Path?.StartsWith("/") ?? true)
        {
            return (false, $"Path must start with /: {Path}");
        }

        // Validate body hash (must be 64-char lowercase hex)
        if (!IsValidHex(BodyHash, 64))
        {
            return (false, $"Invalid body hash: {BodyHash} (must be 64-char lowercase hex)");
        }

        return (true, string.Empty);
    }

    /// <summary>
    /// Checks if timestamp matches YYYY-MM-DDTHH:mm:ssZ format
    /// </summary>
    private static bool IsValidRfc3339Timestamp(string ts)
    {
        if (string.IsNullOrEmpty(ts) || ts.Length != 20)
        {
            return false;
        }

        if (ts[19] != 'Z' || ts[10] != 'T')
        {
            return false;
        }

        if (ts[4] != '-' || ts[7] != '-')
        {
            return false;
        }

        if (ts[13] != ':' || ts[16] != ':')
        {
            return false;
        }

        // All other characters must be digits
        var digitPositions = new[] { 0, 1, 2, 3, 5, 6, 8, 9, 11, 12, 14, 15, 17, 18 };
        foreach (var pos in digitPositions)
        {
            if (!char.IsDigit(ts[pos]))
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// Checks if method is uppercase and known
    /// </summary>
    private static bool IsValidHttpMethod(string method)
    {
        return !string.IsNullOrEmpty(method) && method switch
        {
            "GET" or "POST" or "PUT" or "DELETE" or "PATCH" or "HEAD" or "OPTIONS" => true,
            _ => false
        };
    }

    /// <summary>
    /// Checks if string is N-character lowercase hexadecimal
    /// </summary>
    private static bool IsValidHex(string s, int length)
    {
        if (string.IsNullOrEmpty(s) || s.Length != length)
        {
            return false;
        }

        foreach (var c in s)
        {
            if ((c < '0' || c > '9') && (c < 'a' || c > 'f'))
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// Computes HMAC-SHA256 signature using the canonical message
    /// This is the v1 signature algorithm
    /// </summary>
    public static string ComputeSignature(string canonicalMessage, string deviceSecret)
    {
        var key = Encoding.UTF8.GetBytes(deviceSecret ?? string.Empty);
        using var hmac = new HMACSHA256(key);
        var sig = hmac.ComputeHash(Encoding.UTF8.GetBytes(canonicalMessage ?? string.Empty));
        return Convert.ToHexString(sig).ToLowerInvariant();
    }
}

// Security/Encryption.cs - 加密服务接口和实现合并

using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Security;

/// <summary>
/// 加密服务接口
/// </summary>
public interface IEncryptionService
{
    /// <summary>
    /// 加密字符串
    /// </summary>
    /// <param name="plaintext">明文</param>
    /// <returns>Base64 编码的密文</returns>
    string Encrypt(string plaintext);

    /// <summary>
    /// 解密字符串
    /// </summary>
    /// <param name="ciphertext">Base64 编码的密文</param>
    /// <returns>明文</returns>
    string Decrypt(string ciphertext);

    /// <summary>
    /// 加密字节数组
    /// </summary>
    /// <param name="plaintext">明文</param>
    /// <returns>密文</returns>
    byte[] Encrypt(byte[] plaintext);

    /// <summary>
    /// 解密字节数组
    /// </summary>
    /// <param name="ciphertext">密文</param>
    /// <returns>明文</returns>
    byte[] Decrypt(byte[] ciphertext);

    /// <summary>
    /// 加密字符串，返回字节数组
    /// </summary>
    /// <param name="plaintext">明文</param>
    /// <returns>密文字节数组</returns>
    byte[] EncryptToBytes(string plaintext);

    /// <summary>
    /// 从字节数组解密字符串
    /// </summary>
    /// <param name="ciphertext">密文字节数组</param>
    /// <returns>明文</returns>
    string DecryptFromBytes(byte[] ciphertext);
}

/// <summary>
/// AES-GCM 文件加密服务
/// 提供认证加密，防止篡改
/// </summary>
public class AesGcmEncryption : IEncryptionService
{
    private readonly byte[] _key;
    private readonly ILogger<AesGcmEncryption> _logger;

    public AesGcmEncryption(string base64Key, ILogger<AesGcmEncryption> logger)
    {
        if (string.IsNullOrWhiteSpace(base64Key))
            throw new ArgumentException("Base64 key cannot be null or whitespace", nameof(base64Key));
        
        _key = Convert.FromBase64String(base64Key);
        _logger = logger;
        
        // ✅ 添加密钥长度验证 - AES-256 需要 32 字节 (256 bits)
        if (_key.Length != 32)
        {
            throw new CryptographicException(
                $"Invalid AES key length: {_key.Length} bytes, expected 32 bytes for AES-256");
        }
        
        // ✅ 检查平台是否支持 AES-GCM
        if (!AesGcm.IsSupported)
        {
            throw new PlatformNotSupportedException(
                "AES-GCM is not supported on this platform. Minimum requirements: .NET Core 3.0 or .NET 5+ on Windows 10/Server 2019, Linux, or macOS 10.15+");
        }
    }

    /// <summary>
    /// 加密字符串
    /// </summary>
    public string Encrypt(string plainText)
    {
        if (string.IsNullOrEmpty(plainText))
            return string.Empty;
        
        var plainBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
        var nonce = new byte[12];
        var tag = new byte[16];
        var ciphertext = new byte[plainBytes.Length];
        
        using (var rng = RandomNumberGenerator.Create())
            rng.GetBytes(nonce);
        
        using var aes = new AesGcm(_key, 16);
        aes.Encrypt(nonce, plainBytes, ciphertext, tag);
        
        // 格式: [nonce][tag][ciphertext]
        var result = new byte[nonce.Length + tag.Length + ciphertext.Length];
        Buffer.BlockCopy(nonce, 0, result, 0, nonce.Length);
        Buffer.BlockCopy(tag, 0, result, nonce.Length, tag.Length);
        Buffer.BlockCopy(ciphertext, 0, result, nonce.Length + tag.Length, ciphertext.Length);
        
        return Convert.ToBase64String(result);
    }

    /// <summary>
    /// 解密字符串
    /// </summary>
    public string Decrypt(string cipherText)
    {
        if (string.IsNullOrEmpty(cipherText))
            return string.Empty;
        
        var combined = Convert.FromBase64String(cipherText);
        
        if (combined.Length < 28) // 12 + 16 = 28
            throw new CryptographicException("Invalid cipher text format");
        
        var nonce = new byte[12];
        var tag = new byte[16];
        var ciphertext = new byte[combined.Length - 28];
        
        Buffer.BlockCopy(combined, 0, nonce, 0, 12);
        Buffer.BlockCopy(combined, 12, tag, 0, 16);
        Buffer.BlockCopy(combined, 28, ciphertext, 0, ciphertext.Length);
        
        var plaintext = new byte[ciphertext.Length];
        
        using var aes = new AesGcm(_key, 16);
        aes.Decrypt(nonce, ciphertext, tag, plaintext);
        
        return System.Text.Encoding.UTF8.GetString(plaintext);
    }

    public void EncryptFile(string inputPath, string outputPath)
    {
        if (!File.Exists(inputPath))
            throw new FileNotFoundException($"Input file not found: {inputPath}");
        
        var plaintext = File.ReadAllBytes(inputPath);
        var nonce = new byte[12];
        var tag = new byte[16];
        var ciphertext = new byte[plaintext.Length];
        
        using (var rng = RandomNumberGenerator.Create())
            rng.GetBytes(nonce);
        
        using var aes = new AesGcm(_key, 16);
        aes.Encrypt(nonce, plaintext, ciphertext, tag);
        
        using var fs = new FileStream(outputPath, FileMode.Create);
        // 写入格式: [nonce长度:4字节][nonce][tag长度:4字节][tag][ciphertext]
        fs.Write(BitConverter.GetBytes(nonce.Length));
        fs.Write(nonce);
        fs.Write(BitConverter.GetBytes(tag.Length));
        fs.Write(tag);
        fs.Write(ciphertext);
        
        _logger.LogInformation("Encrypted file: {InputPath} -> {OutputPath}", inputPath, outputPath);
        
        // 安全删除原文件
        File.Delete(inputPath);
    }

    public void DecryptFile(string inputPath, string outputPath)
    {
        if (!File.Exists(inputPath))
            throw new FileNotFoundException($"Input file not found: {inputPath}");
        
        using var fs = new FileStream(inputPath, FileMode.Open);
        
        // 读取 nonce 长度
        var nonceLenBytes = ReadExactly(fs, 4);
        var nonceLen = BitConverter.ToInt32(nonceLenBytes);
        
        if (nonceLen != 12)
            _logger.LogWarning("Unexpected nonce length: {NonceLen} bytes (standard is 12)", nonceLen);
        
        // 读取 nonce
        var nonce = ReadExactly(fs, nonceLen);
        
        // 读取 tag 长度
        var tagLenBytes = ReadExactly(fs, 4);
        var tagLen = BitConverter.ToInt32(tagLenBytes);
        
        if (tagLen != 16)
            throw new CryptographicException($"Invalid tag length: {tagLen} bytes, expected 16");
        
        // 读取 tag
        var tag = ReadExactly(fs, tagLen);
        
        // 读取剩余密文
        var remainingBytes = fs.Length - fs.Position;
        if (remainingBytes <= 0)
            throw new CryptographicException("No ciphertext data found");
        
        var ciphertext = ReadExactly(fs, (int)remainingBytes);
        
        var plaintext = new byte[ciphertext.Length];
        using var aes = new AesGcm(_key, 16);
        
        try
        {
            aes.Decrypt(nonce, ciphertext, tag, plaintext);
        }
        catch (CryptographicException ex)
        {
            _logger.LogError(ex, "Decryption failed for file: {InputPath}", inputPath);
            throw new CryptographicException("Decryption failed. The file may be corrupted or the key is incorrect.", ex);
        }
        
        File.WriteAllBytes(outputPath, plaintext);
        _logger.LogInformation("Decrypted file: {InputPath} -> {OutputPath}", inputPath, outputPath);
    }

    /// <summary>
    /// 精确读取指定数量的字节
    /// </summary>
    private static byte[] ReadExactly(Stream stream, int count)
    {
        if (count < 0)
            throw new ArgumentOutOfRangeException(nameof(count), "Count cannot be negative");
        
        if (count == 0)
            return Array.Empty<byte>();
        
        var buffer = new byte[count];
        var totalRead = 0;
        
        while (totalRead < count)
        {
            var bytesRead = stream.Read(buffer, totalRead, count - totalRead);
            if (bytesRead == 0)
                throw new EndOfStreamException($"Unexpected end of stream. Expected {count} bytes, read {totalRead} bytes.");
            totalRead += bytesRead;
        }
        
        return buffer;
    }

    /// <summary>
    /// 加密字节数组
    /// </summary>
    public byte[] Encrypt(byte[] plaintext)
    {
        if (plaintext == null || plaintext.Length == 0)
            return Array.Empty<byte>();
        
        var nonce = new byte[12];
        var tag = new byte[16];
        var ciphertext = new byte[plaintext.Length];
        
        using (var rng = RandomNumberGenerator.Create())
            rng.GetBytes(nonce);
        
        using var aes = new AesGcm(_key, 16);
        aes.Encrypt(nonce, plaintext, ciphertext, tag);
        
        // 格式: [nonce][tag][ciphertext]
        var result = new byte[nonce.Length + tag.Length + ciphertext.Length];
        Buffer.BlockCopy(nonce, 0, result, 0, nonce.Length);
        Buffer.BlockCopy(tag, 0, result, nonce.Length, tag.Length);
        Buffer.BlockCopy(ciphertext, 0, result, nonce.Length + tag.Length, ciphertext.Length);
        
        return result;
    }

    /// <summary>
    /// 解密字节数组
    /// </summary>
    public byte[] Decrypt(byte[] ciphertext)
    {
        if (ciphertext == null || ciphertext.Length == 0)
            return Array.Empty<byte>();
        
        if (ciphertext.Length < 28) // 12 + 16 = 28
            throw new CryptographicException("Invalid cipher text format");
        
        var nonce = new byte[12];
        var tag = new byte[16];
        var cipher = new byte[ciphertext.Length - 28];
        
        Buffer.BlockCopy(ciphertext, 0, nonce, 0, 12);
        Buffer.BlockCopy(ciphertext, 12, tag, 0, 16);
        Buffer.BlockCopy(ciphertext, 28, cipher, 0, cipher.Length);
        
        var plaintext = new byte[cipher.Length];
        
        using var aes = new AesGcm(_key, 16);
        aes.Decrypt(nonce, cipher, tag, plaintext);
        
        return plaintext;
    }

    /// <summary>
    /// 加密字符串，返回字节数组
    /// </summary>
    public byte[] EncryptToBytes(string plaintext)
    {
        if (string.IsNullOrEmpty(plaintext))
            return Array.Empty<byte>();
        
        var plainBytes = System.Text.Encoding.UTF8.GetBytes(plaintext);
        return Encrypt(plainBytes);
    }

    /// <summary>
    /// 从字节数组解密字符串
    /// </summary>
    public string DecryptFromBytes(byte[] ciphertext)
    {
        if (ciphertext == null || ciphertext.Length == 0)
            return string.Empty;
        
        var plainBytes = Decrypt(ciphertext);
        return System.Text.Encoding.UTF8.GetString(plainBytes);
    }
}

[SupportedOSPlatform("windows")]
/// <summary>
/// Windows DPAPI 数据保护服务
/// 使用 Windows 内置的 Data Protection API 加密本地存储的敏感数据
/// </summary>
/// <remarks>
/// 特点：
/// - 加密密钥由 Windows 系统管理，无需手动管理密钥
/// - 解密只能在加密的同一台机器、同一用户账户下进行
/// - 适用于本地存储的配置、Token 等敏感数据
/// - 仅在 Windows 平台上可用
/// </remarks>
public class WindowsDataProtection : IEncryptionService, IDisposable
{
    private readonly ILogger<WindowsDataProtection> _logger;
    private readonly DataProtectionScope _scope;
    private readonly byte[]? _optionalEntropy;
    private readonly bool _isWindows;
    private bool _disposed;

    /// <summary>
    /// 默认熵值（用于增加安全性）
    /// 如果更改此值，所有已加密的数据将无法解密
    /// </summary>
    private static readonly byte[] DefaultEntropy = 
        Encoding.UTF8.GetBytes("EnterpriseAgent-DPAPI-Entropy-v2");

    /// <summary>
    /// 初始化 Windows DPAPI 加密服务
    /// </summary>
    /// <param name="logger">日志记录器</param>
    /// <param name="useEntropy">是否使用额外的熵值（默认 true）</param>
    /// <param name="scope">数据保护范围（默认 CurrentUser）</param>
    public WindowsDataProtection(
        ILogger<WindowsDataProtection> logger, 
        bool useEntropy = true,
        DataProtectionScope scope = DataProtectionScope.CurrentUser)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _scope = scope;
        
        // 检查平台兼容性
        _isWindows = RuntimeInformation.IsOSPlatform(OSPlatform.Windows);
        
        if (!_isWindows)
        {
            var error = "WindowsDataProtection is only supported on Windows platforms";
            _logger.LogError(error);
            throw new PlatformNotSupportedException(error);
        }
        
        // 可选熵值（增加安全性）
        if (useEntropy)
        {
            _optionalEntropy = DefaultEntropy;
            _logger.LogDebug("Using custom entropy for DPAPI");
        }
        
        _logger.LogInformation("Windows Data Protection initialized with scope: {Scope}", _scope);
    }

    /// <summary>
    /// 加密敏感数据
    /// </summary>
    /// <param name="plainText">明文</param>
    /// <returns>Base64 编码的密文</returns>
    /// <exception cref="ArgumentException">当 plainText 为 null 或空时抛出</exception>
    /// <exception cref="CryptographicException">加密失败时抛出</exception>
    public string Encrypt(string plainText)
    {
        if (plainText is null)
        {
            throw new ArgumentNullException(nameof(plainText), "Plain text cannot be null");
        }
        
        if (string.IsNullOrWhiteSpace(plainText))
        {
            _logger.LogDebug("Encrypt called with empty string, returning empty");
            return string.Empty;
        }
        
        ThrowIfDisposed();
        
        try
        {
            var plainBytes = Encoding.UTF8.GetBytes(plainText);
            var encryptedBytes = ProtectedData.Protect(plainBytes, _optionalEntropy, _scope);
            var result = Convert.ToBase64String(encryptedBytes);
            
            _logger.LogDebug("Encrypted data successfully (plain length: {Length})", plainText.Length);
            return result;
        }
        catch (CryptographicException ex)
        {
            _logger.LogError(ex, "Cryptographic error during encryption");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during encryption");
            throw new CryptographicException("Encryption failed", ex);
        }
    }

    /// <summary>
    /// 解密敏感数据
    /// </summary>
    /// <param name="cipherText">Base64 编码的密文</param>
    /// <returns>明文</returns>
    /// <exception cref="ArgumentException">当 cipherText 为 null 或格式无效时抛出</exception>
    /// <exception cref="CryptographicException">解密失败时抛出</exception>
    public string Decrypt(string cipherText)
    {
        if (cipherText is null)
        {
            throw new ArgumentNullException(nameof(cipherText), "Cipher text cannot be null");
        }
        
        if (string.IsNullOrWhiteSpace(cipherText))
        {
            _logger.LogDebug("Decrypt called with empty string, returning empty");
            return string.Empty;
        }
        
        ThrowIfDisposed();
        
        // 验证 Base64 格式
        if (!IsValidBase64(cipherText))
        {
            var error = "Invalid Base64 format for cipher text";
            _logger.LogError(error);
            throw new ArgumentException(error, nameof(cipherText));
        }
        
        try
        {
            var encryptedBytes = Convert.FromBase64String(cipherText);
            var plainBytes = ProtectedData.Unprotect(encryptedBytes, _optionalEntropy, _scope);
            var result = Encoding.UTF8.GetString(plainBytes);
            
            // ✅ 安全清理：解密后立即清零缓冲区
            Array.Clear(plainBytes, 0, plainBytes.Length);
            
            _logger.LogDebug("Decrypted data successfully (plain length: {Length})", result.Length);
            return result;
        }
        catch (FormatException ex)
        {
            _logger.LogError(ex, "Invalid Base64 format");
            throw new ArgumentException("Invalid Base64 cipher text format", nameof(cipherText), ex);
        }
        catch (CryptographicException ex)
        {
            var error = "Decryption failed. This may be due to: " +
                        "1) Different Windows user account, " +
                        "2) Different machine, " +
                        "3) Corrupted data, " +
                        "4) Data encrypted with different entropy";
            _logger.LogError(ex, error);
            throw new CryptographicException(error, ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during decryption");
            throw new CryptographicException("Decryption failed", ex);
        }
    }

    #region IEncryptionService 接口实现（新增）

    /// <summary>
    /// 加密字节数组
    /// </summary>
    public byte[] Encrypt(byte[] plaintext)
    {
        if (plaintext == null || plaintext.Length == 0)
            return Array.Empty<byte>();

        ThrowIfDisposed();

        try
        {
            return ProtectedData.Protect(
                plaintext,
                _optionalEntropy,
                _scope);
        }
        catch (CryptographicException ex)
        {
            _logger.LogError(ex, "Cryptographic error during encryption");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during encryption");
            throw new CryptographicException("Encryption failed", ex);
        }
    }

    /// <summary>
    /// 解密字节数组
    /// </summary>
    public byte[] Decrypt(byte[] ciphertext)
    {
        if (ciphertext == null || ciphertext.Length == 0)
            return Array.Empty<byte>();

        ThrowIfDisposed();

        try
        {
            return ProtectedData.Unprotect(
                ciphertext,
                _optionalEntropy,
                _scope);
        }
        catch (CryptographicException ex)
        {
            _logger.LogError(ex, "Cryptographic error during decryption");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during decryption");
            throw new CryptographicException("Decryption failed", ex);
        }
    }

    /// <summary>
    /// 加密字符串并返回字节数组
    /// </summary>
    public byte[] EncryptToBytes(string plaintext)
    {
        if (string.IsNullOrEmpty(plaintext))
            return Array.Empty<byte>();

        var plainBytes = Encoding.UTF8.GetBytes(plaintext);
        return Encrypt(plainBytes);
    }

    /// <summary>
    /// 从字节数组解密为字符串
    /// </summary>
    public string DecryptFromBytes(byte[] ciphertext)
    {
        if (ciphertext == null || ciphertext.Length == 0)
            return string.Empty;

        var plainBytes = Decrypt(ciphertext);
        return Encoding.UTF8.GetString(plainBytes);
    }

    #endregion

    /// <summary>
    /// 验证是否为有效的 Base64 字符串
    /// </summary>
    private static bool IsValidBase64(string base64String)
    {
        if (string.IsNullOrEmpty(base64String))
            return false;
        
        // 快速检查：Base64 字符串长度应为 4 的倍数
        if (base64String.Length % 4 != 0)
            return false;
        
        // 检查字符是否在 Base64 字符集内
        foreach (char c in base64String)
        {
            if (!IsBase64Char(c))
                return false;
        }
        
        return true;
    }

    /// <summary>
    /// 判断字符是否为 Base64 有效字符
    /// </summary>
    private static bool IsBase64Char(char c)
    {
        return (c >= 'A' && c <= 'Z') ||
               (c >= 'a' && c <= 'z') ||
               (c >= '0' && c <= '9') ||
               c == '+' || c == '/' || c == '=';
    }

    /// <summary>
    /// 检查服务是否已释放
    /// </summary>
    private void ThrowIfDisposed()
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(WindowsDataProtection));
        }
    }

    /// <summary>
    /// 获取平台兼容性信息（用于诊断）
    /// </summary>
    public (bool isWindows, bool isSupported) GetPlatformInfo()
    {
        return (_isWindows, _isWindows);
    }

    /// <summary>
    /// 验证当前环境是否可以正常加密/解密
    /// </summary>
    public async Task<bool> TestEncryptionAsync()
    {
        if (_disposed)
            return false;
        
        try
        {
            var testData = "Test data for DPAPI validation";
            var encrypted = Encrypt(testData);
            var decrypted = Decrypt(encrypted);
            
            return testData == decrypted;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Encryption test failed");
            return false;
        }
    }

    /// <summary>
    /// 加密文件
    /// </summary>
    public void EncryptFile(string inputPath, string outputPath)
    {
        if (inputPath is null) throw new ArgumentNullException(nameof(inputPath));
        if (outputPath is null) throw new ArgumentNullException(nameof(outputPath));
        ThrowIfDisposed();

        if (!File.Exists(inputPath))
        {
            throw new FileNotFoundException("Input file not found", inputPath);
        }

        var fileBytes = File.ReadAllBytes(inputPath);
        var encryptedBytes = ProtectedData.Protect(fileBytes, _optionalEntropy, _scope);
        File.WriteAllBytes(outputPath, encryptedBytes);
        
        // ✅ 安全清理：加密后删除原文件
        File.Delete(inputPath);
        
        _logger.LogDebug("Encrypted file {InputPath} to {OutputPath}", inputPath, outputPath);
    }

    /// <summary>
    /// 解密文件
    /// </summary>
    public void DecryptFile(string inputPath, string outputPath)
    {
        if (inputPath is null) throw new ArgumentNullException(nameof(inputPath));
        if (outputPath is null) throw new ArgumentNullException(nameof(outputPath));
        ThrowIfDisposed();

        if (!File.Exists(inputPath))
        {
            throw new FileNotFoundException("Input file not found", inputPath);
        }

        var fileBytes = File.ReadAllBytes(inputPath);
        var plainBytes = ProtectedData.Unprotect(fileBytes, _optionalEntropy, _scope);
        File.WriteAllBytes(outputPath, plainBytes);
        
        _logger.LogDebug("Decrypted file {InputPath} to {OutputPath}", inputPath, outputPath);
    }

    public void Dispose()
    {
        _disposed = true;
    }
}

/// <summary>
/// 敏感数据过滤接口
/// </summary>
public interface ISensitiveDataFilter
{
    string Filter(string input);
    string SafeObjectString(object? obj);
}

/// <summary>
/// 敏感数据过滤器 - 防止在日志中泄露 token、密钥等
/// </summary>
public class SensitiveDataFilter : ISensitiveDataFilter
{
    private readonly ILogger<SensitiveDataFilter> _logger;

    // ✅ 移除静态实例，改为线程安全的静态方法
    private static readonly object _staticLock = new();
    private static readonly Regex TokenRegex = new(
        @"(?<=token=|Bearer\s+|Authorization:\s*)[A-Za-z0-9_\-\.]+",
        RegexOptions.Compiled | RegexOptions.IgnoreCase);

    private static readonly Regex DeviceIdRegex = new(
        @"(?<=deviceId=|device_id=|""deviceId"":\s*"")[A-Za-z0-9_\-]+",
        RegexOptions.Compiled | RegexOptions.IgnoreCase);

    private static readonly Regex KeyRegex = new(
        @"(?<=key=|secret=|password=)[A-Za-z0-9+/=]+",
        RegexOptions.Compiled | RegexOptions.IgnoreCase);

    private static readonly Regex JsonTokenRegex = new(
        @"""token""\s*:\s*""[^""]+""",
        RegexOptions.Compiled | RegexOptions.IgnoreCase);

    private static readonly Regex JsonPasswordRegex = new(
        @"""password""\s*:\s*""[^""]+""",
        RegexOptions.Compiled | RegexOptions.IgnoreCase);

    private static readonly Regex JsonSecretRegex = new(
        @"""(secretKey|encryptionKey|refreshToken)""\s*:\s*""[^""]+""",
        RegexOptions.Compiled | RegexOptions.IgnoreCase);

    private static readonly Regex IpAddressRegex = new(
        @"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b",
        RegexOptions.Compiled);

    private static readonly Regex EmailRegex = new(
        @"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
        RegexOptions.Compiled);

    public SensitiveDataFilter(ILogger<SensitiveDataFilter> logger)
    {
        _logger = logger;
    }

    public string Filter(string input)
    {
        return FilterInternal(input);
    }

    /// <summary>
    /// 静态过滤方法 - 线程安全
    /// </summary>
    public static string FilterStatic(string input)
    {
        return FilterInternalStatic(input);
    }

    private string FilterInternal(string input)
    {
        return FilterInternalStatic(input);
    }

    private static string FilterInternalStatic(string input)
    {
        if (string.IsNullOrEmpty(input))
            return input;

        var result = input;
        
        result = TokenRegex.Replace(result, "[REDACTED_TOKEN]");
        result = DeviceIdRegex.Replace(result, "[REDACTED_DEVICE_ID]");
        result = KeyRegex.Replace(result, "[REDACTED_KEY]");
        result = JsonTokenRegex.Replace(result, "\"token\": \"[REDACTED]\"");
        result = JsonPasswordRegex.Replace(result, "\"password\": \"[REDACTED]\"");
        result = JsonSecretRegex.Replace(result, "\"$1\": \"[REDACTED]\"");
        
        result = IpAddressRegex.Replace(result, m => 
        {
            var parts = m.Value.Split('.');
            return parts.Length == 4 ? $"{parts[0]}.{parts[1]}.{parts[2]}.xxx" : m.Value;
        });
        
        result = EmailRegex.Replace(result, m =>
        {
            var atIndex = m.Value.IndexOf('@');
            if (atIndex > 0 && atIndex <= 3)
                return "***" + m.Value.Substring(atIndex);
            if (atIndex > 3)
                return m.Value.Substring(0, 3) + "***" + m.Value.Substring(atIndex);
            return "[REDACTED_EMAIL]";
        });
        
        return result;
    }

    public string SafeObjectString(object? obj)
    {
        if (obj == null) return "null";
        
        var typeName = obj.GetType().Name;
        
        if (obj is string str)
            return FilterInternal(str);
        
        return $"{typeName} [REDACTED]";
    }
    
    public static string SafeFilePath(string? filePath)
    {
        if (string.IsNullOrEmpty(filePath))
            return "[empty]";
        
        try
        {
            return Path.GetFileName(filePath);
        }
        catch
        {
            return "[invalid_path]";
        }
    }
    
    public static string SafeDeviceId(string? deviceId)
    {
        if (string.IsNullOrEmpty(deviceId))
            return "[empty]";
        
        if (deviceId.Length <= 12)
            return "***";
        
        return $"{deviceId[..4]}...{deviceId[^4..]}";
    }
}

/// <summary>
/// 自定义日志过滤器
/// </summary>
public class SensitiveDataLogFilter : ILogger
{
    private readonly ILogger _inner;

    public SensitiveDataLogFilter(ILogger inner)
    {
        _inner = inner;
    }

    public IDisposable? BeginScope<TState>(TState state) where TState : notnull
        => _inner.BeginScope(state);

    public bool IsEnabled(LogLevel logLevel)
        => _inner.IsEnabled(logLevel);

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
    {
        string? originalMessage = null;
        try
        {
            originalMessage = formatter(state, exception);
        }
        catch { }

        if (!string.IsNullOrEmpty(originalMessage))
        {
            var filteredMessage = SensitiveDataFilter.FilterStatic(originalMessage);
            _inner.Log(logLevel, eventId, filteredMessage, exception, (s, ex) => s);
        }
        else
        {
            _inner.Log(logLevel, eventId, state, exception, formatter);
        }
    }
}

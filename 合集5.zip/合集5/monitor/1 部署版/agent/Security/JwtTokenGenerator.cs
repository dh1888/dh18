// Security/JwtTokenGenerator.cs
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;

namespace EnterpriseAgent.Agent.Security;

/// <summary>
/// JWT Token 生成器
/// </summary>
public class JwtTokenGenerator
{
    private readonly string _secretKey;
    private readonly ILogger<JwtTokenGenerator> _logger;

    public JwtTokenGenerator(string secretKey, ILogger<JwtTokenGenerator> logger)
    {
        _secretKey = secretKey ?? throw new ArgumentNullException(nameof(secretKey));
        _logger = logger;
    }

    /// <summary>
    /// 生成 JWT Token
    /// </summary>
    /// <param name="deviceId">设备ID</param>
    /// <param name="expiresHours">过期时间（小时）</param>
    /// <returns>JWT Token 字符串</returns>
    public string GenerateToken(string deviceId, int expiresHours = 24)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_secretKey));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, deviceId),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim("deviceId", deviceId),
            new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64)
        };

        var token = new JwtSecurityToken(
            issuer: "EnterpriseAgent",
            audience: "EnterpriseServer",
            claims: claims,
            expires: DateTime.UtcNow.AddHours(expiresHours),
            notBefore: DateTime.UtcNow,
            signingCredentials: credentials
        );

        var tokenString = new JwtSecurityTokenHandler().WriteToken(token);
        _logger.LogDebug("Generated JWT token for device: {DeviceId}, expires in {Hours}h", 
            SensitiveDataFilter.SafeDeviceId(deviceId), expiresHours);
        
        return tokenString;
    }

    /// <summary>
    /// 验证 JWT Token
    /// </summary>
    /// <param name="token">JWT Token</param>
    /// <returns>是否有效</returns>
    public bool ValidateToken(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return false;

        try
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_secretKey);
            
            tokenHandler.ValidateToken(token, new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = "EnterpriseAgent",
                ValidateAudience = true,
                ValidAudience = "EnterpriseServer",
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromMinutes(5)
            }, out var validatedToken);
            
            return validatedToken != null;
        }
        catch (SecurityTokenExpiredException)
        {
            _logger.LogDebug("Token has expired");
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Token validation failed");
            return false;
        }
    }

    /// <summary>
    /// 从 Token 中提取设备 ID
    /// </summary>
    /// <param name="token">JWT Token</param>
    /// <returns>设备 ID，验证失败返回 null</returns>
    public string? ExtractDeviceId(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return null;

        try
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var jwtToken = tokenHandler.ReadJwtToken(token);
            
            var deviceIdClaim = jwtToken.Claims.FirstOrDefault(c => c.Type == "deviceId");
            if (deviceIdClaim != null)
                return deviceIdClaim.Value;
            
            var subClaim = jwtToken.Claims.FirstOrDefault(c => c.Type == JwtRegisteredClaimNames.Sub);
            return subClaim?.Value;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to extract device ID from token");
            return null;
        }
    }

    /// <summary>
    /// 刷新 Token（生成新 Token）
    /// </summary>
    /// <param name="oldToken">旧的 Token</param>
    /// <param name="expiresHours">新 Token 过期时间</param>
    /// <returns>新 Token，验证失败返回 null</returns>
    public string? RefreshToken(string oldToken, int expiresHours = 24)
    {
        var deviceId = ExtractDeviceId(oldToken);
        if (string.IsNullOrEmpty(deviceId))
            return null;
        
        return GenerateToken(deviceId, expiresHours);
    }
}

/// <summary>
/// 从 JWT 载荷解析过期时间（不验证签名，仅读取 exp）。
/// </summary>
public static class JwtTokenExpiryParser
{
    public static DateTime? TryGetExpiryUtc(string? token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return null;

        try
        {
            var parts = token.Split('.');
            if (parts.Length < 2)
                return null;

            var payload = parts[1];
            var padding = payload.Length % 4;
            if (padding > 0)
                payload += new string('=', 4 - padding);

            var jsonBytes = Convert.FromBase64String(payload.Replace('-', '+').Replace('_', '/'));
            var json = Encoding.UTF8.GetString(jsonBytes);

            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("exp", out var exp) && exp.TryGetInt64(out var unix))
                return DateTimeOffset.FromUnixTimeSeconds(unix).UtcDateTime;
        }
        catch
        {
            // 解析失败时由调用方回退默认 TTL
        }

        return null;
    }
}

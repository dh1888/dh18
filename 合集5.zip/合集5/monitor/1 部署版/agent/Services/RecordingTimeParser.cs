using System.Globalization;
using EnterpriseAgent.Agent.Models;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 从录屏文件路径解析 UTC 起止时间（新/旧文件名格式统一入口）
/// </summary>
internal static class RecordingTimeParser
{
    public static bool TryParse(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        if (string.IsNullOrWhiteSpace(filePath))
            return false;

        sliceSeconds = Math.Max(sliceSeconds, Constants.MinSliceSeconds);

        if (TryParseNewFormat(filePath, sliceSeconds, out startUtc, out endUtc) ||
            TryParseLegacyFormat(filePath, sliceSeconds, out startUtc, out endUtc) ||
            TryParseFromFileTime(filePath, sliceSeconds, out startUtc, out endUtc))
        {
            endUtc = RefineEndTime(filePath, startUtc, endUtc, sliceSeconds);
            return true;
        }

        return false;
    }

    private static bool TryParseNewFormat(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        try
        {
            var fileName = Path.GetFileNameWithoutExtension(filePath);
            var parts = fileName.Split('_');
            if (parts.Length != 3 || parts[0].Length != 10 || !parts[0].Contains('-'))
                return false;

            if (!DateTime.TryParseExact(parts[0], "yyyy-MM-dd",
                    CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var date))
                return false;

            var timeParts = parts[1].Split('-');
            if (timeParts.Length != 3)
                return false;

            if (!int.TryParse(timeParts[0], out var hour) ||
                !int.TryParse(timeParts[1], out var minute) ||
                !int.TryParse(timeParts[2], out var second) ||
                !int.TryParse(parts[2], out var segmentIndex))
                return false;

            startUtc = new DateTime(date.Year, date.Month, date.Day, hour, minute, second, DateTimeKind.Utc)
                .AddSeconds(segmentIndex * sliceSeconds);
            endUtc = startUtc.AddSeconds(sliceSeconds);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static bool TryParseLegacyFormat(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        try
        {
            var fileName = Path.GetFileNameWithoutExtension(filePath);
            var underscoreIndex = fileName.IndexOf('_');
            var segmentIndex = 0;
            if (underscoreIndex >= 0 && underscoreIndex + 1 < fileName.Length)
                int.TryParse(fileName.Substring(underscoreIndex + 1), out segmentIndex);

            var timePart = underscoreIndex >= 0 ? fileName.Substring(0, underscoreIndex) : fileName;
            var parts = timePart.Split('-');
            if (parts.Length < 3)
                return false;

            if (!int.TryParse(parts[0], out var hour) ||
                !int.TryParse(parts[1], out var minute) ||
                !int.TryParse(parts[2], out var second))
                return false;

            var dateStr = Path.GetFileName(Path.GetDirectoryName(filePath));
            if (!DateTime.TryParseExact(dateStr, "yyyy-MM-dd",
                    CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var date))
                return false;

            var localTime = new DateTime(date.Year, date.Month, date.Day, hour, minute, second, DateTimeKind.Unspecified);
            var cstZone = TimeZoneInfo.FindSystemTimeZoneById("China Standard Time");
            var baseStartTime = TimeZoneInfo.ConvertTimeToUtc(localTime, cstZone);

            startUtc = baseStartTime.AddSeconds(segmentIndex * sliceSeconds);
            endUtc = startUtc.AddSeconds(sliceSeconds);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static bool TryParseFromFileTime(string filePath, int sliceSeconds, out DateTime startUtc, out DateTime endUtc)
    {
        startUtc = default;
        endUtc = default;

        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return false;

            startUtc = fileInfo.LastWriteTimeUtc;
            endUtc = startUtc.AddSeconds(sliceSeconds);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static DateTime RefineEndTime(string filePath, DateTime startUtc, DateTime estimatedEndUtc, int sliceSeconds)
    {
        try
        {
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
                return estimatedEndUtc;

            var writeUtc = fileInfo.LastWriteTimeUtc;
            var maxEnd = startUtc.AddSeconds(sliceSeconds * 2);
            if (writeUtc > startUtc && writeUtc <= maxEnd)
                return writeUtc;
        }
        catch
        {
            // keep estimated end
        }

        return estimatedEndUtc;
    }
}

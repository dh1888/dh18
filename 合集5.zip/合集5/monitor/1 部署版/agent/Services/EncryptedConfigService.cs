// Services/EncryptedConfigService.cs - 完整修复版

using Microsoft.Extensions.Logging;
using System.Text.Json;
using EnterpriseAgent.Agent.Security;
using EnterpriseAgent.Agent.Models;
using System.Security.Cryptography;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 加密配置服务 - 管理加密的配置文件
/// </summary>
public class EncryptedConfigService
{
    private readonly ILogger<EncryptedConfigService> _logger;
    private readonly WindowsDataProtection _dataProtection;
    private readonly string _configPath;
    private readonly SemaphoreSlim _saveLock = new(1, 1);

    public EncryptedConfigService(
        ILogger<EncryptedConfigService> logger,
        WindowsDataProtection dataProtection,
        string configPath)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _dataProtection = dataProtection ?? throw new ArgumentNullException(nameof(dataProtection));
        _configPath = configPath ?? throw new ArgumentNullException(nameof(configPath));
        
        // 修复：检查 Path.GetDirectoryName 可能返回 null 的情况
        var directory = Path.GetDirectoryName(_configPath);
        if (!string.IsNullOrEmpty(directory))
        {
            if (!Directory.Exists(directory))
            {
                try
                {
                    Directory.CreateDirectory(directory);
                    _logger.LogDebug("Created configuration directory: {Directory}", directory);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Failed to create configuration directory: {Directory}", directory);
                }
            }
        }
        else
        {
            // 如果无法获取目录名，记录警告
            _logger.LogWarning("Could not determine directory from config path: {ConfigPath}", _configPath);
        }
    }
    /// <summary>
    /// 从加密文件加载配置（泛型方法）
    /// </summary>
    /// <typeparam name="T">配置类型</typeparam>
    /// <param name="filename">文件名</param>
    /// <returns>配置对象</returns>
    /// <summary>
    /// 从加密文件加载配置（泛型方法）
    /// </summary>
    public async Task<T?> LoadConfigAsync<T>(string filename) where T : class
    {
        try
        {
            var filePath = Path.Combine(_configPath, filename);
            if (!File.Exists(filePath))
            {
                _logger.LogWarning("Config file not found: {FilePath}", filePath);
                return null;
            }

            var fileContent = await File.ReadAllBytesAsync(filePath);
            string json;
            
            // 尝试作为加密文件读取
            try
            {
                var decryptedContent = _dataProtection.Decrypt(fileContent);
                json = System.Text.Encoding.UTF8.GetString(decryptedContent);
                _logger.LogDebug("Config loaded as encrypted file: {Filename}", filename);
            }
            catch (CryptographicException)
            {
                var allowPlaintext = string.Equals(
                    Environment.GetEnvironmentVariable("AGENT_ALLOW_PLAINTEXT_CONFIG"),
                    "1",
                    StringComparison.Ordinal);

                if (!allowPlaintext)
                {
                    throw new InvalidOperationException(
                        $"Config file '{filename}' is not encrypted. Set AGENT_ALLOW_PLAINTEXT_CONFIG=1 to migrate once, then re-save.");
                }

                _logger.LogWarning(
                    "Reading plaintext config for one-time migration: {Filename}. Re-save to encrypt.",
                    filename);
                json = System.Text.Encoding.UTF8.GetString(fileContent);
            }
            
            // 检查 JSON 是否为空
            if (string.IsNullOrWhiteSpace(json))
            {
                _logger.LogWarning("Config file is empty: {Filename}", filename);
                return null;
            }
            
            // 反序列化并处理可能的 null 结果
            var result = JsonSerializer.Deserialize<T>(json);
            
            if (result == null)
            {
                _logger.LogWarning("Failed to deserialize config from {Filename}, JSON: {Json}", filename, json);
                return null;
            }
            
            _logger.LogDebug("Config loaded successfully from {Filename}", filename);
            return result;
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "JSON deserialization error while loading config from {Filename}", filename);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to load config from {Filename}", filename);
            return null;
        }
    }

    /// <summary>
    /// 保存配置到加密文件（泛型方法）
    /// </summary>
    /// <typeparam name="T">配置类型</typeparam>
    /// <param name="filename">文件名</param>
    /// <param name="config">配置对象</param>
    public async Task SaveConfigAsync<T>(string filename, T config) where T : class
    {
        if (config == null)
            throw new ArgumentNullException(nameof(config));

        await _saveLock.WaitAsync();
        try
        {
            await SaveConfigCoreAsync(filename, config);
        }
        finally
        {
            _saveLock.Release();
        }
    }

    private async Task SaveConfigCoreAsync<T>(string filename, T config) where T : class
    {
        try
        {
            var json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
            var plaintext = System.Text.Encoding.UTF8.GetBytes(json);
            var encrypted = _dataProtection.Encrypt(plaintext);

            var filePath = Path.Combine(_configPath, filename);
            var directory = Path.GetDirectoryName(filePath);
            
            // 确保目录存在
            if (!string.IsNullOrEmpty(directory))
            {
                if (!Directory.Exists(directory))
                {
                    try
                    {
                        Directory.CreateDirectory(directory);
                        _logger.LogDebug("Created directory: {Directory}", directory);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to create directory: {Directory}", directory);
                        throw new InvalidOperationException($"Cannot create directory: {directory}", ex);
                    }
                }
                
                // 验证目录是否可写
                var testFile = Path.Combine(directory, ".write_test_" + Guid.NewGuid().ToString("N"));
                try
                {
                    await File.WriteAllTextAsync(testFile, "test");
                    File.Delete(testFile);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Directory is not writable: {Directory}", directory);
                    throw new InvalidOperationException($"Directory is not writable: {directory}", ex);
                }
            }

            var tempFilePath = filePath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                await File.WriteAllBytesAsync(tempFilePath, encrypted);

                if (File.Exists(filePath))
                {
                    var backupPath = filePath + ".bak";
                    try
                    {
                        if (File.Exists(backupPath))
                            File.Delete(backupPath);
                        File.Move(filePath, backupPath);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to create backup, continuing without backup");
                    }
                }

                File.Move(tempFilePath, filePath, true);
            }
            finally
            {
                if (File.Exists(tempFilePath))
                {
                    try { File.Delete(tempFilePath); } catch { /* best effort */ }
                }
            }
            
            _logger.LogInformation("Config saved to {Filename} at {Path}", filename, filePath);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to save config to {Filename}", filename);
            throw;
        }
    }

    /// <summary>
    /// 检查配置文件是否存在
    /// </summary>
    /// <param name="filename">文件名</param>
    /// <returns>是否存在</returns>
    public bool ConfigExists(string filename)
    {
        var filePath = Path.Combine(_configPath, filename);
        return File.Exists(filePath);
    }

    /// <summary>
    /// 删除配置文件
    /// </summary>
    /// <param name="filename">文件名</param>
    public void DeleteConfig(string filename)
    {
        try
        {
            var filePath = Path.Combine(_configPath, filename);
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
                _logger.LogInformation("Config deleted: {Filename}", filename);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to delete config {Filename}", filename);
            throw;
        }
    }
    
    /// <summary>
    /// 获取配置目录路径
    /// </summary>
    public string GetConfigPath()
    {
        return _configPath;
    }

    // ========== 便捷方法：专门用于 AgentConfig ==========

    /// <summary>
    /// 保存 AgentConfig 配置（便捷方法）
    /// </summary>
    /// <param name="config">Agent 配置对象</param>
    public async Task SaveAsync(AgentConfig config)
    {
        await SaveConfigAsync("config.json", config);
    }

    /// <summary>
    /// 加载 AgentConfig 配置（便捷方法）
    /// </summary>
    /// <returns>Agent 配置对象，如果不存在则返回 null</returns>
    public async Task<AgentConfig?> LoadAsync()
    {
        return await LoadConfigAsync<AgentConfig>("config.json");
    }
}

public static class DeploymentConfigLoader
{
    public const string FileName = "deployment.json";

    public static string GetExpectedPath()
        => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, FileName);

    public static DeploymentBundle? TryLoad(ILogger? logger = null)
    {
        var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, FileName);
        if (!File.Exists(path))
            return null;

        try
        {
            var json = File.ReadAllText(path);
            var bundle = JsonSerializer.Deserialize<DeploymentBundle>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

            if (bundle == null)
            {
                logger?.LogWarning("deployment.json is empty or invalid");
                return null;
            }

            logger?.LogInformation("Loaded deployment bundle from {Path}", path);
            return bundle;
        }
        catch (Exception ex)
        {
            logger?.LogError(ex, "Failed to load deployment.json from {Path}", path);
            return null;
        }
    }

    public static string? TryGetLockedServerUrl(DeploymentBundle? bundle)
    {
        if (bundle == null)
            return null;

        var url = bundle.ResolveServerUrl();
        return IsPlaceholder(url) ? null : url;
    }

    public static bool HasLockedServerUrl(DeploymentBundle? bundle)
        => !string.IsNullOrWhiteSpace(TryGetLockedServerUrl(bundle));

    public static (bool IsValid, List<string> Errors) Validate(DeploymentBundle? bundle)
    {
        var errors = new List<string>();
        if (bundle == null)
        {
            errors.Add($"未找到 {FileName}，请复制 deployment.json.example 为 deployment.json 并填写密钥");
            return (false, errors);
        }

        if (IsPlaceholder(bundle.JwtSecret))
            errors.Add("jwtSecret 未填写（请与 backend/.env 中 JWT_SECRET 一致）");

        if (IsPlaceholder(bundle.PolicySignatureSecret))
            errors.Add("policySignatureSecret 未填写（请与 backend/.env 中 POLICY_SIGNATURE_SECRET 一致）");

        var serverUrl = bundle.ResolveServerUrl();
        if (!IsPlaceholder(serverUrl))
        {
            if (!Uri.TryCreate(serverUrl.Trim(), UriKind.Absolute, out var uri))
                errors.Add($"serverUrl 不是合法 URL：{serverUrl}");
            else if (uri.Scheme is not ("http" or "https"))
                errors.Add("serverUrl 必须以 http:// 或 https:// 开头");
            else if (serverUrl.Contains("http://http", StringComparison.OrdinalIgnoreCase)
                     || serverUrl.Contains("https://https", StringComparison.OrdinalIgnoreCase))
                errors.Add("serverUrl 重复写了协议头（如 http://http://），请只保留一个");
            else if (uri.AbsolutePath is not "/" and not "")
                errors.Add("serverUrl 不要包含路径（不要写 /api/v1），只需写 http://IP:端口 或 https://域名");
        }

        return (errors.Count == 0, errors);
    }

    private static bool IsPlaceholder(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return true;

        var v = value.Trim();
        return v.Contains("请填写", StringComparison.Ordinal)
               || v.Contains("相同", StringComparison.Ordinal)
               || v.StartsWith("与 backend", StringComparison.OrdinalIgnoreCase)
               || v.StartsWith("your-", StringComparison.OrdinalIgnoreCase);
    }

    public static void ApplyTo(AgentConfig config, DeploymentBundle? bundle)
    {
        if (bundle == null)
            return;

        config.Auth ??= new AuthConfig();

        if (string.IsNullOrWhiteSpace(config.Auth.SecretKey) &&
            !string.IsNullOrWhiteSpace(bundle.JwtSecret))
        {
            config.Auth.SecretKey = bundle.JwtSecret.Trim();
        }

        if (string.IsNullOrWhiteSpace(config.Auth.PolicySignatureSecret) &&
            !string.IsNullOrWhiteSpace(bundle.PolicySignatureSecret))
        {
            config.Auth.PolicySignatureSecret = bundle.PolicySignatureSecret.Trim();
        }

        if (bundle.AllowInsecureTransport)
            config.AllowInsecureTransport = true;

        var lockedServerUrl = TryGetLockedServerUrl(bundle);
        if (!string.IsNullOrWhiteSpace(lockedServerUrl))
        {
            config.ServerUrl = lockedServerUrl;
            config.SyncWsUrlWithServer();
        }
    }
}
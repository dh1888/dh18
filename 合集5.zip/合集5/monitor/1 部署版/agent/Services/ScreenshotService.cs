// Services/ScreenshotService.cs - 企业级最终版（含数据库重试 + 补偿防重复 + 生命周期管理）

using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Threading.Channels;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Formats.Webp;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Formats.Png;
using SixLabors.ImageSharp.Processing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.Storage;
using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;
using ImageSharpRectangle = SixLabors.ImageSharp.Rectangle;

namespace EnterpriseAgent.Agent.Services;

/// <summary>
/// 截图服务 - 企业级最终版
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class ScreenshotService : BackgroundService
{
    private readonly ILogger<ScreenshotService> _logger;
    private readonly ILogger<ScreenCapture> _screenCaptureLogger;
    private readonly AgentConfig _config;
    private readonly IServiceScopeFactory _scopeFactory;
    
    private AgentPolicy? _currentPolicy;
    private readonly SemaphoreSlim _captureLock = new(1, 1);
    private bool _isStopping;
    
    // ✅ 使用 long 类型以便 Interlocked.Read 支持
    private long _captureCount;
    private long _consecutiveFailures;
    
    // 对象池
    private ScreenCapture? _screenCapture;
    private readonly object _captureLockObj = new();
    
    // 编码器
    private readonly PngEncoder _pngEncoder;
    
    // 性能统计
    private readonly MovingAverage _captureTimeMs = new(30);
    private readonly MovingAverage _encodeTimeMs = new(30);
    private readonly MovingAverage _saveTimeMs = new(30);
    private readonly Stopwatch _performanceStopwatch = new();
    
    // 配置缓存
    private ScreenshotConfig _cachedConfig;
    private DateTime _lastConfigUpdate;
    
    // ✅ 统计计数器（全部使用 long）
    private long _saveSuccess = 0;
    private long _saveFailed = 0;
    private long _uploadQueued = 0;
    private long _uploadFailed = 0;
    private long _fileMissingOnQueue = 0;
    private readonly TimeSpan _statsLogInterval = TimeSpan.FromMinutes(5);
    
    // GDI 相关
    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out POINT lpPoint);
    
    [StructLayout(LayoutKind.Sequential)]
    private struct POINT { public int X; public int Y; }
    
    [DllImport("user32.dll")]
    private static extern IntPtr GetCursor();
    
    [DllImport("user32.dll")]
    private static extern bool DestroyIcon(IntPtr hIcon);
    
    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(int nIndex);
    private const int SM_CXSCREEN = 0;
    private const int SM_CYSCREEN = 1;
    
    private string DeviceId => _config.DeviceId;

    private int _lastLoggedInterval = -1;
    
    // ✅ 保存队列 - 使用 Wait 模式，绝不丢数据
    private readonly Channel<SaveTask> _saveChannel;
    private readonly Task _saveWorker;
    private readonly CancellationTokenSource _cts;

    // ✅ 后台任务
    private Task? _statsTask;
    private Task? _compensationTask;
    
    // ✅ 补偿扫描防重复
    private bool _compensationCompleted;
    private readonly HashSet<string> _compensationProcessedIds = new();
    private readonly object _compensationLockObj = new();

    // 保存任务结构
    private readonly struct SaveTask
    {
        public byte[] Data { get; }
        public string FilePath { get; }
        public string Format { get; }
        public DateTime CaptureTime { get; }
        
        public SaveTask(byte[] data, string filePath, string format, DateTime captureTime)
        {
            Data = data;
            FilePath = filePath;
            Format = format;
            CaptureTime = captureTime;
        }
    }

    public ScreenshotService(
        ILogger<ScreenshotService> logger,
        ILogger<ScreenCapture> screenCaptureLogger,
        IServiceScopeFactory scopeFactory,
        AgentConfig config)
    {
        _logger = logger;
        _screenCaptureLogger = screenCaptureLogger;
        _scopeFactory = scopeFactory;
        _config = config;
        _cts = new CancellationTokenSource();
        _cachedConfig = new ScreenshotConfig();
        
        // PNG 编码器
        _pngEncoder = new PngEncoder
        {
            CompressionLevel = PngCompressionLevel.Level1,
            BitDepth = PngBitDepth.Bit8,
            TransparentColorMode = PngTransparentColorMode.Clear
        };
        
        // ✅ 关键修复：使用 Wait 模式，绝不丢弃数据
        _saveChannel = Channel.CreateBounded<SaveTask>(new BoundedChannelOptions(50)
        {
            FullMode = BoundedChannelFullMode.Wait,  // ← 阻塞等待，不丢数据
            SingleReader = true,
            SingleWriter = false
        });
        
        _saveWorker = Task.Run(SaveWorkerAsync);
        
        // ✅ 注意：后台任务在 ExecuteAsync 中启动，不在构造函数中启动
    }
    
    public void UpdatePolicy(AgentPolicy policy)
    {
        _currentPolicy = policy;
        var config = policy.GetScreenshotConfig();
        
        _cachedConfig = config;
        _lastConfigUpdate = DateTime.UtcNow;
        
        var quality = Math.Clamp(config.Quality, 10, 100);
        
        _logger.LogInformation("截图策略已更新: Enabled={Enabled}, Interval={Interval}s, Quality={Quality}, Format={Format}",
            config.Enabled, config.IntervalSeconds, quality, config.Format);
    }
    
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("截图服务已启动 (ImageSharp 纯托管实现)");
        _logger.LogInformation("队列模式: Wait (不丢数据), 队列大小: 50");
        
        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken, _cts.Token);
        var ct = linkedCts.Token;
        
        lock (_captureLockObj)
        {
            _screenCapture?.Dispose();
            _screenCapture = new ScreenCapture(_screenCaptureLogger);
        }
        
        // ✅ 启动后台任务（纳入生命周期管理）
        _statsTask = Task.Run(() => StatsLoggerAsync(ct), ct);
        _compensationTask = Task.Run(() => CompensationScanAsync(ct), ct);
        
        while (!ct.IsCancellationRequested && !_isStopping)
        {
            try
            {
                var config = GetCurrentConfig();
                if (config.Enabled)
                {
                    await CaptureScreenshotAsync(ct);
                    
                    var interval = config.IntervalSeconds;
                    await Task.Delay(TimeSpan.FromSeconds(interval), ct);
                }
                else
                {
                    await Task.Delay(5000, ct);
                }
                
                // ✅ 使用 long 类型的 Interlocked 操作
                if (Interlocked.Read(ref _consecutiveFailures) > 0)
                    Interlocked.Decrement(ref _consecutiveFailures);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("截图服务被取消");
                break;
            }
            catch (Exception ex)
            {
                // ✅ 使用 long 类型的 Interlocked 操作
                var failures = Interlocked.Increment(ref _consecutiveFailures);
                _logger.LogError(ex, "截图捕获失败 (连续失败: {Failures})", failures);
                
                var backoffSeconds = Math.Min(Math.Pow(2, failures), 60);
                try
                {
                    await Task.Delay(TimeSpan.FromSeconds(backoffSeconds), ct);
                }
                catch (OperationCanceledException)
                {
                    _logger.LogInformation("截图服务在退避期间被取消");
                    break;
                }
            }
        }
        
        // ✅ 等待后台任务完成
        await StopBackgroundTasksAsync();
        
        // 等待保存队列清空
        _saveChannel.Writer.TryComplete();
        try { await _saveWorker.WaitAsync(TimeSpan.FromSeconds(30)); } catch { }
        
        var total = Interlocked.Read(ref _captureCount);
        var success = Interlocked.Read(ref _saveSuccess);
        var failed = Interlocked.Read(ref _saveFailed);
        var queued = Interlocked.Read(ref _uploadQueued);
        
        _logger.LogInformation("截图服务已停止 - 总截图: {Count}, 成功保存: {Success}, 失败: {Failed}, 已入队: {Queued}", 
            total, success, failed, queued);
    }
    
    private ScreenshotConfig GetCurrentConfig()
    {
        if (_currentPolicy != null && DateTime.UtcNow - _lastConfigUpdate < TimeSpan.FromSeconds(5))
        {
            return _cachedConfig;
        }
        
        if (_currentPolicy != null)
        {
            _cachedConfig = _currentPolicy.GetScreenshotConfig();
            _lastConfigUpdate = DateTime.UtcNow;
            return _cachedConfig;
        }
        
        return new ScreenshotConfig();
    }
    
    private async Task CaptureScreenshotAsync(CancellationToken ct)
    {
        if (!await _captureLock.WaitAsync(0, ct))
        {
            _logger.LogDebug("截图捕获已在进行中");
            return;
        }
        
        _performanceStopwatch.Restart();
        
        try
        {
            ct.ThrowIfCancellationRequested();
            
            var config = GetCurrentConfig();
            if (_lastLoggedInterval != config.IntervalSeconds)
            {
                _logger.LogInformation("Screenshot interval: {Interval}秒", config.IntervalSeconds);
                _lastLoggedInterval = config.IntervalSeconds;
            }
            
            var bounds = GetScreenBoundsFast(config.Resolution);
            if (bounds.Width <= 0 || bounds.Height <= 0) return;
            
            Image<Rgba32>? image = null;
            
            try
            {
                var capture = GetScreenCapture();
                image = capture.Capture(bounds);
                
                var captureTime = _performanceStopwatch.ElapsedMilliseconds;
                _captureTimeMs.AddSample(captureTime);
                
                if (image == null)
                {
                    _logger.LogWarning("屏幕捕获失败");
                    return;
                }
                
                DrawCursor(image);
                
                _performanceStopwatch.Restart();
                var format = config.GetNormalizedFormat();
                var quality = config.Quality;
                var encodedData = await EncodeImageAsync(image, format, quality, ct);
                var encodeTime = _performanceStopwatch.ElapsedMilliseconds;
                _encodeTimeMs.AddSample(encodeTime);
                
                if (encodedData == null || encodedData.Length == 0)
                {
                    _logger.LogWarning("图像编码失败");
                    return;
                }
                
                // 构建文件路径（目录按本地日期，便于员工在资源管理器中查找）
                var screenshotDir = Path.Combine(_config.GetEffectiveStoragePath(), "screenshots",
                    DateTime.Now.ToLocalDateDirectory());
                Directory.CreateDirectory(screenshotDir);
                
                var fileName = $"{DateTime.UtcNow:HH-mm-ss-fff}.{format}";
                var filePath = Path.Combine(screenshotDir, fileName);
                
                // ✅ 写入队列（可能阻塞等待，但不丢数据）
                await _saveChannel.Writer.WriteAsync(
                    new SaveTask(encodedData, filePath, format, DateTime.UtcNow),
                    ct);
                
                Interlocked.Increment(ref _captureCount);
            }
            finally
            {
                image?.Dispose();
            }
        }
        catch (OperationCanceledException) { }
        catch (Exception ex)
        {
            _logger.LogError(ex, "截图捕获失败");
        }
        finally
        {
            _captureLock.Release();
        }
    }
    
    private ScreenCapture GetScreenCapture()
    {
        lock (_captureLockObj)
        {
            if (_screenCapture == null)
            {
                _screenCapture = new ScreenCapture(_screenCaptureLogger);
            }
            return _screenCapture;
        }
    }
    
    /// <summary>
    /// 零拷贝光标绘制
    /// </summary>
    private static void DrawCursor(Image<Rgba32> image)
    {
        IntPtr cursorHandle = IntPtr.Zero;

        try
        {
            if (GetCursorPos(out POINT cursorPos))
            {
                cursorHandle = GetCursor();

                if (cursorHandle != IntPtr.Zero &&
                    cursorPos.X >= 0 &&
                    cursorPos.X < image.Width &&
                    cursorPos.Y >= 0 &&
                    cursorPos.Y < image.Height)
                {
                    image.ProcessPixelRows(accessor =>
                    {
                        const int radius = 3;

                        for (int dy = -radius; dy <= radius; dy++)
                        {
                            var y = cursorPos.Y + dy;
                            if (y < 0 || y >= image.Height) continue;

                            var row = accessor.GetRowSpan(y);

                            for (int dx = -radius; dx <= radius; dx++)
                            {
                                var x = cursorPos.X + dx;
                                if (x < 0 || x >= image.Width) continue;

                                if (dx * dx + dy * dy > radius * radius)
                                    continue;

                                ref var pixel = ref row[x];

                                pixel = new Rgba32(
                                    (byte)(255 - pixel.R),
                                    (byte)(255 - pixel.G),
                                    (byte)(255 - pixel.B),
                                    pixel.A);
                            }
                        }
                    });
                }
            }
        }
        finally
        {
            if (cursorHandle != IntPtr.Zero)
                DestroyIcon(cursorHandle);
        }
    }
    
    /// <summary>
    /// 智能编码
    /// </summary>
    private static async Task<byte[]> EncodeImageAsync(Image<Rgba32> image, string format, int quality, CancellationToken ct)
    {
        return await Task.Run(() =>
        {
            quality = Math.Clamp(quality, 10, 100);
            using var ms = new MemoryStream(1024 * 100);
            
            if (format.Equals("webp", StringComparison.OrdinalIgnoreCase))
            {
                var encoder = new WebpEncoder
                {
                    Quality = quality,
                    Method = WebpEncodingMethod.Default,
                    FileFormat = WebpFileFormatType.Lossy,
                    TransparentColorMode = WebpTransparentColorMode.Clear
                };
                image.Save(ms, encoder);
            }
            else if (format.Equals("png", StringComparison.OrdinalIgnoreCase))
            {
                var pngEncoder = new PngEncoder
                {
                    CompressionLevel = PngCompressionLevel.Level1,
                    BitDepth = PngBitDepth.Bit8
                };
                image.Save(ms, pngEncoder);
            }
            else
            {
                var jpegEncoder = new JpegEncoder
                {
                    Quality = quality
                };
                image.Save(ms, jpegEncoder);
            }
            
            return ms.ToArray();
        }, ct);
    }
    
    /// <summary>
    /// ✅ 保存工作线程 - 支持取消
    /// </summary>
    private async Task SaveWorkerAsync()
    {
        var reader = _saveChannel.Reader;
        var batch = new List<SaveTask>(10);
        
        try
        {
            while (await reader.WaitToReadAsync(_cts.Token))
            {
                while (reader.TryRead(out var task))
                {
                    batch.Add(task);
                    if (batch.Count >= 10) break;
                }
                
                if (batch.Count == 0)
                {
                    await Task.Delay(100, _cts.Token);
                    continue;
                }
                
                var sw = Stopwatch.StartNew();
                
                foreach (var task in batch)
                {
                    try
                    {
                        // ✅ 步骤1: 写入文件
                        await SaveFileAtomicAsync(task);
                        Interlocked.Increment(ref _saveSuccess);
                        
                        // ✅ 步骤2: 记录到数据库并入队（带重试）
                        await RecordScreenshotWithRetryAsync(task.FilePath, task.Data.Length, task.CaptureTime);
                        Interlocked.Increment(ref _uploadQueued);
                        
                        _logger.LogDebug("截图已保存并入库: {File}", Path.GetFileName(task.FilePath));
                    }
                    catch (Exception ex)
                    {
                        Interlocked.Increment(ref _saveFailed);
                        _logger.LogError(ex, "保存截图失败: {File}", Path.GetFileName(task.FilePath));
                        
                        // 清理可能残留的文件
                        try 
                        { 
                            if (File.Exists(task.FilePath)) 
                                File.Delete(task.FilePath); 
                        } 
                        catch { }
                    }
                }
                
                sw.Stop();
                _saveTimeMs.AddSample(sw.ElapsedMilliseconds / batch.Count);
                
                batch.Clear();
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("SaveWorker 被取消");
        }
        
        _logger.LogDebug("SaveWorker 已停止");
    }
    
    /// <summary>
    /// ✅ 原子保存文件（临时文件 + 重命名）
    /// </summary>
    private static async Task SaveFileAtomicAsync(SaveTask task)
    {
        var tempPath = task.FilePath + ".tmp";
        
        try
        {
            await File.WriteAllBytesAsync(tempPath, task.Data);
            
            var tempInfo = new FileInfo(tempPath);
            if (!tempInfo.Exists || tempInfo.Length == 0)
            {
                throw new InvalidOperationException($"临时文件写入失败: {tempPath}");
            }
            
            if (File.Exists(task.FilePath))
            {
                File.Delete(task.FilePath);
            }
            File.Move(tempPath, task.FilePath);
            
            var fileInfo = new FileInfo(task.FilePath);
            if (!fileInfo.Exists || fileInfo.Length == 0)
            {
                throw new InvalidOperationException($"文件保存验证失败: {task.FilePath}");
            }
        }
        catch
        {
            try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { }
            throw;
        }
    }
    
    /// <summary>
    /// ✅ 记录截图到数据库并上传（带重试）
    /// </summary>
    private async Task RecordScreenshotWithRetryAsync(string filePath, long fileSize, DateTime captureTime)
    {
        const int maxRetry = 3;

        for (var i = 0; i < maxRetry; i++)
        {
            try
            {
                await RecordScreenshotAsync(filePath, fileSize, captureTime);
                return;
            }
            catch (Exception ex)
            {
                if (i == maxRetry - 1)
                {
                    _logger.LogError(ex, "记录截图失败，已重试 {MaxRetry} 次: {File}", maxRetry, Path.GetFileName(filePath));
                    throw;
                }

                var delayMs = 200 * (i + 1);
                _logger.LogWarning(ex, "记录截图失败 (重试 {Retry}/{Max}): {File}，{Delay}ms 后重试", 
                    i + 1, maxRetry, Path.GetFileName(filePath), delayMs);
                
                await Task.Delay(TimeSpan.FromMilliseconds(delayMs));
            }
        }
    }
    
    /// <summary>
    /// ✅ 记录截图到数据库并上传（实际执行）
    /// </summary>
    private async Task RecordScreenshotAsync(string filePath, long fileSize, DateTime captureTime)
    {
        if (!File.Exists(filePath))
        {
            Interlocked.Increment(ref _fileMissingOnQueue);
            _logger.LogWarning("文件在入库前丢失: {File}", Path.GetFileName(filePath));
            return;
        }
        
        using var scope = _scopeFactory.CreateScope();
        var repo = scope.ServiceProvider.GetRequiredService<ScreenshotRepository>();
        var uploader = scope.ServiceProvider.GetRequiredService<FileUploadService>();

        var existing = await repo.GetByFilePathAsync(filePath);
        Screenshot screenshot;

        if (existing != null)
        {
            screenshot = existing;
            if (existing.Uploaded)
            {
                _logger.LogDebug("截图已上传，跳过重复入库: {File}", Path.GetFileName(filePath));
                return;
            }
            _logger.LogDebug("截图记录已存在，复用 ID 入队: {File}, Id={Id}",
                Path.GetFileName(filePath), screenshot.Id);
        }
        else
        {
            screenshot = new Screenshot
            {
                Id = Guid.NewGuid().ToString(),
                DeviceId = DeviceId,
                CapturedAt = captureTime,
                FilePath = filePath,
                FileSize = fileSize,
                Uploaded = false,
                Format = Path.GetExtension(filePath).TrimStart('.')
            };

            await repo.AddAsync(screenshot);
        }
        
        if (!File.Exists(filePath))
        {
            Interlocked.Increment(ref _fileMissingOnQueue);
            _logger.LogWarning("文件在数据库记录后丢失: {File}", Path.GetFileName(filePath));
            await repo.UpdateUploadStatusAsync(screenshot.Id, false);
            return;
        }
        
        await uploader.QueueFileWithTimeAsync(new UploadQueue
        {
            Id = Guid.NewGuid().ToString(),
            FilePath = filePath,
            FileType = "screenshot",
            FileId = screenshot.Id,
            Status = "pending",
            Offset = 0,
            RetryCount = 0,
            CreatedAt = DateTime.UtcNow,
            RecordStartTime = captureTime,
            RecordEndTime = captureTime
        });
    }
    
    /// <summary>
    /// ✅ 定期统计日志
    /// </summary>
    private async Task StatsLoggerAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(_statsLogInterval, ct);
                
                var success = Interlocked.Read(ref _saveSuccess);
                var failed = Interlocked.Read(ref _saveFailed);
                var queued = Interlocked.Read(ref _uploadQueued);
                var uploadFailed = Interlocked.Read(ref _uploadFailed);
                var missing = Interlocked.Read(ref _fileMissingOnQueue);
                var total = Interlocked.Read(ref _captureCount);
                
                _logger.LogInformation(
                    "[截图统计] 总捕获: {Total}, 保存成功: {Success}, 保存失败: {Failed}, " +
                    "已入队: {Queued}, 入队失败: {UploadFailed}, 文件丢失: {Missing}",
                    total, success, failed, queued, uploadFailed, missing);
                
                // 如果有异常指标，输出警告
                if (failed > 0 || uploadFailed > 0 || missing > 0)
                {
                    _logger.LogWarning(
                        "[截图告警] 保存失败: {Failed}, 入队失败: {UploadFailed}, 文件丢失: {Missing}",
                        failed, uploadFailed, missing);
                }
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "统计日志输出失败");
            }
        }
        
        _logger.LogDebug("StatsLogger 已停止");
    }
    
    /// <summary>
    /// ✅ 上传补偿扫描 - 防重复
    /// </summary>
    private async Task CompensationScanAsync(CancellationToken ct)
    {
        // 等待服务完全启动
        await Task.Delay(TimeSpan.FromSeconds(30), ct);
        
        // ✅ 只执行一次
        if (_compensationCompleted)
            return;
        
        try
        {
            _logger.LogInformation("开始上传补偿扫描...");
            
            using var scope = _scopeFactory.CreateScope();
            var repo = scope.ServiceProvider.GetRequiredService<ScreenshotRepository>();
            var uploader = scope.ServiceProvider.GetRequiredService<FileUploadService>();
            
            // 获取所有未上传的截图
            var screenshots = await repo.GetUnuploadedAsync(limit: 1000);
            
            if (screenshots.Count == 0)
            {
                _logger.LogInformation("上传补偿扫描完成: 无待补传文件");
                _compensationCompleted = true;
                return;
            }
            
            _logger.LogInformation("上传补偿扫描: 发现 {Count} 个待补传文件", screenshots.Count);
            
            var compensated = 0;
            var failed = 0;
            var skipped = 0;
            
            foreach (var screenshot in screenshots)
            {
                // ✅ 防重复处理
                bool shouldSkip;
                lock (_compensationLockObj)
                {
                    if (_compensationProcessedIds.Contains(screenshot.Id))
                    {
                        shouldSkip = true;
                    }
                    else
                    {
                        _compensationProcessedIds.Add(screenshot.Id);
                        shouldSkip = false;
                    }
                }
                
                if (shouldSkip)
                {
                    skipped++;
                    _logger.LogDebug("跳过重复补偿: {File}", Path.GetFileName(screenshot.FilePath));
                    continue;
                }
                
                try
                {
                    if (!File.Exists(screenshot.FilePath))
                    {
                        _logger.LogWarning("补偿文件不存在: {File}", Path.GetFileName(screenshot.FilePath));
                        await repo.UpdateUploadStatusAsync(screenshot.Id, false);
                        failed++;
                        continue;
                    }
                    
                    // ✅ 检查是否已在队列中
                    if (await uploader.QueueFileExistsAsync(screenshot.FilePath))
                    {
                        _logger.LogDebug("文件已在队列中，跳过: {File}", Path.GetFileName(screenshot.FilePath));
                        skipped++;
                        continue;
                    }
                    
                    await uploader.QueueFileWithTimeAsync(new UploadQueue
                    {
                        Id = Guid.NewGuid().ToString(),
                        FilePath = screenshot.FilePath,
                        FileType = "screenshot",
                        FileId = screenshot.Id,
                        Status = "pending",
                        Offset = 0,
                        RetryCount = 0,
                        CreatedAt = DateTime.UtcNow,
                        RecordStartTime = screenshot.CapturedAt,
                        RecordEndTime = screenshot.CapturedAt
                    });
                    compensated++;
                    
                    _logger.LogDebug("补偿入队成功: {File}", Path.GetFileName(screenshot.FilePath));
                }
                catch (Exception ex)
                {
                    failed++;
                    _logger.LogError(ex, "补偿入队失败: {File}", Path.GetFileName(screenshot.FilePath));
                }
            }
            
            _logger.LogInformation("上传补偿扫描完成: 成功补偿 {Compensated}, 失败 {Failed}, 跳过 {Skipped}", 
                compensated, failed, skipped);
            
            _compensationCompleted = true;
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("补偿扫描被取消");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "上传补偿扫描失败");
        }
        
        _logger.LogDebug("CompensationScan 已停止");
    }
    
    /// <summary>
    /// ✅ 停止所有后台任务
    /// </summary>
    private async Task StopBackgroundTasksAsync()
    {
        _logger.LogDebug("停止后台任务...");
        
        _cts.Cancel();
        
        var tasks = new List<Task>();
        
        if (_statsTask != null && !_statsTask.IsCompleted)
            tasks.Add(_statsTask);
            
        if (_compensationTask != null && !_compensationTask.IsCompleted)
            tasks.Add(_compensationTask);
        
        if (tasks.Count == 0)
            return;
        
        try
        {
            await Task.WhenAll(tasks).WaitAsync(TimeSpan.FromSeconds(5));
            _logger.LogDebug("所有后台任务已停止");
        }
        catch (TimeoutException)
        {
            _logger.LogWarning("后台任务停止超时，强制完成");
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "停止后台任务时发生异常");
        }
    }
    
    /// <summary>
    /// 快速获取屏幕边界
    /// </summary>
    private static ImageSharpRectangle GetScreenBoundsFast(string resolution)
    {
        var screenWidth = GetSystemMetrics(SM_CXSCREEN);
        var screenHeight = GetSystemMetrics(SM_CYSCREEN);
        
        if (string.IsNullOrEmpty(resolution))
            return new ImageSharpRectangle(0, 0, screenWidth, screenHeight);
        
        try
        {
            var parts = resolution.Split(new[] { 'x', '*' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length >= 2 && int.TryParse(parts[0], out var width) && int.TryParse(parts[1], out var height))
            {
                width = Math.Min(width, screenWidth);
                height = Math.Min(height, screenHeight);
                return new ImageSharpRectangle(0, 0, width, height);
            }
        }
        catch { }
        
        return new ImageSharpRectangle(0, 0, screenWidth, screenHeight);
    }
    
    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("停止截图服务...");
        _isStopping = true;
        
        // ✅ 停止后台任务
        await StopBackgroundTasksAsync();
        
        // 取消捕获
        _cts.Cancel();
        
        if (_captureLock.CurrentCount == 0)
        {
            try 
            { 
                await _captureLock.WaitAsync(TimeSpan.FromSeconds(10), cancellationToken); 
                _captureLock.Release(); 
            }
            catch (TimeoutException) 
            { 
                _logger.LogWarning("等待截图捕获超时"); 
            }
        }
        
        lock (_captureLockObj)
        {
            _screenCapture?.Dispose();
            _screenCapture = null;
        }
        
        await base.StopAsync(cancellationToken);
    }
    
    public override void Dispose()
    {
        if (_cts != null && !_cts.IsCancellationRequested)
        {
            _cts.Cancel();
            _cts.Dispose();
        }
        _captureLock?.Dispose();

        lock (_captureLockObj)
        {
            _screenCapture?.Dispose();
            _screenCapture = null;
        }
        base.Dispose();
    }
    
    /// <summary>
    /// 移动平均计算器
    /// </summary>
    private sealed class MovingAverage
    {
        private readonly int _windowSize;
        private readonly double[] _samples;
        private int _index;
        private int _count;
        private double _sum;
        
        public MovingAverage(int windowSize = 30)
        {
            _windowSize = windowSize;
            _samples = new double[windowSize];
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void AddSample(double value)
        {
            lock (_samples)
            {
                _sum -= _samples[_index];
                _samples[_index] = value;
                _sum += value;
                _index = (_index + 1) % _windowSize;
                if (_count < _windowSize) _count++;
            }
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public double GetAverage() => _count == 0 ? 0 : _sum / _count;
    }
}
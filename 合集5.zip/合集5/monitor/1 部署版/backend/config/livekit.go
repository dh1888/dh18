package config

import (
	"os"
	"strconv"
	"strings"
	"time"
)

// LiveKitConfig holds LiveKit connection and token settings.
type LiveKitConfig struct {
	URL              string
	APIHost          string
	APIKey           string
	APISecret        string
	TokenTTL         time.Duration
	MaxViewersPerDev int
	StartingTimeout  time.Duration
}

func LoadLiveKitConfig() LiveKitConfig {
	ttlMinutes := 30
	if v := os.Getenv("REMOTE_VIEW_TOKEN_TTL_MINUTES"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			ttlMinutes = n
		}
	}

	maxViewers := 10
	if v := os.Getenv("REMOTE_VIEW_MAX_VIEWERS_PER_DEVICE"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			maxViewers = n
		}
	}

	startingTimeoutSec := 90
	if v := os.Getenv("REMOTE_VIEW_STARTING_TIMEOUT_SECONDS"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			startingTimeoutSec = n
		}
	}

	url := strings.TrimSpace(os.Getenv("LIVEKIT_URL"))
	apiHost := strings.TrimSpace(os.Getenv("LIVEKIT_API_HOST"))
	if apiHost == "" {
		apiHost = deriveAPIHost(url)
	}

	return LiveKitConfig{
		URL:              url,
		APIHost:          apiHost,
		APIKey:           strings.TrimSpace(os.Getenv("LIVEKIT_API_KEY")),
		APISecret:        strings.TrimSpace(os.Getenv("LIVEKIT_API_SECRET")),
		TokenTTL:         time.Duration(ttlMinutes) * time.Minute,
		MaxViewersPerDev: maxViewers,
		StartingTimeout:  time.Duration(startingTimeoutSec) * time.Second,
	}
}

func (c LiveKitConfig) Enabled() bool {
	return c.URL != "" && c.APIKey != "" && c.APISecret != "" && c.APIHost != ""
}

func deriveAPIHost(wsURL string) string {
	if wsURL == "" {
		return ""
	}
	host := strings.TrimPrefix(wsURL, "wss://")
	host = strings.TrimPrefix(host, "ws://")
	host = strings.TrimPrefix(host, "https://")
	host = strings.TrimPrefix(host, "http://")
	if idx := strings.Index(host, "/"); idx >= 0 {
		host = host[:idx]
	}
	if host == "" {
		return ""
	}
	return "http://" + host
}

func RoomNameForDevice(deviceID string) string {
	return "rv-" + deviceID
}

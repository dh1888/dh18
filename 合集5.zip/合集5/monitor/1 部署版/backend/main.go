package main

import (
	"context"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"

	"enterprise-agent/backend/config"
	"enterprise-agent/backend/handlers"
	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/models"
	"enterprise-agent/backend/routes"
	"enterprise-agent/backend/services"
)
func main() {
    // 加载环境变量
    if err := godotenv.Load(); err != nil {
        log.Println("Warning: .env file not found, using environment variables")
    }

    // 设置 Gin 为发布模式（生产环境）
    if os.Getenv("ENV") == "production" {
        gin.SetMode(gin.ReleaseMode)
        log.Println("Running in production mode (ReleaseMode)")
    }

    // 验证必要的环境变量
    if os.Getenv("JWT_SECRET") == "" {
        log.Fatal("FATAL: JWT_SECRET environment variable is required")
    }
    if os.Getenv("DB_PASSWORD") == "" {
        log.Fatal("FATAL: DB_PASSWORD environment variable is required")
    }
    log.Println("Environment validation passed")

    // 验证所有必需的配置
    if err := models.ValidateConfig(); err != nil {
        log.Fatalf("Configuration error: %v", err)
    }
    log.Println("Configuration validated successfully")

    // 初始化数据库
    db := services.NewDatabase()
    redis := services.NewRedis()
    if redis != nil {
        pingCtx, pingCancel := context.WithTimeout(context.Background(), 3*time.Second)
        if err := redis.Ping(pingCtx).Err(); err != nil {
            log.Printf("Warning: Redis ping failed at startup: %v (refresh token operations will fail until Redis is available)", err)
        } else {
            log.Println("Redis connection verified")
        }
        pingCancel()
    }
    minio := services.NewMinIO()

    // 创建 WebSocket Hub
    wsHub := services.NewWebSocketHubWithRedis(redis)

    // 初始化所有 Repository
    deviceRepo := services.NewDeviceRepository(db)
    policyRepo := services.NewPolicyRepository(db)
    recordingRepo := services.NewRecordingRepository(db, minio)
    taskRepo := services.NewTaskRepository(db)
    screenshotRepo := services.NewScreenshotRepository(db)
    activityRepo := services.NewActivityRepository(db)
    cleanupRepo := services.NewCleanupRepositoryWithAll(db, recordingRepo, screenshotRepo, activityRepo, minio)
    userRepo := services.NewUserRepository(db)
    wsHub.SetActivityRepository(activityRepo)
    wsHub.SetDeviceRepository(deviceRepo)

    go cleanupRepo.StartAutoCleanup()

    taskMonitorCtx, taskMonitorCancel := context.WithCancel(context.Background())
    go taskRepo.StartStaleTaskMonitor(taskMonitorCtx)

    // ========== 磁盘监控服务 ==========
    uploadsDir := os.Getenv("UPLOADS_DIR")
    if uploadsDir == "" {
        uploadsDir = "./uploads"
    }

    // 转换为绝对路径
    uploadsDirAbs, err := filepath.Abs(uploadsDir)
    if err != nil {
        log.Fatalf("failed to resolve uploads directory: %v", err)
    }
    uploadsDir = uploadsDirAbs

    // 确保目录存在
    if err := os.MkdirAll(uploadsDir, 0755); err != nil {
        log.Fatalf("Failed to create uploads dir: %v", err)
    }

    // 创建数据目录（用于安全配置）
    dataDir, err := filepath.Abs(filepath.Join(".", "data"))
    if err != nil {
        log.Fatalf("failed to resolve data directory: %v", err)
    }
    if err := os.MkdirAll(dataDir, 0755); err != nil {
        log.Fatalf("failed to create data directory: %v", err)
    }

    // 创建磁盘监控器
    diskMonitor := services.NewDiskMonitor(cleanupRepo, uploadsDir)
    diskMonitor.SetInterval(10 * time.Minute)
    diskMonitor.SetThreshold(85)
    go diskMonitor.Start(context.Background())
    log.Printf("[Main] Disk monitor started: interval=10m, threshold=85%%")

    alertService := services.NewAlertService(deviceRepo, taskRepo, uploadsDir)
    alertMonitorCtx, alertMonitorCancel := context.WithCancel(context.Background())
    go alertService.StartMonitor(alertMonitorCtx)

    // 初始化截图安全配置
    handlers.InitScreenshotSecurity(uploadsDir, dataDir)
    log.Println("Screenshot security initialized")

    // 初始化 Handlers
    userHandler := handlers.NewUserHandler(userRepo)
    screenshotHandler := handlers.NewScreenshotHandler(screenshotRepo, deviceRepo)
    activityHandler := handlers.NewActivityHandler(activityRepo, deviceRepo)
    authHandler := handlers.NewAuthHandler(db, redis)
    deviceHandler := handlers.NewDeviceHandler(deviceRepo, wsHub, redis)
    policyHandler := handlers.NewPolicyHandler(policyRepo, wsHub)
    recordingHandler := handlers.NewRecordingHandler(recordingRepo, deviceRepo)
    uploadHandler := handlers.NewUploadHandler(recordingRepo, screenshotRepo, minio, taskRepo, deviceRepo)
    taskHandler := handlers.NewTaskHandler(taskRepo, wsHub, deviceRepo, alertService)
    cleanupHandler := handlers.NewCleanupHandler(cleanupRepo)
    adminHandler := handlers.NewAdminHandler(db)
    operationLogHandler := handlers.NewOperationLogHandler(db)

    liveKitCfg := config.LoadLiveKitConfig()
    remoteViewRepo := services.NewRemoteViewRepository(db)
    remoteViewSvc := services.NewRemoteViewService(liveKitCfg, remoteViewRepo, deviceRepo, wsHub)
    wsHub.SetRemoteViewService(remoteViewSvc)
    remoteViewHandler := handlers.NewRemoteViewHandler(remoteViewSvc)

    handlers.GlobalLogger = operationLogHandler

    handlers.InitUploadSessionStore(redis)
    middleware.InitSignatureNonceStore(redis)

    healthHandler := handlers.NewHealthHandler(db, redis, uploadsDir)
    healthHandler.SetLiveKitPing(remoteViewSvc.PingLiveKit)

    // 创建 Gin 路由
    router := gin.New()
    router.Use(middleware.Logger())
    router.Use(middleware.Recovery())
    router.Use(middleware.CORS())
    // 媒体文件通过鉴权 API 访问（/recordings/:id/stream、/screenshots/:id/image），禁止静态公开目录
    router.Use(handlers.OperationLogMiddleware(db))

    // 健康检查
    router.GET("/health", healthHandler.Live)
    router.GET("/ready", healthHandler.Ready)

    // 路由配置
    routeHandlers := &routes.Handlers{
        Auth:         authHandler,
        Device:       deviceHandler,
        Policy:       policyHandler,
        Recording:    recordingHandler,
        Upload:       uploadHandler,
        Task:         taskHandler,
        Cleanup:      cleanupHandler,
        Activity:     activityHandler,
        Screenshot:   screenshotHandler,
        User:         userHandler,
        Admin:        adminHandler,
        OperationLog: operationLogHandler,
        RemoteView:   remoteViewHandler,
    }
    routes.SetupRoutesWithHub(router, routeHandlers, redis, wsHub, deviceRepo)

    port := os.Getenv("PORT")
    if port == "" {
        port = "8080"
    }

    listener, err := net.Listen("tcp4", ":"+port)
    if err != nil {
        log.Fatalf("Failed to create listener: %v", err)
    }

    srv := &http.Server{
        Handler: router,
    }

    go func() {
        log.Printf("Server starting on port %s (IPv4)", port)
        if err := srv.Serve(listener); err != nil && err != http.ErrServerClosed {
            log.Fatalf("Failed to start server: %v", err)
        }
    }()

    // 等待退出信号
    quit := make(chan os.Signal, 1)
    signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
    <-quit

    log.Println("Shutting down server...")

    shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 30*time.Second)
    defer shutdownCancel()

    if err := srv.Shutdown(shutdownCtx); err != nil {
        log.Printf("HTTP server shutdown error: %v", err)
    }

    uploadHandler.Stop()
    middleware.CloseSignatureNonceStore()
    taskMonitorCancel()
    alertMonitorCancel()
    wsHub.Stop()
    cleanupRepo.Stop()
    diskMonitor.Stop()

    if db != nil {
        db.Close()
    }
    if redis != nil {
        if err := redis.Close(); err != nil {
            log.Printf("Error closing redis: %v", err)
        }
    }
    log.Println("Server stopped")
}
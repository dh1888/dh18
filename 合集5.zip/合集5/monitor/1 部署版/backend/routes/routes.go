// backend/routes/routes.go - 完整修复版

package routes

import (
	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/handlers"
	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/services"
)

// Handlers 结构体，包含所有处理器
type Handlers struct {
	Auth       *handlers.AuthHandler
	Device     *handlers.DeviceHandler
	Policy     *handlers.PolicyHandler
	Recording  *handlers.RecordingHandler
	Upload     *handlers.UploadHandler
	Task       *handlers.TaskHandler
	Cleanup    *handlers.CleanupHandler
	Activity   *handlers.ActivityHandler
	Screenshot *handlers.ScreenshotHandler
	User       *handlers.UserHandler
	Admin      *handlers.AdminHandler
	OperationLog *handlers.OperationLogHandler
	RemoteView   *handlers.RemoteViewHandler
}

func registerUploadPublicRoutes(public *gin.RouterGroup, handlers *Handlers, redisClient *redis.Client) {
	uploadPublic := public.Group("/upload")
	// 上传接口允许可选认证，并验证设备签名（如果提供）
	uploadPublic.Use(middleware.OptionalAuth(redisClient), middleware.VerifyDeviceSignature(handlers.Upload.DeviceRepo))
	{
		uploadPublic.POST("/chunk", handlers.Upload.UploadChunk)
		uploadPublic.POST("/complete", handlers.Upload.Complete)
		uploadPublic.GET("/:uploadId/progress", handlers.Upload.GetUploadProgress)
		uploadPublic.DELETE("/:uploadId", handlers.Upload.CancelUpload)
	}
}

// SetupRoutes 配置所有路由
func SetupRoutes(router *gin.Engine, handlers *Handlers, redisClient *redis.Client) {
	api := router.Group("/api/v1")

	// ========== 公开接口（不需要认证） ==========
	public := api.Group("")
	{
		public.POST("/auth/login", handlers.Auth.Login)
		public.POST("/auth/refresh", handlers.Auth.Refresh)
		public.POST("/auth/logout", handlers.Auth.Logout)
		public.POST("/devices/register", handlers.Device.Register)
		public.POST("/devices/refresh", handlers.Device.Refresh)

		registerUploadPublicRoutes(public, handlers, redisClient)
	}

	// ========== 需要认证的接口 ==========
	protected := api.Group("")
	protected.Use(middleware.Auth(redisClient))
	{
		// ---------- 设备管理 ----------
		devices := protected.Group("/devices")
		{
			devices.GET("", middleware.RequirePermission("device:view"), handlers.Device.List)
			devices.GET("/:id", middleware.RequirePermission("device:view"), handlers.Device.Get)
			// devices.GET("/:id/verify", middleware.DeviceAuth(redisClient), handlers.Device.Verify)
			devices.POST("/:id/bind", middleware.RequirePermission("device:bind"), handlers.Device.Bind)
			devices.POST("/:id/unbind", middleware.RequirePermission("device:unbind"), handlers.Device.Unbind)
			devices.PUT("/:id/status", middleware.RequirePermission("device:manage"), handlers.Device.UpdateStatus)
			devices.GET("/stats/online", middleware.RequirePermission("device:view"), handlers.Device.OnlineStats)
			devices.POST("/info", handlers.Device.ReportInfo)
			devices.GET("/export", middleware.RequirePermission("device:view"), handlers.Device.ExportEmployees)
			devices.PUT("/:id/employee", middleware.RequirePermission("device:bind"), handlers.Device.UpdateEmployee)
		}

		// ---------- 录屏管理 ----------
		recordings := protected.Group("/recordings")
		{
			// ✅ 修复：按优先级排序路由，集合操作放在参数路由前面
			recordings.GET("", middleware.RequirePermission("recording:view"), handlers.Recording.List)
			recordings.POST("/batch-delete", middleware.RequirePermission("recording:delete"), handlers.Recording.BatchDelete)
			recordings.GET("/device/:deviceId", middleware.RequirePermission("recording:view"), handlers.Recording.GetByDevice)
			recordings.GET("/stats", middleware.RequirePermission("recording:view"), handlers.Recording.GetStats)
			recordings.GET("/export", middleware.RequirePermission("recording:export"), handlers.Recording.ExportRecordings)

			// 具体 ID 路由放在最后
			recordings.GET("/:id/play", middleware.RequirePermission("recording:play"), handlers.Recording.Play)
			recordings.GET("/:id/stream", middleware.RequirePermission("recording:play"), handlers.Recording.Stream)
			recordings.GET("/:id/download", middleware.RequirePermission("recording:export"), handlers.Recording.Download)
			recordings.GET("/:id/playback-info", middleware.RequirePermission("recording:view"), handlers.Recording.GetPlaybackInfo)
			recordings.GET("/:id", middleware.RequirePermission("recording:view"), handlers.Recording.Get)
			recordings.DELETE("/:id", middleware.RequirePermission("recording:delete"), handlers.Recording.Delete)
		}

		// ---------- 活动日志管理 ----------
		activities := protected.Group("/activities")
		{
			// ✅ 修复：按优先级排序路由，集合操作放在前面
			activities.GET("", middleware.RequirePermission("activity:view"), handlers.Activity.ListActivities)
			activities.GET("/daily-summary", middleware.RequirePermission("activity:view"), handlers.Activity.GetDailySummary)
			activities.GET("/stats", middleware.RequirePermission("activity:view"), handlers.Activity.GetActivityStats)
			activities.GET("/processes", middleware.RequirePermission("activity:view"), handlers.Activity.GetProcessNames)
			activities.GET("/export", middleware.RequirePermission("activity:export"), handlers.Activity.ExportActivities)
			activities.DELETE("", middleware.RequirePermission("activity:delete"), handlers.Activity.DeleteActivities)

			// POST 操作
			activities.POST("/report", handlers.Activity.ReportActivities)
		}

		// ---------- 策略管理 ----------
		policies := protected.Group("/policies")
		{
			policies.GET("/current", handlers.Policy.GetCurrent)
			policies.GET("", middleware.RequirePermission("policy:view"), handlers.Policy.List)
			policies.POST("", middleware.RequirePermission("policy:create"), handlers.Policy.Create)
			policies.GET("/:id", middleware.RequirePermission("policy:view"), handlers.Policy.Get)
			policies.PUT("/:id", middleware.RequirePermission("policy:update"), handlers.Policy.Update)
			policies.DELETE("/:id", middleware.RequirePermission("policy:delete"), handlers.Policy.Delete)
			policies.POST("/:id/publish", middleware.RequirePermission("policy:update"), handlers.Policy.Publish)
			policies.POST("/:id/rollback", middleware.RequirePermission("policy:update"), handlers.Policy.Rollback)
		}

		// ---------- 清理策略 ----------
		cleanup := protected.Group("/cleanup")
		{
			cleanup.GET("/policy", middleware.RequirePermission("policy:view"), handlers.Cleanup.GetCleanupPolicy)
			cleanup.PUT("/policy", middleware.RequirePermission("policy:update"), handlers.Cleanup.UpdateCleanupPolicy)
			cleanup.GET("/stats", middleware.RequirePermission("policy:view"), handlers.Cleanup.GetStorageStats)
			cleanup.POST("/manual", middleware.RequirePermission("policy:update"), handlers.Cleanup.ManualCleanup)
			cleanup.GET("/logs", middleware.RequirePermission("policy:view"), handlers.Cleanup.GetCleanupLogs)
		}

		// ---------- 任务管理 ----------
		tasks := protected.Group("/tasks")
		{
			tasks.GET("/pending", handlers.Task.GetPendingTasks)
			tasks.GET("", handlers.Task.ListTasks)
			tasks.GET("/:id", handlers.Task.GetTask)
			tasks.POST("", handlers.Task.CreateTask)
			tasks.POST("/:id/cancel", handlers.Task.CancelTask)
			tasks.POST("/:id/retry", handlers.Task.RetryTask)
			tasks.DELETE("/:id", handlers.Task.DeleteTask)
			tasks.POST("/batch-status", handlers.Task.BatchUpdateStatus)
		}

		// ---------- 上传任务 ----------
		uploadTasks := protected.Group("/upload-tasks")
		{
			uploadTasks.GET("", handlers.Upload.ListTasks)
		}

		// ---------- 上传接口（已移至公开组，支持可选认证） ----------
		// 见上方 public 注册，支持 OptionalAuth

		// ---------- 用户管理 ----------
		users := protected.Group("/users")
		{
			users.GET("", middleware.RequirePermission("user:view"), handlers.User.ListUsers)
			users.POST("", middleware.RequirePermission("user:create"), handlers.User.CreateUser)
			users.GET("/:id", middleware.RequirePermission("user:view"), handlers.User.GetUser)
			users.PUT("/:id", middleware.RequirePermission("user:update"), handlers.User.UpdateUser)
			users.DELETE("/:id", middleware.RequirePermission("user:delete"), handlers.User.DeleteUser)
			users.POST("/:id/reset-password", middleware.RequirePermission("user:manage"), handlers.User.ResetPassword)
			users.POST("/:id/roles", middleware.RequirePermission("user:manage"), handlers.User.AssignRole)
			users.DELETE("/:id/roles/:roleId", middleware.RequirePermission("user:manage"), handlers.User.RemoveRole)
		}

		// ---------- 个人信息 ----------
		profile := protected.Group("/user")
		{
			profile.GET("/profile", handlers.User.GetProfile)
			profile.PUT("/profile", handlers.User.UpdateProfile)
			profile.POST("/change-password", handlers.User.ChangeOwnPassword)
		}

		// ---------- 角色管理 ----------
		roles := protected.Group("/roles")
		{
			roles.GET("", middleware.RequirePermission("role:view"), handlers.User.GetAllRoles)
			roles.GET("/:id", middleware.RequirePermission("role:view"), handlers.User.GetRole)
			roles.POST("", middleware.RequirePermission("role:create"), handlers.User.CreateRole)
			roles.PUT("/:id", middleware.RequirePermission("role:update"), handlers.User.UpdateRole)
			roles.DELETE("/:id", middleware.RequirePermission("role:delete"), handlers.User.DeleteRole)
		}
		admin := protected.Group("/admin")
		{
			admin.GET("/employees", middleware.RequirePermission("attendance:view"), handlers.Admin.GetEmployees)
			admin.POST("/employees", middleware.RequirePermission("attendance:edit"), handlers.Admin.CreateEmployee)
			admin.PUT("/employees/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.UpdateEmployee)
			admin.DELETE("/employees/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.DeleteEmployee)
			admin.GET("/attendance/records", middleware.RequirePermission("attendance:view"), handlers.Admin.GetAttendanceRecords)
			admin.POST("/attendance/records", middleware.RequirePermission("attendance:edit"), handlers.Admin.SaveAttendanceRecords)
			admin.GET("/performance", middleware.RequirePermission("attendance:view"), handlers.Admin.GetPerformance)
			admin.POST("/performance/batch", middleware.RequirePermission("attendance:edit"), handlers.Admin.BatchSavePerformance)
			admin.GET("/penalty/records", middleware.RequirePermission("attendance:view"), handlers.Admin.GetPenaltyRecords)
			admin.POST("/penalty/record", middleware.RequirePermission("attendance:edit"), handlers.Admin.CreatePenaltyRecord)
			admin.DELETE("/penalty/records/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.DeletePenaltyRecord)
			admin.GET("/site-stats/sites", middleware.RequirePermission("site:view"), handlers.Admin.GetSites)
			admin.POST("/site-stats/sites", middleware.RequirePermission("site:manage"), handlers.Admin.CreateSite)
			admin.PUT("/site-stats/sites/:id", middleware.RequirePermission("site:manage"), handlers.Admin.UpdateSite)
			admin.DELETE("/site-stats/sites/:id", middleware.RequirePermission("site:manage"), handlers.Admin.DeleteSite)
			admin.GET("/site-stats/employee-accounts", middleware.RequirePermission("site:view"), handlers.Admin.GetEmployeeAccounts)
			admin.POST("/site-stats/employee-accounts", middleware.RequirePermission("site:manage"), handlers.Admin.CreateEmployeeAccount)
			admin.PUT("/site-stats/employee-accounts/:id", middleware.RequirePermission("site:manage"), handlers.Admin.UpdateEmployeeAccount)
			admin.DELETE("/site-stats/employee-accounts/:id", middleware.RequirePermission("site:manage"), handlers.Admin.DeleteEmployeeAccount)
			admin.POST("/site-stats/upload/preview", middleware.RequirePermission("stats:edit"), handlers.Admin.PreviewSiteStatsUpload)
			admin.POST("/site-stats/upload", middleware.RequirePermission("stats:edit"), handlers.Admin.UploadSiteStats)
			admin.DELETE("/site-stats/data/clear-by-date", middleware.RequirePermission("stats:edit"), handlers.Admin.ClearSiteStatsByDate)
			admin.GET("/site-stats/summary", middleware.RequirePermission("stats:view"), handlers.Admin.GetSiteStatsSummary)
			admin.GET("/site-stats/stacked-summary", middleware.RequirePermission("stats:view"), handlers.Admin.GetSiteStatsStacked)
			admin.DELETE("/site-stats/clear-by-date-only", middleware.RequirePermission("stats:edit"), handlers.Admin.ClearSiteStatsByDateOnly)
		}
	}

	// ========== WebSocket 路由 ==========
	router.GET("/ws/agent", middleware.DeviceAuth(redisClient), handlers.Device.HandleAgentWebSocket)
	router.GET("/ws/admin", middleware.WebSocketAuth(redisClient), handlers.Device.HandleAdminWebSocket)
}

func SetupRoutesWithHub(router *gin.Engine, handlers *Handlers, redisClient *redis.Client, wsHub *services.WebSocketHub, deviceRepo *services.DeviceRepository) {
	api := router.Group("/api/v1")

	// ========== 公开接口（不需要认证） ==========
	public := api.Group("")
	{
		public.POST("/auth/login", middleware.AuthRateLimit(), handlers.Auth.Login)
		public.POST("/auth/refresh", middleware.AuthRateLimit(), handlers.Auth.Refresh)
		public.POST("/auth/logout", middleware.AuthRateLimit(), handlers.Auth.Logout)
		public.POST("/devices/register", middleware.DeviceRegisterRateLimit(), handlers.Device.Register)
		public.POST("/devices/refresh", middleware.AuthRateLimit(), handlers.Device.Refresh)
		// 设备信息上报：管理端（用户 Token）与 Agent（设备 Token）共用
		public.POST("/devices/info", middleware.UserOrDeviceAuth(redisClient), handlers.Device.ReportInfo)

		// 上传接口：对分片上传允许可选认证（设备或匿名），兼容旧客户端
		registerUploadPublicRoutes(public, handlers, redisClient)
	}

	// ========== 用户认证接口 ==========
	protected := api.Group("")
	protected.Use(middleware.Auth(redisClient))
	{
		// ---------- 设备管理 ----------
		devices := protected.Group("/devices")
		{
			devices.GET("", middleware.RequirePermission("device:view"), handlers.Device.List)
			devices.GET("/:id", middleware.RequirePermission("device:view"), handlers.Device.Get)
			devices.POST("/:id/bind", middleware.RequirePermission("device:bind"), handlers.Device.Bind)
			devices.POST("/:id/unbind", middleware.RequirePermission("device:unbind"), handlers.Device.Unbind)
			devices.PUT("/:id/status", middleware.RequirePermission("device:manage"), handlers.Device.UpdateStatus)
			devices.GET("/stats/online", middleware.RequirePermission("device:view"), handlers.Device.OnlineStats)
			devices.GET("/export", middleware.RequirePermission("device:view"), handlers.Device.ExportEmployees)
			devices.PUT("/:id/employee", middleware.RequirePermission("device:bind"), handlers.Device.UpdateEmployee)
			devices.POST("/:id/remote-view/start", middleware.RequirePermission("device:view"), handlers.RemoteView.Start)
			devices.POST("/:id/remote-view/stop", middleware.RequirePermission("device:view"), handlers.RemoteView.Stop)
			devices.GET("/:id/remote-view/status", middleware.RequirePermission("device:view"), handlers.RemoteView.Status)
		}

		remoteView := protected.Group("/remote-view")
		{
			remoteView.GET("/audit-logs", middleware.RequirePermission("device:view"), handlers.RemoteView.AuditLogs)
		}

		// ---------- 录屏管理 ----------
		recordings := protected.Group("/recordings")
		{
			recordings.GET("", middleware.RequirePermission("recording:view"), handlers.Recording.List)
			recordings.GET("/:id", middleware.RequirePermission("recording:view"), handlers.Recording.Get)
			recordings.GET("/:id/play", middleware.RequirePermission("recording:play"), handlers.Recording.Play)
			recordings.GET("/:id/stream", middleware.RequirePermission("recording:play"), handlers.Recording.Stream)
			recordings.GET("/:id/download", middleware.RequirePermission("recording:export"), handlers.Recording.Download)
			recordings.GET("/:id/playback-info", middleware.RequirePermission("recording:view"), handlers.Recording.GetPlaybackInfo)
			recordings.DELETE("/:id", middleware.RequirePermission("recording:delete"), handlers.Recording.Delete)
			recordings.POST("/batch-delete", middleware.RequirePermission("recording:delete"), handlers.Recording.BatchDelete)
			recordings.GET("/stats", middleware.RequirePermission("recording:view"), handlers.Recording.GetStats)
			recordings.GET("/device/:deviceId", middleware.RequirePermission("recording:view"), handlers.Recording.GetByDevice)
			recordings.GET("/export", middleware.RequirePermission("recording:export"), handlers.Recording.ExportRecordings)
		}

		// ---------- 活动日志管理 ----------
		activities := protected.Group("/activities")
		{
			activities.GET("", middleware.RequirePermission("activity:view"), handlers.Activity.ListActivities)
			activities.GET("/daily-summary", middleware.RequirePermission("activity:view"), handlers.Activity.GetDailySummary)
			activities.GET("/stats", middleware.RequirePermission("activity:view"), handlers.Activity.GetActivityStats)
			activities.GET("/processes", middleware.RequirePermission("activity:view"), handlers.Activity.GetProcessNames)
			activities.GET("/export", middleware.RequirePermission("activity:export"), handlers.Activity.ExportActivities)
			activities.DELETE("", middleware.RequirePermission("activity:delete"), handlers.Activity.DeleteActivities)
		}

		// ---------- 策略管理 ----------
		policies := protected.Group("/policies")
		{
			policies.GET("", middleware.RequirePermission("policy:view"), handlers.Policy.List)
			policies.POST("", middleware.RequirePermission("policy:create"), handlers.Policy.Create)
			policies.GET("/:id", middleware.RequirePermission("policy:view"), handlers.Policy.Get)
			policies.PUT("/:id", middleware.RequirePermission("policy:update"), handlers.Policy.Update)
			policies.DELETE("/:id", middleware.RequirePermission("policy:delete"), handlers.Policy.Delete)
			policies.POST("/:id/publish", middleware.RequirePermission("policy:update"), handlers.Policy.Publish)
			policies.POST("/:id/rollback", middleware.RequirePermission("policy:update"), handlers.Policy.Rollback)
		}

		// ---------- 清理策略 ----------
		cleanup := protected.Group("/cleanup")
		{
			cleanup.GET("/policy", middleware.RequirePermission("policy:view"), handlers.Cleanup.GetCleanupPolicy)
			cleanup.PUT("/policy", middleware.RequirePermission("policy:update"), handlers.Cleanup.UpdateCleanupPolicy)
			cleanup.GET("/stats", middleware.RequirePermission("policy:view"), handlers.Cleanup.GetStorageStats)
			cleanup.POST("/manual", middleware.RequirePermission("policy:update"), handlers.Cleanup.ManualCleanup)
			cleanup.GET("/logs", middleware.RequirePermission("policy:view"), handlers.Cleanup.GetCleanupLogs)
		}

		// ---------- 任务管理 ----------
		tasks := protected.Group("/tasks")
		{
			tasks.GET("", middleware.RequirePermission("recording:view"), handlers.Task.ListTasks)
			tasks.GET("/:id", middleware.RequirePermission("recording:view"), handlers.Task.GetTask)
			tasks.POST("", middleware.RequirePermission("recording:upload"), handlers.Task.CreateTask)
			tasks.POST("/:id/cancel", middleware.RequirePermission("recording:upload"), handlers.Task.CancelTask)
			tasks.POST("/:id/retry", middleware.RequirePermission("recording:upload"), handlers.Task.RetryTask)
			tasks.DELETE("/:id", middleware.RequirePermission("recording:upload"), handlers.Task.DeleteTask)
			tasks.POST("/batch-status", middleware.RequirePermission("recording:upload"), handlers.Task.BatchUpdateStatus)
		}

		// ---------- 上传任务 ----------
		uploadTasks := protected.Group("/upload-tasks")
		{
			uploadTasks.GET("", handlers.Upload.ListTasks)
		}

		// ---------- 用户管理 ----------
		users := protected.Group("/users")
		{
			users.GET("", middleware.RequirePermission("user:view"), handlers.User.ListUsers)
			users.POST("", middleware.RequirePermission("user:create"), handlers.User.CreateUser)
			users.GET("/:id", middleware.RequirePermission("user:view"), handlers.User.GetUser)
			users.PUT("/:id", middleware.RequirePermission("user:update"), handlers.User.UpdateUser)
			users.DELETE("/:id", middleware.RequirePermission("user:delete"), handlers.User.DeleteUser)
			users.POST("/:id/reset-password", middleware.RequirePermission("user:manage"), handlers.User.ResetPassword)
			users.POST("/:id/roles", middleware.RequirePermission("user:manage"), handlers.User.AssignRole)
			users.DELETE("/:id/roles/:roleId", middleware.RequirePermission("user:manage"), handlers.User.RemoveRole)
		}

		// ---------- 截图管理 ----------
		screenshots := protected.Group("/screenshots")
		{
			screenshots.GET("", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.ListScreenshots)
			screenshots.GET("/:id", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.GetScreenshot)
			screenshots.GET("/:id/image", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.GetScreenshotImage)
			screenshots.GET("/:id/thumbnail", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.GetScreenshotThumbnail)
			screenshots.DELETE("/:id", middleware.RequirePermission("screenshot:delete"), handlers.Screenshot.DeleteScreenshot)
			screenshots.POST("/batch-delete", middleware.RequirePermission("screenshot:delete"), handlers.Screenshot.BatchDeleteScreenshots)
			screenshots.GET("/stats/employee/:deviceId", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.GetEmployeeScreenshotStats)
		}

		// ---------- 个人信息 ----------
		profile := protected.Group("/user")
		{
			profile.GET("/profile", handlers.User.GetProfile)
			profile.PUT("/profile", handlers.User.UpdateProfile)
			profile.POST("/change-password", handlers.User.ChangeOwnPassword)
		}

		// ---------- 角色管理 ----------
		roles := protected.Group("/roles")
		{
			roles.GET("", middleware.RequirePermission("role:view"), handlers.User.GetAllRoles)
			roles.GET("/:id", middleware.RequirePermission("role:view"), handlers.User.GetRole)
			roles.POST("", middleware.RequirePermission("role:create"), handlers.User.CreateRole)
			roles.PUT("/:id", middleware.RequirePermission("role:update"), handlers.User.UpdateRole)
			roles.DELETE("/:id", middleware.RequirePermission("role:delete"), handlers.User.DeleteRole)
		}

		// ---------- 出款与考勤管理 ----------
		admin := protected.Group("/admin")
        {
            // ========== 员工管理 ==========
            admin.GET("/employees", middleware.RequirePermission("attendance:view"), handlers.Admin.GetEmployees)
            admin.POST("/employees", middleware.RequirePermission("attendance:edit"), handlers.Admin.CreateEmployee)
            admin.PUT("/employees/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.UpdateEmployee)
            admin.DELETE("/employees/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.DeleteEmployee)

            // ========== 考勤管理 ==========
            admin.GET("/attendance/records", middleware.RequirePermission("attendance:view"), handlers.Admin.GetAttendanceRecords)
            admin.POST("/attendance/records", middleware.RequirePermission("attendance:edit"), handlers.Admin.SaveAttendanceRecords)
			admin.GET("/attendance/today-absentees", middleware.RequirePermission("attendance:view"), handlers.Admin.GetTodayAbsentees)

            // ========== 绩效管理 ==========
            admin.GET("/performance", middleware.RequirePermission("attendance:view"), handlers.Admin.GetPerformance)
            admin.POST("/performance/batch", middleware.RequirePermission("attendance:edit"), handlers.Admin.BatchSavePerformance)
            // ⭐ 新增：单条绩效修改和删除
            admin.PUT("/performance/:employeeId/:month", middleware.RequirePermission("attendance:edit"), handlers.Admin.UpdatePerformance)
            admin.DELETE("/performance/:employeeId/:month", middleware.RequirePermission("attendance:edit"), handlers.Admin.DeletePerformance)

            // ========== 罚款管理 ==========
            admin.GET("/penalty/records", middleware.RequirePermission("attendance:view"), handlers.Admin.GetPenaltyRecords)
            admin.POST("/penalty/record", middleware.RequirePermission("attendance:edit"), handlers.Admin.CreatePenaltyRecord)
            // ⭐ 新增：罚款修改
            admin.PUT("/penalty/records/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.UpdatePenaltyRecord)
            admin.DELETE("/penalty/records/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.DeletePenaltyRecord)

            // ========== 站点管理 ==========
            admin.GET("/site-stats/sites", middleware.RequirePermission("site:view"), handlers.Admin.GetSites)
            admin.POST("/site-stats/sites", middleware.RequirePermission("site:manage"), handlers.Admin.CreateSite)
            admin.PUT("/site-stats/sites/:id", middleware.RequirePermission("site:manage"), handlers.Admin.UpdateSite)
            admin.DELETE("/site-stats/sites/:id", middleware.RequirePermission("site:manage"), handlers.Admin.DeleteSite)

            // ========== 员工账号管理 ==========
            admin.GET("/site-stats/employee-accounts", middleware.RequirePermission("site:view"), handlers.Admin.GetEmployeeAccounts)
            admin.POST("/site-stats/employee-accounts", middleware.RequirePermission("site:manage"), handlers.Admin.CreateEmployeeAccount)
            admin.PUT("/site-stats/employee-accounts/:id", middleware.RequirePermission("site:manage"), handlers.Admin.UpdateEmployeeAccount)
            admin.DELETE("/site-stats/employee-accounts/:id", middleware.RequirePermission("site:manage"), handlers.Admin.DeleteEmployeeAccount)

            // ========== 出款统计 ==========
            admin.POST("/site-stats/upload/preview", middleware.RequirePermission("stats:edit"), handlers.Admin.PreviewSiteStatsUpload)
            admin.POST("/site-stats/upload", middleware.RequirePermission("stats:edit"), handlers.Admin.UploadSiteStats)
            admin.DELETE("/site-stats/data/clear-by-date", middleware.RequirePermission("stats:edit"), handlers.Admin.ClearSiteStatsByDate)
            admin.DELETE("/site-stats/data/clear", middleware.RequirePermission("stats:edit"), handlers.Admin.ClearAllSiteStats)
            admin.GET("/site-stats/summary", middleware.RequirePermission("stats:view"), handlers.Admin.GetSiteStatsSummary)
            admin.GET("/site-stats/stacked-summary", middleware.RequirePermission("stats:view"), handlers.Admin.GetSiteStatsStacked)
            admin.DELETE("/site-stats/clear-by-date-only", middleware.RequirePermission("stats:edit"), handlers.Admin.ClearSiteStatsByDateOnly)
        }

        // ---------- 工资管理 ----------
        salary := protected.Group("/salary")
        {
            salary.POST("/upload", middleware.RequirePermission("salary:upload"), handlers.Admin.UploadSalary)
            salary.GET("/records", middleware.RequirePermission("salary:view"), handlers.Admin.GetSalaryRecords)
            salary.PUT("/records/:id", middleware.RequirePermission("salary:edit"), handlers.Admin.UpdateSalaryRecord)
            salary.DELETE("/records/:id", middleware.RequirePermission("salary:delete"), handlers.Admin.DeleteSalaryRecord)
            salary.GET("/months", middleware.RequirePermission("salary:view"), handlers.Admin.GetSalaryMonths)
        }

		// ---------- 操作日志管理 ----------
        operationLogs := protected.Group("/operation-logs")
        {
            operationLogs.GET("", middleware.RequirePermission("operation_log:view"), handlers.OperationLog.GetOperationLogs)
            operationLogs.GET("/modules", middleware.RequirePermission("operation_log:view"), handlers.OperationLog.GetOperationModules)
            operationLogs.GET("/types", middleware.RequirePermission("operation_log:view"), handlers.OperationLog.GetOperationTypes)
            operationLogs.GET("/export", middleware.RequirePermission("operation_log:export"), handlers.OperationLog.ExportOperationLogs)
            operationLogs.DELETE("", middleware.RequirePermission("operation_log:delete"), handlers.OperationLog.DeleteOperationLogs)
        }
		
	}

	// ========== ✅ 设备认证接口（使用设备 Token）==========
	deviceProtected := api.Group("")
	deviceProtected.Use(middleware.DeviceAuth(redisClient))
	{
		// 设备验证
		deviceProtected.GET("/devices/:id/verify", handlers.Device.Verify)
		deviceProtected.POST("/devices/heartbeat", handlers.Device.Heartbeat)

		// 策略同步
		deviceProtected.GET("/policies/current", handlers.Policy.GetCurrent)

		// 任务同步（需管理员审核通过）
		deviceProtected.GET("/tasks/pending", middleware.RequireApprovedDevice(deviceRepo), handlers.Task.GetPendingTasks)
		deviceProtected.PUT("/tasks/:id/status", middleware.RequireApprovedDevice(deviceRepo), handlers.Task.UpdateTaskStatus)
		// ✅ 活动日志上报
		deviceProtected.POST("/activities/report", handlers.Activity.ReportActivities)

		// 上传接口已在 public 组以 OptionalAuth 注册，避免重复路由覆盖
	}

	// ========== WebSocket 路由 ==========
	router.GET("/ws/agent", middleware.DeviceAuth(redisClient), handlers.Device.HandleAgentWebSocket)
	router.GET("/ws/admin", middleware.WebSocketAuth(redisClient), handlers.Device.HandleAdminWebSocket)
}

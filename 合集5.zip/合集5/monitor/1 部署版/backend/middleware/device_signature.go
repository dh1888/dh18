package middleware

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/url"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/security"
	"enterprise-agent/backend/services"
)

// VerifyDeviceSignature 使用每设备 device_secret 验证请求签名
// 签名规则： HMACSHA256(timestamp + method + path + bodyHash, deviceSecret)
// Header: X-Device-Id, X-Timestamp, X-Signature
func VerifyDeviceSignature(deviceRepo *services.DeviceRepository) gin.HandlerFunc {
    return func(c *gin.Context) {
        // 读取并恢复请求体
        rawBody, _ := io.ReadAll(c.Request.Body)
        c.Request.Body = io.NopCloser(bytes.NewReader(rawBody))

        // 优先使用 Header
        deviceId := strings.TrimSpace(c.GetHeader("X-Device-Id"))
        timestamp := strings.TrimSpace(c.GetHeader("X-Timestamp"))
        signature := strings.TrimSpace(c.GetHeader("X-Signature"))
        nonce := strings.TrimSpace(c.GetHeader("X-Nonce"))

        // 兼容：尝试从 body 中解析 deviceId/timestamp/signature
        if deviceId == "" || timestamp == "" || signature == "" {
            var probe struct {
                DeviceId  string `json:"deviceId"`
                Timestamp string `json:"timestamp"`
                Signature string `json:"signature"`
                Nonce     string `json:"nonce"`
            }
            _ = json.Unmarshal(rawBody, &probe)
            if deviceId == "" {
                deviceId = probe.DeviceId
            }
            if timestamp == "" {
                timestamp = probe.Timestamp
            }
            if signature == "" {
                signature = probe.Signature
            }
            if nonce == "" {
                nonce = probe.Nonce
            }
        }

        if nonce == "" {
            models.SendError(c, 401, 1002, "missing nonce")
            c.Abort()
            return
        }

        // 不允许缺失签名（已结束兼容放行）
        if signature == "" {
            models.SendError(c, 401, 1002, "missing signature")
            c.Abort()
            return
        }

        if deviceId == "" {
            models.SendError(c, 401, 1002, "missing device id")
            c.Abort()
            return
        }

        // 解析时间戳（RFC3339）并验证 ±300s
        ts, err := time.Parse(time.RFC3339, timestamp)
        if err != nil {
            models.SendError(c, 401, 1002, "invalid timestamp format")
            c.Abort()
            return
        }
        now := time.Now().UTC()
        if now.Sub(ts) > 5*time.Minute || ts.Sub(now) > 5*time.Minute {
            models.SendError(c, 401, 1002, "timestamp expired")
            c.Abort()
            return
        }

        // 获取 device secret（deviceId 可能是 UUID 或 fingerprint）
        var dev *models.Device
        if _, err := uuid.Parse(deviceId); err == nil {
            // UUID 格式
            id, _ := uuid.Parse(deviceId)
            dev, err = deviceRepo.Get(c.Request.Context(), id)
            if err != nil {
                models.SendError(c, 500, 5000, "failed to query device")
                c.Abort()
                return
            }
        } else {
            dev, err = deviceRepo.GetByDeviceId(c.Request.Context(), deviceId)
            if err != nil {
                models.SendError(c, 500, 5000, "failed to query device")
                c.Abort()
                return
            }
        }

        if dev == nil || strings.TrimSpace(dev.DeviceSecret) == "" {
            models.SendError(c, 401, 1002, "device secret not configured")
            c.Abort()
            return
        }

        if strings.ToLower(strings.TrimSpace(dev.Status)) != "approved" {
            models.SendError(c, 403, 1003, "device not approved for upload")
            c.Abort()
            return
        }

        if signatureNonceStore != nil {
            nonceKey := deviceId + ":" + nonce
            if err := signatureNonceStore.CheckAndStore(nonceKey); err != nil {
                if err == security.ErrNonceReused {
                    models.SendError(c, 401, 1002, "nonce already used")
                } else {
                    models.SendError(c, 401, 1002, "invalid nonce")
                }
                c.Abort()
                return
            }
        }

        // 计算 bodyHash
        bodyHash := sha256.Sum256(rawBody)
        bodyHashHex := hex.EncodeToString(bodyHash[:])

        // 计算 path（使用原始路径，不含 host/query）
        path := c.Request.URL.Path
        if u, err := url.PathUnescape(path); err == nil {
            path = u
        }

        message := timestamp + c.Request.Method + path + bodyHashHex

        mac := hmac.New(sha256.New, []byte(dev.DeviceSecret))
        _, _ = mac.Write([]byte(message))
        expected := hex.EncodeToString(mac.Sum(nil))

        if !hmac.Equal([]byte(strings.ToLower(expected)), []byte(strings.ToLower(signature))) {
            models.SendError(c, 401, 1002, "invalid signature")
            c.Abort()
            return
        }

        // 验证通过，设置 deviceID 到 context（UUID 字符串）
        if dev.ID != uuid.Nil {
            c.Set("deviceID", dev.ID.String())
        }
        // Set signature version for reference
        c.Set("signatureVersion", "v1")
        c.Next()
    }
}

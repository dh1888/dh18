// backend/middleware/signature_monitoring.go
// Signature verification monitoring and observability

package middleware

import (
	"sync"
	"sync/atomic"
	"time"
)

// SignatureMetrics tracks signature verification metrics
type SignatureMetrics struct {
	SuccessCount         int64     // 签名验证成功计数
	FailureCount         int64     // 签名验证失败计数
	MissingSecretCount   int64     // device_secret 缺失或为空计数
	TimestampRejectedCount int64   // 时间戳超过 ±5 分钟计数
	InvalidFormatCount   int64     // 无效格式计数
	LastUpdateTime       time.Time // 最后更新时间
	mu                   sync.RWMutex
}

var globalSignatureMetrics = &SignatureMetrics{
	LastUpdateTime: time.Now(),
}

// RecordSuccess 记录验证成功
func RecordSignatureSuccess() {
	atomic.AddInt64(&globalSignatureMetrics.SuccessCount, 1)
	globalSignatureMetrics.mu.Lock()
	globalSignatureMetrics.LastUpdateTime = time.Now()
	globalSignatureMetrics.mu.Unlock()
}

// RecordFailure 记录验证失败
func RecordSignatureFailure(reason string) {
	atomic.AddInt64(&globalSignatureMetrics.FailureCount, 1)
	globalSignatureMetrics.mu.Lock()
	globalSignatureMetrics.LastUpdateTime = time.Now()
	globalSignatureMetrics.mu.Unlock()
}

// RecordMissingSecret 记录缺失 secret
func RecordMissingSecret() {
	atomic.AddInt64(&globalSignatureMetrics.MissingSecretCount, 1)
}

// RecordTimestampRejected 记录时间戳被拒绝
func RecordTimestampRejected() {
	atomic.AddInt64(&globalSignatureMetrics.TimestampRejectedCount, 1)
}

// RecordInvalidFormat 记录无效格式
func RecordInvalidFormat() {
	atomic.AddInt64(&globalSignatureMetrics.InvalidFormatCount, 1)
}

// GetMetrics 获取当前指标快照
func GetSignatureMetrics() SignatureMetrics {
	globalSignatureMetrics.mu.RLock()
	defer globalSignatureMetrics.mu.RUnlock()
	
	return SignatureMetrics{
		SuccessCount:           atomic.LoadInt64(&globalSignatureMetrics.SuccessCount),
		FailureCount:           atomic.LoadInt64(&globalSignatureMetrics.FailureCount),
		MissingSecretCount:     atomic.LoadInt64(&globalSignatureMetrics.MissingSecretCount),
		TimestampRejectedCount: atomic.LoadInt64(&globalSignatureMetrics.TimestampRejectedCount),
		InvalidFormatCount:     atomic.LoadInt64(&globalSignatureMetrics.InvalidFormatCount),
		LastUpdateTime:         globalSignatureMetrics.LastUpdateTime,
	}
}

// ResetMetrics 重置指标（用于测试）
func ResetSignatureMetrics() {
	atomic.StoreInt64(&globalSignatureMetrics.SuccessCount, 0)
	atomic.StoreInt64(&globalSignatureMetrics.FailureCount, 0)
	atomic.StoreInt64(&globalSignatureMetrics.MissingSecretCount, 0)
	atomic.StoreInt64(&globalSignatureMetrics.TimestampRejectedCount, 0)
	atomic.StoreInt64(&globalSignatureMetrics.InvalidFormatCount, 0)
}

// IsHealthy 检查签名系统是否健康
// 如果失败率 > 5%，视为不健康
func IsSignatureSystemHealthy() bool {
	metrics := GetSignatureMetrics()
	total := metrics.SuccessCount + metrics.FailureCount
	
	if total == 0 {
		return true // 无样本
	}
	
	failureRate := float64(metrics.FailureCount) / float64(total)
	return failureRate < 0.05 // 5% 阈值
}

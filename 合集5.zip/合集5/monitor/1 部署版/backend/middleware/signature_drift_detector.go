// backend/middleware/signature_drift_detector.go
// Signature drift detection mechanism (runs at startup and periodically)

package middleware

import (
	"fmt"
	"strings"

	"enterprise-agent/backend/signature"
)

// SignatureDriftDetector 漂移检测器
type SignatureDriftDetector struct {
	logger interface {
		Infof(format string, args ...interface{})
		Errorf(format string, args ...interface{})
	}
}

// NewSignatureDriftDetector 创建新的漂移检测器
func NewSignatureDriftDetector(logger interface {
	Infof(format string, args ...interface{})
	Errorf(format string, args ...interface{})
}) *SignatureDriftDetector {
	return &SignatureDriftDetector{logger: logger}
}

// DetectV1Drift 检测 v1 签名是否漂移
// 通过比较 Go 当前实现与冻结的 test vectors
func (d *SignatureDriftDetector) DetectV1Drift() (hasDrift bool, diffs []string) {
	vectors := signature.GetV1TestVectors()
	
	// 只检查前 3 个已验证的向量
	expectedCSharpOutputs := map[string]string{
		"POST upload chunk with JSON":      "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
		"POST upload complete":             "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
		"GET device verify with empty body": "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d",
	}
	
	for i, vec := range vectors {
		if i >= 3 {
			break // 只检查前 3 个
		}
		
		computed := signature.ComputeSignatureV1(
			vec.Timestamp, vec.Method, vec.Path, []byte(vec.Body), vec.DeviceSecret,
		)
		expected := expectedCSharpOutputs[vec.Name]
		
		if computed != expected {
			hasDrift = true
			diffs = append(diffs, fmt.Sprintf(
				"DRIFT DETECTED: %s\n  Expected (C#): %s\n  Got (Go):      %s",
				vec.Name, expected, computed,
			))
		}
	}
	
	return
}

// RunOnStartup 在应用启动时执行漂移检测
// 如果检测到漂移，将阻止应用启动
func (d *SignatureDriftDetector) RunOnStartup() error {
	d.logger.Infof("[STARTUP] Running v1 signature drift detection...")
	
	hasDrift, diffs := d.DetectV1Drift()
	
	if hasDrift {
		errMsg := fmt.Sprintf("CRITICAL: Signature drift detected on %d test vectors:\n%s",
			len(diffs), strings.Join(diffs, "\n"))
		d.logger.Errorf(errMsg)
		return fmt.Errorf(errMsg)
	}
	
	d.logger.Infof("[STARTUP] ✓ Signature drift detection PASSED (3/3 vectors match)")
	return nil
}

// CheckPeriodicDrift 周期性检查漂移（可在后台运行）
func (d *SignatureDriftDetector) CheckPeriodicDrift() {
	hasDrift, diffs := d.DetectV1Drift()
	
	if hasDrift {
		d.logger.Errorf("[PERIODIC] ALERT: Signature drift detected:\n%s",
			strings.Join(diffs, "\n"))
		// 可选：发送告警到监控系统
	}
}

// backend/middleware/signature_safety_checks.go
// Runtime signature safety checks to prevent drift

package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"
)

// SafetyCheckSignaturePrerequisites 在签名验证前执行安全检查
// 返回 true 表示通过安全检查，false 表示应该拒绝请求
func SafetyCheckSignaturePrerequisites(c *gin.Context, logger interface {
	Warnf(format string, args ...interface{})
	Errorf(format string, args ...interface{})
}) bool {
	// 检查 1: Non-UTF-8 encoding（高风险）
	contentType := c.GetHeader("Content-Type")
	if strings.Contains(contentType, "charset=") {
		if !strings.Contains(strings.ToLower(contentType), "charset=utf-8") &&
			!strings.Contains(strings.ToLower(contentType), "charset=utf8") {
			logger.Errorf("Non-UTF-8 encoding detected: %s (will reject)", contentType)
			return false // 拒绝非 UTF-8
		}
	}

	// 检查 2: Path modification by proxy（记录但不拒绝）
	if originalURI := c.GetHeader("X-Original-URI"); originalURI != "" {
		if originalURI != c.Request.RequestURI {
			logger.Warnf("Path potentially modified by proxy: %s -> %s",
				originalURI, c.Request.RequestURI)
		}
	}

	// 检查 3: Forwarded header（记录代理链）
	if forwarded := c.GetHeader("X-Forwarded-For"); forwarded != "" {
		logger.Warnf("Request forwarded through proxy chain: %s", forwarded)
	}

	// 检查 4: Empty body for POST/PUT（警告但不拒绝）
	if (c.Request.Method == "POST" || c.Request.Method == "PUT") &&
		c.Request.ContentLength <= 0 {
		logger.Warnf("Empty or missing Content-Length for %s request", c.Request.Method)
	}

	return true
}

// ValidateBodyHashConsistency 验证 body 是否被修改
// 在验证前后计算 hash，确保一致
func ValidateBodyHashConsistency(bodyBefore, bodyAfter []byte, logger interface {
	Errorf(format string, args ...interface{})
}) bool {
	if len(bodyBefore) != len(bodyAfter) {
		logger.Errorf("Body size changed: %d -> %d bytes (potential middleware tampering)",
			len(bodyBefore), len(bodyAfter))
		return false
	}

	// 简单字节对比（不计算 hash，节省 CPU）
	for i := 0; i < len(bodyBefore); i++ {
		if bodyBefore[i] != bodyAfter[i] {
			logger.Errorf("Body content changed at byte %d (potential middleware tampering)", i)
			return false
		}
	}

	return true
}

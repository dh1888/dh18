package middleware

import (
	"time"

	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/security"
)

var signatureNonceStore *security.DistributedNonceStore

// InitSignatureNonceStore 初始化签名 nonce 防重放缓存
func InitSignatureNonceStore(redisClient *redis.Client) {
	signatureNonceStore = security.NewDistributedNonceStore(redisClient, 10*time.Minute)
}

// CloseSignatureNonceStore 关闭 nonce 缓存
func CloseSignatureNonceStore() {
	if signatureNonceStore != nil {
		_ = signatureNonceStore.Close()
	}
}

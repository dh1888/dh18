// upload_session_store.go - 上传会话 Redis 持久化（多实例元数据共享）

package handlers

import (
	"context"
	"encoding/json"
	"log"
	"time"

	"github.com/redis/go-redis/v9"
)

const uploadSessionRedisPrefix = "upload:session:"

// uploadSessionData 可序列化的会话元数据（分块文件仍存本地临时目录）。
type uploadSessionData struct {
	UploadID       string         `json:"uploadId"`
	FileName       string         `json:"fileName"`
	FileType       string         `json:"fileType"`
	FileID         string         `json:"fileId"`
	TotalChunks    int            `json:"totalChunks"`
	Received       map[int]bool   `json:"received"`
	ChunkChecksums map[int]string `json:"chunkChecksums"`
	LastActive     time.Time      `json:"lastActive"`
	TotalSize      int64          `json:"totalSize"`
	Completed      bool           `json:"completed"`
	Completing     bool           `json:"completing"`
	CompletedAt    time.Time      `json:"completedAt,omitempty"`
}

var uploadSessionRedis *redis.Client

// InitUploadSessionStore 注入 Redis；为 nil 时仅使用进程内内存（单实例模式）。
func InitUploadSessionStore(client *redis.Client) {
	uploadSessionRedis = client
	if client != nil {
		log.Println("[UploadSession] Redis-backed session metadata enabled")
	} else {
		log.Println("[UploadSession] In-memory session store only (single instance)")
	}
}

func uploadSessionRedisKey(uploadID string) string {
	return uploadSessionRedisPrefix + uploadID
}

func (s *uploadSession) toData() *uploadSessionData {
	s.mu.RLock()
	defer s.mu.RUnlock()

	received := make(map[int]bool, len(s.Received))
	for k, v := range s.Received {
		received[k] = v
	}
	checksums := make(map[int]string, len(s.ChunkChecksums))
	for k, v := range s.ChunkChecksums {
		checksums[k] = v
	}

	return &uploadSessionData{
		UploadID:       s.UploadID,
		FileName:       s.FileName,
		FileType:       s.FileType,
		FileID:         s.FileID,
		TotalChunks:    s.TotalChunks,
		Received:       received,
		ChunkChecksums: checksums,
		LastActive:     s.LastActive,
		TotalSize:      s.TotalSize,
		Completed:      s.Completed,
		Completing:     s.Completing,
		CompletedAt:    s.CompletedAt,
	}
}

func uploadSessionFromData(d *uploadSessionData) *uploadSession {
	if d == nil {
		return nil
	}
	received := d.Received
	if received == nil {
		received = make(map[int]bool)
	}
	checksums := d.ChunkChecksums
	if checksums == nil {
		checksums = make(map[int]string)
	}
	return &uploadSession{
		UploadID:       d.UploadID,
		FileName:       d.FileName,
		FileType:       d.FileType,
		FileID:         d.FileID,
		TotalChunks:    d.TotalChunks,
		Received:       received,
		ChunkChecksums: checksums,
		LastActive:     d.LastActive,
		TotalSize:      d.TotalSize,
		Completed:      d.Completed,
		Completing:     d.Completing,
		CompletedAt:    d.CompletedAt,
	}
}

func (m *uploadSessionManager) persistSession(session *uploadSession) {
	if uploadSessionRedis == nil || session == nil {
		return
	}

	data := session.toData()
	payload, err := json.Marshal(data)
	if err != nil {
		log.Printf("[UploadSession] Failed to marshal session %s: %v", session.UploadID, err)
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	key := uploadSessionRedisKey(session.UploadID)
	if err := uploadSessionRedis.Set(ctx, key, payload, sessionTTL).Err(); err != nil {
		log.Printf("[UploadSession] Failed to persist session %s to Redis: %v", session.UploadID, err)
	}
}

func (m *uploadSessionManager) loadSessionFromRedis(uploadID string) (*uploadSession, bool) {
	if uploadSessionRedis == nil {
		return nil, false
	}

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	payload, err := uploadSessionRedis.Get(ctx, uploadSessionRedisKey(uploadID)).Bytes()
	if err != nil {
		return nil, false
	}

	var data uploadSessionData
	if err := json.Unmarshal(payload, &data); err != nil {
		log.Printf("[UploadSession] Failed to unmarshal session %s: %v", uploadID, err)
		return nil, false
	}

	return uploadSessionFromData(&data), true
}

func (m *uploadSessionManager) removeSessionFromRedis(uploadID string) {
	if uploadSessionRedis == nil {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	if err := uploadSessionRedis.Del(ctx, uploadSessionRedisKey(uploadID)).Err(); err != nil {
		log.Printf("[UploadSession] Failed to delete session %s from Redis: %v", uploadID, err)
	}
}

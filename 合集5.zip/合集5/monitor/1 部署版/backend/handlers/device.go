// backend/handlers/device.go
package handlers

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

const deviceRefreshTokenTTL = 30 * 24 * time.Hour

func deviceRefreshRedisKey(token string) string {
	return "device_refresh:" + token
}

type DeviceHandler struct {
	repo  *services.DeviceRepository
	wsHub *services.WebSocketHub
	redis *redis.Client
}

func NewDeviceHandler(repo *services.DeviceRepository, wsHub *services.WebSocketHub, redisClient *redis.Client) *DeviceHandler {
	return &DeviceHandler{repo: repo, wsHub: wsHub, redis: redisClient}
}

// List 获取设备列表（支持多条件筛选和分页）
// List 获取设备列表（支持多条件筛选和分页）
func (h *DeviceHandler) List(c *gin.Context) {
    // 解析分页参数
    page, err := strconv.Atoi(c.DefaultQuery("page", "1"))
    if err != nil || page < 1 {
        page = 1
    }
    
    pageSize, err := strconv.Atoi(c.DefaultQuery("pageSize", "20"))
    if err != nil || pageSize < 1 {
        pageSize = 20
    }
    if pageSize > 100 {
        pageSize = 100
    }
    
    // 筛选参数
    status := c.Query("status")                    // 审核状态: pending, approved
    employeeSearch := c.Query("employeeSearch")    // 员工搜索（姓名/工号/职位）
    deviceStatus := c.Query("deviceStatus")        // 设备状态: pending, approved_online, approved_offline
    keyword := c.Query("keyword")                  // 设备名称搜索

    // ✅ 使用结构体参数
    opts := services.DeviceListOptions{
        Page:           page,
        PageSize:       pageSize,
        Status:         status,
        EmployeeSearch: employeeSearch,
        DeviceStatus:   deviceStatus,
        Keyword:        keyword,
    }

    devices, total, err := h.repo.List(c.Request.Context(), opts)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // 动态计算在线状态
    for i := range devices {
        devices[i].OnlineStatus = devices[i].GetOnlineStatus()
    }

    models.Send(c, 200, 0, "success", gin.H{
        "items":    devices,
        "total":    total,
        "page":     page,
        "pageSize": pageSize,
    })
}

// Get 获取设备详情
func (h *DeviceHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	device, err := h.repo.Get(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Device not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", device)
}

// Bind 绑定设备到员工
func (h *DeviceHandler) Bind(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	var req struct {
		EmployeeID     string `json:"employeeId" binding:"required"`
		EmployeeName   string `json:"employeeName"`
		EmployeeNumber string `json:"employeeNumber"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: employeeId required")
		return
	}

	if err := h.repo.Bind(c.Request.Context(), id, req.EmployeeID, req.EmployeeName, req.EmployeeNumber); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// 广播设备状态变更
	h.wsHub.BroadcastToAdmin(gin.H{
		"type":       "device_status",
		"deviceId":   id.String(),
		"status":     "bound",
		"employeeId": req.EmployeeID,
		"timestamp":  models.FormatUTC(models.UTCNow()),
	})

	models.Send(c, 200, 0, "Device bound successfully", nil)
}

// Unbind 解绑设备
func (h *DeviceHandler) Unbind(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	if err := h.repo.Unbind(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// 广播设备状态变更
	h.wsHub.BroadcastToAdmin(gin.H{
		"type":      "device_status",
		"deviceId":  id.String(),
		"status":    "unbound",
		"timestamp": models.FormatUTC(models.UTCNow()),
	})

	models.Send(c, 200, 0, "Device unbound successfully", nil)
}

// UpdateStatus 更新设备审核状态
func (h *DeviceHandler) UpdateStatus(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	var req struct {
		Status string `json:"status" binding:"required,oneof=pending approved rejected"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: status must be pending/approved/rejected")
		return
	}

	if err := h.repo.UpdateStatus(c.Request.Context(), id, req.Status); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	if req.Status == "approved" {
		h.wsHub.BroadcastToAgent(id.String(), gin.H{
			"type":      "device_approved",
			"deviceId":  id.String(),
			"status":    "approved",
			"timestamp": models.FormatUTC(models.UTCNow()),
		})
	} else if req.Status == "rejected" {
		h.wsHub.BroadcastToAgent(id.String(), gin.H{
			"type":      "device_rejected",
			"deviceId":  id.String(),
			"status":    "rejected",
			"timestamp": models.FormatUTC(models.UTCNow()),
		})
	}

	models.Send(c, 200, 0, "Status updated", nil)
}

// OnlineStats 获取在线统计
func (h *DeviceHandler) OnlineStats(c *gin.Context) {
	online, offline, err := h.repo.GetOnlineStats(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"online":  online,
		"offline": offline,
		"total":   online + offline,
	})
}

// Register 设备注册
func (h *DeviceHandler) Register(c *gin.Context) {
	var req struct {
		DeviceId     string            `json:"deviceId" binding:"required"`
		Hostname     string            `json:"hostname"`
		OsVersion    string            `json:"osVersion"`
		AgentVersion string            `json:"agentVersion"`
		Fingerprint  map[string]string `json:"fingerprint"`
		PublicKey    string            `json:"publicKey"`
		// ✅ 新增：员工信息字段
		Employee *struct {
			Name           string `json:"name"`
			EmployeeNumber string `json:"employeeNumber"`
		} `json:"employee,omitempty"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request: deviceId required")
		return
	}

	existing, _ := h.repo.GetByDeviceId(c.Request.Context(), req.DeviceId)
	var deviceID uuid.UUID
	var isNew bool

	// ✅ 提取员工信息
	var employeeID, employeeName, employeeNumber string
	if req.Employee != nil {
		employeeName = req.Employee.Name
		employeeNumber = req.Employee.EmployeeNumber
		// 生成员工ID（可以使用工号或者UUID）
		if employeeNumber != "" {
			employeeID = employeeNumber
		} else {
			employeeID = uuid.New().String()
		}
	}

	if existing == nil {
		boundAt := models.UTCNow()
		var err error
		// 生成 device secret（32 字节随机 hex）
		secretBytes := make([]byte, 32)
		if _, err := rand.Read(secretBytes); err != nil {
			models.SendError(c, 500, 5000, "failed to generate device secret")
			return
		}
		secretHex := hex.EncodeToString(secretBytes)

		deviceID, err = h.repo.Create(c.Request.Context(), &models.Device{
			DeviceFingerprint: req.DeviceId,
			Hostname:          req.Hostname,
			OSVersion:         req.OsVersion,
			AgentVersion:      req.AgentVersion,
			EmployeeID:        employeeID,
			EmployeeName:      employeeName,
			EmployeeNumber:    employeeNumber,
			Status:            "pending",
			BoundAt:           &boundAt,
			DeviceSecret:      secretHex,
		})
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		isNew = true
	} else {
		deviceID = existing.ID
		if err := h.repo.UpdateInfo(c.Request.Context(), deviceID, req.Hostname, req.OsVersion, req.AgentVersion); err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}

		// 如果已有设备但未配置 device secret，则生成并持久化
		if strings.TrimSpace(existing.DeviceSecret) == "" {
			b := make([]byte, 32)
			if _, err := rand.Read(b); err == nil {
				secretHex := hex.EncodeToString(b)
				_ = h.repo.UpdateSecret(c.Request.Context(), deviceID, secretHex)
			}
		}
		// ✅ 更新员工信息
		if employeeName != "" || employeeNumber != "" {
			if err := h.repo.UpdateEmployeeInfo(c.Request.Context(), deviceID, employeeID, employeeName, employeeNumber, ""); err != nil {
				models.SendError(c, 500, 5000, err.Error())
				return
			}
		}
		// 更新最后在线时间
		deviceIDCopy := deviceID
		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			_ = h.repo.UpdateLastSeen(ctx, deviceIDCopy)
		}()
	}

	// 生成设备 token
	token := generateDeviceToken(deviceID.String())
	refreshToken := uuid.New().String()

	if h.redis == nil {
		log.Printf("Error: Redis unavailable, cannot issue refresh token")
		models.SendError(c, 500, 5000, "Refresh token store unavailable")
		return
	}

	if err := h.redis.Set(
		c.Request.Context(),
		deviceRefreshRedisKey(refreshToken),
		deviceID.String(),
		deviceRefreshTokenTTL,
	).Err(); err != nil {
		log.Printf("Failed to store device refresh token: %v", err)
		models.SendError(c, 500, 5000, "Failed to store refresh token")
		return
	}

	// 广播新设备注册
	if isNew {
		h.wsHub.BroadcastToAdmin(gin.H{
			"type":     "device_registered",
			"deviceId": deviceID.String(),
			"hostname": req.Hostname,
			"employee": gin.H{
				"name":   employeeName,
				"number": employeeNumber,
			},
			"timestamp": models.FormatUTC(models.UTCNow()),
		})
	}

	// 返回 deviceSecret 给客户端（新注册或已存在设备都返回）
	var respSecret string
	var respStatus string
	if d, err := h.repo.Get(c.Request.Context(), deviceID); err == nil && d != nil {
		respSecret = d.DeviceSecret
		respStatus = d.Status
	}

	tokenExpiresAt := models.UTCNow().Add(7 * 24 * time.Hour)
	models.Send(c, 200, 0, "success", gin.H{
		"deviceId":     deviceID.String(),
		"deviceSecret": respSecret,
		"status":       respStatus,
		"token":        token,
		"refreshToken": refreshToken,
		"expiresAt":    models.FormatUTC(tokenExpiresAt),
	})
}

// Refresh 使用设备 refresh token 轮换访问令牌
func (h *DeviceHandler) Refresh(c *gin.Context) {
	var req struct {
		RefreshToken string `json:"refreshToken"`
		DeviceId     string `json:"deviceId"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	req.RefreshToken = strings.TrimSpace(req.RefreshToken)
	req.DeviceId = strings.TrimSpace(req.DeviceId)
	if req.RefreshToken == "" || req.DeviceId == "" {
		models.SendError(c, 400, 1001, "refreshToken and deviceId are required")
		return
	}

	if h.redis == nil {
		models.SendError(c, 500, 5000, "Refresh token store unavailable")
		return
	}

	deviceID, err := h.redis.Get(c.Request.Context(), deviceRefreshRedisKey(req.RefreshToken)).Result()
	if err != nil {
		models.SendError(c, 401, 1002, "Invalid refresh token")
		return
	}

	if !strings.EqualFold(deviceID, req.DeviceId) {
		models.SendError(c, 401, 1002, "Device ID mismatch")
		return
	}

	parsedDeviceID, err := uuid.Parse(deviceID)
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	if _, err := h.repo.Get(c.Request.Context(), parsedDeviceID); err != nil {
		models.SendError(c, 401, 1002, "Device not found")
		return
	}

	token := generateDeviceToken(deviceID)
	newRefreshToken := uuid.New().String()
	expiresAt := models.UTCNow().Add(7 * 24 * time.Hour)

	pipe := h.redis.Pipeline()
	pipe.Del(c.Request.Context(), deviceRefreshRedisKey(req.RefreshToken))
	pipe.Set(c.Request.Context(), deviceRefreshRedisKey(newRefreshToken), deviceID, deviceRefreshTokenTTL)
	if _, err := pipe.Exec(c.Request.Context()); err != nil {
		log.Printf("Failed to rotate device refresh token: %v", err)
		models.SendError(c, 500, 5000, "Failed to rotate refresh token")
		return
	}

	models.Send(c, 200, 0, "success", gin.H{
		"token":        token,
		"refreshToken": newRefreshToken,
		"expiresAt":    models.FormatUTC(expiresAt),
	})
}

// Verify 验证设备（需要设备认证）
func (h *DeviceHandler) Verify(c *gin.Context) {
	// 从认证中间件获取设备 ID
	deviceIDFromToken := c.GetString("deviceID")
	if deviceIDFromToken == "" {
		models.SendError(c, 401, 1002, "Device not authenticated")
		return
	}

	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	// 验证 URL 中的设备 ID 与 token 中的一致
	if deviceIDFromToken != id.String() {
		models.SendError(c, 403, 1003, "Device ID mismatch")
		return
	}

	device, err := h.repo.Get(c.Request.Context(), id)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "Device not found")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	// 异步更新最后在线时间
	go func() {
		_ = h.repo.UpdateLastSeen(c.Request.Context(), id)
	}()

	// ✅ 修复：处理指针类型的时间字段
	boundAtStr := ""
	if device.BoundAt != nil {
		boundAtStr = models.FormatUTC(*device.BoundAt)
	}

	models.Send(c, 200, 0, "verified", gin.H{
		"deviceId":   device.ID.String(),
		"status":     device.Status,
		"employeeId": device.EmployeeID,
		"boundAt":    boundAtStr,
	})
}

// ReportInfo 上报设备信息（支持 UUID 或 device_fingerprint）
func (h *DeviceHandler) ReportInfo(c *gin.Context) {
	var req struct {
		DeviceId        string `json:"deviceId" binding:"required"`
		Hostname        string `json:"hostname"`
		OsVersion       string `json:"osVersion"`
		AgentVersion    string `json:"agentVersion"`
		ProcessorCount  int    `json:"processorCount"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	var device *models.Device
	var err error

	if id, parseErr := uuid.Parse(req.DeviceId); parseErr == nil {
		device, err = h.repo.Get(c.Request.Context(), id)
	} else {
		device, err = h.repo.GetByDeviceId(c.Request.Context(), req.DeviceId)
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if device == nil {
		models.SendError(c, 404, 2001, "Device not found")
		return
	}

	if err := h.repo.UpdateInfo(c.Request.Context(), device.ID, req.Hostname, req.OsVersion, req.AgentVersion); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	go func() {
		_ = h.repo.UpdateLastSeen(c.Request.Context(), device.ID)
	}()

	models.Send(c, 200, 0, "info reported", nil)
}

// UpdateEmployee 更新设备员工信息
func (h *DeviceHandler) UpdateEmployee(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	var req struct {
		EmployeeID     string `json:"employeeId"`
		EmployeeName   string `json:"employeeName"`
		EmployeeNumber string `json:"employeeNumber"`
		Position       string `json:"position"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request payload")
		return
	}

	if err := h.repo.UpdateEmployeeInfo(c.Request.Context(), id, req.EmployeeID, req.EmployeeName, req.EmployeeNumber, req.Position); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "Employee information updated", nil)
}

func (h *DeviceHandler) Heartbeat(c *gin.Context) {
	deviceIDFromToken := c.GetString("deviceID")
	if deviceIDFromToken == "" {
		models.SendError(c, 401, 1002, "Device not authenticated")
		return
	}

	id, err := uuid.Parse(deviceIDFromToken)
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid device ID")
		return
	}

	if err := h.repo.UpdateLastSeen(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	models.Send(c, 200, 0, "pong", nil)
}

// HandleAgentWebSocket Agent WebSocket 连接
func (h *DeviceHandler) HandleAgentWebSocket(c *gin.Context) {
    // ✅ 修改：从认证中间件获取设备 ID
    deviceIDFromToken := c.GetString("deviceID")
    if deviceIDFromToken == "" {
        models.SendError(c, 401, 1002, "Device not authenticated")
        return
    }
    
    // ✅ 使用 token 中的 deviceID 而不是 query 参数
    h.wsHub.HandleAgentWithDeviceID(c, deviceIDFromToken)
}

// HandleAdminWebSocket Admin WebSocket 连接
func (h *DeviceHandler) HandleAdminWebSocket(c *gin.Context) {
	h.wsHub.HandleAdmin(c)
}

// ========== 辅助函数 ==========

// generateDeviceToken 生成设备 JWT token
func generateDeviceToken(deviceID string) string {
    // 改为 7 天
    expiresAt := models.UTCNow().Add(7 * 24 * time.Hour)
    claims := &models.DeviceClaims{
        DeviceID: deviceID,
        RegisteredClaims: jwt.RegisteredClaims{
            ExpiresAt: jwt.NewNumericDate(expiresAt),
            IssuedAt:  jwt.NewNumericDate(models.UTCNow()),
            NotBefore: jwt.NewNumericDate(models.UTCNow()),
        },
    }
    token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
    secret := models.JWTSecret()
    if len(secret) == 0 {
        return ""
    }
    tokenString, err := token.SignedString(secret)
    if err != nil {
        return ""
    }
    return tokenString
}

// ExportEmployees 导出员工信息
func (h *DeviceHandler) ExportEmployees(c *gin.Context) {
	// ✅ 修复：使用结构体参数调用新的 List 方法
	opts := services.DeviceListOptions{
		Page:     1,
		PageSize: 10000,
		Status:   "", // 不过滤审核状态
		// 其他筛选条件为空，表示不过滤
	}

	devices, _, err := h.repo.List(c.Request.Context(), opts)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	var builder strings.Builder
	builder.WriteString("设备ID,设备指纹,员工ID,员工姓名,工号,主机名,操作系统,状态,绑定时间,最后在线时间,注册时间\n")

	for _, d := range devices {
		boundAt := ""
		if d.BoundAt != nil {
			boundAt = d.BoundAt.Format(time.RFC3339)
		}
		lastSeen := ""
		if d.LastSeenAt != nil {
			lastSeen = d.LastSeenAt.Format(time.RFC3339)
		}
		builder.WriteString(fmt.Sprintf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
			d.ID.String(), d.DeviceFingerprint, d.EmployeeID, d.EmployeeName, d.EmployeeNumber,
			d.Hostname, d.OSVersion, d.Status, boundAt, lastSeen, d.CreatedAt.Format(time.RFC3339)))
	}

	c.Header("Content-Type", "text/csv; charset=utf-8")
	c.Header("Content-Disposition", "attachment; filename=employees.csv")
	c.String(200, builder.String())
}
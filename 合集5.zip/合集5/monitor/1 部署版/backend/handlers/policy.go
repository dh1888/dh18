package handlers

import (
	"encoding/json"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
	"enterprise-agent/backend/services"
)

type PolicyHandler struct {
	repo  *services.PolicyRepository
	wsHub *services.WebSocketHub
}

func NewPolicyHandler(repo *services.PolicyRepository, wsHub *services.WebSocketHub) *PolicyHandler {
	return &PolicyHandler{repo: repo, wsHub: wsHub}
}

func (h *PolicyHandler) List(c *gin.Context) {
	policies, err := h.repo.List(c.Request.Context())
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", policies)
}

func (h *PolicyHandler) GetCurrent(c *gin.Context) {
	policy, err := h.repo.GetCurrent(c.Request.Context())
	if err != nil {
		models.SendError(c, 404, 2001, "No policy found")
		return
	}

	freshSignature := models.SignPolicyContent(policy.Content)
	if freshSignature != "" && freshSignature != policy.Signature {
		policy.Signature = freshSignature
		_ = h.repo.UpdateSignature(c.Request.Context(), policy.ID, freshSignature)
	}

	models.Send(c, 200, 0, "success", policy)
}

func (h *PolicyHandler) Create(c *gin.Context) {
	var req struct {
		Name    string          `json:"name"`
		Content json.RawMessage `json:"content"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if len(req.Content) == 0 {
		models.SendError(c, 400, 1001, "Policy content is required")
		return
	}

	var typedContent models.PolicyContent
	if err := json.Unmarshal(req.Content, &typedContent); err != nil {
		models.SendError(c, 400, 1001, "Invalid policy content")
		return
	}

	signature := calculateSignature(req.Content)
	policy := &models.Policy{
		ID:        uuid.New(),
		Name:      req.Name,
		Version:   typedContent.Version,
		Content:   string(req.Content),
		Signature: signature,
		Status:    0,
		CreatedAt: models.UTCNow(),
	}
	if policy.Version == 0 {
		policy.Version = 1
	}
	if err := h.repo.Create(c.Request.Context(), policy); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "Policy created", policy)
}

func (h *PolicyHandler) Publish(c *gin.Context) {
    id, err := uuid.Parse(c.Param("id"))
    if err != nil {
        models.SendError(c, 400, 1001, "Invalid policy ID")
        return
    }

    policy, err := h.repo.Get(c.Request.Context(), id)
    if err != nil {
        models.SendError(c, 404, 2001, "Policy not found")
        return
    }
    
    if err := h.repo.SetCurrent(c.Request.Context(), policy); err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // 重新获取策略，确保获取最新的 status 和 is_current
    policy, err = h.repo.Get(c.Request.Context(), id)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    h.broadcastPolicyUpdate(policy)
    models.Send(c, 200, 0, "Policy published", nil)
}

func (h *PolicyHandler) Rollback(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid policy ID")
		return
	}

	// 获取要回滚到的策略版本
	policy, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "Policy not found")
		return
	}

	// 设置为当前策略
	if err := h.repo.SetCurrent(c.Request.Context(), policy); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	h.broadcastPolicyUpdate(policy)
	models.Send(c, 200, 0, "Policy rolled back", nil)
}

func calculateSignature(content []byte) string {
	return models.SignPolicyContent(string(content))
}

// broadcastPolicyUpdate 向所有 Agent 推送策略（携带与 DB 一致的 content 与 signature）
func (h *PolicyHandler) broadcastPolicyUpdate(policy *models.Policy) {
	if h.wsHub == nil || policy == nil {
		return
	}

	h.wsHub.SendCriticalToAllAgents(gin.H{
		"type":      "policy_update",
		"version":   policy.Version,
		"signature": policy.Signature,
		"policy":    json.RawMessage(policy.Content),
	})
}

// Get 获取单个策略
func (h *PolicyHandler) Get(c *gin.Context) {
    id, err := uuid.Parse(c.Param("id"))
    if err != nil {
        models.SendError(c, 400, 1001, "Invalid policy ID")
        return
    }

    policy, err := h.repo.Get(c.Request.Context(), id)
    if err != nil {
        models.SendError(c, 404, 2001, "Policy not found")
        return
    }

    models.Send(c, 200, 0, "success", policy)
}

// Update 更新策略
func (h *PolicyHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid policy ID")
		return
	}

	policy, err := h.repo.Get(c.Request.Context(), id)
	if err != nil {
		models.SendError(c, 404, 2001, "Policy not found")
		return
	}

	var req struct {
		Name    string          `json:"name"`
		Content json.RawMessage `json:"content"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	if len(req.Content) == 0 {
		models.SendError(c, 400, 1001, "Policy content is required")
		return
	}

	var typedContent models.PolicyContent
	if err := json.Unmarshal(req.Content, &typedContent); err != nil {
		models.SendError(c, 400, 1001, "Invalid policy content")
		return
	}

	signature := calculateSignature(req.Content)
	policy.Name = req.Name
	policy.Version = typedContent.Version
	policy.Content = string(req.Content)
	policy.Signature = signature
	policy.UpdatedAt = models.UTCNow()

	if err := h.repo.Update(c.Request.Context(), policy); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "Policy updated", policy)
}

// Delete 删除策略
func (h *PolicyHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		models.SendError(c, 400, 1001, "Invalid policy ID")
		return
	}

	if err := h.repo.Delete(c.Request.Context(), id); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "Policy deleted", nil)
}	

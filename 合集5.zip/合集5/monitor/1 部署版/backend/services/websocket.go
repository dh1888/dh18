// backend/services/websocket.go
// 完整替换文件内容 - 添加远程屏幕功能

package services

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"github.com/gorilla/websocket"

	"enterprise-agent/backend/config"
	"enterprise-agent/backend/models"
	"github.com/redis/go-redis/v9"
)

// WebSocket 配置常量
const (
    writeWait      = 10 * time.Second
    pongWait       = 90 * time.Second     // ✅ 对齐 Agent 的 90 秒超时
    pingPeriod     = 54 * time.Second     // ✅ 对齐 Agent 的 54 秒心跳
    maxMessageSize = 8192                 // Admin 等小消息连接
    sendBufferSize = 512
)

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		origin := r.Header.Get("Origin")
		if config.IsOriginAllowed(origin) {
			return true
		}
		config.LogOriginRejected(origin)
		return false
	},
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
}

// ========== AgentConn 定义 ==========

// AgentConn 代表一个Agent的WebSocket连接
type AgentConn struct {
	ConnID      string
	DeviceID  string
	Conn      *websocket.Conn
	Send      chan []byte  // 发送消息队列
	LastSeen  time.Time
	MissedPongs  int32    // 最后活跃时间
	mu        sync.RWMutex // 保护 LastSeen
	sendMu    sync.Mutex
	closeOnce sync.Once
	closed    atomic.Bool
}

// Close 安全关闭连接
func (ac *AgentConn) Close() {
    if ac == nil {
        return
    }

    ac.closeOnce.Do(func() {

        ac.closed.Store(true)

        // 先关 websocket
        ac.mu.Lock()
        if ac.Conn != nil {

            _ = ac.Conn.WriteMessage(
                websocket.CloseMessage,
                websocket.FormatCloseMessage(
                    websocket.CloseNormalClosure,
                    "",
                ),
            )

            _ = ac.Conn.Close()
            ac.Conn = nil
        }
        ac.mu.Unlock()

        // 再关发送通道
        ac.sendMu.Lock()
        if ac.Send != nil {
            close(ac.Send)
            ac.Send = nil
        }
        ac.sendMu.Unlock()

        log.Printf(
            "Agent connection closed: device=%s conn=%p",
            ac.DeviceID,
            ac,
        )
    })
}

func (ac *AgentConn) SendMessage(message []byte) error {
    if ac.closed.Load() {
        return errors.New("agent connection already closed")
    }
    
    ac.sendMu.Lock()
    defer ac.sendMu.Unlock()
    
    if ac.Send == nil {
        return errors.New("agent connection closed")
    }
    
    for attempt := 0; attempt < 5; attempt++ {
        select {
        case ac.Send <- message:
            return nil
        case <-time.After(100 * time.Millisecond):
        }
    }

    log.Printf("Agent %s send buffer full after retries, dropping message (len=%d)",
        ac.DeviceID, len(message))
    return errors.New("agent send buffer full")
}

func (ac *AgentConn) IsClosed() bool {
    return ac.closed.Load()
}

type AdminConn struct {
	Conn      *websocket.Conn
	Send      chan []byte
	closeOnce sync.Once
	sendMu    sync.Mutex
	closed    atomic.Bool
}

func NewAdminConn(conn *websocket.Conn) *AdminConn {
	return &AdminConn{
		Conn: conn,
		Send: make(chan []byte, sendBufferSize),
	}
}

func (ac *AdminConn) Close() {
    ac.closeOnce.Do(func() {
        ac.closed.Store(true)
        
        ac.sendMu.Lock()
        if ac.Send != nil {
            close(ac.Send)
            ac.Send = nil
        }
        ac.sendMu.Unlock()
        
        if ac.Conn != nil {
            ac.Conn.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""))
            ac.Conn.Close()
            ac.Conn = nil
        }
    })
}

func (ac *AdminConn) SendMessage(message []byte) error {

    ac.sendMu.Lock()
    defer ac.sendMu.Unlock()

    if ac.closed.Load() {
        return errors.New("admin connection already closed")
    }

    if ac.Send == nil {
        return errors.New("admin send channel is nil")
    }

    select {
    case ac.Send <- message:
        return nil

    default:
        return errors.New("admin send buffer full")
    }
}

func (ac *AdminConn) WritePump() {
	ticker := time.NewTicker(pingPeriod)
	defer func() {
		ticker.Stop()
		ac.Close()
	}()

	for {
		select {
		case message, ok := <-ac.Send:
			if !ok {
				return
			}
			if ac.Conn == nil {
				return
			}
			ac.Conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := ac.Conn.WriteMessage(websocket.TextMessage, message); err != nil {
				log.Printf("Admin WritePump error: %v", err)
				return
			}
		case <-ticker.C:
			if ac.Conn == nil {
				return
			}
			ac.Conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := ac.Conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}

// UpdateLastSeen 更新最后活跃时间
func (ac *AgentConn) UpdateLastSeen() {
	ac.mu.Lock()
	defer ac.mu.Unlock()
	ac.LastSeen = time.Now()
}

// GetLastSeen 获取最后活跃时间
func (ac *AgentConn) GetLastSeen() time.Time {
	ac.mu.RLock()
	defer ac.mu.RUnlock()
	return ac.LastSeen
}

// WritePump 负责向Agent发送消息（独立goroutine）
// ✅ 修改 WritePump - 不主动 Close
func (ac *AgentConn) WritePump() {
    ticker := time.NewTicker(pingPeriod)
    defer func() {
        ticker.Stop()
        // ✅ 不在这里 Close，让 ReadPump 的 defer 处理
        log.Printf("WritePump stopped for device=%s, conn=%s", ac.DeviceID, ac.ConnID)
    }()

    for {
        select {
        case message, ok := <-ac.Send:
            if !ok {
                log.Printf("Send channel closed for device=%s, conn=%s, exiting WritePump",
                    ac.DeviceID, ac.ConnID)
                return
            }

            conn := ac.getConn()
            if conn == nil {
                log.Printf("Connection is nil for device=%s, conn=%s, exiting WritePump",
                    ac.DeviceID, ac.ConnID)
                return
            }

            conn.SetWriteDeadline(time.Now().Add(writeWait))
            if err := conn.WriteMessage(websocket.TextMessage, message); err != nil {
                log.Printf("WritePump error for device=%s, conn=%s: %v",
                    ac.DeviceID, ac.ConnID, err)
                return
            }

        case <-ticker.C:
            if ac.closed.Load() {
                log.Printf("Connection closed for device=%s, conn=%s, exiting WritePump",
                    ac.DeviceID, ac.ConnID)
                return
            }

            conn := ac.getConn()
            if conn == nil {
                return
            }

            conn.SetWriteDeadline(time.Now().Add(writeWait))
            if err := conn.WriteMessage(websocket.PingMessage, nil); err != nil {
                log.Printf("Ping error for device=%s, conn=%s: %v",
                    ac.DeviceID, ac.ConnID, err)
                // ✅ 不 Close，直接返回，让 ReadPump 检测到错误
                return
            }
        }
    }
}

// ✅ 辅助函数：线程安全地获取连接
func (ac *AgentConn) getConn() *websocket.Conn {
	ac.mu.RLock()
	defer ac.mu.RUnlock()
	return ac.Conn
}

// ReadPump 负责从Agent读取消息（独立goroutine）
func (ac *AgentConn) ReadPump(hub *WebSocketHub) {
    defer func() {
        // 通知hub移除连接
        hub.unregister <- ac
    }()

    ac.mu.RLock()
    conn := ac.Conn
    ac.mu.RUnlock()

    if conn == nil {
        return
    }

    conn.SetReadLimit(maxAgentReadSize)
    conn.SetReadDeadline(time.Now().Add(pongWait))
    conn.SetPongHandler(func(string) error {
		    log.Printf(
        "[PONG] device=%s",
        ac.DeviceID,
    )
        ac.UpdateLastSeen()
        hub.SyncAgentLastSeen(ac.DeviceID, false)
        atomic.StoreInt32(&ac.MissedPongs, 0)  // ✅ 重置 miss 计数
        conn.SetReadDeadline(time.Now().Add(pongWait))
        return nil
    })

    for {
        _, message, err := conn.ReadMessage()
        if err != nil {
            // ✅ 分类处理错误
            if websocket.IsUnexpectedCloseError(err, 
                websocket.CloseGoingAway, 
                websocket.CloseAbnormalClosure) {
                log.Printf("ReadPump unexpected error for device %s: %v", ac.DeviceID, err)
                break  // 非正常关闭，断开
            }
            
            // ✅ 检查是否是临时网络错误
            if netErr, ok := err.(net.Error); ok && netErr.Temporary() {
                log.Printf("ReadPump temporary error for device %s: %v, waiting...", ac.DeviceID, err)
                time.Sleep(1 * time.Second)
                continue  // 临时错误，继续尝试读取
            }
            
            // ✅ 正常关闭或普通错误，记录但不立即断开
            if websocket.IsCloseError(err, websocket.CloseNormalClosure) {
                log.Printf("ReadPump normal close for device %s", ac.DeviceID)
            } else {
                log.Printf("ReadPump error for device %s: %v", ac.DeviceID, err)
            }
            break
        }

        ac.UpdateLastSeen()
        hub.SyncAgentLastSeen(ac.DeviceID, false)
        // ✅ 收到任何消息都重置 miss 计数
        atomic.StoreInt32(&ac.MissedPongs, 0)

        // 处理心跳响应
        var data map[string]interface{}
        if err := json.Unmarshal(message, &data); err == nil {
            if msgType, ok := data["type"].(string); ok && msgType == "ping" {
                // 响应pong
                pongMsg, _ := json.Marshal(map[string]string{
                    "type":      "pong",
                    "timestamp": time.Now().Format(time.RFC3339),
                })
                // ✅ 使用 select + timeout，不阻塞
                select {
                case ac.Send <- pongMsg:
                case <-time.After(200 * time.Millisecond):
                    log.Printf("Send buffer full for device %s, dropping pong response", ac.DeviceID)
                }
                continue
            }
        }

        // 处理其他消息（包括屏幕帧）
        hub.handleAgentMessage(ac.DeviceID, message)
    }
}

// ========== WebSocketHub 定义 ==========

// WebSocketHub WebSocket连接管理中心
type WebSocketHub struct {
	// Agent连接管理
	agents   map[string]*AgentConn
	agentsMu sync.RWMutex

	// Admin连接管理
	admins   map[*AdminConn]bool
	adminsMu sync.RWMutex

	// Redis 客户端（用于 token 黑名单检查）
	redis *redis.Client

	// 活动日志仓储（处理 activity.real_time）
	activityRepo *ActivityRepository

	// 设备仓储（同步 WS 活跃时间到 DB）
	deviceRepo *DeviceRepository
	lastSeenMu sync.Mutex
	lastSeenAt map[string]time.Time

	// 通道
	register   chan *AgentConn
	unregister chan *AgentConn
	broadcast  chan []byte

	// 广播并发限制（避免 1000 Agent 时 goroutine 风暴）
	broadcastSem chan struct{}

	// 清理控制
	stopCleanup chan struct{}
	cleanupOnce sync.Once

	// 关键消息可靠投递（策略/命令 ACK + 重试）
	critical *criticalDelivery

	// 远程查看（LiveKit 会话编排）
	remoteViewSvc *RemoteViewService
}

// SetActivityRepository 注入活动仓储（用于实时活动 WS 上报）
func (h *WebSocketHub) SetActivityRepository(repo *ActivityRepository) {
	h.activityRepo = repo
}

// SetRemoteViewService 注入远程查看服务
func (h *WebSocketHub) SetRemoteViewService(svc *RemoteViewService) {
	h.remoteViewSvc = svc
}

// SetDeviceRepository 注入设备仓储（用于同步 last_seen_at）
func (h *WebSocketHub) SetDeviceRepository(repo *DeviceRepository) {
	h.deviceRepo = repo
}

const agentLastSeenDBInterval = 60 * time.Second

// SyncAgentLastSeen 将 Agent WS 活跃时间写入数据库（节流，避免频繁写库）
func (h *WebSocketHub) SyncAgentLastSeen(deviceID string, force bool) {
	if h.deviceRepo == nil || deviceID == "" {
		return
	}

	now := time.Now()
	if !force {
		h.lastSeenMu.Lock()
		if last, ok := h.lastSeenAt[deviceID]; ok && now.Sub(last) < agentLastSeenDBInterval {
			h.lastSeenMu.Unlock()
			return
		}
		h.lastSeenAt[deviceID] = now
		h.lastSeenMu.Unlock()
	} else {
		h.lastSeenMu.Lock()
		h.lastSeenAt[deviceID] = now
		h.lastSeenMu.Unlock()
	}

	deviceUUID, err := uuid.Parse(deviceID)
	if err != nil {
		return
	}

	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		if err := h.deviceRepo.UpdateLastSeen(ctx, deviceUUID); err != nil {
			log.Printf("[WebSocketHub] Failed to update last_seen_at for device %s: %v", deviceID, err)
		}
	}()
}

// NewWebSocketHub 创建新的WebSocketHub
func NewWebSocketHub() *WebSocketHub {
	return NewWebSocketHubWithRedis(nil)
}

// NewWebSocketHubWithRedis 创建带有 Redis 的 WebSocketHub
func NewWebSocketHubWithRedis(redis *redis.Client) *WebSocketHub {
	hub := &WebSocketHub{
		agents:      make(map[string]*AgentConn),
		admins:      make(map[*AdminConn]bool),
		redis:       redis,
		lastSeenAt:  make(map[string]time.Time),
		register:     make(chan *AgentConn, 256),
		unregister:   make(chan *AgentConn, 256),
		broadcast:    make(chan []byte, 1024),
		broadcastSem: make(chan struct{}, 32),
		stopCleanup:  make(chan struct{}),
	}

	go hub.run()
	go hub.cleanupStaleConnections()
	hub.critical = newCriticalDelivery(hub)

	return hub
}

// run 主事件循环
func (h *WebSocketHub) run() {
    for {
        select {
        case agent := <-h.register:
            h.registerAgent(agent)

        case agent := <-h.unregister: // ✅ 接收 *AgentConn
            h.unregisterAgent(agent)

        case message := <-h.broadcast:
            h.broadcastToAll(message)
        }
    }
}

// registerAgent 注册Agent连接
func (h *WebSocketHub) registerAgent(agent *AgentConn) {
	var oldAgent *AgentConn

	h.agentsMu.Lock()
	if old, exists := h.agents[agent.DeviceID]; exists {
		oldAgent = old
	}
	h.agents[agent.DeviceID] = agent
	total := len(h.agents)
	h.agentsMu.Unlock()

	if oldAgent != nil {
		log.Printf("Replacing old connection for device: %s", agent.DeviceID)
		h.enqueueUnregister(oldAgent)
	}

	log.Printf("Agent registered: %s, total agents: %d", agent.DeviceID, total)
	h.SyncAgentLastSeen(agent.DeviceID, true)

	if h.critical != nil {
		h.critical.onAgentRegistered(agent.DeviceID)
	}

	// 通知所有Admin设备上线
	h.broadcastToAdmins(gin.H{
		"type":     "device_status",
		"deviceId": agent.DeviceID,
		"status":   "online",
	})
}

// unregisterAgent 注销Agent连接
func (h *WebSocketHub) unregisterAgent(agent *AgentConn) {
    if agent == nil {
        return
    }

    deviceID := agent.DeviceID

    h.agentsMu.Lock()

    current, exists := h.agents[deviceID]
    if !exists || current != agent {
        h.agentsMu.Unlock()

        agent.Close()
        return
    }

    delete(h.agents, deviceID)

    remaining := len(h.agents)

    h.agentsMu.Unlock()

    agent.Close()

    if h.remoteViewSvc != nil {
        h.remoteViewSvc.OnAgentDisconnected(context.Background(), deviceID)
    }

    h.broadcastToAdmins(gin.H{
        "type":     "device_status",
        "deviceId": deviceID,
        "status":   "offline",
    })

    log.Printf(
        "Agent unregistered: device=%s, conn=%p, remaining agents=%d",
        deviceID,
        agent,
        remaining,
    )
}

// broadcastToAll 广播消息给所有Agent和Admin（Hub 主循环快速返回，发送并发受限）
func (h *WebSocketHub) broadcastToAll(message []byte) {
	h.agentsMu.RLock()
	agents := make([]*AgentConn, 0, len(h.agents))
	for _, agent := range h.agents {
		agents = append(agents, agent)
	}
	h.agentsMu.RUnlock()

	for _, agent := range agents {
		h.dispatchAgentMessage(agent, message)
	}

	h.adminsMu.RLock()
	admins := make([]*AdminConn, 0, len(h.admins))
	for admin := range h.admins {
		admins = append(admins, admin)
	}
	h.adminsMu.RUnlock()

	for _, admin := range admins {
		target := admin
		go func() {
			if err := target.SendMessage(message); err != nil {
				log.Printf("Admin send buffer full or closed, skipping: %v", err)
			}
		}()
	}
}

func (h *WebSocketHub) dispatchAgentMessage(agent *AgentConn, message []byte) {
	target := agent
	h.broadcastSem <- struct{}{}
	go func() {
		defer func() { <-h.broadcastSem }()
		if err := target.SendMessage(message); err != nil {
			log.Printf("Agent %s send buffer full or closed, skipping: %v", target.DeviceID, err)
		}
	}()
}

// broadcastToAdmins 广播消息给所有Admin（不发送给Agent）
func (h *WebSocketHub) broadcastToAdmins(message interface{}) {
	payload, err := json.Marshal(message)
	if err != nil {
		log.Printf("Failed to marshal admin broadcast: %v", err)
		return
	}

	h.adminsMu.RLock()
	for admin := range h.admins {
		if err := admin.SendMessage(payload); err != nil {
			log.Printf("Admin send buffer full or closed: %v", err)
		}
	}
	h.adminsMu.RUnlock()
}

// cleanupStaleConnections 定期清理过期连接
func (h *WebSocketHub) cleanupStaleConnections() {
	ticker := time.NewTicker(60 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-h.stopCleanup:
			log.Println("Cleanup routine stopped")
			return
		case <-ticker.C:
			h.performCleanup()
		}
	}
}

// performCleanup 执行清理操作
func (h *WebSocketHub) performCleanup() {
	h.agentsMu.RLock()

	var toRemove []*AgentConn
	maxMissedPongs := 3

	for deviceID, agent := range h.agents {
		missed := atomic.LoadInt32(&agent.MissedPongs)

		if agent.closed.Load() {
			toRemove = append(toRemove, agent)
			log.Printf("Device %s (conn=%s) already closed, scheduling map cleanup", deviceID, agent.ConnID)
			continue
		}

		if missed >= int32(maxMissedPongs) {
			toRemove = append(toRemove, agent)
			log.Printf("Device %s (conn=%s) scheduled for cleanup after %d missed heartbeats",
				deviceID, agent.ConnID, missed)
		} else {
			atomic.AddInt32(&agent.MissedPongs, 1)
		}
	}

	h.agentsMu.RUnlock()

	for _, agent := range toRemove {
		h.enqueueUnregister(agent)
	}
}

// enqueueUnregister 将连接移出在线表并关闭，channel 满时同步清理
func (h *WebSocketHub) enqueueUnregister(agent *AgentConn) {
	if agent == nil {
		return
	}

	select {
	case h.unregister <- agent:
	default:
		h.removeAgentFromMap(agent)
	}
}

// removeAgentFromMap 同步从在线表移除并关闭连接
func (h *WebSocketHub) removeAgentFromMap(agent *AgentConn) {
	deviceID := agent.DeviceID

	h.agentsMu.Lock()
	current, exists := h.agents[deviceID]
	if exists && current == agent {
		delete(h.agents, deviceID)
	}
	h.agentsMu.Unlock()

	agent.Close()

	if exists && current == agent {
		if h.remoteViewSvc != nil {
			h.remoteViewSvc.OnAgentDisconnected(context.Background(), deviceID)
		}
		h.broadcastToAdmins(gin.H{
			"type":     "device_status",
			"deviceId": deviceID,
			"status":   "offline",
		})
		log.Printf("Agent removed synchronously: device=%s, conn=%s", deviceID, agent.ConnID)
	}
}

// Stop 停止WebSocketHub
func (h *WebSocketHub) Stop() {
	h.cleanupOnce.Do(func() {
		close(h.stopCleanup)
	})

	if h.critical != nil {
		h.critical.stop()
	}

	// 关闭所有Agent连接
	h.agentsMu.Lock()
	for _, agent := range h.agents {
		agent.Close()
	}
	h.agents = make(map[string]*AgentConn)
	h.agentsMu.Unlock()

	// 关闭所有Admin连接
	h.adminsMu.Lock()
	for admin := range h.admins {
		admin.Close()
	}
	h.admins = make(map[*AdminConn]bool)
	h.adminsMu.Unlock()

	log.Println("WebSocket hub stopped")
}

// validateUserToken 验证用户 JWT token
func (h *WebSocketHub) validateUserToken(tokenString string) (*models.Claims, error) {
	secret := models.JWTSecret()
	if len(secret) == 0 {
		return nil, jwt.ErrInvalidKey
	}

	claims := &models.Claims{}
	token, err := jwt.ParseWithClaims(tokenString, claims, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, jwt.ErrSignatureInvalid
		}
		return secret, nil
	}, jwt.WithValidMethods([]string{jwt.SigningMethodHS256.Name}))
	if err != nil {
		return nil, err
	}
	if !token.Valid {
		return nil, jwt.ErrSignatureInvalid
	}
	if claims.UserID == "" {
		return nil, jwt.ErrTokenMalformed
	}

	if h.redis != nil {
		ctx := context.Background()
		exists, _ := h.redis.Exists(ctx, "blacklist:"+tokenString).Result()
		if exists > 0 {
			return nil, jwt.ErrTokenExpired
		}
	}

	return claims, nil
}

// validateDeviceToken 验证设备 JWT token
func (h *WebSocketHub) validateDeviceToken(tokenString string) (*models.DeviceClaims, error) {
	secret := models.JWTSecret()
	if len(secret) == 0 {
		return nil, jwt.ErrInvalidKey
	}

	claims := &models.DeviceClaims{}
	token, err := jwt.ParseWithClaims(tokenString, claims, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, jwt.ErrSignatureInvalid
		}
		return secret, nil
	}, jwt.WithValidMethods([]string{jwt.SigningMethodHS256.Name}))
	if err != nil {
		return nil, err
	}
	if !token.Valid {
		return nil, jwt.ErrSignatureInvalid
	}
	if claims.DeviceID == "" {
		return nil, jwt.ErrTokenMalformed
	}

	if h.redis != nil {
		ctx := context.Background()
		exists, _ := h.redis.Exists(ctx, "blacklist:"+tokenString).Result()
		if exists > 0 {
			return nil, jwt.ErrTokenExpired
		}
	}

	return claims, nil
}

// ========== Agent WebSocket 处理 ==========

// extractAgentAuthToken 从 Authorization Header 或 query 提取设备 token（优先 Header）
func extractAgentAuthToken(c *gin.Context) string {
	if auth := strings.TrimSpace(c.GetHeader("Authorization")); auth != "" {
		const prefix = "Bearer "
		if strings.HasPrefix(auth, prefix) {
			return strings.TrimSpace(auth[len(prefix):])
		}
	}

	token := strings.TrimSpace(c.Query("token"))
	if token != "" {
		log.Printf("Agent WebSocket using deprecated query token; migrate to Authorization header")
	}
	return token
}

// HandleAgent 处理Agent的WebSocket连接
func (h *WebSocketHub) HandleAgent(c *gin.Context) {
	token := extractAgentAuthToken(c)
	deviceID := c.Query("deviceId")

	if token == "" || deviceID == "" {
		models.SendError(c, 401, 1002, "Missing token or deviceId")
		return
	}

	// 验证 token
	claims, err := h.validateDeviceToken(token)
	if err != nil {
		log.Printf("Agent token validation failed for device %s: %v", deviceID, err)
		models.SendError(c, 401, 1002, "Invalid token")
		return
	}
	if claims == nil {
		models.SendError(c, 401, 1002, "Token validation failed")
		return
	}

	if claims.DeviceID != deviceID {
		log.Printf("Agent device ID mismatch: token=%s query=%s", claims.DeviceID, deviceID)
		models.SendError(c, 403, 1003, "Device ID mismatch")
		return
	}

	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("WebSocket upgrade failed for device %s: %v", deviceID, err)
		return
	}

	// 创建Agent连接对象
	agent := &AgentConn{
		ConnID:   uuid.New().String()[:8],
		DeviceID: deviceID,
		Conn:     conn,
		Send:     make(chan []byte, sendBufferSize),
		LastSeen: time.Now(),
	}

	// 启动读写goroutine
	go agent.WritePump()
	go agent.ReadPump(h)

	// 注册到hub
	h.register <- agent
}

// ========== Admin WebSocket 处理 ==========

// HandleAdmin 处理Admin的WebSocket连接
func (h *WebSocketHub) HandleAdmin(c *gin.Context) {
	userID := c.GetString("userID")
	username := c.GetString("username")
	role := c.GetString("role")

	if role != "admin" && role != "operator" {
		c.JSON(403, gin.H{
			"code":    1003,
			"message": "Permission denied",
		})
		return
	}

	log.Printf(
		"Admin WebSocket authenticated: userID=%s username=%s role=%s",
		userID,
		username,
		role,
	)

	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("Admin WebSocket upgrade failed: %v", err)
		return
	}

	admin := NewAdminConn(conn)

	h.adminsMu.Lock()
	h.admins[admin] = true
	adminCount := len(h.admins)
	h.adminsMu.Unlock()

	log.Printf("Admin connected, total admins: %d", adminCount)

	go admin.WritePump()

	defer func() {
		h.adminsMu.Lock()
		delete(h.admins, admin)
		adminCount := len(h.admins)
		h.adminsMu.Unlock()

		admin.Close()

		log.Printf(
			"Admin disconnected, remaining admins: %d",
			adminCount,
		)
	}()

	// 首次推送在线设备
	h.sendOnlineDevices(admin)

	conn.SetReadLimit(maxMessageSize)

	conn.SetReadDeadline(time.Now().Add(pongWait))

	conn.SetPongHandler(func(string) error {
		conn.SetReadDeadline(time.Now().Add(pongWait))
		return nil
	})

	for {
		_, message, err := conn.ReadMessage()
		if err != nil {
			if websocket.IsUnexpectedCloseError(
				err,
				websocket.CloseGoingAway,
				websocket.CloseAbnormalClosure,
			) {
				log.Printf("Admin read error: %v", err)
			}
			break
		}

		conn.SetReadDeadline(time.Now().Add(pongWait))

		if err := h.handleAdminMessage(admin, message); err != nil {
			log.Printf("handleAdminMessage error: %v", err)
		}
	}
}

func (h *WebSocketHub) handleAdminMessage(
	admin *AdminConn,
	message []byte,
) error {
	var data map[string]interface{}

	if err := json.Unmarshal(message, &data); err != nil {
		return nil
	}

	msgType, ok := data["type"].(string)
	if !ok {
		return nil
	}


	switch msgType {

	case "ping":
		
		pongMsg, err := json.Marshal(gin.H{
			"type":      "pong",
			"timestamp": time.Now().Unix(),
		})
		if err != nil {
			return err
		}
		
		if err := admin.SendMessage(pongMsg); err != nil {
			return err
		}
		
		return nil

	case "get_devices":
		h.sendOnlineDevices(admin)
		return nil

	case "pong":
		return nil

	default:
		log.Printf("⚠️ [Admin] Unknown message type: %s", msgType)
		return nil
	}
}
// ========== 设备命令发送 ==========

// SendCommandToDevice 向指定设备发送命令（可靠投递 + ACK）
func (h *WebSocketHub) SendCommandToDevice(deviceID string, command string, params gin.H) {
	if params == nil {
		params = gin.H{}
	}
	h.SendCriticalToAgent(deviceID, gin.H{
		"type":    "command",
		"command": command,
		"params":  params,
	})
}

// ========== 消息处理 ==========

func (h *WebSocketHub) handleRealtimeActivity(deviceID string, envelope map[string]interface{}) {
	if h.activityRepo == nil {
		return
	}

	payload, ok := envelope["data"].(map[string]interface{})
	if !ok {
		return
	}

	getString := func(key string) string {
		if v, ok := payload[key].(string); ok {
			return v
		}
		return ""
	}

	activityID := getString("id")
	if activityID == "" {
		return
	}

	effectiveDeviceID := deviceID
	if v := getString("deviceId"); v != "" {
		effectiveDeviceID = v
	}

	startedAt, err := models.ParseUTC(getString("startedAt"))
	if err != nil {
		startedAt = models.UTCNow()
	}

	var endedAt *time.Time
	if endedStr := getString("endedAt"); endedStr != "" {
		if parsed, parseErr := models.ParseUTC(endedStr); parseErr == nil {
			endedAt = &parsed
		}
	}

	durationSeconds := 0
	switch v := payload["durationSeconds"].(type) {
	case float64:
		durationSeconds = int(v)
	case int:
		durationSeconds = v
	}

	isIdle := false
	if v, ok := payload["isIdle"].(bool); ok {
		isIdle = v
	}

	now := models.UTCNow()
	logEntry := models.ActivityLog{
		ID:              activityID,
		DeviceID:        effectiveDeviceID,
		ProcessName:     getString("processName"),
		WindowTitle:     getString("windowTitle"),
		BrowserTitle:    getString("browserTitle"),
		StartedAt:       startedAt,
		EndedAt:         endedAt,
		IsIdle:          isIdle,
		DurationSeconds: durationSeconds,
		CreatedAt:       now,
		Reported:        true,
		ReportedAt:      &now,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := h.activityRepo.BatchAdd(ctx, []models.ActivityLog{logEntry}); err != nil {
		log.Printf("Failed to persist realtime activity from %s: %v", deviceID, err)
	}
}

// handleAgentMessage 处理Agent发送的消息
func (h *WebSocketHub) handleAgentMessage(deviceID string, message []byte) {
	// 尝试解析为 JSON
	var data map[string]interface{}
	if err := json.Unmarshal(message, &data); err != nil {
		log.Printf("Failed to parse agent message from %s: %v", deviceID, err)
		return
	}

	msgType, ok := data["type"].(string)
	if !ok {
		return
	}

	switch msgType {

	case "ack":
		if messageID, ok := data["messageId"].(string); ok && h.critical != nil {
			h.critical.onAck(messageID)
		}

	case "log":
		// 处理Agent日志上报
		log.Printf("Agent log from %s: %v", deviceID, data)

	case "activity.real_time":
		h.handleRealtimeActivity(deviceID, data)

	case "remote_view_stats":
		if h.remoteViewSvc != nil {
			stats := &models.RemoteViewStatsPayload{}
			if v, ok := data["fps"].(float64); ok {
				stats.FPS = int(v)
			}
			if v, ok := data["bitrateKbps"].(float64); ok {
				stats.BitrateKbps = int(v)
			}
			if v, ok := data["encoder"].(string); ok {
				stats.Encoder = v
			}
			h.remoteViewSvc.UpdateDeviceStats(deviceID, stats)
		}

	case "remote_view_event":
		if h.remoteViewSvc != nil {
			event, _ := data["event"].(string)
			sessionID, _ := data["sessionId"].(string)
			switch event {
			case "published":
				_ = h.remoteViewSvc.MarkSessionActive(context.Background(), deviceID, sessionID)
			case "failed":
				detail, _ := data["detail"].(string)
				if err := h.remoteViewSvc.MarkSessionFailed(context.Background(), deviceID, sessionID, detail); err != nil {
					log.Printf("[RemoteView] mark failed for device %s session %s: %v", deviceID, sessionID, err)
				}
			}
		}

	default:
		log.Printf("Unknown message type %s from %s", msgType, deviceID)
	}
}

// ========== 压缩/解压辅助函数 ==========

// decompressGZip 解压 GZip 数据
func decompressGZip(data []byte) ([]byte, error) {
	if len(data) == 0 {
		return data, nil
	}
	
	reader, err := gzip.NewReader(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("gzip reader error: %w", err)
	}
	defer reader.Close()
	
	decompressed, err := io.ReadAll(reader)
	if err != nil {
		return nil, fmt.Errorf("decompress error: %w", err)
	}
	
	return decompressed, nil
}

// isCompressedData 检测数据是否为 GZip 压缩格式
func isCompressedData(data []byte) bool {
	if len(data) < 2 {
		return false
	}
	// GZip 魔术数字: 0x1F 0x8B
	return data[0] == 0x1F && data[1] == 0x8B
}
// ========== 公共方法 ==========

// sendOnlineDevices 发送在线设备列表
func (h *WebSocketHub) sendOnlineDevices(admin *AdminConn) {
	h.agentsMu.RLock()
	devices := make([]string, 0, len(h.agents))
	for id := range h.agents {
		devices = append(devices, id)
	}
	h.agentsMu.RUnlock()

	payload, err := json.Marshal(gin.H{
		"type":    "online_devices",
		"devices": devices,
		"count":   len(devices),
	})
	if err != nil {
		return
	}
	if err := admin.SendMessage(payload); err != nil {
		log.Printf("Failed to send online devices: %v", err)
	}
}

// BroadcastToAgents 向所有Agent广播消息
func (h *WebSocketHub) BroadcastToAgents(message interface{}) {
	payload, err := json.Marshal(message)
	if err != nil {
		return
	}

	select {
	case h.broadcast <- payload:
	default:
		// channel 满时直接分发，避免阻塞 HTTP handler
		log.Printf("broadcast channel full, dispatching directly (%d bytes)", len(payload))
		go h.broadcastToAll(payload)
	}
}

// BroadcastToAgent 向指定Agent发送消息
func (h *WebSocketHub) BroadcastToAgent(deviceID string, message interface{}) {
	payload, err := json.Marshal(message)
	if err != nil {
		return
	}

	h.agentsMu.RLock()
	agent, exists := h.agents[deviceID]
	h.agentsMu.RUnlock()

	if exists {
		if err := agent.SendMessage(payload); err != nil {
			log.Printf("Send buffer full for device %s: %v", deviceID, err)
		}
	}
}

// BroadcastToAdmins 向所有Admin广播消息
func (h *WebSocketHub) BroadcastToAdmins(message interface{}) {
	h.broadcastToAdmins(message)
}

// BroadcastToAdmin 广播到Admin（兼容旧接口名）
func (h *WebSocketHub) BroadcastToAdmin(message interface{}) {
	h.broadcastToAdmins(message)
}

// GetOnlineDevices 获取在线设备列表
func (h *WebSocketHub) GetOnlineDevices() []string {
	h.agentsMu.RLock()
	defer h.agentsMu.RUnlock()

	devices := make([]string, 0, len(h.agents))
	for id := range h.agents {
		devices = append(devices, id)
	}
	return devices
}

// GetOnlineCount 获取在线设备数量
func (h *WebSocketHub) GetOnlineCount() int {
	h.agentsMu.RLock()
	defer h.agentsMu.RUnlock()
	return len(h.agents)
}

// IsAgentOnline 检查Agent是否在线
func (h *WebSocketHub) IsAgentOnline(deviceID string) bool {
	h.agentsMu.RLock()
	defer h.agentsMu.RUnlock()
	_, exists := h.agents[deviceID]
	return exists
}

// SendPolicyUpdate 向指定设备发送策略更新（可靠投递）
func (h *WebSocketHub) SendPolicyUpdate(deviceID string, policyContent interface{}, version int, signature string) {
	h.SendCriticalToAgent(deviceID, gin.H{
		"type":      "policy_update",
		"policy":    policyContent,
		"version":   version,
		"signature": signature,
	})
}

// SendCommand 向指定设备发送命令
func (h *WebSocketHub) SendCommand(deviceID string, command string, params map[string]interface{}) {
	h.BroadcastToAgent(deviceID, gin.H{
		"type":    "command",
		"command": command,
		"params":  params,
	})
}

// SendTask 向指定设备发送任务
func (h *WebSocketHub) SendTask(deviceID string, taskID string, taskType string, params interface{}) {
	h.BroadcastToAgent(deviceID, gin.H{
		"type":    "task",
		"taskId":  taskID,
		"task":    taskType,
		"params":  params,
		"timeout": 300, // 5分钟超时
	})
}

// HandleAgentWithDeviceID 使用指定的设备ID处理Agent连接
func (h *WebSocketHub) HandleAgentWithDeviceID(c *gin.Context, deviceID string) {
    conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
    if err != nil {
        log.Printf("WebSocket upgrade failed for device %s: %v", deviceID, err)
        return
    }

    agent := &AgentConn{
		ConnID:   uuid.New().String()[:8],
        DeviceID: deviceID,
        Conn:     conn,
        Send:     make(chan []byte, sendBufferSize),
        LastSeen: time.Now(),
    }

    go agent.WritePump()
    go agent.ReadPump(h)

    h.register <- agent
}

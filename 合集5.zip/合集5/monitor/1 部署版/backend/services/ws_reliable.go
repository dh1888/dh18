package services

import (
	"encoding/json"
	"errors"
	"log"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

const (
	maxAgentReadSize            = 1 << 20 // 1 MiB — 对齐 Agent MaxWebSocketMessageSize
	criticalDeliveryMaxAttempts = 8
	criticalDeliveryRetryEvery  = 15 * time.Second
	criticalDeliveryAckTimeout  = 45 * time.Second
	criticalSendRetryCount      = 12
	criticalSendRetryWait       = 200 * time.Millisecond
)

type criticalPendingMsg struct {
	DeviceID   string
	Payload    []byte
	Attempts   int
	CreatedAt  time.Time
	LastSentAt time.Time
}

// criticalDelivery 跟踪策略/命令等关键消息，直到收到 Agent ACK 或耗尽重试
type criticalDelivery struct {
	hub     *WebSocketHub
	pending map[string]*criticalPendingMsg
	mu      sync.Mutex
	stopCh  chan struct{}
}

func newCriticalDelivery(hub *WebSocketHub) *criticalDelivery {
	cd := &criticalDelivery{
		hub:     hub,
		pending: make(map[string]*criticalPendingMsg),
		stopCh:  make(chan struct{}),
	}
	go cd.retryLoop()
	return cd
}

func (cd *criticalDelivery) stop() {
	select {
	case <-cd.stopCh:
	default:
		close(cd.stopCh)
	}
}

// SendCriticalToAgent 向单设备发送需 ACK 的关键消息（policy_update / command 等）
func (h *WebSocketHub) SendCriticalToAgent(deviceID string, message gin.H) {
	if h == nil || h.critical == nil || deviceID == "" {
		return
	}
	h.critical.enqueue(deviceID, message)
}

// SendCriticalToAllAgents 向所有在线设备广播关键消息（每设备独立 messageId 与重试状态）
func (h *WebSocketHub) SendCriticalToAllAgents(message gin.H) {
	if h == nil || h.critical == nil {
		return
	}

	h.agentsMu.RLock()
	deviceIDs := make([]string, 0, len(h.agents))
	for id := range h.agents {
		deviceIDs = append(deviceIDs, id)
	}
	h.agentsMu.RUnlock()

	for _, deviceID := range deviceIDs {
		msg := cloneGinH(message)
		h.critical.enqueue(deviceID, msg)
	}
}

func cloneGinH(src gin.H) gin.H {
	dst := make(gin.H, len(src))
	for k, v := range src {
		dst[k] = v
	}
	return dst
}

func (cd *criticalDelivery) enqueue(deviceID string, message gin.H) {
	messageID := uuid.New().String()
	message["messageId"] = messageID

	payload, err := json.Marshal(message)
	if err != nil {
		log.Printf("critical delivery marshal failed for device %s: %v", deviceID, err)
		return
	}

	now := time.Now()
	cd.mu.Lock()
	cd.pending[messageID] = &criticalPendingMsg{
		DeviceID:   deviceID,
		Payload:    payload,
		CreatedAt:  now,
		LastSentAt: time.Time{},
	}
	cd.mu.Unlock()

	cd.tryDeliver(messageID)
}

func (cd *criticalDelivery) onAck(messageID string) {
	if messageID == "" {
		return
	}
	cd.mu.Lock()
	delete(cd.pending, messageID)
	cd.mu.Unlock()
}

func (cd *criticalDelivery) onAgentRegistered(deviceID string) {
	cd.mu.Lock()
	var ids []string
	for id, p := range cd.pending {
		if p.DeviceID == deviceID {
			ids = append(ids, id)
		}
	}
	cd.mu.Unlock()

	for _, id := range ids {
		cd.tryDeliver(id)
	}
}

func (cd *criticalDelivery) tryDeliver(messageID string) bool {
	cd.mu.Lock()
	p, ok := cd.pending[messageID]
	if !ok {
		cd.mu.Unlock()
		return true
	}
	if p.Attempts >= criticalDeliveryMaxAttempts {
		log.Printf("critical message %s to device %s dropped after %d attempts",
			messageID, p.DeviceID, p.Attempts)
		delete(cd.pending, messageID)
		cd.mu.Unlock()
		return false
	}
	deviceID := p.DeviceID
	payload := p.Payload
	cd.mu.Unlock()

	cd.hub.agentsMu.RLock()
	agent, exists := cd.hub.agents[deviceID]
	cd.hub.agentsMu.RUnlock()

	if !exists {
		return false
	}

	if err := sendCriticalMessage(agent, payload); err != nil {
		log.Printf("critical send failed device=%s messageId=%s: %v", deviceID, messageID, err)
		cd.mu.Lock()
		if pp, ok := cd.pending[messageID]; ok {
			pp.Attempts++
		}
		cd.mu.Unlock()
		return false
	}

	now := time.Now()
	cd.mu.Lock()
	if pp, ok := cd.pending[messageID]; ok {
		pp.Attempts++
		pp.LastSentAt = now
	}
	cd.mu.Unlock()
	return true
}

func sendCriticalMessage(agent *AgentConn, payload []byte) error {
	if agent == nil || agent.IsClosed() {
		return errAgentConnectionClosed
	}

	agent.sendMu.Lock()
	defer agent.sendMu.Unlock()

	if agent.Send == nil {
		return errAgentConnectionClosed
	}

	for attempt := 0; attempt < criticalSendRetryCount; attempt++ {
		select {
		case agent.Send <- payload:
			return nil
		case <-time.After(criticalSendRetryWait):
		}
	}
	return errAgentSendBufferFull
}

var (
	errAgentConnectionClosed = errors.New("agent connection closed")
	errAgentSendBufferFull   = errors.New("agent send buffer full")
)

func (cd *criticalDelivery) retryLoop() {
	ticker := time.NewTicker(criticalDeliveryRetryEvery)
	defer ticker.Stop()

	for {
		select {
		case <-cd.stopCh:
			return
		case <-ticker.C:
			cd.retryDue()
		}
	}
}

func (cd *criticalDelivery) retryDue() {
	now := time.Now()

	cd.mu.Lock()
	ids := make([]string, 0, len(cd.pending))
	for id, p := range cd.pending {
		if p.Attempts >= criticalDeliveryMaxAttempts {
			continue
		}
		if p.LastSentAt.IsZero() {
			if now.Sub(p.CreatedAt) >= criticalDeliveryRetryEvery {
				ids = append(ids, id)
			}
			continue
		}
		if now.Sub(p.LastSentAt) >= criticalDeliveryAckTimeout {
			ids = append(ids, id)
		}
	}
	cd.mu.Unlock()

	for _, id := range ids {
		cd.tryDeliver(id)
	}
}

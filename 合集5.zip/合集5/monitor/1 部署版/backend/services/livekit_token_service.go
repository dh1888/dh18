package services

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

type LiveKitTokenService struct {
	apiKey    string
	apiSecret string
	ttl       time.Duration
}

func NewLiveKitTokenService(apiKey, apiSecret string, ttl time.Duration) *LiveKitTokenService {
	return &LiveKitTokenService{
		apiKey:    apiKey,
		apiSecret: apiSecret,
		ttl:       ttl,
	}
}

type liveKitVideoGrant struct {
	RoomJoin      bool   `json:"roomJoin,omitempty"`
	Room          string `json:"room,omitempty"`
	CanPublish    bool   `json:"canPublish,omitempty"`
	CanSubscribe  bool   `json:"canSubscribe,omitempty"`
	IngressAdmin  bool   `json:"ingressAdmin,omitempty"`
}

type liveKitClaims struct {
	Video liveKitVideoGrant `json:"video"`
	jwt.RegisteredClaims
}

func (s *LiveKitTokenService) signToken(identity string, grant liveKitVideoGrant) (string, error) {
	if s.apiKey == "" || s.apiSecret == "" {
		return "", fmt.Errorf("livekit api credentials not configured")
	}

	now := time.Now()
	claims := liveKitClaims{
		Video: grant,
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    s.apiKey,
			Subject:   identity,
			NotBefore: jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(s.ttl)),
			IssuedAt:  jwt.NewNumericDate(now),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.apiSecret))
}

func (s *LiveKitTokenService) CreateSubscriberToken(roomName, userID, sessionID string) (string, error) {
	return s.signToken(fmt.Sprintf("viewer-%s-%s", userID, sessionID), liveKitVideoGrant{
		RoomJoin:     true,
		Room:         roomName,
		CanPublish:   false,
		CanSubscribe: true,
	})
}

func (s *LiveKitTokenService) createAdminToken(ttl time.Duration) (string, error) {
	if s.apiKey == "" || s.apiSecret == "" {
		return "", fmt.Errorf("livekit api credentials not configured")
	}
	now := time.Now()
	claims := liveKitClaims{
		Video: liveKitVideoGrant{IngressAdmin: true},
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    s.apiKey,
			NotBefore: jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(ttl)),
			IssuedAt:  jwt.NewNumericDate(now),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.apiSecret))
}

type liveKitIngressClient struct {
	apiHost   string
	apiKey    string
	apiSecret string
	http      *http.Client
	tokens    *LiveKitTokenService
}

func newLiveKitIngressClient(apiHost, apiKey, apiSecret string) *liveKitIngressClient {
	return &liveKitIngressClient{
		apiHost:   strings.TrimSuffix(apiHost, "/"),
		apiKey:    apiKey,
		apiSecret: apiSecret,
		http:      &http.Client{Timeout: 15 * time.Second},
		tokens:    NewLiveKitTokenService(apiKey, apiSecret, 5*time.Minute),
	}
}

type createIngressRequest struct {
	InputType           int    `json:"input_type"`
	Name                string `json:"name"`
	RoomName            string `json:"room_name"`
	ParticipantIdentity string `json:"participant_identity"`
	ParticipantName     string `json:"participant_name"`
}

type ingressInfoResponse struct {
	IngressId string `json:"ingress_id"`
	Url       string `json:"url"`
	StreamKey string `json:"stream_key"`
}

func (c *liveKitIngressClient) CreateRTMPIngress(ctx context.Context, roomName, deviceID string) (rtmpURL, ingressID string, err error) {
	body, _ := json.Marshal(createIngressRequest{
		InputType:           0,
		Name:                roomName,
		RoomName:            roomName,
		ParticipantIdentity: "agent-" + deviceID,
		ParticipantName:     "agent-" + deviceID,
	})

	token, err := c.tokens.createAdminToken(5 * time.Minute)
	if err != nil {
		return "", "", err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.apiHost+"/twirp/livekit.Ingress/CreateIngress", bytes.NewReader(body))
	if err != nil {
		return "", "", err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return "", "", err
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", "", fmt.Errorf("create ingress http %d: %s", resp.StatusCode, string(respBody))
	}

	var info ingressInfoResponse
	if err := json.Unmarshal(respBody, &info); err != nil {
		return "", "", err
	}

	rtmpURL = strings.TrimSuffix(info.Url, "/") + "/" + info.StreamKey
	return rtmpURL, info.IngressId, nil
}

func (c *liveKitIngressClient) DeleteIngress(ctx context.Context, ingressID string) error {
	body, _ := json.Marshal(map[string]string{"ingress_id": ingressID})

	token, err := c.tokens.createAdminToken(5 * time.Minute)
	if err != nil {
		return err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.apiHost+"/twirp/livekit.Ingress/DeleteIngress", bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		respBody, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("delete ingress http %d: %s", resp.StatusCode, string(respBody))
	}
	return nil
}

func (c *liveKitIngressClient) Ping(ctx context.Context) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.apiHost, nil)
	if err != nil {
		return err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 400 {
		return fmt.Errorf("livekit http %d", resp.StatusCode)
	}
	return nil
}

package services

import (
	"context"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/config"
	"enterprise-agent/backend/models"
)

type RemoteViewService struct {
	cfg         config.LiveKitConfig
	repo        *RemoteViewRepository
	deviceRepo  *DeviceRepository
	wsHub       *WebSocketHub
	tokens      *LiveKitTokenService
	ingress     *liveKitIngressClient
	statsMu     sync.RWMutex
	deviceStats map[string]*models.RemoteViewStatsPayload
	startLocks  sync.Map
}

func NewRemoteViewService(
	cfg config.LiveKitConfig,
	repo *RemoteViewRepository,
	deviceRepo *DeviceRepository,
	wsHub *WebSocketHub,
) *RemoteViewService {
	svc := &RemoteViewService{
		cfg:         cfg,
		repo:        repo,
		deviceRepo:  deviceRepo,
		wsHub:       wsHub,
		tokens:      NewLiveKitTokenService(cfg.APIKey, cfg.APISecret, cfg.TokenTTL),
		deviceStats: make(map[string]*models.RemoteViewStatsPayload),
	}
	if cfg.Enabled() {
		svc.ingress = newLiveKitIngressClient(cfg.APIHost, cfg.APIKey, cfg.APISecret)
	}
	return svc
}

func (s *RemoteViewService) UpdateDeviceStats(deviceID string, stats *models.RemoteViewStatsPayload) {
	if stats == nil {
		return
	}
	s.statsMu.Lock()
	s.deviceStats[deviceID] = stats
	s.statsMu.Unlock()
}

func (s *RemoteViewService) GetDeviceStats(deviceID string) *models.RemoteViewStatsPayload {
	s.statsMu.RLock()
	defer s.statsMu.RUnlock()
	return s.deviceStats[deviceID]
}

func (s *RemoteViewService) StartSession(
	ctx context.Context,
	deviceIDStr, userIDStr, username, clientIP string,
) (*models.RemoteViewStartResponse, error) {
	if !s.cfg.Enabled() {
		return nil, fmt.Errorf("livekit is not configured")
	}

	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid device id")
	}

	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid user id")
	}

	device, err := s.deviceRepo.Get(ctx, deviceID)
	if err != nil {
		return nil, fmt.Errorf("device not found")
	}

	if !s.wsHub.IsAgentOnline(deviceIDStr) {
		return nil, fmt.Errorf("device is not connected")
	}

	unlock := s.lockDeviceStart(deviceIDStr)
	defer unlock()

	s.expireStaleStartingIfNeeded(ctx, deviceID)

	roomName := config.RoomNameForDevice(deviceIDStr)
	expiresAt := models.UTCNow().Add(s.cfg.TokenTTL)

	active, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err == nil && active != nil {
		if active.ViewerCount >= s.cfg.MaxViewersPerDev {
			return nil, fmt.Errorf("maximum viewers reached for this device")
		}

		viewerToken, err := s.tokens.CreateSubscriberToken(roomName, userIDStr, active.ID.String())
		if err != nil {
			return nil, err
		}

		if _, err := s.repo.IncrementViewerCount(ctx, active.ID); err != nil {
			return nil, err
		}

		s.writeAudit(ctx, &active.ID, deviceID, userID, username, "viewer_join", clientIP, gin.H{
			"roomName": roomName,
		})

		return &models.RemoteViewStartResponse{
			SessionID:   active.ID.String(),
			DeviceID:    deviceIDStr,
			DeviceName:  device.Hostname,
			RoomName:    roomName,
			LiveKitURL:  s.cfg.URL,
			ViewerToken: viewerToken,
			ExpiresAt:   expiresAt,
		}, nil
	}

	sessionID := uuid.New()
	now := models.UTCNow()
	session := &models.RemoteViewSession{
		ID:                sessionID,
		DeviceID:          deviceID,
		RoomName:          roomName,
		Status:            models.RemoteViewStatusStarting,
		StartedBy:         userID,
		StartedByName:     username,
		ViewerCount:       1,
		PublisherIdentity: "agent-" + deviceIDStr,
		LiveKitURL:        s.cfg.URL,
		StartedAt:         now,
		CreatedAt:         now,
		UpdatedAt:         now,
	}

	rtmpURL, ingressID, err := s.ensureIngress(ctx, roomName, deviceIDStr)
	if err != nil {
		return nil, err
	}
	session.IngressID = ingressID
	session.RTMPURL = rtmpURL

	if err := s.repo.Create(ctx, session); err != nil {
		if s.ingress != nil && ingressID != "" {
			_ = s.ingress.DeleteIngress(ctx, ingressID)
		}
		return nil, err
	}

	viewerToken, err := s.tokens.CreateSubscriberToken(roomName, userIDStr, sessionID.String())
	if err != nil {
		return nil, err
	}

	s.writeAudit(ctx, &sessionID, deviceID, userID, username, "session_start", clientIP, gin.H{
		"roomName": roomName,
	})

	go func() {
		time.Sleep(300 * time.Millisecond)
		s.wsHub.SendCommandToDevice(deviceIDStr, "start_remote_view", gin.H{
			"sessionId": sessionID.String(),
			"roomName":  roomName,
			"livekitUrl": s.cfg.URL,
			"rtmpUrl":   rtmpURL,
			"width":     1920,
			"height":    1080,
			"fps":       15,
		})
		log.Printf("[RemoteView] start_remote_view sent to device %s session=%s", deviceIDStr, sessionID)
	}()

	return &models.RemoteViewStartResponse{
		SessionID:   sessionID.String(),
		DeviceID:    deviceIDStr,
		DeviceName:  device.Hostname,
		RoomName:    roomName,
		LiveKitURL:  s.cfg.URL,
		ViewerToken: viewerToken,
		ExpiresAt:   expiresAt,
	}, nil
}

func (s *RemoteViewService) StopSession(
	ctx context.Context,
	deviceIDStr, userIDStr, username, sessionIDStr, clientIP string,
) (bool, error) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return false, fmt.Errorf("invalid device id")
	}

	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		return false, fmt.Errorf("invalid user id")
	}

	var session *models.RemoteViewSession
	if sessionIDStr != "" {
		sessionID, parseErr := uuid.Parse(sessionIDStr)
		if parseErr != nil {
			return false, fmt.Errorf("invalid session id")
		}
		session, err = s.repo.GetByID(ctx, sessionID)
	} else {
		session, err = s.repo.GetActiveByDevice(ctx, deviceID)
	}
	if err != nil || session == nil {
		return false, fmt.Errorf("session not found")
	}

	if session.DeviceID != deviceID {
		return false, fmt.Errorf("session does not belong to device")
	}

	// 已结束或正在结束：幂等返回，避免重复减计数、重复删 Ingress
	if session.Status == models.RemoteViewStatusStopped || session.Status == models.RemoteViewStatusStopping {
		return false, nil
	}

	sessionDeviceID := session.DeviceID.String()

	viewerCount, err := s.repo.DecrementViewerCount(ctx, session.ID)
	if err != nil {
		return false, err
	}

	s.writeAudit(ctx, &session.ID, deviceID, userID, username, "viewer_leave", clientIP, gin.H{
		"viewerCount": viewerCount,
	})

	publisherStopped := false
	if viewerCount <= 0 {
		_ = s.repo.UpdateStatus(ctx, session.ID, models.RemoteViewStatusStopping)
		s.wsHub.SendCommandToDevice(sessionDeviceID, "stop_remote_view", gin.H{
			"sessionId": session.ID.String(),
		})
		if s.ingress != nil && session.IngressID != "" {
			if err := s.ingress.DeleteIngress(ctx, session.IngressID); err != nil {
				log.Printf("[RemoteView] delete ingress failed: %v", err)
			}
		}
		_ = s.repo.MarkStopped(ctx, session.ID, "user_stop")
		s.statsMu.Lock()
		delete(s.deviceStats, sessionDeviceID)
		s.statsMu.Unlock()
		publisherStopped = true

		s.writeAudit(ctx, &session.ID, deviceID, userID, username, "session_stop", clientIP, nil)
	}

	return publisherStopped, nil
}

func (s *RemoteViewService) GetStatus(ctx context.Context, deviceIDStr string) (*models.RemoteViewStatusResponse, error) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid device id")
	}

	s.expireStaleStartingIfNeeded(ctx, deviceID)

	session, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err != nil {
		return &models.RemoteViewStatusResponse{IsActive: false}, nil
	}

	resp := &models.RemoteViewStatusResponse{
		IsActive:    true,
		SessionID:   session.ID.String(),
		Status:      session.Status,
		ViewerCount: session.ViewerCount,
		StartedAt:   models.FormatUTC(session.StartedAt),
		Stats:       s.GetDeviceStats(deviceIDStr),
	}
	return resp, nil
}

func (s *RemoteViewService) MarkSessionActive(ctx context.Context, deviceIDStr, sessionIDStr string) error {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return fmt.Errorf("invalid device id")
	}
	sessionID, err := uuid.Parse(sessionIDStr)
	if err != nil {
		return fmt.Errorf("invalid session id")
	}

	session, err := s.repo.GetByID(ctx, sessionID)
	if err != nil || session == nil {
		return fmt.Errorf("session not found")
	}
	if session.DeviceID != deviceID {
		return fmt.Errorf("session does not belong to device")
	}
	if session.Status == models.RemoteViewStatusStopped {
		return fmt.Errorf("session already stopped")
	}

	return s.repo.UpdateStatus(ctx, sessionID, models.RemoteViewStatusActive)
}

func (s *RemoteViewService) MarkSessionFailed(ctx context.Context, deviceIDStr, sessionIDStr, reason string) error {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return fmt.Errorf("invalid device id")
	}
	sessionID, err := uuid.Parse(sessionIDStr)
	if err != nil {
		return fmt.Errorf("invalid session id")
	}
	if strings.TrimSpace(reason) == "" {
		reason = "publish_failed"
	}

	session, err := s.repo.GetByID(ctx, sessionID)
	if err != nil || session == nil {
		return fmt.Errorf("session not found")
	}
	if session.DeviceID != deviceID {
		return fmt.Errorf("session does not belong to device")
	}
	if session.Status == models.RemoteViewStatusStopped || session.Status == models.RemoteViewStatusFailed {
		return nil
	}

	if s.ingress != nil && session.IngressID != "" {
		if err := s.ingress.DeleteIngress(ctx, session.IngressID); err != nil {
			log.Printf("[RemoteView] delete ingress on failed: %v", err)
		}
	}
	if err := s.repo.MarkFailed(ctx, session.ID, reason); err != nil {
		return err
	}
	s.statsMu.Lock()
	delete(s.deviceStats, deviceIDStr)
	s.statsMu.Unlock()
	return nil
}

func (s *RemoteViewService) expireStaleStartingIfNeeded(ctx context.Context, deviceID uuid.UUID) {
	session, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err != nil || session == nil {
		return
	}
	if session.Status != models.RemoteViewStatusStarting {
		return
	}
	if time.Since(session.UpdatedAt) < s.cfg.StartingTimeout {
		return
	}

	log.Printf("[RemoteView] expiring stale starting session %s for device %s", session.ID, deviceID)
	if s.ingress != nil && session.IngressID != "" {
		_ = s.ingress.DeleteIngress(ctx, session.IngressID)
	}
	_ = s.repo.MarkFailed(ctx, session.ID, "starting_timeout")
	s.statsMu.Lock()
	delete(s.deviceStats, deviceID.String())
	s.statsMu.Unlock()
	s.wsHub.SendCommandToDevice(deviceID.String(), "stop_remote_view", gin.H{
		"sessionId": session.ID.String(),
	})
}

func (s *RemoteViewService) lockDeviceStart(deviceID string) func() {
	v, _ := s.startLocks.LoadOrStore(deviceID, &sync.Mutex{})
	mu := v.(*sync.Mutex)
	mu.Lock()
	return mu.Unlock
}

func (s *RemoteViewService) PingLiveKit(ctx context.Context) error {
	if s.ingress == nil {
		return fmt.Errorf("livekit is not configured")
	}
	return s.ingress.Ping(ctx)
}

func (s *RemoteViewService) ensureIngress(ctx context.Context, roomName, deviceID string) (string, string, error) {
	if s.ingress == nil {
		return "", "", fmt.Errorf("livekit ingress client not configured")
	}

	rtmpURL, ingressID, err := s.ingress.CreateRTMPIngress(ctx, roomName, deviceID)
	if err != nil {
		return "", "", fmt.Errorf("create ingress: %w", err)
	}
	return rtmpURL, ingressID, nil
}

func (s *RemoteViewService) writeAudit(
	ctx context.Context,
	sessionID *uuid.UUID,
	deviceID, operatorID uuid.UUID,
	operatorName, action, clientIP string,
	detail interface{},
) {
	entry := &models.RemoteViewAuditLog{
		ID:           uuid.New(),
		SessionID:    sessionID,
		DeviceID:     deviceID,
		OperatorID:   operatorID,
		OperatorName: operatorName,
		Action:       action,
		Detail:       auditDetail(detail),
		ClientIP:     clientIP,
		CreatedAt:    models.UTCNow(),
	}
	if err := s.repo.InsertAudit(ctx, entry); err != nil {
		log.Printf("[RemoteView] audit insert failed: %v", err)
	}
}

func (s *RemoteViewService) ListAuditLogs(ctx context.Context, deviceID *uuid.UUID, page, pageSize int) ([]models.RemoteViewAuditLog, int, error) {
	return s.repo.ListAuditLogs(ctx, deviceID, page, pageSize)
}

func (s *RemoteViewService) OnAgentDisconnected(ctx context.Context, deviceIDStr string) {
	deviceID, err := uuid.Parse(deviceIDStr)
	if err != nil {
		return
	}
	session, err := s.repo.GetActiveByDevice(ctx, deviceID)
	if err != nil || session == nil {
		return
	}
	_ = s.repo.MarkStopped(ctx, session.ID, "agent_offline")
	if s.ingress != nil && session.IngressID != "" {
		_ = s.ingress.DeleteIngress(ctx, session.IngressID)
	}
	s.statsMu.Lock()
	delete(s.deviceStats, deviceIDStr)
	s.statsMu.Unlock()
}

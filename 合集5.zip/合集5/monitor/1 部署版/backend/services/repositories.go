// backend/services/repositories.go
// 完整替换文件内容 - 修复 NULL 字段处理

package services

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"crypto/rand"
	"encoding/hex"

	"github.com/google/uuid"
	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
	"github.com/redis/go-redis/v9"
	"golang.org/x/crypto/bcrypt"

	_ "github.com/lib/pq"

	"enterprise-agent/backend/models"
)

var ErrRecordingRemoteStorage = fmt.Errorf("recording stored in remote object storage")

// ========== 数据库初始化 ==========

func NewDatabase() *sql.DB {
	host := os.Getenv("DB_HOST")
	if host == "" {
		host = "localhost"
	}
	port := os.Getenv("DB_PORT")
	if port == "" {
		port = "5432"
	}
	user := os.Getenv("DB_USER")
	if user == "" {
		user = "agent"
	}
	password := os.Getenv("DB_PASSWORD")
	if password == "" {
		password = "agent123"
	}
	dbname := os.Getenv("DB_NAME")
	if dbname == "" {
		dbname = "agent"
	}

	dsn := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
		host, port, user, password, dbname)

	db, err := sql.Open("postgres", dsn)
	if err != nil {
		panic(fmt.Sprintf("failed to open database: %v", err))
	}

	db.SetMaxOpenConns(30)
	db.SetMaxIdleConns(15)
	db.SetConnMaxLifetime(5 * time.Minute)

	if err := db.Ping(); err != nil {
		panic(fmt.Sprintf("failed to ping database: %v", err))
	}

	// 初始化schema（如果表不存在）
	if err := initializeSchema(db); err != nil {
		panic(fmt.Sprintf("failed to initialize schema: %v", err))
	}

	if err := seedDefaultAdmin(db); err != nil {
		panic(fmt.Sprintf("failed to seed default admin: %v", err))
	}

    if err := EnsureDefaultPolicy(db); err != nil {
        log.Printf("⚠️ 警告: 创建默认策略失败: %v", err)
    }

    if err := EnsurePolicySignatures(db); err != nil {
        log.Printf("⚠️ 警告: 修复策略签名失败: %v", err)
    }

	fmt.Println("PostgreSQL connected successfully")
	return db


}

func initializeSchema(db *sql.DB) error {
	// 检查表是否存在
	var exists bool
	err := db.QueryRow(`SELECT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'users')`).Scan(&exists)
	if err != nil {
		return err
	}

	if exists {
		// 表已存在，检查并添加缺失的列
		return migrateSchema(db)
	}

	// 读取schema文件
	schemaPath := "schema_postgresql.sql"
	schema, err := os.ReadFile(schemaPath)
	if err != nil {
		// 如果文件不存在，使用内嵌SQL
		return initEmbeddedSchema(db)
	}

	_, err = db.Exec(string(schema))
	return err
}

func migrateSchema(db *sql.DB) error {
    migrations := []string{
        // 出款和考勤业务表（如果缺失则创建）
        `CREATE TABLE IF NOT EXISTS employees (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id VARCHAR(100),
            name VARCHAR(255),
            position VARCHAR(100),
            hire_date DATE,
            work_location VARCHAR(255),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employees_employee_id ON employees(employee_id)`,
        `CREATE TABLE IF NOT EXISTS attendance_records (
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            year_month VARCHAR(7) NOT NULL,
            date DATE NOT NULL,
            status VARCHAR(50) NOT NULL,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (employee_id, year_month, date)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_attendance_records_employee_id ON attendance_records(employee_id)`,
        `CREATE TABLE IF NOT EXISTS performance_records (
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            employee_name VARCHAR(255),
            position VARCHAR(100),
            score_records JSONB,
            total_score INTEGER DEFAULT 0,
            grade VARCHAR(50),
            month VARCHAR(7) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (employee_id, month)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_performance_records_month ON performance_records(month)`,
        `CREATE TABLE IF NOT EXISTS penalty_records (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
            employee_name VARCHAR(255),
            position VARCHAR(100),
            amount NUMERIC(12,2) NOT NULL DEFAULT 0,
            category VARCHAR(100),
            reason TEXT,
            penalty_date DATE NOT NULL,
            created_by VARCHAR(100),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_penalty_records_employee_id ON penalty_records(employee_id)`,
        `CREATE INDEX IF NOT EXISTS idx_penalty_records_penalty_date ON penalty_records(penalty_date)`,
        `CREATE TABLE IF NOT EXISTS sites (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            code VARCHAR(100) NOT NULL UNIQUE,
            name VARCHAR(255) NOT NULL,
            sort_order INTEGER NOT NULL DEFAULT 0,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,
        `CREATE TABLE IF NOT EXISTS employee_accounts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            site_id UUID NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
            name VARCHAR(255),
            account_name VARCHAR(255) NOT NULL,
            shift VARCHAR(50),
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            UNIQUE (site_id, account_name)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employee_accounts_site_id ON employee_accounts(site_id)`,
        `CREATE TABLE IF NOT EXISTS site_stats (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_account_id UUID NOT NULL REFERENCES employee_accounts(id) ON DELETE CASCADE,
            site_id UUID NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
            stat_date DATE NOT NULL,
            shift VARCHAR(50),
            order_count INTEGER NOT NULL DEFAULT 0,
            avg_time_seconds INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            UNIQUE (employee_account_id, stat_date, shift)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_site_id ON site_stats(site_id)`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_employee_account_id ON site_stats(employee_account_id)`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_stat_date ON site_stats(stat_date)`,

        // 用户表
        `ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP WITH TIME ZONE`,
        
        // 策略表
        `ALTER TABLE policies ADD COLUMN IF NOT EXISTS is_current BOOLEAN DEFAULT FALSE`,
        
        // 录屏表
        `ALTER TABLE recordings ADD COLUMN IF NOT EXISTS duration INTEGER DEFAULT 0`,
        `ALTER TABLE recordings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE`,
        
        // 截图表
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS width INTEGER DEFAULT 0`,
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS height INTEGER DEFAULT 0`,
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS format VARCHAR(10) DEFAULT 'jpg'`,
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS uploaded_at TIMESTAMP WITH TIME ZONE`,
        `ALTER TABLE screenshots ADD COLUMN IF NOT EXISTS encrypted BOOLEAN DEFAULT FALSE`,
        
        // 活动日志表
        `ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS reported BOOLEAN DEFAULT FALSE`,
        `ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS reported_at TIMESTAMP WITH TIME ZONE`,
        `ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS retry_count INTEGER DEFAULT 0`,
        `ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS error_message TEXT DEFAULT ''`,

        `ALTER TABLE upload_tasks ADD COLUMN IF NOT EXISTS task_type VARCHAR(50) NOT NULL DEFAULT 'upload_recordings'`,
        `ALTER TABLE upload_tasks ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()`,

        // ========== ⭐ ==========
        `ALTER TABLE operation_logs ADD COLUMN IF NOT EXISTS execution_time_ms INTEGER DEFAULT 0`,
        `ALTER TABLE operation_logs ADD COLUMN IF NOT EXISTS target_name VARCHAR(255)`,
        
        // 索引（建议先添加列，后添加索引）
        `CREATE INDEX IF NOT EXISTS idx_screenshots_device_captured ON screenshots(device_id, captured_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_recordings_uploaded ON recordings(uploaded)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_device_started ON activity_logs(device_id, started_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_reported ON activity_logs(reported)`,

		`ALTER TABLE devices DROP CONSTRAINT IF EXISTS devices_status_check`,
        `ALTER TABLE devices ADD CONSTRAINT devices_status_check CHECK (status IN ('pending', 'approved', 'rejected'))`,
        
        // 修复错误数据
        `UPDATE devices SET status = 'approved' WHERE status NOT IN ('pending', 'approved', 'rejected')`,

        // ========== 工资记录表 ==========
        `CREATE TABLE IF NOT EXISTS salary_records (
            id VARCHAR(36) PRIMARY KEY,
            employee_id VARCHAR(100) NOT NULL,
            employee_name VARCHAR(255) NOT NULL,
            position VARCHAR(100),
            hire_date_dept VARCHAR(255),
            months_employed INTEGER DEFAULT 0,
            last_month_base DECIMAL(12,2) DEFAULT 0,
            total_increase DECIMAL(12,2) DEFAULT 0,
            base_salary DECIMAL(12,2) DEFAULT 0,
            attendance_days DECIMAL(10,2) DEFAULT 0,
            actual_base_salary DECIMAL(12,2) DEFAULT 0,
            attendance_adjustment DECIMAL(12,2) DEFAULT 0,
            half_year_unpaid_leave DECIMAL(12,2) DEFAULT 0,
            exchange_rate DECIMAL(10,4) DEFAULT 0,
            performance_score INTEGER DEFAULT 0,
            performance_bonus_b DECIMAL(12,2) DEFAULT 0,
            reward DECIMAL(12,2) DEFAULT 0,
            penalty DECIMAL(12,2) DEFAULT 0,
            advance DECIMAL(12,2) DEFAULT 0,
            other_deduction DECIMAL(12,2) DEFAULT 0,
            protection_return DECIMAL(12,2) DEFAULT 0,
            protection_fee DECIMAL(12,2) DEFAULT 0,
            total_salary DECIMAL(12,2) DEFAULT 0,
            remark TEXT,
            year_month VARCHAR(7) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(employee_id, year_month)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_employee_id ON salary_records(employee_id)`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_year_month ON salary_records(year_month)`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_employee_name ON salary_records(employee_name)`,
        `DROP TRIGGER IF EXISTS update_salary_records_updated_at ON salary_records;
        CREATE TRIGGER update_salary_records_updated_at
            BEFORE UPDATE ON salary_records
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,
        
        // ========== 操作日志表 ==========
        `CREATE TABLE IF NOT EXISTS operation_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            operator_id VARCHAR(36),
            operator_name VARCHAR(100) NOT NULL,
            operator_role VARCHAR(50),
            operation_type VARCHAR(50) NOT NULL,
            operation_module VARCHAR(50) NOT NULL,
            operation_desc TEXT NOT NULL,
            target_id VARCHAR(100),
            target_name VARCHAR(255),
            ip_address VARCHAR(45),
            user_agent TEXT,
            request_method VARCHAR(10),
            request_path VARCHAR(255),
            request_params TEXT,
            response_status INTEGER,
            execution_time_ms INTEGER,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        `CREATE INDEX IF NOT EXISTS idx_operation_logs_operator_name ON operation_logs(operator_name)`,
        `CREATE INDEX IF NOT EXISTS idx_operation_logs_created_at ON operation_logs(created_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_operation_logs_operation_module ON operation_logs(operation_module)`,
        `CREATE INDEX IF NOT EXISTS idx_operation_logs_operation_type ON operation_logs(operation_type)`,

        // ========== 远程查看（LiveKit）==========
        `CREATE TABLE IF NOT EXISTS remote_view_sessions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id),
            room_name VARCHAR(128) NOT NULL,
            status VARCHAR(32) NOT NULL,
            started_by UUID NOT NULL,
            started_by_name VARCHAR(128) NOT NULL,
            viewer_count INTEGER NOT NULL DEFAULT 0,
            publisher_identity VARCHAR(128) NOT NULL,
            livekit_url VARCHAR(512) NOT NULL,
            ingress_id VARCHAR(128),
            rtmp_url VARCHAR(512),
            started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            ended_at TIMESTAMPTZ,
            end_reason VARCHAR(64),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_rv_sessions_device_id ON remote_view_sessions(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_rv_sessions_status ON remote_view_sessions(status)`,
        `CREATE INDEX IF NOT EXISTS idx_rv_sessions_started_at ON remote_view_sessions(started_at DESC)`,

        `CREATE TABLE IF NOT EXISTS remote_view_audit_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            session_id UUID REFERENCES remote_view_sessions(id),
            device_id UUID NOT NULL,
            operator_id UUID NOT NULL,
            operator_name VARCHAR(128) NOT NULL,
            action VARCHAR(64) NOT NULL,
            detail JSONB,
            client_ip VARCHAR(64),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_rv_audit_device_id ON remote_view_audit_logs(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_rv_audit_created_at ON remote_view_audit_logs(created_at DESC)`,

        `CREATE INDEX IF NOT EXISTS idx_upload_tasks_device_status ON upload_tasks(device_id, status)`,
    }

    for _, migration := range migrations {
        if _, err := db.Exec(migration); err != nil {
            // 记录警告但继续执行
            log.Printf("Migration warning (non-fatal): %v\nSQL: %s\n", err, migration)
        }
    }
    // Ensure devices table has device_secret column
    if _, err := db.Exec(`ALTER TABLE devices ADD COLUMN IF NOT EXISTS device_secret VARCHAR(128)`); err != nil {
        log.Printf("Warning: failed to add device_secret column: %v", err)
    }

    // 为现有设备生成 device_secret（如果为空）
    if err := ensureDeviceSecrets(db); err != nil {
        log.Printf("Warning: failed to ensure device secrets: %v", err)
    }
    return nil
}

// ensureDeviceSecrets 为 devices 表中缺失 device_secret 的行生成随机 secret
func ensureDeviceSecrets(db *sql.DB) error {
    rows, err := db.Query(`SELECT id FROM devices WHERE device_secret IS NULL OR device_secret = ''`)
    if err != nil {
        return err
    }
    defer rows.Close()

    var ids []string
    for rows.Next() {
        var id string
        if err := rows.Scan(&id); err != nil {
            return err
        }
        ids = append(ids, id)
    }
    for _, id := range ids {
        // 生成 32 字节随机数，hex 编码
        b := make([]byte, 32)
        if _, err := rand.Read(b); err != nil {
            log.Printf("failed to generate device secret for %s: %v", id, err)
            continue
        }
        secret := hex.EncodeToString(b)
        if _, err := db.Exec(`UPDATE devices SET device_secret = $1 WHERE id = $2`, secret, id); err != nil {
            log.Printf("failed to store device secret for %s: %v", id, err)
            continue
        }
        log.Printf("Generated device_secret for device %s", id)
    }
    return nil
}

func initEmbeddedSchema(db *sql.DB) error {
    statements := []string{
        // `CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`,

        // ========== 用户表 ==========
        `CREATE TABLE IF NOT EXISTS users (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            username VARCHAR(100) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            email VARCHAR(255),
            real_name VARCHAR(100),
            status SMALLINT NOT NULL DEFAULT 1,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            last_login_at TIMESTAMP WITH TIME ZONE
        )`,

        // ========== 角色表 ==========
        `CREATE TABLE IF NOT EXISTS roles (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            name VARCHAR(100) NOT NULL UNIQUE,
            description TEXT,
            permissions JSONB NOT NULL DEFAULT '[]',
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 用户角色关联表 ==========
        `CREATE TABLE IF NOT EXISTS user_roles (
            user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (user_id, role_id)
        )`,

        // ========== 设备表 ==========
        `CREATE TABLE IF NOT EXISTS devices (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id VARCHAR(100),
            employee_name VARCHAR(255),
            employee_number VARCHAR(100),
            position VARCHAR(100),
            device_fingerprint VARCHAR(255) NOT NULL UNIQUE,
            hostname VARCHAR(255) NOT NULL,
            os_version VARCHAR(255),
            agent_version VARCHAR(50),
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            bound_at TIMESTAMP WITH TIME ZONE,
            last_seen_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            device_secret VARCHAR(128)
        )`,

        // ========== 设备表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_devices_device_fingerprint ON devices(device_fingerprint)`,
        `CREATE INDEX IF NOT EXISTS idx_devices_status ON devices(status)`,
        `CREATE INDEX IF NOT EXISTS idx_devices_last_seen ON devices(last_seen_at)`,
        `CREATE INDEX IF NOT EXISTS idx_devices_employee_id ON devices(employee_id)`,

        // ========== 录屏记录表 ==========
        `CREATE TABLE IF NOT EXISTS recordings (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            start_time TIMESTAMP WITH TIME ZONE NOT NULL,
            end_time TIMESTAMP WITH TIME ZONE NOT NULL,
            file_path TEXT NOT NULL,
            file_size BIGINT NOT NULL DEFAULT 0,
            sha256 VARCHAR(64),
            uploaded BOOLEAN NOT NULL DEFAULT FALSE,
            duration INTEGER DEFAULT 0,
            updated_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 录屏表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_recordings_device_id ON recordings(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_recordings_start_time ON recordings(start_time)`,
        `CREATE INDEX IF NOT EXISTS idx_recordings_uploaded ON recordings(uploaded)`,
        `CREATE INDEX IF NOT EXISTS idx_recordings_device_start ON recordings(device_id, start_time DESC)`,

        // ========== 截图表（✅ 添加新字段） ==========
        `CREATE TABLE IF NOT EXISTS screenshots (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            captured_at TIMESTAMP WITH TIME ZONE NOT NULL,
            file_path TEXT NOT NULL,
            file_size BIGINT NOT NULL DEFAULT 0,
            uploaded BOOLEAN NOT NULL DEFAULT FALSE,
            width INTEGER DEFAULT 0,
            height INTEGER DEFAULT 0,
            format VARCHAR(10) DEFAULT 'jpg',
            uploaded_at TIMESTAMP WITH TIME ZONE,
            encrypted BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 截图表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_screenshots_device_id ON screenshots(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_screenshots_captured_at ON screenshots(captured_at)`,
        `CREATE INDEX IF NOT EXISTS idx_screenshots_device_captured ON screenshots(device_id, captured_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_screenshots_uploaded ON screenshots(uploaded)`,

        // ========== 活动日志表（✅ 添加新字段） ==========
        `CREATE TABLE IF NOT EXISTS activity_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            process_name VARCHAR(255),
            window_title TEXT,
            browser_title TEXT,
            started_at TIMESTAMP WITH TIME ZONE NOT NULL,
            ended_at TIMESTAMP WITH TIME ZONE,
            is_idle BOOLEAN NOT NULL DEFAULT FALSE,
            duration_seconds INTEGER NOT NULL DEFAULT 0,
            reported BOOLEAN DEFAULT FALSE,
            reported_at TIMESTAMP WITH TIME ZONE,
            retry_count INTEGER DEFAULT 0,
            error_message TEXT DEFAULT '',
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 活动日志表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_device_id ON activity_logs(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_started_at ON activity_logs(started_at)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_process_name ON activity_logs(process_name)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_device_started ON activity_logs(device_id, started_at DESC)`,
        `CREATE INDEX IF NOT EXISTS idx_activity_logs_reported ON activity_logs(reported)`,

        // ========== 策略表 ==========
        `CREATE TABLE IF NOT EXISTS policies (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            name VARCHAR(200) NOT NULL,
            version INTEGER NOT NULL DEFAULT 1,
            content JSONB NOT NULL,
            signature VARCHAR(255),
            is_current BOOLEAN NOT NULL DEFAULT FALSE,
            status SMALLINT NOT NULL DEFAULT 1,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,

        // ========== 策略表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_policies_is_current ON policies(is_current) WHERE is_current = TRUE`,
        `CREATE INDEX IF NOT EXISTS idx_policies_version ON policies(version)`,

        // ========== 上传任务表 ==========
        `CREATE TABLE IF NOT EXISTS upload_tasks (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            task_type VARCHAR(50) NOT NULL DEFAULT 'upload_recordings',
            start_time TIMESTAMP WITH TIME ZONE NOT NULL,
            end_time TIMESTAMP WITH TIME ZONE,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            progress INTEGER NOT NULL DEFAULT 0,
            result TEXT,
            completed_at TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 上传任务表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_upload_tasks_device_id ON upload_tasks(device_id)`,
        `CREATE INDEX IF NOT EXISTS idx_upload_tasks_status ON upload_tasks(status)`,
        `CREATE INDEX IF NOT EXISTS idx_upload_tasks_created_at ON upload_tasks(created_at)`,

        // ========== 清理策略表 ==========
        `CREATE TABLE IF NOT EXISTS cleanup_policy (
            id VARCHAR(50) PRIMARY KEY DEFAULT 'default',
            auto_cleanup_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            recording_retention_days INTEGER NOT NULL DEFAULT 30,
            screenshot_retention_days INTEGER NOT NULL DEFAULT 30,
            log_retention_days INTEGER NOT NULL DEFAULT 90,
            disk_usage_threshold_percent INTEGER NOT NULL DEFAULT 80,
            cleanup_interval_minutes INTEGER NOT NULL DEFAULT 60,
            last_run_at TIMESTAMP WITH TIME ZONE,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,

        // ========== 清理日志表 ==========
        `CREATE TABLE IF NOT EXISTS cleanup_logs (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            trigger_type VARCHAR(20) NOT NULL,
            status VARCHAR(20) NOT NULL,
            deleted_recordings INTEGER NOT NULL DEFAULT 0,
            deleted_screenshots INTEGER NOT NULL DEFAULT 0,
            deleted_logs INTEGER NOT NULL DEFAULT 0,
            deleted_bytes BIGINT NOT NULL DEFAULT 0,
            message TEXT,
            started_at TIMESTAMP WITH TIME ZONE NOT NULL,
            completed_at TIMESTAMP WITH TIME ZONE NOT NULL
        )`,

        // ========== 清理日志表索引 ==========
        `CREATE INDEX IF NOT EXISTS idx_cleanup_logs_started_at ON cleanup_logs(started_at)`,
        `CREATE INDEX IF NOT EXISTS idx_cleanup_logs_trigger_type ON cleanup_logs(trigger_type)`,

        // ========== 出款与考勤业务表 ==========
        `CREATE TABLE IF NOT EXISTS employees (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id VARCHAR(100),
            name VARCHAR(255),
            position VARCHAR(100),
            hire_date DATE,
            work_location VARCHAR(255),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employees_employee_id ON employees(employee_id)`,
        `CREATE TABLE IF NOT EXISTS attendance_records (
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            year_month VARCHAR(7) NOT NULL,
            date DATE NOT NULL,
            status VARCHAR(50) NOT NULL,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (employee_id, year_month, date)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_attendance_records_employee_id ON attendance_records(employee_id)`,
        `CREATE TABLE IF NOT EXISTS performance_records (
            employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
            employee_name VARCHAR(255),
            position VARCHAR(100),
            score_records JSONB,
            total_score INTEGER DEFAULT 0,
            grade VARCHAR(50),
            month VARCHAR(7) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            PRIMARY KEY (employee_id, month)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_performance_records_month ON performance_records(month)`,
        `CREATE TABLE IF NOT EXISTS penalty_records (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
            employee_name VARCHAR(255),
            position VARCHAR(100),
            amount NUMERIC(12,2) NOT NULL DEFAULT 0,
            category VARCHAR(100),
            reason TEXT,
            penalty_date DATE NOT NULL,
            created_by VARCHAR(100),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
        )`,
        `CREATE INDEX IF NOT EXISTS idx_penalty_records_employee_id ON penalty_records(employee_id)`,
        `CREATE INDEX IF NOT EXISTS idx_penalty_records_penalty_date ON penalty_records(penalty_date)`,
        `CREATE TABLE IF NOT EXISTS sites (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            code VARCHAR(100) NOT NULL UNIQUE,
            name VARCHAR(255) NOT NULL,
            sort_order INTEGER NOT NULL DEFAULT 0,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE
        )`,
        `CREATE TABLE IF NOT EXISTS employee_accounts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            site_id UUID NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
            name VARCHAR(255),
            account_name VARCHAR(255) NOT NULL,
            shift VARCHAR(50),
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            UNIQUE (site_id, account_name)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_employee_accounts_site_id ON employee_accounts(site_id)`,
        `CREATE TABLE IF NOT EXISTS site_stats (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_account_id UUID NOT NULL REFERENCES employee_accounts(id) ON DELETE CASCADE,
            site_id UUID NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
            stat_date DATE NOT NULL,
            shift VARCHAR(50),
            order_count INTEGER NOT NULL DEFAULT 0,
            avg_time_seconds INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE,
            UNIQUE (employee_account_id, stat_date, shift)
        )`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_site_id ON site_stats(site_id)`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_employee_account_id ON site_stats(employee_account_id)`,
        `CREATE INDEX IF NOT EXISTS idx_site_stats_stat_date ON site_stats(stat_date)`,

        // ========== 添加 updated_at 自动更新触发器 ==========
        `CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql`,

        // ========== 为 users 表添加触发器 ==========
        `DROP TRIGGER IF EXISTS update_users_updated_at ON users;
        CREATE TRIGGER update_users_updated_at
            BEFORE UPDATE ON users
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,

        // ========== 为 policies 表添加触发器 ==========
        `DROP TRIGGER IF EXISTS update_policies_updated_at ON policies;
        CREATE TRIGGER update_policies_updated_at
            BEFORE UPDATE ON policies
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,

		`ALTER TABLE devices DROP CONSTRAINT IF EXISTS devices_status_check`,
        `ALTER TABLE devices ADD CONSTRAINT devices_status_check CHECK (status IN ('pending', 'approved', 'rejected'))`,

        // ========== 工资记录表 ==========
        `CREATE TABLE IF NOT EXISTS salary_records (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id VARCHAR(100) NOT NULL,
            employee_name VARCHAR(255) NOT NULL,
            position VARCHAR(100),
            hire_date_dept VARCHAR(255),
            months_employed INTEGER DEFAULT 0,
            last_month_base DECIMAL(12,2) DEFAULT 0,
            total_increase DECIMAL(12,2) DEFAULT 0,
            base_salary DECIMAL(12,2) DEFAULT 0,
            attendance_days DECIMAL(10,2) DEFAULT 0,
            actual_base_salary DECIMAL(12,2) DEFAULT 0,
            attendance_adjustment DECIMAL(12,2) DEFAULT 0,
            half_year_unpaid_leave DECIMAL(12,2) DEFAULT 0,
            exchange_rate DECIMAL(10,4) DEFAULT 0,
            performance_score INTEGER DEFAULT 0,
            performance_bonus_b DECIMAL(12,2) DEFAULT 0,
            reward DECIMAL(12,2) DEFAULT 0,
            penalty DECIMAL(12,2) DEFAULT 0,
            advance DECIMAL(12,2) DEFAULT 0,
            other_deduction DECIMAL(12,2) DEFAULT 0,
            protection_return DECIMAL(12,2) DEFAULT 0,
            protection_fee DECIMAL(12,2) DEFAULT 0,
            total_salary DECIMAL(12,2) DEFAULT 0,
            remark TEXT,
            year_month VARCHAR(7) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
            UNIQUE(employee_id, year_month)
        )`,

        `CREATE INDEX IF NOT EXISTS idx_salary_records_employee_id ON salary_records(employee_id)`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_year_month ON salary_records(year_month)`,
        `CREATE INDEX IF NOT EXISTS idx_salary_records_employee_name ON salary_records(employee_name)`,

        `DROP TRIGGER IF EXISTS update_salary_records_updated_at ON salary_records;
        CREATE TRIGGER update_salary_records_updated_at
            BEFORE UPDATE ON salary_records
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column()`,
    }

    for _, stmt := range statements {
        if _, err := db.Exec(stmt); err != nil {
            // 如果表已存在，忽略错误
            if !strings.Contains(err.Error(), "already exists") {
                return fmt.Errorf("failed to execute statement: %s\nError: %v", stmt, err)
            }
        }
    }
    return nil
}

func seedDefaultAdmin(db *sql.DB) error {
	// 插入默认角色
	defaultRoles := []struct {
		Name        string
		Description string
		Permissions []string
	}{
		{
			Name:        "管理员",
			Description: "拥有所有权限",
			Permissions: []string{
				"user:view", "user:create", "user:update", "user:delete", "user:manage",
				"role:view", "role:create", "role:update", "role:delete",
				"device:view", "device:manage", "device:bind", "device:unbind",
				"recording:view", "recording:play", "recording:export", "recording:delete", "recording:upload",
				"screenshot:view", "screenshot:delete",
				"activity:view", "activity:export", "activity:delete",
				"policy:view", "policy:create", "policy:update", "policy:delete",
				"audit:view",
			},
		},
		{
			Name:        "审计员",
			Description: "只读权限",
			Permissions: []string{
				"device:view", "recording:view", "recording:play",
				"screenshot:view", "activity:view", "audit:view",
			},
		},
		{
			Name:        "查看员",
			Description: "基础查看权限，具体功能由管理员分配",
			Permissions: []string{},
		},
	}

	var adminRoleID string
	for _, role := range defaultRoles {
		permissionsJSON, _ := json.Marshal(role.Permissions)

		var roleID string
		err := db.QueryRow(`
			INSERT INTO roles (id, name, description, permissions, created_at, updated_at)
			VALUES (gen_random_uuid(), $1, $2, $3, NOW(), NOW())
			ON CONFLICT (name) DO UPDATE SET name = EXCLUDED.name
			RETURNING id`,
			role.Name, role.Description, string(permissionsJSON)).Scan(&roleID)
		if err != nil {
			return err
		}
		if role.Name == "管理员" {
			adminRoleID = roleID
		}
	}

	if adminRoleID == "" {
		return fmt.Errorf("admin role not found")
	}

	// 创建默认管理员用户
	username := os.Getenv("ADMIN_USERNAME")
	if username == "" {
		username = "admin"
	}
	password := os.Getenv("ADMIN_PASSWORD")
	if password == "" {
		password = "admin123"
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}

	var userID string
	err = db.QueryRow(`
		INSERT INTO users (id, username, password_hash, email, real_name, status, created_at)
		VALUES (gen_random_uuid(), $1, $2, $3, $4, 1, NOW())
		ON CONFLICT (username) DO UPDATE SET username = EXCLUDED.username
		RETURNING id`,
		username, string(hash), "admin@example.com", "系统管理员").Scan(&userID)
	if err != nil {
		return err
	}

	// 关联用户和角色
	_, err = db.Exec(`
		INSERT INTO user_roles (user_id, role_id, created_at)
		VALUES (gen_random_uuid(), $1, NOW())
		ON CONFLICT (user_id, role_id) DO NOTHING`,
		userID, adminRoleID)

	// 初始化清理策略
	_, err = db.Exec(`
		INSERT INTO cleanup_policy (id, auto_cleanup_enabled, recording_retention_days, 
			screenshot_retention_days, log_retention_days, disk_usage_threshold_percent, 
			cleanup_interval_minutes, updated_at)
		VALUES (gen_random_uuid(), TRUE, 5, 5, 3, 70, 60, NOW())
		ON CONFLICT (id) DO NOTHING`)

	return err
}

func NewRedis() *redis.Client {
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "localhost:6379"
	}
	password := os.Getenv("REDIS_PASSWORD")
	db := 0
	if dbStr := os.Getenv("REDIS_DB"); dbStr != "" {
		db, _ = strconv.Atoi(dbStr)
	}
	return redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password,
		DB:       db,
	})
}

// ========== MinIO客户端 ==========

type MinIOClient struct {
	bucket    string
	enabled   bool
	rootDir   string
	endpoint  string
	accessKey string
	secretKey string
	useSSL    bool
	client    *minio.Client
}

func NewMinIO() *MinIOClient {
	bucket := os.Getenv("MINIO_BUCKET")
	if bucket == "" {
		bucket = "recordings"
	}
	rootDir := os.Getenv("UPLOADS_DIR")
	if rootDir == "" {
		rootDir = filepath.Join(".", "uploads")
	}
	absRoot, err := filepath.Abs(rootDir)
	if err == nil {
		rootDir = absRoot
	}
	m := &MinIOClient{
		bucket:    bucket,
		enabled:   true,
		rootDir:   rootDir,
		endpoint:  strings.TrimSpace(os.Getenv("MINIO_ENDPOINT")),
		accessKey: strings.TrimSpace(os.Getenv("MINIO_ACCESS_KEY")),
		secretKey: strings.TrimSpace(os.Getenv("MINIO_SECRET_KEY")),
		useSSL:    os.Getenv("MINIO_USE_SSL") == "true",
	}
	if m.endpoint != "" && m.accessKey != "" && m.secretKey != "" {
		client, err := minio.New(m.endpoint, &minio.Options{
			Creds:  credentials.NewStaticV4(m.accessKey, m.secretKey, ""),
			Secure: m.useSSL,
		})
		if err != nil {
			log.Printf("Warning: failed to initialize MinIO client: %v", err)
		} else {
			m.client = client
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			exists, bucketErr := client.BucketExists(ctx, m.bucket)
			cancel()
			if bucketErr != nil {
				log.Printf("Warning: failed to check MinIO bucket %q: %v", m.bucket, bucketErr)
			} else if !exists {
				ctx, cancel = context.WithTimeout(context.Background(), 10*time.Second)
				if err := client.MakeBucket(ctx, m.bucket, minio.MakeBucketOptions{}); err != nil {
					log.Printf("Warning: failed to create MinIO bucket %q: %v", m.bucket, err)
				}
				cancel()
			}
		}
	}
	return m
}

func (m *MinIOClient) usesRemote() bool {
	return m != nil && m.client != nil
}

func (m *MinIOClient) cleanObjectName(objectName string) (string, error) {
	cleanObjectName := strings.TrimPrefix(filepath.ToSlash(objectName), "/")
	if cleanObjectName == "" {
		return "", fmt.Errorf("object name is required")
	}
	return cleanObjectName, nil
}

func (m *MinIOClient) Save(ctx context.Context, objectName string, data []byte) error {
	if m == nil || !m.enabled {
		return nil
	}
	cleanObjectName, err := m.cleanObjectName(objectName)
	if err != nil {
		return err
	}
	if m.usesRemote() {
		_, err := m.client.PutObject(ctx, m.bucket, cleanObjectName, bytes.NewReader(data), int64(len(data)), minio.PutObjectOptions{
			ContentType: "application/octet-stream",
		})
		if err != nil {
			return fmt.Errorf("failed to upload to minio: %w", err)
		}
		return nil
	}
	if err := os.MkdirAll(m.rootDir, 0o755); err != nil {
		return err
	}
	outputPath := filepath.Join(m.rootDir, filepath.FromSlash(cleanObjectName))
	if err := os.MkdirAll(filepath.Dir(outputPath), 0o755); err != nil {
		return err
	}
	if err := os.WriteFile(outputPath, data, 0o644); err != nil {
		return err
	}
	return nil
}

func (m *MinIOClient) GetURL(ctx context.Context, objectName string) (string, error) {
	cleanObjectName, err := m.cleanObjectName(objectName)
	if err != nil {
		return "", err
	}
	if m.usesRemote() {
		presigned, err := m.client.PresignedGetObject(ctx, m.bucket, cleanObjectName, time.Hour, nil)
		if err != nil {
			return "", fmt.Errorf("failed to presign minio object: %w", err)
		}
		return presigned.String(), nil
	}
	return "/uploads/" + cleanObjectName, nil
}

func (m *MinIOClient) SaveStream(ctx context.Context, objectName string, reader io.Reader) error {
	if m == nil || !m.enabled {
		return nil
	}

	cleanObjectName, err := m.cleanObjectName(objectName)
	if err != nil {
		return err
	}

	if m.usesRemote() {
		_, err := m.client.PutObject(ctx, m.bucket, cleanObjectName, reader, -1, minio.PutObjectOptions{
			ContentType: "application/octet-stream",
		})
		if err != nil {
			return fmt.Errorf("failed to upload to minio: %w", err)
		}
		return nil
	}

	filePath := filepath.Join(m.rootDir, filepath.FromSlash(cleanObjectName))
	if err := os.MkdirAll(filepath.Dir(filePath), 0755); err != nil {
		return fmt.Errorf("failed to create directory: %w", err)
	}

	out, err := os.Create(filePath)
	if err != nil {
		return fmt.Errorf("failed to create file: %w", err)
	}
	defer out.Close()

	if _, err = io.Copy(out, reader); err != nil {
		return fmt.Errorf("failed to write file: %w", err)
	}

	return nil
}

// RemoveObject 删除 MinIO 对象或本地镜像文件
func (m *MinIOClient) RemoveObject(ctx context.Context, objectName string) error {
	if m == nil || !m.enabled {
		return nil
	}

	cleanObjectName, err := m.cleanObjectName(objectName)
	if err != nil {
		return err
	}

	if m.usesRemote() {
		return m.client.RemoveObject(ctx, m.bucket, cleanObjectName, minio.RemoveObjectOptions{})
	}

	filePath := filepath.Join(m.rootDir, filepath.FromSlash(cleanObjectName))
	if err := os.Remove(filePath); err != nil && !os.IsNotExist(err) {
		return err
	}
	return nil
}

// ========== DeviceRepository PostgreSQL实现 ==========

type DeviceRepository struct {
	db *sql.DB
}

// DeviceListOptions 设备列表查询参数
type DeviceListOptions struct {
	Page           int    // 页码
	PageSize       int    // 每页数量
	Status         string // 审核状态: pending, approved
	EmployeeSearch string // 员工搜索（姓名/工号/职位）
	DeviceStatus   string // 设备状态: pending, approved_online, approved_offline
	Keyword        string // 设备名称搜索
}

func NewDeviceRepository(db *sql.DB) *DeviceRepository {
	return &DeviceRepository{db: db}
}

// List 获取设备列表（支持多条件筛选和分页）
func (r *DeviceRepository) List(ctx context.Context, opts DeviceListOptions) ([]models.Device, int, error) {
    pageNum := opts.Page
    if pageNum < 1 {
        pageNum = 1
    }
    pageSizeNum := opts.PageSize
    if pageSizeNum < 1 {
        pageSizeNum = 20
    }
    if pageSizeNum > 100 {
        pageSizeNum = 100
    }

    offset := (pageNum - 1) * pageSizeNum
    args := []interface{}{}
    conditions := []string{}
    argIdx := 1

    // 1. 审核状态筛选
    if opts.Status != "" {
        conditions = append(conditions, fmt.Sprintf("status = $%d", argIdx))
        args = append(args, opts.Status)
        argIdx++
    }

    // 2. 员工搜索（姓名、工号、职位）
    if opts.EmployeeSearch != "" {
        searchPattern := "%" + opts.EmployeeSearch + "%"
        conditions = append(conditions, fmt.Sprintf("(employee_name ILIKE $%d OR employee_number ILIKE $%d OR position ILIKE $%d)", argIdx, argIdx+1, argIdx+2))
        args = append(args, searchPattern, searchPattern, searchPattern)
        argIdx += 3
    }

    // 3. 设备名称搜索
    if opts.Keyword != "" {
        searchPattern := "%" + opts.Keyword + "%"
        conditions = append(conditions, fmt.Sprintf("hostname ILIKE $%d", argIdx))
        args = append(args, searchPattern)
        argIdx++
    }

    // 4. 设备状态筛选（pending / approved_online / approved_offline）
    if opts.DeviceStatus != "" {
        switch opts.DeviceStatus {
        case "pending":
            conditions = append(conditions, fmt.Sprintf("status = $%d", argIdx))
            args = append(args, "pending")
            argIdx++
        case "rejected":
            conditions = append(conditions, fmt.Sprintf("status = $%d", argIdx))
            args = append(args, "rejected")
            argIdx++
        case "approved_online":
            conditions = append(conditions, "status = 'approved' AND (last_seen_at IS NOT NULL AND last_seen_at > NOW() - INTERVAL '3 minutes')")
        case "approved_offline":
            conditions = append(conditions, "status = 'approved' AND (last_seen_at IS NULL OR last_seen_at <= NOW() - INTERVAL '3 minutes')")
        }
    }

    whereClause := ""
    if len(conditions) > 0 {
        whereClause = " WHERE " + strings.Join(conditions, " AND ")
    }

    // 查询总数
    countQuery := "SELECT COUNT(*) FROM devices" + whereClause
    var total int
    if err := r.db.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
        return nil, 0, err
    }

    // 查询数据
    dataQuery := `SELECT id, employee_id, employee_name, employee_number, position, device_fingerprint, 
                         hostname, os_version, agent_version, status, bound_at, last_seen_at, created_at
                  FROM devices` + whereClause + `
                  ORDER BY created_at DESC
                  LIMIT $` + strconv.Itoa(argIdx) + ` OFFSET $` + strconv.Itoa(argIdx+1)

    args = append(args, pageSizeNum, offset)

    rows, err := r.db.QueryContext(ctx, dataQuery, args...)
    if err != nil {
        return nil, 0, err
    }
    defer rows.Close()

    var devices []models.Device
    for rows.Next() {
        var d models.Device
        var boundAt, lastSeenAt sql.NullTime
        var employeeID, employeeName, employeeNumber, position sql.NullString

        err := rows.Scan(
            &d.ID,
            &employeeID, &employeeName, &employeeNumber, &position,
            &d.DeviceFingerprint, &d.Hostname,
            &d.OSVersion, &d.AgentVersion,
            &d.Status, &boundAt, &lastSeenAt, &d.CreatedAt)
        if err != nil {
            return nil, 0, err
        }

        // 处理 NULL 值
        if employeeID.Valid {
            d.EmployeeID = employeeID.String
        }
        if employeeName.Valid {
            d.EmployeeName = employeeName.String
        }
        if employeeNumber.Valid {
            d.EmployeeNumber = employeeNumber.String
        }
        if position.Valid {
            d.Position = position.String
        }
        if boundAt.Valid {
            d.BoundAt = &boundAt.Time
        }
        if lastSeenAt.Valid {
            d.LastSeenAt = &lastSeenAt.Time
        }
        devices = append(devices, d)
    }

    return devices, total, nil
}

// ✅ 修复：使用 sql.NullString 处理 NULL 字段
func (r *DeviceRepository) Get(ctx context.Context, id uuid.UUID) (*models.Device, error) {
	var d models.Device
	var boundAt, lastSeenAt sql.NullTime
	var employeeID, employeeName, employeeNumber, position sql.NullString

    query := `SELECT id, employee_id, employee_name, employee_number, position, device_fingerprint, hostname, os_version, agent_version, status, bound_at, last_seen_at, created_at, device_secret
              FROM devices WHERE id = $1`
    var deviceSecret sql.NullString
    err := r.db.QueryRowContext(ctx, query, id).Scan(
        &d.ID,
        &employeeID, &employeeName, &employeeNumber, &position,
        &d.DeviceFingerprint, &d.Hostname,
        &d.OSVersion, &d.AgentVersion,
        &d.Status, &boundAt, &lastSeenAt, &d.CreatedAt, &deviceSecret)
	if err == sql.ErrNoRows {
		return nil, err
	}
	if err != nil {
		return nil, err
	}

	// 处理 NULL 值
	if employeeID.Valid {
		d.EmployeeID = employeeID.String
	}
	if employeeName.Valid {
		d.EmployeeName = employeeName.String
	}
	if employeeNumber.Valid {
		d.EmployeeNumber = employeeNumber.String
	}
	if position.Valid {
		d.Position = position.String
	}
	if boundAt.Valid {
		d.BoundAt = &boundAt.Time
	}
	if lastSeenAt.Valid {
		d.LastSeenAt = &lastSeenAt.Time
	}
    if deviceSecret.Valid {
        d.DeviceSecret = deviceSecret.String
    }
	return &d, nil
}

// ✅ 修复：使用 sql.NullString 处理 NULL 字段
func (r *DeviceRepository) GetByDeviceId(ctx context.Context, deviceID string) (*models.Device, error) {
	var d models.Device
	var boundAt, lastSeenAt sql.NullTime
	var employeeID, employeeName, employeeNumber, position sql.NullString

    query := `SELECT id, employee_id, employee_name, employee_number, position, device_fingerprint, hostname, os_version, agent_version, status, bound_at, last_seen_at, created_at, device_secret
              FROM devices WHERE device_fingerprint = $1`
    var deviceSecret sql.NullString
    err := r.db.QueryRowContext(ctx, query, deviceID).Scan(
        &d.ID,
        &employeeID, &employeeName, &employeeNumber, &position,
        &d.DeviceFingerprint, &d.Hostname,
        &d.OSVersion, &d.AgentVersion,
        &d.Status, &boundAt, &lastSeenAt, &d.CreatedAt, &deviceSecret)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	// 处理 NULL 值
	if employeeID.Valid {
		d.EmployeeID = employeeID.String
	}
	if employeeName.Valid {
		d.EmployeeName = employeeName.String
	}
	if employeeNumber.Valid {
		d.EmployeeNumber = employeeNumber.String
	}
	if position.Valid {
		d.Position = position.String
	}
	if boundAt.Valid {
		d.BoundAt = &boundAt.Time
	}
	if lastSeenAt.Valid {
		d.LastSeenAt = &lastSeenAt.Time
	}
    if deviceSecret.Valid {
        d.DeviceSecret = deviceSecret.String
    }
	return &d, nil
}

func (r *DeviceRepository) Create(ctx context.Context, device *models.Device) (uuid.UUID, error) {
	if device.ID == uuid.Nil {
		device.ID = uuid.New()
	}
	if device.CreatedAt.IsZero() {
		device.CreatedAt = models.UTCNow()
	}

    query := `
        INSERT INTO devices (id, employee_id, employee_name, employee_number, position, device_fingerprint, hostname, os_version, agent_version, status, bound_at, created_at, device_secret)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        ON CONFLICT (device_fingerprint) DO UPDATE SET
            hostname = EXCLUDED.hostname,
            os_version = EXCLUDED.os_version,
            last_seen_at = NOW(),
            device_secret = COALESCE(NULLIF(devices.device_secret, ''), EXCLUDED.device_secret)
        RETURNING id`
    err := r.db.QueryRowContext(ctx, query,
        device.ID,
        nullString(device.EmployeeID),
        nullString(device.EmployeeName),
        nullString(device.EmployeeNumber),
        nullString(device.Position),
        device.DeviceFingerprint,
        device.Hostname,
        device.OSVersion,
        device.AgentVersion,
        device.Status,
        nullTime(device.BoundAt),
        device.CreatedAt,
        nullString(device.DeviceSecret),
    ).Scan(&device.ID)
	if err != nil {
		return uuid.Nil, err
	}
	return device.ID, nil
}

// UpdateSecret updates device_secret for a device
func (r *DeviceRepository) UpdateSecret(ctx context.Context, id uuid.UUID, secret string) error {
    query := `UPDATE devices SET device_secret = $1 WHERE id = $2`
    _, err := r.db.ExecContext(ctx, query, secret, id)
    return err
}

func (r *DeviceRepository) UpdateInfo(ctx context.Context, id uuid.UUID, hostname, osVersion, agentVersion string) error {
	query := `UPDATE devices SET hostname = $1, os_version = $2, agent_version = $3, last_seen_at = NOW() WHERE id = $4`
	_, err := r.db.ExecContext(ctx, query, hostname, osVersion, agentVersion, id)
	return err
}

func (r *DeviceRepository) Bind(ctx context.Context, id uuid.UUID, employeeID, employeeName, employeeNumber string) error {
    // ✅ 删除 status = 'online'，只更新员工信息
    query := `UPDATE devices SET employee_id = $1, employee_name = $2, employee_number = $3, bound_at = $4 WHERE id = $5`
    _, err := r.db.ExecContext(ctx, query, employeeID, nullString(employeeName), nullString(employeeNumber), models.UTCNow(), id)
    return err
}

func (r *DeviceRepository) UpdateEmployeeInfo(ctx context.Context, id uuid.UUID, employeeID, employeeName, employeeNumber, position string) error {
	query := `UPDATE devices SET employee_id = $1, employee_name = $2, employee_number = $3, position = $4 WHERE id = $5`
	_, err := r.db.ExecContext(ctx, query, nullString(employeeID), nullString(employeeName), nullString(employeeNumber), nullString(position), id)
	return err
}

func (r *DeviceRepository) Unbind(ctx context.Context, id uuid.UUID) error {
    // ✅ 删除 status = 'offline'，只清空员工信息
    query := `UPDATE devices SET employee_id = NULL, employee_name = NULL, employee_number = NULL, position = NULL, bound_at = NULL WHERE id = $1`
    _, err := r.db.ExecContext(ctx, query, id)
    return err
}

func (r *DeviceRepository) UpdateStatus(ctx context.Context, id uuid.UUID, status string) error {
	query := `UPDATE devices SET status = $1 WHERE id = $2`
	_, err := r.db.ExecContext(ctx, query, status, id)
	return err
}

func (r *DeviceRepository) GetOnlineStats(ctx context.Context) (int, int, error) {
    // ✅ 使用 last_seen_at 判断在线状态（3分钟内活跃为在线）
    var online, offline int
    err := r.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM devices WHERE last_seen_at > NOW() - INTERVAL '3 minutes'`).Scan(&online)
    if err != nil {
        return 0, 0, err
    }
    err = r.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM devices WHERE last_seen_at IS NULL OR last_seen_at <= NOW() - INTERVAL '3 minutes'`).Scan(&offline)
    if err != nil {
        return 0, 0, err
    }
    return online, offline, nil
}

func (r *DeviceRepository) UpdateLastSeen(ctx context.Context, id uuid.UUID) error {
	_, err := r.db.ExecContext(ctx, `UPDATE devices SET last_seen_at = NOW() WHERE id = $1`, id)
	return err
}

// ========== RecordingRepository PostgreSQL实现 ==========

type RecordingRepository struct {
	db    *sql.DB
	minio *MinIOClient
}

func NewRecordingRepository(db *sql.DB, minio *MinIOClient) *RecordingRepository {
	return &RecordingRepository{db: db, minio: minio}
}

// appendRecordingTimeOverlapFilter 按时间范围重叠筛选录屏（而非完全包含）
func appendRecordingTimeOverlapFilter(conditions *[]string, args *[]interface{}, argIdx *int, startTime, endTime string) error {
	var startObj, endObj time.Time
	hasStart := startTime != ""
	hasEnd := endTime != ""

	if hasStart {
		parsed, err := models.ParseFlexibleUTC(startTime)
		if err != nil {
			return fmt.Errorf("invalid startTime format: %w", err)
		}
		startObj = parsed
	}
	if hasEnd {
		parsed, err := models.ParseFlexibleUTC(endTime)
		if err != nil {
			return fmt.Errorf("invalid endTime format: %w", err)
		}
		endObj = parsed
	}

	switch {
	case hasStart && hasEnd:
		*conditions = append(*conditions, fmt.Sprintf("start_time <= $%d AND end_time >= $%d", *argIdx, *argIdx+1))
		*args = append(*args, endObj, startObj)
		*argIdx += 2
	case hasStart:
		*conditions = append(*conditions, fmt.Sprintf("end_time >= $%d", *argIdx))
		*args = append(*args, startObj)
		*argIdx++
	case hasEnd:
		*conditions = append(*conditions, fmt.Sprintf("start_time <= $%d", *argIdx))
		*args = append(*args, endObj)
		*argIdx++
	}
	return nil
}

// List 获取录制列表（分页）
func (r *RecordingRepository) List(ctx context.Context, deviceID, startTime, endTime, page, pageSize string) ([]models.Recording, int, error) {
    pageNum := 1
    pageSizeNum := 20
    if page != "" {
        if v, err := strconv.Atoi(page); err == nil && v > 0 {
            pageNum = v
        }
    }
    if pageSize != "" {
        if v, err := strconv.Atoi(pageSize); err == nil && v > 0 {
            pageSizeNum = v
        }
    }

    offset := (pageNum - 1) * pageSizeNum
    args := []interface{}{}
    conditions := []string{}
    argIdx := 1

    if deviceID != "" {
        conditions = append(conditions, fmt.Sprintf("device_id = $%d", argIdx))
        args = append(args, deviceID)
        argIdx++
    }

    if err := appendRecordingTimeOverlapFilter(&conditions, &args, &argIdx, startTime, endTime); err != nil {
        return nil, 0, err
    }

    whereClause := ""
    if len(conditions) > 0 {
        whereClause = " WHERE " + strings.Join(conditions, " AND ")
    }

    // 查询总数
    countQuery := "SELECT COUNT(*) FROM recordings" + whereClause
    var total int
    if err := r.db.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
        return nil, 0, fmt.Errorf("count query failed: %w", err)
    }

    // 查询数据
    dataQuery := "SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, created_at" +
        " FROM recordings" + whereClause +
        " ORDER BY start_time DESC" +
        " LIMIT $" + strconv.Itoa(argIdx) + " OFFSET $" + strconv.Itoa(argIdx+1)

    args = append(args, pageSizeNum, offset)

    rows, err := r.db.QueryContext(ctx, dataQuery, args...)
    if err != nil {
        return nil, 0, fmt.Errorf("query failed: %w", err)
    }
    defer rows.Close()

    var recordings []models.Recording
    for rows.Next() {
        var rec models.Recording
        var deviceUUID uuid.UUID
        if err := rows.Scan(&rec.ID, &deviceUUID, &rec.StartTime, &rec.EndTime, &rec.FilePath, &rec.FileSize, &rec.SHA256, &rec.Uploaded, &rec.CreatedAt); err != nil {
            return nil, 0, fmt.Errorf("scan failed: %w", err)
        }
        rec.DeviceID = deviceUUID
        recordings = append(recordings, rec)
    }

    return recordings, total, nil
}

func (r *RecordingRepository) GetPlayURL(ctx context.Context, id uuid.UUID) (string, error) {
	var filePath string
	query := `SELECT file_path FROM recordings WHERE id = $1`
	err := r.db.QueryRowContext(ctx, query, id).Scan(&filePath)
	if err != nil {
		return "", err
	}
	if r.minio != nil {
		return r.minio.GetURL(ctx, filePath)
	}
	return "/uploads/" + strings.TrimPrefix(filepath.ToSlash(filePath), "/"), nil
}

func (r *RecordingRepository) GetDownloadURL(ctx context.Context, id uuid.UUID) (string, error) {
	return r.GetPlayURL(ctx, id)
}

// removeRecordingFile 删除录制对应的物理文件（兼容 /uploads/ 前缀与相对路径）
func (r *RecordingRepository) removeRecordingFile(filePath string) error {
	if filePath == "" {
		return nil
	}

	clean := strings.TrimPrefix(filepath.ToSlash(filePath), "/")
	clean = strings.TrimPrefix(clean, "uploads/")
	if clean == "" {
		return nil
	}

	fullPath := filepath.Join(r.getUploadsDir(), filepath.FromSlash(clean))
	if err := os.Remove(fullPath); err != nil && !os.IsNotExist(err) {
		return err
	}
	return nil
}

// Delete 删除单个录制（同时删除物理文件）
func (r *RecordingRepository) Delete(ctx context.Context, id uuid.UUID) error {
	var filePath string
	err := r.db.QueryRowContext(ctx, `SELECT file_path FROM recordings WHERE id = $1`, id).Scan(&filePath)
	if err != nil {
		return err
	}

	if err := r.removeRecordingFile(filePath); err != nil {
		log.Printf("Failed to delete recording file %s: %v", filePath, err)
	}

	_, err = r.db.ExecContext(ctx, `DELETE FROM recordings WHERE id = $1`, id)
	return err
}

func (r *RecordingRepository) Add(ctx context.Context, recording *models.Recording) error {
	if recording.ID == uuid.Nil {
		recording.ID = uuid.New()
	}
	if recording.CreatedAt.IsZero() {
		recording.CreatedAt = models.UTCNow()
	}
	query := `INSERT INTO recordings (id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, created_at)
              VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`
	_, err := r.db.ExecContext(ctx, query, recording.ID, recording.DeviceID, recording.StartTime, recording.EndTime,
		recording.FilePath, recording.FileSize, recording.SHA256, recording.Uploaded, recording.CreatedAt)
	return err
}

// GetByID 根据ID获取录制详情
func (r *RecordingRepository) GetByID(ctx context.Context, id uuid.UUID) (*models.Recording, error) {
	var rec models.Recording
	var deviceID uuid.UUID

	query := `SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, created_at
	          FROM recordings WHERE id = $1`
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&rec.ID, &deviceID, &rec.StartTime, &rec.EndTime, &rec.FilePath, &rec.FileSize, &rec.SHA256, &rec.Uploaded, &rec.CreatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, err
		}
		return nil, err
	}
	rec.DeviceID = deviceID
	return &rec, nil
}

// ExistsByFilePathPattern 检查是否已有以 uploadId 为文件名的存储记录
func (r *RecordingRepository) ExistsByFilePathPattern(ctx context.Context, pattern string) (bool, error) {
	var exists bool
	err := r.db.QueryRowContext(ctx,
		`SELECT EXISTS(SELECT 1 FROM recordings WHERE file_path LIKE $1)`,
		pattern).Scan(&exists)
	return exists, err
}

// GetFilePath 获取文件路径
func (r *RecordingRepository) getUploadsDir() string {
	uploadsDir := os.Getenv("UPLOADS_DIR")
	if uploadsDir == "" {
		uploadsDir = "./uploads"
	}
	return uploadsDir
}

// usesRemoteObjectStorage 仅当 MinIO 客户端可用时才走对象存储
func (r *RecordingRepository) usesRemoteObjectStorage() bool {
	return r.minio != nil && r.minio.usesRemote()
}

// GetFilePath 返回录制文件的本地绝对路径（远程 MinIO 场景返回 ErrRecordingRemoteStorage）
func (r *RecordingRepository) GetFilePath(ctx context.Context, id uuid.UUID) (string, error) {
	if r.usesRemoteObjectStorage() {
		return "", ErrRecordingRemoteStorage
	}

	var filePath string
	query := `SELECT file_path FROM recordings WHERE id = $1`
	err := r.db.QueryRowContext(ctx, query, id).Scan(&filePath)
	if err != nil {
		return "", err
	}
	if filePath == "" {
		return "", fmt.Errorf("recording file path is empty")
	}

	fullPath := filepath.Join(r.getUploadsDir(), filePath)
	if _, err := os.Stat(fullPath); err != nil {
		if os.IsNotExist(err) {
			return "", fmt.Errorf("recording file not found on disk")
		}
		return "", err
	}
	return fullPath, nil
}

// BatchDelete 批量删除录制（同时删除物理文件）
func (r *RecordingRepository) BatchDelete(ctx context.Context, ids []uuid.UUID) (int64, error) {
    if len(ids) == 0 {
        return 0, nil
    }

    // 1. 先获取所有文件的路径
    placeholders := make([]string, len(ids))
    args := make([]interface{}, len(ids))
    for i, id := range ids {
        placeholders[i] = "$" + strconv.Itoa(i+1)
        args[i] = id
    }

    rows, err := r.db.QueryContext(ctx, `SELECT id, file_path FROM recordings WHERE id IN (`+strings.Join(placeholders, ",")+`)`, args...)
    if err != nil {
        return 0, err
    }
    defer rows.Close()

    var filePaths []string
    var idList []uuid.UUID
    for rows.Next() {
        var id uuid.UUID
        var filePath string
        if err := rows.Scan(&id, &filePath); err != nil {
            continue
        }
        idList = append(idList, id)
        if filePath != "" {
            filePaths = append(filePaths, filePath)
        }
    }

    if len(idList) == 0 {
        return 0, nil
    }

    // 2. 删除物理文件
    for _, filePath := range filePaths {
        if err := r.removeRecordingFile(filePath); err != nil {
            log.Printf("Failed to delete recording file %s: %v", filePath, err)
        }
    }

    // 3. 删除数据库记录
    query := `DELETE FROM recordings WHERE id IN (` + strings.Join(placeholders, ",") + `)`
    result, err := r.db.ExecContext(ctx, query, args...)
    if err != nil {
        return 0, err
    }
    return result.RowsAffected()
}

// GetStats 获取录制统计
func (r *RecordingRepository) GetStats(ctx context.Context, deviceID, startTime, endTime string) (map[string]interface{}, error) {
	stats := make(map[string]interface{})

	args := []interface{}{}
	where := "1=1"
	argIdx := 1

	if deviceID != "" {
		where += " AND device_id = $" + strconv.Itoa(argIdx)
		args = append(args, deviceID)
		argIdx++
	}
	timeConditions := []string{}
	if err := appendRecordingTimeOverlapFilter(&timeConditions, &args, &argIdx, startTime, endTime); err != nil {
		return nil, err
	}
	for _, cond := range timeConditions {
		where += " AND " + cond
	}

	// 总数
	var total int
	err := r.db.QueryRowContext(ctx, "SELECT COUNT(*) FROM recordings WHERE "+where, args...).Scan(&total)
	if err != nil {
		return nil, err
	}
	stats["total"] = total

	// 总大小
	var totalSize int64
	err = r.db.QueryRowContext(ctx, "SELECT COALESCE(SUM(file_size), 0) FROM recordings WHERE "+where, args...).Scan(&totalSize)
	if err != nil {
		return nil, err
	}
	stats["totalSize"] = totalSize

	// 平均大小
	var avgSize float64
	err = r.db.QueryRowContext(ctx, "SELECT COALESCE(AVG(file_size), 0) FROM recordings WHERE "+where, args...).Scan(&avgSize)
	if err != nil {
		return nil, err
	}
	stats["avgSize"] = avgSize

	// 今日新增
	today := time.Now().UTC().Truncate(24 * time.Hour)
	var todayCount int
	todayQuery := "SELECT COUNT(*) FROM recordings WHERE " + where + " AND created_at >= $" + strconv.Itoa(argIdx)
	err = r.db.QueryRowContext(ctx, todayQuery, append(args, today)...).Scan(&todayCount)
	if err != nil {
		todayCount = 0
	}
	stats["todayCount"] = todayCount

	return stats, nil
}

// ListByDevice 获取指定设备的所有录制
func (r *RecordingRepository) ListByDevice(ctx context.Context, deviceID, startTime, endTime string, limit int) ([]models.Recording, error) {
    args := []interface{}{}
    conditions := []string{}
    argIdx := 1

    if deviceID != "" {
        conditions = append(conditions, fmt.Sprintf("device_id = $%d", argIdx))
        args = append(args, deviceID)
        argIdx++
    }

    if err := appendRecordingTimeOverlapFilter(&conditions, &args, &argIdx, startTime, endTime); err != nil {
        return nil, err
    }

    whereClause := ""
    if len(conditions) > 0 {
        whereClause = " WHERE " + strings.Join(conditions, " AND ")
    }

    query := "SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, created_at" +
        " FROM recordings" + whereClause +
        " ORDER BY start_time DESC LIMIT $" + strconv.Itoa(argIdx)

    args = append(args, limit)

    rows, err := r.db.QueryContext(ctx, query, args...)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    var recordings []models.Recording
    for rows.Next() {
        var rec models.Recording
        var deviceUUID uuid.UUID
        if err := rows.Scan(&rec.ID, &deviceUUID, &rec.StartTime, &rec.EndTime, &rec.FilePath, &rec.FileSize, &rec.SHA256, &rec.Uploaded, &rec.CreatedAt); err != nil {
            return nil, err
        }
        rec.DeviceID = deviceUUID
        recordings = append(recordings, rec)
    }
    return recordings, nil
}

// GetPlaybackInfo 获取播放信息
func (r *RecordingRepository) GetPlaybackInfo(ctx context.Context, id uuid.UUID) (map[string]interface{}, error) {
	var rec models.Recording
	var deviceID uuid.UUID

	query := `SELECT id, device_id, start_time, end_time, file_path, file_size, sha256, uploaded, created_at
	          FROM recordings WHERE id = $1`
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&rec.ID, &deviceID, &rec.StartTime, &rec.EndTime, &rec.FilePath, &rec.FileSize, &rec.SHA256, &rec.Uploaded, &rec.CreatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, err
		}
		return nil, err
	}

	info := map[string]interface{}{
		"id":         rec.ID.String(),
		"deviceId":   deviceID.String(),
		"startTime":  rec.StartTime,
		"endTime":    rec.EndTime,
		"duration":   rec.EndTime.Sub(rec.StartTime).Seconds(),
		"fileSize":   rec.FileSize,
		"fileSizeMB": float64(rec.FileSize) / 1024 / 1024,
		"uploaded":   rec.Uploaded,
	}
	return info, nil
}

// ExportCSV 导出为CSV
func (r *RecordingRepository) ExportCSV(ctx context.Context, deviceID, startTime, endTime string) (string, error) {
	recordings, err := r.ListByDevice(ctx, deviceID, startTime, endTime, 10000)
	if err != nil {
		return "", err
	}

	var builder strings.Builder
	builder.WriteString("ID,设备ID,开始时间,结束时间,时长(秒),文件大小(字节),SHA256,已上传,创建时间\n")

	for _, rec := range recordings {
		duration := rec.EndTime.Sub(rec.StartTime).Seconds()
		uploaded := "否"
		if rec.Uploaded {
			uploaded = "是"
		}
		builder.WriteString(fmt.Sprintf("%s,%s,%s,%s,%.2f,%d,%s,%s,%s\n",
			rec.ID.String(), rec.DeviceID.String(),
			rec.StartTime.Format(time.RFC3339), rec.EndTime.Format(time.RFC3339),
			duration, rec.FileSize, rec.SHA256, uploaded,
			rec.CreatedAt.Format(time.RFC3339)))
	}
	return builder.String(), nil
}

// ========== TaskRepository PostgreSQL实现 ==========

type TaskRepository struct {
	db *sql.DB
}

func NewTaskRepository(db *sql.DB) *TaskRepository {
	return &TaskRepository{db: db}
}

// GetPendingByDevice 获取指定设备的待处理任务
func (r *TaskRepository) GetPendingByDevice(ctx context.Context, deviceID string) ([]models.UploadTask, error) {
	// 确保 deviceID 是有效的 UUID
	deviceUUID, err := uuid.Parse(deviceID)
	if err != nil {
		return nil, fmt.Errorf("invalid device ID format: %w", err)
	}
	
	log.Printf("TaskRepository.GetPendingByDevice: querying for device %s", deviceUUID.String())
	
	query := `SELECT id, device_id, COALESCE(NULLIF(task_type, ''), 'upload_recordings'), start_time, end_time, status, progress, result, completed_at, created_at
              FROM upload_tasks WHERE status = 'pending' AND device_id = $1
              ORDER BY created_at ASC`
	
	rows, err := r.db.QueryContext(ctx, query, deviceUUID)
	if err != nil {
		log.Printf("Query error: %v", err)
		return nil, fmt.Errorf("query failed: %w", err)
	}
	defer rows.Close()
	
	var tasks []models.UploadTask
	for rows.Next() {
		var t models.UploadTask
		var completedAt sql.NullTime
		var taskDeviceUUID uuid.UUID
		
		if err := rows.Scan(&t.ID, &taskDeviceUUID, &t.Type, &t.StartTime, &t.EndTime, &t.Status, &t.Progress, &t.Result, &completedAt, &t.CreatedAt); err != nil {
			log.Printf("Scan error: %v", err)
			return nil, fmt.Errorf("scan failed: %w", err)
		}
		t.DeviceID = taskDeviceUUID
		if completedAt.Valid {
			t.CompletedAt = &completedAt.Time
		}
		tasks = append(tasks, t)
	}
	
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}
	
	log.Printf("Found %d pending tasks for device %s", len(tasks), deviceUUID.String())
	
	return tasks, nil
}

func (r *TaskRepository) List(ctx context.Context) ([]models.UploadTask, error) {
	rows, err := r.db.QueryContext(ctx, `SELECT id, device_id, COALESCE(NULLIF(task_type, ''), 'upload_recordings'), start_time, end_time, status, progress, result, completed_at, created_at
                                          FROM upload_tasks ORDER BY created_at DESC LIMIT 100`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tasks []models.UploadTask
	for rows.Next() {
		var t models.UploadTask
		var completedAt sql.NullTime
		var deviceUUID uuid.UUID
		if err := rows.Scan(&t.ID, &deviceUUID, &t.Type, &t.StartTime, &t.EndTime, &t.Status, &t.Progress, &t.Result, &completedAt, &t.CreatedAt); err != nil {
			return nil, err
		}
		t.DeviceID = deviceUUID
		if completedAt.Valid {
			t.CompletedAt = &completedAt.Time
		}
		tasks = append(tasks, t)
	}
	return tasks, nil
}

func (r *TaskRepository) GetByID(ctx context.Context, taskID string) (*models.UploadTask, error) {
	id, err := uuid.Parse(taskID)
	if err != nil {
		return nil, fmt.Errorf("invalid task id: %w", err)
	}

	var t models.UploadTask
	var deviceUUID uuid.UUID
	var completedAt sql.NullTime

	query := `SELECT id, device_id, COALESCE(NULLIF(task_type, ''), 'upload_recordings'), start_time, end_time, status, progress, result, completed_at, created_at
	          FROM upload_tasks WHERE id = $1`
	err = r.db.QueryRowContext(ctx, query, id).Scan(
		&t.ID, &deviceUUID, &t.Type, &t.StartTime, &t.EndTime,
		&t.Status, &t.Progress, &t.Result, &completedAt, &t.CreatedAt,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	t.DeviceID = deviceUUID
	if completedAt.Valid {
		t.CompletedAt = &completedAt.Time
	}
	return &t, nil
}

func (r *TaskRepository) UpdateStatus(ctx context.Context, taskID, status, result string, progress int, completedAt *time.Time) error {
	id, err := uuid.Parse(taskID)
	if err != nil {
		return err
	}
	query := `UPDATE upload_tasks SET status = $1, result = $2, progress = $3, completed_at = $4, updated_at = NOW() WHERE id = $5`
	_, err = r.db.ExecContext(ctx, query, status, result, progress, completedAt, id)
	return err
}

func (r *TaskRepository) Create(ctx context.Context, task *models.UploadTask) error {
	if task.ID == uuid.Nil {
		task.ID = uuid.New()
	}
	if task.CreatedAt.IsZero() {
		task.CreatedAt = models.UTCNow()
	}
	if task.Type == "" {
		task.Type = "upload_recordings"
	}
	query := `INSERT INTO upload_tasks (id, device_id, task_type, start_time, end_time, status, progress, result, completed_at, created_at, updated_at)
              VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $10)`
	_, err := r.db.ExecContext(ctx, query, task.ID, task.DeviceID, task.Type, task.StartTime, task.EndTime,
		task.Status, task.Progress, task.Result, task.CompletedAt, task.CreatedAt)
	return err
}

// ListRecentlyFailed 供告警扫描近期失败任务
func (r *TaskRepository) ListRecentlyFailed(ctx context.Context, since time.Duration) ([]models.UploadTask, error) {
	cutoff := time.Now().Add(-since)
	rows, err := r.db.QueryContext(ctx, `
		SELECT id, device_id, COALESCE(NULLIF(task_type, ''), 'upload_recordings'),
		       start_time, end_time, status, progress, result, completed_at, created_at
		FROM upload_tasks
		WHERE status = 'failed' AND COALESCE(completed_at, updated_at, created_at) >= $1
		ORDER BY COALESCE(completed_at, updated_at, created_at) DESC
		LIMIT 50`, cutoff)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tasks []models.UploadTask
	for rows.Next() {
		var t models.UploadTask
		var deviceUUID uuid.UUID
		var completedAt sql.NullTime
		if err := rows.Scan(
			&t.ID, &deviceUUID, &t.Type, &t.StartTime, &t.EndTime,
			&t.Status, &t.Progress, &t.Result, &completedAt, &t.CreatedAt,
		); err != nil {
			return nil, err
		}
		t.DeviceID = deviceUUID
		if completedAt.Valid {
			t.CompletedAt = &completedAt.Time
		}
		tasks = append(tasks, t)
	}
	return tasks, rows.Err()
}

// ExpireStaleRunningTasks 将长时间无更新的 running 任务标为 failed。
func (r *TaskRepository) ExpireStaleRunningTasks(ctx context.Context, timeout time.Duration) (int64, error) {
	if timeout <= 0 {
		timeout = 90 * time.Minute
	}

	cutoff := models.UTCNow().Add(-timeout)
	resultMsg := fmt.Sprintf("任务超时：超过 %d 分钟无进度更新", int(timeout.Minutes()))

	res, err := r.db.ExecContext(ctx, `
		UPDATE upload_tasks
		SET status = 'failed',
		    result = $1,
		    completed_at = NOW(),
		    updated_at = NOW()
		WHERE status = 'running'
		  AND updated_at < $2`,
		resultMsg, cutoff)
	if err != nil {
		return 0, err
	}
	return res.RowsAffected()
}

// StartStaleTaskMonitor 定期清扫卡住的 running 任务。
func (r *TaskRepository) StartStaleTaskMonitor(ctx context.Context) {
	const (
		checkInterval = 5 * time.Minute
		runningTimeout = 90 * time.Minute
	)

	ticker := time.NewTicker(checkInterval)
	defer ticker.Stop()

	log.Printf("[TaskMonitor] Stale running task monitor started (timeout=%v)", runningTimeout)

	for {
		select {
		case <-ctx.Done():
			log.Println("[TaskMonitor] Stale running task monitor stopped")
			return
		case <-ticker.C:
			n, err := r.ExpireStaleRunningTasks(ctx, runningTimeout)
			if err != nil {
				log.Printf("[TaskMonitor] Failed to expire stale tasks: %v", err)
				continue
			}
			if n > 0 {
				log.Printf("[TaskMonitor] Expired %d stale running task(s)", n)
			}
		}
	}
}

// ========== 辅助函数 ==========

// formatArg 格式化参数占位符（支持多位数）
func formatArg(n int) string {
	return "$" + strconv.Itoa(n)
}

// itoa 已弃用，使用 formatArg 代替
// 保留用于兼容性
func itoa(n int) string {
	return formatArg(n)
}

func nullString(s string) sql.NullString {
	if s == "" {
		return sql.NullString{Valid: false}
	}
	return sql.NullString{String: s, Valid: true}
}

func nullTime(t *time.Time) sql.NullTime {
	if t == nil {
		return sql.NullTime{Valid: false}
	}
	return sql.NullTime{Time: *t, Valid: true}
}

// EnsureDefaultPolicy 确保数据库中存在默认策略
func EnsureDefaultPolicy(db *sql.DB) error {
    var count int
    err := db.QueryRow(`SELECT COUNT(*) FROM policies`).Scan(&count)
    if err != nil {
        return err
    }
    
    if count > 0 {
        log.Println("📋 策略表已有数据，跳过默认策略创建")
        return nil
    }
    
    log.Println("📋 未发现策略，正在创建默认策略...")
    
    // 默认策略内容（与客户端对齐）
    defaultPolicyContent := `{
        "version": 1,
        "config": {
            "recording": {
                "enabled": true,
                "fps": 5,
                "quality": 70,
                "enableGpu": true,
                "sliceMinutes": 1
            },
            "screenshot": {
                "enabled": true,
                "intervalSeconds": 30,
                "quality": 70,
                "format": "webp"
            },
            "activity": {
                "enabled": true,
                "trackIdle": true,
                "idleThresholdSeconds": 300
            },
            "security": {
                "enableEncryption": true,
                "enableVPN": false
            },
            "cleanup": {
                "enabled": true,
                "recordingDays": 7,
                "screenshotDays": 15,
                "logDays": 3,
                "diskThresholdPercent": 80
            }
        }
    }`
    
    signature := models.SignPolicyContent(defaultPolicyContent)
    
    _, err = db.Exec(`
        INSERT INTO policies (id, name, version, content, signature, is_current, status, created_at)
        VALUES (
            gen_random_uuid(),
            '默认策略',
            1,
            $1,
            $2,
            true,
            1,
            NOW()
        )
    `, defaultPolicyContent, signature)
    
    if err != nil {
        return fmt.Errorf("插入默认策略失败: %w", err)
    }
    
    log.Println("✅ 默认策略创建成功")
    return nil
}

// EnsurePolicySignatures 用当前 POLICY_SIGNATURE_SECRET 修复空签名或过期签名
func EnsurePolicySignatures(db *sql.DB) error {
    rows, err := db.Query(`SELECT id, content, signature FROM policies`)
    if err != nil {
        return err
    }
    defer rows.Close()

    var fixed int
    for rows.Next() {
        var id uuid.UUID
        var content, signature string
        if err := rows.Scan(&id, &content, &signature); err != nil {
            return err
        }

        fresh := models.SignPolicyContent(content)
        if fresh == "" || fresh == signature {
            continue
        }

        if _, err := db.Exec(
            `UPDATE policies SET signature = $1, updated_at = NOW() WHERE id = $2`,
            fresh, id,
        ); err != nil {
            return fmt.Errorf("update policy signature %s: %w", id, err)
        }
        fixed++
    }

    if fixed > 0 {
        log.Printf("✅ 已修复 %d 条策略签名（与当前 POLICY_SIGNATURE_SECRET 对齐）", fixed)
    }
    return rows.Err()
}


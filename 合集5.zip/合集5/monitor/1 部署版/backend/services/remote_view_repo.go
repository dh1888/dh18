package services

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"log"

	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

type RemoteViewRepository struct {
	db *sql.DB
}

func NewRemoteViewRepository(db *sql.DB) *RemoteViewRepository {
	return &RemoteViewRepository{db: db}
}

func (r *RemoteViewRepository) GetActiveByDevice(ctx context.Context, deviceID uuid.UUID) (*models.RemoteViewSession, error) {
	row := r.db.QueryRowContext(ctx, `
		SELECT id, device_id, room_name, status, started_by, started_by_name, viewer_count,
		       publisher_identity, livekit_url, COALESCE(ingress_id, ''), COALESCE(rtmp_url, ''),
		       started_at, ended_at, COALESCE(end_reason, ''), created_at, updated_at
		FROM remote_view_sessions
		WHERE device_id = $1 AND status IN ('starting', 'active')
		ORDER BY created_at DESC
		LIMIT 1
	`, deviceID)

	return scanRemoteViewSession(row)
}

func (r *RemoteViewRepository) GetByID(ctx context.Context, sessionID uuid.UUID) (*models.RemoteViewSession, error) {
	row := r.db.QueryRowContext(ctx, `
		SELECT id, device_id, room_name, status, started_by, started_by_name, viewer_count,
		       publisher_identity, livekit_url, COALESCE(ingress_id, ''), COALESCE(rtmp_url, ''),
		       started_at, ended_at, COALESCE(end_reason, ''), created_at, updated_at
		FROM remote_view_sessions
		WHERE id = $1
	`, sessionID)
	return scanRemoteViewSession(row)
}

func (r *RemoteViewRepository) Create(ctx context.Context, session *models.RemoteViewSession) error {
	_, err := r.db.ExecContext(ctx, `
		INSERT INTO remote_view_sessions (
			id, device_id, room_name, status, started_by, started_by_name, viewer_count,
			publisher_identity, livekit_url, ingress_id, rtmp_url, started_at, created_at, updated_at
		) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
	`, session.ID, session.DeviceID, session.RoomName, session.Status, session.StartedBy,
		session.StartedByName, session.ViewerCount, session.PublisherIdentity, session.LiveKitURL,
		session.IngressID, session.RTMPURL, session.StartedAt, session.CreatedAt, session.UpdatedAt)
	return err
}

func (r *RemoteViewRepository) IncrementViewerCount(ctx context.Context, sessionID uuid.UUID) (int, error) {
	var count int
	err := r.db.QueryRowContext(ctx, `
		UPDATE remote_view_sessions
		SET viewer_count = viewer_count + 1, updated_at = NOW()
		WHERE id = $1
		RETURNING viewer_count
	`, sessionID).Scan(&count)
	return count, err
}

func (r *RemoteViewRepository) DecrementViewerCount(ctx context.Context, sessionID uuid.UUID) (int, error) {
	var count int
	err := r.db.QueryRowContext(ctx, `
		UPDATE remote_view_sessions
		SET viewer_count = GREATEST(viewer_count - 1, 0), updated_at = NOW()
		WHERE id = $1
		RETURNING viewer_count
	`, sessionID).Scan(&count)
	return count, err
}

func (r *RemoteViewRepository) UpdateStatus(ctx context.Context, sessionID uuid.UUID, status string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions SET status = $2, updated_at = NOW() WHERE id = $1
	`, sessionID, status)
	return err
}

func (r *RemoteViewRepository) MarkStopped(ctx context.Context, sessionID uuid.UUID, reason string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET status = 'stopped', end_reason = $2, ended_at = NOW(), updated_at = NOW()
		WHERE id = $1
	`, sessionID, reason)
	return err
}

func (r *RemoteViewRepository) MarkFailed(ctx context.Context, sessionID uuid.UUID, reason string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET status = 'failed', end_reason = $2, ended_at = NOW(), updated_at = NOW()
		WHERE id = $1 AND status IN ('starting', 'active', 'stopping')
	`, sessionID, reason)
	return err
}

func (r *RemoteViewRepository) UpdateIngress(ctx context.Context, sessionID uuid.UUID, ingressID, rtmpURL string) error {
	_, err := r.db.ExecContext(ctx, `
		UPDATE remote_view_sessions
		SET ingress_id = $2, rtmp_url = $3, updated_at = NOW()
		WHERE id = $1
	`, sessionID, ingressID, rtmpURL)
	return err
}

func (r *RemoteViewRepository) InsertAudit(ctx context.Context, entry *models.RemoteViewAuditLog) error {
	var detail interface{}
	if entry.Detail != "" {
		detail = entry.Detail
	}
	_, err := r.db.ExecContext(ctx, `
		INSERT INTO remote_view_audit_logs (
			id, session_id, device_id, operator_id, operator_name, action, detail, client_ip, created_at
		) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8,$9)
	`, entry.ID, entry.SessionID, entry.DeviceID, entry.OperatorID, entry.OperatorName,
		entry.Action, detail, entry.ClientIP, entry.CreatedAt)
	return err
}

func (r *RemoteViewRepository) ListAuditLogs(ctx context.Context, deviceID *uuid.UUID, page, pageSize int) ([]models.RemoteViewAuditLog, int, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 100 {
		pageSize = 20
	}
	offset := (page - 1) * pageSize

	countQuery := `SELECT COUNT(*) FROM remote_view_audit_logs`
	listQuery := `
		SELECT id, session_id, device_id, operator_id, operator_name, action,
		       COALESCE(detail::text, ''), COALESCE(client_ip, ''), created_at
		FROM remote_view_audit_logs
	`
	args := []interface{}{}
	argIdx := 1
	where := ""
	if deviceID != nil {
		where = fmt.Sprintf(" WHERE device_id = $%d", argIdx)
		args = append(args, *deviceID)
		argIdx++
	}

	var total int
	if err := r.db.QueryRowContext(ctx, countQuery+where, args...).Scan(&total); err != nil {
		return nil, 0, err
	}

	listQuery += where + fmt.Sprintf(" ORDER BY created_at DESC LIMIT $%d OFFSET $%d", argIdx, argIdx+1)
	args = append(args, pageSize, offset)

	rows, err := r.db.QueryContext(ctx, listQuery, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	var logs []models.RemoteViewAuditLog
	for rows.Next() {
		var item models.RemoteViewAuditLog
		var sessionID sql.NullString
		if err := rows.Scan(&item.ID, &sessionID, &item.DeviceID, &item.OperatorID, &item.OperatorName,
			&item.Action, &item.Detail, &item.ClientIP, &item.CreatedAt); err != nil {
			return nil, 0, err
		}
		if sessionID.Valid {
			if sid, err := uuid.Parse(sessionID.String); err == nil {
				item.SessionID = &sid
			}
		}
		logs = append(logs, item)
	}
	return logs, total, rows.Err()
}

func scanRemoteViewSession(row *sql.Row) (*models.RemoteViewSession, error) {
	var session models.RemoteViewSession
	var endedAt sql.NullTime
	err := row.Scan(
		&session.ID, &session.DeviceID, &session.RoomName, &session.Status,
		&session.StartedBy, &session.StartedByName, &session.ViewerCount,
		&session.PublisherIdentity, &session.LiveKitURL, &session.IngressID, &session.RTMPURL,
		&session.StartedAt, &endedAt, &session.EndReason, &session.CreatedAt, &session.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}
	if endedAt.Valid {
		session.EndedAt = &endedAt.Time
	}
	return &session, nil
}

func auditDetail(v interface{}) string {
	if v == nil {
		return ""
	}
	b, err := json.Marshal(v)
	if err != nil {
		log.Printf("[RemoteView] audit detail marshal failed: %v", err)
		return ""
	}
	return string(b)
}

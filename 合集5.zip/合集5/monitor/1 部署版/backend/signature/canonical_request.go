// backend/signature/canonical_request.go
// Canonical Request Builder - v1 specification implementation
// This file defines the canonical request construction rules for signature v1

package signature

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/url"
	"strings"
)

// CanonicalRequest represents a canonicalized HTTP request for signature computation
type CanonicalRequest struct {
	Timestamp  string // ISO 8601 UTC format: YYYY-MM-DDTHH:mm:ssZ
	HTTPMethod string // UPPERCASE: POST, GET, PUT, DELETE, PATCH
	Path       string // Absolute URL path (decoded)
	BodyHash   string // SHA256(body) in lowercase hex
}

// BuildCanonical constructs a canonical request from raw inputs
// This is the ONLY approved way to build canonical requests for v1
func BuildCanonical(timestamp, method, path string, bodyBytes []byte) *CanonicalRequest {
	// 1. Normalize HTTP method to UPPERCASE
	method = strings.ToUpper(method)

	// 2. Decode and normalize path
	decodedPath := path
	if unescaped, err := url.PathUnescape(path); err == nil {
		decodedPath = unescaped
	}

	// 3. Calculate body hash
	bodyHash := sha256.Sum256(bodyBytes)
	bodyHashHex := hex.EncodeToString(bodyHash[:])

	return &CanonicalRequest{
		Timestamp:  timestamp,
		HTTPMethod: method,
		Path:       decodedPath,
		BodyHash:   bodyHashHex,
	}
}

// String returns the canonical message for HMAC computation
// Format: TIMESTAMP + HTTP_METHOD + PATH + BODY_HASH (no separators)
func (cr *CanonicalRequest) String() string {
	return cr.Timestamp + cr.HTTPMethod + cr.Path + cr.BodyHash
}

// Message returns the canonical message (same as String)
func (cr *CanonicalRequest) Message() string {
	return cr.String()
}

// Validate checks if canonical request is valid according to v1 spec
func (cr *CanonicalRequest) Validate() error {
	if cr == nil {
		return fmt.Errorf("canonical request is nil")
	}

	// Validate timestamp format (ISO 8601 UTC)
	if !isValidRFC3339Timestamp(cr.Timestamp) {
		return fmt.Errorf("invalid timestamp format: %s (must be YYYY-MM-DDTHH:mm:ssZ)", cr.Timestamp)
	}

	// Validate HTTP method
	if !isValidHTTPMethod(cr.HTTPMethod) {
		return fmt.Errorf("invalid HTTP method: %s (must be uppercase)", cr.HTTPMethod)
	}

	// Validate path (must start with /)
	if !strings.HasPrefix(cr.Path, "/") {
		return fmt.Errorf("path must start with /: %s", cr.Path)
	}

	// Validate body hash (must be 64-char lowercase hex)
	if !isValidHex(cr.BodyHash, 64) {
		return fmt.Errorf("invalid body hash: %s (must be 64-char lowercase hex)", cr.BodyHash)
	}

	return nil
}

// isValidRFC3339Timestamp checks if timestamp matches YYYY-MM-DDTHH:mm:ssZ format
func isValidRFC3339Timestamp(ts string) bool {
	if len(ts) != 20 {
		return false // Exact length: YYYY-MM-DDTHH:mm:ssZ
	}
	if ts[19] != 'Z' {
		return false
	}
	if ts[10] != 'T' {
		return false
	}
	if ts[4] != '-' || ts[7] != '-' {
		return false
	}
	if ts[13] != ':' || ts[16] != ':' {
		return false
	}
	// All other characters must be digits
	digits := map[int]bool{0: true, 1: true, 2: true, 3: true, 5: true, 6: true,
		8: true, 9: true, 11: true, 12: true, 14: true, 15: true, 17: true, 18: true}
	for i, c := range ts {
		if digits[i] && (c < '0' || c > '9') {
			return false
		}
	}
	return true
}

// isValidHTTPMethod checks if method is uppercase and known
func isValidHTTPMethod(method string) bool {
	valid := map[string]bool{
		"GET":     true,
		"POST":    true,
		"PUT":     true,
		"DELETE":  true,
		"PATCH":   true,
		"HEAD":    true,
		"OPTIONS": true,
	}
	return valid[method]
}

// isValidHex checks if string is N-character lowercase hexadecimal
func isValidHex(s string, length int) bool {
	if len(s) != length {
		return false
	}
	for _, c := range s {
		if (c < '0' || c > '9') && (c < 'a' || c > 'f') {
			return false
		}
	}
	return true
}

// ComputeSignature calculates HMAC-SHA256 signature
// This is the v1 signature algorithm
func ComputeSignature(canonicalMessage string, deviceSecret string) string {
	mac := hmac.New(sha256.New, []byte(deviceSecret))
	mac.Write([]byte(canonicalMessage))
	return hex.EncodeToString(mac.Sum(nil))
}

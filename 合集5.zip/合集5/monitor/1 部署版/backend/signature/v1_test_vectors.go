// backend/signature/v1_test_vectors.go
// v1 Protocol Regression Test Vectors
// These vectors are FROZEN and must produce identical signatures in both Go and C#

package signature

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"testing"
)

// TestVector defines a fixed input and expected output for regression testing
type TestVector struct {
	Name              string
	Timestamp         string
	Method            string
	Path              string
	Body              string
	DeviceSecret      string
	ExpectedSignature string
}

// GetV1TestVectors returns all frozen test vectors for protocol v1
// These MUST NOT change and must match C# implementation exactly
func GetV1TestVectors() []TestVector {
	return []TestVector{
		{
			Name:              "POST upload chunk with JSON",
			Timestamp:         "2026-06-13T14:30:45Z",
			Method:            "POST",
			Path:              "/api/v1/upload/chunk",
			Body:              `{"uploadId":"550e8400-e29b-41d4-a716-446655440000","chunkIndex":0,"totalChunks":5}`,
			DeviceSecret:      "a1b2c3d4e5f6789012345678901234567890123456789012345678901234567",
			ExpectedSignature: "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
		},
		{
			Name:              "POST upload complete",
			Timestamp:         "2026-06-13T14:30:50Z",
			Method:            "POST",
			Path:              "/api/v1/upload/complete",
			Body:              `{"uploadId":"550e8400-e29b-41d4-a716-446655440000","deviceId":"e8c7b3f9-4d3e-4c5a-8a2c-5d5d5d5d5d5d"}`,
			DeviceSecret:      "f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a69871f1e2d3c4b5a698",
			ExpectedSignature: "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
		},
		{
			Name:              "GET device verify with empty body",
			Timestamp:         "2026-06-13T14:31:00Z",
			Method:            "GET",
			Path:              "/api/v1/devices/verify",
			Body:              "",
			DeviceSecret:      "0102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f20",
			ExpectedSignature: "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d",
		},
		{
			Name:              "DELETE with different method",
			Timestamp:         "2026-06-13T14:31:05Z",
			Method:            "DELETE",
			Path:              "/api/v1/devices/abc-123",
			Body:              "",
			DeviceSecret:      "aaaabbbbccccddddeeeeffffgggghhhh11112222333344445555666677778888",
			ExpectedSignature: "", // Will be computed
		},
		{
			Name:              "PUT with patch body",
			Timestamp:         "2026-06-13T14:31:10Z",
			Method:            "PUT",
			Path:              "/api/v1/settings/config",
			Body:              `{"enabled":true,"timeout":30}`,
			DeviceSecret:      "88887777666655554444333322221111ffffeeeeddddcccbbbbaaa99998888777",
			ExpectedSignature: "", // Will be computed
		},
	}
}

// ComputeSignatureV1 computes a v1 signature from inputs
func ComputeSignatureV1(timestamp, method, path string, bodyBytes []byte, deviceSecret string) string {
	cr := BuildCanonical(timestamp, method, path, bodyBytes)
	message := cr.Message()

	mac := hmac.New(sha256.New, []byte(deviceSecret))
	mac.Write([]byte(message))
	return hex.EncodeToString(mac.Sum(nil))
}

// TestV1Regression verifies that all test vectors produce expected signatures
func TestV1Regression(t *testing.T) {
	vectors := GetV1TestVectors()

	for _, vec := range vectors {
		t.Run(vec.Name, func(t *testing.T) {
			computed := ComputeSignatureV1(vec.Timestamp, vec.Method, vec.Path, []byte(vec.Body), vec.DeviceSecret)

			if vec.ExpectedSignature != "" && computed != vec.ExpectedSignature {
				t.Errorf("Signature mismatch for %s\n  Expected: %s\n  Got:      %s", vec.Name, vec.ExpectedSignature, computed)
			} else if vec.ExpectedSignature == "" {
				// For new vectors, just verify it's a valid 64-char hex
				if len(computed) != 64 {
					t.Errorf("Invalid signature length for %s: %d (expected 64)", vec.Name, len(computed))
				}
				t.Logf("Vector %s: %s", vec.Name, computed)
			}
		})
	}
}

// TestV1ParityWithCSharp verifies Go signatures match C# output (manual cross-check)
func TestV1ParityWithCSharp(t *testing.T) {
	vectors := GetV1TestVectors()[:3] // Only test first 3 (confirmed via C# test)

	expectedCSharpOutputs := map[string]string{
		"POST upload chunk with JSON": "941657ad01071026c1fc36ca103198b41ba0d93feb225d601468dae157fa8f01",
		"POST upload complete":        "17b00537ac005390dab846296e5998c45e5b099272e11f3aef713aa4f59a62c5",
		"GET device verify with empty body": "63cde4e840a1879b7d662214a796d6814eccc1c36cbb143381b903ccc4e7984d",
	}

	for _, vec := range vectors {
		t.Run(vec.Name, func(t *testing.T) {
			computed := ComputeSignatureV1(vec.Timestamp, vec.Method, vec.Path, []byte(vec.Body), vec.DeviceSecret)
			expected := expectedCSharpOutputs[vec.Name]

			if computed != expected {
				t.Errorf("Parity mismatch for %s\n  Expected (C#): %s\n  Got (Go):      %s", vec.Name, expected, computed)
			} else {
				t.Logf("✓ Parity verified for %s", vec.Name)
			}
		})
	}
}

// BenchmarkV1Signature benchmarks signature computation
func BenchmarkV1Signature(b *testing.B) {
	vector := GetV1TestVectors()[0]
	body := []byte(vector.Body)

	b.ReportAllocs()
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		_ = ComputeSignatureV1(vector.Timestamp, vector.Method, vector.Path, body, vector.DeviceSecret)
	}
}

// PrintV1TestVectors prints all test vectors in a readable format
func PrintV1TestVectors() {
	vectors := GetV1TestVectors()

	fmt.Println("=== v1 Protocol Test Vectors (FROZEN) ===\n")

	for i, vec := range vectors {
		sig := ComputeSignatureV1(vec.Timestamp, vec.Method, vec.Path, []byte(vec.Body), vec.DeviceSecret)

		fmt.Printf("Vector %d: %s\n", i+1, vec.Name)
		fmt.Printf("  Timestamp: %s\n", vec.Timestamp)
		fmt.Printf("  Method:    %s\n", vec.Method)
		fmt.Printf("  Path:      %s\n", vec.Path)
		fmt.Printf("  Body:      %s\n", vec.Body)
		fmt.Printf("  Secret:    %s\n", vec.DeviceSecret)
		fmt.Printf("  Signature: %s\n\n", sig)
	}
}

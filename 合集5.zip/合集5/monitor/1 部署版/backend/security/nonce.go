// backend/security/nonce.go
package security

import (
	"context"
	"errors"
	"sync"
	"time"
)

var (
	ErrNonceReused   = errors.New("nonce already used")
	ErrNonceTooLarge = errors.New("nonce too large")
	ErrCacheFull     = errors.New("nonce cache full")
)

// NonceCache 内存版 nonce 防重放缓存
//
// 适用于：
// - 单机
// - 中低并发
//
// 多实例请使用 Redis SETNX
type NonceCache struct {
	mu sync.RWMutex

	// nonce -> 创建时间
	items map[string]time.Time

	// nonce 有效期
	ttl time.Duration

	// 最大缓存数
	maxEntries int

	// cleanup 周期
	cleanupInterval time.Duration

	// lifecycle
	ctx    context.Context
	cancel context.CancelFunc

	wg sync.WaitGroup
}

// NewNonceCache 创建 cache
func NewNonceCache(
	ttl time.Duration,
	maxEntries int,
) *NonceCache {

	if ttl <= 0 {
		ttl = 5 * time.Minute
	}

	if maxEntries <= 0 {
		maxEntries = 100000
	}

	cleanupInterval := ttl / 2

	if cleanupInterval > time.Minute {
		cleanupInterval = time.Minute
	}

	if cleanupInterval < 10*time.Second {
		cleanupInterval = 10 * time.Second
	}

	ctx, cancel := context.WithCancel(
		context.Background(),
	)

	cache := &NonceCache{
		items:           make(map[string]time.Time),
		ttl:             ttl,
		maxEntries:      maxEntries,
		cleanupInterval: cleanupInterval,
		ctx:             ctx,
		cancel:          cancel,
	}

	cache.wg.Add(1)

	go cache.cleanupLoop()

	return cache
}

// CheckAndStore 原子检查+写入
func (c *NonceCache) CheckAndStore(
	nonce string,
) error {

	if nonce == "" {
		return ErrNonceTooLarge
	}

	if len(nonce) > 128 {
		return ErrNonceTooLarge
	}

	now := time.Now()

	c.mu.Lock()
	defer c.mu.Unlock()

	// nonce 已存在
	if createdAt, exists := c.items[nonce]; exists {

		// 未过期 => replay
		if now.Sub(createdAt) <= c.ttl {
			return ErrNonceReused
		}

		// 已过期删除
		delete(c.items, nonce)
	}

	// 防止内存爆炸
	if len(c.items) >= c.maxEntries {

		// 尝试 cleanup
		c.cleanupLocked(now)

		// 再次检查
		if len(c.items) >= c.maxEntries {
			return ErrCacheFull
		}
	}

	c.items[nonce] = now

	return nil
}

// Exists nonce 是否存在
func (c *NonceCache) Exists(
	nonce string,
) bool {

	now := time.Now()

	c.mu.RLock()

	createdAt, exists := c.items[nonce]

	c.mu.RUnlock()

	if !exists {
		return false
	}

	// 已过期
	if now.Sub(createdAt) > c.ttl {

		c.mu.Lock()

		// double check
		if createdAt2, ok := c.items[nonce]; ok {

			if now.Sub(createdAt2) > c.ttl {
				delete(c.items, nonce)
			}
		}

		c.mu.Unlock()

		return false
	}

	return true
}

// Count 当前数量
func (c *NonceCache) Count() int {

	c.mu.RLock()
	defer c.mu.RUnlock()

	return len(c.items)
}

// cleanupLoop
func (c *NonceCache) cleanupLoop() {
	defer c.wg.Done()

	ticker := time.NewTicker(
		c.cleanupInterval,
	)

	defer ticker.Stop()

	for {
		select {

		case <-c.ctx.Done():
			return

		case <-ticker.C:

			now := time.Now()

			c.mu.Lock()

			c.cleanupLocked(now)

			c.mu.Unlock()
		}
	}
}

// cleanupLocked
//
// 调用方必须持有锁
func (c *NonceCache) cleanupLocked(
	now time.Time,
) {

	for nonce, createdAt := range c.items {

		if now.Sub(createdAt) > c.ttl {
			delete(c.items, nonce)
		}
	}
}

// Close 关闭 cache
func (c *NonceCache) Close() error {

	c.cancel()

	c.wg.Wait()

	return nil
}

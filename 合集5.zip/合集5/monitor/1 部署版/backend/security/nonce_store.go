package security

import (
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

// DistributedNonceStore 签名 nonce 防重放（Redis 优先，内存兜底）
type DistributedNonceStore struct {
	redis *redis.Client
	mem   *NonceCache
	ttl   time.Duration
}

func NewDistributedNonceStore(redisClient *redis.Client, ttl time.Duration) *DistributedNonceStore {
	if ttl <= 0 {
		ttl = 10 * time.Minute
	}
	return &DistributedNonceStore{
		redis: redisClient,
		mem:   NewNonceCache(ttl, 100000),
		ttl:   ttl,
	}
}

func (s *DistributedNonceStore) CheckAndStore(key string) error {
	if key == "" {
		return ErrInvalidNonce
	}
	if len(key) > 256 {
		return ErrNonceTooLarge
	}

	redisKey := "sig_nonce:" + key

	if s.redis != nil {
		ok, err := s.redis.SetNX(context.Background(), redisKey, "1", s.ttl).Result()
		if err == nil {
			if !ok {
				return ErrNonceReused
			}
			return nil
		}
	}

	return s.mem.CheckAndStore(key)
}

func (s *DistributedNonceStore) Close() error {
	if s.mem != nil {
		return s.mem.Close()
	}
	return nil
}

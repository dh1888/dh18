package models

import (
	"time"

	"github.com/google/uuid"
)

const (
	RemoteViewStatusStarting = "starting"
	RemoteViewStatusActive   = "active"
	RemoteViewStatusStopping = "stopping"
	RemoteViewStatusStopped  = "stopped"
	RemoteViewStatusFailed   = "failed"
)

type RemoteViewSession struct {
	ID                 uuid.UUID  `json:"id"`
	DeviceID           uuid.UUID  `json:"deviceId"`
	RoomName           string     `json:"roomName"`
	Status             string     `json:"status"`
	StartedBy          uuid.UUID  `json:"startedBy"`
	StartedByName      string     `json:"startedByName"`
	ViewerCount        int        `json:"viewerCount"`
	PublisherIdentity  string     `json:"publisherIdentity"`
	LiveKitURL         string     `json:"livekitUrl"`
	IngressID          string     `json:"ingressId,omitempty"`
	RTMPURL            string     `json:"rtmpUrl,omitempty"`
	StartedAt          time.Time  `json:"startedAt"`
	EndedAt            *time.Time `json:"endedAt,omitempty"`
	EndReason          string     `json:"endReason,omitempty"`
	CreatedAt          time.Time  `json:"createdAt"`
	UpdatedAt          time.Time  `json:"updatedAt"`
}

type RemoteViewAuditLog struct {
	ID           uuid.UUID `json:"id"`
	SessionID    *uuid.UUID `json:"sessionId,omitempty"`
	DeviceID     uuid.UUID `json:"deviceId"`
	OperatorID   uuid.UUID `json:"operatorId"`
	OperatorName string    `json:"operatorName"`
	Action       string    `json:"action"`
	Detail       string    `json:"detail,omitempty"`
	ClientIP     string    `json:"clientIp,omitempty"`
	CreatedAt    time.Time `json:"createdAt"`
}

type RemoteViewStartResponse struct {
	SessionID   string    `json:"sessionId"`
	DeviceID    string    `json:"deviceId"`
	DeviceName  string    `json:"deviceName"`
	RoomName    string    `json:"roomName"`
	LiveKitURL  string    `json:"livekitUrl"`
	ViewerToken string    `json:"viewerToken"`
	ExpiresAt   time.Time `json:"expiresAt"`
}

type RemoteViewStatusResponse struct {
	IsActive    bool      `json:"isActive"`
	SessionID   string    `json:"sessionId,omitempty"`
	Status      string    `json:"status,omitempty"`
	ViewerCount int       `json:"viewerCount"`
	StartedAt   string    `json:"startedAt,omitempty"`
	Stats       *RemoteViewStatsPayload `json:"stats,omitempty"`
}

type RemoteViewStatsPayload struct {
	FPS         int    `json:"fps"`
	BitrateKbps int    `json:"bitrateKbps"`
	Encoder     string `json:"encoder"`
}

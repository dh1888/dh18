// frontend/store/websocket.ts
import { defineStore } from "pinia";
import { ref, computed, watch } from "vue";
import type { WSMessage } from "@api/types";
import { useUserStore } from "./user";

const WS_CONFIG = {
  BASE_RECONNECT_DELAY: 1000,
  MAX_RECONNECT_DELAY: 60000,
  PING_INTERVAL: 20000,
  PONG_TIMEOUT: 60000,
  MAX_MESSAGES: 100,
  CONNECTION_TIMEOUT: 10000,
} as const;

export const useWebSocketStore = defineStore("websocket", () => {
  const ws = ref<WebSocket | null>(null);
  const connected = ref(false);
  const connecting = ref(false);
  const reconnecting = ref(false);
  const onlineDevices = ref<string[]>([]);
  const messages = ref<WSMessage[]>([]);
  const reconnectAttempts = ref(0);
  const isManualDisconnect = ref(false);

  let heartbeatInterval: number | null = null;
  let reconnectTimer: number | null = null;
  let connectionTimer: number | null = null;
  let lastPongTime = Date.now();

  const deviceCount = computed(() => onlineDevices.value.length);
  const userStore = useUserStore();

  const devLog = (...args: any[]) => {
    if (import.meta.env.DEV) {
      console.debug(...args);
    }
  };

  // 获取 WebSocket URL
  const getWebSocketUrl = (token: string): string => {
    let wsBaseUrl = import.meta.env.VITE_WS_URL;

    if (!wsBaseUrl) {
      const isDev = import.meta.env.DEV;
      if (isDev) {
        wsBaseUrl = "ws://localhost:8080";
      } else {
        const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
        wsBaseUrl = `${protocol}//${window.location.host}`;
      }
    }

    wsBaseUrl = wsBaseUrl.replace(/\/$/, "");
    const fullUrl = `${wsBaseUrl}/ws/admin?token=${encodeURIComponent(token)}`;

    return fullUrl;
  };
  const startHeartbeat = () => {
    if (heartbeatInterval) {
      clearInterval(heartbeatInterval);
    }

    heartbeatInterval = window.setInterval(() => {
      if (ws.value?.readyState === WebSocket.OPEN) {
        const pingMsg = { type: "ping", timestamp: Date.now() };
        send(pingMsg);

        const timeSinceLastPong = Date.now() - lastPongTime;
        if (timeSinceLastPong > WS_CONFIG.PONG_TIMEOUT) {
          console.warn("WebSocket pong timeout, reconnecting...");
          ws.value?.close();
        }
      } else {
      }
    }, WS_CONFIG.PING_INTERVAL);
  };

  const stopHeartbeat = () => {
    if (heartbeatInterval) {
      clearInterval(heartbeatInterval);
      heartbeatInterval = null;
    }
  };

  const clearReconnectTimer = () => {
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
  };

  const shouldRefreshToken = (): boolean => {
    if (!userStore.expiresAt) return false;
    const expiry = new Date(userStore.expiresAt);
    if (isNaN(expiry.getTime())) return false;
    return expiry.getTime() - Date.now() < 5 * 60 * 1000;
  };

  const refreshTokenBeforeReconnect = async (): Promise<string | null> => {
    if (!userStore.refreshToken) {
      return null;
    }

    if (!userStore.isAuthenticated || shouldRefreshToken()) {
      const ok = await userStore.refresh(false);
      return ok ? userStore.token : null;
    }

    return userStore.token || null;
  };

  const scheduleReconnect = () => {
    if (isManualDisconnect.value) return;

    clearReconnectTimer();
    reconnecting.value = true;

    const baseDelay = Math.min(
      Math.pow(2, reconnectAttempts.value) * WS_CONFIG.BASE_RECONNECT_DELAY,
      WS_CONFIG.MAX_RECONNECT_DELAY,
    );
    const jitter = Math.random() * 1000;
    const delay = baseDelay + jitter;

    reconnectTimer = window.setTimeout(async () => {
      reconnectAttempts.value++;
      devLog(
        `WebSocket reconnecting... attempt ${reconnectAttempts.value} after ${Math.round(delay)}ms`,
      );

      const token = await refreshTokenBeforeReconnect();
      if (!token) {
        devLog("WebSocket reconnect skipped: unable to refresh token");
        reconnecting.value = false;
        return;
      }

      connect(token, true);
    }, delay);
  };

  const startConnectionTimeout = () => {
    if (connectionTimer) clearTimeout(connectionTimer);
    connectionTimer = window.setTimeout(() => {
      if (connecting.value && !connected.value) {
        console.warn("WebSocket connection timeout");
        ws.value?.close();
        connecting.value = false;
      }
    }, WS_CONFIG.CONNECTION_TIMEOUT);
  };

  const connect = (token: string, isReconnect = false) => {
    if (!token) {
      console.warn("No token provided for WebSocket connection");
      return;
    }

    if (ws.value?.readyState === WebSocket.OPEN && !isReconnect) {
      return;
    }

    if (connecting.value) {
      return;
    }

    connecting.value = true;
    startConnectionTimeout();

    if (ws.value) {
      ws.value.close();
      ws.value = null;
    }

    try {
      const wsUrl = getWebSocketUrl(token);
      ws.value = new WebSocket(wsUrl);

      ws.value.onopen = () => {
        connected.value = true;
        connecting.value = false;
        reconnecting.value = false;
        reconnectAttempts.value = 0;
        lastPongTime = Date.now();
        startHeartbeat();

        if (connectionTimer) {
          clearTimeout(connectionTimer);
          connectionTimer = null;
        }
      };

      ws.value.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data) as WSMessage;

          if (data.type === "pong") {
            lastPongTime = Date.now();
            return;
          }

          handleMessage(data);
        } catch (e) {
          console.error("Parse WebSocket message error:", e);
        }
      };

      // ✅ 修复：移除未使用的 event 参数，或者使用 _event 表示故意忽略
      ws.value.onclose = () => {
        connected.value = false;
        connecting.value = false;
        stopHeartbeat();

        if (!isManualDisconnect.value) {
          onlineDevices.value = [];
          scheduleReconnect();
        }
      };

      ws.value.onerror = (error) => {
        console.error("WebSocket error:", error);
      };
    } catch (error) {
      console.error("Failed to create WebSocket connection:", error);
      connecting.value = false;
      if (!isManualDisconnect.value) {
        scheduleReconnect();
      }
    }
  };

  const handleMessage = (data: WSMessage) => {
    messages.value.unshift(data);
    if (messages.value.length > WS_CONFIG.MAX_MESSAGES) {
      messages.value.pop();
    }

    switch (data.type) {
      case "online_devices":
        onlineDevices.value = data.devices || [];
        break;
      case "device_status":
        if (data.deviceId && data.status) {
          if (data.status === "online") {
            if (!onlineDevices.value.includes(data.deviceId)) {
              onlineDevices.value.push(data.deviceId);
            }
          } else {
            onlineDevices.value = onlineDevices.value.filter(
              (id) => id !== data.deviceId,
            );
          }

          window.dispatchEvent(
            new CustomEvent("device-status-change", {
              detail: { deviceId: data.deviceId, status: data.status },
            }),
          );
        }
        break;
      case "policy_update":
        window.dispatchEvent(
          new CustomEvent("policy-update", { detail: data }),
        );
        break;
      case "device_info_update":
        window.dispatchEvent(
          new CustomEvent("device-info-update", { detail: data }),
        );
        break;
      case "device_registered":
        window.dispatchEvent(
          new CustomEvent("device-registered", { detail: data }),
        );
        break;
      case "task_notification":
      case "task_created":
      case "task_status_update":
      case "task_cancelled":
        window.dispatchEvent(
          new CustomEvent("task-notification", { detail: data }),
        );
        break;
    }
  };

  const disconnect = () => {
    isManualDisconnect.value = true;
    connecting.value = false;
    reconnecting.value = false;
    stopHeartbeat();
    clearReconnectTimer();

    if (connectionTimer) {
      clearTimeout(connectionTimer);
      connectionTimer = null;
    }

    if (ws.value) {
      ws.value.close(1000, "Normal closure");
      ws.value = null;
    }

    connected.value = false;
    onlineDevices.value = [];
    reconnectAttempts.value = 0;
  };

  const send = (data: any): boolean => {
    if (ws.value?.readyState === WebSocket.OPEN) {
      const message = JSON.stringify(data);
      ws.value.send(message);
      return true;
    } else {
      return false;
    }
  };

  const clearMessages = () => {
    messages.value = [];
  };

  if (typeof window !== "undefined") {
    window.addEventListener("beforeunload", () => {
      if (ws.value) {
        ws.value.close(1000, "Page unload");
      }
    });
  }

  return {
    ws,
    connected,
    connecting,
    reconnecting,
    onlineDevices,
    messages,
    deviceCount,
    connect,
    disconnect,
    send,
    clearMessages,
  };
});

if (import.meta.env.DEV) {
  // 延迟执行，确保 store 已初始化
  setTimeout(() => {
    const store = useWebSocketStore();
    (window as any).__wsStore = store;
  }, 100);
}

<template>
  <div class="dashboard">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <!-- ========== 顶部核心指标卡片（4个） ========== -->
    <el-row :gutter="20" class="stats-row">
      <el-col :xs="12" :sm="12" :md="6" v-for="stat in stats" :key="stat.title">
        <el-card
          class="stat-card"
          shadow="hover"
          :body-style="{ padding: '16px' }"
        >
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-title">{{ stat.title }}</div>
              <div class="stat-value">{{ stat.value }}</div>
              <div class="stat-trend" :class="stat.trendType">
                <el-icon
                  ><CaretTop v-if="stat.trendType === 'up'" /><CaretBottom
                    v-else-if="stat.trendType === 'down'"
                /></el-icon>
                <span>{{ stat.trendText }}</span>
              </div>
            </div>
            <div class="stat-icon" :style="{ backgroundColor: stat.bgColor }">
              <el-icon :size="28" :color="stat.iconColor">
                <component :is="stat.icon" />
              </el-icon>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- ========== 第一行：今日活动概览 + 存储使用情况 ========== -->
    <el-row :gutter="20" class="chart-row">
      <!-- 今日活动概览卡片 -->
      <el-col :xs="24" :lg="14">
        <el-card class="activity-overview-card" shadow="hover">
          <template #header>
            <div class="card-header">
              <span>
                <el-icon><User /></el-icon>
                今日休假/请假/旷工人员
              </span>
              <el-button
                size="small"
                @click="loadTodayAbsentees"
                :loading="absenteesLoading"
              >
                <el-icon><Refresh /></el-icon>
                刷新
              </el-button>
            </div>
          </template>

          <div class="absentees-container" v-loading="absenteesLoading">
            <!-- 当有数据时显示三栏布局 -->
            <div
              v-if="todayAbsentees.total > 0"
              class="absentees-three-columns"
            >
              <!-- 休假人员 -->
              <div class="absentee-column vacation-column">
                <div class="column-header">
                  <span class="column-icon">🌙</span>
                  <span class="column-title">休假人员</span>
                  <el-badge
                    :value="todayAbsentees.vacation.length"
                    class="column-badge"
                  />
                </div>
                <div class="column-list">
                  <div
                    v-for="item in todayAbsentees.vacation"
                    :key="item.employeeId"
                    class="absentee-item"
                  >
                    <div class="employee-info">
                      <el-avatar :size="32" class="employee-avatar-small">
                        {{ item.employeeName?.charAt(0) || "?" }}
                      </el-avatar>
                      <div class="employee-details">
                        <div class="employee-name">{{ item.employeeName }}</div>
                        <div class="employee-position">
                          {{ item.position || "-" }}
                        </div>
                      </div>
                    </div>
                    <el-tag
                      :type="item.status === 'rest_full' ? 'danger' : 'warning'"
                      size="small"
                    >
                      {{ item.statusLabel }}
                    </el-tag>
                  </div>
                  <div
                    v-if="todayAbsentees.vacation.length === 0"
                    class="empty-column"
                  >
                    <el-icon><SuccessFilled /></el-icon>
                    <span>暂无休假人员</span>
                  </div>
                </div>
              </div>

              <!-- 请假人员 -->
              <div class="absentee-column leave-column">
                <div class="column-header">
                  <span class="column-icon">📝</span>
                  <span class="column-title">请假人员</span>
                  <el-badge
                    :value="todayAbsentees.leave.length"
                    class="column-badge"
                  />
                </div>
                <div class="column-list">
                  <div
                    v-for="item in todayAbsentees.leave"
                    :key="item.employeeId"
                    class="absentee-item"
                  >
                    <div class="employee-info">
                      <el-avatar :size="32" class="employee-avatar-small">
                        {{ item.employeeName?.charAt(0) || "?" }}
                      </el-avatar>
                      <div class="employee-details">
                        <div class="employee-name">{{ item.employeeName }}</div>
                        <div class="employee-position">
                          {{ item.position || "-" }}
                        </div>
                      </div>
                    </div>
                    <el-tag type="warning" size="small">{{
                      item.statusLabel
                    }}</el-tag>
                  </div>
                  <div
                    v-if="todayAbsentees.leave.length === 0"
                    class="empty-column"
                  >
                    <el-icon><SuccessFilled /></el-icon>
                    <span>暂无请假人员</span>
                  </div>
                </div>
              </div>

              <!-- 旷工人员 -->
              <div class="absentee-column absent-column">
                <div class="column-header">
                  <span class="column-icon">❌</span>
                  <span class="column-title">旷工人员</span>
                  <el-badge
                    :value="todayAbsentees.absent.length"
                    class="column-badge"
                    type="danger"
                  />
                </div>
                <div class="column-list">
                  <div
                    v-for="item in todayAbsentees.absent"
                    :key="item.employeeId"
                    class="absentee-item absent-item"
                  >
                    <div class="employee-info">
                      <el-avatar
                        :size="32"
                        class="employee-avatar-small absent-avatar"
                      >
                        {{ item.employeeName?.charAt(0) || "?" }}
                      </el-avatar>
                      <div class="employee-details">
                        <div class="employee-name">{{ item.employeeName }}</div>
                        <div class="employee-position">
                          {{ item.position || "-" }}
                        </div>
                      </div>
                    </div>
                    <el-tag type="danger" size="small">{{
                      item.statusLabel
                    }}</el-tag>
                  </div>
                  <div
                    v-if="todayAbsentees.absent.length === 0"
                    class="empty-column"
                  >
                    <el-icon><SuccessFilled /></el-icon>
                    <span>暂无旷工人员</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- 空状态 -->
            <el-empty
              v-else-if="!absenteesLoading"
              description="今日无休假、请假或旷工人员"
              :image-size="100"
            >
              <template #image>
                <el-icon :size="60" color="#67c23a"><SuccessFilled /></el-icon>
              </template>
              <span class="empty-tip">今日全员正常出勤 👍</span>
            </el-empty>
          </div>
        </el-card>
      </el-col>

      <!-- 存储使用情况 -->
      <el-col :xs="24" :lg="10">
        <el-card class="chart-card" shadow="hover">
          <template #header>
            <span>
              <el-icon><DataLine /></el-icon>
              存储使用情况
            </span>
          </template>
          <div class="storage-info">
            <div ref="storageChartRef" style="height: 200px"></div>
            <div class="storage-detail">
              <div class="storage-item">
                <span class="label">已用空间</span>
                <span class="value">{{
                  formatBytes(storageStats.usedBytes)
                }}</span>
              </div>
              <div class="storage-item">
                <span class="label">剩余空间</span>
                <span class="value">{{
                  formatBytes(storageStats.freeBytes)
                }}</span>
              </div>
              <div class="storage-item">
                <span class="label">录制文件</span>
                <span class="value">{{ storageStats.recordingCount }} 个</span>
              </div>
              <div class="storage-item">
                <span class="label">截图文件</span>
                <span class="value">{{ storageStats.screenshotCount }} 个</span>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- ========== 第二行：最近活动 + 应用使用排行 ========== -->
    <el-row :gutter="20" class="middle-row">
      <!-- 最近活动卡片 -->
      <el-col :xs="24" :lg="12">
        <el-card class="activity-card" shadow="hover">
          <template #header>
            <div class="card-header">
              <span>
                <el-icon><List /></el-icon>
                最近活动
              </span>
              <el-button
                size="small"
                @click="loadRecentActivities"
                :loading="activityLoading"
              >
                <el-icon><Refresh /></el-icon>
                刷新
              </el-button>
            </div>
          </template>
          <div class="recent-activities" v-loading="activityLoading">
            <div
              v-for="activity in recentActivities.slice(0, 6)"
              :key="activity.id"
              class="activity-item"
            >
              <div class="activity-time">
                {{ formatTime(activity.startedAt) }}
              </div>
              <div class="activity-content">
                <div class="activity-app">
                  <el-tag size="small" type="primary" effect="plain">{{
                    activity.processName || "未知应用"
                  }}</el-tag>
                </div>
                <div class="activity-title">
                  {{
                    activity.windowTitle || activity.browserTitle || "无标题"
                  }}
                </div>
              </div>
              <div class="activity-duration">
                {{ formatDuration(activity.durationSeconds) }}
              </div>
              <div class="activity-status">
                <el-tag
                  :type="activity.isIdle ? 'info' : 'success'"
                  size="small"
                >
                  {{ activity.isIdle ? "空闲" : "活跃" }}
                </el-tag>
              </div>
            </div>
            <el-empty
              v-if="recentActivities.length === 0 && !activityLoading"
              description="暂无最近活动"
              :image-size="80"
            />
            <div v-if="recentActivities.length > 6" class="more-link">
              <el-button type="primary" link @click="goToActivitiesPage"
                >查看更多活动 →</el-button
              >
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 应用使用排行卡片 -->
      <el-col :xs="24" :lg="12">
        <el-card class="top-apps-card" shadow="hover">
          <template #header>
            <span>
              <el-icon><Grid /></el-icon>
              应用使用排行
            </span>
          </template>
          <div class="top-apps-list" v-loading="activityLoading">
            <div
              v-for="(app, index) in (activityStats.topApps || []).slice(0, 6)"
              :key="app.name"
              class="app-item"
            >
              <div class="app-rank" :class="getRankClass(index)">
                {{ index + 1 }}
              </div>
              <div class="app-name">
                <el-icon><Monitor /></el-icon>
                <span>{{ formatAppName(app.name) }}</span>
              </div>
              <div class="app-duration">{{ formatDuration(app.duration) }}</div>
              <div class="app-progress">
                <el-progress
                  :percentage="getAppPercentage(app)"
                  :show-text="false"
                  :stroke-width="6"
                />
              </div>
              <div class="app-percentage">
                {{ getAppPercentage(app).toFixed(1) }}%
              </div>
            </div>
            <el-empty
              v-if="!activityStats.topApps?.length && !activityLoading"
              description="暂无应用使用数据"
              :image-size="80"
            />
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- ========== 第三行：今日在线员工（表格样式） ========== -->
    <el-row :gutter="20" class="bottom-row">
      <el-col :span="24">
        <el-card class="online-employee-card" shadow="hover">
          <template #header>
            <div class="card-header">
              <span>
                <el-icon><User /></el-icon>
                今日在线员工
                <el-badge
                  :value="onlineEmployees.length"
                  class="online-badge"
                />
              </span>
              <el-button
                size="small"
                @click="loadDevices"
                :loading="devicesLoading"
              >
                <el-icon><Refresh /></el-icon>
                刷新
              </el-button>
            </div>
          </template>
          <div class="online-employee-table" v-loading="devicesLoading">
            <el-table :data="onlineEmployees" stripe style="width: 100%">
              <el-table-column prop="employeeName" label="员工姓名" width="120">
                <template #default="{ row }">
                  <div class="employee-cell">
                    <el-avatar
                      :size="28"
                      :src="getEmployeeAvatar(row.employeeName)"
                      class="employee-avatar-small"
                    />
                    <span>{{ row.employeeName || "-" }}</span>
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="employeeNumber" label="工号" width="120">
                <template #default="{ row }">
                  {{ row.employeeNumber || "-" }}
                </template>
              </el-table-column>
              <el-table-column prop="position" label="职位" width="120">
                <template #default="{ row }">
                  {{ row.position || "-" }}
                </template>
              </el-table-column>
              <el-table-column prop="hostname" label="设备名称" min-width="150">
                <template #default="{ row }">
                  {{ row.hostname }}
                </template>
              </el-table-column>
              <el-table-column prop="osVersion" label="操作系统" width="150">
                <template #default="{ row }">
                  {{ row.osVersion || "-" }}
                </template>
              </el-table-column>
              <el-table-column
                prop="agentVersion"
                label="Agent版本"
                width="100"
              >
                <template #default="{ row }">
                  {{ row.agentVersion || "-" }}
                </template>
              </el-table-column>
              <el-table-column prop="lastSeenAt" label="最后在线" width="170">
                <template #default="{ row }">
                  {{ formatTime(row.lastSeenAt) }}
                </template>
              </el-table-column>
              <el-table-column label="操作" width="180" fixed="right">
                <template #default="{ row }">
                  <el-button
                    link
                    type="primary"
                    size="small"
                    @click="goToEmployeeDetail(row)"
                  >
                    <el-icon><InfoFilled /></el-icon>
                    详情
                  </el-button>
                  <el-button
                    link
                    type="success"
                    size="small"
                    @click="goToScreenshotsByEmployee(row)"
                    v-permission="'screenshot:view'"
                  >
                    <el-icon><Camera /></el-icon>
                    查看截图
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
            <div v-if="onlineEmployees.length === 0" class="empty-employees">
              <el-empty description="暂无在线员工" :image-size="80" />
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, onUnmounted } from "vue";
import { useRouter } from "vue-router";
import * as echarts from "echarts";
import {
  deviceApi,
  cleanupApi,
  activityApi,
  screenshotApi,
  recordingApi,
} from "@api/index";
import type { Device, ActivityLog } from "@api/types";
import adminApi from "@api/admin_api";
import type { TodayAbsenteesResponse } from "@api/types";
import {
  Monitor,
  DataLine,
  Refresh,
  CaretTop,
  CaretBottom,
  InfoFilled,
} from "@element-plus/icons-vue";

const router = useRouter();

// ========== 图表引用 ==========
const storageChartRef = ref<HTMLElement>();
let storageChart: echarts.ECharts | null = null;

// ========== 状态定义 ==========
const devicesLoading = ref(false);
const activityLoading = ref(false);
const absenteesLoading = ref(false);
const devices = ref<Device[]>([]);
const recentActivities = ref<ActivityLog[]>([]);

// ⭐ 今日考勤异常人员数据
const todayAbsentees = ref<TodayAbsenteesResponse>({
  vacation: [],
  leave: [],
  absent: [],
  total: 0,
});

// 存储统计
const storageStats = reactive({
  totalBytes: 0,
  usedBytes: 0,
  freeBytes: 0,
  diskUsagePercent: 0,
  recordingCount: 0,
  screenshotCount: 0,
  logCount: 0,
  lastCleanupAt: null as string | null,
});

// 活动统计
const activityStats = reactive({
  totalDuration: 0,
  idleDuration: 0,
  activeDuration: 0,
  productivityRate: 0,
  topApps: [] as Array<{
    name: string;
    duration: number;
    count: number;
  }>,
  dailyActivity: [] as Array<{
    date: string;
    duration: number;
    idle: number;
  }>,
  hourlyActivity: {} as Record<number, number>,
});

// ========== 计算属性 ==========
const onlineEmployees = computed(() => {
  return devices.value.filter((d) => d.onlineStatus === "online");
});

// 核心指标卡片数据
const stats = ref([
  {
    title: "在线设备",
    value: 0,
    icon: "Monitor",
    bgColor: "#e6f7ff",
    iconColor: "#1890ff",
    trendType: "up",
    trendText: "较昨日 +2",
  },
  {
    title: "总设备数",
    value: 0,
    icon: "Monitor",
    bgColor: "#f6ffed",
    iconColor: "#52c41a",
    trendType: "up",
    trendText: "较昨日 +5",
  },
  {
    title: "录制文件",
    value: 0,
    icon: "VideoCamera",
    bgColor: "#fff7e6",
    iconColor: "#faad14",
    trendType: "down",
    trendText: "较昨日 -12",
  },
  {
    title: "今日截图",
    value: 0,
    icon: "Camera",
    bgColor: "#f9f0ff",
    iconColor: "#722ed1",
    trendType: "up",
    trendText: "较昨日 +8",
  },
]);

// ========== 辅助函数 ==========
const formatBytes = (bytes: number) => {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
};

const formatDuration = (seconds: number) => {
  if (seconds <= 0) return "0分钟";
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (hours > 0) return `${hours}小时${minutes}分钟`;
  return `${minutes}分钟`;
};

const formatTime = (time: string | null) => {
  if (!time) return "-";
  const date = new Date(time);
  return date.toLocaleTimeString("zh-CN", {
    hour: "2-digit",
    minute: "2-digit",
  });
};

const formatAppName = (name: string) => {
  if (!name) return "未知应用";
  return name.replace(/\.exe$/i, "");
};

const BEIJING_OFFSET_MS = 8 * 60 * 60 * 1000;

const getBeijingDateString = (date: Date): string => {
  return date.toLocaleDateString("en-CA", {
    timeZone: "Asia/Shanghai",
  });
};

const getBeijingDayUtcRange = (date: Date) => {
  const [year, month, day] = getBeijingDateString(date).split("-").map(Number);
  const startUtc = new Date(
    Date.UTC(year, month - 1, day, 0, 0, 0) - BEIJING_OFFSET_MS,
  );
  const endUtc = new Date(
    Date.UTC(year, month - 1, day + 1, 0, 0, 0) - BEIJING_OFFSET_MS,
  );
  return {
    startUtcIso: startUtc.toISOString(),
    endUtcIso: endUtc.toISOString(),
  };
};

const getRankClass = (index: number) => {
  if (index === 0) return "rank-1";
  if (index === 1) return "rank-2";
  if (index === 2) return "rank-3";
  return "";
};

const getEmployeeAvatar = (name: string) => {
  const letter = (name || "U").charAt(0).toUpperCase();
  return `https://ui-avatars.com/api/?background=409eff&color=fff&size=28&rounded=true&bold=true&length=1&name=${letter}`;
};

// 计算应用使用百分比
const getAppPercentage = (app: { duration: number }) => {
  const totalDuration = activityStats.totalDuration || 0;
  if (totalDuration === 0) return 0;
  return (app.duration / totalDuration) * 100;
};

const loadTodayAbsentees = async () => {
  absenteesLoading.value = true;
  try {
    const { data } = await adminApi.getTodayAbsentees();
    todayAbsentees.value = {
      vacation: data.vacation || [],
      leave: data.leave || [],
      absent: data.absent || [],
      total: data.total || 0,
    };
  } catch (error: any) {
    console.error("加载今日考勤异常人员失败:", error);
    // 降级处理
    todayAbsentees.value = { vacation: [], leave: [], absent: [], total: 0 };
  } finally {
    absenteesLoading.value = false;
  }
};

// ========== 数据加载 ==========
const loadDevices = async () => {
  devicesLoading.value = true;
  try {
    const { data } = await deviceApi.list({ page: 1, pageSize: 1000 });
    devices.value = data.items || [];
    const online = devices.value.filter(
      (d) => d.onlineStatus === "online",
    ).length;
    stats.value[0].value = online;
    stats.value[1].value = devices.value.length;
  } catch (error) {
    console.error("Load devices error:", error);
  } finally {
    devicesLoading.value = false;
  }
};

const loadStorageStats = async () => {
  try {
    const { data } = await cleanupApi.getStats();
    storageStats.usedBytes = data.usedBytes;
    storageStats.freeBytes = data.freeBytes;
    storageStats.recordingCount = data.recordingCount;
    storageStats.screenshotCount = data.screenshotCount;

    if (storageChart) {
      storageChart.setOption({
        series: [
          {
            data: [
              {
                value: data.usedBytes,
                name: "已使用",
                itemStyle: { color: "#5470c6" },
              },
              {
                value: data.freeBytes,
                name: "剩余",
                itemStyle: { color: "#91cc75" },
              },
            ],
          },
        ],
      });
    }
  } catch (error) {
    console.error("Load storage stats error:", error);
  }
};

const loadTodayRecordingCount = async () => {
  try {
    const { startUtcIso, endUtcIso } = getBeijingDayUtcRange(new Date());
    const { data } = await recordingApi.list({
      startTime: startUtcIso,
      endTime: endUtcIso,
      page: 1,
      pageSize: 1,
    });
    stats.value[2].value = data.total || 0;
  } catch (error) {
    console.error("Load today recording count error:", error);
    stats.value[2].value = 0;
  }
};

const loadTodayScreenshotCount = async () => {
  try {
    // ✅ 按北京时间计算今日截图数量
    const { startUtcIso, endUtcIso } = getBeijingDayUtcRange(new Date());

    const { data } = await screenshotApi.list({
      startDate: startUtcIso,
      endDate: endUtcIso,
      page: 1,
      pageSize: 1,
    });
    stats.value[3].value = data.total || 0;
  } catch (error) {
    console.error("Load today screenshot count error:", error);
    stats.value[3].value = 0;
  }
};

// 计算并更新“较昨日”对比数据
const loadTrendComparisons = async () => {
  try {
    // 确保 devices 已加载
    if (!devices.value.length) {
      const res = await deviceApi.list({ page: 1, pageSize: 1000 });
      devices.value = res.data.items || [];
    }

    // 按北京时间计算今日和昨日时间范围
    const todayRange = getBeijingDayUtcRange(new Date());
    const yesterdayRange = getBeijingDayUtcRange(
      new Date(Date.now() - 24 * 60 * 60 * 1000),
    );

    const todayUTCStart = new Date(todayRange.startUtcIso);
    const todayUTCEnd = new Date(todayRange.endUtcIso);
    const yesterdayUTCStart = new Date(yesterdayRange.startUtcIso);
    const yesterdayUTCEnd = new Date(yesterdayRange.endUtcIso);

    // 1) 在线设备：当前在线 vs 昨日有过在线
    const onlineNow = devices.value.filter(
      (d) => d.onlineStatus === "online",
    ).length;
    const yesterdayOnline = devices.value.filter((d) => {
      if (!d.lastSeenAt) return false;
      const lastSeen = new Date(d.lastSeenAt);
      return lastSeen >= yesterdayUTCStart && lastSeen < yesterdayUTCEnd;
    }).length;
    stats.value[0].trendType = onlineNow - yesterdayOnline >= 0 ? "up" : "down";
    stats.value[0].trendText = `较昨日 ${onlineNow - yesterdayOnline >= 0 ? "+" : ""}${onlineNow - yesterdayOnline}`;

    // 2) 总设备数
    const totalNow = devices.value.length;
    const yesterdayTotal = devices.value.filter((d) => {
      if (!d.createdAt) return false;
      return new Date(d.createdAt) < yesterdayUTCEnd;
    }).length;
    stats.value[1].trendType = totalNow - yesterdayTotal >= 0 ? "up" : "down";
    stats.value[1].trendText = `较昨日 ${totalNow - yesterdayTotal >= 0 ? "+" : ""}${totalNow - yesterdayTotal}`;

    // 3) 录制文件 - 使用正确的 UTC 格式
    try {
      const todayRec = await recordingApi.list({
        startTime: todayUTCStart.toISOString(),
        endTime: todayUTCEnd.toISOString(),
        page: 1,
        pageSize: 1,
      });
      const yesterdayRec = await recordingApi.list({
        startTime: yesterdayUTCStart.toISOString(),
        endTime: yesterdayUTCEnd.toISOString(),
        page: 1,
        pageSize: 1,
      });
      const todayCount = todayRec.data.total || 0;
      const yesterdayCount = yesterdayRec.data.total || 0;
      const delta = todayCount - yesterdayCount;
      stats.value[2].trendType = delta >= 0 ? "up" : "down";
      stats.value[2].trendText = `较昨日 ${delta >= 0 ? "+" : ""}${delta}`;
    } catch (err) {
      console.error("Load recordings trend error:", err);
      stats.value[2].trendText = "";
    }

    // 4) 今日截图 - 使用正确的 UTC 格式
    try {
      const todaySs = await screenshotApi.list({
        startDate: todayUTCStart.toISOString(),
        endDate: todayUTCEnd.toISOString(),
        page: 1,
        pageSize: 1,
      });
      const yesterdaySs = await screenshotApi.list({
        startDate: yesterdayUTCStart.toISOString(),
        endDate: yesterdayUTCEnd.toISOString(),
        page: 1,
        pageSize: 1,
      });
      const tCount = todaySs.data.total || 0;
      const yCount = yesterdaySs.data.total || 0;
      const delta = tCount - yCount;
      stats.value[3].trendType = delta >= 0 ? "up" : "down";
      stats.value[3].trendText = `较昨日 ${delta >= 0 ? "+" : ""}${delta}`;
    } catch (err) {
      console.error("Load screenshots trend error:", err);
      stats.value[3].trendText = "";
    }
  } catch (ex) {
    console.error("Load trend comparisons error:", ex);
  }
};

const loadActivityStats = async () => {
  activityLoading.value = true;
  try {
    const { data } = await activityApi.getStats();
    activityStats.totalDuration = data.totalDuration || 0;
    activityStats.idleDuration = data.idleDuration || 0;
    activityStats.activeDuration = data.activeDuration || 0;
    activityStats.productivityRate = data.productivityRate || 0;
    activityStats.topApps = data.topApps || [];
    activityStats.dailyActivity = data.dailyActivity || [];
    activityStats.hourlyActivity = data.hourlyActivity || {};
  } catch (error) {
    console.error("Load activity stats error:", error);
  } finally {
    activityLoading.value = false;
  }
};

const loadRecentActivities = async () => {
  activityLoading.value = true;
  try {
    const today = new Date().toISOString().slice(0, 10);
    const { data } = await activityApi.list({
      startDate: today,
      endDate: today,
      page: 1,
      pageSize: 20,
    });
    recentActivities.value = data.items || [];
  } catch (error) {
    console.error("Load recent activities error:", error);
    recentActivities.value = [];
  } finally {
    activityLoading.value = false;
  }
};

// ========== 图表初始化 ==========
const initStorageChart = () => {
  if (!storageChartRef.value) return;
  storageChart = echarts.init(storageChartRef.value);
  storageChart.setOption({
    tooltip: { trigger: "item" },
    legend: { orient: "vertical", left: "left", top: "center" },
    series: [
      {
        type: "pie",
        radius: ["40%", "70%"],
        avoidLabelOverlap: false,
        label: { show: true, formatter: "{b}: {d}%" },
        emphasis: { scale: true },
        data: [
          { value: 0, name: "已使用", itemStyle: { color: "#5470c6" } },
          { value: 0, name: "剩余", itemStyle: { color: "#91cc75" } },
        ],
      },
    ],
  });
};

// ========== 页面跳转 ==========
const goToEmployeeDetail = (employee: Device) => {
  router.push(`/devices?employeeId=${employee.id}`);
};

const goToActivitiesPage = () => {
  router.push("/activities");
};

const goToScreenshotsByEmployee = (device: Device) => {
  router.push({
    path: "/screenshots",
    query: {
      deviceId: device.id,
      deviceName: device.employeeName || device.hostname,
    },
  });
};

// ========== 事件处理 ==========
const handleResize = () => {
  storageChart?.resize();
};

const handleDeviceStatusChange = () => {
  loadDevices();
  loadStorageStats();
};

// ========== 生命周期 ==========
onMounted(() => {
  initStorageChart();
  loadDevices();
  loadStorageStats();
  loadTodayRecordingCount();
  loadTodayScreenshotCount();
  loadActivityStats();
  loadRecentActivities();
  loadTodayAbsentees();
  // 计算较昨日对比（在主要数据加载后执行）
  setTimeout(() => void loadTrendComparisons(), 500);
  window.addEventListener("resize", handleResize);
  window.addEventListener("device-status-change", handleDeviceStatusChange);
});

onUnmounted(() => {
  storageChart?.dispose();
  window.removeEventListener("resize", handleResize);
  window.removeEventListener("device-status-change", handleDeviceStatusChange);
});
</script>

<style scoped>
.dashboard {
  padding: 0px;
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
}

/* ========== 背景装饰 ========== */
.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}

.blob-1 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -200px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 600px;
  height: 600px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -250px;
  left: -150px;
  animation-delay: -5s;
}

.blob-3 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 30%;
  animation-delay: -10s;
}

@keyframes float {
  0%,
  100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -30px) scale(1.05);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.95);
  }
}

/* 确保内容在背景之上 */
.stats-row,
.chart-row,
.middle-row,
.bottom-row {
  position: relative;
  z-index: 1;
}

/* 统计卡片样式 */
.stats-row {
  margin-bottom: 20px;
}

.stat-card {
  border-radius: 16px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
}

.stat-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.stat-info {
  flex: 1;
}

.stat-title {
  color: #8c8c8c;
  font-size: 14px;
  margin-bottom: 8px;
}

.stat-value {
  font-size: 28px;
  font-weight: bold;
  color: #262626;
  line-height: 1.2;
}

.stat-trend {
  font-size: 12px;
  margin-top: 8px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.stat-trend.up {
  color: #67c23a;
}

.stat-trend.down {
  color: #f56c6c;
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 卡片通用样式 */
.activity-overview-card,
.chart-card,
.activity-card,
.top-apps-card,
.online-employee-card {
  border-radius: 16px;
  transition: all 0.3s;
  height: 100%;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.activity-overview-card:hover,
.chart-card:hover,
.activity-card:hover,
.top-apps-card:hover,
.online-employee-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
}

.chart-row {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* 按钮样式 */
:deep(.el-button--primary) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border: none;
  transition: all 0.3s ease;
}

:deep(.el-button--primary):hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

/* 今日活动概览样式 */
.activity-metrics {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 20px;
}

.metric-item {
  text-align: center;
  padding: 12px;
  background: rgba(245, 247, 250, 0.8);
  border-radius: 12px;
  transition: all 0.2s;
}

.metric-item:hover {
  background: rgba(230, 242, 255, 0.9);
  transform: translateY(-2px);
}

.metric-value {
  font-size: 24px;
  font-weight: bold;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}

.metric-label {
  font-size: 12px;
  color: #8c8c8c;
  margin-top: 4px;
}

.metric-trend {
  font-size: 11px;
  margin-top: 6px;
}

.metric-trend.up {
  color: #67c23a;
}

.metric-trend.down {
  color: #f56c6c;
}

.activity-detail {
  display: flex;
  gap: 20px;
  padding-top: 16px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.detail-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.detail-item .label {
  font-size: 13px;
  color: #8c8c8c;
}

/* 存储详情 */
.storage-info {
  padding: 8px 0;
}

.storage-detail {
  margin-top: 16px;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}

.storage-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
  padding: 8px 0;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.storage-item .label {
  color: #8c8c8c;
}

.storage-item .value {
  font-weight: 500;
  color: #262626;
}

/* 最近活动列表 */
.recent-activities {
  max-height: 380px;
  overflow-y: auto;
}

.activity-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 12px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  transition: all 0.2s;
}

.activity-item:hover {
  background: rgba(245, 247, 250, 0.8);
  transform: translateX(4px);
}

.activity-time {
  width: 70px;
  font-size: 12px;
  color: #999;
}

.activity-content {
  flex: 1;
}

.activity-app {
  margin-bottom: 4px;
}

.activity-title {
  font-size: 13px;
  color: #333;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.activity-duration {
  width: 80px;
  font-size: 12px;
  color: #666;
}

.activity-status {
  width: 60px;
}

.more-link {
  text-align: center;
  padding: 12px;
}

/* 应用排行 */
.top-apps-list {
  max-height: 380px;
  overflow-y: auto;
}

.app-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 8px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  transition: all 0.2s;
}

.app-item:hover {
  background: rgba(245, 247, 250, 0.8);
  transform: translateX(4px);
}

.app-rank {
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  font-weight: bold;
  font-size: 13px;
}

.app-rank.rank-1 {
  background: linear-gradient(135deg, #ffd700, #ffb347);
  color: white;
}

.app-rank.rank-2 {
  background: linear-gradient(135deg, #c0c0c0, #a8a8a8);
  color: white;
}

.app-rank.rank-3 {
  background: linear-gradient(135deg, #cd7f32, #b87333);
  color: white;
}

.app-name {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: #333;
}

.app-duration {
  width: 80px;
  font-size: 12px;
  color: #666;
}

.app-progress {
  width: 100px;
}

.app-percentage {
  width: 50px;
  font-size: 12px;
  color: #52c41a;
  text-align: right;
}

/* 在线员工表格 */
.online-employee-card {
  margin-top: 0;
}

.online-employee-card :deep(.el-table) {
  background: transparent;
}

.online-employee-card :deep(.el-table__header-wrapper) {
  background: rgba(248, 250, 252, 0.9);
}

.employee-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.employee-avatar-small {
  flex-shrink: 0;
}

.empty-employees {
  padding: 40px;
}

/* 滚动条美化 */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(135deg, #5a67d8, #6b46c1);
}

/* ========== 考勤异常人员卡片样式 ========== */
.absentees-container {
  min-height: 280px;
}

.absentees-three-columns {
  display: flex;
  gap: 16px;
}

.absentee-column {
  flex: 1;
  background: rgba(245, 247, 250, 0.6);
  border-radius: 12px;
  overflow: hidden;
}

.column-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: rgba(255, 255, 255, 0.8);
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.column-icon {
  font-size: 18px;
}

.column-title {
  font-weight: 600;
  font-size: 14px;
  color: #1a1a2e;
}

.column-badge :deep(.el-badge__content) {
  background-color: #409eff;
}

.column-list {
  max-height: 240px;
  overflow-y: auto;
  padding: 8px;
}

.absentee-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 8px;
  margin-bottom: 8px;
  background: white;
  border-radius: 10px;
  transition: all 0.2s;
}

.absentee-item:hover {
  transform: translateX(2px);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.absentee-item.absent-item {
  background: #fff1f0;
}

.employee-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.employee-avatar-small {
  flex-shrink: 0;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
}

.absent-avatar {
  background: linear-gradient(135deg, #f5576c, #f093fb);
}

.employee-details {
  display: flex;
  flex-direction: column;
}

.employee-name {
  font-weight: 600;
  font-size: 13px;
  color: #303133;
}

.employee-position {
  font-size: 11px;
  color: #909399;
  margin-top: 2px;
}

.empty-column {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px 16px;
  color: #c0c4cc;
  gap: 8px;
}

.empty-column .el-icon {
  font-size: 32px;
}

.empty-column span {
  font-size: 12px;
}

.empty-tip {
  font-size: 14px;
  color: #67c23a;
}

/* 滚动条样式 */
.column-list::-webkit-scrollbar {
  width: 4px;
}

.column-list::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 2px;
}

.column-list::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-radius: 2px;
}

/* 响应式 */
@media (max-width: 1200px) {
  .dashboard {
    padding: 16px;
  }

  .stat-value {
    font-size: 22px;
  }

  .stat-icon {
    width: 48px;
    height: 48px;
  }

  .blob-1,
  .blob-2,
  .blob-3 {
    opacity: 0.2;
  }
}

@media (max-width: 768px) {
  .dashboard {
    padding: 12px;
  }

  .blob-1,
  .blob-2,
  .blob-3 {
    display: none;
  }

  .stat-value {
    font-size: 20px;
  }

  .stat-icon {
    width: 44px;
    height: 44px;
  }

  .activity-metrics {
    grid-template-columns: repeat(2, 1fr);
  }

  .activity-detail {
    flex-direction: column;
  }

  .storage-detail {
    grid-template-columns: 1fr;
  }

  .activity-item {
    flex-wrap: wrap;
  }

  .app-item {
    flex-wrap: wrap;
  }

  .app-progress {
    width: 100%;
    margin-top: 8px;
  }

  .online-employee-card :deep(.el-table) {
    overflow-x: auto;
  }
}
</style>

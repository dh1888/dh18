<template>
  <div class="devices-page">
    <!-- 背景装饰 -->
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <el-card class="filter-card card-hover">
      <el-form :inline="true" :model="filters" class="filter-form">
        <!-- 员工信息搜索（合并姓名、工号、职位） -->
        <el-form-item label="员工信息">
          <el-input
            v-model="filters.employeeSearch"
            placeholder="请输入姓名/工号/职位"
            clearable
            @clear="handleSearch"
            style="width: 200px"
          />
        </el-form-item>

        <!-- 设备状态（合并审核状态 + 在线状态） -->
        <el-form-item label="设备状态">
          <el-select
            v-model="filters.deviceStatus"
            placeholder="全部"
            clearable
            @change="handleSearch"
            style="width: 130px"
          >
            <el-option label="待审核" value="pending" />
            <el-option label="已拒绝" value="rejected" />
            <el-option label="已审核 | 在线" value="approved_online" />
            <el-option label="已审核 | 离线" value="approved_offline" />
          </el-select>
        </el-form-item>

        <!-- 设备名称搜索 -->
        <el-form-item label="设备名称">
          <el-input
            v-model="filters.keyword"
            placeholder="请输入设备名称"
            clearable
            style="width: 160px"
            @clear="handleSearch"
          />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleSearch">
            <el-icon><Search /></el-icon>
            搜索
          </el-button>
          <el-button @click="handleReset">
            <el-icon><Refresh /></el-icon>
            重置
          </el-button>
          <el-button type="success" @click="handleExport">
            <el-icon><Download /></el-icon>
            导出
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card class="table-card card-hover">
      <template #header>
        <div class="card-header">
          <span>员工设备列表</span>
          <el-button type="primary" @click="handleRefresh" :loading="loading">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
        </div>
      </template>

      <el-table :data="devices" v-loading="loading" stripe>
        <!-- 员工姓名列 -->
        <el-table-column prop="employeeName" label="员工姓名" width="120">
          <template #default="{ row }">
            <span>{{ row.employeeName || "-" }}</span>
          </template>
        </el-table-column>
        <!-- 工号列 -->
        <el-table-column prop="employeeNumber" label="工号" width="120">
          <template #default="{ row }">
            <span>{{ row.employeeNumber || "-" }}</span>
          </template>
        </el-table-column>
        <!-- 职位列 -->
        <el-table-column prop="position" label="职位" width="120">
          <template #default="{ row }">
            <span>{{ row.position || "-" }}</span>
          </template>
        </el-table-column>
        <!-- 设备名称列 -->
        <el-table-column prop="hostname" label="设备名称" min-width="150" />
        <!-- 操作系统列 -->
        <el-table-column
          prop="osVersion"
          label="操作系统"
          width="150"
          show-overflow-tooltip
        />
        <!-- Agent版本列 -->
        <el-table-column prop="agentVersion" label="Agent版本" width="100" />

        <el-table-column label="截图统计" width="120" align="center">
          <template #default="{ row }">
            <div class="screenshot-stats">
              <div class="stats-today">
                <span class="stats-label">今日</span>
                <span
                  class="stats-value"
                  :class="{ 'has-data': row.screenshotStats?.todayCount > 0 }"
                >
                  {{ row.screenshotStats?.todayCount || 0 }}
                </span>
              </div>
              <div class="stats-total">
                <span class="stats-label">总计</span>
                <span
                  class="stats-value"
                  :class="{ 'has-data': row.screenshotStats?.totalCount > 0 }"
                >
                  {{ row.screenshotStats?.totalCount || 0 }}
                </span>
              </div>
            </div>
          </template>
        </el-table-column>

        <!-- 审核状态列 -->
        <el-table-column prop="status" label="审核状态" width="100">
          <template #default="{ row }">
            <el-tag :type="getAuditStatusType(row.status)" effect="light">
              {{ getAuditStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>

        <!-- 在线状态列 -->
        <el-table-column prop="onlineStatus" label="在线状态" width="100">
          <template #default="{ row }">
            <el-tag
              :type="row.onlineStatus === 'online' ? 'success' : 'info'"
              effect="light"
            >
              <el-icon v-if="row.onlineStatus === 'online'"
                ><Connection
              /></el-icon>
              <el-icon v-else><CircleClose /></el-icon>
              {{ row.onlineStatus === "online" ? "在线" : "离线" }}
            </el-tag>
          </template>
        </el-table-column>

        <!-- 最后在线列 -->
        <el-table-column prop="lastSeenAt" label="最后在线" width="180">
          <template #default="{ row }">
            {{ formatTime(row.lastSeenAt) }}
          </template>
        </el-table-column>

        <!-- 操作列 -->
        <el-table-column label="操作" width="420" fixed="right" align="center">
          <template #default="{ row }">
            <div class="action-buttons">
              <el-button
                link
                type="primary"
                size="small"
                @click="handleViewScreenshots(row)"
                class="action-btn screenshot-btn"
              >
                <el-icon><Camera /></el-icon>
                截图
              </el-button>
              <el-button
                link
                type="primary"
                size="small"
                @click="handleViewRecordings(row)"
                class="action-btn recording-btn"
              >
                <el-icon><VideoCamera /></el-icon>
                录屏
              </el-button>
              <el-button
                link
                type="success"
                size="small"
                @click="handleEditEmployee(row)"
                class="action-btn edit-btn"
              >
                <el-icon><Edit /></el-icon>
                编辑
              </el-button>
              <!-- 审核通过（待审核 + device:manage） -->
              <el-button
                link
                type="success"
                size="small"
                @click="handleApprove(row)"
                v-if="row.status === 'pending'"
                v-permission="'device:manage'"
                class="action-btn approve-btn"
              >
                <el-icon><Select /></el-icon>
                通过
              </el-button>
              <!-- 审核拒绝（待审核 + device:manage） -->
              <el-button
                link
                type="danger"
                size="small"
                @click="handleReject(row)"
                v-if="row.status === 'pending'"
                v-permission="'device:manage'"
                class="action-btn reject-btn"
              >
                <el-icon><CircleClose /></el-icon>
                拒绝
              </el-button>
              <!-- 解绑按钮（已绑定员工时显示） -->
              <el-button
                link
                type="warning"
                size="small"
                @click="handleUnbind(row)"
                v-if="row.employeeId"
                class="action-btn unbind-btn"
              >
                <el-icon><Unlock /></el-icon>
                解绑
              </el-button>
              <!-- 详情按钮 -->
              <el-button
                link
                type="info"
                size="small"
                @click="handleViewDetail(row)"
                class="action-btn detail-btn"
              >
                <el-icon><InfoFilled /></el-icon>
                详情
              </el-button>
              <!-- 上报按钮（仅在线状态显示） -->
              <el-button
                link
                type="primary"
                size="small"
                @click="handleReportInfo(row)"
                v-if="row.onlineStatus === 'online'"
                class="action-btn report-btn"
              >
                <el-icon><Upload /></el-icon>
                上报
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="pagination.total"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 编辑员工信息对话框 -->
    <el-dialog
      v-model="editEmployeeDialogVisible"
      title="编辑员工信息"
      width="480px"
      class="animate-dialog modern-dialog"
    >
      <el-form
        :model="employeeForm"
        :rules="employeeRules"
        ref="employeeFormRef"
        label-width="80px"
      >
        <el-form-item label="员工姓名" prop="employeeName">
          <el-input
            v-model="employeeForm.employeeName"
            placeholder="请输入员工姓名"
          />
        </el-form-item>
        <el-form-item label="工号" prop="employeeNumber">
          <el-input
            v-model="employeeForm.employeeNumber"
            placeholder="请输入工号"
          />
        </el-form-item>
        <el-form-item label="职位" prop="position">
          <el-input
            v-model="employeeForm.position"
            placeholder="请输入职位（如：客服、出款、运维）"
          />
        </el-form-item>
        <el-form-item label="员工ID" prop="employeeId">
          <el-input
            v-model="employeeForm.employeeId"
            placeholder="员工ID（可选）"
          />
          <div class="form-tip">员工ID用于系统内部标识，可选填</div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="editEmployeeDialogVisible = false">取消</el-button>
        <el-button
          type="primary"
          @click="confirmEditEmployee"
          :loading="editEmployeeLoading"
          >保存</el-button
        >
      </template>
    </el-dialog>

    <!-- 设备详情对话框 -->
    <el-dialog
      v-model="detailDialogVisible"
      title="设备详情"
      width="550px"
      class="animate-dialog modern-dialog"
    >
      <el-descriptions :column="1" border v-if="currentDevice">
        <el-descriptions-item label="员工姓名">{{
          currentDevice.employeeName || "-"
        }}</el-descriptions-item>
        <el-descriptions-item label="工号">{{
          currentDevice.employeeNumber || "-"
        }}</el-descriptions-item>
        <el-descriptions-item label="职位">{{
          currentDevice.position || "-"
        }}</el-descriptions-item>
        <el-descriptions-item label="员工ID">{{
          currentDevice.employeeId || "-"
        }}</el-descriptions-item>
        <el-descriptions-item label="设备ID">
          <el-tooltip :content="currentDevice.id" placement="top">
            <span>{{ currentDevice.id.slice(0, 8) }}...</span>
          </el-tooltip>
        </el-descriptions-item>
        <el-descriptions-item label="设备名称">{{
          currentDevice.hostname
        }}</el-descriptions-item>
        <el-descriptions-item label="设备指纹">
          <el-tooltip
            :content="currentDevice.deviceFingerprint"
            placement="top"
          >
            <span>{{ currentDevice.deviceFingerprint?.slice(0, 16) }}...</span>
          </el-tooltip>
        </el-descriptions-item>
        <el-descriptions-item label="操作系统">{{
          currentDevice.osVersion
        }}</el-descriptions-item>
        <el-descriptions-item label="Agent版本">{{
          currentDevice.agentVersion
        }}</el-descriptions-item>
        <el-descriptions-item label="审核状态">
          <el-tag
            :type="getAuditStatusType(currentDevice.status)"
            effect="light"
          >
            {{ getAuditStatusText(currentDevice.status) }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="在线状态">
          <el-tag
            :type="currentDevice.onlineStatus === 'online' ? 'success' : 'info'"
            effect="light"
          >
            <el-icon v-if="currentDevice.onlineStatus === 'online'"
              ><Connection
            /></el-icon>
            <el-icon v-else><CircleClose /></el-icon>
            {{ currentDevice.onlineStatus === "online" ? "在线" : "离线" }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="最后在线">{{
          formatTime(currentDevice.lastSeenAt)
        }}</el-descriptions-item>
        <el-descriptions-item label="绑定时间">{{
          formatTime(currentDevice.boundAt)
        }}</el-descriptions-item>
        <el-descriptions-item label="创建时间">{{
          formatTime(currentDevice.createdAt)
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <el-button @click="detailDialogVisible = false">关闭</el-button>
        <el-button
          type="primary"
          @click="handleViewScreenshotsFromDetail"
          v-if="currentDevice"
        >
          <el-icon><Camera /></el-icon>
          查看截图
        </el-button>
        <el-button
          type="success"
          @click="handleEditEmployeeFromDetail"
          v-if="currentDevice"
        >
          <el-icon><Edit /></el-icon>
          编辑员工
        </el-button>
        <el-button
          type="primary"
          @click="handleReportInfoFromDetail"
          v-if="currentDevice?.onlineStatus === 'online'"
        >
          <el-icon><Upload /></el-icon>
          上报信息
        </el-button>
        <el-button
          type="warning"
          @click="handleApproveFromDetail"
          v-if="currentDevice?.status === 'pending'"
          v-permission="'device:manage'"
        >
          <el-icon><Select /></el-icon>
          审核通过
        </el-button>
        <el-button
          type="danger"
          @click="handleRejectFromDetail"
          v-if="currentDevice?.status === 'pending'"
          v-permission="'device:manage'"
        >
          <el-icon><CircleClose /></el-icon>
          审核拒绝
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, onUnmounted } from "vue";
import { useRouter } from "vue-router";
import { ElMessage, ElMessageBox } from "element-plus";
import { screenshotApi } from "@api/index";
import {
  Refresh,
  Search,
  Download,
  Camera,
  VideoCamera,
  Unlock,
  InfoFilled,
  Upload,
  Edit,
  Select,
  Connection,
  CircleClose,
} from "@element-plus/icons-vue";
import { deviceApi } from "@api/index";
import type { Device } from "@api/types";

const router = useRouter();

const loading = ref(false);
const devices = ref<Device[]>([]);

// 编辑员工对话框
const editEmployeeDialogVisible = ref(false);
const editEmployeeLoading = ref(false);
const employeeFormRef = ref();
const editingDeviceId = ref("");

// 详情对话框
const detailDialogVisible = ref(false);
const currentDevice = ref<Device | null>(null);

// 筛选条件
const filters = reactive({
  employeeSearch: "", // 合并搜索：姓名/工号/职位
  deviceStatus: "", // 合并状态：pending / approved_online / approved_offline
  keyword: "", // 设备名称搜索
});

const pagination = reactive({
  page: 1,
  pageSize: 20,
  total: 0,
});

// 编辑员工表单
const employeeForm = reactive({
  employeeName: "",
  employeeNumber: "",
  position: "",
  employeeId: "",
});

const employeeRules = {
  employeeName: [
    { required: true, message: "请输入员工姓名", trigger: "blur" },
  ],
  employeeNumber: [{ required: true, message: "请输入工号", trigger: "blur" }],
  position: [{ required: false, message: "请输入职位", trigger: "blur" }],
};

// 审核状态映射
const getAuditStatusType = (status: string) => {
  const map: Record<string, string> = {
    pending: "warning",
    approved: "primary",
    rejected: "danger",
  };
  return map[status] || "info";
};

const getAuditStatusText = (status: string) => {
  const map: Record<string, string> = {
    pending: "待审核",
    approved: "已审核",
    rejected: "已拒绝",
  };
  return map[status] || status;
};

// 格式化时间
const formatTime = (time: string | null) => {
  if (!time) return "-";
  const date = new Date(time);
  return date.toLocaleString("zh-CN");
};

const loadDevices = async () => {
  loading.value = true;
  try {
    const params: any = {
      page: pagination.page,
      pageSize: pagination.pageSize,
    };

    if (filters.employeeSearch && filters.employeeSearch.trim()) {
      params.employeeSearch = filters.employeeSearch;
    }
    if (filters.deviceStatus && filters.deviceStatus.trim()) {
      params.deviceStatus = filters.deviceStatus;
    }
    if (filters.keyword && filters.keyword.trim()) {
      params.keyword = filters.keyword;
    }

    const { data } = await deviceApi.list(params);

    const items = data.items || [];

    // ✅ 并行加载每个设备的截图统计
    const statsPromises = items.map(async (device: Device) => {
      try {
        const stats = await screenshotApi.getEmployeeStats(device.id);
        return { ...device, screenshotStats: stats.data };
      } catch {
        return { ...device, screenshotStats: { todayCount: 0, totalCount: 0 } };
      }
    });

    devices.value = await Promise.all(statsPromises);
    pagination.total = data.total || 0;
  } catch (error: any) {
    ElMessage.error(error.message || "加载设备列表失败");
  } finally {
    loading.value = false;
  }
};

// 审核通过
const handleApprove = async (row: Device) => {
  try {
    await ElMessageBox.confirm(
      `确定要审核通过设备「${row.employeeName || row.hostname}」吗？通过后设备可正常上传与执行任务。`,
      "审核确认",
      { confirmButtonText: "通过", cancelButtonText: "取消", type: "info" },
    );

    await deviceApi.updateStatus(row.id, "approved");
    ElMessage.success("审核通过成功");
    await refreshDeviceRow(row.id);
  } catch (error: any) {
    if (error !== "cancel") {
      ElMessage.error(error.message || "审核失败");
    }
  }
};

// 审核拒绝
const handleReject = async (row: Device) => {
  try {
    await ElMessageBox.confirm(
      `确定要拒绝设备「${row.employeeName || row.hostname}」的注册申请吗？拒绝后该设备将无法上传数据。`,
      "拒绝确认",
      { confirmButtonText: "拒绝", cancelButtonText: "取消", type: "warning" },
    );

    await deviceApi.updateStatus(row.id, "rejected");
    ElMessage.success("已拒绝该设备");
    await refreshDeviceRow(row.id);
  } catch (error: any) {
    if (error !== "cancel") {
      ElMessage.error(error.message || "拒绝失败");
    }
  }
};

const refreshDeviceRow = async (deviceId: string) => {
  await loadDevices();
  if (detailDialogVisible.value && currentDevice.value?.id === deviceId) {
    currentDevice.value = devices.value.find((d) => d.id === deviceId) || null;
  }
};

// 从详情对话框审核通过
const handleApproveFromDetail = async () => {
  if (currentDevice.value) {
    await handleApprove(currentDevice.value);
    detailDialogVisible.value = false;
  }
};

// 从详情对话框审核拒绝
const handleRejectFromDetail = async () => {
  if (currentDevice.value) {
    await handleReject(currentDevice.value);
    detailDialogVisible.value = false;
  }
};

// 查看截图
const handleViewScreenshots = (row: Device) => {
  router.push({
    path: "/screenshots",
    query: { deviceId: row.id, deviceName: row.employeeName || row.hostname },
  });
};

// 从详情对话框查看截图
const handleViewScreenshotsFromDetail = () => {
  if (currentDevice.value) {
    handleViewScreenshots(currentDevice.value);
    detailDialogVisible.value = false;
  }
};

// 查看录屏
const handleViewRecordings = (row: Device) => {
  router.push(`/recordings?deviceId=${row.id}`);
};

// 编辑员工信息
const handleEditEmployee = (row: Device) => {
  editingDeviceId.value = row.id;
  employeeForm.employeeName = row.employeeName || "";
  employeeForm.employeeNumber = row.employeeNumber || "";
  employeeForm.position = row.position || "";
  employeeForm.employeeId = row.employeeId || "";
  editEmployeeDialogVisible.value = true;
};

// 从详情对话框编辑员工
const handleEditEmployeeFromDetail = () => {
  if (currentDevice.value) {
    handleEditEmployee(currentDevice.value);
    detailDialogVisible.value = false;
  }
};

// 确认编辑员工信息
const confirmEditEmployee = async () => {
  if (!employeeFormRef.value) return;

  try {
    await employeeFormRef.value.validate();
  } catch {
    return;
  }

  editEmployeeLoading.value = true;
  try {
    await deviceApi.updateEmployee(editingDeviceId.value, {
      employeeId: employeeForm.employeeId,
      employeeName: employeeForm.employeeName,
      employeeNumber: employeeForm.employeeNumber,
      position: employeeForm.position,
    });
    ElMessage.success("员工信息更新成功");
    editEmployeeDialogVisible.value = false;
    await loadDevices();
  } catch (error: any) {
    ElMessage.error(error.message || "更新失败");
  } finally {
    editEmployeeLoading.value = false;
  }
};

// 解绑设备
const handleUnbind = (row: Device) => {
  ElMessageBox.confirm(`确定要解绑设备 "${row.hostname}" 吗？`, "提示", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  }).then(async () => {
    try {
      await deviceApi.unbind(row.id);
      ElMessage.success("解绑成功");
      loadDevices();
    } catch (error: any) {
      ElMessage.error(error.message || "解绑失败");
    }
  });
};

// 查看详情
const handleViewDetail = (row: Device) => {
  currentDevice.value = row;
  detailDialogVisible.value = true;
};

// 设备信息上报
const handleReportInfo = async (row: Device) => {
  try {
    await ElMessageBox.confirm(
      `确定要向服务器上报设备 "${row.hostname}" 的当前信息吗？`,
      "确认上报",
      { confirmButtonText: "确定", cancelButtonText: "取消", type: "info" },
    );

    const reportLoading = ElMessage({
      message: "正在上报设备信息...",
      type: "info",
      duration: 0,
    });

    try {
      await deviceApi.reportInfo({
        deviceId: row.deviceFingerprint,
        hostname: row.hostname,
        osVersion: row.osVersion,
        agentVersion: row.agentVersion,
      });

      reportLoading.close();
      ElMessage.success("设备信息上报成功");
      await loadDevices();
    } catch (error: any) {
      reportLoading.close();
      ElMessage.error(error.message || "上报失败");
    }
  } catch {
    // 用户取消
  }
};

// 从详情对话框上报信息
const handleReportInfoFromDetail = async () => {
  if (!currentDevice.value) return;

  try {
    await ElMessageBox.confirm(
      `确定要向服务器上报设备 "${currentDevice.value.hostname}" 的当前信息吗？`,
      "确认上报",
      { confirmButtonText: "确定", cancelButtonText: "取消", type: "info" },
    );

    const reportLoading = ElMessage({
      message: "正在上报设备信息...",
      type: "info",
      duration: 0,
    });

    try {
      await deviceApi.reportInfo({
        deviceId: currentDevice.value.deviceFingerprint,
        hostname: currentDevice.value.hostname,
        osVersion: currentDevice.value.osVersion,
        agentVersion: currentDevice.value.agentVersion,
      });

      reportLoading.close();
      ElMessage.success("设备信息上报成功");
      await loadDevices();
      if (currentDevice.value) {
        const updatedDevice = devices.value.find(
          (d) => d.id === currentDevice.value!.id,
        );
        if (updatedDevice) {
          currentDevice.value = updatedDevice;
        }
      }
    } catch (error: any) {
      reportLoading.close();
      ElMessage.error(error.message || "上报失败");
    }
  } catch {
    // 用户取消
  }
};

// 导出员工设备信息
const handleExport = async () => {
  const headers = [
    "员工姓名",
    "工号",
    "职位",
    "员工ID",
    "设备名称",
    "设备ID",
    "操作系统",
    "Agent版本",
    "审核状态",
    "在线状态",
    "最后在线时间",
    "绑定时间",
  ];
  const rows = devices.value.map((d) => [
    d.employeeName || "-",
    d.employeeNumber || "-",
    d.position || "-",
    d.employeeId || "-",
    d.hostname,
    d.id,
    d.osVersion || "-",
    d.agentVersion || "-",
    getAuditStatusText(d.status),
    d.onlineStatus === "online" ? "在线" : "离线",
    formatTime(d.lastSeenAt),
    formatTime(d.boundAt),
  ]);

  const csvContent = [headers, ...rows].map((row) => row.join(",")).join("\n");
  const blob = new Blob(["\uFEFF" + csvContent], {
    type: "text/csv;charset=utf-8;",
  });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.href = url;
  link.setAttribute(
    "download",
    `employees_devices_${new Date().toISOString().slice(0, 10)}.csv`,
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
  ElMessage.success("导出成功");
};

const handleSearch = () => {
  pagination.page = 1;
  loadDevices();
};

// 每页条数变化时使用
const handleSizeChange = (size: number) => {
  pagination.pageSize = size;
  pagination.page = 1;
  loadDevices();
};

// 页码变化时使用（不要重置页码）
const handleCurrentChange = (page: number) => {
  pagination.page = page;
  loadDevices();
};

const handleReset = () => {
  filters.employeeSearch = "";
  filters.deviceStatus = "";
  filters.keyword = "";
  pagination.page = 1;
  handleSearch();
};

const handleRefresh = () => {
  loadDevices();
};

const handleDeviceRegistered = () => {
  loadDevices();
};

onMounted(() => {
  loadDevices();
  window.addEventListener("device-registered", handleDeviceRegistered);
});

onUnmounted(() => {
  window.removeEventListener("device-registered", handleDeviceRegistered);
});
</script>

<style scoped>
.devices-page {
  padding: 0px;
  min-height: 100vh;
  background: #f0f2f6;
  position: relative;
}

/* ========== 背景装饰 ========== */
.bg-decoration {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 0;
  overflow: hidden;
}

.blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}

.blob-1 {
  width: 500px;
  height: 500px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  top: -200px;
  right: -100px;
  animation-delay: 0s;
}

.blob-2 {
  width: 600px;
  height: 600px;
  background: linear-gradient(135deg, #f093fb, #f5576c);
  bottom: -250px;
  left: -150px;
  animation-delay: -5s;
}

.blob-3 {
  width: 400px;
  height: 400px;
  background: linear-gradient(135deg, #4facfe, #00f2fe);
  top: 40%;
  left: 30%;
  animation-delay: -10s;
}

@keyframes float {
  0%,
  100% {
    transform: translate(0, 0) scale(1);
  }
  33% {
    transform: translate(30px, -30px) scale(1.05);
  }
  66% {
    transform: translate(-20px, 20px) scale(0.95);
  }
}

/* 确保内容在背景之上 */
.filter-card,
.table-card {
  position: relative;
  z-index: 1;
}

.filter-card {
  margin-bottom: 20px;
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  transition: all 0.3s ease;
}

.table-card {
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  transition: all 0.3s ease;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.filter-form {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
}

.filter-form .el-form-item {
  margin-bottom: 0;
  display: inline-flex;
  align-items: center;
}

.card-hover {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.card-hover:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
}

/* 按钮样式 */
:deep(.el-button--primary) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border: none;
  transition: all 0.3s ease;
}

:deep(.el-button--primary):hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

:deep(.el-button--success) {
  background: linear-gradient(135deg, #43e97b, #38f9d7);
  border: none;
  color: #1a1a2e;
}

:deep(.el-button--success):hover {
  transform: translateY(-2px);
}

:deep(.el-button--warning) {
  background: linear-gradient(135deg, #f093fb, #f5576c);
  border: none;
  color: white;
}

:deep(.el-button--warning):hover {
  transform: translateY(-2px);
}

/* 表格样式优化 */
:deep(.el-table) {
  background: transparent;
}

:deep(.el-table__header-wrapper) {
  background: rgba(248, 250, 252, 0.9);
}

:deep(.el-table__header th) {
  background: transparent;
  font-weight: 600;
  color: #1e293b;
}

:deep(.el-table__row) {
  transition: all 0.2s ease;
}

:deep(.el-table__row:hover) {
  transform: translateX(2px);
  background: linear-gradient(90deg, rgba(102, 126, 234, 0.05), transparent);
}

/* 按钮链接样式 */
.el-button.is-link {
  transition: all 0.2s ease;
}

.el-button.is-link:hover {
  transform: translateX(2px);
}

/* 标签样式 */
.el-tag {
  transition: all 0.2s ease;
}

.el-tag:hover {
  transform: scale(1.02);
}

/* 现代化对话框 */
.modern-dialog :deep(.el-dialog) {
  border-radius: 20px;
  overflow: hidden;
}

.modern-dialog :deep(.el-dialog__header) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  padding: 16px 20px;
  margin: 0;
}

.modern-dialog :deep(.el-dialog__title) {
  color: white;
  font-weight: 600;
  font-size: 18px;
}

.modern-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: white;
  font-size: 18px;
}

.modern-dialog :deep(.el-dialog__body) {
  padding: 20px;
  max-height: 60vh;
  overflow-y: auto;
}

.modern-dialog :deep(.el-dialog__footer) {
  padding: 16px 20px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

/* 描述列表样式优化 */
:deep(.el-descriptions) {
  background: transparent;
}

:deep(.el-descriptions__label) {
  background: rgba(248, 250, 252, 0.8);
  font-weight: 600;
}

.form-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

/* 截图统计列样式 */
.screenshot-stats {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.stats-today,
.stats-total {
  display: flex;
  justify-content: space-between;
  width: 100%;
  font-size: 13px;
  padding: 4px 8px;
  border-radius: 8px;
}

.stats-today {
  background: linear-gradient(135deg, #d4edda20, #c3e6cb20);
}

.stats-total {
  background: linear-gradient(135deg, #d0ebfc20, #bae6fd20);
}

.stats-label {
  color: #909399;
  font-weight: normal;
}

.stats-value {
  font-weight: bold;
  color: #606266;
}

.stats-value.has-data {
  color: #409eff;
}

.stats-today .stats-value.has-data {
  color: #67c23a;
}

.stats-total .stats-value.has-data {
  color: #409eff;
}

/* 动画 */
.animate-dialog :deep(.el-dialog) {
  animation: dialogFadeIn 0.3s ease;
}

@keyframes dialogFadeIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

/* 滚动条美化 */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(135deg, #5a67d8, #6b46c1);
}

/* 加载遮罩 */
.el-loading-mask {
  border-radius: 8px;
}

/* 分页样式 */
.pagination :deep(.el-pagination .btn-prev),
.pagination :deep(.el-pagination .btn-next),
.pagination :deep(.el-pager li) {
  border-radius: 10px;
  margin: 0 3px;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  font-weight: 500;
  min-width: 36px;
  height: 36px;
}

.pagination :deep(.el-pager li.active) {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-color: transparent;
  color: #ffffff;
}

/* 响应式 */
@media (max-width: 1200px) {
  .devices-page {
    padding: 0px;
  }

  .blob-1,
  .blob-2,
  .blob-3 {
    opacity: 0.2;
  }
}

@media (max-width: 768px) {
  .devices-page {
    padding: 2px;
  }

  .blob-1,
  .blob-2,
  .blob-3 {
    display: none;
  }

  .filter-form {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }

  .filter-form .el-form-item {
    margin-bottom: 0;
    width: 100%;
  }

  .filter-form .el-form-item .el-select,
  .filter-form .el-form-item .el-input {
    width: 100% !important;
  }

  .table-card :deep(.el-table) {
    overflow-x: auto;
  }

  .table-card :deep(.el-table__fixed-right) {
    height: auto !important;
  }

  .el-dialog {
    width: 95% !important;
    margin: 20px auto !important;
  }

  .pagination {
    overflow-x: auto;
  }

  .pagination :deep(.el-pagination) {
    flex-wrap: wrap;
    justify-content: center;
  }

  .el-table .el-button.is-link {
    padding: 4px 6px;
    font-size: 12px;
  }
}

@media (min-width: 769px) and (max-width: 1024px) {
  .el-table .el-button.is-link {
    padding: 4px 8px;
  }
}
/* 操作按钮组 */
.action-buttons {
  display: flex;
  gap: 6px;
  justify-content: center;
  flex-wrap: wrap;
}

.action-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  border-radius: 16px;
  font-size: 12px;
  font-weight: 500;
  transition: all 0.2s ease;
}

/* 截图按钮 */
.screenshot-btn {
  background: rgba(64, 158, 255, 0.1);
  color: #409eff;
}

.screenshot-btn:hover {
  background: rgba(64, 158, 255, 0.2);
  transform: translateY(-1px);
}

/* 录屏按钮 */
.recording-btn {
  background: rgba(64, 158, 255, 0.1);
  color: #409eff;
}

.recording-btn:hover {
  background: rgba(64, 158, 255, 0.2);
  transform: translateY(-1px);
}

/* 编辑按钮 */
.edit-btn {
  background: rgba(64, 158, 255, 0.1);
  color: #409eff;
}

.edit-btn:hover {
  background: rgba(64, 158, 255, 0.2);
  transform: translateY(-1px);
}

/* 审核按钮 */
.approve-btn {
  background: rgba(103, 194, 58, 0.1);
  color: #67c23a;
}

.approve-btn:hover {
  background: rgba(103, 194, 58, 0.2);
  transform: translateY(-1px);
}

/* 解绑按钮 */
.unbind-btn {
  background: rgba(230, 162, 60, 0.1);
  color: #e6a23c;
}

.unbind-btn:hover {
  background: rgba(230, 162, 60, 0.2);
  transform: translateY(-1px);
}

/* 详情按钮 */
.detail-btn {
  background: rgba(144, 147, 153, 0.1);
  color: #909399;
}

.detail-btn:hover {
  background: rgba(144, 147, 153, 0.2);
  transform: translateY(-1px);
}

/* 上报按钮 */
.report-btn {
  background: rgba(64, 158, 255, 0.1);
  color: #409eff;
}

.report-btn:hover {
  background: rgba(64, 158, 255, 0.2);
  transform: translateY(-1px);
}

/* 按钮图标样式 */
.action-btn .el-icon {
  font-size: 13px;
}

.action-btn:hover .el-icon {
  transform: scale(1.05);
}

/* 响应式：小屏幕时按钮换行 */
@media (max-width: 1400px) {
  .action-buttons {
    gap: 4px;
  }

  .action-btn {
    padding: 3px 8px;
    font-size: 11px;
  }
}

@media (max-width: 1200px) {
  .action-btn span {
    display: none;
  }

  .action-btn {
    padding: 6px;
    border-radius: 50%;
  }

  .action-btn .el-icon {
    font-size: 14px;
    margin: 0;
  }
}
</style>

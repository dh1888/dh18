// frontend/src/router/index.ts
import { createRouter, createWebHistory } from "vue-router";
import { useUserStore } from "@store/user";

// 定义应用名称
const APP_TITLE = "DHPG管理后台";

const routes = [
  {
    path: "/login",
    name: "Login",
    component: () => import("@views/Login.vue"),
    meta: { requiresAuth: false, title: "登录" },
  },
  {
    path: "/",
    component: () => import("@layouts/MainLayout.vue"),
    meta: { requiresAuth: true },
    children: [
      {
        path: "",
        name: "Dashboard",
        component: () => import("@views/Dashboard.vue"),
        meta: { title: "仪表盘", icon: "DataLine" },
      },
      {
        path: "devices",
        name: "Devices",
        component: () => import("@views/Devices.vue"),
        meta: { title: "员工管理", icon: "Monitor", permission: "device:view" },
      },
      {
        path: "recordings",
        name: "Recordings",
        component: () => import("@views/Recordings.vue"),
        meta: {
          title: "录屏查看",
          icon: "VideoCamera",
          permission: "recording:view",
        },
      },
      {
        path: "policies",
        name: "Policies",
        component: () => import("@views/Policies.vue"),
        meta: {
          title: "策略管理",
          icon: "Document",
          permission: "policy:view",
        },
      },
      {
        path: "settings",
        name: "Settings",
        component: () => import("@views/Settings.vue"),
        meta: {
          title: "系统设置",
          icon: "Setting",
          permission: "policy:update",
        },
      },
      {
        path: "users",
        name: "Users",
        component: () => import("@views/Users.vue"),
        meta: { title: "用户管理", icon: "User", permission: "user:view" },
      },
      {
        path: "roles",
        name: "Roles",
        component: () => import("@views/Roles.vue"),
        meta: { title: "角色管理", icon: "Avatar", permission: "role:view" },
      },
      {
        path: "profile",
        name: "Profile",
        component: () => import("@views/Profile.vue"),
        meta: { title: "个人资料", icon: "UserFilled" },
      },
      {
        path: "upload",
        name: "Upload",
        component: () => import("@views/UploadManager.vue"),
        meta: {
          title: "上传任务",
          icon: "Upload",
          permission: "recording:upload",
        },
      },
      {
        path: "screenshots",
        name: "Screenshots",
        component: () => import("@views/Screenshots.vue"),
        meta: {
          title: "截图查看",
          icon: "Camera",
          permission: "screenshot:view",
        },
      },
      {
        path: "activities",
        name: "Activities",
        component: () => import("@views/Activities.vue"),
        meta: { title: "活动日志", icon: "List", permission: "activity:view" },
      },
      {
        path: "remote-screen",
        name: "RemoteScreen",
        component: () => import("@views/RemoteScreenManager.vue"),
        meta: {
          title: "远程屏幕",
          icon: "Connection",
          permission: "device:view",
          keepAlive: false,
        },
      },
      // 在 routes 数组中 children 里添加
      {
        path: "attendance",
        redirect: "/attendance/records",
      },
      {
        path: "attendance/records",
        name: "AttendanceRecords",
        component: () => import("@views/attendance/AttendanceRecords.vue"),
        meta: {
          title: "考勤查看",
          icon: "Calendar",
          permission: "attendance:view",
        },
      },
      {
        path: "attendance/performance",
        name: "PerformanceReview",
        component: () => import("@views/attendance/PerformanceReview.vue"),
        meta: {
          title: "绩效考核",
          icon: "TrendCharts",
          permission: "attendance:view",
        },
      },
      {
        path: "attendance/penalty",
        name: "PenaltyDetails",
        component: () => import("@views/attendance/PenaltyDetails.vue"),
        meta: {
          title: "罚款详情",
          icon: "Warning",
          permission: "attendance:view",
        },
      },
      {
        path: "site-management",
        name: "SiteManagement",
        component: () => import("@views/SiteManagement.vue"),
        meta: {
          title: "出款站点",
          icon: "OfficeBuilding",
          permission: "site:view",
        },
      },
      {
        path: "site-stats",
        name: "SiteStats",
        component: () => import("@views/SiteStats.vue"),
        meta: {
          title: "出款统计",
          icon: "TrendCharts",
          permission: "stats:view",
        },
      },
      {
        path: "monthly-stats",
        name: "MonthlyStats",
        component: () => import("@views/MonthlyStats.vue"),
        meta: {
          title: "出款汇总",
          icon: "DataAnalysis",
          permission: "stats:view",
        },
      },
      {
        path: "salary-management",
        name: "SalaryManagement",
        component: () => import("@views/SalaryManagement.vue"),
        meta: {
          title: "工资管理",
          icon: "Money",
          permission: "salary:upload",
        },
      },
      {
        path: "salary-view",
        name: "SalaryView",
        component: () => import("@views/SalaryView.vue"),
        meta: {
          title: "工资查看",
          icon: "Money",
          permission: "salary:view",
        },
      },
      {
        path: "operation-logs",
        name: "OperationLogs",
        component: () => import("@views/OperationLogs.vue"),
        meta: {
          title: "操作日志",
          icon: "Document",
          permission: "operation_log:view",
        },
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

/**
 * 基于用户实际权限检查
 * @param permission 需要的权限
 * @returns 是否拥有权限
 */
function checkPermission(permission: string): boolean {
  const userStore = useUserStore();

  // 未登录时返回 false
  if (!userStore.isAuthenticated) {
    return false;
  }

  // 超级管理员（admin角色）拥有所有权限
  if (userStore.role === "admin") {
    return true;
  }

  // 从 userStore.permissions 读取用户的实际权限列表
  const userPermissions = userStore.permissions || [];
  return userPermissions.includes(permission);
}

// 设置页面标题
const setPageTitle = (to: any) => {
  const pageTitle = to.meta?.title as string;
  if (pageTitle) {
    document.title = `${pageTitle} - ${APP_TITLE}`;
  } else {
    document.title = APP_TITLE;
  }
};

router.beforeEach((to, _from, next) => {
  const userStore = useUserStore();

  // ✅ 修复：先尝试恢复会话
  if (to.meta.requiresAuth !== false && !userStore.isAuthenticated) {
    const restored = userStore.restoreSession();
    if (!restored) {
      next("/login");
      return;
    }
  }

  // 已登录时访问登录页，跳转到首页
  if (to.path === "/login" && userStore.isAuthenticated) {
    next("/");
    return;
  }

  // 权限检查
  const requiredPermission = to.meta.permission as string;
  if (requiredPermission && userStore.isAuthenticated) {
    if (!checkPermission(requiredPermission)) {
      next("/");
      return;
    }
  }

  // 设置浏览器标题
  setPageTitle(to);

  next();
});

export default router;

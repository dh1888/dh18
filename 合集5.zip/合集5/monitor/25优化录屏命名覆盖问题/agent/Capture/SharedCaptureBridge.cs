using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Capture;

/// <summary>
/// Single desktop capture (gdigrab) with frame relay to two named pipe consumers.
/// </summary>
public sealed class SharedCaptureBridge : ISharedCaptureBridge
{
    private static readonly TimeSpan ConsumerConnectTimeout = TimeSpan.FromSeconds(30);
    private static readonly TimeSpan FlowingTimeout = TimeSpan.FromSeconds(45);

    private readonly ILogger<SharedCaptureBridge> _logger;
    private readonly SharedCapturePipeHost _pipeHost;
    private readonly object _stateGate = new();
    private TaskCompletionSource _flowingTcs = CreateFlowingTcs();

    private Process? _bridgeProcess;
    private Task? _relayTask;
    private CancellationTokenSource? _bridgeCts;
    private byte[]? _frameBuffer;
    private int _captureWidth;
    private int _captureHeight;
    private int _captureFps;
    private SharedBridgeState _state = SharedBridgeState.Idle;
    private SharedBridgeReadyFlags _readyFlags;
    private DateTime _lastFrameUtc = DateTime.MinValue;
    private long _lastFrameCount;
    private long _producerSessionFrames;
    private SharedBridgeReadyFlags _flowingRequiredFlags = SharedBridgeReady.RunningRequired;
    private string? _lastError;
    private bool _disposed;

    public SharedCaptureBridge(
        ILogger<SharedCaptureBridge> logger,
        SharedCapturePipeHost pipeHost)
    {
        _logger = logger;
        _pipeHost = pipeHost;
    }

    public SharedBridgeState State
    {
        get { lock (_stateGate) return _state; }
    }

    public SharedBridgeReadyFlags ReadyFlags
    {
        get { lock (_stateGate) return _readyFlags; }
    }

    public bool IsActive =>
        State is SharedBridgeState.Preparing
            or SharedBridgeState.PipesListening
            or SharedBridgeState.ConsumersConnected
            or SharedBridgeState.BridgeStarting
            or SharedBridgeState.Flowing;

    public async Task PrepareAsync(int width, int height, int fps, CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        if (State == SharedBridgeState.Stopped)
            TransitionTo(SharedBridgeState.Idle);

        _captureWidth = width;
        _captureHeight = height;
        _captureFps = fps;

        TransitionTo(SharedBridgeState.Preparing);
        _logger.LogInformation("Bridge Preparing: {Width}x{Height}@{Fps}", width, height, fps);

        ResetFlowingSignal();
        SetReadyFlag(SharedBridgeReadyFlags.None, replace: true);

        await _pipeHost.PrepareAsync(width, height, fps, cancellationToken);
        _frameBuffer = new byte[_pipeHost.FrameBytes];

        SetReadyFlag(SharedBridgeReadyFlags.PipesListening);
        TransitionTo(SharedBridgeState.PipesListening);
        _logger.LogInformation("Bridge state: PipesListening");
    }

    public async Task WaitConsumersConnectedAsync(CancellationToken cancellationToken = default)
    {
        EnsureState(SharedBridgeState.PipesListening);
        await _pipeHost.WaitConsumersConnectedAsync(ConsumerConnectTimeout, cancellationToken);
        SetReadyFlag(SharedBridgeReadyFlags.RecordingConnected | SharedBridgeReadyFlags.RemoteConnected);
        TransitionTo(SharedBridgeState.ConsumersConnected);
        _logger.LogInformation("Recording Connected; Remote Connected");
    }

    public async Task StartBridgeAsync(CancellationToken cancellationToken = default)
    {
        EnsureState(SharedBridgeState.ConsumersConnected);

        var ffmpeg = FindFfmpeg();
        if (string.IsNullOrWhiteSpace(ffmpeg))
            throw new InvalidOperationException("ffmpeg.exe not found for SharedCaptureBridge");

        TransitionTo(SharedBridgeState.BridgeStarting);
        _logger.LogInformation("Bridge Started (launching gdigrab producer)");

        _bridgeCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var linked = _bridgeCts.Token;

        var args =
            $"-hide_banner -loglevel error -nostats " +
            $"-f gdigrab -framerate {_captureFps} -i desktop " +
            $"-vf \"fps={_captureFps},scale={_captureWidth}:{_captureHeight}:force_original_aspect_ratio=decrease," +
            $"pad={_captureWidth}:{_captureHeight}:(ow-iw)/2:(oh-ih)/2,format=bgr24\" " +
            "-f rawvideo -pix_fmt bgr24 -";

        _bridgeProcess = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = ffmpeg,
                Arguments = args,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true,
                RedirectStandardOutput = true,
            },
            EnableRaisingEvents = true,
        };

        if (!_bridgeProcess.Start())
            throw new InvalidOperationException("Failed to start SharedCaptureBridge producer process");

        Interlocked.Exchange(ref _producerSessionFrames, 0);

        _ = Task.Run(() => DrainBridgeStderrAsync(_bridgeProcess, linked), CancellationToken.None);
        _relayTask = Task.Run(() => RelayFramesAsync(_bridgeProcess, linked), CancellationToken.None);
        ObserveRelayTask(_relayTask);

        SetReadyFlag(SharedBridgeReadyFlags.BridgeStarted);
        _logger.LogInformation("Bridge producer process started pid={Pid}", _bridgeProcess.Id);
    }

    public async Task WaitFlowingAsync(CancellationToken cancellationToken = default, bool requireConsumerFirstFrames = true)
    {
        EnsureAtLeast(SharedBridgeState.BridgeStarting);

        _flowingRequiredFlags = requireConsumerFirstFrames
            ? SharedBridgeReady.RunningRequired
            : SharedBridgeReady.ProducerFlowingRequired;

        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(FlowingTimeout);

        try
        {
            await _flowingTcs.Task.WaitAsync(timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException(
                $"Timed out waiting for SharedBridge first frame (ready={ReadyFlags}, required={_flowingRequiredFlags}, frames={_pipeHost.FramesWritten}, producerFrames={_producerSessionFrames})");
        }

        if ((ReadyFlags & _flowingRequiredFlags) != _flowingRequiredFlags)
        {
            throw new InvalidOperationException(
                $"SharedBridge not fully ready: missing {(_flowingRequiredFlags & ~ReadyFlags)}");
        }

        TransitionTo(SharedBridgeState.Flowing);
        _logger.LogInformation("Bridge Flowing");
    }

    public async Task RestartProducerAsync(CancellationToken cancellationToken = default)
    {
        if (State is not (SharedBridgeState.Flowing
            or SharedBridgeState.BridgeStarting
            or SharedBridgeState.ConsumersConnected))
        {
            _logger.LogWarning("SharedBridge producer restart skipped in state {State}", State);
            return;
        }

        _logger.LogInformation("SharedBridge producer restart (consumers remain connected)");

        if (State is not SharedBridgeState.ConsumersConnected)
            await StopProducerInternalAsync(cancellationToken);

        lock (_stateGate)
        {
            _readyFlags &= SharedBridgeReadyFlags.PipesListening
                | SharedBridgeReadyFlags.RecordingConnected
                | SharedBridgeReadyFlags.RemoteConnected
                | SharedBridgeReadyFlags.RecordingFirstFrame
                | SharedBridgeReadyFlags.RemoteFirstFrame;
        }

        ResetFlowingSignal();
        _flowingRequiredFlags = SharedBridgeReady.ProducerFlowingRequired;
        TransitionTo(SharedBridgeState.ConsumersConnected);
        await StartBridgeAsync(cancellationToken);
        await WaitFlowingAsync(cancellationToken, requireConsumerFirstFrames: false);
    }

    public async Task ReconnectConsumerAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        if (State is SharedBridgeState.Idle or SharedBridgeState.Stopped or SharedBridgeState.Preparing)
        {
            throw new InvalidOperationException(
                $"Cannot reconnect {consumer} pipe while SharedBridge is in state {State}");
        }

        _logger.LogInformation("SharedBridge reconnect consumer: {Consumer}", consumer);

        await _pipeHost.ReconnectPipeAsync(consumer, ConsumerConnectTimeout, cancellationToken);

        lock (_stateGate)
        {
            if (consumer == CaptureConsumer.Recording)
            {
                _readyFlags |= SharedBridgeReadyFlags.RecordingConnected;
                _readyFlags &= ~SharedBridgeReadyFlags.RecordingFirstFrame;
            }
            else
            {
                _readyFlags |= SharedBridgeReadyFlags.RemoteConnected;
                _readyFlags &= ~SharedBridgeReadyFlags.RemoteFirstFrame;
            }
        }

        _logger.LogInformation("SharedBridge consumer reconnected: {Consumer}", consumer);
    }

    public Task ResetSessionAsync(CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        ResetFlowingSignal();
        SetReadyFlag(SharedBridgeReadyFlags.None, replace: true);
        TransitionTo(SharedBridgeState.Idle);
        _lastError = null;
        _lastFrameUtc = DateTime.MinValue;
        Interlocked.Exchange(ref _lastFrameCount, 0);
        _frameBuffer = null;

        _logger.LogInformation("SharedBridge session reset to Idle");
        return Task.CompletedTask;
    }

    public async Task StopAsync(CancellationToken cancellationToken = default)
    {
        if (State is SharedBridgeState.Idle or SharedBridgeState.Stopped)
            return;

        TransitionTo(SharedBridgeState.Stopping);
        _logger.LogInformation("Bridge Stop");

        await StopProducerInternalAsync(cancellationToken);
        await _pipeHost.StopAsync();
        TransitionTo(SharedBridgeState.Stopped);
        _logger.LogInformation("Bridge Stopped");
    }

    private async Task StopProducerInternalAsync(CancellationToken cancellationToken)
    {
        _bridgeCts?.Cancel();

        if (_bridgeProcess is { HasExited: false })
        {
            try
            {
                if (!_bridgeProcess.WaitForExit(3000))
                    _bridgeProcess.Kill(entireProcessTree: true);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to stop bridge producer process");
            }
        }

        if (_relayTask != null)
        {
            try { await _relayTask.WaitAsync(TimeSpan.FromSeconds(5), cancellationToken); }
            catch { /* ignore relay shutdown timeout */ }
        }

        _bridgeProcess?.Dispose();
        _bridgeProcess = null;
        _relayTask = null;
        _bridgeCts?.Dispose();
        _bridgeCts = null;
    }

    public async Task DisposeAsync(CancellationToken cancellationToken = default)
    {
        if (_disposed) return;
        _disposed = true;
        await StopAsync(cancellationToken);
        await _pipeHost.DisposeAsync();
    }

    public void NotifyConsumerFirstFrame(CaptureConsumer consumer)
    {
        switch (consumer)
        {
            case CaptureConsumer.Recording:
                SetReadyFlag(SharedBridgeReadyFlags.RecordingFirstFrame);
                _logger.LogInformation("Recording first frame observed on SharedBridge consumer");
                break;
            case CaptureConsumer.RemoteView:
                SetReadyFlag(SharedBridgeReadyFlags.RemoteFirstFrame);
                _logger.LogInformation("Remote first frame observed on SharedBridge consumer");
                break;
        }

        TryMarkFlowing();
    }

    public bool NeedsConsumerFirstFrame(CaptureConsumer consumer)
    {
        lock (_stateGate)
        {
            if (State is SharedBridgeState.Idle or SharedBridgeState.Stopped or SharedBridgeState.Preparing)
                return false;

            var flag = consumer == CaptureConsumer.Recording
                ? SharedBridgeReadyFlags.RecordingFirstFrame
                : SharedBridgeReadyFlags.RemoteFirstFrame;

            if ((_readyFlags & flag) != 0)
                return false;

            return consumer == CaptureConsumer.Recording
                ? _pipeHost.RecordingConnected
                : _pipeHost.RemoteConnected;
        }
    }

    public SharedBridgeHealthSnapshot GetHealthSnapshot()
    {
        var frames = _pipeHost.FramesWritten;
        var now = DateTime.UtcNow;
        var frameAge = _lastFrameUtc == DateTime.MinValue ? double.MaxValue : (now - _lastFrameUtc).TotalSeconds;
        var previous = Interlocked.Exchange(ref _lastFrameCount, frames);

        return new SharedBridgeHealthSnapshot
        {
            State = State,
            ReadyFlags = ReadyFlags,
            BridgeProcessAlive = _bridgeProcess is { HasExited: false },
            RecordingPipeConnected = _pipeHost.RecordingConnected,
            RemotePipeConnected = _pipeHost.RemoteConnected,
            FrameFlowing = frames > 0 && frameAge < 5,
            FramesWritten = frames,
            FramesSinceUtc = frames - previous,
            LastFrameUtc = _lastFrameUtc,
            LastError = _lastError,
        };
    }

    private async Task RelayFramesAsync(Process process, CancellationToken cancellationToken)
    {
        var buffer = _frameBuffer ?? throw new InvalidOperationException("Frame buffer not initialized");
        var stdout = process.StandardOutput.BaseStream;

        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                if (process.HasExited)
                    break;

                var offset = 0;
                while (offset < buffer.Length)
                {
                    var read = await stdout.ReadAsync(buffer.AsMemory(offset, buffer.Length - offset), cancellationToken);
                    if (read == 0)
                        throw new EndOfStreamException("SharedBridge producer stdout ended before full frame");

                    offset += read;
                }

                var writeResult = await _pipeHost.WriteFrameAsync(buffer, cancellationToken);
                _lastFrameUtc = DateTime.UtcNow;

                if (writeResult.RecordingWritten && NeedsConsumerFirstFrame(CaptureConsumer.Recording))
                    NotifyConsumerFirstFrame(CaptureConsumer.Recording);
                if (writeResult.RemoteWritten && NeedsConsumerFirstFrame(CaptureConsumer.RemoteView))
                    NotifyConsumerFirstFrame(CaptureConsumer.RemoteView);

                if (Interlocked.Increment(ref _producerSessionFrames) == 1)
                {
                    SetReadyFlag(SharedBridgeReadyFlags.FirstFrameWritten);
                    _logger.LogInformation("First Frame relayed from bridge to both consumers");
                    TryMarkFlowing();
                }
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // expected during stop
        }
        catch (IOException ex)
        {
            _lastError = ex.Message;
            _logger.LogWarning(ex, "SharedBridge frame relay stopped: no live consumer pipes");
            StopProducerAfterRelayFailure();
        }
        catch (Exception ex)
        {
            _lastError = ex.Message;
            _logger.LogError(ex, "SharedBridge frame relay failed");
            _flowingTcs.TrySetException(ex);
            StopProducerAfterRelayFailure();
        }
    }

    private void ObserveRelayTask(Task? relayTask)
    {
        if (relayTask == null)
            return;

        _ = relayTask.ContinueWith(
            t =>
            {
                if (t.Exception != null)
                    _logger.LogError(t.Exception.GetBaseException(), "SharedBridge relay task faulted");
            },
            CancellationToken.None,
            TaskContinuationOptions.OnlyOnFaulted,
            TaskScheduler.Default);
    }

    private void TryMarkFlowing()
    {
        if ((ReadyFlags & _flowingRequiredFlags) != _flowingRequiredFlags)
            return;

        _flowingTcs.TrySetResult();
    }

    private void StopProducerAfterRelayFailure()
    {
        try
        {
            _bridgeCts?.Cancel();

            if (_bridgeProcess is { HasExited: false })
            {
                try
                {
                    if (!_bridgeProcess.WaitForExit(3000))
                        _bridgeProcess.Kill(entireProcessTree: true);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to kill bridge producer after relay failure");
                }
            }

            _bridgeProcess?.Dispose();
            _bridgeProcess = null;
            _bridgeCts?.Dispose();
            _bridgeCts = null;

            if (State is SharedBridgeState.Flowing or SharedBridgeState.BridgeStarting)
            {
                lock (_stateGate)
                {
                    _readyFlags &= SharedBridgeReadyFlags.PipesListening
                        | SharedBridgeReadyFlags.RecordingConnected
                        | SharedBridgeReadyFlags.RemoteConnected
                        | SharedBridgeReadyFlags.RecordingFirstFrame
                        | SharedBridgeReadyFlags.RemoteFirstFrame;
                }

                TransitionTo(SharedBridgeState.ConsumersConnected);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to stop SharedBridge producer after relay failure");
        }
    }

    private async Task DrainBridgeStderrAsync(Process process, CancellationToken cancellationToken)
    {
        try
        {
            while (!cancellationToken.IsCancellationRequested && !process.HasExited)
            {
                var line = await process.StandardError.ReadLineAsync(cancellationToken);
                if (line == null) break;
                if (line.Contains("error", StringComparison.OrdinalIgnoreCase))
                    _logger.LogWarning("Bridge producer: {Line}", line);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // expected
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Bridge stderr reader ended");
        }
    }

    private void ResetFlowingSignal() => _flowingTcs = CreateFlowingTcs();

    private static TaskCompletionSource CreateFlowingTcs() =>
        new(TaskCreationOptions.RunContinuationsAsynchronously);

    private void SetReadyFlag(SharedBridgeReadyFlags flag, bool replace = false)
    {
        lock (_stateGate)
            _readyFlags = replace ? flag : _readyFlags | flag;
    }

    private void TransitionTo(SharedBridgeState state)
    {
        lock (_stateGate)
            _state = state;
    }

    private void EnsureState(SharedBridgeState expected)
    {
        if (State != expected)
            throw new InvalidOperationException($"SharedBridge expected state {expected} but was {State}");
    }

    private void EnsureAtLeast(SharedBridgeState expected)
    {
        if (State < expected)
            throw new InvalidOperationException($"SharedBridge expected at least {expected} but was {State}");
    }

    private static string? FindFfmpeg()
    {
        var paths = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "ffmpeg.exe"),
            Path.Combine(AppContext.BaseDirectory, "bin", "ffmpeg.exe"),
            @"C:\ffmpeg\bin\ffmpeg.exe",
        };

        foreach (var path in paths)
        {
            if (File.Exists(path))
                return path;
        }

        return null;
    }
}

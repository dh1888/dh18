using System.IO.Pipes;
using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.Capture;

public readonly record struct PipeFrameWriteResult(bool RecordingWritten, bool RemoteWritten);

/// <summary>
/// Owns Windows named pipe servers for recording and remote encoder consumers.
/// Server writes raw BGR24 frames; FFmpeg consumers connect as clients and read.
/// </summary>
public sealed class SharedCapturePipeHost : IAsyncDisposable
{
    public const string RecordingPipeName = "agent_capture_rec";
    public const string RemotePipeName = "agent_capture_rv";

    private readonly ILogger<SharedCapturePipeHost> _logger;
    private readonly object _gate = new();
    private readonly SemaphoreSlim _reconnectGate = new(1, 1);

    private NamedPipeServerStream? _recordingPipe;
    private NamedPipeServerStream? _remotePipe;
    private TaskCompletionSource _recordingConnectedTcs = CreateConnectionTcs();
    private TaskCompletionSource _remoteConnectedTcs = CreateConnectionTcs();
    private CancellationTokenSource? _listenCts;

    private int _width;
    private int _height;
    private int _fps;
    private int _frameBytes;
    private long _framesWritten;
    private bool _disposed;
    private bool _sessionActive;

    public SharedCapturePipeHost(ILogger<SharedCapturePipeHost> logger) => _logger = logger;

    public bool RecordingConnected => IsPipeLive(_recordingPipe);
    public bool RemoteConnected => IsPipeLive(_remotePipe);
    public long FramesWritten => Interlocked.Read(ref _framesWritten);
    public int FrameBytes => _frameBytes;
    public bool SessionActive => _sessionActive;

    public static string RecordingPipePath => $@"\\.\pipe\{RecordingPipeName}";
    public static string RemotePipePath => $@"\\.\pipe\{RemotePipeName}";

    public static string BuildRecordingInputArgs(int width, int height, int fps) =>
        $"-f rawvideo -pix_fmt bgr24 -video_size {width}x{height} -framerate {fps} -i \"{RecordingPipePath}\"";

    public static string BuildRemoteInputArgs(int width, int height, int fps) =>
        $"-f rawvideo -pix_fmt bgr24 -video_size {width}x{height} -framerate {fps} -i \"{RemotePipePath}\"";

    public async Task PrepareAsync(int width, int height, int fps, CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        await StopSessionPipesAsync();

        _width = width;
        _height = height;
        _fps = fps;
        _frameBytes = width * height * 3;
        Interlocked.Exchange(ref _framesWritten, 0);
        _recordingConnectedTcs = CreateConnectionTcs();
        _remoteConnectedTcs = CreateConnectionTcs();

        _listenCts?.Dispose();
        _listenCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        _sessionActive = true;

        _recordingPipe = CreateServerStream(RecordingPipeName);
        _remotePipe = CreateServerStream(RemotePipeName);

        _logger.LogInformation(
            "Pipe Listening: recording={RecordingPipe}, remote={RemotePipe}, {Width}x{Height}@{Fps}, frameBytes={FrameBytes}",
            RecordingPipePath,
            RemotePipePath,
            width,
            height,
            fps,
            _frameBytes);

        _ = WaitForClientAsync(_recordingPipe, _recordingConnectedTcs, CaptureConsumer.Recording, _listenCts.Token);
        _ = WaitForClientAsync(_remotePipe, _remoteConnectedTcs, CaptureConsumer.RemoteView, _listenCts.Token);

        await Task.Yield();
    }

    public async Task WaitConsumersConnectedAsync(TimeSpan timeout, CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(timeout);

        try
        {
            await Task.WhenAll(_recordingConnectedTcs.Task, _remoteConnectedTcs.Task)
                .WaitAsync(timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException(
                $"Timed out waiting for SharedBridge consumers to connect (recording={RecordingConnected}, remote={RemoteConnected})");
        }

        if (!RecordingConnected || !RemoteConnected)
        {
            throw new InvalidOperationException(
                $"SharedBridge consumer pipes not live after connect wait (recording={RecordingConnected}, remote={RemoteConnected})");
        }
    }

    public async Task ReconnectPipeAsync(
        CaptureConsumer consumer,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (!_sessionActive)
            throw new InvalidOperationException("Cannot reconnect pipe: SharedCapture session is not active");

        await _reconnectGate.WaitAsync(cancellationToken);
        try
        {
            _logger.LogInformation("Pipe Reconnect: {Consumer}", consumer);

            if (consumer == CaptureConsumer.Recording)
            {
                await RecreateRecordingPipeAsync(cancellationToken);
            }
            else
            {
                await RecreateRemotePipeAsync(cancellationToken);
            }

            var tcs = consumer == CaptureConsumer.Recording ? _recordingConnectedTcs : _remoteConnectedTcs;
            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeoutCts.CancelAfter(timeout);

            try
            {
                await tcs.Task.WaitAsync(timeoutCts.Token);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                throw new TimeoutException($"Timed out waiting for {consumer} pipe reconnect");
            }

            var live = consumer == CaptureConsumer.Recording ? RecordingConnected : RemoteConnected;
            if (!live)
                throw new InvalidOperationException($"{consumer} pipe reconnect completed but pipe is not live");

            _logger.LogInformation("Pipe Reconnected: {Consumer}", consumer);
        }
        finally
        {
            _reconnectGate.Release();
        }
    }

    public async Task<PipeFrameWriteResult> WriteFrameAsync(ReadOnlyMemory<byte> frame, CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (frame.Length != _frameBytes)
            throw new InvalidOperationException($"Frame size mismatch: expected {_frameBytes}, got {frame.Length}");

        NamedPipeServerStream? recording;
        NamedPipeServerStream? remote;
        lock (_gate)
        {
            recording = _recordingPipe;
            remote = _remotePipe;
        }

        var recordingWritten = false;
        var remoteWritten = false;

        if (recording != null && IsPipeLive(recording))
        {
            try
            {
                await recording.WriteAsync(frame, cancellationToken);
                await recording.FlushAsync(cancellationToken);
                recordingWritten = true;
            }
            catch (Exception ex) when (ex is IOException or InvalidOperationException or ObjectDisposedException)
            {
                _logger.LogWarning(ex, "Recording pipe write failed; marking pipe broken");
                await InvalidatePipeAsync(CaptureConsumer.Recording);
            }
        }

        if (remote != null && IsPipeLive(remote))
        {
            try
            {
                await remote.WriteAsync(frame, cancellationToken);
                await remote.FlushAsync(cancellationToken);
                remoteWritten = true;
            }
            catch (Exception ex) when (ex is IOException or InvalidOperationException or ObjectDisposedException)
            {
                _logger.LogWarning(ex, "Remote pipe write failed; marking pipe broken");
                await InvalidatePipeAsync(CaptureConsumer.RemoteView);
            }
        }

        if (!recordingWritten && !remoteWritten)
            throw new IOException("SharedBridge frame write failed: no consumer pipes are live");

        Interlocked.Increment(ref _framesWritten);
        return new PipeFrameWriteResult(recordingWritten, remoteWritten);
    }

    public async Task StopAsync()
    {
        _listenCts?.Cancel();
        await StopSessionPipesAsync();
        _sessionActive = false;
        _logger.LogInformation("Pipe Closed");
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed) return;
        _disposed = true;
        await StopAsync();
        _listenCts?.Dispose();
        _listenCts = null;
        _reconnectGate.Dispose();
    }

    private async Task RecreateRecordingPipeAsync(CancellationToken cancellationToken)
    {
        NamedPipeServerStream? previous;
        lock (_gate)
        {
            previous = _recordingPipe;
            _recordingPipe = CreateServerStream(RecordingPipeName);
            _recordingConnectedTcs = CreateConnectionTcs();
        }

        await DisposePipeAsync(previous);
        await StartListeningAsync(_recordingPipe, _recordingConnectedTcs, CaptureConsumer.Recording, cancellationToken);
    }

    private async Task RecreateRemotePipeAsync(CancellationToken cancellationToken)
    {
        NamedPipeServerStream? previous;
        lock (_gate)
        {
            previous = _remotePipe;
            _remotePipe = CreateServerStream(RemotePipeName);
            _remoteConnectedTcs = CreateConnectionTcs();
        }

        await DisposePipeAsync(previous);
        await StartListeningAsync(_remotePipe, _remoteConnectedTcs, CaptureConsumer.RemoteView, cancellationToken);
    }

    private Task StartListeningAsync(
        NamedPipeServerStream? pipe,
        TaskCompletionSource connectedTcs,
        CaptureConsumer consumer,
        CancellationToken cancellationToken)
    {
        if (_listenCts == null || _listenCts.IsCancellationRequested)
            throw new InvalidOperationException("Pipe host listener is not active");
        if (pipe == null)
            throw new InvalidOperationException($"{consumer} pipe was not recreated");

        _ = WaitForClientAsync(pipe, connectedTcs, consumer, _listenCts.Token);
        return Task.CompletedTask;
    }

    private async Task InvalidatePipeAsync(CaptureConsumer consumer)
    {
        NamedPipeServerStream? pipe;
        lock (_gate)
        {
            if (consumer == CaptureConsumer.Recording)
            {
                pipe = _recordingPipe;
                _recordingPipe = null;
            }
            else
            {
                pipe = _remotePipe;
                _remotePipe = null;
            }
        }

        await DisposePipeAsync(pipe);
    }

    private async Task WaitForClientAsync(
        NamedPipeServerStream pipe,
        TaskCompletionSource tcs,
        CaptureConsumer consumer,
        CancellationToken cancellationToken)
    {
        var label = consumer == CaptureConsumer.Recording ? "Recording" : "Remote";
        try
        {
            await pipe.WaitForConnectionAsync(cancellationToken);
            if (!IsPipeLive(pipe))
            {
                tcs.TrySetException(new InvalidOperationException($"{label} pipe disconnected immediately after connect"));
                return;
            }

            _logger.LogInformation("{Label} Connected", label);
            tcs.TrySetResult();
        }
        catch (OperationCanceledException)
        {
            tcs.TrySetCanceled(cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "{Label} pipe connection failed", label);
            tcs.TrySetException(ex);
        }
    }

    private static bool IsPipeLive(NamedPipeServerStream? pipe)
    {
        if (pipe == null)
            return false;

        try
        {
            return pipe.IsConnected;
        }
        catch (ObjectDisposedException)
        {
            return false;
        }
    }

    private static NamedPipeServerStream CreateServerStream(string pipeName) =>
        new(
            pipeName,
            PipeDirection.Out,
            maxNumberOfServerInstances: 1,
            PipeTransmissionMode.Byte,
            PipeOptions.Asynchronous);

    private async Task StopSessionPipesAsync()
    {
        NamedPipeServerStream? recording;
        NamedPipeServerStream? remote;
        lock (_gate)
        {
            recording = _recordingPipe;
            remote = _remotePipe;
            _recordingPipe = null;
            _remotePipe = null;
        }

        await DisposePipeAsync(recording);
        await DisposePipeAsync(remote);
    }

    private static async Task DisposePipeAsync(NamedPipeServerStream? pipe)
    {
        if (pipe == null) return;
        try
        {
            if (pipe.IsConnected)
                pipe.Disconnect();
        }
        catch
        {
            // ignore disconnect failures during teardown
        }

        await pipe.DisposeAsync();
    }

    private static TaskCompletionSource CreateConnectionTcs() =>
        new(TaskCreationOptions.RunContinuationsAsynchronously);
}

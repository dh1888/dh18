namespace EnterpriseAgent.Agent.Capture;

public enum SharedBridgeState
{
    Idle,
    Preparing,
    PipesListening,
    ConsumersConnected,
    BridgeStarting,
    Flowing,
    Stopping,
    Stopped,
}

public enum SharedBridgeReadyFlags
{
    None = 0,
    PipesListening = 1 << 0,
    RecordingConnected = 1 << 1,
    RemoteConnected = 1 << 2,
    BridgeStarted = 1 << 3,
    FirstFrameWritten = 1 << 4,
    RecordingFirstFrame = 1 << 5,
    RemoteFirstFrame = 1 << 6,
}

public static class SharedBridgeReady
{
    public const SharedBridgeReadyFlags ProducerFlowingRequired =
        SharedBridgeReadyFlags.PipesListening
        | SharedBridgeReadyFlags.RecordingConnected
        | SharedBridgeReadyFlags.RemoteConnected
        | SharedBridgeReadyFlags.BridgeStarted
        | SharedBridgeReadyFlags.FirstFrameWritten;

    public const SharedBridgeReadyFlags RunningRequired =
        ProducerFlowingRequired
        | SharedBridgeReadyFlags.RecordingFirstFrame
        | SharedBridgeReadyFlags.RemoteFirstFrame;
}

namespace EnterpriseAgent.Agent.Capture;

public sealed class CaptureConfig
{
    public CaptureMode Mode { get; set; } = CaptureMode.DualGdigrab;
    public int BridgeFps { get; set; } = 15;
}

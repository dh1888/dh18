using EnterpriseAgent.Agent.Models;
using EnterpriseAgent.Agent.RemoteView;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

using AgentPolicy = EnterpriseAgent.Agent.Models.Policy;

namespace EnterpriseAgent.Agent.Capture;

public sealed class CaptureCoordinator : ICaptureCoordinator, IDisposable
{
    private readonly ILogger<CaptureCoordinator> _logger;
    private readonly CaptureConfig _config;
    private readonly RemoteViewConfig _remoteConfig;
    private readonly ISharedCaptureBridge _sharedBridge;
    private readonly object _gate = new();

    private AgentPolicy? _policy;
    private bool _recordingActive;
    private bool _remoteActive;
    private bool _sharedCaptureManaged;
    private bool _sharedBridgeOrchestrated;
    private int _bridgeWidth = 1920;
    private int _bridgeHeight = 1080;
    private int _bridgeFps = 15;
    private bool _disposed;

    public CaptureCoordinator(
        ILogger<CaptureCoordinator> logger,
        IOptions<CaptureConfig> config,
        IOptions<RemoteViewConfig> remoteConfig,
        ISharedCaptureBridge sharedBridge)
    {
        _logger = logger;
        _config = config.Value;
        _remoteConfig = remoteConfig.Value;
        _sharedBridge = sharedBridge;
    }

    public CaptureMode Mode => UsesSharedBridgeProfile() ? CaptureMode.SharedBridge : CaptureMode.DualGdigrab;

    public bool IsSharedCaptureActive => _sharedCaptureManaged && _sharedBridge.IsActive;

    public bool IsSharedBridgeOrchestrated => _sharedBridgeOrchestrated;

    public void UpdatePolicy(AgentPolicy? policy) => _policy = policy;

    public CaptureProfile GetProfile()
    {
        lock (_gate)
        {
            var recordingConfig = _policy?.GetRecordingConfig() ?? new RecordingConfig();
            var recFps = Math.Clamp(recordingConfig.Fps, 1, 30);
            var recResolution = ResolveResolution(recordingConfig.Resolution);
            var remoteWidth = _remoteConfig.TargetWidth;
            var remoteHeight = _remoteConfig.TargetHeight;
            var remoteFps = _remoteConfig.TargetFps;

            if (UsesSharedBridgeProfile())
            {
                return new CaptureProfile
                {
                    Mode = CaptureMode.SharedBridge,
                    RecordingWidth = _bridgeWidth,
                    RecordingHeight = _bridgeHeight,
                    RecordingFps = _bridgeFps,
                    RemoteWidth = _bridgeWidth,
                    RemoteHeight = _bridgeHeight,
                    RemoteFps = _bridgeFps,
                    RecordingInputArgs = SharedCapturePipeHost.BuildRecordingInputArgs(_bridgeWidth, _bridgeHeight, _bridgeFps),
                    RemoteInputArgs = SharedCapturePipeHost.BuildRemoteInputArgs(_bridgeWidth, _bridgeHeight, _bridgeFps),
                };
            }

            return new CaptureProfile
            {
                Mode = CaptureMode.DualGdigrab,
                RecordingWidth = recResolution.width,
                RecordingHeight = recResolution.height,
                RecordingFps = recFps,
                RemoteWidth = remoteWidth,
                RemoteHeight = remoteHeight,
                RemoteFps = remoteFps,
            };
        }
    }

    public Task NotifyConsumerStartingAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default)
    {
        lock (_gate)
        {
            if (consumer == CaptureConsumer.Recording)
                _recordingActive = true;
            else
                _remoteActive = true;
        }

        PrepareBridgeDimensions();
        return Task.CompletedTask;
    }

    public Task NotifyConsumerStoppingAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default)
    {
        lock (_gate)
        {
            if (consumer == CaptureConsumer.Recording)
                _recordingActive = false;
            else
                _remoteActive = false;
        }

        if (_sharedCaptureManaged)
            return Task.CompletedTask;

        return Task.CompletedTask;
    }

    public async Task PrepareSharedCaptureAsync(CancellationToken cancellationToken = default)
    {
        lock (_gate)
        {
            _sharedCaptureManaged = true;
            _sharedBridgeOrchestrated = true;
        }

        PrepareBridgeDimensions(force: true);

        _logger.LogInformation(
            "Prepare SharedCapture {Width}x{Height}@{Fps}",
            _bridgeWidth,
            _bridgeHeight,
            _bridgeFps);
        await _sharedBridge.PrepareAsync(_bridgeWidth, _bridgeHeight, _bridgeFps, cancellationToken);
    }

    public Task WaitSharedConsumersConnectedAsync(CancellationToken cancellationToken = default) =>
        _sharedBridge.WaitConsumersConnectedAsync(cancellationToken);

    public Task StartSharedCaptureAsync(CancellationToken cancellationToken = default) =>
        _sharedBridge.StartBridgeAsync(cancellationToken);

    public     Task WaitSharedBridgeFlowingAsync(CancellationToken cancellationToken = default, bool requireConsumerFirstFrames = true) =>
        _sharedBridge.WaitFlowingAsync(cancellationToken, requireConsumerFirstFrames);

    public async Task StopSharedCaptureAsync(CancellationToken cancellationToken = default)
    {
        if (!_sharedCaptureManaged)
            return;

        await _sharedBridge.StopAsync(cancellationToken);
    }

    public async Task DisposeSharedCaptureAsync(CancellationToken cancellationToken = default)
    {
        if (!_sharedCaptureManaged)
            return;

        await _sharedBridge.StopAsync(cancellationToken);
        await _sharedBridge.ResetSessionAsync(cancellationToken);
        ResetConsumerTracking();
        _sharedCaptureManaged = false;
        _sharedBridgeOrchestrated = false;
        _logger.LogInformation("Restore DualGdigrab (shared capture disposed)");
    }

    public Task RestartSharedBridgeProducerAsync(CancellationToken cancellationToken = default)
    {
        if (!_sharedCaptureManaged)
            return Task.CompletedTask;

        return _sharedBridge.RestartProducerAsync(cancellationToken);
    }

    public async Task ReconnectSharedBridgeConsumerAsync(CaptureConsumer consumer, CancellationToken cancellationToken = default)
    {
        if (!_sharedCaptureManaged)
            return;

        var health = _sharedBridge.GetHealthSnapshot();
        var connected = consumer == CaptureConsumer.Recording
            ? health.RecordingPipeConnected
            : health.RemotePipeConnected;

        if (connected)
            return;

        await _sharedBridge.ReconnectConsumerAsync(consumer, cancellationToken);
    }

    public async Task ReconnectBrokenSharedBridgeConsumersAsync(CancellationToken cancellationToken = default)
    {
        if (!_sharedCaptureManaged)
            return;

        var health = _sharedBridge.GetHealthSnapshot();
        if (!health.RecordingPipeConnected)
        {
            _logger.LogWarning("SharedBridge health: reconnecting recording pipe");
            await _sharedBridge.ReconnectConsumerAsync(CaptureConsumer.Recording, cancellationToken);
        }

        if (!health.RemotePipeConnected)
        {
            _logger.LogWarning("SharedBridge health: reconnecting remote pipe");
            await _sharedBridge.ReconnectConsumerAsync(CaptureConsumer.RemoteView, cancellationToken);
        }
    }

    public void NotifyConsumerFirstFrame(CaptureConsumer consumer) =>
        _sharedBridge.NotifyConsumerFirstFrame(consumer);

    public bool NeedsConsumerFirstFrame(CaptureConsumer consumer) =>
        _sharedBridge.NeedsConsumerFirstFrame(consumer);

    public void SetSharedBridgeOrchestrated(bool orchestrated) =>
        _sharedBridgeOrchestrated = orchestrated;

    public void ResetConsumerTracking()
    {
        lock (_gate)
        {
            _recordingActive = false;
            _remoteActive = false;
        }
    }

    public SharedBridgeHealthSnapshot GetSharedBridgeHealth() =>
        _sharedBridge.GetHealthSnapshot();

    private bool UsesSharedBridgeProfile()
    {
        if (_sharedCaptureManaged)
            return true;

        if (_config.Mode == CaptureMode.SharedBridge)
            return _recordingActive || _remoteActive;

        return _recordingActive && _remoteActive;
    }

    private void PrepareBridgeDimensions(bool force = false)
    {
        lock (_gate)
        {
            // Pipe frame size is fixed once the bridge session is listening — never shrink mid-session.
            if (_sharedBridge.IsActive)
                return;

            if (!force && !_sharedCaptureManaged && !UsesSharedBridgeProfile() && !(_recordingActive && _remoteActive))
                return;

            var recordingConfig = _policy?.GetRecordingConfig() ?? new RecordingConfig();
            var recResolution = ResolveResolution(recordingConfig.Resolution);
            _bridgeWidth = Math.Max(recResolution.width, _remoteConfig.TargetWidth);
            _bridgeHeight = Math.Max(recResolution.height, _remoteConfig.TargetHeight);
            _bridgeFps = Math.Max(Math.Clamp(recordingConfig.Fps, 1, 30), _remoteConfig.TargetFps);
            if (_config.BridgeFps > 0)
                _bridgeFps = Math.Min(_bridgeFps, _config.BridgeFps);
        }
    }

    private static (int width, int height) ResolveResolution(string? resolution)
    {
        if (string.IsNullOrWhiteSpace(resolution))
            return (1920, 1080);

        var parts = resolution.Split('x', 'X');
        if (parts.Length == 2 &&
            int.TryParse(parts[0], out var w) &&
            int.TryParse(parts[1], out var h))
            return (w, h);

        return (1920, 1080);
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _sharedBridge.DisposeAsync().GetAwaiter().GetResult();
    }
}

package services

import (
	"testing"

	"github.com/google/uuid"
)

func TestExportStatKeySeparatesSharedTelegramEmployees(t *testing.T) {
	tgUID := int64(987654321)
	empA := uuid.MustParse("11111111-1111-1111-1111-111111111111")
	empB := uuid.MustParse("22222222-2222-2222-2222-222222222222")

	keyA := exportStatKey(empA, tgUID, "day")
	keyB := exportStatKey(empB, tgUID, "day")
	if keyA == keyB {
		t.Fatalf("shared TG employees must not share export stat key: %q", keyA)
	}
	if exportUserKey(empA, tgUID) != exportUserKey(empA, 0) {
		t.Fatal("export user key should not depend on telegram user id")
	}
}

func TestExportDisplayUserIDStillUsesTelegramWhenPresent(t *testing.T) {
	tgUID := int64(12345)
	empID := uuid.New()
	if got := exportDisplayUserID(tgUID, empID); got != tgUID {
		t.Fatalf("display user id = %d, want %d", got, tgUID)
	}
}

package services

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const defaultDailyResetExecutionOffsetMinutes = 120

func (s *WorkforceTelegramService) dailyResetExecutionOffset(settings *TelegramSettings) time.Duration {
	if settings == nil || settings.DailyResetExecutionOffsetMinutes <= 0 {
		return time.Duration(defaultDailyResetExecutionOffsetMinutes) * time.Minute
	}
	return time.Duration(settings.DailyResetExecutionOffsetMinutes) * time.Minute
}

func (s *WorkforceTelegramService) dailyResetExecutionTimeForChat(ctx context.Context, settings *TelegramSettings, chatID string, now time.Time) time.Time {
	resetTime := settings.DailyResetTime
	if chatID != "" {
		if t := s.GetGroupDailyResetTime(ctx, chatID); t != "" {
			resetTime = t
		}
	}
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	resetH, resetM, ok := parseClock(resetTime)
	if !ok {
		return now
	}
	return time.Date(now.Year(), now.Month(), now.Day(), resetH, resetM, 0, 0, loc).Add(s.dailyResetExecutionOffset(settings))
}

// scheduledResetExportDate 自动日重置只处理日历「昨日」，不碰当日数据。
func (s *WorkforceTelegramService) scheduledResetExportDate(settings *TelegramSettings, now time.Time) string {
	loc := tgLoadLocation(settings.Timezone)
	return now.In(loc).AddDate(0, 0, -1).Format("2006-01-02")
}

func (s *WorkforceTelegramService) shouldRunScheduledDailyReset(ctx context.Context, settings *TelegramSettings, chatID string, now time.Time) bool {
	execAt := s.dailyResetExecutionTimeForChat(ctx, settings, chatID, now)
	if now.Before(execAt) {
		return false
	}
	resetDate := now.Format("2006-01-02")
	return !s.groupResetAlreadyDone(ctx, chatID, resetDate)
}

func (s *WorkforceTelegramService) resetExportDateForChat(ctx context.Context, settings *TelegramSettings, chatID string, now time.Time) string {
	_ = ctx
	_ = chatID
	return s.scheduledResetExportDate(settings, now)
}

// resetExportDateSpan 自动日重置仅导出单日（昨日）；手动重置仍可使用较宽区间。
func (s *WorkforceTelegramService) resetExportDateSpan(ctx context.Context, settings *TelegramSettings, chatID, exportDate string, now time.Time, runOpts *DailyResetRunOptions) (dateFrom, dateTo string) {
	exportDate = strings.TrimSpace(exportDate)
	if exportDate == "" {
		exportDate = s.scheduledResetExportDate(settings, now)
	}
	if runOpts != nil && runOpts.ManualTrigger {
		loc := tgLoadLocation(settings.Timezone)
		calendarYesterday := now.In(loc).AddDate(0, 0, -1).Format("2006-01-02")
		dateFrom, dateTo = exportDate, exportDate
		if calendarYesterday < dateFrom {
			dateFrom = calendarYesterday
		} else if calendarYesterday > dateTo {
			dateTo = calendarYesterday
		}
		return dateFrom, dateTo
	}
	return exportDate, exportDate
}

func (s *WorkforceTelegramService) IsAdminTelegramUser(ctx context.Context, telegramUserID int64) bool {
	for _, id := range s.listAdminTelegramUserIDs(ctx) {
		if id == telegramUserID {
			return true
		}
	}
	return false
}

func (s *WorkforceTelegramService) groupResetAlreadyDone(ctx context.Context, chatID, resetDate string) bool {
	var n int
	_ = s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM wf_tg_group_reset_log WHERE chat_id = $1 AND reset_date = $2::date`, chatID, resetDate).Scan(&n)
	return n > 0
}

func (s *WorkforceTelegramService) MaybeRunDailyReset(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	settings, err := s.GetSettings(ctx)
	if err != nil || !settings.DailyResetEnabled {
		return
	}
	groups, err := s.ListGroups(ctx)
	if err != nil {
		return
	}
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)
	resetDate := now.Format("2006-01-02")
	for _, g := range groups {
		if !g.Enabled || strings.TrimSpace(g.ChatID) == "" {
			continue
		}
		if !s.shouldRunScheduledDailyReset(ctx, settings, g.ChatID, now) {
			continue
		}
		if _, err := s.runDailyResetForGroup(ctx, g.ChatID, resetDate, nil); err != nil {
			log.Printf("[Telegram] group reset %s: %v", g.ChatID, err)
		}
	}
}

// MaybeLazyResetForChat 已废弃：日重置仅由定时任务/补偿任务触发，不在用户点击 TG 时执行。
func (s *WorkforceTelegramService) MaybeLazyResetForChat(ctx context.Context, chatID string) {
	_ = ctx
	_ = chatID
}

func (s *WorkforceTelegramService) RunDailyReset(ctx context.Context, runOpts *DailyResetRunOptions) (*TgDailyResetResult, error) {
	if !TelegramAttendanceEnabled() {
		return nil, ErrTelegramDisabled
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return nil, err
	}
	if !settings.DailyResetEnabled {
		return nil, nil
	}
	groups, err := s.ListGroups(ctx)
	if err != nil {
		return nil, err
	}
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)
	resetDate := now.Format("2006-01-02")
	total := &TgDailyResetResult{ResetDate: resetDate}
	processed := 0
	for _, g := range groups {
		if !g.Enabled || strings.TrimSpace(g.ChatID) == "" {
			continue
		}
		if s.groupResetAlreadyDone(ctx, g.ChatID, resetDate) {
			continue
		}
		r, err := s.runDailyResetForGroup(ctx, g.ChatID, resetDate, runOpts)
		if err != nil {
			return total, err
		}
		if r != nil {
			processed++
			total.ClosedWorkSessions += r.ClosedWorkSessions
			total.ClosedAgentSessions += r.ClosedAgentSessions
			total.ClosedActivities += r.ClosedActivities
			if r.ExportDate != "" {
				total.ExportDate = r.ExportDate
			}
			if r.ExportDateNote != "" {
				total.ExportDateNote = r.ExportDateNote
			}
			if len(r.BindingWarnings) > 0 {
				total.BindingWarnings = append(total.BindingWarnings, r.BindingWarnings...)
			}
			if r.ExportPath != "" {
				total.ExportPath = r.ExportPath
			}
			if r.ArchivedMonth != "" {
				total.ArchivedMonth = r.ArchivedMonth
			}
		}
	}
	total.GroupsProcessed = processed
	if processed == 0 {
		total.SkippedAllGroups = true
	}
	var exists int
	_ = s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM wf_tg_daily_reset_log WHERE reset_date = $1::date`, resetDate).Scan(&exists)
	if exists == 0 && (total.ClosedWorkSessions > 0 || total.ClosedActivities > 0) {
		_, _ = s.db.ExecContext(ctx, `
			INSERT INTO wf_tg_daily_reset_log (reset_date, closed_work_sessions, closed_activities)
			VALUES ($1::date, $2, $3) ON CONFLICT (reset_date) DO NOTHING`,
			resetDate, total.ClosedWorkSessions, total.ClosedActivities)
	}
	return total, nil
}

func (s *WorkforceTelegramService) runDailyResetForGroup(ctx context.Context, chatID, resetDate string, runOpts *DailyResetRunOptions) (*TgDailyResetResult, error) {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return nil, err
	}
	loc := tgLoadLocation(settings.Timezone)
	now := time.Now().In(loc)
	exportDate, exportNote := s.resolveGroupResetExportDate(ctx, settings, chatID, now, runOpts)
	result := &TgDailyResetResult{
		ResetDate:      resetDate,
		ExportDate:     exportDate,
		ExportDateNote: exportNote,
	}

	bindingWarnings := s.collectGroupBindingWarnings(ctx, chatID, exportDate)
	if len(bindingWarnings) > 0 {
		result.BindingWarnings = bindingWarnings
		for _, w := range bindingWarnings {
			log.Printf("[Telegram] group reset binding warning chat=%s: %s", chatID, w)
		}
	}

	completed, err := s.completeMissingWorkEndsForGroup(ctx, chatID, exportDate, runOpts)
	if err != nil {
		return result, fmt.Errorf("complete work ends failed: %w", err)
	}
	result.ClosedWorkSessions += completed

	agentCompleted, err := s.completeMissingAgentWorkEndsForGroup(ctx, chatID, exportDate, runOpts)
	if err != nil {
		return result, fmt.Errorf("complete agent work ends failed: %w", err)
	}
	result.ClosedAgentSessions += agentCompleted

	closedAct, err := s.forceCloseOpenActivitiesForGroup(ctx, chatID, exportDate)
	if err != nil {
		return result, fmt.Errorf("close activities failed: %w", err)
	}
	result.ClosedActivities += closedAct

	if backfilled, err := s.backfillAttendanceCheckoutsForGroup(ctx, chatID, exportDate); err != nil {
		log.Printf("[Telegram] backfill attendance checkouts chat=%s date=%s: %v", chatID, exportDate, err)
	} else if backfilled > 0 {
		log.Printf("[Telegram] backfilled %d attendance checkout(s) chat=%s date=%s", backfilled, chatID, exportDate)
	}

	if attCompleted, err := s.completeMissingAttendanceRecordCheckoutsForGroup(ctx, chatID, exportDate, runOpts); err != nil {
		return result, fmt.Errorf("complete attendance checkouts failed: %w", err)
	} else if attCompleted > 0 {
		log.Printf("[Telegram] completed %d attendance checkout(s) chat=%s date=%s", attCompleted, chatID, exportDate)
	}

	if parsed, err := time.Parse("2006-01-02", exportDate); err == nil {
		lastOfMonth := parsed.AddDate(0, 1, -parsed.Day()).Day()
		if parsed.Day() == lastOfMonth {
			month := parsed.Format("2006-01")
			if err := s.archiveMonthlyStats(ctx, month); err == nil {
				result.ArchivedMonth = month
			}
		}
	}

	exportDateFrom, exportDateTo := s.resetExportDateSpan(ctx, settings, chatID, exportDate, now, runOpts)
	exportPath, exportErr := s.exportBeforeReset(ctx, exportDateFrom, exportDateTo, chatID)
	if exportErr != nil {
		return result, fmt.Errorf("reset export failed: %w", exportErr)
	}
	result.ExportPath = exportPath

	spanNote := ""
	if exportDateFrom != exportDateTo {
		spanNote = fmt.Sprintf("（导出区间 %s ~ %s）", exportDateFrom, exportDateTo)
	}
	caption := fmt.Sprintf(
		"📊 日重置数据导出\n📅 统计日期：%s%s\n📝 %s\n💬 群组：%s",
		exportDate, spanNote, exportNote, chatID,
	)
	if len(bindingWarnings) > 0 {
		caption += "\n⚠️ 绑定告警：\n• " + strings.Join(bindingWarnings, "\n• ")
	}
	if exportPath != "" {
		if data, err := os.ReadFile(exportPath); err == nil {
			s.PushDocumentToChatTargets(ctx, chatID, filepath.Base(exportPath), data, caption, false)
		}
	} else if data, name, err := s.ExportAttendanceXLSX(ctx, exportDateFrom, exportDateTo, chatID); err == nil {
		s.PushDocumentToChatTargets(ctx, chatID, name, data, caption, false)
	}

	for d := exportDateFrom; ; {
		if err := s.purgeDailyDetailForGroup(ctx, chatID, d); err != nil {
			log.Printf("[Telegram] purge daily detail chat=%s date=%s: %v", chatID, d, err)
		}
		if d == exportDateTo {
			break
		}
		parsed, err := time.Parse("2006-01-02", d)
		if err != nil {
			break
		}
		d = parsed.AddDate(0, 0, 1).Format("2006-01-02")
	}

	_, err = s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_group_reset_log (chat_id, reset_date, closed_work_sessions, closed_activities)
		VALUES ($1, $2::date, $3, $4)
		ON CONFLICT (chat_id, reset_date) DO UPDATE SET
			closed_work_sessions = EXCLUDED.closed_work_sessions,
			closed_activities = EXCLUDED.closed_activities,
			run_at = NOW()`,
		chatID, resetDate, result.ClosedWorkSessions, result.ClosedActivities)
	if err != nil {
		return result, err
	}
	return result, nil
}

func (s *WorkforceTelegramService) FormatActivityOccupancy(ctx context.Context, chatID string) string {
	rows, err := s.db.QueryContext(ctx, `
		SELECT t.name, t.max_concurrent,
			(SELECT COUNT(*) FROM wf_tg_activity_sessions s
			 WHERE s.status = 'open' AND s.activity_code = t.code
			   AND ($1 = '' OR COALESCE(s.source_chat_id,'') = $1))
		FROM wf_tg_activity_types t WHERE t.enabled = TRUE ORDER BY t.sort_order, t.name`, chatID)
	if err != nil {
		return "查询失败"
	}
	defer rows.Close()
	var b strings.Builder
	b.WriteString("📊 活动实时占用\n")
	has := false
	for rows.Next() {
		has = true
		var name string
		var maxC, open int
		if rows.Scan(&name, &maxC, &open) != nil {
			continue
		}
		limit := "不限"
		if maxC > 0 {
			limit = fmt.Sprintf("%d/%d", open, maxC)
		} else {
			limit = fmt.Sprintf("%d", open)
		}
		b.WriteString(fmt.Sprintf("• %s：%s\n", name, limit))
	}
	if !has {
		b.WriteString("暂无活动配置")
	}
	return strings.TrimSpace(b.String())
}

func (s *WorkforceTelegramService) BotExportAndPush(ctx context.Context, chatID, dateFrom, dateTo string) (string, error) {
	if strings.TrimSpace(dateFrom) == "" {
		dateFrom = time.Now().Format("2006-01-02")
	}
	if strings.TrimSpace(dateTo) == "" {
		dateTo = dateFrom
	}
	data, filename, err := s.ExportAttendanceXLSX(ctx, dateFrom, dateTo, chatID)
	if err != nil {
		return "", err
	}
	caption := fmt.Sprintf("📤 考勤导出 %s ~ %s", dateFrom, dateTo)
	s.PushDocumentToChatTargets(ctx, chatID, filename, data, caption, false)
	return caption, nil
}

func (s *WorkforceTelegramService) FormatMonthlyReport(ctx context.Context, chatID, yearMonth string) (string, error) {
	if strings.TrimSpace(yearMonth) == "" {
		now := time.Now()
		now = now.AddDate(0, -1, 0)
		yearMonth = now.Format("2006-01")
	}
	t, err := time.Parse("2006-01", yearMonth)
	if err != nil {
		return "", err
	}
	dateFrom := t.Format("2006-01-02")
	dateTo := t.AddDate(0, 1, -1).Format("2006-01-02")

	var fineTotal float64
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(SUM(fine_amount),0) FROM wf_tg_activity_sessions
		WHERE attendance_date BETWEEN $1::date AND $2::date
		  AND ($3 = '' OR COALESCE(source_chat_id,'') = $3)`, dateFrom, dateTo, chatID).Scan(&fineTotal)

	var topName string
	var topSec int
	_ = s.db.QueryRowContext(ctx, `
		SELECT e.name, COALESCE(SUM(EXTRACT(EPOCH FROM (COALESCE(ws.checkout_time, NOW()) - ws.checkin_time))),0)::int
		FROM work_sessions ws JOIN employees e ON e.id = ws.employee_id
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source = 'telegram' AND ws.attendance_date BETWEEN $1::date AND $2::date
		  AND ($3 = '' OR b.chat_id = $3)
		GROUP BY e.name ORDER BY 2 DESC LIMIT 1`, dateFrom, dateTo, chatID).Scan(&topName, &topSec)

	text := fmt.Sprintf("📅 <b>月报 %s</b>\n\n", yearMonth)
	text += fmt.Sprintf("💰 活动罚款合计：¥%.2f\n", fineTotal)
	if topName != "" {
		text += fmt.Sprintf("⏱ 工时最长：%s（%s）\n", topName, formatDurationZh(topSec))
	}
	text += "\n完整数据请使用 /exportmonthly 或后台导出 XLSX。"
	return text, nil
}

func (s *WorkforceTelegramService) FormatShowSettings(ctx context.Context, chatID string) string {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return "读取配置失败"
	}
	mode := s.GetLangMode(ctx, chatID)
	grace, _ := s.GetGraceConfig(ctx, chatID)
	var b strings.Builder
	b.WriteString(fmt.Sprintf("⚙️ <b>群组配置</b> %s\n\n", chatID))
	b.WriteString(fmt.Sprintf("• 界面语言：%s\n", mode))
	b.WriteString(fmt.Sprintf("• 双班：%v | 班次窗口禁用：%v\n", settings.DualShiftEnabled, settings.ShiftWindowDisabled))
	b.WriteString(fmt.Sprintf("• 白班 %s-%s | 夜班 %s-%s\n", settings.DayStart, settings.DayEnd, settings.NightStart, settings.NightEnd))
	b.WriteString(fmt.Sprintf("• 上班打卡窗口 前%d/后%d 分钟\n", grace.CheckInBefore, grace.CheckInAfter))
	b.WriteString(fmt.Sprintf("• 下班打卡窗口 前%d/后%d 分钟\n", grace.CheckOutBefore, grace.CheckOutAfter))
	b.WriteString(fmt.Sprintf("• 迟到/早退宽限 迟到%d 早退%d 分钟\n", grace.LateTolerance, grace.EarlyLeaveTolerance))
	b.WriteString(fmt.Sprintf("• 日重置：%s +%dm（群覆盖：%s）\n", settings.DailyResetTime, settings.DailyResetExecutionOffsetMinutes, s.GetGroupDailyResetTime(ctx, chatID)))
	ps, _ := s.GetPushSettings(ctx, chatID)
	if ps != nil {
		b.WriteString(fmt.Sprintf("• 推送 频道:%s 通知群:%s 额外上班群:%s\n", ps.ChannelID, ps.NotificationGroupID, ps.ExtraWorkGroupID))
		b.WriteString(fmt.Sprintf("• 推送开关 ch=%v gr=%v admin=%v\n", ps.EnableChannelPush, ps.EnableGroupPush, ps.EnableAdminPush))
	}
	return b.String()
}

func (s *WorkforceTelegramService) FixActivityMessageIDs(ctx context.Context) int {
	res, err := s.db.ExecContext(ctx, `UPDATE wf_tg_activity_sessions SET telegram_message_id = NULL WHERE telegram_message_id IS NOT NULL`)
	if err != nil {
		return 0
	}
	n, _ := res.RowsAffected()
	return int(n)
}

func (s *WorkforceTelegramService) RecoverGroupShiftStates(ctx context.Context) {
	_, _ = s.db.ExecContext(ctx, `DELETE FROM wf_tg_group_shift_state`)
	rows, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT b.chat_id, COALESCE(ws.shift_type,'day')
		FROM work_sessions ws
		JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.status = 'open' AND ws.source = 'telegram' AND b.chat_id <> ''`)
	if err != nil {
		return
	}
	defer rows.Close()
	for rows.Next() {
		var chatID, shift string
		if rows.Scan(&chatID, &shift) == nil {
			_, _ = s.db.ExecContext(ctx, `
				INSERT INTO wf_tg_group_shift_state (chat_id, current_shift, updated_at)
				VALUES ($1, $2, NOW())
				ON CONFLICT (chat_id) DO UPDATE SET current_shift = EXCLUDED.current_shift, updated_at = NOW()`,
				chatID, shift)
		}
	}
}

func (s *WorkforceTelegramService) FormatCheckDB(ctx context.Context) string {
	var settingsOK, groups, bindings, openAct, openWork int
	_ = s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM wf_telegram_settings WHERE enabled = TRUE`).Scan(&settingsOK)
	_ = s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM wf_telegram_groups WHERE enabled = TRUE`).Scan(&groups)
	_ = s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM employee_telegram_bindings WHERE status = 1`).Scan(&bindings)
	_ = s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM wf_tg_activity_sessions WHERE status = 'open'`).Scan(&openAct)
	_ = s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM work_sessions WHERE status = 'open' AND source = 'telegram'`).Scan(&openWork)
	return fmt.Sprintf("🗄 DB 状态\n• 启用配置:%d 群组:%d 绑定:%d\n• 进行中活动:%d 上班中:%d",
		settingsOK, groups, bindings, openAct, openWork)
}

func (s *WorkforceTelegramService) BuildActivityBotCommands(ctx context.Context) []map[string]string {
	types, _ := s.ListEnabledActivityTypesForWorker(ctx)
	out := make([]map[string]string, 0, len(types)+12)
	for _, t := range types {
		cmd := activityCommandSlug(t.Name)
		if cmd == "" {
			continue
		}
		out = append(out, map[string]string{"command": cmd, "description": t.Name})
	}
	for _, c := range []struct{ cmd, desc string }{
		{"start", "帮助 / Help"},
		{"checkin", "上班"},
		{"checkout", "下班"},
		{"at", "回座"},
		{"status", "状态"},
		{"myinfo", "我的记录"},
		{"rankings", "排行榜"},
		{"export", "导出今日"},
		{"exportmonthly", "导出上月"},
		{"monthlyreport", "月报摘要"},
		{"actstatus", "活动占用"},
		{"chatid", "Chat ID"},
		{"ci", "快捷开始活动"},
	} {
		out = append(out, map[string]string{"command": c.cmd, "description": c.desc})
	}
	return out
}

func activityCommandSlug(name string) string {
	name = strings.TrimSpace(name)
	if name == "" {
		return ""
	}
	aliases := map[string]string{
		"小厕": "wc1", "大厕": "wc2", "吃饭": "meal", "抽烟或休息": "smoke", "抽烟": "smoke",
	}
	if slug, ok := aliases[name]; ok {
		return slug
	}
	r := strings.NewReplacer(" ", "", "或", "")
	s := r.Replace(name)
	if len([]rune(s)) > 32 {
		s = string([]rune(s)[:32])
	}
	return s
}

func (s *WorkforceTelegramService) ResolveActivityFromCI(ctx context.Context, text string) string {
	text = strings.TrimSpace(text)
	if text == "" {
		return ""
	}
	types, _ := s.ListEnabledActivityTypesForWorker(ctx)
	lookup := s.BuildButtonLookup(ctx, activityNamesFromTypes(types))
	if act := lookup[text]; act != "" {
		for _, t := range types {
			if t.Name == act {
				return t.Name
			}
		}
	}
	lower := strings.ToLower(text)
	for _, t := range types {
		if strings.ToLower(t.Name) == lower || activityCommandSlug(t.Name) == lower {
			return t.Name
		}
	}
	return ""
}

func activityNamesFromTypes(types []TgActivityType) []string {
	names := make([]string, 0, len(types))
	for _, t := range types {
		if strings.TrimSpace(t.Name) != "" {
			names = append(names, t.Name)
		}
	}
	return names
}

package services

import (
	"context"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
)

func telegramShiftStateMaxHours() int {
	if v := strings.TrimSpace(os.Getenv("TELEGRAM_SHIFT_STATE_MAX_HOURS")); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			return n
		}
	}
	return 24
}

func tgExportChatFilter(chatID string) (string, string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return "", ""
	}
	return ` AND EXISTS (
			SELECT 1 FROM employee_telegram_bindings b
			WHERE b.employee_id = ws.employee_id AND b.status = 1
			  AND (
				b.chat_id = $3
				OR (
					COALESCE(NULLIF(TRIM(b.chat_id), ''), '') = ''
					AND EXISTS (
						SELECT 1 FROM wf_tg_activity_sessions s
						WHERE s.employee_id = ws.employee_id
						  AND COALESCE(s.source_chat_id,'') = $3
						  AND s.attendance_date BETWEEN $1::date AND $2::date
					)
				)
			  )
		)`, chatID
}

func tgExportActivityChatFilter(chatID string) (string, string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return "", ""
	}
	return ` AND COALESCE(s.source_chat_id,'') = $3`, chatID
}

func tgExportHandoverChatFilter(chatID string) (string, string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return "", ""
	}
	return ` AND COALESCE(chat_id,'') = $3`, chatID
}

func exportFilenameSuffix(chatID, dateFrom, dateTo string) string {
	if strings.TrimSpace(chatID) == "" {
		return fmt.Sprintf("telegram_attendance_%s_%s", dateFrom, dateTo)
	}
	return fmt.Sprintf("telegram_attendance_%s_%s_%s", chatID, dateFrom, dateTo)
}

func (s *WorkforceTelegramService) resetAutoCheckoutTime(ctx context.Context, settings *TelegramSettings, chatID, exportDate, shift string) time.Time {
	loc := tgLoadLocation(settings.Timezone)
	parsed, err := time.ParseInLocation("2006-01-02", exportDate, loc)
	if err != nil {
		return time.Now().In(loc)
	}
	if shift == "night" {
		startH, startM, ok := parseClock(settings.DayStart)
		if !ok {
			startH, startM = 9, 0
		}
		return time.Date(parsed.Year(), parsed.Month(), parsed.Day()+1, startH, startM, 0, 0, loc)
	}
	resetTime := settings.DailyResetTime
	if t := s.GetGroupDailyResetTime(ctx, chatID); strings.TrimSpace(t) != "" {
		resetTime = t
	}
	resetH, resetM, ok := parseClock(resetTime)
	if !ok {
		resetH, resetM = 0, 0
	}
	return time.Date(parsed.Year(), parsed.Month(), parsed.Day(), resetH, resetM, 0, 0, loc).Add(s.dailyResetExecutionOffset(settings))
}

// resetWorkEndDateFilter 定时/懒重置只处理统计日（昨日）；手动重置保留日期保护。
func resetWorkEndDateFilter(runOpts *DailyResetRunOptions, exportDate string, todayDate string, argN int) (string, []interface{}) {
	if runOpts != nil && runOpts.ManualTrigger {
		if runOpts.ExportBusinessToday {
			return fmt.Sprintf(" AND ws.attendance_date < $%d::date", argN), []interface{}{todayDate}
		}
		return fmt.Sprintf(" AND ws.attendance_date <= $%d::date", argN), []interface{}{exportDate}
	}
	if strings.TrimSpace(exportDate) == "" {
		return "", nil
	}
	return fmt.Sprintf(" AND ws.attendance_date = $%d::date", argN), []interface{}{exportDate}
}

func (s *WorkforceTelegramService) completeMissingWorkEndsForGroup(ctx context.Context, chatID, exportDate string, runOpts *DailyResetRunOptions) (int, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return 0, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return 0, err
	}
	loc := tgLoadLocation(settings.Timezone)
	todayDate := time.Now().In(loc).Format("2006-01-02")
	dateFilter, dateArgs := resetWorkEndDateFilter(runOpts, exportDate, todayDate, 2)
	query := fmt.Sprintf(`
		SELECT ws.id, ws.employee_id, COALESCE(ws.shift_type,'day'), ws.attendance_date::text
		FROM work_sessions ws
		JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source = 'telegram' AND ws.status = 'open' AND b.chat_id = $1%s`, dateFilter)
	args := append([]interface{}{chatID}, dateArgs...)
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	closed := 0
	for rows.Next() {
		var sid, empID uuid.UUID
		var shift, recordDate string
		if rows.Scan(&sid, &empID, &shift, &recordDate) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		checkoutAt := s.resetAutoCheckoutTime(ctx, settings, chatID, exportDate, shift)
		if recordDate != exportDate {
			checkoutAt = s.resetAutoCheckoutTime(ctx, settings, chatID, recordDate, shift)
		}
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, checkoutAt, "日重置补全下班"); err != nil {
			log.Printf("[Telegram] complete work end session=%s: %v", sid, err)
			continue
		}
		closed++
	}
	return closed, nil
}

func (s *WorkforceTelegramService) completeMissingAgentWorkEndsForGroup(ctx context.Context, chatID, exportDate string, runOpts *DailyResetRunOptions) (int, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return 0, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return 0, err
	}
	loc := tgLoadLocation(settings.Timezone)
	todayDate := time.Now().In(loc).Format("2006-01-02")
	dateFilter, dateArgs := resetWorkEndDateFilter(runOpts, exportDate, todayDate, 2)
	query := fmt.Sprintf(`
		SELECT ws.id, ws.employee_id, COALESCE(ws.shift_type,'day'), ws.attendance_date::text
		FROM work_sessions ws
		JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source = 'agent' AND ws.status = 'open' AND b.chat_id = $1%s`, dateFilter)
	args := append([]interface{}{chatID}, dateArgs...)
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	closed := 0
	for rows.Next() {
		var sid, empID uuid.UUID
		var shift, recordDate string
		if rows.Scan(&sid, &empID, &shift, &recordDate) != nil {
			continue
		}
		checkoutAt := s.resetAutoCheckoutTime(ctx, settings, chatID, exportDate, shift)
		if recordDate != exportDate {
			checkoutAt = s.resetAutoCheckoutTime(ctx, settings, chatID, recordDate, shift)
		}
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, checkoutAt, "日重置补全PC下班"); err != nil {
			log.Printf("[Telegram] complete agent work end session=%s: %v", sid, err)
			continue
		}
		closed++
	}
	return closed, nil
}

// backfillAttendanceCheckoutsForGroup copies checkout_time from closed work_sessions into
// attendance_records when the session was closed without syncing attendance (e.g. PC logout).
func (s *WorkforceTelegramService) backfillAttendanceCheckoutsForGroup(ctx context.Context, chatID, exportDate string) (int, error) {
	chatID = strings.TrimSpace(chatID)
	exportDate = strings.TrimSpace(exportDate)
	if chatID == "" || exportDate == "" {
		return 0, nil
	}
	res, err := s.db.ExecContext(ctx, `
		UPDATE attendance_records ar
		SET checkout_time = ws.checkout_time,
			checkout_source = CASE
				WHEN ar.manually_edited THEN ar.checkout_source
				ELSE $3 END,
			updated_at = NOW()
		FROM work_sessions ws
		JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1 AND b.chat_id = $1
		WHERE ar.employee_id = ws.employee_id
		  AND ar.date = ws.attendance_date
		  AND ar.date = $2::date
		  AND ar.checkin_time IS NOT NULL
		  AND ar.checkout_time IS NULL
		  AND NOT ar.manually_edited
		  AND ws.status = 'closed'
		  AND ws.checkout_time IS NOT NULL
		  AND ws.source IN ('telegram','agent')`,
		chatID, exportDate, CheckoutSourceSystem)
	if err != nil {
		return 0, err
	}
	n, _ := res.RowsAffected()
	return int(n), nil
}

// completeMissingAttendanceRecordCheckoutsForGroup fills attendance_records.checkout_time when
// check-in exists but checkout is still missing after session-level补全 (e.g. deleted/mismatched session).
func (s *WorkforceTelegramService) completeMissingAttendanceRecordCheckoutsForGroup(
	ctx context.Context,
	chatID, exportDate string,
	runOpts *DailyResetRunOptions,
) (int, error) {
	chatID = strings.TrimSpace(chatID)
	exportDate = strings.TrimSpace(exportDate)
	if chatID == "" || exportDate == "" {
		return 0, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return 0, err
	}

	rows, err := s.db.QueryContext(ctx, `
		SELECT ar.employee_id, ar.date::text, COALESCE(ws.shift_type,'day')
		FROM attendance_records ar
		JOIN employee_telegram_bindings b ON b.employee_id = ar.employee_id AND b.status = 1 AND b.chat_id = $1
		LEFT JOIN LATERAL (
			SELECT shift_type FROM work_sessions ws
			WHERE ws.employee_id = ar.employee_id
			  AND ws.attendance_date = ar.date
			  AND ws.source IN ('telegram','agent')
			ORDER BY ws.checkin_time DESC
			LIMIT 1
		) ws ON TRUE
		WHERE ar.date = $2::date
		  AND ar.checkin_time IS NOT NULL
		  AND ar.checkout_time IS NULL
		  AND NOT ar.manually_edited
		  AND ar.status NOT IN ('leave','absent','rest_full','rest_half','off_post','resigned')`,
		chatID, exportDate)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	completed := 0
	for rows.Next() {
		var empID uuid.UUID
		var recordDate, shift string
		if rows.Scan(&empID, &recordDate, &shift) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}

		var openSID uuid.UUID
		err = s.db.QueryRowContext(ctx, `
			SELECT id FROM work_sessions
			WHERE employee_id = $1 AND attendance_date = $2::date AND status = 'open'
			ORDER BY checkin_time ASC LIMIT 1`, empID, recordDate).Scan(&openSID)
		if err == nil && openSID != uuid.Nil {
			checkoutAt := s.resetAutoCheckoutTime(ctx, settings, chatID, exportDate, shift)
			if recordDate != exportDate {
				checkoutAt = s.resetAutoCheckoutTime(ctx, settings, chatID, recordDate, shift)
			}
			if err := s.forceCheckoutWorkSessionAt(ctx, openSID, chatID, checkoutAt, "日重置补全下班"); err != nil {
				log.Printf("[Telegram] complete attendance via open session emp=%s date=%s: %v", empID, recordDate, err)
				continue
			}
			completed++
			continue
		}

		checkoutAt := s.resetAutoCheckoutTime(ctx, settings, chatID, exportDate, shift)
		if recordDate != exportDate {
			checkoutAt = s.resetAutoCheckoutTime(ctx, settings, chatID, recordDate, shift)
		}
		if err := s.workforce.syncAttendanceCheckout(ctx, empID, recordDate, checkoutAt, CheckoutSourceSystem); err != nil {
			log.Printf("[Telegram] complete attendance record emp=%s date=%s: %v", empID, recordDate, err)
			continue
		}
		completed++
	}
	return completed, nil
}

func (s *WorkforceTelegramService) ensureExportAttendanceComplete(ctx context.Context, dateFrom, dateTo, chatID string) error {
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return err
	}
	loc := tgLoadLocation(settings.Timezone)
	today := time.Now().In(loc).Format("2006-01-02")
	runOpts := &DailyResetRunOptions{ManualTrigger: true}

	for d := dateFrom; ; {
		if d >= today {
			if d == dateTo {
				break
			}
		} else {
			trimmedChat := strings.TrimSpace(chatID)
			if trimmedChat != "" {
				if _, err := s.completeMissingWorkEndsForGroup(ctx, trimmedChat, d, runOpts); err != nil {
					return err
				}
				if _, err := s.completeMissingAgentWorkEndsForGroup(ctx, trimmedChat, d, runOpts); err != nil {
					return err
				}
				if _, err := s.backfillAttendanceCheckoutsForGroup(ctx, trimmedChat, d); err != nil {
					return err
				}
				if _, err := s.completeMissingAttendanceRecordCheckoutsForGroup(ctx, trimmedChat, d, runOpts); err != nil {
					return err
				}
			} else {
				if _, err := s.completeMissingWorkEndsForExportDate(ctx, d); err != nil {
					return err
				}
				if _, err := s.backfillAttendanceCheckoutsGlobal(ctx, d); err != nil {
					return err
				}
				if _, err := s.completeMissingAttendanceRecordCheckoutsGlobal(ctx, d); err != nil {
					return err
				}
			}
		}
		if d == dateTo {
			break
		}
		parsed, err := time.Parse("2006-01-02", d)
		if err != nil {
			break
		}
		d = parsed.AddDate(0, 0, 1).Format("2006-01-02")
	}
	return nil
}

func (s *WorkforceTelegramService) completeMissingWorkEndsForExportDate(ctx context.Context, exportDate string) (int, error) {
	exportDate = strings.TrimSpace(exportDate)
	if exportDate == "" {
		return 0, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return 0, err
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT ws.id, ws.employee_id, COALESCE(ws.shift_type,'day'), ws.attendance_date::text, COALESCE(b.chat_id,'')
		FROM work_sessions ws
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source IN ('telegram','agent') AND ws.status = 'open'
		  AND ws.attendance_date = $1::date`, exportDate)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	closed := 0
	for rows.Next() {
		var sid, empID uuid.UUID
		var shift, recordDate, chatID string
		if rows.Scan(&sid, &empID, &shift, &recordDate, &chatID) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		checkoutAt := s.resetAutoCheckoutTime(ctx, settings, chatID, exportDate, shift)
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, checkoutAt, "导出补全下班"); err != nil {
			log.Printf("[Telegram] export complete work end session=%s: %v", sid, err)
			continue
		}
		closed++
	}
	return closed, nil
}

func (s *WorkforceTelegramService) backfillAttendanceCheckoutsGlobal(ctx context.Context, exportDate string) (int, error) {
	exportDate = strings.TrimSpace(exportDate)
	if exportDate == "" {
		return 0, nil
	}
	res, err := s.db.ExecContext(ctx, `
		UPDATE attendance_records ar
		SET checkout_time = ws.checkout_time,
			checkout_source = CASE
				WHEN ar.manually_edited THEN ar.checkout_source
				ELSE $2 END,
			updated_at = NOW()
		FROM work_sessions ws
		WHERE ar.employee_id = ws.employee_id
		  AND ar.date = ws.attendance_date
		  AND ar.date = $1::date
		  AND ar.checkin_time IS NOT NULL
		  AND ar.checkout_time IS NULL
		  AND NOT ar.manually_edited
		  AND ws.status = 'closed'
		  AND ws.checkout_time IS NOT NULL
		  AND ws.source IN ('telegram','agent')`,
		exportDate, CheckoutSourceSystem)
	if err != nil {
		return 0, err
	}
	n, _ := res.RowsAffected()
	return int(n), nil
}

func (s *WorkforceTelegramService) completeMissingAttendanceRecordCheckoutsGlobal(ctx context.Context, exportDate string) (int, error) {
	exportDate = strings.TrimSpace(exportDate)
	if exportDate == "" {
		return 0, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return 0, err
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT ar.employee_id, ar.date::text, COALESCE(ws.shift_type,'day')
		FROM attendance_records ar
		LEFT JOIN LATERAL (
			SELECT shift_type FROM work_sessions ws
			WHERE ws.employee_id = ar.employee_id
			  AND ws.attendance_date = ar.date
			  AND ws.source IN ('telegram','agent')
			ORDER BY ws.checkin_time DESC
			LIMIT 1
		) ws ON TRUE
		WHERE ar.date = $1::date
		  AND ar.checkin_time IS NOT NULL
		  AND ar.checkout_time IS NULL
		  AND NOT ar.manually_edited
		  AND ar.status NOT IN ('leave','absent','rest_full','rest_half','off_post','resigned')`,
		exportDate)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	completed := 0
	for rows.Next() {
		var empID uuid.UUID
		var recordDate, shift string
		if rows.Scan(&empID, &recordDate, &shift) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		chatID := s.getChatIDForEmployee(ctx, empID)
		checkoutAt := s.resetAutoCheckoutTime(ctx, settings, chatID, exportDate, shift)
		if err := s.workforce.syncAttendanceCheckout(ctx, empID, recordDate, checkoutAt, CheckoutSourceSystem); err != nil {
			log.Printf("[Telegram] export complete attendance emp=%s date=%s: %v", empID, recordDate, err)
			continue
		}
		completed++
	}
	return completed, nil
}

func (s *WorkforceTelegramService) collectGroupBindingWarnings(ctx context.Context, chatID, exportDate string) []string {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return nil
	}
	warnings := make([]string, 0)

	rows, err := s.db.QueryContext(ctx, `
		SELECT e.name
		FROM employee_telegram_bindings b
		JOIN employees e ON e.id = b.employee_id
		WHERE b.status = 1 AND COALESCE(NULLIF(TRIM(b.chat_id), ''), '') = ''
		ORDER BY e.name`)
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var name string
			if rows.Scan(&name) == nil && strings.TrimSpace(name) != "" {
				warnings = append(warnings, fmt.Sprintf("员工 %s 未设置打卡群 chat_id", name))
			}
		}
	}

	rows2, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT e.name
		FROM wf_tg_activity_sessions s
		JOIN employees e ON e.id = s.employee_id
		JOIN employee_telegram_bindings b ON b.employee_id = s.employee_id AND b.status = 1
		WHERE s.attendance_date = $2::date
		  AND COALESCE(s.source_chat_id,'') = $1
		  AND COALESCE(NULLIF(TRIM(b.chat_id), ''), '') != ''
		  AND COALESCE(NULLIF(TRIM(b.chat_id), ''), '') != $1
		ORDER BY e.name`, chatID, exportDate)
	if err == nil {
		defer rows2.Close()
		for rows2.Next() {
			var name string
			if rows2.Scan(&name) == nil && strings.TrimSpace(name) != "" {
				warnings = append(warnings, fmt.Sprintf("员工 %s 员工绑定打卡群与活动记录群不一致，请在 TG 配置中统一 chat_id", name))
			}
		}
	}

	rows3, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT e.name
		FROM work_sessions ws
		JOIN employees e ON e.id = ws.employee_id
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.attendance_date = $2::date
		  AND ws.source IN ('telegram','agent')
		  AND EXISTS (
			SELECT 1 FROM employee_telegram_bindings bx
			WHERE bx.employee_id = ws.employee_id AND bx.status = 1 AND bx.chat_id = $1
		  )
		  AND COALESCE(NULLIF(TRIM(b.chat_id), ''), '') != ''
		  AND COALESCE(NULLIF(TRIM(b.chat_id), ''), '') != $1
		ORDER BY e.name`, chatID, exportDate)
	if err == nil {
		defer rows3.Close()
		for rows3.Next() {
			var name string
			if rows3.Scan(&name) == nil && strings.TrimSpace(name) != "" {
				warnings = append(warnings, fmt.Sprintf("员工 %s 绑定群与导出群不匹配", name))
			}
		}
	}

	if len(warnings) > 12 {
		extra := len(warnings) - 12
		warnings = append(warnings[:12], fmt.Sprintf("…另有 %d 条绑定告警", extra))
	}
	return warnings
}

func (s *WorkforceTelegramService) resolveGroupResetExportDate(
	ctx context.Context,
	settings *TelegramSettings,
	chatID string,
	now time.Time,
	runOpts *DailyResetRunOptions,
) (exportDate, note string) {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	if runOpts != nil && strings.TrimSpace(runOpts.ForcedExportDate) != "" {
		return strings.TrimSpace(runOpts.ForcedExportDate), "补偿重置：指定统计日"
	}
	if runOpts != nil && runOpts.ManualTrigger {
		if runOpts.ExportBusinessToday {
			if period, err := s.DetermineCurrentPeriod(ctx, chatID, now); err == nil && period != nil && strings.TrimSpace(period.BusinessDate) != "" {
				return period.BusinessDate, "手动重置：导出当前业务日"
			}
			return now.Format("2006-01-02"), "手动重置：导出今日（日历日）"
		}
		return s.scheduledResetExportDate(settings, now), "手动重置：导出昨日"
	}
	exportDate = s.scheduledResetExportDate(settings, now)
	return exportDate, "自动统计日（昨日）"
}

func (s *WorkforceTelegramService) forceCloseOpenActivitiesForGroup(ctx context.Context, chatID, exportDate string) (int, error) {
	chatID = strings.TrimSpace(chatID)
	exportDate = strings.TrimSpace(exportDate)
	if chatID == "" || exportDate == "" {
		return 0, nil
	}
	rows, err := s.db.QueryContext(ctx, `
		SELECT DISTINCT s.employee_id FROM wf_tg_activity_sessions s
		WHERE s.status = 'open' AND COALESCE(s.source_chat_id,'') = $1
		  AND s.attendance_date = $2::date`, chatID, exportDate)
	if err != nil {
		return 0, err
	}
	defer rows.Close()
	closed := 0
	for rows.Next() {
		var empID uuid.UUID
		if rows.Scan(&empID) != nil {
			continue
		}
		if err := s.forceCloseOpenActivityByEmployee(ctx, empID); err == nil {
			closed++
		}
	}
	return closed, nil
}

func (s *WorkforceTelegramService) purgeDailyDetailForGroup(ctx context.Context, chatID, exportDate string) error {
	chatID = strings.TrimSpace(chatID)
	exportDate = strings.TrimSpace(exportDate)
	if chatID == "" || exportDate == "" {
		return nil
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	_, err = tx.ExecContext(ctx, `
		DELETE FROM wf_tg_activity_sessions
		WHERE status = 'closed' AND attendance_date = $2::date
		  AND COALESCE(source_chat_id,'') = $1`, chatID, exportDate)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		DELETE FROM work_sessions ws
		USING employee_telegram_bindings b
		WHERE ws.employee_id = b.employee_id AND b.status = 1 AND b.chat_id = $1
		  AND ws.source = 'telegram' AND ws.status = 'closed'
		  AND ws.attendance_date = $2::date`, chatID, exportDate)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		DELETE FROM wf_tg_group_shift_state
		WHERE chat_id = $1 AND record_date <= $2::date`, chatID, exportDate)
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `
		DELETE FROM wf_tg_handover_cycles
		WHERE chat_id = $1 AND handover_date <= $2::date`, chatID, exportDate)
	if err != nil {
		return err
	}
	return tx.Commit()
}

func (s *WorkforceTelegramService) closeExpiredWorkSessionsForEmployee(ctx context.Context, empID uuid.UUID, chatID string) (int, error) {
	maxHours := telegramShiftStateMaxHours()
	cutoff := time.Now().Add(-time.Duration(maxHours) * time.Hour)
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, COALESCE(shift_type,'day'), attendance_date::text
		FROM work_sessions
		WHERE employee_id = $1 AND source IN ('telegram','agent') AND status = 'open'
		  AND checkin_time < $2`, empID, cutoff)
	if err != nil {
		return 0, err
	}
	defer rows.Close()
	closed := 0
	for rows.Next() {
		var sid uuid.UUID
		var shift, recordDate string
		if rows.Scan(&sid, &shift, &recordDate) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		checkoutAt := time.Now()
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, checkoutAt, fmt.Sprintf("班次超时自动下班（>%dh）", maxHours)); err != nil {
			log.Printf("[Telegram] expired shift close session=%s: %v", sid, err)
			continue
		}
		closed++
	}
	return closed, nil
}

func (s *WorkforceTelegramService) CloseExpiredWorkSessionsGlobal(ctx context.Context) {
	if !TelegramAttendanceEnabled() {
		return
	}
	maxHours := telegramShiftStateMaxHours()
	cutoff := time.Now().Add(-time.Duration(maxHours) * time.Hour)
	rows, err := s.db.QueryContext(ctx, `
		SELECT ws.id, ws.employee_id, COALESCE(b.chat_id,''), COALESCE(ws.shift_type,'day'), ws.attendance_date::text
		FROM work_sessions ws
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = ws.employee_id AND b.status = 1
		WHERE ws.source IN ('telegram','agent') AND ws.status = 'open' AND ws.checkin_time < $1`, cutoff)
	if err != nil {
		return
	}
	defer rows.Close()
	for rows.Next() {
		var sid, empID uuid.UUID
		var chatID, shift, recordDate string
		if rows.Scan(&sid, &empID, &chatID, &shift, &recordDate) != nil {
			continue
		}
		if shift == "night" && s.hasOpenNightContinuation(ctx, empID, recordDate) {
			continue
		}
		if err := s.forceCheckoutWorkSessionAt(ctx, sid, chatID, time.Now(), fmt.Sprintf("班次超时自动下班（>%dh）", maxHours)); err != nil {
			log.Printf("[Telegram] global expired shift close session=%s: %v", sid, err)
		}
	}
}

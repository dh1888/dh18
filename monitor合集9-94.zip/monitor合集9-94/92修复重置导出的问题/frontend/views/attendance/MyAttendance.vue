<template>
  <div class="attendance-management my-attendance-page" v-loading="loading">
    <div class="bg-decoration">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="blob blob-3"></div>
    </div>

    <div class="page-content">
      <el-card class="hero-card" shadow="never">
        <div class="hero-inner">
          <div class="hero-left">
            <div class="hero-avatar">{{ avatarLetter }}</div>
            <div>
              <h1 class="hero-title">{{ employee?.name || "我的考勤" }}</h1>
              <p class="hero-sub">
                <span v-if="employee?.employeeNumber">工号 {{ employee.employeeNumber }}</span>
                <span v-if="employee?.position"> · {{ employee.position }}</span>
                <span v-if="employee?.department"> · {{ employee.department }}</span>
              </p>
            </div>
          </div>
          <div class="hero-actions">
            <el-date-picker
              v-model="selectedMonth"
              type="month"
              placeholder="选择月份"
              format="YYYY年MM月"
              value-format="YYYY-MM"
              :clearable="false"
              class="month-picker"
              @change="loadOverview"
            />
            <el-button :loading="loading" @click="loadOverview">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
          </div>
        </div>
      </el-card>

      <el-alert
        v-if="loadError"
        type="warning"
        :closable="false"
        show-icon
        class="link-alert"
        title="无法加载个人考勤数据"
        description="当前账号未关联员工档案，请联系管理员在员工管理中绑定您的账号。"
      />

      <template v-if="!loadError">
        <el-row :gutter="16" class="stats-row">
          <el-col :xs="12" :sm="6" v-for="card in statCards" :key="card.key">
            <div class="stat-card" :class="`stat-${card.key}`">
              <div class="stat-icon-wrap" :style="{ background: card.bg }">
                <el-icon><component :is="card.icon" /></el-icon>
              </div>
              <div class="stat-body">
                <div class="stat-value">{{ card.value }}</div>
                <div class="stat-label">{{ card.label }}</div>
              </div>
            </div>
          </el-col>
        </el-row>

        <el-card class="tabs-card" shadow="never">
          <el-tabs v-model="activeTab" class="modern-tabs">
            <el-tab-pane label="考勤记录" name="attendance">
              <el-table
                :data="attendanceItems"
                stripe
                border
                empty-text="本月暂无考勤记录"
                class="modern-table"
                :header-cell-style="tableHeaderStyle"
              >
                <el-table-column prop="date" label="日期" width="120" />
                <el-table-column label="状态" width="100" align="center">
                  <template #default="{ row }">
                    <el-tag :type="statusTagType(row.status)" size="small" effect="light">
                      {{ getStatusText(row.status) }}
                    </el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="上班" min-width="140">
                  <template #default="{ row }">
                    {{ formatAttendanceClockTime(row.checkinTime) }}
                  </template>
                </el-table-column>
                <el-table-column label="下班" min-width="140">
                  <template #default="{ row }">
                    {{ formatAttendanceClockTime(row.checkoutTime) }}
                  </template>
                </el-table-column>
                <el-table-column prop="positionSnapshot" label="岗位快照" min-width="100" show-overflow-tooltip />
              </el-table>
            </el-tab-pane>

            <el-tab-pane label="绩效考核" name="performance">
              <div v-if="performance" class="performance-panel">
                <div class="performance-summary">
                  <div class="perf-score">{{ performance.totalScore ?? 0 }}</div>
                  <div class="perf-meta">
                    <el-tag :type="getGradeType(performance.grade)" size="large" effect="dark">
                      {{ performance.grade || "未评级" }}
                    </el-tag>
                    <span class="perf-month">{{ selectedMonth }} 月度绩效</span>
                  </div>
                </div>
                <el-table
                  :data="performance.scoreRecords || []"
                  stripe
                  border
                  empty-text="暂无评分明细"
                  class="modern-table"
                  :header-cell-style="tableHeaderStyle"
                >
                  <el-table-column label="日期" width="120">
                    <template #default="{ row }">{{ row.date || row.recordDate || "-" }}</template>
                  </el-table-column>
                  <el-table-column label="得分" width="90" align="center">
                    <template #default="{ row }">
                      <el-tag :type="getScoreType(Number(row.score) || 0)" size="small">
                        {{ row.score ?? "-" }}
                      </el-tag>
                    </template>
                  </el-table-column>
                  <el-table-column prop="reason" label="说明" min-width="200" show-overflow-tooltip />
                  <el-table-column label="操作人" width="120">
                    <template #default="{ row }">
                      {{ row.operatorName || row.operator || "-" }}
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <el-empty v-else description="本月暂无绩效考核记录" />
            </el-tab-pane>

            <el-tab-pane name="penalty">
              <template #label>
                罚款记录
                <el-badge
                  v-if="penaltyCount > 0"
                  :value="penaltyCount"
                  class="tab-badge"
                />
              </template>
              <el-table
                :data="penaltyItems"
                stripe
                border
                empty-text="本月暂无罚款记录"
                class="modern-table"
                :header-cell-style="tableHeaderStyle"
              >
                <el-table-column prop="penaltyDate" label="日期" width="120" />
                <el-table-column label="类别" width="130" align="center">
                  <template #default="{ row }">
                    <el-tag :type="getPenaltyCategoryType(row.category)" size="small">
                      {{ row.category }}
                    </el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="金额" width="110" align="right">
                  <template #default="{ row }">
                    <span class="amount-text">¥{{ formatMoney(row.amount) }}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="reason" label="原因" min-width="220" show-overflow-tooltip />
              </el-table>
            </el-tab-pane>

            <el-tab-pane name="activities">
              <template #label>
                活动记录
                <el-badge
                  v-if="activityCount > 0"
                  :value="activityCount"
                  class="tab-badge"
                />
              </template>
              <el-table
                :data="activityItems"
                stripe
                border
                empty-text="本月暂无活动记录"
                class="modern-table"
                :header-cell-style="tableHeaderStyle"
              >
                <el-table-column prop="attendanceDate" label="日期" width="110" />
                <el-table-column prop="activityName" label="活动" min-width="120" />
                <el-table-column label="开始" min-width="150">
                  <template #default="{ row }">{{ formatAttendanceTime(row.startedAt) }}</template>
                </el-table-column>
                <el-table-column label="结束" min-width="150">
                  <template #default="{ row }">{{ formatAttendanceTime(row.endedAt) }}</template>
                </el-table-column>
                <el-table-column label="时长" width="100" align="center">
                  <template #default="{ row }">{{ formatDurationSec(row.elapsedSeconds) }}</template>
                </el-table-column>
                <el-table-column label="超时" width="90" align="center">
                  <template #default="{ row }">
                    <span :class="{ 'overtime-text': row.overtimeSeconds > 0 }">
                      {{ row.overtimeSeconds > 0 ? formatDurationSec(row.overtimeSeconds) : "-" }}
                    </span>
                  </template>
                </el-table-column>
                <el-table-column label="罚款" width="100" align="right">
                  <template #default="{ row }">
                    <span v-if="row.fineAmount > 0" class="amount-text">¥{{ formatMoney(row.fineAmount) }}</span>
                    <span v-else>-</span>
                  </template>
                </el-table-column>
                <el-table-column label="来源" width="90" align="center">
                  <template #default="{ row }">
                    <el-tag size="small" type="info">{{ sourceLabel(row.startSource) }}</el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="状态" width="90" align="center">
                  <template #default="{ row }">
                    <el-tag :type="row.status === 'open' ? 'warning' : 'success'" size="small">
                      {{ row.status === "open" ? "进行中" : "已结束" }}
                    </el-tag>
                  </template>
                </el-table-column>
              </el-table>
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { Calendar, Refresh, TrendCharts, Warning, Timer } from "@element-plus/icons-vue";
import workforceApi from "@api/workforce_api";
import {
  formatAttendanceClockTime,
  formatAttendanceTime,
  getCurrentYearMonth,
  getGradeType,
  getPenaltyCategoryType,
  getScoreType,
  getStatusText,
} from "./helpers";
import "./attendance.css";

const loading = ref(false);
const loadError = ref(false);
const selectedMonth = ref(getCurrentYearMonth());
const activeTab = ref("attendance");

const employee = ref<any>(null);
const attendanceItems = ref<any[]>([]);
const attendanceStats = ref<any>({});
const performance = ref<any>(null);
const penaltyItems = ref<any[]>([]);
const penaltyTotal = ref(0);
const penaltyCount = ref(0);
const activityItems = ref<any[]>([]);
const activityCount = ref(0);

const tableHeaderStyle = {
  background: "#f8fafc",
  color: "#1e293b",
  fontWeight: "600",
};

const avatarLetter = computed(() => {
  const name = employee.value?.name || "?";
  return name.slice(0, 1);
});

const statCards = computed(() => [
  {
    key: "work",
    label: "出勤天数",
    value: attendanceStats.value.workDays ?? 0,
    icon: Calendar,
    bg: "linear-gradient(135deg, #667eea22, #764ba244)",
  },
  {
    key: "perf",
    label: "绩效得分",
    value: performance.value?.totalScore ?? "-",
    icon: TrendCharts,
    bg: "linear-gradient(135deg, #43e97b22, #38f9d744)",
  },
  {
    key: "penalty",
    label: "罚款合计",
    value: penaltyCount.value > 0 ? `¥${formatMoney(penaltyTotal.value)}` : "¥0",
    icon: Warning,
    bg: "linear-gradient(135deg, #fa709a22, #fee14044)",
  },
  {
    key: "activity",
    label: "活动次数",
    value: activityCount.value,
    icon: Timer,
    bg: "linear-gradient(135deg, #4facfe22, #00f2fe44)",
  },
]);

function formatMoney(v: number | string | undefined) {
  const n = Number(v) || 0;
  return n.toFixed(2);
}

function formatDurationSec(sec?: number) {
  if (!sec || sec <= 0) return "-";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (h > 0 && m > 0) return `${h}小时${m}分`;
  if (h > 0) return `${h}小时`;
  return `${m}分钟`;
}

function sourceLabel(src?: string) {
  if (src === "telegram") return "TG";
  if (src === "agent") return "PC";
  return src || "-";
}

function statusTagType(status: string) {
  const s = (status || "").toLowerCase();
  if (s === "work" || s === "working") return "success";
  if (s === "absent") return "danger";
  if (s === "leave" || s === "off_post") return "warning";
  if (s.startsWith("rest")) return "info";
  return "info";
}

async function loadOverview() {
  loading.value = true;
  loadError.value = false;
  try {
    const res = await workforceApi.getMyAttendanceOverview(selectedMonth.value);
    const data = res.data || res;
    employee.value = data.employee || null;
    attendanceItems.value = data.attendance?.items || [];
    attendanceStats.value = data.attendance?.stats || {};
    performance.value = data.performance || null;
    penaltyItems.value = data.penalties?.items || [];
    penaltyTotal.value = data.penalties?.totalAmount || 0;
    penaltyCount.value = data.penalties?.count || penaltyItems.value.length;
    activityItems.value = data.activities?.items || [];
    activityCount.value = data.activities?.count || activityItems.value.length;
  } catch (e: any) {
    const code = e?.response?.data?.code ?? e?.code;
    if (code === 2001 || e?.response?.status === 404) {
      loadError.value = true;
    }
    employee.value = null;
    attendanceItems.value = [];
    performance.value = null;
    penaltyItems.value = [];
    activityItems.value = [];
  } finally {
    loading.value = false;
  }
}

onMounted(loadOverview);
</script>

<style scoped>
.my-attendance-page.attendance-management {
  width: 100%;
  box-sizing: border-box;
}

.my-attendance-page .page-content {
  position: relative;
  z-index: 1;
  width: 100%;
  padding: 20px;
  box-sizing: border-box;
}

.modern-table {
  width: 100%;
}

.hero-card {
  border-radius: 16px;
  border: none;
  background: linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(248, 250, 252, 0.98));
  backdrop-filter: blur(12px);
  margin-bottom: 20px;
}

.hero-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  flex-wrap: wrap;
}

.hero-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.hero-avatar {
  width: 56px;
  height: 56px;
  border-radius: 16px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  font-size: 24px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 24px rgba(102, 126, 234, 0.35);
}

.hero-title {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  color: #1e293b;
}

.hero-sub {
  margin: 6px 0 0;
  color: #64748b;
  font-size: 14px;
}

.hero-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}

.stats-row {
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 18px 16px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.92);
  border: 1px solid rgba(226, 232, 240, 0.8);
  box-shadow: 0 4px 20px rgba(15, 23, 42, 0.06);
  margin-bottom: 16px;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 28px rgba(15, 23, 42, 0.1);
}

.stat-icon-wrap {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  color: #475569;
}

.stat-value {
  font-size: 22px;
  font-weight: 700;
  color: #0f172a;
  line-height: 1.2;
}

.stat-label {
  font-size: 13px;
  color: #64748b;
  margin-top: 2px;
}

.tabs-card {
  border-radius: 16px;
  border: none;
  background: rgba(255, 255, 255, 0.95);
}

.modern-tabs :deep(.el-tabs__header) {
  margin-bottom: 16px;
}

.performance-panel {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.performance-summary {
  display: flex;
  align-items: center;
  gap: 24px;
  padding: 20px 24px;
  border-radius: 14px;
  background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
  border: 1px solid #bae6fd;
}

.perf-score {
  font-size: 48px;
  font-weight: 800;
  color: #0369a1;
  line-height: 1;
}

.perf-meta {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.perf-month {
  color: #64748b;
  font-size: 14px;
}

.amount-text {
  color: #dc2626;
  font-weight: 600;
}

.overtime-text {
  color: #ea580c;
  font-weight: 600;
}

.link-alert {
  margin-bottom: 16px;
}

.tab-badge {
  margin-left: 6px;
}

@media (max-width: 768px) {
  .hero-inner {
    flex-direction: column;
    align-items: flex-start;
  }

  .perf-score {
    font-size: 36px;
  }
}
</style>

<template>
  <div class="salary-view">
    <header class="page-header">
      <div class="header-main">
        <h1 class="page-title">
          <el-icon><Money /></el-icon>
          工资单
        </h1>
        <p class="page-subtitle">查看月度工资明细与收款信息</p>
      </div>
      <div class="header-actions">
        <el-select
          v-model="selectedMonth"
          @change="loadMySalary"
          placeholder="选择月份"
          class="month-select"
        >
          <el-option
            v-for="month in availableMonths"
            :key="month"
            :label="formatMonth(month)"
            :value="month"
          />
        </el-select>
        <el-button
          v-if="mySalary"
          type="primary"
          plain
          @click="printSalary"
        >
          <el-icon><Printer /></el-icon>
          打印
        </el-button>
      </div>
    </header>

    <div v-if="loading" class="state-panel">
      <el-icon class="is-loading" :size="36"><Loading /></el-icon>
      <span>加载中...</span>
    </div>

    <div v-else class="content-grid">
      <section class="panel salary-panel">
        <template v-if="mySalary">
          <div class="summary-strip">
            <div class="summary-profile">
              <el-avatar
                :size="56"
                :style="{ backgroundColor: getAvatarColor(mySalary.employeeName) }"
              >
                {{ mySalary.employeeName?.charAt(0) }}
              </el-avatar>
              <div class="summary-info">
                <div class="summary-name">{{ mySalary.employeeName }}</div>
                <div class="summary-meta">
                  <el-tag size="small" type="primary">{{
                    mySalary.position || "员工"
                  }}</el-tag>
                  <el-tag size="small" type="info">{{
                    formatMonth(selectedMonth)
                  }}</el-tag>
                  <el-tag
                    size="small"
                    :type="mySalary.paidStatus === 'paid' ? 'success' : 'warning'"
                  >
                    {{
                      mySalary.paidStatusLabel ||
                      (mySalary.paidStatus === "paid" ? "已发" : "待发")
                    }}
                  </el-tag>
                </div>
              </div>
            </div>
            <div class="summary-total">
              <span class="summary-total-label">实发合计</span>
              <span class="summary-total-value"
                >¥{{ formatNumber(mySalary.totalSalary) }}</span
              >
            </div>
          </div>

          <!-- 动态列模式 -->
          <div v-if="dynamicCells.length" class="detail-block">
            <h3 class="block-title">工资明细</h3>
            <div class="detail-grid">
              <div
                v-for="cell in dynamicCells"
                :key="cell.header"
                class="detail-item"
                :class="{ 'is-total': cell.isTotal }"
              >
                <span class="detail-label">{{ cell.header }}</span>
                <span
                  class="detail-value"
                  :class="{ 'total-value': cell.isTotal }"
                  >{{ cell.value }}</span
                >
              </div>
            </div>
          </div>

          <!-- 固定列模式 -->
          <template v-else>
            <div class="detail-block">
              <h3 class="block-title">基本信息</h3>
              <div class="detail-grid">
                <div class="detail-item">
                  <span class="detail-label">职务</span>
                  <span class="detail-value">{{ mySalary.position || "-" }}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">入职日期-部门</span>
                  <span class="detail-value">{{
                    formatHireDateDisplay(mySalary.hireDateDept)
                  }}</span>
                </div>
                <div class="detail-item">
                  <span class="detail-label">在职月数</span>
                  <span class="detail-value"
                    >{{ mySalary.monthsEmployed || 0 }}个月</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">汇率</span>
                  <span class="detail-value">{{
                    mySalary.exchangeRate || 0
                  }}</span>
                </div>
              </div>
            </div>

            <div class="detail-block">
              <h3 class="block-title">工资构成</h3>
              <div class="detail-grid">
                <div class="detail-item">
                  <span class="detail-label">上月底薪</span>
                  <span class="detail-value"
                    >¥{{ formatNumber(mySalary.lastMonthBase) }}</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">递增总额</span>
                  <span class="detail-value"
                    >¥{{ formatNumber(mySalary.totalIncrease) }}</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">底薪(RMB)</span>
                  <span class="detail-value"
                    >¥{{ formatNumber(mySalary.baseSalary) }}</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">出勤</span>
                  <span class="detail-value"
                    >{{ mySalary.attendanceDays }}天</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">实际底薪</span>
                  <span class="detail-value"
                    >¥{{ formatNumber(mySalary.actualBaseSalary) }}</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">调勤</span>
                  <span class="detail-value"
                    >¥{{ formatNumber(mySalary.attendanceAdjustment) }}</span
                  >
                </div>
              </div>
            </div>

            <div class="detail-block">
              <h3 class="block-title">绩效与奖励</h3>
              <div class="detail-grid">
                <div class="detail-item">
                  <span class="detail-label">绩效分数</span>
                  <span class="detail-value"
                    >{{ mySalary.performanceScore || 0 }}分</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">绩效奖励B</span>
                  <span class="detail-value"
                    >¥{{ formatNumber(mySalary.performanceBonusB) }}</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">奖励</span>
                  <span class="detail-value"
                    >¥{{ formatNumber(mySalary.reward) }}</span
                  >
                </div>
              </div>
            </div>

            <div class="detail-block">
              <h3 class="block-title">扣款项目</h3>
              <div class="detail-grid">
                <div class="detail-item">
                  <span class="detail-label">罚款</span>
                  <span class="detail-value negative"
                    >-¥{{ formatNumber(mySalary.penalty) }}</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">预支15-15</span>
                  <span class="detail-value negative"
                    >-¥{{ formatNumber(mySalary.advance) }}</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">其他扣款</span>
                  <span class="detail-value negative"
                    >-¥{{ formatNumber(mySalary.otherDeduction) }}</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">保护费</span>
                  <span class="detail-value negative"
                    >-¥{{ formatNumber(mySalary.protectionFee) }}</span
                  >
                </div>
                <div class="detail-item">
                  <span class="detail-label">保护费返还</span>
                  <span class="detail-value positive"
                    >+¥{{ formatNumber(mySalary.protectionReturn) }}</span
                  >
                </div>
              </div>
            </div>

            <div v-if="mySalary.remark" class="detail-block remark-block">
              <h3 class="block-title">备注</h3>
              <p class="remark-text">{{ mySalary.remark }}</p>
            </div>
          </template>
        </template>

        <el-empty v-else description="暂无工资数据">
          <template #image>
            <el-icon :size="64" color="#c0c4cc"><Money /></el-icon>
          </template>
          <el-button type="primary" @click="loadMySalary">刷新</el-button>
        </el-empty>
      </section>

      <aside class="panel payment-panel">
        <div class="panel-head">
          <h3 class="block-title">
            <el-icon><Wallet /></el-icon>
            收款信息
          </h3>
          <el-button type="primary" size="small" @click="openPaymentDialog">
            {{ paymentAddress ? "修改" : "添加" }}
          </el-button>
        </div>

        <div v-if="paymentLoading" class="payment-loading">
          <el-icon class="is-loading"><Loading /></el-icon>
          加载中...
        </div>
        <template v-else-if="paymentAddress">
          <div
            v-if="paymentAddress.preferredMethodLabel"
            class="preferred-tip"
          >
            默认收款：{{ paymentAddress.preferredMethodLabel }}
          </div>
          <div
            v-for="acc in paymentAddress.boundAccounts || []"
            :key="acc.type"
            class="bound-section"
            :class="{ preferred: acc.isPreferred }"
          >
            <div class="bound-title">
              {{ acc.label }}
              <el-tag v-if="acc.isPreferred" size="small" type="success"
                >默认</el-tag
              >
            </div>
            <div class="payment-fields">
              <template v-if="acc.type === 'bank'">
                <div class="payment-field">
                  <span class="detail-label">收款人</span>
                  <span class="detail-value">{{
                    paymentAddress.accountHolder
                  }}</span>
                </div>
                <div class="payment-field">
                  <span class="detail-label">开户行</span>
                  <span class="detail-value">{{
                    paymentAddress.bankName
                  }}</span>
                </div>
                <div class="payment-field">
                  <span class="detail-label">银行账号</span>
                  <CopyableText
                    class="detail-value"
                    :text="paymentAddress.bankAccount"
                  />
                </div>
              </template>
              <template v-else-if="acc.type === 'usdt'">
                <div class="payment-field">
                  <span class="detail-label">网络</span>
                  <span class="detail-value">{{
                    paymentAddress.usdtNetwork
                  }}</span>
                </div>
                <div class="payment-field">
                  <span class="detail-label">USDT 地址</span>
                  <CopyableText
                    class="detail-value"
                    :text="paymentAddress.usdtAddress"
                  />
                </div>
              </template>
              <template v-else>
                <div class="payment-field">
                  <span class="detail-label">类型</span>
                  <span class="detail-value">{{
                    paymentAddress.otherWalletType
                  }}</span>
                </div>
                <div class="payment-field">
                  <span class="detail-label">地址/账号</span>
                  <CopyableText
                    class="detail-value"
                    :text="paymentAddress.otherWalletAddress"
                  />
                </div>
              </template>
            </div>
          </div>
          <div v-if="paymentAddress.remark" class="payment-field remark-field">
            <span class="detail-label">备注</span>
            <span class="detail-value">{{ paymentAddress.remark }}</span>
          </div>
          <div class="payment-field notification-field">
            <span class="detail-label">通知邮箱</span>
            <span class="detail-value">{{
              paymentAddress.notificationEmail || "未绑定"
            }}</span>
          </div>
          <div v-if="paymentAddress.updatedAt" class="payment-updated">
            最后更新：{{ formatPaymentTime(paymentAddress.updatedAt) }}
          </div>
        </template>
        <el-empty
          v-else
          description="尚未配置收款地址"
          :image-size="64"
        />
      </aside>
    </div>

    <el-dialog
      v-model="paymentDialogVisible"
      :title="paymentAddress ? '修改收款地址' : '添加收款地址'"
      width="560px"
      destroy-on-close
    >
      <el-alert
        type="warning"
        :closable="false"
        show-icon
        title="保存收款地址需输入谷歌验证码"
        style="margin-bottom: 16px"
      />
      <el-form :model="paymentForm" label-width="110px">
        <el-divider content-position="left">银行账户</el-divider>
        <el-form-item label="收款人">
          <el-input
            v-model="paymentForm.accountHolder"
            placeholder="与银行卡一致的姓名"
          />
        </el-form-item>
        <el-form-item label="开户银行">
          <el-input
            v-model="paymentForm.bankName"
            placeholder="例如：中国工商银行"
          />
        </el-form-item>
        <el-form-item label="银行账号">
          <el-input
            v-model="paymentForm.bankAccount"
            placeholder="银行卡号"
          />
        </el-form-item>

        <el-divider content-position="left">USDT 钱包</el-divider>
        <el-form-item label="网络类型">
          <el-select
            v-model="paymentForm.usdtNetwork"
            placeholder="选择网络"
            clearable
            style="width: 100%"
          >
            <el-option label="TRC20" value="TRC20" />
            <el-option label="ERC20" value="ERC20" />
            <el-option label="BEP20" value="BEP20" />
            <el-option label="其他" value="其他" />
          </el-select>
        </el-form-item>
        <el-form-item label="USDT 地址">
          <el-input
            v-model="paymentForm.usdtAddress"
            placeholder="USDT 收款地址"
          />
        </el-form-item>

        <el-divider content-position="left">其他钱包</el-divider>
        <el-form-item label="钱包类型">
          <el-input
            v-model="paymentForm.otherWalletType"
            placeholder="例如：支付宝、微信、ETH"
          />
        </el-form-item>
        <el-form-item label="钱包地址">
          <el-input
            v-model="paymentForm.otherWalletAddress"
            placeholder="账号或链上地址"
          />
        </el-form-item>

        <el-form-item label="备注">
          <el-input v-model="paymentForm.remark" type="textarea" :rows="2" />
        </el-form-item>

        <el-form-item
          v-if="availablePaymentOptions.length > 1"
          label="默认账号"
          required
        >
          <el-radio-group v-model="paymentForm.preferredMethod">
            <el-radio
              v-for="opt in availablePaymentOptions"
              :key="opt.value"
              :value="opt.value"
            >
              {{ opt.label }}
            </el-radio>
          </el-radio-group>
          <div class="form-tip">
            绑定多种收款方式时，请选择工资发放默认使用的账号
          </div>
        </el-form-item>

        <el-divider content-position="left">工资通知</el-divider>
        <el-form-item label="通知邮箱">
          <el-input
            v-model="paymentForm.notificationEmail"
            placeholder="用于接收工资发放等通知（可选）"
          />
          <div class="form-tip">保存后将用于工资已发邮件通知；未填写时尝试使用账号邮箱</div>
        </el-form-item>

        <el-divider content-position="left">安全验证</el-divider>
        <el-form-item label="谷歌验证码" required>
          <el-input
            v-model="paymentForm.totpCode"
            maxlength="6"
            placeholder="6 位验证码"
            autocomplete="one-time-code"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="paymentDialogVisible = false">取消</el-button>
        <el-button
          type="primary"
          :loading="paymentSaving"
          @click="savePaymentAddress"
        >
          保存
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { Money, Loading, Printer, Wallet } from "@element-plus/icons-vue";
import adminApi from "@api/admin_api";
import CopyableText from "@/components/CopyableText.vue";
import {
  formatHireDateDisplay,
  formatSheetDisplayCell,
  isSheetTotalHeader,
} from "@/utils/salaryColumnMapping";

const loading = ref(false);
const mySalary = ref<any>(null);
const sheetHeaders = ref<string[]>([]);
const selectedMonth = ref(getLastMonth());
const availableMonths = ref<string[]>([]);

const paymentLoading = ref(false);
const paymentAddress = ref<any>(null);
const paymentDialogVisible = ref(false);
const paymentSaving = ref(false);
const paymentForm = ref({
  accountHolder: "",
  bankName: "",
  bankAccount: "",
  usdtNetwork: "",
  usdtAddress: "",
  otherWalletType: "",
  otherWalletAddress: "",
  preferredMethod: "",
  remark: "",
  notificationEmail: "",
  totpCode: "",
});

const dynamicCells = computed(() => {
  if (!sheetHeaders.value.length || !mySalary.value?.sheetValues) return [];
  return sheetHeaders.value
    .map((header, idx) => {
      const value = formatSheetDisplayCell(
        header,
        mySalary.value.sheetValues[idx],
      );
      if (value === "-") return null;
      return {
        header,
        value,
        isTotal: isSheetTotalHeader(header),
      };
    })
    .filter(Boolean) as { header: string; value: string; isTotal: boolean }[];
});

const availablePaymentOptions = computed(() => {
  const options: { value: string; label: string }[] = [];
  const f = paymentForm.value;
  if (f.accountHolder && f.bankName && f.bankAccount) {
    options.push({ value: "bank", label: `银行卡 ${f.bankAccount}` });
  }
  if (f.usdtNetwork && f.usdtAddress) {
    options.push({
      value: "usdt",
      label: `USDT(${f.usdtNetwork}) ${f.usdtAddress.slice(0, 8)}...`,
    });
  }
  if (f.otherWalletType && f.otherWalletAddress) {
    options.push({
      value: "other",
      label: `${f.otherWalletType} ${f.otherWalletAddress.slice(0, 8)}...`,
    });
  }
  return options;
});

function getLastMonth() {
  const now = new Date();
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${lastMonth.getFullYear()}-${String(lastMonth.getMonth() + 1).padStart(2, "0")}`;
}

function formatMonth(month: string) {
  if (!month) return "-";
  const [year, m] = month.split("-");
  return `${year}年${parseInt(m)}月`;
}

function formatNumber(num: number) {
  if (num === undefined || num === null) return "0.00";
  return num.toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function getAvatarColor(name: string) {
  const colors = [
    "#667eea",
    "#764ba2",
    "#f093fb",
    "#4facfe",
    "#43e97b",
    "#fa709a",
  ];
  const index = (name?.charCodeAt(0) || 0) % colors.length;
  return colors[index];
}

async function loadAvailableMonths() {
  try {
    const response = await adminApi.getSalaryMonths();
    availableMonths.value = response.data || [];
    if (availableMonths.value.length > 0 && !selectedMonth.value) {
      selectedMonth.value = availableMonths.value[0];
    }
  } catch (error) {
    console.error("加载月份列表失败:", error);
  }
}

async function loadMySalary() {
  loading.value = true;
  try {
    const params: any = {};
    if (selectedMonth.value) params.yearMonth = selectedMonth.value;
    const response = await adminApi.getSalaryRecords(params);
    sheetHeaders.value = response.data?.sheetHeaders || [];
    const records = response.data?.items || [];
    mySalary.value = records[0] || null;
  } catch (error: any) {
    ElMessage.error(error.message || "加载工资数据失败");
    mySalary.value = null;
    sheetHeaders.value = [];
  } finally {
    loading.value = false;
  }
}

function formatPaymentTime(value: string) {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString("zh-CN", { hour12: false });
}

async function loadPaymentAddress() {
  paymentLoading.value = true;
  try {
    const response = await adminApi.getMyPaymentAddress();
    paymentAddress.value = response.data || null;
  } catch (error: any) {
    ElMessage.error(error.message || "加载收款信息失败");
    paymentAddress.value = null;
  } finally {
    paymentLoading.value = false;
  }
}

function openPaymentDialog() {
  const src = paymentAddress.value || {};
  paymentForm.value = {
    accountHolder: src.accountHolder || "",
    bankName: src.bankName || "",
    bankAccount: src.bankAccount || "",
    usdtNetwork: src.usdtNetwork || "",
    usdtAddress: src.usdtAddress || "",
    otherWalletType: src.otherWalletType || "",
    otherWalletAddress: src.otherWalletAddress || "",
    preferredMethod: src.preferredMethod || "",
    remark: src.remark || "",
    notificationEmail: src.notificationEmail || "",
    totpCode: "",
  };
  paymentDialogVisible.value = true;
}

async function savePaymentAddress() {
  if (!paymentForm.value.totpCode.trim()) {
    ElMessage.warning("请输入谷歌验证码");
    return;
  }
  if (
    availablePaymentOptions.value.length > 1 &&
    !paymentForm.value.preferredMethod
  ) {
    ElMessage.warning("请选择默认使用的收款账号");
    return;
  }
  paymentSaving.value = true;
  try {
    const response = await adminApi.upsertMyPaymentAddress({
      ...paymentForm.value,
    });
    paymentAddress.value = response.data;
    paymentDialogVisible.value = false;
    ElMessage.success("收款地址已保存");
  } catch (error: any) {
    ElMessage.error(error.message || "保存失败");
  } finally {
    paymentSaving.value = false;
  }
}

function printSalary() {
  const printContent = document
    .querySelector(".salary-panel")
    ?.cloneNode(true) as HTMLElement;
  if (!printContent) return;

  const printWindow = window.open("", "_blank");
  if (!printWindow) return;

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"><title>工资条 - ${mySalary.value?.employeeName}</title>
    <style>
      body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 32px; margin: 0; }
      .summary-strip { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 2px solid #eee; }
      .summary-name { font-size: 22px; font-weight: 700; margin-bottom: 8px; }
      .summary-total-value { font-size: 28px; font-weight: 700; color: #67c23a; }
      .detail-block { margin-bottom: 20px; }
      .block-title { font-size: 16px; margin: 0 0 12px; color: #303133; }
      .detail-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
      .detail-item { display: flex; justify-content: space-between; padding: 10px 12px; background: #f5f7fa; border-radius: 8px; }
      .detail-label { color: #909399; }
      .detail-value { font-weight: 600; }
      .negative { color: #f56c6c; }
      .positive { color: #67c23a; }
      .panel-head, .payment-panel { display: none; }
    </style>
    </head>
    <body>${printContent.innerHTML}</body>
    </html>
  `);
  printWindow.document.close();
  printWindow.print();
}

onMounted(() => {
  loadAvailableMonths();
  loadMySalary();
  loadPaymentAddress();
});
</script>

<style scoped>
.salary-view {
  margin: -20px;
  padding: 0 20px 24px;
  min-height: calc(100vh - 60px);
  box-sizing: border-box;
}

.page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  padding: 20px 0 16px;
}

.page-title {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  color: #1a1a2e;
}

.page-subtitle {
  margin: 6px 0 0;
  font-size: 13px;
  color: #909399;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.month-select {
  width: 160px;
}

.state-panel {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  min-height: 320px;
  color: #909399;
  background: #fff;
  border-radius: 16px;
  border: 1px solid #ebeef5;
}

.content-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
  width: 100%;
}

@media (min-width: 1080px) {
  .content-grid {
    grid-template-columns: minmax(0, 1fr) minmax(300px, 380px);
    align-items: start;
  }
}

.panel {
  background: #fff;
  border: 1px solid #ebeef5;
  border-radius: 16px;
  padding: 20px 22px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
}

.summary-strip {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  padding-bottom: 18px;
  margin-bottom: 18px;
  border-bottom: 1px solid #f0f2f6;
}

.summary-profile {
  display: flex;
  align-items: center;
  gap: 14px;
  min-width: 0;
}

.summary-name {
  font-size: 20px;
  font-weight: 700;
  color: #1a1a2e;
  margin-bottom: 8px;
}

.summary-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.summary-total {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 4px;
  flex-shrink: 0;
}

.summary-total-label {
  font-size: 13px;
  color: #909399;
}

.summary-total-value {
  font-size: 28px;
  font-weight: 700;
  color: #67c23a;
  line-height: 1.2;
}

.detail-block + .detail-block {
  margin-top: 18px;
}

.block-title {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 0 12px;
  font-size: 15px;
  font-weight: 600;
  color: #303133;
}

.detail-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 10px;
}

@media (min-width: 1400px) {
  .detail-grid {
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  }
}

.detail-item {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 12px 14px;
  background: #f8fafc;
  border-radius: 10px;
  border: 1px solid transparent;
  transition: border-color 0.2s, box-shadow 0.2s;
}

.detail-item:hover {
  border-color: #e4e7ed;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}

.detail-item.is-total {
  background: linear-gradient(135deg, #f0f9eb, #ecf5ff);
  border-color: #c2e7b0;
}

.detail-label {
  font-size: 12px;
  color: #909399;
  line-height: 1.4;
}

.detail-value {
  font-size: 15px;
  font-weight: 600;
  color: #303133;
  word-break: break-word;
}

.detail-value.total-value {
  font-size: 18px;
  color: #67c23a;
}

.detail-value.negative {
  color: #f56c6c;
}

.detail-value.positive {
  color: #67c23a;
}

.remark-block .remark-text {
  margin: 0;
  padding: 12px 14px;
  background: #f8fafc;
  border-radius: 10px;
  color: #606266;
  line-height: 1.6;
}

.panel-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 16px;
}

.payment-panel .block-title {
  margin: 0;
}

.payment-loading {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #909399;
  padding: 16px 0;
}

.preferred-tip {
  margin-bottom: 14px;
  padding: 10px 12px;
  background: #f0f9eb;
  border-radius: 8px;
  color: #67c23a;
  font-size: 13px;
}

.bound-section {
  margin-bottom: 12px;
  padding: 12px;
  border: 1px solid #ebeef5;
  border-radius: 10px;
}

.bound-section.preferred {
  border-color: #b3e19d;
  background: #fafdf8;
}

.bound-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
  font-size: 14px;
  font-weight: 600;
  color: #303133;
}

.payment-fields {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.payment-field {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  padding: 8px 0;
  border-bottom: 1px dashed #f0f2f6;
}

.payment-field:last-child {
  border-bottom: none;
}

.payment-field .detail-value {
  text-align: right;
  max-width: 58%;
}

.remark-field {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid #f0f2f6;
}

.payment-updated {
  margin-top: 12px;
  font-size: 12px;
  color: #909399;
}

.form-tip {
  margin-top: 6px;
  font-size: 12px;
  color: #909399;
  line-height: 1.5;
}

@media (max-width: 768px) {
  .salary-view {
    margin: -14px;
    padding: 0 14px 20px;
  }

  .page-header {
    flex-direction: column;
    padding-top: 14px;
  }

  .header-actions {
    width: 100%;
  }

  .month-select {
    flex: 1;
    min-width: 0;
  }

  .summary-strip {
    flex-direction: column;
    align-items: stretch;
  }

  .summary-total {
    align-items: flex-start;
    padding-top: 12px;
    border-top: 1px dashed #ebeef5;
  }

  .detail-grid {
    grid-template-columns: 1fr;
  }

  .payment-field {
    flex-direction: column;
    gap: 4px;
  }

  .payment-field .detail-value {
    max-width: 100%;
    text-align: left;
  }
}
</style>

package models

import (
	"encoding/json"
	"strings"
	"time"

	"github.com/google/uuid"
)

const (
	PermDiagnosticView   = "diagnostic:view"
	PermDiagnosticManage = "diagnostic:manage"
	PermDiagnosticExport = "diagnostic:export"
)

type DiagnosticLevel string

const (
	DiagnosticLevelOff   DiagnosticLevel = "OFF"
	DiagnosticLevelError DiagnosticLevel = "ERROR"
	DiagnosticLevelWarn  DiagnosticLevel = "WARN"
	DiagnosticLevelInfo  DiagnosticLevel = "INFO"
	DiagnosticLevelDebug DiagnosticLevel = "DEBUG"
	DiagnosticLevelTrace DiagnosticLevel = "TRACE"
)

var DiagnosticModules = []string{
	"RemoteView",
	"Recording",
	"Upload",
	"WebSocket",
	"LiveKit",
	"FFmpeg",
	"Policy",
	"Capture",
	"Lifecycle",
	"Health",
	"Backend",
}

type DiagnosticCenterConfig struct {
	Enabled               bool                       `json:"enabled"`
	ExpiresAt             *time.Time                 `json:"expiresAt,omitempty"`
	GlobalLevel           DiagnosticLevel            `json:"globalLevel"`
	ModuleLevels          map[string]DiagnosticLevel `json:"moduleLevels"`
	AgentUploadEnabled    bool                       `json:"agentUploadEnabled"`
	FrontendUploadEnabled bool                       `json:"frontendUploadEnabled"`
	RetentionHours        int                        `json:"retentionHours"`
	AppliedTemplateID     string                     `json:"appliedTemplateId,omitempty"`
	UpdatedAt             time.Time                  `json:"updatedAt"`
	UpdatedBy             string                     `json:"updatedBy,omitempty"`
}

type DiagnosticRuntimeConfig struct {
	Active                bool                       `json:"active"`
	ExpiresAt             *time.Time                 `json:"expiresAt,omitempty"`
	GlobalLevel           DiagnosticLevel            `json:"globalLevel"`
	ModuleLevels          map[string]DiagnosticLevel `json:"moduleLevels"`
	AgentUploadEnabled    bool                       `json:"agentUploadEnabled"`
	FrontendUploadEnabled bool                       `json:"frontendUploadEnabled"`
}

type DiagnosticEvent struct {
	ID            uuid.UUID       `json:"id"`
	Source        string          `json:"source"`
	DeviceID      *uuid.UUID      `json:"deviceId,omitempty"`
	Module        string          `json:"module"`
	Level         DiagnosticLevel `json:"level"`
	Message       string          `json:"message"`
	Context       json.RawMessage `json:"context,omitempty"`
	CorrelationID string          `json:"correlationId,omitempty"`
	CreatedAt     time.Time       `json:"createdAt"`
}

func DefaultDiagnosticCenterConfig() DiagnosticCenterConfig {
	levels := make(map[string]DiagnosticLevel, len(DiagnosticModules))
	for _, module := range DiagnosticModules {
		levels[module] = DiagnosticLevelOff
	}
	return DiagnosticCenterConfig{
		Enabled:               false,
		GlobalLevel:           DiagnosticLevelOff,
		ModuleLevels:          levels,
		AgentUploadEnabled:    true,
		FrontendUploadEnabled: true,
		RetentionHours:        72,
		UpdatedAt:             UTCNow(),
	}
}

func NormalizeDiagnosticLevel(raw string) DiagnosticLevel {
	switch strings.ToUpper(strings.TrimSpace(raw)) {
	case string(DiagnosticLevelError):
		return DiagnosticLevelError
	case string(DiagnosticLevelWarn):
		return DiagnosticLevelWarn
	case string(DiagnosticLevelInfo):
		return DiagnosticLevelInfo
	case string(DiagnosticLevelDebug):
		return DiagnosticLevelDebug
	case string(DiagnosticLevelTrace):
		return DiagnosticLevelTrace
	default:
		return DiagnosticLevelOff
	}
}

func DiagnosticLevelRank(level DiagnosticLevel) int {
	switch NormalizeDiagnosticLevel(string(level)) {
	case DiagnosticLevelTrace:
		return 5
	case DiagnosticLevelDebug:
		return 4
	case DiagnosticLevelInfo:
		return 3
	case DiagnosticLevelWarn:
		return 2
	case DiagnosticLevelError:
		return 1
	default:
		return 0
	}
}

func (c DiagnosticCenterConfig) Effective(now time.Time) DiagnosticRuntimeConfig {
	runtime := DiagnosticRuntimeConfig{
		Active:                false,
		GlobalLevel:           DiagnosticLevelOff,
		ModuleLevels:          map[string]DiagnosticLevel{},
		AgentUploadEnabled:    c.AgentUploadEnabled,
		FrontendUploadEnabled: c.FrontendUploadEnabled,
	}
	if !c.Enabled {
		return runtime
	}
	if c.ExpiresAt != nil && !c.ExpiresAt.After(now) {
		return runtime
	}
	runtime.Active = true
	runtime.ExpiresAt = c.ExpiresAt
	runtime.GlobalLevel = NormalizeDiagnosticLevel(string(c.GlobalLevel))
	for _, module := range DiagnosticModules {
		level := runtime.GlobalLevel
		if c.ModuleLevels != nil {
			if moduleLevel, ok := c.ModuleLevels[module]; ok {
				level = NormalizeDiagnosticLevel(string(moduleLevel))
			}
		}
		runtime.ModuleLevels[module] = level
	}
	return runtime
}

func (r DiagnosticRuntimeConfig) Allows(module string, level DiagnosticLevel) bool {
	if !r.Active {
		return false
	}
	moduleLevel := r.GlobalLevel
	if r.ModuleLevels != nil {
		if v, ok := r.ModuleLevels[module]; ok {
			moduleLevel = v
		}
	}
	if moduleLevel == DiagnosticLevelOff {
		return false
	}
	return DiagnosticLevelRank(level) <= DiagnosticLevelRank(moduleLevel)
}

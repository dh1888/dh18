package handlers

import (
	"context"

	"github.com/google/uuid"
)

func (h *AdminHandler) notifySalaryPaid(
	ctx context.Context,
	employeeUUID, yearMonth, employeeName string,
	totalSalary float64,
) {
	if employeeUUID == "" {
		return
	}
	_ = CreateSalaryPaidNotification(ctx, h.db, employeeUUID, yearMonth, employeeName, totalSalary)
	if h.agentNotify != nil {
		if empID, err := uuid.Parse(employeeUUID); err == nil {
			h.agentNotify.PushSalaryPaid(ctx, empID, yearMonth, employeeName, totalSalary)
		}
	}
	if h.mail != nil {
		h.mail.SendSalaryPaidNotification(ctx, h.db, employeeUUID, yearMonth, employeeName, totalSalary)
	}
}

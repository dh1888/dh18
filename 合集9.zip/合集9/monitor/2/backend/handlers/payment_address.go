package handlers

import (
	"database/sql"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"enterprise-agent/backend/models"
)

const (
	paymentMethodBank  = "bank"
	paymentMethodUsdt  = "usdt"
	paymentMethodOther = "other"
)

var (
	errTotpRequired     = errors.New("totp required")
	errInvalidUser      = errors.New("invalid user")
	errTotpNotBound     = errors.New("totp not bound")
	errInvalidTotpCode  = errors.New("invalid totp code")
	errEmployeeNotFound = errors.New("employee not found")
)

type paymentAddressPayload struct {
	AccountHolder      string `json:"accountHolder"`
	BankName           string `json:"bankName"`
	BankAccount        string `json:"bankAccount"`
	UsdtNetwork        string `json:"usdtNetwork"`
	UsdtAddress        string `json:"usdtAddress"`
	OtherWalletType    string `json:"otherWalletType"`
	OtherWalletAddress string `json:"otherWalletAddress"`
	PreferredMethod    string `json:"preferredMethod"`
	Remark             string `json:"remark"`
	NotificationEmail  string `json:"notificationEmail"`
	TotpCode           string `json:"totpCode"`
}

const attendancePositionExpr = `
	COALESCE(
		NULLIF(TRIM(e.position), ''),
		NULLIF((
			SELECT ar.position_snapshot
			FROM attendance_records ar
			WHERE ar.employee_id = e.id
			  AND NULLIF(TRIM(ar.position_snapshot), '') IS NOT NULL
			ORDER BY ar.year_month DESC, ar.date DESC
			LIMIT 1
		), ''),
		''
	)`

const attendanceDepartmentExpr = `
	COALESCE(NULLIF(TRIM(e.department), ''), NULLIF(TRIM(e.work_location), ''), '')`

func lastCalendarMonth(now time.Time) string {
	return now.AddDate(0, -1, 0).Format("2006-01")
}

func monthLabelFromYearMonth(yearMonth string) string {
	parts := strings.Split(yearMonth, "-")
	if len(parts) != 2 {
		return yearMonth
	}
	m, err := strconv.Atoi(parts[1])
	if err != nil {
		return yearMonth
	}
	return fmt.Sprintf("%d月", m)
}

func resolveSalaryMonthStatus(hasRecord bool, paidStatus, yearMonth string, now time.Time) (status, label string) {
	if hasRecord {
		if paidStatus == "paid" {
			return "paid", "已发"
		}
		return "pending", "待发"
	}
	parts := strings.Split(yearMonth, "-")
	if len(parts) != 2 {
		return "none", "-"
	}
	month, err := strconv.Atoi(parts[1])
	if err != nil {
		return "none", "-"
	}
	year, err := strconv.Atoi(parts[0])
	if err != nil {
		return "none", "-"
	}
	target := time.Date(year, time.Month(month), 1, 0, 0, 0, 0, now.Location())
	current := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, now.Location())
	if !target.Before(current) {
		return "none", "未出"
	}
	return "pending", "待发"
}

func (h *AdminHandler) resolveEmployeeIDForCurrentUser(c *gin.Context) (string, error) {
	userID := strings.TrimSpace(c.GetString("userID"))
	if userID != "" {
		var empID string
		err := h.db.QueryRowContext(c.Request.Context(), `
			SELECT id::text FROM employees WHERE user_id = $1 AND status = 1
		`, userID).Scan(&empID)
		if err == nil {
			return empID, nil
		}
		if err != sql.ErrNoRows {
			return "", err
		}
	}

	username := strings.TrimSpace(c.GetString("username"))
	if username == "" {
		return "", errEmployeeNotFound
	}
	var empID string
	err := h.db.QueryRowContext(c.Request.Context(), `
		SELECT id::text FROM employees WHERE name = $1 AND status = 1
	`, username).Scan(&empID)
	if err == sql.ErrNoRows {
		return "", errEmployeeNotFound
	}
	if err != nil {
		return "", err
	}
	return empID, nil
}

func sendTotpVerifyError(c *gin.Context, err error) bool {
	if err == nil {
		return false
	}
	switch {
	case errors.Is(err, errTotpRequired):
		models.SendError(c, 400, 1001, "请输入谷歌验证码")
	case errors.Is(err, errTotpNotBound):
		models.SendError(c, 400, 1001, "请先绑定谷歌验证器后再修改收款地址")
	case errors.Is(err, errInvalidTotpCode):
		models.SendError(c, 401, 1002, "谷歌验证码错误")
	case errors.Is(err, errInvalidUser):
		models.SendError(c, 401, 1002, "用户无效")
	default:
		models.SendError(c, 500, 5000, err.Error())
	}
	return true
}

func hasCompleteBank(p paymentAddressPayload) bool {
	return p.AccountHolder != "" && p.BankName != "" && p.BankAccount != ""
}

func hasCompleteUsdt(p paymentAddressPayload) bool {
	return p.UsdtAddress != "" && p.UsdtNetwork != ""
}

func hasCompleteOther(p paymentAddressPayload) bool {
	return p.OtherWalletAddress != "" && p.OtherWalletType != ""
}

func availablePaymentMethods(p paymentAddressPayload) []string {
	methods := make([]string, 0, 3)
	if hasCompleteBank(p) {
		methods = append(methods, paymentMethodBank)
	}
	if hasCompleteUsdt(p) {
		methods = append(methods, paymentMethodUsdt)
	}
	if hasCompleteOther(p) {
		methods = append(methods, paymentMethodOther)
	}
	return methods
}

func normalizePaymentPayload(req *paymentAddressPayload) {
	req.AccountHolder = strings.TrimSpace(req.AccountHolder)
	req.BankName = strings.TrimSpace(req.BankName)
	req.BankAccount = strings.TrimSpace(req.BankAccount)
	req.UsdtNetwork = strings.TrimSpace(req.UsdtNetwork)
	req.UsdtAddress = strings.TrimSpace(req.UsdtAddress)
	req.OtherWalletType = strings.TrimSpace(req.OtherWalletType)
	req.OtherWalletAddress = strings.TrimSpace(req.OtherWalletAddress)
	req.PreferredMethod = strings.TrimSpace(req.PreferredMethod)
	req.Remark = strings.TrimSpace(req.Remark)
	req.NotificationEmail = strings.ToLower(strings.TrimSpace(req.NotificationEmail))
}

func validateNotificationEmail(email string) error {
	if email == "" {
		return nil
	}
	if len(email) > 255 || !strings.Contains(email, "@") || strings.HasPrefix(email, "@") || strings.HasSuffix(email, "@") {
		return fmt.Errorf("通知邮箱格式无效")
	}
	return nil
}

func validatePaymentPayload(req paymentAddressPayload) (string, error) {
	hasPartialBank := req.AccountHolder != "" || req.BankName != "" || req.BankAccount != ""
	hasPartialUsdt := req.UsdtAddress != "" || req.UsdtNetwork != ""
	hasPartialOther := req.OtherWalletAddress != "" || req.OtherWalletType != ""

	methods := availablePaymentMethods(req)
	if len(methods) == 0 {
		return "", fmt.Errorf("请至少完整填写一项收款信息")
	}
	if hasPartialBank && !hasCompleteBank(req) {
		return "", fmt.Errorf("银行账户需填写收款人、开户行和账号")
	}
	if hasPartialUsdt && !hasCompleteUsdt(req) {
		return "", fmt.Errorf("USDT 需填写网络类型和地址")
	}
	if hasPartialOther && !hasCompleteOther(req) {
		return "", fmt.Errorf("其他钱包需填写类型和地址/账号")
	}

	preferred := req.PreferredMethod
	if len(methods) == 1 {
		return methods[0], nil
	}
	if preferred == "" {
		return "", fmt.Errorf("绑定多种收款方式时，请选择默认使用的账号")
	}
	for _, method := range methods {
		if method == preferred {
			return preferred, nil
		}
	}
	return "", fmt.Errorf("所选默认收款方式无效")
}

func paymentMethodLabel(method string) string {
	switch method {
	case paymentMethodBank:
		return "银行卡"
	case paymentMethodUsdt:
		return "USDT"
	case paymentMethodOther:
		return "其他钱包"
	default:
		return method
	}
}

func buildBoundAccounts(
	accountHolder, bankName, bankAccount, usdtNetwork, usdtAddress,
	otherWalletType, otherWalletAddress, preferredMethod string,
) []map[string]interface{} {
	accounts := make([]map[string]interface{}, 0, 3)
	if bankAccount != "" && bankName != "" && accountHolder != "" {
		accounts = append(accounts, map[string]interface{}{
			"type":        paymentMethodBank,
			"label":       "银行卡",
			"display":     bankAccount,
			"detail":      fmt.Sprintf("%s · %s", bankName, accountHolder),
			"isPreferred": preferredMethod == paymentMethodBank,
		})
	}
	if usdtAddress != "" {
		label := "USDT"
		if usdtNetwork != "" {
			label = fmt.Sprintf("USDT(%s)", usdtNetwork)
		}
		accounts = append(accounts, map[string]interface{}{
			"type":        paymentMethodUsdt,
			"label":       label,
			"display":     usdtAddress,
			"detail":      usdtNetwork,
			"isPreferred": preferredMethod == paymentMethodUsdt,
		})
	}
	if otherWalletAddress != "" {
		label := otherWalletType
		if label == "" {
			label = "其他钱包"
		}
		accounts = append(accounts, map[string]interface{}{
			"type":        paymentMethodOther,
			"label":       label,
			"display":     otherWalletAddress,
			"detail":      otherWalletType,
			"isPreferred": preferredMethod == paymentMethodOther,
		})
	}
	return accounts
}

func paymentAddressRowToMap(
	id, employeeID, accountHolder, bankName, bankAccount, usdtNetwork, usdtAddress,
	otherWalletType, otherWalletAddress, preferredMethod, remark, notificationEmail string,
	createdAt, updatedAt time.Time,
) map[string]interface{} {
	item := map[string]interface{}{
		"id":                 id,
		"employeeId":         employeeID,
		"accountHolder":      accountHolder,
		"bankName":           bankName,
		"bankAccount":        bankAccount,
		"usdtNetwork":        usdtNetwork,
		"usdtAddress":        usdtAddress,
		"otherWalletType":    otherWalletType,
		"otherWalletAddress": otherWalletAddress,
		"preferredMethod":    preferredMethod,
		"preferredMethodLabel": paymentMethodLabel(preferredMethod),
		"remark":             remark,
		"notificationEmail":  notificationEmail,
		"createdAt":          models.FormatUTC(createdAt),
		"updatedAt":          models.FormatUTC(updatedAt),
	}
	item["boundAccounts"] = buildBoundAccounts(
		accountHolder, bankName, bankAccount, usdtNetwork, usdtAddress,
		otherWalletType, otherWalletAddress, preferredMethod,
	)
	return item
}

func scanPaymentAddress(scanner interface {
	Scan(dest ...interface{}) error
}) (map[string]interface{}, error) {
	var id, employeeID, accountHolder, bankName, bankAccount, usdtNetwork, usdtAddress string
	var otherWalletType, otherWalletAddress, preferredMethod, remark, notificationEmail string
	var createdAt, updatedAt time.Time
	err := scanner.Scan(
		&id, &employeeID, &accountHolder, &bankName, &bankAccount,
		&usdtNetwork, &usdtAddress, &otherWalletType, &otherWalletAddress,
		&preferredMethod, &remark, &notificationEmail, &createdAt, &updatedAt,
	)
	if err != nil {
		return nil, err
	}
	return paymentAddressRowToMap(
		id, employeeID, accountHolder, bankName, bankAccount, usdtNetwork, usdtAddress,
		otherWalletType, otherWalletAddress, preferredMethod, remark, notificationEmail, createdAt, updatedAt,
	), nil
}

const paymentAddressSelectCols = `
	pa.id::text, pa.employee_id::text, pa.account_holder, pa.bank_name, pa.bank_account,
	pa.usdt_network, pa.usdt_address, pa.other_wallet_type, pa.other_wallet_address,
	COALESCE(pa.preferred_method, ''), pa.remark, COALESCE(pa.notification_email, ''), pa.created_at, pa.updated_at`

// GetMyPaymentAddress returns the current user's payment address.
func (h *AdminHandler) GetMyPaymentAddress(c *gin.Context) {
	employeeID, err := h.resolveEmployeeIDForCurrentUser(c)
	if err != nil {
		if errors.Is(err, errEmployeeNotFound) {
			models.SendError(c, 404, 2001, "未找到员工信息")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	row := h.db.QueryRowContext(c.Request.Context(), fmt.Sprintf(`
		SELECT %s FROM employee_payment_accounts pa WHERE pa.employee_id = $1
	`, paymentAddressSelectCols), employeeID)

	item, err := scanPaymentAddress(row)
	if err == sql.ErrNoRows {
		models.Send(c, 200, 0, "success", nil)
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", item)
}

// UpsertMyPaymentAddress creates or updates the current user's payment address (TOTP required).
func (h *AdminHandler) UpsertMyPaymentAddress(c *gin.Context) {
	var req paymentAddressPayload
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	normalizePaymentPayload(&req)
	preferredMethod, err := validatePaymentPayload(req)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if err := validateNotificationEmail(req.NotificationEmail); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if sendTotpVerifyError(c, VerifyCurrentUserTotp(c, h.db, req.TotpCode)) {
		return
	}

	employeeID, err := h.resolveEmployeeIDForCurrentUser(c)
	if err != nil {
		if errors.Is(err, errEmployeeNotFound) {
			models.SendError(c, 404, 2001, "未找到员工信息")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	var existingID string
	err = h.db.QueryRowContext(c.Request.Context(), `
		SELECT id::text FROM employee_payment_accounts WHERE employee_id = $1
	`, employeeID).Scan(&existingID)
	isUpdate := err == nil
	if err != nil && err != sql.ErrNoRows {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	var resultID string
	if isUpdate {
		resultID = existingID
		_, err = h.db.ExecContext(c.Request.Context(), `
			UPDATE employee_payment_accounts SET
				account_holder = $1, bank_name = $2, bank_account = $3,
				usdt_network = $4, usdt_address = $5,
				other_wallet_type = $6, other_wallet_address = $7,
				preferred_method = $8, remark = $9, notification_email = $10, updated_at = NOW()
			WHERE employee_id = $11
		`, req.AccountHolder, req.BankName, req.BankAccount,
			req.UsdtNetwork, req.UsdtAddress,
			req.OtherWalletType, req.OtherWalletAddress,
			preferredMethod, req.Remark, req.NotificationEmail, employeeID)
	} else {
		resultID = uuid.NewString()
		_, err = h.db.ExecContext(c.Request.Context(), `
			INSERT INTO employee_payment_accounts (
				id, employee_id, account_holder, bank_name, bank_account,
				usdt_network, usdt_address, other_wallet_type, other_wallet_address,
				preferred_method, remark, notification_email
			) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
		`, resultID, employeeID,
			req.AccountHolder, req.BankName, req.BankAccount,
			req.UsdtNetwork, req.UsdtAddress,
			req.OtherWalletType, req.OtherWalletAddress,
			preferredMethod, req.Remark, req.NotificationEmail)
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	var employeeName string
	_ = h.db.QueryRowContext(c.Request.Context(), `SELECT name FROM employees WHERE id = $1`, employeeID).Scan(&employeeName)

	opType := models.OperationTypeCreate
	if isUpdate {
		opType = models.OperationTypeUpdate
	}
	Log(c, opType, models.OperationModuleSalary,
		fmt.Sprintf("%s收款地址：%s", map[bool]string{true: "修改", false: "新增"}[isUpdate], employeeName),
		resultID, employeeName)

	row := h.db.QueryRowContext(c.Request.Context(), fmt.Sprintf(`
		SELECT %s FROM employee_payment_accounts pa WHERE pa.employee_id = $1
	`, paymentAddressSelectCols), employeeID)
	item, err := scanPaymentAddress(row)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	models.Send(c, 200, 0, "success", item)
}

// ListPaymentAddresses lists all employee payment addresses (admin only).
func (h *AdminHandler) ListPaymentAddresses(c *gin.Context) {
	skip, _ := strconv.Atoi(c.DefaultQuery("skip", "0"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "50"))
	if limit <= 0 {
		limit = 50
	}
	if limit > 500 {
		limit = 500
	}
	search := strings.TrimSpace(c.Query("search"))
	now := time.Now()
	lastMonth := lastCalendarMonth(now)

	where := "e.status = 1 AND pa.id IS NOT NULL"
	countArgs := []interface{}{}
	listArgs := []interface{}{lastMonth}
	argIdx := 2

	if search != "" {
		where += fmt.Sprintf(` AND (
			e.name ILIKE $%d OR e.employee_id ILIKE $%d
			OR e.department ILIKE $%d OR e.work_location ILIKE $%d
			OR e.position ILIKE $%d
			OR pa.account_holder ILIKE $%d OR pa.bank_account ILIKE $%d
			OR pa.usdt_address ILIKE $%d OR pa.other_wallet_address ILIKE $%d
			OR pa.notification_email ILIKE $%d
		)`, argIdx, argIdx, argIdx, argIdx, argIdx, argIdx, argIdx, argIdx, argIdx, argIdx)
		pattern := "%" + search + "%"
		countArgs = append(countArgs, pattern)
		listArgs = append(listArgs, pattern)
		argIdx++
	}

	countQuery := fmt.Sprintf(`
		SELECT COUNT(*)
		FROM employees e
		INNER JOIN employee_payment_accounts pa ON pa.employee_id = e.id
		WHERE %s
	`, where)
	var total int
	if err := h.db.QueryRowContext(c.Request.Context(), countQuery, countArgs...).Scan(&total); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	listQuery := fmt.Sprintf(`
		SELECT e.id::text, e.employee_id, e.name,
		       %s AS department,
		       %s AS position,
		       pa.id::text,
		       COALESCE(pa.account_holder, ''), COALESCE(pa.bank_name, ''),
		       COALESCE(pa.bank_account, ''), COALESCE(pa.usdt_network, ''), COALESCE(pa.usdt_address, ''),
		       COALESCE(pa.other_wallet_type, ''), COALESCE(pa.other_wallet_address, ''),
		       COALESCE(pa.preferred_method, ''), COALESCE(pa.remark, ''), COALESCE(pa.notification_email, ''), pa.updated_at,
		       sr_last.id::text, sr_last.total_salary, COALESCE(sr_last.paid_status, 'pending'),
		       spp.id::text, spp.file_name, spp.uploaded_at
		FROM employees e
		INNER JOIN employee_payment_accounts pa ON pa.employee_id = e.id
		LEFT JOIN salary_records sr_last ON sr_last.employee_id = e.id::text AND sr_last.year_month = $1
		LEFT JOIN salary_payment_proofs spp ON spp.employee_id = e.id AND spp.year_month = $1
		WHERE %s
		ORDER BY pa.updated_at DESC NULLS LAST, e.name ASC
		OFFSET $%d LIMIT $%d
	`, attendanceDepartmentExpr, attendancePositionExpr, where, argIdx, argIdx+1)
	listArgs = append(listArgs, skip, limit)

	rows, err := h.db.QueryContext(c.Request.Context(), listQuery, listArgs...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	items := make([]map[string]interface{}, 0)
	for rows.Next() {
		var empUUID, empCode, empName, department, position string
		var paID string
		var accountHolder, bankName, bankAccount, usdtNetwork, usdtAddress string
		var otherWalletType, otherWalletAddress, preferredMethod, remark, notificationEmail string
		var updatedAt sql.NullTime
		var lastMonthSalaryID sql.NullString
		var lastMonthSalary sql.NullFloat64
		var lastMonthPaidStatus sql.NullString
		var paymentProofID sql.NullString
		var paymentProofFileName sql.NullString
		var paymentProofUploadedAt sql.NullTime
		if err := rows.Scan(
			&empUUID, &empCode, &empName, &department, &position,
			&paID, &accountHolder, &bankName, &bankAccount, &usdtNetwork, &usdtAddress,
			&otherWalletType, &otherWalletAddress, &preferredMethod, &remark, &notificationEmail, &updatedAt,
			&lastMonthSalaryID, &lastMonthSalary, &lastMonthPaidStatus,
			&paymentProofID, &paymentProofFileName, &paymentProofUploadedAt,
		); err != nil {
			continue
		}
		hasSalaryRecord := lastMonthSalaryID.Valid
		paidStatus := "pending"
		if lastMonthPaidStatus.Valid {
			paidStatus = lastMonthPaidStatus.String
		}
		salaryStatus, salaryStatusLabel := resolveSalaryMonthStatus(hasSalaryRecord, paidStatus, lastMonth, now)
		var lastMonthAmount interface{}
		if lastMonthSalary.Valid {
			lastMonthAmount = lastMonthSalary.Float64
		}
		boundAccounts := buildBoundAccounts(
			accountHolder, bankName, bankAccount, usdtNetwork, usdtAddress,
			otherWalletType, otherWalletAddress, preferredMethod,
		)
		item := map[string]interface{}{
			"employeeUuid":         empUUID,
			"employeeCode":         empCode,
			"employeeName":         empName,
			"department":           department,
			"position":             position,
			"accountHolder":        accountHolder,
			"bankName":             bankName,
			"bankAccount":          bankAccount,
			"usdtNetwork":          usdtNetwork,
			"usdtAddress":          usdtAddress,
			"otherWalletType":      otherWalletType,
			"otherWalletAddress":   otherWalletAddress,
			"preferredMethod":      preferredMethod,
			"preferredMethodLabel": paymentMethodLabel(preferredMethod),
			"boundAccounts":        boundAccounts,
			"remark":               remark,
			"notificationEmail":    notificationEmail,
			"lastMonthYearMonth":   lastMonth,
			"lastMonthLabel":       monthLabelFromYearMonth(lastMonth),
			"lastMonthSalaryId":    nil,
			"lastMonthAmount":      lastMonthAmount,
			"lastMonthStatus":      salaryStatus,
			"lastMonthStatusLabel": salaryStatusLabel,
		}
		if lastMonthSalaryID.Valid {
			item["lastMonthSalaryId"] = lastMonthSalaryID.String
		}
		if paymentProofID.Valid {
			item["paymentProofId"] = paymentProofID.String
			item["paymentProofFileName"] = paymentProofFileName.String
			if paymentProofUploadedAt.Valid {
				item["paymentProofUploadedAt"] = models.FormatUTC(paymentProofUploadedAt.Time)
			}
		}
		if updatedAt.Valid {
			item["updatedAt"] = models.FormatUTC(updatedAt.Time)
		}
		items = append(items, item)
	}

	models.Send(c, 200, 0, "success", map[string]interface{}{
		"items": items,
		"total": total,
	})
}

// GetPaymentAddressSalaryYear returns monthly salary summary for an employee (admin).
func (h *AdminHandler) GetPaymentAddressSalaryYear(c *gin.Context) {
	employeeUUID := strings.TrimSpace(c.Param("employeeUuid"))
	if _, err := uuid.Parse(employeeUUID); err != nil {
		models.SendError(c, 400, 1001, "Invalid employee ID")
		return
	}

	yearStr := strings.TrimSpace(c.DefaultQuery("year", strconv.Itoa(time.Now().Year())))
	year, err := strconv.Atoi(yearStr)
	if err != nil || year < 2000 || year > 2100 {
		models.SendError(c, 400, 1001, "Invalid year")
		return
	}

	var exists bool
	if err := h.db.QueryRowContext(c.Request.Context(), `
		SELECT EXISTS(SELECT 1 FROM employees WHERE id = $1 AND status = 1)
	`, employeeUUID).Scan(&exists); err != nil || !exists {
		models.SendError(c, 404, 2001, "员工不存在")
		return
	}

	rows, err := h.db.QueryContext(c.Request.Context(), `
		SELECT year_month, total_salary, COALESCE(paid_status, 'pending')
		FROM salary_records
		WHERE employee_id = $1 AND year_month LIKE $2
		ORDER BY year_month ASC
	`, employeeUUID, fmt.Sprintf("%d-%%", year))
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	recordMap := make(map[string]float64)
	paidMap := make(map[string]string)
	for rows.Next() {
		var yearMonth, paidStatus string
		var totalSalary float64
		if err := rows.Scan(&yearMonth, &totalSalary, &paidStatus); err != nil {
			continue
		}
		recordMap[yearMonth] = totalSalary
		paidMap[yearMonth] = paidStatus
	}

	now := time.Now()
	months := make([]map[string]interface{}, 0, 12)
	for m := 1; m <= 12; m++ {
		yearMonth := fmt.Sprintf("%d-%02d", year, m)
		totalSalary, hasRecord := recordMap[yearMonth]
		paidStatus := paidMap[yearMonth]
		status, statusLabel := resolveSalaryMonthStatus(hasRecord, paidStatus, yearMonth, now)
		item := map[string]interface{}{
			"month":       m,
			"yearMonth":   yearMonth,
			"monthLabel":  fmt.Sprintf("%d月", m),
			"status":      status,
			"statusLabel": statusLabel,
		}
		if hasRecord {
			item["amount"] = totalSalary
		}
		months = append(months, item)
	}

	models.Send(c, 200, 0, "success", map[string]interface{}{
		"year":   year,
		"months": months,
	})
}

// GetEmployeePaymentAddress returns payment address for a specific employee (admin).
func (h *AdminHandler) GetEmployeePaymentAddress(c *gin.Context) {
	employeeUUID := strings.TrimSpace(c.Param("employeeUuid"))
	if _, err := uuid.Parse(employeeUUID); err != nil {
		models.SendError(c, 400, 1001, "Invalid employee ID")
		return
	}

	row := h.db.QueryRowContext(c.Request.Context(), fmt.Sprintf(`
		SELECT e.id::text, e.employee_id, e.name,
		       %s AS department,
		       %s AS position,
		       pa.id::text,
		       COALESCE(pa.account_holder, ''), COALESCE(pa.bank_name, ''),
		       COALESCE(pa.bank_account, ''), COALESCE(pa.usdt_network, ''), COALESCE(pa.usdt_address, ''),
		       COALESCE(pa.other_wallet_type, ''), COALESCE(pa.other_wallet_address, ''),
		       COALESCE(pa.preferred_method, ''), COALESCE(pa.remark, ''), COALESCE(pa.notification_email, ''), pa.updated_at
		FROM employees e
		LEFT JOIN employee_payment_accounts pa ON pa.employee_id = e.id
		WHERE e.id = $1 AND e.status = 1
	`, attendanceDepartmentExpr, attendancePositionExpr), employeeUUID)

	var empUUID, empCode, empName, department, position string
	var paID sql.NullString
	var accountHolder, bankName, bankAccount, usdtNetwork, usdtAddress string
	var otherWalletType, otherWalletAddress, preferredMethod, remark, notificationEmail string
	var updatedAt sql.NullTime
	err := row.Scan(
		&empUUID, &empCode, &empName, &department, &position,
		&paID, &accountHolder, &bankName, &bankAccount, &usdtNetwork, &usdtAddress,
		&otherWalletType, &otherWalletAddress, &preferredMethod, &remark, &notificationEmail, &updatedAt,
	)
	if err == sql.ErrNoRows {
		models.SendError(c, 404, 2001, "员工不存在")
		return
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	result := map[string]interface{}{
		"employeeUuid": empUUID,
		"employeeCode": empCode,
		"employeeName": empName,
		"department":   department,
		"position":     position,
		"configured":   paID.Valid,
	}
	if paID.Valid {
		boundAccounts := buildBoundAccounts(
			accountHolder, bankName, bankAccount, usdtNetwork, usdtAddress,
			otherWalletType, otherWalletAddress, preferredMethod,
		)
		result["accountHolder"] = accountHolder
		result["bankName"] = bankName
		result["bankAccount"] = bankAccount
		result["usdtNetwork"] = usdtNetwork
		result["usdtAddress"] = usdtAddress
		result["otherWalletType"] = otherWalletType
		result["otherWalletAddress"] = otherWalletAddress
		result["preferredMethod"] = preferredMethod
		result["preferredMethodLabel"] = paymentMethodLabel(preferredMethod)
		result["boundAccounts"] = boundAccounts
		result["remark"] = remark
		result["notificationEmail"] = notificationEmail
		if updatedAt.Valid {
			result["updatedAt"] = models.FormatUTC(updatedAt.Time)
		}
	}
	models.Send(c, 200, 0, "success", result)
}

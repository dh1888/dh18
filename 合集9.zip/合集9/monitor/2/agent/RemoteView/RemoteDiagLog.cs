using Microsoft.Extensions.Logging;

namespace EnterpriseAgent.Agent.RemoteView;

/// <summary>
/// Unified remote-view diagnostic logging. Information level only; state/event driven.
/// </summary>
internal static class RemoteDiagLog
{
    public static void Event(
        ILogger logger,
        string module,
        string? sessionId,
        string state,
        string reason)
    {
        if (!logger.IsEnabled(LogLevel.Information))
            return;

        logger.LogInformation(
            "[RemoteDiag] ts={Timestamp:O} module={Module} session={SessionId} state={State} reason={Reason}",
            DateTime.UtcNow,
            module,
            NormalizeSessionId(sessionId),
            state,
            reason);
    }

    public static void Transition(
        ILogger logger,
        string module,
        string? sessionId,
        string fromState,
        string toState,
        string reason)
        => Event(logger, module, sessionId, $"{fromState}->{toState}", reason);

    private static string NormalizeSessionId(string? sessionId)
        => string.IsNullOrWhiteSpace(sessionId) ? "-" : sessionId.Trim();

    internal static string Truncate(string? value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "-";
        var trimmed = value.Trim();
        return trimmed.Length <= maxLength ? trimmed : trimmed[..maxLength] + "...";
    }
}

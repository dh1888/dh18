// backend/routes/routes.go - 完整修复版

package routes

import (
	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"enterprise-agent/backend/handlers"
	"enterprise-agent/backend/middleware"
	"enterprise-agent/backend/services"
)

// Handlers 结构体，包含所有处理器
type Handlers struct {
	Auth       *handlers.AuthHandler
	Device     *handlers.DeviceHandler
	Policy     *handlers.PolicyHandler
	Recording  *handlers.RecordingHandler
	Upload     *handlers.UploadHandler
	Task       *handlers.TaskHandler
	Cleanup    *handlers.CleanupHandler
	Activity   *handlers.ActivityHandler
	Screenshot *handlers.ScreenshotHandler
	User         *handlers.UserHandler
	Admin        *handlers.AdminHandler
	Workforce    *handlers.WorkforceHandler
	WorkforceTG  *handlers.WorkforceTelegramHandler
	OperationLog *handlers.OperationLogHandler
	RemoteView   *handlers.RemoteViewHandler
	Diagnostic   *handlers.DiagnosticHandler
	MediaToken   *handlers.MediaTokenHandler
	Meta         *handlers.MetaHandler
	Settings     *handlers.SettingsHandler
	WSTicket     *handlers.WSTicketHandler
	Notification *handlers.NotificationHandler
}

func registerUploadRoutes(public *gin.RouterGroup, handlers *Handlers, redisClient *redis.Client, deviceRepo *services.DeviceRepository) {
	upload := public.Group("/upload")
	// Session SSOT：DeviceAuth 必填 + 审核通过 + HMAC 完整性
	upload.Use(
		middleware.DeviceAuth(redisClient),
		middleware.RequireApprovedDevice(deviceRepo),
		middleware.VerifyDeviceSignature(handlers.Upload.DeviceRepo, redisClient),
	)
	{
		upload.POST("/chunk", handlers.Upload.UploadChunk)
		upload.POST("/complete", middleware.UploadCompleteRateLimit(redisClient), handlers.Upload.Complete)
		upload.GET("/:uploadId/progress", handlers.Upload.GetUploadProgress)
		upload.DELETE("/:uploadId", handlers.Upload.CancelUpload)
	}
}

// Legacy SetupRoutes removed — use SetupRoutesWithHub only.

func SetupRoutesWithHub(router *gin.Engine, handlers *Handlers, redisClient *redis.Client, wsHub *services.WebSocketHub, deviceRepo *services.DeviceRepository) {
	if handlers.WorkforceTG != nil {
		router.POST("/telegram/webhook", handlers.WorkforceTG.TelegramWebhook)
	}

	api := router.Group("/api/v1")
	api.Use(middleware.GlobalAPIRateLimit(redisClient))

	// ========== 公开接口（不需要认证） ==========
	public := api.Group("")
	{
		public.GET("/auth/login-config", handlers.Auth.GetLoginConfig)
		public.GET("/auth/captcha", middleware.CaptchaRateLimit(), handlers.Auth.GetCaptcha)
		public.POST("/auth/login", middleware.AuthRateLimit(), handlers.Auth.Login)
		public.POST("/auth/refresh", middleware.AuthRateLimit(), handlers.Auth.Refresh)
		public.POST("/auth/logout", middleware.AuthRateLimit(), handlers.Auth.Logout)
		public.POST("/devices/register", middleware.DeviceRegisterRateLimit(), handlers.Device.Register)
		public.POST("/devices/refresh", middleware.DeviceTokenRefreshRateLimit(), handlers.Device.Refresh)
		public.GET("/meta/capabilities", handlers.Meta.Capabilities)
		public.GET("/meta/client-release", handlers.Meta.ClientRelease)
		public.GET("/meta/client-release/update-package", handlers.Meta.DownloadUpdatePackage)
		// 设备信息上报：管理端（用户 Token）与 Agent（设备 Token）共用
		public.POST("/devices/info", middleware.UserOrDeviceAuth(redisClient), handlers.Device.ReportInfo)

		// 上传接口：设备 Session + HMAC 双验证
		registerUploadRoutes(public, handlers, redisClient, deviceRepo)
	}

	// ========== 用户认证接口 ==========
	protected := api.Group("")
	protected.Use(middleware.Auth(redisClient))
	{
		protected.GET("/meta/modules", handlers.Meta.Modules)
		protected.POST("/ws-ticket", middleware.WSTicketUserRateLimit(redisClient), handlers.WSTicket.IssueUser)

		notifications := protected.Group("/notifications")
		{
			notifications.GET("", handlers.Notification.ListNotifications)
			notifications.GET("/unread-count", handlers.Notification.GetUnreadCount)
			notifications.GET("/popups", handlers.Notification.ListPopupNotifications)
			notifications.POST("/read-all", handlers.Notification.MarkAllNotificationsRead)
			notifications.POST("/:id/read", handlers.Notification.MarkNotificationRead)
		}

		protected.GET("/client-download", handlers.Workforce.GetClientDownload)
		protected.GET("/client-download/file", handlers.Workforce.DownloadClientFile)

		// ---------- 设备管理 ----------
		devices := protected.Group("/devices")
		{
			devices.GET("", middleware.RequirePermission("device:view"), handlers.Device.List)
			devices.GET("/:id", middleware.RequirePermission("device:view"), handlers.Device.Get)
			devices.POST("/:id/bind", middleware.RequirePermission("device:bind"), handlers.Device.Bind)
			devices.POST("/:id/unbind", middleware.RequirePermission("device:unbind"), handlers.Device.Unbind)
			devices.POST("/:id/force-offline", middleware.RequirePermission("device:manage"), handlers.Device.ForceOffline)
			devices.GET("/:id/client-protection", middleware.RequirePermission("device:view"), handlers.Device.GetDeviceClientProtection)
			devices.PUT("/:id/client-protection", middleware.RequirePermission("device:manage"), handlers.Device.UpdateDeviceClientProtection)
			devices.POST("/:id/temporary-exit-grant", middleware.RequirePermission("device:manage"), handlers.Device.GrantDeviceTemporaryExit)
			devices.POST("/:id/exit-unlock-code", middleware.RequirePermission("device:manage"), handlers.Device.IssueDeviceExitUnlockCode)
			devices.PUT("/:id/status", middleware.RequirePermission("device:manage"), handlers.Device.UpdateStatus)
			devices.GET("/stats/online", middleware.RequirePermission("device:view"), handlers.Device.OnlineStats)
			devices.GET("/export", middleware.RequirePermission("device:view"), handlers.Device.ExportEmployees)
			devices.PUT("/:id/employee", middleware.RequirePermission("device:bind"), handlers.Device.UpdateEmployee)
			devices.POST("/:id/remote-view/start", middleware.RequirePermission("device:remote"), handlers.RemoteView.Start)
			devices.POST("/:id/remote-view/stop", middleware.RequirePermission("device:remote"), handlers.RemoteView.Stop)
			devices.POST("/:id/remote-view/quality", middleware.RequirePermission("device:remote"), handlers.RemoteView.UpdateQuality)
			devices.GET("/:id/remote-view/status", middleware.RequirePermission("device:remote"), handlers.RemoteView.Status)
		}

		remoteView := protected.Group("/remote-view")
		{
			remoteView.GET("/audit-logs", middleware.RequirePermission("device:remote"), handlers.RemoteView.AuditLogs)
		}

	recordingView := middleware.RequireAnyPermission("recording:view", "employee:recording:view_own")
	recordingPlay := middleware.RequireAnyPermission("recording:play", "employee:recording:view_own")

		// ---------- 录屏管理 ----------
		recordings := protected.Group("/recordings")
		{
			recordings.GET("", recordingView, handlers.Recording.List)
			recordings.GET("/:id", recordingView, handlers.Recording.Get)
			recordings.GET("/:id/play", recordingPlay, handlers.Recording.Play)
			recordings.GET("/:id/playback-info", recordingView, handlers.Recording.GetPlaybackInfo)
			recordings.DELETE("/:id", middleware.RequirePermission("recording:delete"), handlers.Recording.Delete)
			recordings.POST("/batch-delete", middleware.RequirePermission("recording:delete"), handlers.Recording.BatchDelete)
			recordings.GET("/stats", recordingView, handlers.Recording.GetStats)
			recordings.GET("/device/:deviceId", recordingView, handlers.Recording.GetByDevice)
			recordings.GET("/export", middleware.RequirePermission("recording:export"), handlers.Recording.ExportRecordings)
		}

		// ---------- 活动日志管理 ----------
		activities := protected.Group("/activities")
		{
			activities.GET("", middleware.RequirePermission("activity:view"), handlers.Activity.ListActivities)
			activities.GET("/daily-summary", middleware.RequirePermission("activity:view"), handlers.Activity.GetDailySummary)
			activities.GET("/stats", middleware.RequirePermission("activity:view"), handlers.Activity.GetActivityStats)
			activities.GET("/processes", middleware.RequirePermission("activity:view"), handlers.Activity.GetProcessNames)
			activities.GET("/export", middleware.RequirePermission("activity:export"), handlers.Activity.ExportActivities)
			activities.DELETE("", middleware.RequirePermission("activity:delete"), handlers.Activity.DeleteActivities)
		}

		// ---------- 策略管理 ----------
		policies := protected.Group("/policies")
		{
			policies.GET("", middleware.RequirePermission("policy:view"), handlers.Policy.List)
			policies.POST("", middleware.RequirePermission("policy:create"), handlers.Policy.Create)
			policies.GET("/:id", middleware.RequirePermission("policy:view"), handlers.Policy.Get)
			policies.PUT("/:id", middleware.RequirePermission("policy:update"), handlers.Policy.Update)
			policies.DELETE("/:id", middleware.RequirePermission("policy:delete"), handlers.Policy.Delete)
			policies.POST("/:id/publish", middleware.RequirePermission("policy:update"), handlers.Policy.Publish)
			policies.POST("/:id/rollback", middleware.RequirePermission("policy:update"), handlers.Policy.Rollback)
		}

		// ---------- 清理策略 ----------
		cleanup := protected.Group("/cleanup")
		{
			cleanup.GET("/policy", middleware.RequirePermission("policy:view"), handlers.Cleanup.GetCleanupPolicy)
			cleanup.PUT("/policy", middleware.RequirePermission("policy:update"), handlers.Cleanup.UpdateCleanupPolicy)
			cleanup.GET("/stats", middleware.RequirePermission("policy:view"), handlers.Cleanup.GetStorageStats)
			cleanup.POST("/manual", middleware.RequirePermission("policy:update"), handlers.Cleanup.ManualCleanup)
			cleanup.GET("/logs", middleware.RequirePermission("policy:view"), handlers.Cleanup.GetCleanupLogs)
		}

		settings := protected.Group("/settings")
		{
			settings.GET("/cors-origins", middleware.RequirePermission("policy:view"), handlers.Settings.GetCorsOrigins)
			settings.PUT("/cors-origins", middleware.RequirePermission("policy:update"), handlers.Settings.UpdateCorsOrigins)
			settings.GET("/auth-security", middleware.RequirePermission("policy:view"), handlers.Settings.GetAuthSecurity)
			settings.PUT("/auth-security", middleware.RequirePermission("policy:update"), handlers.Settings.UpdateAuthSecurity)
			settings.GET("/login-ip-whitelist", middleware.RequirePermission("policy:view"), handlers.Settings.GetLoginIPWhitelist)
			settings.PUT("/login-ip-whitelist", middleware.RequirePermission("policy:update"), handlers.Settings.UpdateLoginIPWhitelist)
			settings.GET("/client-protection", middleware.RequirePermission("policy:view"), handlers.Settings.GetClientProtectionDefaults)
			settings.PUT("/client-protection", middleware.RequirePermission("policy:update"), handlers.Settings.UpdateClientProtectionDefaults)
		}

		// ---------- 任务管理 ----------
		tasks := protected.Group("/tasks")
		{
			tasks.GET("", middleware.RequirePermission("recording:view"), handlers.Task.ListTasks)
			tasks.GET("/:id", middleware.RequirePermission("recording:view"), handlers.Task.GetTask)
			tasks.POST("", middleware.RequirePermission("recording:upload"), handlers.Task.CreateTask)
			tasks.POST("/:id/cancel", middleware.RequirePermission("recording:upload"), handlers.Task.CancelTask)
			tasks.POST("/:id/retry", middleware.RequirePermission("recording:upload"), handlers.Task.RetryTask)
			tasks.DELETE("/:id", middleware.RequirePermission("recording:upload"), handlers.Task.DeleteTask)
			tasks.POST("/batch-status", middleware.RequirePermission("recording:upload"), handlers.Task.BatchUpdateStatus)
		}

		// ---------- 上传任务 ----------
		uploadTasks := protected.Group("/upload-tasks")
		{
			uploadTasks.GET("", middleware.RequirePermission("recording:view"), handlers.Upload.ListTasks)
		}

		// ---------- 用户管理 ----------
		users := protected.Group("/users")
		{
			users.GET("", middleware.RequirePermission("user:view"), handlers.User.ListUsers)
			users.POST("", middleware.RequirePermission("user:create"), handlers.User.CreateUser)
			users.GET("/:id", middleware.RequirePermission("user:view"), handlers.User.GetUser)
			users.PUT("/:id", middleware.RequirePermission("user:update"), handlers.User.UpdateUser)
			users.DELETE("/:id", middleware.RequirePermission("user:delete"), handlers.User.DeleteUser)
			users.POST("/:id/reset-password", middleware.RequirePermission("user:manage"), handlers.User.ResetPassword)
			users.GET("/:id/salary-view-password", middleware.RequirePermission("user:reset_salary_view_password"), handlers.User.GetSalaryViewPasswordStatus)
			users.POST("/:id/reset-salary-view-password", middleware.RequirePermission("user:reset_salary_view_password"), handlers.User.ResetSalaryViewPassword)
			users.GET("/:id/screen-lock-password", middleware.RequirePermission("user:reset_screen_lock_password"), handlers.User.GetScreenLockPasswordStatus)
			users.POST("/:id/reset-screen-lock-password", middleware.RequirePermission("user:reset_screen_lock_password"), handlers.User.ResetScreenLockPassword)
			users.POST("/:id/reset-totp", middleware.RequirePermission("user:manage"), handlers.User.ResetTotp)
			users.POST("/:id/totp-enroll", middleware.RequirePermission("user:manage"), handlers.User.InitiateTotpEnroll)
			users.POST("/:id/totp-enroll/confirm", middleware.RequirePermission("user:manage"), handlers.User.ConfirmTotpEnroll)
			users.POST("/:id/roles", middleware.RequirePermission("user:manage"), handlers.User.AssignRole)
			users.DELETE("/:id/roles/:roleId", middleware.RequirePermission("user:manage"), handlers.User.RemoveRole)
		}

		// ---------- 截图管理 ----------
		screenshots := protected.Group("/screenshots")
		{
			screenshots.GET("", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.ListScreenshots)
			screenshots.GET("/overview", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.GetOverview)
			screenshots.POST("/purge", middleware.RequirePermission("screenshot:delete"), handlers.Screenshot.PurgeScreenshots)
			screenshots.GET("/:id", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.GetScreenshot)
			screenshots.DELETE("/:id", middleware.RequirePermission("screenshot:delete"), handlers.Screenshot.DeleteScreenshot)
			screenshots.POST("/batch-delete", middleware.RequirePermission("screenshot:delete"), handlers.Screenshot.BatchDeleteScreenshots)
			screenshots.GET("/stats/batch", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.GetBatchEmployeeScreenshotStats)
			screenshots.GET("/stats/employee/:deviceId", middleware.RequirePermission("screenshot:view"), handlers.Screenshot.GetEmployeeScreenshotStats)
		}

		// 短期媒体访问令牌（用于录屏流等）
		if handlers.MediaToken != nil {
			protected.POST("/media/access-token", handlers.MediaToken.Issue)
		}

		// ---------- 个人信息 ----------
		profile := protected.Group("/user")
		{
			profile.GET("/profile", handlers.User.GetProfile)
			profile.PUT("/profile", handlers.User.UpdateProfile)
			profile.POST("/change-password", handlers.User.ChangeOwnPassword)
			profile.GET("/screen-lock/status", handlers.User.GetScreenLockStatus)
			profile.POST("/screen-lock/setup", handlers.User.SetupScreenLockPassword)
			profile.POST("/screen-lock/verify", handlers.User.VerifyScreenLockPassword)
			profile.POST("/screen-lock/change-password", handlers.User.ChangeScreenLockPassword)
			profile.GET("/totp", handlers.User.GetOwnTotpStatus)
			profile.POST("/totp/enroll", handlers.User.InitiateOwnTotpEnroll)
			profile.POST("/totp/enroll/confirm", handlers.User.ConfirmOwnTotpEnroll)
			profile.GET("/invite-code", handlers.Workforce.GetMyInviteCode)
		}

		// ---------- 角色管理 ----------
		roles := protected.Group("/roles")
		{
			roles.GET("", middleware.RequirePermission("role:view"), handlers.User.GetAllRoles)
			roles.GET("/:id", middleware.RequirePermission("role:view"), handlers.User.GetRole)
			roles.POST("", middleware.RequirePermission("role:create"), handlers.User.CreateRole)
			roles.PUT("/:id", middleware.RequirePermission("role:update"), handlers.User.UpdateRole)
			roles.DELETE("/:id", middleware.RequirePermission("role:delete"), handlers.User.DeleteRole)
		}

		// ---------- 出款与考勤管理 ----------
		admin := protected.Group("/admin")
        {
            // ========== 员工管理 ==========
            admin.GET("/employees", middleware.RequirePermission("attendance:view"), handlers.Admin.GetEmployees)
            admin.POST("/employees", middleware.RequirePermission("attendance:edit"), handlers.Admin.CreateEmployee)
            admin.PUT("/employees/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.UpdateEmployee)
            admin.DELETE("/employees/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.DeleteEmployee)
            admin.POST("/employee-accounts", middleware.RequirePermission("attendance:edit"), handlers.Workforce.CreateEmployeeAccount)
            admin.POST("/employees/:id/disable", middleware.RequirePermission("attendance:edit"), handlers.Workforce.DisableEmployee)

            admin.GET("/invite-codes", middleware.RequirePermission("invite:view"), handlers.Workforce.ListInviteCodes)
            admin.GET("/invite-codes/settings", middleware.RequirePermission("invite:view"), handlers.Workforce.GetInviteCodeSettings)
            admin.PUT("/invite-codes/settings", middleware.RequirePermission("invite:manage"), handlers.Workforce.UpdateInviteCodeSettings)
            admin.GET("/invite-codes/history", middleware.RequirePermission("invite:view"), handlers.Workforce.ListInviteCodeHistory)
            admin.POST("/invite-codes/:id/revoke", middleware.RequirePermission("invite:manage"), handlers.Workforce.RevokeInviteCode)
            admin.POST("/employees/:id/invite-code/regenerate", middleware.RequirePermission("invite:manage"), handlers.Workforce.RegenerateInviteCode)

            // ========== 考勤管理 ==========
            admin.GET("/attendance/records", middleware.RequirePermission("attendance:view"), handlers.Admin.GetAttendanceRecords)
            admin.POST("/attendance/records", middleware.RequirePermission("attendance:edit"), handlers.Admin.SaveAttendanceRecords)
            admin.POST("/attendance/records/import", middleware.RequirePermission("attendance:edit"), handlers.Workforce.ImportAttendanceRecords)
			admin.GET("/attendance/today-absentees", middleware.RequirePermission("attendance:view"), handlers.Admin.GetTodayAbsentees)
			admin.GET("/attendance/today-rate", middleware.RequirePermission("attendance:view"), handlers.Admin.GetTodayAttendanceRate)

            // ========== Telegram 考勤 (P0) ==========
            admin.GET("/workforce/telegram/settings", middleware.RequireAnyPermission("telegram:view", "attendance:view"), handlers.WorkforceTG.GetSettings)
            admin.PUT("/workforce/telegram/settings", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.UpdateSettings)
            admin.POST("/workforce/telegram/settings/regenerate-secret", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.RegenerateWorkerSecret)
            admin.POST("/workforce/telegram/settings/regenerate-webhook-secret", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.RegenerateWebhookSecret)
            admin.POST("/workforce/telegram/settings/generate-worker-pairing", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.GenerateWorkerPairing)
            admin.GET("/workforce/telegram/worker-connection", middleware.RequirePermission("telegram:view"), handlers.WorkforceTG.GetWorkerConnection)
            admin.GET("/workforce/telegram/groups/discover", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.DiscoverGroups)
            admin.GET("/workforce/telegram/groups", middleware.RequireAnyPermission("telegram:view", "attendance:view"), handlers.WorkforceTG.ListGroups)
            admin.POST("/workforce/telegram/groups", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.UpsertGroup)
            admin.DELETE("/workforce/telegram/groups/:id", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.DeleteGroup)
            admin.GET("/workforce/telegram/bindings", middleware.RequirePermission("telegram:view"), handlers.WorkforceTG.ListBindings)
            admin.POST("/workforce/telegram/bindings", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.CreateBinding)
            admin.DELETE("/workforce/telegram/bindings/:id", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.DeleteBinding)
            admin.POST("/workforce/telegram/bindings/:id/reset-daily", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.ResetBindingDaily)
            admin.POST("/workforce/telegram/reset-daily", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.ResetEmployeeDaily)
            admin.POST("/workforce/telegram/device-bindings/:id/reset-daily", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.ResetDeviceBindingDaily)

            admin.GET("/workforce/telegram/activity-types", middleware.RequireAnyPermission("telegram:view", "attendance:view"), handlers.WorkforceTG.ListActivityTypes)
            admin.PUT("/workforce/telegram/activity-types", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.UpsertActivityType)
            admin.DELETE("/workforce/telegram/activity-types/:code", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.DeleteActivityType)
            admin.GET("/workforce/telegram/activity-fines", middleware.RequirePermission("telegram:view"), handlers.WorkforceTG.ListActivityFines)
            admin.POST("/workforce/telegram/activity-fines/batch", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.BatchUpsertActivityFines)
            admin.POST("/workforce/telegram/activity-fines", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.UpsertActivityFine)
            admin.DELETE("/workforce/telegram/activity-fines/:id", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.DeleteActivityFine)
            admin.GET("/workforce/telegram/activity-sessions", middleware.RequireAnyPermission("telegram:view", "attendance:view"), handlers.WorkforceTG.ListActivitySessions)
            admin.GET("/workforce/telegram/work-sessions", middleware.RequireAnyPermission("telegram:view", "attendance:view"), handlers.WorkforceTG.ListWorkSessions)
            admin.GET("/workforce/telegram/handovers", middleware.RequireAnyPermission("telegram:view", "attendance:view"), handlers.WorkforceTG.ListHandovers)
            admin.GET("/workforce/telegram/rankings", middleware.RequireAnyPermission("telegram:view", "attendance:view"), handlers.WorkforceTG.ListRankings)
            admin.GET("/workforce/telegram/export", middleware.RequirePermission("telegram:view"), handlers.WorkforceTG.ExportAttendance)
            admin.POST("/workforce/telegram/daily-reset", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.RunDailyReset)
            admin.GET("/workforce/telegram/handover-config", middleware.RequirePermission("telegram:view"), handlers.WorkforceTG.GetHandoverConfig)
            admin.PUT("/workforce/telegram/handover-config", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.UpsertHandoverConfig)
            admin.GET("/workforce/telegram/push-settings", middleware.RequirePermission("telegram:view"), handlers.WorkforceTG.GetPushSettings)
            admin.PUT("/workforce/telegram/push-settings", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.UpsertPushSettings)
            admin.POST("/workforce/telegram/push-settings/test", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.TestPushSettings)
            admin.GET("/workforce/telegram/attendance-review/settings", middleware.RequireAnyPermission("telegram:view", "attendance:view"), handlers.WorkforceTG.GetAttendanceReviewSettings)
            admin.PUT("/workforce/telegram/attendance-review/settings", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.SaveAttendanceReviewSettings)
            admin.GET("/workforce/telegram/attendance-review/tasks", middleware.RequireAnyPermission("telegram:view", "attendance:view"), handlers.WorkforceTG.ListAttendanceReviewTasks)
            admin.POST("/workforce/telegram/attendance-review/tasks/:id/confirm", middleware.RequirePermission("attendance:edit"), handlers.WorkforceTG.ConfirmAttendanceReviewTask)
            admin.POST("/workforce/telegram/punch/checkin", middleware.RequireAnyPermission("attendance:view", "attendance:edit", "telegram:view"), handlers.WorkforceTG.AdminPunchCheckIn)
            admin.POST("/workforce/telegram/punch/checkout", middleware.RequireAnyPermission("attendance:view", "attendance:edit", "telegram:view"), handlers.WorkforceTG.AdminPunchCheckOut)
            admin.POST("/workforce/telegram/punch/activity/start", middleware.RequireAnyPermission("attendance:view", "attendance:edit", "telegram:view"), handlers.WorkforceTG.AdminPunchActivityStart)
            admin.POST("/workforce/telegram/punch/activity/back", middleware.RequireAnyPermission("attendance:view", "attendance:edit", "telegram:view"), handlers.WorkforceTG.AdminPunchActivityBack)
            admin.GET("/workforce/telegram/punch/me", middleware.RequireAnyPermission("attendance:view", "attendance:edit", "telegram:view"), handlers.WorkforceTG.GetAdminPunchMe)
            admin.GET("/workforce/telegram/work-fines", middleware.RequirePermission("telegram:view"), handlers.WorkforceTG.ListWorkFines)
            admin.POST("/workforce/telegram/work-fines/batch", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.BatchUpsertWorkFines)
            admin.POST("/workforce/telegram/work-fines", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.UpsertWorkFine)
            admin.DELETE("/workforce/telegram/work-fines/:id", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.DeleteWorkFine)
            admin.GET("/workforce/telegram/shared-workstations", middleware.RequirePermission("telegram:view"), handlers.WorkforceTG.ListSharedWorkstationMembers)
            admin.POST("/workforce/telegram/shared-workstations", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.AddSharedWorkstationMember)
            admin.DELETE("/workforce/telegram/shared-workstations", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.RemoveSharedWorkstationMember)
            admin.GET("/workforce/telegram/device-bindings", middleware.RequirePermission("telegram:view"), handlers.WorkforceTG.ListDeviceTelegramBindings)
            admin.DELETE("/workforce/telegram/device-bindings/:id", middleware.RequirePermission("telegram:edit"), handlers.WorkforceTG.DeleteDeviceTelegramBinding)

            // ========== 绩效管理 ==========
            admin.GET("/performance", middleware.RequirePermission("attendance:view"), handlers.Admin.GetPerformance)
            admin.POST("/performance/batch", middleware.RequirePermission("attendance:edit"), handlers.Admin.BatchSavePerformance)
            admin.GET("/performance/rule-settings", middleware.RequirePermission("attendance:view"), handlers.Admin.GetPerformanceRuleSettings)
            admin.PUT("/performance/rule-settings", middleware.RequirePermission("attendance:edit"), handlers.Admin.SavePerformanceRuleSettings)
            // ⭐ 新增：单条绩效修改和删除
            admin.PUT("/performance/:employeeId/:month", middleware.RequirePermission("attendance:edit"), handlers.Admin.UpdatePerformance)
            admin.DELETE("/performance/:employeeId/:month", middleware.RequirePermission("attendance:edit"), handlers.Admin.DeletePerformance)
            admin.GET("/performance/push-settings", middleware.RequirePermission("attendance:view"), handlers.Admin.GetPerformancePushSettings)
            admin.PUT("/performance/push-settings/enabled", middleware.RequirePermission("attendance:edit"), handlers.Admin.SavePerformancePushEnabled)
            admin.PUT("/performance/push-settings/token", middleware.RequirePermission("attendance:edit"), handlers.Admin.SavePerformancePushToken)
            admin.POST("/performance/push-settings/discover", middleware.RequirePermission("attendance:edit"), handlers.Admin.DiscoverPerformancePushChats)
            admin.PUT("/performance/push-settings/bind", middleware.RequirePermission("attendance:edit"), handlers.Admin.BindPerformancePushChat)
            admin.DELETE("/performance/push-settings/bind", middleware.RequirePermission("attendance:edit"), handlers.Admin.UnbindPerformancePushChat)
            admin.POST("/performance/push-settings/test", middleware.RequirePermission("attendance:edit"), handlers.Admin.TestPerformancePush)
            admin.POST("/performance/push-notify", middleware.RequirePermission("attendance:edit"), handlers.Admin.NotifyPerformancePush)

            admin.GET("/penalty/push-settings", middleware.RequirePermission("attendance:view"), handlers.Admin.GetPenaltyPushSettings)
            admin.PUT("/penalty/push-settings/enabled", middleware.RequirePermission("attendance:edit"), handlers.Admin.SavePenaltyPushEnabled)
            admin.PUT("/penalty/push-settings/token", middleware.RequirePermission("attendance:edit"), handlers.Admin.SavePenaltyPushToken)
            admin.POST("/penalty/push-settings/discover", middleware.RequirePermission("attendance:edit"), handlers.Admin.DiscoverPenaltyPushChats)
            admin.PUT("/penalty/push-settings/bind", middleware.RequirePermission("attendance:edit"), handlers.Admin.BindPenaltyPushChat)
            admin.DELETE("/penalty/push-settings/bind", middleware.RequirePermission("attendance:edit"), handlers.Admin.UnbindPenaltyPushChat)
            admin.POST("/penalty/push-settings/test", middleware.RequirePermission("attendance:edit"), handlers.Admin.TestPenaltyPush)
            admin.POST("/penalty/push-notify", middleware.RequirePermission("attendance:edit"), handlers.Admin.NotifyPenaltyPush)

            admin.GET("/agent-notification/settings", middleware.RequirePermission("agent_notification:view"), handlers.Admin.GetAgentNotificationSettings)
            admin.PUT("/agent-notification/settings", middleware.RequirePermission("agent_notification:edit"), handlers.Admin.SaveAgentNotificationSettings)

            admin.GET("/cs-tool/settings", middleware.RequireAnyPermission("cstool:view", "cstool:settings"), handlers.Admin.GetCsToolSettings)
            admin.PUT("/cs-tool/settings", middleware.RequirePermission("cstool:settings"), handlers.Admin.SaveCsToolSettings)

            // ========== 罚款管理 ==========
            admin.GET("/penalty/records", middleware.RequirePermission("attendance:view"), handlers.Admin.GetPenaltyRecords)
            admin.POST("/penalty/record", middleware.RequirePermission("attendance:edit"), handlers.Admin.CreatePenaltyRecord)
            // ⭐ 新增：罚款修改
            admin.PUT("/penalty/records/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.UpdatePenaltyRecord)
            admin.DELETE("/penalty/records/:id", middleware.RequirePermission("attendance:edit"), handlers.Admin.DeletePenaltyRecord)

            // ========== 站点管理 ==========
            admin.GET("/site-stats/sites", middleware.RequireAnyPermission("site:view", "stats:view"), handlers.Admin.GetSites)
            admin.POST("/site-stats/sites", middleware.RequirePermission("site:manage"), handlers.Admin.CreateSite)
            admin.PUT("/site-stats/sites/:id", middleware.RequirePermission("site:manage"), handlers.Admin.UpdateSite)
            admin.DELETE("/site-stats/sites/:id", middleware.RequirePermission("site:manage"), handlers.Admin.DeleteSite)

            // ========== 员工账号管理 ==========
            admin.GET("/site-stats/employee-accounts", middleware.RequireAnyPermission("site:view", "stats:view"), handlers.Admin.GetEmployeeAccounts)
            admin.POST("/site-stats/employee-accounts", middleware.RequirePermission("site:manage"), handlers.Admin.CreateEmployeeAccount)
            admin.POST("/site-stats/employee-accounts/import", middleware.RequirePermission("site:manage"), handlers.Admin.ImportEmployeeAccounts)
            admin.PUT("/site-stats/employee-accounts/:id", middleware.RequirePermission("site:manage"), handlers.Admin.UpdateEmployeeAccount)
            admin.DELETE("/site-stats/employee-accounts/:id", middleware.RequirePermission("site:manage"), handlers.Admin.DeleteEmployeeAccount)

            // ========== 出款统计 ==========
            admin.POST("/site-stats/upload/preview", middleware.RequirePermission("stats:edit"), handlers.Admin.PreviewSiteStatsUpload)
            admin.POST("/site-stats/upload", middleware.RequirePermission("stats:edit"), handlers.Admin.UploadSiteStats)
            admin.DELETE("/site-stats/data/clear-by-date", middleware.RequirePermission("stats:edit"), handlers.Admin.ClearSiteStatsByDate)
            admin.DELETE("/site-stats/data/clear", middleware.RequirePermission("stats:edit"), handlers.Admin.ClearAllSiteStats)
            admin.GET("/site-stats/summary", middleware.RequirePermission("stats:view"), handlers.Admin.GetSiteStatsSummary)
            admin.GET("/site-stats/stacked-summary", middleware.RequirePermission("stats:view"), handlers.Admin.GetSiteStatsStacked)
            admin.DELETE("/site-stats/clear-by-date-only", middleware.RequirePermission("stats:edit"), handlers.Admin.ClearSiteStatsByDateOnly)
            admin.DELETE("/site-stats/clear-by-date-shift", middleware.RequirePermission("stats:edit"), handlers.Admin.ClearSiteStatsByDateAndShift)
        }

        // ---------- 工资管理 ----------
        salary := protected.Group("/salary")
        {
            salary.GET("/view-gate/status", middleware.RequirePermission("salary:view"), handlers.Admin.GetSalaryViewGateStatus)
            salary.POST("/view-gate/setup", middleware.RequirePermission("salary:view"), handlers.Admin.SetupSalaryViewPassword)
            salary.POST("/view-gate/verify", middleware.RequirePermission("salary:view"), handlers.Admin.VerifySalaryViewPassword)
            salary.POST("/view-gate/change-password", middleware.RequirePermission("salary:view"), handlers.Admin.ChangeSalaryViewPassword)

            salaryViewUnlock := middleware.RequireSalaryViewUnlock()

            salary.POST("/upload/preview", middleware.RequirePermission("salary:upload"), handlers.Admin.PreviewSalaryUpload)
            salary.POST("/upload", middleware.RequirePermission("salary:upload"), handlers.Admin.UploadSalary)
            salary.GET("/records", middleware.RequirePermission("salary:view"), salaryViewUnlock, handlers.Admin.GetSalaryRecords)
            salary.PUT("/records/:id", middleware.RequirePermission("salary:edit"), handlers.Admin.UpdateSalaryRecord)
            salary.DELETE("/records/:id", middleware.RequirePermission("salary:delete"), handlers.Admin.DeleteSalaryRecord)
            salary.POST("/records/mark-paid", middleware.RequirePermission("salary:upload"), handlers.Admin.MarkSalaryPaid)
            salary.POST("/records/mark-all-paid", middleware.RequirePermission("salary:upload"), handlers.Admin.MarkAllSalaryPaid)
            salary.POST("/payment-proofs", middleware.RequireAnyPermission("salary:upload", "salary:payment_address:view"), handlers.Admin.UploadSalaryPaymentProof)
            salary.GET("/payment-proofs", middleware.RequireAnyPermission("salary:upload", "salary:payment_address:view", "salary:view"), salaryViewUnlock, handlers.Admin.GetSalaryPaymentProof)
            salary.GET("/payment-proofs/:id/file", middleware.RequireAnyPermission("salary:upload", "salary:payment_address:view", "salary:view"), salaryViewUnlock, handlers.Admin.GetSalaryPaymentProofFile)
            salary.GET("/months", middleware.RequirePermission("salary:view"), salaryViewUnlock, handlers.Admin.GetSalaryMonths)
            salary.GET("/payment-address/me", middleware.RequirePermission("salary:view"), salaryViewUnlock, handlers.Admin.GetMyPaymentAddress)
            salary.PUT("/payment-address/me", middleware.RequirePermission("salary:view"), salaryViewUnlock, handlers.Admin.UpsertMyPaymentAddress)
            salary.GET("/payment-addresses", middleware.RequirePermission("salary:payment_address:view"), handlers.Admin.ListPaymentAddresses)
            salary.GET("/payment-addresses/:employeeUuid/salary-year", middleware.RequireAnyPermission("salary:upload", "salary:payment_address:view"), handlers.Admin.GetPaymentAddressSalaryYear)
            salary.GET("/payment-addresses/:employeeUuid", middleware.RequireAnyPermission("salary:upload", "salary:payment_address:view"), handlers.Admin.GetEmployeePaymentAddress)
            salary.GET("/config", middleware.RequirePermission("salary:upload"), handlers.Admin.GetSalaryConfigs)
            salary.POST("/config", middleware.RequirePermission("salary:upload"), handlers.Admin.CreateSalaryConfig)
            salary.PUT("/config", middleware.RequirePermission("salary:upload"), handlers.Admin.UpsertSalaryConfig)
            salary.DELETE("/config/:configKey", middleware.RequirePermission("salary:upload"), handlers.Admin.DeleteSalaryConfig)
            salary.GET("/calculate/draft", middleware.RequirePermission("salary:upload"), handlers.Admin.GetSalaryCalculateDraft)
            salary.POST("/calculate/recalculate", middleware.RequirePermission("salary:upload"), handlers.Admin.RecalculateSalaryRows)
            salary.POST("/calculate/save", middleware.RequirePermission("salary:upload"), handlers.Admin.SaveSalaryCalculateRows)
        }

		// ---------- 操作日志管理 ----------
        operationLogs := protected.Group("/operation-logs")
        {
            operationLogs.GET("", middleware.RequirePermission("operation_log:view"), handlers.OperationLog.GetOperationLogs)
            operationLogs.GET("/modules", middleware.RequirePermission("operation_log:view"), handlers.OperationLog.GetOperationModules)
            operationLogs.GET("/types", middleware.RequirePermission("operation_log:view"), handlers.OperationLog.GetOperationTypes)
            operationLogs.GET("/export", middleware.RequirePermission("operation_log:export"), handlers.OperationLog.ExportOperationLogs)
            operationLogs.DELETE("", middleware.RequirePermission("operation_log:delete"), handlers.OperationLog.DeleteOperationLogs)
        }

		// ---------- 诊断中心 ----------
		if handlers.Diagnostic != nil {
			diagnostics := protected.Group("/diagnostics")
			{
				diagnostics.GET("/config", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.GetConfig)
				diagnostics.PUT("/config", middleware.RequirePermission("diagnostic:manage"), handlers.Diagnostic.UpdateConfig)
				diagnostics.GET("/templates", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.ListTemplates)
				diagnostics.POST("/templates/apply", middleware.RequirePermission("diagnostic:manage"), handlers.Diagnostic.ApplyTemplate)
				diagnostics.GET("/snapshot", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.GetSnapshot)
				diagnostics.GET("/analyze", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.Analyze)
				diagnostics.GET("/pipeline", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.GetPipeline)
				diagnostics.GET("/pipeline/node", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.GetPipelineNode)
				diagnostics.GET("/sessions", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.ListSessions)
				diagnostics.GET("/sessions/:sessionId", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.GetSession)
				diagnostics.POST("/reproduce", middleware.RequirePermission("diagnostic:manage"), handlers.Diagnostic.StartReproduce)
				diagnostics.GET("/reproduce/:jobId", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.GetReproduceStatus)
				diagnostics.GET("/events", middleware.RequirePermission("diagnostic:view"), handlers.Diagnostic.ListEvents)
				diagnostics.GET("/export", middleware.RequirePermission("diagnostic:export"), handlers.Diagnostic.Export)
				diagnostics.POST("/capture", middleware.RequirePermission("diagnostic:export"), handlers.Diagnostic.Capture)
				diagnostics.POST("/capture/export", middleware.RequirePermission("diagnostic:export"), handlers.Diagnostic.CaptureExport)
				diagnostics.GET("/runtime", handlers.Diagnostic.GetRuntime)
				diagnostics.POST("/ingest", handlers.Diagnostic.IngestFrontend)
			}
		}
		
		// ---------- 员工自助门户 ----------
		portal := protected.Group("/employee")
		portal.Use(middleware.RequireEmployeePortal())
		{
			portal.GET("/portal/me", handlers.Workforce.GetPortalMe)
			portal.GET("/invite-code", handlers.Workforce.GetMyInviteCode)
			portal.GET("/attendance", handlers.Workforce.GetMyAttendance)
			portal.GET("/attendance/overview", handlers.Workforce.GetMyAttendanceOverview)
			portal.GET("/device", handlers.Workforce.GetMyDevice)
			// Keep portal aliases for older clients; any authenticated portal user may download.
			portal.GET("/client-download", handlers.Workforce.GetClientDownload)
			portal.GET("/client-download/file", handlers.Workforce.DownloadClientFile)
		}
	}

	// 截图/录屏二进制访问：Bearer JWT 或短期 mediaToken（独立于 protected，避免强制 JWT 拦截 mediaToken）
	mediaAccess := api.Group("")
	{
		mediaAccess.GET("/screenshots/:id/image",
			middleware.MediaAccessAuth(redisClient, "screenshot", "view", "screenshot:view"),
			handlers.Screenshot.GetScreenshotImage)
		mediaAccess.GET("/screenshots/:id/thumbnail",
			middleware.MediaAccessAuth(redisClient, "screenshot", "view", "screenshot:view"),
			handlers.Screenshot.GetScreenshotThumbnail)
		mediaAccess.GET("/recordings/:id/stream",
			middleware.MediaAccessAnyAuth(redisClient, "recording", "stream", "recording:play", "employee:recording:view_own"),
			handlers.Recording.Stream)
		mediaAccess.GET("/recordings/:id/download",
			middleware.MediaAccessAuth(redisClient, "recording", "download", "recording:export"),
			handlers.Recording.Download)
	}

	// ========== ✅ 设备认证接口（使用设备 Token）==========
	deviceProtected := api.Group("")
	deviceProtected.Use(middleware.DeviceAuth(redisClient))
	{
		// 设备验证
		deviceProtected.GET("/devices/:id/verify", handlers.Device.Verify)
		deviceProtected.POST("/devices/heartbeat", handlers.Device.Heartbeat)

		// 策略同步（需管理员审核通过，与 tasks/activities 一致）
		deviceProtected.GET("/policies/current", middleware.RequireApprovedDevice(deviceRepo), handlers.Policy.GetCurrent)

		// 任务同步（需管理员审核通过）
		deviceProtected.GET("/tasks/pending", middleware.RequireApprovedDevice(deviceRepo), handlers.Task.GetPendingTasks)
		deviceProtected.PUT("/tasks/:id/status", middleware.RequireApprovedDevice(deviceRepo), handlers.Task.UpdateTaskStatus)
		// ✅ 活动日志上报
		deviceProtected.POST("/activities/report", middleware.RequireApprovedDevice(deviceRepo), handlers.Activity.ReportActivities)

		deviceProtected.POST("/agent/checkin", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.CheckIn)
		deviceProtected.POST("/agent/checkout", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.CheckOut)
		deviceProtected.POST("/agent/employee-login", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.EmployeeLogin)
		deviceProtected.POST("/agent/employee-logout", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.EmployeeLogout)
		deviceProtected.GET("/agent/session", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.GetAgentSession)
		deviceProtected.GET("/agent/telegram-bind-status", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.GetTelegramBindStatus)
		deviceProtected.POST("/agent/telegram-bind-token", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.CreateTelegramBindToken)
		deviceProtected.POST("/agent/activity/back", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.ActivityBack)
		deviceProtected.POST("/agent/activity/start", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.ActivityStart)
		deviceProtected.GET("/agent/tg-dashboard", middleware.RequireApprovedDevice(deviceRepo), handlers.Workforce.GetAgentTgDashboard)
		deviceProtected.GET("/agent/client-protection", middleware.RequireApprovedDevice(deviceRepo), handlers.Device.GetAgentClientProtection)
		deviceProtected.POST("/agent/client-protection/verify-unlock", middleware.RequireApprovedDevice(deviceRepo), handlers.Device.VerifyAgentExitUnlock)
		deviceProtected.POST("/devices/ws-ticket", middleware.WSTicketDeviceRateLimit(redisClient), handlers.WSTicket.IssueDevice)
	}

	// ========== Telegram Worker（薄 Bot 调用的内部 API，Worker Secret 鉴权）==========
	telegramWorker := api.Group("/telegram/worker")
	{
		telegramWorker.POST("/pair", handlers.WorkforceTG.WorkerPair)
		telegramWorker.POST("/heartbeat", handlers.WorkforceTG.WorkerHeartbeat)
		telegramWorker.GET("/config", handlers.WorkforceTG.WorkerConfig)
		telegramWorker.GET("/status", handlers.WorkforceTG.WorkerStatus)
		telegramWorker.POST("/bind", handlers.WorkforceTG.WorkerBind)
		telegramWorker.POST("/bind-workstation", handlers.WorkforceTG.WorkerBindWorkstation)
		telegramWorker.POST("/checkin", handlers.WorkforceTG.WorkerCheckIn)
		telegramWorker.POST("/checkout", handlers.WorkforceTG.WorkerCheckOut)
		telegramWorker.POST("/activity/start", handlers.WorkforceTG.WorkerStartActivity)
		telegramWorker.POST("/activity/end", handlers.WorkforceTG.WorkerEndActivity)
		telegramWorker.POST("/activity/callback-back", handlers.WorkforceTG.WorkerCallbackQuickBack)
		telegramWorker.POST("/attendance-review/callback", handlers.WorkforceTG.WorkerAttendanceReviewCallback)
		telegramWorker.POST("/activity/message-id", handlers.WorkforceTG.WorkerActivityMessageID)
		telegramWorker.POST("/group/register", handlers.WorkforceTG.WorkerRegisterGroup)
		telegramWorker.POST("/chat/seen", handlers.WorkforceTG.WorkerRecordChatSeen)
		telegramWorker.GET("/myinfo", handlers.WorkforceTG.WorkerMyInfo)
		telegramWorker.POST("/handover", handlers.WorkforceTG.WorkerHandover)
		telegramWorker.GET("/rankings", handlers.WorkforceTG.WorkerRankings)
		telegramWorker.GET("/export", handlers.WorkforceTG.WorkerExport)
		telegramWorker.GET("/monthly-report", handlers.WorkforceTG.WorkerMonthlyReport)
		telegramWorker.GET("/actstatus", handlers.WorkforceTG.WorkerActStatus)
		telegramWorker.GET("/showsettings", handlers.WorkforceTG.WorkerShowSettings)
		telegramWorker.GET("/checkdb", handlers.WorkforceTG.WorkerCheckDB)
		telegramWorker.GET("/resolve-ci", handlers.WorkforceTG.WorkerResolveCI)
		telegramWorker.POST("/admin/fixmessages", handlers.WorkforceTG.WorkerFixMessages)
	}

	// ========== WebSocket 路由 ==========
	wsGuard := middleware.WSHandshakeRateLimit(redisClient)
	router.GET("/ws/agent",
		wsGuard,
		middleware.AgentWebSocketAuth(redisClient),
		middleware.RequireApprovedDevice(deviceRepo),
		handlers.Device.HandleAgentWebSocket)
	router.GET("/ws/admin", wsGuard, middleware.WebSocketAuth(redisClient), handlers.Device.HandleAdminWebSocket)
}

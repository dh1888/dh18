package services

import (
	"context"
	"fmt"
	"log"
	"strings"

	"github.com/google/uuid"
)

// AdminPunchResult is the admin console punch outcome (same core path as TG).
type AdminPunchResult struct {
	Result         *CheckInResult
	CheckOut       *CheckOutResult
	EmployeeName   string
	WorkFine       float64
	HandoverHint   string
	ActivityWarn   string
	GroupReplyHTML string
	MessageText    string
}

func (s *WorkforceTelegramService) resolveAdminPunchContext(ctx context.Context, empID uuid.UUID) (int64, string, *TelegramActor, string, error) {
	if empID == uuid.Nil {
		return 0, "", nil, "", ErrEmployeeNotFound
	}
	if err := s.ensureAttendanceModuleAvailable(ctx); err != nil {
		return 0, "", nil, "", err
	}
	var empName string
	if err := s.db.QueryRowContext(ctx, `SELECT COALESCE(name,'') FROM employees WHERE id = $1`, empID).Scan(&empName); err != nil {
		return 0, "", nil, "", ErrEmployeeNotFound
	}
	chatID := s.resolveNotifyChatID(ctx, empID, uuid.Nil)
	tgUID := s.employeeTelegramUserID(ctx, empID)
	actor := &TelegramActor{
		Channel:     TelegramChannelPersonal,
		EmployeeID:  empID,
		PunchSource: PunchSourceWeb,
	}
	if deviceID, err := s.findDeviceForEmployee(ctx, empID); err == nil && deviceID != uuid.Nil {
		actor.DeviceID = deviceID
	}
	return tgUID, chatID, actor, empName, nil
}

func (s *WorkforceTelegramService) publishAdminPunchGroupReply(ctx context.Context, chatID string, empID uuid.UUID, groupHTML string) {
	chatID = strings.TrimSpace(chatID)
	groupHTML = strings.TrimSpace(groupHTML)
	if chatID == "" || groupHTML == "" {
		return
	}
	html := "🖥 <b>后台打卡</b>\n" + groupHTML
	kb := s.BuildWorkerReplyKeyboard(ctx, chatID)
	replyTo := s.getEmployeeLastGroupBotMessageID(ctx, chatID, empID)
	msgID, err := s.SendTelegramHTMLReplyReturnID(ctx, chatID, html, replyTo, kb)
	if err != nil {
		log.Printf("[Telegram] admin punch group notify failed chat=%s emp=%s: %v", chatID, empID, err)
		return
	}
	if msgID > 0 {
		s.setEmployeeLastGroupBotMessageID(ctx, chatID, empID, msgID)
	}
}

func (s *WorkforceTelegramService) AdminPunchCheckIn(ctx context.Context, empID uuid.UUID, shift string) (*AdminPunchResult, error) {
	tgUID, chatID, actor, empName, err := s.resolveAdminPunchContext(ctx, empID)
	if err != nil {
		return nil, err
	}
	shift = strings.TrimSpace(strings.ToLower(shift))
	if shift == "" {
		shift = "day"
	}
	if _, err = normalizeShiftType(shift); err != nil {
		return nil, err
	}
	outcome, err := s.telegramCheckInWithShift(ctx, empID, tgUID, chatID, shift, actor)
	if err != nil {
		return nil, err
	}
	s.publishAdminPunchGroupReply(ctx, chatID, empID, outcome.GroupReplyHTML)

	msg := fmt.Sprintf("上班打卡成功（%s）", ShiftLabelPublic(outcome.Result.ShiftType))
	if outcome.WorkFine > 0 {
		msg += fmt.Sprintf("，迟到罚款 ¥%.2f", outcome.WorkFine)
	}
	if hint := strings.TrimSpace(outcome.HandoverHint); hint != "" {
		msg += "\n" + hint
	}
	return &AdminPunchResult{
		Result:         outcome.Result,
		EmployeeName:   empName,
		WorkFine:       outcome.WorkFine,
		HandoverHint:   outcome.HandoverHint,
		GroupReplyHTML: outcome.GroupReplyHTML,
		MessageText:    msg,
	}, nil
}

func (s *WorkforceTelegramService) AdminPunchCheckOut(ctx context.Context, empID uuid.UUID, shift string) (*AdminPunchResult, error) {
	tgUID, chatID, actor, empName, err := s.resolveAdminPunchContext(ctx, empID)
	if err != nil {
		return nil, err
	}
	_ = shift // FIFO checkout matches TG bot behavior
	outcome, err := s.telegramCheckOutFIFO(ctx, empID, tgUID, chatID, actor)
	if err != nil {
		return nil, err
	}
	s.publishAdminPunchGroupReply(ctx, chatID, empID, outcome.GroupReplyHTML)

	msg := fmt.Sprintf("下班打卡成功（%s）", ShiftLabelPublic(outcome.ShiftType))
	if outcome.WorkFine > 0 {
		msg += fmt.Sprintf("，早退相关金额 ¥%.2f", outcome.WorkFine)
	}
	if warn := strings.TrimSpace(outcome.ActivityWarn); warn != "" {
		msg += "\n" + warn
	}
	if hint := strings.TrimSpace(outcome.HandoverHint); hint != "" {
		msg += "\n" + hint
	}
	return &AdminPunchResult{
		CheckOut:       outcome.Result,
		EmployeeName:   empName,
		WorkFine:       outcome.WorkFine,
		HandoverHint:   outcome.HandoverHint,
		ActivityWarn:   outcome.ActivityWarn,
		GroupReplyHTML: outcome.GroupReplyHTML,
		MessageText:    msg,
	}, nil
}

func (s *WorkforceTelegramService) AdminPunchStartActivity(ctx context.Context, empID uuid.UUID, activity string) (*TgActivityStartResult, error) {
	if _, _, _, _, err := s.resolveAdminPunchContext(ctx, empID); err != nil {
		return nil, err
	}
	return s.startActivitySessionWithSource(ctx, empID, uuid.Nil, activity, PunchSourceWeb)
}

func (s *WorkforceTelegramService) AdminPunchBackActivity(ctx context.Context, empID uuid.UUID) (*TgActivitySession, error) {
	if _, _, _, _, err := s.resolveAdminPunchContext(ctx, empID); err != nil {
		return nil, err
	}
	session, err := s.getOpenActivitySession(ctx, empID)
	if err != nil {
		return nil, err
	}
	return s.endActivitySessionForEmployee(ctx, session.ID, empID, PunchSourceWeb)
}

package services

import (
	"bytes"
	"context"
	"database/sql"
	"fmt"
	"log"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/xuri/excelize/v2"
)

type tgExportActivityStat struct {
	Count int
	Time  int
}

type tgExportUserStat struct {
	UserID               int64
	Nickname             string
	Shift                string
	WorkDays             int
	WorkStartCount       int
	WorkEndCount         int
	WorkStartAt          *time.Time
	WorkEndAt            *time.Time
	WorkHours            int
	Activities           map[string]tgExportActivityStat
	TotalActivityCount   int
	TotalAccumulatedTime int
	OvertimeCount        int
	TotalOvertimeTime    int
	EarlyCount           int
	LateCount            int
	WorkEndFines         int
	WorkStartFines       int
	TotalFines           int
}

func (s *WorkforceTelegramService) ExportAttendanceXLSX(ctx context.Context, dateFrom, dateTo, chatID string) ([]byte, string, error) {
	dateFrom = strings.TrimSpace(dateFrom)
	dateTo = strings.TrimSpace(dateTo)
	if dateFrom == "" {
		dateFrom = time.Now().Format("2006-01-02")
	}
	if dateTo == "" {
		dateTo = dateFrom
	}

	if err := s.ensureExportAttendanceComplete(ctx, dateFrom, dateTo, chatID); err != nil {
		log.Printf("[Telegram] export attendance prep failed: %v", err)
	}

	stats, activityNames, err := s.buildTelegramExportStats(ctx, dateFrom, dateTo, chatID)
	if err != nil {
		return nil, "", err
	}

	f := excelize.NewFile()
	defer f.Close()
	if err := s.writeTelegramStatsWorkbook(f, stats, activityNames, telegramExportUsePunchTimes(dateFrom, dateTo)); err != nil {
		return nil, "", err
	}

	buf := bytes.NewBuffer(nil)
	if err := f.Write(buf); err != nil {
		return nil, "", err
	}
	filename := exportFilenameSuffix(chatID, dateFrom, dateTo) + ".xlsx"
	return buf.Bytes(), filename, nil
}

func (s *WorkforceTelegramService) buildTelegramExportStats(ctx context.Context, dateFrom, dateTo, chatID string) ([]tgExportUserStat, []string, error) {
	settings, _ := s.GetSettings(ctx)
	dualShift := settings == nil || settings.DualShiftEnabled
	shifts := []string{"day"}
	if dualShift {
		shifts = []string{"day", "night"}
	}

	type userKey struct {
		userID int64
		empID  uuid.UUID
		name   string
	}
	users := make(map[string]userKey)
	chatID = strings.TrimSpace(chatID)
	userQuery := `
		SELECT DISTINCT b.telegram_user_id, b.employee_id, e.name
		FROM employee_telegram_bindings b
		JOIN employees e ON e.id = b.employee_id
		WHERE b.status = 1
		  AND ($1 = '' OR b.chat_id = $1 OR EXISTS (
			SELECT 1 FROM work_sessions ws
			WHERE ws.employee_id = b.employee_id
			  AND ws.source IN ('telegram','agent','web')
			  AND (
				ws.attendance_date BETWEEN $2::date AND $3::date
				OR (ws.checkin_time AT TIME ZONE $4)::date BETWEEN $2::date AND $3::date
			  )
		  ) OR EXISTS (
			SELECT 1 FROM work_sessions_archive wsa
			WHERE wsa.employee_id = b.employee_id
			  AND wsa.source IN ('telegram','agent','web')
			  AND (
				wsa.attendance_date BETWEEN $2::date AND $3::date
				OR (wsa.checkin_time AT TIME ZONE $4)::date BETWEEN $2::date AND $3::date
			  )
		  ) OR EXISTS (
			SELECT 1 FROM wf_tg_activity_sessions s
			WHERE s.employee_id = b.employee_id
			  AND COALESCE(s.source_chat_id,'') = $1
			  AND s.attendance_date BETWEEN $2::date AND $3::date
		  ) OR EXISTS (
			SELECT 1 FROM wf_tg_activity_sessions_archive sa
			WHERE sa.employee_id = b.employee_id
			  AND COALESCE(sa.source_chat_id,'') = $1
			  AND sa.attendance_date BETWEEN $2::date AND $3::date
		  ) OR EXISTS (
			SELECT 1 FROM attendance_records ar
			WHERE ar.employee_id = b.employee_id
			  AND ar.date BETWEEN $2::date AND $3::date
			  AND ar.checkin_time IS NOT NULL
		  ) OR EXISTS (
			SELECT 1 FROM wf_shared_workstation_members m
			JOIN device_telegram_bindings dtb ON dtb.device_id = m.device_id AND dtb.status = 1
			WHERE m.employee_id = b.employee_id AND dtb.chat_id = $1
		  ))
		ORDER BY e.name`
	tz := "Asia/Shanghai"
	if settings != nil && strings.TrimSpace(settings.Timezone) != "" {
		tz = strings.TrimSpace(settings.Timezone)
	}
	loc := tgLoadLocation(tz)
	usePunchTimes := telegramExportUsePunchTimes(dateFrom, dateTo)
	userRows, err := s.db.QueryContext(ctx, userQuery, chatID, dateFrom, dateTo, tz)
	if err != nil {
		return nil, nil, err
	}
	defer userRows.Close()
	for userRows.Next() {
		var tgUID int64
		var empID uuid.UUID
		var name string
		if userRows.Scan(&tgUID, &empID, &name) != nil {
			continue
		}
		users[exportUserKey(empID, tgUID)] = userKey{userID: tgUID, empID: empID, name: name}
	}

	// Weak mode: include employees who punched via web without Telegram binding (admin full export).
	if settings != nil && settings.WebPunchOnly && chatID == "" {
		unboundQuery := `
			SELECT DISTINCT e.id, e.name
			FROM employees e
			WHERE (
				EXISTS (
					SELECT 1 FROM work_sessions ws
					WHERE ws.employee_id = e.id
					  AND ws.source = 'web'
					  AND (
						ws.attendance_date BETWEEN $1::date AND $2::date
						OR (ws.checkin_time AT TIME ZONE $3)::date BETWEEN $1::date AND $2::date
					  )
				) OR EXISTS (
					SELECT 1 FROM work_sessions_archive wsa
					WHERE wsa.employee_id = e.id
					  AND wsa.source = 'web'
					  AND (
						wsa.attendance_date BETWEEN $1::date AND $2::date
						OR (wsa.checkin_time AT TIME ZONE $3)::date BETWEEN $1::date AND $2::date
					  )
				) OR EXISTS (
					SELECT 1 FROM wf_tg_activity_sessions s
					WHERE s.employee_id = e.id
					  AND COALESCE(s.source,'') = 'web'
					  AND s.attendance_date BETWEEN $1::date AND $2::date
				) OR EXISTS (
					SELECT 1 FROM wf_tg_activity_sessions_archive sa
					WHERE sa.employee_id = e.id
					  AND COALESCE(sa.source,'') = 'web'
					  AND sa.attendance_date BETWEEN $1::date AND $2::date
				) OR EXISTS (
					SELECT 1 FROM attendance_records ar
					WHERE ar.employee_id = e.id
					  AND ar.date BETWEEN $1::date AND $2::date
					  AND ar.checkin_time IS NOT NULL
					  AND COALESCE(ar.checkin_source,'') = 'web'
				)
			)
			  AND NOT EXISTS (
				SELECT 1 FROM employee_telegram_bindings b
				WHERE b.employee_id = e.id AND b.status = 1
			)`
		if rows, err := s.db.QueryContext(ctx, unboundQuery, dateFrom, dateTo, tz); err == nil {
			for rows.Next() {
				var empID uuid.UUID
				var name string
				if rows.Scan(&empID, &name) != nil {
					continue
				}
				key := exportUserKey(empID, 0)
				if _, exists := users[key]; exists {
					continue
				}
				users[key] = userKey{userID: 0, empID: empID, name: name}
			}
			rows.Close()
		}
	}

	statMap := make(map[string]*tgExportUserStat)
	for _, u := range users {
		for _, shift := range shifts {
			key := exportStatKey(u.empID, u.userID, shift)
			statMap[key] = &tgExportUserStat{
				UserID:     exportDisplayUserID(u.userID, u.empID),
				Nickname:   u.name,
				Shift:      shift,
				Activities: make(map[string]tgExportActivityStat),
			}
		}
	}

	chatFilter, chatArg := tgExportChatFilter(chatID)
	tzParam := 3
	todayParam := 4
	if chatArg != "" {
		tzParam = 4
		todayParam = 5
	}
	todayDate := time.Now().In(loc).Format("2006-01-02")
	// Live ∪ archive (deduped by id); attendance_records fills days purged before work archive existed.
	// Open sessions: only live + attendance_date=today may use NOW(); archive/historical open contribute 0.
	workQuery := fmt.Sprintf(`
		WITH unioned AS (
			SELECT ws.id,
				ws.employee_id,
				COALESCE(ws.shift_type,'day') AS shift_type,
				ws.attendance_date,
				ws.checkin_time,
				ws.checkout_time,
				COALESCE(ws.status,'closed') AS status,
				ws.source_chat_id,
				ws.is_live
			FROM (
				SELECT id, employee_id, shift_type, attendance_date, checkin_time, checkout_time, status, source_chat_id, source, TRUE AS is_live
				FROM work_sessions
				UNION ALL
				SELECT id, employee_id, shift_type, attendance_date, checkin_time, checkout_time, status, source_chat_id, source, FALSE AS is_live
				FROM work_sessions_archive
			) ws
			WHERE ws.source IN ('telegram','agent','web')
			  AND (
				ws.attendance_date BETWEEN $1::date AND $2::date
				OR (ws.checkin_time AT TIME ZONE $%d)::date BETWEEN $1::date AND $2::date
			  )%s
		),
		sess_raw AS (
			SELECT DISTINCT ON (id)
				id, employee_id, shift_type, attendance_date, checkin_time, checkout_time, status, source_chat_id, is_live
			FROM unioned
			ORDER BY id, is_live DESC
		),
		sess AS (
			SELECT employee_id, shift_type, attendance_date, checkin_time, checkout_time, source_chat_id,
				CASE
					WHEN checkout_time IS NOT NULL THEN checkout_time
					WHEN is_live AND status = 'open' AND attendance_date = $%d::date THEN NOW()
					ELSE NULL
				END AS duration_end
			FROM sess_raw
		),
		ar_fill AS (
			SELECT ar.employee_id,
				COALESCE(NULLIF(TRIM(ar.shift_type), ''), 'day') AS shift_type,
				ar.date AS attendance_date,
				ar.checkin_time,
				ar.checkout_time,
				NULL::varchar AS source_chat_id,
				CASE
					WHEN ar.checkout_time IS NOT NULL THEN ar.checkout_time
					WHEN ar.date = $%d::date THEN NOW()
					ELSE NULL
				END AS duration_end
			FROM attendance_records ar
			WHERE ar.date BETWEEN $1::date AND $2::date
			  AND ar.checkin_time IS NOT NULL
			  AND NOT EXISTS (
				SELECT 1 FROM sess s
				WHERE s.employee_id = ar.employee_id
				  AND s.attendance_date = ar.date
				  AND s.shift_type = COALESCE(NULLIF(TRIM(ar.shift_type), ''), 'day')
			  )%s
		),
		combined AS (
			SELECT employee_id, shift_type, attendance_date, checkin_time, checkout_time, source_chat_id, duration_end FROM sess
			UNION ALL
			SELECT employee_id, shift_type, attendance_date, checkin_time, checkout_time, source_chat_id, duration_end FROM ar_fill
		)
		SELECT c.employee_id, c.shift_type,
			COUNT(DISTINCT CASE WHEN c.duration_end IS NOT NULL THEN c.attendance_date END)::int,
			COUNT(*) FILTER (WHERE c.checkin_time IS NOT NULL AND c.duration_end IS NOT NULL)::int,
			COUNT(*) FILTER (WHERE c.checkout_time IS NOT NULL)::int,
			MIN(c.checkin_time) FILTER (WHERE c.duration_end IS NOT NULL),
			MAX(c.checkout_time),
			COALESCE(SUM(
				CASE
					WHEN c.duration_end IS NOT NULL AND c.duration_end > c.checkin_time
					THEN EXTRACT(EPOCH FROM (c.duration_end - c.checkin_time))
					ELSE 0
				END
			),0)::int
		FROM combined c
		GROUP BY c.employee_id, c.shift_type`, tzParam, chatFilter, todayParam, todayParam, tgExportAttendanceChatFilter(chatID))
	workArgs := []interface{}{dateFrom, dateTo}
	if chatArg != "" {
		workArgs = append(workArgs, chatArg)
	}
	workArgs = append(workArgs, tz, todayDate)
	if rows, err := s.db.QueryContext(ctx, workQuery, workArgs...); err == nil {
		defer rows.Close()
		for rows.Next() {
			var empID uuid.UUID
			var shift string
			var workDays, startCnt, endCnt, workHours int
			var minCheckin sql.NullTime
			var maxCheckout sql.NullTime
			if rows.Scan(&empID, &shift, &workDays, &startCnt, &endCnt, &minCheckin, &maxCheckout, &workHours) != nil {
				continue
			}
			tgUID := s.telegramUserIDForEmployee(ctx, empID)
			st := statMap[exportStatKey(empID, tgUID, shift)]
			if st == nil {
				var name string
				_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, empID).Scan(&name)
				st = &tgExportUserStat{
					UserID:     exportDisplayUserID(tgUID, empID),
					Nickname:   name,
					Shift:      shift,
					Activities: make(map[string]tgExportActivityStat),
				}
				statMap[exportStatKey(empID, tgUID, shift)] = st
			}
			st.WorkDays = workDays
			st.WorkStartCount = startCnt
			st.WorkEndCount = endCnt
			st.WorkHours = workHours
			if usePunchTimes {
				if minCheckin.Valid {
					t := minCheckin.Time.In(loc)
					st.WorkStartAt = &t
				}
				if maxCheckout.Valid {
					t := maxCheckout.Time.In(loc)
					st.WorkEndAt = &t
				}
			}
		}
	}

	actFilter, actArg := tgExportActivityChatFilter(chatID)
	actQuery := fmt.Sprintf(`
		SELECT s.employee_id, COALESCE(s.shift_type,'day'), s.activity_name,
			COUNT(*)::int,
			COALESCE(SUM(s.elapsed_seconds),0)::int,
			COUNT(*) FILTER (WHERE s.overtime_seconds > 0)::int,
			COALESCE(SUM(s.overtime_seconds),0)::int,
			COALESCE(SUM(s.fine_amount),0)::int
		FROM (
			SELECT employee_id, shift_type, activity_name, elapsed_seconds, overtime_seconds, fine_amount,
				status, attendance_date, source_chat_id
			FROM wf_tg_activity_sessions
			UNION ALL
			SELECT employee_id, shift_type, activity_name, elapsed_seconds, overtime_seconds, fine_amount,
				status, attendance_date, source_chat_id
			FROM wf_tg_activity_sessions_archive
		) s
		WHERE s.status = 'closed'
		  AND s.attendance_date BETWEEN $1::date AND $2::date%s
		GROUP BY s.employee_id, COALESCE(s.shift_type,'day'), s.activity_name`, actFilter)
	actArgs := []interface{}{dateFrom, dateTo}
	if actArg != "" {
		actArgs = append(actArgs, actArg)
	}
	activityNameSet := make(map[string]struct{})
	if rows, err := s.db.QueryContext(ctx, actQuery, actArgs...); err == nil {
		defer rows.Close()
		for rows.Next() {
			var empID uuid.UUID
			var shift, actName string
			var count, totalSec, otCount, otSec, actFine int
			if rows.Scan(&empID, &shift, &actName, &count, &totalSec, &otCount, &otSec, &actFine) != nil {
				continue
			}
			tgUID := s.telegramUserIDForEmployee(ctx, empID)
			st := statMap[exportStatKey(empID, tgUID, shift)]
			if st == nil {
				var name string
				_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, empID).Scan(&name)
				st = &tgExportUserStat{
					UserID:     exportDisplayUserID(tgUID, empID),
					Nickname:   name,
					Shift:      shift,
					Activities: make(map[string]tgExportActivityStat),
				}
				statMap[exportStatKey(empID, tgUID, shift)] = st
			}
			actName = strings.TrimSpace(actName)
			if actName != "" {
				activityNameSet[actName] = struct{}{}
				st.Activities[actName] = tgExportActivityStat{Count: count, Time: totalSec}
			}
			st.TotalActivityCount += count
			st.TotalAccumulatedTime += totalSec
			st.OvertimeCount += otCount
			st.TotalOvertimeTime += otSec
			st.TotalFines += actFine
		}
	}

	penaltyQuery := `
		SELECT p.employee_id, p.reason, p.amount
		FROM penalty_records p
		WHERE p.category = 'TG考勤'
		  AND p.penalty_date BETWEEN $1::date AND $2::date`
	penaltyArgs := []interface{}{dateFrom, dateTo}
	if strings.TrimSpace(chatID) != "" {
		penaltyQuery += `
		  AND (` + tgGroupEmployeeBelongsToChatSQL("p.employee_id", "$3") + `)`
		penaltyArgs = append(penaltyArgs, chatID)
	}
	if rows, err := s.db.QueryContext(ctx, penaltyQuery, penaltyArgs...); err == nil {
		defer rows.Close()
		for rows.Next() {
			var empID uuid.UUID
			var reason string
			var amount float64
			if rows.Scan(&empID, &reason, &amount) != nil {
				continue
			}
			tgUID := s.telegramUserIDForEmployee(ctx, empID)
			shift := exportPenaltyShift(reason)
			st := statMap[exportStatKey(empID, tgUID, shift)]
			if st == nil {
				continue
			}
			amt := int(amount + 0.5)
			st.TotalFines += amt
			if strings.Contains(reason, "迟到") {
				st.LateCount++
				st.WorkStartFines += amt
			} else if strings.Contains(reason, "早退") {
				st.EarlyCount++
				st.WorkEndFines += amt
			} else if strings.Contains(reason, "上班") {
				st.WorkStartFines += amt
			} else if strings.Contains(reason, "下班") {
				st.WorkEndFines += amt
			}
		}
	}

	types, _ := s.ListActivityTypes(ctx)
	for _, t := range types {
		name := strings.TrimSpace(t.Name)
		if name != "" {
			activityNameSet[name] = struct{}{}
		}
	}
	activityNames := make([]string, 0, len(activityNameSet))
	for name := range activityNameSet {
		activityNames = append(activityNames, name)
	}
	sort.Strings(activityNames)

	out := make([]tgExportUserStat, 0, len(statMap))
	for _, st := range statMap {
		out = append(out, *st)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Nickname != out[j].Nickname {
			return out[i].Nickname < out[j].Nickname
		}
		return out[i].Shift < out[j].Shift
	})
	return out, activityNames, nil
}

// exportUserKey identifies one employee in export stats. Always keyed by employee_id so
// shared-workstation members with the same Telegram account each get their own row.
func exportUserKey(empID uuid.UUID, _ int64) string {
	return "emp:" + empID.String()
}

func exportStatKey(empID uuid.UUID, tgUID int64, shift string) string {
	return exportUserKey(empID, tgUID) + ":" + shift
}

func exportDisplayUserID(tgUID int64, empID uuid.UUID) int64 {
	if tgUID > 0 {
		return tgUID
	}
	var n uint64
	for _, b := range empID {
		n = n*31 + uint64(b)
	}
	if n == 0 {
		return -1
	}
	return -int64(n % 1_000_000_000)
}

func exportPenaltyShift(reason string) string {
	if strings.Contains(reason, "夜班") {
		return "night"
	}
	return "day"
}

func (s *WorkforceTelegramService) telegramUserIDForEmployee(ctx context.Context, empID uuid.UUID) int64 {
	var tgUID int64
	_ = s.db.QueryRowContext(ctx, `
		SELECT telegram_user_id FROM employee_telegram_bindings
		WHERE employee_id = $1 AND status = 1
		ORDER BY updated_at DESC NULLS LAST LIMIT 1`, empID).Scan(&tgUID)
	return tgUID
}

func formatShiftForExport(shift string) string {
	switch strings.ToLower(strings.TrimSpace(shift)) {
	case "night", "night_last", "night_tonight":
		return "夜班"
	default:
		return "白班"
	}
}

func formatExportValue(value int, isTime bool) string {
	if value <= 0 {
		return "-"
	}
	if isTime {
		return formatDurationForExport(value)
	}
	return strconv.Itoa(value)
}

func formatDurationForExport(seconds int) string {
	if seconds <= 0 {
		return "0分0秒"
	}
	h := seconds / 3600
	m := (seconds % 3600) / 60
	sec := seconds % 60
	if h > 0 {
		return fmt.Sprintf("%d时%d分%d秒", h, m, sec)
	}
	if m > 0 {
		return fmt.Sprintf("%d分%d秒", m, sec)
	}
	return fmt.Sprintf("%d秒", sec)
}

// exportSessionDurationSeconds mirrors export SQL duration rules for unit tests.
// Archive / historical open sessions contribute 0; only live open on today uses now.
func exportSessionDurationSeconds(checkin, checkout time.Time, hasCheckout, isLive, isOpen bool, attendanceDate, today string, now time.Time) int {
	if hasCheckout {
		if !checkout.After(checkin) {
			return 0
		}
		return int(checkout.Sub(checkin).Seconds())
	}
	if isLive && isOpen && strings.TrimSpace(attendanceDate) == strings.TrimSpace(today) {
		if !now.After(checkin) {
			return 0
		}
		return int(now.Sub(checkin).Seconds())
	}
	return 0
}

// telegramExportUsePunchTimes：单日导出（含 TG 日重置前导出）展示打卡时刻；跨日/月汇总仍用次数。
func telegramExportUsePunchTimes(dateFrom, dateTo string) bool {
	dateFrom = strings.TrimSpace(dateFrom)
	dateTo = strings.TrimSpace(dateTo)
	if dateFrom == "" || dateTo == "" {
		return true
	}
	return dateFrom == dateTo
}

func formatExportPunchClock(t *time.Time) string {
	if t == nil || t.IsZero() {
		return "-"
	}
	return t.Format("15:04:05")
}

func telegramExportWorkColumnHeaders(usePunchTimes bool) (startLabel, endLabel string) {
	if usePunchTimes {
		return "上班打卡时间", "下班打卡时间"
	}
	return "上班次数", "下班次数"
}

func telegramExportWorkColumnValues(st tgExportUserStat, usePunchTimes bool) (startVal, endVal string) {
	if usePunchTimes {
		return formatExportPunchClock(st.WorkStartAt), formatExportPunchClock(st.WorkEndAt)
	}
	return formatExportValue(st.WorkStartCount, false), formatExportValue(st.WorkEndCount, false)
}

func exportRowEmpty(row []string) bool {
	for i, v := range row {
		if i <= 2 {
			continue
		}
		if v != "-" {
			return false
		}
	}
	return true
}

func (s *WorkforceTelegramService) writeTelegramStatsWorkbook(f *excelize.File, stats []tgExportUserStat, activityNames []string, usePunchTimes bool) error {
	sheet := "打卡统计"
	_ = f.SetSheetName("Sheet1", sheet)

	startLabel, endLabel := telegramExportWorkColumnHeaders(usePunchTimes)
	headers := []string{"用户ID", "用户昵称", "班次", "工作天数", startLabel, endLabel, "工作时长"}
	for _, act := range activityNames {
		headers = append(headers, act+"次数", act+"总时长")
	}
	headers = append(headers,
		"活动次数总计", "活动用时总计", "超时次数", "超时时长",
		"早退次数", "迟到次数", "下班罚款", "上班罚款", "罚款总金额",
	)

	headerStyle, _ := f.NewStyle(&excelize.Style{
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"4472C4"}, Pattern: 1},
		Font:      &excelize.Font{Color: "FFFFFF", Bold: true, Size: 11},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
		Border: []excelize.Border{
			{Type: "left", Color: "000000", Style: 1},
			{Type: "right", Color: "000000", Style: 1},
			{Type: "top", Color: "000000", Style: 1},
			{Type: "bottom", Color: "000000", Style: 1},
		},
	})
	dataStyle, _ := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Size: 10},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
		Border: []excelize.Border{
			{Type: "left", Color: "000000", Style: 1},
			{Type: "right", Color: "000000", Style: 1},
			{Type: "top", Color: "000000", Style: 1},
			{Type: "bottom", Color: "000000", Style: 1},
		},
	})
	fineStyle, _ := f.NewStyle(&excelize.Style{
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"FFEB9C"}, Pattern: 1},
		Font:      &excelize.Font{Size: 10},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
		Border: []excelize.Border{
			{Type: "left", Color: "000000", Style: 1},
			{Type: "right", Color: "000000", Style: 1},
			{Type: "top", Color: "000000", Style: 1},
			{Type: "bottom", Color: "000000", Style: 1},
		},
	})
	noFineStyle, _ := f.NewStyle(&excelize.Style{
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"C6EFCE"}, Pattern: 1},
		Font:      &excelize.Font{Size: 10},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
		Border: []excelize.Border{
			{Type: "left", Color: "000000", Style: 1},
			{Type: "right", Color: "000000", Style: 1},
			{Type: "top", Color: "000000", Style: 1},
			{Type: "bottom", Color: "000000", Style: 1},
		},
	})
	emptyStyle, _ := f.NewStyle(&excelize.Style{
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"FFC7CE"}, Pattern: 1},
		Font:      &excelize.Font{Size: 10},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
		Border: []excelize.Border{
			{Type: "left", Color: "000000", Style: 1},
			{Type: "right", Color: "000000", Style: 1},
			{Type: "top", Color: "000000", Style: 1},
			{Type: "bottom", Color: "000000", Style: 1},
		},
	})

	for col, header := range headers {
		cell, _ := excelize.CoordinatesToCellName(col+1, 1)
		_ = f.SetCellValue(sheet, cell, header)
		_ = f.SetCellStyle(sheet, cell, cell, headerStyle)
	}
	_ = f.SetRowHeight(sheet, 1, 21)

	for rowIdx, st := range stats {
		rowNum := rowIdx + 2
		totalFines := formatExportValue(st.TotalFines, false)
		hasFine := totalFines != "-" && totalFines != "0"
		startVal, endVal := telegramExportWorkColumnValues(st, usePunchTimes)

		row := []string{
			strconv.FormatInt(st.UserID, 10),
			st.Nickname,
			formatShiftForExport(st.Shift),
			formatExportValue(st.WorkDays, false),
			startVal,
			endVal,
			formatExportValue(st.WorkHours, true),
		}
		for _, act := range activityNames {
			info := st.Activities[act]
			row = append(row,
				formatExportValue(info.Count, false),
				formatExportValue(info.Time, true),
			)
		}
		row = append(row,
			formatExportValue(st.TotalActivityCount, false),
			formatExportValue(st.TotalAccumulatedTime, true),
			formatExportValue(st.OvertimeCount, false),
			formatExportValue(st.TotalOvertimeTime, true),
			formatExportValue(st.EarlyCount, false),
			formatExportValue(st.LateCount, false),
			formatExportValue(st.WorkEndFines, false),
			formatExportValue(st.WorkStartFines, false),
			totalFines,
		)

		rowStyle := dataStyle
		switch {
		case exportRowEmpty(row):
			rowStyle = emptyStyle
		case hasFine:
			rowStyle = fineStyle
		default:
			rowStyle = noFineStyle
		}

		for col, value := range row {
			cell, _ := excelize.CoordinatesToCellName(col+1, rowNum)
			_ = f.SetCellValue(sheet, cell, value)
			_ = f.SetCellStyle(sheet, cell, cell, rowStyle)
		}
		_ = f.SetRowHeight(sheet, rowNum, 21)
	}

	for col := 1; col <= len(headers); col++ {
		colName, _ := excelize.ColumnNumberToName(col)
		_ = f.SetColWidth(sheet, colName, colName, 12)
	}
	_ = f.SetPanes(sheet, &excelize.Panes{Freeze: true, YSplit: 1, TopLeftCell: "A2", ActivePane: "bottomLeft"})
	return nil
}

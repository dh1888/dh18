const STORAGE_KEY = "screen_lock_account";

/** Session lock flag keyed by login username. */
export function isScreenLockedForUser(accountKey: string | undefined | null): boolean {
  if (!accountKey) return false;
  try {
    return sessionStorage.getItem(STORAGE_KEY) === accountKey;
  } catch {
    return false;
  }
}

export function setScreenLocked(accountKey: string) {
  try {
    sessionStorage.setItem(STORAGE_KEY, accountKey);
  } catch {
    // ignore
  }
}

export function clearScreenLocked() {
  try {
    sessionStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}

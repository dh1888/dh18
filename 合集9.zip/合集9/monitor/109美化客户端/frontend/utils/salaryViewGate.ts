import { ElMessage, ElMessageBox } from "element-plus";
import adminApi from "@api/admin_api";

const SALARY_VIEW_UNLOCK_HEADER = "X-Salary-View-Unlock";

let unlockToken: string | null = null;

export function getSalaryViewUnlockToken(): string | null {
  return unlockToken;
}

export function getSalaryViewUnlockHeaderName(): string {
  return SALARY_VIEW_UNLOCK_HEADER;
}

export function setSalaryViewUnlockToken(token: string | null) {
  unlockToken = token?.trim() ? token.trim() : null;
}

export function clearSalaryViewUnlock() {
  unlockToken = null;
}

async function promptPassword(title: string, message: string): Promise<string | null> {
  try {
    const { value } = await ElMessageBox.prompt(message, title, {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      inputType: "password",
      inputPlaceholder: "请输入密码",
      showInput: true,
      closeOnClickModal: false,
      closeOnPressEscape: false,
    });
    const pwd = (value ?? "").trim();
    return pwd || null;
  } catch {
    return null;
  }
}

async function promptSetupPassword(): Promise<boolean> {
  const pwd = await promptPassword(
    "设置工资查看密码",
    "首次进入工资查看，请设置独立密码（至少 6 位）",
  );
  if (!pwd) {
    return false;
  }
  if (pwd.length < 6) {
    ElMessage.warning("密码至少 6 位");
    return false;
  }
  const confirm = await promptPassword("确认密码", "请再次输入工资查看密码");
  if (!confirm) {
    return false;
  }
  if (pwd !== confirm) {
    ElMessage.error("两次输入的密码不一致");
    return false;
  }
  try {
    const res = await adminApi.setupSalaryViewPassword({ password: pwd });
    const token = (res.data as { unlockToken?: string })?.unlockToken;
    if (token) {
      setSalaryViewUnlockToken(token);
      ElMessage.success("工资查看密码设置成功");
      return true;
    }
    ElMessage.error("设置失败，请重试");
    return false;
  } catch (e: any) {
    ElMessage.error(e?.message || "设置失败");
    return false;
  }
}

async function promptVerifyPassword(): Promise<boolean> {
  const pwd = await promptPassword(
    "验证工资查看密码",
    "请输入工资查看密码以继续",
  );
  if (!pwd) {
    return false;
  }
  try {
    const res = await adminApi.verifySalaryViewPassword({ password: pwd });
    const token = (res.data as { unlockToken?: string })?.unlockToken;
    if (token) {
      setSalaryViewUnlockToken(token);
      return true;
    }
    ElMessage.error("验证失败，请重试");
    return false;
  } catch {
    ElMessage.error("密码不正确");
    return false;
  }
}

/** Returns true when the user may open the salary view page. */
export async function ensureSalaryViewAccess(): Promise<boolean> {
  clearSalaryViewUnlock();
  try {
    const res = await adminApi.getSalaryViewGateStatus();
    const configured = Boolean((res.data as { configured?: boolean })?.configured);
    if (!configured) {
      return promptSetupPassword();
    }
    return promptVerifyPassword();
  } catch (e: any) {
    ElMessage.error(e?.message || "无法校验工资查看权限");
    return false;
  }
}

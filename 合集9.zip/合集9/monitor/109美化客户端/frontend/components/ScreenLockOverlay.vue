<template>
  <Teleport to="body">
    <div v-if="visible" class="screen-lock-overlay">
      <div class="screen-lock-panel">
        <div class="screen-lock-icon-wrap">
          <el-icon :size="40"><Lock /></el-icon>
        </div>
        <h2 class="screen-lock-title">界面已锁定</h2>
        <p class="screen-lock-subtitle">{{ username || "当前用户" }}</p>
        <el-form @submit.prevent="submitUnlock">
          <el-input
            ref="passwordInputRef"
            v-model="password"
            type="password"
            show-password
            placeholder="请输入锁屏密码"
            size="large"
            class="screen-lock-input"
            :disabled="loading"
            @keyup.enter="submitUnlock"
          />
          <el-button
            type="primary"
            size="large"
            class="screen-lock-btn"
            :loading="loading"
            @click="submitUnlock"
          >
            解锁
          </el-button>
        </el-form>
        <p v-if="errorMessage" class="screen-lock-error">{{ errorMessage }}</p>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, watch, nextTick } from "vue";
import { Lock } from "@element-plus/icons-vue";
import { userApi } from "@api/index";
import { clearScreenLocked } from "@/utils/screenLock";

const props = defineProps<{
  visible: boolean;
  username?: string;
}>();

const emit = defineEmits<{
  unlocked: [];
}>();

const password = ref("");
const loading = ref(false);
const errorMessage = ref("");
const passwordInputRef = ref();

watch(
  () => props.visible,
  (v) => {
    if (v) {
      password.value = "";
      errorMessage.value = "";
      nextTick(() => {
        passwordInputRef.value?.focus?.();
      });
    }
  },
);

async function submitUnlock() {
  if (loading.value) return;
  const pwd = password.value.trim();
  if (!pwd) {
    errorMessage.value = "请输入锁屏密码";
    return;
  }
  loading.value = true;
  errorMessage.value = "";
  try {
    await userApi.verifyScreenLockPassword({ password: pwd });
    clearScreenLocked();
    password.value = "";
    emit("unlocked");
  } catch (e: any) {
    errorMessage.value = e?.message || "解锁失败";
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
.screen-lock-overlay {
  position: fixed;
  inset: 0;
  z-index: 10000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(15, 23, 42, 0.92);
  backdrop-filter: blur(8px);
}

.screen-lock-panel {
  width: min(400px, 92vw);
  padding: 40px 32px 32px;
  text-align: center;
  background: var(--el-bg-color);
  border-radius: 16px;
  box-shadow: 0 24px 48px rgba(0, 0, 0, 0.35);
}

.screen-lock-icon-wrap {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 72px;
  height: 72px;
  margin-bottom: 16px;
  color: var(--el-color-primary);
  background: var(--el-color-primary-light-9);
  border-radius: 50%;
}

.screen-lock-title {
  margin: 0 0 8px;
  font-size: 22px;
  font-weight: 600;
  color: var(--el-text-color-primary);
}

.screen-lock-subtitle {
  margin: 0 0 24px;
  font-size: 14px;
  color: var(--el-text-color-secondary);
}

.screen-lock-input {
  margin-bottom: 16px;
}

.screen-lock-btn {
  width: 100%;
}

.screen-lock-error {
  margin: 12px 0 0;
  font-size: 13px;
  color: var(--el-color-danger);
}
</style>

// UI/ModernTrayMenuForm.cs — modern 2-level tray menu with hover flyouts
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace EnterpriseAgent.Agent.UI;

internal enum TrayMenuItemKind
{
    Header,
    Separator,
    Action,
    Toggle,
    Navigate,
}

internal sealed class TrayMenuItemModel
{
    public string Id { get; init; } = "";
    public TrayMenuItemKind Kind { get; init; }
    public string Text { get; set; } = "";
    /// <summary>Optional second line (e.g. bound Telegram handle under employee).</summary>
    public string SubText { get; set; } = "";
    public bool Visible { get; set; } = true;
    public bool Enabled { get; set; } = true;
    public bool Checked { get; set; }
    public Color? Accent { get; set; }
    public Action? OnClick { get; init; }
}

internal sealed class ModernTrayMenuForm : Form, IMessageFilter
{
    private const int MenuWidth = 320;
    private const int FlyoutWidth = 300;
    private const int RowHeight = 34;
    private const int HeaderRowHeight = 40;
    private const int HeaderRowHeightTall = 56;
    private const int PadX = 10;
    private const int CornerRadius = 12;
    // Extra beyond measured content — only enough so rounded Region does not clip last row.
    private const int BottomSafePad = 4;
    private const int BodyPad = 8;

    private static readonly Color Bg = Color.White;
    private static readonly Color HeaderBg = Color.FromArgb(243, 246, 250);
    private static readonly Color HoverBg = Color.FromArgb(232, 240, 254);
    private static readonly Color DisabledBg = Color.FromArgb(248, 249, 251);
    private static readonly Color Border = Color.FromArgb(226, 230, 236);
    private static readonly Color BorderSoft = Color.FromArgb(236, 239, 243);
    private static readonly Color TextPrimary = Color.FromArgb(31, 41, 55);
    private static readonly Color TextMuted = Color.FromArgb(107, 114, 128);
    private static readonly Color TextDisabled = Color.FromArgb(168, 175, 186);
    private static readonly Color Sep = Color.FromArgb(229, 233, 240);
    private static readonly Color Check = Color.FromArgb(22, 163, 74);
    private static readonly Color CheckDisabled = Color.FromArgb(190, 198, 208);

    private static readonly Font ItemFont = new("Segoe UI", 9.25f, FontStyle.Regular);
    private static readonly Font MarkFont = new("Segoe UI", 10f, FontStyle.Bold);
    private static readonly Font ChevronFont = new("Segoe UI", 14f, FontStyle.Regular);
    private static readonly Font HeaderTitleFont = new("Segoe UI Semibold", 9f, FontStyle.Bold);
    private static readonly Font HeaderSubFont = new("Segoe UI", 8.25f, FontStyle.Regular);

    private readonly BufferedPanel _chrome;
    private readonly BufferedPanel _body;
    private readonly Label _titleLabel;
    private readonly BufferedFlowLayoutPanel _list;
    private readonly DropShadowForm _flyout;
    private readonly BufferedPanel _flyoutChrome;
    private readonly BufferedPanel _flyoutBody;
    private readonly Label _flyoutTitleLabel;
    private readonly BufferedFlowLayoutPanel _flyoutList;
    private readonly System.Windows.Forms.Timer _flyoutHideTimer;

    private IReadOnlyList<TrayMenuItemModel> _root = Array.Empty<TrayMenuItemModel>();
    private IReadOnlyList<TrayMenuItemModel> _settings = Array.Empty<TrayMenuItemModel>();
    private IReadOnlyList<TrayMenuItemModel> _languages = Array.Empty<TrayMenuItemModel>();
    private string _rootTitle = "DHPG";
    private string _settingsTitle = "设置";
    private string _languageTitle = "语言";
    private string? _openFlyoutId;
    private Control? _flyoutAnchor;
    private bool _suppressDeactivateHide;
    private bool _pointerInFlyout;
    private bool _pointerInAnchor;
    private bool _messageFilterAdded;
    private bool _mouseHookActive;
    private IntPtr _mouseHook = IntPtr.Zero;
    private LowLevelMouseProc? _mouseProc;
    private int _appliedWidth;
    private int _appliedHeight;

    public ModernTrayMenuForm()
    {
        Text = "TrayMenu";
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        BackColor = Bg;
        AutoScaleMode = AutoScaleMode.Dpi;
        DoubleBuffered = true;
        Width = MenuWidth;
        Padding = Padding.Empty;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);

        _chrome = new BufferedPanel
        {
            Dock = DockStyle.Fill,
            BackColor = Bg,
            Padding = new Padding(2),
        };
        _chrome.Paint += (_, e) => PaintChrome(e, _chrome);

        _body = new BufferedPanel
        {
            Dock = DockStyle.Fill,
            BackColor = Bg,
            Padding = new Padding(BodyPad),
        };

        var header = new BufferedPanel
        {
            Dock = DockStyle.Top,
            Height = 36,
            BackColor = Bg,
        };

        _titleLabel = new Label
        {
            AutoSize = false,
            Text = _rootTitle,
            Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold),
            ForeColor = TextPrimary,
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            BackColor = Bg,
        };
        header.Controls.Add(_titleLabel);

        _list = new BufferedFlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoScroll = false,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Bg,
            Padding = Padding.Empty,
            Margin = Padding.Empty,
        };

        _body.Controls.Add(_list);
        _body.Controls.Add(header);
        _chrome.Controls.Add(_body);
        Controls.Add(_chrome);

        _flyout = new DropShadowForm
        {
            FormBorderStyle = FormBorderStyle.None,
            ShowInTaskbar = false,
            StartPosition = FormStartPosition.Manual,
            TopMost = true,
            BackColor = Bg,
            Width = FlyoutWidth,
            AutoScaleMode = AutoScaleMode.Dpi,
        };

        _flyoutChrome = new BufferedPanel
        {
            Dock = DockStyle.Fill,
            BackColor = Bg,
            Padding = new Padding(2),
        };
        _flyoutChrome.Paint += (_, e) => PaintChrome(e, _flyoutChrome);

        _flyoutBody = new BufferedPanel
        {
            Dock = DockStyle.Fill,
            BackColor = Bg,
            Padding = new Padding(BodyPad),
        };

        var flyoutHeader = new BufferedPanel
        {
            Dock = DockStyle.Top,
            Height = 36,
            BackColor = Bg,
        };
        _flyoutTitleLabel = new Label
        {
            AutoSize = false,
            Text = _settingsTitle,
            Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold),
            ForeColor = TextPrimary,
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            BackColor = Bg,
        };
        flyoutHeader.Controls.Add(_flyoutTitleLabel);

        _flyoutList = new BufferedFlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoScroll = false,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Bg,
            Padding = Padding.Empty,
            Margin = Padding.Empty,
        };
        _flyoutBody.Controls.Add(_flyoutList);
        _flyoutBody.Controls.Add(flyoutHeader);
        _flyoutChrome.Controls.Add(_flyoutBody);
        _flyout.Controls.Add(_flyoutChrome);

        void MarkFlyoutEnter()
        {
            _pointerInFlyout = true;
            CancelHideFlyout();
        }

        void MarkFlyoutLeave()
        {
            _pointerInFlyout = false;
            ScheduleHideFlyout();
        }

        _flyout.MouseEnter += (_, _) => MarkFlyoutEnter();
        _flyout.MouseLeave += (_, _) => MarkFlyoutLeave();
        _flyoutChrome.MouseEnter += (_, _) => MarkFlyoutEnter();
        _flyoutBody.MouseEnter += (_, _) => MarkFlyoutEnter();
        _flyoutList.MouseEnter += (_, _) => MarkFlyoutEnter();
        _flyoutTitleLabel.MouseEnter += (_, _) => MarkFlyoutEnter();

        _flyoutHideTimer = new System.Windows.Forms.Timer { Interval = 220 };
        _flyoutHideTimer.Tick += (_, _) =>
        {
            _flyoutHideTimer.Stop();
            if (!_pointerInFlyout && !_pointerInAnchor)
                HideFlyout();
        };

        KeyPreview = true;
        KeyDown += (_, e) =>
        {
            if (e.KeyCode != Keys.Escape) return;
            if (_flyout.Visible)
                HideFlyout();
            else
                HideMenu();
        };

        Resize += (_, _) => ApplyRoundedRegion(this, CornerRadius, ref _appliedWidth, ref _appliedHeight, force: false);
        HandleCreated += (_, _) => ApplyRoundedRegion(this, CornerRadius, ref _appliedWidth, ref _appliedHeight, force: true);
        // Flyout manages its own rounded region (ShowWithoutActivation otherwise drops Region).
        _flyout.CornerRadius = CornerRadius;

        VisibleChanged += (_, _) =>
        {
            if (Visible)
                InstallOutsideClickWatch(true);
            else
                InstallOutsideClickWatch(false);
        };
    }

    protected override CreateParams CreateParams
    {
        get
        {
            var cp = base.CreateParams;
            cp.ClassStyle |= 0x00020000; // CS_DROPSHADOW
            return cp;
        }
    }

    protected override void OnPaintBackground(PaintEventArgs e)
    {
        using var brush = new SolidBrush(Bg);
        e.Graphics.FillRectangle(brush, ClientRectangle);
    }

    public void SetTitles(string root, string settings, string language)
    {
        _rootTitle = root;
        _settingsTitle = settings;
        _languageTitle = language;
        _titleLabel.Text = _rootTitle;
        if (_openFlyoutId == "nav.settings")
            _flyoutTitleLabel.Text = _settingsTitle;
        else if (_openFlyoutId == "nav.language")
            _flyoutTitleLabel.Text = _languageTitle;
    }

    public void SetModel(
        IReadOnlyList<TrayMenuItemModel> root,
        IReadOnlyList<TrayMenuItemModel> settings,
        IReadOnlyList<TrayMenuItemModel> languages)
    {
        _root = root;
        _settings = settings;
        _languages = languages;
    }

    public void SoftRefreshHeaders(
        string statusText,
        Color statusAccent,
        string employeeText,
        Color employeeAccent,
        string? employeeSubText = null)
    {
        var sub = employeeSubText ?? "";
        foreach (Control c in _list.Controls)
        {
            if (c.Tag is not TrayMenuItemModel model)
                continue;

            if (model.Id == "status")
            {
                if (model.Text == statusText && AccentEquals(model.Accent, statusAccent))
                    continue;
                model.Text = statusText;
                model.SubText = "";
                model.Accent = statusAccent;
                c.Invalidate();
            }
            else if (model.Id == "employee")
            {
                if (model.Text == employeeText
                    && model.SubText == sub
                    && AccentEquals(model.Accent, employeeAccent))
                    continue;
                model.Text = employeeText;
                model.SubText = sub;
                model.Accent = employeeAccent;
                // Employee row stays tall — never resize here (avoids layout flicker).
                if (c.Height != HeaderRowHeightTall)
                    c.Height = HeaderRowHeightTall;
                c.Invalidate();
            }
        }
    }

    private static bool AccentEquals(Color? a, Color b) =>
        a.HasValue && a.Value.ToArgb() == b.ToArgb();

    private static int HeaderHeightFor(TrayMenuItemModel item) =>
        // Keep employee row height stable so TG subtext arrival does not reflow the menu.
        item.Id == "employee" ? HeaderRowHeightTall : HeaderRowHeight;

    public void ShowNear(Point screenPoint)
    {
        HideFlyout();
        RenderRoot(force: true);

        var screen = Screen.FromPoint(screenPoint).WorkingArea;
        var x = screenPoint.X - Width + 8;
        var y = screenPoint.Y - Height - 8;
        if (x < screen.Left) x = screen.Left + 8;
        if (y < screen.Top) y = screenPoint.Y + 8;
        if (x + Width > screen.Right) x = screen.Right - Width - 8;
        if (y + Height > screen.Bottom) y = screen.Bottom - Height - 8;

        Location = new Point(x, y);
        if (!Visible)
            Show();
        else
        {
            BringToFront();
            Activate();
        }
        InstallOutsideClickWatch(true);
    }

    public void HideMenu()
    {
        HideFlyout();
        InstallOutsideClickWatch(false);
        if (Visible)
            Hide();
    }

    public void RefreshIfVisible()
    {
        if (Visible)
            RenderRoot(force: true);
    }

    public void RebuildVisible()
    {
        if (!Visible)
            return;
        var keepFlyout = _openFlyoutId;
        RenderRoot(force: true);
        if (keepFlyout == null)
            return;

        foreach (Control c in _list.Controls)
        {
            if (c.Tag is TrayMenuItemModel m && m.Id == keepFlyout)
            {
                ShowFlyout(keepFlyout, c, forceRebuild: true);
                break;
            }
        }
    }

    public bool PreFilterMessage(ref Message m)
    {
        if (!Visible)
            return false;

        if (m.Msg is 0x0201 or 0x0204 or 0x0207 or 0x00A1 or 0x00A4)
        {
            if (!IsPointOnMenuUi(Control.MousePosition))
                BeginInvoke(HideMenu);
        }
        return false;
    }

    protected override void OnDeactivate(EventArgs e)
    {
        base.OnDeactivate(e);
        if (_suppressDeactivateHide)
            return;

        BeginInvoke(new Action(() =>
        {
            if (_suppressDeactivateHide || !Visible)
                return;
            if (IsPointOnMenuUi(Control.MousePosition))
                return;
            HideMenu();
        }));
    }

    protected override void WndProc(ref Message m)
    {
        // App lost activation (clicked another process / desktop) → close menu.
        if (m.Msg == 0x001C /* WM_ACTIVATEAPP */ && m.WParam == IntPtr.Zero && Visible)
            BeginInvoke(HideMenu);
        base.WndProc(ref m);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            InstallOutsideClickWatch(false);
            _flyoutHideTimer.Stop();
            _flyoutHideTimer.Dispose();
            _flyout.Dispose();
        }
        base.Dispose(disposing);
    }

    private bool IsPointOnMenuUi(Point screenPoint) =>
        Bounds.Contains(screenPoint) || (_flyout.Visible && _flyout.Bounds.Contains(screenPoint));

    private void InstallOutsideClickWatch(bool enable)
    {
        // WinForms filter: clicks inside this app but outside the menu.
        if (enable && !_messageFilterAdded)
        {
            Application.AddMessageFilter(this);
            _messageFilterAdded = true;
        }
        else if (!enable && _messageFilterAdded)
        {
            Application.RemoveMessageFilter(this);
            _messageFilterAdded = false;
        }

        // Low-level hook: clicks on desktop / other apps (tray menus need this).
        if (enable)
            InstallMouseHook();
        else
            UninstallMouseHook();
    }

    private void InstallMouseHook()
    {
        if (_mouseHookActive)
            return;
        _mouseProc = MouseHookCallback;
        using var curProcess = System.Diagnostics.Process.GetCurrentProcess();
        using var curModule = curProcess.MainModule!;
        _mouseHook = SetWindowsHookEx(14 /* WH_MOUSE_LL */, _mouseProc, GetModuleHandle(curModule.ModuleName), 0);
        _mouseHookActive = _mouseHook != IntPtr.Zero;
    }

    private void UninstallMouseHook()
    {
        if (!_mouseHookActive)
            return;
        if (_mouseHook != IntPtr.Zero)
        {
            UnhookWindowsHookEx(_mouseHook);
            _mouseHook = IntPtr.Zero;
        }
        _mouseProc = null;
        _mouseHookActive = false;
    }

    private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0 && Visible)
        {
            var msg = wParam.ToInt32();
            // WM_LBUTTONDOWN / RBUTTONDOWN / MBUTTONDOWN / NCLBUTTONDOWN
            if (msg is 0x0201 or 0x0204 or 0x0207 or 0x00A1)
            {
                var info = Marshal.PtrToStructure<MsllHookStruct>(lParam);
                var pt = new Point(info.pt.x, info.pt.y);
                if (!IsPointOnMenuUi(pt))
                {
                    try
                    {
                        BeginInvoke(HideMenu);
                    }
                    catch
                    {
                        // ignore if handle gone
                    }
                }
            }
        }
        return CallNextHookEx(_mouseHook, nCode, wParam, lParam);
    }

    private void RenderRoot(bool force = false)
    {
        _titleLabel.Text = _rootTitle;
        SetRedraw(this, false);
        SuspendLayout();
        try
        {
            PopulateList(_list, _root.Where(i => i.Visible).ToList(), MenuWidth - 28, isFlyout: false);
            Height = MeasureListHeight(_root.Where(i => i.Visible), includeTitle: true) + BottomSafePad;
            Width = MenuWidth;
            ApplyRoundedRegion(this, CornerRadius, ref _appliedWidth, ref _appliedHeight, force);
        }
        finally
        {
            ResumeLayout(true);
            SetRedraw(this, true);
            Invalidate(true);
            Update();
        }
    }

    private void ShowFlyout(string id, Control anchor, bool forceRebuild = false)
    {
        CancelHideFlyout();
        _pointerInAnchor = true;
        _flyoutAnchor = anchor;

        if (!forceRebuild && _flyout.Visible && string.Equals(_openFlyoutId, id, StringComparison.Ordinal))
            return;

        var items = id switch
        {
            "nav.settings" => _settings,
            "nav.language" => _languages,
            _ => Array.Empty<TrayMenuItemModel>(),
        };
        var visible = items.Where(i => i.Visible).ToList();
        if (visible.Count == 0)
        {
            HideFlyout();
            return;
        }

        _openFlyoutId = id;
        _flyoutTitleLabel.Text = id == "nav.language" ? _languageTitle : _settingsTitle;

        SetRedraw(_flyout, false);
        try
        {
            PopulateList(_flyoutList, visible, FlyoutWidth - 28, isFlyout: true);
            _flyout.Width = FlyoutWidth;
            // Same chrome as main: title + body padding + safe bottom.
            _flyout.Height = MeasureListHeight(visible, includeTitle: true) + BottomSafePad;

            var anchorScreen = anchor.RectangleToScreen(anchor.ClientRectangle);
            var screen = Screen.FromControl(this).WorkingArea;
            var x = Right - 4;
            if (x + _flyout.Width > screen.Right)
                x = Left - _flyout.Width + 4;
            if (x < screen.Left)
                x = screen.Left + 4;

            var y = anchorScreen.Top - 8;
            if (y + _flyout.Height > screen.Bottom)
                y = screen.Bottom - _flyout.Height - 4;
            if (y < screen.Top)
                y = screen.Top + 4;

            _flyout.Location = new Point(x, y);
        }
        finally
        {
            SetRedraw(_flyout, true);
        }

        if (!_flyout.Visible)
            _flyout.Show(this);
        else
        {
            _flyout.Invalidate(true);
            _flyout.Update();
        }

        // Region must be applied after the window is visible — ShowWithoutActivation
        // otherwise leaves a square frame until the next resize.
        _flyout.ApplyRoundedRegionNow(force: true);
        _flyout.Invalidate(true);
        _flyout.Update();
    }

    private void HideFlyout()
    {
        CancelHideFlyout();
        _openFlyoutId = null;
        _flyoutAnchor = null;
        _pointerInFlyout = false;
        _pointerInAnchor = false;
        if (_flyout.Visible)
            _flyout.Hide();
    }

    private void ScheduleHideFlyout() =>
        BeginInvoke(new Action(() =>
        {
            _flyoutHideTimer.Stop();
            _flyoutHideTimer.Start();
        }));

    private void CancelHideFlyout()
    {
        _flyoutHideTimer.Stop();
    }

    private static int MeasureListHeight(IEnumerable<TrayMenuItemModel> items, bool includeTitle)
    {
        // title + chrome border(1*2) + body padding
        var h = includeTitle
            ? 36 + 2 + BodyPad * 2
            : 2 + BodyPad * 2;
        foreach (var item in items)
        {
            h += item.Kind switch
            {
                TrayMenuItemKind.Separator => 10 + 2,
                TrayMenuItemKind.Header => HeaderHeightFor(item) + 2,
                _ => RowHeight + 2,
            };
        }
        return Math.Max(includeTitle ? 96 : 48, h);
    }

    private void PopulateList(BufferedFlowLayoutPanel list, List<TrayMenuItemModel> items, int rowWidth, bool isFlyout)
    {
        list.SuspendLayout();
        list.Controls.Clear();
        foreach (var item in items)
            list.Controls.Add(CreateRow(item, rowWidth, isFlyout));
        list.ResumeLayout(true);
    }

    private Control CreateRow(TrayMenuItemModel item, int rowWidth, bool isFlyout)
    {
        if (item.Kind == TrayMenuItemKind.Separator)
        {
            var sepHost = new BufferedPanel
            {
                Width = rowWidth,
                Height = 10,
                Margin = new Padding(2, 1, 2, 1),
                BackColor = Bg,
            };
            sepHost.Paint += (_, e) =>
            {
                e.Graphics.Clear(Bg);
                using var pen = new Pen(Sep);
                var y = sepHost.Height / 2;
                e.Graphics.DrawLine(pen, 8, y, sepHost.Width - 8, y);
            };
            return sepHost;
        }

        var h = item.Kind == TrayMenuItemKind.Header ? HeaderHeightFor(item) : RowHeight;
        var interactive = item.Kind is TrayMenuItemKind.Action or TrayMenuItemKind.Toggle or TrayMenuItemKind.Navigate;
        var row = new MenuRowPanel
        {
            Width = rowWidth,
            Height = h,
            Margin = new Padding(2, 1, 2, 1),
            BackColor = Bg,
            Cursor = interactive && item.Enabled ? Cursors.Hand : Cursors.Default,
            Tag = item,
        };

        if (item.Kind == TrayMenuItemKind.Header)
        {
            row.Paint += (_, e) => PaintHeaderRow(e.Graphics, row, item);
            return row;
        }

        row.Paint += (_, e) => PaintItemRow(e.Graphics, row, item);

        void InvokeItem()
        {
            if (!item.Enabled)
                return;

            if (item.Kind == TrayMenuItemKind.Navigate)
            {
                ShowFlyout(item.Id, row);
                return;
            }

            if (item.Kind is TrayMenuItemKind.Action or TrayMenuItemKind.Toggle)
            {
                _suppressDeactivateHide = true;
                try
                {
                    HideMenu();
                    item.OnClick?.Invoke();
                }
                finally
                {
                    _suppressDeactivateHide = false;
                }
            }
        }

        void SetHover(bool hover)
        {
            if (row.Hovered == hover)
                return;
            row.Hovered = hover;
            row.Invalidate();
        }

        row.MouseEnter += (_, _) =>
        {
            SetHover(true);
            if (item.Kind == TrayMenuItemKind.Navigate && item.Enabled)
            {
                _pointerInAnchor = true;
                CancelHideFlyout();
                ShowFlyout(item.Id, row);
            }
            else if (!isFlyout && item.Kind is not TrayMenuItemKind.Navigate)
            {
                _pointerInAnchor = false;
                ScheduleHideFlyout();
            }
            else if (isFlyout)
            {
                _pointerInFlyout = true;
                CancelHideFlyout();
            }
        };
        row.MouseLeave += (_, _) =>
        {
            SetHover(false);
            if (item.Kind == TrayMenuItemKind.Navigate)
            {
                _pointerInAnchor = false;
                ScheduleHideFlyout();
            }
            else if (isFlyout)
            {
                _pointerInFlyout = false;
                ScheduleHideFlyout();
            }
        };

        if (interactive && item.Enabled)
            row.Click += (_, _) => InvokeItem();

        return row;
    }

    private static void PaintItemRow(Graphics g, MenuRowPanel row, TrayMenuItemModel item)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.Clear(Bg);

        var r = new Rectangle(0, 0, row.Width - 1, row.Height - 1);
        Color fill;
        if (!item.Enabled)
            fill = DisabledBg;
        else if (row.Hovered)
            fill = HoverBg;
        else
            fill = Bg;

        using (var path = RoundRect(r, 8))
        using (var brush = new SolidBrush(fill))
            g.FillPath(brush, path);

        var left = PadX;
        var textColor = item.Enabled ? TextPrimary : TextDisabled;

        if (item.Kind == TrayMenuItemKind.Toggle)
        {
            var markColor = item.Enabled ? Check : CheckDisabled;
            var markRect = new Rectangle(left, 0, 18, row.Height);
            TextRenderer.DrawText(
                g,
                item.Checked ? "✓" : "",
                MarkFont,
                markRect,
                markColor,
                TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter | TextFormatFlags.NoPrefix);
            left += 18;
        }

        var rightReserve = item.Kind == TrayMenuItemKind.Navigate ? 28 : 12;
        var textRect = new Rectangle(left, 0, Math.Max(40, row.Width - left - rightReserve), row.Height);
        TextRenderer.DrawText(
            g,
            item.Text,
            ItemFont,
            textRect,
            textColor,
            TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);

        if (item.Kind == TrayMenuItemKind.Navigate)
        {
            var chevronColor = item.Enabled ? TextMuted : TextDisabled;
            var chevronRect = new Rectangle(row.Width - 26, 0, 22, row.Height);
            TextRenderer.DrawText(
                g,
                "›",
                ChevronFont,
                chevronRect,
                chevronColor,
                TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter | TextFormatFlags.NoPrefix);
        }
    }

    private static void PaintHeaderRow(Graphics g, Control row, TrayMenuItemModel item)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.Clear(Bg);

        var bounds = new Rectangle(0, 0, row.Width - 1, row.Height - 1);
        using (var path = RoundRect(bounds, 8))
        using (var brush = new SolidBrush(HeaderBg))
            g.FillPath(brush, path);

        var hasSub = !string.IsNullOrWhiteSpace(item.SubText);
        var textColor = item.Accent ?? TextMuted;
        var subColor = TextMuted;

        const int dot = 8;
        const int gap = 8;
        const int lineGap = 2;
        const int sidePad = 12;
        // CJK glyphs need extra room — NoPadding measure clips the last character (e.g. 中).
        const int glyphPad = 10;
        var measureFlags = TextFormatFlags.NoPrefix;
        var drawAccent = item.Accent.HasValue;

        var titleSize = TextRenderer.MeasureText(g, item.Text, HeaderTitleFont, new Size(int.MaxValue, row.Height), measureFlags);
        var subSize = hasSub
            ? TextRenderer.MeasureText(g, item.SubText, HeaderSubFont, new Size(int.MaxValue, row.Height), measureFlags)
            : Size.Empty;

        var availW = Math.Max(40, row.Width - sidePad * 2 - (drawAccent ? dot + gap : 0));
        var neededW = Math.Max(titleSize.Width, hasSub ? subSize.Width : 0) + glyphPad;
        var textBlockW = Math.Min(availW, neededW);
        var textBlockH = hasSub ? titleSize.Height + lineGap + subSize.Height : titleSize.Height;
        var blockW = (drawAccent ? dot + gap : 0) + textBlockW;
        var startX = Math.Max(sidePad, (row.Width - blockW) / 2);
        var startY = Math.Max(4, (row.Height - textBlockH) / 2);

        if (drawAccent)
        {
            using var accentBrush = new SolidBrush(item.Accent!.Value);
            // Bullet sits in front of the first line (状态 / 员工), not mid of two-line block.
            var dotY = startY + (titleSize.Height - dot) / 2;
            g.FillEllipse(accentBrush, startX, Math.Max(0, dotY), dot, dot);
            startX += dot + gap;
        }

        var drawFlags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter
                        | TextFormatFlags.NoPrefix | TextFormatFlags.GlyphOverhangPadding;
        // Only ellipsize when content truly exceeds the row; avoid clipping 中 etc.
        if (neededW > availW + 2)
            drawFlags |= TextFormatFlags.EndEllipsis;

        var titleRect = new Rectangle(startX, startY, textBlockW, titleSize.Height);
        TextRenderer.DrawText(g, item.Text, HeaderTitleFont, titleRect, textColor, drawFlags);

        if (hasSub)
        {
            var subRect = new Rectangle(startX, startY + titleSize.Height + lineGap, textBlockW, subSize.Height);
            var subFlags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter
                           | TextFormatFlags.NoPrefix | TextFormatFlags.GlyphOverhangPadding;
            if (subSize.Width + glyphPad > availW + 2)
                subFlags |= TextFormatFlags.EndEllipsis;
            TextRenderer.DrawText(g, item.SubText, HeaderSubFont, subRect, subColor, subFlags);
        }
    }

    private class BufferedPanel : Panel
    {
        public BufferedPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint
                     | ControlStyles.UserPaint
                     | ControlStyles.OptimizedDoubleBuffer
                     | ControlStyles.ResizeRedraw, true);
            DoubleBuffered = true;
            UpdateStyles();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using var brush = new SolidBrush(BackColor.IsEmpty ? Color.White : BackColor);
            e.Graphics.FillRectangle(brush, ClientRectangle);
        }
    }

    private sealed class MenuRowPanel : BufferedPanel
    {
        public bool Hovered { get; set; }
    }

    private sealed class BufferedFlowLayoutPanel : FlowLayoutPanel
    {
        public BufferedFlowLayoutPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint
                     | ControlStyles.UserPaint
                     | ControlStyles.OptimizedDoubleBuffer
                     | ControlStyles.ResizeRedraw, true);
            DoubleBuffered = true;
            UpdateStyles();
        }
    }

    private sealed class DropShadowForm : Form
    {
        private int _appliedW;
        private int _appliedH;

        public int CornerRadius { get; set; } = 12;

        public DropShadowForm()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
            DoubleBuffered = true;
            BackColor = Color.White;
        }

        // Keep focus on the main menu so opening submenu does not flicker via deactivate.
        protected override bool ShowWithoutActivation => true;

        protected override CreateParams CreateParams
        {
            get
            {
                const int WsExNoActivate = 0x08000000;
                const int WsExToolWindow = 0x00000080;
                var cp = base.CreateParams;
                cp.ClassStyle |= 0x00020000; // CS_DROPSHADOW
                cp.ExStyle |= WsExNoActivate | WsExToolWindow;
                return cp;
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using var brush = new SolidBrush(Bg);
            e.Graphics.FillRectangle(brush, ClientRectangle);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            ApplyRoundedRegionNow(force: true);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            ApplyRoundedRegionNow(force: false);
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            ApplyRoundedRegionNow(force: true);
            Invalidate(true);
        }

        public void ApplyRoundedRegionNow(bool force)
        {
            if (!IsHandleCreated || Width <= 0 || Height <= 0) return;
            if (!force && _appliedW == Width && _appliedH == Height)
                return;

            // SetWindowRgn is more reliable than Form.Region for ShowWithoutActivation popups.
            // CreateRoundRectRgn right/bottom are exclusive; system takes ownership of the HRGN.
            var rgn = CreateRoundRectRgn(0, 0, Width + 1, Height + 1, CornerRadius * 2, CornerRadius * 2);
            if (rgn != IntPtr.Zero)
                SetWindowRgn(Handle, rgn, true);

            _appliedW = Width;
            _appliedH = Height;
        }
    }

    private static void PaintChrome(PaintEventArgs e, Control chrome)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;

        // Full opaque base — prevents dark fringe at rounded clip edges.
        using (var bgBrush = new SolidBrush(Bg))
            g.FillRectangle(bgBrush, chrome.ClientRectangle);

        // Inset the stroke so anti-aliased pixels stay inside the window region (avoids black outline).
        var r = new Rectangle(1, 1, Math.Max(0, chrome.Width - 3), Math.Max(0, chrome.Height - 3));
        if (r.Width < 4 || r.Height < 4)
            return;

        using var path = RoundRect(r, Math.Max(8, CornerRadius - 1));
        using (var fill = new SolidBrush(Bg))
            g.FillPath(fill, path);

        // Soft double stroke: outer wash + inner hairline (no harsh black).
        using (var soft = new Pen(BorderSoft, 1.5f))
            g.DrawPath(soft, path);
        using (var border = new Pen(Border, 1f))
            g.DrawPath(border, path);
    }

    private static void ApplyRoundedRegion(Form form, int radius, ref int appliedW, ref int appliedH, bool force)
    {
        if (!form.IsHandleCreated || form.Width <= 0 || form.Height <= 0) return;
        if (!force && appliedW == form.Width && appliedH == form.Height)
            return;

        var rgn = CreateRoundRectRgn(0, 0, form.Width + 1, form.Height + 1, radius * 2, radius * 2);
        if (rgn != IntPtr.Zero)
            SetWindowRgn(form.Handle, rgn, true);

        appliedW = form.Width;
        appliedH = form.Height;
    }

    private static void SetRedraw(Control control, bool enable)
    {
        if (!control.IsHandleCreated) return;
        SendMessage(control.Handle, 0x000B /* WM_SETREDRAW */, enable ? 1 : 0, IntPtr.Zero);
    }

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, IntPtr lParam);

    [DllImport("gdi32.dll")]
    private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

    [DllImport("user32.dll")]
    private static extern int SetWindowRgn(IntPtr hWnd, IntPtr hRgn, bool bRedraw);

    private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string? lpModuleName);

    [StructLayout(LayoutKind.Sequential)]
    private struct PointApi
    {
        public int x;
        public int y;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MsllHookStruct
    {
        public PointApi pt;
        public int mouseData;
        public int flags;
        public int time;
        public IntPtr dwExtraInfo;
    }

    private static GraphicsPath RoundRect(Rectangle bounds, int radius)
    {
        var diameter = radius * 2;
        var path = new GraphicsPath();
        if (radius <= 0)
        {
            path.AddRectangle(bounds);
            return path;
        }

        var arc = new Rectangle(bounds.Location, new Size(diameter, diameter));
        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - diameter;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - diameter;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.Left;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }
}

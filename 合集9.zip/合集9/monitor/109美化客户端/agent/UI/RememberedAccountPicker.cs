using System.Drawing;
using System.Windows.Forms;
using EnterpriseAgent.Agent.Services;

namespace EnterpriseAgent.Agent.UI;

/// <summary>
/// Username entry styled like a combo (click to pick remembered accounts) plus remember checkbox.
/// Typing a new account is still allowed (DropDown, not DropDownList).
/// </summary>
public sealed class RememberedAccountPicker : UserControl
{
    private readonly ComboBox _accountCombo;
    private readonly CheckBox _rememberCheck;
    private readonly ContextMenuStrip _accountMenu;
    private readonly ToolStripMenuItem _removeCurrentItem;
    private ILocalizationService? _localization;
    private Func<string> _serverKeyProvider = () => RememberedAccountStore.NormalizeServerKey(null);

    public RememberedAccountPicker()
    {
        Height = 58;
        Width = 298;
        BackColor = Color.Transparent;

        _accountCombo = new ComboBox
        {
            Location = new Point(0, 0),
            Size = new Size(Width, LoginUiChrome.FieldHeight),
            DropDownStyle = ComboBoxStyle.DropDown,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 10F),
            IntegralHeight = false,
            MaxDropDownItems = 10
        };
        _accountCombo.BackColor = LoginUiChrome.FieldBg;
        _accountCombo.ForeColor = LoginUiChrome.TextPrimary;

        _rememberCheck = new CheckBox
        {
            Location = new Point(0, LoginUiChrome.FieldHeight + 6),
            AutoSize = true,
            Checked = true,
            ForeColor = LoginUiChrome.TextMuted,
            Font = new Font("Segoe UI", 8.75F)
        };

        _removeCurrentItem = new ToolStripMenuItem();
        _removeCurrentItem.Click += (_, _) => RemoveCurrentAccount();
        _accountMenu = new ContextMenuStrip();
        _accountMenu.Items.Add(_removeCurrentItem);
        _accountCombo.ContextMenuStrip = _accountMenu;

        Controls.Add(_accountCombo);
        Controls.Add(_rememberCheck);

        Resize += (_, _) => LayoutControls();
        LayoutControls();
        ApplyLocalization(null);
    }

    public string Username => _accountCombo.Text.Trim();

    public bool RememberAccount => _rememberCheck.Checked;

    public void SetServerKeyProvider(Func<string> provider)
    {
        _serverKeyProvider = provider ?? (() => RememberedAccountStore.NormalizeServerKey(null));
        RefreshAccounts();
    }

    public void SetServerKey(string? serverUrl)
        => SetServerKeyProvider(() => RememberedAccountStore.NormalizeServerKey(serverUrl));

    public void ApplyLocalization(ILocalizationService? localization)
    {
        _localization = localization;
        _rememberCheck.Text = L("RememberAccount", "记住账号");
        _removeCurrentItem.Text = L("RemoveRememberedAccount", "清除此账号");
    }

    /// <summary>Optional visual align with login dialogs; does not change behavior.</summary>
    public void ApplyChrome()
    {
        BackColor = Color.Transparent;
        _accountCombo.FlatStyle = FlatStyle.Flat;
        _accountCombo.Font = new Font("Segoe UI", 10F);
        _accountCombo.BackColor = LoginUiChrome.FieldBg;
        _accountCombo.ForeColor = LoginUiChrome.TextPrimary;
        _rememberCheck.ForeColor = LoginUiChrome.TextMuted;
        _rememberCheck.Font = new Font("Segoe UI", 8.75F);
        LayoutControls();
    }

    public void RefreshAccounts()
    {
        var serverKey = _serverKeyProvider();
        var accounts = RememberedAccountStore.GetAccounts(serverKey);
        var previous = _accountCombo.Text;

        _accountCombo.BeginUpdate();
        try
        {
            _accountCombo.Items.Clear();
            foreach (var account in accounts)
                _accountCombo.Items.Add(account);
        }
        finally
        {
            _accountCombo.EndUpdate();
        }

        var lastUsed = RememberedAccountStore.GetLastUsed(serverKey);
        if (!string.IsNullOrWhiteSpace(lastUsed))
            _accountCombo.Text = lastUsed;
        else if (!string.IsNullOrWhiteSpace(previous))
            _accountCombo.Text = previous;
    }

    public void FocusUsername()
    {
        _accountCombo.Focus();
        _accountCombo.SelectAll();
    }

    private void RemoveCurrentAccount()
    {
        var username = Username;
        if (string.IsNullOrWhiteSpace(username))
            return;

        var serverKey = _serverKeyProvider();
        RememberedAccountStore.Remove(serverKey, username);
        _accountCombo.Text = string.Empty;
        RefreshAccounts();
    }

    private void LayoutControls()
    {
        _accountCombo.Location = new Point(0, 0);
        _accountCombo.Width = Math.Max(120, Width);
        _accountCombo.Height = LoginUiChrome.FieldHeight;
        _rememberCheck.Location = new Point(0, _accountCombo.Bottom + 6);
        Height = Math.Max(58, _rememberCheck.Bottom + 2);
    }

    private string L(string key, string fallback)
        => _localization?.GetString(key, fallback) ?? fallback;
}

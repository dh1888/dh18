#Requires -Version 5.1
<#
.SYNOPSIS
  Publish hiddex as a self-contained single-file exe.

.EXAMPLE
  .\publish.ps1
#>

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$outDir = Join-Path $root 'dist\hiddex'

Write-Host "==> Clean $outDir"
if (Test-Path $outDir) { Remove-Item -Recurse -Force $outDir }
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

Write-Host '==> Publish self-contained single-file (win-x64)...'
dotnet publish (Join-Path $root 'HiddenWindowManager.csproj') `
    -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:EnableCompressionInSingleFile=true `
    -p:DebugType=none -p:DebugSymbols=false `
    -o $outDir

# Keep only the runnable exe in the output folder
Get-ChildItem $outDir -File | Where-Object { $_.Name -ne 'hiddex.exe' } | Remove-Item -Force

$exe = Join-Path $outDir 'hiddex.exe'
if (-not (Test-Path $exe)) {
    throw "Publish failed: hiddex.exe not found in $outDir"
}

$sizeMb = [math]::Round((Get-Item $exe).Length / 1MB, 2)
Write-Host "==> Done: $exe  ($sizeMb MB)"

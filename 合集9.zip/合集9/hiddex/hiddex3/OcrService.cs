using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using Windows.Globalization;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage.Streams;
using DrawingPixelFormat = System.Drawing.Imaging.PixelFormat;
using WpfBitmapSource = System.Windows.Media.Imaging.BitmapSource;

namespace HiddenWindowManager
{
    /// <summary>
    /// 基于 Windows.Media.Ocr 的本地多语言文字识别。
    /// 识别能力取决于系统已安装的 OCR 语言包（设置 → 时间和语言 → 语言）。
    /// </summary>
    internal static class OcrService
    {
        public static IReadOnlyList<OcrLanguageOption> GetAvailableLanguages()
        {
            return OcrEngine.AvailableRecognizerLanguages
                .Select(l => new OcrLanguageOption(l.LanguageTag, l.DisplayName))
                .OrderBy(l => l.DisplayName, StringComparer.CurrentCultureIgnoreCase)
                .ToList();
        }

        /// <summary>
        /// 已安装的识别器语言标签，用于判断某种语言能不能识别。
        /// </summary>
        public static IReadOnlyList<string> InstalledTags =>
            OcrEngine.AvailableRecognizerLanguages.Select(l => l.LanguageTag).ToList();

        /// <summary>
        /// 判断某语言是否装了识别器（接受地区回退：请求 pt-BR，装了 pt-PT 也算）。
        /// </summary>
        public static bool IsLanguageInstalled(string tag) =>
            FindBestMatch(OcrEngine.AvailableRecognizerLanguages, tag) != null;

        /// <summary>
        /// 用户系统语言里有哪些**没装**识别器。用来提示用户去装语言包 ——
        /// Windows OCR 只能识别已安装"文本识别"功能的语言，
        /// 缺包时无论怎么改代码都识别不出来，必须让用户知道。
        /// </summary>
        public static IReadOnlyList<string> MissingUserLanguages()
        {
            var missing = new List<string>();
            foreach (var tag in UserPreferredTags())
            {
                if (IsLanguageInstalled(tag)) continue;
                try
                {
                    var name = new System.Globalization.CultureInfo(tag).DisplayName;
                    missing.Add($"{name} ({tag})");
                }
                catch
                {
                    missing.Add(tag);
                }
            }
            return missing;
        }

        /// <summary>OCR 引擎最喜欢的字高（像素）。模糊图略抬高目标，放大后更稳。</summary>
        private const double TargetTextHeight = 42.0;

        private const double MaxScale = 10.0;

        /// <summary>低于这个分数视为几乎没认出，触发增强/更大倍数重试。</summary>
        private const int WeakScoreThreshold = 4;

        /// <summary>
        /// 识别图片中的文字。
        /// </summary>
        /// <param name="image">待识别图像（应为未标注的干净图，标注会干扰识别）。</param>
        /// <param name="languageTag">指定语言；null 或空表示自动。</param>
        /// <param name="tryAllLanguages">
        /// true 时用多个已装语言包各识别一遍，取提取内容最多的结果。
        /// 适合中英混排或不确定语言的场景。
        /// </param>
        public static async Task<OcrOutcome> RecognizeDetailedAsync(
            WpfBitmapSource image, string? languageTag = null, bool tryAllLanguages = false)
        {
            var layout = await RecognizeLayoutAsync(image, languageTag, tryAllLanguages).ConfigureAwait(false);
            return new OcrOutcome(layout.Text, layout.LanguageDisplayName, layout.LanguageTag, layout.Scale);
        }

        /// <summary>
        /// 识别并返回每一行的文本与边界框（原图像素坐标，已除掉放大倍数）。
        /// 供截图翻译在页内按行覆盖译文使用。
        /// </summary>
        public static async Task<OcrLayoutOutcome> RecognizeLayoutAsync(
            WpfBitmapSource image, string? languageTag = null, bool tryAllLanguages = false)
        {
            if (OcrEngine.AvailableRecognizerLanguages.Count == 0)
                throw new InvalidOperationException(
                    "未找到可用的 OCR 语言包。请在 Windows「设置 → 时间和语言 → 语言和区域」中安装语言的「文本识别」功能。");

            var candidates = BuildCandidateLanguages(languageTag, tryAllLanguages);
            if (candidates.Count == 0)
                throw new InvalidOperationException("未找到可用的 OCR 语言包。");

            using var raw = ToDrawingBitmap(image);
            using var src = PrepareBitmapForOcr(raw);
            using var enhanced = EnhanceForOcr(src);

            var (best, bestLang, usedScale, lastError) =
                await RecognizeBestAcrossVariantsAsync(src, enhanced, candidates).ConfigureAwait(false);

            if (string.IsNullOrWhiteSpace(best.Text) && lastError != null)
                throw new InvalidOperationException("OCR 识别失败：" + lastError.Message, lastError);

            string fixedText = FixLatinDiacriticConfusions(best.Text, bestLang.LanguageTag);
            var fixedLines = FixLineDiacritics(best.Lines, bestLang.LanguageTag);

            return new OcrLayoutOutcome(
                fixedText.Trim(),
                bestLang.DisplayName,
                bestLang.LanguageTag,
                usedScale,
                fixedLines);
        }

        /// <summary>
        /// 清晰图走原图；模糊/低对比度时自动换增强图，并在空手时加大放大倍数重试。
        /// </summary>
        private static async Task<(
            (string Text, double MedianWordHeight, IReadOnlyList<OcrLineBox> Lines, Exception? Error) Best,
            Language BestLang,
            double UsedScale,
            Exception? LastError)> RecognizeBestAcrossVariantsAsync(
            Bitmap original, Bitmap enhanced, List<Language> candidates)
        {
            var primary = candidates[0];
            Exception? lastError = null;
            Bitmap winnerBmp = original;

            async Task<((string Text, double MedianWordHeight, IReadOnlyList<OcrLineBox> Lines, Exception? Error) Result, double Scale)>
                ProbeAsync(Bitmap img)
            {
                double scale = InitialScale(img.Width, img.Height);
                var probe = await RecognizeLayoutAtScaleAsync(img, primary, scale).ConfigureAwait(false);
                lastError ??= probe.Error;

                double refined = RefineScale(scale, probe.MedianWordHeight, img.Width, img.Height);
                if (Math.Abs(refined - scale) > 0.25)
                {
                    var second = await RecognizeLayoutAtScaleAsync(img, primary, refined).ConfigureAwait(false);
                    lastError ??= second.Error;
                    if (Score(second.Text) > Score(probe.Text))
                    {
                        probe = second;
                        scale = refined;
                    }
                }

                return (probe, scale);
            }

            // 1) 原图自适应
            var (best, usedScale) = await ProbeAsync(original).ConfigureAwait(false);
            var bestLang = primary;
            int bestScore = Score(best.Text, primary.LanguageTag);

            // 2) 弱结果：换对比度+锐化图（模糊截图的主路径）
            if (bestScore < WeakScoreThreshold)
            {
                var (enh, enhScale) = await ProbeAsync(enhanced).ConfigureAwait(false);
                int enhScore = Score(enh.Text, primary.LanguageTag);
                if (enhScore > bestScore)
                {
                    best = enh;
                    bestScore = enhScore;
                    usedScale = enhScale;
                    winnerBmp = enhanced;
                }
            }

            // 3) 仍弱：更大倍数硬放大（模糊小字）
            if (bestScore < WeakScoreThreshold)
            {
                foreach (var img in new[] { enhanced, original })
                {
                    foreach (double bump in FallbackScales(usedScale, img.Width, img.Height))
                    {
                        var r = await RecognizeLayoutAtScaleAsync(img, primary, bump).ConfigureAwait(false);
                        lastError ??= r.Error;
                        int s = Score(r.Text, primary.LanguageTag);
                        if (s > bestScore)
                        {
                            best = r;
                            bestScore = s;
                            usedScale = bump;
                            winnerBmp = img;
                        }
                        if (bestScore >= WeakScoreThreshold) break;
                    }
                    if (bestScore >= WeakScoreThreshold) break;
                }
            }

            foreach (var lang in candidates.Skip(1))
            {
                var r = await RecognizeLayoutAtScaleAsync(winnerBmp, lang, usedScale).ConfigureAwait(false);
                lastError ??= r.Error;
                int s = Score(r.Text, lang.LanguageTag);
                if (s > bestScore)
                {
                    bestScore = s;
                    best = r;
                    bestLang = lang;
                }
            }

            return (best, bestLang, usedScale, lastError);
        }

        private static IEnumerable<double> FallbackScales(double already, int w, int h)
        {
            foreach (double s in new[] { 2.0, 3.0, 4.0, 6.0, 8.0 })
            {
                double clamped = ClampScale(s, w, h);
                if (clamped <= already + 0.2) continue;
                yield return clamped;
            }
        }

        /// <summary>兼容旧调用：只返回文本。</summary>
        public static async Task<string> RecognizeAsync(WpfBitmapSource image, string? languageTag = null)
        {
            var outcome = await RecognizeDetailedAsync(image, languageTag);
            return outcome.Text;
        }

        // ---------------------------------------------------------------
        // 缩放策略
        // ---------------------------------------------------------------
        /// <summary>
        /// 首次缩放的猜测值：区域越小越可能是一小段字，放大得更狠。
        /// </summary>
        private static double InitialScale(int w, int h)
        {
            int shortSide = Math.Min(w, h);
            double s = shortSide switch
            {
                < 40 => 6.0,
                < 80 => 4.0,
                < 160 => 3.0,
                < 400 => 2.0,
                < 700 => 1.5, // 中等选区里也可能是偏糊的小字
                _ => 1.0
            };
            return ClampScale(s, w, h);
        }

        /// <summary>
        /// 已知当前缩放下的实际字高，反推能让字高接近 TargetTextHeight 的缩放。
        /// </summary>
        private static double RefineScale(double currentScale, double medianHeightAtScale, int w, int h)
        {
            // 没认出词：多半是糊/太小，直接抬一档放大再试
            if (medianHeightAtScale < 1)
                return ClampScale(Math.Max(currentScale * 2.0, 3.0), w, h);

            double heightAt1x = medianHeightAtScale / currentScale;
            if (heightAt1x < 0.5) return ClampScale(Math.Max(currentScale * 2.0, 3.0), w, h);
            return ClampScale(TargetTextHeight / heightAt1x, w, h);
        }

        private static double ClampScale(double s, int w, int h)
        {
            s = Math.Clamp(s, 1.0, MaxScale);

            // 不能超过引擎的最大边长限制
            double max = OcrEngine.MaxImageDimension;
            double limit = Math.Min(max / Math.Max(1, w), max / Math.Max(1, h));
            if (limit < s) s = Math.Max(1.0, limit);
            return s;
        }

        private static async Task<(string Text, double MedianWordHeight, Exception? Error)> RecognizeAtScaleAsync(
            Bitmap source, Language lang, double scale)
        {
            var layout = await RecognizeLayoutAtScaleAsync(source, lang, scale).ConfigureAwait(false);
            return (layout.Text, layout.MedianWordHeight, layout.Error);
        }

        private static async Task<(string Text, double MedianWordHeight, IReadOnlyList<OcrLineBox> Lines, Exception? Error)>
            RecognizeLayoutAtScaleAsync(Bitmap source, Language lang, double scale)
        {
            var engine = OcrEngine.TryCreateFromLanguage(lang);
            if (engine == null)
                return (string.Empty, 0, Array.Empty<OcrLineBox>(), null);

            Bitmap? scaled = null;
            try
            {
                var use = source;
                if (scale > 1.01)
                {
                    scaled = ScreenCaptureHelper.Scale(source, scale);
                    use = scaled;
                }

                using var soft = await ToSoftwareBitmapAsync(use).ConfigureAwait(false);
                // 上一行已 ConfigureAwait(false)，此处不再回到 UI 线程，避免 Wait/死锁
                var result = await engine.RecognizeAsync(soft);
                var lines = ExtractLines(result, scale);
                return (AssembleText(result), MedianWordHeight(result), lines, null);
            }
            catch (Exception ex)
            {
                return (string.Empty, 0, Array.Empty<OcrLineBox>(), ex);
            }
            finally
            {
                scaled?.Dispose();
            }
        }

        /// <summary>
        /// OCR 前把图铺到不透明白底上。CopyFromScreen / RenderTargetBitmap
        /// 偶发 alpha=0，Premultiplied 后像素会变成全透明，Windows OCR 就认不出字。
        /// </summary>
        private static Bitmap PrepareBitmapForOcr(Bitmap source)
        {
            var opaque = new Bitmap(source.Width, source.Height, DrawingPixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(opaque))
            {
                g.Clear(Color.White);
                g.DrawImageUnscaled(source, 0, 0);
            }

            // 强制 96 DPI，避免后续 WPF/WinRT 往返时按系统 DPI 把尺寸算歪
            opaque.SetResolution(96f, 96f);
            return opaque;
        }

        /// <summary>
        /// 模糊/低对比度专用：灰度化 → 百分位对比度拉伸 → 轻度锐化。
        /// 清晰印刷体也会略增对比，一般不伤识别。
        /// </summary>
        private static Bitmap EnhanceForOcr(Bitmap source)
        {
            int w = source.Width;
            int h = source.Height;
            var gray = new byte[w * h];

            var rect = new Rectangle(0, 0, w, h);
            var srcData = source.LockBits(rect, ImageLockMode.ReadOnly, DrawingPixelFormat.Format32bppArgb);
            try
            {
                int stride = srcData.Stride;
                var buf = new byte[Math.Abs(stride) * h];
                Marshal.Copy(srcData.Scan0, buf, 0, buf.Length);

                for (int y = 0; y < h; y++)
                {
                    int row = y * stride;
                    for (int x = 0; x < w; x++)
                    {
                        int i = row + x * 4;
                        // BT.601 亮度
                        gray[y * w + x] = (byte)Math.Clamp(
                            (buf[i + 2] * 30 + buf[i + 1] * 59 + buf[i] * 11) / 100, 0, 255);
                    }
                }
            }
            finally
            {
                source.UnlockBits(srcData);
            }

            // 2%–98% 百分位拉伸，避开极端噪点
            var hist = new int[256];
            foreach (byte v in gray) hist[v]++;
            int total = gray.Length;
            int loCount = Math.Max(1, total * 2 / 100);
            int hiCount = Math.Max(1, total * 2 / 100);
            int lo = 0, hi = 255, acc = 0;
            for (int i = 0; i < 256; i++)
            {
                acc += hist[i];
                if (acc >= loCount) { lo = i; break; }
            }
            acc = 0;
            for (int i = 255; i >= 0; i--)
            {
                acc += hist[i];
                if (acc >= hiCount) { hi = i; break; }
            }
            if (hi <= lo) { lo = 0; hi = 255; }

            double scale = 255.0 / (hi - lo);
            var stretched = new byte[gray.Length];
            for (int i = 0; i < gray.Length; i++)
                stretched[i] = (byte)Math.Clamp((int)Math.Round((gray[i] - lo) * scale), 0, 255);

            // 3x3 盒式模糊后做 unsharp：out = src + 1.2*(src-blur)
            var blur = BoxBlur3x3(stretched, w, h);
            var sharp = new byte[stretched.Length];
            for (int i = 0; i < stretched.Length; i++)
            {
                int v = stretched[i] + (int)Math.Round(1.2 * (stretched[i] - blur[i]));
                sharp[i] = (byte)Math.Clamp(v, 0, 255);
            }

            var result = new Bitmap(w, h, DrawingPixelFormat.Format32bppArgb);
            result.SetResolution(96f, 96f);
            var dstData = result.LockBits(rect, ImageLockMode.WriteOnly, DrawingPixelFormat.Format32bppArgb);
            try
            {
                int stride = dstData.Stride;
                var buf = new byte[Math.Abs(stride) * h];
                for (int y = 0; y < h; y++)
                {
                    int row = y * stride;
                    for (int x = 0; x < w; x++)
                    {
                        byte v = sharp[y * w + x];
                        int i = row + x * 4;
                        buf[i] = v;
                        buf[i + 1] = v;
                        buf[i + 2] = v;
                        buf[i + 3] = 255;
                    }
                }
                Marshal.Copy(buf, 0, dstData.Scan0, buf.Length);
            }
            finally
            {
                result.UnlockBits(dstData);
            }

            return result;
        }

        private static byte[] BoxBlur3x3(byte[] src, int w, int h)
        {
            var dst = new byte[src.Length];
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    int sum = 0, n = 0;
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        int yy = y + dy;
                        if (yy < 0 || yy >= h) continue;
                        for (int dx = -1; dx <= 1; dx++)
                        {
                            int xx = x + dx;
                            if (xx < 0 || xx >= w) continue;
                            sum += src[yy * w + xx];
                            n++;
                        }
                    }
                    dst[y * w + x] = (byte)(sum / Math.Max(1, n));
                }
            }
            return dst;
        }

        /// <summary>
        /// 把 OCR 行框缩回原图像素坐标（除以 scale）。
        /// </summary>
        private static IReadOnlyList<OcrLineBox> ExtractLines(OcrResult result, double scale)
        {
            double s = Math.Max(0.01, scale);
            var list = new List<OcrLineBox>();

            foreach (var line in result.Lines)
            {
                string text = AssembleLineText(line);
                if (string.IsNullOrWhiteSpace(text)) continue;

                double left = double.MaxValue, top = double.MaxValue;
                double right = double.MinValue, bottom = double.MinValue;
                bool any = false;

                foreach (var word in line.Words)
                {
                    var r = word.BoundingRect;
                    if (r.Width <= 0 || r.Height <= 0) continue;
                    any = true;
                    left = Math.Min(left, r.X);
                    top = Math.Min(top, r.Y);
                    right = Math.Max(right, r.X + r.Width);
                    bottom = Math.Max(bottom, r.Y + r.Height);
                }

                if (!any) continue;

                list.Add(new OcrLineBox(
                    text,
                    new System.Windows.Rect(left / s, top / s, (right - left) / s, (bottom - top) / s)));
            }

            return list;
        }

        private static string AssembleLineText(OcrLine line)
        {
            var sb = new StringBuilder();
            AppendAssembledLine(sb, line);
            return NormalizeOcrText(sb.ToString());
        }

        // ---------------------------------------------------------------
        // 语言候选
        // ---------------------------------------------------------------
        /// <summary>
        /// 选语言：指定的排第一；多语言模式下再补中文、英文和用户配置语言，
        /// 最多 4 个（每个语言一遍识别，太多会明显变慢）。
        /// </summary>
        private static List<Language> BuildCandidateLanguages(string? languageTag, bool tryAll)
        {
            var all = OcrEngine.AvailableRecognizerLanguages;
            var picked = new List<Language>();

            void TryAdd(Language? l)
            {
                if (l == null) return;
                if (picked.Any(p => string.Equals(p.LanguageTag, l.LanguageTag, StringComparison.OrdinalIgnoreCase)))
                    return;
                picked.Add(l);
            }

            if (!string.IsNullOrWhiteSpace(languageTag))
            {
                TryAdd(all.FirstOrDefault(l =>
                    string.Equals(l.LanguageTag, languageTag, StringComparison.OrdinalIgnoreCase)));
            }

            if (picked.Count == 0)
            {
                // 没指定语言时按"用户自己的语言"优先，而不是硬编码中文。
                // 原来写死 zh-Hans -> zh -> en，巴西葡萄牙语/西班牙语用户会被安排
                // 一个完全不相关的引擎，accented 字符全部识别错。
                foreach (var tag in UserPreferredTags())
                {
                    TryAdd(FindBestMatch(all, tag));
                    if (picked.Count > 0) break;
                }

                if (picked.Count == 0 && all.Count > 0)
                    TryAdd(all[0]);
            }

            if (tryAll)
            {
                // 先补用户偏好语言，再把其余已装语言全部纳入。
                // 上限从 4 提到 8：装了多个语言包时，原来的 4 会让
                // 葡萄牙语/西班牙语根本排不进候选，等于永远试不到。
                foreach (var tag in UserPreferredTags())
                    TryAdd(FindBestMatch(all, tag));

                foreach (var l in all)
                {
                    if (picked.Count >= 8) break;
                    TryAdd(l);
                }
            }

            return picked;
        }

        /// <summary>
        /// 用户偏好语言标签，按优先级：Windows 界面语言 → 已安装的输入语言 → 当前区域。
        /// </summary>
        private static IEnumerable<string> UserPreferredTags()
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var tag in Windows.System.UserProfile.GlobalizationPreferences.Languages)
            {
                if (!string.IsNullOrWhiteSpace(tag) && seen.Add(tag))
                    yield return tag;
            }

            var ui = System.Globalization.CultureInfo.CurrentUICulture.Name;
            if (!string.IsNullOrWhiteSpace(ui) && seen.Add(ui)) yield return ui;

            var cur = System.Globalization.CultureInfo.CurrentCulture.Name;
            if (!string.IsNullOrWhiteSpace(cur) && seen.Add(cur)) yield return cur;
        }

        /// <summary>
        /// 按语言标签找最合适的已装识别器：先精确匹配（pt-BR），
        /// 再退到同语言的其他地区（pt-BR 找不到就用 pt-PT）。
        /// </summary>
        private static Language? FindBestMatch(IReadOnlyList<Language> all, string tag)
        {
            var exact = all.FirstOrDefault(l =>
                string.Equals(l.LanguageTag, tag, StringComparison.OrdinalIgnoreCase));
            if (exact != null) return exact;

            // 取主语言子标签：pt-BR -> pt，zh-Hans-CN -> zh
            string primary = tag.Split('-')[0];
            if (string.IsNullOrEmpty(primary)) return null;

            return all.FirstOrDefault(l =>
                l.LanguageTag.StartsWith(primary + "-", StringComparison.OrdinalIgnoreCase)
                || string.Equals(l.LanguageTag, primary, StringComparison.OrdinalIgnoreCase));
        }

        // ---------------------------------------------------------------
        // 结果打分与拼装
        // ---------------------------------------------------------------
        /// <summary>
        /// 给识别结果打分，用来在多语言之间挑赢家。
        /// Windows OCR 不给置信度，所以只能按"提取到多少有效内容"衡量：
        /// CJK 字权重更高（一个汉字信息量大于一个字母），
        /// 孤立的标点/符号算噪声要扣分。
        /// </summary>
        private static int Score(string text) => Score(text, null);

        /// <param name="engineTag">
        /// 传引擎语言时会加一项"脚本匹配"分：纯拉丁结果偏向拉丁引擎，
        /// 含 CJK 的结果偏向 CJK 引擎。否则分数打平时先跑的引擎总是赢，
        /// 纯英文内容会被中文引擎拿走（实测把 Invoice 读成 lnvoice）。
        /// </param>
        private static int Score(string text, string? engineTag)
        {
            if (string.IsNullOrWhiteSpace(text)) return 0;

            int score = 0;
            int cjk = 0, latin = 0, accented = 0;
            int cyrillic = 0, thai = 0, arabic = 0;

            foreach (var ch in text)
            {
                if (IsCjk(ch)) { score += 3; cjk++; }
                else if (IsCyrillic(ch)) { score += 3; cyrillic++; }
                else if (IsThai(ch)) { score += 3; thai++; }
                else if (IsArabic(ch)) { score += 3; arabic++; }
                else if (IsAccentedLatin(ch))
                {
                    // 关键：带音调符号的字母必须比普通字母值钱。
                    // 否则 "ação" 和 "acao" 得分相同，英文引擎把葡语的重音吃掉
                    // 之后照样打平，还因为先跑而胜出 —— 这就是葡语/西语
                    // 识别结果一直不对的直接原因。
                    // 越南语 ơ ư ă 等在 Latin Extended Additional，也必须算进来。
                    score += 3;
                    accented++;
                    latin++;
                }
                else if (char.IsLetterOrDigit(ch)) { score += 1; latin++; }
                else if (char.IsWhiteSpace(ch)) continue;
                else score -= 1;    // 标点符号：少量正常，成片出现说明在瞎猜
            }

            int meaningful = cjk + latin + cyrillic + thai + arabic;
            if (engineTag != null && meaningful > 0)
            {
                bool engineIsCjk = IsCjkLanguage(engineTag);
                bool textIsCjk = cjk > 0;
                if (engineIsCjk == textIsCjk) score += 2;

                // 结果里出现重音字母，说明这个引擎认得该语言的字符集。
                // 英文引擎几乎不会产出重音字母，所以这一项能把
                // 葡语/西语/法语/德语/越南语的正确引擎顶上去。
                if (accented > 0 && !engineIsCjk)
                    score += accented;

                // 常用带音调的拉丁语系：额外加权，避免和 en 打平时 en 因先跑而胜出
                if (accented > 0 && IsAccentHeavyLatinLanguage(engineTag))
                    score += accented * 2;

                // ã/õ 偏葡语，ä/ö/ü/ß 偏德语。Windows OCR 常把 ã 认成 ä，
                // 若两边都算"重音"等分，德语引擎会误胜 —— PixPin 能出 ã 而这里出 ä。
                score += DiacriticLanguageAffinity(text, engineTag);

                // 英文引擎出了重音极少见；若文本全是无重音拉丁而候选里另有重音结果，
                // 上面的 accented 分已经够用。这里略微压低纯英文引擎对"像葡语"文本的亲和。
                if (accented == 0 && latin > 0 && cjk == 0
                    && engineTag.StartsWith("en", StringComparison.OrdinalIgnoreCase))
                    score -= 1;

                // 脚本与引擎标签对齐：俄/泰/阿在自动多语言时不会被英文引擎抢走
                if (cyrillic > 0 && engineTag.StartsWith("ru", StringComparison.OrdinalIgnoreCase))
                    score += cyrillic;
                if (thai > 0 && engineTag.StartsWith("th", StringComparison.OrdinalIgnoreCase))
                    score += thai;
                if (arabic > 0 && (engineTag.StartsWith("ar", StringComparison.OrdinalIgnoreCase)
                                   || engineTag.StartsWith("fa", StringComparison.OrdinalIgnoreCase)
                                   || engineTag.StartsWith("ur", StringComparison.OrdinalIgnoreCase)))
                    score += arabic;
            }

            return score;
        }

        /// <summary>
        /// 按结果里的特色变音字母，给匹配的语言引擎加分、给易混淆的引擎扣分。
        /// </summary>
        private static int DiacriticLanguageAffinity(string text, string engineTag)
        {
            int ptMarks = 0, deMarks = 0, esMarks = 0;
            foreach (var ch in text)
            {
                switch (ch)
                {
                    case 'ã': case 'õ': case 'Ã': case 'Õ':
                    case 'ç': case 'Ç':
                        ptMarks++; break;
                    case 'ä': case 'ö': case 'ü': case 'Ä': case 'Ö': case 'Ü': case 'ß':
                        deMarks++; break;
                    case 'ñ': case 'Ñ':
                        esMarks++; break;
                }
            }

            string primary = PrimaryLang(engineTag);
            int bonus = 0;

            if (primary == "pt")
            {
                bonus += ptMarks * 5;
                // 德语引擎才该大量出 ä；葡语结果里出现 ä 多半是 ã 被认错
                bonus -= deMarks * 3;
            }
            else if (primary == "es")
            {
                bonus += esMarks * 5 + ptMarks * 2; // ç/ã 在西语/葡语都常见
                bonus -= deMarks * 3;
            }
            else if (primary == "de")
            {
                bonus += deMarks * 5;
                bonus -= ptMarks * 3;
            }

            return bonus;
        }

        private static string PrimaryLang(string tag) =>
            tag.Split('-')[0].ToLowerInvariant();

        /// <summary>
        /// Windows OCR 把葡语 ã/õ 认成德语 ä/ö 时的纠错。
        /// 仅在葡/西引擎，或文本本身明显像葡/西语时启用，避免误伤德语。
        /// </summary>
        private static string FixLatinDiacriticConfusions(string text, string engineTag)
        {
            if (string.IsNullOrEmpty(text)) return text;

            string primary = PrimaryLang(engineTag);
            bool ptOrEsEngine = primary is "pt" or "es";
            bool looksPtEs = LooksPortugueseOrSpanish(text);
            bool looksDe = LooksGerman(text);
            // 系统界面/输入法是葡西语时，短词（如 mãe→mäe）没有 ç 线索也能纠
            bool userPtEs = UserPrefersPortugueseOrSpanish();

            if (!ptOrEsEngine && !(looksPtEs && !looksDe) && !(userPtEs && !looksDe))
                return text;

            var sb = new StringBuilder(text.Length);
            foreach (var ch in text)
            {
                sb.Append(ch switch
                {
                    'ä' => 'ã',
                    'Ä' => 'Ã',
                    'ö' => 'õ',
                    'Ö' => 'Õ',
                    _ => ch
                });
            }
            return sb.ToString();
        }

        private static IReadOnlyList<OcrLineBox> FixLineDiacritics(
            IReadOnlyList<OcrLineBox> lines, string engineTag)
        {
            if (lines.Count == 0) return lines;
            var list = new List<OcrLineBox>(lines.Count);
            foreach (var line in lines)
                list.Add(line with { Text = FixLatinDiacriticConfusions(line.Text, engineTag) });
            return list;
        }

        private static bool LooksPortugueseOrSpanish(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;
            // 特色字母，或常见葡语后缀（即使 ã 已被误成 ä，ç/ão 碎片仍在）
            if (text.IndexOfAny(['ã', 'õ', 'Ã', 'Õ', 'ç', 'Ç', 'ñ', 'Ñ']) >= 0)
                return true;

            // 不含正确 ã 时：看是否同时有德语式 ä 与葡语痕迹（ç、nh、lh、ão 被拆坏后的 ao）
            bool hasUmlaut = text.IndexOfAny(['ä', 'ö', 'Ä', 'Ö']) >= 0;
            if (!hasUmlaut) return false;

            string lower = text.ToLowerInvariant();
            return lower.Contains('ç')
                || lower.Contains("nh")
                || lower.Contains("lh")
                || lower.Contains("ção")
                || lower.Contains("coes")
                || lower.Contains("ães");
        }

        private static bool LooksGerman(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;
            if (text.Contains('ß')) return true;
            string lower = text.ToLowerInvariant();
            // ü 在葡语几乎不用；sch/cht 是德语强特征
            return lower.Contains('ü')
                || lower.Contains("sch")
                || lower.Contains("cht")
                || lower.Contains("ung");
        }

        private static bool UserPrefersPortugueseOrSpanish()
        {
            foreach (var tag in UserPreferredTags())
            {
                string p = PrimaryLang(tag);
                if (p is "pt" or "es") return true;
            }
            return false;
        }

        /// <summary>葡萄牙语/西语/法语等：OCR 引擎标签本身就应该保留 ã ó ç 这类字符。</summary>
        private static bool IsAccentHeavyLatinLanguage(string tag)
        {
            // 取主语言：pt-BR -> pt
            string primary = tag.Split('-')[0].ToLowerInvariant();
            return primary is "pt" or "es" or "fr" or "de" or "it" or "vi"
                or "pl" or "tr" or "nl" or "sv" or "da" or "nb" or "nn" or "no"
                or "fi" or "cs" or "hu" or "ro" or "ca" or "gl" or "eu";
        }

        /// <summary>
        /// 拉丁字母的带附加符号变体（á à â ã ä ç é ê í ó õ ô ú ü ñ、越南语 ơ ư …）。
        /// 覆盖 Latin-1 / Ext-A/B + Latin Extended Additional。
        /// </summary>
        private static bool IsAccentedLatin(char ch)
        {
            if (ch < 0x00C0) return false;
            if (ch >= 0x00C0 && ch <= 0x024F) return char.IsLetter(ch); // Latin-1 + Ext-A/B
            if (ch >= 0x1E00 && ch <= 0x1EFF) return char.IsLetter(ch); // Ext Additional（越南语等）
            return false;
        }

        private static bool IsCyrillic(char ch) =>
            (ch >= 0x0400 && ch <= 0x04FF) || (ch >= 0x0500 && ch <= 0x052F);

        private static bool IsThai(char ch) =>
            ch >= 0x0E00 && ch <= 0x0E7F;

        private static bool IsArabic(char ch) =>
            (ch >= 0x0600 && ch <= 0x06FF)
            || (ch >= 0x0750 && ch <= 0x077F)
            || (ch >= 0x08A0 && ch <= 0x08FF)
            || (ch >= 0xFB50 && ch <= 0xFDFF)
            || (ch >= 0xFE70 && ch <= 0xFEFF);

        private static bool IsCjkLanguage(string tag) =>
            tag.StartsWith("zh", StringComparison.OrdinalIgnoreCase)
            || tag.StartsWith("ja", StringComparison.OrdinalIgnoreCase)
            || tag.StartsWith("ko", StringComparison.OrdinalIgnoreCase);

        private static bool IsCjk(char ch) =>
            (ch >= 0x4E00 && ch <= 0x9FFF)      // 统一汉字
            || (ch >= 0x3400 && ch <= 0x4DBF)   // 扩展 A
            || (ch >= 0x3040 && ch <= 0x30FF)   // 平假名/片假名
            || (ch >= 0xAC00 && ch <= 0xD7AF);  // 韩文音节

        /// <summary>
        /// 按行拼装文本。Windows OCR 的 Line.Text 会在每个"词"之间插空格，
        /// 中文会被切成很多单字词，直接用就变成"你 好 世 界"。
        /// 拉丁文还常把带音调的词切碎（nação → na / ç / ão），或给出
        /// 基字+组合音符（a + ◌̃）；拼装时要避免误插空格，并做 NFC 合成。
        /// </summary>
        private static string AssembleText(OcrResult result)
        {
            var sb = new StringBuilder();

            foreach (var line in result.Lines)
            {
                if (sb.Length > 0) sb.Append('\n');
                AppendAssembledLine(sb, line);
            }

            return NormalizeOcrText(sb.ToString());
        }

        private static void AppendAssembledLine(StringBuilder sb, OcrLine line)
        {
            string? prevWord = null;
            foreach (var word in line.Words)
            {
                string w = word.Text ?? string.Empty;
                if (w.Length == 0) continue;

                if (prevWord != null && ShouldInsertSpaceBetweenWords(prevWord, w))
                    sb.Append(' ');

                sb.Append(w);
                prevWord = w;
            }
        }

        /// <summary>
        /// 是否在两个 OCR 词之间插空格。
        /// CJK 两侧都不插；组合音符前不插；疑似被音调切开的拉丁碎片不插。
        /// </summary>
        private static bool ShouldInsertSpaceBetweenWords(string left, string right)
        {
            if (left.Length == 0 || right.Length == 0) return false;

            // 组合附加符号必须贴在前一个字母上，中间绝不能有空格
            if (IsCombiningMark(right[0])) return false;

            bool leftCjk = IsCjk(left[^1]);
            bool rightCjk = IsCjk(right[0]);
            if (leftCjk && rightCjk) return false;

            // 拉丁：Windows OCR 常在重音处切词，如 "nação" → "na"+"ç"+"ão"
            if (LooksLikeAccentedLatinSplit(left, right)) return false;

            // 一侧 CJK 一侧拉丁：通常需要空格（中英混排）
            // 两侧都非 CJK：默认空格
            return true;
        }

        /// <summary>
        /// 判断两个相邻词是否其实是被 OCR 在音调处切开的同一拉丁词碎片。
        /// </summary>
        private static bool LooksLikeAccentedLatinSplit(string left, string right)
        {
            if (!char.IsLetter(left[^1]) || !char.IsLetter(right[0])) return false;
            if (!IsLatinLetterRun(left) || !IsLatinLetterRun(right)) return false;

            bool rightAccentShort =
                (right.Length <= 2 && ContainsAccentedLatin(right))
                || (right.Length <= 3 && IsAccentedLatin(right[0]));

            bool leftAccentShort =
                (left.Length <= 2 && ContainsAccentedLatin(left))
                || (left.Length == 1 && right.Length <= 3 && ContainsAccentedLatin(right));

            return rightAccentShort || leftAccentShort;
        }

        private static bool IsLatinLetterRun(string s)
        {
            foreach (var ch in s)
            {
                if (IsCombiningMark(ch)) continue;
                if (!char.IsLetter(ch)) return false;
                if (IsCjk(ch) || IsCyrillic(ch) || IsThai(ch) || IsArabic(ch)) return false;
            }
            return true;
        }

        private static bool ContainsAccentedLatin(string s)
        {
            foreach (var ch in s)
                if (IsAccentedLatin(ch)) return true;
            return false;
        }

        private static bool IsCombiningMark(char ch)
        {
            var cat = CharUnicodeInfo.GetUnicodeCategory(ch);
            return cat is UnicodeCategory.NonSpacingMark
                or UnicodeCategory.SpacingCombiningMark
                or UnicodeCategory.EnclosingMark;
        }

        /// <summary>把 a+◌̃ 合成 ã，并清掉异常的孤立组合符间距问题。</summary>
        private static string NormalizeOcrText(string text)
        {
            if (string.IsNullOrEmpty(text)) return text;
            try
            {
                return text.Normalize(NormalizationForm.FormC);
            }
            catch
            {
                return text;
            }
        }

        /// <summary>
        /// 识别结果里词框高度的中位数，用来判断字够不够大。
        /// 用中位数而非平均值，避免个别误识别的大框拉偏。
        /// </summary>
        private static double MedianWordHeight(OcrResult result)
        {
            var heights = result.Lines
                .SelectMany(l => l.Words)
                .Select(w => (double)w.BoundingRect.Height)
                .Where(h => h > 0)
                .OrderBy(h => h)
                .ToList();

            if (heights.Count == 0) return 0;
            return heights[heights.Count / 2];
        }

        private static Bitmap ToDrawingBitmap(WpfBitmapSource source)
        {
            var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
            encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(source));

            // 注意：Bitmap 会持续引用这个流，不能 using 掉，
            // 所以先落成字节再从副本构造，避免 GDI+ "参数无效"
            using var ms = new MemoryStream();
            encoder.Save(ms);
            var bytes = ms.ToArray();

            using var copy = new MemoryStream(bytes, writable: false);
            using var decoded = new Bitmap(copy);
            return new Bitmap(decoded);   // 深拷贝，脱离流
        }

        private static OcrEngine? CreateEngine(string? languageTag)
        {
            if (!string.IsNullOrWhiteSpace(languageTag))
            {
                var match = OcrEngine.AvailableRecognizerLanguages
                    .FirstOrDefault(l => string.Equals(l.LanguageTag, languageTag, StringComparison.OrdinalIgnoreCase));
                if (match != null)
                {
                    var engine = OcrEngine.TryCreateFromLanguage(match);
                    if (engine != null) return engine;
                }
            }

            return OcrEngine.TryCreateFromUserProfileLanguages()
                ?? OcrEngine.AvailableRecognizerLanguages
                    .Select(OcrEngine.TryCreateFromLanguage)
                    .FirstOrDefault(e => e != null);
        }

        /// <summary>
        /// Drawing.Bitmap 直接转 SoftwareBitmap，省掉一次 BitmapSource 往返。
        /// </summary>
        private static async Task<SoftwareBitmap> ToSoftwareBitmapAsync(Bitmap bitmap)
        {
            using var managed = new MemoryStream();
            bitmap.Save(managed, System.Drawing.Imaging.ImageFormat.Png);
            var bytes = managed.ToArray();

            using var random = new InMemoryRandomAccessStream();
            await random.WriteAsync(bytes.AsBuffer()).AsTask().ConfigureAwait(false);
            random.Seek(0);

            var decoder = await BitmapDecoder.CreateAsync(random).AsTask().ConfigureAwait(false);
            // Ignore：避免 premultiplied + 透明像素把字“乘没”
            return await decoder.GetSoftwareBitmapAsync(
                BitmapPixelFormat.Bgra8, BitmapAlphaMode.Ignore).AsTask().ConfigureAwait(false);
        }

        private static async Task<SoftwareBitmap> ToSoftwareBitmapAsync(WpfBitmapSource source)
        {
            var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
            encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(source));

            using var managed = new MemoryStream();
            encoder.Save(managed);
            var bytes = managed.ToArray();

            using var random = new InMemoryRandomAccessStream();
            await random.WriteAsync(bytes.AsBuffer()).AsTask().ConfigureAwait(false);
            random.Seek(0);

            var decoder = await BitmapDecoder.CreateAsync(random).AsTask().ConfigureAwait(false);
            return await decoder.GetSoftwareBitmapAsync(
                BitmapPixelFormat.Bgra8, BitmapAlphaMode.Ignore).AsTask().ConfigureAwait(false);
        }
    }

    internal sealed record OcrLanguageOption(string Tag, string DisplayName)
    {
        /// <summary>多语言自动模式的哨兵项。</summary>
        public const string AutoTag = "__auto__";

        public bool IsAuto => Tag == AutoTag;

        public static OcrLanguageOption Auto => new(AutoTag, "自动（多语言）");

        public override string ToString() =>
            IsAuto ? DisplayName
                   : string.IsNullOrWhiteSpace(DisplayName) ? Tag : $"{DisplayName} ({Tag})";
    }

    /// <summary>识别结果，附带用了哪个语言和放大倍数，便于在提示栏说明。</summary>
    internal sealed record OcrOutcome(string Text, string LanguageDisplayName, string LanguageTag, double Scale);

    /// <summary>一行文字及其在原图上的像素包围盒。</summary>
    internal sealed record OcrLineBox(string Text, System.Windows.Rect Bounds);

    /// <summary>带行级布局的识别结果，用于页内覆盖译文。</summary>
    internal sealed record OcrLayoutOutcome(
        string Text,
        string LanguageDisplayName,
        string LanguageTag,
        double Scale,
        IReadOnlyList<OcrLineBox> Lines);
}

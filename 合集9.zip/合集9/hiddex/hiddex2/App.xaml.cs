using System.Threading;
using System.Windows;
using Application = System.Windows.Application;

namespace HiddenWindowManager
{
    public partial class App : Application
    {
        private const string MutexName = @"Local\hiddex.HiddenWindowManager.SingleInstance";
        private const string ActivateEventName = @"Local\hiddex.HiddenWindowManager.Activate";

        private Mutex? _instanceMutex;
        private EventWaitHandle? _activateEvent;
        private Thread? _activateWatcher;
        private volatile bool _watching;

        protected override void OnStartup(StartupEventArgs e)
        {
            // dpi 自检允许并行，不占用单实例锁
            if (DpiSelfCheck.HandleCommandLine(e.Args))
            {
                Shutdown();
                return;
            }

            bool createdNew;
            try
            {
                _instanceMutex = new Mutex(initiallyOwned: true, MutexName, out createdNew);
            }
            catch
            {
                createdNew = true;
            }

            if (!createdNew)
            {
                // 已有实例：通知它显示主窗口，自己退出
                try
                {
                    using var existing = EventWaitHandle.OpenExisting(ActivateEventName);
                    existing.Set();
                }
                catch
                {
                    // 老实例还没建好事件时忽略
                }

                Shutdown();
                return;
            }

            base.OnStartup(e);
            ShutdownMode = ShutdownMode.OnExplicitShutdown;

            try
            {
                _activateEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ActivateEventName);
            }
            catch
            {
                _activateEvent = new EventWaitHandle(false, EventResetMode.AutoReset);
            }

            _watching = true;
            _activateWatcher = new Thread(WatchActivateRequests)
            {
                IsBackground = true,
                Name = "hiddex-single-instance"
            };
            _activateWatcher.Start();

            var main = new MainWindow();
            MainWindow = main;
            main.Show();
        }

        private void WatchActivateRequests()
        {
            while (_watching)
            {
                try
                {
                    if (_activateEvent == null) break;
                    if (!_activateEvent.WaitOne(500)) continue;
                    if (!_watching) break;

                    Dispatcher.BeginInvoke(() =>
                    {
                        if (MainWindow is MainWindow mw)
                            mw.ShowMainWindow();
                    });
                }
                catch
                {
                    break;
                }
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _watching = false;
            try { _activateEvent?.Set(); } catch { /* ignore */ }
            try { _activateEvent?.Dispose(); } catch { /* ignore */ }
            _activateEvent = null;

            try
            {
                _instanceMutex?.ReleaseMutex();
            }
            catch
            {
                // 未持有时忽略
            }

            try { _instanceMutex?.Dispose(); } catch { /* ignore */ }
            _instanceMutex = null;

            base.OnExit(e);
        }
    }
}

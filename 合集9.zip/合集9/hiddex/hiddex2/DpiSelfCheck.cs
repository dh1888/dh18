using System.Runtime.InteropServices;

namespace HiddenWindowManager
{
    /// <summary>
    /// 启动时自检 DPI 感知状态。
    /// DPI 不感知会导致截屏只拿到缩放后的低分辨率画面（细节当场丢失），
    /// 窗口再被系统放大，贴图和 OCR 文字都会发虚、字形走形。
    /// 用 --dpi-check 参数运行可打印诊断信息。
    /// </summary>
    internal static class DpiSelfCheck
    {
        [DllImport("user32.dll")]
        private static extern IntPtr GetThreadDpiAwarenessContext();

        [DllImport("user32.dll")]
        private static extern int GetAwarenessFromDpiAwarenessContext(IntPtr ctx);

        /// <summary>0=UNAWARE, 1=SYSTEM_AWARE, 2=PER_MONITOR_AWARE</summary>
        public static int Awareness
        {
            get
            {
                try { return GetAwarenessFromDpiAwarenessContext(GetThreadDpiAwarenessContext()); }
                catch { return -1; }
            }
        }

        public static bool IsDpiAware => Awareness >= 1;

        public static string Describe() => Awareness switch
        {
            0 => "UNAWARE (截图会失真)",
            1 => "SYSTEM_AWARE",
            2 => "PER_MONITOR_AWARE",
            _ => "UNKNOWN"
        };

        /// <summary>用 hiddex.exe --dpi-check 运行时打印诊断并返回 true。</summary>
        public static bool HandleCommandLine(string[] args)
        {
            if (!args.Any(a => string.Equals(a, "--dpi-check", StringComparison.OrdinalIgnoreCase)))
                return false;

            var vs = ScreenCaptureHelper.VirtualScreenBounds;
            var lines = new List<string>
            {
                "DPI awareness : " + Describe(),
                "VirtualScreen : " + vs.Width + "x" + vs.Height,
            };

            try
            {
                using var shot = ScreenCaptureHelper.CaptureVirtualScreen();
                lines.Add("captured      : " + shot.Width + "x" + shot.Height);
            }
            catch (Exception ex)
            {
                lines.Add("captured      : FAILED " + ex.Message);
            }

            lines.Add(IsDpiAware
                ? "=> OK: 拿到真实物理像素，贴图/OCR 不会被系统放大"
                : "=> BAD: DPI 不感知，截图会被降采样后再放大");

            string report = string.Join(Environment.NewLine, lines);

            // 同时写文件，便于脚本读取（GUI 程序没有控制台）
            try
            {
                System.IO.File.WriteAllText(
                    System.IO.Path.Combine(AppContext.BaseDirectory, "dpi-check.txt"),
                    report);
            }
            catch { /* 写不了就算了，仍然弹窗 */ }

            System.Windows.MessageBox.Show(report,
                "DPI 自检", System.Windows.MessageBoxButton.OK,
                System.Windows.MessageBoxImage.Information);
            return true;
        }
    }
}

using System.Drawing;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using Brushes = System.Windows.Media.Brushes;
using Button = System.Windows.Controls.Button;
using Color = System.Windows.Media.Color;
using ColorConverter = System.Windows.Media.ColorConverter;
using KeyEventArgs = System.Windows.Input.KeyEventArgs;
using MessageBox = System.Windows.MessageBox;
using MouseEventArgs = System.Windows.Input.MouseEventArgs;
using Point = System.Windows.Point;
using Rectangle = System.Drawing.Rectangle;
using WpfTextBox = System.Windows.Controls.TextBox;

namespace HiddenWindowManager
{
    public partial class ScreenshotOverlayWindow : Window
    {
        private enum Stage { Selecting, Editing }

        private readonly Bitmap _screenBitmap;
        private readonly BitmapSource _screenSource;

        private Stage _stage = Stage.Selecting;
        private bool _dragging;
        private Point _start;
        private Point _current;
        private Rect _selection;

        private readonly AppConfig? _config;

        private AnnotTool _tool = AnnotTool.Move;
        private Color _color = (Color)ColorConverter.ConvertFromString("#FF3B30")!;
        private string _colorHex = "#FF3B30";
        private bool _drawing;

        /// <summary>每个工具各自的颜色和大小。</summary>
        private readonly Dictionary<AnnotTool, ToolStyle> _styles = new();

        /// <summary>正在用代码回填控件，避免事件回环。</summary>
        private bool _syncingStyleUi;
        private bool _movingSelection;
        private Point _drawStart;
        private Point _moveMouseOrigin;
        private Rect _selectionAtMoveStart;
        private PenStrokeItem? _activeStroke;

        // 矩形/椭圆/箭头：选中后拖动位置或手柄缩放
        private bool _editingShape;
        private ShapeHandle _editHandle = ShapeHandle.None;
        private Point _editLastPoint;

        // 文字工具
        private bool _textEditing;
        private Point _textAnchor;

        // OCR 结果视图是否正在显示
        private bool _ocrViewOpen;

        // 本次截图进入后的自动模式（普通 / OCR / 翻译）
        private readonly CaptureMode _captureMode;

        // 页内译文覆盖
        private readonly List<TranslateOverlayItem> _translateItems = new();
        private bool _showingOriginal;
        private bool _translateBusy;

        // 最近一次标注落地的时间，用来防止画完立刻被误判成双击完成
        private DateTime _lastAnnotationAt = DateTime.MinValue;

        // 马赛克：整块选区的像素化图，按 (blockSize, 选区尺寸) 缓存
        private BitmapSource? _mosaicCache;
        private int _mosaicCacheBlock = -1;
        private Rect _mosaicCacheSelection = Rect.Empty;

        public ScreenshotOverlayWindow(Bitmap screenBitmap, AppConfig? config = null,
            CaptureMode mode = CaptureMode.Normal)
        {
            _screenBitmap = screenBitmap;
            _config = config;
            _captureMode = mode;
            _screenSource = ScreenCaptureHelper.ToBitmapSource(screenBitmap);
            InitializeComponent();

            ScreenImage.Source = _screenSource;

            var vs = ScreenCaptureHelper.VirtualScreenBounds;
            Left = SystemParameters.VirtualScreenLeft;
            Top = SystemParameters.VirtualScreenTop;
            Width = SystemParameters.VirtualScreenWidth;
            Height = SystemParameters.VirtualScreenHeight;

            if (Width < 100 || Height < 100)
            {
                Left = vs.Left;
                Top = vs.Top;
                Width = vs.Width;
                Height = vs.Height;
            }

            InitOcrLanguages();
            SelectTool(AnnotTool.Move);
            RestoreAnnotationPrefs();
            Closed += (_, _) => SaveAnnotationPrefs();

            Loaded += (_, _) =>
            {
                double w = CanvasRoot.ActualWidth;
                double h = CanvasRoot.ActualHeight;
                PlaceMask(MaskTop, 0, 0, w, h);
                PlaceMask(MaskBottom, 0, 0, 0, 0);
                PlaceMask(MaskLeft, 0, 0, 0, 0);
                PlaceMask(MaskRight, 0, 0, 0, 0);

                Activate();
                Focus();
                Keyboard.Focus(this);
            };
        }

        /// <summary>当前工具的线宽。</summary>
        private double StrokeThickness => Math.Max(0.5, CurrentStyle.Size);

        /// <summary>文字工具的字号，独立于线宽（不再由粗细换算）。</summary>
        private double TextFontSize => Math.Max(8, StyleFor(AnnotTool.Text).Size);

        /// <summary>马赛克块边长（DIP），独立于线宽。</summary>
        private int MosaicBlockSize => (int)Math.Round(Math.Max(4, StyleFor(AnnotTool.Mosaic).Size));

        // ---------------------------------------------------------------
        // 选区阶段
        // ---------------------------------------------------------------
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            // 结果窗口是独立的模态窗口，它开着时按键归它处理，
            // 这里直接忽略，免得两个窗口抢 Esc
            if (_ocrViewOpen) return;

            if (e.Key == Key.Escape)
            {
                // 一次 Esc 直接退出截图（不再先退回选区再退一次）
                Cancel();
                e.Handled = true;
                return;
            }

            if (_stage == Stage.Editing)
            {
                // 焦点在任何文本框里（文字工具的输入框、OCR 结果框）时，
                // 编辑类快捷键归文本框所有：Ctrl+Z 撤销打错的字而不是撤销标注，
                // Enter 换行而不是复制关闭。
                if (Keyboard.FocusedElement is WpfTextBox) return;

                if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.Z)
                {
                    Undo();
                    e.Handled = true;
                }
                else if (Keyboard.Modifiers == (ModifierKeys.Control | ModifierKeys.Shift) && e.Key == Key.C)
                {
                    // 有页内译文时：复制全部译文（不关窗口）；无译文则忽略
                    if (_translateItems.Count > 0)
                    {
                        CopyAllTranslations();
                        e.Handled = true;
                    }
                }
                else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.C)
                {
                    CopyAndClose();
                    e.Handled = true;
                }
                else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.S)
                {
                    SaveImage();
                    e.Handled = true;
                }
                else if (e.Key == Key.Enter)
                {
                    CopyAndClose();
                    e.Handled = true;
                }
                return;
            }

            if (e.Key == Key.Enter)
            {
                if (_dragging || HasValidSelection())
                    EnterEditing(GetSelectionRect());
                else
                    EnterEditing(new Rect(0, 0, CanvasRoot.ActualWidth, CanvasRoot.ActualHeight));
                e.Handled = true;
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_stage != Stage.Selecting) return;
            // 点到底部按钮时不要开始选区
            if (e.OriginalSource is DependencyObject d && IsDescendantOf(d, SelectBottomBar))
                return;

            _dragging = true;
            _start = e.GetPosition(CanvasRoot);
            _current = _start;
            CaptureMouse();
            UpdateSelectionVisual();
            HintText.Text = "拖拽选择区域 · 松开后直接标注 · Esc 取消";
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (_stage != Stage.Selecting || !_dragging) return;
            _current = e.GetPosition(CanvasRoot);
            UpdateSelectionVisual();
        }

        private void Window_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_stage != Stage.Selecting || !_dragging) return;
            _dragging = false;
            _current = e.GetPosition(CanvasRoot);
            ReleaseMouseCapture();
            UpdateSelectionVisual();

            if (HasValidSelection())
                EnterEditing(GetSelectionRect());
            else
                HintText.Text = "选区太小，请重新拖拽；或按 Enter / 全屏截图 · Esc 取消";
        }

        private void Window_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_stage == Stage.Editing)
                ExitToSelecting();
            else
                Cancel();
            e.Handled = true;
        }

        private static bool IsDescendantOf(DependencyObject? node, DependencyObject ancestor)
        {
            while (node != null)
            {
                if (ReferenceEquals(node, ancestor)) return true;
                node = System.Windows.Media.VisualTreeHelper.GetParent(node);
            }
            return false;
        }

        private bool HasValidSelection()
        {
            var r = GetSelectionRect();
            return r.Width >= 4 && r.Height >= 4;
        }

        private Rect GetSelectionRect()
        {
            var x = Math.Min(_start.X, _current.X);
            var y = Math.Min(_start.Y, _current.Y);
            var w = Math.Abs(_current.X - _start.X);
            var h = Math.Abs(_current.Y - _start.Y);
            return new Rect(x, y, w, h);
        }

        private void UpdateSelectionVisual()
        {
            var r = _stage == Stage.Editing ? _selection : GetSelectionRect();
            ApplySelectionChrome(r);
        }

        private void ApplySelectionChrome(Rect r)
        {
            SelectionRect.Width = r.Width;
            SelectionRect.Height = r.Height;
            Canvas.SetLeft(SelectionRect, r.X);
            Canvas.SetTop(SelectionRect, r.Y);
            SelectionRect.Visibility = r.Width > 0 && r.Height > 0 ? Visibility.Visible : Visibility.Collapsed;

            double W = CanvasRoot.ActualWidth;
            double H = CanvasRoot.ActualHeight;
            if (W <= 0 || H <= 0) return;

            PlaceMask(MaskTop, 0, 0, W, Math.Max(0, r.Y));
            PlaceMask(MaskBottom, 0, r.Y + r.Height, W, Math.Max(0, H - r.Y - r.Height));
            PlaceMask(MaskLeft, 0, r.Y, Math.Max(0, r.X), r.Height);
            PlaceMask(MaskRight, r.X + r.Width, r.Y, Math.Max(0, W - r.X - r.Width), r.Height);

            SelectionSizeText.Text = $"{(int)r.Width} × {(int)r.Height}";
            Canvas.SetLeft(SizeLabelBorder, r.X);
            Canvas.SetTop(SizeLabelBorder, Math.Max(0, r.Y - 28));
            SizeLabelBorder.Visibility = r.Width > 0 && r.Height > 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private static void PlaceMask(System.Windows.Shapes.Rectangle rect, double x, double y, double w, double h)
        {
            rect.Width = Math.Max(0, w);
            rect.Height = Math.Max(0, h);
            Canvas.SetLeft(rect, x);
            Canvas.SetTop(rect, y);
        }

        private Rectangle MapToBitmapPixels(Rect dipRect)
        {
            double scaleX = _screenBitmap.Width / Math.Max(1.0, CanvasRoot.ActualWidth);
            double scaleY = _screenBitmap.Height / Math.Max(1.0, CanvasRoot.ActualHeight);

            int x = (int)Math.Floor(dipRect.X * scaleX);
            int y = (int)Math.Floor(dipRect.Y * scaleY);
            int w = (int)Math.Ceiling(dipRect.Width * scaleX);
            int h = (int)Math.Ceiling(dipRect.Height * scaleY);

            return new Rectangle(x, y, w, h);
        }

        // ---------------------------------------------------------------
        // 进入 / 退出编辑
        // ---------------------------------------------------------------
        private void EnterEditing(Rect selection)
        {
            _selection = selection;
            _stage = Stage.Editing;
            Cursor = System.Windows.Input.Cursors.Arrow;

            ApplySelectionChrome(_selection);

            EditHost.Width = _selection.Width;
            EditHost.Height = _selection.Height;
            Canvas.SetLeft(EditHost, _selection.X);
            Canvas.SetTop(EditHost, _selection.Y);
            EditHost.Visibility = Visibility.Visible;

            AnnoLayer.Width = _selection.Width;
            AnnoLayer.Height = _selection.Height;
            AnnoLayer.ClearAll();

            CancelTextEditor();
            InvalidateMosaicCache();   // 新选区，旧的像素化图作废

            // 编辑阶段可选中选区边框进行拖动
            SelectionRect.IsHitTestVisible = true;

            SelectBottomBar.Visibility = Visibility.Collapsed;
            EditToolbar.Visibility = Visibility.Visible;
            PlaceToolbar();

            HintText.Text = "可拖动选区 · 工具条切换标注 · Enter 完成 · Esc 取消";
            SelectTool(AnnotTool.Move);

            // 热键模式：框完自动跑对应动作，不用再点一次
            if (_captureMode == CaptureMode.Ocr)
            {
                Dispatcher.BeginInvoke(new Action(() => OcrButton_Click(this, new RoutedEventArgs())),
                    System.Windows.Threading.DispatcherPriority.Loaded);
            }
            else if (_captureMode == CaptureMode.Translate)
            {
                Dispatcher.BeginInvoke(new Action(() => _ = RunTranslateAsync()),
                    System.Windows.Threading.DispatcherPriority.Loaded);
            }
        }

        private void PlaceToolbar()
        {
            EditToolbar.UpdateLayout();
            double tw = EditToolbar.ActualWidth > 0 ? EditToolbar.ActualWidth : 780;
            double th = EditToolbar.ActualHeight > 0 ? EditToolbar.ActualHeight : 48;

            double x = _selection.X;
            double y = _selection.Y + _selection.Height + 10;

            // 底部放不下则放到选区上方
            if (y + th > CanvasRoot.ActualHeight - 8)
                y = Math.Max(8, _selection.Y - th - 10);

            // 水平钳制
            if (x + tw > CanvasRoot.ActualWidth - 8)
                x = Math.Max(8, CanvasRoot.ActualWidth - tw - 8);
            if (x < 8) x = 8;

            Canvas.SetLeft(EditToolbar, x);
            Canvas.SetTop(EditToolbar, y);

            // 布局变化后再校正一次（OCR 展开后也要调）
            Dispatcher.BeginInvoke(new Action(() =>
            {
                tw = EditToolbar.ActualWidth;
                th = EditToolbar.ActualHeight;
                y = _selection.Y + _selection.Height + 10;
                if (y + th > CanvasRoot.ActualHeight - 8)
                    y = Math.Max(8, _selection.Y - th - 10);
                x = _selection.X;
                if (x + tw > CanvasRoot.ActualWidth - 8)
                    x = Math.Max(8, CanvasRoot.ActualWidth - tw - 8);
                Canvas.SetLeft(EditToolbar, x);
                Canvas.SetTop(EditToolbar, y);
            }), System.Windows.Threading.DispatcherPriority.Loaded);
        }

        private void ExitToSelecting()
        {
            _stage = Stage.Selecting;
            Cursor = System.Windows.Input.Cursors.Cross;
            _dragging = false;
            CancelTextEditor();
            ClearTranslationOverlays();
            InvalidateMosaicCache();
            AnnoLayer.ClearAll();
            EditHost.Visibility = Visibility.Collapsed;
            EditToolbar.Visibility = Visibility.Collapsed;
            SelectBottomBar.Visibility = Visibility.Visible;

            double w = CanvasRoot.ActualWidth;
            double h = CanvasRoot.ActualHeight;
            PlaceMask(MaskTop, 0, 0, w, h);
            PlaceMask(MaskBottom, 0, 0, 0, 0);
            PlaceMask(MaskLeft, 0, 0, 0, 0);
            PlaceMask(MaskRight, 0, 0, 0, 0);
            SelectionRect.Visibility = Visibility.Collapsed;
            SelectionRect.IsHitTestVisible = false;
            SizeLabelBorder.Visibility = Visibility.Collapsed;
            _movingSelection = false;

            HintText.Text = "拖拽选择截图区域 · Enter 全屏 · Esc 取消";
        }

        private void FullScreenButton_Click(object sender, RoutedEventArgs e)
        {
            EnterEditing(new Rect(0, 0, CanvasRoot.ActualWidth, CanvasRoot.ActualHeight));
        }

        private void ReselectButton_Click(object sender, RoutedEventArgs e) => ExitToSelecting();

        private void CancelButton_Click(object sender, RoutedEventArgs e) => Cancel();

        private void Cancel()
        {
            DialogResult = false;
            Close();
        }

        private void DoneButton_Click(object sender, RoutedEventArgs e) => CopyAndClose();

        // ---------------------------------------------------------------
        // 标注
        // ---------------------------------------------------------------
        private void ToolButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not string tag) return;
            if (Enum.TryParse<AnnotTool>(tag, out var tool))
                SelectTool(tool);
        }

        private void SelectTool(AnnotTool tool)
        {
            // 切到别的工具时，正在输入的文字先落地，不然会凭空消失
            if (tool != AnnotTool.Text)
                CommitTextEditor();

            _tool = tool;
            // 换工具时清掉几何选中，避免误拖
            if (tool is not (AnnotTool.Move or AnnotTool.Rectangle or AnnotTool.Ellipse or AnnotTool.Arrow))
                AnnoLayer.Selected = null;

            UpdateToolHighlight();
            SyncStyleUi();          // 切工具时把它自己的颜色/大小调出来
            if (_stage == Stage.Editing)
                PlaceToolbar();     // 第二行显隐后高度变了，重新摆位置
            EditHost.Cursor = tool switch
            {
                AnnotTool.Move => System.Windows.Input.Cursors.SizeAll,
                AnnotTool.Text => System.Windows.Input.Cursors.IBeam,
                _ => System.Windows.Input.Cursors.Cross
            };
            AnnoLayer.Cursor = EditHost.Cursor;
        }

        private void UpdateToolHighlight()
        {
            HighlightTool(ToolMove, _tool == AnnotTool.Move);
            HighlightTool(ToolPen, _tool == AnnotTool.Pen);
            HighlightTool(ToolHighlight, _tool == AnnotTool.Highlight);
            HighlightTool(ToolRect, _tool == AnnotTool.Rectangle);
            HighlightTool(ToolEllipse, _tool == AnnotTool.Ellipse);
            HighlightTool(ToolArrow, _tool == AnnotTool.Arrow);
            HighlightTool(ToolText, _tool == AnnotTool.Text);
            HighlightTool(ToolMosaic, _tool == AnnotTool.Mosaic);
        }

        private static void HighlightTool(Button btn, bool on)
        {
            var accent = System.Windows.Application.Current?.TryFindResource("AccentBrush") as System.Windows.Media.Brush
                         ?? Brushes.MediumPurple;
            var normal = System.Windows.Application.Current?.TryFindResource("TextPrimaryBrush") as System.Windows.Media.Brush
                         ?? Brushes.White;
            btn.Foreground = on ? accent : normal;
            btn.FontWeight = on ? FontWeights.SemiBold : FontWeights.Normal;
        }

        private void ColorButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not string hex) return;
            ApplyColor(hex);
        }

        private void ApplyColor(string hex)
        {
            try
            {
                _color = (Color)ColorConverter.ConvertFromString(hex)!;
                _colorHex = hex;
            }
            catch
            {
                return; // 配置里的颜色值无效则保持当前颜色
            }

            // 只改当前工具的颜色，不影响其他工具
            CurrentStyle.Color = hex;
            UpdateColorHighlight();

            // 已选中的几何标注同步改色
            if (AnnoLayer.Selected is { IsEditable: true } sel)
            {
                sel.Color = _color;
                AnnoLayer.Invalidate();
            }
        }

        /// <summary>
        /// 给当前颜色的色块加一圈白环，让"记住的颜色"看得出来。
        /// </summary>
        private void UpdateColorHighlight()
        {
            foreach (var child in ColorPanel.Children)
            {
                if (child is not Button b || b.Tag is not string tag) continue;
                b.BorderBrush = string.Equals(tag, _colorHex, StringComparison.OrdinalIgnoreCase)
                    ? Brushes.White
                    : Brushes.Transparent;
            }
        }

        /// <summary>当前工具的样式；没有就按默认建一份。</summary>
        private ToolStyle CurrentStyle => StyleFor(_tool);

        private ToolStyle StyleFor(AnnotTool tool)
        {
            if (!_styles.TryGetValue(tool, out var s))
            {
                s = new ToolStyle
                {
                    Color = ToolStyleDefaults.DefaultColor,
                    Size = ToolStyleDefaults.SizeOf(tool)
                };
                _styles[tool] = s;
            }
            return s;
        }

        /// <summary>
        /// 从配置载入每个工具的样式。旧配置只有一套全局颜色/粗细，
        /// 这里迁移过去：颜色沿用，大小仍取各工具默认（旧的 6 对矩形太粗）。
        /// </summary>
        private void RestoreAnnotationPrefs()
        {
            _styles.Clear();

            foreach (AnnotTool tool in Enum.GetValues<AnnotTool>())
            {
                var style = new ToolStyle
                {
                    Color = ToolStyleDefaults.DefaultColor,
                    Size = ToolStyleDefaults.SizeOf(tool)
                };

                if (_config != null)
                {
                    if (_config.ToolStyles.TryGetValue(tool.ToString(), out var saved) && saved != null)
                    {
                        if (!string.IsNullOrWhiteSpace(saved.Color)) style.Color = saved.Color;
                        if (saved.Size > 0) style.Size = saved.Size;
                    }
                    else if (!string.IsNullOrWhiteSpace(_config.AnnotationColor))
                    {
                        // 旧配置迁移：只继承颜色
                        style.Color = _config.AnnotationColor;
                    }
                }

                style.Size = Math.Clamp(style.Size,
                    ToolStyleDefaults.MinOf(tool), ToolStyleDefaults.MaxOf(tool));
                _styles[tool] = style;
            }

            SyncStyleUi();
        }

        private void SaveAnnotationPrefs()
        {
            if (_config == null) return;

            bool changed = false;
            foreach (var kv in _styles)
            {
                string key = kv.Key.ToString();
                if (_config.ToolStyles.TryGetValue(key, out var existing)
                    && existing != null
                    && string.Equals(existing.Color, kv.Value.Color, StringComparison.OrdinalIgnoreCase)
                    && Math.Abs(existing.Size - kv.Value.Size) < 0.01)
                {
                    continue;
                }

                _config.ToolStyles[key] = new ToolStyle { Color = kv.Value.Color, Size = kv.Value.Size };
                changed = true;
            }

            if (!changed) return;

            try
            {
                _config.Save();
            }
            catch
            {
                // 写配置失败不该影响截图结果
            }
        }

        /// <summary>
        /// 把当前工具的样式回填到滑块/数字框/色块，并按工具调整范围和标签。
        /// </summary>
        private void SyncStyleUi()
        {
            _syncingStyleUi = true;
            try
            {
                var style = CurrentStyle;

                bool usesSize = ToolStyleDefaults.UsesSize(_tool);
                bool usesColor = ToolStyleDefaults.UsesColor(_tool);

                bool showStyleRow = usesSize || usesColor;
                StyleRow.Visibility = showStyleRow ? Visibility.Visible : Visibility.Collapsed;
                SizePanel.Visibility = usesSize || usesColor ? Visibility.Visible : Visibility.Collapsed;
                StyleSizeLabel.Text = ToolStyleDefaults.SizeLabelOf(_tool);

                ThicknessSlider.Minimum = ToolStyleDefaults.MinOf(_tool);
                ThicknessSlider.Maximum = ToolStyleDefaults.MaxOf(_tool);
                ThicknessSlider.Value = Math.Clamp(style.Size,
                    ThicknessSlider.Minimum, ThicknessSlider.Maximum);
                SizeBox.Text = FormatSize(ThicknessSlider.Value);

                ThicknessSlider.IsEnabled = usesSize;
                SizeBox.IsEnabled = usesSize;
                StyleSizeLabel.Opacity = usesSize ? 1.0 : 0.35;

                ColorPanel.Visibility = usesColor ? Visibility.Visible : Visibility.Collapsed;

                // 颜色跟着当前工具走
                if (usesColor)
                {
                    try
                    {
                        _color = (Color)ColorConverter.ConvertFromString(style.Color)!;
                        _colorHex = style.Color;
                    }
                    catch { /* 配置里颜色坏了就保持原样 */ }
                }
                UpdateColorHighlight();
            }
            finally
            {
                _syncingStyleUi = false;
            }
        }

        private static string FormatSize(double v) =>
            Math.Abs(v - Math.Round(v)) < 0.01
                ? ((int)Math.Round(v)).ToString()
                : v.ToString("0.#");

        private void ThicknessSlider_ValueChanged(object sender,
            RoutedPropertyChangedEventArgs<double> e)
        {
            // InitializeComponent 连线时 XAML 的 Value 会先触发一次；
            // 那时 SizeBox 还没赋值，必须跳过，否则启动截图直接 NRE。
            if (_syncingStyleUi || SizeBox == null) return;
            CurrentStyle.Size = e.NewValue;
            SizeBox.Text = FormatSize(e.NewValue);
            InvalidateMosaicCache();   // 块大小变了，像素化图要重算

            if (AnnoLayer.Selected is { IsEditable: true } sel
                && _tool is AnnotTool.Rectangle or AnnotTool.Ellipse or AnnotTool.Arrow or AnnotTool.Move)
            {
                sel.Thickness = Math.Max(0.5, e.NewValue);
                AnnoLayer.Invalidate();
            }
        }

        /// <summary>数字框：回车或失焦生效，非法输入回退到当前值。</summary>
        private void CommitSizeBox()
        {
            if (!double.TryParse(SizeBox.Text.Trim(), out double v))
            {
                SizeBox.Text = FormatSize(CurrentStyle.Size);
                return;
            }

            v = Math.Clamp(v, ToolStyleDefaults.MinOf(_tool), ToolStyleDefaults.MaxOf(_tool));
            CurrentStyle.Size = v;

            _syncingStyleUi = true;
            ThicknessSlider.Value = v;
            _syncingStyleUi = false;

            SizeBox.Text = FormatSize(v);
            InvalidateMosaicCache();

            if (AnnoLayer.Selected is { IsEditable: true } sel
                && _tool is AnnotTool.Rectangle or AnnotTool.Ellipse or AnnotTool.Arrow or AnnotTool.Move)
            {
                sel.Thickness = Math.Max(0.5, v);
                AnnoLayer.Invalidate();
            }
        }

        private void SizeBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Enter 必须在这里吃掉，否则冒泡到窗口会触发完成
            if (e.Key == Key.Enter)
            {
                CommitSizeBox();
                Keyboard.Focus(this);
                e.Handled = true;
            }
            // Esc 不拦截，让窗口一次退出截图
        }

        private void SizeBox_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
            => CommitSizeBox();

        /// <summary>恢复当前工具的默认颜色和大小。</summary>
        private void ResetStyleButton_Click(object sender, RoutedEventArgs e)
        {
            var style = CurrentStyle;
            style.Color = ToolStyleDefaults.DefaultColor;
            style.Size = ToolStyleDefaults.SizeOf(_tool);
            SyncStyleUi();
            InvalidateMosaicCache();
            HintText.Text = $"已恢复默认（{ToolStyleDefaults.SizeLabelOf(_tool)} {FormatSize(style.Size)}）";
        }

        private void Anno_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_stage != Stage.Editing) return;

            // 文字面板开着时点画面不应该画东西
            if (_ocrViewOpen) return;

            if (IsCompletingDoubleClick(e))
            {
                CopyAndClose();
                e.Handled = true;
                return;
            }

            var layerPos = e.GetPosition(AnnoLayer);

            // 移动工具：优先编辑已有几何，否则拖动选区
            if (_tool == AnnotTool.Move)
            {
                if (TryBeginShapeEdit(layerPos))
                {
                    e.Handled = true;
                    return;
                }

                AnnoLayer.Selected = null;
                BeginMoveSelection(e.GetPosition(CanvasRoot));
                AnnoLayer.CaptureMouse();
                e.Handled = true;
                return;
            }

            if (_tool == AnnotTool.Text)
            {
                AnnoLayer.Selected = null;
                BeginTextEditor(layerPos);
                e.Handled = true;
                return;
            }

            // 矩形/椭圆/箭头：点中已有图形则进入编辑，否则开画
            if (_tool is AnnotTool.Rectangle or AnnotTool.Ellipse or AnnotTool.Arrow)
            {
                if (TryBeginShapeEdit(layerPos))
                {
                    e.Handled = true;
                    return;
                }
                AnnoLayer.Selected = null;
            }

            _drawing = true;
            _drawStart = layerPos;
            AnnoLayer.CaptureMouse();

            if (_tool == AnnotTool.Pen)
            {
                _activeStroke = new PenStrokeItem { Color = _color, Thickness = StrokeThickness };
                _activeStroke.Points.Add(_drawStart);
                AnnoLayer.SetPreview(_activeStroke);
            }
            e.Handled = true;
        }

        /// <summary>点中选中项手柄/本体，或点中其他可编辑标注时开始拖动。</summary>
        private bool TryBeginShapeEdit(Point layerPos)
        {
            if (AnnoLayer.Selected is { IsEditable: true } selected)
            {
                var handle = AnnoLayer.HitTestHandle(selected, layerPos);
                if (handle != ShapeHandle.None)
                {
                    BeginShapeEdit(selected, handle, layerPos);
                    return true;
                }
            }

            var hit = AnnoLayer.HitTestEditable(layerPos);
            if (hit == null) return false;

            AnnoLayer.Selected = hit;
            var h = AnnoLayer.HitTestHandle(hit, layerPos);
            BeginShapeEdit(hit, h == ShapeHandle.None ? ShapeHandle.Body : h, layerPos);
            return true;
        }

        private void BeginShapeEdit(AnnotationItem item, ShapeHandle handle, Point layerPos)
        {
            _editingShape = true;
            _editHandle = handle;
            _editLastPoint = layerPos;
            AnnoLayer.Selected = item;
            AnnoLayer.CaptureMouse();
            AnnoLayer.Cursor = AnnotationCanvas.CursorForHandle(handle);
        }

        private void Anno_MouseMove(object sender, MouseEventArgs e)
        {
            if (_movingSelection)
            {
                UpdateMoveSelection(e.GetPosition(CanvasRoot));
                e.Handled = true;
                return;
            }

            var p = e.GetPosition(AnnoLayer);

            if (_editingShape && AnnoLayer.Selected is { IsEditable: true } editing)
            {
                if (_editHandle == ShapeHandle.Body)
                {
                    double dx = p.X - _editLastPoint.X;
                    double dy = p.Y - _editLastPoint.Y;
                    editing.Offset(dx, dy);
                    _editLastPoint = p;
                }
                else
                {
                    editing.ApplyHandle(_editHandle, p);
                }

                AnnoLayer.Invalidate();
                e.Handled = true;
                return;
            }

            // 悬停时更新光标（编辑几何工具 / 移动工具）
            if (!_drawing && (_tool is AnnotTool.Move or AnnotTool.Rectangle or AnnotTool.Ellipse or AnnotTool.Arrow))
            {
                UpdateShapeHoverCursor(p);
            }

            if (!_drawing) return;

            switch (_tool)
            {
                case AnnotTool.Pen:
                    if (_activeStroke != null)
                    {
                        _activeStroke.Points.Add(p);
                        AnnoLayer.SetPreview(_activeStroke);
                    }
                    break;
                case AnnotTool.Highlight:
                    AnnoLayer.SetPreview(new HighlightItem { Color = _color, Bounds = NormalizeRect(_drawStart, p) });
                    break;
                case AnnotTool.Rectangle:
                    AnnoLayer.SetPreview(new RectItem { Color = _color, Thickness = StrokeThickness, Bounds = NormalizeRect(_drawStart, p) });
                    break;
                case AnnotTool.Ellipse:
                    AnnoLayer.SetPreview(new EllipseItem { Color = _color, Thickness = StrokeThickness, Bounds = NormalizeRect(_drawStart, p) });
                    break;
                case AnnotTool.Arrow:
                    AnnoLayer.SetPreview(new ArrowItem { Color = _color, Thickness = StrokeThickness, Start = _drawStart, End = p });
                    break;
                case AnnotTool.Mosaic:
                    AnnoLayer.SetPreview(NewMosaic(NormalizeRect(_drawStart, p)));
                    break;
            }
            e.Handled = true;
        }

        private void UpdateShapeHoverCursor(Point p)
        {
            if (AnnoLayer.Selected is { IsEditable: true } sel)
            {
                var h = AnnoLayer.HitTestHandle(sel, p);
                if (h != ShapeHandle.None)
                {
                    AnnoLayer.Cursor = AnnotationCanvas.CursorForHandle(h);
                    return;
                }
            }

            if (AnnoLayer.HitTestEditable(p) != null)
            {
                AnnoLayer.Cursor = System.Windows.Input.Cursors.SizeAll;
                return;
            }

            AnnoLayer.Cursor = _tool == AnnotTool.Move
                ? System.Windows.Input.Cursors.SizeAll
                : System.Windows.Input.Cursors.Cross;
        }

        private void Anno_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_movingSelection)
            {
                EndMoveSelection();
                AnnoLayer.ReleaseMouseCapture();
                e.Handled = true;
                return;
            }

            if (_editingShape)
            {
                _editingShape = false;
                _editHandle = ShapeHandle.None;
                AnnoLayer.ReleaseMouseCapture();
                _lastAnnotationAt = DateTime.UtcNow;
                HintText.Text = "已选中标注 · 拖动手柄改大小 · 拖动本体移动 · 点空白处取消";
                e.Handled = true;
                return;
            }

            if (!_drawing) return;
            _drawing = false;
            AnnoLayer.ReleaseMouseCapture();
            var p = e.GetPosition(AnnoLayer);

            AnnotationItem? finished = _tool switch
            {
                AnnotTool.Pen when _activeStroke != null && _activeStroke.Points.Count >= 2 => _activeStroke,
                AnnotTool.Highlight => new HighlightItem { Color = _color, Bounds = NormalizeRect(_drawStart, p) },
                AnnotTool.Rectangle => new RectItem { Color = _color, Thickness = StrokeThickness, Bounds = NormalizeRect(_drawStart, p) },
                AnnotTool.Ellipse => new EllipseItem { Color = _color, Thickness = StrokeThickness, Bounds = NormalizeRect(_drawStart, p) },
                AnnotTool.Arrow => new ArrowItem { Color = _color, Thickness = StrokeThickness, Start = _drawStart, End = p },
                AnnotTool.Mosaic => NewMosaic(NormalizeRect(_drawStart, p)),
                _ => null
            };

            AnnoLayer.SetPreview(null);
            _activeStroke = null;

            if (finished != null && IsMeaningful(finished))
            {
                AnnoLayer.Add(finished);
                _lastAnnotationAt = DateTime.UtcNow;   // 供双击守卫判断

                // 画完几何后自动选中，方便立刻调位置/大小
                if (finished.IsEditable)
                {
                    AnnoLayer.Selected = finished;
                    HintText.Text = "已选中标注 · 拖动手柄改大小 · 拖动本体移动 · 点空白处取消";
                }
            }

            e.Handled = true;
        }

        /// <summary>
        /// 选区内双击 = 完成并复制。
        /// 文字工具下不生效（双击要留给输入框）；刚落地过标注的 500ms 内也不生效，
        /// 否则用画笔快速连点两笔会被误判成"完成"，正在画的东西就没了。
        /// </summary>
        private bool IsCompletingDoubleClick(MouseButtonEventArgs e)
        {
            if (e.ClickCount != 2) return false;
            if (_tool == AnnotTool.Text) return false;
            if (_textEditing) return false;
            if ((DateTime.UtcNow - _lastAnnotationAt).TotalMilliseconds < 500) return false;
            return true;
        }

        // 通过选区边框拖动（移动工具下也可点在边框上）
        private void Selection_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_stage != Stage.Editing) return;
            if (_ocrViewOpen) return;

            if (IsCompletingDoubleClick(e))
            {
                CopyAndClose();
                e.Handled = true;
                return;
            }

            BeginMoveSelection(e.GetPosition(CanvasRoot));
            SelectionRect.CaptureMouse();
            e.Handled = true;
        }

        private void Selection_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_movingSelection) return;
            UpdateMoveSelection(e.GetPosition(CanvasRoot));
            e.Handled = true;
        }

        private void Selection_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (!_movingSelection) return;
            EndMoveSelection();
            SelectionRect.ReleaseMouseCapture();
            e.Handled = true;
        }

        private void BeginMoveSelection(Point canvasPos)
        {
            _movingSelection = true;
            _moveMouseOrigin = canvasPos;
            _selectionAtMoveStart = _selection;
        }

        private void UpdateMoveSelection(Point canvasPos)
        {
            if (!_movingSelection) return;

            double dx = canvasPos.X - _moveMouseOrigin.X;
            double dy = canvasPos.Y - _moveMouseOrigin.Y;
            double maxX = Math.Max(0, CanvasRoot.ActualWidth - _selectionAtMoveStart.Width);
            double maxY = Math.Max(0, CanvasRoot.ActualHeight - _selectionAtMoveStart.Height);
            double nx = Math.Clamp(_selectionAtMoveStart.X + dx, 0, maxX);
            double ny = Math.Clamp(_selectionAtMoveStart.Y + dy, 0, maxY);

            _selection = new Rect(nx, ny, _selectionAtMoveStart.Width, _selectionAtMoveStart.Height);
            ApplySelectionChrome(_selection);
            Canvas.SetLeft(EditHost, _selection.X);
            Canvas.SetTop(EditHost, _selection.Y);
            PlaceToolbar();
        }

        private void EndMoveSelection()
        {
            if (!_movingSelection) return;
            _movingSelection = false;

            // 选区挪到新位置后，旧标注会错位，清空更合理
            if (Math.Abs(_selection.X - _selectionAtMoveStart.X) > 0.5
                || Math.Abs(_selection.Y - _selectionAtMoveStart.Y) > 0.5)
            {
                AnnoLayer.ClearAll();
            }
        }

        private static bool IsMeaningful(AnnotationItem item) => item switch
        {
            PenStrokeItem s => s.Points.Count >= 2,
            HighlightItem h => Math.Min(h.Bounds.Width, h.Bounds.Height) >= 4,
            RectItem r => Math.Min(r.Bounds.Width, r.Bounds.Height) >= 4,
            EllipseItem el => Math.Min(el.Bounds.Width, el.Bounds.Height) >= 4,
            ArrowItem a => Math.Abs(a.End.X - a.Start.X) + Math.Abs(a.End.Y - a.Start.Y) >= 4,
            _ => true
        };

        private static Rect NormalizeRect(Point a, Point b) => new(
            Math.Min(a.X, b.X), Math.Min(a.Y, b.Y),
            Math.Abs(a.X - b.X), Math.Abs(a.Y - b.Y));

        // ---------------------------------------------------------------
        // 马赛克
        // ---------------------------------------------------------------
        /// <summary>
        /// 取当前选区的像素化位图。块大小或选区尺寸变了才重算。
        /// </summary>
        private BitmapSource? GetMosaicSource()
        {
            int block = MosaicBlockSize;
            if (_mosaicCache != null
                && _mosaicCacheBlock == block
                && Math.Abs(_mosaicCacheSelection.Width - _selection.Width) < 0.5
                && Math.Abs(_mosaicCacheSelection.Height - _selection.Height) < 0.5
                && Math.Abs(_mosaicCacheSelection.X - _selection.X) < 0.5
                && Math.Abs(_mosaicCacheSelection.Y - _selection.Y) < 0.5)
            {
                return _mosaicCache;
            }

            try
            {
                var pixelRect = MapToBitmapPixels(_selection);
                using var cropped = ScreenCaptureHelper.Crop(_screenBitmap, pixelRect);

                // block 是 DIP，位图是物理像素，按比例换算才能保证观感一致
                double scale = _selection.Width > 0 ? cropped.Width / _selection.Width : 1.0;
                int blockPx = Math.Max(2, (int)Math.Round(block * scale));

                using var mosaic = ScreenCaptureHelper.Pixelate(cropped, blockPx);
                _mosaicCache = ScreenCaptureHelper.ToBitmapSource(mosaic);
                _mosaicCacheBlock = block;
                _mosaicCacheSelection = _selection;
                return _mosaicCache;
            }
            catch
            {
                return null;
            }
        }

        private void InvalidateMosaicCache()
        {
            _mosaicCache = null;
            _mosaicCacheBlock = -1;
            _mosaicCacheSelection = Rect.Empty;
        }

        private MosaicItem? NewMosaic(Rect bounds)
        {
            var src = GetMosaicSource();
            if (src == null) return null;
            return new MosaicItem
            {
                Bounds = bounds,
                Pixelated = src,
                LayerRect = new Rect(0, 0, _selection.Width, _selection.Height)
            };
        }

        // ---------------------------------------------------------------
        // 文字工具
        // ---------------------------------------------------------------
        private void BeginTextEditor(Point layerPos)
        {
            CommitTextEditor();

            _textAnchor = layerPos;
            _textEditing = true;

            TextEditor.Text = string.Empty;
            TextEditor.FontSize = TextFontSize;
            TextEditor.Foreground = new SolidColorBrush(_color);

            // TextBox 的 border+padding 让首字比 FormattedText 起点偏右下，反向补偿
            Canvas.SetLeft(TextEditor, _selection.X + layerPos.X - 3);
            Canvas.SetTop(TextEditor, _selection.Y + layerPos.Y - 1);
            TextEditor.MaxWidth = Math.Max(60, _selection.Width - layerPos.X + 6);

            TextEditor.Visibility = Visibility.Visible;
            TextEditor.Focus();
            Keyboard.Focus(TextEditor);

            HintText.Text = "输入文字 · Ctrl+Enter 确认 · Esc 取消";
        }

        /// <summary>把输入框里的内容落成标注。空白则丢弃。</summary>
        private void CommitTextEditor()
        {
            if (!_textEditing) return;
            _textEditing = false;   // 先置位，避免 Focus 变化再次进来

            string text = TextEditor.Text;
            TextEditor.Visibility = Visibility.Collapsed;
            TextEditor.Text = string.Empty;

            if (!string.IsNullOrWhiteSpace(text))
            {
                AnnoLayer.Add(new TextItem
                {
                    Text = text.TrimEnd('\r', '\n'),
                    Position = _textAnchor,
                    Color = _color,
                    FontSize = TextEditor.FontSize
                });
            }

            if (_stage == Stage.Editing)
                HintText.Text = "可拖动选区 · 工具条切换标注 · Enter 完成 · Esc 取消";
        }

        private void CancelTextEditor()
        {
            if (!_textEditing) return;
            _textEditing = false;
            TextEditor.Visibility = Visibility.Collapsed;
            TextEditor.Text = string.Empty;

            if (_stage == Stage.Editing)
                HintText.Text = "可拖动选区 · 工具条切换标注 · Enter 完成 · Esc 取消";
        }

        private void TextEditor_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // 这三个键必须在这里吃掉，否则冒泡到 Window_KeyDown 会触发
            // 重选/完成，正在打的字就丢了
            if (e.Key == Key.Escape)
            {
                CancelTextEditor();
                e.Handled = true;
                return;
            }

            if (e.Key == Key.Enter)
            {
                if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
                {
                    CommitTextEditor();
                    e.Handled = true;
                }
                // 裸 Enter 交给 TextBox 自己换行（AcceptsReturn=True）
            }
        }

        private void TextEditor_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            // 点到别处（画布/工具条）即确认
            CommitTextEditor();
        }

        private void UndoButton_Click(object sender, RoutedEventArgs e) => Undo();

        private void Undo()
        {
            if (!AnnoLayer.Undo())
                HintText.Text = "没有可撤销的标注";
        }

        // ---------------------------------------------------------------
        // 截图翻译（页内覆盖）
        // ---------------------------------------------------------------
        private sealed class TranslateOverlayItem
        {
            public required Border Host { get; init; }
            public required TextBlock Label { get; init; }
            public required string Original { get; init; }
            public required string Translated { get; init; }
        }

        private async void TranslateButton_Click(object sender, RoutedEventArgs e)
            => await RunTranslateAsync();

        private async Task RunTranslateAsync()
        {
            if (_translateBusy || _stage != Stage.Editing) return;

            string key = _config?.TranslatorKey?.Trim() ?? string.Empty;
            if (string.IsNullOrEmpty(key))
            {
                MessageBox.Show(this,
                    "请先在主窗口底部「截图翻译」填写 Microsoft Translator 的 Key 和区域。\n" +
                    "可在 Azure 门户创建「翻译」认知服务（F0 免费档约 200 万字符/月）。",
                    "截图翻译", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var img = BuildImageForOcr();
            if (img == null) return;

            var selected = OcrLanguageCombo.SelectedItem as OcrLanguageOption;
            bool auto = selected?.IsAuto ?? true;
            string? tag = auto ? null : selected?.Tag;
            string region = _config?.TranslatorRegion?.Trim() ?? string.Empty;
            string to = string.IsNullOrWhiteSpace(_config?.TranslatorTargetLanguage)
                ? "zh-Hans"
                : _config!.TranslatorTargetLanguage.Trim();

            _translateBusy = true;
            TranslateButton.IsEnabled = false;
            HintText.Text = "正在识别并翻译…";

            try
            {
                var layout = await OcrService.RecognizeLayoutAsync(img, tag, tryAllLanguages: auto);
                if (layout.Lines.Count == 0)
                {
                    ClearTranslationOverlays();
                    HintText.Text = "未识别到文字 · 试试框大一点或换 OCR 语言";
                    return;
                }

                var sources = layout.Lines.Select(l => l.Text).ToList();
                var translated = await TranslatorService.TranslateBatchAsync(
                    sources, key, region, to);

                ShowTranslationOverlays(layout.Lines, translated, img.PixelWidth, img.PixelHeight);

                string scaleNote = layout.Scale > 1.05 ? $" · 放大 {layout.Scale:0.#}x" : string.Empty;
                HintText.Text =
                    $"已覆盖 {layout.Lines.Count} 行译文（{layout.LanguageDisplayName} → {to}{scaleNote}）" +
                    " · Ctrl+Shift+C 复制译文 · Enter 完成";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "截图翻译",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                HintText.Text = "翻译失败";
            }
            finally
            {
                _translateBusy = false;
                TranslateButton.IsEnabled = true;
            }
        }

        private void ShowTranslationOverlays(
            IReadOnlyList<OcrLineBox> lines,
            IReadOnlyList<string> translated,
            int imagePixelWidth,
            int imagePixelHeight)
        {
            ClearTranslationOverlays();

            double sx = _selection.Width / Math.Max(1.0, imagePixelWidth);
            double sy = _selection.Height / Math.Max(1.0, imagePixelHeight);

            TranslateLayer.Width = _selection.Width;
            TranslateLayer.Height = _selection.Height;

            for (int i = 0; i < lines.Count; i++)
            {
                var line = lines[i];
                string zh = i < translated.Count ? translated[i] : line.Text;
                if (string.IsNullOrWhiteSpace(zh)) continue;

                var r = new Rect(
                    line.Bounds.X * sx,
                    line.Bounds.Y * sy,
                    Math.Max(8, line.Bounds.Width * sx),
                    Math.Max(10, line.Bounds.Height * sy));

                // 略放大覆盖块，避免描边裁切
                r.Inflate(2, 1);
                if (r.X < 0) { r.Width += r.X; r.X = 0; }
                if (r.Y < 0) { r.Height += r.Y; r.Y = 0; }

                double fontSize = Math.Clamp(r.Height * 0.78, 9, 42);

                var label = new TextBlock
                {
                    Text = zh,
                    Foreground = Brushes.Black,
                    FontSize = fontSize,
                    FontFamily = new System.Windows.Media.FontFamily(TextItem.FontStack),
                    FontWeight = FontWeights.SemiBold,
                    TextWrapping = TextWrapping.Wrap,
                    TextAlignment = TextAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Center
                };

                var host = new Border
                {
                    Background = new SolidColorBrush(Color.FromArgb(230, 255, 251, 235)),
                    CornerRadius = new CornerRadius(2),
                    Padding = new Thickness(3, 1, 3, 1),
                    Width = Math.Max(12, r.Width),
                    MinHeight = Math.Max(12, r.Height),
                    Child = label
                };

                Canvas.SetLeft(host, r.X);
                Canvas.SetTop(host, r.Y);
                TranslateLayer.Children.Add(host);

                _translateItems.Add(new TranslateOverlayItem
                {
                    Host = host,
                    Label = label,
                    Original = line.Text,
                    Translated = zh
                });
            }

            _showingOriginal = false;
            CopyTranslationButton.Visibility = _translateItems.Count > 0
                ? Visibility.Visible : Visibility.Collapsed;
            ToggleTranslationButton.Visibility = CopyTranslationButton.Visibility;
            PlaceToolbar();
        }

        private void ClearTranslationOverlays()
        {
            TranslateLayer.Children.Clear();
            _translateItems.Clear();
            _showingOriginal = false;
            CopyTranslationButton.Visibility = Visibility.Collapsed;
            ToggleTranslationButton.Visibility = Visibility.Collapsed;
        }

        private void CopyTranslationButton_Click(object sender, RoutedEventArgs e)
            => CopyAllTranslations();

        private void CopyAllTranslations()
        {
            if (_translateItems.Count == 0) return;
            string text = string.Join(Environment.NewLine,
                _translateItems.Select(i => _showingOriginal ? i.Original : i.Translated));
            try
            {
                System.Windows.Clipboard.SetText(text);
                HintText.Text = _showingOriginal ? "已复制原文" : "已复制全部译文";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "复制失败：" + ex.Message, "截图翻译",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ToggleTranslationButton_Click(object sender, RoutedEventArgs e)
        {
            if (_translateItems.Count == 0) return;
            _showingOriginal = !_showingOriginal;
            foreach (var item in _translateItems)
                item.Label.Text = _showingOriginal ? item.Original : item.Translated;
            HintText.Text = _showingOriginal ? "当前显示原文 · 再点可切回译文" : "当前显示译文";
        }

        // ---------------------------------------------------------------
        // 导出 / OCR
        // ---------------------------------------------------------------
        private BitmapSource? BuildFinalImage()
        {
            // 兜底：不管从哪条路进来（按钮/快捷键/OCR），没落地的文字先落地，
            // 否则正在输入的内容不会出现在图里
            CommitTextEditor();

            try
            {
                var pixelRect = MapToBitmapPixels(_selection);
                using var cropped = ScreenCaptureHelper.Crop(_screenBitmap, pixelRect);
                var src = ScreenCaptureHelper.ToBitmapSource(cropped);

                AnnoLayer.Width = _selection.Width;
                AnnoLayer.Height = _selection.Height;
                AnnoLayer.Measure(new System.Windows.Size(_selection.Width, _selection.Height));
                AnnoLayer.Arrange(new Rect(0, 0, _selection.Width, _selection.Height));

                var combined = AnnoLayer.RenderCombined(src, null,
                    new System.Windows.Size(_selection.Width, _selection.Height)) ?? src;

                // 页内译文一并烘焙进导出图
                if (TranslateLayer.Children.Count > 0)
                    combined = CompositeTranslateLayer(combined) ?? combined;

                return combined;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "生成图片失败：" + ex.Message, "截图",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }
        }

        /// <summary>把 TranslateLayer 按选区 DIP 渲出后叠到像素图上。</summary>
        private BitmapSource? CompositeTranslateLayer(BitmapSource baseImage)
        {
            try
            {
                double dipW = Math.Max(1, _selection.Width);
                double dipH = Math.Max(1, _selection.Height);

                TranslateLayer.Width = dipW;
                TranslateLayer.Height = dipH;
                TranslateLayer.Measure(new System.Windows.Size(dipW, dipH));
                TranslateLayer.Arrange(new Rect(0, 0, dipW, dipH));
                TranslateLayer.UpdateLayout();

                int dipPxW = Math.Max(1, (int)Math.Ceiling(dipW));
                int dipPxH = Math.Max(1, (int)Math.Ceiling(dipH));
                var overlayDip = new RenderTargetBitmap(dipPxW, dipPxH, 96, 96, PixelFormats.Pbgra32);
                overlayDip.Render(TranslateLayer);
                overlayDip.Freeze();

                var dv = new DrawingVisual();
                using (var dc = dv.RenderOpen())
                {
                    dc.DrawImage(baseImage, new Rect(0, 0, baseImage.PixelWidth, baseImage.PixelHeight));
                    dc.DrawImage(overlayDip, new Rect(0, 0, baseImage.PixelWidth, baseImage.PixelHeight));
                }

                var rtb = new RenderTargetBitmap(
                    baseImage.PixelWidth, baseImage.PixelHeight, 96, 96, PixelFormats.Pbgra32);
                rtb.Render(dv);
                rtb.Freeze();
                return rtb;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// OCR 专用图：只保留马赛克，去掉画笔/高亮/矩形/椭圆/箭头/文字。
        /// 标注压在文字上会显著干扰识别；马赛克必须保留，否则会把遮住的内容读回来。
        /// </summary>
        private BitmapSource? BuildImageForOcr()
        {
            CommitTextEditor();

            try
            {
                var pixelRect = MapToBitmapPixels(_selection);
                using var cropped = ScreenCaptureHelper.Crop(_screenBitmap, pixelRect);
                var src = ScreenCaptureHelper.ToBitmapSource(cropped);

                AnnoLayer.Width = _selection.Width;
                AnnoLayer.Height = _selection.Height;
                AnnoLayer.Measure(new System.Windows.Size(_selection.Width, _selection.Height));
                AnnoLayer.Arrange(new Rect(0, 0, _selection.Width, _selection.Height));

                return AnnoLayer.RenderCombined(src, item => item is MosaicItem,
                    new System.Windows.Size(_selection.Width, _selection.Height)) ?? src;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "生成识别图失败：" + ex.Message, "OCR",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }
        }

        private void CopyAndClose()
        {
            var img = BuildFinalImage();
            if (img == null) return;
            ScreenCaptureHelper.CopyToClipboard(img);
            DialogResult = true;
            Close();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e) => SaveImage();

        private void SaveImage()
        {
            var img = BuildFinalImage();
            if (img == null) return;

            // 临时降低置顶，避免挡住保存对话框
            Topmost = false;
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "PNG 图片|*.png|JPEG 图片|*.jpg",
                FileName = $"hiddex_{DateTime.Now:yyyyMMdd_HHmmss}",
                AddExtension = true,
                DefaultExt = ".png"
            };

            bool? ok = dlg.ShowDialog(this);
            Topmost = true;
            Activate();

            if (ok != true) return;

            try
            {
                if (dlg.FilterIndex == 2
                    || dlg.FileName.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase)
                    || dlg.FileName.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase))
                {
                    var encoder = new JpegBitmapEncoder { QualityLevel = 92 };
                    encoder.Frames.Add(BitmapFrame.Create(img));
                    using var fs = File.Create(dlg.FileName);
                    encoder.Save(fs);
                }
                else
                {
                    ScreenCaptureHelper.SavePng(img, dlg.FileName);
                }
                HintText.Text = "已保存：" + dlg.FileName;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "保存失败：" + ex.Message, "截图",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void InitOcrLanguages()
        {
            var langs = OcrService.GetAvailableLanguages();
            if (langs.Count == 0)
            {
                OcrLanguageCombo.IsEnabled = false;
                OcrButton.IsEnabled = false;
                return;
            }

            // 第一项是"自动（多语言）"：各语言都试一遍取最好的结果
            var items = new List<OcrLanguageOption> { OcrLanguageOption.Auto };
            items.AddRange(langs);
            OcrLanguageCombo.ItemsSource = items;

            // 装了不止一个语言包时默认走自动，中英混排最省事
            OcrLanguageCombo.SelectedItem = langs.Count > 1
                ? items[0]
                : items[1];
        }

        private async void OcrButton_Click(object sender, RoutedEventArgs e)
        {
            // 用干净图识别，标注会干扰
            var img = BuildImageForOcr();
            if (img == null) return;

            var selected = OcrLanguageCombo.SelectedItem as OcrLanguageOption;
            bool auto = selected?.IsAuto ?? true;
            string? tag = auto ? null : selected?.Tag;

            OcrButton.IsEnabled = false;
            HintText.Text = auto ? "正在识别文字（多语言）…" : "正在识别文字…";

            try
            {
                var r = await OcrService.RecognizeDetailedAsync(img, tag, tryAllLanguages: auto);
                bool empty = string.IsNullOrWhiteSpace(r.Text);

                string scaleNote = r.Scale > 1.05 ? $" · 放大 {r.Scale:0.#}x" : string.Empty;
                string meta = empty
                    ? "未识别到文字 · 试试框大一点或换语言"
                    : $"{r.LanguageDisplayName}{scaleNote}";

                string body = empty ? "（未识别到文字）" : r.Text;

                // Windows OCR 只能识别"已安装文本识别功能"的语言。
                // 缺包时结果必然不对（会被别的语言引擎硬猜），而且用户看不出原因，
                // 所以要明确告诉他缺哪个、怎么装。
                var missing = OcrService.MissingUserLanguages();
                if (missing.Count > 0)
                {
                    body += Environment.NewLine + Environment.NewLine
                          + "--- 提示 ---" + Environment.NewLine
                          + "以下语言未安装 OCR 语言包，无法识别："
                          + Environment.NewLine + "  " + string.Join("、", missing)
                          + Environment.NewLine
                          + "安装方法：设置 → 时间和语言 → 语言和区域 → 选中该语言 →"
                          + " 语言选项 → 可选语言功能 → 添加「文本识别」。";
                }

                ShowOcrResult(body, meta);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "OCR", MessageBoxButton.OK, MessageBoxImage.Warning);
                HintText.Text = "OCR 失败";
            }
            finally
            {
                OcrButton.IsEnabled = OcrLanguageCombo.Items.Count > 0;
            }
        }

        /// <summary>
        /// 弹出独立的文字结果窗口。
        /// 不做成叠加面板，因为本窗口开了 AllowsTransparency=True，
        /// WPF 会关掉整个窗口的 ClearType，文字必然发虚。
        /// </summary>
        private void ShowOcrResult(string text, string meta)
        {
            _ocrViewOpen = true;

            // 遮罩和工具条会挡住结果窗口的观感，识别期间整体隐去
            var savedToolbar = EditToolbar.Visibility;
            EditToolbar.Visibility = Visibility.Collapsed;
            HintBar.Visibility = Visibility.Collapsed;

            // 本窗口是 Topmost，不降下来会压住结果窗口
            bool savedTopmost = Topmost;
            Topmost = false;

            try
            {
                var dlg = new OcrResultWindow(text, meta) { Owner = this };
                bool? copied = dlg.ShowDialog();

                if (copied == true)
                {
                    // 文字已进剪贴板，整个截图流程结束
                    DialogResult = false;
                    Close();
                    return;
                }

                if (dlg.WantsBackToAnnotate)
                {
                    // 回到标注：恢复原样
                    Topmost = savedTopmost;
                    EditToolbar.Visibility = savedToolbar;
                    HintBar.Visibility = Visibility.Visible;
                    _ocrViewOpen = false;
                    PlaceToolbar();
                    HintText.Text = "可拖动选区 · 工具条切换标注 · Enter 完成 · Esc 取消";
                    Activate();
                    Focus();
                    Keyboard.Focus(this);
                    return;
                }

                // 直接关掉结果窗口（Esc / 关闭按钮）= 结束整个流程
                DialogResult = false;
                Close();
            }
            catch (Exception ex)
            {
                Topmost = savedTopmost;
                EditToolbar.Visibility = savedToolbar;
                HintBar.Visibility = Visibility.Visible;
                _ocrViewOpen = false;
                MessageBox.Show(this, "显示识别结果失败：" + ex.Message, "OCR",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // ---------------------------------------------------------------
        // 贴图
        // ---------------------------------------------------------------
        private void PinButton_Click(object sender, RoutedEventArgs e) => PinToScreen();

        /// <summary>
        /// 把当前选区（含标注）钉成一张贴图，然后关掉截图界面。
        /// 贴图窗口独立存在，可以同时开多张。
        /// </summary>
        private void PinToScreen()
        {
            var img = BuildFinalImage();
            if (img == null) return;

            // 贴图要在截图窗口关闭后继续存在，位图必须是冻结的独立副本
            if (img.CanFreeze && !img.IsFrozen) img.Freeze();

            // 贴到原位置，视觉上"就地钉住"。
            // 注意不能直接用 _selection.X：BuildFinalImage 裁剪时对像素做了
            // Floor 取整，实际截到的像素可能比选区左上角更靠前，直接用选区
            // 坐标会错开 1px。这里把裁剪后的像素原点换算回 DIP，保证严格对齐。
            var pixelRect = MapToBitmapPixels(_selection);
            double scaleX = _screenBitmap.Width / Math.Max(1.0, CanvasRoot.ActualWidth);
            double scaleY = _screenBitmap.Height / Math.Max(1.0, CanvasRoot.ActualHeight);

            var topLeft = new Point(
                Left + pixelRect.X / Math.Max(0.0001, scaleX),
                Top + pixelRect.Y / Math.Max(0.0001, scaleY));

            try
            {
                var sticky = new StickyImageWindow(img, topLeft);
                sticky.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "创建贴图失败：" + ex.Message, "贴图",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
            Close();
        }

    }
}

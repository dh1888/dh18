# 隐藏窗口管理器（现代 UI 版本）

用 WPF 重构的窗口隐藏工具，深色主题 + 自定义无边框标题栏 + 圆角卡片式布局，
功能上与之前的 WinForms 版本完全一致，只是把界面全部重新设计成现代风格。

## 界面特点

- 无边框自定义标题栏（可拖动、双击最大化、自定义最小化/关闭按钮）
- 深色主题（背景 #1B1D26，强调色紫蓝 #7C6BFF）
- 圆角卡片式列表，鼠标悬停/选中有高亮描边反馈
- 自定义 Toggle 开关控件替代传统 CheckBox
- 自定义下拉框、输入框、滚动条样式，去掉了 Windows 原生控件的方块感

## 功能（与之前版本相同）

- 枚举当前所有可见窗口
- 按标题 / 类名 / 进程名 三种方式添加隐藏规则
- 全局热键一键隐藏 / 恢复（默认 Ctrl+Alt+H，可在界面里按下新组合键修改）
- 可选：恢复前需要密码验证
- 可选：开机自动启动
- 最小化到系统托盘，双击或右键菜单可以呼出/切换/退出

## 新增行为：隐藏后自动收进托盘

无论是按全局热键"全部隐藏"，还是给单条规则设置的专属热键/按钮触发隐藏，
只要真的把目标窗口隐藏了，管理器自己的主界面也会跟着 `Hide()` 到托盘，
桌面上不会留下管理器窗口。恢复窗口时不会自动弹回主界面（如果开了密码保护，
恢复前依然会弹密码框），需要打开主界面时双击托盘图标或用右键菜单里的
"显示主窗口"即可。

## 截图 / 标注 / OCR（新增）

- 默认全局热键 **Ctrl + Alt + A** 启动区域截图（可在主界面修改；托盘菜单也有「区域截图」）
- 默认全局热键 **Ctrl + Alt + T** 启动提取文字：框选完自动识别，直接出文字面板，
  不用先截图再点 OCR（可在主界面修改；托盘菜单也有「提取文字」）
- 冻结画面后拖拽选区；松开后**在选区上直接标注**（不另开编辑窗口）
- 选区旁浮动工具条：画笔、高亮、矩形、椭圆、箭头、文字、马赛克；颜色 / 粗细；撤销、OCR、保存、重选、关闭、完成
- **文字**：点击选区内任意位置就地输入，`Ctrl+Enter` 或点到别处确认，`Esc` 取消，回车换行；字号跟随粗细滑块
- **马赛克**：拖拽涂抹要遮住的区域；块大小跟随粗细滑块
- **完成** / **Enter** / **在选区内双击**：复制到剪贴板并关闭；**Ctrl+S** 保存；**Esc / 右键**：返回重选
  （双击在文字工具下不生效，刚画完标注的 500ms 内也不生效，避免连笔被误判成完成）
- 画笔颜色和粗细会记住上次的选择（存在 `config.json`），当前颜色的色块带白色选中环；粗细默认 6，范围 1-16
- OCR 结果弹出**独立窗口**（可拖标题栏移动、可拉边缘缩放），文字清晰不发虚。
  之前做成截图窗口内的叠加面板，因为截图窗口开了 `AllowsTransparency=True`，
  WPF 会关掉整个窗口的 ClearType，文字必然模糊 —— 独立窗口不开这个属性才能清晰。
  文字可直接编辑。「复制并关闭」= 文字进剪贴板并退出，「返回标注」回到标注界面，
  `Esc` 关闭，`Ctrl+Enter` 等于复制并关闭
- **贴图**：工具条的图钉按钮把当前选区（含标注）钉在屏幕上，停在原位置。
  可拖动，可同时开多张互不影响，**`Esc` 只关掉当前那一张**；
  右键或双击也能关；鼠标悬停时才浮现描边和右上角的复制 / 另存为 / 关闭按钮。
  平时**没有任何边框和内边距**，窗口尺寸严格等于图像像素，看起来就是原页面的一块，
  而不是"贴上去的一块东西"；描边是覆盖层，出现时不会挪动或缩放图像。
  按 1:1 物理像素显示（高 DPI 按缩放比换算），不会被放大重采样导致发虚。
  程序退出时自动关掉所有贴图
- OCR 使用 Windows 自带 `Windows.Media.Ocr`；可在系统语言设置中安装「文本识别」
- 小区域识别：识别前会按实际字高自适应放大（最高 8 倍），解决「框小了识别不出」
- 语言下拉第一项「自动（多语言）」会用已装的多个语言包各识别一遍，取最好的结果；
  提示栏会显示实际采用的语言和放大倍数
- **多语言支持依赖系统语言包**。Windows OCR 只能识别已安装「文本识别」功能的语言，
  缺包时无论怎么调代码都识别不出来。安装方法：
  设置 → 时间和语言 → 语言和区域 → 选中语言 → 语言选项 → 可选语言功能 → 添加「文本识别」。
  缺包时识别结果下方会列出缺哪些语言
- 候选语言按**用户系统语言**优先（不再硬编码中英），并支持地区回退
  （请求 `pt-BR`，装了 `pt-PT` 也能用）；自动模式最多尝试 8 个语言包
- 打分对**带音调符号的字母加权**（`á ã ç é ñ ü ß` 等）。这一项是葡语/西语/法语/德语
  能正确识别的关键：没有它，`ação` 和被英文引擎吃掉重音的 `acao` 得分完全相同，
  英文引擎会因为先跑而胜出；德语更糟，`ß`→`ss` 让错误结果分数反而更高
- 识别用的是**未标注的干净图**（画笔/文字等不干扰识别），但马赛克仍然生效，
  不会把刚遮住的内容读出来

原有窗口隐藏 / 热键 / 密码 / 托盘 / 开机自启逻辑保持不变。

## 编译方法


需要 Windows + .NET 8 SDK。

```bash
cd HiddenWindowManager
dotnet build -c Release
```

```bash
cd HiddenWindowManager
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true
```

编译产物：`bin\Release\net8.0-windows\HiddenWindowManager.exe`

打包成免安装单文件 exe（自带 .NET 运行时，发给别人电脑上不用装 .NET 也能直接双击运行）：

```bash
dotnet publish -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true ^
  -p:IncludeNativeLibrariesForSelfExtract=true ^
  -p:EnableCompressionInSingleFile=true
```

（Windows 命令提示符 / PowerShell 里的续行符是 `^`，如果是一行写完可以去掉 `^` 直接拼在一起。）

生成的单文件在：

```
bin\Release\net8.0-windows\win-x64\publish\HiddenWindowManager.exe
```

这一个 exe 文件已经把 .NET 8 桌面运行时和所有依赖都打进去了，体积会比较大
（一般 100MB+），但只要把这一个文件拷给别人，对方电脑不需要预装任何 .NET
运行时就能直接双击运行。配置文件会在对方电脑的
`%AppData%\HiddenWindowManager\config.json` 自动生成，不需要额外部署。

## 高 DPI / 缩放显示（重要）

程序通过 `app.manifest` 声明 `PerMonitorV2` DPI 感知。这一项**必须有**，否则：

- 进程处于 DPI UNAWARE 状态，Windows 做 DPI 虚拟化
- `CopyFromScreen` 只能拿到缩放后的低分辨率画面（1920x1080 屏在 125% 缩放下只截到
  1536x864），**细节在截取那一刻就丢失了**
- 程序窗口再被系统放大回去显示，于是贴图看起来被放大、发虚、字形走形，OCR 精度也下降

注意 `.csproj` 里的 `ApplicationHighDpiMode` 对本程序**没有效果** —— 那是 WinForms 的
`Application.SetHighDpiMode` 开关，而本程序入口是 WPF 的 `App.OnStartup`，从不走
WinForms 初始化。WPF 只认 manifest。

自检命令（会弹窗并在 exe 同目录写 `dpi-check.txt`）：

```bash
hiddex.exe --dpi-check
```

正常应显示：

```
DPI awareness : PER_MONITOR_AWARE
VirtualScreen : 1920x1080      <- 真实物理分辨率，不是缩放后的
captured      : 1920x1080
```

如果显示 `UNAWARE` 且 VirtualScreen 小于真实分辨率，说明 manifest 没生效，
贴图和 OCR 都会失真。

## 自定义程序图标

把你喜欢的图片准备成 `.ico` 格式（Windows 图标只认 `.ico`），命名为 `icon.ico`，
放到跟 `HiddenWindowManager.csproj` 同一级目录下，然后重新编译即可：

- 如果图片是 `.png` / `.jpg`，需要先转换成 `.ico`。可以用在线工具（搜索"图片转
  ico"，选一个支持多尺寸的，建议勾选 256x256、48x48、32x32、16x16 几个尺寸都
  包含进去，这样任务栏和托盘小图标都清晰），或者本地装了 ImageMagick 的话可以：
  ```bash
  magick convert my-photo.png -define icon:auto-resize=256,64,48,32,16 icon.ico
  ```
- 放好 `icon.ico` 后，`dotnet build` / `dotnet publish` 会自动把它设置成
  exe 本身的图标、窗口标题栏图标、以及系统托盘图标（三处保持一致）。
- 如果不放这个文件，程序照常编译运行，只是继续用默认图标，不影响任何功能。

## 项目结构

```
HiddenWindowManager/
├── HiddenWindowManager.csproj
├── App.xaml / App.xaml.cs          全局主题样式 + 应用入口
├── MainWindow.xaml / .xaml.cs       主界面
├── HotkeyDialog.xaml / .xaml.cs     热键设置弹窗
├── PasswordDialog.xaml / .xaml.cs   密码输入弹窗
├── NativeMethods.cs                 Win32 API 封装
├── WindowEnumerator.cs               枚举窗口
├── WindowInfo.cs                     数据结构
└── AppConfig.cs                      配置读写
```

## 后续可以继续美化的方向

- 换成 Fluent Design 风格的第三方库（如 WPF-UI / ModernWpfUI），拿到 Windows 11
  原生的亚克力/云母背景效果（这需要联网安装 NuGet 包）
- 给隐藏/恢复动作加过渡动画（Storyboard 淡入淡出）
- 支持浅色/深色主题切换（当前只做了深色，配置里已经预留了 DarkTheme 字段）
- 隐藏列表支持拖拽排序、分组（比如"工作时隐藏"/"游戏时隐藏"两组规则一键切换）

using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace HiddenWindowManager
{
    /// <summary>
    /// 在截图之上绘制标注层（笔迹、高亮、几何、箭头）。
    /// </summary>
    internal sealed class AnnotationCanvas : FrameworkElement
    {
        private readonly List<AnnotationItem> _items = new();
        private AnnotationItem? _preview;

        public IReadOnlyList<AnnotationItem> Items => _items;

        public void Add(AnnotationItem item)
        {
            _items.Add(item);
            InvalidateVisual();
        }

        public void SetPreview(AnnotationItem? preview)
        {
            _preview = preview;
            InvalidateVisual();
        }

        public bool Undo()
        {
            if (_items.Count == 0) return false;
            _items.RemoveAt(_items.Count - 1);
            InvalidateVisual();
            return true;
        }

        public void ClearAll()
        {
            _items.Clear();
            _preview = null;
            InvalidateVisual();
        }

        protected override HitTestResult HitTestCore(PointHitTestParameters hitTestParameters)
        {
            return new PointHitTestResult(this, hitTestParameters.HitPoint);
        }

        protected override void OnRender(DrawingContext drawingContext)
        {
            base.OnRender(drawingContext);
            drawingContext.DrawRectangle(System.Windows.Media.Brushes.Transparent, null, new Rect(RenderSize));
            foreach (var item in _items)
                item.Draw(drawingContext);
            _preview?.Draw(drawingContext);
        }

        public BitmapSource? RenderCombined(ImageSource background)
        {
            if (background is not BitmapSource bmp) return null;

            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                dc.DrawImage(bmp, new Rect(0, 0, bmp.PixelWidth, bmp.PixelHeight));

                double scaleX = bmp.PixelWidth / Math.Max(1.0, ActualWidth > 0 ? ActualWidth : bmp.Width);
                double scaleY = bmp.PixelHeight / Math.Max(1.0, ActualHeight > 0 ? ActualHeight : bmp.Height);

                dc.PushTransform(new ScaleTransform(scaleX, scaleY));
                foreach (var item in _items)
                    item.Draw(dc);
                dc.Pop();
            }

            var rtb = new RenderTargetBitmap(bmp.PixelWidth, bmp.PixelHeight, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(dv);
            rtb.Freeze();
            return rtb;
        }
    }
}

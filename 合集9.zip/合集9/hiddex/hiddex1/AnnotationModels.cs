using System.Windows;
using System.Windows.Media;
using MediaColor = System.Windows.Media.Color;
using MediaPen = System.Windows.Media.Pen;
using WpfPoint = System.Windows.Point;

namespace HiddenWindowManager
{
    internal enum AnnotTool
    {
        Move,
        Pen,
        Highlight,
        Rectangle,
        Ellipse,
        Arrow
    }

    internal abstract class AnnotationItem
    {
        public MediaColor Color { get; set; } = Colors.Red;
        public double Thickness { get; set; } = 3;

        public abstract void Draw(DrawingContext dc);
    }

    internal sealed class PenStrokeItem : AnnotationItem
    {
        public List<WpfPoint> Points { get; } = new();

        public override void Draw(DrawingContext dc)
        {
            if (Points.Count < 2) return;
            var geo = new StreamGeometry();
            using (var ctx = geo.Open())
            {
                ctx.BeginFigure(Points[0], false, false);
                ctx.PolyLineTo(Points.Skip(1).ToList(), true, true);
            }
            geo.Freeze();
            dc.DrawGeometry(null, new MediaPen(new SolidColorBrush(Color), Thickness)
            {
                StartLineCap = PenLineCap.Round,
                EndLineCap = PenLineCap.Round,
                LineJoin = PenLineJoin.Round
            }, geo);
        }
    }

    internal sealed class HighlightItem : AnnotationItem
    {
        public Rect Bounds { get; set; }

        public override void Draw(DrawingContext dc)
        {
            var c = Color;
            c.A = 90;
            dc.DrawRectangle(new SolidColorBrush(c), null, Bounds);
        }
    }

    internal sealed class RectItem : AnnotationItem
    {
        public Rect Bounds { get; set; }

        public override void Draw(DrawingContext dc)
        {
            dc.DrawRectangle(null, new MediaPen(new SolidColorBrush(Color), Thickness), Bounds);
        }
    }

    internal sealed class EllipseItem : AnnotationItem
    {
        public Rect Bounds { get; set; }

        public override void Draw(DrawingContext dc)
        {
            dc.DrawEllipse(null, new MediaPen(new SolidColorBrush(Color), Thickness),
                new WpfPoint(Bounds.X + Bounds.Width / 2, Bounds.Y + Bounds.Height / 2),
                Math.Abs(Bounds.Width / 2), Math.Abs(Bounds.Height / 2));
        }
    }

    internal sealed class ArrowItem : AnnotationItem
    {
        public WpfPoint Start { get; set; }
        public WpfPoint End { get; set; }

        public override void Draw(DrawingContext dc)
        {
            // 尾细头粗的实心箭头（类似 Snipaste / 标注工具常见样式）
            var dx = End.X - Start.X;
            var dy = End.Y - Start.Y;
            var len = Math.Sqrt(dx * dx + dy * dy);
            if (len < 2) return;

            var ux = dx / len;
            var uy = dy / len;
            // 垂直于箭头方向的单位向量
            var px = -uy;
            var py = ux;

            // 箭头头部尺寸随粗细变化，同时避免短线段时头比身还长
            double headLen = Math.Min(Math.Max(16, Thickness * 5.5), len * 0.42);
            double headHalf = headLen * 0.55;                 // 翼展半宽
            double shaftHalf = Math.Max(Thickness * 0.75, headHalf * 0.30); // 接头部的杆宽
            double joinDist = headLen * 0.62;                 // 杆与头衔接处（比翼更靠近尖端，形成倒刺）

            var tip = End;
            var leftWing = new WpfPoint(
                End.X - ux * headLen + px * headHalf,
                End.Y - uy * headLen + py * headHalf);
            var leftJoin = new WpfPoint(
                End.X - ux * joinDist + px * shaftHalf,
                End.Y - uy * joinDist + py * shaftHalf);
            var rightJoin = new WpfPoint(
                End.X - ux * joinDist - px * shaftHalf,
                End.Y - uy * joinDist - py * shaftHalf);
            var rightWing = new WpfPoint(
                End.X - ux * headLen - px * headHalf,
                End.Y - uy * headLen - py * headHalf);
            var tail = Start; // 尾端收成针尖

            var geo = new StreamGeometry { FillRule = FillRule.Nonzero };
            using (var ctx = geo.Open())
            {
                ctx.BeginFigure(tip, isFilled: true, isClosed: true);
                ctx.LineTo(leftWing, true, false);
                ctx.LineTo(leftJoin, true, false);
                ctx.LineTo(tail, true, false);
                ctx.LineTo(rightJoin, true, false);
                ctx.LineTo(rightWing, true, false);
            }
            geo.Freeze();
            dc.DrawGeometry(new SolidColorBrush(Color), null, geo);
        }
    }
}

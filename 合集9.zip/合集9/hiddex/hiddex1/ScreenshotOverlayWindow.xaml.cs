using System.Drawing;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using Brushes = System.Windows.Media.Brushes;
using Button = System.Windows.Controls.Button;
using Color = System.Windows.Media.Color;
using ColorConverter = System.Windows.Media.ColorConverter;
using KeyEventArgs = System.Windows.Input.KeyEventArgs;
using MessageBox = System.Windows.MessageBox;
using MouseEventArgs = System.Windows.Input.MouseEventArgs;
using Point = System.Windows.Point;
using Rectangle = System.Drawing.Rectangle;
using WpfTextBox = System.Windows.Controls.TextBox;

namespace HiddenWindowManager
{
    public partial class ScreenshotOverlayWindow : Window
    {
        private enum Stage { Selecting, Editing }

        private readonly Bitmap _screenBitmap;
        private readonly BitmapSource _screenSource;

        private Stage _stage = Stage.Selecting;
        private bool _dragging;
        private Point _start;
        private Point _current;
        private Rect _selection;

        private AnnotTool _tool = AnnotTool.Move;
        private Color _color = (Color)ColorConverter.ConvertFromString("#FF3B30")!;
        private bool _drawing;
        private bool _movingSelection;
        private Point _drawStart;
        private Point _moveMouseOrigin;
        private Rect _selectionAtMoveStart;
        private PenStrokeItem? _activeStroke;

        public ScreenshotOverlayWindow(Bitmap screenBitmap)
        {
            _screenBitmap = screenBitmap;
            _screenSource = ScreenCaptureHelper.ToBitmapSource(screenBitmap);
            InitializeComponent();

            ScreenImage.Source = _screenSource;

            var vs = ScreenCaptureHelper.VirtualScreenBounds;
            Left = SystemParameters.VirtualScreenLeft;
            Top = SystemParameters.VirtualScreenTop;
            Width = SystemParameters.VirtualScreenWidth;
            Height = SystemParameters.VirtualScreenHeight;

            if (Width < 100 || Height < 100)
            {
                Left = vs.Left;
                Top = vs.Top;
                Width = vs.Width;
                Height = vs.Height;
            }

            InitOcrLanguages();
            SelectTool(AnnotTool.Move);

            Loaded += (_, _) =>
            {
                double w = CanvasRoot.ActualWidth;
                double h = CanvasRoot.ActualHeight;
                PlaceMask(MaskTop, 0, 0, w, h);
                PlaceMask(MaskBottom, 0, 0, 0, 0);
                PlaceMask(MaskLeft, 0, 0, 0, 0);
                PlaceMask(MaskRight, 0, 0, 0, 0);

                Activate();
                Focus();
                Keyboard.Focus(this);
            };
        }

        private double StrokeThickness => Math.Max(1, ThicknessSlider.Value);

        // ---------------------------------------------------------------
        // 选区阶段
        // ---------------------------------------------------------------
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                if (_stage == Stage.Editing)
                    ExitToSelecting();
                else
                    Cancel();
                e.Handled = true;
                return;
            }

            if (_stage == Stage.Editing)
            {
                if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.Z)
                {
                    Undo();
                    e.Handled = true;
                }
                else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.C)
                {
                    if (Keyboard.FocusedElement is WpfTextBox) return;
                    CopyAndClose();
                    e.Handled = true;
                }
                else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.S)
                {
                    SaveImage();
                    e.Handled = true;
                }
                else if (e.Key == Key.Enter)
                {
                    CopyAndClose();
                    e.Handled = true;
                }
                return;
            }

            if (e.Key == Key.Enter)
            {
                if (_dragging || HasValidSelection())
                    EnterEditing(GetSelectionRect());
                else
                    EnterEditing(new Rect(0, 0, CanvasRoot.ActualWidth, CanvasRoot.ActualHeight));
                e.Handled = true;
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_stage != Stage.Selecting) return;
            // 点到底部按钮时不要开始选区
            if (e.OriginalSource is DependencyObject d && IsDescendantOf(d, SelectBottomBar))
                return;

            _dragging = true;
            _start = e.GetPosition(CanvasRoot);
            _current = _start;
            CaptureMouse();
            UpdateSelectionVisual();
            HintText.Text = "拖拽选择区域 · 松开后直接标注 · Esc 取消";
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (_stage != Stage.Selecting || !_dragging) return;
            _current = e.GetPosition(CanvasRoot);
            UpdateSelectionVisual();
        }

        private void Window_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_stage != Stage.Selecting || !_dragging) return;
            _dragging = false;
            _current = e.GetPosition(CanvasRoot);
            ReleaseMouseCapture();
            UpdateSelectionVisual();

            if (HasValidSelection())
                EnterEditing(GetSelectionRect());
            else
                HintText.Text = "选区太小，请重新拖拽；或按 Enter / 全屏截图 · Esc 取消";
        }

        private void Window_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_stage == Stage.Editing)
                ExitToSelecting();
            else
                Cancel();
            e.Handled = true;
        }

        private static bool IsDescendantOf(DependencyObject? node, DependencyObject ancestor)
        {
            while (node != null)
            {
                if (ReferenceEquals(node, ancestor)) return true;
                node = System.Windows.Media.VisualTreeHelper.GetParent(node);
            }
            return false;
        }

        private bool HasValidSelection()
        {
            var r = GetSelectionRect();
            return r.Width >= 4 && r.Height >= 4;
        }

        private Rect GetSelectionRect()
        {
            var x = Math.Min(_start.X, _current.X);
            var y = Math.Min(_start.Y, _current.Y);
            var w = Math.Abs(_current.X - _start.X);
            var h = Math.Abs(_current.Y - _start.Y);
            return new Rect(x, y, w, h);
        }

        private void UpdateSelectionVisual()
        {
            var r = _stage == Stage.Editing ? _selection : GetSelectionRect();
            ApplySelectionChrome(r);
        }

        private void ApplySelectionChrome(Rect r)
        {
            SelectionRect.Width = r.Width;
            SelectionRect.Height = r.Height;
            Canvas.SetLeft(SelectionRect, r.X);
            Canvas.SetTop(SelectionRect, r.Y);
            SelectionRect.Visibility = r.Width > 0 && r.Height > 0 ? Visibility.Visible : Visibility.Collapsed;

            double W = CanvasRoot.ActualWidth;
            double H = CanvasRoot.ActualHeight;
            if (W <= 0 || H <= 0) return;

            PlaceMask(MaskTop, 0, 0, W, Math.Max(0, r.Y));
            PlaceMask(MaskBottom, 0, r.Y + r.Height, W, Math.Max(0, H - r.Y - r.Height));
            PlaceMask(MaskLeft, 0, r.Y, Math.Max(0, r.X), r.Height);
            PlaceMask(MaskRight, r.X + r.Width, r.Y, Math.Max(0, W - r.X - r.Width), r.Height);

            SizeLabel.Text = $"{(int)r.Width} × {(int)r.Height}";
            Canvas.SetLeft(SizeLabelBorder, r.X);
            Canvas.SetTop(SizeLabelBorder, Math.Max(0, r.Y - 28));
            SizeLabelBorder.Visibility = r.Width > 0 && r.Height > 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private static void PlaceMask(System.Windows.Shapes.Rectangle rect, double x, double y, double w, double h)
        {
            rect.Width = Math.Max(0, w);
            rect.Height = Math.Max(0, h);
            Canvas.SetLeft(rect, x);
            Canvas.SetTop(rect, y);
        }

        private Rectangle MapToBitmapPixels(Rect dipRect)
        {
            double scaleX = _screenBitmap.Width / Math.Max(1.0, CanvasRoot.ActualWidth);
            double scaleY = _screenBitmap.Height / Math.Max(1.0, CanvasRoot.ActualHeight);

            int x = (int)Math.Floor(dipRect.X * scaleX);
            int y = (int)Math.Floor(dipRect.Y * scaleY);
            int w = (int)Math.Ceiling(dipRect.Width * scaleX);
            int h = (int)Math.Ceiling(dipRect.Height * scaleY);

            return new Rectangle(x, y, w, h);
        }

        // ---------------------------------------------------------------
        // 进入 / 退出编辑
        // ---------------------------------------------------------------
        private void EnterEditing(Rect selection)
        {
            _selection = selection;
            _stage = Stage.Editing;
            Cursor = System.Windows.Input.Cursors.Arrow;

            ApplySelectionChrome(_selection);

            EditHost.Width = _selection.Width;
            EditHost.Height = _selection.Height;
            Canvas.SetLeft(EditHost, _selection.X);
            Canvas.SetTop(EditHost, _selection.Y);
            EditHost.Visibility = Visibility.Visible;

            AnnoLayer.Width = _selection.Width;
            AnnoLayer.Height = _selection.Height;
            AnnoLayer.ClearAll();

            // 编辑阶段可选中选区边框进行拖动
            SelectionRect.IsHitTestVisible = true;

            SelectBottomBar.Visibility = Visibility.Collapsed;
            EditToolbar.Visibility = Visibility.Visible;
            PlaceToolbar();

            HintText.Text = "可拖动选区 · 工具条切换标注 · Enter 完成 · Esc 重选";
            SelectTool(AnnotTool.Move);
        }

        private void PlaceToolbar()
        {
            EditToolbar.UpdateLayout();
            double tw = EditToolbar.ActualWidth > 0 ? EditToolbar.ActualWidth : 780;
            double th = EditToolbar.ActualHeight > 0 ? EditToolbar.ActualHeight : 48;

            double x = _selection.X;
            double y = _selection.Y + _selection.Height + 10;

            // 底部放不下则放到选区上方
            if (y + th > CanvasRoot.ActualHeight - 8)
                y = Math.Max(8, _selection.Y - th - 10);

            // 水平钳制
            if (x + tw > CanvasRoot.ActualWidth - 8)
                x = Math.Max(8, CanvasRoot.ActualWidth - tw - 8);
            if (x < 8) x = 8;

            Canvas.SetLeft(EditToolbar, x);
            Canvas.SetTop(EditToolbar, y);

            // 布局变化后再校正一次（OCR 展开后也要调）
            Dispatcher.BeginInvoke(new Action(() =>
            {
                tw = EditToolbar.ActualWidth;
                th = EditToolbar.ActualHeight;
                y = _selection.Y + _selection.Height + 10;
                if (y + th > CanvasRoot.ActualHeight - 8)
                    y = Math.Max(8, _selection.Y - th - 10);
                x = _selection.X;
                if (x + tw > CanvasRoot.ActualWidth - 8)
                    x = Math.Max(8, CanvasRoot.ActualWidth - tw - 8);
                Canvas.SetLeft(EditToolbar, x);
                Canvas.SetTop(EditToolbar, y);
            }), System.Windows.Threading.DispatcherPriority.Loaded);
        }

        private void ExitToSelecting()
        {
            _stage = Stage.Selecting;
            Cursor = System.Windows.Input.Cursors.Cross;
            _dragging = false;
            AnnoLayer.ClearAll();
            EditHost.Visibility = Visibility.Collapsed;
            EditToolbar.Visibility = Visibility.Collapsed;
            OcrInlinePanel.Visibility = Visibility.Collapsed;
            SelectBottomBar.Visibility = Visibility.Visible;

            double w = CanvasRoot.ActualWidth;
            double h = CanvasRoot.ActualHeight;
            PlaceMask(MaskTop, 0, 0, w, h);
            PlaceMask(MaskBottom, 0, 0, 0, 0);
            PlaceMask(MaskLeft, 0, 0, 0, 0);
            PlaceMask(MaskRight, 0, 0, 0, 0);
            SelectionRect.Visibility = Visibility.Collapsed;
            SelectionRect.IsHitTestVisible = false;
            SizeLabelBorder.Visibility = Visibility.Collapsed;
            _movingSelection = false;

            HintText.Text = "拖拽选择截图区域 · Enter 全屏 · Esc 取消";
        }

        private void FullScreenButton_Click(object sender, RoutedEventArgs e)
        {
            EnterEditing(new Rect(0, 0, CanvasRoot.ActualWidth, CanvasRoot.ActualHeight));
        }

        private void ReselectButton_Click(object sender, RoutedEventArgs e) => ExitToSelecting();

        private void CancelButton_Click(object sender, RoutedEventArgs e) => Cancel();

        private void Cancel()
        {
            DialogResult = false;
            Close();
        }

        private void DoneButton_Click(object sender, RoutedEventArgs e) => CopyAndClose();

        // ---------------------------------------------------------------
        // 标注
        // ---------------------------------------------------------------
        private void ToolButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not string tag) return;
            if (Enum.TryParse<AnnotTool>(tag, out var tool))
                SelectTool(tool);
        }

        private void SelectTool(AnnotTool tool)
        {
            _tool = tool;
            UpdateToolHighlight();
            EditHost.Cursor = tool == AnnotTool.Move
                ? System.Windows.Input.Cursors.SizeAll
                : System.Windows.Input.Cursors.Cross;
            AnnoLayer.Cursor = EditHost.Cursor;
        }

        private void UpdateToolHighlight()
        {
            HighlightTool(ToolMove, _tool == AnnotTool.Move);
            HighlightTool(ToolPen, _tool == AnnotTool.Pen);
            HighlightTool(ToolHighlight, _tool == AnnotTool.Highlight);
            HighlightTool(ToolRect, _tool == AnnotTool.Rectangle);
            HighlightTool(ToolEllipse, _tool == AnnotTool.Ellipse);
            HighlightTool(ToolArrow, _tool == AnnotTool.Arrow);
        }

        private static void HighlightTool(Button btn, bool on)
        {
            var accent = System.Windows.Application.Current?.TryFindResource("AccentBrush") as System.Windows.Media.Brush
                         ?? Brushes.MediumPurple;
            var normal = System.Windows.Application.Current?.TryFindResource("TextPrimaryBrush") as System.Windows.Media.Brush
                         ?? Brushes.White;
            btn.Foreground = on ? accent : normal;
            btn.FontWeight = on ? FontWeights.SemiBold : FontWeights.Normal;
        }

        private void ColorButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not string hex) return;
            _color = (Color)ColorConverter.ConvertFromString(hex)!;
        }

        private void Anno_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_stage != Stage.Editing) return;

            if (_tool == AnnotTool.Move)
            {
                BeginMoveSelection(e.GetPosition(CanvasRoot));
                AnnoLayer.CaptureMouse();
                e.Handled = true;
                return;
            }

            _drawing = true;
            _drawStart = e.GetPosition(AnnoLayer);
            AnnoLayer.CaptureMouse();

            if (_tool == AnnotTool.Pen)
            {
                _activeStroke = new PenStrokeItem { Color = _color, Thickness = StrokeThickness };
                _activeStroke.Points.Add(_drawStart);
                AnnoLayer.SetPreview(_activeStroke);
            }
            e.Handled = true;
        }

        private void Anno_MouseMove(object sender, MouseEventArgs e)
        {
            if (_movingSelection)
            {
                UpdateMoveSelection(e.GetPosition(CanvasRoot));
                e.Handled = true;
                return;
            }

            if (!_drawing) return;
            var p = e.GetPosition(AnnoLayer);

            switch (_tool)
            {
                case AnnotTool.Pen:
                    if (_activeStroke != null)
                    {
                        _activeStroke.Points.Add(p);
                        AnnoLayer.SetPreview(_activeStroke);
                    }
                    break;
                case AnnotTool.Highlight:
                    AnnoLayer.SetPreview(new HighlightItem { Color = _color, Bounds = NormalizeRect(_drawStart, p) });
                    break;
                case AnnotTool.Rectangle:
                    AnnoLayer.SetPreview(new RectItem { Color = _color, Thickness = StrokeThickness, Bounds = NormalizeRect(_drawStart, p) });
                    break;
                case AnnotTool.Ellipse:
                    AnnoLayer.SetPreview(new EllipseItem { Color = _color, Thickness = StrokeThickness, Bounds = NormalizeRect(_drawStart, p) });
                    break;
                case AnnotTool.Arrow:
                    AnnoLayer.SetPreview(new ArrowItem { Color = _color, Thickness = StrokeThickness, Start = _drawStart, End = p });
                    break;
            }
            e.Handled = true;
        }

        private void Anno_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_movingSelection)
            {
                EndMoveSelection();
                AnnoLayer.ReleaseMouseCapture();
                e.Handled = true;
                return;
            }

            if (!_drawing) return;
            _drawing = false;
            AnnoLayer.ReleaseMouseCapture();
            var p = e.GetPosition(AnnoLayer);

            AnnotationItem? finished = _tool switch
            {
                AnnotTool.Pen when _activeStroke != null && _activeStroke.Points.Count >= 2 => _activeStroke,
                AnnotTool.Highlight => new HighlightItem { Color = _color, Bounds = NormalizeRect(_drawStart, p) },
                AnnotTool.Rectangle => new RectItem { Color = _color, Thickness = StrokeThickness, Bounds = NormalizeRect(_drawStart, p) },
                AnnotTool.Ellipse => new EllipseItem { Color = _color, Thickness = StrokeThickness, Bounds = NormalizeRect(_drawStart, p) },
                AnnotTool.Arrow => new ArrowItem { Color = _color, Thickness = StrokeThickness, Start = _drawStart, End = p },
                _ => null
            };

            AnnoLayer.SetPreview(null);
            _activeStroke = null;

            if (finished != null && IsMeaningful(finished))
                AnnoLayer.Add(finished);

            e.Handled = true;
        }

        // 通过选区边框拖动（移动工具下也可点在边框上）
        private void Selection_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_stage != Stage.Editing) return;
            BeginMoveSelection(e.GetPosition(CanvasRoot));
            SelectionRect.CaptureMouse();
            e.Handled = true;
        }

        private void Selection_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_movingSelection) return;
            UpdateMoveSelection(e.GetPosition(CanvasRoot));
            e.Handled = true;
        }

        private void Selection_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (!_movingSelection) return;
            EndMoveSelection();
            SelectionRect.ReleaseMouseCapture();
            e.Handled = true;
        }

        private void BeginMoveSelection(Point canvasPos)
        {
            _movingSelection = true;
            _moveMouseOrigin = canvasPos;
            _selectionAtMoveStart = _selection;
        }

        private void UpdateMoveSelection(Point canvasPos)
        {
            if (!_movingSelection) return;

            double dx = canvasPos.X - _moveMouseOrigin.X;
            double dy = canvasPos.Y - _moveMouseOrigin.Y;
            double maxX = Math.Max(0, CanvasRoot.ActualWidth - _selectionAtMoveStart.Width);
            double maxY = Math.Max(0, CanvasRoot.ActualHeight - _selectionAtMoveStart.Height);
            double nx = Math.Clamp(_selectionAtMoveStart.X + dx, 0, maxX);
            double ny = Math.Clamp(_selectionAtMoveStart.Y + dy, 0, maxY);

            _selection = new Rect(nx, ny, _selectionAtMoveStart.Width, _selectionAtMoveStart.Height);
            ApplySelectionChrome(_selection);
            Canvas.SetLeft(EditHost, _selection.X);
            Canvas.SetTop(EditHost, _selection.Y);
            PlaceToolbar();
        }

        private void EndMoveSelection()
        {
            if (!_movingSelection) return;
            _movingSelection = false;

            // 选区挪到新位置后，旧标注会错位，清空更合理
            if (Math.Abs(_selection.X - _selectionAtMoveStart.X) > 0.5
                || Math.Abs(_selection.Y - _selectionAtMoveStart.Y) > 0.5)
            {
                AnnoLayer.ClearAll();
            }
        }

        private static bool IsMeaningful(AnnotationItem item) => item switch
        {
            PenStrokeItem s => s.Points.Count >= 2,
            HighlightItem h => Math.Min(h.Bounds.Width, h.Bounds.Height) >= 4,
            RectItem r => Math.Min(r.Bounds.Width, r.Bounds.Height) >= 4,
            EllipseItem el => Math.Min(el.Bounds.Width, el.Bounds.Height) >= 4,
            ArrowItem a => Math.Abs(a.End.X - a.Start.X) + Math.Abs(a.End.Y - a.Start.Y) >= 4,
            _ => true
        };

        private static Rect NormalizeRect(Point a, Point b) => new(
            Math.Min(a.X, b.X), Math.Min(a.Y, b.Y),
            Math.Abs(a.X - b.X), Math.Abs(a.Y - b.Y));

        private void UndoButton_Click(object sender, RoutedEventArgs e) => Undo();

        private void Undo()
        {
            if (!AnnoLayer.Undo())
                HintText.Text = "没有可撤销的标注";
        }

        // ---------------------------------------------------------------
        // 导出 / OCR
        // ---------------------------------------------------------------
        private BitmapSource? BuildFinalImage()
        {
            try
            {
                var pixelRect = MapToBitmapPixels(_selection);
                using var cropped = ScreenCaptureHelper.Crop(_screenBitmap, pixelRect);
                var src = ScreenCaptureHelper.ToBitmapSource(cropped);

                AnnoLayer.Width = _selection.Width;
                AnnoLayer.Height = _selection.Height;
                AnnoLayer.Measure(new System.Windows.Size(_selection.Width, _selection.Height));
                AnnoLayer.Arrange(new Rect(0, 0, _selection.Width, _selection.Height));

                return AnnoLayer.RenderCombined(src) ?? src;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "生成图片失败：" + ex.Message, "截图",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }
        }

        private void CopyButton_Click(object sender, RoutedEventArgs e) => CopyAndClose();

        private void CopyAndClose()
        {
            var img = BuildFinalImage();
            if (img == null) return;
            ScreenCaptureHelper.CopyToClipboard(img);
            DialogResult = true;
            Close();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e) => SaveImage();

        private void SaveImage()
        {
            var img = BuildFinalImage();
            if (img == null) return;

            // 临时降低置顶，避免挡住保存对话框
            Topmost = false;
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "PNG 图片|*.png|JPEG 图片|*.jpg",
                FileName = $"hiddex_{DateTime.Now:yyyyMMdd_HHmmss}",
                AddExtension = true,
                DefaultExt = ".png"
            };

            bool? ok = dlg.ShowDialog(this);
            Topmost = true;
            Activate();

            if (ok != true) return;

            try
            {
                if (dlg.FilterIndex == 2
                    || dlg.FileName.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase)
                    || dlg.FileName.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase))
                {
                    var encoder = new JpegBitmapEncoder { QualityLevel = 92 };
                    encoder.Frames.Add(BitmapFrame.Create(img));
                    using var fs = File.Create(dlg.FileName);
                    encoder.Save(fs);
                }
                else
                {
                    ScreenCaptureHelper.SavePng(img, dlg.FileName);
                }
                HintText.Text = "已保存：" + dlg.FileName;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "保存失败：" + ex.Message, "截图",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void InitOcrLanguages()
        {
            var langs = OcrService.GetAvailableLanguages();
            OcrLanguageCombo.ItemsSource = langs;
            if (langs.Count == 0)
            {
                OcrLanguageCombo.IsEnabled = false;
                OcrButton.IsEnabled = false;
                return;
            }

            var preferred = langs.FirstOrDefault(l => l.Tag.StartsWith("zh-Hans", StringComparison.OrdinalIgnoreCase))
                ?? langs.FirstOrDefault(l => l.Tag.StartsWith("zh", StringComparison.OrdinalIgnoreCase))
                ?? langs.FirstOrDefault(l => l.Tag.StartsWith("en", StringComparison.OrdinalIgnoreCase))
                ?? langs[0];
            OcrLanguageCombo.SelectedItem = preferred;
        }

        private async void OcrButton_Click(object sender, RoutedEventArgs e)
        {
            var img = BuildFinalImage();
            if (img == null) return;

            var tag = (OcrLanguageCombo.SelectedItem as OcrLanguageOption)?.Tag;
            OcrButton.IsEnabled = false;
            HintText.Text = "正在识别文字…";

            try
            {
                var text = await OcrService.RecognizeAsync(img, tag);
                OcrResultBox.Text = string.IsNullOrWhiteSpace(text) ? "（未识别到文字）" : text;
                OcrInlinePanel.Visibility = Visibility.Visible;
                PlaceToolbar();
                HintText.Text = string.IsNullOrWhiteSpace(text) ? "未识别到文字" : "识别完成（结果在工具条下方）";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "OCR", MessageBoxButton.OK, MessageBoxImage.Warning);
                HintText.Text = "OCR 失败";
            }
            finally
            {
                OcrButton.IsEnabled = OcrLanguageCombo.Items.Count > 0;
            }
        }

        private void CopyOcrText_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(OcrResultBox.Text)) return;
            System.Windows.Clipboard.SetText(OcrResultBox.Text);
            HintText.Text = "已复制识别文字";
        }

        private void CloseOcrInline_Click(object sender, RoutedEventArgs e)
        {
            OcrInlinePanel.Visibility = Visibility.Collapsed;
            PlaceToolbar();
        }
    }
}

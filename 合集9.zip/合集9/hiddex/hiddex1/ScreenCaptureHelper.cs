using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using PixelFormat = System.Drawing.Imaging.PixelFormat;

namespace HiddenWindowManager
{
    /// <summary>
    /// 屏幕截取工具：捕获虚拟桌面（多显示器），并在 Bitmap / BitmapSource 之间转换。
    /// </summary>
    internal static class ScreenCaptureHelper
    {
        public static Rectangle VirtualScreenBounds =>
            System.Windows.Forms.SystemInformation.VirtualScreen;

        public static Bitmap CaptureVirtualScreen()
        {
            var vs = VirtualScreenBounds;
            var bmp = new Bitmap(vs.Width, vs.Height, PixelFormat.Format32bppArgb);
            using var g = Graphics.FromImage(bmp);
            g.CopyFromScreen(vs.Left, vs.Top, 0, 0, bmp.Size, CopyPixelOperation.SourceCopy);
            return bmp;
        }

        public static Bitmap Crop(Bitmap source, Rectangle region)
        {
            region = Rectangle.Intersect(region, new Rectangle(0, 0, source.Width, source.Height));
            if (region.Width <= 0 || region.Height <= 0)
                throw new ArgumentException("截取区域无效。");

            var cropped = new Bitmap(region.Width, region.Height, PixelFormat.Format32bppArgb);
            using var g = Graphics.FromImage(cropped);
            g.DrawImage(source, new Rectangle(0, 0, region.Width, region.Height), region, GraphicsUnit.Pixel);
            return cropped;
        }

        public static BitmapSource ToBitmapSource(Bitmap bitmap)
        {
            using var ms = new MemoryStream();
            bitmap.Save(ms, ImageFormat.Png);
            ms.Position = 0;
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.StreamSource = ms;
            image.EndInit();
            image.Freeze();
            return image;
        }

        public static Bitmap ToBitmap(BitmapSource source)
        {
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(source));
            using var ms = new MemoryStream();
            encoder.Save(ms);
            ms.Position = 0;
            return new Bitmap(ms);
        }

        public static void CopyToClipboard(BitmapSource source)
        {
            System.Windows.Clipboard.SetImage(source);
        }

        public static void SavePng(BitmapSource source, string path)
        {
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(source));
            using var fs = File.Create(path);
            encoder.Save(fs);
        }
    }
}

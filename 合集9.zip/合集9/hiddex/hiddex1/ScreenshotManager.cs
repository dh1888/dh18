using System.Drawing;
using System.Windows;
using MessageBox = System.Windows.MessageBox;

namespace HiddenWindowManager
{
    /// <summary>
    /// 截图流程入口：冻结画面 → 选区 → 原地标注 / OCR / 复制保存。
    /// </summary>
    internal static class ScreenshotManager
    {
        private static bool _busy;

        public static void StartCapture()
        {
            if (_busy) return;
            _busy = true;

            Bitmap? frozen = null;
            try
            {
                frozen = ScreenCaptureHelper.CaptureVirtualScreen();

                var overlay = new ScreenshotOverlayWindow(frozen)
                {
                    Topmost = true
                };

                NativeMethods.AllowSetForegroundWindow(NativeMethods.ASFW_ANY);
                overlay.Loaded += (_, _) => overlay.Activate();
                overlay.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("启动截图失败：" + ex.Message, "截图",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            finally
            {
                frozen?.Dispose();
                _busy = false;
            }
        }
    }
}

using System.Drawing;
using System.IO;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage.Streams;
using WpfBitmapSource = System.Windows.Media.Imaging.BitmapSource;

namespace HiddenWindowManager
{
    /// <summary>
    /// 基于 Windows.Media.Ocr 的本地多语言文字识别。
    /// 识别能力取决于系统已安装的 OCR 语言包（设置 → 时间和语言 → 语言）。
    /// </summary>
    internal static class OcrService
    {
        public static IReadOnlyList<OcrLanguageOption> GetAvailableLanguages()
        {
            return OcrEngine.AvailableRecognizerLanguages
                .Select(l => new OcrLanguageOption(l.LanguageTag, l.DisplayName))
                .OrderBy(l => l.DisplayName, StringComparer.CurrentCultureIgnoreCase)
                .ToList();
        }

        public static async Task<string> RecognizeAsync(WpfBitmapSource image, string? languageTag = null)
        {
            var engine = CreateEngine(languageTag)
                ?? throw new InvalidOperationException(
                    "未找到可用的 OCR 语言包。请在 Windows「设置 → 时间和语言 → 语言和区域」中安装语言的「文本识别」功能。");

            using var softwareBitmap = await ToSoftwareBitmapAsync(image);
            var result = await engine.RecognizeAsync(softwareBitmap);
            return result.Text?.Trim() ?? string.Empty;
        }

        private static OcrEngine? CreateEngine(string? languageTag)
        {
            if (!string.IsNullOrWhiteSpace(languageTag))
            {
                var match = OcrEngine.AvailableRecognizerLanguages
                    .FirstOrDefault(l => string.Equals(l.LanguageTag, languageTag, StringComparison.OrdinalIgnoreCase));
                if (match != null)
                {
                    var engine = OcrEngine.TryCreateFromLanguage(match);
                    if (engine != null) return engine;
                }
            }

            return OcrEngine.TryCreateFromUserProfileLanguages()
                ?? OcrEngine.AvailableRecognizerLanguages
                    .Select(OcrEngine.TryCreateFromLanguage)
                    .FirstOrDefault(e => e != null);
        }

        private static async Task<SoftwareBitmap> ToSoftwareBitmapAsync(WpfBitmapSource source)
        {
            var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
            encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(source));

            using var managed = new MemoryStream();
            encoder.Save(managed);
            var bytes = managed.ToArray();

            var random = new InMemoryRandomAccessStream();
            await random.WriteAsync(bytes.AsBuffer());
            random.Seek(0);

            var decoder = await BitmapDecoder.CreateAsync(random);
            var soft = await decoder.GetSoftwareBitmapAsync(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Premultiplied);
            return soft;
        }
    }

    internal sealed record OcrLanguageOption(string Tag, string DisplayName)
    {
        public override string ToString() => string.IsNullOrWhiteSpace(DisplayName) ? Tag : $"{DisplayName} ({Tag})";
    }
}

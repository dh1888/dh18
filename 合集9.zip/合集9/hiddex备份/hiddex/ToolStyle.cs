namespace HiddenWindowManager
{
    /// <summary>
    /// 单个标注工具的样式（颜色 + 大小）。每个工具各存一份，
    /// 这样切换工具时不会互相覆盖 —— 箭头调粗不影响画笔，矩形的细边框也能保住。
    /// </summary>
    public sealed class ToolStyle
    {
        public string Color { get; set; } = "#FF3B30";

        /// <summary>
        /// 大小。含义随工具而变：
        /// 画笔/矩形/椭圆/箭头 = 线宽；文字 = 字号；马赛克 = 色块边长。
        /// </summary>
        public double Size { get; set; } = 3;
    }

    /// <summary>
    /// 各工具的默认值和可调范围。"恢复默认"按钮读的就是这里。
    /// </summary>
    internal static class ToolStyleDefaults
    {
        public const string DefaultColor = "#FF3B30";

        /// <summary>默认大小。矩形/椭圆/箭头刻意比画笔细，边框太粗会糊住内容。</summary>
        public static double SizeOf(AnnotTool tool) => tool switch
        {
            AnnotTool.Pen => 4,
            AnnotTool.Highlight => 1,     // 高亮不用线宽
            AnnotTool.Rectangle => 2,     // 细边框
            AnnotTool.Ellipse => 2,
            AnnotTool.Arrow => 5,
            AnnotTool.Text => 22,         // 字号
            AnnotTool.Mosaic => 12,       // 色块边长
            _ => 3
        };

        public static double MinOf(AnnotTool tool) => tool switch
        {
            AnnotTool.Text => 8,
            AnnotTool.Mosaic => 4,
            _ => 1
        };

        public static double MaxOf(AnnotTool tool) => tool switch
        {
            AnnotTool.Text => 96,
            AnnotTool.Mosaic => 60,
            _ => 40
        };

        /// <summary>大小这一项对该工具有意义吗（高亮只认颜色）。</summary>
        public static bool UsesSize(AnnotTool tool) =>
            tool != AnnotTool.Highlight && tool != AnnotTool.Move;

        /// <summary>颜色这一项对该工具有意义吗（马赛克无颜色）。</summary>
        public static bool UsesColor(AnnotTool tool) =>
            tool != AnnotTool.Mosaic && tool != AnnotTool.Move;

        /// <summary>大小这一项在界面上的名字。</summary>
        public static string SizeLabelOf(AnnotTool tool) => tool switch
        {
            AnnotTool.Text => "字号",
            AnnotTool.Mosaic => "块",
            _ => "粗细"
        };
    }
}

using System.Windows;

namespace HiddenWindowManager
{
    public partial class PasswordDialog : Window
    {
        public string EnteredPassword => PasswordBox.Password;

        public PasswordDialog(string title)
        {
            InitializeComponent();
            TitleLabel.Text = title;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}

using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using PixelFormat = System.Drawing.Imaging.PixelFormat;

namespace HiddenWindowManager
{
    /// <summary>
    /// 屏幕截取工具：捕获虚拟桌面（多显示器），并在 Bitmap / BitmapSource 之间转换。
    /// </summary>
    internal static class ScreenCaptureHelper
    {
        public static Rectangle VirtualScreenBounds =>
            System.Windows.Forms.SystemInformation.VirtualScreen;

        public static Bitmap CaptureVirtualScreen()
        {
            var vs = VirtualScreenBounds;
            var bmp = new Bitmap(vs.Width, vs.Height, PixelFormat.Format32bppArgb);
            using var g = Graphics.FromImage(bmp);
            g.CopyFromScreen(vs.Left, vs.Top, 0, 0, bmp.Size, CopyPixelOperation.SourceCopy);
            return bmp;
        }

        public static Bitmap Crop(Bitmap source, Rectangle region)
        {
            region = Rectangle.Intersect(region, new Rectangle(0, 0, source.Width, source.Height));
            if (region.Width <= 0 || region.Height <= 0)
                throw new ArgumentException("截取区域无效。");

            var cropped = new Bitmap(region.Width, region.Height, PixelFormat.Format32bppArgb);
            using var g = Graphics.FromImage(cropped);
            g.DrawImage(source, new Rectangle(0, 0, region.Width, region.Height), region, GraphicsUnit.Pixel);
            return cropped;
        }

        /// <summary>
        /// 高质量缩放。OCR 前放大小字用：Windows OCR 对小于约 25px 高的字识别率很差，
        /// 放大后能显著提升命中率。
        /// </summary>
        public static Bitmap Scale(Bitmap source, double factor)
        {
            int w = Math.Max(1, (int)Math.Round(source.Width * factor));
            int h = Math.Max(1, (int)Math.Round(source.Height * factor));

            var dest = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            using var g = Graphics.FromImage(dest);
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            g.DrawImage(source, new Rectangle(0, 0, w, h),
                new Rectangle(0, 0, source.Width, source.Height), GraphicsUnit.Pixel);
            return dest;
        }

        /// <summary>
        /// 马赛克：先按 blockSize 缩小（双线性取平均色），再用最近邻放回原尺寸，
        /// 得到硬边色块。blockSize 为像素单位。
        /// </summary>
        public static Bitmap Pixelate(Bitmap source, int blockSize)
        {
            blockSize = Math.Max(2, blockSize);

            int sw = Math.Max(1, source.Width / blockSize);
            int sh = Math.Max(1, source.Height / blockSize);

            using var small = new Bitmap(sw, sh, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(small))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                g.DrawImage(source, new Rectangle(0, 0, sw, sh),
                    new Rectangle(0, 0, source.Width, source.Height), GraphicsUnit.Pixel);
            }

            var result = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(result))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.Half;
                g.DrawImage(small, new Rectangle(0, 0, result.Width, result.Height),
                    new Rectangle(0, 0, sw, sh), GraphicsUnit.Pixel);
            }
            return result;
        }

        public static BitmapSource ToBitmapSource(Bitmap bitmap)
        {
            using var ms = new MemoryStream();
            bitmap.Save(ms, ImageFormat.Png);
            ms.Position = 0;
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.StreamSource = ms;
            image.EndInit();
            image.Freeze();
            return image;
        }

        public static Bitmap ToBitmap(BitmapSource source)
        {
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(source));
            using var ms = new MemoryStream();
            encoder.Save(ms);
            ms.Position = 0;
            return new Bitmap(ms);
        }

        public static void CopyToClipboard(BitmapSource source)
        {
            System.Windows.Clipboard.SetImage(source);
        }

        public static void SavePng(BitmapSource source, string path)
        {
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(source));
            using var fs = File.Create(path);
            encoder.Save(fs);
        }
    }
}

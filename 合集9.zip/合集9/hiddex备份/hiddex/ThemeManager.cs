using System.Windows;
using System.Windows.Media;
using Application = System.Windows.Application;
using Color = System.Windows.Media.Color;
using ColorConverter = System.Windows.Media.ColorConverter;

namespace HiddenWindowManager
{
    // 运行时切换深色/浅色主题：直接把 Application.Resources 里对应的画刷(Brush)
    // 替换成新的 SolidColorBrush 实例。因为 XAML 里所有用到颜色的地方都改成了
    // {DynamicResource xxxBrush} 引用，替换资源字典里的条目后界面会立刻刷新，
    // 不需要重启窗口。
    public static class ThemeManager
    {
        private record ThemeColors(
            string BgDark, string BgPanel, string BgCard,
            string Accent, string AccentHover,
            string TextPrimary, string TextSecondary,
            string Border, string Danger,
            string CaptionHover);

        private static readonly ThemeColors Dark = new(
            BgDark: "#1B1D26", BgPanel: "#242733", BgCard: "#2C2F3E",
            Accent: "#7C6BFF", AccentHover: "#9385FF",
            TextPrimary: "#F2F2F7", TextSecondary: "#9A9CB0",
            Border: "#383B4A", Danger: "#FF6B6B",
            CaptionHover: "#3A3D4D");

        private static readonly ThemeColors Light = new(
            BgDark: "#F4F5FA", BgPanel: "#FFFFFF", BgCard: "#EFF0F7",
            Accent: "#6C5CE7", AccentHover: "#8477EE",
            TextPrimary: "#1E2029", TextSecondary: "#6B6E80",
            Border: "#E1E3ED", Danger: "#E5484D",
            CaptionHover: "#E6E7F0");

        public static void ApplyTheme(bool dark)
        {
            var app = Application.Current;
            if (app == null) return;

            var theme = dark ? Dark : Light;

            SetBrush(app, "BgDarkBrush", theme.BgDark);
            SetBrush(app, "BgPanelBrush", theme.BgPanel);
            SetBrush(app, "BgCardBrush", theme.BgCard);
            SetBrush(app, "AccentBrush", theme.Accent);
            SetBrush(app, "AccentHoverBrush", theme.AccentHover);
            SetBrush(app, "TextPrimaryBrush", theme.TextPrimary);
            SetBrush(app, "TextSecondaryBrush", theme.TextSecondary);
            SetBrush(app, "BorderBrush2", theme.Border);
            SetBrush(app, "DangerBrush", theme.Danger);
            SetBrush(app, "CaptionHoverBrush", theme.CaptionHover);

            // 选中行背景需要半透明，浅色主题下用淡淡的强调色叠加，深色主题保持原有的半透明紫色
            SetBrush(app, "SelectedRowBrush", dark ? "#33342E52" : "#1F6C5CE7");
        }

        private static void SetBrush(Application app, string key, string hex)
        {
            var color = (Color)ColorConverter.ConvertFromString(hex)!;
            app.Resources[key] = new SolidColorBrush(color);
        }
    }
}
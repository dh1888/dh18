using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;
using Application = System.Windows.Application;
using MessageBox = System.Windows.MessageBox;
using Button = System.Windows.Controls.Button;

namespace HiddenWindowManager
{
    public partial class MainWindow : Window
    {
        private const int HOTKEY_ID = 9000;          // 全局"隐藏全部/恢复全部"热键 ID
        private const int SCREENSHOT_HOTKEY_ID = 9001; // 截图热键 ID
        private const int OCR_HOTKEY_ID = 9002;        // 提取文字热键 ID
        private const int TRANSLATE_HOTKEY_ID = 9003;  // 截图翻译热键 ID
        private const int RULE_HOTKEY_BASE_ID = 9100; // 每条规则专属热键的起始 ID

        private AppConfig _config;
        private HwndSource? _source;

        private NotifyIcon _trayIcon = null!;

        private List<WindowInfo> _allWindows = new();

        // 已注册的"单条规则"热键：热键ID -> 对应规则
        private readonly Dictionary<int, HideRule> _ruleHotkeys = new();

        // 自动刷新窗口/进程列表的定时器
        private DispatcherTimer? _refreshTimer;

        public MainWindow()
        {
            InitializeComponent();
            _config = AppConfig.Load();

            Loaded += MainWindow_Loaded;
            Closing += MainWindow_Closing;

            ThemeManager.ApplyTheme(_config.DarkTheme);
            UpdateThemeIcon();
            TryApplyCustomAppIcon();

            SetupTrayIcon();
            RefreshWindowList();
            RefreshRulesList();
            UpdateHotkeyLabel();
            UpdateScreenshotHotkeyLabel();
            UpdateOcrHotkeyLabel();
            UpdateTranslateHotkeyLabel();
            ApplyOcrEngineConfig(notifyMissingModel: false);

            // 开机自启动的真实状态以注册表为准（可能被用户在系统设置里手动改过），
            // 而不是简单信任上次保存的配置
            SyncStartupStateFromRegistry();
        }

        private void ApplyOcrEngineConfig(bool notifyMissingModel = false)
        {
            // 配置写了 RapidOCR 但模型不完整/被删：回退系统 OCR
            if (_config.OcrEngine == OcrEngineKind.RapidOcr && !RapidOcrModelStore.IsInstalled())
            {
                _config.OcrEngine = OcrEngineKind.Windows;
                try { _config.Save(); } catch { /* ignore */ }
                if (notifyMissingModel)
                {
                    MessageBox.Show(this,
                        "已选择 RapidOCR，但未找到完整模型文件，已暂时改回系统 OCR。\n" +
                        "请打开「文字识别设置」重新下载 small 模型。",
                        "文字识别",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }

            OcrService.PreferredEngine = _config.OcrEngine;
            if (_config.OcrEngine != OcrEngineKind.RapidOcr)
                RapidOcrEngine.Reset();
        }

        // ---------------------------------------------------------------
        // 窗口生命周期 / 热键钩子
        // ---------------------------------------------------------------
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            var helper = new WindowInteropHelper(this);
            _source = HwndSource.FromHwnd(helper.Handle);
            _source?.AddHook(WndProc);
            RegisterGlobalHotkey();
            RegisterScreenshotHotkey();
            RegisterOcrHotkey();
            RegisterTranslateHotkey();
            RegisterRuleHotkeys();
            StartAutoRefresh();
        }

        private void StartAutoRefresh()
        {
            _refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(3) };
            _refreshTimer.Tick += (_, _) => RefreshWindowList();
            _refreshTimer.Start();
        }

        private void MainWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            // 关闭按钮只是隐藏到托盘，不真正退出
            e.Cancel = true;
            Hide();
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == NativeMethods.WM_HOTKEY)
            {
                int id = wParam.ToInt32();
                if (id == HOTKEY_ID)
                {
                    ToggleHideAll();
                    handled = true;
                }
                else if (id == SCREENSHOT_HOTKEY_ID)
                {
                    StartScreenshotCapture();
                    handled = true;
                }
                else if (id == OCR_HOTKEY_ID)
                {
                    StartScreenshotCapture(CaptureMode.Ocr);
                    handled = true;
                }
                else if (id == TRANSLATE_HOTKEY_ID)
                {
                    StartScreenshotCapture(CaptureMode.Translate);
                    handled = true;
                }
                else if (_ruleHotkeys.TryGetValue(id, out var rule))
                {
                    ToggleRule(rule);
                    RefreshRulesList();
                    handled = true;
                }
            }
            return IntPtr.Zero;
        }

        private void RegisterGlobalHotkey()
        {
            var helper = new WindowInteropHelper(this);
            NativeMethods.UnregisterHotKey(helper.Handle, HOTKEY_ID);

            if (_config.HotkeyKey == 0)
                return;

            bool ok = NativeMethods.RegisterHotKey(helper.Handle, HOTKEY_ID, _config.HotkeyModifiers, _config.HotkeyKey);
            if (!ok)
            {
                // 常见原因：这个组合键已经被别的程序注册了。以前这里不检查返回值，
                // 会导致热键其实根本没注册上，用户按键毫无反应却不知道为什么。
                MessageBox.Show(this,
                    $"全局热键 {DescribeHotkey(_config.HotkeyModifiers, _config.HotkeyKey)} 注册失败，" +
                    "可能已被其他程序占用，请换一个组合键。",
                    "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void RegisterScreenshotHotkey()
        {
            var helper = new WindowInteropHelper(this);
            NativeMethods.UnregisterHotKey(helper.Handle, SCREENSHOT_HOTKEY_ID);

            if (_config.ScreenshotHotkeyKey == 0)
                return;

            bool ok = NativeMethods.RegisterHotKey(helper.Handle, SCREENSHOT_HOTKEY_ID,
                _config.ScreenshotHotkeyModifiers, _config.ScreenshotHotkeyKey);
            if (!ok)
            {
                MessageBox.Show(this,
                    $"截图热键 {DescribeHotkey(_config.ScreenshotHotkeyModifiers, _config.ScreenshotHotkeyKey)} 注册失败，" +
                    "可能已被其他程序占用，请换一个组合键。",
                    "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void RegisterOcrHotkey()
        {
            var helper = new WindowInteropHelper(this);
            NativeMethods.UnregisterHotKey(helper.Handle, OCR_HOTKEY_ID);

            if (_config.OcrHotkeyKey == 0)
                return;

            bool ok = NativeMethods.RegisterHotKey(helper.Handle, OCR_HOTKEY_ID,
                _config.OcrHotkeyModifiers, _config.OcrHotkeyKey);
            if (!ok)
            {
                MessageBox.Show(this,
                    $"提取文字热键 {DescribeHotkey(_config.OcrHotkeyModifiers, _config.OcrHotkeyKey)} 注册失败，" +
                    "可能已被其他程序占用，请换一个组合键。",
                    "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void RegisterTranslateHotkey()
        {
            var helper = new WindowInteropHelper(this);
            NativeMethods.UnregisterHotKey(helper.Handle, TRANSLATE_HOTKEY_ID);

            if (_config.TranslateHotkeyKey == 0)
                return;

            bool ok = NativeMethods.RegisterHotKey(helper.Handle, TRANSLATE_HOTKEY_ID,
                _config.TranslateHotkeyModifiers, _config.TranslateHotkeyKey);
            if (!ok)
            {
                MessageBox.Show(this,
                    $"截图翻译热键 {DescribeHotkey(_config.TranslateHotkeyModifiers, _config.TranslateHotkeyKey)} 注册失败，" +
                    "可能已被其他程序占用，请换一个组合键。",
                    "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // 为每一条隐藏规则（进程/窗口）注册各自独立的全局热键
        private void RegisterRuleHotkeys()
        {
            var helper = new WindowInteropHelper(this);

            foreach (var id in _ruleHotkeys.Keys.ToList())
                NativeMethods.UnregisterHotKey(helper.Handle, id);
            _ruleHotkeys.Clear();

            int nextId = RULE_HOTKEY_BASE_ID;
            foreach (var rule in _config.HideRules)
            {
                rule.RegisteredHotkeyId = 0;
                if (!rule.HasHotkey) continue;

                if (NativeMethods.RegisterHotKey(helper.Handle, nextId, rule.HotkeyModifiers, rule.HotkeyKey))
                {
                    _ruleHotkeys[nextId] = rule;
                    rule.RegisteredHotkeyId = nextId;
                    nextId++;
                }
            }
        }

        private void UnregisterRuleHotkeys()
        {
            var helper = new WindowInteropHelper(this);
            foreach (var id in _ruleHotkeys.Keys.ToList())
                NativeMethods.UnregisterHotKey(helper.Handle, id);
            _ruleHotkeys.Clear();
        }

        // 全局热键该"隐藏全部"还是"恢复全部"，实时根据每条规则自己的 IsHidden 算出来，
        // 而不是单独维护一个布尔值——否则一旦用户用某条规则自己的快捷键/按钮单独
        // 隐藏或恢复过某个窗口，这个单独维护的标记就会跟真实状态脱节，导致按全局
        // 热键时该恢复却又去隐藏（或者反过来），表现就是"按了快捷键窗口却没恢复"。
        private bool AnyRuleHidden => _config.HideRules.Any(r => r.IsHidden);

        // 检查某个组合键是否已经被全局热键、截图热键或其他规则占用
        private bool IsHotkeyTaken(uint mods, uint key, HideRule? excluding)
        {
            if (key == 0) return false;
            if (FindHotkeyConflict(mods, key, HotkeySlot.None, excluding) != null) return true;
            return false;
        }

        /// <summary>
        /// 所有全局热键槽位的统一表。新增热键只需在这里加一行，
        /// 冲突检测就自动覆盖到，不会漏掉某个组合。
        /// </summary>
        private IEnumerable<(HotkeySlot Slot, string Name, uint Mods, uint Key)> HotkeySlots()
        {
            yield return (HotkeySlot.HideToggle, "全局隐藏热键", _config.HotkeyModifiers, _config.HotkeyKey);
            yield return (HotkeySlot.Screenshot, "截图热键", _config.ScreenshotHotkeyModifiers, _config.ScreenshotHotkeyKey);
            yield return (HotkeySlot.Ocr, "提取文字热键", _config.OcrHotkeyModifiers, _config.OcrHotkeyKey);
            yield return (HotkeySlot.Sticky, "贴图热键", _config.StickyHotkeyModifiers, _config.StickyHotkeyKey);
            yield return (HotkeySlot.Translate, "截图翻译热键", _config.TranslateHotkeyModifiers, _config.TranslateHotkeyKey);
        }

        /// <summary>
        /// 找出这个组合键跟谁冲突，返回占用者的名字；没冲突返回 null。
        /// </summary>
        /// <param name="editing">正在修改的槽位，排除它自己（否则原值也会被判为冲突）。</param>
        private string? FindHotkeyConflict(uint mods, uint key, HotkeySlot editing, HideRule? excludingRule = null)
        {
            if (key == 0) return null;

            foreach (var slot in HotkeySlots())
            {
                if (slot.Slot == editing) continue;
                if (slot.Key == 0) continue;
                if (slot.Mods == mods && slot.Key == key) return slot.Name;
            }

            var rule = _config.HideRules.FirstOrDefault(r =>
                r != excludingRule && r.HasHotkey && r.HotkeyModifiers == mods && r.HotkeyKey == key);
            if (rule != null) return $"隐藏规则「{rule.Value}」";

            return null;
        }

        private void UpdateHotkeyLabel()
        {
            HotkeyLabel.Text = _config.HotkeyKey == 0
                ? "未设置"
                : DescribeHotkey(_config.HotkeyModifiers, _config.HotkeyKey);
        }

        private void UpdateScreenshotHotkeyLabel()
        {
            ScreenshotHotkeyLabel.Text = _config.ScreenshotHotkeyKey == 0
                ? "未设置"
                : DescribeHotkey(_config.ScreenshotHotkeyModifiers, _config.ScreenshotHotkeyKey);
        }

        private void UpdateOcrHotkeyLabel()
        {
            OcrHotkeyLabel.Text = _config.OcrHotkeyKey == 0
                ? "未设置"
                : DescribeHotkey(_config.OcrHotkeyModifiers, _config.OcrHotkeyKey);
        }

        private void UpdateTranslateHotkeyLabel()
        {
            TranslateHotkeyLabel.Text = _config.TranslateHotkeyKey == 0
                ? "None"
                : DescribeHotkey(_config.TranslateHotkeyModifiers, _config.TranslateHotkeyKey);
        }

        public static string DescribeHotkey(uint mods, uint vk)
        {
            var parts = new List<string>();
            if ((mods & NativeMethods.MOD_CONTROL) != 0) parts.Add("Ctrl");
            if ((mods & NativeMethods.MOD_ALT) != 0) parts.Add("Alt");
            if ((mods & NativeMethods.MOD_SHIFT) != 0) parts.Add("Shift");
            if ((mods & NativeMethods.MOD_WIN) != 0) parts.Add("Win");
            var key = KeyInterop.KeyFromVirtualKey((int)vk);
            parts.Add(key.ToString());
            return string.Join(" + ", parts);
        }

        // ---------------------------------------------------------------
        // 自定义程序图标（根目录放一张 icon.ico 即可，见 README）
        // ---------------------------------------------------------------
        // 没放自定义图标时静默忽略，继续用 WPF 默认图标，不影响其他功能
        private void TryApplyCustomAppIcon()
        {
            try
            {
                Icon = new System.Windows.Media.Imaging.BitmapImage(new Uri("pack://application:,,,/icon.ico"));
            }
            catch
            {
                // icon.ico 不存在或不是有效的图标文件，保持默认图标
            }
        }

        // 托盘图标优先复用程序自己的图标（即 icon.ico，在编译时通过 ApplicationIcon
        // 打进了 exe 里），这样单文件发布出去后，托盘图标依然和自定义图标一致，
        // 不需要额外带着 icon.ico 文件到处走。取不到时才退回系统默认图标
        private static System.Drawing.Icon LoadTrayIcon()
        {
            try
            {
                var exePath = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;
                if (!string.IsNullOrEmpty(exePath))
                {
                    var icon = System.Drawing.Icon.ExtractAssociatedIcon(exePath);
                    if (icon != null) return icon;
                }
            }
            catch
            {
                // 提取失败就退回系统默认图标
            }
            return System.Drawing.SystemIcons.Application;
        }

        // ---------------------------------------------------------------
        // 标题栏拖动 / 最小化 / 关闭
        // ---------------------------------------------------------------
        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
                return;
            }

            try
            {
                DragMove();
            }
            catch (InvalidOperationException)
            {
                // 鼠标在 DragMove 真正开始前就已经松开时会抛出，忽略即可
            }
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

        private void CloseButton_Click(object sender, RoutedEventArgs e) => Hide();

        // ---------------------------------------------------------------
        // 主题切换
        // ---------------------------------------------------------------
        private void AppSettingsButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new AppSettingsDialog(
                _config.PasswordEnabled,
                _config.RunAtStartup,
                ApplyPasswordEnabled,
                ApplyStartupEnabled,
                PromptSetPassword)
            {
                Owner = this
            };
            dlg.ShowDialog();
        }

        /// <returns>true 表示已应用；false 表示应还原开关。</returns>
        private bool ApplyPasswordEnabled(bool enabled)
        {
            _config.PasswordEnabled = enabled;

            if (enabled && string.IsNullOrEmpty(_config.PasswordHash))
            {
                MessageBox.Show(this, "请先设置一个密码。", "提示");
                PromptSetPassword();
                if (string.IsNullOrEmpty(_config.PasswordHash))
                {
                    _config.PasswordEnabled = false;
                    _config.Save();
                    return false;
                }
            }

            _config.Save();
            return true;
        }

        private bool ApplyStartupEnabled(bool enabled)
        {
            if (TrySetStartupRegistration(enabled, out var errorMessage))
            {
                _config.RunAtStartup = enabled;
                _config.Save();
                return true;
            }

            MessageBox.Show(this, $"设置开机自启动失败：{errorMessage}\n请尝试以管理员身份运行本程序后重试。", "提示",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        private void PromptSetPassword()
        {
            var dlg = new PasswordDialog("设置新密码") { Owner = this };
            if (dlg.ShowDialog() != true) return;

            if (string.IsNullOrEmpty(dlg.EnteredPassword))
            {
                MessageBox.Show(this, "密码不能为空。", "提示");
                return;
            }

            _config.PasswordHash = AppConfig.HashPassword(dlg.EnteredPassword);
            _config.Save();
            MessageBox.Show(this, "密码已更新。", "提示");
        }

        private void ThemeToggleButton_Click(object sender, RoutedEventArgs e)
        {
            _config.DarkTheme = !_config.DarkTheme;
            ThemeManager.ApplyTheme(_config.DarkTheme);
            UpdateThemeIcon();
            _config.Save();
        }

        private void UpdateThemeIcon()
        {
            // 深色主题下显示"太阳"（点击可切换到浅色）；浅色主题下显示"月亮"（点击可切换到深色）
            ThemeToggleButton.Content = _config.DarkTheme ? "\u2600" : "\u263D";
            ThemeToggleButton.ToolTip = _config.DarkTheme ? "切换到浅色主题" : "切换到深色主题";
        }

        // ---------------------------------------------------------------
        // 系统托盘
        // ---------------------------------------------------------------
        private void SetupTrayIcon()
        {
            var menu = new ContextMenuStrip();
            menu.Items.Add("显示主窗口", null, (_, _) => ShowMainWindow());
            menu.Items.Add("立即切换隐藏/恢复", null, (_, _) => ToggleHideAll());
            menu.Items.Add("区域截图", null, (_, _) => StartScreenshotCapture());
            menu.Items.Add("提取文字", null, (_, _) => StartScreenshotCapture(CaptureMode.Ocr));
            menu.Items.Add("截图翻译", null, (_, _) => StartScreenshotCapture(CaptureMode.Translate));
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("退出", null, (_, _) => ExitApp());

            _trayIcon = new NotifyIcon
            {
                Icon = LoadTrayIcon(),
                Visible = true,
                Text = "隐藏窗口管理器 · Ctrl+Alt+A 截图",
                ContextMenuStrip = menu
            };
            _trayIcon.DoubleClick += (_, _) => ShowMainWindow();
        }

        /// <summary>
        /// 托盘双击 / 单实例二次启动时唤起主窗口。
        /// </summary>
        internal void ShowMainWindow()
        {
            Show();
            WindowState = WindowState.Normal;
            Activate();

            try
            {
                var hwnd = new WindowInteropHelper(this).Handle;
                if (hwnd != IntPtr.Zero)
                {
                    if (NativeMethods.IsIconic(hwnd))
                        NativeMethods.ShowWindow(hwnd, NativeMethods.SW_RESTORE);
                    NativeMethods.AllowSetForegroundWindow(NativeMethods.ASFW_ANY);
                    NativeMethods.BringWindowToTop(hwnd);
                    NativeMethods.SetForegroundWindow(hwnd);
                }
            }
            catch
            {
                // 置前失败不影响窗口已显示
            }
        }

        private void ExitApp()
        {
            // 退出前先把所有仍处于隐藏状态的窗口恢复出来，避免留下"找不回来"的孤儿窗口
            RestoreAllHiddenWindowsOnExit();

            // 贴图是独立窗口，显式关掉，不要留在屏幕上
            StickyImageWindow.CloseAll();

            var helper = new WindowInteropHelper(this);
            NativeMethods.UnregisterHotKey(helper.Handle, HOTKEY_ID);
            NativeMethods.UnregisterHotKey(helper.Handle, SCREENSHOT_HOTKEY_ID);
            NativeMethods.UnregisterHotKey(helper.Handle, OCR_HOTKEY_ID);
            NativeMethods.UnregisterHotKey(helper.Handle, TRANSLATE_HOTKEY_ID);
            UnregisterRuleHotkeys();
            _refreshTimer?.Stop();
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
            Application.Current.Shutdown();
        }

        // 退出时批量恢复所有隐藏中的规则，不做密码校验（程序都要关了，不能把窗口丢在隐藏状态）
        private void RestoreAllHiddenWindowsOnExit()
        {
            foreach (var rule in _config.HideRules)
            {
                if (rule.IsHidden)
                    ShowRuleWindows(rule);
            }
        }

        // ---------------------------------------------------------------
        // 窗口列表 / 隐藏规则
        // ---------------------------------------------------------------
        private void RefreshButton_Click(object sender, RoutedEventArgs e) => RefreshWindowList();

        private void RefreshWindowList()
        {
            var selectedHandle = (WindowsListView.SelectedItem as WindowInfo)?.Handle;

            _allWindows = WindowEnumerator.GetTopLevelWindows()
                .Where(w => !string.IsNullOrWhiteSpace(w.Title))
                .OrderBy(w => w.ProcessName, StringComparer.OrdinalIgnoreCase)
                .ToList();
            WindowsListView.ItemsSource = _allWindows;

            if (selectedHandle.HasValue)
            {
                var match = _allWindows.FirstOrDefault(w => w.Handle == selectedHandle.Value);
                if (match != null) WindowsListView.SelectedItem = match;
            }
        }

        private void RefreshRulesList()
        {
            RulesListView.ItemsSource = null;
            RulesListView.ItemsSource = _config.HideRules;
        }

        private void AddRuleButton_Click(object sender, RoutedEventArgs e)
        {
            if (WindowsListView.SelectedItem is not WindowInfo info)
            {
                MessageBox.Show(this, "请先在左侧列表选中一个窗口。", "提示");
                return;
            }

            AddRuleFromWindow(info);
        }

        // 双击左侧窗口列表中的某一项，直接按当前选择的匹配方式加入隐藏列表
        private void WindowsListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (WindowsListView.SelectedItem is not WindowInfo info) return;
            AddRuleFromWindow(info);
        }

        private void AddRuleFromWindow(WindowInfo info)
        {
            var matchType = MatchTypeCombo.SelectedIndex switch
            {
                0 => MatchType.Title,
                1 => MatchType.ClassName,
                _ => MatchType.ProcessName
            };

            var value = matchType switch
            {
                MatchType.Title => info.Title,
                MatchType.ClassName => info.ClassName,
                _ => info.ProcessName
            };

            if (_config.HideRules.Any(r => r.Type == matchType && string.Equals(r.Value, value, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show(this, "这条规则已经在隐藏列表中了。", "提示");
                return;
            }

            _config.HideRules.Add(new HideRule { Type = matchType, Value = value });
            _config.Save();
            RefreshRulesList();
            RegisterRuleHotkeys();
        }

        private void RemoveRuleButton_Click(object sender, RoutedEventArgs e)
        {
            if (RulesListView.SelectedItem is not HideRule rule) return;
            RemoveRule(rule);
        }

        // 双击隐藏列表中的某一项，直接移除该规则
        private void RulesListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (RulesListView.SelectedItem is not HideRule rule) return;
            RemoveRule(rule);
        }

        private void RemoveRule(HideRule rule)
        {
            // 若该规则当前处于隐藏状态，移除前先恢复对应窗口，避免"孤儿"窗口找不回来
            if (rule.IsHidden) ShowRuleWindows(rule);

            _config.HideRules.Remove(rule);
            _config.Save();
            RefreshRulesList();
            RegisterRuleHotkeys();
        }

        // ---------------------------------------------------------------
        // 单条规则的专属快捷键
        // ---------------------------------------------------------------
        private void SetRuleHotkeyButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not HideRule rule) return;

            var dlg = new HotkeyDialog(rule.HotkeyModifiers, rule.HotkeyKey) { Owner = this };
            if (dlg.ShowDialog() != true) return;

            // 清除热键（对话框里点了"清除"）
            if (dlg.SelectedKey == 0)
            {
                rule.HotkeyModifiers = 0;
                rule.HotkeyKey = 0;
                _config.Save();
                RegisterRuleHotkeys();
                RefreshRulesList();
                return;
            }

            if (IsHotkeyTaken(dlg.SelectedModifiers, dlg.SelectedKey, rule))
            {
                MessageBox.Show(this, "这个快捷键已经被占用（全局热键或另一条规则），请换一个组合。", "提示",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            rule.HotkeyModifiers = dlg.SelectedModifiers;
            rule.HotkeyKey = dlg.SelectedKey;
            _config.Save();
            RegisterRuleHotkeys();
            RefreshRulesList();
        }

        // 手动点击隐藏/恢复某一条规则（不通过热键）
        private void ToggleRuleButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not HideRule rule) return;
            ToggleRule(rule);
            RefreshRulesList();
        }

        // ---------------------------------------------------------------
        // 热键修改
        // ---------------------------------------------------------------
        private void ChangeHotkeyButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new HotkeyDialog(_config.HotkeyModifiers, _config.HotkeyKey) { Owner = this };
            if (dlg.ShowDialog() != true) return;

            if (dlg.SelectedKey == 0)
            {
                _config.HotkeyModifiers = 0;
                _config.HotkeyKey = 0;
                _config.Save();
                RegisterGlobalHotkey();
                UpdateHotkeyLabel();
                return;
            }

            var owner = FindHotkeyConflict(dlg.SelectedModifiers, dlg.SelectedKey, HotkeySlot.HideToggle);
            if (owner != null)
            {
                MessageBox.Show(this, $"这个快捷键已被{owner}占用，请换一个组合。", "提示",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _config.HotkeyModifiers = dlg.SelectedModifiers;
            _config.HotkeyKey = dlg.SelectedKey;
            _config.Save();
            RegisterGlobalHotkey();
            UpdateHotkeyLabel();
        }

        private void ChangeScreenshotHotkeyButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new HotkeyDialog(_config.ScreenshotHotkeyModifiers, _config.ScreenshotHotkeyKey) { Owner = this };
            if (dlg.ShowDialog() != true) return;

            // 清除截图热键
            if (dlg.SelectedKey == 0)
            {
                _config.ScreenshotHotkeyModifiers = 0;
                _config.ScreenshotHotkeyKey = 0;
                _config.Save();
                RegisterScreenshotHotkey();
                UpdateScreenshotHotkeyLabel();
                return;
            }

            // 改的是截图热键本身，所以把它排除，否则"没改"也会报冲突
            var ssOwner = FindHotkeyConflict(dlg.SelectedModifiers, dlg.SelectedKey, HotkeySlot.Screenshot);
            if (ssOwner != null)
            {
                MessageBox.Show(this, $"这个快捷键已被{ssOwner}占用，请换一个组合。", "提示",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _config.ScreenshotHotkeyModifiers = dlg.SelectedModifiers;
            _config.ScreenshotHotkeyKey = dlg.SelectedKey;
            _config.Save();
            RegisterScreenshotHotkey();
            UpdateScreenshotHotkeyLabel();
        }

        private void ChangeOcrHotkeyButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new HotkeyDialog(_config.OcrHotkeyModifiers, _config.OcrHotkeyKey) { Owner = this };
            if (dlg.ShowDialog() != true) return;

            if (dlg.SelectedKey == 0)
            {
                _config.OcrHotkeyModifiers = 0;
                _config.OcrHotkeyKey = 0;
                _config.Save();
                RegisterOcrHotkey();
                UpdateOcrHotkeyLabel();
                return;
            }

            var ocrOwner = FindHotkeyConflict(dlg.SelectedModifiers, dlg.SelectedKey, HotkeySlot.Ocr);
            if (ocrOwner != null)
            {
                MessageBox.Show(this, $"这个快捷键已被{ocrOwner}占用，请换一个组合。", "提示",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _config.OcrHotkeyModifiers = dlg.SelectedModifiers;
            _config.OcrHotkeyKey = dlg.SelectedKey;
            _config.Save();
            RegisterOcrHotkey();
            UpdateOcrHotkeyLabel();
        }

        private void OcrCaptureButton_Click(object sender, RoutedEventArgs e)
            => StartScreenshotCapture(CaptureMode.Ocr);

        private void TranslateCaptureButton_Click(object sender, RoutedEventArgs e)
            => StartScreenshotCapture(CaptureMode.Translate);

        private void ScreenshotButton_Click(object sender, RoutedEventArgs e) => StartScreenshotCapture();

        private void ChangeTranslateHotkeyButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new HotkeyDialog(_config.TranslateHotkeyModifiers, _config.TranslateHotkeyKey) { Owner = this };
            if (dlg.ShowDialog() != true) return;

            if (dlg.SelectedKey == 0)
            {
                _config.TranslateHotkeyModifiers = 0;
                _config.TranslateHotkeyKey = 0;
                _config.Save();
                RegisterTranslateHotkey();
                UpdateTranslateHotkeyLabel();
                return;
            }

            var owner = FindHotkeyConflict(dlg.SelectedModifiers, dlg.SelectedKey, HotkeySlot.Translate);
            if (owner != null)
            {
                MessageBox.Show(this, $"这个快捷键已被{owner}占用，请换一个组合。", "提示",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _config.TranslateHotkeyModifiers = dlg.SelectedModifiers;
            _config.TranslateHotkeyKey = dlg.SelectedKey;
            _config.Save();
            RegisterTranslateHotkey();
            UpdateTranslateHotkeyLabel();
        }

        private void OcrSettingsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dlg = new OcrSettingsDialog(_config.OcrEngine) { Owner = this };
                if (dlg.ShowDialog() != true) return;

                _config.OcrEngine = dlg.SelectedEngine;
                try { _config.Save(); } catch { /* ignore */ }
                ApplyOcrEngineConfig(notifyMissingModel: true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "打开识别设置失败：" + ex.Message, "文字识别",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void TranslatorSettingsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dlg = new TranslatorSettingsDialog(
                    _config.TranslatorKey,
                    _config.TranslatorRegion,
                    _config.TranslatorTargetLanguage)
                {
                    Owner = this
                };

                if (dlg.ShowDialog() != true) return;

                _config.TranslatorKey = dlg.TranslatorKey;
                _config.TranslatorRegion = dlg.TranslatorRegion;
                _config.TranslatorTargetLanguage = dlg.TargetLanguage;
                try { _config.Save(); }
                catch { /* ignore */ }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "打开翻译设置失败：" + ex.Message, "翻译设置",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        /// <summary>
        /// 统一截图入口：若主窗口可见则先收起，避免截进自身。
        /// </summary>
        private void StartScreenshotCapture(CaptureMode mode = CaptureMode.Normal)
        {
            if (IsVisible)
                Hide();

            Dispatcher.BeginInvoke(new Action(() => ScreenshotManager.StartCapture(_config, mode)),
                System.Windows.Threading.DispatcherPriority.ApplicationIdle);
        }

        // ---------------------------------------------------------------
        // 隐藏 / 恢复核心逻辑
        // ---------------------------------------------------------------
        private void ToggleHideAll()
        {
            // 只要还有任何一条规则处于隐藏状态，全局热键就先做"恢复全部"，
            // 而不是只看"上一次全局热键把方向切成了隐藏"。这样即使用户中途
            // 用某条规则自己的快捷键/按钮单独隐藏过窗口，全局热键依然知道
            // 现在真实是"有东西被隐藏着"，按下去会正确地恢复，而不是又把
            // 其它窗口也隐藏一遍。
            if (!AnyRuleHidden)
            {
                foreach (var rule in _config.HideRules)
                    HideRuleWindows(rule);
                HideMainWindowToTray();
            }
            else
            {
                if (_config.PasswordEnabled && !VerifyPassword())
                    return;

                foreach (var rule in _config.HideRules)
                    ShowRuleWindows(rule);
            }
            RefreshRulesList();
        }

        // 单条规则的隐藏/恢复切换（供每条规则的专属快捷键、以及列表里的按钮调用）
        private void ToggleRule(HideRule rule)
        {
            if (!rule.IsHidden)
            {
                HideRuleWindows(rule);
                HideMainWindowToTray();
            }
            else
            {
                if (_config.PasswordEnabled && !VerifyPassword())
                    return;

                ShowRuleWindows(rule);
            }
        }

        // 隐藏目标窗口的同时，把管理器自己也收起到系统托盘，桌面上不留任何痕迹；
        // 恢复窗口时不会自动弹回主界面，需要的话从托盘图标里呼出即可
        private void HideMainWindowToTray()
        {
            if (IsVisible)
                Hide();
        }

        private void HideRuleWindows(HideRule rule)
        {
            if (rule.IsHidden) return;

            var all = WindowEnumerator.GetTopLevelWindows();
            rule.HiddenHandles = all.Where(w => Matches(rule, w)).Select(w => w.Handle).ToList();

            foreach (var handle in rule.HiddenHandles)
                NativeMethods.ShowWindow(handle, NativeMethods.SW_HIDE);

            rule.IsHidden = true;
        }

        private void ShowRuleWindows(HideRule rule)
        {
            if (!rule.IsHidden) return;

            foreach (var handle in rule.HiddenHandles)
            {
                if (NativeMethods.IsWindow(handle))
                    BringWindowToFront(handle);
            }

            rule.HiddenHandles.Clear();
            rule.IsHidden = false;
        }

        // 恢复窗口时，把它显示出来并置于最前台（而不是仅仅可见但被别的窗口遮住）
        private static void BringWindowToFront(IntPtr handle)
        {
            NativeMethods.ShowWindow(handle, NativeMethods.IsIconic(handle) ? NativeMethods.SW_RESTORE : NativeMethods.SW_SHOW);
            NativeMethods.AllowSetForegroundWindow(NativeMethods.ASFW_ANY);
            NativeMethods.BringWindowToTop(handle);
            NativeMethods.SetForegroundWindow(handle);
        }

        private static bool Matches(HideRule rule, WindowInfo w)
        {
            return rule.Type switch
            {
                MatchType.Title => w.Title.Contains(rule.Value, StringComparison.OrdinalIgnoreCase),
                MatchType.ClassName => string.Equals(w.ClassName, rule.Value, StringComparison.OrdinalIgnoreCase),
                MatchType.ProcessName => string.Equals(w.ProcessName, rule.Value, StringComparison.OrdinalIgnoreCase),
                _ => false
            };
        }

        // ---------------------------------------------------------------
        // 密码保护
        // ---------------------------------------------------------------
        private bool VerifyPassword()
        {
            var dlg = new PasswordDialog("恢复窗口需要输入密码") { Owner = this };

            // 这个弹窗常常是全局热键触发的（这时主窗口大概率还隐藏在托盘里），
            // 不是鼠标点击应用内按钮触发的。Windows 的前台锁定机制经常不让
            // 这种后台触发的新窗口自动抢到前台焦点，用户会看不到弹窗、以为
            // 按键没反应。这里显式抢一下前台，并临时置顶，确保弹窗能被看到。
            NativeMethods.AllowSetForegroundWindow(NativeMethods.ASFW_ANY);
            dlg.Topmost = true;
            dlg.Loaded += (_, _) => dlg.Activate();

            if (dlg.ShowDialog() != true) return false;

            var hash = AppConfig.HashPassword(dlg.EnteredPassword);
            if (hash != _config.PasswordHash)
            {
                MessageBox.Show(this, "密码错误。", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            return true;
        }

        // ---------------------------------------------------------------
        // 开机自启动
        // ---------------------------------------------------------------
        private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
        private const string RunValueName = "HiddenWindowManager";

        // 打开时用注册表里的真实状态校正配置，避免"配置说开了，但其实注册表项已经不存在了"这种不一致
        private void SyncStartupStateFromRegistry()
        {
            try
            {
                using var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(RunKeyPath, writable: false);
                var value = key?.GetValue(RunValueName) as string;
                _config.RunAtStartup = !string.IsNullOrEmpty(value);
            }
            catch
            {
                // 读取失败就保留配置文件里原来的值
            }
        }

        // 实际读写注册表启动项，并在写入后立即读回校验，确保"看起来成功"不等于"真的成功"
        private static bool TrySetStartupRegistration(bool enabled, out string errorMessage)
        {
            errorMessage = string.Empty;
            try
            {
                // CreateSubKey 在键已存在时等价于打开，不存在时会自动创建，
                // 比 OpenSubKey 更可靠，不会因为键碰巧不存在就静默失败
                using var key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(RunKeyPath, writable: true);
                if (key == null)
                {
                    errorMessage = "无法访问注册表启动项";
                    return false;
                }

                if (enabled)
                {
                    var exePath = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;
                    if (string.IsNullOrEmpty(exePath))
                    {
                        errorMessage = "无法获取程序自身路径";
                        return false;
                    }

                    key.SetValue(RunValueName, $"\"{exePath}\"");

                    // 写入后立刻读回校验，确认真的写进去了
                    if (key.GetValue(RunValueName) is not string written || string.IsNullOrEmpty(written))
                    {
                        errorMessage = "写入后校验失败";
                        return false;
                    }
                }
                else
                {
                    key.DeleteValue(RunValueName, throwOnMissingValue: false);

                    if (key.GetValue(RunValueName) != null)
                    {
                        errorMessage = "删除启动项失败";
                        return false;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }
    }
}
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using RapidOcrNet;
using SkiaSharp;

namespace HiddenWindowManager
{
    /// <summary>
    /// RapidOCR（ONNX）引擎包装。模型按需加载；识别在后台线程串行执行。
    /// </summary>
    internal static class RapidOcrEngine
    {
        private static readonly object Gate = new();
        private static RapidOcr? _ocr;
        private static RapidOcrPack _loadedPack = RapidOcrPack.None;
        private static string? _initError;

        public static string? LastError
        {
            get { lock (Gate) return _initError; }
        }

        public static bool IsReady
        {
            get { lock (Gate) return _ocr != null; }
        }

        public static void Reset()
        {
            lock (Gate)
            {
                _ocr?.Dispose();
                _ocr = null;
                _loadedPack = RapidOcrPack.None;
                _initError = null;
            }
        }

        public static bool TryEnsureInitialized(out string? error)
        {
            lock (Gate)
            {
                var pack = RapidOcrModelStore.InstalledPack;
                if (_ocr != null && _loadedPack == pack && pack != RapidOcrPack.None)
                {
                    error = null;
                    return true;
                }

                if (_ocr != null)
                {
                    _ocr.Dispose();
                    _ocr = null;
                    _loadedPack = RapidOcrPack.None;
                }

                _initError = null;

                if (pack == RapidOcrPack.None)
                {
                    error = "尚未下载 RapidOCR 模型。请在「文字识别设置」中启用并下载（当前查找目录："
                            + RapidOcrModelStore.SmallDir + "）。";
                    _initError = error;
                    Log("init-missing", error);
                    return false;
                }

                try
                {
                    NativeBootstrap.EnsureRapidOcrNatives();

                    var ocr = new RapidOcr();
                    var preset = pack == RapidOcrPack.Medium
                        ? RapidOcrModelSet.PPOCRv6Medium
                        : RapidOcrModelSet.PPOCRv6Small;

                    var models = preset with
                    {
                        DetModelPath = RapidOcrModelStore.DetPath,
                        RecModelPath = RapidOcrModelStore.RecPath,
                        ClsModelPath = RapidOcrModelStore.ClsPath,
                        KeysPath = RapidOcrModelStore.DictPath
                    };
                    ocr.InitModels(models);
                    _ocr = ocr;
                    _loadedPack = pack;
                    error = null;
                    Log("init-ok", "pack=" + pack + " dir=" + RapidOcrModelStore.RootDir);
                    return true;
                }
                catch (Exception ex)
                {
                    try
                    {
                        NativeBootstrap.EnsureRapidOcrNatives();
                        var ocr = new RapidOcr();
                        ocr.InitModels(
                            RapidOcrModelStore.DetPath,
                            RapidOcrModelStore.ClsPath,
                            RapidOcrModelStore.RecPath,
                            RapidOcrModelStore.DictPath);
                        _ocr = ocr;
                        _loadedPack = pack;
                        error = null;
                        Log("init-ok-fallback-api", "pack=" + pack);
                        return true;
                    }
                    catch (Exception ex2)
                    {
                        string detail = NativeBootstrap.FlattenException(ex);
                        if (!string.Equals(ex.Message, ex2.Message, StringComparison.Ordinal))
                            detail += " / " + NativeBootstrap.FlattenException(ex2);

                        string beside = AppContext.BaseDirectory;
                        bool hasOrt = File.Exists(Path.Combine(beside, "onnxruntime.dll"));
                        _initError =
                            "RapidOCR 初始化失败：" + detail
                            + "\n模型目录：" + RapidOcrModelStore.RootDir
                            + "\nexe 旁 onnxruntime.dll：" + (hasOrt ? "有" : "无（请重新 publish）")
                            + "\nBaseDirectory：" + beside;
                        error = _initError;
                        Log("init-fail", ex + " || " + ex2);
                        return false;
                    }
                }
            }
        }

        /// <summary>
        /// 在调用线程把图编码成 PNG，再丢到后台识别，避免 GDI+ Bitmap 跨线程报错。
        /// </summary>
        public static Task<OcrLayoutOutcome> RecognizeLayoutAsync(Bitmap bitmap)
        {
            byte[] png;
            try
            {
                png = EncodePng(bitmap);
            }
            catch (Exception ex)
            {
                Log("encode-fail", ex.ToString());
                return Task.FromException<OcrLayoutOutcome>(
                    new InvalidOperationException("RapidOCR 图像编码失败：" + ex.Message, ex));
            }

            return Task.Run(() => RecognizePng(png));
        }

        private static OcrLayoutOutcome RecognizePng(byte[] png)
        {
            if (!TryEnsureInitialized(out var err))
                throw new InvalidOperationException(err);

            RapidOcr ocr;
            lock (Gate)
            {
                ocr = _ocr ?? throw new InvalidOperationException("RapidOCR 未初始化。");
            }

            using var sk = SKBitmap.Decode(png)
                ?? throw new InvalidOperationException("无法解码图像供 RapidOCR 使用。");

            OcrResult result;
            try
            {
                lock (Gate)
                {
                    result = ocr.Detect(sk, RapidOcrOptions.PPOCRv6);
                }
            }
            catch (Exception ex)
            {
                Log("detect-fail", ex.ToString());
                throw new InvalidOperationException("RapidOCR Detect 失败：" + ex.Message, ex);
            }

            var lines = new List<OcrLineBox>();
            var sb = new StringBuilder();
            var blocks = result.TextBlocks;

            if (blocks != null)
            {
                foreach (var block in blocks)
                {
                    string text = (block.Text ?? string.Empty).Trim();
                    if (string.IsNullOrWhiteSpace(text)) continue;

                    if (sb.Length > 0) sb.Append('\n');
                    sb.Append(text);

                    var pts = block.BoxPoints;
                    if (pts == null || pts.Length < 4)
                    {
                        lines.Add(new OcrLineBox(text, new System.Windows.Rect(0, 0, 8, 8)));
                        continue;
                    }

                    double minX = pts.Min(p => (double)p.X);
                    double minY = pts.Min(p => (double)p.Y);
                    double maxX = pts.Max(p => (double)p.X);
                    double maxY = pts.Max(p => (double)p.Y);
                    lines.Add(new OcrLineBox(text,
                        new System.Windows.Rect(minX, minY, Math.Max(1, maxX - minX), Math.Max(1, maxY - minY))));
                }
            }

            return new OcrLayoutOutcome(
                sb.ToString().Trim(),
                RapidOcrModelStore.PackDisplayName,
                "rapidocr-v6",
                1.0,
                lines);
        }

        private static byte[] EncodePng(Bitmap bitmap)
        {
            // 调用线程上深拷贝再编码，避免与 UI/其他线程抢同一 GDI 对象
            using var clone = new Bitmap(bitmap.Width, bitmap.Height, PixelFormat.Format32bppArgb);
            clone.SetResolution(96f, 96f);
            using (var g = Graphics.FromImage(clone))
            {
                g.Clear(Color.White);
                g.DrawImageUnscaled(bitmap, 0, 0);
            }

            using var ms = new MemoryStream();
            clone.Save(ms, ImageFormat.Png);
            return ms.ToArray();
        }

        internal static void Log(string tag, string message)
        {
            try
            {
                string dir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "HiddenWindowManager");
                Directory.CreateDirectory(dir);
                string path = Path.Combine(dir, "rapidocr.log");
                string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " [" + tag + "] " + message
                              + Environment.NewLine;
                File.AppendAllText(path, line, Encoding.UTF8);
            }
            catch
            {
                // ignore
            }
        }
    }
}

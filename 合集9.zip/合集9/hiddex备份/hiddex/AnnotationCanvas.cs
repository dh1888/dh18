using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MediaColor = System.Windows.Media.Color;
using MediaPen = System.Windows.Media.Pen;
using WpfPoint = System.Windows.Point;

namespace HiddenWindowManager
{
    /// <summary>
    /// 在截图之上绘制标注层（笔迹、高亮、几何、箭头）。
    /// </summary>
    internal sealed class AnnotationCanvas : FrameworkElement
    {
        private const double HandleSize = 8;
        private const double HitTolerance = 6;

        private readonly List<AnnotationItem> _items = new();
        private AnnotationItem? _preview;
        private AnnotationItem? _selected;

        public IReadOnlyList<AnnotationItem> Items => _items;

        public AnnotationItem? Selected
        {
            get => _selected;
            set
            {
                if (ReferenceEquals(_selected, value)) return;
                _selected = value;
                InvalidateVisual();
            }
        }

        public void Add(AnnotationItem item)
        {
            _items.Add(item);
            InvalidateVisual();
        }

        public void SetPreview(AnnotationItem? preview)
        {
            _preview = preview;
            InvalidateVisual();
        }

        public void Invalidate() => InvalidateVisual();

        public bool Undo()
        {
            if (_items.Count == 0) return false;
            var removed = _items[^1];
            _items.RemoveAt(_items.Count - 1);
            if (ReferenceEquals(_selected, removed))
                _selected = null;
            InvalidateVisual();
            return true;
        }

        public void ClearAll()
        {
            _items.Clear();
            _preview = null;
            _selected = null;
            InvalidateVisual();
        }

        /// <summary>从上到下找可编辑标注（后画的优先）。</summary>
        public AnnotationItem? HitTestEditable(WpfPoint p)
        {
            for (int i = _items.Count - 1; i >= 0; i--)
            {
                var item = _items[i];
                if (!item.IsEditable) continue;
                if (item.HitTest(p, HitTolerance)) return item;
            }
            return null;
        }

        /// <summary>检测选中项上的手柄；没有命中手柄则看是否点在本体。</summary>
        public ShapeHandle HitTestHandle(AnnotationItem item, WpfPoint p)
        {
            foreach (var (handle, center) in EnumerateHandles(item))
            {
                if (HandleRect(center).Contains(p))
                    return handle;
            }

            if (item.HitTest(p, HitTolerance) || item.GetEditBounds().Contains(p))
                return ShapeHandle.Body;

            return ShapeHandle.None;
        }

        public static System.Windows.Input.Cursor CursorForHandle(ShapeHandle handle) => handle switch
        {
            ShapeHandle.NW or ShapeHandle.SE => System.Windows.Input.Cursors.SizeNWSE,
            ShapeHandle.NE or ShapeHandle.SW => System.Windows.Input.Cursors.SizeNESW,
            ShapeHandle.ArrowStart or ShapeHandle.ArrowEnd => System.Windows.Input.Cursors.Cross,
            ShapeHandle.Body => System.Windows.Input.Cursors.SizeAll,
            _ => System.Windows.Input.Cursors.Arrow
        };

        protected override HitTestResult HitTestCore(PointHitTestParameters hitTestParameters)
        {
            return new PointHitTestResult(this, hitTestParameters.HitPoint);
        }

        protected override void OnRender(DrawingContext drawingContext)
        {
            base.OnRender(drawingContext);
            drawingContext.DrawRectangle(System.Windows.Media.Brushes.Transparent, null, new Rect(RenderSize));
            foreach (var item in _items)
                item.Draw(drawingContext);
            _preview?.Draw(drawingContext);

            if (_selected != null && _selected.IsEditable)
                DrawSelectionChrome(drawingContext, _selected);
        }

        private void DrawSelectionChrome(DrawingContext dc, AnnotationItem item)
        {
            var bounds = item.GetEditBounds();
            if (bounds.Width > 0 && bounds.Height > 0)
            {
                var dash = new MediaPen(new SolidColorBrush(MediaColor.FromRgb(124, 107, 255)), 1.0)
                {
                    DashStyle = DashStyles.Dash
                };
                dc.DrawRectangle(null, dash, bounds);
            }

            foreach (var (_, center) in EnumerateHandles(item))
            {
                var r = HandleRect(center);
                dc.DrawRectangle(System.Windows.Media.Brushes.White,
                    new MediaPen(new SolidColorBrush(MediaColor.FromRgb(124, 107, 255)), 1.2), r);
            }
        }

        private static IEnumerable<(ShapeHandle Handle, WpfPoint Center)> EnumerateHandles(AnnotationItem item)
        {
            if (item is ArrowItem arrow)
            {
                yield return (ShapeHandle.ArrowStart, arrow.Start);
                yield return (ShapeHandle.ArrowEnd, arrow.End);
                yield break;
            }

            var b = item.GetEditBounds();
            if (b.IsEmpty) yield break;
            yield return (ShapeHandle.NW, new WpfPoint(b.Left, b.Top));
            yield return (ShapeHandle.NE, new WpfPoint(b.Right, b.Top));
            yield return (ShapeHandle.SW, new WpfPoint(b.Left, b.Bottom));
            yield return (ShapeHandle.SE, new WpfPoint(b.Right, b.Bottom));
        }

        private static Rect HandleRect(WpfPoint center)
        {
            double h = HandleSize / 2;
            return new Rect(center.X - h, center.Y - h, HandleSize, HandleSize);
        }

        public BitmapSource? RenderCombined(ImageSource background,
                                            Func<AnnotationItem, bool>? filter = null,
                                            System.Windows.Size? dipSize = null)
        {
            if (background is not BitmapSource bmp) return null;

            double dipW = dipSize?.Width ?? (ActualWidth > 0 ? ActualWidth : bmp.Width);
            double dipH = dipSize?.Height ?? (ActualHeight > 0 ? ActualHeight : bmp.Height);

            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                // 先铺不透明底，避免 Pbgra32 透明像素在 OCR 的 Premultiplied/Ignore 路径里丢内容
                dc.DrawRectangle(System.Windows.Media.Brushes.White, null,
                    new Rect(0, 0, bmp.PixelWidth, bmp.PixelHeight));
                dc.DrawImage(bmp, new Rect(0, 0, bmp.PixelWidth, bmp.PixelHeight));

                double scaleX = bmp.PixelWidth / Math.Max(1.0, dipW);
                double scaleY = bmp.PixelHeight / Math.Max(1.0, dipH);

                dc.PushTransform(new ScaleTransform(scaleX, scaleY));
                foreach (var item in _items)
                {
                    if (filter != null && !filter(item)) continue;
                    item.Draw(dc);
                }
                dc.Pop();
            }

            var rtb = new RenderTargetBitmap(bmp.PixelWidth, bmp.PixelHeight, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(dv);
            rtb.Freeze();
            return rtb;
        }
    }
}

using System.Windows;
using System.Windows.Controls;

namespace HiddenWindowManager
{
    public partial class TranslatorSettingsDialog : Window
    {
        public string TranslatorKey { get; private set; } = string.Empty;
        public string TranslatorRegion { get; private set; } = "eastasia";
        public string TargetLanguage { get; private set; } = "zh-Hans";

        private bool _keyVisible;

        public TranslatorSettingsDialog(string key, string region, string targetLanguage)
        {
            InitializeComponent();

            string initialKey = key ?? string.Empty;
            KeyPasswordBox.Password = initialKey;
            KeyPlainBox.Text = initialKey;

            RegionBox.Text = string.IsNullOrWhiteSpace(region) ? "eastasia" : region;

            var targets = new (string Tag, string Name)[]
            {
                ("zh-Hans", "简体中文"),
                ("zh-Hant", "繁体中文"),
                ("en", "英语"),
                ("ja", "日语"),
                ("ko", "韩语"),
                ("vi", "越南语"),
                ("th", "泰语"),
                ("ru", "俄语"),
                ("es", "西班牙语"),
                ("pt", "葡萄牙语"),
                ("fr", "法语"),
                ("de", "德语"),
                ("ar", "阿拉伯语"),
            };

            string current = string.IsNullOrWhiteSpace(targetLanguage) ? "zh-Hans" : targetLanguage;
            ComboBoxItem? selected = null;

            foreach (var (tag, name) in targets)
            {
                var item = new ComboBoxItem { Content = name, Tag = tag };
                TargetCombo.Items.Add(item);
                if (string.Equals(tag, current, StringComparison.OrdinalIgnoreCase))
                    selected = item;
            }

            if (selected == null)
            {
                selected = new ComboBoxItem { Content = current, Tag = current };
                TargetCombo.Items.Add(selected);
            }

            TargetCombo.SelectedItem = selected;
        }

        private void ToggleKeyVisibility_Click(object sender, RoutedEventArgs e)
        {
            _keyVisible = !_keyVisible;

            if (_keyVisible)
            {
                KeyPlainBox.Text = KeyPasswordBox.Password;
                KeyPasswordBox.Visibility = Visibility.Collapsed;
                KeyPlainBox.Visibility = Visibility.Visible;
                ToggleKeyButton.Content = "\uE8F5"; // hide
                ToggleKeyButton.ToolTip = "隐藏密钥";
                KeyPlainBox.CaretIndex = KeyPlainBox.Text.Length;
                KeyPlainBox.Focus();
            }
            else
            {
                KeyPasswordBox.Password = KeyPlainBox.Text;
                KeyPlainBox.Visibility = Visibility.Collapsed;
                KeyPasswordBox.Visibility = Visibility.Visible;
                ToggleKeyButton.Content = "\uE890"; // view
                ToggleKeyButton.ToolTip = "显示密钥";
                KeyPasswordBox.Focus();
            }
        }

        private string ReadKey() =>
            _keyVisible ? (KeyPlainBox.Text ?? string.Empty) : KeyPasswordBox.Password;

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            TranslatorKey = ReadKey().Trim();
            TranslatorRegion = RegionBox.Text?.Trim() ?? string.Empty;
            if (TargetCombo.SelectedItem is ComboBoxItem item && item.Tag is string tag)
                TargetLanguage = tag;
            else
                TargetLanguage = "zh-Hans";

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}

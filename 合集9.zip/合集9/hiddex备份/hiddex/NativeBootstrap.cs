using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace HiddenWindowManager
{
    /// <summary>
    /// 修复单文件发布 / ZIP 分发后 OnnxRuntime 原生库 DllNotFound：
    /// 1) 去掉 Mark of the Web（Zone.Identifier）
    /// 2) 把 exe 目录加入 DLL 搜索路径并预加载
    /// 3) 为 OnnxRuntime 注册 DllImportResolver，强制从 exe 旁加载
    /// </summary>
    internal static class NativeBootstrap
    {
        [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr LoadLibraryEx(string lpFileName, IntPtr hFile, uint dwFlags);

        [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool SetDllDirectory(string? lpPathName);

        [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool DeleteFile(string lpFileName);

        private static bool _done;
        private static bool _resolverSet;

        public static void EnsureRapidOcrNatives()
        {
            if (_done) return;
            _done = true;

            string dir = AppContext.BaseDirectory.TrimEnd(
                Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);

            UnblockDirectory(dir);
            ConfigureSearchPath(dir);
            Preload(dir, "onnxruntime.dll");
            Preload(dir, "onnxruntime_providers_shared.dll");
            Preload(dir, "libSkiaSharp.dll");
            TrySetOnnxResolver(dir);
        }

        private static void ConfigureSearchPath(string dir)
        {
            // 让 onnxruntime 的依赖（vcruntime 等）优先从 exe 目录解析
            try { SetDllDirectory(dir); }
            catch { /* ignore */ }
        }

        private static void Preload(string dir, string name)
        {
            string path = Path.Combine(dir, name);
            if (!File.Exists(path))
            {
                RapidOcrEngine.Log("native-missing", path);
                return;
            }

            // LOAD_WITH_ALTERED_SEARCH_PATH = 0x8：用 DLL 所在目录解析其依赖
            IntPtr handle = LoadLibraryEx(path, IntPtr.Zero, 0x00000008);
            if (handle == IntPtr.Zero)
            {
                int err = Marshal.GetLastWin32Error();
                RapidOcrEngine.Log("native-load-fail", path + " win32=" + err
                    + " (126=缺依赖/被阻止，建议安装 VC++ x64 或解除文件阻止)");
            }
            else
            {
                RapidOcrEngine.Log("native-load-ok", path);
            }
        }

        private static void TrySetOnnxResolver(string dir)
        {
            if (_resolverSet) return;
            try
            {
                Assembly? ortAsm = AppDomain.CurrentDomain.GetAssemblies()
                    .FirstOrDefault(a => a.GetName().Name == "Microsoft.ML.OnnxRuntime");

                if (ortAsm == null)
                {
                    // 尚未加载时先按程序集名解析；触发一次加载
                    ortAsm = Assembly.Load("Microsoft.ML.OnnxRuntime");
                }

                NativeLibrary.SetDllImportResolver(ortAsm, (libraryName, _, _) =>
                {
                    if (!libraryName.Contains("onnxruntime", StringComparison.OrdinalIgnoreCase))
                        return IntPtr.Zero;

                    string full = Path.Combine(dir, "onnxruntime.dll");
                    if (File.Exists(full) && NativeLibrary.TryLoad(full, out IntPtr handle))
                        return handle;

                    return IntPtr.Zero;
                });
                _resolverSet = true;
                RapidOcrEngine.Log("onnx-resolver", "registered for " + dir);
            }
            catch (Exception ex)
            {
                RapidOcrEngine.Log("onnx-resolver-fail", ex.ToString());
            }
        }

        /// <summary>去掉 ZIP/网络传来的 Zone.Identifier，否则 LoadLibrary 可能直接失败。</summary>
        private static void UnblockDirectory(string dir)
        {
            try
            {
                foreach (string file in Directory.EnumerateFiles(dir))
                {
                    string ext = Path.GetExtension(file);
                    if (!ext.Equals(".dll", StringComparison.OrdinalIgnoreCase)
                        && !ext.Equals(".exe", StringComparison.OrdinalIgnoreCase))
                        continue;

                    // 删除 ADS：path:Zone.Identifier（File.Exists 对 ADS 不可靠）
                    if (DeleteFile(file + ":Zone.Identifier"))
                        RapidOcrEngine.Log("unblock", file);
                }
            }
            catch (Exception ex)
            {
                RapidOcrEngine.Log("unblock-fail", ex.Message);
            }
        }

        public static string FlattenException(Exception ex)
        {
            var parts = new List<string>();
            for (Exception? e = ex; e != null; e = e.InnerException)
                parts.Add(e.GetType().Name + ": " + e.Message);
            return string.Join(" → ", parts);
        }
    }
}

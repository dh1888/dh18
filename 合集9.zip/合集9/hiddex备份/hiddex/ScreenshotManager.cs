using System.Drawing;
using System.Windows;
using MessageBox = System.Windows.MessageBox;

namespace HiddenWindowManager
{
    /// <summary>
    /// 截图流程入口：冻结画面 → 选区 → 原地标注 / OCR / 翻译 / 复制保存。
    /// </summary>
    internal static class ScreenshotManager
    {
        private static bool _busy;

        /// <param name="config">
        /// 传主窗口那份实例，标注画笔的颜色/粗细就能存进同一个 config.json。
        /// 传 null 则本次截图不记忆。
        /// </param>
        /// <param name="mode">框选完成后的自动动作。</param>
        public static void StartCapture(AppConfig? config = null, CaptureMode mode = CaptureMode.Normal)
        {
            if (_busy) return;
            _busy = true;

            Bitmap? frozen = null;
            try
            {
                frozen = ScreenCaptureHelper.CaptureVirtualScreen();

                var overlay = new ScreenshotOverlayWindow(frozen, config, mode)
                {
                    Topmost = true
                };

                NativeMethods.AllowSetForegroundWindow(NativeMethods.ASFW_ANY);
                overlay.Loaded += (_, _) => overlay.Activate();
                overlay.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("启动截图失败：" + ex.Message, "截图",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            finally
            {
                frozen?.Dispose();
                _busy = false;
            }
        }
    }
}

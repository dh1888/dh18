using System.Windows;

namespace HiddenWindowManager
{
    /// <summary>
    /// 应用设置：恢复密码、开机自启。通过回调交给主窗口处理实际逻辑。
    /// </summary>
    public partial class AppSettingsDialog : Window
    {
        private readonly Func<bool, bool> _applyPasswordEnabled;
        private readonly Func<bool, bool> _applyStartup;
        private readonly Action _setPassword;
        private bool _syncing;

        public AppSettingsDialog(
            bool passwordEnabled,
            bool runAtStartup,
            Func<bool, bool> applyPasswordEnabled,
            Func<bool, bool> applyStartup,
            Action setPassword)
        {
            _applyPasswordEnabled = applyPasswordEnabled;
            _applyStartup = applyStartup;
            _setPassword = setPassword;

            InitializeComponent();

            _syncing = true;
            PasswordToggle.IsChecked = passwordEnabled;
            StartupToggle.IsChecked = runAtStartup;
            _syncing = false;
        }

        private void PasswordToggle_Changed(object sender, RoutedEventArgs e)
        {
            if (_syncing) return;
            bool enabled = PasswordToggle.IsChecked == true;
            if (_applyPasswordEnabled(enabled)) return;

            // 主窗口拒绝（例如未设密码又取消）时还原开关
            _syncing = true;
            PasswordToggle.IsChecked = !enabled;
            _syncing = false;
        }

        private void StartupToggle_Changed(object sender, RoutedEventArgs e)
        {
            if (_syncing) return;
            bool enabled = StartupToggle.IsChecked == true;
            if (_applyStartup(enabled)) return;

            _syncing = true;
            StartupToggle.IsChecked = !enabled;
            _syncing = false;
        }

        private void SetPasswordButton_Click(object sender, RoutedEventArgs e)
            => _setPassword();

        private void CloseButton_Click(object sender, RoutedEventArgs e)
            => DialogResult = true;
    }
}

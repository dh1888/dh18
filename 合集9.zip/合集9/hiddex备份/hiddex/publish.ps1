#Requires -Version 5.1
<#
.SYNOPSIS
  Publish hiddex as a self-contained single-file exe.

.EXAMPLE
  .\publish.ps1
#>

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$outDir = Join-Path $root 'dist\hiddex'

# 正在运行的 hiddex 会锁住 exe，先结束再清理
$running = @(Get-Process -Name 'hiddex' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) {
    Write-Host "==> Stop running hiddex ($($running.Count))..."
    $running | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 800
}

Write-Host "==> Clean $outDir"
if (Test-Path $outDir) {
    try {
        Remove-Item -Recurse -Force $outDir
    } catch {
        Get-Process -Name 'hiddex' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
        Remove-Item -Recurse -Force $outDir
    }
}
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

Write-Host '==> Publish self-contained single-file (win-x64)...'
dotnet publish (Join-Path $root 'HiddenWindowManager.csproj') `
    -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:EnableCompressionInSingleFile=true `
    -p:DebugType=none -p:DebugSymbols=false `
    -o $outDir

# 只删 NuGet 示例 OCR 模型
$modelsDir = Join-Path $outDir 'models'
if (Test-Path $modelsDir) { Remove-Item -Recurse -Force $modelsDir }

# 去掉无关文件；保留所有 dll
Get-ChildItem $outDir -File | Where-Object {
    $_.Extension -in '.pdb', '.xml', '.lib' -or $_.Name -like '*.dev.json'
} | Remove-Item -Force -ErrorAction SilentlyContinue

# OnnxRuntime / Skia 在单文件自解压下经常加载失败：强制把原生 DLL 放到 exe 旁
$nativeSources = @(
    (Join-Path $env:USERPROFILE '.nuget\packages\microsoft.ml.onnxruntime\1.27.0\runtimes\win-x64\native\onnxruntime.dll'),
    (Join-Path $env:USERPROFILE '.nuget\packages\microsoft.ml.onnxruntime\1.27.0\runtimes\win-x64\native\onnxruntime_providers_shared.dll'),
    (Join-Path $env:USERPROFILE '.nuget\packages\skiasharp.nativeassets.win32\3.119.1\runtimes\win-x64\native\libSkiaSharp.dll')
)
# 备用：从本次构建输出复制
$buildNative = Join-Path $root 'bin\Release\net8.0-windows10.0.19041.0\win-x64'
foreach ($name in @('onnxruntime.dll', 'onnxruntime_providers_shared.dll', 'libSkiaSharp.dll')) {
    $dest = Join-Path $outDir $name
    $src = $nativeSources | Where-Object { [IO.Path]::GetFileName($_) -eq $name -and (Test-Path $_) } | Select-Object -First 1
    if (-not $src) {
        $alt = Join-Path $buildNative $name
        if (Test-Path $alt) { $src = $alt }
    }
    if (-not $src) {
        Write-Warning "Missing native source for $name"
        continue
    }
    Copy-Item -Force $src $dest
    Write-Host "OK sidecar: $name"
}

$exe = Join-Path $outDir 'hiddex.exe'
if (-not (Test-Path $exe)) {
    throw "Publish failed: hiddex.exe not found in $outDir"
}

foreach ($need in @('onnxruntime.dll', 'libSkiaSharp.dll')) {
    if (-not (Test-Path (Join-Path $outDir $need))) {
        throw "Publish incomplete: $need not beside hiddex.exe (RapidOCR will fail)"
    }
}

# 附带 VC++ x64 运行库（目标机未装可再发行组件时，onnxruntime.dll 会报 DllNotFound）
$crtNames = @(
    'vcruntime140.dll', 'vcruntime140_1.dll',
    'msvcp140.dll', 'msvcp140_1.dll', 'msvcp140_2.dll',
    'concrt140.dll'
)
foreach ($name in $crtNames) {
    $src = Join-Path $env:SystemRoot "System32\$name"
    if (Test-Path $src) {
        Copy-Item -Force $src (Join-Path $outDir $name)
        Write-Host "OK crt: $name"
    } else {
        Write-Warning "CRT missing on build machine: $name"
    }
}

# 清除构建机上的 Zone 标记，减少二次压缩后的“已阻止”
Get-ChildItem $outDir -File | Unblock-File -ErrorAction SilentlyContinue

$sizeMb = [math]::Round((Get-Item $exe).Length / 1MB, 2)
$dllCount = @(Get-ChildItem $outDir -Filter '*.dll' -File).Count
Write-Host "==> Done: $exe  ($sizeMb MB), sidecar dlls: $dllCount"
Write-Host "TIP: zip 发给别人后，对方可先右键 zip → 属性 → 解除锁定，再解压。"
Get-ChildItem $outDir | Select-Object Name, Length | Format-Table -AutoSize

namespace HiddenWindowManager
{
    public class WindowInfo
    {
        public IntPtr Handle { get; set; }
        public string Title { get; set; } = string.Empty;
        public string ClassName { get; set; } = string.Empty;
        public string ProcessName { get; set; } = string.Empty;
        public uint ProcessId { get; set; }
    }

    public enum MatchType
    {
        Title,
        ClassName,
        ProcessName
    }

    public class HideRule
    {
        public MatchType Type { get; set; }
        public string Value { get; set; } = string.Empty;

        // 每条规则自己的快捷键（HotkeyKey == 0 表示未设置）
        public uint HotkeyModifiers { get; set; } = 0;
        public uint HotkeyKey { get; set; } = 0;

        [System.Text.Json.Serialization.JsonIgnore]
        public IntPtr LastKnownHandle { get; set; }

        // 运行时状态，不需要持久化
        [System.Text.Json.Serialization.JsonIgnore]
        public List<IntPtr> HiddenHandles { get; set; } = new();

        [System.Text.Json.Serialization.JsonIgnore]
        public bool IsHidden { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public int RegisteredHotkeyId { get; set; }

        public string TypeLabel => Type switch
        {
            MatchType.Title => "标题",
            MatchType.ClassName => "类名",
            _ => "进程"
        };

        public bool HasHotkey => HotkeyKey != 0;

        public string HotkeyLabel => HasHotkey
            ? MainWindow.DescribeHotkey(HotkeyModifiers, HotkeyKey)
            : "未设置快捷键";

        public string StatusLabel => IsHidden ? "已隐藏" : "显示中";

        public string ToggleButtonLabel => IsHidden ? "恢复" : "隐藏";
    }
}

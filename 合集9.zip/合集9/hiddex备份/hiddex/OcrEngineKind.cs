namespace HiddenWindowManager
{
    /// <summary>文字识别引擎。</summary>
    public enum OcrEngineKind
    {
        /// <summary>Windows 自带 OCR（默认，无需下载）。</summary>
        Windows = 0,

        /// <summary>RapidOCR + ONNX 多语言模型（首次启用需下载）。</summary>
        RapidOcr = 1
    }
}

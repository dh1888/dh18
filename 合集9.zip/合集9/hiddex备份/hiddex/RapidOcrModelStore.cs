using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;

namespace HiddenWindowManager
{
    internal enum RapidOcrPack
    {
        None = 0,
        Small = 1,
        Medium = 2
    }

    /// <summary>
    /// RapidOCR PP-OCRv6 多语言模型的本机存储与按需下载。
    /// 默认不随程序分发；启用增强引擎时再下载到 %AppData%。
    /// </summary>
    internal static class RapidOcrModelStore
    {
        private static readonly HttpClient Http = CreateHttp();

        private static HttpClient CreateHttp()
        {
            var http = new HttpClient
            {
                Timeout = TimeSpan.FromMinutes(30)
            };
            // ModelScope 对无 UA 的 onnx 下载返回 403；需伪装成浏览器。
            http.DefaultRequestHeaders.UserAgent.ParseAdd(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("*/*"));
            return http;
        }

        public const string PackDisplayNameDefault = "RapidOCR small";
        public const string PackSizeHint = "约 32MB";

        private static string OcrRoot =>
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "HiddenWindowManager", "ocr");

        public static string SmallDir => Path.Combine(OcrRoot, "rapidocr-v6-small");
        public static string MediumDir => Path.Combine(OcrRoot, "rapidocr-v6-medium");

        /// <summary>更早版本用过的目录。</summary>
        private static string LegacyDir =>
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "HiddenWindowManager", "ocr-models", "v6");

        public static RapidOcrPack InstalledPack
        {
            get
            {
                TryMigrateLegacySmall();
                // 优先 small（当前默认）；仅当没有 small 时才用残留的 medium
                if (HasSmall(SmallDir) || HasSmall(LegacyDir))
                {
                    TryDeleteMediumPack();
                    return RapidOcrPack.Small;
                }
                if (HasMedium(MediumDir)) return RapidOcrPack.Medium;
                return RapidOcrPack.None;
            }
        }

        public static bool IsInstalled() => InstalledPack != RapidOcrPack.None;

        public static bool IsSmallInstalled() =>
            HasSmall(SmallDir) || HasSmall(LegacyDir);

        public static string PackDisplayName => InstalledPack switch
        {
            RapidOcrPack.Small => "RapidOCR small",
            RapidOcrPack.Medium => "RapidOCR medium",
            _ => PackDisplayNameDefault
        };

        public static string RootDir => InstalledPack switch
        {
            RapidOcrPack.Small => Directory.Exists(SmallDir) && HasSmall(SmallDir) ? SmallDir : LegacyDir,
            RapidOcrPack.Medium => MediumDir,
            _ => SmallDir
        };

        public static string DetPath => Path.Combine(RootDir,
            InstalledPack == RapidOcrPack.Medium ? "PP-OCRv6_det_medium.onnx" : "PP-OCRv6_det_small.onnx");
        public static string RecPath => Path.Combine(RootDir,
            InstalledPack == RapidOcrPack.Medium ? "PP-OCRv6_rec_medium.onnx" : "PP-OCRv6_rec_small.onnx");
        public static string ClsPath => Path.Combine(RootDir, "ch_PP-LCNet_x0_25_textline_ori_cls_mobile.onnx");
        public static string DictPath => Path.Combine(RootDir,
            InstalledPack == RapidOcrPack.Medium ? "ppocrv6_medium_dict.txt" : "ppocrv6_small_dict.txt");

        private static bool HasMedium(string dir) =>
            File.Exists(Path.Combine(dir, "PP-OCRv6_det_medium.onnx"))
            && File.Exists(Path.Combine(dir, "PP-OCRv6_rec_medium.onnx"))
            && File.Exists(Path.Combine(dir, "ch_PP-LCNet_x0_25_textline_ori_cls_mobile.onnx"))
            && File.Exists(Path.Combine(dir, "ppocrv6_medium_dict.txt"));

        private static bool HasSmall(string dir) =>
            File.Exists(Path.Combine(dir, "PP-OCRv6_det_small.onnx"))
            && File.Exists(Path.Combine(dir, "PP-OCRv6_rec_small.onnx"))
            && File.Exists(Path.Combine(dir, "ch_PP-LCNet_x0_25_textline_ori_cls_mobile.onnx"))
            && File.Exists(Path.Combine(dir, "ppocrv6_small_dict.txt"));

        /// <summary>把旧目录 ocr-models\v6 迁到 ocr\rapidocr-v6-small。</summary>
        private static void TryMigrateLegacySmall()
        {
            try
            {
                if (!HasSmall(LegacyDir)) return;
                if (HasSmall(SmallDir)) return;

                Directory.CreateDirectory(SmallDir);
                foreach (var file in Directory.GetFiles(LegacyDir))
                {
                    string dest = Path.Combine(SmallDir, Path.GetFileName(file));
                    if (!File.Exists(dest))
                        File.Copy(file, dest, overwrite: false);
                }
            }
            catch
            {
                // ignore
            }
        }

        // RapidOCR 官方清单；附 ModelScope API 镜像（免登录）。
        public static IReadOnlyList<(string FileName, string[] Urls, string? Sha256)> RequiredFiles { get; } =
        [
            ("PP-OCRv6_det_small.onnx",
            [
                "https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.9.1/onnx/PP-OCRv6/det/PP-OCRv6_det_small.onnx",
                "https://www.modelscope.cn/api/v1/models/RapidAI/RapidOCR/repo?Revision=v3.9.1&FilePath=onnx/PP-OCRv6/det/PP-OCRv6_det_small.onnx"
            ],
            "090f04abcd9d9a7498bc4ebf677e4cb9bdce1fe4197ddb7e529f1ef44e1ff94f"),

            ("PP-OCRv6_rec_small.onnx",
            [
                "https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.9.1/onnx/PP-OCRv6/rec/PP-OCRv6_rec_small.onnx",
                "https://www.modelscope.cn/api/v1/models/RapidAI/RapidOCR/repo?Revision=v3.9.1&FilePath=onnx/PP-OCRv6/rec/PP-OCRv6_rec_small.onnx"
            ],
            "6f327246b50388f3c176ae304bd95767ea6dc0c9ae92153ef8cbe210b3c14884"),

            ("ch_PP-LCNet_x0_25_textline_ori_cls_mobile.onnx",
            [
                "https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.9.1/onnx/PP-OCRv5/cls/ch_PP-LCNet_x0_25_textline_ori_cls_mobile.onnx",
                "https://www.modelscope.cn/api/v1/models/RapidAI/RapidOCR/repo?Revision=v3.9.1&FilePath=onnx/PP-OCRv5/cls/ch_PP-LCNet_x0_25_textline_ori_cls_mobile.onnx"
            ],
            "54379ae5174d026780215fc748a7f31910dee36818e63d49e17dc598ecc82df7"),

            ("ppocrv6_small_dict.txt",
            [
                "https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.9.1/paddle/PP-OCRv6/rec/PP-OCRv6_rec_small/ppocrv6_dict.txt",
                "https://www.modelscope.cn/api/v1/models/RapidAI/RapidOCR/repo?Revision=v3.9.1&FilePath=paddle/PP-OCRv6/rec/PP-OCRv6_rec_small/ppocrv6_dict.txt"
            ],
            null)
        ];

        /// <summary>
        /// 下载 small 模型到标准目录。progress: (已完成文件数, 总文件数, 当前文件名, 当前文件 0–1 进度)。
        /// </summary>
        public static async Task DownloadAsync(
            IProgress<(int doneFiles, int totalFiles, string fileName, double fileProgress)>? progress,
            CancellationToken ct)
        {
            TryMigrateLegacySmall();
            Directory.CreateDirectory(SmallDir);
            int total = RequiredFiles.Count;
            int done = 0;

            foreach (var (fileName, urls, sha) in RequiredFiles)
            {
                ct.ThrowIfCancellationRequested();
                string dest = Path.Combine(SmallDir, fileName);

                if (File.Exists(dest) && (sha == null || await Sha256MatchesAsync(dest, sha, ct)))
                {
                    done++;
                    progress?.Report((done, total, fileName, 1));
                    continue;
                }

                Exception? last = null;
                bool ok = false;
                foreach (var url in urls)
                {
                    ct.ThrowIfCancellationRequested();
                    try
                    {
                        await DownloadOneAsync(url, dest, p =>
                            progress?.Report((done, total, fileName, p)), ct).ConfigureAwait(false);

                        if (sha != null && !await Sha256MatchesAsync(dest, sha, ct).ConfigureAwait(false))
                        {
                            try { File.Delete(dest); } catch { /* ignore */ }
                            throw new InvalidOperationException("校验失败：" + fileName);
                        }

                        ok = true;
                        break;
                    }
                    catch (Exception ex) when (ex is not OperationCanceledException)
                    {
                        last = ex;
                        try { if (File.Exists(dest)) File.Delete(dest); } catch { /* ignore */ }
                    }
                }

                if (!ok)
                    throw new InvalidOperationException(
                        "下载失败：" + fileName + (last != null ? "\n" + last.Message : string.Empty), last);

                done++;
                progress?.Report((done, total, fileName, 1));
            }

            // small 就绪后删掉更大的 medium，避免占盘且误用慢模型
            TryDeleteMediumPack();
        }

        public static void DeleteAll()
        {
            foreach (var dir in new[] { MediumDir, SmallDir, LegacyDir })
            {
                try
                {
                    if (Directory.Exists(dir))
                        Directory.Delete(dir, recursive: true);
                }
                catch
                {
                    // ignore
                }
            }

            try
            {
                string legacyRoot = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "HiddenWindowManager", "ocr-models");
                if (Directory.Exists(legacyRoot))
                    Directory.Delete(legacyRoot, recursive: true);
            }
            catch
            {
                // ignore
            }
        }

        private static void TryDeleteMediumPack()
        {
            try
            {
                if (Directory.Exists(MediumDir))
                    Directory.Delete(MediumDir, recursive: true);
            }
            catch
            {
                // ignore
            }
        }

        private static async Task DownloadOneAsync(
            string url, string dest,
            Action<double>? fileProgress, CancellationToken ct)
        {
            string temp = dest + ".download";
            try { if (File.Exists(temp)) File.Delete(temp); } catch { /* ignore */ }

            using var resp = await Http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct)
                .ConfigureAwait(false);
            resp.EnsureSuccessStatusCode();

            long? total = resp.Content.Headers.ContentLength;
            await using var input = await resp.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);
            await using var output = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None, 81920, true);

            var buffer = new byte[81920];
            long readTotal = 0;
            int n;
            while ((n = await input.ReadAsync(buffer.AsMemory(0, buffer.Length), ct).ConfigureAwait(false)) > 0)
            {
                await output.WriteAsync(buffer.AsMemory(0, n), ct).ConfigureAwait(false);
                readTotal += n;
                if (total is > 0)
                    fileProgress?.Invoke(Math.Clamp(readTotal / (double)total.Value, 0, 1));
                else
                    fileProgress?.Invoke(0);
            }

            await output.FlushAsync(ct).ConfigureAwait(false);
            output.Close();

            if (File.Exists(dest)) File.Delete(dest);
            File.Move(temp, dest);
            fileProgress?.Invoke(1);
        }

        private static async Task<bool> Sha256MatchesAsync(string path, string expectedHex, CancellationToken ct)
        {
            await using var fs = File.OpenRead(path);
            var hash = await SHA256.HashDataAsync(fs, ct).ConfigureAwait(false);
            string actual = Convert.ToHexString(hash).ToLowerInvariant();
            return string.Equals(actual, expectedHex, StringComparison.OrdinalIgnoreCase);
        }
    }
}

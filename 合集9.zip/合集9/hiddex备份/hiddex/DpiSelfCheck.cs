using System.Runtime.InteropServices;
using System.Threading;

namespace HiddenWindowManager
{
    /// <summary>
    /// 启动时自检 DPI 感知状态。
    /// DPI 不感知会导致截屏只拿到缩放后的低分辨率画面（细节当场丢失），
    /// 窗口再被系统放大，贴图和 OCR 文字都会发虚、字形走形。
    /// 用 --dpi-check 参数运行可打印诊断信息。
    /// </summary>
    internal static class DpiSelfCheck
    {
        [DllImport("user32.dll")]
        private static extern IntPtr GetThreadDpiAwarenessContext();

        [DllImport("user32.dll")]
        private static extern int GetAwarenessFromDpiAwarenessContext(IntPtr ctx);

        /// <summary>0=UNAWARE, 1=SYSTEM_AWARE, 2=PER_MONITOR_AWARE</summary>
        public static int Awareness
        {
            get
            {
                try { return GetAwarenessFromDpiAwarenessContext(GetThreadDpiAwarenessContext()); }
                catch { return -1; }
            }
        }

        public static bool IsDpiAware => Awareness >= 1;

        public static string Describe() => Awareness switch
        {
            0 => "UNAWARE (截图会失真)",
            1 => "SYSTEM_AWARE",
            2 => "PER_MONITOR_AWARE",
            _ => "UNKNOWN"
        };

        /// <summary>用 hiddex.exe --dpi-check / --ocr-selftest 运行时打印诊断并返回 true。</summary>
        public static bool HandleCommandLine(string[] args)
        {
            if (args.Any(a => string.Equals(a, "--ocr-selftest", StringComparison.OrdinalIgnoreCase)))
            {
                RunOcrSelfTest();
                return true;
            }

            if (!args.Any(a => string.Equals(a, "--dpi-check", StringComparison.OrdinalIgnoreCase)))
                return false;

            var vs = ScreenCaptureHelper.VirtualScreenBounds;
            var lines = new List<string>
            {
                "DPI awareness : " + Describe(),
                "VirtualScreen : " + vs.Width + "x" + vs.Height,
            };

            try
            {
                using var shot = ScreenCaptureHelper.CaptureVirtualScreen();
                lines.Add("captured      : " + shot.Width + "x" + shot.Height);
            }
            catch (Exception ex)
            {
                lines.Add("captured      : FAILED " + ex.Message);
            }

            lines.Add(IsDpiAware
                ? "=> OK: 拿到真实物理像素，贴图/OCR 不会被系统放大"
                : "=> BAD: DPI 不感知，截图会被降采样后再放大");

            string report = string.Join(Environment.NewLine, lines);

            // 同时写文件，便于脚本读取（GUI 程序没有控制台）
            try
            {
                System.IO.File.WriteAllText(
                    System.IO.Path.Combine(AppContext.BaseDirectory, "dpi-check.txt"),
                    report);
            }
            catch { /* 写不了就算了，仍然弹窗 */ }

            System.Windows.MessageBox.Show(report,
                "DPI 自检", System.Windows.MessageBoxButton.OK,
                System.Windows.MessageBoxImage.Information);
            return true;
        }

        /// <summary>
        /// 用合成图走一遍 OcrService，结果写 ocr-selftest.txt（尽量不弹窗，便于脚本读取）。
        /// </summary>
        private static void RunOcrSelfTest()
        {
            string path = System.IO.Path.Combine(AppContext.BaseDirectory, "ocr-selftest.txt");
            var lines = new List<string> { "start: " + DateTime.Now.ToString("o") };
            void Flush()
            {
                try { System.IO.File.WriteAllText(path, string.Join(Environment.NewLine, lines)); }
                catch { /* ignore */ }
            }

            Flush();
            try
            {
                lines.Add("DPI awareness : " + Describe());
                lines.Add("OCR languages  : " + string.Join(", ",
                    OcrService.GetAvailableLanguages().Select(l => l.Tag)));
                Flush();

                using var synthetic = new System.Drawing.Bitmap(480, 140,
                    System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                using (var g = System.Drawing.Graphics.FromImage(synthetic))
                {
                    g.Clear(System.Drawing.Color.White);
                    g.DrawString("提取文字 Hello 123",
                        new System.Drawing.Font("Microsoft YaHei UI", 28,
                            System.Drawing.FontStyle.Bold),
                        System.Drawing.Brushes.Black, 16, 40);
                }

                var src = ScreenCaptureHelper.ToBitmapSource(synthetic);
                lines.Add($"synthetic src  : {src.PixelWidth}x{src.PixelHeight} dpi={src.DpiX:0.#}");
                Flush();

                // 清掉同步上下文，避免在 STA 上 Wait 造成假死锁
                var oldCtx = SynchronizationContext.Current;
                SynchronizationContext.SetSynchronizationContext(null);
                try
                {
                    var r = OcrService.RecognizeDetailedAsync(src, null, tryAllLanguages: true)
                        .ConfigureAwait(false)
                        .GetAwaiter()
                        .GetResult();
                    lines.Add($"synthetic OCR : lang={r.LanguageTag} scale={r.Scale:0.##}");
                    lines.Add($"synthetic text : {(string.IsNullOrWhiteSpace(r.Text) ? "(EMPTY)" : r.Text)}");
                }
                finally
                {
                    SynchronizationContext.SetSynchronizationContext(oldCtx);
                }
            }
            catch (Exception ex)
            {
                lines.Add("FAILED: " + ex);
            }

            lines.Add("done");
            Flush();
        }
    }
}

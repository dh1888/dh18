using System.Windows;
using MessageBox = System.Windows.MessageBox;

namespace HiddenWindowManager
{
    public partial class OcrSettingsDialog : Window
    {
        private OcrEngineKind _engine;
        private CancellationTokenSource? _cts;
        private bool _busy;
        private bool _syncing;

        public OcrEngineKind SelectedEngine => _engine;

        public OcrSettingsDialog(OcrEngineKind current)
        {
            InitializeComponent();
            _engine = current;
            _syncing = true;
            EngineWindows.IsChecked = current != OcrEngineKind.RapidOcr;
            EngineRapid.IsChecked = current == OcrEngineKind.RapidOcr;
            _syncing = false;
            RefreshStatus();
        }

        private void Engine_Changed(object sender, RoutedEventArgs e)
        {
            if (_syncing || !IsLoaded) return;

            if (EngineRapid.IsChecked == true)
            {
                _engine = OcrEngineKind.RapidOcr;
                if (!RapidOcrModelStore.IsInstalled())
                    _ = EnsureDownloadedAsync();
            }
            else
            {
                _engine = OcrEngineKind.Windows;
            }

            RefreshStatus();
        }

        private async void DownloadButton_Click(object sender, RoutedEventArgs e)
            => await EnsureDownloadedAsync();

        private async Task EnsureDownloadedAsync()
        {
            if (_busy) return;
            if (RapidOcrModelStore.IsSmallInstalled())
            {
                RapidOcrEngine.Reset();
                RefreshStatus();
                return;
            }

            var ask = MessageBox.Show(this,
                $"将从 RapidAI 模型源下载 {RapidOcrModelStore.PackDisplayNameDefault}（{RapidOcrModelStore.PackSizeHint}）。\n" +
                "下载完成后可用于提取文字与截图 OCR。\n\n是否开始下载？",
                "下载 RapidOCR 模型",
                MessageBoxButton.YesNo,
                MessageBoxImage.Information);

            if (ask != MessageBoxResult.Yes)
            {
                if (!RapidOcrModelStore.IsInstalled())
                {
                    _syncing = true;
                    EngineWindows.IsChecked = true;
                    EngineRapid.IsChecked = false;
                    _syncing = false;
                    _engine = OcrEngineKind.Windows;
                }
                RefreshStatus();
                return;
            }

            _busy = true;
            _cts = new CancellationTokenSource();
            SetUiBusy(true);
            StatusText.Text = "正在下载 small…";

            var progress = new Progress<(int done, int total, string name, double fileProgress)>(p =>
            {
                double overall = (p.done + p.fileProgress) / Math.Max(1, p.total) * 100;
                DownloadProgress.Value = Math.Clamp(overall, 0, 100);
                StatusText.Text = $"下载中 {p.done}/{p.total}：{p.name}";
            });

            try
            {
                await RapidOcrModelStore.DownloadAsync(progress, _cts.Token);
                RapidOcrEngine.Reset();
                StatusText.Text = "下载完成，已就绪。";
                DownloadProgress.Value = 100;
                _engine = OcrEngineKind.RapidOcr;
                _syncing = true;
                EngineRapid.IsChecked = true;
                _syncing = false;
            }
            catch (OperationCanceledException)
            {
                StatusText.Text = "已取消下载。";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "下载失败：\n" + ex.Message, "RapidOCR",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                StatusText.Text = "下载失败。";
                if (!RapidOcrModelStore.IsInstalled())
                {
                    _syncing = true;
                    EngineWindows.IsChecked = true;
                    EngineRapid.IsChecked = false;
                    _syncing = false;
                    _engine = OcrEngineKind.Windows;
                }
            }
            finally
            {
                _busy = false;
                SetUiBusy(false);
                RefreshStatus();
                _cts?.Dispose();
                _cts = null;
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (_busy) return;
            if (!RapidOcrModelStore.IsInstalled())
            {
                RefreshStatus();
                return;
            }

            var ask = MessageBox.Show(this, "确定删除已下载的 RapidOCR 模型？", "删除模型",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (ask != MessageBoxResult.Yes) return;

            RapidOcrEngine.Reset();
            RapidOcrModelStore.DeleteAll();
            _engine = OcrEngineKind.Windows;
            _syncing = true;
            EngineWindows.IsChecked = true;
            EngineRapid.IsChecked = false;
            _syncing = false;
            RefreshStatus();
        }

        private void RefreshStatus()
        {
            bool installed = RapidOcrModelStore.IsInstalled();
            bool small = RapidOcrModelStore.IsSmallInstalled();

            DeleteButton.IsEnabled = installed && !_busy;
            DownloadButton.IsEnabled = !small && !_busy;
            DownloadButton.Content = small ? "已下载" : "下载增强模型";

            if (_busy) return;

            StatusText.Text = installed
                ? $"模型已安装：{RapidOcrModelStore.PackDisplayName}\n路径：{RapidOcrModelStore.RootDir}"
                : "尚未下载增强模型。选择 RapidOCR 或点击下载后才会联网获取。";
        }

        private void SetUiBusy(bool busy)
        {
            DownloadProgress.Visibility = busy ? Visibility.Visible : Visibility.Collapsed;
            EngineWindows.IsEnabled = !busy;
            EngineRapid.IsEnabled = !busy;
            DownloadButton.IsEnabled = !busy && !RapidOcrModelStore.IsSmallInstalled();
            DeleteButton.IsEnabled = !busy && RapidOcrModelStore.IsInstalled();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (_busy)
            {
                _cts?.Cancel();
                return;
            }
            DialogResult = false;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (_busy)
            {
                MessageBox.Show(this, "请等待下载完成或取消后再保存。", "提示",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (_engine == OcrEngineKind.RapidOcr && !RapidOcrModelStore.IsInstalled())
            {
                MessageBox.Show(this, "尚未下载模型，已改回系统 OCR。", "提示",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                _engine = OcrEngineKind.Windows;
            }

            DialogResult = true;
        }

        protected override void OnClosed(EventArgs e)
        {
            _cts?.Cancel();
            base.OnClosed(e);
        }
    }
}

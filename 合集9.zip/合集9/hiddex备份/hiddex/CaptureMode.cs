namespace HiddenWindowManager
{
    /// <summary>
    /// 截图流程的目标：框选完之后自动做什么。
    /// 用枚举而不是一堆 bool，加新模式时不会出现 (ocrMode: false, stickyMode: true) 这种调用。
    /// </summary>
    public enum CaptureMode
    {
        /// <summary>正常截图：进标注界面，由用户决定复制/保存/贴图。</summary>
        Normal,

        /// <summary>提取文字：框完立刻 OCR，直接出文字窗口。</summary>
        Ocr,

        /// <summary>贴图：框完立刻钉在屏幕上，不进标注界面。</summary>
        Sticky,

        /// <summary>截图翻译：框完 OCR 后页内覆盖译文（不弹文字面板）。</summary>
        Translate
    }

    /// <summary>
    /// 全局热键的槽位。用于冲突检测 —— 检查某个组合键是否被占用时，
    /// 需要排除"正在修改的那个槽位自己"，否则没改动也会报冲突。
    /// 做成枚举是为了避免之前那种 (excludeScreenshot, excludeOcr) 布尔参数堆叠，
    /// 加一个热键就得改所有调用点，很容易漏掉某个组合。
    /// </summary>
    public enum HotkeySlot
    {
        /// <summary>不排除任何槽位（新增规则热键时用）。</summary>
        None,

        /// <summary>全局隐藏/恢复。</summary>
        HideToggle,

        /// <summary>区域截图。</summary>
        Screenshot,

        /// <summary>提取文字。</summary>
        Ocr,

        /// <summary>贴图。</summary>
        Sticky,

        /// <summary>截图翻译。</summary>
        Translate
    }
}

using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace HiddenWindowManager
{
    public class AppConfig
    {
        public List<HideRule> HideRules { get; set; } = new();

        // 全局隐藏热键：默认未设置（None）
        public uint HotkeyModifiers { get; set; } = 0;
        public uint HotkeyKey { get; set; } = 0;

        // 截图热键：默认 Ctrl + Alt + A
        public uint ScreenshotHotkeyModifiers { get; set; } = NativeMethods.MOD_CONTROL | NativeMethods.MOD_ALT;
        public uint ScreenshotHotkeyKey { get; set; } = 0x41; // VK_A

        // 提取文字热键：截图后自动跑 OCR。默认 Ctrl + Alt + T
        public uint OcrHotkeyModifiers { get; set; } = NativeMethods.MOD_CONTROL | NativeMethods.MOD_ALT;
        public uint OcrHotkeyKey { get; set; } = 0x54; // VK_T

        // 贴图热键：框选完直接钉在屏幕上。默认 Ctrl + Alt + S
        public uint StickyHotkeyModifiers { get; set; } = NativeMethods.MOD_CONTROL | NativeMethods.MOD_ALT;
        public uint StickyHotkeyKey { get; set; } = 0x53; // VK_S

        // 截图翻译热键：默认未设置（None）
        public uint TranslateHotkeyModifiers { get; set; } = 0;
        public uint TranslateHotkeyKey { get; set; } = 0;

        /// <summary>Azure Translator 订阅密钥（存在本地，勿分享 config.json）。</summary>
        public string TranslatorKey { get; set; } = string.Empty;

        /// <summary>Azure 资源区域，如 eastasia / japaneast；全局资源可留空或填 global。</summary>
        public string TranslatorRegion { get; set; } = "eastasia";

        /// <summary>目标语言 BCP-47，默认简体中文。</summary>
        public string TranslatorTargetLanguage { get; set; } = "zh-Hans";

        /// <summary>
        /// 文字识别引擎。默认 Windows；RapidOcr 需在设置中下载模型后启用。
        /// </summary>
        public OcrEngineKind OcrEngine { get; set; } = OcrEngineKind.Windows;

        public bool PasswordEnabled { get; set; } = false;
        public string PasswordHash { get; set; } = string.Empty;

        public bool RunAtStartup { get; set; } = false;
        public bool DarkTheme { get; set; } = true;

        // 旧版字段：所有工具共用一套颜色/粗细。保留只为兼容旧配置，
        // 首次加载时会迁移进 ToolStyles，之后不再使用。
        public string AnnotationColor { get; set; } = "#FF3B30";
        public double AnnotationThickness { get; set; } = 6;

        /// <summary>
        /// 每个标注工具各自的颜色和大小，键是 AnnotTool 的名字（Pen / Rectangle / ...）。
        /// 分开存是为了让"箭头调粗"不会把"矩形的细边框"也改掉。
        /// </summary>
        public Dictionary<string, ToolStyle> ToolStyles { get; set; } = new();

        /// <summary>配置迁移版本。用于一次性改掉旧默认值。</summary>
        public int ConfigVersion { get; set; } = 0;

        private static string ConfigDir =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HiddenWindowManager");

        private static string ConfigPath => Path.Combine(ConfigDir, "config.json");

        public static AppConfig Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                {
                    var json = File.ReadAllText(ConfigPath);
                    var cfg = JsonSerializer.Deserialize<AppConfig>(json);
                    if (cfg != null)
                    {
                        if (Migrate(cfg))
                            cfg.Save();
                        return cfg;
                    }
                }
            }
            catch
            {
                // 配置损坏则使用默认值
            }
            return new AppConfig();
        }

        /// <summary>
        /// 一次性迁移。返回 true 表示改过配置，调用方应 Save。
        /// </summary>
        private static bool Migrate(AppConfig cfg)
        {
            bool changed = false;

            // v1：截图翻译热键默认从 Ctrl+Alt+R 改为 None
            if (cfg.ConfigVersion < 1)
            {
                const uint legacyMods = NativeMethods.MOD_CONTROL | NativeMethods.MOD_ALT;
                const uint legacyKey = 0x52; // VK_R
                if (cfg.TranslateHotkeyKey == legacyKey && cfg.TranslateHotkeyModifiers == legacyMods)
                {
                    cfg.TranslateHotkeyKey = 0;
                    cfg.TranslateHotkeyModifiers = 0;
                }
                cfg.ConfigVersion = 1;
                changed = true;
            }

            return changed;
        }

        public void Save()
        {
            Directory.CreateDirectory(ConfigDir);
            var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(ConfigPath, json);
        }

        public static string HashPassword(string plain)
        {
            var bytes = Encoding.UTF8.GetBytes(plain);
            var hash = SHA256.HashData(bytes);
            return Convert.ToHexString(hash);
        }
    }
}

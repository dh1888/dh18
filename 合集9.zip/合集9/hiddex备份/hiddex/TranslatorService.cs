using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace HiddenWindowManager
{
    /// <summary>
    /// Microsoft Azure Translator（认知服务）文本翻译。
    /// 需要用户自备 F0/付费密钥；密钥存在本地 config.json。
    /// </summary>
    internal static class TranslatorService
    {
        private static readonly HttpClient Http = new()
        {
            Timeout = TimeSpan.FromSeconds(30)
        };

        private const string Endpoint = "https://api.cognitive.microsofttranslator.com";
        private const int MaxBatch = 40;

        /// <summary>
        /// 批量翻译。texts 与返回列表一一对应；空串原样返回。
        /// </summary>
        public static async Task<IReadOnlyList<string>> TranslateBatchAsync(
            IReadOnlyList<string> texts,
            string subscriptionKey,
            string region,
            string toLanguage,
            CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(subscriptionKey))
                throw new InvalidOperationException(
                    "尚未配置 Microsoft Translator 密钥。请在主窗口底部「截图翻译」里填写 Key 与区域。");

            if (string.IsNullOrWhiteSpace(toLanguage))
                toLanguage = "zh-Hans";

            var results = new string[texts.Count];
            for (int i = 0; i < texts.Count; i++)
                results[i] = texts[i] ?? string.Empty;

            var pending = new List<(int Index, string Text)>();
            for (int i = 0; i < texts.Count; i++)
            {
                if (!string.IsNullOrWhiteSpace(texts[i]))
                    pending.Add((i, texts[i]));
            }

            if (pending.Count == 0) return results;

            for (int offset = 0; offset < pending.Count; offset += MaxBatch)
            {
                int take = Math.Min(MaxBatch, pending.Count - offset);
                var chunk = pending.GetRange(offset, take);
                var translated = await TranslateChunkAsync(chunk.Select(c => c.Text).ToList(),
                    subscriptionKey, region, toLanguage, ct).ConfigureAwait(false);

                for (int j = 0; j < chunk.Count; j++)
                    results[chunk[j].Index] = j < translated.Count ? translated[j] : chunk[j].Text;
            }

            return results;
        }

        private static async Task<IReadOnlyList<string>> TranslateChunkAsync(
            IReadOnlyList<string> texts,
            string key,
            string region,
            string to,
            CancellationToken ct)
        {
            string path = $"/translate?api-version=3.0&to={Uri.EscapeDataString(to)}";
            using var req = new HttpRequestMessage(HttpMethod.Post, Endpoint + path);

            req.Headers.Add("Ocp-Apim-Subscription-Key", key.Trim());
            if (!string.IsNullOrWhiteSpace(region))
                req.Headers.Add("Ocp-Apim-Subscription-Region", region.Trim());

            var body = texts.Select(t => new { Text = t }).ToArray();
            req.Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");
            req.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            using var resp = await Http.SendAsync(req, ct).ConfigureAwait(false);
            string json = await resp.Content.ReadAsStringAsync(ct).ConfigureAwait(false);

            if (!resp.IsSuccessStatusCode)
            {
                string detail = TryExtractError(json) ?? $"{(int)resp.StatusCode} {resp.ReasonPhrase}";
                throw new InvalidOperationException("翻译失败：" + detail);
            }

            using var doc = JsonDocument.Parse(json);
            var list = new List<string>(texts.Count);
            foreach (var item in doc.RootElement.EnumerateArray())
            {
                string text = texts.Count > list.Count ? texts[list.Count] : string.Empty;
                if (item.TryGetProperty("translations", out var arr)
                    && arr.GetArrayLength() > 0
                    && arr[0].TryGetProperty("text", out var t))
                {
                    text = t.GetString() ?? text;
                }
                list.Add(text);
            }

            while (list.Count < texts.Count)
                list.Add(texts[list.Count]);

            return list;
        }

        private static string? TryExtractError(string json)
        {
            try
            {
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("error", out var err)
                    && err.TryGetProperty("message", out var msg))
                {
                    return msg.GetString();
                }
            }
            catch { /* ignore */ }
            return null;
        }
    }
}

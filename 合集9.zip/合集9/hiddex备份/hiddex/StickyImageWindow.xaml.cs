using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using KeyEventArgs = System.Windows.Input.KeyEventArgs;
using MessageBox = System.Windows.MessageBox;
using MouseButtonEventArgs = System.Windows.Input.MouseButtonEventArgs;
using Point = System.Windows.Point;

namespace HiddenWindowManager
{
    /// <summary>
    /// 贴图窗口：把截好的图钉在屏幕上，可拖动，Esc 只关掉当前这一张。
    /// 多张贴图各自独立，互不影响。
    /// </summary>
    public partial class StickyImageWindow : Window
    {
        private static readonly List<StickyImageWindow> _open = new();

        /// <summary>当前打开的贴图数量。</summary>
        public static int OpenCount => _open.Count;

        private readonly BitmapSource _image;

        public StickyImageWindow(BitmapSource image, Point screenTopLeft)
        {
            _image = image;
            InitializeComponent();

            Picture.Source = _image;

            // 位图是物理像素，窗口尺寸是 DIP，高 DPI 下必须换算。
            // 必须在 SourceInitialized 里做：那时 HWND 已建好（能拿到真实 DPI），
            // 但还没走第一次布局。放在 Loaded 里就晚了 —— SizeToContent 已经按
            // 位图自然 DIP 尺寸把窗口撑大，会先闪一下再缩回去。
            SourceInitialized += (_, _) => ApplyNativePixelSize();

            Left = screenTopLeft.X;
            Top = screenTopLeft.Y;

            // 平时完全无边框，看起来就是原页面的一块；
            // 悬停才显示描边和工具条，让人知道这是可操作的贴图
            MouseEnter += (_, _) =>
            {
                HoverBar.Visibility = Visibility.Visible;
                HoverOutline.Visibility = Visibility.Visible;
            };
            MouseLeave += (_, _) =>
            {
                HoverBar.Visibility = Visibility.Collapsed;
                HoverOutline.Visibility = Visibility.Collapsed;
            };

            Closed += (_, _) => _open.Remove(this);
            _open.Add(this);
        }

        /// <summary>
        /// 让 Image 以 1:1 物理像素显示：DIP 尺寸 = 像素数 / DPI 缩放。
        /// </summary>
        private void ApplyNativePixelSize()
        {
            double scaleX = 1.0, scaleY = 1.0;

            var src = PresentationSource.FromVisual(this);
            if (src?.CompositionTarget != null)
            {
                scaleX = src.CompositionTarget.TransformToDevice.M11;
                scaleY = src.CompositionTarget.TransformToDevice.M22;
            }

            if (scaleX <= 0) scaleX = 1.0;
            if (scaleY <= 0) scaleY = 1.0;

            Picture.Width = _image.PixelWidth / scaleX;
            Picture.Height = _image.PixelHeight / scaleY;
        }

        /// <summary>关闭全部贴图。主程序退出时调用。</summary>
        public static void CloseAll()
        {
            foreach (var w in _open.ToList())
            {
                try { w.Close(); } catch { /* 已经关掉了就算了 */ }
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            // 只关当前这一张，其他贴图不受影响
            if (e.Key == Key.Escape)
            {
                Close();
                e.Handled = true;
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // 双击也关掉，和常见贴图工具一致
            if (e.ClickCount == 2)
            {
                Close();
                e.Handled = true;
                return;
            }

            if (e.ButtonState == MouseButtonState.Pressed)
            {
                Activate();
                DragMove();
            }
        }

        private void Window_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            Close();
            e.Handled = true;
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            // 获得焦点说明这张是"当前贴图"，Esc 会关的就是它。
            // 描边只在悬停时可见，这里只调颜色，不改可见性。
            HoverOutline.BorderBrush = System.Windows.Media.Brushes.MediumPurple;
        }

        private void Window_Deactivated(object sender, EventArgs e)
        {
            HoverOutline.BorderBrush = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromArgb(120, 124, 107, 255));
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e) => Close();

        private void CopyButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ScreenCaptureHelper.CopyToClipboard(_image);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "复制失败：" + ex.Message, "贴图",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            bool wasTopmost = Topmost;
            Topmost = false;

            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "PNG 图片|*.png",
                FileName = $"hiddex_{DateTime.Now:yyyyMMdd_HHmmss}",
                AddExtension = true,
                DefaultExt = ".png"
            };

            bool? ok = dlg.ShowDialog(this);
            Topmost = wasTopmost;

            if (ok != true) return;

            try
            {
                ScreenCaptureHelper.SavePng(_image, dlg.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "保存失败：" + ex.Message, "贴图",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}

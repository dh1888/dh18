using System.Windows;
using System.Windows.Media;
using FlowDirection = System.Windows.FlowDirection;
using MediaColor = System.Windows.Media.Color;
using MediaFontFamily = System.Windows.Media.FontFamily;
using MediaPen = System.Windows.Media.Pen;
using WpfPoint = System.Windows.Point;

namespace HiddenWindowManager
{
    internal enum AnnotTool
    {
        Move,
        Pen,
        Highlight,
        Rectangle,
        Ellipse,
        Arrow,
        Text,
        Mosaic
    }

    /// <summary>标注编辑手柄：几何框四角 + 箭头两端。</summary>
    internal enum ShapeHandle
    {
        None,
        Body,
        NW, NE, SW, SE,
        ArrowStart,
        ArrowEnd
    }

    internal abstract class AnnotationItem
    {
        public MediaColor Color { get; set; } = Colors.Red;
        public double Thickness { get; set; } = 3;

        public abstract void Draw(DrawingContext dc);

        /// <summary>可被点选移动/缩放的标注（矩形/椭圆/箭头）。</summary>
        public virtual bool IsEditable => false;

        public virtual Rect GetEditBounds() => Rect.Empty;

        public virtual bool HitTest(WpfPoint p, double tolerance) => false;

        public virtual void Offset(double dx, double dy) { }

        public virtual void ApplyHandle(ShapeHandle handle, WpfPoint p) { }
    }

    internal sealed class PenStrokeItem : AnnotationItem
    {
        public List<WpfPoint> Points { get; } = new();

        public override void Draw(DrawingContext dc)
        {
            if (Points.Count < 2) return;
            var geo = new StreamGeometry();
            using (var ctx = geo.Open())
            {
                ctx.BeginFigure(Points[0], false, false);
                ctx.PolyLineTo(Points.Skip(1).ToList(), true, true);
            }
            geo.Freeze();
            dc.DrawGeometry(null, new MediaPen(new SolidColorBrush(Color), Thickness)
            {
                StartLineCap = PenLineCap.Round,
                EndLineCap = PenLineCap.Round,
                LineJoin = PenLineJoin.Round
            }, geo);
        }
    }

    internal sealed class HighlightItem : AnnotationItem
    {
        public Rect Bounds { get; set; }

        public override void Draw(DrawingContext dc)
        {
            var c = Color;
            c.A = 90;
            dc.DrawRectangle(new SolidColorBrush(c), null, Bounds);
        }
    }

    internal sealed class RectItem : AnnotationItem
    {
        public Rect Bounds { get; set; }

        public override bool IsEditable => true;
        public override Rect GetEditBounds() => Bounds;

        public override void Draw(DrawingContext dc)
        {
            dc.DrawRectangle(null, new MediaPen(new SolidColorBrush(Color), Thickness), Bounds);
        }

        public override bool HitTest(WpfPoint p, double tolerance)
        {
            // 点中边框或内部都可以选中/拖动（编辑场景更直观）
            var outer = Bounds;
            outer.Inflate(tolerance, tolerance);
            return outer.Contains(p);
        }

        public override void Offset(double dx, double dy)
            => Bounds = new Rect(Bounds.X + dx, Bounds.Y + dy, Bounds.Width, Bounds.Height);

        public override void ApplyHandle(ShapeHandle handle, WpfPoint p)
        {
            double l = Bounds.Left, t = Bounds.Top, r = Bounds.Right, b = Bounds.Bottom;
            switch (handle)
            {
                case ShapeHandle.NW: l = p.X; t = p.Y; break;
                case ShapeHandle.NE: r = p.X; t = p.Y; break;
                case ShapeHandle.SW: l = p.X; b = p.Y; break;
                case ShapeHandle.SE: r = p.X; b = p.Y; break;
                default: return;
            }
            Bounds = Normalize(l, t, r, b);
        }

        private static Rect Normalize(double l, double t, double r, double b)
        {
            if (r < l) (l, r) = (r, l);
            if (b < t) (t, b) = (b, t);
            return new Rect(l, t, Math.Max(2, r - l), Math.Max(2, b - t));
        }
    }

    internal sealed class EllipseItem : AnnotationItem
    {
        public Rect Bounds { get; set; }

        public override bool IsEditable => true;
        public override Rect GetEditBounds() => Bounds;

        public override void Draw(DrawingContext dc)
        {
            dc.DrawEllipse(null, new MediaPen(new SolidColorBrush(Color), Thickness),
                new WpfPoint(Bounds.X + Bounds.Width / 2, Bounds.Y + Bounds.Height / 2),
                Math.Abs(Bounds.Width / 2), Math.Abs(Bounds.Height / 2));
        }

        public override bool HitTest(WpfPoint p, double tolerance)
        {
            if (Bounds.Width < 1 || Bounds.Height < 1) return false;
            double cx = Bounds.X + Bounds.Width / 2;
            double cy = Bounds.Y + Bounds.Height / 2;
            double rx = Math.Abs(Bounds.Width / 2) + tolerance;
            double ry = Math.Abs(Bounds.Height / 2) + tolerance;
            if (rx < 1 || ry < 1) return false;

            double nx = (p.X - cx) / rx;
            double ny = (p.Y - cy) / ry;
            return nx * nx + ny * ny <= 1.0;
        }

        public override void Offset(double dx, double dy)
            => Bounds = new Rect(Bounds.X + dx, Bounds.Y + dy, Bounds.Width, Bounds.Height);

        public override void ApplyHandle(ShapeHandle handle, WpfPoint p)
        {
            double l = Bounds.Left, t = Bounds.Top, r = Bounds.Right, b = Bounds.Bottom;
            switch (handle)
            {
                case ShapeHandle.NW: l = p.X; t = p.Y; break;
                case ShapeHandle.NE: r = p.X; t = p.Y; break;
                case ShapeHandle.SW: l = p.X; b = p.Y; break;
                case ShapeHandle.SE: r = p.X; b = p.Y; break;
                default: return;
            }
            if (r < l) (l, r) = (r, l);
            if (b < t) (t, b) = (b, t);
            Bounds = new Rect(l, t, Math.Max(2, r - l), Math.Max(2, b - t));
        }
    }

    /// <summary>
    /// 文字标注。带一圈深色描边，保证在浅色/深色背景上都看得清。
    /// </summary>
    internal sealed class TextItem : AnnotationItem
    {
        public string Text { get; set; } = string.Empty;
        public WpfPoint Position { get; set; }
        public double FontSize { get; set; } = 22;

        public const string FontStack = "Microsoft YaHei UI, Segoe UI, Arial";

        public override void Draw(DrawingContext dc)
        {
            if (string.IsNullOrEmpty(Text)) return;

            var ft = new FormattedText(
                Text,
                System.Globalization.CultureInfo.CurrentUICulture,
                FlowDirection.LeftToRight,
                new Typeface(new MediaFontFamily(FontStack), FontStyles.Normal, FontWeights.SemiBold, FontStretches.Normal),
                FontSize,
                new SolidColorBrush(Color),
                1.0);

            var geo = ft.BuildGeometry(Position);

            var outline = new MediaPen(
                new SolidColorBrush(MediaColor.FromArgb(150, 0, 0, 0)),
                Math.Max(1.25, FontSize * 0.07))
            {
                LineJoin = PenLineJoin.Round
            };
            dc.DrawGeometry(null, outline, geo);
            dc.DrawGeometry(new SolidColorBrush(Color), null, geo);
        }
    }

    internal sealed class MosaicItem : AnnotationItem
    {
        public Rect Bounds { get; set; }
        public ImageSource? Pixelated { get; set; }
        public Rect LayerRect { get; set; }

        public override void Draw(DrawingContext dc)
        {
            if (Pixelated == null || Bounds.Width < 1 || Bounds.Height < 1) return;

            dc.PushClip(new RectangleGeometry(Bounds));
            dc.DrawImage(Pixelated, LayerRect);
            dc.Pop();
        }
    }

    internal sealed class ArrowItem : AnnotationItem
    {
        public WpfPoint Start { get; set; }
        public WpfPoint End { get; set; }

        public override bool IsEditable => true;

        public override Rect GetEditBounds()
        {
            double x1 = Math.Min(Start.X, End.X);
            double y1 = Math.Min(Start.Y, End.Y);
            double x2 = Math.Max(Start.X, End.X);
            double y2 = Math.Max(Start.Y, End.Y);
            return new Rect(x1, y1, Math.Max(2, x2 - x1), Math.Max(2, y2 - y1));
        }

        public override void Draw(DrawingContext dc)
        {
            var dx = End.X - Start.X;
            var dy = End.Y - Start.Y;
            var len = Math.Sqrt(dx * dx + dy * dy);
            if (len < 2) return;

            var ux = dx / len;
            var uy = dy / len;
            var px = -uy;
            var py = ux;

            double headLen = Math.Min(Math.Max(16, Thickness * 5.5), len * 0.42);
            double headHalf = headLen * 0.55;
            double shaftHalf = Math.Max(Thickness * 0.75, headHalf * 0.30);
            double joinDist = headLen * 0.62;

            var tip = End;
            var leftWing = new WpfPoint(
                End.X - ux * headLen + px * headHalf,
                End.Y - uy * headLen + py * headHalf);
            var leftJoin = new WpfPoint(
                End.X - ux * joinDist + px * shaftHalf,
                End.Y - uy * joinDist + py * shaftHalf);
            var rightJoin = new WpfPoint(
                End.X - ux * joinDist - px * shaftHalf,
                End.Y - uy * joinDist - py * shaftHalf);
            var rightWing = new WpfPoint(
                End.X - ux * headLen - px * headHalf,
                End.Y - uy * headLen - py * headHalf);
            var tail = Start;

            var geo = new StreamGeometry { FillRule = FillRule.Nonzero };
            using (var ctx = geo.Open())
            {
                ctx.BeginFigure(tip, isFilled: true, isClosed: true);
                ctx.LineTo(leftWing, true, false);
                ctx.LineTo(leftJoin, true, false);
                ctx.LineTo(tail, true, false);
                ctx.LineTo(rightJoin, true, false);
                ctx.LineTo(rightWing, true, false);
            }
            geo.Freeze();
            dc.DrawGeometry(new SolidColorBrush(Color), null, geo);
        }

        public override bool HitTest(WpfPoint p, double tolerance)
        {
            double dist = DistanceToSegment(p, Start, End);
            return dist <= Math.Max(tolerance, Thickness * 1.8 + 4);
        }

        public override void Offset(double dx, double dy)
        {
            Start = new WpfPoint(Start.X + dx, Start.Y + dy);
            End = new WpfPoint(End.X + dx, End.Y + dy);
        }

        public override void ApplyHandle(ShapeHandle handle, WpfPoint p)
        {
            if (handle == ShapeHandle.ArrowStart) Start = p;
            else if (handle == ShapeHandle.ArrowEnd) End = p;
        }

        private static double DistanceToSegment(WpfPoint p, WpfPoint a, WpfPoint b)
        {
            double dx = b.X - a.X;
            double dy = b.Y - a.Y;
            double len2 = dx * dx + dy * dy;
            if (len2 < 1e-6) return (p - a).Length;
            double t = Math.Clamp(((p.X - a.X) * dx + (p.Y - a.Y) * dy) / len2, 0, 1);
            double qx = a.X + t * dx;
            double qy = a.Y + t * dy;
            return Math.Sqrt((p.X - qx) * (p.X - qx) + (p.Y - qy) * (p.Y - qy));
        }
    }
}

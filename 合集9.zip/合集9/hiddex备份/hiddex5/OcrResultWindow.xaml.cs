using System.Windows;
using System.Windows.Input;
using KeyEventArgs = System.Windows.Input.KeyEventArgs;
using MessageBox = System.Windows.MessageBox;

namespace HiddenWindowManager
{
    /// <summary>
    /// OCR 结果窗口。独立窗口而非叠加层，因为截图遮罩窗口开了
    /// AllowsTransparency=True，那会让整个窗口失去 ClearType，文字发虚。
    /// </summary>
    public partial class OcrResultWindow : Window
    {
        /// <summary>用户点了"返回标注"（而不是关闭/复制）。</summary>
        public bool WantsBackToAnnotate { get; private set; }

        public string Text => ResultBox.Text;

        public OcrResultWindow(string text, string meta, string? notice = null)
        {
            InitializeComponent();

            ResultBox.Text = text;
            MetaText.Text = meta;

            if (!string.IsNullOrWhiteSpace(notice))
            {
                NoticeText.Text = notice;
                NoticeBorder.Visibility = Visibility.Visible;
            }

            Loaded += (_, _) =>
            {
                ResultBox.Focus();
                ResultBox.SelectAll();
                Keyboard.Focus(ResultBox);
            };
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
                DragMove();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                DialogResult = false;
                e.Handled = true;
                return;
            }

            if (e.Key == Key.Enter && Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
            {
                CopyAndClose();
                e.Handled = true;
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e) => DialogResult = false;

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            WantsBackToAnnotate = true;
            DialogResult = false;
        }

        private void CopyButton_Click(object sender, RoutedEventArgs e) => CopyAndClose();

        private void CopyAndClose()
        {
            string text = ResultBox.Text;
            if (string.IsNullOrWhiteSpace(text)) return;

            try
            {
                System.Windows.Clipboard.SetText(text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "写入剪贴板失败：" + ex.Message, "OCR",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
        }
    }
}
